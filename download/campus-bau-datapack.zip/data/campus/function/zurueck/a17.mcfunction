# Abschnitt a17: x 136..199, z -318..-255 (14818 Blöcke)
forceload add 136 -318 199 -255
tellraw @a {"text":"Campus zurueck a17: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a17_1 2s
