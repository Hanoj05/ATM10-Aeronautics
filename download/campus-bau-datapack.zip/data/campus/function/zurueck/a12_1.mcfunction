setblock 278 72 -321 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 264 72 -322 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 72 -322 279 72 -322 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 311 72 -322 minecraft:air
fill 264 72 -323 265 72 -323 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 278 72 -323 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 264 72 -324 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 279 72 -327 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 265 72 -328 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 278 72 -328 279 72 -328 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 72 -329 266 72 -329 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 279 72 -329 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 265 72 -330 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 311 72 -346 minecraft:air
setblock 311 72 -370 minecraft:air
fill 264 71 -319 265 71 -319 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 71 -320 278 71 -320 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 311 71 -320 minecraft:air
fill 264 71 -321 265 71 -321 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 276 71 -321 279 71 -321 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 310 71 -321 312 71 -321 minecraft:air
fill 264 71 -322 266 71 -322 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 276 71 -322 279 71 -322 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 309 71 -322 313 71 -322 minecraft:air
fill 264 71 -323 266 71 -323 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 276 71 -323 279 71 -323 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 310 71 -323 312 71 -323 minecraft:air
fill 264 71 -324 266 71 -324 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 71 -324 279 71 -324 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 311 71 -324 minecraft:air
fill 264 71 -325 265 71 -325 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 278 71 -326 279 71 -326 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 71 -327 266 71 -327 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 71 -327 279 71 -327 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 71 -328 267 71 -328 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 71 -328 279 71 -328 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 71 -329 267 71 -329 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 71 -329 279 71 -329 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 71 -330 267 71 -330 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 278 71 -330 279 71 -330 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 71 -331 266 71 -331 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 311 71 -344 minecraft:air
fill 310 71 -345 312 71 -345 minecraft:air
fill 309 71 -346 313 71 -346 minecraft:air
fill 310 71 -347 312 71 -347 minecraft:air
setblock 311 71 -348 minecraft:air
setblock 311 71 -368 minecraft:air
fill 310 71 -369 312 71 -369 minecraft:air
fill 309 71 -370 313 71 -370 minecraft:air
fill 310 71 -371 312 71 -371 minecraft:air
setblock 311 71 -372 minecraft:air
fill 264 70 -319 265 70 -319 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 70 -320 278 70 -320 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 310 70 -320 312 70 -320 minecraft:air
fill 264 70 -321 265 70 -321 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 276 70 -321 279 70 -321 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 309 70 -321 313 70 -321 minecraft:air
fill 264 70 -322 266 70 -322 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 276 70 -322 279 70 -322 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 309 70 -322 313 70 -322 minecraft:air
fill 264 70 -323 266 70 -323 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 276 70 -323 279 70 -323 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 309 70 -323 313 70 -323 minecraft:air
fill 264 70 -324 266 70 -324 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 70 -324 279 70 -324 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 310 70 -324 312 70 -324 minecraft:air
fill 264 70 -325 265 70 -325 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 278 70 -326 279 70 -326 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 70 -327 266 70 -327 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 70 -327 279 70 -327 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 70 -328 267 70 -328 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 70 -328 279 70 -328 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 70 -329 267 70 -329 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 70 -329 279 70 -329 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 70 -330 267 70 -330 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 278 70 -330 279 70 -330 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 70 -331 266 70 -331 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 310 70 -344 312 70 -344 minecraft:air
fill 309 70 -345 313 70 -345 minecraft:air
fill 309 70 -346 313 70 -346 minecraft:air
fill 309 70 -347 313 70 -347 minecraft:air
fill 310 70 -348 312 70 -348 minecraft:air
fill 310 70 -368 312 70 -368 minecraft:air
fill 309 70 -369 313 70 -369 minecraft:air
fill 309 70 -370 313 70 -370 minecraft:air
fill 309 70 -371 313 70 -371 minecraft:air
fill 310 70 -372 312 70 -372 minecraft:air
setblock 311 69 -320 minecraft:air
fill 277 69 -321 279 69 -321 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 310 69 -321 312 69 -321 minecraft:air
fill 264 69 -322 265 69 -322 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 277 69 -322 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 278 69 -322 ars_nouveau:green_archwood_log[axis=y]
setblock 279 69 -322 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 309 69 -322 313 69 -322 minecraft:air
setblock 264 69 -323 ars_nouveau:green_archwood_log[axis=y]
setblock 265 69 -323 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 69 -323 279 69 -323 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 310 69 -323 312 69 -323 minecraft:air
fill 264 69 -324 265 69 -324 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 311 69 -324 minecraft:air
fill 278 69 -327 279 69 -327 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 69 -328 266 69 -328 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 278 69 -328 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 279 69 -328 ars_nouveau:green_archwood_log[axis=y]
setblock 264 69 -329 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 265 69 -329 ars_nouveau:green_archwood_log[axis=y]
setblock 266 69 -329 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 278 69 -329 279 69 -329 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 264 69 -330 266 69 -330 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 311 69 -344 minecraft:air
fill 310 69 -345 312 69 -345 minecraft:air
fill 309 69 -346 313 69 -346 minecraft:air
fill 310 69 -347 312 69 -347 minecraft:air
setblock 311 69 -348 minecraft:air
setblock 311 69 -368 minecraft:air
fill 310 69 -369 312 69 -369 minecraft:air
fill 309 69 -370 313 69 -370 minecraft:air
fill 310 69 -371 312 69 -371 minecraft:air
setblock 311 69 -372 minecraft:air
setblock 278 68 -322 ars_nouveau:green_archwood_log[axis=y]
setblock 311 68 -322 minecraft:air
setblock 264 68 -323 ars_nouveau:green_archwood_log[axis=y]
setblock 279 68 -328 ars_nouveau:green_archwood_log[axis=y]
setblock 265 68 -329 ars_nouveau:green_archwood_log[axis=y]
setblock 311 68 -346 minecraft:air
setblock 311 68 -370 minecraft:air
setblock 278 67 -322 ars_nouveau:green_archwood_log[axis=y]
setblock 311 67 -322 minecraft:air
setblock 264 67 -323 ars_nouveau:green_archwood_log[axis=y]
setblock 279 67 -328 ars_nouveau:green_archwood_log[axis=y]
setblock 265 67 -329 ars_nouveau:green_archwood_log[axis=y]
setblock 311 67 -346 minecraft:air
setblock 311 67 -370 minecraft:air
setblock 277 66 -320 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 306 66 -320 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 278 66 -322 ars_nouveau:green_archwood_log[axis=y]
setblock 311 66 -322 minecraft:air
setblock 264 66 -323 ars_nouveau:green_archwood_log[axis=y]
setblock 288 66 -327 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 279 66 -328 ars_nouveau:green_archwood_log[axis=y]
setblock 265 66 -329 ars_nouveau:green_archwood_log[axis=y]
setblock 319 66 -331 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 302 66 -333 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 322 66 -340 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 311 66 -346 minecraft:air
setblock 311 66 -347 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 325 66 -356 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 301 66 -358 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 312 66 -365 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 311 66 -370 minecraft:air
setblock 300 66 -371 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 321 66 -372 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 272 66 -378 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 308 66 -378 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 268 66 -380 evilcraft:blood_stain
fill 264 65 -319 266 65 -319 minecraft:grass_block[snowy=false]
fill 276 65 -319 278 65 -319 minecraft:grass_block[snowy=false]
fill 279 65 -319 327 65 -319 minecraft:black_concrete
fill 264 65 -320 266 65 -320 minecraft:grass_block[snowy=false]
fill 276 65 -320 278 65 -320 minecraft:grass_block[snowy=false]
fill 280 65 -320 327 65 -320 minecraft:black_concrete
fill 264 65 -321 266 65 -321 minecraft:grass_block[snowy=false]
fill 276 65 -321 279 65 -321 minecraft:grass_block[snowy=false]
fill 281 65 -321 327 65 -321 minecraft:black_concrete
fill 264 65 -322 266 65 -322 minecraft:grass_block[snowy=false]
fill 276 65 -322 277 65 -322 minecraft:grass_block[snowy=false]
setblock 278 65 -322 minecraft:dirt
setblock 279 65 -322 minecraft:grass_block[snowy=false]
fill 281 65 -322 327 65 -322 minecraft:black_concrete
setblock 264 65 -323 minecraft:dirt
fill 265 65 -323 266 65 -323 minecraft:grass_block[snowy=false]
fill 276 65 -323 279 65 -323 minecraft:grass_block[snowy=false]
fill 281 65 -323 327 65 -323 minecraft:black_concrete
fill 264 65 -324 266 65 -324 minecraft:grass_block[snowy=false]
fill 276 65 -324 279 65 -324 minecraft:grass_block[snowy=false]
fill 280 65 -324 327 65 -324 minecraft:black_concrete
fill 264 65 -325 266 65 -325 minecraft:grass_block[snowy=false]
fill 276 65 -325 279 65 -325 minecraft:grass_block[snowy=false]
fill 280 65 -325 327 65 -325 minecraft:black_concrete
fill 264 65 -326 266 65 -326 minecraft:grass_block[snowy=false]
fill 276 65 -326 279 65 -326 minecraft:grass_block[snowy=false]
fill 281 65 -326 327 65 -326 minecraft:black_concrete
fill 264 65 -327 267 65 -327 minecraft:grass_block[snowy=false]
setblock 269 65 -327 minecraft:black_concrete
setblock 275 65 -327 minecraft:black_concrete
fill 277 65 -327 279 65 -327 minecraft:grass_block[snowy=false]
fill 282 65 -327 327 65 -327 minecraft:black_concrete
fill 264 65 -328 267 65 -328 minecraft:grass_block[snowy=false]
setblock 269 65 -328 minecraft:black_concrete
setblock 275 65 -328 minecraft:black_concrete
fill 277 65 -328 278 65 -328 minecraft:grass_block[snowy=false]
setblock 279 65 -328 minecraft:dirt
fill 282 65 -328 327 65 -328 minecraft:black_concrete
setblock 264 65 -329 minecraft:grass_block[snowy=false]
setblock 265 65 -329 minecraft:dirt
fill 266 65 -329 267 65 -329 minecraft:grass_block[snowy=false]
setblock 269 65 -329 minecraft:black_concrete
setblock 275 65 -329 minecraft:black_concrete
fill 277 65 -329 279 65 -329 minecraft:grass_block[snowy=false]
fill 282 65 -329 327 65 -329 minecraft:black_concrete
fill 264 65 -330 267 65 -330 minecraft:grass_block[snowy=false]
setblock 269 65 -330 minecraft:black_concrete
setblock 275 65 -330 minecraft:black_concrete
fill 277 65 -330 279 65 -330 minecraft:grass_block[snowy=false]
fill 281 65 -330 327 65 -330 minecraft:black_concrete
fill 264 65 -331 267 65 -331 minecraft:grass_block[snowy=false]
setblock 269 65 -331 minecraft:black_concrete
setblock 275 65 -331 minecraft:black_concrete
fill 277 65 -331 279 65 -331 minecraft:grass_block[snowy=false]
fill 280 65 -331 327 65 -331 minecraft:black_concrete
setblock 264 65 -332 minecraft:black_concrete
fill 265 65 -332 267 65 -332 minecraft:grass_block[snowy=false]
setblock 269 65 -332 minecraft:black_concrete
setblock 275 65 -332 minecraft:black_concrete
setblock 277 65 -332 minecraft:grass_block[snowy=false]
fill 278 65 -332 327 65 -332 minecraft:black_concrete
fill 264 65 -333 266 65 -333 minecraft:black_concrete
setblock 267 65 -333 minecraft:grass_block[snowy=false]
setblock 269 65 -333 minecraft:black_concrete
fill 273 65 -333 285 65 -333 minecraft:black_concrete
setblock 287 65 -333 minecraft:black_concrete
fill 289 65 -333 327 65 -333 minecraft:black_concrete
fill 264 65 -334 282 65 -334 minecraft:black_concrete
setblock 284 65 -334 minecraft:black_concrete
setblock 290 65 -334 minecraft:black_concrete
fill 292 65 -334 327 65 -334 minecraft:black_concrete
fill 265 65 -335 279 65 -335 minecraft:black_concrete
setblock 281 65 -335 minecraft:black_concrete
setblock 293 65 -335 minecraft:black_concrete
fill 295 65 -335 327 65 -335 minecraft:black_concrete
fill 266 65 -336 278 65 -336 minecraft:black_concrete
fill 296 65 -336 327 65 -336 minecraft:black_concrete
fill 267 65 -337 277 65 -337 minecraft:black_concrete
fill 297 65 -337 327 65 -337 minecraft:black_concrete
fill 268 65 -338 276 65 -338 minecraft:black_concrete
fill 298 65 -338 327 65 -338 minecraft:black_concrete
fill 267 65 -339 277 65 -339 minecraft:black_concrete
fill 297 65 -339 327 65 -339 minecraft:black_concrete
fill 268 65 -340 276 65 -340 minecraft:black_concrete
fill 298 65 -340 327 65 -340 minecraft:black_concrete
fill 269 65 -341 275 65 -341 minecraft:black_concrete
fill 299 65 -341 327 65 -341 minecraft:black_concrete
fill 268 65 -342 276 65 -342 minecraft:black_concrete
fill 298 65 -342 327 65 -342 minecraft:black_concrete
fill 269 65 -343 275 65 -343 minecraft:black_concrete
fill 299 65 -343 327 65 -343 minecraft:black_concrete
fill 269 65 -344 275 65 -344 minecraft:black_concrete
fill 300 65 -344 327 65 -344 minecraft:black_concrete
fill 299 65 -345 327 65 -345 minecraft:black_concrete
fill 300 65 -346 327 65 -346 minecraft:black_concrete
fill 299 65 -347 327 65 -347 minecraft:black_concrete
fill 298 65 -348 327 65 -348 minecraft:black_concrete
fill 299 65 -349 327 65 -349 minecraft:black_concrete
fill 298 65 -350 327 65 -350 minecraft:black_concrete
fill 297 65 -351 327 65 -351 minecraft:black_concrete
fill 298 65 -352 327 65 -352 minecraft:black_concrete
fill 297 65 -353 327 65 -353 minecraft:black_concrete
fill 296 65 -354 327 65 -354 minecraft:black_concrete
setblock 293 65 -355 minecraft:black_concrete
fill 295 65 -355 327 65 -355 minecraft:black_concrete
setblock 290 65 -356 minecraft:black_concrete
fill 292 65 -356 327 65 -356 minecraft:black_concrete
fill 288 65 -357 327 65 -357 minecraft:black_concrete
fill 288 65 -358 327 65 -358 minecraft:black_concrete
fill 288 65 -359 327 65 -359 minecraft:black_concrete
fill 288 65 -360 327 65 -360 minecraft:black_concrete
fill 288 65 -361 327 65 -361 minecraft:black_concrete
fill 288 65 -362 327 65 -362 minecraft:black_concrete
fill 288 65 -363 327 65 -363 minecraft:black_concrete
setblock 290 65 -364 minecraft:black_concrete
fill 292 65 -364 327 65 -364 minecraft:black_concrete
setblock 293 65 -365 minecraft:black_concrete
fill 295 65 -365 327 65 -365 minecraft:black_concrete
fill 296 65 -366 327 65 -366 minecraft:black_concrete
fill 297 65 -367 327 65 -367 minecraft:black_concrete
fill 298 65 -368 327 65 -368 minecraft:black_concrete
fill 297 65 -369 327 65 -369 minecraft:black_concrete
fill 298 65 -370 327 65 -370 minecraft:black_concrete
fill 299 65 -371 327 65 -371 minecraft:black_concrete
fill 298 65 -372 327 65 -372 minecraft:black_concrete
fill 299 65 -373 327 65 -373 minecraft:black_concrete
fill 300 65 -374 327 65 -374 minecraft:black_concrete
fill 299 65 -375 327 65 -375 minecraft:black_concrete
fill 269 65 -376 275 65 -376 minecraft:black_concrete
fill 300 65 -376 327 65 -376 minecraft:black_concrete
fill 269 65 -377 275 65 -377 minecraft:black_concrete
fill 299 65 -377 327 65 -377 minecraft:black_concrete
fill 268 65 -378 276 65 -378 minecraft:black_concrete
fill 298 65 -378 327 65 -378 minecraft:black_concrete
fill 269 65 -379 275 65 -379 minecraft:black_concrete
fill 299 65 -379 327 65 -379 minecraft:black_concrete
fill 268 65 -380 276 65 -380 minecraft:black_concrete
fill 298 65 -380 327 65 -380 minecraft:black_concrete
fill 267 65 -381 276 65 -381 minecraft:black_concrete
setblock 277 65 -381 minecraft:stone
fill 297 65 -381 309 65 -381 minecraft:black_concrete
fill 310 65 -381 311 65 -381 alltheores:aluminum_ore
fill 312 65 -381 327 65 -381 minecraft:black_concrete
fill 268 65 -382 276 65 -382 minecraft:black_concrete
fill 298 65 -382 310 65 -382 minecraft:black_concrete
fill 311 65 -382 312 65 -382 minecraft:sandstone
fill 313 65 -382 327 65 -382 minecraft:black_concrete
fill 289 64 -319 309 64 -319 minecraft:air
fill 290 64 -320 309 64 -320 minecraft:air
fill 291 64 -321 308 64 -321 minecraft:air
fill 291 64 -322 307 64 -322 minecraft:air
setblock 291 64 -323 minecraft:short_grass
fill 292 64 -323 306 64 -323 minecraft:air
fill 292 64 -324 305 64 -324 minecraft:air
fill 291 64 -325 304 64 -325 minecraft:air
setblock 305 64 -325 minecraft:short_grass
setblock 289 64 -326 minecraft:air
setblock 290 64 -326 minecraft:tall_grass[half=upper]
fill 291 64 -326 303 64 -326 minecraft:air
setblock 304 64 -326 regions_unexplored:grass_sprouts
setblock 305 64 -326 minecraft:air
fill 278 64 -327 280 64 -327 minecraft:air
fill 289 64 -327 292 64 -327 minecraft:air
fill 294 64 -327 304 64 -327 minecraft:air
fill 272 64 -328 282 64 -328 minecraft:air
fill 289 64 -328 302 64 -328 minecraft:air
setblock 303 64 -328 regions_unexplored:grass_sprouts
fill 272 64 -329 277 64 -329 minecraft:air
fill 278 64 -329 280 64 -329 minecraft:short_grass
setblock 281 64 -329 minecraft:air
setblock 282 64 -329 minecraft:short_grass
fill 290 64 -329 304 64 -329 minecraft:air
fill 271 64 -330 273 64 -330 minecraft:air
setblock 274 64 -330 regions_unexplored:grass_sprouts
fill 275 64 -330 279 64 -330 minecraft:air
setblock 280 64 -330 minecraft:short_grass
fill 281 64 -330 282 64 -330 minecraft:air
setblock 283 64 -330 regions_unexplored:grass_sprouts
fill 291 64 -330 293 64 -330 minecraft:air
fill 298 64 -330 303 64 -330 minecraft:air
setblock 304 64 -330 minecraft:short_grass
setblock 305 64 -330 regions_unexplored:grass_sprouts
setblock 306 64 -330 minecraft:air
fill 267 64 -331 268 64 -331 minecraft:air
setblock 271 64 -331 minecraft:air
setblock 272 64 -331 ars_nouveau:light_block[level=14,waterlogged=false]
fill 273 64 -331 275 64 -331 minecraft:air
fill 276 64 -331 277 64 -331 regions_unexplored:grass_sprouts
fill 278 64 -331 285 64 -331 minecraft:air
setblock 292 64 -331 minecraft:air
setblock 300 64 -331 minecraft:air
setblock 301 64 -331 minecraft:short_grass
setblock 302 64 -331 minecraft:air
setblock 303 64 -331 regions_unexplored:grass_sprouts
fill 304 64 -331 306 64 -331 minecraft:air
setblock 307 64 -331 minecraft:short_grass
setblock 308 64 -331 regions_unexplored:grass_sprouts
setblock 309 64 -331 minecraft:air
setblock 310 64 -331 minecraft:short_grass
fill 266 64 -332 268 64 -332 minecraft:air
fill 270 64 -332 285 64 -332 minecraft:air
fill 302 64 -332 304 64 -332 minecraft:air
setblock 305 64 -332 regions_unexplored:grass_sprouts
fill 306 64 -332 307 64 -332 minecraft:air
setblock 308 64 -332 minecraft:short_grass
fill 309 64 -332 312 64 -332 minecraft:air
fill 266 64 -333 267 64 -333 minecraft:air
fill 270 64 -333 276 64 -333 minecraft:air
setblock 277 64 -333 regions_unexplored:grass_sprouts
fill 278 64 -333 286 64 -333 minecraft:air
fill 303 64 -333 312 64 -333 minecraft:air
setblock 270 64 -334 minecraft:air
setblock 272 64 -334 regions_unexplored:grass_sprouts
fill 273 64 -334 276 64 -334 minecraft:air
setblock 277 64 -334 regions_unexplored:grass_sprouts
fill 278 64 -334 287 64 -334 minecraft:air
fill 304 64 -334 305 64 -334 minecraft:air
setblock 306 64 -334 minecraft:short_grass
fill 307 64 -334 309 64 -334 minecraft:air
setblock 310 64 -334 regions_unexplored:grass_sprouts
fill 311 64 -334 312 64 -334 minecraft:air
setblock 313 64 -334 regions_unexplored:grass_sprouts
fill 270 64 -335 276 64 -335 minecraft:air
setblock 277 64 -335 minecraft:short_grass
fill 278 64 -335 288 64 -335 minecraft:air
fill 304 64 -335 309 64 -335 minecraft:air
setblock 310 64 -335 regions_unexplored:grass_sprouts
setblock 311 64 -335 minecraft:air
setblock 312 64 -335 regions_unexplored:grass_sprouts
setblock 313 64 -335 minecraft:air
fill 270 64 -336 276 64 -336 minecraft:air
setblock 277 64 -336 minecraft:short_grass
fill 278 64 -336 288 64 -336 minecraft:air
fill 305 64 -336 312 64 -336 minecraft:air
setblock 313 64 -336 minecraft:short_grass
setblock 314 64 -336 minecraft:air
setblock 315 64 -336 regions_unexplored:grass_sprouts
fill 270 64 -337 289 64 -337 minecraft:air
setblock 305 64 -337 minecraft:short_grass
fill 306 64 -337 311 64 -337 minecraft:air
setblock 312 64 -337 minecraft:short_grass
fill 313 64 -337 316 64 -337 minecraft:air
setblock 317 64 -337 minecraft:short_grass
fill 318 64 -337 320 64 -337 minecraft:air
fill 269 64 -338 277 64 -338 minecraft:air
setblock 278 64 -338 minecraft:short_grass
fill 279 64 -338 287 64 -338 minecraft:air
setblock 288 64 -338 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 289 64 -338 minecraft:air
fill 306 64 -338 313 64 -338 minecraft:air
setblock 314 64 -338 minecraft:short_grass
fill 315 64 -338 318 64 -338 minecraft:air
fill 319 64 -338 320 64 -338 minecraft:short_grass
fill 321 64 -338 323 64 -338 minecraft:air
fill 270 64 -339 274 64 -339 minecraft:air
setblock 276 64 -339 regions_unexplored:grass_sprouts
setblock 277 64 -339 minecraft:air
setblock 278 64 -339 minecraft:short_grass
fill 279 64 -339 289 64 -339 minecraft:air
setblock 306 64 -339 regions_unexplored:grass_sprouts
fill 307 64 -339 312 64 -339 minecraft:air
fill 314 64 -339 315 64 -339 minecraft:air
fill 317 64 -339 322 64 -339 minecraft:air
fill 323 64 -339 324 64 -339 minecraft:short_grass
fill 325 64 -339 326 64 -339 minecraft:air
fill 268 64 -340 271 64 -340 minecraft:air
setblock 272 64 -340 regions_unexplored:grass_sprouts
fill 273 64 -340 289 64 -340 minecraft:air
fill 307 64 -340 310 64 -340 minecraft:air
fill 312 64 -340 324 64 -340 minecraft:air
fill 325 64 -340 326 64 -340 minecraft:short_grass
setblock 327 64 -340 minecraft:air
fill 268 64 -341 272 64 -341 minecraft:air
setblock 273 64 -341 minecraft:short_grass
fill 274 64 -341 289 64 -341 minecraft:air
setblock 309 64 -341 minecraft:air
fill 310 64 -341 311 64 -341 minecraft:short_grass
setblock 312 64 -341 regions_unexplored:grass_sprouts
setblock 313 64 -341 minecraft:air
setblock 315 64 -341 minecraft:air
fill 319 64 -341 327 64 -341 minecraft:air
setblock 268 64 -342 regions_unexplored:grass_sprouts
fill 269 64 -342 290 64 -342 minecraft:air
fill 312 64 -342 313 64 -342 minecraft:air
setblock 314 64 -342 regions_unexplored:grass_sprouts
setblock 315 64 -342 minecraft:air
fill 317 64 -342 327 64 -342 minecraft:air
setblock 267 64 -343 minecraft:air
setblock 268 64 -343 minecraft:short_grass
fill 269 64 -343 273 64 -343 minecraft:air
setblock 274 64 -343 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 275 64 -343 regions_unexplored:grass_sprouts
fill 276 64 -343 292 64 -343 minecraft:air
fill 315 64 -343 316 64 -343 minecraft:air
setblock 317 64 -343 regions_unexplored:grass_sprouts
fill 318 64 -343 327 64 -343 minecraft:air
setblock 266 64 -344 minecraft:air
setblock 267 64 -344 regions_unexplored:grass_sprouts
fill 268 64 -344 274 64 -344 minecraft:air
setblock 275 64 -344 minecraft:short_grass
setblock 276 64 -344 minecraft:air
fill 278 64 -344 292 64 -344 minecraft:air
setblock 316 64 -344 minecraft:air
setblock 317 64 -344 regions_unexplored:grass_sprouts
fill 319 64 -344 327 64 -344 minecraft:air
fill 268 64 -345 272 64 -345 minecraft:air
fill 274 64 -345 275 64 -345 minecraft:air
fill 277 64 -345 292 64 -345 minecraft:air
setblock 306 64 -345 minecraft:air
fill 317 64 -345 327 64 -345 minecraft:air
fill 270 64 -346 273 64 -346 minecraft:air
setblock 274 64 -346 regions_unexplored:grass_sprouts
setblock 275 64 -346 minecraft:air
fill 277 64 -346 292 64 -346 minecraft:air
fill 307 64 -346 308 64 -346 minecraft:air
setblock 319 64 -346 minecraft:air
setblock 320 64 -346 minecraft:short_grass
fill 321 64 -346 327 64 -346 minecraft:air
fill 272 64 -347 274 64 -347 minecraft:air
fill 277 64 -347 278 64 -347 minecraft:air
fill 280 64 -347 286 64 -347 minecraft:air
fill 288 64 -347 292 64 -347 minecraft:air
fill 308 64 -347 310 64 -347 minecraft:air
fill 320 64 -347 321 64 -347 minecraft:air
setblock 322 64 -347 regions_unexplored:grass_sprouts
fill 323 64 -347 324 64 -347 minecraft:short_grass
fill 325 64 -347 326 64 -347 minecraft:air
fill 277 64 -348 286 64 -348 minecraft:air
fill 288 64 -348 292 64 -348 minecraft:air
fill 309 64 -348 311 64 -348 minecraft:air
fill 323 64 -348 327 64 -348 minecraft:air
setblock 278 64 -349 regions_unexplored:grass_sprouts
setblock 279 64 -349 minecraft:air
fill 281 64 -349 288 64 -349 minecraft:air
fill 311 64 -349 313 64 -349 minecraft:air
setblock 326 64 -349 minecraft:air
setblock 327 64 -349 minecraft:short_grass
fill 279 64 -350 282 64 -350 minecraft:air
setblock 312 64 -350 regions_unexplored:grass_sprouts
fill 313 64 -350 315 64 -350 minecraft:air
setblock 327 64 -350 minecraft:air
setblock 280 64 -351 minecraft:air
fill 314 64 -351 316 64 -351 minecraft:air
fill 316 64 -352 318 64 -352 minecraft:air
fill 318 64 -353 319 64 -353 minecraft:air
setblock 321 64 -354 minecraft:air
fill 280 64 -363 281 64 -363 minecraft:air
fill 280 64 -364 282 64 -364 minecraft:air
fill 281 64 -365 282 64 -365 minecraft:air
fill 292 63 -319 293 63 -319 minecraft:air
fill 295 63 -319 308 63 -319 minecraft:air
fill 293 63 -320 308 63 -320 minecraft:air
fill 293 63 -321 305 63 -321 minecraft:air
setblock 307 63 -321 minecraft:air
fill 293 63 -322 306 63 -322 minecraft:air
fill 293 63 -323 304 63 -323 minecraft:air
setblock 305 63 -323 regions_unexplored:grass_sprouts
fill 294 63 -324 304 63 -324 minecraft:air
fill 293 63 -325 304 63 -325 minecraft:air
setblock 290 63 -326 minecraft:tall_grass[half=lower]
fill 293 63 -326 303 63 -326 minecraft:air
fill 290 63 -327 292 63 -327 minecraft:air
fill 294 63 -327 297 63 -327 minecraft:air
fill 299 63 -327 303 63 -327 minecraft:air
fill 290 63 -328 302 63 -328 minecraft:air
fill 292 63 -329 294 63 -329 minecraft:air
setblock 298 63 -329 minecraft:air
setblock 299 63 -329 minecraft:short_grass
setblock 300 63 -329 minecraft:air
setblock 301 63 -329 minecraft:short_grass
setblock 302 63 -329 regions_unexplored:grass_sprouts
fill 293 63 -330 294 63 -330 minecraft:air
setblock 300 63 -330 minecraft:air
fill 268 63 -331 269 63 -331 minecraft:air
fill 267 63 -332 269 63 -332 minecraft:air
fill 266 63 -333 268 63 -333 minecraft:air
setblock 308 63 -333 minecraft:air
setblock 307 63 -334 regions_unexplored:grass_sprouts
setblock 308 63 -334 minecraft:short_grass
setblock 309 63 -334 minecraft:air
setblock 307 63 -335 minecraft:air
setblock 308 63 -335 regions_unexplored:grass_sprouts
setblock 309 63 -335 minecraft:air
setblock 307 63 -336 regions_unexplored:grass_sprouts
fill 308 63 -336 310 63 -336 minecraft:air
fill 308 63 -337 310 63 -337 minecraft:air
fill 308 63 -338 310 63 -338 minecraft:air
fill 310 63 -339 312 63 -339 minecraft:air
fill 314 63 -339 315 63 -339 regions_unexplored:grass_sprouts
fill 317 63 -339 318 63 -339 minecraft:short_grass
fill 319 63 -339 321 63 -339 minecraft:air
setblock 310 63 -340 minecraft:air
fill 312 63 -340 318 63 -340 minecraft:air
setblock 319 63 -340 minecraft:short_grass
fill 320 63 -340 323 63 -340 minecraft:air
setblock 313 63 -341 minecraft:short_grass
setblock 315 63 -341 minecraft:air
fill 319 63 -341 320 63 -341 minecraft:air
setblock 321 63 -341 regions_unexplored:grass_sprouts
fill 322 63 -341 326 63 -341 minecraft:air
setblock 327 63 -341 regions_unexplored:grass_sprouts
fill 317 63 -342 327 63 -342 minecraft:air
fill 318 63 -343 319 63 -343 minecraft:short_grass
fill 320 63 -343 322 63 -343 minecraft:air
setblock 324 63 -343 minecraft:air
fill 326 63 -343 327 63 -343 minecraft:air
fill 319 63 -344 321 63 -344 minecraft:air
setblock 323 63 -344 minecraft:air
fill 326 63 -344 327 63 -344 minecraft:air
fill 320 63 -345 321 63 -345 minecraft:air
fill 322 63 -345 323 63 -345 regions_unexplored:grass_sprouts
fill 324 63 -345 327 63 -345 minecraft:air
setblock 308 63 -346 minecraft:air
setblock 322 63 -346 minecraft:short_grass
setblock 323 63 -346 regions_unexplored:grass_sprouts
fill 324 63 -346 327 63 -346 minecraft:air
fill 309 63 -347 310 63 -347 minecraft:air
fill 325 63 -347 326 63 -347 minecraft:air
fill 310 63 -348 312 63 -348 minecraft:air
setblock 327 63 -348 minecraft:short_grass
fill 311 63 -349 314 63 -349 minecraft:air
fill 313 63 -350 315 63 -350 minecraft:air
setblock 314 63 -351 regions_unexplored:grass_sprouts
fill 315 63 -351 317 63 -351 minecraft:air
fill 316 63 -352 319 63 -352 minecraft:air
fill 318 63 -353 320 63 -353 minecraft:air
fill 321 63 -354 322 63 -354 minecraft:air
setblock 323 63 -355 minecraft:air
fill 280 63 -364 282 63 -364 minecraft:air
fill 281 63 -365 283 63 -365 minecraft:air
fill 295 62 -319 308 62 -319 minecraft:water[level=0]
fill 294 62 -320 307 62 -320 minecraft:water[level=0]
fill 295 62 -321 305 62 -321 minecraft:water[level=0]
fill 295 62 -322 305 62 -322 minecraft:water[level=0]
fill 295 62 -323 304 62 -323 minecraft:water[level=0]
setblock 295 62 -324 minecraft:water[level=0]
setblock 296 62 -324 minecraft:seagrass
fill 297 62 -324 304 62 -324 minecraft:water[level=0]
fill 295 62 -325 298 62 -325 minecraft:water[level=0]
setblock 299 62 -325 minecraft:tall_seagrass[half=upper]
fill 300 62 -325 302 62 -325 minecraft:water[level=0]
setblock 303 62 -325 minecraft:seagrass
setblock 291 62 -326 minecraft:water[level=0]
setblock 296 62 -326 minecraft:seagrass
fill 297 62 -326 302 62 -326 minecraft:water[level=0]
fill 290 62 -327 292 62 -327 minecraft:water[level=0]
fill 296 62 -327 297 62 -327 minecraft:seagrass
fill 299 62 -327 301 62 -327 minecraft:water[level=0]
fill 290 62 -328 294 62 -328 minecraft:water[level=0]
fill 296 62 -328 298 62 -328 minecraft:water[level=0]
setblock 299 62 -328 minecraft:seagrass
setblock 300 62 -328 minecraft:tall_seagrass[half=upper]
setblock 301 62 -328 minecraft:water[level=0]
fill 292 62 -329 294 62 -329 minecraft:water[level=0]
setblock 300 62 -329 minecraft:water[level=0]
fill 293 62 -330 294 62 -330 minecraft:water[level=0]
fill 268 62 -331 270 62 -331 minecraft:water[level=0]
fill 267 62 -332 269 62 -332 minecraft:water[level=0]
fill 267 62 -333 268 62 -333 minecraft:water[level=0]
fill 316 62 -340 317 62 -340 minecraft:water[level=0]
setblock 324 62 -343 minecraft:water[level=0]
fill 326 62 -343 327 62 -343 minecraft:water[level=0]
setblock 321 62 -344 minecraft:seagrass
setblock 323 62 -344 minecraft:seagrass
fill 326 62 -344 327 62 -344 minecraft:water[level=0]
fill 325 62 -345 327 62 -345 minecraft:water[level=0]
setblock 327 62 -346 minecraft:water[level=0]
fill 311 62 -348 312 62 -348 minecraft:water[level=0]
fill 312 62 -349 314 62 -349 minecraft:water[level=0]
fill 314 62 -350 316 62 -350 minecraft:water[level=0]
fill 315 62 -351 318 62 -351 minecraft:water[level=0]
fill 317 62 -352 320 62 -352 minecraft:water[level=0]
fill 318 62 -353 321 62 -353 minecraft:water[level=0]
fill 320 62 -354 323 62 -354 minecraft:water[level=0]
fill 323 62 -355 324 62 -355 minecraft:water[level=0]
setblock 325 62 -356 minecraft:water[level=0]
setblock 281 62 -364 minecraft:water[level=0]
fill 281 62 -365 283 62 -365 minecraft:water[level=0]
fill 282 62 -366 283 62 -366 minecraft:water[level=0]
fill 295 61 -319 305 61 -319 minecraft:water[level=0]
fill 296 61 -320 306 61 -320 minecraft:water[level=0]
fill 296 61 -321 305 61 -321 minecraft:water[level=0]
fill 296 61 -322 304 61 -322 minecraft:water[level=0]
fill 297 61 -323 298 61 -323 minecraft:water[level=0]
setblock 299 61 -323 minecraft:tall_seagrass[half=upper]
setblock 300 61 -323 minecraft:water[level=0]
setblock 301 61 -323 minecraft:tall_seagrass[half=upper]
fill 302 61 -323 303 61 -323 minecraft:water[level=0]
fill 297 61 -324 303 61 -324 minecraft:water[level=0]
setblock 297 61 -325 minecraft:seagrass
setblock 298 61 -325 minecraft:water[level=0]
setblock 299 61 -325 minecraft:tall_seagrass[half=lower]
fill 300 61 -325 302 61 -325 minecraft:water[level=0]
fill 298 61 -326 301 61 -326 minecraft:water[level=0]
fill 291 61 -327 293 61 -327 minecraft:water[level=0]
fill 299 61 -327 300 61 -327 minecraft:water[level=0]
fill 291 61 -328 294 61 -328 minecraft:water[level=0]
setblock 300 61 -328 minecraft:tall_seagrass[half=lower]
fill 292 61 -329 295 61 -329 minecraft:water[level=0]
setblock 294 61 -330 minecraft:water[level=0]
fill 268 61 -331 270 61 -331 minecraft:water[level=0]
fill 268 61 -332 269 61 -332 minecraft:water[level=0]
fill 268 61 -333 269 61 -333 minecraft:water[level=0]
fill 313 61 -349 314 61 -349 minecraft:water[level=0]
fill 315 61 -350 316 61 -350 minecraft:water[level=0]
fill 316 61 -351 319 61 -351 minecraft:water[level=0]
fill 318 61 -352 320 61 -352 minecraft:water[level=0]
fill 319 61 -353 322 61 -353 minecraft:water[level=0]
fill 321 61 -354 323 61 -354 minecraft:water[level=0]
fill 322 61 -355 325 61 -355 minecraft:water[level=0]
fill 325 61 -356 326 61 -356 minecraft:water[level=0]
setblock 327 61 -357 minecraft:water[level=0]
setblock 281 61 -364 minecraft:water[level=0]
fill 281 61 -365 282 61 -365 minecraft:water[level=0]
fill 281 61 -366 283 61 -366 minecraft:water[level=0]
setblock 283 61 -367 minecraft:water[level=0]
fill 281 60 -319 283 60 -319 minecraft:water[level=0]
fill 285 60 -319 289 60 -319 minecraft:water[level=0]
fill 297 60 -319 303 60 -319 minecraft:water[level=0]
fill 297 60 -320 304 60 -320 minecraft:water[level=0]
fill 298 60 -321 303 60 -321 minecraft:water[level=0]
fill 298 60 -322 302 60 -322 minecraft:water[level=0]
fill 315 60 -322 316 60 -322 minecraft:cave_air
setblock 299 60 -323 minecraft:tall_seagrass[half=lower]
setblock 300 60 -323 minecraft:water[level=0]
setblock 301 60 -323 minecraft:tall_seagrass[half=lower]
setblock 302 60 -323 minecraft:water[level=0]
fill 315 60 -323 317 60 -323 minecraft:cave_air
fill 299 60 -324 301 60 -324 minecraft:water[level=0]
fill 315 60 -324 317 60 -324 minecraft:cave_air
setblock 300 60 -325 minecraft:water[level=0]
fill 315 60 -325 317 60 -325 minecraft:cave_air
fill 292 60 -327 293 60 -327 minecraft:water[level=0]
setblock 291 60 -328 minecraft:seagrass
fill 292 60 -328 295 60 -328 minecraft:water[level=0]
fill 293 60 -329 295 60 -329 minecraft:water[level=0]
fill 294 60 -330 295 60 -330 minecraft:water[level=0]
fill 269 60 -331 271 60 -331 minecraft:water[level=0]
setblock 295 60 -331 minecraft:water[level=0]
fill 268 60 -332 270 60 -332 minecraft:water[level=0]
setblock 269 60 -333 minecraft:water[level=0]
fill 315 60 -350 316 60 -350 minecraft:water[level=0]
fill 317 60 -351 318 60 -351 minecraft:water[level=0]
fill 319 60 -352 321 60 -352 minecraft:water[level=0]
fill 320 60 -353 323 60 -353 minecraft:water[level=0]
fill 322 60 -354 324 60 -354 minecraft:water[level=0]
fill 323 60 -355 325 60 -355 minecraft:water[level=0]
fill 325 60 -356 327 60 -356 minecraft:water[level=0]
setblock 327 60 -357 minecraft:water[level=0]
fill 281 60 -365 282 60 -365 minecraft:water[level=0]
fill 281 60 -366 283 60 -366 minecraft:water[level=0]
fill 282 60 -367 284 60 -367 minecraft:water[level=0]
setblock 284 60 -368 minecraft:water[level=0]
setblock 292 60 -382 minecraft:water[level=0]
fill 274 59 -319 289 59 -319 minecraft:water[level=0]
fill 299 59 -319 301 59 -319 minecraft:water[level=0]
fill 315 59 -319 320 59 -319 minecraft:air
fill 274 59 -320 283 59 -320 minecraft:water[level=0]
fill 299 59 -320 302 59 -320 minecraft:water[level=0]
fill 314 59 -320 320 59 -320 minecraft:air
setblock 274 59 -321 minecraft:water[level=0]
setblock 276 59 -321 minecraft:water[level=0]
setblock 299 59 -321 minecraft:water[level=0]
setblock 300 59 -321 minecraft:seagrass
setblock 301 59 -321 minecraft:water[level=0]
fill 313 59 -321 320 59 -321 minecraft:air
setblock 300 59 -322 minecraft:water[level=0]
fill 313 59 -322 319 59 -322 minecraft:air
fill 314 59 -323 318 59 -323 minecraft:air
fill 314 59 -324 319 59 -324 minecraft:air
fill 314 59 -325 319 59 -325 minecraft:air
fill 315 59 -326 318 59 -326 minecraft:air
fill 293 59 -327 294 59 -327 minecraft:water[level=0]
fill 292 59 -328 295 59 -328 minecraft:water[level=0]
setblock 293 59 -329 minecraft:tall_seagrass[half=upper]
fill 294 59 -329 296 59 -329 minecraft:water[level=0]
fill 294 59 -330 295 59 -330 minecraft:water[level=0]
fill 269 59 -331 271 59 -331 minecraft:water[level=0]
fill 269 59 -332 270 59 -332 minecraft:water[level=0]
setblock 270 59 -333 minecraft:water[level=0]
setblock 318 59 -351 minecraft:water[level=0]
fill 319 59 -352 320 59 -352 minecraft:water[level=0]
fill 321 59 -353 323 59 -353 minecraft:water[level=0]
fill 322 59 -354 325 59 -354 minecraft:water[level=0]
fill 324 59 -355 326 59 -355 minecraft:water[level=0]
fill 325 59 -356 327 59 -356 minecraft:water[level=0]
setblock 327 59 -357 minecraft:water[level=0]
fill 282 59 -366 283 59 -366 minecraft:water[level=0]
fill 281 59 -367 284 59 -367 minecraft:water[level=0]
fill 283 59 -368 284 59 -368 minecraft:water[level=0]
setblock 284 59 -369 minecraft:water[level=0]
setblock 291 59 -381 minecraft:water[level=0]
fill 291 59 -382 292 59 -382 minecraft:water[level=0]
fill 272 58 -319 288 58 -319 minecraft:water[level=0]
fill 315 58 -319 321 58 -319 minecraft:cave_air
fill 272 58 -320 284 58 -320 minecraft:water[level=0]
setblock 300 58 -320 minecraft:seagrass
fill 314 58 -320 321 58 -320 minecraft:cave_air
fill 272 58 -321 278 58 -321 minecraft:water[level=0]
fill 314 58 -321 320 58 -321 minecraft:cave_air
fill 273 58 -322 275 58 -322 minecraft:water[level=0]
fill 314 58 -322 320 58 -322 minecraft:cave_air
fill 314 58 -323 319 58 -323 minecraft:cave_air
fill 314 58 -324 320 58 -324 minecraft:cave_air
fill 314 58 -325 320 58 -325 minecraft:cave_air
fill 315 58 -326 319 58 -326 minecraft:cave_air
fill 293 58 -327 294 58 -327 minecraft:water[level=0]
setblock 293 58 -328 minecraft:tall_seagrass[half=upper]
fill 294 58 -328 295 58 -328 minecraft:water[level=0]
setblock 293 58 -329 minecraft:tall_seagrass[half=lower]
fill 294 58 -329 296 58 -329 minecraft:water[level=0]
fill 265 58 -330 267 58 -330 minecraft:water[level=0]
fill 295 58 -330 296 58 -330 minecraft:water[level=0]
fill 265 58 -331 267 58 -331 minecraft:water[level=0]
fill 270 58 -331 271 58 -331 minecraft:water[level=0]
setblock 266 58 -332 minecraft:water[level=0]
fill 269 58 -332 271 58 -332 minecraft:water[level=0]
setblock 270 58 -333 minecraft:water[level=0]
setblock 264 58 -336 minecraft:water[level=0]
setblock 264 58 -337 minecraft:water[level=0]
setblock 320 58 -352 minecraft:water[level=0]
fill 322 58 -353 323 58 -353 minecraft:water[level=0]
fill 323 58 -354 325 58 -354 minecraft:water[level=0]
fill 324 58 -355 327 58 -355 minecraft:water[level=0]
fill 326 58 -356 327 58 -356 minecraft:water[level=0]
setblock 327 58 -357 minecraft:water[level=0]
setblock 282 58 -366 minecraft:water[level=0]
fill 282 58 -367 283 58 -367 minecraft:water[level=0]
fill 282 58 -368 285 58 -368 minecraft:water[level=0]
fill 283 58 -369 285 58 -369 minecraft:water[level=0]
fill 284 58 -370 285 58 -370 minecraft:water[level=0]
setblock 285 58 -371 minecraft:water[level=0]
setblock 289 58 -378 minecraft:water[level=0]
setblock 290 58 -379 minecraft:water[level=0]
fill 290 58 -380 291 58 -380 minecraft:water[level=0]
fill 290 58 -381 292 58 -381 minecraft:water[level=0]
fill 291 58 -382 293 58 -382 minecraft:water[level=0]
fill 264 57 -319 265 57 -319 minecraft:water[level=0]
fill 272 57 -319 287 57 -319 minecraft:water[level=0]
fill 315 57 -319 320 57 -319 minecraft:lava[level=0]
fill 264 57 -320 265 57 -320 minecraft:water[level=0]
fill 272 57 -320 284 57 -320 minecraft:water[level=0]
fill 317 57 -320 320 57 -320 minecraft:lava[level=0]
fill 264 57 -321 265 57 -321 minecraft:water[level=0]
fill 272 57 -321 278 57 -321 minecraft:water[level=0]
fill 315 57 -321 320 57 -321 minecraft:lava[level=0]
setblock 264 57 -322 minecraft:water[level=0]
setblock 270 57 -322 minecraft:bubble_column[drag=true]
fill 271 57 -322 276 57 -322 minecraft:water[level=0]
fill 314 57 -322 320 57 -322 minecraft:lava[level=0]
setblock 269 57 -323 minecraft:bubble_column[drag=true]
fill 270 57 -323 274 57 -323 minecraft:water[level=0]
fill 314 57 -323 317 57 -323 minecraft:lava[level=0]
setblock 269 57 -324 minecraft:water[level=0]
setblock 270 57 -324 minecraft:bubble_column[drag=true]
fill 271 57 -324 273 57 -324 minecraft:water[level=0]
fill 315 57 -324 318 57 -324 minecraft:lava[level=0]
fill 268 57 -325 273 57 -325 minecraft:water[level=0]
fill 315 57 -325 317 57 -325 minecraft:lava[level=0]
fill 268 57 -326 272 57 -326 minecraft:water[level=0]
fill 264 57 -327 265 57 -327 minecraft:water[level=0]
fill 267 57 -327 271 57 -327 minecraft:water[level=0]
fill 294 57 -327 295 57 -327 minecraft:water[level=0]
fill 264 57 -328 271 57 -328 minecraft:water[level=0]
setblock 293 57 -328 minecraft:tall_seagrass[half=lower]
fill 294 57 -328 296 57 -328 minecraft:water[level=0]
fill 264 57 -329 270 57 -329 minecraft:water[level=0]
fill 294 57 -329 296 57 -329 minecraft:water[level=0]
fill 264 57 -330 269 57 -330 minecraft:water[level=0]
fill 295 57 -330 296 57 -330 minecraft:water[level=0]
fill 264 57 -331 272 57 -331 minecraft:water[level=0]
setblock 264 57 -332 minecraft:bubble_column[drag=true]
fill 265 57 -332 268 57 -332 minecraft:water[level=0]
fill 270 57 -332 271 57 -332 minecraft:water[level=0]
fill 264 57 -333 267 57 -333 minecraft:water[level=0]
setblock 264 57 -334 minecraft:water[level=0]
setblock 265 57 -334 minecraft:bubble_column[drag=true]
setblock 266 57 -334 minecraft:water[level=0]
fill 264 57 -335 266 57 -335 minecraft:water[level=0]
fill 264 57 -336 266 57 -336 minecraft:water[level=0]
fill 264 57 -337 265 57 -337 minecraft:water[level=0]
fill 264 57 -338 265 57 -338 minecraft:water[level=0]
setblock 264 57 -339 minecraft:water[level=0]
setblock 322 57 -353 minecraft:water[level=0]
fill 324 57 -354 325 57 -354 minecraft:water[level=0]
fill 325 57 -355 327 57 -355 minecraft:water[level=0]
fill 326 57 -356 327 57 -356 minecraft:water[level=0]
setblock 327 57 -357 minecraft:water[level=0]
fill 282 57 -367 283 57 -367 minecraft:water[level=0]
fill 282 57 -368 284 57 -368 minecraft:water[level=0]
fill 283 57 -369 285 57 -369 minecraft:water[level=0]
fill 284 57 -370 286 57 -370 minecraft:water[level=0]
fill 285 57 -371 286 57 -371 minecraft:water[level=0]
setblock 286 57 -372 minecraft:water[level=0]
fill 286 57 -373 287 57 -373 minecraft:water[level=0]
setblock 287 57 -374 minecraft:water[level=0]
fill 287 57 -375 288 57 -375 minecraft:water[level=0]
setblock 288 57 -376 minecraft:water[level=0]
fill 288 57 -377 289 57 -377 minecraft:water[level=0]
fill 289 57 -378 290 57 -378 minecraft:water[level=0]
fill 289 57 -379 291 57 -379 minecraft:water[level=0]
fill 289 57 -380 291 57 -380 minecraft:water[level=0]
fill 290 57 -381 292 57 -381 minecraft:water[level=0]
fill 290 57 -382 292 57 -382 minecraft:water[level=0]
fill 264 56 -319 267 56 -319 minecraft:water[level=0]
fill 272 56 -319 284 56 -319 minecraft:water[level=0]
setblock 319 56 -319 minecraft:lava[level=0]
fill 264 56 -320 267 56 -320 minecraft:water[level=0]
fill 272 56 -320 283 56 -320 minecraft:water[level=0]
fill 318 56 -320 319 56 -320 minecraft:lava[level=0]
fill 264 56 -321 266 56 -321 minecraft:water[level=0]
fill 270 56 -321 278 56 -321 minecraft:water[level=0]
fill 264 56 -322 266 56 -322 minecraft:water[level=0]
setblock 269 56 -322 minecraft:water[level=0]
setblock 270 56 -322 minecraft:bubble_column[drag=true]
fill 271 56 -322 276 56 -322 minecraft:water[level=0]
fill 264 56 -323 266 56 -323 minecraft:water[level=0]
setblock 269 56 -323 minecraft:bubble_column[drag=true]
fill 270 56 -323 275 56 -323 minecraft:water[level=0]
fill 264 56 -324 266 56 -324 minecraft:water[level=0]
fill 268 56 -324 269 56 -324 minecraft:water[level=0]
setblock 270 56 -324 minecraft:bubble_column[drag=true]
fill 271 56 -324 274 56 -324 minecraft:water[level=0]
fill 316 56 -324 317 56 -324 minecraft:lava[level=0]
fill 264 56 -325 266 56 -325 minecraft:water[level=0]
fill 268 56 -325 273 56 -325 minecraft:water[level=0]
fill 264 56 -326 273 56 -326 minecraft:water[level=0]
fill 264 56 -327 272 56 -327 minecraft:water[level=0]
fill 294 56 -327 295 56 -327 minecraft:water[level=0]
fill 264 56 -328 272 56 -328 minecraft:water[level=0]
fill 294 56 -328 296 56 -328 minecraft:water[level=0]
fill 264 56 -329 271 56 -329 minecraft:water[level=0]
fill 294 56 -329 297 56 -329 minecraft:water[level=0]
fill 264 56 -330 271 56 -330 minecraft:water[level=0]
setblock 296 56 -330 minecraft:water[level=0]
fill 264 56 -331 272 56 -331 minecraft:water[level=0]
setblock 264 56 -332 minecraft:bubble_column[drag=true]
fill 265 56 -332 271 56 -332 minecraft:water[level=0]
fill 264 56 -333 268 56 -333 minecraft:water[level=0]
setblock 271 56 -333 minecraft:water[level=0]
setblock 264 56 -334 minecraft:water[level=0]
setblock 265 56 -334 minecraft:bubble_column[drag=true]
fill 266 56 -334 267 56 -334 minecraft:water[level=0]
fill 264 56 -335 267 56 -335 minecraft:water[level=0]
fill 264 56 -336 266 56 -336 minecraft:water[level=0]
fill 264 56 -337 266 56 -337 minecraft:water[level=0]
fill 264 56 -338 265 56 -338 minecraft:water[level=0]
setblock 264 56 -339 minecraft:water[level=0]
fill 271 56 -346 272 56 -346 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 271 56 -347 272 56 -347 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 325 56 -354 minecraft:water[level=0]
fill 326 56 -355 327 56 -355 minecraft:water[level=0]
setblock 327 56 -356 minecraft:water[level=0]
fill 282 56 -368 283 56 -368 minecraft:water[level=0]
fill 282 56 -369 284 56 -369 minecraft:water[level=0]
fill 283 56 -370 285 56 -370 minecraft:water[level=0]
fill 284 56 -371 286 56 -371 minecraft:water[level=0]
fill 285 56 -372 287 56 -372 minecraft:water[level=0]
fill 286 56 -373 287 56 -373 minecraft:water[level=0]
fill 286 56 -374 288 56 -374 minecraft:water[level=0]
fill 287 56 -375 288 56 -375 minecraft:water[level=0]
fill 287 56 -376 289 56 -376 minecraft:water[level=0]
fill 288 56 -377 289 56 -377 minecraft:water[level=0]
fill 288 56 -378 290 56 -378 minecraft:water[level=0]
fill 288 56 -379 290 56 -379 minecraft:water[level=0]
fill 289 56 -380 290 56 -380 minecraft:water[level=0]
fill 289 56 -381 291 56 -381 minecraft:water[level=0]
fill 290 56 -382 291 56 -382 minecraft:water[level=0]
fill 264 55 -319 267 55 -319 minecraft:water[level=0]
fill 272 55 -319 279 55 -319 minecraft:water[level=0]
fill 264 55 -320 267 55 -320 minecraft:water[level=0]
fill 272 55 -320 278 55 -320 minecraft:water[level=0]
fill 264 55 -321 267 55 -321 minecraft:water[level=0]
fill 270 55 -321 277 55 -321 minecraft:water[level=0]
fill 264 55 -322 267 55 -322 minecraft:water[level=0]
setblock 269 55 -322 minecraft:water[level=0]
setblock 270 55 -322 minecraft:bubble_column[drag=true]
fill 271 55 -322 276 55 -322 minecraft:water[level=0]
fill 264 55 -323 268 55 -323 minecraft:water[level=0]
setblock 269 55 -323 minecraft:bubble_column[drag=true]
fill 270 55 -323 274 55 -323 minecraft:water[level=0]
fill 264 55 -324 269 55 -324 minecraft:water[level=0]
setblock 270 55 -324 minecraft:bubble_column[drag=true]
fill 271 55 -324 274 55 -324 minecraft:water[level=0]
fill 264 55 -325 274 55 -325 minecraft:water[level=0]
fill 264 55 -326 273 55 -326 minecraft:water[level=0]
setblock 296 55 -326 minecraft:water[level=0]
fill 264 55 -327 272 55 -327 minecraft:water[level=0]
fill 295 55 -327 297 55 -327 minecraft:water[level=0]
fill 264 55 -328 272 55 -328 minecraft:water[level=0]
fill 294 55 -328 297 55 -328 minecraft:water[level=0]
fill 264 55 -329 271 55 -329 minecraft:water[level=0]
fill 295 55 -329 297 55 -329 minecraft:water[level=0]
fill 264 55 -330 270 55 -330 minecraft:water[level=0]
fill 264 55 -331 273 55 -331 minecraft:water[level=0]
setblock 264 55 -332 minecraft:bubble_column[drag=true]
fill 265 55 -332 272 55 -332 minecraft:water[level=0]
fill 264 55 -333 269 55 -333 minecraft:water[level=0]
setblock 264 55 -334 minecraft:water[level=0]
setblock 265 55 -334 minecraft:bubble_column[drag=true]
fill 266 55 -334 268 55 -334 minecraft:water[level=0]
fill 264 55 -335 267 55 -335 minecraft:water[level=0]
fill 264 55 -336 266 55 -336 minecraft:water[level=0]
fill 264 55 -337 266 55 -337 minecraft:water[level=0]
fill 264 55 -338 265 55 -338 minecraft:water[level=0]
setblock 264 55 -339 minecraft:water[level=0]
fill 271 55 -346 272 55 -346 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 271 55 -347 272 55 -347 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 283 55 -369 minecraft:water[level=0]
fill 282 55 -370 284 55 -370 minecraft:water[level=0]
fill 283 55 -371 285 55 -371 minecraft:water[level=0]
fill 284 55 -372 286 55 -372 minecraft:water[level=0]
fill 285 55 -373 287 55 -373 minecraft:water[level=0]
fill 285 55 -374 287 55 -374 minecraft:water[level=0]
fill 286 55 -375 288 55 -375 minecraft:water[level=0]
fill 287 55 -376 288 55 -376 minecraft:water[level=0]
fill 287 55 -377 289 55 -377 minecraft:water[level=0]
fill 287 55 -378 289 55 -378 minecraft:water[level=0]
fill 288 55 -379 289 55 -379 minecraft:water[level=0]
fill 288 55 -380 290 55 -380 minecraft:water[level=0]
fill 289 55 -381 290 55 -381 minecraft:water[level=0]
fill 289 55 -382 291 55 -382 minecraft:water[level=0]
fill 264 54 -319 267 54 -319 minecraft:water[level=0]
fill 264 54 -320 267 54 -320 minecraft:water[level=0]
fill 264 54 -321 267 54 -321 minecraft:water[level=0]
fill 270 54 -321 272 54 -321 minecraft:water[level=0]
fill 264 54 -322 267 54 -322 minecraft:water[level=0]
setblock 269 54 -322 minecraft:water[level=0]
setblock 270 54 -322 minecraft:bubble_column[drag=true]
fill 271 54 -322 273 54 -322 minecraft:water[level=0]
fill 264 54 -323 267 54 -323 minecraft:water[level=0]
setblock 269 54 -323 minecraft:bubble_column[drag=true]
fill 270 54 -323 274 54 -323 minecraft:water[level=0]
fill 264 54 -324 269 54 -324 minecraft:water[level=0]
setblock 270 54 -324 minecraft:bubble_column[drag=true]
fill 271 54 -324 274 54 -324 minecraft:water[level=0]
fill 264 54 -325 273 54 -325 minecraft:water[level=0]
fill 264 54 -326 273 54 -326 minecraft:water[level=0]
fill 296 54 -326 297 54 -326 minecraft:water[level=0]
fill 264 54 -327 272 54 -327 minecraft:water[level=0]
fill 295 54 -327 298 54 -327 minecraft:water[level=0]
fill 264 54 -328 272 54 -328 minecraft:water[level=0]
fill 295 54 -328 298 54 -328 minecraft:water[level=0]
fill 264 54 -329 271 54 -329 minecraft:water[level=0]
setblock 297 54 -329 minecraft:water[level=0]
fill 264 54 -330 270 54 -330 minecraft:water[level=0]
setblock 272 54 -330 minecraft:water[level=0]
fill 264 54 -331 273 54 -331 minecraft:water[level=0]
setblock 264 54 -332 minecraft:bubble_column[drag=true]
fill 265 54 -332 269 54 -332 minecraft:water[level=0]
fill 271 54 -332 272 54 -332 minecraft:water[level=0]
fill 264 54 -333 269 54 -333 minecraft:water[level=0]
setblock 264 54 -334 minecraft:water[level=0]
setblock 265 54 -334 minecraft:bubble_column[drag=true]
fill 266 54 -334 268 54 -334 minecraft:water[level=0]
fill 264 54 -335 266 54 -335 minecraft:water[level=0]
fill 264 54 -336 266 54 -336 minecraft:water[level=0]
fill 264 54 -337 265 54 -337 minecraft:water[level=0]
setblock 283 54 -370 minecraft:water[level=0]
fill 282 54 -371 284 54 -371 minecraft:water[level=0]
fill 283 54 -372 285 54 -372 minecraft:water[level=0]
fill 284 54 -373 286 54 -373 minecraft:water[level=0]
fill 285 54 -374 286 54 -374 minecraft:water[level=0]
fill 285 54 -375 287 54 -375 minecraft:water[level=0]
fill 286 54 -376 288 54 -376 minecraft:water[level=0]
fill 286 54 -377 288 54 -377 minecraft:water[level=0]
fill 287 54 -378 288 54 -378 minecraft:water[level=0]
fill 287 54 -379 289 54 -379 minecraft:water[level=0]
fill 288 54 -380 289 54 -380 minecraft:water[level=0]
fill 288 54 -381 290 54 -381 minecraft:water[level=0]
fill 288 54 -382 290 54 -382 minecraft:water[level=0]
fill 264 53 -319 267 53 -319 minecraft:water[level=0]
fill 264 53 -320 267 53 -320 minecraft:water[level=0]
fill 264 53 -321 267 53 -321 minecraft:water[level=0]
fill 264 53 -322 267 53 -322 minecraft:water[level=0]
fill 264 53 -323 267 53 -323 minecraft:water[level=0]
fill 264 53 -324 267 53 -324 minecraft:water[level=0]
fill 264 53 -325 267 53 -325 minecraft:water[level=0]
fill 297 53 -325 298 53 -325 minecraft:water[level=0]
fill 264 53 -326 267 53 -326 minecraft:water[level=0]
fill 296 53 -326 298 53 -326 minecraft:water[level=0]
fill 264 53 -327 267 53 -327 minecraft:water[level=0]
fill 295 53 -327 299 53 -327 minecraft:water[level=0]
fill 264 53 -328 268 53 -328 minecraft:water[level=0]
fill 297 53 -328 298 53 -328 minecraft:water[level=0]
fill 264 53 -329 268 53 -329 minecraft:water[level=0]
fill 264 53 -330 269 53 -330 minecraft:water[level=0]
fill 272 53 -330 273 53 -330 minecraft:water[level=0]
fill 264 53 -331 269 53 -331 minecraft:water[level=0]
fill 272 53 -331 273 53 -331 minecraft:water[level=0]
setblock 264 53 -332 minecraft:bubble_column[drag=true]
fill 265 53 -332 269 53 -332 minecraft:water[level=0]
setblock 272 53 -332 minecraft:water[level=0]
fill 264 53 -333 268 53 -333 minecraft:water[level=0]
setblock 265 53 -334 minecraft:bubble_column[drag=true]
fill 266 53 -334 267 53 -334 minecraft:water[level=0]
setblock 283 53 -370 minecraft:water[level=0]
fill 283 53 -371 284 53 -371 minecraft:water[level=0]
fill 283 53 -372 284 53 -372 minecraft:water[level=0]
fill 283 53 -373 285 53 -373 minecraft:water[level=0]
fill 284 53 -374 286 53 -374 minecraft:water[level=0]
fill 285 53 -375 286 53 -375 minecraft:water[level=0]
fill 285 53 -376 287 53 -376 minecraft:water[level=0]
fill 286 53 -377 287 53 -377 minecraft:water[level=0]
fill 286 53 -378 288 53 -378 minecraft:water[level=0]
fill 286 53 -379 288 53 -379 minecraft:water[level=0]
fill 287 53 -380 289 53 -380 minecraft:water[level=0]
fill 287 53 -381 289 53 -381 minecraft:water[level=0]
fill 288 53 -382 289 53 -382 minecraft:water[level=0]
fill 264 52 -319 266 52 -319 minecraft:water[level=0]
fill 264 52 -320 267 52 -320 minecraft:water[level=0]
fill 264 52 -321 267 52 -321 minecraft:water[level=0]
fill 264 52 -322 267 52 -322 minecraft:water[level=0]
fill 264 52 -323 267 52 -323 minecraft:water[level=0]
fill 264 52 -324 267 52 -324 minecraft:water[level=0]
fill 264 52 -325 267 52 -325 minecraft:water[level=0]
fill 298 52 -325 299 52 -325 minecraft:water[level=0]
fill 264 52 -326 267 52 -326 minecraft:water[level=0]
fill 297 52 -326 300 52 -326 minecraft:water[level=0]
fill 264 52 -327 267 52 -327 minecraft:water[level=0]
fill 297 52 -327 299 52 -327 minecraft:water[level=0]
fill 264 52 -328 267 52 -328 minecraft:water[level=0]
setblock 298 52 -328 minecraft:water[level=0]
fill 264 52 -329 268 52 -329 minecraft:water[level=0]
fill 264 52 -330 267 52 -330 minecraft:water[level=0]
fill 273 52 -330 274 52 -330 minecraft:water[level=0]
fill 264 52 -331 267 52 -331 minecraft:water[level=0]
fill 272 52 -331 273 52 -331 minecraft:water[level=0]
setblock 264 52 -332 minecraft:bubble_column[drag=true]
fill 265 52 -332 266 52 -332 minecraft:water[level=0]
setblock 273 52 -332 minecraft:water[level=0]
setblock 283 52 -371 minecraft:water[level=0]
fill 283 52 -372 284 52 -372 minecraft:water[level=0]
setblock 284 52 -373 minecraft:water[level=0]
fill 283 52 -374 285 52 -374 minecraft:water[level=0]
fill 284 52 -375 286 52 -375 minecraft:water[level=0]
fill 284 52 -376 286 52 -376 minecraft:water[level=0]
fill 285 52 -377 287 52 -377 minecraft:water[level=0]
fill 285 52 -378 287 52 -378 minecraft:water[level=0]
fill 286 52 -379 288 52 -379 minecraft:water[level=0]
fill 286 52 -380 288 52 -380 minecraft:water[level=0]
fill 287 52 -381 288 52 -381 minecraft:water[level=0]
fill 287 52 -382 289 52 -382 minecraft:water[level=0]
fill 299 51 -324 300 51 -324 minecraft:water[level=0]
fill 298 51 -325 301 51 -325 minecraft:water[level=0]
fill 297 51 -326 301 51 -326 minecraft:water[level=0]
fill 298 51 -327 300 51 -327 minecraft:water[level=0]
fill 273 51 -330 274 51 -330 minecraft:water[level=0]
fill 272 51 -331 274 51 -331 minecraft:water[level=0]
setblock 273 51 -332 minecraft:water[level=0]
setblock 283 51 -372 minecraft:water[level=0]
fill 283 51 -373 284 51 -373 minecraft:water[level=0]
setblock 284 51 -374 minecraft:water[level=0]
fill 284 51 -375 285 51 -375 minecraft:water[level=0]
fill 284 51 -376 285 51 -376 minecraft:water[level=0]
fill 284 51 -377 286 51 -377 minecraft:water[level=0]
fill 285 51 -378 286 51 -378 minecraft:water[level=0]
fill 285 51 -379 287 51 -379 minecraft:water[level=0]
fill 286 51 -380 287 51 -380 minecraft:water[level=0]
fill 286 51 -381 288 51 -381 minecraft:water[level=0]
fill 286 51 -382 288 51 -382 minecraft:water[level=0]
fill 301 50 -323 302 50 -323 minecraft:water[level=0]
fill 300 50 -324 302 50 -324 minecraft:water[level=0]
fill 299 50 -325 302 50 -325 minecraft:water[level=0]
fill 299 50 -326 301 50 -326 minecraft:water[level=0]
setblock 300 50 -327 minecraft:water[level=0]
setblock 274 50 -329 minecraft:water[level=0]
fill 273 50 -330 275 50 -330 minecraft:water[level=0]
fill 273 50 -331 274 50 -331 minecraft:water[level=0]
setblock 281 50 -374 minecraft:air
setblock 282 50 -375 minecraft:air
setblock 284 50 -375 minecraft:water[level=0]
fill 284 50 -376 285 50 -376 minecraft:water[level=0]
fill 284 50 -377 285 50 -377 minecraft:water[level=0]
fill 285 50 -378 286 50 -378 minecraft:water[level=0]
fill 285 50 -379 286 50 -379 minecraft:water[level=0]
fill 285 50 -380 287 50 -380 minecraft:water[level=0]
fill 285 50 -381 287 50 -381 minecraft:water[level=0]
fill 286 50 -382 288 50 -382 minecraft:water[level=0]
fill 303 49 -322 304 49 -322 minecraft:water[level=0]
fill 302 49 -323 304 49 -323 minecraft:water[level=0]
fill 300 49 -324 304 49 -324 minecraft:water[level=0]
fill 300 49 -325 303 49 -325 minecraft:water[level=0]
fill 301 49 -326 302 49 -326 minecraft:water[level=0]
setblock 274 49 -329 minecraft:water[level=0]
fill 273 49 -330 275 49 -330 minecraft:water[level=0]
fill 273 49 -331 274 49 -331 minecraft:water[level=0]
fill 281 49 -374 282 49 -374 minecraft:air
fill 281 49 -375 282 49 -375 minecraft:air
setblock 282 49 -376 minecraft:air
setblock 284 49 -376 minecraft:water[level=0]
setblock 282 49 -377 minecraft:air
setblock 283 49 -378 minecraft:air
setblock 285 49 -378 minecraft:water[level=0]
setblock 283 49 -379 minecraft:air
setblock 285 49 -379 minecraft:water[level=0]
fill 285 49 -380 286 49 -380 minecraft:water[level=0]
setblock 286 49 -381 minecraft:water[level=0]
fill 286 49 -382 287 49 -382 minecraft:water[level=0]
setblock 306 48 -321 minecraft:water[level=0]
fill 304 48 -322 306 48 -322 minecraft:water[level=0]
fill 302 48 -323 306 48 -323 minecraft:water[level=0]
fill 301 48 -324 305 48 -324 minecraft:water[level=0]
fill 302 48 -325 303 48 -325 minecraft:water[level=0]
setblock 302 48 -326 minecraft:water[level=0]
fill 274 48 -329 275 48 -329 minecraft:water[level=0]
fill 274 48 -330 275 48 -330 minecraft:water[level=0]
setblock 274 48 -331 minecraft:water[level=0]
fill 280 48 -374 282 48 -374 minecraft:air
fill 280 48 -375 282 48 -375 minecraft:air
fill 281 48 -376 282 48 -376 minecraft:air
fill 281 48 -377 283 48 -377 minecraft:air
fill 282 48 -378 283 48 -378 minecraft:air
setblock 283 48 -379 minecraft:air
setblock 285 48 -379 minecraft:water[level=0]
setblock 283 48 -380 minecraft:air
setblock 311 47 -319 minecraft:water[level=0]
fill 309 47 -320 310 47 -320 minecraft:water[level=0]
fill 307 47 -321 309 47 -321 minecraft:water[level=0]
fill 305 47 -322 309 47 -322 minecraft:water[level=0]
fill 304 47 -323 308 47 -323 minecraft:water[level=0]
fill 304 47 -324 306 47 -324 minecraft:water[level=0]
setblock 304 47 -325 minecraft:water[level=0]
setblock 275 47 -329 minecraft:water[level=0]
fill 274 47 -330 275 47 -330 minecraft:water[level=0]
setblock 275 47 -331 minecraft:water[level=0]
setblock 280 47 -373 minecraft:air
fill 279 47 -374 281 47 -374 minecraft:air
fill 278 47 -375 281 47 -375 minecraft:air
fill 279 47 -376 282 47 -376 minecraft:air
fill 280 47 -377 283 47 -377 minecraft:air
fill 281 47 -378 283 47 -378 minecraft:air
fill 281 47 -379 283 47 -379 minecraft:air
setblock 283 47 -380 minecraft:air
fill 311 46 -319 314 46 -319 minecraft:water[level=0]
fill 309 46 -320 313 46 -320 minecraft:water[level=0]
fill 307 46 -321 312 46 -321 minecraft:water[level=0]
fill 307 46 -322 311 46 -322 minecraft:water[level=0]
fill 306 46 -323 309 46 -323 minecraft:water[level=0]
setblock 306 46 -324 minecraft:water[level=0]
fill 275 46 -329 276 46 -329 minecraft:water[level=0]
fill 274 46 -330 276 46 -330 minecraft:water[level=0]
setblock 275 46 -331 minecraft:water[level=0]
fill 278 46 -374 279 46 -374 minecraft:air
fill 276 46 -375 280 46 -375 minecraft:air
fill 278 46 -376 281 46 -376 minecraft:air
fill 278 46 -377 282 46 -377 minecraft:air
setblock 279 46 -378 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=true]
fill 280 46 -378 282 46 -378 minecraft:air
setblock 283 46 -379 minecraft:air
fill 312 45 -319 316 45 -319 minecraft:water[level=0]
fill 310 45 -320 315 45 -320 minecraft:water[level=0]
fill 310 45 -321 313 45 -321 minecraft:water[level=0]
fill 310 45 -322 311 45 -322 minecraft:water[level=0]
setblock 309 45 -323 minecraft:water[level=0]
setblock 276 45 -328 minecraft:water[level=0]
fill 275 45 -329 277 45 -329 minecraft:water[level=0]
fill 275 45 -330 276 45 -330 minecraft:water[level=0]
fill 276 45 -374 277 45 -374 minecraft:air
fill 275 45 -375 279 45 -375 minecraft:air
fill 275 45 -376 280 45 -376 minecraft:air
fill 276 45 -377 280 45 -377 minecraft:air
forceload remove 264 -382 327 -319
tellraw @a {"text":"Campus zurueck a12 fertig.","color":"green"}
