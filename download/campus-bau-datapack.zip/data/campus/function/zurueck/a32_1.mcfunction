setblock 215 87 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 87 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 87 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 87 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 87 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 86 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 86 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 256 86 -148 minecraft:white_concrete
setblock 256 86 -149 minecraft:white_concrete
setblock 247 86 -150 minecraft:white_concrete
setblock 256 86 -150 minecraft:white_concrete
setblock 247 86 -151 minecraft:white_concrete
fill 237 86 -153 238 86 -153 minecraft:white_concrete
setblock 238 86 -154 minecraft:white_concrete
setblock 229 86 -157 minecraft:white_concrete
setblock 229 86 -158 minecraft:white_concrete
setblock 221 86 -162 minecraft:white_concrete
setblock 221 86 -163 minecraft:white_concrete
setblock 242 86 -166 minecraft:white_concrete
fill 213 86 -168 214 86 -168 minecraft:white_concrete
setblock 235 86 -169 minecraft:white_concrete
setblock 229 86 -173 minecraft:white_concrete
setblock 207 86 -175 minecraft:white_concrete
setblock 223 86 -178 minecraft:white_concrete
setblock 201 86 -182 minecraft:white_concrete
setblock 202 86 -183 minecraft:white_concrete
setblock 213 86 -190 minecraft:white_concrete
setblock 205 85 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 85 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 85 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 85 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 85 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 85 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 85 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 85 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 85 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 85 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 85 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 85 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 85 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 85 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 85 -142 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 253 85 -146 minecraft:white_concrete
setblock 255 85 -146 minecraft:white_concrete
setblock 258 85 -146 minecraft:white_concrete
setblock 261 85 -146 minecraft:white_concrete
setblock 247 85 -147 minecraft:white_concrete
setblock 249 85 -147 minecraft:white_concrete
setblock 233 85 -151 minecraft:white_concrete
setblock 235 85 -151 minecraft:white_concrete
setblock 232 85 -152 minecraft:white_concrete
setblock 227 85 -154 minecraft:white_concrete
setblock 225 85 -155 minecraft:white_concrete
setblock 224 85 -156 minecraft:white_concrete
setblock 222 85 -157 minecraft:white_concrete
setblock 220 85 -158 minecraft:white_concrete
setblock 219 85 -159 minecraft:white_concrete
setblock 216 85 -162 minecraft:white_concrete
setblock 214 85 -163 minecraft:white_concrete
setblock 212 85 -165 minecraft:white_concrete
setblock 210 85 -166 minecraft:white_concrete
setblock 257 85 -166 minecraft:white_concrete
setblock 259 85 -166 minecraft:white_concrete
setblock 262 85 -166 minecraft:white_concrete
setblock 251 85 -167 minecraft:white_concrete
setblock 253 85 -167 minecraft:white_concrete
setblock 255 85 -167 minecraft:white_concrete
setblock 208 85 -168 minecraft:white_concrete
setblock 206 85 -170 minecraft:white_concrete
setblock 242 85 -170 minecraft:white_concrete
setblock 239 85 -171 minecraft:white_concrete
setblock 204 85 -173 minecraft:white_concrete
setblock 236 85 -173 minecraft:white_concrete
setblock 202 85 -175 minecraft:white_concrete
setblock 233 85 -175 minecraft:white_concrete
setblock 202 85 -176 minecraft:white_concrete
setblock 231 85 -176 minecraft:white_concrete
setblock 229 85 -177 minecraft:white_concrete
setblock 200 85 -178 minecraft:white_concrete
setblock 200 85 -179 minecraft:white_concrete
setblock 226 85 -180 minecraft:white_concrete
setblock 224 85 -182 minecraft:white_concrete
setblock 222 85 -184 minecraft:white_concrete
setblock 220 85 -186 minecraft:white_concrete
setblock 218 85 -189 minecraft:white_concrete
setblock 214 84 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 84 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 84 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 84 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 213 84 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 84 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 84 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 84 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 84 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 84 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 214 84 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 84 -133 minecraft:spruce_log[axis=y]
setblock 216 84 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 84 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 213 84 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 84 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 84 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 84 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 84 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 83 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 83 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 83 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 83 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 83 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 83 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 214 83 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 83 -133 minecraft:spruce_log[axis=y]
setblock 216 83 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 83 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 249 82 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 250 82 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 251 82 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 250 82 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 82 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 82 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 82 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 82 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 82 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 82 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 82 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 82 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 82 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 82 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 82 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 82 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 82 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 82 -132 minecraft:spruce_log[axis=y]
setblock 206 82 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 207 82 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 213 82 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 82 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 82 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 82 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 82 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 82 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 82 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 82 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 82 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 82 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 82 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 214 82 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 82 -133 minecraft:spruce_log[axis=y]
setblock 216 82 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 82 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 82 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 82 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 82 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 82 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 82 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 82 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 82 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 82 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 81 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 81 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 81 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 209 81 -127 210 81 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 211 81 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 250 81 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 81 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 213 81 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 81 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 81 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 81 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 217 81 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 205 81 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 212 81 -131 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 213 81 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 81 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 81 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 81 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 81 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 81 -131 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 81 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 81 -132 minecraft:spruce_log[axis=y]
setblock 206 81 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 212 81 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 81 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 81 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 81 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 81 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 81 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 81 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 81 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 212 81 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 81 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 214 81 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 81 -133 minecraft:spruce_log[axis=y]
setblock 216 81 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 81 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 81 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 212 81 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 81 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 81 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 81 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 81 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 81 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 81 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 202 80 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 80 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 80 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 80 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 206 80 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 209 80 -127 210 80 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 211 80 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 249 80 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 250 80 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 251 80 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 80 -128 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 203 80 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 204 80 -128 205 80 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 206 80 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 216 80 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 250 80 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 203 80 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 80 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 80 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 80 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 216 80 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 217 80 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 80 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 80 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 80 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 80 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 80 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 80 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 80 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 80 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 80 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 80 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 80 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 80 -132 minecraft:spruce_log[axis=y]
setblock 206 80 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 207 80 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 80 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 203 80 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 80 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 80 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 80 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 80 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 80 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 80 -133 minecraft:spruce_log[axis=y]
setblock 216 80 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 204 80 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 80 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 80 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 80 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 80 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 80 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 80 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 80 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 80 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 80 -146 minecraft:spruce_log[axis=y]
setblock 200 80 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 80 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 80 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 80 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 79 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 79 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 79 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 79 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 79 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 208 79 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 209 79 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 210 79 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 211 79 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 212 79 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 215 79 -127 216 79 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 217 79 -127 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 248 79 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 249 79 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 79 -127 minecraft:spruce_log[axis=y]
setblock 251 79 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 252 79 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 79 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 79 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 79 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 79 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 206 79 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 209 79 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 210 79 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 211 79 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 79 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 215 79 -128 216 79 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 217 79 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 218 79 -128 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 248 79 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 79 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 250 79 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 251 79 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 252 79 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 79 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 79 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 79 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 79 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 207 79 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 79 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 215 79 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 216 79 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 79 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 79 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 242 79 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 79 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 79 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 251 79 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 202 79 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 79 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 79 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 79 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 79 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 79 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 208 79 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 79 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 79 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 79 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 217 79 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 218 79 -130 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 202 79 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 79 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 79 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 79 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 79 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 79 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 79 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 211 79 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 79 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 79 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 79 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 79 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 202 79 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 79 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 79 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 79 -132 minecraft:spruce_log[axis=y]
setblock 206 79 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 207 79 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 208 79 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 79 -132 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 211 79 -132 212 79 -132 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 79 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 79 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 79 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 79 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 79 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 202 79 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 79 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 79 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 79 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 79 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 79 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 79 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 211 79 -133 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 213 79 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 214 79 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 79 -133 minecraft:spruce_log[axis=y]
setblock 216 79 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 79 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 79 -134 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 79 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 79 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 79 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 79 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 79 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 208 79 -134 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 213 79 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 79 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 79 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 79 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 79 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 79 -135 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 79 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 79 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 79 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 207 79 -135 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 79 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 79 -135 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 79 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 79 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 79 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 79 -146 minecraft:spruce_log[axis=y]
setblock 201 79 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 202 78 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 78 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 78 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 78 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 78 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 208 78 -127 209 78 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 78 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 211 78 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 212 78 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 213 78 -127 214 78 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 215 78 -127 216 78 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 217 78 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 249 78 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 78 -127 minecraft:spruce_log[axis=y]
setblock 251 78 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 202 78 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 78 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 78 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 78 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 78 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 209 78 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 210 78 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 211 78 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 78 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 78 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 215 78 -128 216 78 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 78 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 78 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 242 78 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 78 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 203 78 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 78 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 78 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 78 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 78 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 78 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 78 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 78 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 78 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 241 78 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 242 78 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 78 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 78 -130 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 211 78 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 212 78 -130 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 213 78 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 78 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 215 78 -130 216 78 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 78 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 78 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 242 78 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 78 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 209 78 -131 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 210 78 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 211 78 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 212 78 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 213 78 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 78 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 78 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 78 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 78 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 78 -131 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 78 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 78 -132 minecraft:spruce_log[axis=y]
setblock 206 78 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 209 78 -132 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 210 78 -132 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 211 78 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 212 78 -132 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 78 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 78 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 78 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 78 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 78 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 78 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 78 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
fill 209 78 -133 210 78 -133 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 211 78 -133 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 212 78 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 78 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 214 78 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 78 -133 minecraft:spruce_log[axis=y]
setblock 216 78 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 78 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 78 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 78 -134 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 209 78 -134 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 210 78 -134 211 78 -134 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 212 78 -134 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 78 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 78 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 78 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 78 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 78 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 78 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 209 78 -135 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 212 78 -135 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 213 78 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 78 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 78 -135 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 78 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 78 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 78 -135 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 213 78 -136 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 78 -136 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 78 -136 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 78 -136 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 217 78 -136 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 200 78 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 78 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 78 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 78 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 78 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 78 -146 minecraft:spruce_log[axis=y]
setblock 200 78 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 78 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 78 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 78 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 203 77 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 204 77 -127 regions_unexplored:maple_log[axis=x]
setblock 205 77 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 208 77 -127 209 77 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 77 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 211 77 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 212 77 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 77 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 77 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 215 77 -127 216 77 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 77 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 77 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 248 77 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 249 77 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 77 -127 minecraft:spruce_log[axis=y]
setblock 251 77 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 252 77 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 77 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 209 77 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 210 77 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 211 77 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 77 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 77 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 77 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 216 77 -128 217 77 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 218 77 -128 219 77 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 248 77 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 77 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 250 77 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 251 77 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 252 77 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 77 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 77 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 77 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 77 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 77 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 77 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 219 77 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 242 77 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 249 77 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 77 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 251 77 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 77 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 77 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 77 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 77 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 211 77 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 212 77 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 77 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 77 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 77 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 77 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 77 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 219 77 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 77 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 77 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 77 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 77 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 77 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 209 77 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 210 77 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 211 77 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 212 77 -131 213 77 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 77 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 77 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 77 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 77 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 77 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 77 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 77 -132 minecraft:spruce_log[axis=y]
setblock 206 77 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 207 77 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 208 77 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 209 77 -132 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 210 77 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 211 77 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 212 77 -132 213 77 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 77 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 203 77 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 77 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 77 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 77 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 77 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 208 77 -133 210 77 -133 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 211 77 -133 212 77 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 77 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 214 77 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 77 -133 minecraft:spruce_log[axis=y]
setblock 216 77 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 204 77 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 77 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 77 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 207 77 -134 208 77 -134 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 209 77 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 210 77 -134 212 77 -134 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 77 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
fill 207 77 -135 208 77 -135 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 209 77 -135 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 210 77 -135 211 77 -135 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 208 77 -136 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 209 77 -136 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 210 77 -136 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 200 77 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 201 77 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 77 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 77 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 77 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 77 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 77 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 77 -146 minecraft:spruce_log[axis=y]
setblock 200 77 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 77 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 77 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 77 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 200 77 -149 201 77 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 76 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 213 76 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 76 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 215 76 -127 216 76 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 76 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 76 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 247 76 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 248 76 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 249 76 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 76 -127 minecraft:spruce_log[axis=y]
setblock 251 76 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 252 76 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 253 76 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 76 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 76 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 215 76 -128 216 76 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 76 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 218 76 -128 219 76 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 220 76 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 76 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 247 76 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 248 76 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 76 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 250 76 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 251 76 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 252 76 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 253 76 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 76 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 76 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 76 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 76 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 207 76 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 213 76 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 76 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 76 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 76 -129 regions_unexplored:maple_log[axis=y]
setblock 217 76 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 218 76 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 219 76 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 76 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 76 -129 minecraft:spruce_log[axis=y]
setblock 243 76 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 247 76 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 248 76 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 249 76 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 76 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 251 76 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 252 76 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 253 76 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 202 76 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 76 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 76 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 76 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 76 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 76 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 208 76 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 210 76 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 211 76 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 212 76 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 76 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 76 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 76 -130 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 76 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 76 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 219 76 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 242 76 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 248 76 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 249 76 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 250 76 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 251 76 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 252 76 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 202 76 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 76 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 76 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 76 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 76 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 76 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 76 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 209 76 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 210 76 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 211 76 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 212 76 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 76 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 76 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 76 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 76 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 76 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 76 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 202 76 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 76 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 76 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 76 -132 minecraft:spruce_log[axis=y]
setblock 206 76 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 207 76 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 208 76 -132 209 76 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 76 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 211 76 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 212 76 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 213 76 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 76 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 76 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 76 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 76 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 202 76 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 76 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 76 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 76 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 76 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 76 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 76 -133 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 209 76 -133 210 76 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 211 76 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 212 76 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 76 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 214 76 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 76 -133 minecraft:spruce_log[axis=y]
setblock 216 76 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 76 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 76 -134 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 76 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 76 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 76 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 76 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 76 -134 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 208 76 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 209 76 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 210 76 -134 211 76 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 212 76 -134 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 76 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 76 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 76 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 76 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 76 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 76 -135 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 76 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 76 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 76 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 207 76 -135 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 208 76 -135 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 209 76 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 210 76 -135 211 76 -135 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 76 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 76 -135 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 76 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 76 -136 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 209 76 -136 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 210 76 -136 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 201 76 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 76 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 76 -146 minecraft:spruce_log[axis=y]
setblock 201 76 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 75 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 75 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 75 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 75 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 220 75 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 75 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 242 75 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 75 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 75 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 75 -127 minecraft:spruce_log[axis=y]
setblock 251 75 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 214 75 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 75 -128 regions_unexplored:maple_log[axis=x]
setblock 216 75 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 75 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 75 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 219 75 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 220 75 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 221 75 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 75 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 75 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 75 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 75 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 244 75 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 75 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 75 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 75 -129 regions_unexplored:maple_log[axis=y]
setblock 217 75 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 218 75 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 219 75 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 220 75 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 221 75 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 240 75 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 75 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 75 -129 minecraft:spruce_log[axis=y]
setblock 243 75 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 244 75 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 213 75 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 75 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 75 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 75 -130 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 75 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 75 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 219 75 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 240 75 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 75 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 75 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 75 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 244 75 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 75 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 211 75 -131 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 212 75 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 213 75 -131 214 75 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 75 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 75 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 75 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 75 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 241 75 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 242 75 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 75 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 75 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 75 -132 minecraft:spruce_log[axis=y]
setblock 206 75 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 208 75 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 209 75 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 210 75 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 211 75 -132 regions_unexplored:maple_log[axis=y]
setblock 212 75 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 213 75 -132 214 75 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 75 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 75 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 75 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 75 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 75 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 207 75 -133 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 208 75 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 209 75 -133 210 75 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 211 75 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 212 75 -133 213 75 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 214 75 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 75 -133 minecraft:spruce_log[axis=y]
setblock 216 75 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 75 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 75 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 75 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 75 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 209 75 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 210 75 -134 211 75 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 212 75 -134 213 75 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 75 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 75 -134 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 75 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 75 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 75 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 207 75 -135 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 208 75 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 209 75 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 210 75 -135 211 75 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 212 75 -135 213 75 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 75 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 75 -135 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 75 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 75 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 75 -135 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 208 75 -136 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 209 75 -136 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 75 -136 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 75 -136 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 75 -136 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 75 -136 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 75 -136 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 217 75 -136 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 200 75 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 75 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 75 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 75 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 75 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 75 -146 minecraft:spruce_log[axis=y]
setblock 200 75 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 75 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 75 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 75 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 74 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 220 74 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 221 74 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 248 74 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 249 74 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 74 -127 minecraft:spruce_log[axis=y]
setblock 251 74 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 252 74 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 74 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 219 74 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 220 74 -128 regions_unexplored:maple_log[axis=y]
setblock 221 74 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 74 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 248 74 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 74 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 250 74 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 251 74 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 252 74 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 74 -129 regions_unexplored:maple_log[axis=y]
setblock 217 74 -129 regions_unexplored:maple_log[axis=x]
setblock 218 74 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 219 74 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 220 74 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 241 74 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 74 -129 minecraft:spruce_log[axis=y]
setblock 243 74 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 249 74 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 74 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 251 74 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 74 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 74 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 74 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 74 -130 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 74 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 203 74 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 74 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 74 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 74 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 74 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 74 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 74 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 74 -132 minecraft:spruce_log[axis=y]
setblock 206 74 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 207 74 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 211 74 -132 regions_unexplored:maple_log[axis=y]
setblock 203 74 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 74 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 74 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 74 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 74 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 209 74 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 74 -133 minecraft:spruce_log[axis=y]
setblock 228 74 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 74 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 74 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 74 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 74 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 209 74 -134 regions_unexplored:maple_log[axis=x]
setblock 210 74 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 209 74 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 74 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 201 74 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 74 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 74 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 74 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 74 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 74 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 74 -146 minecraft:spruce_log[axis=y]
setblock 200 74 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 74 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 74 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 74 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 74 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 201 74 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 73 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 219 73 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 220 73 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 221 73 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 73 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 241 73 -127 243 73 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 247 73 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 248 73 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 73 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 250 73 -127 minecraft:spruce_log[axis=y]
setblock 251 73 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 252 73 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 253 73 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 200 73 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 219 73 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 220 73 -128 regions_unexplored:maple_log[axis=y]
setblock 221 73 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 240 73 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 241 73 -128 243 73 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 244 73 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 247 73 -128 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 248 73 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 249 73 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 73 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 251 73 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 252 73 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 253 73 -128 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 200 73 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 73 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 73 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 73 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 73 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 207 73 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 216 73 -129 regions_unexplored:maple_log[axis=y]
setblock 219 73 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 220 73 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 221 73 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 73 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 73 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 73 -129 minecraft:spruce_log[axis=y]
setblock 243 73 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 244 73 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 247 73 -129 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 248 73 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 249 73 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 250 73 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 251 73 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 252 73 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 253 73 -129 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 202 73 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 73 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 73 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 73 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 73 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 73 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 208 73 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 220 73 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 73 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 73 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 73 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 73 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 244 73 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 248 73 -130 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 249 73 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 250 73 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 251 73 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 252 73 -130 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 202 73 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 73 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 73 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 73 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 73 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 73 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 73 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 241 73 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 242 73 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 73 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 202 73 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 73 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 73 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 73 -132 minecraft:spruce_log[axis=y]
setblock 206 73 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 207 73 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 208 73 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 211 73 -132 regions_unexplored:maple_log[axis=y]
setblock 228 73 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 229 73 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 202 73 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 203 73 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 73 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 73 -133 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 73 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 207 73 -133 208 73 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 73 -133 regions_unexplored:maple_log[axis=x]
setblock 215 73 -133 minecraft:spruce_log[axis=y]
setblock 227 73 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 228 73 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 73 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 73 -134 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 203 73 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 73 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 73 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 206 73 -134 207 73 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 73 -134 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 227 73 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 228 73 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 73 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 203 73 -135 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 204 73 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 73 -135 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 206 73 -135 207 73 -135 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 201 73 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 73 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 73 -146 minecraft:spruce_log[axis=y]
setblock 201 73 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 72 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 218 72 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 219 72 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 220 72 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 221 72 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 222 72 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 230 72 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 72 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 232 72 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 249 72 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 72 -127 minecraft:spruce_log[axis=y]
setblock 251 72 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 72 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 72 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 219 72 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 220 72 -128 regions_unexplored:maple_log[axis=y]
setblock 221 72 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 222 72 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 72 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 72 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 72 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 72 -129 regions_unexplored:maple_log[axis=y]
setblock 218 72 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 219 72 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 220 72 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 221 72 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 222 72 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 72 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 72 -129 minecraft:spruce_log[axis=y]
setblock 243 72 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 219 72 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 220 72 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 221 72 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 222 72 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 242 72 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 72 -132 minecraft:spruce_log[axis=y]
setblock 211 72 -132 regions_unexplored:maple_log[axis=y]
setblock 228 72 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 72 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 72 -133 minecraft:spruce_log[axis=y]
setblock 227 72 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 228 72 -133 regions_unexplored:maple_log[axis=y]
setblock 229 72 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 240 72 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 72 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 228 72 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 72 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 72 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 72 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 72 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 72 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 72 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 72 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 72 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 72 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 72 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 72 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 72 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 72 -146 minecraft:spruce_log[axis=y]
setblock 200 72 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 72 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 72 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 201 72 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 201 71 -127 203 71 -127 minecraft:air
setblock 218 71 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 219 71 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 220 71 -127 regions_unexplored:maple_branch[facing=south]
setblock 221 71 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 222 71 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 71 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 231 71 -127 regions_unexplored:maple_log[axis=y]
setblock 232 71 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 241 71 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 242 71 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 71 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 248 71 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 249 71 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 71 -127 minecraft:spruce_log[axis=y]
setblock 251 71 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 252 71 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 71 -128 minecraft:air
setblock 218 71 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 219 71 -128 regions_unexplored:maple_branch[facing=west]
setblock 220 71 -128 regions_unexplored:maple_log[axis=y]
setblock 221 71 -128 regions_unexplored:maple_branch[facing=east]
setblock 222 71 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 230 71 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 71 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 240 71 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 71 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 71 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 71 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 244 71 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 248 71 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 71 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 250 71 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 251 71 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 252 71 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 216 71 -129 regions_unexplored:maple_log[axis=y]
setblock 218 71 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 219 71 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 220 71 -129 regions_unexplored:maple_branch[facing=north]
setblock 221 71 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 222 71 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 71 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 71 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 71 -129 minecraft:spruce_log[axis=y]
setblock 243 71 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 244 71 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 249 71 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 71 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 251 71 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 219 71 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 220 71 -130 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 221 71 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 222 71 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 240 71 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 71 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 71 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 71 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 244 71 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 228 71 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 71 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 242 71 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 71 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 71 -132 minecraft:spruce_log[axis=y]
setblock 211 71 -132 regions_unexplored:maple_log[axis=y]
setblock 227 71 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 228 71 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 71 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 71 -133 minecraft:spruce_log[axis=y]
setblock 227 71 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 228 71 -133 regions_unexplored:maple_log[axis=y]
setblock 229 71 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 230 71 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 71 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 71 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 227 71 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 228 71 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 71 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 71 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 241 71 -134 regions_unexplored:maple_log[axis=y]
setblock 242 71 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 241 71 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 71 -146 minecraft:spruce_log[axis=y]
fill 200 70 -127 204 70 -127 minecraft:air
setblock 220 70 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 70 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 70 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 231 70 -127 regions_unexplored:maple_log[axis=y]
setblock 232 70 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 247 70 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 248 70 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 249 70 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 70 -127 minecraft:spruce_log[axis=y]
setblock 251 70 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 252 70 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 253 70 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 201 70 -128 203 70 -128 minecraft:air
setblock 219 70 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 220 70 -128 regions_unexplored:maple_log[axis=y]
setblock 221 70 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 230 70 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 70 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 232 70 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 70 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 247 70 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 248 70 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 70 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 250 70 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 251 70 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 252 70 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 253 70 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 216 70 -129 regions_unexplored:maple_log[axis=y]
setblock 220 70 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 231 70 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 70 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 70 -129 minecraft:spruce_log[axis=y]
setblock 243 70 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 247 70 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 248 70 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 249 70 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 70 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 251 70 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 252 70 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 253 70 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 242 70 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 248 70 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 249 70 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 250 70 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 251 70 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 252 70 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 227 70 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 228 70 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 229 70 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 230 70 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 70 -132 minecraft:spruce_log[axis=y]
setblock 211 70 -132 regions_unexplored:maple_log[axis=y]
setblock 212 70 -132 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 214 70 -132 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 215 70 -132 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
setblock 226 70 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 227 70 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 228 70 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 70 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 70 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 70 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 70 -133 minecraft:spruce_log[axis=y]
setblock 226 70 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 227 70 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 228 70 -133 regions_unexplored:maple_log[axis=y]
setblock 229 70 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 230 70 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 70 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 70 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 70 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 70 -134 regions_unexplored:grass_sprouts
setblock 226 70 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 227 70 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 228 70 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 70 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 70 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 240 70 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 241 70 -134 regions_unexplored:maple_log[axis=y]
setblock 242 70 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 70 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 212 70 -135 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
setblock 214 70 -135 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 215 70 -135 regions_unexplored:grass_sprouts
setblock 227 70 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 228 70 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 229 70 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 240 70 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 70 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 70 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 212 70 -136 regions_unexplored:grass_sprouts
setblock 215 70 -136 regions_unexplored:grass_sprouts
setblock 215 70 -137 minecraft:short_grass
setblock 201 70 -146 minecraft:spruce_log[axis=y]
fill 201 69 -127 203 69 -127 minecraft:air
setblock 229 69 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 69 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 231 69 -127 regions_unexplored:maple_log[axis=y]
setblock 232 69 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 233 69 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 69 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 242 69 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 69 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 249 69 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 69 -127 minecraft:spruce_log[axis=y]
setblock 251 69 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 202 69 -128 minecraft:air
setblock 220 69 -128 regions_unexplored:maple_log[axis=y]
setblock 229 69 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 230 69 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 69 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 232 69 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 233 69 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 240 69 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 69 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 69 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 69 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 244 69 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 250 69 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 69 -129 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 216 69 -129 regions_unexplored:maple_log[axis=y]
setblock 230 69 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 231 69 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 232 69 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 233 69 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 240 69 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 69 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 69 -129 minecraft:spruce_log[axis=y]
setblock 243 69 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 244 69 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 208 69 -130 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 209 69 -130 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
setblock 210 69 -130 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 211 69 -130 minecraft:short_grass
setblock 214 69 -130 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
setblock 216 69 -130 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 240 69 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 69 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 69 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 69 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 244 69 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 69 -131 regions_unexplored:grass_sprouts
setblock 208 69 -131 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 210 69 -131 regions_unexplored:grass_sprouts
setblock 212 69 -131 regions_unexplored:grass_sprouts
fill 213 69 -131 214 69 -131 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 216 69 -131 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
setblock 217 69 -131 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
setblock 226 69 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 227 69 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 228 69 -131 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 69 -131 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 69 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 69 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 242 69 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 69 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 69 -132 minecraft:spruce_log[axis=y]
setblock 208 69 -132 regions_unexplored:grass_sprouts
setblock 210 69 -132 minecraft:short_grass
setblock 211 69 -132 regions_unexplored:maple_log[axis=y]
fill 212 69 -132 216 69 -132 minecraft:grass_block[snowy=false]
fill 218 69 -132 219 69 -132 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 226 69 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 227 69 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 228 69 -132 regions_unexplored:maple_branch[facing=south]
setblock 229 69 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 230 69 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 69 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 241 69 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 69 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 69 -133 regions_unexplored:grass_sprouts
setblock 208 69 -133 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
setblock 210 69 -133 minecraft:short_grass
setblock 211 69 -133 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
fill 212 69 -133 214 69 -133 minecraft:grass_block[snowy=false]
setblock 215 69 -133 minecraft:dirt
setblock 216 69 -133 minecraft:grass_block[snowy=false]
setblock 226 69 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 227 69 -133 regions_unexplored:maple_branch[facing=west]
setblock 228 69 -133 regions_unexplored:maple_log[axis=y]
setblock 229 69 -133 regions_unexplored:maple_branch[facing=east]
setblock 230 69 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 239 69 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 240 69 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 69 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 69 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 69 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 69 -134 minecraft:short_grass
setblock 208 69 -134 minecraft:short_grass
setblock 211 69 -134 regions_unexplored:grass_sprouts
fill 212 69 -134 217 69 -134 minecraft:grass_block[snowy=false]
setblock 226 69 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 227 69 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 228 69 -134 regions_unexplored:maple_branch[facing=north]
setblock 229 69 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 230 69 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 239 69 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 69 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 241 69 -134 regions_unexplored:maple_log[axis=y]
setblock 242 69 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 69 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 69 -135 regions_unexplored:grass_sprouts
setblock 206 69 -135 minecraft:short_grass
setblock 209 69 -135 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 210 69 -135 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
fill 212 69 -135 217 69 -135 minecraft:grass_block[snowy=false]
setblock 218 69 -135 regions_unexplored:mossy_stone
setblock 226 69 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 227 69 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 228 69 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 229 69 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 69 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 239 69 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 240 69 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 69 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 69 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 243 69 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 69 -136 minecraft:short_grass
fill 212 69 -136 216 69 -136 minecraft:grass_block[snowy=false]
fill 217 69 -136 219 69 -136 minecraft:coarse_dirt
setblock 220 69 -136 regions_unexplored:mossy_stone
setblock 208 69 -137 minecraft:short_grass
setblock 212 69 -137 minecraft:short_grass
setblock 214 69 -137 minecraft:grass_block[snowy=false]
setblock 216 69 -137 minecraft:coarse_dirt
fill 219 69 -137 220 69 -137 minecraft:stone
setblock 201 69 -146 minecraft:spruce_log[axis=y]
setblock 202 68 -127 regions_unexplored:grass_sprouts
setblock 205 68 -127 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
setblock 216 68 -127 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 229 68 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 230 68 -127 regions_unexplored:maple_branch[facing=west]
setblock 231 68 -127 regions_unexplored:maple_log[axis=y]
setblock 232 68 -127 regions_unexplored:maple_branch[facing=east]
setblock 233 68 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 68 -127 minecraft:spruce_log[axis=y]
setblock 201 68 -128 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
setblock 202 68 -128 regions_unexplored:grass_sprouts
setblock 208 68 -128 minecraft:grass_block[snowy=false]
setblock 216 68 -128 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=3]
setblock 220 68 -128 regions_unexplored:maple_log[axis=y]
setblock 229 68 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 68 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 231 68 -128 regions_unexplored:maple_branch[facing=north]
setblock 232 68 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 233 68 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 68 -129 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
fill 207 68 -129 208 68 -129 minecraft:grass_block[snowy=false]
setblock 210 68 -129 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 211 68 -129 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 214 68 -129 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
setblock 215 68 -129 minecraft:grass_block[snowy=false]
setblock 216 68 -129 minecraft:dirt
setblock 218 68 -129 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
setblock 230 68 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 68 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 232 68 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 242 68 -129 minecraft:spruce_log[axis=y]
setblock 201 68 -130 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=3]
fill 207 68 -130 217 68 -130 minecraft:grass_block[snowy=false]
setblock 219 68 -130 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
fill 207 68 -131 218 68 -131 minecraft:grass_block[snowy=false]
setblock 205 68 -132 minecraft:spruce_log[axis=y]
fill 206 68 -132 210 68 -132 minecraft:grass_block[snowy=false]
fill 211 68 -132 216 68 -132 minecraft:dirt
fill 217 68 -132 218 68 -132 minecraft:grass_block[snowy=false]
setblock 219 68 -132 minecraft:coarse_dirt
setblock 228 68 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 239 68 -132 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 240 68 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 241 68 -132 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 242 68 -132 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 206 68 -133 211 68 -133 minecraft:grass_block[snowy=false]
fill 212 68 -133 216 68 -133 minecraft:dirt
fill 217 68 -133 218 68 -133 minecraft:grass_block[snowy=false]
fill 219 68 -133 220 68 -133 regions_unexplored:mossy_stone
setblock 227 68 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 228 68 -133 regions_unexplored:maple_log[axis=y]
setblock 229 68 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 239 68 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 68 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 241 68 -133 regions_unexplored:maple_branch[facing=south]
setblock 242 68 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 68 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 206 68 -134 211 68 -134 minecraft:grass_block[snowy=false]
fill 212 68 -134 217 68 -134 minecraft:dirt
fill 218 68 -134 220 68 -134 regions_unexplored:mossy_stone
setblock 228 68 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 239 68 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 240 68 -134 regions_unexplored:maple_branch[facing=west]
setblock 241 68 -134 regions_unexplored:maple_log[axis=y]
setblock 242 68 -134 regions_unexplored:maple_branch[facing=east]
setblock 243 68 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 68 -135 minecraft:short_grass
setblock 204 68 -135 minecraft:short_grass
fill 205 68 -135 211 68 -135 minecraft:grass_block[snowy=false]
fill 212 68 -135 218 68 -135 minecraft:dirt
fill 219 68 -135 220 68 -135 regions_unexplored:mossy_stone
setblock 221 68 -135 minecraft:stone
setblock 239 68 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 240 68 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 241 68 -135 regions_unexplored:maple_branch[facing=north]
setblock 242 68 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 243 68 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 68 -136 minecraft:short_grass
fill 205 68 -136 211 68 -136 minecraft:grass_block[snowy=false]
fill 212 68 -136 219 68 -136 minecraft:dirt
fill 220 68 -136 223 68 -136 minecraft:stone
fill 206 68 -137 213 68 -137 minecraft:grass_block[snowy=false]
setblock 214 68 -137 minecraft:dirt
setblock 216 68 -137 minecraft:dirt
fill 219 68 -137 220 68 -137 minecraft:stone
fill 221 68 -137 223 68 -137 regions_unexplored:mossy_stone
setblock 224 68 -137 minecraft:stone
setblock 204 68 -138 regions_unexplored:grass_sprouts
setblock 205 68 -138 minecraft:short_grass
fill 206 68 -138 207 68 -138 minecraft:grass_block[snowy=false]
setblock 207 68 -139 minecraft:grass_block[snowy=false]
setblock 200 68 -140 regions_unexplored:grass_sprouts
setblock 201 68 -143 regions_unexplored:grass_sprouts
setblock 201 68 -146 minecraft:spruce_log[axis=y]
fill 202 67 -127 216 67 -127 minecraft:grass_block[snowy=false]
setblock 230 67 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 231 67 -127 regions_unexplored:maple_log[axis=y]
setblock 232 67 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 250 67 -127 minecraft:spruce_log[axis=y]
fill 200 67 -128 207 67 -128 minecraft:grass_block[snowy=false]
setblock 208 67 -128 minecraft:dirt
fill 209 67 -128 216 67 -128 minecraft:grass_block[snowy=false]
setblock 220 67 -128 regions_unexplored:maple_log[axis=y]
setblock 231 67 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 200 67 -129 206 67 -129 minecraft:grass_block[snowy=false]
fill 207 67 -129 208 67 -129 minecraft:dirt
fill 209 67 -129 214 67 -129 minecraft:grass_block[snowy=false]
fill 215 67 -129 216 67 -129 minecraft:dirt
fill 217 67 -129 218 67 -129 minecraft:grass_block[snowy=false]
setblock 242 67 -129 minecraft:spruce_log[axis=y]
fill 201 67 -130 206 67 -130 minecraft:grass_block[snowy=false]
fill 207 67 -130 217 67 -130 minecraft:dirt
fill 218 67 -130 219 67 -130 minecraft:grass_block[snowy=false]
fill 201 67 -131 206 67 -131 minecraft:grass_block[snowy=false]
fill 207 67 -131 218 67 -131 minecraft:dirt
setblock 219 67 -131 minecraft:grass_block[snowy=false]
setblock 220 67 -131 minecraft:coarse_dirt
fill 201 67 -132 204 67 -132 minecraft:grass_block[snowy=false]
fill 205 67 -132 219 67 -132 minecraft:dirt
fill 220 67 -132 221 67 -132 minecraft:coarse_dirt
fill 201 67 -133 205 67 -133 minecraft:grass_block[snowy=false]
fill 206 67 -133 220 67 -133 minecraft:dirt
setblock 221 67 -133 regions_unexplored:mossy_stone
setblock 228 67 -133 regions_unexplored:maple_log[axis=y]
setblock 241 67 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 201 67 -134 205 67 -134 minecraft:grass_block[snowy=false]
fill 206 67 -134 220 67 -134 minecraft:dirt
fill 221 67 -134 222 67 -134 regions_unexplored:mossy_stone
setblock 240 67 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 241 67 -134 regions_unexplored:maple_log[axis=y]
setblock 242 67 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 201 67 -135 204 67 -135 minecraft:grass_block[snowy=false]
fill 205 67 -135 219 67 -135 minecraft:dirt
fill 220 67 -135 224 67 -135 minecraft:stone
setblock 241 67 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 201 67 -136 204 67 -136 minecraft:grass_block[snowy=false]
fill 205 67 -136 219 67 -136 minecraft:dirt
fill 220 67 -136 223 67 -136 minecraft:stone
fill 224 67 -136 225 67 -136 regions_unexplored:mossy_stone
fill 201 67 -137 205 67 -137 minecraft:grass_block[snowy=false]
fill 206 67 -137 214 67 -137 minecraft:dirt
setblock 216 67 -137 minecraft:dirt
fill 219 67 -137 224 67 -137 minecraft:stone
setblock 225 67 -137 regions_unexplored:mossy_stone
fill 201 67 -138 205 67 -138 minecraft:grass_block[snowy=false]
fill 206 67 -138 207 67 -138 minecraft:dirt
fill 201 67 -139 206 67 -139 minecraft:grass_block[snowy=false]
setblock 207 67 -139 minecraft:dirt
fill 200 67 -140 201 67 -140 minecraft:grass_block[snowy=false]
setblock 201 67 -141 minecraft:grass_block[snowy=false]
setblock 201 67 -142 minecraft:grass_block[snowy=false]
setblock 201 67 -143 minecraft:grass_block[snowy=false]
setblock 201 67 -144 minecraft:grass_block[snowy=false]
setblock 201 67 -146 minecraft:spruce_log[axis=y]
setblock 236 67 -180 minecraft:air
fill 200 66 -127 201 66 -127 minecraft:grass_block[snowy=false]
fill 202 66 -127 216 66 -127 minecraft:dirt
fill 217 66 -127 218 66 -127 minecraft:grass_block[snowy=false]
setblock 219 66 -127 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
setblock 220 66 -127 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=3]
setblock 231 66 -127 regions_unexplored:maple_log[axis=y]
setblock 250 66 -127 minecraft:spruce_log[axis=y]
fill 200 66 -128 216 66 -128 minecraft:dirt
fill 217 66 -128 219 66 -128 minecraft:grass_block[snowy=false]
setblock 220 66 -128 regions_unexplored:maple_log[axis=y]
fill 200 66 -129 218 66 -129 minecraft:dirt
setblock 219 66 -129 minecraft:grass_block[snowy=false]
fill 220 66 -129 221 66 -129 regions_unexplored:mossy_stone
setblock 222 66 -129 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
setblock 242 66 -129 minecraft:spruce_log[axis=y]
setblock 200 66 -130 minecraft:grass_block[snowy=false]
fill 201 66 -130 219 66 -130 minecraft:dirt
fill 220 66 -130 221 66 -130 minecraft:coarse_dirt
setblock 200 66 -131 minecraft:grass_block[snowy=false]
fill 201 66 -131 220 66 -131 minecraft:dirt
fill 221 66 -131 222 66 -131 minecraft:coarse_dirt
setblock 200 66 -132 minecraft:grass_block[snowy=false]
fill 201 66 -132 211 66 -132 minecraft:dirt
fill 212 66 -132 215 66 -132 minecraft:stone
fill 216 66 -132 221 66 -132 minecraft:dirt
setblock 222 66 -132 regions_unexplored:mossy_stone
setblock 200 66 -133 minecraft:grass_block[snowy=false]
fill 201 66 -133 211 66 -133 minecraft:dirt
fill 212 66 -133 215 66 -133 minecraft:stone
fill 216 66 -133 221 66 -133 minecraft:dirt
fill 222 66 -133 223 66 -133 regions_unexplored:mossy_stone
setblock 228 66 -133 regions_unexplored:maple_log[axis=y]
setblock 200 66 -134 minecraft:grass_block[snowy=false]
fill 201 66 -134 211 66 -134 minecraft:dirt
fill 212 66 -134 214 66 -134 minecraft:stone
fill 215 66 -134 220 66 -134 minecraft:dirt
fill 221 66 -134 222 66 -134 minecraft:stone
setblock 223 66 -134 regions_unexplored:mossy_stone
setblock 224 66 -134 minecraft:coarse_dirt
setblock 241 66 -134 regions_unexplored:maple_log[axis=y]
setblock 200 66 -135 minecraft:grass_block[snowy=false]
fill 201 66 -135 211 66 -135 minecraft:dirt
fill 212 66 -135 216 66 -135 minecraft:stone
fill 217 66 -135 219 66 -135 minecraft:dirt
fill 220 66 -135 224 66 -135 minecraft:stone
setblock 225 66 -135 regions_unexplored:mossy_stone
setblock 226 66 -135 regions_unexplored:grass_sprouts
setblock 200 66 -136 minecraft:grass_block[snowy=false]
fill 201 66 -136 211 66 -136 minecraft:dirt
fill 212 66 -136 214 66 -136 minecraft:stone
fill 215 66 -136 219 66 -136 minecraft:dirt
fill 220 66 -136 225 66 -136 minecraft:stone
setblock 226 66 -136 regions_unexplored:mossy_stone
setblock 200 66 -137 minecraft:grass_block[snowy=false]
fill 201 66 -137 213 66 -137 minecraft:dirt
setblock 214 66 -137 minecraft:stone
setblock 216 66 -137 minecraft:dirt
fill 219 66 -137 226 66 -137 minecraft:stone
setblock 200 66 -138 minecraft:grass_block[snowy=false]
fill 201 66 -138 207 66 -138 minecraft:dirt
setblock 200 66 -139 minecraft:grass_block[snowy=false]
fill 201 66 -139 207 66 -139 minecraft:dirt
fill 200 66 -140 201 66 -140 minecraft:dirt
setblock 200 66 -141 minecraft:grass_block[snowy=false]
setblock 201 66 -141 minecraft:dirt
setblock 200 66 -142 minecraft:grass_block[snowy=false]
setblock 201 66 -142 minecraft:dirt
setblock 200 66 -143 minecraft:grass_block[snowy=false]
setblock 201 66 -143 minecraft:dirt
setblock 200 66 -144 minecraft:grass_block[snowy=false]
setblock 201 66 -144 minecraft:dirt
fill 200 66 -145 201 66 -145 minecraft:grass_block[snowy=false]
setblock 200 66 -146 minecraft:grass_block[snowy=false]
setblock 201 66 -146 minecraft:dirt
setblock 200 66 -147 minecraft:grass_block[snowy=false]
setblock 225 66 -190 minecraft:air
fill 200 65 -127 218 65 -127 minecraft:dirt
fill 219 65 -127 221 65 -127 minecraft:grass_block[snowy=false]
setblock 231 65 -127 regions_unexplored:maple_log[axis=y]
setblock 250 65 -127 minecraft:spruce_log[axis=y]
fill 200 65 -128 207 65 -128 minecraft:dirt
setblock 208 65 -128 minecraft:stone
fill 209 65 -128 220 65 -128 minecraft:dirt
setblock 221 65 -128 regions_unexplored:mossy_stone
setblock 222 65 -128 minecraft:coarse_dirt
setblock 223 65 -128 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=4]
setblock 200 65 -129 minecraft:stone
fill 201 65 -129 206 65 -129 minecraft:dirt
fill 207 65 -129 208 65 -129 minecraft:stone
fill 209 65 -129 214 65 -129 minecraft:dirt
setblock 215 65 -129 minecraft:stone
fill 216 65 -129 221 65 -129 minecraft:dirt
setblock 222 65 -129 minecraft:coarse_dirt
setblock 242 65 -129 minecraft:spruce_log[axis=y]
fill 200 65 -130 206 65 -130 minecraft:dirt
fill 207 65 -130 215 65 -130 minecraft:stone
fill 216 65 -130 221 65 -130 minecraft:dirt
setblock 222 65 -130 minecraft:coarse_dirt
setblock 223 65 -130 regions_unexplored:mossy_stone
setblock 225 65 -130 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
fill 200 65 -131 206 65 -131 minecraft:dirt
fill 207 65 -131 216 65 -131 minecraft:stone
fill 217 65 -131 222 65 -131 minecraft:dirt
setblock 223 65 -131 regions_unexplored:mossy_stone
fill 200 65 -132 205 65 -132 minecraft:dirt
fill 206 65 -132 216 65 -132 minecraft:stone
fill 217 65 -132 222 65 -132 minecraft:dirt
setblock 223 65 -132 regions_unexplored:mossy_stone
setblock 224 65 -132 regions_unexplored:maple_log[axis=y]
setblock 225 65 -132 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
setblock 226 65 -132 minecraft:air
setblock 227 65 -132 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
fill 228 65 -132 263 65 -132 minecraft:air
fill 200 65 -133 205 65 -133 minecraft:dirt
fill 206 65 -133 216 65 -133 minecraft:stone
fill 217 65 -133 222 65 -133 minecraft:dirt
setblock 223 65 -133 minecraft:stone
setblock 224 65 -133 minecraft:coarse_dirt
setblock 226 65 -133 minecraft:air
setblock 227 65 -133 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=2]
setblock 228 65 -133 regions_unexplored:maple_log[axis=y]
fill 229 65 -133 263 65 -133 minecraft:air
fill 200 65 -134 205 65 -134 minecraft:dirt
fill 206 65 -134 217 65 -134 minecraft:stone
fill 218 65 -134 220 65 -134 minecraft:dirt
fill 221 65 -134 224 65 -134 minecraft:stone
fill 227 65 -134 240 65 -134 minecraft:air
setblock 241 65 -134 regions_unexplored:maple_log[axis=y]
fill 242 65 -134 260 65 -134 minecraft:air
fill 261 65 -134 263 65 -134 minecraft:cave_air
fill 200 65 -135 204 65 -135 minecraft:dirt
fill 205 65 -135 218 65 -135 minecraft:stone
setblock 219 65 -135 minecraft:dirt
fill 220 65 -135 226 65 -135 minecraft:stone
fill 227 65 -135 258 65 -135 minecraft:air
fill 259 65 -135 263 65 -135 minecraft:cave_air
fill 200 65 -136 204 65 -136 minecraft:dirt
fill 205 65 -136 227 65 -136 minecraft:stone
fill 228 65 -136 238 65 -136 minecraft:air
fill 243 65 -136 258 65 -136 minecraft:air
fill 259 65 -136 263 65 -136 minecraft:cave_air
fill 200 65 -137 205 65 -137 minecraft:dirt
fill 206 65 -137 214 65 -137 minecraft:stone
setblock 216 65 -137 minecraft:stone
fill 219 65 -137 228 65 -137 minecraft:stone
fill 229 65 -137 255 65 -137 minecraft:air
setblock 256 65 -137 minecraft:spruce_log[axis=y]
setblock 257 65 -137 minecraft:air
fill 258 65 -137 262 65 -137 minecraft:cave_air
fill 200 65 -138 205 65 -138 minecraft:dirt
fill 206 65 -138 212 65 -138 minecraft:stone
fill 216 65 -138 230 65 -138 minecraft:stone
fill 231 65 -138 250 65 -138 minecraft:air
fill 200 65 -139 206 65 -139 minecraft:dirt
fill 207 65 -139 208 65 -139 minecraft:stone
fill 210 65 -139 211 65 -139 minecraft:stone
fill 217 65 -139 230 65 -139 minecraft:stone
fill 231 65 -139 239 65 -139 minecraft:air
setblock 240 65 -139 minecraft:stone
setblock 241 65 -139 regions_unexplored:grass_sprouts
fill 242 65 -139 244 65 -139 minecraft:air
fill 200 65 -140 201 65 -140 minecraft:dirt
setblock 207 65 -140 minecraft:stone
fill 210 65 -140 211 65 -140 minecraft:stone
fill 216 65 -140 231 65 -140 minecraft:stone
fill 232 65 -140 235 65 -140 minecraft:air
fill 236 65 -140 237 65 -140 regions_unexplored:mossy_stone
fill 238 65 -140 240 65 -140 minecraft:stone
fill 200 65 -141 201 65 -141 minecraft:dirt
fill 202 65 -141 203 65 -141 minecraft:air
setblock 216 65 -141 minecraft:stone
fill 217 65 -141 218 65 -141 theurgy:sal_ammoniac_ore
fill 219 65 -141 234 65 -141 minecraft:stone
fill 235 65 -141 236 65 -141 regions_unexplored:mossy_stone
setblock 237 65 -141 minecraft:stone
setblock 200 65 -142 minecraft:dirt
fill 201 65 -142 204 65 -142 minecraft:air
fill 215 65 -142 216 65 -142 minecraft:stone
fill 217 65 -142 218 65 -142 theurgy:sal_ammoniac_ore
fill 219 65 -142 231 65 -142 minecraft:stone
fill 232 65 -142 234 65 -142 regions_unexplored:mossy_stone
setblock 200 65 -143 minecraft:dirt
fill 201 65 -143 204 65 -143 minecraft:air
fill 215 65 -143 231 65 -143 minecraft:stone
fill 200 65 -144 203 65 -144 minecraft:air
fill 215 65 -144 229 65 -144 minecraft:stone
setblock 200 65 -145 minecraft:air
setblock 201 65 -145 minecraft:dirt
fill 215 65 -145 227 65 -145 minecraft:stone
fill 200 65 -146 201 65 -146 minecraft:dirt
fill 216 65 -146 225 65 -146 minecraft:stone
setblock 200 65 -147 minecraft:dirt
fill 217 65 -147 223 65 -147 minecraft:stone
fill 217 65 -148 221 65 -148 minecraft:stone
fill 218 65 -149 219 65 -149 minecraft:stone
setblock 200 65 -159 minecraft:air
setblock 200 65 -160 minecraft:air
fill 200 65 -162 203 65 -162 minecraft:air
setblock 200 65 -163 regions_unexplored:grass_sprouts
fill 201 65 -163 202 65 -163 minecraft:air
setblock 200 65 -164 minecraft:air
setblock 201 65 -164 minecraft:short_grass
fill 213 64 -127 216 64 -127 minecraft:stone
fill 217 64 -127 221 64 -127 minecraft:dirt
fill 222 64 -127 223 64 -127 minecraft:grass_block[snowy=false]
setblock 224 64 -127 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 225 64 -127 minecraft:air
setblock 226 64 -127 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
fill 227 64 -127 230 64 -127 minecraft:air
setblock 231 64 -127 regions_unexplored:maple_log[axis=y]
setblock 232 64 -127 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
setblock 233 64 -127 minecraft:air
setblock 234 64 -127 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
fill 235 64 -127 236 64 -127 minecraft:air
setblock 237 64 -127 minecraft:short_grass
fill 238 64 -127 239 64 -127 minecraft:air
setblock 240 64 -127 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
fill 241 64 -127 244 64 -127 minecraft:air
setblock 245 64 -127 regions_unexplored:grass_sprouts
fill 246 64 -127 249 64 -127 minecraft:air
setblock 250 64 -127 minecraft:spruce_log[axis=y]
fill 251 64 -127 263 64 -127 minecraft:air
fill 213 64 -128 216 64 -128 minecraft:stone
fill 217 64 -128 222 64 -128 minecraft:dirt
fill 223 64 -128 224 64 -128 minecraft:grass_block[snowy=false]
fill 225 64 -128 228 64 -128 minecraft:air
setblock 229 64 -128 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 230 64 -128 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 231 64 -128 minecraft:air
fill 232 64 -128 233 64 -128 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
setblock 234 64 -128 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
fill 235 64 -128 237 64 -128 minecraft:air
setblock 238 64 -128 regions_unexplored:white_trillium
fill 239 64 -128 263 64 -128 minecraft:air
fill 213 64 -129 216 64 -129 minecraft:stone
fill 217 64 -129 222 64 -129 minecraft:dirt
fill 223 64 -129 224 64 -129 minecraft:coarse_dirt
setblock 225 64 -129 minecraft:grass_block[snowy=false]
fill 226 64 -129 233 64 -129 minecraft:air
setblock 234 64 -129 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
fill 235 64 -129 241 64 -129 minecraft:air
setblock 242 64 -129 minecraft:spruce_log[axis=y]
fill 243 64 -129 263 64 -129 minecraft:air
fill 213 64 -130 217 64 -130 minecraft:stone
fill 218 64 -130 223 64 -130 minecraft:dirt
setblock 224 64 -130 regions_unexplored:mossy_stone
fill 225 64 -130 226 64 -130 minecraft:grass_block[snowy=false]
fill 227 64 -130 229 64 -130 minecraft:air
setblock 230 64 -130 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
fill 231 64 -130 233 64 -130 minecraft:air
setblock 234 64 -130 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=3]
fill 235 64 -130 263 64 -130 minecraft:air
fill 213 64 -131 218 64 -131 minecraft:stone
fill 219 64 -131 223 64 -131 minecraft:dirt
setblock 224 64 -131 minecraft:coarse_dirt
fill 225 64 -131 226 64 -131 minecraft:grass_block[snowy=false]
fill 227 64 -131 237 64 -131 minecraft:air
setblock 238 64 -131 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
fill 239 64 -131 240 64 -131 minecraft:air
setblock 241 64 -131 regions_unexplored:white_trillium
fill 242 64 -131 263 64 -131 minecraft:air
fill 228 64 -132 230 64 -132 minecraft:air
setblock 231 64 -132 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=4]
fill 232 64 -132 241 64 -132 minecraft:air
fill 243 64 -132 262 64 -132 minecraft:air
fill 229 64 -133 239 64 -133 minecraft:air
setblock 240 64 -133 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
setblock 241 64 -133 minecraft:air
setblock 242 64 -133 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
fill 243 64 -133 263 64 -133 minecraft:air
fill 228 64 -134 238 64 -134 minecraft:air
setblock 239 64 -134 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=4]
setblock 240 64 -134 minecraft:air
setblock 242 64 -134 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
fill 243 64 -134 256 64 -134 minecraft:air
setblock 258 64 -134 minecraft:air
setblock 259 64 -134 minecraft:short_grass
fill 260 64 -134 263 64 -134 minecraft:cave_air
fill 229 64 -135 238 64 -135 minecraft:air
fill 241 64 -135 257 64 -135 minecraft:air
fill 258 64 -135 263 64 -135 minecraft:cave_air
fill 229 64 -136 234 64 -136 minecraft:air
fill 241 64 -136 253 64 -136 minecraft:air
setblock 254 64 -136 regions_unexplored:grass_sprouts
fill 255 64 -136 257 64 -136 minecraft:air
fill 258 64 -136 263 64 -136 minecraft:cave_air
setblock 232 64 -137 minecraft:air
fill 242 64 -137 255 64 -137 minecraft:air
setblock 257 64 -137 minecraft:air
fill 258 64 -137 263 64 -137 minecraft:cave_air
fill 243 64 -138 257 64 -138 minecraft:air
fill 258 64 -138 263 64 -138 minecraft:cave_air
fill 246 64 -139 255 64 -139 minecraft:air
setblock 256 64 -139 regions_unexplored:grass_sprouts
fill 257 64 -139 263 64 -139 minecraft:cave_air
fill 247 64 -140 256 64 -140 minecraft:air
fill 257 64 -140 263 64 -140 minecraft:cave_air
fill 202 64 -141 203 64 -141 minecraft:air
setblock 247 64 -141 minecraft:short_grass
fill 248 64 -141 251 64 -141 minecraft:air
setblock 252 64 -141 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
fill 253 64 -141 254 64 -141 regions_unexplored:grass_sprouts
fill 255 64 -141 256 64 -141 minecraft:air
fill 257 64 -141 263 64 -141 minecraft:cave_air
fill 201 64 -142 203 64 -142 minecraft:air
fill 247 64 -142 250 64 -142 minecraft:air
setblock 251 64 -142 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
setblock 252 64 -142 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 253 64 -142 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=3]
setblock 255 64 -142 minecraft:air
setblock 256 64 -142 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
fill 257 64 -142 263 64 -142 minecraft:cave_air
fill 201 64 -143 203 64 -143 minecraft:air
fill 247 64 -143 250 64 -143 minecraft:air
setblock 251 64 -143 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=3]
setblock 252 64 -143 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 253 64 -143 minecraft:short_grass
setblock 254 64 -143 minecraft:air
setblock 255 64 -143 regions_unexplored:grass_sprouts
fill 256 64 -143 257 64 -143 minecraft:air
fill 258 64 -143 263 64 -143 minecraft:cave_air
fill 200 64 -144 203 64 -144 minecraft:air
fill 247 64 -144 250 64 -144 minecraft:air
setblock 251 64 -144 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
fill 252 64 -144 253 64 -144 minecraft:air
setblock 254 64 -144 regions_unexplored:grass_sprouts
setblock 255 64 -144 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
fill 256 64 -144 259 64 -144 minecraft:air
setblock 260 64 -144 minecraft:short_grass
setblock 261 64 -144 minecraft:air
fill 262 64 -144 263 64 -144 minecraft:cave_air
fill 200 64 -145 203 64 -145 minecraft:air
setblock 247 64 -145 minecraft:air
setblock 248 64 -145 regions_unexplored:grass_sprouts
setblock 249 64 -145 minecraft:air
fill 250 64 -145 251 64 -145 regions_unexplored:grass_sprouts
fill 252 64 -145 256 64 -145 minecraft:air
setblock 257 64 -145 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
fill 258 64 -145 262 64 -145 minecraft:air
setblock 263 64 -145 regions_unexplored:grass_sprouts
fill 201 64 -146 202 64 -146 minecraft:air
fill 247 64 -146 251 64 -146 minecraft:air
setblock 252 64 -146 minecraft:short_grass
fill 253 64 -146 255 64 -146 minecraft:air
setblock 256 64 -146 minecraft:short_grass
fill 257 64 -146 263 64 -146 minecraft:air
fill 247 64 -147 251 64 -147 minecraft:air
setblock 252 64 -147 regions_unexplored:grass_sprouts
fill 253 64 -147 261 64 -147 minecraft:air
setblock 262 64 -147 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
setblock 263 64 -147 minecraft:air
setblock 247 64 -148 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=2]
setblock 248 64 -148 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=3]
setblock 249 64 -148 minecraft:air
setblock 250 64 -148 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
fill 251 64 -148 252 64 -148 minecraft:air
setblock 253 64 -148 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=2]
fill 254 64 -148 258 64 -148 minecraft:air
setblock 259 64 -148 regions_unexplored:grass_sprouts
fill 260 64 -148 262 64 -148 minecraft:air
setblock 263 64 -148 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
fill 247 64 -149 252 64 -149 minecraft:air
setblock 253 64 -149 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
setblock 254 64 -149 minecraft:air
setblock 255 64 -149 minecraft:short_grass
fill 256 64 -149 260 64 -149 minecraft:air
setblock 261 64 -149 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 262 64 -149 minecraft:air
setblock 263 64 -149 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
setblock 248 64 -150 regions_unexplored:grass_sprouts
setblock 249 64 -150 minecraft:air
fill 250 64 -150 251 64 -150 minecraft:short_grass
setblock 252 64 -150 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
fill 253 64 -150 255 64 -150 minecraft:air
setblock 256 64 -150 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
fill 257 64 -150 258 64 -150 minecraft:short_grass
fill 259 64 -150 263 64 -150 minecraft:air
fill 248 64 -151 253 64 -151 minecraft:air
setblock 254 64 -151 minecraft:short_grass
setblock 255 64 -151 minecraft:air
setblock 256 64 -151 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=2]
fill 257 64 -151 261 64 -151 minecraft:air
setblock 262 64 -151 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 263 64 -151 minecraft:air
fill 249 64 -152 251 64 -152 minecraft:air
setblock 252 64 -152 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=2]
fill 253 64 -152 255 64 -152 minecraft:air
setblock 256 64 -152 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=3]
fill 257 64 -152 260 64 -152 minecraft:air
setblock 261 64 -152 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
fill 262 64 -152 263 64 -152 minecraft:air
setblock 250 64 -153 minecraft:air
setblock 251 64 -153 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
setblock 252 64 -153 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
setblock 253 64 -153 regions_unexplored:grass_sprouts
setblock 254 64 -153 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=4]
setblock 255 64 -153 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 256 64 -153 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
setblock 257 64 -153 regions_unexplored:grass_sprouts
setblock 258 64 -153 minecraft:air
setblock 259 64 -153 regions_unexplored:grass_sprouts
fill 260 64 -153 263 64 -153 minecraft:air
setblock 250 64 -154 minecraft:air
setblock 251 64 -154 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
setblock 252 64 -154 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 253 64 -154 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
setblock 254 64 -154 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
setblock 255 64 -154 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
fill 256 64 -154 263 64 -154 minecraft:air
setblock 251 64 -155 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
fill 252 64 -155 253 64 -155 minecraft:air
setblock 255 64 -155 minecraft:air
setblock 256 64 -155 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
setblock 257 64 -155 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
fill 258 64 -155 259 64 -155 minecraft:air
setblock 260 64 -155 regions_unexplored:grass_sprouts
fill 261 64 -155 263 64 -155 minecraft:air
setblock 252 64 -156 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
fill 253 64 -156 254 64 -156 minecraft:air
setblock 255 64 -156 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
fill 256 64 -156 263 64 -156 minecraft:air
setblock 254 64 -157 minecraft:short_grass
fill 255 64 -157 263 64 -157 minecraft:air
setblock 263 64 -160 minecraft:air
setblock 200 64 -164 minecraft:air
setblock 200 64 -166 minecraft:air
setblock 200 64 -167 minecraft:short_grass
setblock 248 64 -167 regions_unexplored:grass_sprouts
fill 249 64 -167 250 64 -167 minecraft:air
setblock 251 64 -167 regions_unexplored:grass_sprouts
setblock 252 64 -167 minecraft:air
setblock 200 64 -168 regions_unexplored:grass_sprouts
fill 247 64 -168 253 64 -168 minecraft:air
fill 200 64 -169 202 64 -169 minecraft:air
fill 246 64 -169 254 64 -169 minecraft:air
setblock 200 64 -170 minecraft:air
setblock 202 64 -170 minecraft:short_grass
setblock 203 64 -170 minecraft:air
fill 245 64 -170 255 64 -170 minecraft:air
setblock 200 64 -171 minecraft:air
fill 201 64 -171 202 64 -171 regions_unexplored:grass_sprouts
fill 203 64 -171 206 64 -171 minecraft:air
fill 243 64 -171 255 64 -171 minecraft:air
fill 200 64 -172 207 64 -172 minecraft:air
fill 241 64 -172 256 64 -172 minecraft:air
fill 200 64 -173 205 64 -173 minecraft:air
setblock 206 64 -173 regions_unexplored:grass_sprouts
setblock 207 64 -173 minecraft:air
setblock 208 64 -173 regions_unexplored:grass_sprouts
fill 241 64 -173 252 64 -173 minecraft:air
setblock 253 64 -173 regions_unexplored:grass_sprouts
fill 254 64 -173 256 64 -173 minecraft:air
setblock 200 64 -174 regions_unexplored:grass_sprouts
fill 201 64 -174 205 64 -174 minecraft:air
setblock 206 64 -174 minecraft:short_grass
fill 207 64 -174 208 64 -174 minecraft:air
fill 242 64 -174 257 64 -174 minecraft:air
setblock 200 64 -175 minecraft:short_grass
fill 201 64 -175 207 64 -175 minecraft:air
setblock 208 64 -175 regions_unexplored:grass_sprouts
fill 242 64 -175 257 64 -175 minecraft:air
fill 200 64 -176 206 64 -176 minecraft:air
setblock 207 64 -176 regions_unexplored:grass_sprouts
setblock 208 64 -176 minecraft:air
fill 242 64 -176 257 64 -176 minecraft:air
fill 200 64 -177 206 64 -177 minecraft:air
fill 242 64 -177 257 64 -177 minecraft:air
fill 200 64 -178 206 64 -178 minecraft:air
fill 243 64 -178 248 64 -178 minecraft:air
setblock 249 64 -178 ars_nouveau:light_block[level=14,waterlogged=false]
fill 250 64 -178 257 64 -178 minecraft:air
setblock 200 64 -179 minecraft:air
setblock 201 64 -179 minecraft:short_grass
fill 202 64 -179 206 64 -179 minecraft:air
setblock 243 64 -179 regions_unexplored:grass_sprouts
fill 244 64 -179 255 64 -179 minecraft:air
setblock 256 64 -179 regions_unexplored:grass_sprouts
setblock 257 64 -179 minecraft:air
fill 200 64 -180 205 64 -180 minecraft:air
fill 243 64 -180 245 64 -180 minecraft:air
setblock 246 64 -180 regions_unexplored:grass_sprouts
setblock 247 64 -180 minecraft:air
setblock 248 64 -180 regions_unexplored:grass_sprouts
fill 249 64 -180 257 64 -180 minecraft:air
fill 200 64 -181 203 64 -181 minecraft:air
fill 243 64 -181 246 64 -181 minecraft:air
fill 247 64 -181 248 64 -181 regions_unexplored:grass_sprouts
fill 249 64 -181 251 64 -181 minecraft:air
setblock 252 64 -181 regions_unexplored:grass_sprouts
fill 253 64 -181 258 64 -181 minecraft:air
setblock 200 64 -182 minecraft:air
fill 243 64 -182 256 64 -182 minecraft:air
setblock 257 64 -182 regions_unexplored:grass_sprouts
fill 258 64 -182 262 64 -182 minecraft:air
setblock 263 64 -182 regions_unexplored:grass_sprouts
setblock 242 64 -183 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
fill 243 64 -183 244 64 -183 minecraft:air
setblock 245 64 -183 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
setblock 246 64 -183 minecraft:air
setblock 247 64 -183 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
fill 248 64 -183 261 64 -183 minecraft:air
setblock 262 64 -183 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 263 64 -183 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
fill 242 64 -184 262 64 -184 minecraft:air
setblock 263 64 -184 regions_unexplored:grass_sprouts
fill 242 64 -185 243 64 -185 minecraft:air
setblock 244 64 -185 minecraft:short_grass
setblock 245 64 -185 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
setblock 246 64 -185 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 247 64 -185 minecraft:short_grass
fill 248 64 -185 258 64 -185 minecraft:air
setblock 259 64 -185 regions_unexplored:grass_sprouts
setblock 260 64 -185 minecraft:short_grass
setblock 261 64 -185 regions_unexplored:grass_sprouts
setblock 262 64 -185 minecraft:air
setblock 263 64 -185 minecraft:short_grass
fill 242 64 -186 251 64 -186 minecraft:air
setblock 252 64 -186 minecraft:short_grass
fill 253 64 -186 261 64 -186 minecraft:air
setblock 262 64 -186 minecraft:short_grass
setblock 263 64 -186 minecraft:air
fill 242 64 -187 261 64 -187 minecraft:air
setblock 262 64 -187 regions_unexplored:grass_sprouts
setblock 263 64 -187 minecraft:air
setblock 242 64 -188 minecraft:air
setblock 243 64 -188 regions_unexplored:grass_sprouts
fill 244 64 -188 262 64 -188 minecraft:air
setblock 263 64 -188 minecraft:short_grass
fill 242 64 -189 244 64 -189 minecraft:air
setblock 245 64 -189 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 246 64 -189 minecraft:air
setblock 247 64 -189 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=4]
fill 248 64 -189 251 64 -189 minecraft:air
setblock 252 64 -189 minecraft:short_grass
fill 253 64 -189 260 64 -189 minecraft:air
fill 262 64 -189 263 64 -189 minecraft:air
fill 243 64 -190 263 64 -190 minecraft:air
fill 257 63 -127 263 63 -127 minecraft:air
fill 257 63 -128 263 63 -128 minecraft:air
fill 261 63 -129 263 63 -129 minecraft:air
fill 260 63 -134 263 63 -134 pneumaticcraft:oil[level=0]
fill 259 63 -135 263 63 -135 pneumaticcraft:oil[level=0]
fill 259 63 -136 263 63 -136 pneumaticcraft:oil[level=0]
fill 258 63 -137 263 63 -137 pneumaticcraft:oil[level=0]
fill 258 63 -138 263 63 -138 pneumaticcraft:oil[level=0]
fill 258 63 -139 263 63 -139 pneumaticcraft:oil[level=0]
fill 258 63 -140 263 63 -140 pneumaticcraft:oil[level=0]
fill 258 63 -141 263 63 -141 pneumaticcraft:oil[level=0]
fill 258 63 -142 263 63 -142 pneumaticcraft:oil[level=0]
fill 202 63 -143 203 63 -143 minecraft:air
fill 260 63 -143 263 63 -143 pneumaticcraft:oil[level=0]
fill 201 63 -144 203 63 -144 minecraft:air
fill 200 63 -145 203 63 -145 minecraft:air
fill 200 63 -146 203 63 -146 minecraft:air
fill 201 63 -147 203 63 -147 minecraft:air
setblock 261 63 -151 minecraft:air
fill 259 63 -152 260 63 -152 minecraft:air
setblock 203 63 -175 minecraft:air
fill 202 63 -176 205 63 -176 minecraft:air
fill 202 63 -177 206 63 -177 minecraft:air
fill 202 63 -178 207 63 -178 minecraft:air
fill 202 63 -179 206 63 -179 minecraft:air
fill 203 63 -180 205 63 -180 minecraft:air
setblock 204 63 -181 minecraft:air
fill 206 63 -182 207 63 -182 minecraft:air
fill 247 63 -186 249 63 -186 minecraft:air
setblock 257 63 -186 minecraft:air
fill 247 63 -187 249 63 -187 minecraft:air
setblock 257 63 -187 regions_unexplored:grass_sprouts
setblock 258 63 -187 minecraft:air
fill 247 63 -188 249 63 -188 minecraft:air
fill 257 63 -188 260 63 -188 minecraft:air
fill 258 63 -189 260 63 -189 minecraft:air
setblock 262 63 -189 minecraft:air
fill 260 63 -190 263 63 -190 minecraft:air
fill 260 62 -135 263 62 -135 pneumaticcraft:oil[level=0]
fill 260 62 -136 263 62 -136 pneumaticcraft:oil[level=0]
fill 260 62 -137 261 62 -137 pneumaticcraft:oil[level=0]
fill 260 62 -138 261 62 -138 pneumaticcraft:oil[level=0]
fill 259 62 -140 261 62 -140 pneumaticcraft:oil[level=0]
fill 260 62 -141 261 62 -141 pneumaticcraft:oil[level=0]
fill 201 62 -144 202 62 -144 minecraft:air
fill 201 62 -145 203 62 -145 minecraft:air
fill 201 62 -146 203 62 -146 minecraft:air
fill 201 62 -147 203 62 -147 minecraft:air
setblock 202 62 -148 minecraft:air
setblock 261 62 -151 minecraft:air
setblock 260 62 -152 minecraft:air
setblock 204 62 -175 minecraft:air
fill 203 62 -176 206 62 -176 minecraft:air
fill 202 62 -177 206 62 -177 minecraft:air
fill 201 62 -178 206 62 -178 minecraft:air
fill 202 62 -179 206 62 -179 minecraft:air
fill 203 62 -180 206 62 -180 minecraft:air
setblock 204 62 -181 minecraft:air
fill 206 62 -181 207 62 -181 minecraft:air
fill 204 62 -182 207 62 -182 minecraft:air
setblock 259 62 -188 minecraft:short_grass
setblock 260 62 -188 regions_unexplored:grass_sprouts
fill 259 62 -189 260 62 -189 minecraft:air
setblock 262 62 -189 minecraft:air
fill 260 62 -190 263 62 -190 minecraft:air
setblock 202 61 -145 minecraft:air
fill 201 61 -146 203 61 -146 minecraft:air
fill 201 61 -147 204 61 -147 minecraft:air
fill 203 61 -148 204 61 -148 minecraft:air
setblock 261 61 -151 minecraft:air
setblock 260 61 -152 minecraft:air
fill 203 61 -176 205 61 -176 minecraft:air
fill 202 61 -177 206 61 -177 minecraft:air
fill 203 61 -178 206 61 -178 minecraft:air
fill 202 61 -179 206 61 -179 minecraft:air
setblock 204 61 -180 minecraft:air
fill 206 61 -180 208 61 -180 minecraft:air
fill 204 61 -181 208 61 -181 minecraft:air
fill 204 61 -182 208 61 -182 minecraft:air
setblock 208 61 -183 minecraft:air
setblock 203 60 -146 minecraft:air
fill 202 60 -147 204 60 -147 minecraft:air
fill 202 60 -148 205 60 -148 minecraft:air
fill 202 60 -149 204 60 -149 minecraft:air
fill 205 60 -178 207 60 -178 minecraft:air
fill 205 60 -179 207 60 -179 minecraft:air
fill 204 60 -180 208 60 -180 minecraft:air
fill 204 60 -181 208 60 -181 minecraft:air
fill 204 60 -182 208 60 -182 minecraft:air
fill 207 60 -183 208 60 -183 minecraft:air
fill 207 60 -184 208 60 -184 minecraft:air
fill 203 59 -146 204 59 -146 minecraft:air
fill 202 59 -147 205 59 -147 minecraft:air
fill 202 59 -148 205 59 -148 minecraft:air
fill 203 59 -149 204 59 -149 minecraft:air
fill 204 58 -146 206 58 -146 minecraft:air
fill 203 58 -147 206 58 -147 minecraft:air
fill 203 58 -148 206 58 -148 minecraft:air
fill 203 58 -149 205 58 -149 minecraft:air
fill 204 57 -146 207 57 -146 minecraft:air
fill 203 57 -147 207 57 -147 minecraft:air
fill 203 57 -148 206 57 -148 minecraft:air
setblock 204 57 -149 minecraft:air
fill 205 56 -145 207 56 -145 minecraft:air
fill 204 56 -146 208 56 -146 minecraft:air
fill 204 56 -147 207 56 -147 minecraft:air
fill 204 56 -148 207 56 -148 minecraft:air
setblock 200 56 -178 minecraft:air
setblock 200 56 -179 minecraft:air
setblock 207 55 -144 minecraft:air
fill 205 55 -145 208 55 -145 minecraft:air
fill 205 55 -146 208 55 -146 minecraft:air
fill 205 55 -147 208 55 -147 minecraft:air
fill 205 55 -148 206 55 -148 minecraft:air
setblock 200 55 -178 minecraft:air
setblock 200 55 -179 minecraft:air
setblock 200 55 -180 minecraft:air
setblock 201 55 -181 minecraft:air
fill 206 54 -144 208 54 -144 minecraft:air
fill 206 54 -145 209 54 -145 minecraft:air
fill 205 54 -146 208 54 -146 minecraft:air
fill 206 54 -147 207 54 -147 minecraft:air
setblock 200 54 -178 minecraft:air
setblock 200 54 -179 minecraft:air
setblock 200 54 -180 minecraft:air
fill 200 54 -181 202 54 -181 minecraft:air
fill 200 54 -182 202 54 -182 minecraft:air
fill 201 54 -183 202 54 -183 minecraft:air
setblock 200 54 -189 minecraft:air
fill 200 54 -190 201 54 -190 minecraft:air
fill 207 53 -143 208 53 -143 minecraft:air
fill 206 53 -144 209 53 -144 minecraft:air
fill 206 53 -145 209 53 -145 minecraft:air
fill 206 53 -146 209 53 -146 minecraft:air
setblock 207 53 -147 minecraft:air
fill 200 53 -181 202 53 -181 minecraft:air
fill 200 53 -182 202 53 -182 minecraft:air
fill 201 53 -183 202 53 -183 minecraft:air
fill 201 53 -184 202 53 -184 minecraft:air
fill 201 53 -185 202 53 -185 minecraft:air
fill 201 53 -186 202 53 -186 minecraft:air
fill 201 53 -187 202 53 -187 minecraft:air
fill 200 53 -188 202 53 -188 minecraft:air
fill 200 53 -189 201 53 -189 minecraft:air
fill 200 53 -190 201 53 -190 minecraft:air
fill 207 52 -143 209 52 -143 minecraft:air
fill 206 52 -144 209 52 -144 minecraft:air
fill 206 52 -145 209 52 -145 minecraft:air
fill 207 52 -146 209 52 -146 minecraft:air
fill 200 52 -181 202 52 -181 minecraft:air
fill 200 52 -182 202 52 -182 minecraft:air
fill 201 52 -183 202 52 -183 minecraft:air
fill 201 52 -184 203 52 -184 minecraft:air
fill 201 52 -185 203 52 -185 minecraft:air
fill 201 52 -186 202 52 -186 minecraft:air
fill 200 52 -187 202 52 -187 minecraft:air
fill 200 52 -188 202 52 -188 minecraft:air
fill 200 52 -189 202 52 -189 minecraft:air
fill 200 52 -190 201 52 -190 minecraft:air
fill 207 51 -143 209 51 -143 minecraft:air
fill 207 51 -144 210 51 -144 minecraft:air
fill 207 51 -145 209 51 -145 minecraft:air
setblock 210 51 -145 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=false,waterlogged=false,west=false]
fill 207 51 -146 209 51 -146 minecraft:air
fill 201 51 -183 202 51 -183 minecraft:air
fill 201 51 -184 202 51 -184 minecraft:air
fill 201 51 -185 203 51 -185 minecraft:air
fill 201 51 -186 203 51 -186 minecraft:air
fill 200 51 -187 202 51 -187 minecraft:air
fill 200 51 -188 202 51 -188 minecraft:air
fill 200 51 -189 202 51 -189 minecraft:air
fill 200 51 -190 201 51 -190 minecraft:air
fill 209 50 -142 210 50 -142 minecraft:air
fill 207 50 -143 211 50 -143 minecraft:air
fill 207 50 -144 211 50 -144 minecraft:air
fill 207 50 -145 210 50 -145 minecraft:air
setblock 257 50 -158 minecraft:water[level=0]
fill 260 49 -128 261 49 -128 minecraft:water[level=0]
fill 218 49 -132 220 49 -132 minecraft:air
fill 219 49 -133 220 49 -133 minecraft:air
setblock 220 49 -134 minecraft:air
fill 223 49 -135 224 49 -135 minecraft:air
fill 222 49 -136 224 49 -136 minecraft:air
fill 222 49 -137 223 49 -137 minecraft:air
fill 222 49 -138 223 49 -138 minecraft:air
setblock 223 49 -139 minecraft:air
setblock 223 49 -140 minecraft:air
fill 208 49 -142 211 49 -142 minecraft:air
fill 208 49 -143 211 49 -143 minecraft:air
fill 208 49 -144 211 49 -144 minecraft:air
fill 208 49 -145 210 49 -145 minecraft:air
setblock 248 49 -150 minecraft:water[level=0]
setblock 248 49 -151 minecraft:water[level=0]
setblock 248 49 -152 minecraft:water[level=0]
setblock 260 49 -155 minecraft:water[level=0]
setblock 259 49 -156 minecraft:water[level=0]
setblock 258 49 -157 minecraft:water[level=0]
fill 257 49 -158 258 49 -158 minecraft:water[level=0]
setblock 216 49 -180 minecraft:air
setblock 216 49 -181 minecraft:air
fill 215 49 -182 217 49 -182 minecraft:air
fill 215 49 -183 218 49 -183 minecraft:air
fill 215 49 -184 219 49 -184 minecraft:air
fill 215 49 -185 218 49 -185 minecraft:air
fill 215 49 -186 218 49 -186 minecraft:air
fill 216 49 -187 217 49 -187 minecraft:air
fill 216 49 -188 217 49 -188 minecraft:air
fill 201 48 -127 202 48 -127 minecraft:air
fill 203 48 -127 204 48 -127 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 205 48 -127 236 48 -127 minecraft:air
fill 238 48 -127 254 48 -127 minecraft:water[level=0]
setblock 255 48 -127 minecraft:bubble_column[drag=true]
setblock 256 48 -127 minecraft:water[level=0]
setblock 257 48 -127 minecraft:bubble_column[drag=true]
fill 258 48 -127 263 48 -127 minecraft:water[level=0]
fill 201 48 -128 235 48 -128 minecraft:air
fill 238 48 -128 254 48 -128 minecraft:water[level=0]
setblock 255 48 -128 minecraft:bubble_column[drag=true]
fill 256 48 -128 263 48 -128 minecraft:water[level=0]
fill 200 48 -129 235 48 -129 minecraft:air
fill 238 48 -129 263 48 -129 minecraft:water[level=0]
fill 200 48 -130 234 48 -130 minecraft:air
fill 238 48 -130 254 48 -130 minecraft:water[level=0]
fill 257 48 -130 263 48 -130 minecraft:water[level=0]
fill 202 48 -131 230 48 -131 minecraft:air
fill 237 48 -131 253 48 -131 minecraft:water[level=0]
fill 259 48 -131 263 48 -131 minecraft:water[level=0]
fill 205 48 -132 225 48 -132 minecraft:air
fill 234 48 -132 263 48 -132 minecraft:water[level=0]
fill 206 48 -133 224 48 -133 minecraft:air
fill 230 48 -133 263 48 -133 minecraft:water[level=0]
fill 207 48 -134 225 48 -134 minecraft:air
fill 229 48 -134 263 48 -134 minecraft:water[level=0]
fill 209 48 -135 225 48 -135 minecraft:air
fill 229 48 -135 263 48 -135 minecraft:water[level=0]
fill 209 48 -136 225 48 -136 minecraft:air
fill 229 48 -136 263 48 -136 minecraft:water[level=0]
fill 210 48 -137 225 48 -137 minecraft:air
fill 229 48 -137 263 48 -137 minecraft:water[level=0]
fill 210 48 -138 225 48 -138 minecraft:air
fill 229 48 -138 263 48 -138 minecraft:water[level=0]
fill 211 48 -139 224 48 -139 minecraft:air
fill 228 48 -139 263 48 -139 minecraft:water[level=0]
fill 212 48 -140 224 48 -140 minecraft:air
fill 228 48 -140 263 48 -140 minecraft:water[level=0]
setblock 210 48 -141 minecraft:air
fill 213 48 -141 224 48 -141 minecraft:air
fill 228 48 -141 241 48 -141 minecraft:water[level=0]
fill 243 48 -141 263 48 -141 minecraft:water[level=0]
fill 209 48 -142 212 48 -142 minecraft:air
fill 215 48 -142 224 48 -142 minecraft:air
fill 228 48 -142 240 48 -142 minecraft:water[level=0]
fill 242 48 -142 263 48 -142 minecraft:water[level=0]
fill 208 48 -143 212 48 -143 minecraft:air
fill 216 48 -143 222 48 -143 minecraft:air
setblock 224 48 -143 minecraft:air
fill 228 48 -143 233 48 -143 minecraft:water[level=0]
setblock 234 48 -143 minecraft:bubble_column[drag=true]
fill 235 48 -143 240 48 -143 minecraft:water[level=0]
fill 242 48 -143 263 48 -143 minecraft:water[level=0]
fill 208 48 -144 211 48 -144 minecraft:air
fill 217 48 -144 223 48 -144 minecraft:air
fill 228 48 -144 237 48 -144 minecraft:water[level=0]
setblock 239 48 -144 minecraft:water[level=0]
fill 241 48 -144 263 48 -144 minecraft:water[level=0]
fill 209 48 -145 210 48 -145 minecraft:air
fill 218 48 -145 224 48 -145 minecraft:air
fill 230 48 -145 237 48 -145 minecraft:water[level=0]
fill 240 48 -145 242 48 -145 minecraft:water[level=0]
fill 244 48 -145 263 48 -145 minecraft:water[level=0]
fill 219 48 -146 227 48 -146 minecraft:air
fill 232 48 -146 236 48 -146 minecraft:water[level=0]
fill 240 48 -146 241 48 -146 minecraft:water[level=0]
fill 243 48 -146 263 48 -146 minecraft:water[level=0]
fill 219 48 -147 229 48 -147 minecraft:air
fill 234 48 -147 236 48 -147 minecraft:water[level=0]
fill 239 48 -147 240 48 -147 minecraft:water[level=0]
fill 242 48 -147 262 48 -147 minecraft:water[level=0]
fill 220 48 -148 232 48 -148 minecraft:air
setblock 239 48 -148 minecraft:water[level=0]
setblock 241 48 -148 minecraft:water[level=0]
setblock 242 48 -148 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=true,west=false]
fill 243 48 -148 262 48 -148 minecraft:water[level=0]
fill 219 48 -149 232 48 -149 minecraft:air
setblock 233 48 -149 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=false,west=false]
setblock 234 48 -149 minecraft:air
setblock 241 48 -149 minecraft:water[level=0]
setblock 242 48 -149 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=true,west=false]
fill 243 48 -149 263 48 -149 minecraft:water[level=0]
fill 219 48 -150 236 48 -150 minecraft:air
fill 240 48 -150 263 48 -150 minecraft:water[level=0]
fill 218 48 -151 236 48 -151 minecraft:air
fill 239 48 -151 263 48 -151 minecraft:water[level=0]
fill 217 48 -152 237 48 -152 minecraft:air
fill 239 48 -152 263 48 -152 minecraft:water[level=0]
fill 217 48 -153 237 48 -153 minecraft:air
fill 239 48 -153 263 48 -153 minecraft:water[level=0]
fill 216 48 -154 236 48 -154 minecraft:air
fill 239 48 -154 263 48 -154 minecraft:water[level=0]
fill 215 48 -155 236 48 -155 minecraft:air
fill 239 48 -155 263 48 -155 minecraft:water[level=0]
fill 214 48 -156 236 48 -156 minecraft:air
fill 238 48 -156 263 48 -156 minecraft:water[level=0]
fill 213 48 -157 236 48 -157 minecraft:air
fill 238 48 -157 263 48 -157 minecraft:water[level=0]
fill 212 48 -158 236 48 -158 minecraft:air
fill 238 48 -158 263 48 -158 minecraft:water[level=0]
fill 211 48 -159 235 48 -159 minecraft:air
fill 240 48 -159 263 48 -159 minecraft:water[level=0]
fill 210 48 -160 236 48 -160 minecraft:air
fill 242 48 -160 263 48 -160 minecraft:water[level=0]
fill 210 48 -161 239 48 -161 minecraft:air
fill 245 48 -161 263 48 -161 minecraft:water[level=0]
fill 209 48 -162 242 48 -162 minecraft:air
fill 251 48 -162 263 48 -162 minecraft:water[level=0]
fill 208 48 -163 243 48 -163 minecraft:air
fill 252 48 -163 262 48 -163 minecraft:water[level=0]
fill 208 48 -164 247 48 -164 minecraft:air
setblock 250 48 -164 minecraft:air
fill 254 48 -164 261 48 -164 minecraft:water[level=0]
fill 207 48 -165 251 48 -165 minecraft:air
fill 254 48 -165 261 48 -165 minecraft:water[level=0]
fill 207 48 -166 241 48 -166 minecraft:air
setblock 242 48 -166 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 243 48 -166 251 48 -166 minecraft:air
fill 254 48 -166 262 48 -166 minecraft:water[level=0]
fill 206 48 -167 234 48 -167 minecraft:air
setblock 235 48 -167 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 236 48 -167 241 48 -167 minecraft:air
setblock 242 48 -167 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 243 48 -167 251 48 -167 minecraft:air
fill 254 48 -167 263 48 -167 minecraft:water[level=0]
fill 206 48 -168 251 48 -168 minecraft:air
fill 254 48 -168 263 48 -168 minecraft:water[level=0]
fill 205 48 -169 251 48 -169 minecraft:air
fill 254 48 -169 263 48 -169 minecraft:water[level=0]
fill 205 48 -170 251 48 -170 minecraft:air
fill 254 48 -170 258 48 -170 minecraft:water[level=0]
setblock 263 48 -170 minecraft:water[level=0]
fill 203 48 -171 251 48 -171 minecraft:air
fill 254 48 -171 255 48 -171 minecraft:water[level=0]
fill 202 48 -172 251 48 -172 minecraft:air
fill 201 48 -173 241 48 -173 minecraft:air
setblock 242 48 -173 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 243 48 -173 251 48 -173 minecraft:air
fill 200 48 -174 241 48 -174 minecraft:air
setblock 242 48 -174 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 243 48 -174 250 48 -174 minecraft:air
fill 200 48 -175 250 48 -175 minecraft:air
fill 200 48 -176 201 48 -176 minecraft:air
fill 202 48 -176 203 48 -176 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 204 48 -176 249 48 -176 minecraft:air
fill 260 48 -176 261 48 -176 minecraft:water[level=0]
fill 200 48 -177 249 48 -177 minecraft:air
setblock 260 48 -177 minecraft:water[level=0]
fill 200 48 -178 219 48 -178 minecraft:air
fill 220 48 -178 221 48 -178 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 222 48 -178 249 48 -178 minecraft:air
setblock 260 48 -178 minecraft:water[level=0]
fill 200 48 -179 249 48 -179 minecraft:air
setblock 260 48 -179 minecraft:water[level=0]
fill 200 48 -180 249 48 -180 minecraft:air
fill 200 48 -181 250 48 -181 minecraft:air
fill 200 48 -182 250 48 -182 minecraft:air
fill 201 48 -183 251 48 -183 minecraft:air
fill 201 48 -184 251 48 -184 minecraft:air
fill 201 48 -185 250 48 -185 minecraft:air
fill 200 48 -186 246 48 -186 minecraft:air
fill 200 48 -187 243 48 -187 minecraft:air
fill 200 48 -188 202 48 -188 minecraft:air
fill 205 48 -188 241 48 -188 minecraft:air
fill 200 48 -189 202 48 -189 minecraft:air
fill 205 48 -189 231 48 -189 minecraft:air
fill 234 48 -189 236 48 -189 minecraft:air
fill 200 48 -190 201 48 -190 minecraft:air
fill 206 48 -190 229 48 -190 minecraft:air
fill 200 47 -127 236 47 -127 minecraft:air
fill 238 47 -127 254 47 -127 minecraft:water[level=0]
setblock 255 47 -127 minecraft:bubble_column[drag=true]
setblock 256 47 -127 minecraft:water[level=0]
setblock 257 47 -127 minecraft:bubble_column[drag=true]
fill 258 47 -127 263 47 -127 minecraft:water[level=0]
fill 200 47 -128 235 47 -128 minecraft:air
fill 238 47 -128 254 47 -128 minecraft:water[level=0]
setblock 255 47 -128 minecraft:bubble_column[drag=true]
fill 256 47 -128 263 47 -128 minecraft:water[level=0]
fill 200 47 -129 235 47 -129 minecraft:air
fill 238 47 -129 263 47 -129 minecraft:water[level=0]
fill 200 47 -130 233 47 -130 minecraft:air
fill 237 47 -130 253 47 -130 minecraft:water[level=0]
fill 255 47 -130 263 47 -130 minecraft:water[level=0]
fill 203 47 -131 230 47 -131 minecraft:air
fill 237 47 -131 253 47 -131 minecraft:water[level=0]
fill 258 47 -131 263 47 -131 minecraft:water[level=0]
fill 205 47 -132 226 47 -132 minecraft:air
fill 233 47 -132 253 47 -132 minecraft:water[level=0]
fill 258 47 -132 263 47 -132 minecraft:water[level=0]
fill 207 47 -133 226 47 -133 minecraft:air
fill 230 47 -133 263 47 -133 minecraft:water[level=0]
fill 208 47 -134 226 47 -134 minecraft:air
fill 230 47 -134 263 47 -134 minecraft:water[level=0]
fill 209 47 -135 226 47 -135 minecraft:air
fill 230 47 -135 263 47 -135 minecraft:water[level=0]
fill 210 47 -136 226 47 -136 minecraft:air
fill 230 47 -136 263 47 -136 minecraft:water[level=0]
fill 211 47 -137 226 47 -137 minecraft:air
fill 230 47 -137 263 47 -137 minecraft:water[level=0]
fill 211 47 -138 226 47 -138 minecraft:air
fill 230 47 -138 241 47 -138 minecraft:water[level=0]
fill 247 47 -138 263 47 -138 minecraft:water[level=0]
fill 212 47 -139 226 47 -139 minecraft:air
fill 230 47 -139 241 47 -139 minecraft:water[level=0]
fill 247 47 -139 263 47 -139 minecraft:water[level=0]
fill 213 47 -140 226 47 -140 minecraft:air
fill 230 47 -140 240 47 -140 minecraft:water[level=0]
fill 248 47 -140 263 47 -140 minecraft:water[level=0]
fill 210 47 -141 212 47 -141 minecraft:air
fill 214 47 -141 225 47 -141 minecraft:air
fill 229 47 -141 239 47 -141 minecraft:water[level=0]
fill 248 47 -141 263 47 -141 minecraft:water[level=0]
fill 209 47 -142 213 47 -142 minecraft:air
fill 215 47 -142 225 47 -142 minecraft:air
fill 229 47 -142 239 47 -142 minecraft:water[level=0]
fill 248 47 -142 263 47 -142 minecraft:water[level=0]
fill 209 47 -143 213 47 -143 minecraft:air
fill 217 47 -143 225 47 -143 minecraft:air
fill 229 47 -143 233 47 -143 minecraft:water[level=0]
setblock 234 47 -143 minecraft:bubble_column[drag=true]
fill 235 47 -143 238 47 -143 minecraft:water[level=0]
fill 248 47 -143 263 47 -143 minecraft:water[level=0]
fill 209 47 -144 212 47 -144 minecraft:air
fill 217 47 -144 225 47 -144 minecraft:air
fill 229 47 -144 237 47 -144 minecraft:water[level=0]
fill 247 47 -144 263 47 -144 minecraft:water[level=0]
fill 218 47 -145 226 47 -145 minecraft:air
fill 229 47 -145 236 47 -145 minecraft:water[level=0]
fill 246 47 -145 263 47 -145 minecraft:water[level=0]
fill 219 47 -146 226 47 -146 minecraft:air
fill 232 47 -146 236 47 -146 minecraft:water[level=0]
fill 245 47 -146 263 47 -146 minecraft:water[level=0]
fill 219 47 -147 228 47 -147 minecraft:air
fill 234 47 -147 235 47 -147 minecraft:water[level=0]
fill 244 47 -147 259 47 -147 minecraft:water[level=0]
fill 220 47 -148 230 47 -148 minecraft:air
fill 243 47 -148 258 47 -148 minecraft:water[level=0]
fill 219 47 -149 232 47 -149 minecraft:air
setblock 233 47 -149 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=false,west=false]
setblock 234 47 -149 minecraft:air
fill 242 47 -149 261 47 -149 minecraft:water[level=0]
fill 219 47 -150 235 47 -150 minecraft:air
fill 241 47 -150 262 47 -150 minecraft:water[level=0]
fill 218 47 -151 236 47 -151 minecraft:air
fill 241 47 -151 262 47 -151 minecraft:water[level=0]
setblock 218 47 -152 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 219 47 -152 236 47 -152 minecraft:air
fill 240 47 -152 263 47 -152 minecraft:water[level=0]
fill 217 47 -153 236 47 -153 minecraft:air
fill 238 47 -153 263 47 -153 minecraft:water[level=0]
fill 217 47 -154 236 47 -154 minecraft:air
fill 238 47 -154 263 47 -154 minecraft:water[level=0]
fill 216 47 -155 236 47 -155 minecraft:air
fill 238 47 -155 263 47 -155 minecraft:water[level=0]
fill 215 47 -156 235 47 -156 minecraft:air
fill 238 47 -156 263 47 -156 minecraft:water[level=0]
fill 213 47 -157 235 47 -157 minecraft:air
fill 238 47 -157 263 47 -157 minecraft:water[level=0]
fill 212 47 -158 235 47 -158 minecraft:air
fill 237 47 -158 263 47 -158 minecraft:water[level=0]
fill 211 47 -159 235 47 -159 minecraft:air
fill 238 47 -159 263 47 -159 minecraft:water[level=0]
fill 210 47 -160 235 47 -160 minecraft:air
fill 241 47 -160 263 47 -160 minecraft:water[level=0]
fill 210 47 -161 238 47 -161 minecraft:air
fill 243 47 -161 263 47 -161 minecraft:water[level=0]
fill 209 47 -162 240 47 -162 minecraft:air
fill 249 47 -162 250 47 -162 minecraft:water[level=0]
fill 252 47 -162 263 47 -162 minecraft:water[level=0]
fill 208 47 -163 241 47 -163 minecraft:air
fill 253 47 -163 261 47 -163 minecraft:water[level=0]
fill 208 47 -164 245 47 -164 minecraft:air
fill 248 47 -164 249 47 -164 minecraft:air
fill 255 47 -164 261 47 -164 minecraft:water[level=0]
fill 207 47 -165 252 47 -165 minecraft:air
fill 255 47 -165 260 47 -165 minecraft:water[level=0]
fill 207 47 -166 252 47 -166 minecraft:air
fill 255 47 -166 260 47 -166 minecraft:water[level=0]
fill 206 47 -167 252 47 -167 minecraft:air
fill 255 47 -167 259 47 -167 minecraft:water[level=0]
fill 205 47 -168 252 47 -168 minecraft:air
fill 255 47 -168 258 47 -168 minecraft:water[level=0]
fill 205 47 -169 252 47 -169 minecraft:air
fill 255 47 -169 256 47 -169 minecraft:water[level=0]
fill 204 47 -170 252 47 -170 minecraft:air
fill 203 47 -171 251 47 -171 minecraft:air
fill 201 47 -172 251 47 -172 minecraft:air
fill 201 47 -173 250 47 -173 minecraft:air
fill 200 47 -174 249 47 -174 minecraft:air
fill 200 47 -175 249 47 -175 minecraft:air
fill 200 47 -176 248 47 -176 minecraft:air
fill 200 47 -177 248 47 -177 minecraft:air
fill 200 47 -178 247 47 -178 minecraft:air
fill 200 47 -179 247 47 -179 minecraft:air
fill 200 47 -180 247 47 -180 minecraft:air
fill 200 47 -181 247 47 -181 minecraft:air
fill 200 47 -182 247 47 -182 minecraft:air
fill 201 47 -183 247 47 -183 minecraft:air
fill 201 47 -184 247 47 -184 minecraft:air
fill 201 47 -185 245 47 -185 minecraft:air
fill 200 47 -186 243 47 -186 minecraft:air
fill 200 47 -187 236 47 -187 minecraft:air
setblock 237 47 -187 minecraft:lava[level=4]
fill 238 47 -187 242 47 -187 minecraft:air
fill 200 47 -188 236 47 -188 minecraft:air
setblock 237 47 -188 minecraft:lava[level=2]
fill 238 47 -188 239 47 -188 minecraft:air
fill 200 47 -189 203 47 -189 minecraft:air
fill 205 47 -189 230 47 -189 minecraft:air
fill 232 47 -189 234 47 -189 minecraft:air
setblock 237 47 -189 minecraft:lava[level=0]
fill 200 47 -190 202 47 -190 minecraft:air
fill 205 47 -190 228 47 -190 minecraft:air
fill 200 46 -127 235 46 -127 minecraft:air
fill 238 46 -127 254 46 -127 minecraft:water[level=0]
setblock 255 46 -127 minecraft:bubble_column[drag=true]
setblock 256 46 -127 minecraft:water[level=0]
setblock 257 46 -127 minecraft:bubble_column[drag=true]
fill 258 46 -127 263 46 -127 minecraft:water[level=0]
fill 200 46 -128 235 46 -128 minecraft:air
fill 238 46 -128 254 46 -128 minecraft:water[level=0]
setblock 255 46 -128 minecraft:bubble_column[drag=true]
fill 256 46 -128 263 46 -128 minecraft:water[level=0]
fill 200 46 -129 235 46 -129 minecraft:air
fill 238 46 -129 263 46 -129 minecraft:water[level=0]
fill 202 46 -130 233 46 -130 minecraft:air
fill 237 46 -130 263 46 -130 minecraft:water[level=0]
fill 204 46 -131 228 46 -131 minecraft:air
setblock 230 46 -131 minecraft:air
fill 237 46 -131 253 46 -131 minecraft:water[level=0]
fill 258 46 -131 263 46 -131 minecraft:water[level=0]
fill 206 46 -132 226 46 -132 minecraft:air
fill 233 46 -132 253 46 -132 minecraft:water[level=0]
fill 258 46 -132 263 46 -132 minecraft:water[level=0]
fill 207 46 -133 228 46 -133 minecraft:air
fill 232 46 -133 263 46 -133 minecraft:water[level=0]
fill 208 46 -134 228 46 -134 minecraft:air
fill 232 46 -134 263 46 -134 minecraft:water[level=0]
fill 210 46 -135 227 46 -135 minecraft:air
fill 231 46 -135 263 46 -135 minecraft:water[level=0]
fill 211 46 -136 227 46 -136 minecraft:air
fill 231 46 -136 263 46 -136 minecraft:water[level=0]
fill 211 46 -137 227 46 -137 minecraft:air
fill 231 46 -137 240 46 -137 minecraft:water[level=0]
setblock 247 46 -137 minecraft:glow_lichen[down=true,east=false,north=false,south=false,up=false,waterlogged=true,west=true]
fill 248 46 -137 263 46 -137 minecraft:water[level=0]
fill 212 46 -138 227 46 -138 minecraft:air
fill 231 46 -138 240 46 -138 minecraft:water[level=0]
fill 248 46 -138 263 46 -138 minecraft:water[level=0]
fill 213 46 -139 227 46 -139 minecraft:air
fill 231 46 -139 239 46 -139 minecraft:water[level=0]
setblock 243 46 -139 minecraft:air
fill 249 46 -139 263 46 -139 minecraft:water[level=0]
fill 214 46 -140 227 46 -140 minecraft:air
fill 231 46 -140 238 46 -140 minecraft:water[level=0]
setblock 243 46 -140 minecraft:air
fill 249 46 -140 263 46 -140 minecraft:water[level=0]
fill 210 46 -141 213 46 -141 minecraft:air
fill 215 46 -141 227 46 -141 minecraft:air
fill 231 46 -141 237 46 -141 minecraft:water[level=0]
fill 242 46 -141 243 46 -141 minecraft:air
fill 249 46 -141 263 46 -141 minecraft:water[level=0]
fill 210 46 -142 214 46 -142 minecraft:air
fill 216 46 -142 227 46 -142 minecraft:air
fill 231 46 -142 237 46 -142 minecraft:water[level=0]
fill 241 46 -142 243 46 -142 minecraft:air
fill 249 46 -142 263 46 -142 minecraft:water[level=0]
fill 209 46 -143 213 46 -143 minecraft:air
fill 217 46 -143 226 46 -143 minecraft:air
fill 230 46 -143 233 46 -143 minecraft:water[level=0]
setblock 234 46 -143 minecraft:bubble_column[drag=true]
fill 235 46 -143 236 46 -143 minecraft:water[level=0]
fill 240 46 -143 243 46 -143 minecraft:air
fill 248 46 -143 263 46 -143 minecraft:water[level=0]
fill 210 46 -144 212 46 -144 minecraft:air
fill 217 46 -144 226 46 -144 minecraft:air
fill 230 46 -144 235 46 -144 minecraft:water[level=0]
fill 240 46 -144 243 46 -144 minecraft:air
fill 248 46 -144 263 46 -144 minecraft:water[level=0]
fill 218 46 -145 226 46 -145 minecraft:air
fill 230 46 -145 235 46 -145 minecraft:water[level=0]
fill 239 46 -145 243 46 -145 minecraft:air
fill 247 46 -145 263 46 -145 minecraft:water[level=0]
fill 219 46 -146 228 46 -146 minecraft:air
fill 232 46 -146 234 46 -146 minecraft:water[level=0]
fill 238 46 -146 242 46 -146 minecraft:air
fill 246 46 -146 263 46 -146 minecraft:water[level=0]
fill 219 46 -147 229 46 -147 minecraft:air
fill 238 46 -147 241 46 -147 minecraft:air
fill 245 46 -147 257 46 -147 minecraft:water[level=0]
setblock 260 46 -147 minecraft:water[level=0]
fill 220 46 -148 231 46 -148 minecraft:air
fill 237 46 -148 241 46 -148 minecraft:air
fill 244 46 -148 257 46 -148 minecraft:water[level=0]
fill 219 46 -149 240 46 -149 minecraft:air
fill 244 46 -149 258 46 -149 minecraft:water[level=0]
fill 219 46 -150 238 46 -150 minecraft:air
fill 243 46 -150 259 46 -150 minecraft:water[level=0]
fill 218 46 -151 236 46 -151 minecraft:air
fill 242 46 -151 260 46 -151 minecraft:water[level=0]
fill 218 46 -152 236 46 -152 minecraft:air
fill 239 46 -152 261 46 -152 minecraft:water[level=0]
fill 218 46 -153 235 46 -153 minecraft:air
fill 238 46 -153 262 46 -153 minecraft:water[level=0]
fill 217 46 -154 235 46 -154 minecraft:air
fill 238 46 -154 262 46 -154 minecraft:water[level=0]
fill 216 46 -155 234 46 -155 minecraft:air
fill 237 46 -155 263 46 -155 minecraft:water[level=0]
fill 215 46 -156 234 46 -156 minecraft:air
fill 237 46 -156 263 46 -156 minecraft:water[level=0]
fill 213 46 -157 235 46 -157 minecraft:air
fill 237 46 -157 263 46 -157 minecraft:water[level=0]
fill 212 46 -158 234 46 -158 minecraft:air
fill 237 46 -158 263 46 -158 minecraft:water[level=0]
fill 211 46 -159 234 46 -159 minecraft:air
fill 237 46 -159 263 46 -159 minecraft:water[level=0]
fill 210 46 -160 235 46 -160 minecraft:air
fill 239 46 -160 263 46 -160 minecraft:water[level=0]
fill 209 46 -161 235 46 -161 minecraft:air
fill 242 46 -161 263 46 -161 minecraft:water[level=0]
fill 208 46 -162 239 46 -162 minecraft:air
fill 247 46 -162 261 46 -162 minecraft:water[level=0]
fill 208 46 -163 240 46 -163 minecraft:air
fill 254 46 -163 260 46 -163 minecraft:water[level=0]
fill 207 46 -164 244 46 -164 minecraft:air
setblock 247 46 -164 minecraft:air
setblock 254 46 -164 minecraft:water[level=0]
fill 256 46 -164 260 46 -164 minecraft:water[level=0]
fill 207 46 -165 252 46 -165 minecraft:air
setblock 258 46 -165 minecraft:water[level=0]
fill 206 46 -166 252 46 -166 minecraft:air
setblock 257 46 -166 minecraft:water[level=0]
fill 206 46 -167 252 46 -167 minecraft:air
setblock 205 46 -168 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 206 46 -168 252 46 -168 minecraft:air
fill 205 46 -169 252 46 -169 minecraft:air
fill 204 46 -170 251 46 -170 minecraft:air
fill 203 46 -171 251 46 -171 minecraft:air
fill 201 46 -172 250 46 -172 minecraft:air
fill 201 46 -173 249 46 -173 minecraft:air
fill 200 46 -174 249 46 -174 minecraft:air
fill 200 46 -175 248 46 -175 minecraft:air
fill 200 46 -176 247 46 -176 minecraft:air
fill 200 46 -177 247 46 -177 minecraft:air
fill 200 46 -178 247 46 -178 minecraft:air
fill 200 46 -179 247 46 -179 minecraft:air
fill 200 46 -180 246 46 -180 minecraft:air
fill 200 46 -181 246 46 -181 minecraft:air
fill 200 46 -182 246 46 -182 minecraft:air
fill 201 46 -183 246 46 -183 minecraft:air
fill 201 46 -184 245 46 -184 minecraft:air
fill 201 46 -185 243 46 -185 minecraft:air
fill 200 46 -186 242 46 -186 minecraft:air
fill 200 46 -187 236 46 -187 minecraft:air
setblock 237 46 -187 minecraft:lava[level=8]
fill 238 46 -187 240 46 -187 minecraft:air
fill 200 46 -188 236 46 -188 minecraft:air
fill 200 46 -189 233 46 -189 minecraft:air
fill 200 46 -190 225 46 -190 minecraft:air
fill 200 45 -127 234 45 -127 minecraft:air
fill 237 45 -127 254 45 -127 minecraft:water[level=0]
setblock 255 45 -127 minecraft:bubble_column[drag=true]
setblock 256 45 -127 minecraft:water[level=0]
setblock 257 45 -127 minecraft:bubble_column[drag=true]
fill 258 45 -127 263 45 -127 minecraft:water[level=0]
fill 200 45 -128 234 45 -128 minecraft:air
fill 237 45 -128 254 45 -128 minecraft:water[level=0]
setblock 255 45 -128 minecraft:bubble_column[drag=true]
fill 256 45 -128 263 45 -128 minecraft:water[level=0]
fill 201 45 -129 234 45 -129 minecraft:air
fill 237 45 -129 263 45 -129 minecraft:water[level=0]
fill 203 45 -130 231 45 -130 minecraft:air
fill 237 45 -130 263 45 -130 minecraft:water[level=0]
fill 204 45 -131 230 45 -131 minecraft:air
fill 237 45 -131 254 45 -131 minecraft:water[level=0]
fill 257 45 -131 263 45 -131 minecraft:water[level=0]
fill 206 45 -132 229 45 -132 minecraft:air
fill 233 45 -132 253 45 -132 minecraft:water[level=0]
fill 258 45 -132 263 45 -132 minecraft:water[level=0]
fill 207 45 -133 229 45 -133 minecraft:air
fill 233 45 -133 263 45 -133 minecraft:water[level=0]
fill 209 45 -134 229 45 -134 minecraft:air
fill 233 45 -134 263 45 -134 minecraft:water[level=0]
fill 210 45 -135 229 45 -135 minecraft:air
fill 233 45 -135 263 45 -135 minecraft:water[level=0]
fill 211 45 -136 229 45 -136 minecraft:air
fill 233 45 -136 239 45 -136 minecraft:water[level=0]
fill 245 45 -136 263 45 -136 minecraft:water[level=0]
fill 212 45 -137 228 45 -137 minecraft:air
fill 232 45 -137 238 45 -137 minecraft:water[level=0]
fill 248 45 -137 263 45 -137 minecraft:water[level=0]
fill 213 45 -138 228 45 -138 minecraft:air
fill 232 45 -138 238 45 -138 minecraft:water[level=0]
fill 242 45 -138 245 45 -138 minecraft:air
fill 249 45 -138 263 45 -138 minecraft:water[level=0]
fill 214 45 -139 228 45 -139 minecraft:air
fill 232 45 -139 237 45 -139 minecraft:water[level=0]
fill 241 45 -139 247 45 -139 minecraft:air
fill 249 45 -139 263 45 -139 minecraft:water[level=0]
fill 212 45 -140 213 45 -140 minecraft:air
fill 215 45 -140 228 45 -140 minecraft:air
fill 232 45 -140 236 45 -140 minecraft:water[level=0]
fill 241 45 -140 247 45 -140 minecraft:air
fill 250 45 -140 263 45 -140 minecraft:water[level=0]
fill 211 45 -141 228 45 -141 minecraft:air
fill 232 45 -141 236 45 -141 minecraft:water[level=0]
fill 240 45 -141 248 45 -141 minecraft:air
fill 250 45 -141 263 45 -141 minecraft:water[level=0]
fill 210 45 -142 228 45 -142 minecraft:air
fill 232 45 -142 235 45 -142 minecraft:water[level=0]
fill 239 45 -142 247 45 -142 minecraft:air
fill 250 45 -142 263 45 -142 minecraft:water[level=0]
fill 210 45 -143 214 45 -143 minecraft:air
fill 217 45 -143 228 45 -143 minecraft:air
fill 232 45 -143 233 45 -143 minecraft:water[level=0]
setblock 234 45 -143 minecraft:bubble_column[drag=true]
fill 239 45 -143 246 45 -143 minecraft:air
fill 250 45 -143 263 45 -143 minecraft:water[level=0]
fill 211 45 -144 212 45 -144 minecraft:air
fill 217 45 -144 228 45 -144 minecraft:air
fill 232 45 -144 233 45 -144 minecraft:water[level=0]
fill 238 45 -144 245 45 -144 minecraft:air
fill 249 45 -144 263 45 -144 minecraft:water[level=0]
fill 218 45 -145 227 45 -145 minecraft:air
fill 232 45 -145 233 45 -145 minecraft:water[level=0]
fill 237 45 -145 245 45 -145 minecraft:air
fill 248 45 -145 263 45 -145 minecraft:water[level=0]
fill 218 45 -146 228 45 -146 minecraft:air
setblock 229 45 -146 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
fill 236 45 -146 244 45 -146 minecraft:air
fill 248 45 -146 262 45 -146 minecraft:water[level=0]
fill 219 45 -147 229 45 -147 minecraft:air
setblock 230 45 -147 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=false,west=false]
setblock 231 45 -147 minecraft:air
fill 236 45 -147 243 45 -147 minecraft:air
fill 247 45 -147 258 45 -147 minecraft:water[level=0]
fill 219 45 -148 231 45 -148 minecraft:air
setblock 233 45 -148 minecraft:air
fill 235 45 -148 242 45 -148 minecraft:air
fill 246 45 -148 256 45 -148 minecraft:water[level=0]
setblock 263 45 -148 minecraft:air
fill 219 45 -149 241 45 -149 minecraft:air
fill 246 45 -149 255 45 -149 minecraft:water[level=0]
fill 262 45 -149 263 45 -149 minecraft:air
fill 219 45 -150 239 45 -150 minecraft:air
fill 244 45 -150 257 45 -150 minecraft:water[level=0]
setblock 263 45 -150 minecraft:air
fill 219 45 -151 237 45 -151 minecraft:air
setblock 242 45 -151 minecraft:water[level=0]
fill 244 45 -151 258 45 -151 minecraft:water[level=0]
setblock 263 45 -151 minecraft:air
fill 218 45 -152 236 45 -152 minecraft:air
fill 240 45 -152 258 45 -152 minecraft:water[level=0]
fill 218 45 -153 235 45 -153 minecraft:air
fill 237 45 -153 259 45 -153 minecraft:water[level=0]
fill 217 45 -154 235 45 -154 minecraft:air
fill 237 45 -154 260 45 -154 minecraft:water[level=0]
fill 216 45 -155 234 45 -155 minecraft:air
fill 237 45 -155 261 45 -155 minecraft:water[level=0]
fill 215 45 -156 234 45 -156 minecraft:air
fill 237 45 -156 262 45 -156 minecraft:water[level=0]
fill 213 45 -157 234 45 -157 minecraft:air
fill 236 45 -157 262 45 -157 minecraft:water[level=0]
fill 212 45 -158 234 45 -158 minecraft:air
fill 236 45 -158 263 45 -158 minecraft:water[level=0]
fill 211 45 -159 234 45 -159 minecraft:air
fill 237 45 -159 263 45 -159 minecraft:water[level=0]
fill 210 45 -160 235 45 -160 minecraft:air
fill 238 45 -160 263 45 -160 minecraft:water[level=0]
fill 209 45 -161 235 45 -161 minecraft:air
fill 241 45 -161 261 45 -161 minecraft:water[level=0]
fill 208 45 -162 236 45 -162 minecraft:air
fill 245 45 -162 251 45 -162 minecraft:water[level=0]
fill 253 45 -162 261 45 -162 minecraft:water[level=0]
fill 208 45 -163 239 45 -163 minecraft:air
fill 254 45 -163 256 45 -163 minecraft:water[level=0]
fill 259 45 -163 261 45 -163 minecraft:water[level=0]
fill 207 45 -164 243 45 -164 minecraft:air
fill 260 45 -164 261 45 -164 minecraft:water[level=0]
fill 206 45 -165 252 45 -165 minecraft:air
fill 206 45 -166 253 45 -166 minecraft:air
fill 205 45 -167 253 45 -167 minecraft:air
setblock 205 45 -168 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 206 45 -168 252 45 -168 minecraft:air
fill 204 45 -169 251 45 -169 minecraft:air
fill 203 45 -170 251 45 -170 minecraft:air
fill 202 45 -171 250 45 -171 minecraft:air
fill 201 45 -172 249 45 -172 minecraft:air
fill 201 45 -173 249 45 -173 minecraft:air
fill 200 45 -174 248 45 -174 minecraft:air
fill 200 45 -175 247 45 -175 minecraft:air
fill 200 45 -176 247 45 -176 minecraft:air
fill 200 45 -177 247 45 -177 minecraft:air
fill 200 45 -178 246 45 -178 minecraft:air
fill 200 45 -179 246 45 -179 minecraft:air
fill 200 45 -180 246 45 -180 minecraft:air
fill 200 45 -181 246 45 -181 minecraft:air
fill 200 45 -182 245 45 -182 minecraft:air
fill 201 45 -183 245 45 -183 minecraft:air
fill 201 45 -184 244 45 -184 minecraft:air
fill 201 45 -185 242 45 -185 minecraft:air
fill 200 45 -186 236 45 -186 minecraft:air
setblock 237 45 -186 minecraft:lava[level=2]
fill 238 45 -186 241 45 -186 minecraft:air
fill 200 45 -187 235 45 -187 minecraft:air
setblock 236 45 -187 minecraft:lava[level=2]
setblock 237 45 -187 minecraft:lava[level=8]
setblock 238 45 -187 minecraft:air
fill 200 45 -188 234 45 -188 minecraft:air
fill 200 45 -189 231 45 -189 minecraft:air
fill 200 45 -190 226 45 -190 minecraft:air
setblock 228 45 -190 minecraft:air
forceload remove 200 -190 263 -127
tellraw @a {"text":"Campus zurueck a32 fertig.","color":"green"}
