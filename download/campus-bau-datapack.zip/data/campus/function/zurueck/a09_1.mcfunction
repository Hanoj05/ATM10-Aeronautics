setblock 135 79 -325 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 134 78 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 135 78 -320 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 134 78 -321 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 135 78 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 77 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 77 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 77 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 77 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 77 -321 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 135 77 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 135 77 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 77 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 76 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 76 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 76 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 76 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 76 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 76 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 76 -321 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 76 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 76 -321 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 135 76 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 76 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 76 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 76 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 75 -319 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 126 75 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 75 -319 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 133 75 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 75 -319 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 75 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 85 75 -320 86 75 -320 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 132 75 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 75 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 134 75 -320 minecraft:birch_log[axis=y]
setblock 135 75 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 75 -321 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 133 75 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 75 -321 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 75 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 75 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 74 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 74 -319 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 120 74 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 74 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 74 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 74 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 84 74 -320 86 74 -320 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 74 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 74 -320 minecraft:birch_log[axis=y]
setblock 85 74 -321 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 74 -322 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 127 74 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 74 -323 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 127 74 -324 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 72 73 -319 73 73 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 84 73 -319 86 73 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 73 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 73 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 73 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 73 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 73 -319 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 73 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 84 73 -320 86 73 -320 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 73 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 73 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 73 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 73 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 73 -320 minecraft:birch_log[axis=y]
fill 84 73 -321 86 73 -321 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 73 -322 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 73 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 73 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 73 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 73 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 72 72 -319 74 72 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 84 72 -319 86 72 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 72 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 72 -319 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 121 72 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 72 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 72 -319 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 72 -319 minecraft:birch_log[axis=y]
setblock 127 72 -319 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 72 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 72 -320 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 83 72 -320 84 72 -320 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 72 -320 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 86 72 -320 87 72 -320 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 72 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 72 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 72 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 72 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 72 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 72 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 72 -320 minecraft:birch_log[axis=y]
fill 84 72 -321 86 72 -321 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 72 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 72 -322 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 72 -322 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 72 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 72 -322 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 72 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 72 -323 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 72 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 72 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 72 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 72 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 72 71 -319 74 71 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 76 71 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 71 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 71 -319 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 71 -319 minecraft:birch_log[axis=y]
setblock 121 71 -319 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 122 71 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 71 -319 minecraft:birch_log[axis=y]
fill 72 71 -320 74 71 -320 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 71 -320 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 119 71 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 71 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 121 71 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 71 -320 minecraft:birch_log[axis=y]
setblock 120 71 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 71 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 71 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 71 -322 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 71 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 71 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 71 -323 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 71 -323 minecraft:birch_log[axis=y]
setblock 128 71 -323 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 129 71 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 71 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 71 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 71 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 71 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 71 -341 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 125 71 -342 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 126 71 -342 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 71 -342 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 126 71 -343 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 70 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 70 -319 regions_unexplored:silver_birch_log[axis=z,is_base=false]
fill 74 70 -319 75 70 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 70 -319 minecraft:birch_log[axis=y]
setblock 126 70 -319 minecraft:birch_log[axis=y]
fill 72 70 -320 74 70 -320 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 134 70 -320 minecraft:birch_log[axis=y]
setblock 73 70 -321 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 70 -321 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 127 70 -323 minecraft:birch_log[axis=y]
setblock 125 70 -340 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 126 70 -340 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 127 70 -340 herbsandharvest:plum_fruit_leaves[age=2,distance=4,persistent=false,waterlogged=false]
setblock 124 70 -341 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 125 70 -341 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 70 -341 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 70 -341 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 70 -341 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 124 70 -342 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 70 -342 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 70 -342 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 70 -342 herbsandharvest:plum_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 128 70 -342 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 124 70 -343 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 125 70 -343 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 70 -343 herbsandharvest:plum_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 127 70 -343 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 128 70 -343 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 125 70 -344 herbsandharvest:plum_fruit_leaves[age=2,distance=4,persistent=false,waterlogged=false]
setblock 126 70 -344 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 70 -344 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 120 69 -319 minecraft:birch_log[axis=y]
setblock 126 69 -319 minecraft:birch_log[axis=y]
setblock 134 69 -320 minecraft:birch_log[axis=y]
setblock 85 69 -321 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 127 69 -323 minecraft:birch_log[axis=y]
setblock 125 69 -340 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 69 -340 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 69 -340 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 69 -341 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 125 69 -341 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 69 -341 herbsandharvest:plum_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 127 69 -341 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 69 -341 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 124 69 -342 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 69 -342 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 69 -342 minecraft:oak_log[axis=y]
setblock 127 69 -342 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 69 -342 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 69 -343 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 69 -343 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 69 -343 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 69 -343 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 69 -343 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 125 69 -344 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 69 -344 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 69 -344 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 68 -319 minecraft:birch_log[axis=y]
setblock 126 68 -319 minecraft:birch_log[axis=y]
fill 134 68 -319 135 68 -319 minecraft:grass_block[snowy=false]
setblock 134 68 -320 minecraft:dirt
setblock 135 68 -320 minecraft:grass_block[snowy=false]
setblock 84 68 -321 regions_unexplored:silver_birch_log[axis=x,is_base=false]
setblock 85 68 -321 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 135 68 -321 minecraft:grass_block[snowy=false]
setblock 135 68 -322 minecraft:grass_block[snowy=false]
setblock 127 68 -323 minecraft:birch_log[axis=y]
setblock 134 68 -327 regions_unexplored:grass_sprouts
setblock 134 68 -328 regions_unexplored:grass_sprouts
setblock 133 68 -329 minecraft:short_grass
setblock 135 68 -330 minecraft:short_grass
setblock 125 68 -340 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 68 -340 herbsandharvest:plum_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 127 68 -340 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 68 -341 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 68 -341 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 68 -341 herbsandharvest:plum_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 127 68 -341 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 68 -341 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 68 -342 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 68 -342 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 68 -342 minecraft:oak_log[axis=y]
setblock 127 68 -342 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 68 -342 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 68 -343 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 68 -343 herbsandharvest:plum_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 126 68 -343 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 68 -343 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 68 -343 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 68 -344 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 68 -344 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 68 -344 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 67 -319 minecraft:birch_log[axis=y]
setblock 126 67 -319 minecraft:birch_log[axis=y]
fill 131 67 -319 133 67 -319 minecraft:grass_block[snowy=false]
fill 134 67 -319 135 67 -319 minecraft:dirt
fill 132 67 -320 133 67 -320 minecraft:grass_block[snowy=false]
fill 134 67 -320 135 67 -320 minecraft:dirt
setblock 85 67 -321 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 132 67 -321 134 67 -321 minecraft:grass_block[snowy=false]
setblock 135 67 -321 minecraft:dirt
fill 132 67 -322 134 67 -322 minecraft:grass_block[snowy=false]
setblock 135 67 -322 minecraft:dirt
setblock 127 67 -323 minecraft:birch_log[axis=y]
setblock 128 67 -323 minecraft:short_grass
fill 133 67 -323 135 67 -323 minecraft:grass_block[snowy=false]
fill 133 67 -324 135 67 -324 minecraft:grass_block[snowy=false]
fill 129 67 -325 131 67 -325 minecraft:short_grass
fill 133 67 -325 135 67 -325 minecraft:grass_block[snowy=false]
setblock 129 67 -326 regions_unexplored:grass_sprouts
fill 133 67 -326 135 67 -326 minecraft:grass_block[snowy=false]
setblock 130 67 -327 regions_unexplored:grass_sprouts
fill 132 67 -327 135 67 -327 minecraft:grass_block[snowy=false]
fill 132 67 -328 135 67 -328 minecraft:grass_block[snowy=false]
fill 132 67 -329 135 67 -329 minecraft:grass_block[snowy=false]
fill 132 67 -330 135 67 -330 minecraft:grass_block[snowy=false]
fill 132 67 -331 135 67 -331 minecraft:grass_block[snowy=false]
fill 132 67 -332 135 67 -332 minecraft:grass_block[snowy=false]
setblock 129 67 -333 minecraft:tall_grass[half=upper]
fill 133 67 -333 135 67 -333 minecraft:grass_block[snowy=false]
setblock 129 67 -334 minecraft:tall_grass[half=upper]
fill 134 67 -334 135 67 -334 minecraft:grass_block[snowy=false]
setblock 132 67 -335 regions_unexplored:grass_sprouts
setblock 135 67 -335 minecraft:grass_block[snowy=false]
setblock 135 67 -336 minecraft:grass_block[snowy=false]
setblock 135 67 -337 minecraft:short_grass
setblock 126 67 -341 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 67 -342 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 67 -342 minecraft:oak_log[axis=y]
setblock 127 67 -342 herbsandharvest:plum_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 126 67 -343 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 66 -319 minecraft:birch_log[axis=y]
setblock 126 66 -319 minecraft:birch_log[axis=y]
fill 128 66 -319 130 66 -319 minecraft:grass_block[snowy=false]
fill 131 66 -319 135 66 -319 minecraft:dirt
setblock 123 66 -320 regions_unexplored:grass_sprouts
fill 128 66 -320 131 66 -320 minecraft:grass_block[snowy=false]
fill 132 66 -320 135 66 -320 minecraft:dirt
setblock 85 66 -321 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 126 66 -321 regions_unexplored:grass_sprouts
fill 128 66 -321 131 66 -321 minecraft:grass_block[snowy=false]
fill 132 66 -321 135 66 -321 minecraft:dirt
setblock 124 66 -322 minecraft:short_grass
fill 128 66 -322 131 66 -322 minecraft:grass_block[snowy=false]
fill 132 66 -322 135 66 -322 minecraft:dirt
setblock 123 66 -323 regions_unexplored:grass_sprouts
setblock 125 66 -323 regions_unexplored:grass_sprouts
setblock 126 66 -323 minecraft:short_grass
setblock 127 66 -323 minecraft:birch_log[axis=y]
fill 128 66 -323 132 66 -323 minecraft:grass_block[snowy=false]
fill 133 66 -323 135 66 -323 minecraft:dirt
fill 128 66 -324 129 66 -324 regions_unexplored:peat_mud
fill 130 66 -324 132 66 -324 minecraft:grass_block[snowy=false]
fill 133 66 -324 135 66 -324 minecraft:dirt
setblock 123 66 -325 minecraft:tall_grass[half=upper]
setblock 126 66 -325 regions_unexplored:grass_sprouts
fill 128 66 -325 129 66 -325 regions_unexplored:peat_mud
fill 130 66 -325 132 66 -325 minecraft:grass_block[snowy=false]
fill 133 66 -325 135 66 -325 minecraft:dirt
setblock 125 66 -326 regions_unexplored:grass_sprouts
setblock 126 66 -326 minecraft:short_grass
setblock 129 66 -326 regions_unexplored:peat_mud
fill 130 66 -326 132 66 -326 minecraft:grass_block[snowy=false]
fill 133 66 -326 135 66 -326 minecraft:dirt
fill 127 66 -327 128 66 -327 minecraft:short_grass
fill 129 66 -327 131 66 -327 minecraft:grass_block[snowy=false]
fill 132 66 -327 135 66 -327 minecraft:dirt
fill 129 66 -328 131 66 -328 minecraft:grass_block[snowy=false]
fill 132 66 -328 135 66 -328 minecraft:dirt
fill 129 66 -329 131 66 -329 minecraft:grass_block[snowy=false]
fill 132 66 -329 135 66 -329 minecraft:dirt
fill 129 66 -330 131 66 -330 minecraft:grass_block[snowy=false]
fill 132 66 -330 135 66 -330 minecraft:dirt
fill 130 66 -331 131 66 -331 minecraft:grass_block[snowy=false]
fill 132 66 -331 135 66 -331 minecraft:dirt
fill 130 66 -332 131 66 -332 minecraft:grass_block[snowy=false]
fill 132 66 -332 135 66 -332 minecraft:dirt
setblock 129 66 -333 minecraft:tall_grass[half=lower]
fill 130 66 -333 131 66 -333 regions_unexplored:peat_mud
setblock 132 66 -333 minecraft:grass_block[snowy=false]
fill 133 66 -333 135 66 -333 minecraft:dirt
setblock 128 66 -334 regions_unexplored:grass_sprouts
setblock 129 66 -334 minecraft:tall_grass[half=lower]
fill 131 66 -334 132 66 -334 regions_unexplored:peat_mud
setblock 133 66 -334 minecraft:grass_block[snowy=false]
fill 134 66 -334 135 66 -334 minecraft:dirt
fill 131 66 -335 132 66 -335 regions_unexplored:peat_mud
fill 133 66 -335 134 66 -335 minecraft:grass_block[snowy=false]
setblock 135 66 -335 minecraft:dirt
fill 132 66 -336 135 66 -336 regions_unexplored:peat_mud
fill 133 66 -337 135 66 -337 regions_unexplored:peat_mud
fill 133 66 -338 135 66 -338 regions_unexplored:peat_mud
fill 134 66 -339 135 66 -339 regions_unexplored:peat_mud
setblock 135 66 -340 minecraft:grass_block[snowy=false]
setblock 133 66 -341 regions_unexplored:grass_sprouts
setblock 135 66 -341 regions_unexplored:grass_sprouts
setblock 126 66 -342 minecraft:oak_log[axis=y]
setblock 134 66 -344 minecraft:tall_grass[half=upper]
fill 72 65 -319 86 65 -319 minecraft:air
setblock 87 65 -319 regions_unexplored:tassel[half=upper]
fill 88 65 -319 119 65 -319 minecraft:air
setblock 120 65 -319 minecraft:birch_log[axis=y]
setblock 121 65 -319 minecraft:short_grass
setblock 122 65 -319 minecraft:air
setblock 123 65 -319 regions_unexplored:grass_sprouts
setblock 126 65 -319 minecraft:dirt
fill 128 65 -319 135 65 -319 minecraft:dirt
fill 72 65 -320 74 65 -320 minecraft:air
setblock 75 65 -320 minecraft:deepslate[axis=y]
fill 76 65 -320 117 65 -320 minecraft:air
setblock 118 65 -320 regions_unexplored:grass_sprouts
setblock 119 65 -320 minecraft:air
setblock 120 65 -320 regions_unexplored:grass_sprouts
setblock 121 65 -320 minecraft:air
fill 128 65 -320 135 65 -320 minecraft:dirt
fill 72 65 -321 84 65 -321 minecraft:air
setblock 85 65 -321 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 86 65 -321 121 65 -321 minecraft:air
fill 128 65 -321 135 65 -321 minecraft:dirt
fill 72 65 -322 115 65 -322 minecraft:air
setblock 116 65 -322 minecraft:tall_grass[half=upper]
fill 117 65 -322 121 65 -322 minecraft:air
fill 128 65 -322 135 65 -322 minecraft:dirt
fill 72 65 -323 122 65 -323 minecraft:air
fill 127 65 -323 135 65 -323 minecraft:dirt
fill 72 65 -324 121 65 -324 minecraft:air
setblock 122 65 -324 minecraft:short_grass
fill 123 65 -324 124 65 -324 regions_unexplored:peat_mud
fill 127 65 -324 129 65 -324 regions_unexplored:peat_mud
fill 130 65 -324 135 65 -324 minecraft:dirt
fill 72 65 -325 122 65 -325 minecraft:air
setblock 123 65 -325 minecraft:tall_grass[half=lower]
fill 124 65 -325 129 65 -325 regions_unexplored:peat_mud
fill 130 65 -325 135 65 -325 minecraft:dirt
fill 72 65 -326 118 65 -326 minecraft:air
setblock 119 65 -326 minecraft:tall_grass[half=upper]
fill 120 65 -326 123 65 -326 minecraft:air
setblock 124 65 -326 regions_unexplored:grass_sprouts
fill 125 65 -326 129 65 -326 regions_unexplored:peat_mud
fill 130 65 -326 135 65 -326 minecraft:dirt
fill 72 65 -327 122 65 -327 minecraft:air
setblock 123 65 -327 minecraft:short_grass
setblock 124 65 -327 minecraft:air
setblock 125 65 -327 minecraft:short_grass
fill 126 65 -327 128 65 -327 regions_unexplored:peat_mud
fill 129 65 -327 135 65 -327 minecraft:dirt
fill 72 65 -328 118 65 -328 minecraft:air
setblock 119 65 -328 minecraft:tall_grass[half=upper]
fill 120 65 -328 126 65 -328 minecraft:air
fill 127 65 -328 128 65 -328 regions_unexplored:peat_mud
fill 129 65 -328 135 65 -328 minecraft:dirt
fill 72 65 -329 123 65 -329 minecraft:air
setblock 124 65 -329 minecraft:tall_grass[half=upper]
fill 125 65 -329 126 65 -329 minecraft:air
setblock 127 65 -329 regions_unexplored:peat_mud
fill 129 65 -329 135 65 -329 minecraft:dirt
fill 72 65 -330 120 65 -330 minecraft:air
setblock 121 65 -330 minecraft:tall_grass[half=upper]
fill 122 65 -330 126 65 -330 minecraft:air
setblock 127 65 -330 regions_unexplored:peat_mud
fill 129 65 -330 135 65 -330 minecraft:dirt
fill 72 65 -331 122 65 -331 minecraft:air
setblock 123 65 -331 minecraft:tall_grass[half=upper]
setblock 124 65 -331 minecraft:air
setblock 125 65 -331 regions_unexplored:grass_sprouts
setblock 126 65 -331 minecraft:air
fill 127 65 -331 128 65 -331 regions_unexplored:peat_mud
fill 130 65 -331 135 65 -331 minecraft:dirt
fill 72 65 -332 121 65 -332 minecraft:air
setblock 122 65 -332 minecraft:tall_grass[half=upper]
fill 123 65 -332 125 65 -332 minecraft:air
setblock 126 65 -332 minecraft:short_grass
setblock 127 65 -332 minecraft:air
setblock 128 65 -332 regions_unexplored:peat_mud
fill 130 65 -332 135 65 -332 minecraft:dirt
fill 72 65 -333 125 65 -333 minecraft:air
setblock 126 65 -333 minecraft:short_grass
setblock 127 65 -333 minecraft:air
fill 128 65 -333 131 65 -333 regions_unexplored:peat_mud
fill 132 65 -333 135 65 -333 minecraft:dirt
fill 72 65 -334 123 65 -334 minecraft:air
setblock 124 65 -334 minecraft:tall_grass[half=upper]
fill 125 65 -334 127 65 -334 minecraft:air
fill 128 65 -334 131 65 -334 regions_unexplored:peat_mud
fill 132 65 -334 135 65 -334 minecraft:dirt
fill 72 65 -335 127 65 -335 minecraft:air
fill 128 65 -335 132 65 -335 regions_unexplored:peat_mud
fill 133 65 -335 135 65 -335 minecraft:dirt
fill 72 65 -336 128 65 -336 minecraft:air
fill 129 65 -336 133 65 -336 regions_unexplored:peat_mud
setblock 134 65 -336 minecraft:dirt
setblock 135 65 -336 regions_unexplored:peat_mud
fill 72 65 -337 119 65 -337 minecraft:air
setblock 120 65 -337 minecraft:tall_grass[half=upper]
fill 121 65 -337 128 65 -337 minecraft:air
setblock 129 65 -337 minecraft:short_grass
fill 130 65 -337 135 65 -337 regions_unexplored:peat_mud
fill 72 65 -338 129 65 -338 minecraft:air
fill 130 65 -338 135 65 -338 regions_unexplored:peat_mud
fill 72 65 -339 130 65 -339 minecraft:air
fill 131 65 -339 135 65 -339 regions_unexplored:peat_mud
fill 72 65 -340 130 65 -340 minecraft:air
fill 131 65 -340 134 65 -340 regions_unexplored:peat_mud
setblock 135 65 -340 minecraft:dirt
fill 72 65 -341 132 65 -341 minecraft:air
fill 133 65 -341 135 65 -341 regions_unexplored:peat_mud
fill 72 65 -342 125 65 -342 minecraft:air
setblock 126 65 -342 minecraft:oak_log[axis=y]
fill 127 65 -342 133 65 -342 minecraft:air
fill 134 65 -342 135 65 -342 regions_unexplored:peat_mud
fill 72 65 -343 134 65 -343 minecraft:air
setblock 135 65 -343 regions_unexplored:peat_mud
fill 72 65 -344 133 65 -344 minecraft:air
setblock 134 65 -344 minecraft:tall_grass[half=lower]
setblock 135 65 -344 regions_unexplored:peat_mud
fill 72 65 -345 135 65 -345 minecraft:air
fill 72 65 -346 135 65 -346 minecraft:air
fill 72 65 -347 135 65 -347 minecraft:air
fill 72 65 -348 135 65 -348 minecraft:air
fill 72 65 -349 135 65 -349 minecraft:air
fill 72 65 -350 135 65 -350 minecraft:air
fill 72 65 -351 135 65 -351 minecraft:air
fill 72 65 -352 135 65 -352 minecraft:air
fill 72 65 -353 135 65 -353 minecraft:air
fill 72 65 -354 135 65 -354 minecraft:air
fill 72 65 -355 135 65 -355 minecraft:air
fill 72 65 -356 135 65 -356 minecraft:air
fill 72 65 -357 135 65 -357 minecraft:air
fill 72 65 -358 135 65 -358 minecraft:air
fill 72 65 -359 135 65 -359 minecraft:air
fill 72 65 -360 135 65 -360 minecraft:air
fill 72 65 -361 135 65 -361 minecraft:air
fill 72 65 -362 135 65 -362 minecraft:air
fill 72 65 -363 135 65 -363 minecraft:air
fill 72 65 -364 135 65 -364 minecraft:air
fill 72 65 -365 135 65 -365 minecraft:air
fill 72 65 -366 135 65 -366 minecraft:air
fill 72 65 -367 135 65 -367 minecraft:air
fill 72 65 -368 135 65 -368 minecraft:air
fill 72 65 -369 135 65 -369 minecraft:air
fill 72 65 -370 135 65 -370 minecraft:air
fill 72 65 -371 135 65 -371 minecraft:air
fill 72 65 -372 135 65 -372 minecraft:air
fill 72 65 -373 135 65 -373 minecraft:air
fill 72 65 -374 135 65 -374 minecraft:air
fill 72 65 -375 135 65 -375 minecraft:air
fill 72 65 -376 135 65 -376 minecraft:air
fill 72 65 -377 135 65 -377 minecraft:air
fill 72 65 -378 135 65 -378 minecraft:air
fill 72 65 -379 135 65 -379 minecraft:air
fill 72 65 -380 135 65 -380 minecraft:air
fill 72 65 -381 135 65 -381 minecraft:air
fill 72 65 -382 135 65 -382 minecraft:air
fill 72 64 -319 74 64 -319 minecraft:air
setblock 76 64 -319 minecraft:air
setblock 77 64 -319 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
fill 78 64 -319 82 64 -319 minecraft:air
setblock 83 64 -319 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 84 64 -319 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
fill 85 64 -319 86 64 -319 minecraft:air
fill 88 64 -319 117 64 -319 minecraft:air
fill 72 64 -320 74 64 -320 minecraft:air
fill 76 64 -320 82 64 -320 minecraft:air
setblock 83 64 -320 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 84 64 -320 85 64 -320 minecraft:air
setblock 86 64 -320 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
fill 87 64 -320 117 64 -320 minecraft:air
setblock 119 64 -320 minecraft:air
fill 72 64 -321 74 64 -321 minecraft:air
fill 76 64 -321 82 64 -321 minecraft:air
setblock 83 64 -321 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 84 64 -321 minecraft:air
setblock 86 64 -321 minecraft:air
setblock 87 64 -321 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
fill 88 64 -321 120 64 -321 minecraft:air
fill 72 64 -322 74 64 -322 minecraft:air
fill 76 64 -322 85 64 -322 minecraft:air
setblock 86 64 -322 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 87 64 -322 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 88 64 -322 115 64 -322 minecraft:air
setblock 116 64 -322 minecraft:tall_grass[half=lower]
fill 117 64 -322 121 64 -322 minecraft:air
fill 72 64 -323 117 64 -323 minecraft:air
setblock 118 64 -323 minecraft:short_grass
fill 120 64 -323 121 64 -323 minecraft:air
fill 72 64 -324 115 64 -324 minecraft:air
fill 117 64 -324 121 64 -324 minecraft:air
fill 72 64 -325 116 64 -325 minecraft:air
setblock 118 64 -325 minecraft:air
setblock 119 64 -325 regions_unexplored:grass_sprouts
fill 120 64 -325 121 64 -325 minecraft:air
fill 72 64 -326 118 64 -326 minecraft:air
setblock 119 64 -326 minecraft:tall_grass[half=lower]
setblock 121 64 -326 minecraft:air
fill 72 64 -327 121 64 -327 minecraft:air
fill 72 64 -328 117 64 -328 minecraft:air
setblock 119 64 -328 minecraft:tall_grass[half=lower]
setblock 120 64 -328 minecraft:short_grass
fill 121 64 -328 123 64 -328 minecraft:air
fill 72 64 -329 118 64 -329 minecraft:air
fill 120 64 -329 121 64 -329 minecraft:air
setblock 122 64 -329 minecraft:short_grass
setblock 123 64 -329 minecraft:air
setblock 124 64 -329 minecraft:tall_grass[half=lower]
fill 72 64 -330 118 64 -330 minecraft:air
setblock 120 64 -330 minecraft:short_grass
setblock 121 64 -330 minecraft:tall_grass[half=lower]
fill 122 64 -330 123 64 -330 minecraft:air
setblock 124 64 -330 minecraft:short_grass
fill 72 64 -331 121 64 -331 minecraft:air
setblock 122 64 -331 regions_unexplored:grass_sprouts
setblock 123 64 -331 minecraft:tall_grass[half=lower]
setblock 124 64 -331 minecraft:air
fill 72 64 -332 121 64 -332 minecraft:air
setblock 122 64 -332 minecraft:tall_grass[half=lower]
fill 123 64 -332 124 64 -332 minecraft:air
setblock 125 64 -332 regions_unexplored:grass_sprouts
fill 72 64 -333 123 64 -333 minecraft:air
setblock 124 64 -333 regions_unexplored:grass_sprouts
setblock 125 64 -333 minecraft:air
fill 72 64 -334 123 64 -334 minecraft:air
setblock 124 64 -334 minecraft:tall_grass[half=lower]
setblock 125 64 -334 minecraft:air
fill 72 64 -335 123 64 -335 minecraft:air
setblock 124 64 -335 minecraft:short_grass
setblock 125 64 -335 minecraft:air
fill 72 64 -336 125 64 -336 minecraft:air
fill 72 64 -337 119 64 -337 minecraft:air
setblock 120 64 -337 minecraft:tall_grass[half=lower]
fill 121 64 -337 122 64 -337 minecraft:air
setblock 123 64 -337 regions_unexplored:grass_sprouts
setblock 124 64 -337 minecraft:air
setblock 125 64 -337 regions_unexplored:grass_sprouts
fill 72 64 -338 123 64 -338 minecraft:air
setblock 124 64 -338 minecraft:short_grass
fill 125 64 -338 126 64 -338 minecraft:air
fill 72 64 -339 119 64 -339 minecraft:air
setblock 120 64 -339 minecraft:tall_grass[half=upper]
setblock 121 64 -339 minecraft:air
setblock 122 64 -339 minecraft:short_grass
fill 123 64 -339 124 64 -339 minecraft:air
setblock 125 64 -339 minecraft:short_grass
fill 126 64 -339 127 64 -339 minecraft:air
fill 72 64 -340 116 64 -340 minecraft:air
setblock 117 64 -340 minecraft:tall_grass[half=upper]
fill 118 64 -340 127 64 -340 minecraft:air
fill 72 64 -341 115 64 -341 minecraft:air
setblock 116 64 -341 minecraft:tall_grass[half=upper]
fill 117 64 -341 125 64 -341 minecraft:air
setblock 126 64 -341 minecraft:short_grass
fill 127 64 -341 129 64 -341 minecraft:air
fill 72 64 -342 124 64 -342 minecraft:air
fill 127 64 -342 130 64 -342 minecraft:air
fill 72 64 -343 116 64 -343 minecraft:air
setblock 117 64 -343 minecraft:tall_grass[half=upper]
fill 118 64 -343 127 64 -343 minecraft:air
fill 129 64 -343 131 64 -343 minecraft:air
fill 72 64 -344 115 64 -344 minecraft:air
fill 117 64 -344 125 64 -344 minecraft:air
fill 127 64 -344 132 64 -344 minecraft:air
fill 72 64 -345 126 64 -345 minecraft:air
fill 130 64 -345 133 64 -345 minecraft:air
fill 72 64 -346 128 64 -346 minecraft:air
fill 130 64 -346 134 64 -346 minecraft:air
fill 72 64 -347 127 64 -347 minecraft:air
setblock 129 64 -347 minecraft:air
setblock 131 64 -347 minecraft:air
fill 133 64 -347 135 64 -347 minecraft:air
fill 72 64 -348 128 64 -348 minecraft:air
fill 130 64 -348 131 64 -348 minecraft:air
fill 133 64 -348 135 64 -348 minecraft:air
fill 72 64 -349 126 64 -349 minecraft:air
setblock 129 64 -349 minecraft:air
fill 132 64 -349 135 64 -349 minecraft:air
fill 72 64 -350 125 64 -350 minecraft:air
fill 128 64 -350 130 64 -350 minecraft:air
fill 132 64 -350 135 64 -350 minecraft:air
fill 72 64 -351 124 64 -351 minecraft:air
fill 128 64 -351 135 64 -351 minecraft:air
fill 72 64 -352 124 64 -352 minecraft:air
fill 126 64 -352 127 64 -352 minecraft:air
setblock 128 64 -352 regions_unexplored:grass_sprouts
fill 129 64 -352 130 64 -352 minecraft:short_grass
setblock 131 64 -352 minecraft:air
setblock 132 64 -352 regions_unexplored:grass_sprouts
setblock 133 64 -352 minecraft:air
setblock 134 64 -352 regions_unexplored:grass_sprouts
setblock 135 64 -352 minecraft:air
fill 72 64 -353 124 64 -353 minecraft:air
fill 126 64 -353 131 64 -353 minecraft:air
setblock 132 64 -353 minecraft:short_grass
fill 133 64 -353 134 64 -353 minecraft:air
setblock 135 64 -353 regions_unexplored:grass_sprouts
fill 72 64 -354 127 64 -354 minecraft:air
setblock 128 64 -354 regions_unexplored:grass_sprouts
fill 129 64 -354 130 64 -354 minecraft:air
fill 131 64 -354 132 64 -354 minecraft:short_grass
fill 133 64 -354 134 64 -354 minecraft:air
setblock 135 64 -354 regions_unexplored:grass_sprouts
fill 72 64 -355 124 64 -355 minecraft:air
setblock 126 64 -355 minecraft:air
fill 128 64 -355 129 64 -355 minecraft:air
setblock 130 64 -355 minecraft:short_grass
setblock 131 64 -355 minecraft:air
setblock 132 64 -355 minecraft:short_grass
setblock 133 64 -355 minecraft:air
setblock 134 64 -355 regions_unexplored:grass_sprouts
setblock 135 64 -355 minecraft:air
fill 72 64 -356 124 64 -356 minecraft:air
fill 126 64 -356 128 64 -356 minecraft:air
setblock 129 64 -356 regions_unexplored:grass_sprouts
setblock 130 64 -356 minecraft:air
setblock 131 64 -356 regions_unexplored:grass_sprouts
setblock 132 64 -356 minecraft:air
setblock 133 64 -356 minecraft:short_grass
fill 134 64 -356 135 64 -356 minecraft:air
fill 72 64 -357 125 64 -357 minecraft:air
fill 127 64 -357 132 64 -357 minecraft:air
fill 133 64 -357 134 64 -357 minecraft:short_grass
setblock 135 64 -357 minecraft:air
fill 72 64 -358 135 64 -358 minecraft:air
fill 72 64 -359 135 64 -359 minecraft:air
fill 72 64 -360 135 64 -360 minecraft:air
fill 72 64 -361 135 64 -361 minecraft:air
fill 72 64 -362 135 64 -362 minecraft:air
fill 72 64 -363 135 64 -363 minecraft:air
fill 72 64 -364 135 64 -364 minecraft:air
fill 72 64 -365 135 64 -365 minecraft:air
fill 72 64 -366 135 64 -366 minecraft:air
fill 72 64 -367 135 64 -367 minecraft:air
fill 72 64 -368 135 64 -368 minecraft:air
fill 72 64 -369 135 64 -369 minecraft:air
fill 72 64 -370 135 64 -370 minecraft:air
fill 72 64 -371 135 64 -371 minecraft:air
fill 72 64 -372 135 64 -372 minecraft:air
fill 72 64 -373 135 64 -373 minecraft:air
fill 72 64 -374 135 64 -374 minecraft:air
fill 72 64 -375 135 64 -375 minecraft:air
fill 72 64 -376 135 64 -376 minecraft:air
fill 72 64 -377 135 64 -377 minecraft:air
fill 72 64 -378 135 64 -378 minecraft:air
fill 72 64 -379 135 64 -379 minecraft:air
fill 72 64 -380 135 64 -380 minecraft:air
fill 72 64 -381 135 64 -381 minecraft:air
fill 72 64 -382 135 64 -382 minecraft:air
fill 88 63 -319 114 63 -319 minecraft:air
fill 119 63 -319 121 63 -319 minecraft:air
setblock 87 63 -320 minecraft:air
setblock 88 63 -320 regions_unexplored:grass_sprouts
fill 89 63 -320 114 63 -320 minecraft:air
fill 119 63 -320 121 63 -320 minecraft:air
setblock 88 63 -321 regions_unexplored:grass_sprouts
setblock 89 63 -321 minecraft:short_grass
fill 90 63 -321 91 63 -321 minecraft:air
setblock 92 63 -321 minecraft:short_grass
fill 93 63 -321 115 63 -321 minecraft:air
fill 119 63 -321 121 63 -321 minecraft:air
fill 72 63 -322 73 63 -322 minecraft:air
setblock 88 63 -322 regions_unexplored:grass_sprouts
fill 89 63 -322 115 63 -322 minecraft:air
fill 119 63 -322 121 63 -322 minecraft:air
fill 88 63 -323 90 63 -323 minecraft:air
setblock 91 63 -323 regions_unexplored:grass_sprouts
fill 92 63 -323 116 63 -323 minecraft:air
fill 120 63 -323 121 63 -323 minecraft:air
fill 88 63 -324 115 63 -324 minecraft:air
setblock 119 63 -324 minecraft:short_grass
fill 120 63 -324 121 63 -324 minecraft:air
fill 86 63 -325 116 63 -325 minecraft:air
fill 120 63 -325 121 63 -325 minecraft:air
setblock 72 63 -326 minecraft:air
fill 84 63 -326 117 63 -326 minecraft:air
fill 72 63 -327 74 63 -327 minecraft:air
fill 83 63 -327 118 63 -327 minecraft:air
fill 72 63 -328 74 63 -328 minecraft:air
fill 82 63 -328 116 63 -328 minecraft:air
fill 72 63 -329 75 63 -329 minecraft:air
fill 81 63 -329 118 63 -329 minecraft:air
fill 72 63 -330 75 63 -330 minecraft:air
fill 81 63 -330 117 63 -330 minecraft:air
fill 72 63 -331 74 63 -331 minecraft:air
fill 80 63 -331 120 63 -331 minecraft:air
setblock 72 63 -332 minecraft:air
fill 80 63 -332 118 63 -332 minecraft:air
fill 120 63 -332 121 63 -332 minecraft:air
fill 72 63 -333 75 63 -333 minecraft:air
fill 80 63 -333 120 63 -333 minecraft:air
fill 72 63 -334 74 63 -334 minecraft:air
setblock 76 63 -334 minecraft:air
fill 79 63 -334 120 63 -334 minecraft:air
fill 72 63 -335 74 63 -335 minecraft:air
fill 76 63 -335 77 63 -335 minecraft:air
fill 79 63 -335 119 63 -335 minecraft:air
fill 72 63 -336 75 63 -336 minecraft:air
fill 77 63 -336 119 63 -336 minecraft:air
fill 74 63 -337 119 63 -337 minecraft:air
fill 75 63 -338 120 63 -338 minecraft:air
fill 74 63 -339 117 63 -339 minecraft:air
setblock 118 63 -339 minecraft:short_grass
setblock 119 63 -339 regions_unexplored:grass_sprouts
setblock 120 63 -339 minecraft:tall_grass[half=lower]
setblock 121 63 -339 regions_unexplored:grass_sprouts
fill 72 63 -340 87 63 -340 minecraft:air
fill 89 63 -340 115 63 -340 minecraft:air
setblock 116 63 -340 regions_unexplored:grass_sprouts
setblock 117 63 -340 minecraft:tall_grass[half=lower]
fill 118 63 -340 120 63 -340 minecraft:air
setblock 121 63 -340 minecraft:short_grass
setblock 122 63 -340 regions_unexplored:grass_sprouts
fill 123 63 -340 124 63 -340 minecraft:air
fill 72 63 -341 115 63 -341 minecraft:air
setblock 116 63 -341 minecraft:tall_grass[half=lower]
fill 117 63 -341 118 63 -341 minecraft:air
setblock 119 63 -341 regions_unexplored:grass_sprouts
fill 120 63 -341 122 63 -341 minecraft:air
setblock 123 63 -341 minecraft:short_grass
fill 124 63 -341 125 63 -341 minecraft:air
fill 72 63 -342 116 63 -342 minecraft:air
setblock 117 63 -342 regions_unexplored:grass_sprouts
fill 118 63 -342 122 63 -342 minecraft:air
setblock 123 63 -342 regions_unexplored:grass_sprouts
setblock 124 63 -342 minecraft:air
fill 72 63 -343 116 63 -343 minecraft:air
setblock 117 63 -343 minecraft:tall_grass[half=lower]
fill 118 63 -343 120 63 -343 minecraft:air
setblock 121 63 -343 minecraft:short_grass
setblock 122 63 -343 minecraft:air
setblock 123 63 -343 regions_unexplored:grass_sprouts
fill 124 63 -343 125 63 -343 minecraft:air
setblock 126 63 -343 regions_unexplored:grass_sprouts
setblock 127 63 -343 minecraft:air
fill 72 63 -344 75 63 -344 minecraft:air
fill 77 63 -344 115 63 -344 minecraft:air
fill 117 63 -344 118 63 -344 regions_unexplored:grass_sprouts
fill 119 63 -344 125 63 -344 minecraft:air
fill 127 63 -344 129 63 -344 minecraft:air
fill 72 63 -345 120 63 -345 minecraft:air
setblock 121 63 -345 minecraft:short_grass
fill 122 63 -345 126 63 -345 minecraft:air
fill 73 63 -346 128 63 -346 minecraft:air
setblock 130 63 -346 minecraft:air
fill 72 63 -347 126 63 -347 minecraft:air
setblock 129 63 -347 minecraft:air
setblock 131 63 -347 minecraft:air
fill 72 63 -348 123 63 -348 minecraft:air
fill 126 63 -348 128 63 -348 minecraft:air
setblock 130 63 -348 minecraft:short_grass
setblock 131 63 -348 minecraft:air
setblock 133 63 -348 minecraft:air
fill 72 63 -349 122 63 -349 minecraft:air
fill 124 63 -349 125 63 -349 minecraft:air
setblock 129 63 -349 minecraft:air
setblock 132 63 -349 minecraft:air
fill 72 63 -350 125 63 -350 minecraft:air
setblock 128 63 -350 regions_unexplored:grass_sprouts
fill 129 63 -350 130 63 -350 minecraft:air
setblock 132 63 -350 minecraft:air
fill 72 63 -351 121 63 -351 minecraft:air
fill 123 63 -351 124 63 -351 minecraft:air
setblock 128 63 -351 minecraft:air
fill 129 63 -351 130 63 -351 regions_unexplored:grass_sprouts
fill 72 63 -352 124 63 -352 minecraft:air
fill 126 63 -352 127 63 -352 minecraft:air
fill 72 63 -353 120 63 -353 minecraft:air
setblock 122 63 -353 minecraft:air
setblock 126 63 -353 minecraft:air
setblock 127 63 -353 regions_unexplored:grass_sprouts
fill 72 63 -354 126 63 -354 minecraft:air
setblock 127 63 -354 regions_unexplored:grass_sprouts
fill 72 63 -355 122 63 -355 minecraft:air
setblock 124 63 -355 minecraft:air
setblock 126 63 -355 minecraft:air
fill 72 63 -356 123 63 -356 minecraft:air
setblock 126 63 -356 minecraft:air
setblock 127 63 -356 minecraft:short_grass
fill 72 63 -357 123 63 -357 minecraft:air
setblock 125 63 -357 minecraft:air
fill 127 63 -357 129 63 -357 minecraft:air
setblock 135 63 -357 minecraft:air
fill 72 63 -358 124 63 -358 minecraft:air
fill 127 63 -358 133 63 -358 minecraft:air
setblock 134 63 -358 minecraft:short_grass
setblock 135 63 -358 minecraft:air
fill 72 63 -359 123 63 -359 minecraft:air
setblock 125 63 -359 minecraft:air
fill 127 63 -359 135 63 -359 minecraft:air
fill 72 63 -360 125 63 -360 minecraft:air
fill 128 63 -360 135 63 -360 minecraft:air
fill 72 63 -361 126 63 -361 minecraft:air
fill 129 63 -361 135 63 -361 minecraft:air
fill 72 63 -362 128 63 -362 minecraft:air
fill 130 63 -362 135 63 -362 minecraft:air
fill 72 63 -363 135 63 -363 minecraft:air
fill 72 63 -364 135 63 -364 minecraft:air
fill 72 63 -365 135 63 -365 minecraft:air
fill 72 63 -366 135 63 -366 minecraft:air
fill 72 63 -367 135 63 -367 minecraft:air
fill 72 63 -368 135 63 -368 minecraft:air
fill 72 63 -369 135 63 -369 minecraft:air
fill 72 63 -370 135 63 -370 minecraft:air
fill 72 63 -371 135 63 -371 minecraft:air
fill 72 63 -372 135 63 -372 minecraft:air
fill 72 63 -373 135 63 -373 minecraft:air
fill 72 63 -374 135 63 -374 minecraft:air
fill 72 63 -375 135 63 -375 minecraft:air
fill 72 63 -376 135 63 -376 minecraft:air
fill 72 63 -377 135 63 -377 minecraft:air
fill 72 63 -378 135 63 -378 minecraft:air
fill 72 63 -379 135 63 -379 minecraft:air
fill 72 63 -380 135 63 -380 minecraft:air
fill 72 63 -381 135 63 -381 minecraft:air
fill 72 63 -382 135 63 -382 minecraft:air
fill 93 62 -319 110 62 -319 minecraft:water[level=0]
setblock 111 62 -319 minecraft:tall_seagrass[half=upper]
setblock 112 62 -319 minecraft:water[level=0]
fill 119 62 -319 121 62 -319 minecraft:water[level=0]
fill 93 62 -320 113 62 -320 minecraft:water[level=0]
fill 119 62 -320 121 62 -320 minecraft:water[level=0]
fill 93 62 -321 114 62 -321 minecraft:water[level=0]
fill 119 62 -321 121 62 -321 minecraft:water[level=0]
fill 93 62 -322 114 62 -322 minecraft:water[level=0]
fill 119 62 -322 121 62 -322 minecraft:water[level=0]
fill 92 62 -323 115 62 -323 minecraft:water[level=0]
fill 120 62 -323 121 62 -323 minecraft:water[level=0]
fill 92 62 -324 115 62 -324 minecraft:water[level=0]
fill 120 62 -324 121 62 -324 minecraft:water[level=0]
fill 93 62 -325 115 62 -325 minecraft:water[level=0]
setblock 72 62 -326 minecraft:water[level=0]
fill 93 62 -326 116 62 -326 minecraft:water[level=0]
fill 72 62 -327 73 62 -327 minecraft:water[level=0]
fill 93 62 -327 117 62 -327 minecraft:water[level=0]
fill 72 62 -328 74 62 -328 minecraft:water[level=0]
fill 93 62 -328 116 62 -328 minecraft:water[level=0]
fill 72 62 -329 74 62 -329 minecraft:water[level=0]
fill 93 62 -329 118 62 -329 minecraft:water[level=0]
fill 72 62 -330 74 62 -330 minecraft:water[level=0]
fill 84 62 -330 88 62 -330 minecraft:water[level=0]
fill 93 62 -330 117 62 -330 minecraft:water[level=0]
fill 84 62 -331 91 62 -331 minecraft:water[level=0]
fill 93 62 -331 118 62 -331 minecraft:water[level=0]
setblock 72 62 -332 minecraft:water[level=0]
fill 83 62 -332 91 62 -332 minecraft:water[level=0]
fill 93 62 -332 118 62 -332 minecraft:water[level=0]
fill 72 62 -333 74 62 -333 minecraft:water[level=0]
fill 83 62 -333 119 62 -333 minecraft:water[level=0]
fill 72 62 -334 74 62 -334 minecraft:water[level=0]
setblock 76 62 -334 minecraft:water[level=0]
fill 83 62 -334 119 62 -334 minecraft:water[level=0]
fill 72 62 -335 74 62 -335 minecraft:water[level=0]
setblock 76 62 -335 minecraft:water[level=0]
fill 84 62 -335 118 62 -335 minecraft:water[level=0]
fill 72 62 -336 75 62 -336 minecraft:water[level=0]
setblock 77 62 -336 minecraft:water[level=0]
fill 84 62 -336 118 62 -336 minecraft:water[level=0]
fill 75 62 -337 77 62 -337 minecraft:water[level=0]
fill 84 62 -337 117 62 -337 minecraft:water[level=0]
setblock 118 62 -337 minecraft:seagrass
setblock 76 62 -338 minecraft:water[level=0]
fill 84 62 -338 116 62 -338 minecraft:water[level=0]
setblock 117 62 -338 minecraft:seagrass
fill 83 62 -339 85 62 -339 minecraft:water[level=0]
fill 89 62 -339 114 62 -339 minecraft:water[level=0]
setblock 115 62 -339 minecraft:tall_seagrass[half=upper]
fill 116 62 -339 117 62 -339 minecraft:water[level=0]
fill 83 62 -340 85 62 -340 minecraft:water[level=0]
fill 89 62 -340 114 62 -340 minecraft:water[level=0]
setblock 115 62 -340 minecraft:tall_seagrass[half=upper]
fill 81 62 -341 87 62 -341 minecraft:water[level=0]
fill 89 62 -341 114 62 -341 minecraft:water[level=0]
setblock 115 62 -341 minecraft:tall_seagrass[half=upper]
fill 80 62 -342 115 62 -342 minecraft:water[level=0]
fill 79 62 -343 114 62 -343 minecraft:water[level=0]
setblock 115 62 -343 minecraft:tall_seagrass[half=upper]
fill 79 62 -344 114 62 -344 minecraft:water[level=0]
setblock 115 62 -344 minecraft:tall_seagrass[half=upper]
fill 123 62 -344 125 62 -344 minecraft:water[level=0]
fill 77 62 -345 115 62 -345 minecraft:water[level=0]
fill 122 62 -345 125 62 -345 minecraft:water[level=0]
fill 73 62 -346 126 62 -346 minecraft:water[level=0]
fill 72 62 -347 120 62 -347 minecraft:water[level=0]
fill 121 62 -347 122 62 -347 minecraft:seagrass
fill 123 62 -347 126 62 -347 minecraft:water[level=0]
fill 72 62 -348 123 62 -348 minecraft:water[level=0]
fill 126 62 -348 127 62 -348 minecraft:water[level=0]
fill 72 62 -349 122 62 -349 minecraft:water[level=0]
fill 124 62 -349 125 62 -349 minecraft:water[level=0]
fill 72 62 -350 125 62 -350 minecraft:water[level=0]
fill 72 62 -351 121 62 -351 minecraft:water[level=0]
fill 123 62 -351 124 62 -351 minecraft:water[level=0]
fill 72 62 -352 124 62 -352 minecraft:water[level=0]
fill 72 62 -353 120 62 -353 minecraft:water[level=0]
setblock 122 62 -353 minecraft:water[level=0]
fill 72 62 -354 124 62 -354 minecraft:water[level=0]
fill 72 62 -355 122 62 -355 minecraft:water[level=0]
setblock 124 62 -355 minecraft:water[level=0]
fill 72 62 -356 123 62 -356 minecraft:water[level=0]
fill 72 62 -357 123 62 -357 minecraft:water[level=0]
setblock 125 62 -357 minecraft:water[level=0]
fill 72 62 -358 124 62 -358 minecraft:water[level=0]
fill 72 62 -359 123 62 -359 minecraft:water[level=0]
setblock 125 62 -359 minecraft:water[level=0]
setblock 127 62 -359 minecraft:water[level=0]
fill 72 62 -360 125 62 -360 minecraft:water[level=0]
fill 128 62 -360 131 62 -360 minecraft:water[level=0]
setblock 132 62 -360 minecraft:seagrass
fill 133 62 -360 135 62 -360 minecraft:water[level=0]
fill 72 62 -361 126 62 -361 minecraft:water[level=0]
setblock 129 62 -361 minecraft:water[level=0]
setblock 130 62 -361 minecraft:seagrass
fill 131 62 -361 134 62 -361 minecraft:water[level=0]
setblock 135 62 -361 minecraft:seagrass
fill 72 62 -362 123 62 -362 minecraft:water[level=0]
setblock 124 62 -362 minecraft:tall_seagrass[half=upper]
fill 125 62 -362 128 62 -362 minecraft:water[level=0]
fill 130 62 -362 131 62 -362 minecraft:seagrass
fill 132 62 -362 133 62 -362 minecraft:water[level=0]
setblock 134 62 -362 minecraft:seagrass
setblock 135 62 -362 minecraft:water[level=0]
fill 72 62 -363 128 62 -363 minecraft:water[level=0]
setblock 129 62 -363 minecraft:tall_seagrass[half=upper]
fill 130 62 -363 135 62 -363 minecraft:water[level=0]
fill 72 62 -364 135 62 -364 minecraft:water[level=0]
fill 72 62 -365 135 62 -365 minecraft:water[level=0]
fill 72 62 -366 135 62 -366 minecraft:water[level=0]
fill 72 62 -367 135 62 -367 minecraft:water[level=0]
fill 72 62 -368 135 62 -368 minecraft:water[level=0]
fill 72 62 -369 135 62 -369 minecraft:water[level=0]
fill 72 62 -370 135 62 -370 minecraft:water[level=0]
fill 72 62 -371 135 62 -371 minecraft:water[level=0]
fill 72 62 -372 135 62 -372 minecraft:water[level=0]
fill 72 62 -373 135 62 -373 minecraft:water[level=0]
fill 72 62 -374 135 62 -374 minecraft:water[level=0]
fill 72 62 -375 135 62 -375 minecraft:water[level=0]
fill 72 62 -376 135 62 -376 minecraft:water[level=0]
fill 72 62 -377 135 62 -377 minecraft:water[level=0]
fill 72 62 -378 135 62 -378 minecraft:water[level=0]
fill 72 62 -379 135 62 -379 minecraft:water[level=0]
fill 72 62 -380 135 62 -380 minecraft:water[level=0]
fill 72 62 -381 135 62 -381 minecraft:water[level=0]
fill 72 62 -382 135 62 -382 minecraft:water[level=0]
fill 94 61 -319 110 61 -319 minecraft:water[level=0]
setblock 111 61 -319 minecraft:tall_seagrass[half=lower]
fill 119 61 -319 120 61 -319 minecraft:water[level=0]
fill 94 61 -320 109 61 -320 minecraft:water[level=0]
setblock 110 61 -320 minecraft:seagrass
fill 111 61 -320 112 61 -320 minecraft:water[level=0]
fill 120 61 -320 121 61 -320 minecraft:water[level=0]
fill 94 61 -321 108 61 -321 minecraft:water[level=0]
setblock 109 61 -321 minecraft:tall_seagrass[half=upper]
fill 110 61 -321 112 61 -321 minecraft:water[level=0]
fill 120 61 -321 121 61 -321 minecraft:water[level=0]
fill 94 61 -322 113 61 -322 minecraft:water[level=0]
setblock 121 61 -322 minecraft:water[level=0]
fill 94 61 -323 114 61 -323 minecraft:water[level=0]
fill 94 61 -324 114 61 -324 minecraft:water[level=0]
fill 94 61 -325 115 61 -325 minecraft:water[level=0]
fill 94 61 -326 115 61 -326 minecraft:water[level=0]
fill 94 61 -327 116 61 -327 minecraft:water[level=0]
fill 94 61 -328 116 61 -328 minecraft:water[level=0]
fill 94 61 -329 117 61 -329 minecraft:water[level=0]
fill 94 61 -330 117 61 -330 minecraft:water[level=0]
fill 94 61 -331 118 61 -331 minecraft:water[level=0]
fill 87 61 -332 88 61 -332 minecraft:water[level=0]
fill 94 61 -332 118 61 -332 minecraft:water[level=0]
fill 72 61 -333 73 61 -333 minecraft:water[level=0]
fill 87 61 -333 88 61 -333 minecraft:water[level=0]
fill 94 61 -333 118 61 -333 minecraft:water[level=0]
fill 72 61 -334 74 61 -334 minecraft:water[level=0]
fill 87 61 -334 89 61 -334 minecraft:water[level=0]
fill 94 61 -334 118 61 -334 minecraft:water[level=0]
fill 72 61 -335 74 61 -335 minecraft:water[level=0]
fill 88 61 -335 90 61 -335 minecraft:water[level=0]
fill 95 61 -335 117 61 -335 minecraft:water[level=0]
fill 88 61 -336 92 61 -336 minecraft:water[level=0]
fill 97 61 -336 117 61 -336 minecraft:water[level=0]
fill 89 61 -337 116 61 -337 minecraft:water[level=0]
fill 90 61 -338 115 61 -338 minecraft:water[level=0]
fill 90 61 -339 114 61 -339 minecraft:water[level=0]
setblock 115 61 -339 minecraft:tall_seagrass[half=lower]
fill 90 61 -340 114 61 -340 minecraft:water[level=0]
setblock 115 61 -340 minecraft:tall_seagrass[half=lower]
fill 89 61 -341 114 61 -341 minecraft:water[level=0]
setblock 115 61 -341 minecraft:tall_seagrass[half=lower]
fill 83 61 -342 114 61 -342 minecraft:water[level=0]
setblock 115 61 -342 minecraft:seagrass
fill 82 61 -343 114 61 -343 minecraft:water[level=0]
setblock 115 61 -343 minecraft:tall_seagrass[half=lower]
fill 80 61 -344 114 61 -344 minecraft:water[level=0]
setblock 115 61 -344 minecraft:tall_seagrass[half=lower]
fill 79 61 -345 115 61 -345 minecraft:water[level=0]
fill 76 61 -346 115 61 -346 minecraft:water[level=0]
fill 74 61 -347 115 61 -347 minecraft:water[level=0]
fill 73 61 -348 115 61 -348 minecraft:water[level=0]
fill 72 61 -349 115 61 -349 minecraft:water[level=0]
fill 72 61 -350 115 61 -350 minecraft:water[level=0]
fill 72 61 -351 115 61 -351 minecraft:water[level=0]
fill 72 61 -352 114 61 -352 minecraft:water[level=0]
fill 72 61 -353 114 61 -353 minecraft:water[level=0]
fill 72 61 -354 115 61 -354 minecraft:water[level=0]
fill 72 61 -355 115 61 -355 minecraft:water[level=0]
setblock 120 61 -355 minecraft:water[level=0]
fill 72 61 -356 115 61 -356 minecraft:water[level=0]
fill 119 61 -356 120 61 -356 minecraft:water[level=0]
fill 72 61 -357 121 61 -357 minecraft:water[level=0]
fill 72 61 -358 114 61 -358 minecraft:water[level=0]
setblock 115 61 -358 minecraft:tall_seagrass[half=upper]
setblock 116 61 -358 minecraft:seagrass
fill 117 61 -358 122 61 -358 minecraft:water[level=0]
fill 72 61 -359 119 61 -359 minecraft:water[level=0]
setblock 120 61 -359 minecraft:seagrass
fill 121 61 -359 123 61 -359 minecraft:water[level=0]
fill 72 61 -360 124 61 -360 minecraft:water[level=0]
fill 72 61 -361 119 61 -361 minecraft:water[level=0]
setblock 120 61 -361 minecraft:tall_seagrass[half=upper]
fill 121 61 -361 125 61 -361 minecraft:water[level=0]
fill 72 61 -362 123 61 -362 minecraft:water[level=0]
setblock 124 61 -362 minecraft:tall_seagrass[half=lower]
fill 125 61 -362 127 61 -362 minecraft:water[level=0]
fill 72 61 -363 120 61 -363 minecraft:water[level=0]
setblock 121 61 -363 minecraft:tall_seagrass[half=upper]
fill 122 61 -363 128 61 -363 minecraft:water[level=0]
setblock 129 61 -363 minecraft:tall_seagrass[half=lower]
fill 130 61 -363 131 61 -363 minecraft:water[level=0]
setblock 132 61 -363 minecraft:seagrass
setblock 133 61 -363 minecraft:water[level=0]
fill 134 61 -363 135 61 -363 minecraft:seagrass
fill 72 61 -364 127 61 -364 minecraft:water[level=0]
setblock 128 61 -364 minecraft:seagrass
fill 129 61 -364 135 61 -364 minecraft:water[level=0]
fill 72 61 -365 130 61 -365 minecraft:water[level=0]
fill 131 61 -365 132 61 -365 minecraft:seagrass
fill 133 61 -365 135 61 -365 minecraft:water[level=0]
fill 72 61 -366 134 61 -366 minecraft:water[level=0]
setblock 135 61 -366 minecraft:tall_seagrass[half=upper]
fill 72 61 -367 135 61 -367 minecraft:water[level=0]
fill 72 61 -368 130 61 -368 minecraft:water[level=0]
setblock 131 61 -368 minecraft:tall_seagrass[half=upper]
fill 132 61 -368 135 61 -368 minecraft:water[level=0]
fill 72 61 -369 135 61 -369 minecraft:water[level=0]
fill 72 61 -370 83 61 -370 minecraft:water[level=0]
setblock 84 61 -370 minecraft:kelp[age=25]
fill 85 61 -370 135 61 -370 minecraft:water[level=0]
fill 72 61 -371 135 61 -371 minecraft:water[level=0]
fill 72 61 -372 135 61 -372 minecraft:water[level=0]
fill 72 61 -373 135 61 -373 minecraft:water[level=0]
fill 72 61 -374 135 61 -374 minecraft:water[level=0]
fill 72 61 -375 135 61 -375 minecraft:water[level=0]
fill 72 61 -376 135 61 -376 minecraft:water[level=0]
fill 72 61 -377 89 61 -377 minecraft:water[level=0]
setblock 90 61 -377 minecraft:kelp[age=25]
fill 91 61 -377 135 61 -377 minecraft:water[level=0]
fill 72 61 -378 135 61 -378 minecraft:water[level=0]
fill 72 61 -379 135 61 -379 minecraft:water[level=0]
fill 72 61 -380 135 61 -380 minecraft:water[level=0]
fill 72 61 -381 82 61 -381 minecraft:water[level=0]
setblock 83 61 -381 minecraft:kelp[age=25]
fill 84 61 -381 135 61 -381 minecraft:water[level=0]
fill 72 61 -382 135 61 -382 minecraft:water[level=0]
fill 95 60 -319 109 60 -319 minecraft:water[level=0]
fill 95 60 -320 109 60 -320 minecraft:water[level=0]
fill 95 60 -321 108 60 -321 minecraft:water[level=0]
setblock 109 60 -321 minecraft:tall_seagrass[half=lower]
fill 110 60 -321 112 60 -321 minecraft:water[level=0]
fill 95 60 -322 109 60 -322 minecraft:water[level=0]
setblock 110 60 -322 minecraft:tall_seagrass[half=upper]
fill 111 60 -322 112 60 -322 minecraft:water[level=0]
fill 95 60 -323 113 60 -323 minecraft:water[level=0]
fill 95 60 -324 112 60 -324 minecraft:water[level=0]
setblock 113 60 -324 minecraft:tall_seagrass[half=upper]
fill 95 60 -325 114 60 -325 minecraft:water[level=0]
fill 95 60 -326 114 60 -326 minecraft:water[level=0]
fill 95 60 -327 115 60 -327 minecraft:water[level=0]
fill 95 60 -328 116 60 -328 minecraft:water[level=0]
fill 95 60 -329 116 60 -329 minecraft:water[level=0]
fill 95 60 -330 116 60 -330 minecraft:water[level=0]
fill 95 60 -331 117 60 -331 minecraft:water[level=0]
fill 95 60 -332 117 60 -332 minecraft:water[level=0]
fill 96 60 -333 117 60 -333 minecraft:water[level=0]
fill 96 60 -334 117 60 -334 minecraft:water[level=0]
fill 97 60 -335 116 60 -335 minecraft:water[level=0]
fill 98 60 -336 116 60 -336 minecraft:water[level=0]
fill 98 60 -337 115 60 -337 minecraft:water[level=0]
fill 91 60 -338 115 60 -338 minecraft:water[level=0]
fill 91 60 -339 114 60 -339 minecraft:water[level=0]
fill 91 60 -340 99 60 -340 minecraft:water[level=0]
setblock 101 60 -340 minecraft:water[level=0]
setblock 102 60 -340 minecraft:seagrass
fill 103 60 -340 114 60 -340 minecraft:water[level=0]
fill 90 60 -341 100 60 -341 minecraft:water[level=0]
setblock 101 60 -341 minecraft:tall_seagrass[half=upper]
fill 102 60 -341 114 60 -341 minecraft:water[level=0]
fill 89 60 -342 100 60 -342 minecraft:water[level=0]
setblock 101 60 -342 minecraft:tall_seagrass[half=upper]
fill 102 60 -342 114 60 -342 minecraft:water[level=0]
fill 84 60 -343 114 60 -343 minecraft:water[level=0]
fill 82 60 -344 114 60 -344 minecraft:water[level=0]
fill 81 60 -345 114 60 -345 minecraft:water[level=0]
fill 78 60 -346 114 60 -346 minecraft:water[level=0]
fill 76 60 -347 114 60 -347 minecraft:water[level=0]
fill 74 60 -348 114 60 -348 minecraft:water[level=0]
fill 74 60 -349 114 60 -349 minecraft:water[level=0]
fill 73 60 -350 114 60 -350 minecraft:water[level=0]
fill 72 60 -351 114 60 -351 minecraft:water[level=0]
fill 72 60 -352 113 60 -352 minecraft:water[level=0]
fill 72 60 -353 113 60 -353 minecraft:water[level=0]
fill 72 60 -354 113 60 -354 minecraft:water[level=0]
fill 72 60 -355 113 60 -355 minecraft:water[level=0]
fill 72 60 -356 114 60 -356 minecraft:water[level=0]
fill 72 60 -357 115 60 -357 minecraft:water[level=0]
fill 72 60 -358 114 60 -358 minecraft:water[level=0]
setblock 115 60 -358 minecraft:tall_seagrass[half=lower]
fill 72 60 -359 118 60 -359 minecraft:water[level=0]
fill 72 60 -360 119 60 -360 minecraft:water[level=0]
fill 72 60 -361 116 60 -361 minecraft:water[level=0]
setblock 117 60 -361 minecraft:tall_seagrass[half=upper]
fill 118 60 -361 119 60 -361 minecraft:water[level=0]
setblock 120 60 -361 minecraft:tall_seagrass[half=lower]
setblock 121 60 -361 minecraft:water[level=0]
fill 72 60 -362 122 60 -362 minecraft:water[level=0]
fill 72 60 -363 73 60 -363 minecraft:water[level=0]
setblock 74 60 -363 minecraft:kelp[age=24]
fill 75 60 -363 119 60 -363 minecraft:water[level=0]
setblock 120 60 -363 minecraft:tall_seagrass[half=upper]
setblock 121 60 -363 minecraft:tall_seagrass[half=lower]
setblock 122 60 -363 minecraft:water[level=0]
setblock 123 60 -363 minecraft:seagrass
setblock 124 60 -363 minecraft:water[level=0]
fill 72 60 -364 126 60 -364 minecraft:water[level=0]
fill 72 60 -365 127 60 -365 minecraft:water[level=0]
fill 134 60 -365 135 60 -365 minecraft:water[level=0]
fill 72 60 -366 129 60 -366 minecraft:water[level=0]
setblock 130 60 -366 minecraft:seagrass
fill 131 60 -366 134 60 -366 minecraft:water[level=0]
setblock 135 60 -366 minecraft:tall_seagrass[half=lower]
fill 72 60 -367 135 60 -367 minecraft:water[level=0]
fill 72 60 -368 123 60 -368 minecraft:water[level=0]
setblock 124 60 -368 minecraft:tall_seagrass[half=upper]
fill 125 60 -368 130 60 -368 minecraft:water[level=0]
setblock 131 60 -368 minecraft:tall_seagrass[half=lower]
fill 132 60 -368 134 60 -368 minecraft:water[level=0]
setblock 135 60 -368 minecraft:tall_seagrass[half=upper]
fill 72 60 -369 132 60 -369 minecraft:water[level=0]
setblock 133 60 -369 minecraft:tall_seagrass[half=upper]
fill 134 60 -369 135 60 -369 minecraft:water[level=0]
fill 72 60 -370 83 60 -370 minecraft:water[level=0]
setblock 84 60 -370 minecraft:kelp_plant
setblock 85 60 -370 minecraft:water[level=0]
setblock 86 60 -370 minecraft:kelp[age=25]
fill 87 60 -370 135 60 -370 minecraft:water[level=0]
fill 72 60 -371 135 60 -371 minecraft:water[level=0]
fill 72 60 -372 135 60 -372 minecraft:water[level=0]
fill 72 60 -373 135 60 -373 minecraft:water[level=0]
fill 72 60 -374 135 60 -374 minecraft:water[level=0]
fill 72 60 -375 135 60 -375 minecraft:water[level=0]
fill 72 60 -376 135 60 -376 minecraft:water[level=0]
fill 72 60 -377 89 60 -377 minecraft:water[level=0]
setblock 90 60 -377 minecraft:kelp_plant
fill 91 60 -377 135 60 -377 minecraft:water[level=0]
fill 72 60 -378 135 60 -378 minecraft:water[level=0]
fill 72 60 -379 135 60 -379 minecraft:water[level=0]
fill 72 60 -380 135 60 -380 minecraft:water[level=0]
fill 72 60 -381 82 60 -381 minecraft:water[level=0]
setblock 83 60 -381 minecraft:kelp_plant
fill 84 60 -381 135 60 -381 minecraft:water[level=0]
fill 72 60 -382 135 60 -382 minecraft:water[level=0]
fill 95 59 -319 107 59 -319 minecraft:water[level=0]
fill 96 59 -320 107 59 -320 minecraft:water[level=0]
fill 95 59 -321 108 59 -321 minecraft:water[level=0]
fill 95 59 -322 107 59 -322 minecraft:water[level=0]
setblock 108 59 -322 minecraft:seagrass
setblock 109 59 -322 minecraft:water[level=0]
setblock 110 59 -322 minecraft:tall_seagrass[half=lower]
setblock 111 59 -322 minecraft:water[level=0]
fill 95 59 -323 108 59 -323 minecraft:water[level=0]
setblock 109 59 -323 minecraft:tall_seagrass[half=upper]
fill 110 59 -323 112 59 -323 minecraft:water[level=0]
fill 95 59 -324 112 59 -324 minecraft:water[level=0]
setblock 113 59 -324 minecraft:tall_seagrass[half=lower]
fill 95 59 -325 113 59 -325 minecraft:water[level=0]
fill 96 59 -326 114 59 -326 minecraft:water[level=0]
fill 96 59 -327 114 59 -327 minecraft:water[level=0]
fill 96 59 -328 115 59 -328 minecraft:water[level=0]
fill 96 59 -329 116 59 -329 minecraft:water[level=0]
fill 96 59 -330 116 59 -330 minecraft:water[level=0]
fill 96 59 -331 116 59 -331 minecraft:water[level=0]
fill 96 59 -332 116 59 -332 minecraft:water[level=0]
fill 96 59 -333 116 59 -333 minecraft:water[level=0]
fill 97 59 -334 116 59 -334 minecraft:water[level=0]
fill 98 59 -335 115 59 -335 minecraft:water[level=0]
fill 99 59 -336 115 59 -336 minecraft:water[level=0]
fill 99 59 -337 113 59 -337 minecraft:water[level=0]
setblock 114 59 -337 minecraft:tall_seagrass[half=upper]
setblock 115 59 -337 minecraft:water[level=0]
fill 99 59 -338 113 59 -338 minecraft:water[level=0]
setblock 114 59 -338 minecraft:tall_seagrass[half=upper]
fill 92 59 -339 97 59 -339 minecraft:water[level=0]
fill 101 59 -339 114 59 -339 minecraft:water[level=0]
fill 91 59 -340 98 59 -340 minecraft:water[level=0]
fill 103 59 -340 114 59 -340 minecraft:water[level=0]
fill 91 59 -341 99 59 -341 minecraft:water[level=0]
setblock 101 59 -341 minecraft:tall_seagrass[half=lower]
fill 102 59 -341 114 59 -341 minecraft:water[level=0]
fill 89 59 -342 100 59 -342 minecraft:water[level=0]
setblock 101 59 -342 minecraft:tall_seagrass[half=lower]
setblock 102 59 -342 minecraft:tall_seagrass[half=upper]
fill 103 59 -342 114 59 -342 minecraft:water[level=0]
fill 87 59 -343 113 59 -343 minecraft:water[level=0]
setblock 114 59 -343 minecraft:seagrass
fill 84 59 -344 114 59 -344 minecraft:water[level=0]
fill 82 59 -345 114 59 -345 minecraft:water[level=0]
fill 80 59 -346 113 59 -346 minecraft:water[level=0]
setblock 114 59 -346 minecraft:seagrass
fill 77 59 -347 114 59 -347 minecraft:water[level=0]
fill 75 59 -348 114 59 -348 minecraft:water[level=0]
fill 75 59 -349 114 59 -349 minecraft:water[level=0]
fill 74 59 -350 113 59 -350 minecraft:water[level=0]
fill 73 59 -351 113 59 -351 minecraft:water[level=0]
fill 72 59 -352 112 59 -352 minecraft:water[level=0]
fill 72 59 -353 112 59 -353 minecraft:water[level=0]
fill 72 59 -354 112 59 -354 minecraft:water[level=0]
fill 72 59 -355 112 59 -355 minecraft:water[level=0]
fill 72 59 -356 112 59 -356 minecraft:water[level=0]
fill 72 59 -357 114 59 -357 minecraft:water[level=0]
fill 72 59 -358 114 59 -358 minecraft:water[level=0]
fill 72 59 -359 115 59 -359 minecraft:water[level=0]
fill 72 59 -360 115 59 -360 minecraft:water[level=0]
fill 72 59 -361 116 59 -361 minecraft:water[level=0]
setblock 117 59 -361 minecraft:tall_seagrass[half=lower]
setblock 118 59 -361 minecraft:water[level=0]
fill 72 59 -362 116 59 -362 minecraft:water[level=0]
setblock 117 59 -362 minecraft:tall_seagrass[half=upper]
fill 118 59 -362 119 59 -362 minecraft:water[level=0]
fill 72 59 -363 73 59 -363 minecraft:water[level=0]
setblock 74 59 -363 minecraft:kelp_plant
fill 75 59 -363 116 59 -363 minecraft:water[level=0]
setblock 117 59 -363 minecraft:tall_seagrass[half=upper]
fill 118 59 -363 119 59 -363 minecraft:water[level=0]
setblock 120 59 -363 minecraft:tall_seagrass[half=lower]
fill 72 59 -364 118 59 -364 minecraft:water[level=0]
setblock 119 59 -364 minecraft:tall_seagrass[half=upper]
setblock 120 59 -364 minecraft:water[level=0]
setblock 121 59 -364 minecraft:seagrass
fill 72 59 -365 121 59 -365 minecraft:water[level=0]
setblock 122 59 -365 minecraft:seagrass
setblock 123 59 -365 minecraft:water[level=0]
fill 72 59 -366 121 59 -366 minecraft:water[level=0]
setblock 122 59 -366 minecraft:seagrass
fill 123 59 -366 124 59 -366 minecraft:water[level=0]
fill 72 59 -367 125 59 -367 minecraft:water[level=0]
fill 72 59 -368 121 59 -368 minecraft:water[level=0]
setblock 122 59 -368 minecraft:tall_seagrass[half=upper]
setblock 123 59 -368 minecraft:water[level=0]
setblock 124 59 -368 minecraft:tall_seagrass[half=lower]
fill 125 59 -368 126 59 -368 minecraft:water[level=0]
fill 133 59 -368 134 59 -368 minecraft:water[level=0]
setblock 135 59 -368 minecraft:tall_seagrass[half=lower]
fill 72 59 -369 123 59 -369 minecraft:water[level=0]
fill 124 59 -369 125 59 -369 minecraft:tall_seagrass[half=upper]
setblock 126 59 -369 minecraft:water[level=0]
setblock 127 59 -369 minecraft:seagrass
fill 128 59 -369 132 59 -369 minecraft:water[level=0]
setblock 133 59 -369 minecraft:tall_seagrass[half=lower]
fill 134 59 -369 135 59 -369 minecraft:water[level=0]
fill 72 59 -370 83 59 -370 minecraft:water[level=0]
setblock 84 59 -370 minecraft:kelp_plant
setblock 85 59 -370 minecraft:water[level=0]
setblock 86 59 -370 minecraft:kelp_plant
fill 87 59 -370 135 59 -370 minecraft:water[level=0]
fill 72 59 -371 129 59 -371 minecraft:water[level=0]
setblock 130 59 -371 minecraft:tall_seagrass[half=upper]
fill 131 59 -371 135 59 -371 minecraft:water[level=0]
fill 72 59 -372 135 59 -372 minecraft:water[level=0]
fill 72 59 -373 135 59 -373 minecraft:water[level=0]
fill 72 59 -374 135 59 -374 minecraft:water[level=0]
fill 72 59 -375 135 59 -375 minecraft:water[level=0]
fill 72 59 -376 135 59 -376 minecraft:water[level=0]
fill 72 59 -377 89 59 -377 minecraft:water[level=0]
setblock 90 59 -377 minecraft:kelp_plant
fill 91 59 -377 135 59 -377 minecraft:water[level=0]
fill 72 59 -378 135 59 -378 minecraft:water[level=0]
fill 72 59 -379 135 59 -379 minecraft:water[level=0]
fill 72 59 -380 135 59 -380 minecraft:water[level=0]
fill 72 59 -381 82 59 -381 minecraft:water[level=0]
setblock 83 59 -381 minecraft:kelp_plant
fill 84 59 -381 135 59 -381 minecraft:water[level=0]
fill 72 59 -382 135 59 -382 minecraft:water[level=0]
fill 96 58 -319 105 58 -319 minecraft:water[level=0]
setblock 106 58 -319 minecraft:seagrass
fill 96 58 -320 106 58 -320 minecraft:water[level=0]
fill 96 58 -321 107 58 -321 minecraft:water[level=0]
fill 96 58 -322 105 58 -322 minecraft:water[level=0]
setblock 106 58 -322 minecraft:tall_seagrass[half=upper]
setblock 107 58 -322 minecraft:water[level=0]
fill 96 58 -323 106 58 -323 minecraft:water[level=0]
setblock 107 58 -323 minecraft:tall_seagrass[half=upper]
setblock 108 58 -323 minecraft:seagrass
setblock 109 58 -323 minecraft:tall_seagrass[half=lower]
fill 110 58 -323 111 58 -323 minecraft:water[level=0]
fill 96 58 -324 108 58 -324 minecraft:water[level=0]
fill 109 58 -324 110 58 -324 minecraft:tall_seagrass[half=upper]
fill 111 58 -324 112 58 -324 minecraft:water[level=0]
fill 96 58 -325 107 58 -325 minecraft:water[level=0]
setblock 108 58 -325 minecraft:tall_seagrass[half=upper]
fill 109 58 -325 112 58 -325 minecraft:water[level=0]
fill 96 58 -326 113 58 -326 minecraft:water[level=0]
fill 96 58 -327 110 58 -327 minecraft:water[level=0]
setblock 111 58 -327 minecraft:tall_seagrass[half=upper]
fill 112 58 -327 113 58 -327 minecraft:water[level=0]
fill 96 58 -328 114 58 -328 minecraft:water[level=0]
fill 96 58 -329 114 58 -329 minecraft:water[level=0]
fill 96 58 -330 113 58 -330 minecraft:water[level=0]
setblock 114 58 -330 minecraft:tall_seagrass[half=upper]
setblock 115 58 -330 minecraft:water[level=0]
fill 96 58 -331 116 58 -331 minecraft:water[level=0]
fill 96 58 -332 116 58 -332 minecraft:water[level=0]
fill 98 58 -333 115 58 -333 minecraft:water[level=0]
fill 98 58 -334 115 58 -334 minecraft:water[level=0]
fill 99 58 -335 115 58 -335 minecraft:water[level=0]
fill 100 58 -336 114 58 -336 minecraft:water[level=0]
setblock 100 58 -337 minecraft:seagrass
setblock 101 58 -337 minecraft:water[level=0]
setblock 102 58 -337 minecraft:tall_seagrass[half=upper]
fill 103 58 -337 113 58 -337 minecraft:water[level=0]
setblock 114 58 -337 minecraft:tall_seagrass[half=lower]
fill 101 58 -338 113 58 -338 minecraft:water[level=0]
setblock 114 58 -338 minecraft:tall_seagrass[half=lower]
fill 103 58 -339 113 58 -339 minecraft:water[level=0]
fill 92 58 -340 96 58 -340 minecraft:water[level=0]
setblock 104 58 -340 minecraft:water[level=0]
setblock 105 58 -340 minecraft:tall_seagrass[half=upper]
fill 106 58 -340 113 58 -340 minecraft:water[level=0]
fill 91 58 -341 97 58 -341 minecraft:water[level=0]
fill 103 58 -341 113 58 -341 minecraft:water[level=0]
fill 90 58 -342 99 58 -342 minecraft:water[level=0]
setblock 102 58 -342 minecraft:tall_seagrass[half=lower]
setblock 103 58 -342 minecraft:tall_seagrass[half=upper]
fill 104 58 -342 113 58 -342 minecraft:water[level=0]
fill 88 58 -343 113 58 -343 minecraft:water[level=0]
fill 85 58 -344 113 58 -344 minecraft:water[level=0]
fill 84 58 -345 113 58 -345 minecraft:water[level=0]
fill 82 58 -346 113 58 -346 minecraft:water[level=0]
fill 79 58 -347 113 58 -347 minecraft:water[level=0]
fill 76 58 -348 113 58 -348 minecraft:water[level=0]
fill 76 58 -349 113 58 -349 minecraft:water[level=0]
fill 75 58 -350 113 58 -350 minecraft:water[level=0]
fill 75 58 -351 112 58 -351 minecraft:water[level=0]
fill 74 58 -352 111 58 -352 minecraft:water[level=0]
fill 72 58 -353 111 58 -353 minecraft:water[level=0]
fill 72 58 -354 111 58 -354 minecraft:water[level=0]
fill 72 58 -355 111 58 -355 minecraft:water[level=0]
fill 72 58 -356 82 58 -356 minecraft:water[level=0]
setblock 83 58 -356 minecraft:tall_seagrass[half=upper]
fill 84 58 -356 111 58 -356 minecraft:water[level=0]
fill 72 58 -357 80 58 -357 minecraft:water[level=0]
setblock 81 58 -357 minecraft:tall_seagrass[half=upper]
fill 82 58 -357 112 58 -357 minecraft:water[level=0]
fill 72 58 -358 82 58 -358 minecraft:water[level=0]
setblock 83 58 -358 minecraft:tall_seagrass[half=upper]
fill 84 58 -358 113 58 -358 minecraft:water[level=0]
fill 72 58 -359 81 58 -359 minecraft:water[level=0]
setblock 82 58 -359 minecraft:tall_seagrass[half=upper]
fill 83 58 -359 112 58 -359 minecraft:water[level=0]
setblock 113 58 -359 minecraft:tall_seagrass[half=upper]
setblock 114 58 -359 minecraft:water[level=0]
fill 72 58 -360 114 58 -360 minecraft:water[level=0]
setblock 115 58 -360 minecraft:seagrass
fill 72 58 -361 115 58 -361 minecraft:water[level=0]
fill 72 58 -362 116 58 -362 minecraft:water[level=0]
setblock 117 58 -362 minecraft:tall_seagrass[half=lower]
fill 72 58 -363 73 58 -363 minecraft:water[level=0]
setblock 74 58 -363 minecraft:kelp_plant
fill 75 58 -363 116 58 -363 minecraft:water[level=0]
setblock 117 58 -363 minecraft:tall_seagrass[half=lower]
setblock 118 58 -363 minecraft:water[level=0]
fill 72 58 -364 118 58 -364 minecraft:water[level=0]
setblock 119 58 -364 minecraft:tall_seagrass[half=lower]
fill 72 58 -365 117 58 -365 minecraft:water[level=0]
setblock 118 58 -365 minecraft:tall_seagrass[half=upper]
fill 119 58 -365 120 58 -365 minecraft:water[level=0]
fill 72 58 -366 121 58 -366 minecraft:water[level=0]
fill 72 58 -367 119 58 -367 minecraft:water[level=0]
setblock 120 58 -367 minecraft:tall_seagrass[half=upper]
fill 121 58 -367 122 58 -367 minecraft:water[level=0]
fill 72 58 -368 121 58 -368 minecraft:water[level=0]
setblock 122 58 -368 minecraft:tall_seagrass[half=lower]
setblock 123 58 -368 minecraft:water[level=0]
fill 72 58 -369 123 58 -369 minecraft:water[level=0]
fill 124 58 -369 125 58 -369 minecraft:tall_seagrass[half=lower]
setblock 126 58 -369 minecraft:water[level=0]
fill 72 58 -370 83 58 -370 minecraft:water[level=0]
setblock 84 58 -370 minecraft:kelp_plant
setblock 85 58 -370 minecraft:water[level=0]
setblock 86 58 -370 minecraft:kelp_plant
fill 87 58 -370 127 58 -370 minecraft:water[level=0]
fill 134 58 -370 135 58 -370 minecraft:water[level=0]
fill 72 58 -371 129 58 -371 minecraft:water[level=0]
setblock 130 58 -371 minecraft:tall_seagrass[half=lower]
fill 131 58 -371 135 58 -371 minecraft:water[level=0]
fill 72 58 -372 128 58 -372 minecraft:water[level=0]
setblock 129 58 -372 minecraft:seagrass
fill 130 58 -372 135 58 -372 minecraft:water[level=0]
fill 72 58 -373 82 58 -373 minecraft:water[level=0]
setblock 83 58 -373 minecraft:kelp[age=25]
fill 84 58 -373 130 58 -373 minecraft:water[level=0]
setblock 131 58 -373 minecraft:tall_seagrass[half=upper]
fill 132 58 -373 135 58 -373 minecraft:water[level=0]
fill 72 58 -374 131 58 -374 minecraft:water[level=0]
setblock 132 58 -374 minecraft:tall_seagrass[half=upper]
fill 133 58 -374 135 58 -374 minecraft:water[level=0]
fill 72 58 -375 135 58 -375 minecraft:water[level=0]
fill 72 58 -376 135 58 -376 minecraft:water[level=0]
fill 72 58 -377 89 58 -377 minecraft:water[level=0]
setblock 90 58 -377 minecraft:kelp_plant
fill 91 58 -377 135 58 -377 minecraft:water[level=0]
fill 72 58 -378 135 58 -378 minecraft:water[level=0]
fill 72 58 -379 135 58 -379 minecraft:water[level=0]
fill 72 58 -380 135 58 -380 minecraft:water[level=0]
fill 72 58 -381 82 58 -381 minecraft:water[level=0]
setblock 83 58 -381 minecraft:kelp_plant
fill 84 58 -381 135 58 -381 minecraft:water[level=0]
fill 72 58 -382 135 58 -382 minecraft:water[level=0]
setblock 96 57 -319 minecraft:water[level=0]
setblock 97 57 -319 minecraft:tall_seagrass[half=upper]
fill 98 57 -319 105 57 -319 minecraft:water[level=0]
fill 96 57 -320 97 57 -320 minecraft:water[level=0]
setblock 98 57 -320 minecraft:tall_seagrass[half=upper]
fill 99 57 -320 103 57 -320 minecraft:water[level=0]
setblock 104 57 -320 minecraft:tall_seagrass[half=upper]
setblock 105 57 -320 minecraft:water[level=0]
fill 96 57 -321 106 57 -321 minecraft:water[level=0]
fill 96 57 -322 105 57 -322 minecraft:water[level=0]
setblock 106 57 -322 minecraft:tall_seagrass[half=lower]
fill 96 57 -323 106 57 -323 minecraft:water[level=0]
setblock 107 57 -323 minecraft:tall_seagrass[half=lower]
fill 96 57 -324 101 57 -324 minecraft:water[level=0]
setblock 102 57 -324 minecraft:tall_seagrass[half=upper]
fill 103 57 -324 104 57 -324 minecraft:water[level=0]
setblock 105 57 -324 minecraft:tall_seagrass[half=upper]
setblock 106 57 -324 minecraft:water[level=0]
setblock 107 57 -324 minecraft:tall_seagrass[half=upper]
setblock 108 57 -324 minecraft:water[level=0]
fill 109 57 -324 110 57 -324 minecraft:tall_seagrass[half=lower]
fill 111 57 -324 112 57 -324 minecraft:water[level=0]
fill 96 57 -325 107 57 -325 minecraft:water[level=0]
setblock 108 57 -325 minecraft:tall_seagrass[half=lower]
fill 109 57 -325 112 57 -325 minecraft:water[level=0]
fill 96 57 -326 103 57 -326 minecraft:water[level=0]
fill 104 57 -326 105 57 -326 minecraft:tall_seagrass[half=upper]
setblock 106 57 -326 minecraft:water[level=0]
setblock 107 57 -326 minecraft:tall_seagrass[half=upper]
fill 108 57 -326 112 57 -326 minecraft:water[level=0]
fill 97 57 -327 110 57 -327 minecraft:water[level=0]
setblock 111 57 -327 minecraft:tall_seagrass[half=lower]
setblock 112 57 -327 minecraft:water[level=0]
fill 97 57 -328 103 57 -328 minecraft:water[level=0]
setblock 104 57 -328 minecraft:tall_seagrass[half=upper]
setblock 105 57 -328 minecraft:water[level=0]
setblock 106 57 -328 minecraft:tall_seagrass[half=upper]
fill 107 57 -328 113 57 -328 minecraft:water[level=0]
fill 97 57 -329 101 57 -329 minecraft:water[level=0]
setblock 102 57 -329 minecraft:tall_seagrass[half=upper]
fill 103 57 -329 105 57 -329 minecraft:water[level=0]
setblock 106 57 -329 minecraft:tall_seagrass[half=upper]
fill 107 57 -329 112 57 -329 minecraft:water[level=0]
setblock 113 57 -329 minecraft:seagrass
fill 97 57 -330 112 57 -330 minecraft:water[level=0]
setblock 113 57 -330 minecraft:seagrass
setblock 114 57 -330 minecraft:tall_seagrass[half=lower]
fill 97 57 -331 114 57 -331 minecraft:water[level=0]
fill 98 57 -332 107 57 -332 minecraft:water[level=0]
fill 108 57 -332 109 57 -332 minecraft:tall_seagrass[half=upper]
fill 110 57 -332 115 57 -332 minecraft:water[level=0]
fill 99 57 -333 112 57 -333 minecraft:water[level=0]
setblock 113 57 -333 minecraft:tall_seagrass[half=upper]
setblock 114 57 -333 minecraft:water[level=0]
fill 99 57 -334 114 57 -334 minecraft:water[level=0]
fill 100 57 -335 108 57 -335 minecraft:water[level=0]
setblock 109 57 -335 minecraft:tall_seagrass[half=upper]
fill 110 57 -335 114 57 -335 minecraft:water[level=0]
fill 101 57 -336 102 57 -336 minecraft:water[level=0]
setblock 103 57 -336 minecraft:tall_seagrass[half=upper]
fill 104 57 -336 114 57 -336 minecraft:water[level=0]
setblock 102 57 -337 minecraft:tall_seagrass[half=lower]
fill 103 57 -337 113 57 -337 minecraft:water[level=0]
fill 103 57 -338 104 57 -338 minecraft:water[level=0]
setblock 105 57 -338 minecraft:tall_seagrass[half=upper]
fill 106 57 -338 113 57 -338 minecraft:water[level=0]
setblock 104 57 -339 minecraft:seagrass
fill 105 57 -339 106 57 -339 minecraft:water[level=0]
setblock 107 57 -339 minecraft:tall_seagrass[half=upper]
fill 108 57 -339 113 57 -339 minecraft:water[level=0]
setblock 105 57 -340 minecraft:tall_seagrass[half=lower]
setblock 106 57 -340 minecraft:water[level=0]
setblock 107 57 -340 minecraft:tall_seagrass[half=upper]
fill 108 57 -340 113 57 -340 minecraft:water[level=0]
fill 92 57 -341 96 57 -341 minecraft:water[level=0]
setblock 104 57 -341 minecraft:seagrass
setblock 105 57 -341 minecraft:water[level=0]
setblock 106 57 -341 minecraft:tall_seagrass[half=upper]
fill 107 57 -341 113 57 -341 minecraft:water[level=0]
fill 91 57 -342 97 57 -342 minecraft:water[level=0]
setblock 103 57 -342 minecraft:tall_seagrass[half=lower]
fill 104 57 -342 113 57 -342 minecraft:water[level=0]
fill 89 57 -343 98 57 -343 minecraft:water[level=0]
fill 102 57 -343 103 57 -343 minecraft:water[level=0]
fill 104 57 -343 105 57 -343 minecraft:tall_seagrass[half=upper]
fill 106 57 -343 113 57 -343 minecraft:water[level=0]
fill 86 57 -344 98 57 -344 minecraft:water[level=0]
setblock 99 57 -344 minecraft:seagrass
fill 100 57 -344 107 57 -344 minecraft:water[level=0]
fill 108 57 -344 109 57 -344 minecraft:tall_seagrass[half=upper]
fill 110 57 -344 111 57 -344 minecraft:water[level=0]
fill 112 57 -344 113 57 -344 minecraft:tall_seagrass[half=upper]
fill 85 57 -345 103 57 -345 minecraft:water[level=0]
setblock 104 57 -345 minecraft:tall_seagrass[half=upper]
setblock 105 57 -345 minecraft:water[level=0]
setblock 106 57 -345 minecraft:tall_seagrass[half=upper]
fill 107 57 -345 113 57 -345 minecraft:water[level=0]
fill 84 57 -346 113 57 -346 minecraft:water[level=0]
fill 81 57 -347 113 57 -347 minecraft:water[level=0]
fill 77 57 -348 109 57 -348 minecraft:water[level=0]
setblock 110 57 -348 minecraft:tall_seagrass[half=upper]
fill 111 57 -348 112 57 -348 minecraft:water[level=0]
setblock 113 57 -348 minecraft:seagrass
fill 77 57 -349 112 57 -349 minecraft:water[level=0]
fill 76 57 -350 112 57 -350 minecraft:water[level=0]
fill 76 57 -351 111 57 -351 minecraft:water[level=0]
fill 75 57 -352 111 57 -352 minecraft:water[level=0]
fill 72 57 -353 111 57 -353 minecraft:water[level=0]
fill 72 57 -354 111 57 -354 minecraft:water[level=0]
fill 72 57 -355 111 57 -355 minecraft:water[level=0]
fill 72 57 -356 79 57 -356 minecraft:water[level=0]
fill 81 57 -356 82 57 -356 minecraft:water[level=0]
setblock 83 57 -356 minecraft:tall_seagrass[half=lower]
fill 84 57 -356 88 57 -356 minecraft:water[level=0]
setblock 89 57 -356 minecraft:tall_seagrass[half=upper]
fill 90 57 -356 111 57 -356 minecraft:water[level=0]
fill 72 57 -357 78 57 -357 minecraft:water[level=0]
setblock 79 57 -357 minecraft:tall_seagrass[half=upper]
setblock 80 57 -357 minecraft:water[level=0]
setblock 81 57 -357 minecraft:tall_seagrass[half=lower]
fill 82 57 -357 111 57 -357 minecraft:water[level=0]
fill 72 57 -358 81 57 -358 minecraft:water[level=0]
setblock 82 57 -358 minecraft:seagrass
setblock 83 57 -358 minecraft:tall_seagrass[half=lower]
fill 84 57 -358 112 57 -358 minecraft:water[level=0]
fill 72 57 -359 81 57 -359 minecraft:water[level=0]
setblock 82 57 -359 minecraft:tall_seagrass[half=lower]
setblock 83 57 -359 minecraft:water[level=0]
setblock 84 57 -359 minecraft:seagrass
fill 85 57 -359 112 57 -359 minecraft:water[level=0]
setblock 113 57 -359 minecraft:tall_seagrass[half=lower]
fill 72 57 -360 79 57 -360 minecraft:water[level=0]
setblock 80 57 -360 minecraft:tall_seagrass[half=upper]
fill 81 57 -360 83 57 -360 minecraft:water[level=0]
fill 85 57 -360 113 57 -360 minecraft:water[level=0]
setblock 114 57 -360 minecraft:seagrass
fill 72 57 -361 114 57 -361 minecraft:water[level=0]
fill 72 57 -362 114 57 -362 minecraft:water[level=0]
setblock 115 57 -362 minecraft:seagrass
fill 72 57 -363 73 57 -363 minecraft:water[level=0]
setblock 74 57 -363 minecraft:kelp_plant
fill 75 57 -363 77 57 -363 minecraft:water[level=0]
setblock 78 57 -363 minecraft:kelp[age=25]
fill 79 57 -363 116 57 -363 minecraft:water[level=0]
fill 72 57 -364 117 57 -364 minecraft:water[level=0]
setblock 118 57 -364 minecraft:seagrass
fill 72 57 -365 117 57 -365 minecraft:water[level=0]
setblock 118 57 -365 minecraft:tall_seagrass[half=lower]
fill 72 57 -366 118 57 -366 minecraft:water[level=0]
setblock 119 57 -366 minecraft:seagrass
fill 72 57 -367 115 57 -367 minecraft:water[level=0]
setblock 116 57 -367 minecraft:tall_seagrass[half=upper]
setblock 117 57 -367 minecraft:water[level=0]
setblock 118 57 -367 minecraft:tall_seagrass[half=upper]
setblock 119 57 -367 minecraft:water[level=0]
setblock 120 57 -367 minecraft:tall_seagrass[half=lower]
fill 72 57 -368 121 57 -368 minecraft:water[level=0]
fill 72 57 -369 123 57 -369 minecraft:water[level=0]
fill 72 57 -370 83 57 -370 minecraft:water[level=0]
setblock 84 57 -370 minecraft:kelp_plant
setblock 85 57 -370 minecraft:water[level=0]
setblock 86 57 -370 minecraft:kelp_plant
fill 87 57 -370 91 57 -370 minecraft:water[level=0]
setblock 92 57 -370 minecraft:kelp[age=25]
fill 93 57 -370 123 57 -370 minecraft:water[level=0]
setblock 124 57 -370 minecraft:tall_seagrass[half=upper]
setblock 125 57 -370 minecraft:water[level=0]
fill 72 57 -371 125 57 -371 minecraft:water[level=0]
setblock 126 57 -371 minecraft:seagrass
fill 72 57 -372 124 57 -372 minecraft:water[level=0]
setblock 125 57 -372 minecraft:tall_seagrass[half=upper]
fill 126 57 -372 127 57 -372 minecraft:water[level=0]
fill 72 57 -373 82 57 -373 minecraft:water[level=0]
setblock 83 57 -373 minecraft:kelp_plant
fill 84 57 -373 130 57 -373 minecraft:water[level=0]
setblock 131 57 -373 minecraft:tall_seagrass[half=lower]
fill 132 57 -373 135 57 -373 minecraft:water[level=0]
fill 72 57 -374 127 57 -374 minecraft:water[level=0]
setblock 128 57 -374 minecraft:seagrass
setblock 129 57 -374 minecraft:water[level=0]
setblock 130 57 -374 minecraft:seagrass
setblock 131 57 -374 minecraft:water[level=0]
setblock 132 57 -374 minecraft:tall_seagrass[half=lower]
fill 133 57 -374 135 57 -374 minecraft:water[level=0]
fill 72 57 -375 126 57 -375 minecraft:water[level=0]
setblock 127 57 -375 minecraft:tall_seagrass[half=upper]
fill 128 57 -375 135 57 -375 minecraft:water[level=0]
fill 72 57 -376 135 57 -376 minecraft:water[level=0]
fill 72 57 -377 89 57 -377 minecraft:water[level=0]
setblock 90 57 -377 minecraft:kelp_plant
fill 91 57 -377 135 57 -377 minecraft:water[level=0]
fill 72 57 -378 84 57 -378 minecraft:water[level=0]
setblock 85 57 -378 minecraft:kelp[age=25]
fill 86 57 -378 135 57 -378 minecraft:water[level=0]
fill 72 57 -379 135 57 -379 minecraft:water[level=0]
fill 72 57 -380 85 57 -380 minecraft:water[level=0]
setblock 86 57 -380 minecraft:kelp[age=25]
fill 87 57 -380 90 57 -380 minecraft:water[level=0]
setblock 91 57 -380 minecraft:kelp[age=25]
fill 92 57 -380 135 57 -380 minecraft:water[level=0]
fill 72 57 -381 82 57 -381 minecraft:water[level=0]
setblock 83 57 -381 minecraft:kelp_plant
fill 84 57 -381 135 57 -381 minecraft:water[level=0]
fill 72 57 -382 135 57 -382 minecraft:water[level=0]
setblock 97 56 -319 minecraft:tall_seagrass[half=lower]
fill 98 56 -319 102 56 -319 minecraft:water[level=0]
fill 103 56 -319 104 56 -319 minecraft:seagrass
setblock 97 56 -320 minecraft:water[level=0]
setblock 98 56 -320 minecraft:tall_seagrass[half=lower]
fill 99 56 -320 101 56 -320 minecraft:water[level=0]
setblock 102 56 -320 minecraft:seagrass
setblock 103 56 -320 minecraft:water[level=0]
setblock 104 56 -320 minecraft:tall_seagrass[half=lower]
fill 97 56 -321 102 56 -321 minecraft:water[level=0]
setblock 103 56 -321 minecraft:seagrass
fill 104 56 -321 105 56 -321 minecraft:water[level=0]
fill 97 56 -322 101 56 -322 minecraft:water[level=0]
fill 102 56 -322 104 56 -322 minecraft:seagrass
setblock 105 56 -322 minecraft:water[level=0]
fill 97 56 -323 103 56 -323 minecraft:water[level=0]
fill 104 56 -323 106 56 -323 minecraft:seagrass
fill 97 56 -324 101 56 -324 minecraft:water[level=0]
setblock 102 56 -324 minecraft:tall_seagrass[half=lower]
fill 103 56 -324 104 56 -324 minecraft:water[level=0]
setblock 105 56 -324 minecraft:tall_seagrass[half=lower]
setblock 106 56 -324 minecraft:seagrass
setblock 107 56 -324 minecraft:tall_seagrass[half=lower]
fill 97 56 -325 101 56 -325 minecraft:water[level=0]
setblock 102 56 -325 minecraft:seagrass
setblock 103 56 -325 minecraft:water[level=0]
setblock 104 56 -325 minecraft:seagrass
fill 105 56 -325 107 56 -325 minecraft:water[level=0]
fill 97 56 -326 100 56 -326 minecraft:water[level=0]
setblock 101 56 -326 minecraft:tall_seagrass[half=upper]
fill 102 56 -326 103 56 -326 minecraft:water[level=0]
fill 104 56 -326 105 56 -326 minecraft:tall_seagrass[half=lower]
setblock 106 56 -326 minecraft:water[level=0]
setblock 107 56 -326 minecraft:tall_seagrass[half=lower]
setblock 108 56 -326 minecraft:seagrass
fill 98 56 -327 101 56 -327 minecraft:water[level=0]
setblock 102 56 -327 minecraft:seagrass
setblock 103 56 -327 minecraft:water[level=0]
setblock 104 56 -327 minecraft:seagrass
setblock 105 56 -327 minecraft:water[level=0]
setblock 106 56 -327 minecraft:seagrass
setblock 107 56 -327 minecraft:water[level=0]
setblock 108 56 -327 minecraft:seagrass
fill 109 56 -327 110 56 -327 minecraft:water[level=0]
fill 98 56 -328 103 56 -328 minecraft:water[level=0]
setblock 104 56 -328 minecraft:tall_seagrass[half=lower]
setblock 105 56 -328 minecraft:seagrass
setblock 106 56 -328 minecraft:tall_seagrass[half=lower]
fill 107 56 -328 109 56 -328 minecraft:water[level=0]
setblock 110 56 -328 minecraft:seagrass
fill 111 56 -328 112 56 -328 minecraft:water[level=0]
fill 98 56 -329 101 56 -329 minecraft:water[level=0]
setblock 102 56 -329 minecraft:tall_seagrass[half=lower]
setblock 103 56 -329 minecraft:water[level=0]
setblock 104 56 -329 minecraft:tall_seagrass[half=upper]
setblock 105 56 -329 minecraft:water[level=0]
setblock 106 56 -329 minecraft:tall_seagrass[half=lower]
fill 107 56 -329 112 56 -329 minecraft:water[level=0]
fill 98 56 -330 104 56 -330 minecraft:water[level=0]
fill 105 56 -330 106 56 -330 minecraft:seagrass
fill 107 56 -330 108 56 -330 minecraft:water[level=0]
setblock 109 56 -330 minecraft:seagrass
setblock 110 56 -330 minecraft:water[level=0]
setblock 111 56 -330 minecraft:seagrass
setblock 112 56 -330 minecraft:water[level=0]
fill 99 56 -331 112 56 -331 minecraft:water[level=0]
fill 99 56 -332 107 56 -332 minecraft:water[level=0]
fill 108 56 -332 109 56 -332 minecraft:tall_seagrass[half=lower]
fill 110 56 -332 113 56 -332 minecraft:water[level=0]
setblock 100 56 -333 minecraft:seagrass
fill 101 56 -333 105 56 -333 minecraft:water[level=0]
fill 106 56 -333 107 56 -333 minecraft:seagrass
fill 108 56 -333 112 56 -333 minecraft:water[level=0]
setblock 113 56 -333 minecraft:tall_seagrass[half=lower]
fill 100 56 -334 102 56 -334 minecraft:water[level=0]
setblock 103 56 -334 minecraft:seagrass
fill 104 56 -334 113 56 -334 minecraft:water[level=0]
fill 101 56 -335 102 56 -335 minecraft:water[level=0]
setblock 103 56 -335 minecraft:seagrass
setblock 104 56 -335 minecraft:water[level=0]
setblock 105 56 -335 minecraft:tall_seagrass[half=upper]
fill 106 56 -335 108 56 -335 minecraft:water[level=0]
setblock 109 56 -335 minecraft:tall_seagrass[half=lower]
fill 110 56 -335 113 56 -335 minecraft:water[level=0]
setblock 102 56 -336 minecraft:water[level=0]
setblock 103 56 -336 minecraft:tall_seagrass[half=lower]
fill 104 56 -336 113 56 -336 minecraft:water[level=0]
fill 103 56 -337 104 56 -337 minecraft:water[level=0]
setblock 105 56 -337 minecraft:seagrass
fill 106 56 -337 107 56 -337 minecraft:water[level=0]
setblock 108 56 -337 minecraft:tall_seagrass[half=upper]
fill 109 56 -337 113 56 -337 minecraft:water[level=0]
setblock 104 56 -338 minecraft:water[level=0]
setblock 105 56 -338 minecraft:tall_seagrass[half=lower]
fill 106 56 -338 111 56 -338 minecraft:water[level=0]
setblock 112 56 -338 minecraft:seagrass
setblock 113 56 -338 minecraft:water[level=0]
setblock 105 56 -339 minecraft:water[level=0]
setblock 106 56 -339 minecraft:seagrass
setblock 107 56 -339 minecraft:tall_seagrass[half=lower]
fill 108 56 -339 110 56 -339 minecraft:water[level=0]
fill 111 56 -339 112 56 -339 minecraft:seagrass
setblock 106 56 -340 minecraft:seagrass
setblock 107 56 -340 minecraft:tall_seagrass[half=lower]
setblock 108 56 -340 minecraft:water[level=0]
setblock 109 56 -340 minecraft:seagrass
fill 110 56 -340 111 56 -340 minecraft:water[level=0]
setblock 112 56 -340 minecraft:seagrass
setblock 105 56 -341 minecraft:seagrass
setblock 106 56 -341 minecraft:tall_seagrass[half=lower]
fill 107 56 -341 108 56 -341 minecraft:water[level=0]
setblock 109 56 -341 minecraft:seagrass
setblock 110 56 -341 minecraft:water[level=0]
fill 111 56 -341 112 56 -341 minecraft:seagrass
fill 92 56 -342 96 56 -342 minecraft:water[level=0]
fill 104 56 -342 112 56 -342 minecraft:water[level=0]
fill 91 56 -343 97 56 -343 minecraft:water[level=0]
setblock 103 56 -343 minecraft:water[level=0]
fill 104 56 -343 105 56 -343 minecraft:tall_seagrass[half=lower]
fill 106 56 -343 110 56 -343 minecraft:water[level=0]
fill 111 56 -343 112 56 -343 minecraft:seagrass
setblock 113 56 -343 minecraft:water[level=0]
fill 87 56 -344 98 56 -344 minecraft:water[level=0]
fill 102 56 -344 104 56 -344 minecraft:water[level=0]
setblock 105 56 -344 minecraft:seagrass
fill 106 56 -344 107 56 -344 minecraft:water[level=0]
fill 108 56 -344 109 56 -344 minecraft:tall_seagrass[half=lower]
fill 110 56 -344 111 56 -344 minecraft:water[level=0]
fill 112 56 -344 113 56 -344 minecraft:tall_seagrass[half=lower]
fill 86 56 -345 103 56 -345 minecraft:water[level=0]
setblock 104 56 -345 minecraft:tall_seagrass[half=lower]
setblock 105 56 -345 minecraft:water[level=0]
setblock 106 56 -345 minecraft:tall_seagrass[half=lower]
setblock 107 56 -345 minecraft:seagrass
fill 108 56 -345 112 56 -345 minecraft:water[level=0]
setblock 113 56 -345 minecraft:seagrass
fill 85 56 -346 105 56 -346 minecraft:water[level=0]
setblock 106 56 -346 minecraft:seagrass
fill 107 56 -346 110 56 -346 minecraft:water[level=0]
setblock 111 56 -346 minecraft:seagrass
setblock 112 56 -346 minecraft:water[level=0]
fill 83 56 -347 112 56 -347 minecraft:water[level=0]
fill 79 56 -348 109 56 -348 minecraft:water[level=0]
setblock 110 56 -348 minecraft:tall_seagrass[half=lower]
fill 111 56 -348 112 56 -348 minecraft:water[level=0]
fill 79 56 -349 110 56 -349 minecraft:water[level=0]
setblock 111 56 -349 minecraft:seagrass
setblock 112 56 -349 minecraft:water[level=0]
fill 78 56 -350 111 56 -350 minecraft:water[level=0]
fill 77 56 -351 111 56 -351 minecraft:water[level=0]
fill 76 56 -352 111 56 -352 minecraft:water[level=0]
fill 74 56 -353 110 56 -353 minecraft:water[level=0]
fill 72 56 -354 79 56 -354 minecraft:water[level=0]
fill 81 56 -354 110 56 -354 minecraft:water[level=0]
fill 72 56 -355 79 56 -355 minecraft:water[level=0]
fill 83 56 -355 110 56 -355 minecraft:water[level=0]
fill 72 56 -356 78 56 -356 minecraft:water[level=0]
fill 84 56 -356 88 56 -356 minecraft:water[level=0]
setblock 89 56 -356 minecraft:tall_seagrass[half=lower]
fill 90 56 -356 110 56 -356 minecraft:water[level=0]
fill 72 56 -357 78 56 -357 minecraft:water[level=0]
setblock 79 56 -357 minecraft:tall_seagrass[half=lower]
fill 85 56 -357 111 56 -357 minecraft:water[level=0]
fill 72 56 -358 80 56 -358 minecraft:water[level=0]
fill 85 56 -358 86 56 -358 minecraft:water[level=0]
setblock 87 56 -358 minecraft:seagrass
fill 88 56 -358 109 56 -358 minecraft:water[level=0]
setblock 110 56 -358 minecraft:tall_seagrass[half=upper]
fill 111 56 -358 112 56 -358 minecraft:water[level=0]
fill 72 56 -359 79 56 -359 minecraft:water[level=0]
setblock 80 56 -359 minecraft:seagrass
setblock 81 56 -359 minecraft:water[level=0]
fill 85 56 -359 87 56 -359 minecraft:water[level=0]
setblock 88 56 -359 minecraft:tall_seagrass[half=upper]
fill 89 56 -359 112 56 -359 minecraft:water[level=0]
fill 72 56 -360 79 56 -360 minecraft:water[level=0]
setblock 80 56 -360 minecraft:tall_seagrass[half=lower]
fill 81 56 -360 82 56 -360 minecraft:water[level=0]
fill 85 56 -360 112 56 -360 minecraft:water[level=0]
setblock 113 56 -360 minecraft:seagrass
fill 72 56 -361 81 56 -361 minecraft:water[level=0]
setblock 82 56 -361 minecraft:seagrass
fill 83 56 -361 110 56 -361 minecraft:water[level=0]
setblock 111 56 -361 minecraft:tall_seagrass[half=upper]
fill 112 56 -361 113 56 -361 minecraft:water[level=0]
setblock 114 56 -361 minecraft:seagrass
fill 72 56 -362 111 56 -362 minecraft:water[level=0]
setblock 112 56 -362 minecraft:tall_seagrass[half=upper]
fill 113 56 -362 114 56 -362 minecraft:water[level=0]
setblock 72 56 -363 minecraft:kelp[age=25]
setblock 73 56 -363 minecraft:water[level=0]
setblock 74 56 -363 minecraft:kelp_plant
fill 75 56 -363 77 56 -363 minecraft:water[level=0]
setblock 78 56 -363 minecraft:kelp_plant
fill 79 56 -363 115 56 -363 minecraft:water[level=0]
fill 72 56 -364 73 56 -364 minecraft:water[level=0]
setblock 74 56 -364 minecraft:kelp[age=25]
fill 75 56 -364 114 56 -364 minecraft:water[level=0]
setblock 115 56 -364 minecraft:seagrass
setblock 116 56 -364 minecraft:water[level=0]
fill 72 56 -365 115 56 -365 minecraft:water[level=0]
setblock 116 56 -365 minecraft:seagrass
setblock 117 56 -365 minecraft:water[level=0]
fill 72 56 -366 114 56 -366 minecraft:water[level=0]
setblock 115 56 -366 minecraft:tall_seagrass[half=upper]
setblock 116 56 -366 minecraft:water[level=0]
setblock 117 56 -366 minecraft:seagrass
fill 72 56 -367 114 56 -367 minecraft:water[level=0]
setblock 115 56 -367 minecraft:tall_seagrass[half=upper]
setblock 116 56 -367 minecraft:tall_seagrass[half=lower]
setblock 117 56 -367 minecraft:water[level=0]
setblock 118 56 -367 minecraft:tall_seagrass[half=lower]
fill 72 56 -368 120 56 -368 minecraft:water[level=0]
fill 72 56 -369 120 56 -369 minecraft:water[level=0]
setblock 121 56 -369 minecraft:seagrass
setblock 122 56 -369 minecraft:water[level=0]
fill 72 56 -370 83 56 -370 minecraft:water[level=0]
setblock 84 56 -370 minecraft:kelp_plant
setblock 85 56 -370 minecraft:water[level=0]
setblock 86 56 -370 minecraft:kelp_plant
fill 87 56 -370 91 56 -370 minecraft:water[level=0]
setblock 92 56 -370 minecraft:kelp_plant
fill 93 56 -370 120 56 -370 minecraft:water[level=0]
setblock 121 56 -370 minecraft:tall_seagrass[half=upper]
fill 122 56 -370 123 56 -370 minecraft:water[level=0]
setblock 124 56 -370 minecraft:tall_seagrass[half=lower]
fill 72 56 -371 122 56 -371 minecraft:water[level=0]
setblock 123 56 -371 minecraft:tall_seagrass[half=upper]
setblock 124 56 -371 minecraft:water[level=0]
setblock 125 56 -371 minecraft:seagrass
fill 72 56 -372 124 56 -372 minecraft:water[level=0]
setblock 125 56 -372 minecraft:tall_seagrass[half=lower]
setblock 126 56 -372 minecraft:water[level=0]
fill 72 56 -373 82 56 -373 minecraft:water[level=0]
setblock 83 56 -373 minecraft:kelp_plant
fill 84 56 -373 88 56 -373 minecraft:water[level=0]
setblock 89 56 -373 minecraft:kelp[age=25]
fill 90 56 -373 124 56 -373 minecraft:water[level=0]
setblock 125 56 -373 minecraft:tall_seagrass[half=upper]
setblock 126 56 -373 minecraft:seagrass
setblock 127 56 -373 minecraft:water[level=0]
fill 72 56 -374 125 56 -374 minecraft:water[level=0]
setblock 126 56 -374 minecraft:seagrass
setblock 127 56 -374 minecraft:water[level=0]
fill 134 56 -374 135 56 -374 minecraft:water[level=0]
fill 72 56 -375 126 56 -375 minecraft:water[level=0]
setblock 127 56 -375 minecraft:tall_seagrass[half=lower]
fill 128 56 -375 135 56 -375 minecraft:water[level=0]
fill 72 56 -376 125 56 -376 minecraft:water[level=0]
setblock 126 56 -376 minecraft:tall_seagrass[half=upper]
fill 127 56 -376 130 56 -376 minecraft:water[level=0]
setblock 131 56 -376 minecraft:seagrass
fill 132 56 -376 135 56 -376 minecraft:water[level=0]
fill 72 56 -377 89 56 -377 minecraft:water[level=0]
setblock 90 56 -377 minecraft:kelp_plant
fill 91 56 -377 135 56 -377 minecraft:water[level=0]
fill 72 56 -378 84 56 -378 minecraft:water[level=0]
setblock 85 56 -378 minecraft:kelp_plant
fill 86 56 -378 135 56 -378 minecraft:water[level=0]
fill 72 56 -379 83 56 -379 minecraft:water[level=0]
setblock 84 56 -379 minecraft:kelp[age=25]
fill 85 56 -379 135 56 -379 minecraft:water[level=0]
fill 72 56 -380 85 56 -380 minecraft:water[level=0]
setblock 86 56 -380 minecraft:kelp_plant
fill 87 56 -380 90 56 -380 minecraft:water[level=0]
setblock 91 56 -380 minecraft:kelp_plant
fill 92 56 -380 135 56 -380 minecraft:water[level=0]
fill 72 56 -381 82 56 -381 minecraft:water[level=0]
setblock 83 56 -381 minecraft:kelp_plant
fill 84 56 -381 135 56 -381 minecraft:water[level=0]
fill 72 56 -382 135 56 -382 minecraft:water[level=0]
setblock 99 55 -319 minecraft:seagrass
setblock 100 55 -319 minecraft:water[level=0]
setblock 101 55 -319 minecraft:seagrass
fill 99 55 -320 101 55 -320 minecraft:water[level=0]
setblock 99 55 -321 minecraft:seagrass
fill 100 55 -321 101 55 -321 minecraft:water[level=0]
setblock 99 55 -322 minecraft:seagrass
fill 100 55 -322 101 55 -322 minecraft:water[level=0]
fill 100 55 -323 101 55 -323 minecraft:water[level=0]
fill 100 55 -324 101 55 -324 minecraft:water[level=0]
fill 100 55 -325 101 55 -325 minecraft:water[level=0]
setblock 100 55 -326 minecraft:water[level=0]
setblock 101 55 -326 minecraft:tall_seagrass[half=lower]
fill 100 55 -327 101 55 -327 minecraft:water[level=0]
setblock 100 55 -328 minecraft:water[level=0]
setblock 104 55 -329 minecraft:tall_seagrass[half=lower]
fill 103 55 -330 104 55 -330 minecraft:water[level=0]
fill 103 55 -331 104 55 -331 minecraft:water[level=0]
fill 103 55 -332 104 55 -332 minecraft:water[level=0]
setblock 105 55 -332 minecraft:seagrass
fill 104 55 -333 105 55 -333 minecraft:water[level=0]
fill 104 55 -334 105 55 -334 minecraft:water[level=0]
setblock 106 55 -334 minecraft:seagrass
setblock 104 55 -335 minecraft:water[level=0]
setblock 105 55 -335 minecraft:tall_seagrass[half=lower]
fill 106 55 -335 108 55 -335 minecraft:water[level=0]
fill 104 55 -336 105 55 -336 minecraft:water[level=0]
setblock 106 55 -336 minecraft:seagrass
fill 107 55 -336 109 55 -336 minecraft:water[level=0]
setblock 110 55 -336 minecraft:seagrass
setblock 107 55 -337 minecraft:seagrass
setblock 108 55 -337 minecraft:tall_seagrass[half=lower]
setblock 109 55 -337 minecraft:water[level=0]
setblock 108 55 -338 minecraft:water[level=0]
fill 107 55 -346 108 55 -346 minecraft:water[level=0]
setblock 109 55 -346 minecraft:seagrass
fill 91 55 -347 97 55 -347 minecraft:water[level=0]
fill 105 55 -347 109 55 -347 minecraft:water[level=0]
fill 89 55 -348 109 55 -348 minecraft:water[level=0]
fill 90 55 -349 109 55 -349 minecraft:water[level=0]
fill 90 55 -350 109 55 -350 minecraft:water[level=0]
fill 91 55 -351 109 55 -351 minecraft:water[level=0]
setblock 92 55 -352 minecraft:water[level=0]
fill 97 55 -352 109 55 -352 minecraft:water[level=0]
fill 92 55 -353 109 55 -353 minecraft:water[level=0]
fill 72 55 -354 73 55 -354 minecraft:water[level=0]
fill 92 55 -354 109 55 -354 minecraft:water[level=0]
fill 72 55 -355 75 55 -355 minecraft:water[level=0]
fill 92 55 -355 109 55 -355 minecraft:water[level=0]
fill 72 55 -356 76 55 -356 minecraft:water[level=0]
fill 92 55 -356 108 55 -356 minecraft:water[level=0]
setblock 109 55 -356 minecraft:seagrass
fill 72 55 -357 77 55 -357 minecraft:water[level=0]
fill 90 55 -357 109 55 -357 minecraft:water[level=0]
fill 72 55 -358 78 55 -358 minecraft:water[level=0]
fill 89 55 -358 109 55 -358 minecraft:water[level=0]
setblock 110 55 -358 minecraft:tall_seagrass[half=lower]
fill 72 55 -359 78 55 -359 minecraft:water[level=0]
setblock 88 55 -359 minecraft:tall_seagrass[half=lower]
fill 89 55 -359 111 55 -359 minecraft:water[level=0]
fill 72 55 -360 78 55 -360 minecraft:water[level=0]
fill 87 55 -360 111 55 -360 minecraft:water[level=0]
fill 72 55 -361 79 55 -361 minecraft:water[level=0]
setblock 86 55 -361 minecraft:seagrass
fill 87 55 -361 110 55 -361 minecraft:water[level=0]
setblock 111 55 -361 minecraft:tall_seagrass[half=lower]
setblock 112 55 -361 minecraft:water[level=0]
fill 72 55 -362 82 55 -362 minecraft:water[level=0]
setblock 83 55 -362 minecraft:seagrass
setblock 84 55 -362 minecraft:water[level=0]
setblock 85 55 -362 minecraft:seagrass
fill 86 55 -362 111 55 -362 minecraft:water[level=0]
setblock 112 55 -362 minecraft:tall_seagrass[half=lower]
setblock 113 55 -362 minecraft:seagrass
setblock 72 55 -363 minecraft:kelp_plant
setblock 73 55 -363 minecraft:water[level=0]
setblock 74 55 -363 minecraft:kelp_plant
fill 75 55 -363 77 55 -363 minecraft:water[level=0]
setblock 78 55 -363 minecraft:kelp_plant
fill 79 55 -363 82 55 -363 minecraft:water[level=0]
setblock 83 55 -363 minecraft:tall_seagrass[half=upper]
fill 84 55 -363 113 55 -363 minecraft:water[level=0]
fill 72 55 -364 73 55 -364 minecraft:water[level=0]
setblock 74 55 -364 minecraft:kelp_plant
fill 75 55 -364 114 55 -364 minecraft:water[level=0]
fill 72 55 -365 113 55 -365 minecraft:water[level=0]
setblock 114 55 -365 minecraft:tall_seagrass[half=upper]
setblock 115 55 -365 minecraft:water[level=0]
setblock 72 55 -366 minecraft:kelp[age=25]
fill 73 55 -366 114 55 -366 minecraft:water[level=0]
setblock 115 55 -366 minecraft:tall_seagrass[half=lower]
fill 72 55 -367 114 55 -367 minecraft:water[level=0]
setblock 115 55 -367 minecraft:tall_seagrass[half=lower]
fill 72 55 -368 115 55 -368 minecraft:water[level=0]
fill 72 55 -369 116 55 -369 minecraft:water[level=0]
setblock 117 55 -369 minecraft:seagrass
fill 118 55 -369 119 55 -369 minecraft:water[level=0]
fill 72 55 -370 83 55 -370 minecraft:water[level=0]
setblock 84 55 -370 minecraft:kelp_plant
setblock 85 55 -370 minecraft:water[level=0]
setblock 86 55 -370 minecraft:kelp_plant
fill 87 55 -370 91 55 -370 minecraft:water[level=0]
setblock 92 55 -370 minecraft:kelp_plant
fill 93 55 -370 120 55 -370 minecraft:water[level=0]
setblock 121 55 -370 minecraft:tall_seagrass[half=lower]
fill 72 55 -371 120 55 -371 minecraft:water[level=0]
setblock 121 55 -371 minecraft:tall_seagrass[half=upper]
setblock 122 55 -371 minecraft:water[level=0]
setblock 123 55 -371 minecraft:tall_seagrass[half=lower]
fill 72 55 -372 124 55 -372 minecraft:water[level=0]
fill 72 55 -373 79 55 -373 minecraft:water[level=0]
setblock 80 55 -373 minecraft:kelp[age=25]
fill 81 55 -373 82 55 -373 minecraft:water[level=0]
setblock 83 55 -373 minecraft:kelp_plant
fill 84 55 -373 88 55 -373 minecraft:water[level=0]
setblock 89 55 -373 minecraft:kelp_plant
fill 90 55 -373 122 55 -373 minecraft:water[level=0]
setblock 123 55 -373 minecraft:tall_seagrass[half=upper]
setblock 124 55 -373 minecraft:water[level=0]
setblock 125 55 -373 minecraft:tall_seagrass[half=lower]
fill 72 55 -374 125 55 -374 minecraft:water[level=0]
fill 72 55 -375 126 55 -375 minecraft:water[level=0]
fill 72 55 -376 92 55 -376 minecraft:water[level=0]
setblock 93 55 -376 minecraft:kelp[age=25]
fill 94 55 -376 125 55 -376 minecraft:water[level=0]
setblock 126 55 -376 minecraft:tall_seagrass[half=lower]
setblock 127 55 -376 minecraft:water[level=0]
fill 72 55 -377 89 55 -377 minecraft:water[level=0]
setblock 90 55 -377 minecraft:kelp_plant
fill 91 55 -377 127 55 -377 minecraft:water[level=0]
fill 72 55 -378 84 55 -378 minecraft:water[level=0]
setblock 85 55 -378 minecraft:kelp_plant
fill 86 55 -378 128 55 -378 minecraft:water[level=0]
setblock 129 55 -378 minecraft:seagrass
setblock 130 55 -378 minecraft:water[level=0]
fill 72 55 -379 83 55 -379 minecraft:water[level=0]
setblock 84 55 -379 minecraft:kelp_plant
fill 85 55 -379 95 55 -379 minecraft:water[level=0]
setblock 96 55 -379 minecraft:kelp[age=25]
fill 97 55 -379 126 55 -379 minecraft:water[level=0]
setblock 127 55 -379 minecraft:tall_seagrass[half=upper]
setblock 128 55 -379 minecraft:water[level=0]
setblock 129 55 -379 minecraft:seagrass
setblock 130 55 -379 minecraft:water[level=0]
setblock 131 55 -379 minecraft:seagrass
fill 132 55 -379 135 55 -379 minecraft:water[level=0]
fill 72 55 -380 85 55 -380 minecraft:water[level=0]
setblock 86 55 -380 minecraft:kelp_plant
fill 87 55 -380 90 55 -380 minecraft:water[level=0]
setblock 91 55 -380 minecraft:kelp_plant
fill 92 55 -380 135 55 -380 minecraft:water[level=0]
fill 72 55 -381 82 55 -381 minecraft:water[level=0]
setblock 83 55 -381 minecraft:kelp_plant
fill 84 55 -381 135 55 -381 minecraft:water[level=0]
fill 72 55 -382 135 55 -382 minecraft:water[level=0]
fill 107 54 -351 108 54 -351 minecraft:water[level=0]
fill 105 54 -352 108 54 -352 minecraft:water[level=0]
fill 104 54 -353 108 54 -353 minecraft:water[level=0]
fill 103 54 -354 108 54 -354 minecraft:water[level=0]
fill 72 54 -355 73 54 -355 minecraft:water[level=0]
fill 102 54 -355 108 54 -355 minecraft:water[level=0]
fill 72 54 -356 74 54 -356 minecraft:water[level=0]
fill 102 54 -356 106 54 -356 minecraft:water[level=0]
setblock 107 54 -356 minecraft:seagrass
setblock 108 54 -356 minecraft:water[level=0]
fill 72 54 -357 75 54 -357 minecraft:water[level=0]
fill 96 54 -357 97 54 -357 minecraft:water[level=0]
fill 101 54 -357 108 54 -357 minecraft:water[level=0]
fill 72 54 -358 75 54 -358 minecraft:water[level=0]
fill 92 54 -358 109 54 -358 minecraft:water[level=0]
fill 72 54 -359 76 54 -359 minecraft:water[level=0]
fill 91 54 -359 107 54 -359 minecraft:water[level=0]
setblock 108 54 -359 minecraft:tall_seagrass[half=upper]
setblock 109 54 -359 minecraft:seagrass
fill 72 54 -360 77 54 -360 minecraft:water[level=0]
fill 89 54 -360 110 54 -360 minecraft:water[level=0]
fill 72 54 -361 78 54 -361 minecraft:water[level=0]
setblock 88 54 -361 minecraft:water[level=0]
setblock 89 54 -361 minecraft:seagrass
fill 90 54 -361 110 54 -361 minecraft:water[level=0]
fill 72 54 -362 78 54 -362 minecraft:water[level=0]
setblock 79 54 -362 minecraft:seagrass
setblock 87 54 -362 minecraft:seagrass
fill 88 54 -362 109 54 -362 minecraft:water[level=0]
setblock 110 54 -362 minecraft:seagrass
setblock 111 54 -362 minecraft:water[level=0]
setblock 72 54 -363 minecraft:kelp_plant
setblock 73 54 -363 minecraft:water[level=0]
setblock 74 54 -363 minecraft:kelp_plant
setblock 75 54 -363 minecraft:water[level=0]
setblock 76 54 -363 minecraft:kelp[age=25]
setblock 77 54 -363 minecraft:water[level=0]
setblock 78 54 -363 minecraft:kelp_plant
fill 79 54 -363 81 54 -363 minecraft:water[level=0]
setblock 82 54 -363 minecraft:tall_seagrass[half=upper]
setblock 83 54 -363 minecraft:tall_seagrass[half=lower]
fill 84 54 -363 85 54 -363 minecraft:water[level=0]
setblock 86 54 -363 minecraft:tall_seagrass[half=upper]
fill 87 54 -363 110 54 -363 minecraft:water[level=0]
setblock 111 54 -363 minecraft:seagrass
setblock 113 54 -363 minecraft:water[level=0]
fill 72 54 -364 73 54 -364 minecraft:water[level=0]
setblock 74 54 -364 minecraft:kelp_plant
fill 75 54 -364 110 54 -364 minecraft:water[level=0]
setblock 111 54 -364 minecraft:tall_seagrass[half=upper]
fill 112 54 -364 113 54 -364 minecraft:water[level=0]
setblock 114 54 -364 minecraft:tall_seagrass[half=upper]
fill 72 54 -365 110 54 -365 minecraft:water[level=0]
setblock 111 54 -365 minecraft:tall_seagrass[half=upper]
setblock 112 54 -365 minecraft:water[level=0]
setblock 113 54 -365 minecraft:tall_seagrass[half=upper]
setblock 114 54 -365 minecraft:tall_seagrass[half=lower]
setblock 72 54 -366 minecraft:kelp_plant
fill 73 54 -366 77 54 -366 minecraft:water[level=0]
setblock 78 54 -366 minecraft:kelp[age=25]
fill 79 54 -366 114 54 -366 minecraft:water[level=0]
fill 72 54 -367 114 54 -367 minecraft:water[level=0]
fill 72 54 -368 115 54 -368 minecraft:water[level=0]
fill 72 54 -369 115 54 -369 minecraft:water[level=0]
setblock 116 54 -369 minecraft:seagrass
fill 72 54 -370 83 54 -370 minecraft:water[level=0]
setblock 84 54 -370 minecraft:kelp_plant
setblock 85 54 -370 minecraft:water[level=0]
setblock 86 54 -370 minecraft:kelp_plant
fill 87 54 -370 91 54 -370 minecraft:water[level=0]
setblock 92 54 -370 minecraft:kelp_plant
fill 93 54 -370 119 54 -370 minecraft:water[level=0]
fill 72 54 -371 120 54 -371 minecraft:water[level=0]
setblock 121 54 -371 minecraft:tall_seagrass[half=lower]
fill 72 54 -372 123 54 -372 minecraft:water[level=0]
fill 72 54 -373 79 54 -373 minecraft:water[level=0]
setblock 80 54 -373 minecraft:kelp_plant
fill 81 54 -373 82 54 -373 minecraft:water[level=0]
setblock 83 54 -373 minecraft:kelp_plant
fill 84 54 -373 88 54 -373 minecraft:water[level=0]
setblock 89 54 -373 minecraft:kelp_plant
fill 90 54 -373 122 54 -373 minecraft:water[level=0]
setblock 123 54 -373 minecraft:tall_seagrass[half=lower]
setblock 124 54 -373 minecraft:seagrass
fill 72 54 -374 122 54 -374 minecraft:water[level=0]
setblock 123 54 -374 minecraft:tall_seagrass[half=upper]
setblock 124 54 -374 minecraft:seagrass
fill 72 54 -375 85 54 -375 minecraft:water[level=0]
setblock 86 54 -375 minecraft:kelp[age=23]
fill 87 54 -375 124 54 -375 minecraft:water[level=0]
setblock 125 54 -375 minecraft:seagrass
fill 72 54 -376 92 54 -376 minecraft:water[level=0]
setblock 93 54 -376 minecraft:kelp_plant
fill 94 54 -376 125 54 -376 minecraft:water[level=0]
fill 72 54 -377 89 54 -377 minecraft:water[level=0]
setblock 90 54 -377 minecraft:kelp_plant
fill 91 54 -377 126 54 -377 minecraft:water[level=0]
fill 72 54 -378 84 54 -378 minecraft:water[level=0]
setblock 85 54 -378 minecraft:kelp_plant
fill 86 54 -378 126 54 -378 minecraft:water[level=0]
fill 72 54 -379 83 54 -379 minecraft:water[level=0]
setblock 84 54 -379 minecraft:kelp_plant
fill 85 54 -379 95 54 -379 minecraft:water[level=0]
setblock 96 54 -379 minecraft:kelp_plant
fill 97 54 -379 126 54 -379 minecraft:water[level=0]
setblock 127 54 -379 minecraft:tall_seagrass[half=lower]
fill 72 54 -380 85 54 -380 minecraft:water[level=0]
setblock 86 54 -380 minecraft:kelp_plant
fill 87 54 -380 90 54 -380 minecraft:water[level=0]
setblock 91 54 -380 minecraft:kelp_plant
fill 92 54 -380 129 54 -380 minecraft:water[level=0]
fill 72 54 -381 82 54 -381 minecraft:water[level=0]
setblock 83 54 -381 minecraft:kelp_plant
fill 84 54 -381 125 54 -381 minecraft:water[level=0]
setblock 126 54 -381 minecraft:tall_seagrass[half=upper]
fill 127 54 -381 129 54 -381 minecraft:water[level=0]
fill 72 54 -382 128 54 -382 minecraft:water[level=0]
setblock 72 53 -355 minecraft:water[level=0]
fill 72 53 -356 74 53 -356 minecraft:water[level=0]
fill 72 53 -357 75 53 -357 minecraft:water[level=0]
fill 104 53 -357 105 53 -357 minecraft:water[level=0]
setblock 106 53 -357 minecraft:seagrass
fill 72 53 -358 75 53 -358 minecraft:water[level=0]
fill 103 53 -358 108 53 -358 minecraft:water[level=0]
fill 72 53 -359 76 53 -359 minecraft:water[level=0]
fill 93 53 -359 98 53 -359 minecraft:water[level=0]
fill 102 53 -359 107 53 -359 minecraft:water[level=0]
setblock 108 53 -359 minecraft:tall_seagrass[half=lower]
fill 72 53 -360 77 53 -360 minecraft:water[level=0]
fill 91 53 -360 99 53 -360 minecraft:water[level=0]
fill 101 53 -360 108 53 -360 minecraft:water[level=0]
fill 72 53 -361 77 53 -361 minecraft:water[level=0]
fill 90 53 -361 106 53 -361 minecraft:water[level=0]
setblock 107 53 -361 minecraft:tall_seagrass[half=upper]
fill 108 53 -361 109 53 -361 minecraft:water[level=0]
fill 72 53 -362 78 53 -362 minecraft:water[level=0]
fill 88 53 -362 108 53 -362 minecraft:water[level=0]
setblock 109 53 -362 minecraft:seagrass
fill 113 53 -362 114 53 -362 minecraft:water[level=0]
setblock 72 53 -363 minecraft:kelp_plant
setblock 73 53 -363 minecraft:water[level=0]
setblock 74 53 -363 minecraft:kelp_plant
setblock 75 53 -363 minecraft:water[level=0]
setblock 76 53 -363 minecraft:kelp_plant
setblock 77 53 -363 minecraft:water[level=0]
setblock 78 53 -363 minecraft:kelp_plant
setblock 79 53 -363 minecraft:water[level=0]
setblock 80 53 -363 minecraft:seagrass
setblock 81 53 -363 minecraft:water[level=0]
setblock 82 53 -363 minecraft:tall_seagrass[half=lower]
setblock 85 53 -363 minecraft:water[level=0]
setblock 86 53 -363 minecraft:tall_seagrass[half=lower]
fill 87 53 -363 108 53 -363 minecraft:water[level=0]
setblock 109 53 -363 minecraft:tall_seagrass[half=upper]
setblock 110 53 -363 minecraft:water[level=0]
fill 112 53 -363 114 53 -363 minecraft:water[level=0]
fill 72 53 -364 73 53 -364 minecraft:water[level=0]
setblock 74 53 -364 minecraft:kelp_plant
fill 75 53 -364 109 53 -364 minecraft:water[level=0]
setblock 110 53 -364 minecraft:seagrass
setblock 111 53 -364 minecraft:tall_seagrass[half=lower]
setblock 112 53 -364 minecraft:seagrass
setblock 113 53 -364 minecraft:water[level=0]
setblock 114 53 -364 minecraft:tall_seagrass[half=lower]
fill 72 53 -365 109 53 -365 minecraft:water[level=0]
setblock 110 53 -365 minecraft:tall_seagrass[half=upper]
setblock 111 53 -365 minecraft:tall_seagrass[half=lower]
setblock 112 53 -365 minecraft:water[level=0]
setblock 113 53 -365 minecraft:tall_seagrass[half=lower]
setblock 72 53 -366 minecraft:kelp_plant
fill 73 53 -366 77 53 -366 minecraft:water[level=0]
setblock 78 53 -366 minecraft:kelp_plant
setblock 79 53 -366 minecraft:kelp[age=25]
fill 80 53 -366 112 53 -366 minecraft:water[level=0]
setblock 113 53 -366 minecraft:seagrass
fill 72 53 -367 114 53 -367 minecraft:water[level=0]
fill 72 53 -368 114 53 -368 minecraft:water[level=0]
fill 72 53 -369 115 53 -369 minecraft:water[level=0]
fill 72 53 -370 83 53 -370 minecraft:water[level=0]
setblock 84 53 -370 minecraft:kelp_plant
setblock 85 53 -370 minecraft:water[level=0]
setblock 86 53 -370 minecraft:kelp_plant
fill 87 53 -370 91 53 -370 minecraft:water[level=0]
setblock 92 53 -370 minecraft:kelp_plant
fill 93 53 -370 117 53 -370 minecraft:water[level=0]
fill 72 53 -371 117 53 -371 minecraft:water[level=0]
setblock 118 53 -371 minecraft:tall_seagrass[half=upper]
setblock 119 53 -371 minecraft:water[level=0]
fill 72 53 -372 121 53 -372 minecraft:water[level=0]
fill 72 53 -373 79 53 -373 minecraft:water[level=0]
setblock 80 53 -373 minecraft:kelp_plant
fill 81 53 -373 82 53 -373 minecraft:water[level=0]
setblock 83 53 -373 minecraft:kelp_plant
fill 84 53 -373 88 53 -373 minecraft:water[level=0]
setblock 89 53 -373 minecraft:kelp_plant
fill 90 53 -373 121 53 -373 minecraft:water[level=0]
setblock 122 53 -373 minecraft:seagrass
fill 72 53 -374 122 53 -374 minecraft:water[level=0]
setblock 123 53 -374 minecraft:tall_seagrass[half=lower]
fill 72 53 -375 85 53 -375 minecraft:water[level=0]
setblock 86 53 -375 minecraft:kelp_plant
fill 87 53 -375 124 53 -375 minecraft:water[level=0]
fill 72 53 -376 92 53 -376 minecraft:water[level=0]
setblock 93 53 -376 minecraft:kelp_plant
fill 94 53 -376 121 53 -376 minecraft:water[level=0]
setblock 122 53 -376 minecraft:tall_seagrass[half=upper]
fill 123 53 -376 124 53 -376 minecraft:water[level=0]
setblock 125 53 -376 minecraft:seagrass
fill 72 53 -377 89 53 -377 minecraft:water[level=0]
setblock 90 53 -377 minecraft:kelp_plant
fill 91 53 -377 122 53 -377 minecraft:water[level=0]
setblock 123 53 -377 minecraft:tall_seagrass[half=upper]
fill 124 53 -377 125 53 -377 minecraft:water[level=0]
fill 72 53 -378 84 53 -378 minecraft:water[level=0]
setblock 85 53 -378 minecraft:kelp_plant
fill 86 53 -378 96 53 -378 minecraft:water[level=0]
setblock 97 53 -378 minecraft:kelp[age=25]
fill 98 53 -378 125 53 -378 minecraft:water[level=0]
fill 72 53 -379 83 53 -379 minecraft:water[level=0]
setblock 84 53 -379 minecraft:kelp_plant
fill 85 53 -379 95 53 -379 minecraft:water[level=0]
setblock 96 53 -379 minecraft:kelp_plant
fill 97 53 -379 126 53 -379 minecraft:water[level=0]
fill 72 53 -380 85 53 -380 minecraft:water[level=0]
setblock 86 53 -380 minecraft:kelp_plant
fill 87 53 -380 90 53 -380 minecraft:water[level=0]
setblock 91 53 -380 minecraft:kelp_plant
fill 92 53 -380 127 53 -380 minecraft:water[level=0]
fill 72 53 -381 82 53 -381 minecraft:water[level=0]
setblock 83 53 -381 minecraft:kelp_plant
fill 84 53 -381 125 53 -381 minecraft:water[level=0]
setblock 126 53 -381 minecraft:tall_seagrass[half=lower]
fill 72 53 -382 125 53 -382 minecraft:water[level=0]
setblock 76 52 -351 minecraft:water[level=0]
fill 75 52 -352 76 52 -352 minecraft:water[level=0]
fill 74 52 -353 76 52 -353 minecraft:water[level=0]
fill 73 52 -354 77 52 -354 minecraft:water[level=0]
fill 72 52 -355 76 52 -355 minecraft:water[level=0]
fill 72 52 -356 76 52 -356 minecraft:water[level=0]
fill 72 52 -357 76 52 -357 minecraft:water[level=0]
fill 72 52 -358 76 52 -358 minecraft:water[level=0]
setblock 104 52 -358 minecraft:water[level=0]
fill 72 52 -359 75 52 -359 minecraft:water[level=0]
setblock 96 52 -359 minecraft:water[level=0]
fill 103 52 -359 106 52 -359 minecraft:water[level=0]
fill 72 52 -360 76 52 -360 minecraft:water[level=0]
fill 93 52 -360 97 52 -360 minecraft:water[level=0]
fill 103 52 -360 108 52 -360 minecraft:water[level=0]
fill 72 52 -361 77 52 -361 minecraft:water[level=0]
fill 92 52 -361 98 52 -361 minecraft:water[level=0]
fill 102 52 -361 105 52 -361 minecraft:water[level=0]
setblock 106 52 -361 minecraft:tall_seagrass[half=upper]
setblock 107 52 -361 minecraft:tall_seagrass[half=lower]
setblock 108 52 -361 minecraft:water[level=0]
fill 113 52 -361 114 52 -361 minecraft:water[level=0]
fill 72 52 -362 77 52 -362 minecraft:water[level=0]
fill 90 52 -362 99 52 -362 minecraft:water[level=0]
fill 101 52 -362 108 52 -362 minecraft:water[level=0]
fill 112 52 -362 114 52 -362 minecraft:water[level=0]
setblock 72 52 -363 minecraft:kelp_plant
setblock 73 52 -363 minecraft:water[level=0]
setblock 74 52 -363 minecraft:kelp_plant
setblock 75 52 -363 minecraft:water[level=0]
setblock 76 52 -363 minecraft:kelp_plant
setblock 77 52 -363 minecraft:water[level=0]
setblock 78 52 -363 minecraft:kelp_plant
setblock 79 52 -363 minecraft:seagrass
fill 88 52 -363 108 52 -363 minecraft:water[level=0]
setblock 109 52 -363 minecraft:tall_seagrass[half=lower]
fill 112 52 -363 114 52 -363 minecraft:water[level=0]
fill 72 52 -364 73 52 -364 minecraft:water[level=0]
setblock 74 52 -364 minecraft:kelp_plant
fill 75 52 -364 104 52 -364 minecraft:water[level=0]
setblock 105 52 -364 minecraft:tall_seagrass[half=upper]
fill 106 52 -364 109 52 -364 minecraft:water[level=0]
setblock 113 52 -364 minecraft:seagrass
fill 72 52 -365 109 52 -365 minecraft:water[level=0]
setblock 110 52 -365 minecraft:tall_seagrass[half=lower]
setblock 72 52 -366 minecraft:kelp_plant
fill 73 52 -366 77 52 -366 minecraft:water[level=0]
fill 78 52 -366 79 52 -366 minecraft:kelp_plant
fill 80 52 -366 111 52 -366 minecraft:water[level=0]
setblock 112 52 -366 minecraft:seagrass
fill 72 52 -367 113 52 -367 minecraft:water[level=0]
fill 72 52 -368 112 52 -368 minecraft:water[level=0]
setblock 113 52 -368 minecraft:tall_seagrass[half=upper]
setblock 114 52 -368 minecraft:seagrass
fill 72 52 -369 115 52 -369 minecraft:water[level=0]
fill 72 52 -370 83 52 -370 minecraft:water[level=0]
setblock 84 52 -370 minecraft:kelp_plant
setblock 85 52 -370 minecraft:water[level=0]
setblock 86 52 -370 minecraft:kelp_plant
fill 87 52 -370 91 52 -370 minecraft:water[level=0]
setblock 92 52 -370 minecraft:kelp_plant
fill 93 52 -370 116 52 -370 minecraft:water[level=0]
fill 72 52 -371 117 52 -371 minecraft:water[level=0]
setblock 118 52 -371 minecraft:tall_seagrass[half=lower]
fill 72 52 -372 120 52 -372 minecraft:water[level=0]
fill 72 52 -373 79 52 -373 minecraft:water[level=0]
setblock 80 52 -373 minecraft:kelp_plant
fill 81 52 -373 82 52 -373 minecraft:water[level=0]
setblock 83 52 -373 minecraft:kelp_plant
fill 84 52 -373 88 52 -373 minecraft:water[level=0]
setblock 89 52 -373 minecraft:kelp_plant
fill 90 52 -373 120 52 -373 minecraft:water[level=0]
fill 72 52 -374 121 52 -374 minecraft:water[level=0]
fill 72 52 -375 85 52 -375 minecraft:water[level=0]
setblock 86 52 -375 minecraft:kelp_plant
fill 87 52 -375 123 52 -375 minecraft:water[level=0]
fill 72 52 -376 92 52 -376 minecraft:water[level=0]
setblock 93 52 -376 minecraft:kelp_plant
fill 94 52 -376 121 52 -376 minecraft:water[level=0]
setblock 122 52 -376 minecraft:tall_seagrass[half=lower]
setblock 123 52 -376 minecraft:water[level=0]
setblock 124 52 -376 minecraft:seagrass
fill 72 52 -377 89 52 -377 minecraft:water[level=0]
setblock 90 52 -377 minecraft:kelp_plant
fill 91 52 -377 122 52 -377 minecraft:water[level=0]
setblock 123 52 -377 minecraft:tall_seagrass[half=lower]
setblock 124 52 -377 minecraft:water[level=0]
fill 72 52 -378 84 52 -378 minecraft:water[level=0]
setblock 85 52 -378 minecraft:kelp_plant
fill 86 52 -378 96 52 -378 minecraft:water[level=0]
setblock 97 52 -378 minecraft:kelp_plant
fill 98 52 -378 124 52 -378 minecraft:water[level=0]
fill 72 52 -379 83 52 -379 minecraft:water[level=0]
setblock 84 52 -379 minecraft:kelp_plant
fill 85 52 -379 95 52 -379 minecraft:water[level=0]
setblock 96 52 -379 minecraft:kelp_plant
fill 97 52 -379 124 52 -379 minecraft:water[level=0]
fill 72 52 -380 85 52 -380 minecraft:water[level=0]
setblock 86 52 -380 minecraft:kelp_plant
fill 87 52 -380 90 52 -380 minecraft:water[level=0]
setblock 91 52 -380 minecraft:kelp_plant
fill 92 52 -380 125 52 -380 minecraft:water[level=0]
fill 72 52 -381 82 52 -381 minecraft:water[level=0]
setblock 83 52 -381 minecraft:kelp_plant
fill 84 52 -381 124 52 -381 minecraft:water[level=0]
fill 72 52 -382 123 52 -382 minecraft:water[level=0]
fill 73 51 -344 74 51 -344 minecraft:water[level=0]
fill 73 51 -345 74 51 -345 minecraft:water[level=0]
fill 73 51 -346 75 51 -346 minecraft:water[level=0]
fill 73 51 -347 75 51 -347 minecraft:water[level=0]
fill 74 51 -348 75 51 -348 minecraft:water[level=0]
fill 74 51 -349 76 51 -349 minecraft:water[level=0]
fill 74 51 -350 77 51 -350 minecraft:water[level=0]
fill 74 51 -351 77 51 -351 minecraft:water[level=0]
fill 74 51 -352 77 51 -352 minecraft:water[level=0]
fill 73 51 -353 77 51 -353 minecraft:water[level=0]
fill 73 51 -354 77 51 -354 minecraft:water[level=0]
fill 72 51 -355 77 51 -355 minecraft:water[level=0]
fill 72 51 -356 77 51 -356 minecraft:water[level=0]
fill 72 51 -357 76 51 -357 minecraft:water[level=0]
fill 72 51 -358 76 51 -358 minecraft:water[level=0]
fill 72 51 -359 75 51 -359 minecraft:water[level=0]
fill 72 51 -360 76 51 -360 minecraft:water[level=0]
fill 95 51 -360 97 51 -360 minecraft:water[level=0]
fill 104 51 -360 105 51 -360 minecraft:water[level=0]
fill 113 51 -360 114 51 -360 minecraft:water[level=0]
fill 72 51 -361 76 51 -361 minecraft:water[level=0]
fill 94 51 -361 97 51 -361 minecraft:water[level=0]
fill 104 51 -361 105 51 -361 minecraft:water[level=0]
setblock 106 51 -361 minecraft:tall_seagrass[half=lower]
fill 112 51 -361 114 51 -361 minecraft:water[level=0]
fill 72 51 -362 76 51 -362 minecraft:water[level=0]
fill 92 51 -362 97 51 -362 minecraft:water[level=0]
fill 103 51 -362 107 51 -362 minecraft:water[level=0]
fill 112 51 -362 114 51 -362 minecraft:water[level=0]
setblock 72 51 -363 minecraft:kelp_plant
setblock 73 51 -363 minecraft:water[level=0]
setblock 74 51 -363 minecraft:kelp_plant
setblock 75 51 -363 minecraft:water[level=0]
setblock 76 51 -363 minecraft:kelp_plant
setblock 77 51 -363 minecraft:water[level=0]
fill 90 51 -363 98 51 -363 minecraft:water[level=0]
fill 103 51 -363 106 51 -363 minecraft:water[level=0]
setblock 107 51 -363 minecraft:seagrass
setblock 108 51 -363 minecraft:water[level=0]
fill 112 51 -363 114 51 -363 minecraft:water[level=0]
fill 72 51 -364 73 51 -364 minecraft:water[level=0]
setblock 74 51 -364 minecraft:kelp_plant
fill 75 51 -364 104 51 -364 minecraft:water[level=0]
setblock 105 51 -364 minecraft:tall_seagrass[half=lower]
fill 106 51 -364 108 51 -364 minecraft:water[level=0]
fill 72 51 -365 109 51 -365 minecraft:water[level=0]
setblock 72 51 -366 minecraft:kelp_plant
fill 73 51 -366 77 51 -366 minecraft:water[level=0]
fill 78 51 -366 79 51 -366 minecraft:kelp_plant
fill 80 51 -366 110 51 -366 minecraft:water[level=0]
fill 72 51 -367 105 51 -367 minecraft:water[level=0]
setblock 106 51 -367 minecraft:tall_seagrass[half=upper]
fill 107 51 -367 112 51 -367 minecraft:water[level=0]
fill 72 51 -368 112 51 -368 minecraft:water[level=0]
setblock 113 51 -368 minecraft:tall_seagrass[half=lower]
fill 72 51 -369 114 51 -369 minecraft:water[level=0]
fill 72 51 -370 83 51 -370 minecraft:water[level=0]
setblock 84 51 -370 minecraft:kelp_plant
setblock 85 51 -370 minecraft:water[level=0]
setblock 86 51 -370 minecraft:kelp_plant
fill 87 51 -370 91 51 -370 minecraft:water[level=0]
setblock 92 51 -370 minecraft:kelp_plant
fill 93 51 -370 116 51 -370 minecraft:water[level=0]
fill 72 51 -371 117 51 -371 minecraft:water[level=0]
fill 72 51 -372 119 51 -372 minecraft:water[level=0]
fill 72 51 -373 79 51 -373 minecraft:water[level=0]
setblock 80 51 -373 minecraft:kelp_plant
fill 81 51 -373 82 51 -373 minecraft:water[level=0]
setblock 83 51 -373 minecraft:kelp_plant
fill 84 51 -373 88 51 -373 minecraft:water[level=0]
setblock 89 51 -373 minecraft:kelp_plant
fill 90 51 -373 119 51 -373 minecraft:water[level=0]
fill 72 51 -374 119 51 -374 minecraft:water[level=0]
fill 72 51 -375 85 51 -375 minecraft:water[level=0]
setblock 86 51 -375 minecraft:kelp_plant
fill 87 51 -375 118 51 -375 minecraft:water[level=0]
setblock 119 51 -375 minecraft:tall_seagrass[half=upper]
fill 72 51 -376 92 51 -376 minecraft:water[level=0]
setblock 93 51 -376 minecraft:kelp_plant
fill 94 51 -376 121 51 -376 minecraft:water[level=0]
fill 72 51 -377 89 51 -377 minecraft:water[level=0]
setblock 90 51 -377 minecraft:kelp_plant
fill 91 51 -377 120 51 -377 minecraft:water[level=0]
setblock 121 51 -377 minecraft:seagrass
fill 72 51 -378 84 51 -378 minecraft:water[level=0]
setblock 85 51 -378 minecraft:kelp_plant
fill 86 51 -378 96 51 -378 minecraft:water[level=0]
setblock 97 51 -378 minecraft:kelp_plant
fill 98 51 -378 120 51 -378 minecraft:water[level=0]
fill 72 51 -379 83 51 -379 minecraft:water[level=0]
setblock 84 51 -379 minecraft:kelp_plant
fill 85 51 -379 95 51 -379 minecraft:water[level=0]
setblock 96 51 -379 minecraft:kelp_plant
fill 97 51 -379 119 51 -379 minecraft:water[level=0]
fill 123 51 -379 124 51 -379 minecraft:water[level=0]
fill 72 51 -380 85 51 -380 minecraft:water[level=0]
setblock 86 51 -380 minecraft:kelp_plant
fill 87 51 -380 90 51 -380 minecraft:water[level=0]
setblock 91 51 -380 minecraft:kelp_plant
fill 92 51 -380 119 51 -380 minecraft:water[level=0]
fill 122 51 -380 124 51 -380 minecraft:water[level=0]
fill 72 51 -381 82 51 -381 minecraft:water[level=0]
setblock 83 51 -381 minecraft:kelp_plant
fill 84 51 -381 119 51 -381 minecraft:water[level=0]
fill 72 51 -382 119 51 -382 minecraft:water[level=0]
fill 72 50 -340 73 50 -340 minecraft:water[level=0]
fill 72 50 -341 74 50 -341 minecraft:water[level=0]
fill 72 50 -342 75 50 -342 minecraft:water[level=0]
fill 72 50 -343 75 50 -343 minecraft:water[level=0]
fill 72 50 -344 76 50 -344 minecraft:water[level=0]
fill 72 50 -345 76 50 -345 minecraft:water[level=0]
fill 72 50 -346 76 50 -346 minecraft:water[level=0]
fill 72 50 -347 76 50 -347 minecraft:water[level=0]
fill 72 50 -348 76 50 -348 minecraft:water[level=0]
fill 73 50 -349 77 50 -349 minecraft:water[level=0]
fill 73 50 -350 78 50 -350 minecraft:water[level=0]
fill 73 50 -351 78 50 -351 minecraft:water[level=0]
fill 73 50 -352 78 50 -352 minecraft:water[level=0]
fill 73 50 -353 78 50 -353 minecraft:water[level=0]
fill 73 50 -354 77 50 -354 minecraft:water[level=0]
fill 73 50 -355 77 50 -355 minecraft:water[level=0]
fill 72 50 -356 76 50 -356 minecraft:water[level=0]
fill 72 50 -357 76 50 -357 minecraft:water[level=0]
fill 72 50 -358 75 50 -358 minecraft:water[level=0]
fill 72 50 -359 75 50 -359 minecraft:water[level=0]
fill 72 50 -360 76 50 -360 minecraft:water[level=0]
setblock 96 50 -360 minecraft:water[level=0]
fill 113 50 -360 114 50 -360 minecraft:water[level=0]
fill 72 50 -361 76 50 -361 minecraft:water[level=0]
fill 95 50 -361 96 50 -361 minecraft:water[level=0]
fill 112 50 -361 114 50 -361 minecraft:water[level=0]
fill 72 50 -362 76 50 -362 minecraft:water[level=0]
fill 94 50 -362 96 50 -362 minecraft:water[level=0]
fill 112 50 -362 114 50 -362 minecraft:water[level=0]
setblock 72 50 -363 minecraft:kelp_plant
setblock 73 50 -363 minecraft:water[level=0]
setblock 74 50 -363 minecraft:kelp_plant
setblock 75 50 -363 minecraft:water[level=0]
setblock 76 50 -363 minecraft:kelp_plant
setblock 77 50 -363 minecraft:water[level=0]
fill 92 50 -363 97 50 -363 minecraft:water[level=0]
fill 72 50 -364 73 50 -364 minecraft:water[level=0]
setblock 74 50 -364 minecraft:kelp_plant
fill 75 50 -364 84 50 -364 minecraft:water[level=0]
setblock 85 50 -364 minecraft:tall_seagrass[half=upper]
fill 86 50 -364 98 50 -364 minecraft:water[level=0]
setblock 108 50 -364 minecraft:water[level=0]
fill 72 50 -365 99 50 -365 minecraft:water[level=0]
fill 106 50 -365 108 50 -365 minecraft:water[level=0]
setblock 72 50 -366 minecraft:kelp_plant
fill 73 50 -366 77 50 -366 minecraft:water[level=0]
fill 78 50 -366 79 50 -366 minecraft:kelp_plant
fill 80 50 -366 86 50 -366 minecraft:water[level=0]
setblock 87 50 -366 minecraft:seagrass
setblock 88 50 -366 minecraft:water[level=0]
setblock 89 50 -366 minecraft:seagrass
fill 90 50 -366 100 50 -366 minecraft:water[level=0]
fill 106 50 -366 109 50 -366 minecraft:water[level=0]
fill 72 50 -367 101 50 -367 minecraft:water[level=0]
setblock 106 50 -367 minecraft:tall_seagrass[half=lower]
fill 107 50 -367 110 50 -367 minecraft:water[level=0]
setblock 111 50 -367 minecraft:seagrass
fill 72 50 -368 83 50 -368 minecraft:water[level=0]
setblock 84 50 -368 minecraft:tall_seagrass[half=upper]
fill 85 50 -368 102 50 -368 minecraft:water[level=0]
fill 105 50 -368 112 50 -368 minecraft:water[level=0]
fill 72 50 -369 102 50 -369 minecraft:water[level=0]
setblock 105 50 -369 minecraft:seagrass
fill 106 50 -369 113 50 -369 minecraft:water[level=0]
fill 72 50 -370 83 50 -370 minecraft:water[level=0]
setblock 84 50 -370 minecraft:kelp_plant
setblock 85 50 -370 minecraft:water[level=0]
setblock 86 50 -370 minecraft:kelp_plant
fill 87 50 -370 91 50 -370 minecraft:water[level=0]
setblock 92 50 -370 minecraft:kelp_plant
fill 93 50 -370 103 50 -370 minecraft:water[level=0]
fill 105 50 -370 113 50 -370 minecraft:water[level=0]
setblock 114 50 -370 minecraft:tall_seagrass[half=upper]
setblock 115 50 -370 minecraft:water[level=0]
fill 72 50 -371 85 50 -371 minecraft:water[level=0]
setblock 86 50 -371 minecraft:tall_seagrass[half=upper]
fill 87 50 -371 117 50 -371 minecraft:water[level=0]
fill 72 50 -372 118 50 -372 minecraft:water[level=0]
fill 72 50 -373 79 50 -373 minecraft:water[level=0]
setblock 80 50 -373 minecraft:kelp_plant
fill 81 50 -373 82 50 -373 minecraft:water[level=0]
setblock 83 50 -373 minecraft:kelp_plant
setblock 84 50 -373 minecraft:tall_seagrass[half=upper]
setblock 85 50 -373 minecraft:water[level=0]
setblock 86 50 -373 minecraft:tall_seagrass[half=upper]
fill 87 50 -373 88 50 -373 minecraft:water[level=0]
setblock 89 50 -373 minecraft:kelp_plant
setblock 90 50 -373 minecraft:water[level=0]
setblock 91 50 -373 minecraft:tall_seagrass[half=upper]
fill 92 50 -373 118 50 -373 minecraft:water[level=0]
fill 72 50 -374 83 50 -374 minecraft:water[level=0]
setblock 84 50 -374 minecraft:tall_seagrass[half=upper]
setblock 85 50 -374 minecraft:water[level=0]
setblock 86 50 -374 minecraft:tall_seagrass[half=upper]
fill 87 50 -374 103 50 -374 minecraft:water[level=0]
setblock 104 50 -374 minecraft:tall_seagrass[half=upper]
fill 105 50 -374 118 50 -374 minecraft:water[level=0]
fill 72 50 -375 80 50 -375 minecraft:water[level=0]
fill 81 50 -375 82 50 -375 minecraft:tall_seagrass[half=upper]
fill 83 50 -375 85 50 -375 minecraft:water[level=0]
setblock 86 50 -375 minecraft:kelp_plant
fill 87 50 -375 88 50 -375 minecraft:tall_seagrass[half=upper]
fill 89 50 -375 118 50 -375 minecraft:water[level=0]
setblock 119 50 -375 minecraft:tall_seagrass[half=lower]
fill 72 50 -376 83 50 -376 minecraft:water[level=0]
setblock 84 50 -376 minecraft:tall_seagrass[half=upper]
fill 85 50 -376 92 50 -376 minecraft:water[level=0]
setblock 93 50 -376 minecraft:kelp_plant
fill 94 50 -376 119 50 -376 minecraft:water[level=0]
fill 72 50 -377 80 50 -377 minecraft:water[level=0]
setblock 81 50 -377 minecraft:tall_seagrass[half=upper]
fill 82 50 -377 89 50 -377 minecraft:water[level=0]
setblock 90 50 -377 minecraft:kelp_plant
fill 91 50 -377 119 50 -377 minecraft:water[level=0]
fill 72 50 -378 84 50 -378 minecraft:water[level=0]
setblock 85 50 -378 minecraft:kelp_plant
fill 86 50 -378 87 50 -378 minecraft:water[level=0]
setblock 88 50 -378 minecraft:tall_seagrass[half=upper]
fill 89 50 -378 96 50 -378 minecraft:water[level=0]
setblock 97 50 -378 minecraft:kelp_plant
fill 98 50 -378 119 50 -378 minecraft:water[level=0]
fill 72 50 -379 83 50 -379 minecraft:water[level=0]
setblock 84 50 -379 minecraft:kelp_plant
setblock 85 50 -379 minecraft:tall_seagrass[half=upper]
fill 86 50 -379 95 50 -379 minecraft:water[level=0]
setblock 96 50 -379 minecraft:kelp_plant
fill 97 50 -379 119 50 -379 minecraft:water[level=0]
fill 72 50 -380 85 50 -380 minecraft:water[level=0]
setblock 86 50 -380 minecraft:kelp_plant
fill 87 50 -380 90 50 -380 minecraft:water[level=0]
setblock 91 50 -380 minecraft:kelp_plant
fill 92 50 -380 119 50 -380 minecraft:water[level=0]
fill 72 50 -381 82 50 -381 minecraft:water[level=0]
setblock 83 50 -381 minecraft:kelp_plant
fill 84 50 -381 119 50 -381 minecraft:water[level=0]
fill 72 50 -382 119 50 -382 minecraft:water[level=0]
fill 72 49 -339 73 49 -339 minecraft:water[level=0]
fill 72 49 -340 74 49 -340 minecraft:water[level=0]
fill 72 49 -341 75 49 -341 minecraft:water[level=0]
fill 72 49 -342 75 49 -342 minecraft:water[level=0]
fill 72 49 -343 76 49 -343 minecraft:water[level=0]
fill 72 49 -344 76 49 -344 minecraft:water[level=0]
fill 72 49 -345 76 49 -345 minecraft:water[level=0]
fill 72 49 -346 76 49 -346 minecraft:water[level=0]
fill 72 49 -347 76 49 -347 minecraft:water[level=0]
fill 72 49 -348 77 49 -348 minecraft:water[level=0]
fill 72 49 -349 77 49 -349 minecraft:water[level=0]
fill 73 49 -350 77 49 -350 minecraft:water[level=0]
fill 74 49 -351 78 49 -351 minecraft:water[level=0]
fill 74 49 -352 77 49 -352 minecraft:water[level=0]
fill 74 49 -353 77 49 -353 minecraft:water[level=0]
fill 74 49 -354 77 49 -354 minecraft:water[level=0]
fill 74 49 -355 76 49 -355 minecraft:water[level=0]
fill 74 49 -356 75 49 -356 minecraft:water[level=0]
setblock 74 49 -357 minecraft:water[level=0]
setblock 72 49 -358 minecraft:water[level=0]
setblock 72 49 -359 minecraft:water[level=0]
fill 72 49 -360 75 49 -360 minecraft:water[level=0]
fill 113 49 -360 114 49 -360 minecraft:water[level=0]
fill 72 49 -361 76 49 -361 minecraft:water[level=0]
setblock 96 49 -361 minecraft:water[level=0]
fill 112 49 -361 114 49 -361 minecraft:water[level=0]
fill 72 49 -362 76 49 -362 minecraft:water[level=0]
setblock 96 49 -362 minecraft:water[level=0]
fill 113 49 -362 114 49 -362 minecraft:water[level=0]
setblock 72 49 -363 minecraft:kelp_plant
setblock 73 49 -363 minecraft:water[level=0]
setblock 74 49 -363 minecraft:kelp_plant
setblock 75 49 -363 minecraft:water[level=0]
setblock 76 49 -363 minecraft:kelp_plant
setblock 96 49 -363 minecraft:water[level=0]
fill 72 49 -364 73 49 -364 minecraft:water[level=0]
setblock 74 49 -364 minecraft:kelp_plant
fill 75 49 -364 79 49 -364 minecraft:water[level=0]
fill 80 49 -364 82 49 -364 minecraft:seagrass
fill 83 49 -364 84 49 -364 minecraft:water[level=0]
setblock 85 49 -364 minecraft:tall_seagrass[half=lower]
fill 86 49 -364 96 49 -364 minecraft:water[level=0]
fill 72 49 -365 79 49 -365 minecraft:water[level=0]
fill 80 49 -365 82 49 -365 minecraft:seagrass
setblock 83 49 -365 minecraft:water[level=0]
setblock 84 49 -365 minecraft:seagrass
fill 85 49 -365 87 49 -365 minecraft:water[level=0]
fill 89 49 -365 96 49 -365 minecraft:water[level=0]
setblock 108 49 -365 minecraft:water[level=0]
setblock 72 49 -366 minecraft:kelp_plant
fill 73 49 -366 77 49 -366 minecraft:water[level=0]
fill 78 49 -366 79 49 -366 minecraft:kelp_plant
setblock 80 49 -366 minecraft:water[level=0]
setblock 81 49 -366 minecraft:seagrass
fill 82 49 -366 83 49 -366 minecraft:water[level=0]
setblock 84 49 -366 minecraft:seagrass
fill 85 49 -366 86 49 -366 minecraft:water[level=0]
setblock 90 49 -366 minecraft:seagrass
fill 91 49 -366 97 49 -366 minecraft:water[level=0]
fill 107 49 -366 108 49 -366 minecraft:water[level=0]
fill 72 49 -367 82 49 -367 minecraft:water[level=0]
fill 83 49 -367 84 49 -367 minecraft:seagrass
setblock 85 49 -367 minecraft:water[level=0]
fill 91 49 -367 100 49 -367 minecraft:water[level=0]
fill 107 49 -367 109 49 -367 minecraft:water[level=0]
setblock 110 49 -367 minecraft:seagrass
fill 72 49 -368 78 49 -368 minecraft:water[level=0]
fill 79 49 -368 80 49 -368 minecraft:seagrass
fill 81 49 -368 83 49 -368 minecraft:water[level=0]
setblock 84 49 -368 minecraft:tall_seagrass[half=lower]
setblock 85 49 -368 minecraft:water[level=0]
fill 93 49 -368 101 49 -368 minecraft:water[level=0]
setblock 106 49 -368 minecraft:water[level=0]
setblock 107 49 -368 minecraft:tall_seagrass[half=upper]
fill 108 49 -368 111 49 -368 minecraft:water[level=0]
setblock 112 49 -368 minecraft:seagrass
fill 72 49 -369 77 49 -369 minecraft:water[level=0]
setblock 78 49 -369 minecraft:seagrass
fill 79 49 -369 81 49 -369 minecraft:water[level=0]
setblock 82 49 -369 minecraft:seagrass
fill 83 49 -369 86 49 -369 minecraft:water[level=0]
fill 93 49 -369 101 49 -369 minecraft:water[level=0]
fill 106 49 -369 113 49 -369 minecraft:water[level=0]
fill 72 49 -370 83 49 -370 minecraft:water[level=0]
setblock 84 49 -370 minecraft:kelp_plant
setblock 85 49 -370 minecraft:water[level=0]
setblock 86 49 -370 minecraft:kelp_plant
fill 93 49 -370 101 49 -370 minecraft:water[level=0]
fill 106 49 -370 113 49 -370 minecraft:water[level=0]
setblock 114 49 -370 minecraft:tall_seagrass[half=lower]
fill 72 49 -371 77 49 -371 minecraft:water[level=0]
setblock 78 49 -371 minecraft:tall_seagrass[half=upper]
setblock 79 49 -371 minecraft:water[level=0]
setblock 80 49 -371 minecraft:seagrass
fill 81 49 -371 85 49 -371 minecraft:water[level=0]
setblock 86 49 -371 minecraft:tall_seagrass[half=lower]
setblock 87 49 -371 minecraft:water[level=0]
fill 93 49 -371 102 49 -371 minecraft:water[level=0]
fill 105 49 -371 116 49 -371 minecraft:water[level=0]
fill 72 49 -372 80 49 -372 minecraft:water[level=0]
setblock 81 49 -372 minecraft:seagrass
fill 82 49 -372 83 49 -372 minecraft:water[level=0]
setblock 84 49 -372 minecraft:seagrass
fill 85 49 -372 87 49 -372 minecraft:water[level=0]
fill 93 49 -372 118 49 -372 minecraft:water[level=0]
setblock 72 49 -373 minecraft:water[level=0]
setblock 73 49 -373 minecraft:tall_seagrass[half=upper]
fill 74 49 -373 79 49 -373 minecraft:water[level=0]
setblock 80 49 -373 minecraft:kelp_plant
fill 81 49 -373 82 49 -373 minecraft:seagrass
setblock 83 49 -373 minecraft:kelp_plant
setblock 84 49 -373 minecraft:tall_seagrass[half=lower]
setblock 85 49 -373 minecraft:seagrass
setblock 86 49 -373 minecraft:tall_seagrass[half=lower]
setblock 87 49 -373 minecraft:water[level=0]
setblock 88 49 -373 minecraft:seagrass
setblock 89 49 -373 minecraft:kelp_plant
setblock 90 49 -373 minecraft:water[level=0]
setblock 91 49 -373 minecraft:tall_seagrass[half=lower]
fill 92 49 -373 100 49 -373 minecraft:water[level=0]
setblock 101 49 -373 minecraft:tall_seagrass[half=upper]
fill 102 49 -373 104 49 -373 minecraft:water[level=0]
setblock 105 49 -373 minecraft:tall_seagrass[half=upper]
fill 106 49 -373 118 49 -373 minecraft:water[level=0]
setblock 72 49 -374 minecraft:water[level=0]
setblock 73 49 -374 minecraft:tall_seagrass[half=upper]
fill 74 49 -374 79 49 -374 minecraft:water[level=0]
setblock 80 49 -374 minecraft:seagrass
fill 81 49 -374 83 49 -374 minecraft:water[level=0]
setblock 84 49 -374 minecraft:tall_seagrass[half=lower]
setblock 85 49 -374 minecraft:water[level=0]
setblock 86 49 -374 minecraft:tall_seagrass[half=lower]
fill 87 49 -374 103 49 -374 minecraft:water[level=0]
setblock 104 49 -374 minecraft:tall_seagrass[half=lower]
fill 105 49 -374 118 49 -374 minecraft:water[level=0]
fill 72 49 -375 80 49 -375 minecraft:water[level=0]
fill 81 49 -375 82 49 -375 minecraft:tall_seagrass[half=lower]
setblock 83 49 -375 minecraft:seagrass
setblock 84 49 -375 minecraft:water[level=0]
setblock 85 49 -375 minecraft:seagrass
setblock 86 49 -375 minecraft:kelp_plant
fill 87 49 -375 88 49 -375 minecraft:tall_seagrass[half=lower]
fill 89 49 -375 101 49 -375 minecraft:water[level=0]
setblock 102 49 -375 minecraft:tall_seagrass[half=upper]
fill 103 49 -375 118 49 -375 minecraft:water[level=0]
fill 72 49 -376 81 49 -376 minecraft:water[level=0]
setblock 82 49 -376 minecraft:seagrass
setblock 83 49 -376 minecraft:water[level=0]
setblock 84 49 -376 minecraft:tall_seagrass[half=lower]
fill 85 49 -376 92 49 -376 minecraft:water[level=0]
setblock 93 49 -376 minecraft:kelp_plant
fill 94 49 -376 99 49 -376 minecraft:water[level=0]
setblock 100 49 -376 minecraft:tall_seagrass[half=upper]
fill 101 49 -376 106 49 -376 minecraft:water[level=0]
setblock 107 49 -376 minecraft:tall_seagrass[half=upper]
fill 108 49 -376 118 49 -376 minecraft:water[level=0]
setblock 72 49 -377 minecraft:water[level=0]
setblock 73 49 -377 minecraft:tall_seagrass[half=upper]
fill 74 49 -377 80 49 -377 minecraft:water[level=0]
setblock 81 49 -377 minecraft:tall_seagrass[half=lower]
fill 82 49 -377 85 49 -377 minecraft:water[level=0]
setblock 86 49 -377 minecraft:seagrass
fill 87 49 -377 89 49 -377 minecraft:water[level=0]
setblock 90 49 -377 minecraft:kelp_plant
fill 91 49 -377 102 49 -377 minecraft:water[level=0]
fill 103 49 -377 104 49 -377 minecraft:tall_seagrass[half=upper]
fill 105 49 -377 118 49 -377 minecraft:water[level=0]
fill 72 49 -378 74 49 -378 minecraft:water[level=0]
setblock 75 49 -378 minecraft:tall_seagrass[half=upper]
fill 76 49 -378 83 49 -378 minecraft:water[level=0]
setblock 84 49 -378 minecraft:seagrass
setblock 85 49 -378 minecraft:kelp_plant
fill 86 49 -378 87 49 -378 minecraft:water[level=0]
setblock 88 49 -378 minecraft:tall_seagrass[half=lower]
setblock 89 49 -378 minecraft:water[level=0]
setblock 90 49 -378 minecraft:seagrass
fill 91 49 -378 96 49 -378 minecraft:water[level=0]
setblock 97 49 -378 minecraft:kelp_plant
fill 98 49 -378 102 49 -378 minecraft:water[level=0]
setblock 103 49 -378 minecraft:tall_seagrass[half=upper]
setblock 104 49 -378 minecraft:water[level=0]
setblock 105 49 -378 minecraft:tall_seagrass[half=upper]
setblock 106 49 -378 minecraft:water[level=0]
setblock 107 49 -378 minecraft:tall_seagrass[half=upper]
setblock 108 49 -378 minecraft:water[level=0]
setblock 109 49 -378 minecraft:tall_seagrass[half=upper]
fill 110 49 -378 118 49 -378 minecraft:water[level=0]
setblock 72 49 -379 minecraft:water[level=0]
setblock 73 49 -379 minecraft:tall_seagrass[half=upper]
fill 74 49 -379 77 49 -379 minecraft:water[level=0]
setblock 78 49 -379 minecraft:tall_seagrass[half=upper]
setblock 79 49 -379 minecraft:water[level=0]
setblock 80 49 -379 minecraft:tall_seagrass[half=upper]
fill 81 49 -379 83 49 -379 minecraft:water[level=0]
setblock 84 49 -379 minecraft:kelp_plant
setblock 85 49 -379 minecraft:tall_seagrass[half=lower]
setblock 86 49 -379 minecraft:water[level=0]
setblock 87 49 -379 minecraft:seagrass
fill 88 49 -379 95 49 -379 minecraft:water[level=0]
setblock 96 49 -379 minecraft:kelp_plant
setblock 97 49 -379 minecraft:water[level=0]
setblock 98 49 -379 minecraft:tall_seagrass[half=upper]
fill 99 49 -379 118 49 -379 minecraft:water[level=0]
fill 72 49 -380 73 49 -380 minecraft:water[level=0]
setblock 74 49 -380 minecraft:tall_seagrass[half=upper]
fill 75 49 -380 85 49 -380 minecraft:water[level=0]
setblock 86 49 -380 minecraft:kelp_plant
fill 87 49 -380 90 49 -380 minecraft:water[level=0]
setblock 91 49 -380 minecraft:kelp_plant
fill 92 49 -380 118 49 -380 minecraft:water[level=0]
fill 72 49 -381 82 49 -381 minecraft:water[level=0]
setblock 83 49 -381 minecraft:kelp_plant
fill 84 49 -381 85 49 -381 minecraft:water[level=0]
setblock 86 49 -381 minecraft:seagrass
fill 87 49 -381 104 49 -381 minecraft:water[level=0]
setblock 105 49 -381 minecraft:tall_seagrass[half=upper]
setblock 106 49 -381 minecraft:water[level=0]
setblock 107 49 -381 minecraft:tall_seagrass[half=upper]
fill 108 49 -381 118 49 -381 minecraft:water[level=0]
fill 72 49 -382 83 49 -382 minecraft:water[level=0]
setblock 84 49 -382 minecraft:seagrass
fill 85 49 -382 118 49 -382 minecraft:water[level=0]
fill 123 48 -324 131 48 -324 minecraft:water[level=0]
fill 125 48 -325 133 48 -325 minecraft:water[level=0]
fill 126 48 -326 134 48 -326 minecraft:water[level=0]
fill 126 48 -327 135 48 -327 minecraft:water[level=0]
fill 126 48 -328 135 48 -328 minecraft:water[level=0]
fill 127 48 -329 135 48 -329 minecraft:water[level=0]
fill 127 48 -330 135 48 -330 minecraft:water[level=0]
fill 127 48 -331 135 48 -331 minecraft:water[level=0]
fill 127 48 -332 135 48 -332 minecraft:water[level=0]
fill 128 48 -333 135 48 -333 minecraft:water[level=0]
fill 128 48 -334 135 48 -334 minecraft:water[level=0]
fill 130 48 -335 135 48 -335 minecraft:water[level=0]
fill 130 48 -336 135 48 -336 minecraft:water[level=0]
fill 131 48 -337 135 48 -337 minecraft:water[level=0]
fill 132 48 -338 135 48 -338 minecraft:water[level=0]
setblock 72 48 -339 minecraft:water[level=0]
fill 132 48 -339 135 48 -339 minecraft:water[level=0]
fill 72 48 -340 74 48 -340 minecraft:water[level=0]
fill 133 48 -340 135 48 -340 minecraft:water[level=0]
fill 72 48 -341 75 48 -341 minecraft:water[level=0]
fill 134 48 -341 135 48 -341 minecraft:water[level=0]
fill 72 48 -342 75 48 -342 minecraft:water[level=0]
setblock 135 48 -342 minecraft:water[level=0]
fill 72 48 -343 75 48 -343 minecraft:water[level=0]
fill 72 48 -344 76 48 -344 minecraft:water[level=0]
fill 72 48 -345 76 48 -345 minecraft:water[level=0]
fill 72 48 -346 76 48 -346 minecraft:water[level=0]
fill 72 48 -347 76 48 -347 minecraft:water[level=0]
fill 73 48 -348 76 48 -348 minecraft:water[level=0]
fill 73 48 -349 76 48 -349 minecraft:water[level=0]
fill 74 48 -350 76 48 -350 minecraft:water[level=0]
fill 74 48 -351 77 48 -351 minecraft:water[level=0]
fill 75 48 -352 76 48 -352 minecraft:water[level=0]
setblock 72 48 -359 minecraft:water[level=0]
fill 113 48 -359 115 48 -359 minecraft:water[level=0]
fill 72 48 -360 73 48 -360 minecraft:water[level=0]
fill 113 48 -360 114 48 -360 minecraft:water[level=0]
fill 72 48 -361 73 48 -361 minecraft:water[level=0]
fill 72 48 -362 74 48 -362 minecraft:water[level=0]
setblock 72 48 -363 minecraft:kelp_plant
setblock 73 48 -363 minecraft:water[level=0]
setblock 74 48 -363 minecraft:kelp_plant
setblock 75 48 -363 minecraft:water[level=0]
fill 72 48 -364 73 48 -364 minecraft:water[level=0]
setblock 74 48 -364 minecraft:kelp_plant
fill 75 48 -364 77 48 -364 minecraft:water[level=0]
fill 72 48 -365 77 48 -365 minecraft:water[level=0]
fill 105 48 -365 106 48 -365 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 72 48 -366 minecraft:kelp_plant
fill 73 48 -366 77 48 -366 minecraft:water[level=0]
fill 105 48 -366 106 48 -366 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 108 48 -366 minecraft:seagrass
fill 72 48 -367 73 48 -367 minecraft:water[level=0]
fill 75 48 -367 77 48 -367 minecraft:water[level=0]
fill 108 48 -367 109 48 -367 minecraft:water[level=0]
setblock 72 48 -368 minecraft:water[level=0]
fill 75 48 -368 76 48 -368 minecraft:water[level=0]
fill 99 48 -368 100 48 -368 minecraft:water[level=0]
setblock 107 48 -368 minecraft:tall_seagrass[half=lower]
fill 108 48 -368 111 48 -368 minecraft:water[level=0]
fill 72 48 -369 73 48 -369 minecraft:water[level=0]
setblock 75 48 -369 minecraft:water[level=0]
fill 99 48 -369 100 48 -369 minecraft:water[level=0]
fill 107 48 -369 112 48 -369 minecraft:water[level=0]
fill 72 48 -370 73 48 -370 minecraft:water[level=0]
setblock 75 48 -370 minecraft:water[level=0]
setblock 77 48 -370 minecraft:water[level=0]
fill 98 48 -370 100 48 -370 minecraft:water[level=0]
fill 106 48 -370 113 48 -370 minecraft:water[level=0]
setblock 72 48 -371 minecraft:seagrass
fill 74 48 -371 77 48 -371 minecraft:water[level=0]
setblock 78 48 -371 minecraft:tall_seagrass[half=lower]
fill 98 48 -371 100 48 -371 minecraft:water[level=0]
fill 106 48 -371 116 48 -371 minecraft:water[level=0]
fill 77 48 -372 78 48 -372 minecraft:water[level=0]
fill 98 48 -372 101 48 -372 minecraft:water[level=0]
fill 106 48 -372 117 48 -372 minecraft:water[level=0]
setblock 72 48 -373 minecraft:water[level=0]
setblock 73 48 -373 minecraft:tall_seagrass[half=lower]
setblock 75 48 -373 minecraft:water[level=0]
setblock 78 48 -373 minecraft:water[level=0]
fill 97 48 -373 100 48 -373 minecraft:water[level=0]
setblock 101 48 -373 minecraft:tall_seagrass[half=lower]
setblock 102 48 -373 minecraft:water[level=0]
setblock 105 48 -373 minecraft:tall_seagrass[half=lower]
fill 106 48 -373 117 48 -373 minecraft:water[level=0]
setblock 72 48 -374 minecraft:seagrass
setblock 73 48 -374 minecraft:tall_seagrass[half=lower]
setblock 74 48 -374 minecraft:seagrass
setblock 75 48 -374 minecraft:water[level=0]
setblock 79 48 -374 minecraft:seagrass
fill 97 48 -374 102 48 -374 minecraft:water[level=0]
fill 105 48 -374 108 48 -374 minecraft:water[level=0]
setblock 109 48 -374 minecraft:seagrass
fill 110 48 -374 117 48 -374 minecraft:water[level=0]
setblock 72 48 -375 minecraft:seagrass
setblock 73 48 -375 minecraft:water[level=0]
fill 74 48 -375 76 48 -375 minecraft:seagrass
fill 77 48 -375 79 48 -375 minecraft:water[level=0]
fill 96 48 -375 101 48 -375 minecraft:water[level=0]
setblock 102 48 -375 minecraft:tall_seagrass[half=lower]
fill 103 48 -375 104 48 -375 minecraft:water[level=0]
setblock 105 48 -375 minecraft:seagrass
fill 106 48 -375 108 48 -375 minecraft:water[level=0]
setblock 109 48 -375 minecraft:seagrass
fill 110 48 -375 118 48 -375 minecraft:water[level=0]
fill 72 48 -376 73 48 -376 minecraft:seagrass
setblock 74 48 -376 minecraft:water[level=0]
setblock 75 48 -376 minecraft:seagrass
setblock 76 48 -376 minecraft:water[level=0]
fill 77 48 -376 78 48 -376 minecraft:seagrass
setblock 79 48 -376 minecraft:water[level=0]
setblock 80 48 -376 minecraft:seagrass
fill 95 48 -376 99 48 -376 minecraft:water[level=0]
setblock 100 48 -376 minecraft:tall_seagrass[half=lower]
setblock 101 48 -376 minecraft:water[level=0]
setblock 102 48 -376 minecraft:seagrass
fill 103 48 -376 106 48 -376 minecraft:water[level=0]
setblock 107 48 -376 minecraft:tall_seagrass[half=lower]
fill 108 48 -376 118 48 -376 minecraft:water[level=0]
setblock 72 48 -377 minecraft:seagrass
setblock 73 48 -377 minecraft:tall_seagrass[half=lower]
fill 76 48 -377 80 48 -377 minecraft:water[level=0]
fill 95 48 -377 96 48 -377 minecraft:water[level=0]
setblock 97 48 -377 minecraft:seagrass
fill 98 48 -377 102 48 -377 minecraft:water[level=0]
fill 103 48 -377 104 48 -377 minecraft:tall_seagrass[half=lower]
setblock 105 48 -377 minecraft:seagrass
fill 106 48 -377 118 48 -377 minecraft:water[level=0]
fill 73 48 -378 74 48 -378 minecraft:water[level=0]
setblock 75 48 -378 minecraft:tall_seagrass[half=lower]
fill 76 48 -378 79 48 -378 minecraft:water[level=0]
fill 80 48 -378 81 48 -378 minecraft:seagrass
fill 95 48 -378 96 48 -378 minecraft:water[level=0]
setblock 97 48 -378 minecraft:kelp_plant
fill 98 48 -378 100 48 -378 minecraft:water[level=0]
fill 101 48 -378 102 48 -378 minecraft:seagrass
setblock 103 48 -378 minecraft:tall_seagrass[half=lower]
setblock 104 48 -378 minecraft:water[level=0]
setblock 105 48 -378 minecraft:tall_seagrass[half=lower]
setblock 106 48 -378 minecraft:water[level=0]
setblock 107 48 -378 minecraft:tall_seagrass[half=lower]
setblock 108 48 -378 minecraft:water[level=0]
setblock 109 48 -378 minecraft:tall_seagrass[half=lower]
fill 110 48 -378 118 48 -378 minecraft:water[level=0]
setblock 72 48 -379 minecraft:water[level=0]
setblock 73 48 -379 minecraft:tall_seagrass[half=lower]
setblock 74 48 -379 minecraft:water[level=0]
setblock 75 48 -379 minecraft:seagrass
fill 76 48 -379 77 48 -379 minecraft:water[level=0]
setblock 78 48 -379 minecraft:tall_seagrass[half=lower]
setblock 79 48 -379 minecraft:water[level=0]
setblock 80 48 -379 minecraft:tall_seagrass[half=lower]
setblock 81 48 -379 minecraft:water[level=0]
setblock 95 48 -379 minecraft:water[level=0]
setblock 96 48 -379 minecraft:kelp_plant
setblock 97 48 -379 minecraft:water[level=0]
setblock 98 48 -379 minecraft:tall_seagrass[half=lower]
fill 99 48 -379 110 48 -379 minecraft:water[level=0]
setblock 111 48 -379 minecraft:seagrass
fill 112 48 -379 118 48 -379 minecraft:water[level=0]
fill 72 48 -380 73 48 -380 minecraft:water[level=0]
setblock 74 48 -380 minecraft:tall_seagrass[half=lower]
setblock 75 48 -380 minecraft:water[level=0]
setblock 76 48 -380 minecraft:seagrass
fill 77 48 -380 81 48 -380 minecraft:water[level=0]
fill 95 48 -380 99 48 -380 minecraft:water[level=0]
setblock 100 48 -380 minecraft:seagrass
fill 101 48 -380 104 48 -380 minecraft:water[level=0]
setblock 105 48 -380 minecraft:seagrass
setblock 106 48 -380 minecraft:water[level=0]
fill 107 48 -380 108 48 -380 minecraft:seagrass
fill 109 48 -380 118 48 -380 minecraft:water[level=0]
fill 72 48 -381 78 48 -381 minecraft:water[level=0]
setblock 79 48 -381 minecraft:seagrass
fill 80 48 -381 81 48 -381 minecraft:water[level=0]
fill 94 48 -381 97 48 -381 minecraft:water[level=0]
setblock 98 48 -381 minecraft:seagrass
fill 99 48 -381 104 48 -381 minecraft:water[level=0]
setblock 105 48 -381 minecraft:tall_seagrass[half=lower]
setblock 106 48 -381 minecraft:water[level=0]
setblock 107 48 -381 minecraft:tall_seagrass[half=lower]
fill 108 48 -381 118 48 -381 minecraft:water[level=0]
fill 72 48 -382 73 48 -382 minecraft:water[level=0]
setblock 74 48 -382 minecraft:seagrass
fill 75 48 -382 78 48 -382 minecraft:water[level=0]
setblock 79 48 -382 minecraft:seagrass
setblock 80 48 -382 minecraft:water[level=0]
fill 94 48 -382 98 48 -382 minecraft:water[level=0]
setblock 99 48 -382 minecraft:seagrass
fill 100 48 -382 104 48 -382 minecraft:water[level=0]
setblock 105 48 -382 minecraft:seagrass
fill 106 48 -382 117 48 -382 minecraft:water[level=0]
setblock 128 47 -326 minecraft:water[level=0]
fill 128 47 -327 132 47 -327 minecraft:water[level=0]
fill 128 47 -328 133 47 -328 minecraft:water[level=0]
fill 128 47 -329 134 47 -329 minecraft:water[level=0]
fill 128 47 -330 135 47 -330 minecraft:water[level=0]
fill 128 47 -331 135 47 -331 minecraft:water[level=0]
fill 128 47 -332 135 47 -332 minecraft:water[level=0]
fill 129 47 -333 135 47 -333 minecraft:water[level=0]
fill 131 47 -334 135 47 -334 minecraft:water[level=0]
fill 131 47 -335 135 47 -335 minecraft:water[level=0]
fill 132 47 -336 135 47 -336 minecraft:water[level=0]
fill 132 47 -337 135 47 -337 minecraft:water[level=0]
fill 133 47 -338 135 47 -338 minecraft:water[level=0]
fill 134 47 -339 135 47 -339 minecraft:water[level=0]
setblock 135 47 -340 minecraft:water[level=0]
fill 72 47 -341 73 47 -341 minecraft:water[level=0]
fill 72 47 -342 74 47 -342 minecraft:water[level=0]
fill 72 47 -343 74 47 -343 minecraft:water[level=0]
fill 73 47 -344 74 47 -344 minecraft:water[level=0]
setblock 74 47 -345 minecraft:water[level=0]
fill 113 47 -358 114 47 -358 minecraft:water[level=0]
fill 113 47 -359 115 47 -359 minecraft:water[level=0]
fill 113 47 -360 115 47 -360 minecraft:water[level=0]
setblock 114 47 -361 minecraft:water[level=0]
fill 105 47 -365 106 47 -365 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 105 47 -366 106 47 -366 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 112 47 -372 116 47 -372 minecraft:water[level=0]
fill 113 47 -373 116 47 -373 minecraft:water[level=0]
fill 115 47 -374 116 47 -374 minecraft:water[level=0]
fill 115 47 -375 116 47 -375 minecraft:water[level=0]
fill 115 47 -376 116 47 -376 minecraft:water[level=0]
setblock 116 47 -377 minecraft:water[level=0]
setblock 116 47 -378 minecraft:water[level=0]
setblock 116 47 -379 minecraft:water[level=0]
setblock 116 47 -380 minecraft:water[level=0]
setblock 116 47 -381 minecraft:water[level=0]
fill 113 46 -358 115 46 -358 minecraft:water[level=0]
fill 113 46 -359 115 46 -359 minecraft:water[level=0]
fill 113 46 -360 114 46 -360 minecraft:water[level=0]
fill 94 45 -319 97 45 -319 minecraft:water[level=0]
fill 95 45 -320 97 45 -320 minecraft:water[level=0]
fill 95 45 -321 98 45 -321 minecraft:water[level=0]
fill 96 45 -322 101 45 -322 minecraft:water[level=0]
fill 97 45 -323 102 45 -323 minecraft:water[level=0]
fill 98 45 -324 103 45 -324 minecraft:water[level=0]
fill 98 45 -325 103 45 -325 minecraft:water[level=0]
fill 99 45 -326 102 45 -326 minecraft:water[level=0]
fill 100 45 -327 101 45 -327 minecraft:water[level=0]
fill 113 45 -357 114 45 -357 minecraft:water[level=0]
fill 112 45 -358 115 45 -358 minecraft:water[level=0]
fill 113 45 -359 115 45 -359 minecraft:water[level=0]
fill 113 45 -360 114 45 -360 minecraft:water[level=0]
forceload remove 72 -382 135 -319
tellraw @a {"text":"Campus zurueck a09 fertig.","color":"green"}
