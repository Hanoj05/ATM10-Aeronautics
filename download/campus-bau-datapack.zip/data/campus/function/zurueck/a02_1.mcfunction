setblock 72 72 -436 minecraft:air
setblock 82 72 -436 minecraft:air
setblock 92 72 -436 minecraft:air
setblock 102 72 -436 minecraft:air
setblock 112 72 -436 minecraft:air
setblock 122 72 -436 minecraft:air
setblock 132 72 -436 minecraft:air
setblock 72 71 -434 minecraft:air
setblock 82 71 -434 minecraft:air
setblock 92 71 -434 minecraft:air
setblock 102 71 -434 minecraft:air
setblock 112 71 -434 minecraft:air
setblock 122 71 -434 minecraft:air
setblock 132 71 -434 minecraft:air
fill 72 71 -435 73 71 -435 minecraft:air
fill 81 71 -435 83 71 -435 minecraft:air
fill 91 71 -435 93 71 -435 minecraft:air
fill 101 71 -435 103 71 -435 minecraft:air
fill 111 71 -435 113 71 -435 minecraft:air
fill 121 71 -435 123 71 -435 minecraft:air
fill 131 71 -435 133 71 -435 minecraft:air
fill 72 71 -436 74 71 -436 minecraft:air
fill 80 71 -436 84 71 -436 minecraft:air
fill 90 71 -436 94 71 -436 minecraft:air
fill 100 71 -436 104 71 -436 minecraft:air
fill 110 71 -436 114 71 -436 minecraft:air
fill 120 71 -436 124 71 -436 minecraft:air
fill 130 71 -436 134 71 -436 minecraft:air
fill 72 71 -437 73 71 -437 minecraft:air
fill 81 71 -437 83 71 -437 minecraft:air
fill 91 71 -437 93 71 -437 minecraft:air
fill 101 71 -437 103 71 -437 minecraft:air
fill 111 71 -437 113 71 -437 minecraft:air
fill 121 71 -437 123 71 -437 minecraft:air
fill 131 71 -437 133 71 -437 minecraft:air
setblock 72 71 -438 minecraft:air
setblock 82 71 -438 minecraft:air
setblock 92 71 -438 minecraft:air
setblock 102 71 -438 minecraft:air
setblock 112 71 -438 minecraft:air
setblock 122 71 -438 minecraft:air
setblock 132 71 -438 minecraft:air
fill 72 70 -434 73 70 -434 minecraft:air
fill 81 70 -434 83 70 -434 minecraft:air
fill 91 70 -434 93 70 -434 minecraft:air
fill 101 70 -434 103 70 -434 minecraft:air
fill 111 70 -434 113 70 -434 minecraft:air
fill 121 70 -434 123 70 -434 minecraft:air
fill 131 70 -434 133 70 -434 minecraft:air
fill 72 70 -435 74 70 -435 minecraft:air
fill 80 70 -435 84 70 -435 minecraft:air
fill 90 70 -435 94 70 -435 minecraft:air
fill 100 70 -435 104 70 -435 minecraft:air
fill 110 70 -435 114 70 -435 minecraft:air
fill 120 70 -435 124 70 -435 minecraft:air
fill 130 70 -435 134 70 -435 minecraft:air
fill 72 70 -436 74 70 -436 minecraft:air
fill 80 70 -436 84 70 -436 minecraft:air
fill 90 70 -436 94 70 -436 minecraft:air
fill 100 70 -436 104 70 -436 minecraft:air
fill 110 70 -436 114 70 -436 minecraft:air
fill 120 70 -436 124 70 -436 minecraft:air
fill 130 70 -436 134 70 -436 minecraft:air
fill 72 70 -437 74 70 -437 minecraft:air
fill 80 70 -437 84 70 -437 minecraft:air
fill 90 70 -437 94 70 -437 minecraft:air
fill 100 70 -437 104 70 -437 minecraft:air
fill 110 70 -437 114 70 -437 minecraft:air
fill 120 70 -437 124 70 -437 minecraft:air
fill 130 70 -437 134 70 -437 minecraft:air
fill 72 70 -438 73 70 -438 minecraft:air
fill 81 70 -438 83 70 -438 minecraft:air
fill 91 70 -438 93 70 -438 minecraft:air
fill 101 70 -438 103 70 -438 minecraft:air
fill 111 70 -438 113 70 -438 minecraft:air
fill 121 70 -438 123 70 -438 minecraft:air
fill 131 70 -438 133 70 -438 minecraft:air
setblock 72 69 -434 minecraft:air
setblock 82 69 -434 minecraft:air
setblock 92 69 -434 minecraft:air
setblock 102 69 -434 minecraft:air
setblock 112 69 -434 minecraft:air
setblock 122 69 -434 minecraft:air
setblock 132 69 -434 minecraft:air
fill 72 69 -435 73 69 -435 minecraft:air
fill 81 69 -435 83 69 -435 minecraft:air
fill 91 69 -435 93 69 -435 minecraft:air
fill 101 69 -435 103 69 -435 minecraft:air
fill 111 69 -435 113 69 -435 minecraft:air
fill 121 69 -435 123 69 -435 minecraft:air
fill 131 69 -435 133 69 -435 minecraft:air
fill 72 69 -436 74 69 -436 minecraft:air
fill 80 69 -436 84 69 -436 minecraft:air
fill 90 69 -436 94 69 -436 minecraft:air
fill 100 69 -436 104 69 -436 minecraft:air
fill 110 69 -436 114 69 -436 minecraft:air
fill 120 69 -436 124 69 -436 minecraft:air
fill 130 69 -436 134 69 -436 minecraft:air
fill 72 69 -437 73 69 -437 minecraft:air
fill 81 69 -437 83 69 -437 minecraft:air
fill 91 69 -437 93 69 -437 minecraft:air
fill 101 69 -437 103 69 -437 minecraft:air
fill 111 69 -437 113 69 -437 minecraft:air
fill 121 69 -437 123 69 -437 minecraft:air
fill 131 69 -437 133 69 -437 minecraft:air
setblock 72 69 -438 minecraft:air
setblock 82 69 -438 minecraft:air
setblock 92 69 -438 minecraft:air
setblock 102 69 -438 minecraft:air
setblock 112 69 -438 minecraft:air
setblock 122 69 -438 minecraft:air
setblock 132 69 -438 minecraft:air
setblock 72 68 -436 minecraft:air
setblock 82 68 -436 minecraft:air
setblock 92 68 -436 minecraft:air
setblock 102 68 -436 minecraft:air
setblock 112 68 -436 minecraft:air
setblock 122 68 -436 minecraft:air
setblock 132 68 -436 minecraft:air
setblock 72 67 -436 minecraft:air
setblock 82 67 -436 minecraft:air
setblock 92 67 -436 minecraft:air
setblock 102 67 -436 minecraft:air
setblock 112 67 -436 minecraft:air
setblock 122 67 -436 minecraft:air
setblock 132 67 -436 minecraft:air
setblock 72 66 -436 minecraft:air
setblock 82 66 -436 minecraft:air
setblock 92 66 -436 minecraft:air
setblock 102 66 -436 minecraft:air
setblock 112 66 -436 minecraft:air
setblock 122 66 -436 minecraft:air
setblock 132 66 -436 minecraft:air
setblock 92 66 -444 minecraft:sand
fill 90 66 -445 92 66 -445 minecraft:sand
fill 88 66 -446 92 66 -446 minecraft:sand
fill 72 65 -383 135 65 -383 minecraft:air
fill 72 65 -384 135 65 -384 minecraft:air
fill 72 65 -385 135 65 -385 minecraft:air
fill 72 65 -386 135 65 -386 minecraft:air
fill 72 65 -387 135 65 -387 minecraft:air
fill 72 65 -388 135 65 -388 minecraft:air
fill 72 65 -389 135 65 -389 minecraft:air
fill 72 65 -390 135 65 -390 minecraft:air
fill 72 65 -391 135 65 -391 minecraft:air
fill 72 65 -392 135 65 -392 minecraft:air
fill 72 65 -393 135 65 -393 minecraft:air
fill 72 65 -394 135 65 -394 minecraft:air
fill 72 65 -395 135 65 -395 minecraft:air
fill 72 65 -396 135 65 -396 minecraft:air
fill 72 65 -397 135 65 -397 minecraft:air
fill 72 65 -398 135 65 -398 minecraft:air
fill 72 65 -399 135 65 -399 minecraft:air
fill 72 65 -400 135 65 -400 minecraft:air
fill 72 65 -401 135 65 -401 minecraft:air
fill 72 65 -402 135 65 -402 minecraft:air
fill 72 65 -403 135 65 -403 minecraft:air
fill 72 65 -404 135 65 -404 minecraft:air
fill 72 65 -405 135 65 -405 minecraft:air
fill 72 65 -406 135 65 -406 minecraft:air
fill 72 65 -407 135 65 -407 minecraft:air
fill 72 65 -408 135 65 -408 minecraft:air
fill 72 65 -409 135 65 -409 minecraft:air
fill 72 65 -410 135 65 -410 minecraft:air
fill 72 65 -411 135 65 -411 minecraft:air
fill 72 65 -412 135 65 -412 minecraft:air
fill 72 65 -413 135 65 -413 minecraft:air
fill 72 65 -414 135 65 -414 minecraft:air
fill 72 65 -415 135 65 -415 minecraft:air
fill 72 65 -416 135 65 -416 minecraft:air
fill 72 65 -417 135 65 -417 minecraft:air
fill 72 65 -418 135 65 -418 minecraft:air
fill 72 65 -419 135 65 -419 minecraft:air
fill 72 65 -420 135 65 -420 minecraft:air
fill 72 65 -421 135 65 -421 minecraft:air
fill 72 65 -422 135 65 -422 minecraft:air
fill 72 65 -423 135 65 -423 minecraft:air
fill 72 65 -424 135 65 -424 minecraft:air
fill 72 65 -425 135 65 -425 minecraft:air
fill 72 65 -426 135 65 -426 minecraft:air
fill 72 65 -427 135 65 -427 minecraft:air
fill 72 65 -428 135 65 -428 minecraft:air
fill 72 65 -429 135 65 -429 minecraft:air
fill 72 65 -430 135 65 -430 minecraft:air
fill 72 65 -431 135 65 -431 minecraft:air
fill 72 65 -432 135 65 -432 minecraft:air
fill 72 65 -433 135 65 -433 minecraft:air
fill 72 65 -434 135 65 -434 minecraft:air
fill 72 65 -435 135 65 -435 minecraft:air
fill 72 65 -436 135 65 -436 minecraft:air
fill 72 65 -437 135 65 -437 minecraft:air
fill 72 65 -438 135 65 -438 minecraft:air
fill 72 65 -439 135 65 -439 minecraft:air
fill 72 65 -440 135 65 -440 minecraft:air
fill 72 65 -441 135 65 -441 minecraft:air
fill 72 65 -442 135 65 -442 minecraft:air
fill 72 65 -443 135 65 -443 minecraft:air
fill 72 65 -444 87 65 -444 minecraft:air
fill 88 65 -444 92 65 -444 minecraft:sand
fill 93 65 -444 135 65 -444 minecraft:air
fill 72 65 -445 87 65 -445 minecraft:air
fill 88 65 -445 93 65 -445 minecraft:sand
fill 94 65 -445 135 65 -445 minecraft:air
fill 72 65 -446 86 65 -446 minecraft:air
fill 87 65 -446 93 65 -446 minecraft:sand
fill 94 65 -446 135 65 -446 minecraft:air
fill 72 64 -383 135 64 -383 minecraft:air
fill 72 64 -384 135 64 -384 minecraft:air
fill 72 64 -385 135 64 -385 minecraft:air
fill 72 64 -386 135 64 -386 minecraft:air
fill 72 64 -387 135 64 -387 minecraft:air
fill 72 64 -388 135 64 -388 minecraft:air
fill 72 64 -389 135 64 -389 minecraft:air
fill 72 64 -390 135 64 -390 minecraft:air
fill 72 64 -391 135 64 -391 minecraft:air
fill 72 64 -392 135 64 -392 minecraft:air
fill 72 64 -393 135 64 -393 minecraft:air
fill 72 64 -394 135 64 -394 minecraft:air
fill 72 64 -395 135 64 -395 minecraft:air
fill 72 64 -396 135 64 -396 minecraft:air
fill 72 64 -397 135 64 -397 minecraft:air
fill 72 64 -398 135 64 -398 minecraft:air
fill 72 64 -399 135 64 -399 minecraft:air
fill 72 64 -400 135 64 -400 minecraft:air
fill 72 64 -401 135 64 -401 minecraft:air
fill 72 64 -402 135 64 -402 minecraft:air
fill 72 64 -403 135 64 -403 minecraft:air
fill 72 64 -404 135 64 -404 minecraft:air
fill 72 64 -405 135 64 -405 minecraft:air
fill 72 64 -406 135 64 -406 minecraft:air
fill 72 64 -407 135 64 -407 minecraft:air
fill 72 64 -408 135 64 -408 minecraft:air
fill 72 64 -409 135 64 -409 minecraft:air
fill 72 64 -410 135 64 -410 minecraft:air
fill 72 64 -411 135 64 -411 minecraft:air
fill 72 64 -412 135 64 -412 minecraft:air
fill 72 64 -413 135 64 -413 minecraft:air
fill 72 64 -414 135 64 -414 minecraft:air
fill 72 64 -415 135 64 -415 minecraft:air
fill 72 64 -416 135 64 -416 minecraft:air
fill 72 64 -417 135 64 -417 minecraft:air
fill 72 64 -418 135 64 -418 minecraft:air
fill 72 64 -419 135 64 -419 minecraft:air
fill 72 64 -420 135 64 -420 minecraft:air
fill 72 64 -421 135 64 -421 minecraft:air
fill 72 64 -422 135 64 -422 minecraft:air
fill 72 64 -423 135 64 -423 minecraft:air
fill 72 64 -424 135 64 -424 minecraft:air
fill 72 64 -425 135 64 -425 minecraft:air
fill 72 64 -426 135 64 -426 minecraft:air
fill 72 64 -427 135 64 -427 minecraft:air
fill 72 64 -428 135 64 -428 minecraft:air
fill 72 64 -429 135 64 -429 minecraft:air
fill 72 64 -430 135 64 -430 minecraft:air
fill 72 64 -431 135 64 -431 minecraft:air
fill 72 64 -432 135 64 -432 minecraft:air
fill 72 64 -433 135 64 -433 minecraft:air
fill 72 64 -434 135 64 -434 minecraft:air
fill 72 64 -435 135 64 -435 minecraft:air
fill 72 64 -436 135 64 -436 minecraft:air
fill 72 64 -437 135 64 -437 minecraft:air
fill 72 64 -438 135 64 -438 minecraft:air
fill 72 64 -439 135 64 -439 minecraft:air
fill 72 64 -440 135 64 -440 minecraft:air
fill 72 64 -441 135 64 -441 minecraft:air
fill 72 64 -442 135 64 -442 minecraft:air
fill 72 64 -443 90 64 -443 minecraft:air
fill 93 64 -443 135 64 -443 minecraft:air
fill 72 64 -444 87 64 -444 minecraft:air
fill 94 64 -444 135 64 -444 minecraft:air
fill 72 64 -445 86 64 -445 minecraft:air
fill 95 64 -445 135 64 -445 minecraft:air
fill 72 64 -446 85 64 -446 minecraft:air
fill 96 64 -446 135 64 -446 minecraft:air
fill 72 63 -383 135 63 -383 minecraft:air
fill 72 63 -384 135 63 -384 minecraft:air
fill 72 63 -385 135 63 -385 minecraft:air
fill 72 63 -386 135 63 -386 minecraft:air
fill 72 63 -387 135 63 -387 minecraft:air
fill 72 63 -388 135 63 -388 minecraft:air
fill 72 63 -389 135 63 -389 minecraft:air
fill 72 63 -390 135 63 -390 minecraft:air
fill 72 63 -391 135 63 -391 minecraft:air
fill 72 63 -392 135 63 -392 minecraft:air
fill 72 63 -393 135 63 -393 minecraft:air
fill 72 63 -394 135 63 -394 minecraft:air
fill 72 63 -395 135 63 -395 minecraft:air
fill 72 63 -396 135 63 -396 minecraft:air
fill 72 63 -397 135 63 -397 minecraft:air
fill 72 63 -398 135 63 -398 minecraft:air
fill 72 63 -399 135 63 -399 minecraft:air
fill 72 63 -400 135 63 -400 minecraft:air
fill 72 63 -401 135 63 -401 minecraft:air
fill 72 63 -402 135 63 -402 minecraft:air
fill 72 63 -403 135 63 -403 minecraft:air
fill 72 63 -404 135 63 -404 minecraft:air
fill 72 63 -405 135 63 -405 minecraft:air
fill 72 63 -406 135 63 -406 minecraft:air
fill 72 63 -407 135 63 -407 minecraft:air
fill 72 63 -408 135 63 -408 minecraft:air
fill 72 63 -409 135 63 -409 minecraft:air
fill 72 63 -410 135 63 -410 minecraft:air
fill 72 63 -411 135 63 -411 minecraft:air
fill 72 63 -412 135 63 -412 minecraft:air
fill 72 63 -413 135 63 -413 minecraft:air
fill 72 63 -414 135 63 -414 minecraft:air
fill 72 63 -415 135 63 -415 minecraft:air
fill 72 63 -416 135 63 -416 minecraft:air
fill 72 63 -417 135 63 -417 minecraft:air
fill 72 63 -418 135 63 -418 minecraft:air
fill 72 63 -419 135 63 -419 minecraft:air
fill 72 63 -420 135 63 -420 minecraft:air
fill 72 63 -421 135 63 -421 minecraft:air
fill 72 63 -422 135 63 -422 minecraft:air
fill 72 63 -423 135 63 -423 minecraft:air
fill 72 63 -424 135 63 -424 minecraft:air
fill 72 63 -425 135 63 -425 minecraft:air
fill 72 63 -426 135 63 -426 minecraft:air
fill 72 63 -427 135 63 -427 minecraft:air
fill 72 63 -428 135 63 -428 minecraft:air
fill 72 63 -429 135 63 -429 minecraft:air
fill 72 63 -430 135 63 -430 minecraft:air
fill 72 63 -431 135 63 -431 minecraft:air
fill 72 63 -432 135 63 -432 minecraft:air
fill 72 63 -433 135 63 -433 minecraft:air
fill 72 63 -434 135 63 -434 minecraft:air
fill 72 63 -435 135 63 -435 minecraft:air
fill 72 63 -436 135 63 -436 minecraft:air
fill 72 63 -437 135 63 -437 minecraft:air
fill 72 63 -438 135 63 -438 minecraft:air
fill 72 63 -439 135 63 -439 minecraft:air
fill 72 63 -440 135 63 -440 minecraft:air
fill 72 63 -441 135 63 -441 minecraft:air
fill 72 63 -442 90 63 -442 minecraft:air
fill 93 63 -442 135 63 -442 minecraft:air
fill 72 63 -443 87 63 -443 minecraft:air
fill 94 63 -443 135 63 -443 minecraft:air
fill 72 63 -444 86 63 -444 minecraft:air
fill 95 63 -444 135 63 -444 minecraft:air
fill 72 63 -445 85 63 -445 minecraft:air
fill 96 63 -445 135 63 -445 minecraft:air
fill 72 63 -446 83 63 -446 minecraft:air
fill 98 63 -446 135 63 -446 minecraft:air
fill 72 62 -383 135 62 -383 minecraft:water[level=0]
fill 72 62 -384 135 62 -384 minecraft:water[level=0]
fill 72 62 -385 135 62 -385 minecraft:water[level=0]
fill 72 62 -386 135 62 -386 minecraft:water[level=0]
fill 72 62 -387 135 62 -387 minecraft:water[level=0]
fill 72 62 -388 135 62 -388 minecraft:water[level=0]
fill 72 62 -389 135 62 -389 minecraft:water[level=0]
fill 72 62 -390 135 62 -390 minecraft:water[level=0]
fill 72 62 -391 135 62 -391 minecraft:water[level=0]
fill 72 62 -392 135 62 -392 minecraft:water[level=0]
fill 72 62 -393 135 62 -393 minecraft:water[level=0]
fill 72 62 -394 135 62 -394 minecraft:water[level=0]
fill 72 62 -395 135 62 -395 minecraft:water[level=0]
fill 72 62 -396 135 62 -396 minecraft:water[level=0]
fill 72 62 -397 135 62 -397 minecraft:water[level=0]
fill 72 62 -398 135 62 -398 minecraft:water[level=0]
fill 72 62 -399 135 62 -399 minecraft:water[level=0]
fill 72 62 -400 135 62 -400 minecraft:water[level=0]
fill 72 62 -401 135 62 -401 minecraft:water[level=0]
fill 72 62 -402 135 62 -402 minecraft:water[level=0]
fill 72 62 -403 135 62 -403 minecraft:water[level=0]
fill 72 62 -404 135 62 -404 minecraft:water[level=0]
fill 72 62 -405 135 62 -405 minecraft:water[level=0]
fill 72 62 -406 135 62 -406 minecraft:water[level=0]
fill 72 62 -407 135 62 -407 minecraft:water[level=0]
fill 72 62 -408 135 62 -408 minecraft:water[level=0]
fill 72 62 -409 135 62 -409 minecraft:water[level=0]
fill 72 62 -410 135 62 -410 minecraft:water[level=0]
fill 72 62 -411 135 62 -411 minecraft:water[level=0]
fill 72 62 -412 135 62 -412 minecraft:water[level=0]
fill 72 62 -413 135 62 -413 minecraft:water[level=0]
fill 72 62 -414 135 62 -414 minecraft:water[level=0]
fill 72 62 -415 135 62 -415 minecraft:water[level=0]
fill 72 62 -416 135 62 -416 minecraft:water[level=0]
fill 72 62 -417 135 62 -417 minecraft:water[level=0]
fill 72 62 -418 74 62 -418 minecraft:water[level=0]
setblock 75 62 -418 minecraft:kelp[age=24]
fill 76 62 -418 135 62 -418 minecraft:water[level=0]
fill 72 62 -419 76 62 -419 minecraft:water[level=0]
setblock 77 62 -419 minecraft:kelp[age=23]
fill 78 62 -419 135 62 -419 minecraft:water[level=0]
fill 72 62 -420 135 62 -420 minecraft:water[level=0]
fill 72 62 -421 135 62 -421 minecraft:water[level=0]
fill 72 62 -422 135 62 -422 minecraft:water[level=0]
fill 72 62 -423 135 62 -423 minecraft:water[level=0]
fill 72 62 -424 135 62 -424 minecraft:water[level=0]
fill 72 62 -425 135 62 -425 minecraft:water[level=0]
fill 72 62 -426 135 62 -426 minecraft:water[level=0]
fill 72 62 -427 135 62 -427 minecraft:water[level=0]
fill 72 62 -428 135 62 -428 minecraft:water[level=0]
fill 72 62 -429 135 62 -429 minecraft:water[level=0]
fill 72 62 -430 135 62 -430 minecraft:water[level=0]
fill 72 62 -431 135 62 -431 minecraft:water[level=0]
fill 72 62 -432 135 62 -432 minecraft:water[level=0]
fill 72 62 -433 135 62 -433 minecraft:water[level=0]
fill 72 62 -434 135 62 -434 minecraft:water[level=0]
fill 72 62 -435 135 62 -435 minecraft:water[level=0]
fill 72 62 -436 135 62 -436 minecraft:water[level=0]
fill 72 62 -437 135 62 -437 minecraft:water[level=0]
fill 72 62 -438 135 62 -438 minecraft:water[level=0]
fill 72 62 -439 135 62 -439 minecraft:water[level=0]
fill 72 62 -440 135 62 -440 minecraft:water[level=0]
fill 72 62 -441 135 62 -441 minecraft:water[level=0]
fill 72 62 -442 87 62 -442 minecraft:water[level=0]
fill 94 62 -442 135 62 -442 minecraft:water[level=0]
fill 72 62 -443 86 62 -443 minecraft:water[level=0]
fill 95 62 -443 135 62 -443 minecraft:water[level=0]
fill 72 62 -444 85 62 -444 minecraft:water[level=0]
fill 96 62 -444 135 62 -444 minecraft:water[level=0]
fill 72 62 -445 84 62 -445 minecraft:water[level=0]
fill 98 62 -445 134 62 -445 minecraft:water[level=0]
fill 72 62 -446 82 62 -446 minecraft:water[level=0]
fill 100 62 -446 134 62 -446 minecraft:water[level=0]
fill 72 61 -383 84 61 -383 minecraft:water[level=0]
setblock 85 61 -383 minecraft:kelp[age=25]
fill 86 61 -383 135 61 -383 minecraft:water[level=0]
fill 72 61 -384 135 61 -384 minecraft:water[level=0]
fill 72 61 -385 135 61 -385 minecraft:water[level=0]
fill 72 61 -386 135 61 -386 minecraft:water[level=0]
fill 72 61 -387 135 61 -387 minecraft:water[level=0]
fill 72 61 -388 135 61 -388 minecraft:water[level=0]
fill 72 61 -389 135 61 -389 minecraft:water[level=0]
fill 72 61 -390 135 61 -390 minecraft:water[level=0]
fill 72 61 -391 135 61 -391 minecraft:water[level=0]
fill 72 61 -392 135 61 -392 minecraft:water[level=0]
fill 72 61 -393 135 61 -393 minecraft:water[level=0]
fill 72 61 -394 135 61 -394 minecraft:water[level=0]
fill 72 61 -395 135 61 -395 minecraft:water[level=0]
fill 72 61 -396 135 61 -396 minecraft:water[level=0]
fill 72 61 -397 135 61 -397 minecraft:water[level=0]
fill 72 61 -398 135 61 -398 minecraft:water[level=0]
fill 72 61 -399 135 61 -399 minecraft:water[level=0]
fill 72 61 -400 135 61 -400 minecraft:water[level=0]
fill 72 61 -401 135 61 -401 minecraft:water[level=0]
fill 72 61 -402 135 61 -402 minecraft:water[level=0]
fill 72 61 -403 135 61 -403 minecraft:water[level=0]
fill 72 61 -404 135 61 -404 minecraft:water[level=0]
fill 72 61 -405 135 61 -405 minecraft:water[level=0]
fill 72 61 -406 135 61 -406 minecraft:water[level=0]
fill 72 61 -407 135 61 -407 minecraft:water[level=0]
fill 72 61 -408 135 61 -408 minecraft:water[level=0]
fill 72 61 -409 135 61 -409 minecraft:water[level=0]
fill 72 61 -410 135 61 -410 minecraft:water[level=0]
fill 72 61 -411 135 61 -411 minecraft:water[level=0]
fill 72 61 -412 135 61 -412 minecraft:water[level=0]
fill 72 61 -413 135 61 -413 minecraft:water[level=0]
fill 72 61 -414 135 61 -414 minecraft:water[level=0]
fill 72 61 -415 135 61 -415 minecraft:water[level=0]
fill 72 61 -416 135 61 -416 minecraft:water[level=0]
fill 72 61 -417 135 61 -417 minecraft:water[level=0]
fill 72 61 -418 74 61 -418 minecraft:water[level=0]
setblock 75 61 -418 minecraft:kelp_plant
fill 76 61 -418 135 61 -418 minecraft:water[level=0]
setblock 72 61 -419 minecraft:water[level=0]
setblock 73 61 -419 minecraft:kelp[age=21]
fill 74 61 -419 76 61 -419 minecraft:water[level=0]
setblock 77 61 -419 minecraft:kelp_plant
fill 78 61 -419 135 61 -419 minecraft:water[level=0]
fill 72 61 -420 135 61 -420 minecraft:water[level=0]
fill 72 61 -421 135 61 -421 minecraft:water[level=0]
fill 72 61 -422 135 61 -422 minecraft:water[level=0]
fill 72 61 -423 135 61 -423 minecraft:water[level=0]
fill 72 61 -424 135 61 -424 minecraft:water[level=0]
fill 72 61 -425 135 61 -425 minecraft:water[level=0]
fill 72 61 -426 135 61 -426 minecraft:water[level=0]
fill 72 61 -427 135 61 -427 minecraft:water[level=0]
fill 72 61 -428 135 61 -428 minecraft:water[level=0]
fill 72 61 -429 135 61 -429 minecraft:water[level=0]
fill 72 61 -430 135 61 -430 minecraft:water[level=0]
fill 72 61 -431 135 61 -431 minecraft:water[level=0]
fill 72 61 -432 135 61 -432 minecraft:water[level=0]
fill 72 61 -433 135 61 -433 minecraft:water[level=0]
fill 72 61 -434 135 61 -434 minecraft:water[level=0]
fill 72 61 -435 135 61 -435 minecraft:water[level=0]
fill 72 61 -436 135 61 -436 minecraft:water[level=0]
fill 72 61 -437 135 61 -437 minecraft:water[level=0]
fill 72 61 -438 135 61 -438 minecraft:water[level=0]
fill 72 61 -439 135 61 -439 minecraft:water[level=0]
fill 72 61 -440 135 61 -440 minecraft:water[level=0]
fill 72 61 -441 89 61 -441 minecraft:water[level=0]
fill 93 61 -441 134 61 -441 minecraft:water[level=0]
fill 72 61 -442 86 61 -442 minecraft:water[level=0]
fill 95 61 -442 133 61 -442 minecraft:water[level=0]
fill 72 61 -443 85 61 -443 minecraft:water[level=0]
fill 96 61 -443 131 61 -443 minecraft:water[level=0]
fill 72 61 -444 85 61 -444 minecraft:water[level=0]
fill 97 61 -444 131 61 -444 minecraft:water[level=0]
fill 72 61 -445 83 61 -445 minecraft:water[level=0]
fill 99 61 -445 131 61 -445 minecraft:water[level=0]
fill 72 61 -446 81 61 -446 minecraft:water[level=0]
fill 102 61 -446 131 61 -446 minecraft:water[level=0]
fill 72 60 -383 84 60 -383 minecraft:water[level=0]
setblock 85 60 -383 minecraft:kelp_plant
fill 86 60 -383 135 60 -383 minecraft:water[level=0]
fill 72 60 -384 135 60 -384 minecraft:water[level=0]
fill 72 60 -385 135 60 -385 minecraft:water[level=0]
fill 72 60 -386 135 60 -386 minecraft:water[level=0]
fill 72 60 -387 135 60 -387 minecraft:water[level=0]
fill 72 60 -388 135 60 -388 minecraft:water[level=0]
fill 72 60 -389 135 60 -389 minecraft:water[level=0]
fill 72 60 -390 135 60 -390 minecraft:water[level=0]
fill 72 60 -391 135 60 -391 minecraft:water[level=0]
fill 72 60 -392 135 60 -392 minecraft:water[level=0]
fill 72 60 -393 135 60 -393 minecraft:water[level=0]
fill 72 60 -394 135 60 -394 minecraft:water[level=0]
fill 72 60 -395 135 60 -395 minecraft:water[level=0]
fill 72 60 -396 135 60 -396 minecraft:water[level=0]
fill 72 60 -397 135 60 -397 minecraft:water[level=0]
fill 72 60 -398 135 60 -398 minecraft:water[level=0]
fill 72 60 -399 135 60 -399 minecraft:water[level=0]
fill 72 60 -400 135 60 -400 minecraft:water[level=0]
fill 72 60 -401 135 60 -401 minecraft:water[level=0]
fill 72 60 -402 135 60 -402 minecraft:water[level=0]
fill 72 60 -403 135 60 -403 minecraft:water[level=0]
fill 72 60 -404 135 60 -404 minecraft:water[level=0]
fill 72 60 -405 135 60 -405 minecraft:water[level=0]
fill 72 60 -406 135 60 -406 minecraft:water[level=0]
fill 72 60 -407 135 60 -407 minecraft:water[level=0]
fill 72 60 -408 135 60 -408 minecraft:water[level=0]
fill 72 60 -409 135 60 -409 minecraft:water[level=0]
fill 72 60 -410 135 60 -410 minecraft:water[level=0]
fill 72 60 -411 135 60 -411 minecraft:water[level=0]
fill 72 60 -412 135 60 -412 minecraft:water[level=0]
fill 72 60 -413 135 60 -413 minecraft:water[level=0]
fill 72 60 -414 135 60 -414 minecraft:water[level=0]
fill 72 60 -415 135 60 -415 minecraft:water[level=0]
fill 72 60 -416 135 60 -416 minecraft:water[level=0]
fill 72 60 -417 135 60 -417 minecraft:water[level=0]
fill 72 60 -418 74 60 -418 minecraft:water[level=0]
setblock 75 60 -418 minecraft:kelp_plant
fill 76 60 -418 135 60 -418 minecraft:water[level=0]
setblock 72 60 -419 minecraft:water[level=0]
setblock 73 60 -419 minecraft:kelp_plant
fill 74 60 -419 76 60 -419 minecraft:water[level=0]
setblock 77 60 -419 minecraft:kelp_plant
fill 78 60 -419 135 60 -419 minecraft:water[level=0]
fill 72 60 -420 135 60 -420 minecraft:water[level=0]
fill 72 60 -421 135 60 -421 minecraft:water[level=0]
fill 72 60 -422 135 60 -422 minecraft:water[level=0]
fill 72 60 -423 135 60 -423 minecraft:water[level=0]
fill 72 60 -424 135 60 -424 minecraft:water[level=0]
fill 72 60 -425 135 60 -425 minecraft:water[level=0]
fill 72 60 -426 135 60 -426 minecraft:water[level=0]
fill 72 60 -427 135 60 -427 minecraft:water[level=0]
fill 72 60 -428 135 60 -428 minecraft:water[level=0]
fill 72 60 -429 135 60 -429 minecraft:water[level=0]
fill 72 60 -430 135 60 -430 minecraft:water[level=0]
fill 72 60 -431 135 60 -431 minecraft:water[level=0]
fill 72 60 -432 135 60 -432 minecraft:water[level=0]
fill 72 60 -433 135 60 -433 minecraft:water[level=0]
fill 72 60 -434 135 60 -434 minecraft:water[level=0]
fill 72 60 -435 135 60 -435 minecraft:water[level=0]
fill 72 60 -436 135 60 -436 minecraft:water[level=0]
fill 72 60 -437 135 60 -437 minecraft:water[level=0]
fill 72 60 -438 135 60 -438 minecraft:water[level=0]
fill 72 60 -439 134 60 -439 minecraft:water[level=0]
fill 72 60 -440 131 60 -440 minecraft:water[level=0]
fill 72 60 -441 87 60 -441 minecraft:water[level=0]
fill 94 60 -441 130 60 -441 minecraft:water[level=0]
fill 72 60 -442 85 60 -442 minecraft:water[level=0]
fill 96 60 -442 130 60 -442 minecraft:water[level=0]
fill 72 60 -443 85 60 -443 minecraft:water[level=0]
fill 96 60 -443 129 60 -443 minecraft:water[level=0]
fill 72 60 -444 84 60 -444 minecraft:water[level=0]
fill 98 60 -444 129 60 -444 minecraft:water[level=0]
fill 72 60 -445 82 60 -445 minecraft:water[level=0]
fill 100 60 -445 129 60 -445 minecraft:water[level=0]
fill 72 60 -446 80 60 -446 minecraft:water[level=0]
fill 103 60 -446 128 60 -446 minecraft:water[level=0]
fill 72 59 -383 84 59 -383 minecraft:water[level=0]
setblock 85 59 -383 minecraft:kelp_plant
fill 86 59 -383 135 59 -383 minecraft:water[level=0]
fill 72 59 -384 135 59 -384 minecraft:water[level=0]
fill 72 59 -385 135 59 -385 minecraft:water[level=0]
fill 72 59 -386 135 59 -386 minecraft:water[level=0]
fill 72 59 -387 135 59 -387 minecraft:water[level=0]
fill 72 59 -388 90 59 -388 minecraft:water[level=0]
setblock 91 59 -388 minecraft:kelp[age=25]
fill 92 59 -388 135 59 -388 minecraft:water[level=0]
fill 72 59 -389 135 59 -389 minecraft:water[level=0]
fill 72 59 -390 135 59 -390 minecraft:water[level=0]
fill 72 59 -391 135 59 -391 minecraft:water[level=0]
fill 72 59 -392 135 59 -392 minecraft:water[level=0]
fill 72 59 -393 135 59 -393 minecraft:water[level=0]
fill 72 59 -394 135 59 -394 minecraft:water[level=0]
fill 72 59 -395 135 59 -395 minecraft:water[level=0]
fill 72 59 -396 135 59 -396 minecraft:water[level=0]
fill 72 59 -397 135 59 -397 minecraft:water[level=0]
fill 72 59 -398 135 59 -398 minecraft:water[level=0]
fill 72 59 -399 86 59 -399 minecraft:water[level=0]
setblock 87 59 -399 minecraft:kelp[age=25]
fill 88 59 -399 135 59 -399 minecraft:water[level=0]
fill 72 59 -400 135 59 -400 minecraft:water[level=0]
fill 72 59 -401 135 59 -401 minecraft:water[level=0]
fill 72 59 -402 135 59 -402 minecraft:water[level=0]
fill 72 59 -403 135 59 -403 minecraft:water[level=0]
fill 72 59 -404 135 59 -404 minecraft:water[level=0]
fill 72 59 -405 135 59 -405 minecraft:water[level=0]
fill 72 59 -406 135 59 -406 minecraft:water[level=0]
fill 72 59 -407 135 59 -407 minecraft:water[level=0]
fill 72 59 -408 135 59 -408 minecraft:water[level=0]
fill 72 59 -409 135 59 -409 minecraft:water[level=0]
fill 72 59 -410 135 59 -410 minecraft:water[level=0]
fill 72 59 -411 135 59 -411 minecraft:water[level=0]
fill 72 59 -412 135 59 -412 minecraft:water[level=0]
fill 72 59 -413 135 59 -413 minecraft:water[level=0]
fill 72 59 -414 135 59 -414 minecraft:water[level=0]
fill 72 59 -415 135 59 -415 minecraft:water[level=0]
fill 72 59 -416 135 59 -416 minecraft:water[level=0]
fill 72 59 -417 135 59 -417 minecraft:water[level=0]
fill 72 59 -418 74 59 -418 minecraft:water[level=0]
setblock 75 59 -418 minecraft:kelp_plant
fill 76 59 -418 135 59 -418 minecraft:water[level=0]
setblock 72 59 -419 minecraft:water[level=0]
setblock 73 59 -419 minecraft:kelp_plant
fill 74 59 -419 76 59 -419 minecraft:water[level=0]
setblock 77 59 -419 minecraft:kelp_plant
fill 78 59 -419 135 59 -419 minecraft:water[level=0]
fill 72 59 -420 135 59 -420 minecraft:water[level=0]
fill 72 59 -421 135 59 -421 minecraft:water[level=0]
fill 72 59 -422 135 59 -422 minecraft:water[level=0]
fill 72 59 -423 135 59 -423 minecraft:water[level=0]
fill 72 59 -424 135 59 -424 minecraft:water[level=0]
fill 72 59 -425 135 59 -425 minecraft:water[level=0]
fill 72 59 -426 135 59 -426 minecraft:water[level=0]
fill 72 59 -427 135 59 -427 minecraft:water[level=0]
fill 72 59 -428 135 59 -428 minecraft:water[level=0]
fill 72 59 -429 135 59 -429 minecraft:water[level=0]
fill 72 59 -430 135 59 -430 minecraft:water[level=0]
fill 72 59 -431 135 59 -431 minecraft:water[level=0]
fill 72 59 -432 135 59 -432 minecraft:water[level=0]
fill 72 59 -433 135 59 -433 minecraft:water[level=0]
fill 72 59 -434 135 59 -434 minecraft:water[level=0]
fill 72 59 -435 135 59 -435 minecraft:water[level=0]
fill 72 59 -436 135 59 -436 minecraft:water[level=0]
fill 72 59 -437 135 59 -437 minecraft:water[level=0]
fill 72 59 -438 131 59 -438 minecraft:water[level=0]
fill 72 59 -439 130 59 -439 minecraft:water[level=0]
fill 72 59 -440 129 59 -440 minecraft:water[level=0]
fill 72 59 -441 86 59 -441 minecraft:water[level=0]
fill 95 59 -441 128 59 -441 minecraft:water[level=0]
fill 72 59 -442 85 59 -442 minecraft:water[level=0]
fill 96 59 -442 128 59 -442 minecraft:water[level=0]
fill 72 59 -443 84 59 -443 minecraft:water[level=0]
fill 97 59 -443 128 59 -443 minecraft:water[level=0]
fill 72 59 -444 84 59 -444 minecraft:water[level=0]
fill 98 59 -444 128 59 -444 minecraft:water[level=0]
fill 72 59 -445 81 59 -445 minecraft:water[level=0]
fill 102 59 -445 127 59 -445 minecraft:water[level=0]
fill 72 59 -446 80 59 -446 minecraft:water[level=0]
fill 104 59 -446 125 59 -446 minecraft:water[level=0]
fill 72 58 -383 84 58 -383 minecraft:water[level=0]
setblock 85 58 -383 minecraft:kelp_plant
fill 86 58 -383 135 58 -383 minecraft:water[level=0]
fill 72 58 -384 135 58 -384 minecraft:water[level=0]
fill 72 58 -385 135 58 -385 minecraft:water[level=0]
fill 72 58 -386 135 58 -386 minecraft:water[level=0]
fill 72 58 -387 135 58 -387 minecraft:water[level=0]
fill 72 58 -388 90 58 -388 minecraft:water[level=0]
setblock 91 58 -388 minecraft:kelp_plant
fill 92 58 -388 135 58 -388 minecraft:water[level=0]
fill 72 58 -389 80 58 -389 minecraft:water[level=0]
setblock 81 58 -389 minecraft:kelp[age=21]
fill 82 58 -389 135 58 -389 minecraft:water[level=0]
fill 72 58 -390 135 58 -390 minecraft:water[level=0]
fill 72 58 -391 135 58 -391 minecraft:water[level=0]
fill 72 58 -392 135 58 -392 minecraft:water[level=0]
fill 72 58 -393 135 58 -393 minecraft:water[level=0]
fill 72 58 -394 135 58 -394 minecraft:water[level=0]
fill 72 58 -395 135 58 -395 minecraft:water[level=0]
fill 72 58 -396 88 58 -396 minecraft:water[level=0]
setblock 89 58 -396 minecraft:kelp[age=25]
fill 90 58 -396 135 58 -396 minecraft:water[level=0]
fill 72 58 -397 135 58 -397 minecraft:water[level=0]
fill 72 58 -398 85 58 -398 minecraft:water[level=0]
setblock 86 58 -398 minecraft:kelp[age=24]
fill 87 58 -398 135 58 -398 minecraft:water[level=0]
fill 72 58 -399 86 58 -399 minecraft:water[level=0]
setblock 87 58 -399 minecraft:kelp_plant
fill 88 58 -399 135 58 -399 minecraft:water[level=0]
fill 72 58 -400 135 58 -400 minecraft:water[level=0]
fill 72 58 -401 135 58 -401 minecraft:water[level=0]
fill 72 58 -402 135 58 -402 minecraft:water[level=0]
fill 72 58 -403 135 58 -403 minecraft:water[level=0]
fill 72 58 -404 135 58 -404 minecraft:water[level=0]
fill 72 58 -405 135 58 -405 minecraft:water[level=0]
fill 72 58 -406 135 58 -406 minecraft:water[level=0]
fill 72 58 -407 135 58 -407 minecraft:water[level=0]
fill 72 58 -408 135 58 -408 minecraft:water[level=0]
fill 72 58 -409 135 58 -409 minecraft:water[level=0]
fill 72 58 -410 135 58 -410 minecraft:water[level=0]
fill 72 58 -411 135 58 -411 minecraft:water[level=0]
fill 72 58 -412 135 58 -412 minecraft:water[level=0]
fill 72 58 -413 135 58 -413 minecraft:water[level=0]
fill 72 58 -414 135 58 -414 minecraft:water[level=0]
fill 72 58 -415 135 58 -415 minecraft:water[level=0]
fill 72 58 -416 135 58 -416 minecraft:water[level=0]
fill 72 58 -417 135 58 -417 minecraft:water[level=0]
fill 72 58 -418 74 58 -418 minecraft:water[level=0]
setblock 75 58 -418 minecraft:kelp_plant
fill 76 58 -418 135 58 -418 minecraft:water[level=0]
setblock 72 58 -419 minecraft:water[level=0]
setblock 73 58 -419 minecraft:kelp_plant
fill 74 58 -419 76 58 -419 minecraft:water[level=0]
setblock 77 58 -419 minecraft:kelp_plant
fill 78 58 -419 135 58 -419 minecraft:water[level=0]
fill 72 58 -420 135 58 -420 minecraft:water[level=0]
fill 72 58 -421 135 58 -421 minecraft:water[level=0]
fill 72 58 -422 135 58 -422 minecraft:water[level=0]
fill 72 58 -423 135 58 -423 minecraft:water[level=0]
fill 72 58 -424 135 58 -424 minecraft:water[level=0]
fill 72 58 -425 135 58 -425 minecraft:water[level=0]
fill 72 58 -426 135 58 -426 minecraft:water[level=0]
fill 72 58 -427 135 58 -427 minecraft:water[level=0]
fill 72 58 -428 135 58 -428 minecraft:water[level=0]
fill 72 58 -429 135 58 -429 minecraft:water[level=0]
fill 72 58 -430 135 58 -430 minecraft:water[level=0]
fill 72 58 -431 135 58 -431 minecraft:water[level=0]
fill 72 58 -432 135 58 -432 minecraft:water[level=0]
fill 72 58 -433 135 58 -433 minecraft:water[level=0]
fill 72 58 -434 133 58 -434 minecraft:water[level=0]
setblock 134 58 -434 minecraft:tall_seagrass[half=upper]
setblock 135 58 -434 minecraft:water[level=0]
fill 72 58 -435 135 58 -435 minecraft:water[level=0]
fill 72 58 -436 135 58 -436 minecraft:water[level=0]
fill 72 58 -437 130 58 -437 minecraft:water[level=0]
fill 72 58 -438 128 58 -438 minecraft:water[level=0]
fill 72 58 -439 128 58 -439 minecraft:water[level=0]
fill 72 58 -440 124 58 -440 minecraft:water[level=0]
fill 72 58 -441 85 58 -441 minecraft:water[level=0]
fill 95 58 -441 123 58 -441 minecraft:water[level=0]
fill 72 58 -442 84 58 -442 minecraft:water[level=0]
fill 96 58 -442 123 58 -442 minecraft:water[level=0]
fill 72 58 -443 84 58 -443 minecraft:water[level=0]
fill 98 58 -443 122 58 -443 minecraft:water[level=0]
fill 72 58 -444 84 58 -444 minecraft:water[level=0]
fill 99 58 -444 121 58 -444 minecraft:water[level=0]
fill 72 58 -445 80 58 -445 minecraft:water[level=0]
fill 104 58 -445 115 58 -445 minecraft:water[level=0]
fill 74 58 -446 80 58 -446 minecraft:water[level=0]
fill 105 58 -446 114 58 -446 minecraft:water[level=0]
fill 72 57 -383 84 57 -383 minecraft:water[level=0]
setblock 85 57 -383 minecraft:kelp_plant
fill 86 57 -383 135 57 -383 minecraft:water[level=0]
fill 72 57 -384 135 57 -384 minecraft:water[level=0]
fill 72 57 -385 135 57 -385 minecraft:water[level=0]
fill 72 57 -386 135 57 -386 minecraft:water[level=0]
fill 72 57 -387 135 57 -387 minecraft:water[level=0]
fill 72 57 -388 90 57 -388 minecraft:water[level=0]
setblock 91 57 -388 minecraft:kelp_plant
fill 92 57 -388 135 57 -388 minecraft:water[level=0]
fill 72 57 -389 80 57 -389 minecraft:water[level=0]
setblock 81 57 -389 minecraft:kelp_plant
fill 82 57 -389 135 57 -389 minecraft:water[level=0]
fill 72 57 -390 135 57 -390 minecraft:water[level=0]
fill 72 57 -391 135 57 -391 minecraft:water[level=0]
fill 72 57 -392 135 57 -392 minecraft:water[level=0]
fill 72 57 -393 135 57 -393 minecraft:water[level=0]
fill 72 57 -394 90 57 -394 minecraft:water[level=0]
setblock 91 57 -394 minecraft:kelp[age=25]
fill 92 57 -394 135 57 -394 minecraft:water[level=0]
fill 72 57 -395 131 57 -395 minecraft:water[level=0]
setblock 132 57 -395 minecraft:tall_seagrass[half=upper]
fill 133 57 -395 135 57 -395 minecraft:water[level=0]
fill 72 57 -396 88 57 -396 minecraft:water[level=0]
setblock 89 57 -396 minecraft:kelp_plant
fill 90 57 -396 135 57 -396 minecraft:water[level=0]
fill 72 57 -397 135 57 -397 minecraft:water[level=0]
fill 72 57 -398 85 57 -398 minecraft:water[level=0]
setblock 86 57 -398 minecraft:kelp_plant
fill 87 57 -398 135 57 -398 minecraft:water[level=0]
fill 72 57 -399 86 57 -399 minecraft:water[level=0]
setblock 87 57 -399 minecraft:kelp_plant
fill 88 57 -399 135 57 -399 minecraft:water[level=0]
fill 72 57 -400 135 57 -400 minecraft:water[level=0]
fill 72 57 -401 135 57 -401 minecraft:water[level=0]
fill 72 57 -402 135 57 -402 minecraft:water[level=0]
fill 72 57 -403 135 57 -403 minecraft:water[level=0]
fill 72 57 -404 135 57 -404 minecraft:water[level=0]
fill 72 57 -405 135 57 -405 minecraft:water[level=0]
fill 72 57 -406 135 57 -406 minecraft:water[level=0]
fill 72 57 -407 135 57 -407 minecraft:water[level=0]
fill 72 57 -408 135 57 -408 minecraft:water[level=0]
fill 72 57 -409 135 57 -409 minecraft:water[level=0]
fill 72 57 -410 135 57 -410 minecraft:water[level=0]
fill 72 57 -411 135 57 -411 minecraft:water[level=0]
fill 72 57 -412 134 57 -412 minecraft:water[level=0]
setblock 135 57 -412 minecraft:tall_seagrass[half=upper]
fill 72 57 -413 135 57 -413 minecraft:water[level=0]
fill 72 57 -414 134 57 -414 minecraft:water[level=0]
setblock 135 57 -414 minecraft:tall_seagrass[half=upper]
fill 72 57 -415 134 57 -415 minecraft:water[level=0]
setblock 135 57 -415 minecraft:tall_seagrass[half=upper]
fill 72 57 -416 135 57 -416 minecraft:water[level=0]
fill 72 57 -417 135 57 -417 minecraft:water[level=0]
fill 72 57 -418 74 57 -418 minecraft:water[level=0]
setblock 75 57 -418 minecraft:kelp_plant
fill 76 57 -418 135 57 -418 minecraft:water[level=0]
setblock 72 57 -419 minecraft:water[level=0]
setblock 73 57 -419 minecraft:kelp_plant
fill 74 57 -419 76 57 -419 minecraft:water[level=0]
setblock 77 57 -419 minecraft:kelp_plant
fill 78 57 -419 132 57 -419 minecraft:water[level=0]
setblock 133 57 -419 minecraft:tall_seagrass[half=upper]
fill 134 57 -419 135 57 -419 minecraft:water[level=0]
fill 72 57 -420 135 57 -420 minecraft:water[level=0]
fill 72 57 -421 135 57 -421 minecraft:water[level=0]
fill 72 57 -422 135 57 -422 minecraft:water[level=0]
fill 72 57 -423 135 57 -423 minecraft:water[level=0]
fill 72 57 -424 135 57 -424 minecraft:water[level=0]
fill 72 57 -425 135 57 -425 minecraft:water[level=0]
fill 72 57 -426 135 57 -426 minecraft:water[level=0]
fill 72 57 -427 135 57 -427 minecraft:water[level=0]
fill 72 57 -428 135 57 -428 minecraft:water[level=0]
fill 72 57 -429 135 57 -429 minecraft:water[level=0]
fill 72 57 -430 135 57 -430 minecraft:water[level=0]
fill 72 57 -431 135 57 -431 minecraft:water[level=0]
fill 72 57 -432 135 57 -432 minecraft:water[level=0]
fill 72 57 -433 135 57 -433 minecraft:water[level=0]
fill 72 57 -434 133 57 -434 minecraft:water[level=0]
setblock 134 57 -434 minecraft:tall_seagrass[half=lower]
setblock 135 57 -434 minecraft:water[level=0]
fill 72 57 -435 130 57 -435 minecraft:water[level=0]
fill 134 57 -435 135 57 -435 minecraft:water[level=0]
fill 72 57 -436 128 57 -436 minecraft:water[level=0]
fill 72 57 -437 126 57 -437 minecraft:water[level=0]
fill 72 57 -438 123 57 -438 minecraft:water[level=0]
fill 72 57 -439 120 57 -439 minecraft:water[level=0]
fill 72 57 -440 90 57 -440 minecraft:water[level=0]
fill 93 57 -440 119 57 -440 minecraft:water[level=0]
fill 72 57 -441 85 57 -441 minecraft:water[level=0]
fill 96 57 -441 118 57 -441 minecraft:water[level=0]
fill 72 57 -442 84 57 -442 minecraft:water[level=0]
fill 97 57 -442 116 57 -442 minecraft:water[level=0]
fill 72 57 -443 84 57 -443 minecraft:water[level=0]
fill 99 57 -443 115 57 -443 minecraft:water[level=0]
fill 72 57 -444 84 57 -444 minecraft:water[level=0]
fill 100 57 -444 114 57 -444 minecraft:water[level=0]
fill 74 57 -445 80 57 -445 minecraft:water[level=0]
fill 105 57 -445 114 57 -445 minecraft:water[level=0]
fill 76 57 -446 77 57 -446 minecraft:water[level=0]
fill 107 57 -446 113 57 -446 minecraft:water[level=0]
fill 72 56 -383 84 56 -383 minecraft:water[level=0]
setblock 85 56 -383 minecraft:kelp_plant
fill 86 56 -383 135 56 -383 minecraft:water[level=0]
fill 72 56 -384 128 56 -384 minecraft:water[level=0]
setblock 129 56 -384 minecraft:tall_seagrass[half=upper]
fill 130 56 -384 134 56 -384 minecraft:water[level=0]
setblock 135 56 -384 minecraft:tall_seagrass[half=upper]
fill 72 56 -385 127 56 -385 minecraft:water[level=0]
setblock 128 56 -385 minecraft:tall_seagrass[half=upper]
setblock 129 56 -385 minecraft:water[level=0]
setblock 130 56 -385 minecraft:tall_seagrass[half=upper]
fill 131 56 -385 134 56 -385 minecraft:water[level=0]
setblock 135 56 -385 minecraft:tall_seagrass[half=upper]
fill 72 56 -386 132 56 -386 minecraft:water[level=0]
setblock 133 56 -386 minecraft:tall_seagrass[half=upper]
setblock 134 56 -386 minecraft:water[level=0]
setblock 135 56 -386 minecraft:tall_seagrass[half=upper]
fill 72 56 -387 135 56 -387 minecraft:water[level=0]
fill 72 56 -388 90 56 -388 minecraft:water[level=0]
setblock 91 56 -388 minecraft:kelp_plant
fill 92 56 -388 124 56 -388 minecraft:water[level=0]
setblock 125 56 -388 minecraft:tall_seagrass[half=upper]
fill 126 56 -388 134 56 -388 minecraft:water[level=0]
setblock 135 56 -388 minecraft:tall_seagrass[half=upper]
fill 72 56 -389 80 56 -389 minecraft:water[level=0]
setblock 81 56 -389 minecraft:kelp_plant
fill 82 56 -389 84 56 -389 minecraft:water[level=0]
setblock 85 56 -389 minecraft:kelp[age=25]
fill 86 56 -389 126 56 -389 minecraft:water[level=0]
fill 127 56 -389 128 56 -389 minecraft:tall_seagrass[half=upper]
fill 129 56 -389 130 56 -389 minecraft:water[level=0]
setblock 131 56 -389 minecraft:tall_seagrass[half=upper]
fill 132 56 -389 133 56 -389 minecraft:water[level=0]
setblock 134 56 -389 minecraft:tall_seagrass[half=upper]
setblock 135 56 -389 minecraft:water[level=0]
fill 72 56 -390 125 56 -390 minecraft:water[level=0]
fill 126 56 -390 127 56 -390 minecraft:tall_seagrass[half=upper]
fill 128 56 -390 131 56 -390 minecraft:water[level=0]
setblock 132 56 -390 minecraft:tall_seagrass[half=upper]
fill 133 56 -390 135 56 -390 minecraft:water[level=0]
fill 72 56 -391 130 56 -391 minecraft:water[level=0]
setblock 131 56 -391 minecraft:tall_seagrass[half=upper]
fill 132 56 -391 135 56 -391 minecraft:water[level=0]
fill 72 56 -392 125 56 -392 minecraft:water[level=0]
setblock 126 56 -392 minecraft:tall_seagrass[half=upper]
fill 127 56 -392 133 56 -392 minecraft:water[level=0]
setblock 134 56 -392 minecraft:tall_seagrass[half=upper]
setblock 135 56 -392 minecraft:water[level=0]
fill 72 56 -393 128 56 -393 minecraft:water[level=0]
setblock 129 56 -393 minecraft:tall_seagrass[half=upper]
fill 130 56 -393 134 56 -393 minecraft:water[level=0]
setblock 135 56 -393 minecraft:tall_seagrass[half=upper]
fill 72 56 -394 90 56 -394 minecraft:water[level=0]
setblock 91 56 -394 minecraft:kelp_plant
fill 92 56 -394 127 56 -394 minecraft:water[level=0]
setblock 128 56 -394 minecraft:tall_seagrass[half=upper]
fill 129 56 -394 131 56 -394 minecraft:water[level=0]
fill 132 56 -394 133 56 -394 minecraft:tall_seagrass[half=upper]
setblock 134 56 -394 minecraft:seagrass
setblock 135 56 -394 minecraft:water[level=0]
fill 72 56 -395 131 56 -395 minecraft:water[level=0]
setblock 132 56 -395 minecraft:tall_seagrass[half=lower]
setblock 133 56 -395 minecraft:seagrass
fill 134 56 -395 135 56 -395 minecraft:water[level=0]
fill 72 56 -396 88 56 -396 minecraft:water[level=0]
setblock 89 56 -396 minecraft:kelp_plant
fill 90 56 -396 131 56 -396 minecraft:water[level=0]
setblock 132 56 -396 minecraft:seagrass
fill 133 56 -396 134 56 -396 minecraft:water[level=0]
setblock 135 56 -396 minecraft:seagrass
fill 72 56 -397 131 56 -397 minecraft:water[level=0]
setblock 132 56 -397 minecraft:seagrass
fill 133 56 -397 135 56 -397 minecraft:water[level=0]
fill 72 56 -398 85 56 -398 minecraft:water[level=0]
setblock 86 56 -398 minecraft:kelp_plant
fill 87 56 -398 135 56 -398 minecraft:water[level=0]
fill 72 56 -399 86 56 -399 minecraft:water[level=0]
setblock 87 56 -399 minecraft:kelp_plant
fill 88 56 -399 135 56 -399 minecraft:water[level=0]
fill 72 56 -400 135 56 -400 minecraft:water[level=0]
fill 72 56 -401 135 56 -401 minecraft:water[level=0]
fill 72 56 -402 135 56 -402 minecraft:water[level=0]
fill 72 56 -403 135 56 -403 minecraft:water[level=0]
fill 72 56 -404 135 56 -404 minecraft:water[level=0]
fill 72 56 -405 135 56 -405 minecraft:water[level=0]
fill 72 56 -406 135 56 -406 minecraft:water[level=0]
fill 72 56 -407 134 56 -407 minecraft:water[level=0]
setblock 135 56 -407 minecraft:seagrass
fill 72 56 -408 135 56 -408 minecraft:water[level=0]
fill 72 56 -409 135 56 -409 minecraft:water[level=0]
fill 72 56 -410 135 56 -410 minecraft:water[level=0]
fill 72 56 -411 131 56 -411 minecraft:water[level=0]
fill 132 56 -411 133 56 -411 minecraft:tall_seagrass[half=upper]
setblock 134 56 -411 minecraft:water[level=0]
setblock 135 56 -411 minecraft:seagrass
fill 72 56 -412 132 56 -412 minecraft:water[level=0]
setblock 133 56 -412 minecraft:tall_seagrass[half=upper]
setblock 134 56 -412 minecraft:water[level=0]
setblock 135 56 -412 minecraft:tall_seagrass[half=lower]
fill 72 56 -413 135 56 -413 minecraft:water[level=0]
fill 72 56 -414 130 56 -414 minecraft:water[level=0]
setblock 131 56 -414 minecraft:tall_seagrass[half=upper]
fill 132 56 -414 134 56 -414 minecraft:water[level=0]
setblock 135 56 -414 minecraft:tall_seagrass[half=lower]
fill 72 56 -415 134 56 -415 minecraft:water[level=0]
setblock 135 56 -415 minecraft:tall_seagrass[half=lower]
fill 72 56 -416 135 56 -416 minecraft:water[level=0]
fill 72 56 -417 135 56 -417 minecraft:water[level=0]
fill 72 56 -418 74 56 -418 minecraft:water[level=0]
setblock 75 56 -418 minecraft:kelp_plant
fill 76 56 -418 134 56 -418 minecraft:water[level=0]
setblock 135 56 -418 minecraft:seagrass
setblock 72 56 -419 minecraft:water[level=0]
setblock 73 56 -419 minecraft:kelp_plant
fill 74 56 -419 76 56 -419 minecraft:water[level=0]
setblock 77 56 -419 minecraft:kelp_plant
fill 78 56 -419 132 56 -419 minecraft:water[level=0]
setblock 133 56 -419 minecraft:tall_seagrass[half=lower]
fill 134 56 -419 135 56 -419 minecraft:water[level=0]
setblock 72 56 -420 minecraft:tall_seagrass[half=upper]
fill 73 56 -420 135 56 -420 minecraft:water[level=0]
fill 72 56 -421 135 56 -421 minecraft:water[level=0]
fill 72 56 -422 135 56 -422 minecraft:water[level=0]
fill 72 56 -423 133 56 -423 minecraft:water[level=0]
setblock 134 56 -423 minecraft:seagrass
setblock 135 56 -423 minecraft:water[level=0]
fill 72 56 -424 135 56 -424 minecraft:water[level=0]
fill 72 56 -425 135 56 -425 minecraft:water[level=0]
fill 72 56 -426 135 56 -426 minecraft:water[level=0]
fill 72 56 -427 132 56 -427 minecraft:water[level=0]
fill 133 56 -427 134 56 -427 minecraft:seagrass
setblock 135 56 -427 minecraft:water[level=0]
fill 72 56 -428 135 56 -428 minecraft:water[level=0]
fill 72 56 -429 133 56 -429 minecraft:water[level=0]
setblock 134 56 -429 minecraft:seagrass
setblock 135 56 -429 minecraft:water[level=0]
fill 72 56 -430 135 56 -430 minecraft:water[level=0]
fill 72 56 -431 133 56 -431 minecraft:water[level=0]
setblock 134 56 -431 minecraft:seagrass
setblock 135 56 -431 minecraft:water[level=0]
fill 72 56 -432 135 56 -432 minecraft:water[level=0]
fill 72 56 -433 130 56 -433 minecraft:water[level=0]
fill 72 56 -434 128 56 -434 minecraft:water[level=0]
fill 72 56 -435 125 56 -435 minecraft:water[level=0]
fill 72 56 -436 120 56 -436 minecraft:water[level=0]
fill 72 56 -437 118 56 -437 minecraft:water[level=0]
fill 72 56 -438 117 56 -438 minecraft:water[level=0]
fill 72 56 -439 90 56 -439 minecraft:water[level=0]
fill 93 56 -439 117 56 -439 minecraft:water[level=0]
fill 72 56 -440 88 56 -440 minecraft:water[level=0]
fill 94 56 -440 116 56 -440 minecraft:water[level=0]
fill 72 56 -441 84 56 -441 minecraft:water[level=0]
fill 96 56 -441 115 56 -441 minecraft:water[level=0]
fill 74 56 -442 84 56 -442 minecraft:water[level=0]
fill 99 56 -442 114 56 -442 minecraft:water[level=0]
fill 74 56 -443 84 56 -443 minecraft:water[level=0]
fill 100 56 -443 114 56 -443 minecraft:water[level=0]
fill 75 56 -444 84 56 -444 minecraft:water[level=0]
fill 100 56 -444 113 56 -444 minecraft:water[level=0]
setblock 76 56 -445 minecraft:water[level=0]
fill 107 56 -445 112 56 -445 minecraft:water[level=0]
fill 108 56 -446 112 56 -446 minecraft:water[level=0]
fill 72 55 -383 84 55 -383 minecraft:water[level=0]
setblock 85 55 -383 minecraft:kelp_plant
fill 86 55 -383 125 55 -383 minecraft:water[level=0]
setblock 126 55 -383 minecraft:tall_seagrass[half=upper]
fill 127 55 -383 135 55 -383 minecraft:water[level=0]
fill 72 55 -384 91 55 -384 minecraft:water[level=0]
setblock 92 55 -384 minecraft:kelp[age=25]
fill 93 55 -384 128 55 -384 minecraft:water[level=0]
setblock 129 55 -384 minecraft:tall_seagrass[half=lower]
fill 130 55 -384 133 55 -384 minecraft:water[level=0]
setblock 134 55 -384 minecraft:seagrass
setblock 135 55 -384 minecraft:tall_seagrass[half=lower]
fill 72 55 -385 125 55 -385 minecraft:water[level=0]
setblock 126 55 -385 minecraft:tall_seagrass[half=upper]
setblock 127 55 -385 minecraft:water[level=0]
setblock 128 55 -385 minecraft:tall_seagrass[half=lower]
setblock 129 55 -385 minecraft:water[level=0]
setblock 130 55 -385 minecraft:tall_seagrass[half=lower]
fill 131 55 -385 134 55 -385 minecraft:water[level=0]
setblock 135 55 -385 minecraft:tall_seagrass[half=lower]
fill 72 55 -386 129 55 -386 minecraft:water[level=0]
setblock 130 55 -386 minecraft:seagrass
setblock 131 55 -386 minecraft:water[level=0]
setblock 132 55 -386 minecraft:seagrass
setblock 133 55 -386 minecraft:tall_seagrass[half=lower]
setblock 134 55 -386 minecraft:water[level=0]
setblock 135 55 -386 minecraft:tall_seagrass[half=lower]
fill 72 55 -387 125 55 -387 minecraft:water[level=0]
setblock 126 55 -387 minecraft:seagrass
fill 127 55 -387 129 55 -387 minecraft:water[level=0]
setblock 130 55 -387 minecraft:seagrass
fill 131 55 -387 135 55 -387 minecraft:water[level=0]
fill 72 55 -388 90 55 -388 minecraft:water[level=0]
setblock 91 55 -388 minecraft:kelp_plant
fill 92 55 -388 124 55 -388 minecraft:water[level=0]
setblock 125 55 -388 minecraft:tall_seagrass[half=lower]
setblock 126 55 -388 minecraft:water[level=0]
setblock 127 55 -388 minecraft:seagrass
setblock 128 55 -388 minecraft:water[level=0]
setblock 129 55 -388 minecraft:seagrass
fill 130 55 -388 133 55 -388 minecraft:water[level=0]
setblock 134 55 -388 minecraft:seagrass
setblock 135 55 -388 minecraft:tall_seagrass[half=lower]
fill 72 55 -389 80 55 -389 minecraft:water[level=0]
setblock 81 55 -389 minecraft:kelp_plant
fill 82 55 -389 84 55 -389 minecraft:water[level=0]
setblock 85 55 -389 minecraft:kelp_plant
fill 86 55 -389 122 55 -389 minecraft:water[level=0]
setblock 123 55 -389 minecraft:tall_seagrass[half=upper]
setblock 124 55 -389 minecraft:seagrass
fill 125 55 -389 126 55 -389 minecraft:water[level=0]
fill 127 55 -389 128 55 -389 minecraft:tall_seagrass[half=lower]
setblock 129 55 -389 minecraft:water[level=0]
setblock 130 55 -389 minecraft:seagrass
setblock 131 55 -389 minecraft:tall_seagrass[half=lower]
setblock 132 55 -389 minecraft:seagrass
setblock 133 55 -389 minecraft:water[level=0]
setblock 134 55 -389 minecraft:tall_seagrass[half=lower]
setblock 135 55 -389 minecraft:water[level=0]
fill 72 55 -390 125 55 -390 minecraft:water[level=0]
fill 126 55 -390 127 55 -390 minecraft:tall_seagrass[half=lower]
fill 128 55 -390 129 55 -390 minecraft:water[level=0]
fill 130 55 -390 131 55 -390 minecraft:seagrass
setblock 132 55 -390 minecraft:tall_seagrass[half=lower]
setblock 133 55 -390 minecraft:water[level=0]
setblock 134 55 -390 minecraft:seagrass
setblock 135 55 -390 minecraft:water[level=0]
fill 72 55 -391 128 55 -391 minecraft:water[level=0]
setblock 129 55 -391 minecraft:seagrass
setblock 130 55 -391 minecraft:water[level=0]
setblock 131 55 -391 minecraft:tall_seagrass[half=lower]
setblock 132 55 -391 minecraft:seagrass
fill 133 55 -391 135 55 -391 minecraft:water[level=0]
fill 72 55 -392 123 55 -392 minecraft:water[level=0]
setblock 124 55 -392 minecraft:seagrass
setblock 125 55 -392 minecraft:water[level=0]
setblock 126 55 -392 minecraft:tall_seagrass[half=lower]
setblock 127 55 -392 minecraft:seagrass
fill 128 55 -392 129 55 -392 minecraft:water[level=0]
fill 130 55 -392 131 55 -392 minecraft:seagrass
setblock 132 55 -392 minecraft:water[level=0]
setblock 133 55 -392 minecraft:seagrass
setblock 134 55 -392 minecraft:tall_seagrass[half=lower]
setblock 135 55 -392 minecraft:water[level=0]
fill 72 55 -393 125 55 -393 minecraft:water[level=0]
setblock 126 55 -393 minecraft:tall_seagrass[half=upper]
fill 127 55 -393 128 55 -393 minecraft:water[level=0]
setblock 129 55 -393 minecraft:tall_seagrass[half=lower]
fill 130 55 -393 134 55 -393 minecraft:water[level=0]
setblock 135 55 -393 minecraft:tall_seagrass[half=lower]
fill 72 55 -394 90 55 -394 minecraft:water[level=0]
setblock 91 55 -394 minecraft:kelp_plant
fill 92 55 -394 125 55 -394 minecraft:water[level=0]
setblock 126 55 -394 minecraft:tall_seagrass[half=upper]
setblock 127 55 -394 minecraft:water[level=0]
setblock 128 55 -394 minecraft:tall_seagrass[half=lower]
setblock 129 55 -394 minecraft:seagrass
fill 130 55 -394 131 55 -394 minecraft:water[level=0]
fill 132 55 -394 133 55 -394 minecraft:tall_seagrass[half=lower]
fill 72 55 -395 129 55 -395 minecraft:water[level=0]
setblock 130 55 -395 minecraft:seagrass
setblock 131 55 -395 minecraft:water[level=0]
fill 72 55 -396 88 55 -396 minecraft:water[level=0]
setblock 89 55 -396 minecraft:kelp_plant
fill 90 55 -396 130 55 -396 minecraft:water[level=0]
fill 72 55 -397 131 55 -397 minecraft:water[level=0]
fill 72 55 -398 85 55 -398 minecraft:water[level=0]
setblock 86 55 -398 minecraft:kelp_plant
fill 87 55 -398 131 55 -398 minecraft:water[level=0]
fill 72 55 -399 86 55 -399 minecraft:water[level=0]
setblock 87 55 -399 minecraft:kelp_plant
fill 88 55 -399 131 55 -399 minecraft:water[level=0]
fill 72 55 -400 131 55 -400 minecraft:water[level=0]
fill 72 55 -401 131 55 -401 minecraft:water[level=0]
fill 72 55 -402 132 55 -402 minecraft:water[level=0]
fill 72 55 -403 132 55 -403 minecraft:water[level=0]
fill 72 55 -404 133 55 -404 minecraft:water[level=0]
fill 72 55 -405 133 55 -405 minecraft:water[level=0]
fill 72 55 -406 133 55 -406 minecraft:water[level=0]
fill 72 55 -407 134 55 -407 minecraft:water[level=0]
fill 72 55 -408 134 55 -408 minecraft:water[level=0]
fill 72 55 -409 134 55 -409 minecraft:water[level=0]
fill 72 55 -410 134 55 -410 minecraft:water[level=0]
fill 72 55 -411 131 55 -411 minecraft:water[level=0]
fill 132 55 -411 133 55 -411 minecraft:tall_seagrass[half=lower]
setblock 134 55 -411 minecraft:water[level=0]
fill 72 55 -412 132 55 -412 minecraft:water[level=0]
setblock 133 55 -412 minecraft:tall_seagrass[half=lower]
setblock 134 55 -412 minecraft:water[level=0]
fill 72 55 -413 130 55 -413 minecraft:water[level=0]
setblock 131 55 -413 minecraft:seagrass
setblock 132 55 -413 minecraft:water[level=0]
setblock 133 55 -413 minecraft:seagrass
fill 72 55 -414 130 55 -414 minecraft:water[level=0]
setblock 131 55 -414 minecraft:tall_seagrass[half=lower]
fill 132 55 -414 133 55 -414 minecraft:water[level=0]
fill 72 55 -415 130 55 -415 minecraft:water[level=0]
fill 131 55 -415 132 55 -415 minecraft:seagrass
setblock 133 55 -415 minecraft:water[level=0]
fill 72 55 -416 133 55 -416 minecraft:water[level=0]
setblock 72 55 -417 minecraft:water[level=0]
fill 73 55 -417 74 55 -417 minecraft:tall_seagrass[half=upper]
fill 75 55 -417 132 55 -417 minecraft:water[level=0]
setblock 72 55 -418 minecraft:seagrass
fill 73 55 -418 74 55 -418 minecraft:water[level=0]
setblock 75 55 -418 minecraft:kelp_plant
fill 76 55 -418 132 55 -418 minecraft:water[level=0]
setblock 72 55 -419 minecraft:seagrass
setblock 73 55 -419 minecraft:kelp_plant
setblock 74 55 -419 minecraft:water[level=0]
setblock 75 55 -419 minecraft:seagrass
setblock 76 55 -419 minecraft:water[level=0]
setblock 77 55 -419 minecraft:kelp_plant
fill 78 55 -419 131 55 -419 minecraft:water[level=0]
setblock 72 55 -420 minecraft:tall_seagrass[half=lower]
fill 73 55 -420 131 55 -420 minecraft:water[level=0]
fill 72 55 -421 130 55 -421 minecraft:water[level=0]
setblock 72 55 -422 minecraft:water[level=0]
setblock 73 55 -422 minecraft:seagrass
fill 74 55 -422 130 55 -422 minecraft:water[level=0]
fill 72 55 -423 130 55 -423 minecraft:water[level=0]
fill 72 55 -424 129 55 -424 minecraft:water[level=0]
fill 72 55 -425 129 55 -425 minecraft:water[level=0]
fill 72 55 -426 129 55 -426 minecraft:water[level=0]
fill 72 55 -427 129 55 -427 minecraft:water[level=0]
fill 72 55 -428 129 55 -428 minecraft:water[level=0]
fill 72 55 -429 118 55 -429 minecraft:water[level=0]
fill 122 55 -429 128 55 -429 minecraft:water[level=0]
fill 72 55 -430 116 55 -430 minecraft:water[level=0]
setblock 124 55 -430 minecraft:water[level=0]
fill 72 55 -431 115 55 -431 minecraft:water[level=0]
fill 72 55 -432 115 55 -432 minecraft:water[level=0]
fill 72 55 -433 114 55 -433 minecraft:water[level=0]
fill 72 55 -434 114 55 -434 minecraft:water[level=0]
fill 72 55 -435 114 55 -435 minecraft:water[level=0]
fill 72 55 -436 114 55 -436 minecraft:water[level=0]
fill 72 55 -437 73 55 -437 minecraft:water[level=0]
fill 84 55 -437 91 55 -437 minecraft:water[level=0]
fill 93 55 -437 113 55 -437 minecraft:water[level=0]
fill 94 55 -438 113 55 -438 minecraft:water[level=0]
fill 95 55 -439 113 55 -439 minecraft:water[level=0]
fill 95 55 -440 112 55 -440 minecraft:water[level=0]
fill 98 55 -441 112 55 -441 minecraft:water[level=0]
fill 100 55 -442 102 55 -442 minecraft:water[level=0]
fill 105 55 -442 111 55 -442 minecraft:water[level=0]
fill 107 55 -443 109 55 -443 minecraft:water[level=0]
setblock 108 55 -444 minecraft:water[level=0]
fill 72 54 -383 84 54 -383 minecraft:water[level=0]
setblock 85 54 -383 minecraft:kelp_plant
fill 86 54 -383 125 54 -383 minecraft:water[level=0]
setblock 126 54 -383 minecraft:tall_seagrass[half=lower]
setblock 127 54 -383 minecraft:water[level=0]
fill 72 54 -384 91 54 -384 minecraft:water[level=0]
setblock 92 54 -384 minecraft:kelp_plant
fill 93 54 -384 122 54 -384 minecraft:water[level=0]
setblock 123 54 -384 minecraft:tall_seagrass[half=upper]
fill 124 54 -384 125 54 -384 minecraft:water[level=0]
setblock 126 54 -384 minecraft:seagrass
fill 72 54 -385 125 54 -385 minecraft:water[level=0]
setblock 126 54 -385 minecraft:tall_seagrass[half=lower]
fill 72 54 -386 125 54 -386 minecraft:water[level=0]
fill 72 54 -387 123 54 -387 minecraft:water[level=0]
setblock 124 54 -387 minecraft:seagrass
setblock 125 54 -387 minecraft:water[level=0]
fill 72 54 -388 90 54 -388 minecraft:water[level=0]
setblock 91 54 -388 minecraft:kelp_plant
fill 92 54 -388 123 54 -388 minecraft:water[level=0]
setblock 132 54 -388 minecraft:water[level=0]
fill 72 54 -389 80 54 -389 minecraft:water[level=0]
setblock 81 54 -389 minecraft:kelp_plant
fill 82 54 -389 84 54 -389 minecraft:water[level=0]
setblock 85 54 -389 minecraft:kelp_plant
fill 86 54 -389 122 54 -389 minecraft:water[level=0]
setblock 123 54 -389 minecraft:tall_seagrass[half=lower]
fill 72 54 -390 123 54 -390 minecraft:water[level=0]
fill 72 54 -391 123 54 -391 minecraft:water[level=0]
fill 72 54 -392 123 54 -392 minecraft:water[level=0]
fill 72 54 -393 125 54 -393 minecraft:water[level=0]
setblock 126 54 -393 minecraft:tall_seagrass[half=lower]
fill 72 54 -394 90 54 -394 minecraft:water[level=0]
setblock 91 54 -394 minecraft:kelp_plant
fill 92 54 -394 125 54 -394 minecraft:water[level=0]
setblock 126 54 -394 minecraft:tall_seagrass[half=lower]
setblock 127 54 -394 minecraft:water[level=0]
fill 72 54 -395 128 54 -395 minecraft:water[level=0]
fill 72 54 -396 88 54 -396 minecraft:water[level=0]
setblock 89 54 -396 minecraft:kelp_plant
fill 90 54 -396 123 54 -396 minecraft:water[level=0]
setblock 124 54 -396 minecraft:tall_seagrass[half=upper]
fill 125 54 -396 127 54 -396 minecraft:water[level=0]
setblock 128 54 -396 minecraft:seagrass
fill 72 54 -397 128 54 -397 minecraft:water[level=0]
fill 72 54 -398 85 54 -398 minecraft:water[level=0]
setblock 86 54 -398 minecraft:kelp_plant
fill 87 54 -398 128 54 -398 minecraft:water[level=0]
fill 72 54 -399 86 54 -399 minecraft:water[level=0]
setblock 87 54 -399 minecraft:kelp_plant
fill 88 54 -399 129 54 -399 minecraft:water[level=0]
fill 72 54 -400 129 54 -400 minecraft:water[level=0]
fill 72 54 -401 129 54 -401 minecraft:water[level=0]
fill 72 54 -402 130 54 -402 minecraft:water[level=0]
fill 72 54 -403 130 54 -403 minecraft:water[level=0]
fill 72 54 -404 130 54 -404 minecraft:water[level=0]
fill 72 54 -405 131 54 -405 minecraft:water[level=0]
fill 72 54 -406 131 54 -406 minecraft:water[level=0]
fill 72 54 -407 128 54 -407 minecraft:water[level=0]
setblock 129 54 -407 minecraft:tall_seagrass[half=upper]
fill 130 54 -407 132 54 -407 minecraft:water[level=0]
fill 72 54 -408 132 54 -408 minecraft:water[level=0]
fill 72 54 -409 132 54 -409 minecraft:water[level=0]
fill 72 54 -410 129 54 -410 minecraft:water[level=0]
setblock 130 54 -410 minecraft:seagrass
setblock 131 54 -410 minecraft:water[level=0]
setblock 132 54 -410 minecraft:seagrass
fill 72 54 -411 131 54 -411 minecraft:water[level=0]
fill 72 54 -412 127 54 -412 minecraft:water[level=0]
setblock 128 54 -412 minecraft:tall_seagrass[half=upper]
fill 129 54 -412 131 54 -412 minecraft:water[level=0]
setblock 135 54 -412 minecraft:water[level=0]
fill 72 54 -413 129 54 -413 minecraft:water[level=0]
setblock 130 54 -413 minecraft:seagrass
setblock 135 54 -413 minecraft:water[level=0]
setblock 72 54 -414 minecraft:seagrass
setblock 73 54 -414 minecraft:tall_seagrass[half=upper]
fill 74 54 -414 130 54 -414 minecraft:water[level=0]
fill 72 54 -415 129 54 -415 minecraft:water[level=0]
fill 72 54 -416 98 54 -416 minecraft:water[level=0]
fill 101 54 -416 128 54 -416 minecraft:water[level=0]
fill 73 54 -417 74 54 -417 minecraft:tall_seagrass[half=lower]
setblock 75 54 -417 minecraft:water[level=0]
setblock 76 54 -417 minecraft:seagrass
setblock 77 54 -417 minecraft:tall_seagrass[half=upper]
fill 78 54 -417 99 54 -417 minecraft:water[level=0]
fill 101 54 -417 119 54 -417 minecraft:water[level=0]
fill 123 54 -417 127 54 -417 minecraft:water[level=0]
setblock 74 54 -418 minecraft:seagrass
setblock 75 54 -418 minecraft:kelp_plant
fill 76 54 -418 99 54 -418 minecraft:water[level=0]
fill 101 54 -418 118 54 -418 minecraft:water[level=0]
fill 124 54 -418 125 54 -418 minecraft:water[level=0]
setblock 77 54 -419 minecraft:kelp_plant
fill 78 54 -419 117 54 -419 minecraft:water[level=0]
setblock 124 54 -419 minecraft:water[level=0]
fill 78 54 -420 116 54 -420 minecraft:water[level=0]
fill 78 54 -421 115 54 -421 minecraft:water[level=0]
fill 78 54 -422 115 54 -422 minecraft:water[level=0]
fill 72 54 -423 73 54 -423 minecraft:water[level=0]
fill 78 54 -423 115 54 -423 minecraft:water[level=0]
setblock 72 54 -424 minecraft:seagrass
fill 73 54 -424 75 54 -424 minecraft:water[level=0]
fill 82 54 -424 115 54 -424 minecraft:water[level=0]
fill 72 54 -425 75 54 -425 minecraft:water[level=0]
fill 83 54 -425 115 54 -425 minecraft:water[level=0]
fill 72 54 -426 74 54 -426 minecraft:water[level=0]
fill 84 54 -426 115 54 -426 minecraft:water[level=0]
fill 72 54 -427 74 54 -427 minecraft:water[level=0]
setblock 84 54 -427 minecraft:water[level=0]
fill 89 54 -427 115 54 -427 minecraft:water[level=0]
fill 72 54 -428 74 54 -428 minecraft:water[level=0]
fill 90 54 -428 115 54 -428 minecraft:water[level=0]
setblock 72 54 -429 minecraft:water[level=0]
fill 90 54 -429 114 54 -429 minecraft:water[level=0]
fill 89 54 -430 114 54 -430 minecraft:water[level=0]
fill 88 54 -431 113 54 -431 minecraft:water[level=0]
fill 87 54 -432 113 54 -432 minecraft:water[level=0]
fill 88 54 -433 113 54 -433 minecraft:water[level=0]
fill 89 54 -434 112 54 -434 minecraft:water[level=0]
fill 90 54 -435 112 54 -435 minecraft:water[level=0]
fill 92 54 -436 112 54 -436 minecraft:water[level=0]
fill 95 54 -437 112 54 -437 minecraft:water[level=0]
fill 96 54 -438 111 54 -438 minecraft:water[level=0]
fill 96 54 -439 110 54 -439 minecraft:water[level=0]
fill 96 54 -440 109 54 -440 minecraft:water[level=0]
setblock 100 54 -441 minecraft:water[level=0]
setblock 108 54 -441 minecraft:water[level=0]
fill 72 53 -383 84 53 -383 minecraft:water[level=0]
setblock 85 53 -383 minecraft:kelp_plant
fill 86 53 -383 124 53 -383 minecraft:water[level=0]
fill 72 53 -384 91 53 -384 minecraft:water[level=0]
setblock 92 53 -384 minecraft:kelp_plant
fill 93 53 -384 120 53 -384 minecraft:water[level=0]
setblock 121 53 -384 minecraft:tall_seagrass[half=upper]
setblock 122 53 -384 minecraft:water[level=0]
setblock 123 53 -384 minecraft:tall_seagrass[half=lower]
fill 72 53 -385 122 53 -385 minecraft:water[level=0]
fill 72 53 -386 122 53 -386 minecraft:water[level=0]
fill 72 53 -387 122 53 -387 minecraft:water[level=0]
fill 72 53 -388 90 53 -388 minecraft:water[level=0]
setblock 91 53 -388 minecraft:kelp_plant
fill 92 53 -388 122 53 -388 minecraft:water[level=0]
fill 72 53 -389 80 53 -389 minecraft:water[level=0]
setblock 81 53 -389 minecraft:kelp_plant
fill 82 53 -389 84 53 -389 minecraft:water[level=0]
setblock 85 53 -389 minecraft:kelp_plant
fill 86 53 -389 120 53 -389 minecraft:water[level=0]
setblock 121 53 -389 minecraft:tall_seagrass[half=upper]
setblock 122 53 -389 minecraft:water[level=0]
fill 72 53 -390 122 53 -390 minecraft:water[level=0]
fill 72 53 -391 122 53 -391 minecraft:water[level=0]
fill 72 53 -392 120 53 -392 minecraft:water[level=0]
setblock 121 53 -392 minecraft:seagrass
setblock 122 53 -392 minecraft:water[level=0]
fill 72 53 -393 122 53 -393 minecraft:water[level=0]
fill 72 53 -394 90 53 -394 minecraft:water[level=0]
setblock 91 53 -394 minecraft:kelp_plant
fill 92 53 -394 123 53 -394 minecraft:water[level=0]
fill 72 53 -395 124 53 -395 minecraft:water[level=0]
fill 72 53 -396 88 53 -396 minecraft:water[level=0]
setblock 89 53 -396 minecraft:kelp_plant
fill 90 53 -396 123 53 -396 minecraft:water[level=0]
setblock 124 53 -396 minecraft:tall_seagrass[half=lower]
setblock 125 53 -396 minecraft:water[level=0]
fill 72 53 -397 126 53 -397 minecraft:water[level=0]
fill 72 53 -398 85 53 -398 minecraft:water[level=0]
setblock 86 53 -398 minecraft:kelp_plant
fill 87 53 -398 126 53 -398 minecraft:water[level=0]
fill 72 53 -399 86 53 -399 minecraft:water[level=0]
setblock 87 53 -399 minecraft:kelp_plant
fill 88 53 -399 127 53 -399 minecraft:water[level=0]
fill 72 53 -400 127 53 -400 minecraft:water[level=0]
fill 72 53 -401 128 53 -401 minecraft:water[level=0]
fill 72 53 -402 128 53 -402 minecraft:water[level=0]
fill 72 53 -403 129 53 -403 minecraft:water[level=0]
fill 72 53 -404 129 53 -404 minecraft:water[level=0]
fill 72 53 -405 129 53 -405 minecraft:water[level=0]
fill 72 53 -406 129 53 -406 minecraft:water[level=0]
fill 72 53 -407 128 53 -407 minecraft:water[level=0]
setblock 129 53 -407 minecraft:tall_seagrass[half=lower]
setblock 130 53 -407 minecraft:seagrass
fill 72 53 -408 130 53 -408 minecraft:water[level=0]
fill 72 53 -409 129 53 -409 minecraft:water[level=0]
fill 72 53 -410 117 53 -410 minecraft:water[level=0]
setblock 118 53 -410 minecraft:tall_seagrass[half=upper]
fill 119 53 -410 129 53 -410 minecraft:water[level=0]
fill 72 53 -411 128 53 -411 minecraft:water[level=0]
setblock 135 53 -411 minecraft:water[level=0]
fill 72 53 -412 119 53 -412 minecraft:water[level=0]
setblock 128 53 -412 minecraft:tall_seagrass[half=lower]
fill 134 53 -412 135 53 -412 minecraft:water[level=0]
fill 72 53 -413 73 53 -413 minecraft:seagrass
fill 74 53 -413 99 53 -413 minecraft:water[level=0]
fill 101 53 -413 119 53 -413 minecraft:water[level=0]
setblock 135 53 -413 minecraft:water[level=0]
setblock 73 53 -414 minecraft:tall_seagrass[half=lower]
fill 74 53 -414 97 53 -414 minecraft:water[level=0]
fill 102 53 -414 118 53 -414 minecraft:water[level=0]
fill 73 53 -415 96 53 -415 minecraft:water[level=0]
fill 103 53 -415 118 53 -415 minecraft:water[level=0]
fill 75 53 -416 96 53 -416 minecraft:water[level=0]
fill 103 53 -416 117 53 -416 minecraft:water[level=0]
setblock 77 53 -417 minecraft:tall_seagrass[half=lower]
fill 78 53 -417 95 53 -417 minecraft:water[level=0]
fill 103 53 -417 116 53 -417 minecraft:water[level=0]
fill 78 53 -418 94 53 -418 minecraft:water[level=0]
fill 103 53 -418 115 53 -418 minecraft:water[level=0]
fill 79 53 -419 93 53 -419 minecraft:water[level=0]
fill 103 53 -419 114 53 -419 minecraft:water[level=0]
fill 80 53 -420 92 53 -420 minecraft:water[level=0]
fill 102 53 -420 114 53 -420 minecraft:water[level=0]
fill 85 53 -421 92 53 -421 minecraft:water[level=0]
fill 102 53 -421 114 53 -421 minecraft:water[level=0]
fill 88 53 -422 89 53 -422 minecraft:water[level=0]
fill 102 53 -422 114 53 -422 minecraft:water[level=0]
fill 101 53 -423 114 53 -423 minecraft:water[level=0]
fill 101 53 -424 113 53 -424 minecraft:water[level=0]
fill 101 53 -425 113 53 -425 minecraft:water[level=0]
fill 101 53 -426 113 53 -426 minecraft:water[level=0]
fill 101 53 -427 113 53 -427 minecraft:water[level=0]
fill 100 53 -428 113 53 -428 minecraft:water[level=0]
fill 98 53 -429 112 53 -429 minecraft:water[level=0]
fill 97 53 -430 112 53 -430 minecraft:water[level=0]
fill 97 53 -431 112 53 -431 minecraft:water[level=0]
fill 97 53 -432 112 53 -432 minecraft:water[level=0]
fill 96 53 -433 112 53 -433 minecraft:water[level=0]
fill 96 53 -434 112 53 -434 minecraft:water[level=0]
fill 95 53 -435 110 53 -435 minecraft:water[level=0]
fill 95 53 -436 108 53 -436 minecraft:water[level=0]
fill 96 53 -437 107 53 -437 minecraft:water[level=0]
fill 98 53 -438 105 53 -438 minecraft:water[level=0]
fill 99 53 -439 103 53 -439 minecraft:water[level=0]
fill 99 53 -440 101 53 -440 minecraft:water[level=0]
fill 72 52 -383 84 52 -383 minecraft:water[level=0]
setblock 85 52 -383 minecraft:kelp_plant
fill 86 52 -383 121 52 -383 minecraft:water[level=0]
fill 72 52 -384 91 52 -384 minecraft:water[level=0]
setblock 92 52 -384 minecraft:kelp_plant
fill 93 52 -384 120 52 -384 minecraft:water[level=0]
setblock 121 52 -384 minecraft:tall_seagrass[half=lower]
fill 72 52 -385 121 52 -385 minecraft:water[level=0]
fill 72 52 -386 121 52 -386 minecraft:water[level=0]
fill 72 52 -387 121 52 -387 minecraft:water[level=0]
fill 72 52 -388 90 52 -388 minecraft:water[level=0]
setblock 91 52 -388 minecraft:kelp_plant
fill 92 52 -388 121 52 -388 minecraft:water[level=0]
fill 72 52 -389 80 52 -389 minecraft:water[level=0]
setblock 81 52 -389 minecraft:kelp_plant
fill 82 52 -389 84 52 -389 minecraft:water[level=0]
setblock 85 52 -389 minecraft:kelp_plant
fill 86 52 -389 120 52 -389 minecraft:water[level=0]
setblock 121 52 -389 minecraft:tall_seagrass[half=lower]
fill 72 52 -390 119 52 -390 minecraft:water[level=0]
setblock 120 52 -390 minecraft:tall_seagrass[half=upper]
setblock 121 52 -390 minecraft:water[level=0]
fill 72 52 -391 120 52 -391 minecraft:water[level=0]
fill 72 52 -392 120 52 -392 minecraft:water[level=0]
fill 72 52 -393 121 52 -393 minecraft:water[level=0]
fill 72 52 -394 90 52 -394 minecraft:water[level=0]
setblock 91 52 -394 minecraft:kelp_plant
fill 92 52 -394 119 52 -394 minecraft:water[level=0]
setblock 120 52 -394 minecraft:seagrass
setblock 121 52 -394 minecraft:water[level=0]
fill 72 52 -395 121 52 -395 minecraft:water[level=0]
fill 72 52 -396 88 52 -396 minecraft:water[level=0]
setblock 89 52 -396 minecraft:kelp_plant
fill 90 52 -396 123 52 -396 minecraft:water[level=0]
fill 72 52 -397 124 52 -397 minecraft:water[level=0]
fill 72 52 -398 85 52 -398 minecraft:water[level=0]
setblock 86 52 -398 minecraft:kelp_plant
fill 87 52 -398 124 52 -398 minecraft:water[level=0]
fill 72 52 -399 86 52 -399 minecraft:water[level=0]
setblock 87 52 -399 minecraft:kelp_plant
fill 88 52 -399 124 52 -399 minecraft:water[level=0]
fill 72 52 -400 125 52 -400 minecraft:water[level=0]
fill 72 52 -401 125 52 -401 minecraft:water[level=0]
fill 72 52 -402 126 52 -402 minecraft:water[level=0]
fill 72 52 -403 107 52 -403 minecraft:water[level=0]
setblock 108 52 -403 minecraft:tall_seagrass[half=upper]
fill 109 52 -403 128 52 -403 minecraft:water[level=0]
fill 72 52 -404 109 52 -404 minecraft:water[level=0]
setblock 110 52 -404 minecraft:tall_seagrass[half=upper]
fill 111 52 -404 128 52 -404 minecraft:water[level=0]
fill 72 52 -405 113 52 -405 minecraft:water[level=0]
setblock 114 52 -405 minecraft:tall_seagrass[half=upper]
fill 115 52 -405 128 52 -405 minecraft:water[level=0]
fill 72 52 -406 113 52 -406 minecraft:water[level=0]
setblock 114 52 -406 minecraft:tall_seagrass[half=upper]
fill 115 52 -406 128 52 -406 minecraft:water[level=0]
fill 72 52 -407 128 52 -407 minecraft:water[level=0]
fill 72 52 -408 116 52 -408 minecraft:water[level=0]
setblock 117 52 -408 minecraft:tall_seagrass[half=upper]
fill 118 52 -408 128 52 -408 minecraft:water[level=0]
fill 72 52 -409 128 52 -409 minecraft:water[level=0]
fill 72 52 -410 112 52 -410 minecraft:water[level=0]
setblock 113 52 -410 minecraft:tall_seagrass[half=upper]
setblock 114 52 -410 minecraft:water[level=0]
setblock 115 52 -410 minecraft:tall_seagrass[half=upper]
setblock 116 52 -410 minecraft:water[level=0]
setblock 117 52 -410 minecraft:tall_seagrass[half=upper]
setblock 118 52 -410 minecraft:tall_seagrass[half=lower]
fill 119 52 -410 122 52 -410 minecraft:water[level=0]
setblock 135 52 -410 minecraft:water[level=0]
fill 72 52 -411 87 52 -411 minecraft:water[level=0]
fill 89 52 -411 94 52 -411 minecraft:water[level=0]
fill 101 52 -411 119 52 -411 minecraft:water[level=0]
fill 134 52 -411 135 52 -411 minecraft:water[level=0]
fill 73 52 -412 87 52 -412 minecraft:water[level=0]
fill 103 52 -412 118 52 -412 minecraft:water[level=0]
fill 134 52 -412 135 52 -412 minecraft:water[level=0]
fill 74 52 -413 75 52 -413 minecraft:water[level=0]
setblock 76 52 -413 minecraft:tall_seagrass[half=upper]
fill 77 52 -413 87 52 -413 minecraft:water[level=0]
fill 104 52 -413 117 52 -413 minecraft:water[level=0]
setblock 135 52 -413 minecraft:water[level=0]
setblock 75 52 -414 minecraft:seagrass
fill 76 52 -414 86 52 -414 minecraft:water[level=0]
fill 105 52 -414 117 52 -414 minecraft:water[level=0]
fill 76 52 -415 86 52 -415 minecraft:water[level=0]
fill 105 52 -415 116 52 -415 minecraft:water[level=0]
fill 80 52 -416 86 52 -416 minecraft:water[level=0]
fill 105 52 -416 114 52 -416 minecraft:water[level=0]
fill 82 52 -417 85 52 -417 minecraft:water[level=0]
fill 105 52 -417 113 52 -417 minecraft:water[level=0]
fill 104 52 -418 113 52 -418 minecraft:water[level=0]
fill 104 52 -419 113 52 -419 minecraft:water[level=0]
fill 104 52 -420 112 52 -420 minecraft:water[level=0]
fill 104 52 -421 112 52 -421 minecraft:water[level=0]
fill 103 52 -422 112 52 -422 minecraft:water[level=0]
fill 103 52 -423 112 52 -423 minecraft:water[level=0]
fill 103 52 -424 112 52 -424 minecraft:water[level=0]
fill 103 52 -425 112 52 -425 minecraft:water[level=0]
fill 103 52 -426 112 52 -426 minecraft:water[level=0]
fill 104 52 -427 112 52 -427 minecraft:water[level=0]
fill 105 52 -428 111 52 -428 minecraft:water[level=0]
fill 106 52 -429 110 52 -429 minecraft:water[level=0]
setblock 100 52 -435 minecraft:water[level=0]
fill 100 52 -436 101 52 -436 minecraft:water[level=0]
fill 72 51 -383 84 51 -383 minecraft:water[level=0]
setblock 85 51 -383 minecraft:kelp_plant
fill 86 51 -383 119 51 -383 minecraft:water[level=0]
fill 72 51 -384 91 51 -384 minecraft:water[level=0]
setblock 92 51 -384 minecraft:kelp_plant
fill 93 51 -384 119 51 -384 minecraft:water[level=0]
fill 72 51 -385 120 51 -385 minecraft:water[level=0]
fill 72 51 -386 120 51 -386 minecraft:water[level=0]
fill 72 51 -387 120 51 -387 minecraft:water[level=0]
fill 72 51 -388 90 51 -388 minecraft:water[level=0]
setblock 91 51 -388 minecraft:kelp_plant
fill 92 51 -388 120 51 -388 minecraft:water[level=0]
fill 72 51 -389 80 51 -389 minecraft:water[level=0]
setblock 81 51 -389 minecraft:kelp_plant
fill 82 51 -389 84 51 -389 minecraft:water[level=0]
setblock 85 51 -389 minecraft:kelp_plant
fill 86 51 -389 120 51 -389 minecraft:water[level=0]
fill 72 51 -390 119 51 -390 minecraft:water[level=0]
setblock 120 51 -390 minecraft:tall_seagrass[half=lower]
fill 72 51 -391 120 51 -391 minecraft:water[level=0]
fill 72 51 -392 119 51 -392 minecraft:water[level=0]
fill 72 51 -393 119 51 -393 minecraft:water[level=0]
fill 72 51 -394 90 51 -394 minecraft:water[level=0]
setblock 91 51 -394 minecraft:kelp_plant
fill 92 51 -394 119 51 -394 minecraft:water[level=0]
fill 72 51 -395 119 51 -395 minecraft:water[level=0]
fill 72 51 -396 88 51 -396 minecraft:water[level=0]
setblock 89 51 -396 minecraft:kelp_plant
fill 90 51 -396 119 51 -396 minecraft:water[level=0]
fill 72 51 -397 102 51 -397 minecraft:water[level=0]
setblock 103 51 -397 minecraft:tall_seagrass[half=upper]
fill 104 51 -397 119 51 -397 minecraft:water[level=0]
fill 72 51 -398 85 51 -398 minecraft:water[level=0]
setblock 86 51 -398 minecraft:kelp_plant
fill 87 51 -398 119 51 -398 minecraft:water[level=0]
setblock 72 51 -399 minecraft:water[level=0]
setblock 73 51 -399 minecraft:tall_seagrass[half=upper]
fill 74 51 -399 77 51 -399 minecraft:water[level=0]
setblock 78 51 -399 minecraft:tall_seagrass[half=upper]
fill 79 51 -399 86 51 -399 minecraft:water[level=0]
setblock 87 51 -399 minecraft:kelp_plant
fill 88 51 -399 119 51 -399 minecraft:water[level=0]
fill 72 51 -400 119 51 -400 minecraft:water[level=0]
fill 72 51 -401 123 51 -401 minecraft:water[level=0]
fill 72 51 -402 78 51 -402 minecraft:water[level=0]
setblock 79 51 -402 minecraft:tall_seagrass[half=upper]
fill 80 51 -402 117 51 -402 minecraft:water[level=0]
setblock 118 51 -402 minecraft:tall_seagrass[half=upper]
fill 119 51 -402 124 51 -402 minecraft:water[level=0]
fill 72 51 -403 76 51 -403 minecraft:water[level=0]
setblock 77 51 -403 minecraft:tall_seagrass[half=upper]
fill 78 51 -403 107 51 -403 minecraft:water[level=0]
setblock 108 51 -403 minecraft:tall_seagrass[half=lower]
fill 109 51 -403 110 51 -403 minecraft:water[level=0]
setblock 111 51 -403 minecraft:seagrass
fill 112 51 -403 124 51 -403 minecraft:water[level=0]
setblock 72 51 -404 minecraft:water[level=0]
setblock 73 51 -404 minecraft:tall_seagrass[half=upper]
fill 74 51 -404 76 51 -404 minecraft:water[level=0]
setblock 77 51 -404 minecraft:tall_seagrass[half=upper]
fill 78 51 -404 109 51 -404 minecraft:water[level=0]
setblock 110 51 -404 minecraft:tall_seagrass[half=lower]
fill 111 51 -404 125 51 -404 minecraft:water[level=0]
fill 72 51 -405 112 51 -405 minecraft:water[level=0]
setblock 113 51 -405 minecraft:seagrass
setblock 114 51 -405 minecraft:tall_seagrass[half=lower]
fill 115 51 -405 126 51 -405 minecraft:water[level=0]
fill 72 51 -406 75 51 -406 minecraft:water[level=0]
setblock 76 51 -406 minecraft:tall_seagrass[half=upper]
fill 77 51 -406 110 51 -406 minecraft:water[level=0]
setblock 111 51 -406 minecraft:tall_seagrass[half=upper]
fill 112 51 -406 113 51 -406 minecraft:water[level=0]
setblock 114 51 -406 minecraft:tall_seagrass[half=lower]
fill 115 51 -406 116 51 -406 minecraft:seagrass
fill 117 51 -406 118 51 -406 minecraft:water[level=0]
setblock 119 51 -406 minecraft:tall_seagrass[half=upper]
fill 120 51 -406 126 51 -406 minecraft:water[level=0]
fill 72 51 -407 111 51 -407 minecraft:water[level=0]
setblock 112 51 -407 minecraft:tall_seagrass[half=upper]
fill 113 51 -407 114 51 -407 minecraft:water[level=0]
fill 115 51 -407 116 51 -407 minecraft:seagrass
fill 117 51 -407 126 51 -407 minecraft:water[level=0]
fill 72 51 -408 73 51 -408 minecraft:water[level=0]
setblock 74 51 -408 minecraft:tall_seagrass[half=upper]
fill 75 51 -408 87 51 -408 minecraft:water[level=0]
fill 90 51 -408 94 51 -408 minecraft:water[level=0]
fill 97 51 -408 111 51 -408 minecraft:water[level=0]
setblock 112 51 -408 minecraft:tall_seagrass[half=upper]
fill 113 51 -408 114 51 -408 minecraft:water[level=0]
fill 115 51 -408 116 51 -408 minecraft:seagrass
setblock 117 51 -408 minecraft:tall_seagrass[half=lower]
fill 118 51 -408 126 51 -408 minecraft:water[level=0]
fill 72 51 -409 86 51 -409 minecraft:water[level=0]
setblock 92 51 -409 minecraft:water[level=0]
fill 99 51 -409 111 51 -409 minecraft:water[level=0]
setblock 112 51 -409 minecraft:tall_seagrass[half=upper]
setblock 113 51 -409 minecraft:water[level=0]
setblock 114 51 -409 minecraft:seagrass
setblock 115 51 -409 minecraft:water[level=0]
setblock 116 51 -409 minecraft:seagrass
setblock 117 51 -409 minecraft:water[level=0]
setblock 118 51 -409 minecraft:seagrass
fill 119 51 -409 120 51 -409 minecraft:water[level=0]
fill 73 51 -410 86 51 -410 minecraft:water[level=0]
fill 103 51 -410 112 51 -410 minecraft:water[level=0]
setblock 113 51 -410 minecraft:tall_seagrass[half=lower]
setblock 114 51 -410 minecraft:water[level=0]
setblock 115 51 -410 minecraft:tall_seagrass[half=lower]
setblock 116 51 -410 minecraft:water[level=0]
setblock 117 51 -410 minecraft:tall_seagrass[half=lower]
fill 74 51 -411 85 51 -411 minecraft:water[level=0]
fill 105 51 -411 117 51 -411 minecraft:water[level=0]
setblock 135 51 -411 minecraft:water[level=0]
fill 75 51 -412 85 51 -412 minecraft:water[level=0]
fill 106 51 -412 116 51 -412 minecraft:water[level=0]
setblock 117 51 -412 minecraft:seagrass
fill 134 51 -412 135 51 -412 minecraft:water[level=0]
setblock 76 51 -413 minecraft:tall_seagrass[half=lower]
fill 77 51 -413 79 51 -413 minecraft:water[level=0]
fill 81 51 -413 85 51 -413 minecraft:water[level=0]
fill 106 51 -413 116 51 -413 minecraft:water[level=0]
fill 134 51 -413 135 51 -413 minecraft:water[level=0]
fill 83 51 -414 84 51 -414 minecraft:water[level=0]
fill 107 51 -414 112 51 -414 minecraft:water[level=0]
setblock 113 51 -414 minecraft:seagrass
setblock 135 51 -414 minecraft:water[level=0]
setblock 84 51 -415 minecraft:water[level=0]
fill 107 51 -415 111 51 -415 minecraft:water[level=0]
fill 108 51 -416 110 51 -416 minecraft:water[level=0]
fill 107 51 -417 110 51 -417 minecraft:water[level=0]
fill 107 51 -418 110 51 -418 minecraft:water[level=0]
fill 107 51 -419 110 51 -419 minecraft:water[level=0]
fill 106 51 -420 111 51 -420 minecraft:water[level=0]
fill 106 51 -421 111 51 -421 minecraft:water[level=0]
fill 105 51 -422 111 51 -422 minecraft:water[level=0]
fill 104 51 -423 112 51 -423 minecraft:water[level=0]
fill 104 51 -424 112 51 -424 minecraft:water[level=0]
fill 106 51 -425 109 51 -425 minecraft:water[level=0]
fill 72 50 -383 84 50 -383 minecraft:water[level=0]
setblock 85 50 -383 minecraft:kelp_plant
fill 86 50 -383 119 50 -383 minecraft:water[level=0]
fill 72 50 -384 91 50 -384 minecraft:water[level=0]
setblock 92 50 -384 minecraft:kelp_plant
fill 93 50 -384 119 50 -384 minecraft:water[level=0]
fill 72 50 -385 119 50 -385 minecraft:water[level=0]
fill 72 50 -386 119 50 -386 minecraft:water[level=0]
fill 72 50 -387 119 50 -387 minecraft:water[level=0]
fill 72 50 -388 90 50 -388 minecraft:water[level=0]
setblock 91 50 -388 minecraft:kelp_plant
fill 92 50 -388 119 50 -388 minecraft:water[level=0]
fill 72 50 -389 80 50 -389 minecraft:water[level=0]
setblock 81 50 -389 minecraft:kelp_plant
fill 82 50 -389 83 50 -389 minecraft:water[level=0]
setblock 84 50 -389 minecraft:tall_seagrass[half=upper]
setblock 85 50 -389 minecraft:kelp_plant
setblock 86 50 -389 minecraft:tall_seagrass[half=upper]
fill 87 50 -389 119 50 -389 minecraft:water[level=0]
fill 72 50 -390 119 50 -390 minecraft:water[level=0]
fill 72 50 -391 80 50 -391 minecraft:water[level=0]
setblock 81 50 -391 minecraft:tall_seagrass[half=upper]
fill 82 50 -391 87 50 -391 minecraft:water[level=0]
setblock 88 50 -391 minecraft:tall_seagrass[half=upper]
fill 89 50 -391 103 50 -391 minecraft:water[level=0]
setblock 104 50 -391 minecraft:tall_seagrass[half=upper]
fill 105 50 -391 118 50 -391 minecraft:water[level=0]
fill 72 50 -392 118 50 -392 minecraft:water[level=0]
fill 72 50 -393 78 50 -393 minecraft:water[level=0]
setblock 79 50 -393 minecraft:tall_seagrass[half=upper]
fill 80 50 -393 102 50 -393 minecraft:water[level=0]
setblock 103 50 -393 minecraft:tall_seagrass[half=upper]
setblock 104 50 -393 minecraft:water[level=0]
setblock 105 50 -393 minecraft:tall_seagrass[half=upper]
fill 106 50 -393 118 50 -393 minecraft:water[level=0]
fill 72 50 -394 73 50 -394 minecraft:water[level=0]
setblock 74 50 -394 minecraft:tall_seagrass[half=upper]
fill 75 50 -394 90 50 -394 minecraft:water[level=0]
setblock 91 50 -394 minecraft:kelp_plant
fill 92 50 -394 96 50 -394 minecraft:water[level=0]
setblock 97 50 -394 minecraft:tall_seagrass[half=upper]
fill 98 50 -394 103 50 -394 minecraft:water[level=0]
setblock 104 50 -394 minecraft:tall_seagrass[half=upper]
fill 105 50 -394 118 50 -394 minecraft:water[level=0]
fill 72 50 -395 97 50 -395 minecraft:water[level=0]
setblock 98 50 -395 minecraft:tall_seagrass[half=upper]
setblock 99 50 -395 minecraft:water[level=0]
fill 100 50 -395 102 50 -395 minecraft:tall_seagrass[half=upper]
fill 103 50 -395 117 50 -395 minecraft:water[level=0]
setblock 72 50 -396 minecraft:tall_seagrass[half=upper]
fill 73 50 -396 74 50 -396 minecraft:water[level=0]
setblock 75 50 -396 minecraft:tall_seagrass[half=upper]
fill 76 50 -396 77 50 -396 minecraft:water[level=0]
setblock 78 50 -396 minecraft:tall_seagrass[half=upper]
fill 79 50 -396 88 50 -396 minecraft:water[level=0]
setblock 89 50 -396 minecraft:kelp_plant
fill 90 50 -396 100 50 -396 minecraft:water[level=0]
setblock 101 50 -396 minecraft:tall_seagrass[half=upper]
fill 102 50 -396 111 50 -396 minecraft:water[level=0]
fill 113 50 -396 117 50 -396 minecraft:water[level=0]
fill 72 50 -397 77 50 -397 minecraft:water[level=0]
setblock 78 50 -397 minecraft:tall_seagrass[half=upper]
fill 79 50 -397 82 50 -397 minecraft:water[level=0]
setblock 83 50 -397 minecraft:tall_seagrass[half=upper]
fill 84 50 -397 101 50 -397 minecraft:water[level=0]
setblock 102 50 -397 minecraft:seagrass
setblock 103 50 -397 minecraft:tall_seagrass[half=lower]
setblock 104 50 -397 minecraft:seagrass
fill 105 50 -397 111 50 -397 minecraft:water[level=0]
fill 113 50 -397 117 50 -397 minecraft:water[level=0]
fill 72 50 -398 75 50 -398 minecraft:water[level=0]
setblock 76 50 -398 minecraft:tall_seagrass[half=upper]
fill 77 50 -398 85 50 -398 minecraft:water[level=0]
setblock 86 50 -398 minecraft:kelp_plant
fill 87 50 -398 111 50 -398 minecraft:water[level=0]
fill 113 50 -398 117 50 -398 minecraft:water[level=0]
setblock 72 50 -399 minecraft:seagrass
setblock 73 50 -399 minecraft:tall_seagrass[half=lower]
setblock 74 50 -399 minecraft:water[level=0]
setblock 75 50 -399 minecraft:seagrass
fill 76 50 -399 77 50 -399 minecraft:water[level=0]
setblock 78 50 -399 minecraft:tall_seagrass[half=lower]
fill 79 50 -399 82 50 -399 minecraft:water[level=0]
setblock 83 50 -399 minecraft:tall_seagrass[half=upper]
fill 84 50 -399 85 50 -399 minecraft:water[level=0]
setblock 86 50 -399 minecraft:tall_seagrass[half=upper]
setblock 87 50 -399 minecraft:kelp_plant
fill 88 50 -399 100 50 -399 minecraft:water[level=0]
setblock 101 50 -399 minecraft:tall_seagrass[half=upper]
fill 102 50 -399 117 50 -399 minecraft:water[level=0]
fill 72 50 -400 75 50 -400 minecraft:water[level=0]
fill 76 50 -400 77 50 -400 minecraft:seagrass
fill 78 50 -400 117 50 -400 minecraft:water[level=0]
fill 72 50 -401 74 50 -401 minecraft:water[level=0]
setblock 75 50 -401 minecraft:seagrass
fill 76 50 -401 78 50 -401 minecraft:water[level=0]
setblock 79 50 -401 minecraft:seagrass
fill 80 50 -401 99 50 -401 minecraft:water[level=0]
setblock 100 50 -401 minecraft:tall_seagrass[half=upper]
setblock 101 50 -401 minecraft:water[level=0]
setblock 102 50 -401 minecraft:seagrass
fill 103 50 -401 104 50 -401 minecraft:water[level=0]
setblock 105 50 -401 minecraft:seagrass
fill 106 50 -401 111 50 -401 minecraft:water[level=0]
setblock 113 50 -401 minecraft:water[level=0]
setblock 114 50 -401 minecraft:seagrass
fill 115 50 -401 117 50 -401 minecraft:water[level=0]
fill 72 50 -402 73 50 -402 minecraft:seagrass
fill 74 50 -402 76 50 -402 minecraft:water[level=0]
setblock 77 50 -402 minecraft:seagrass
setblock 78 50 -402 minecraft:water[level=0]
setblock 79 50 -402 minecraft:tall_seagrass[half=lower]
setblock 80 50 -402 minecraft:seagrass
fill 81 50 -402 107 50 -402 minecraft:water[level=0]
fill 114 50 -402 117 50 -402 minecraft:water[level=0]
setblock 118 50 -402 minecraft:tall_seagrass[half=lower]
fill 119 50 -402 121 50 -402 minecraft:water[level=0]
fill 72 50 -403 76 50 -403 minecraft:water[level=0]
setblock 77 50 -403 minecraft:tall_seagrass[half=lower]
fill 78 50 -403 107 50 -403 minecraft:water[level=0]
setblock 115 50 -403 minecraft:seagrass
fill 116 50 -403 122 50 -403 minecraft:water[level=0]
setblock 72 50 -404 minecraft:water[level=0]
setblock 73 50 -404 minecraft:tall_seagrass[half=lower]
setblock 74 50 -404 minecraft:water[level=0]
setblock 75 50 -404 minecraft:seagrass
setblock 76 50 -404 minecraft:water[level=0]
setblock 77 50 -404 minecraft:tall_seagrass[half=lower]
setblock 78 50 -404 minecraft:water[level=0]
setblock 79 50 -404 minecraft:seagrass
fill 80 50 -404 106 50 -404 minecraft:water[level=0]
fill 117 50 -404 123 50 -404 minecraft:water[level=0]
fill 72 50 -405 75 50 -405 minecraft:water[level=0]
fill 76 50 -405 77 50 -405 minecraft:seagrass
setblock 78 50 -405 minecraft:water[level=0]
setblock 79 50 -405 minecraft:seagrass
fill 80 50 -405 107 50 -405 minecraft:water[level=0]
fill 117 50 -405 123 50 -405 minecraft:water[level=0]
fill 72 50 -406 75 50 -406 minecraft:water[level=0]
setblock 76 50 -406 minecraft:tall_seagrass[half=lower]
fill 77 50 -406 80 50 -406 minecraft:water[level=0]
setblock 81 50 -406 minecraft:tall_seagrass[half=upper]
fill 82 50 -406 87 50 -406 minecraft:water[level=0]
fill 89 50 -406 94 50 -406 minecraft:water[level=0]
fill 98 50 -406 110 50 -406 minecraft:water[level=0]
setblock 111 50 -406 minecraft:tall_seagrass[half=lower]
setblock 112 50 -406 minecraft:water[level=0]
setblock 118 50 -406 minecraft:seagrass
setblock 119 50 -406 minecraft:tall_seagrass[half=lower]
fill 120 50 -406 123 50 -406 minecraft:water[level=0]
fill 72 50 -407 73 50 -407 minecraft:water[level=0]
setblock 74 50 -407 minecraft:seagrass
setblock 75 50 -407 minecraft:water[level=0]
setblock 76 50 -407 minecraft:seagrass
fill 77 50 -407 80 50 -407 minecraft:water[level=0]
setblock 81 50 -407 minecraft:tall_seagrass[half=upper]
fill 82 50 -407 86 50 -407 minecraft:water[level=0]
setblock 92 50 -407 minecraft:water[level=0]
fill 99 50 -407 110 50 -407 minecraft:water[level=0]
setblock 111 50 -407 minecraft:seagrass
setblock 112 50 -407 minecraft:tall_seagrass[half=lower]
setblock 113 50 -407 minecraft:water[level=0]
fill 119 50 -407 123 50 -407 minecraft:water[level=0]
fill 72 50 -408 73 50 -408 minecraft:water[level=0]
setblock 74 50 -408 minecraft:tall_seagrass[half=lower]
setblock 75 50 -408 minecraft:seagrass
fill 76 50 -408 85 50 -408 minecraft:water[level=0]
fill 100 50 -408 109 50 -408 minecraft:water[level=0]
setblock 110 50 -408 minecraft:seagrass
setblock 111 50 -408 minecraft:water[level=0]
setblock 112 50 -408 minecraft:tall_seagrass[half=lower]
setblock 113 50 -408 minecraft:seagrass
fill 121 50 -408 124 50 -408 minecraft:water[level=0]
fill 74 50 -409 78 50 -409 minecraft:water[level=0]
setblock 79 50 -409 minecraft:seagrass
fill 80 50 -409 85 50 -409 minecraft:water[level=0]
fill 104 50 -409 108 50 -409 minecraft:water[level=0]
setblock 109 50 -409 minecraft:seagrass
fill 110 50 -409 111 50 -409 minecraft:water[level=0]
setblock 112 50 -409 minecraft:tall_seagrass[half=lower]
setblock 113 50 -409 minecraft:seagrass
fill 75 50 -410 84 50 -410 minecraft:water[level=0]
fill 106 50 -410 107 50 -410 minecraft:water[level=0]
setblock 108 50 -410 minecraft:seagrass
setblock 109 50 -410 minecraft:water[level=0]
setblock 110 50 -410 minecraft:seagrass
fill 111 50 -410 112 50 -410 minecraft:water[level=0]
fill 76 50 -411 77 50 -411 minecraft:water[level=0]
fill 83 50 -411 84 50 -411 minecraft:water[level=0]
fill 107 50 -411 111 50 -411 minecraft:water[level=0]
setblock 76 50 -412 minecraft:water[level=0]
fill 108 50 -412 111 50 -412 minecraft:water[level=0]
fill 134 50 -412 135 50 -412 minecraft:water[level=0]
fill 108 50 -413 109 50 -413 minecraft:water[level=0]
setblock 134 50 -413 minecraft:water[level=0]
setblock 108 50 -414 minecraft:water[level=0]
setblock 72 49 -383 minecraft:tall_seagrass[half=upper]
fill 73 49 -383 84 49 -383 minecraft:water[level=0]
setblock 85 49 -383 minecraft:kelp_plant
fill 86 49 -383 98 49 -383 minecraft:water[level=0]
setblock 99 49 -383 minecraft:tall_seagrass[half=upper]
fill 100 49 -383 107 49 -383 minecraft:water[level=0]
setblock 108 49 -383 minecraft:tall_seagrass[half=upper]
fill 109 49 -383 118 49 -383 minecraft:water[level=0]
fill 72 49 -384 91 49 -384 minecraft:water[level=0]
setblock 92 49 -384 minecraft:kelp_plant
fill 93 49 -384 118 49 -384 minecraft:water[level=0]
fill 72 49 -385 104 49 -385 minecraft:water[level=0]
setblock 105 49 -385 minecraft:tall_seagrass[half=upper]
fill 106 49 -385 118 49 -385 minecraft:water[level=0]
fill 72 49 -386 107 49 -386 minecraft:water[level=0]
setblock 108 49 -386 minecraft:tall_seagrass[half=upper]
fill 109 49 -386 118 49 -386 minecraft:water[level=0]
fill 72 49 -387 80 49 -387 minecraft:water[level=0]
setblock 81 49 -387 minecraft:seagrass
fill 82 49 -387 118 49 -387 minecraft:water[level=0]
fill 72 49 -388 81 49 -388 minecraft:water[level=0]
setblock 82 49 -388 minecraft:seagrass
fill 83 49 -388 90 49 -388 minecraft:water[level=0]
setblock 91 49 -388 minecraft:kelp_plant
fill 92 49 -388 119 49 -388 minecraft:water[level=0]
fill 72 49 -389 80 49 -389 minecraft:water[level=0]
setblock 81 49 -389 minecraft:kelp_plant
setblock 82 49 -389 minecraft:water[level=0]
setblock 83 49 -389 minecraft:seagrass
setblock 84 49 -389 minecraft:tall_seagrass[half=lower]
setblock 85 49 -389 minecraft:kelp_plant
setblock 86 49 -389 minecraft:tall_seagrass[half=lower]
fill 87 49 -389 118 49 -389 minecraft:water[level=0]
fill 72 49 -390 81 49 -390 minecraft:water[level=0]
fill 82 49 -390 83 49 -390 minecraft:seagrass
fill 84 49 -390 99 49 -390 minecraft:water[level=0]
setblock 100 49 -390 minecraft:tall_seagrass[half=upper]
fill 101 49 -390 118 49 -390 minecraft:water[level=0]
fill 72 49 -391 80 49 -391 minecraft:water[level=0]
setblock 81 49 -391 minecraft:tall_seagrass[half=lower]
fill 82 49 -391 87 49 -391 minecraft:water[level=0]
setblock 88 49 -391 minecraft:tall_seagrass[half=lower]
fill 89 49 -391 98 49 -391 minecraft:water[level=0]
setblock 99 49 -391 minecraft:tall_seagrass[half=upper]
fill 100 49 -391 102 49 -391 minecraft:water[level=0]
setblock 103 49 -391 minecraft:seagrass
setblock 104 49 -391 minecraft:tall_seagrass[half=lower]
fill 105 49 -391 107 49 -391 minecraft:water[level=0]
fill 109 49 -391 118 49 -391 minecraft:water[level=0]
fill 72 49 -392 78 49 -392 minecraft:water[level=0]
setblock 79 49 -392 minecraft:seagrass
fill 80 49 -392 82 49 -392 minecraft:water[level=0]
setblock 83 49 -392 minecraft:seagrass
setblock 84 49 -392 minecraft:water[level=0]
setblock 85 49 -392 minecraft:seagrass
fill 86 49 -392 106 49 -392 minecraft:water[level=0]
fill 110 49 -392 117 49 -392 minecraft:water[level=0]
fill 72 49 -393 76 49 -393 minecraft:water[level=0]
setblock 77 49 -393 minecraft:seagrass
setblock 78 49 -393 minecraft:water[level=0]
setblock 79 49 -393 minecraft:tall_seagrass[half=lower]
fill 80 49 -393 81 49 -393 minecraft:seagrass
fill 82 49 -393 83 49 -393 minecraft:water[level=0]
setblock 84 49 -393 minecraft:seagrass
setblock 85 49 -393 minecraft:water[level=0]
fill 86 49 -393 87 49 -393 minecraft:seagrass
fill 88 49 -393 99 49 -393 minecraft:water[level=0]
setblock 100 49 -393 minecraft:seagrass
fill 101 49 -393 102 49 -393 minecraft:water[level=0]
setblock 103 49 -393 minecraft:tall_seagrass[half=lower]
setblock 104 49 -393 minecraft:water[level=0]
setblock 105 49 -393 minecraft:tall_seagrass[half=lower]
setblock 106 49 -393 minecraft:water[level=0]
fill 110 49 -393 117 49 -393 minecraft:water[level=0]
fill 72 49 -394 73 49 -394 minecraft:water[level=0]
setblock 74 49 -394 minecraft:tall_seagrass[half=lower]
setblock 75 49 -394 minecraft:seagrass
fill 76 49 -394 79 49 -394 minecraft:water[level=0]
setblock 80 49 -394 minecraft:seagrass
setblock 81 49 -394 minecraft:water[level=0]
fill 82 49 -394 83 49 -394 minecraft:seagrass
fill 84 49 -394 90 49 -394 minecraft:water[level=0]
setblock 91 49 -394 minecraft:kelp_plant
fill 92 49 -394 96 49 -394 minecraft:water[level=0]
setblock 97 49 -394 minecraft:tall_seagrass[half=lower]
fill 98 49 -394 100 49 -394 minecraft:water[level=0]
setblock 101 49 -394 minecraft:seagrass
fill 102 49 -394 103 49 -394 minecraft:water[level=0]
setblock 104 49 -394 minecraft:tall_seagrass[half=lower]
fill 105 49 -394 106 49 -394 minecraft:water[level=0]
fill 113 49 -394 117 49 -394 minecraft:water[level=0]
fill 72 49 -395 73 49 -395 minecraft:water[level=0]
setblock 74 49 -395 minecraft:seagrass
fill 75 49 -395 78 49 -395 minecraft:water[level=0]
setblock 79 49 -395 minecraft:seagrass
fill 80 49 -395 85 49 -395 minecraft:water[level=0]
setblock 86 49 -395 minecraft:seagrass
fill 87 49 -395 96 49 -395 minecraft:water[level=0]
setblock 97 49 -395 minecraft:tall_seagrass[half=upper]
setblock 98 49 -395 minecraft:tall_seagrass[half=lower]
setblock 99 49 -395 minecraft:water[level=0]
fill 100 49 -395 102 49 -395 minecraft:tall_seagrass[half=lower]
setblock 103 49 -395 minecraft:seagrass
fill 104 49 -395 105 49 -395 minecraft:water[level=0]
fill 115 49 -395 116 49 -395 minecraft:water[level=0]
setblock 72 49 -396 minecraft:tall_seagrass[half=lower]
fill 73 49 -396 74 49 -396 minecraft:water[level=0]
setblock 75 49 -396 minecraft:tall_seagrass[half=lower]
setblock 76 49 -396 minecraft:water[level=0]
setblock 77 49 -396 minecraft:seagrass
setblock 78 49 -396 minecraft:tall_seagrass[half=lower]
setblock 79 49 -396 minecraft:water[level=0]
setblock 80 49 -396 minecraft:seagrass
fill 81 49 -396 88 49 -396 minecraft:water[level=0]
setblock 89 49 -396 minecraft:kelp_plant
fill 90 49 -396 98 49 -396 minecraft:water[level=0]
setblock 99 49 -396 minecraft:seagrass
setblock 100 49 -396 minecraft:water[level=0]
setblock 101 49 -396 minecraft:tall_seagrass[half=lower]
setblock 102 49 -396 minecraft:water[level=0]
fill 107 49 -396 108 49 -396 minecraft:water[level=0]
setblock 116 49 -396 minecraft:water[level=0]
setblock 72 49 -397 minecraft:seagrass
fill 73 49 -397 76 49 -397 minecraft:water[level=0]
setblock 77 49 -397 minecraft:seagrass
setblock 78 49 -397 minecraft:tall_seagrass[half=lower]
fill 79 49 -397 82 49 -397 minecraft:water[level=0]
setblock 83 49 -397 minecraft:tall_seagrass[half=lower]
fill 84 49 -397 99 49 -397 minecraft:water[level=0]
fill 100 49 -397 101 49 -397 minecraft:seagrass
fill 72 49 -398 75 49 -398 minecraft:water[level=0]
setblock 76 49 -398 minecraft:tall_seagrass[half=lower]
setblock 77 49 -398 minecraft:seagrass
fill 78 49 -398 84 49 -398 minecraft:water[level=0]
setblock 85 49 -398 minecraft:seagrass
setblock 86 49 -398 minecraft:kelp_plant
fill 87 49 -398 98 49 -398 minecraft:water[level=0]
setblock 99 49 -398 minecraft:seagrass
fill 100 49 -398 101 49 -398 minecraft:water[level=0]
setblock 80 49 -399 minecraft:seagrass
fill 81 49 -399 82 49 -399 minecraft:water[level=0]
setblock 83 49 -399 minecraft:tall_seagrass[half=lower]
fill 84 49 -399 85 49 -399 minecraft:water[level=0]
setblock 86 49 -399 minecraft:tall_seagrass[half=lower]
setblock 87 49 -399 minecraft:kelp_plant
fill 88 49 -399 97 49 -399 minecraft:water[level=0]
setblock 98 49 -399 minecraft:seagrass
fill 99 49 -399 100 49 -399 minecraft:water[level=0]
setblock 101 49 -399 minecraft:tall_seagrass[half=lower]
fill 82 49 -400 95 49 -400 minecraft:water[level=0]
setblock 96 49 -400 minecraft:seagrass
fill 97 49 -400 101 49 -400 minecraft:water[level=0]
fill 83 49 -401 99 49 -401 minecraft:water[level=0]
setblock 100 49 -401 minecraft:tall_seagrass[half=lower]
setblock 101 49 -401 minecraft:water[level=0]
fill 84 49 -402 100 49 -402 minecraft:water[level=0]
fill 85 49 -403 100 49 -403 minecraft:water[level=0]
fill 119 49 -403 120 49 -403 minecraft:water[level=0]
fill 85 49 -404 99 49 -404 minecraft:water[level=0]
fill 102 49 -404 104 49 -404 minecraft:water[level=0]
fill 118 49 -404 121 49 -404 minecraft:water[level=0]
fill 91 49 -405 93 49 -405 minecraft:water[level=0]
fill 102 49 -405 104 49 -405 minecraft:water[level=0]
fill 119 49 -405 121 49 -405 minecraft:water[level=0]
fill 79 49 -406 80 49 -406 minecraft:water[level=0]
setblock 81 49 -406 minecraft:tall_seagrass[half=lower]
fill 82 49 -406 84 49 -406 minecraft:water[level=0]
fill 103 49 -406 104 49 -406 minecraft:water[level=0]
setblock 120 49 -406 minecraft:water[level=0]
setblock 77 49 -407 minecraft:water[level=0]
setblock 78 49 -407 minecraft:seagrass
fill 79 49 -407 80 49 -407 minecraft:water[level=0]
setblock 81 49 -407 minecraft:tall_seagrass[half=lower]
fill 82 49 -407 84 49 -407 minecraft:water[level=0]
fill 103 49 -407 105 49 -407 minecraft:water[level=0]
fill 76 49 -408 84 49 -408 minecraft:water[level=0]
fill 103 49 -408 108 49 -408 minecraft:water[level=0]
setblock 108 49 -409 minecraft:water[level=0]
setblock 72 48 -383 minecraft:tall_seagrass[half=lower]
fill 73 48 -383 80 48 -383 minecraft:water[level=0]
fill 94 48 -383 98 48 -383 minecraft:water[level=0]
setblock 99 48 -383 minecraft:tall_seagrass[half=lower]
fill 100 48 -383 103 48 -383 minecraft:water[level=0]
setblock 104 48 -383 minecraft:seagrass
fill 105 48 -383 107 48 -383 minecraft:water[level=0]
setblock 108 48 -383 minecraft:tall_seagrass[half=lower]
fill 109 48 -383 117 48 -383 minecraft:water[level=0]
fill 72 48 -384 80 48 -384 minecraft:water[level=0]
fill 93 48 -384 100 48 -384 minecraft:water[level=0]
fill 101 48 -384 102 48 -384 minecraft:seagrass
fill 103 48 -384 105 48 -384 minecraft:water[level=0]
setblock 106 48 -384 minecraft:seagrass
fill 107 48 -384 108 48 -384 minecraft:water[level=0]
setblock 109 48 -384 minecraft:seagrass
fill 110 48 -384 117 48 -384 minecraft:water[level=0]
fill 72 48 -385 80 48 -385 minecraft:water[level=0]
fill 93 48 -385 104 48 -385 minecraft:water[level=0]
setblock 105 48 -385 minecraft:tall_seagrass[half=lower]
fill 106 48 -385 117 48 -385 minecraft:water[level=0]
fill 72 48 -386 80 48 -386 minecraft:water[level=0]
fill 93 48 -386 107 48 -386 minecraft:water[level=0]
setblock 108 48 -386 minecraft:tall_seagrass[half=lower]
fill 109 48 -386 118 48 -386 minecraft:water[level=0]
fill 72 48 -387 80 48 -387 minecraft:water[level=0]
fill 93 48 -387 118 48 -387 minecraft:water[level=0]
fill 72 48 -388 75 48 -388 minecraft:water[level=0]
setblock 76 48 -388 minecraft:seagrass
setblock 77 48 -388 minecraft:water[level=0]
fill 78 48 -388 79 48 -388 minecraft:seagrass
setblock 80 48 -388 minecraft:water[level=0]
fill 93 48 -388 118 48 -388 minecraft:water[level=0]
fill 72 48 -389 78 48 -389 minecraft:water[level=0]
setblock 79 48 -389 minecraft:seagrass
setblock 80 48 -389 minecraft:water[level=0]
fill 92 48 -389 95 48 -389 minecraft:water[level=0]
setblock 96 48 -389 minecraft:seagrass
fill 97 48 -389 98 48 -389 minecraft:water[level=0]
setblock 99 48 -389 minecraft:seagrass
fill 100 48 -389 104 48 -389 minecraft:water[level=0]
setblock 105 48 -389 minecraft:seagrass
setblock 106 48 -389 minecraft:water[level=0]
fill 109 48 -389 117 48 -389 minecraft:water[level=0]
fill 72 48 -390 78 48 -390 minecraft:water[level=0]
fill 92 48 -390 94 48 -390 minecraft:water[level=0]
setblock 95 48 -390 minecraft:seagrass
setblock 96 48 -390 minecraft:water[level=0]
fill 97 48 -390 99 48 -390 minecraft:seagrass
setblock 100 48 -390 minecraft:tall_seagrass[half=lower]
fill 101 48 -390 104 48 -390 minecraft:water[level=0]
fill 110 48 -390 117 48 -390 minecraft:water[level=0]
fill 72 48 -391 76 48 -391 minecraft:water[level=0]
fill 91 48 -391 95 48 -391 minecraft:water[level=0]
setblock 96 48 -391 minecraft:seagrass
fill 97 48 -391 98 48 -391 minecraft:water[level=0]
setblock 99 48 -391 minecraft:tall_seagrass[half=lower]
setblock 100 48 -391 minecraft:water[level=0]
setblock 101 48 -391 minecraft:seagrass
setblock 102 48 -391 minecraft:water[level=0]
fill 111 48 -391 117 48 -391 minecraft:water[level=0]
fill 91 48 -392 96 48 -392 minecraft:water[level=0]
fill 97 48 -392 98 48 -392 minecraft:seagrass
setblock 99 48 -392 minecraft:water[level=0]
setblock 100 48 -392 minecraft:seagrass
setblock 101 48 -392 minecraft:water[level=0]
fill 112 48 -392 117 48 -392 minecraft:water[level=0]
fill 91 48 -393 98 48 -393 minecraft:water[level=0]
fill 114 48 -393 116 48 -393 minecraft:water[level=0]
setblock 91 48 -394 minecraft:kelp_plant
fill 92 48 -394 94 48 -394 minecraft:water[level=0]
setblock 95 48 -394 minecraft:seagrass
setblock 96 48 -394 minecraft:water[level=0]
setblock 116 48 -394 minecraft:water[level=0]
fill 89 48 -395 96 48 -395 minecraft:water[level=0]
setblock 97 48 -395 minecraft:tall_seagrass[half=lower]
fill 90 48 -396 97 48 -396 minecraft:water[level=0]
fill 92 48 -397 95 48 -397 minecraft:water[level=0]
fill 91 48 -398 93 48 -398 minecraft:water[level=0]
fill 91 48 -399 93 48 -399 minecraft:water[level=0]
fill 91 48 -400 93 48 -400 minecraft:water[level=0]
setblock 92 48 -401 minecraft:water[level=0]
fill 119 48 -404 121 48 -404 minecraft:water[level=0]
setblock 120 48 -405 minecraft:water[level=0]
fill 89 47 -394 90 47 -394 minecraft:water[level=0]
setblock 91 47 -394 minecraft:kelp_plant
fill 92 47 -394 94 47 -394 minecraft:water[level=0]
fill 88 47 -395 96 47 -395 minecraft:water[level=0]
fill 88 47 -396 93 47 -396 minecraft:water[level=0]
setblock 94 47 -396 minecraft:tall_seagrass[half=upper]
setblock 95 47 -396 minecraft:water[level=0]
fill 91 47 -397 93 47 -397 minecraft:water[level=0]
fill 113 47 -406 114 47 -406 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 113 47 -407 114 47 -407 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 107 47 -434 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 88 46 -394 90 46 -394 minecraft:water[level=0]
setblock 91 46 -394 minecraft:kelp_plant
fill 92 46 -394 93 46 -394 minecraft:water[level=0]
fill 87 46 -395 94 46 -395 minecraft:water[level=0]
setblock 85 46 -396 minecraft:water[level=0]
fill 87 46 -396 93 46 -396 minecraft:water[level=0]
setblock 94 46 -396 minecraft:tall_seagrass[half=lower]
fill 88 46 -397 91 46 -397 minecraft:water[level=0]
setblock 114 46 -407 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 107 46 -433 108 46 -433 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 107 46 -434 108 46 -434 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 87 45 -394 90 45 -394 minecraft:water[level=0]
setblock 91 45 -394 minecraft:kelp_plant
fill 85 45 -395 93 45 -395 minecraft:water[level=0]
fill 84 45 -396 92 45 -396 minecraft:water[level=0]
fill 83 45 -397 90 45 -397 minecraft:water[level=0]
fill 98 45 -413 99 45 -413 minecraft:water[level=0]
fill 99 45 -414 101 45 -414 minecraft:water[level=0]
fill 100 45 -415 102 45 -415 minecraft:water[level=0]
fill 102 45 -416 103 45 -416 minecraft:water[level=0]
setblock 103 45 -417 minecraft:water[level=0]
fill 83 45 -420 88 45 -420 minecraft:water[level=0]
fill 82 45 -421 89 45 -421 minecraft:water[level=0]
fill 82 45 -422 89 45 -422 minecraft:water[level=0]
fill 82 45 -423 89 45 -423 minecraft:water[level=0]
fill 82 45 -424 89 45 -424 minecraft:water[level=0]
fill 82 45 -425 89 45 -425 minecraft:water[level=0]
fill 82 45 -426 89 45 -426 minecraft:water[level=0]
fill 83 45 -427 88 45 -427 minecraft:water[level=0]
forceload remove 72 -446 135 -383
tellraw @a {"text":"Campus zurueck a02 fertig.","color":"green"}
