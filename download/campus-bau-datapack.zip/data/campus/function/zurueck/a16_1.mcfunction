setblock 76 81 -255 minecraft:air
setblock 104 81 -255 minecraft:air
setblock 77 81 -256 minecraft:air
setblock 104 81 -256 minecraft:air
setblock 78 81 -257 minecraft:air
setblock 103 81 -257 minecraft:air
setblock 79 81 -258 minecraft:air
setblock 103 81 -258 minecraft:air
setblock 79 81 -259 minecraft:air
setblock 102 81 -259 minecraft:air
setblock 80 81 -260 minecraft:air
setblock 102 81 -260 minecraft:air
setblock 81 81 -261 minecraft:air
setblock 101 81 -261 minecraft:air
setblock 82 81 -262 minecraft:air
setblock 100 81 -262 minecraft:air
setblock 83 81 -263 minecraft:air
setblock 100 81 -263 minecraft:air
setblock 83 81 -264 minecraft:air
setblock 99 81 -264 minecraft:air
setblock 84 81 -265 minecraft:air
setblock 99 81 -265 minecraft:air
setblock 85 81 -266 minecraft:air
setblock 98 81 -266 minecraft:air
setblock 86 81 -267 minecraft:air
setblock 98 81 -267 minecraft:air
setblock 87 81 -268 minecraft:air
setblock 97 81 -268 minecraft:air
setblock 87 81 -269 minecraft:air
setblock 97 81 -269 minecraft:air
setblock 88 81 -270 minecraft:air
setblock 96 81 -270 minecraft:air
setblock 89 81 -271 minecraft:air
setblock 96 81 -271 minecraft:air
setblock 90 81 -272 minecraft:air
setblock 95 81 -272 minecraft:air
setblock 91 81 -273 minecraft:air
setblock 94 81 -273 minecraft:air
setblock 91 81 -274 minecraft:air
setblock 94 81 -274 minecraft:air
fill 92 81 -275 93 81 -275 minecraft:air
setblock 76 80 -255 minecraft:white_concrete
setblock 104 80 -255 minecraft:white_concrete
setblock 77 80 -256 minecraft:white_concrete
setblock 104 80 -256 minecraft:white_concrete
setblock 78 80 -257 minecraft:white_concrete
setblock 103 80 -257 minecraft:white_concrete
setblock 79 80 -258 minecraft:white_concrete
setblock 103 80 -258 minecraft:white_concrete
setblock 79 80 -259 minecraft:white_concrete
setblock 102 80 -259 minecraft:white_concrete
setblock 80 80 -260 minecraft:white_concrete
setblock 102 80 -260 minecraft:white_concrete
setblock 81 80 -261 minecraft:white_concrete
setblock 101 80 -261 minecraft:white_concrete
setblock 82 80 -262 minecraft:white_concrete
setblock 100 80 -262 minecraft:white_concrete
setblock 83 80 -263 minecraft:white_concrete
setblock 100 80 -263 minecraft:white_concrete
setblock 83 80 -264 minecraft:white_concrete
setblock 99 80 -264 minecraft:white_concrete
setblock 84 80 -265 minecraft:white_concrete
setblock 99 80 -265 minecraft:white_concrete
setblock 85 80 -266 minecraft:white_concrete
setblock 98 80 -266 minecraft:white_concrete
setblock 86 80 -267 minecraft:white_concrete
setblock 98 80 -267 minecraft:white_concrete
setblock 87 80 -268 minecraft:white_concrete
setblock 97 80 -268 minecraft:white_concrete
setblock 87 80 -269 minecraft:white_concrete
setblock 97 80 -269 minecraft:white_concrete
setblock 88 80 -270 minecraft:white_concrete
setblock 96 80 -270 minecraft:white_concrete
setblock 89 80 -271 minecraft:white_concrete
setblock 96 80 -271 minecraft:white_concrete
setblock 90 80 -272 minecraft:white_concrete
setblock 95 80 -272 minecraft:white_concrete
setblock 91 80 -273 minecraft:white_concrete
setblock 94 80 -273 minecraft:white_concrete
setblock 91 80 -274 minecraft:white_concrete
setblock 94 80 -274 minecraft:white_concrete
fill 92 80 -275 93 80 -275 minecraft:white_concrete
setblock 79 77 -294 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 80 77 -294 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 78 77 -296 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 77 77 -297 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 78 77 -297 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 77 -297 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 78 77 -298 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 77 76 -294 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 78 76 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 76 -294 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 80 76 -294 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 81 76 -294 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 78 76 -295 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 80 76 -295 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 78 76 -296 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 76 -297 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 76 -297 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 76 -297 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 76 -298 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 72 76 -317 73 76 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 76 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 77 75 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 75 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 75 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 75 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 75 -296 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 75 -296 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 75 -296 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 75 -297 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 75 -297 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 75 -297 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 75 -298 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 75 -298 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 75 -298 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 75 -300 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 73 75 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 74 75 -300 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 81 75 -302 regions_unexplored:silver_birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 73 75 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 72 75 -317 74 75 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 75 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 75 -317 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 73 75 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 134 75 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 74 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 74 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 74 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 74 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 74 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 74 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 74 -296 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 74 -296 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 74 -296 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 76 74 -297 77 74 -297 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 74 -297 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 79 74 -297 80 74 -297 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 77 74 -298 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 74 -298 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 74 -298 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 74 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 74 -299 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 72 74 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 74 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 74 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 74 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 74 -302 regions_unexplored:silver_birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 81 74 -304 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 74 -305 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 72 74 -316 74 74 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 76 74 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 85 74 -316 87 74 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 74 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 72 74 -317 74 74 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 76 74 -317 77 74 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 74 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 74 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 74 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 72 74 -318 74 74 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 76 74 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 74 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 74 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 73 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 73 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 73 -294 minecraft:birch_log[axis=y]
setblock 79 73 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 73 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 73 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 73 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 73 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 73 -296 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 73 -297 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 72 73 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 73 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 73 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 73 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 73 -300 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 74 73 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 73 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 73 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 73 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 73 -301 regions_unexplored:silver_birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 81 73 -302 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 81 73 -303 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 80 73 -304 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 73 -304 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 73 -305 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 73 -309 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 73 -315 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 73 -315 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 73 -315 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 72 73 -316 74 73 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 76 73 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 85 73 -316 87 73 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 73 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 73 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 73 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 73 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 73 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 73 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 74 73 -317 77 73 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 73 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 73 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 73 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 73 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 72 73 -318 74 73 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 76 73 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 73 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 73 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 73 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 73 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 73 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 73 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 72 -294 minecraft:birch_log[axis=y]
setblock 77 72 -297 regions_unexplored:silver_birch_log[axis=x,is_base=false]
setblock 78 72 -297 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 82 72 -297 minecraft:air
setblock 94 72 -297 minecraft:air
setblock 73 72 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 72 -298 minecraft:air
setblock 113 72 -298 minecraft:air
setblock 123 72 -298 minecraft:air
setblock 133 72 -298 minecraft:air
setblock 72 72 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 72 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 74 72 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 72 -300 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 72 -300 minecraft:birch_log[axis=y]
setblock 74 72 -300 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 75 72 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 72 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 72 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 74 72 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 72 -301 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 73 72 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 72 -302 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 81 72 -302 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 72 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 80 72 -303 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 72 -303 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 72 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 72 -304 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 80 72 -304 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 72 -304 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 72 72 -305 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 80 72 -305 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 72 -305 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 78 72 -311 80 72 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 72 -312 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 72 -312 minecraft:air
setblock 103 72 -312 minecraft:air
setblock 113 72 -312 minecraft:air
setblock 123 72 -312 minecraft:air
setblock 133 72 -312 minecraft:air
fill 85 72 -315 87 72 -315 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 72 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 72 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 75 72 -316 77 72 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 85 72 -316 87 72 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 72 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 72 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 72 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 72 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 72 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 72 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 72 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 75 72 -317 77 72 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 85 72 -317 87 72 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 72 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 72 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 72 -317 minecraft:birch_log[axis=y]
setblock 120 72 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 121 72 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 72 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 72 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 72 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 75 72 -318 77 72 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 72 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 72 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 72 -318 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 72 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 72 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 72 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 72 -318 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 72 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 71 -294 minecraft:birch_log[axis=y]
setblock 82 71 -295 minecraft:air
setblock 94 71 -295 minecraft:air
fill 81 71 -296 83 71 -296 minecraft:air
fill 93 71 -296 95 71 -296 minecraft:air
setblock 103 71 -296 minecraft:air
setblock 113 71 -296 minecraft:air
setblock 123 71 -296 minecraft:air
setblock 133 71 -296 minecraft:air
setblock 78 71 -297 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 80 71 -297 84 71 -297 minecraft:air
fill 92 71 -297 96 71 -297 minecraft:air
fill 102 71 -297 104 71 -297 minecraft:air
fill 112 71 -297 114 71 -297 minecraft:air
fill 122 71 -297 124 71 -297 minecraft:air
fill 132 71 -297 134 71 -297 minecraft:air
fill 81 71 -298 83 71 -298 minecraft:air
fill 93 71 -298 95 71 -298 minecraft:air
fill 101 71 -298 105 71 -298 minecraft:air
fill 111 71 -298 115 71 -298 minecraft:air
fill 121 71 -298 125 71 -298 minecraft:air
fill 131 71 -298 135 71 -298 minecraft:air
setblock 82 71 -299 minecraft:air
setblock 94 71 -299 minecraft:air
fill 102 71 -299 104 71 -299 minecraft:air
fill 112 71 -299 114 71 -299 minecraft:air
fill 122 71 -299 124 71 -299 minecraft:air
fill 132 71 -299 134 71 -299 minecraft:air
setblock 73 71 -300 minecraft:birch_log[axis=y]
setblock 103 71 -300 minecraft:air
setblock 113 71 -300 minecraft:air
setblock 123 71 -300 minecraft:air
setblock 133 71 -300 minecraft:air
setblock 81 71 -302 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 71 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 71 -303 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 71 -303 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 72 71 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 71 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 79 71 -304 80 71 -304 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 81 71 -304 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 72 71 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 80 71 -305 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 71 -305 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 81 71 -306 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 71 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 71 -310 minecraft:air
setblock 103 71 -310 minecraft:air
setblock 113 71 -310 minecraft:air
setblock 123 71 -310 minecraft:air
setblock 133 71 -310 minecraft:air
fill 78 71 -311 80 71 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 92 71 -311 94 71 -311 minecraft:air
fill 102 71 -311 104 71 -311 minecraft:air
fill 112 71 -311 114 71 -311 minecraft:air
fill 122 71 -311 124 71 -311 minecraft:air
fill 132 71 -311 134 71 -311 minecraft:air
setblock 79 71 -312 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 91 71 -312 95 71 -312 minecraft:air
fill 101 71 -312 105 71 -312 minecraft:air
fill 111 71 -312 115 71 -312 minecraft:air
fill 121 71 -312 125 71 -312 minecraft:air
fill 131 71 -312 135 71 -312 minecraft:air
fill 92 71 -313 94 71 -313 minecraft:air
fill 102 71 -313 104 71 -313 minecraft:air
fill 112 71 -313 114 71 -313 minecraft:air
fill 122 71 -313 124 71 -313 minecraft:air
fill 132 71 -313 134 71 -313 minecraft:air
setblock 86 71 -314 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 71 -314 minecraft:air
setblock 103 71 -314 minecraft:air
setblock 113 71 -314 minecraft:air
setblock 123 71 -314 minecraft:air
setblock 133 71 -314 minecraft:air
setblock 76 71 -315 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 85 71 -315 87 71 -315 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 123 71 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 71 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 71 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 75 71 -316 77 71 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 84 71 -316 85 71 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 71 -316 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 87 71 -316 88 71 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 123 71 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 71 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 71 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 71 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 74 71 -317 75 71 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 76 71 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 77 71 -317 78 71 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 85 71 -317 87 71 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 71 -317 minecraft:birch_log[axis=y]
setblock 120 71 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 123 71 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 71 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 71 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 72 71 -318 77 71 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 71 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 119 71 -318 120 71 -318 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 121 71 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 70 -293 productivebees:birch_wood_nest[axis=y,facing=north]
setblock 78 70 -294 minecraft:birch_log[axis=y]
fill 81 70 -295 83 70 -295 minecraft:air
fill 93 70 -295 95 70 -295 minecraft:air
fill 80 70 -296 84 70 -296 minecraft:air
fill 92 70 -296 96 70 -296 minecraft:air
fill 102 70 -296 104 70 -296 minecraft:air
fill 112 70 -296 114 70 -296 minecraft:air
fill 122 70 -296 124 70 -296 minecraft:air
fill 132 70 -296 134 70 -296 minecraft:air
setblock 78 70 -297 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 80 70 -297 84 70 -297 minecraft:air
fill 92 70 -297 96 70 -297 minecraft:air
fill 101 70 -297 105 70 -297 minecraft:air
fill 111 70 -297 115 70 -297 minecraft:air
fill 121 70 -297 125 70 -297 minecraft:air
fill 131 70 -297 135 70 -297 minecraft:air
fill 80 70 -298 84 70 -298 minecraft:air
fill 92 70 -298 96 70 -298 minecraft:air
fill 101 70 -298 105 70 -298 minecraft:air
fill 111 70 -298 115 70 -298 minecraft:air
fill 121 70 -298 125 70 -298 minecraft:air
fill 131 70 -298 135 70 -298 minecraft:air
fill 81 70 -299 83 70 -299 minecraft:air
fill 93 70 -299 95 70 -299 minecraft:air
fill 101 70 -299 105 70 -299 minecraft:air
fill 111 70 -299 115 70 -299 minecraft:air
fill 121 70 -299 125 70 -299 minecraft:air
fill 131 70 -299 135 70 -299 minecraft:air
setblock 73 70 -300 minecraft:birch_log[axis=y]
fill 102 70 -300 104 70 -300 minecraft:air
fill 112 70 -300 114 70 -300 minecraft:air
fill 122 70 -300 124 70 -300 minecraft:air
fill 132 70 -300 134 70 -300 minecraft:air
setblock 72 70 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 70 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 70 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 70 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 70 -304 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 72 70 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 70 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 78 70 -310 80 70 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 92 70 -310 94 70 -310 minecraft:air
fill 102 70 -310 104 70 -310 minecraft:air
fill 112 70 -310 114 70 -310 minecraft:air
fill 122 70 -310 124 70 -310 minecraft:air
fill 132 70 -310 134 70 -310 minecraft:air
fill 78 70 -311 80 70 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 91 70 -311 95 70 -311 minecraft:air
fill 101 70 -311 105 70 -311 minecraft:air
fill 111 70 -311 115 70 -311 minecraft:air
fill 121 70 -311 125 70 -311 minecraft:air
fill 131 70 -311 135 70 -311 minecraft:air
fill 78 70 -312 80 70 -312 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 91 70 -312 95 70 -312 minecraft:air
fill 101 70 -312 105 70 -312 minecraft:air
fill 111 70 -312 115 70 -312 minecraft:air
fill 121 70 -312 125 70 -312 minecraft:air
fill 131 70 -312 135 70 -312 minecraft:air
fill 91 70 -313 95 70 -313 minecraft:air
fill 101 70 -313 105 70 -313 minecraft:air
fill 111 70 -313 115 70 -313 minecraft:air
fill 121 70 -313 125 70 -313 minecraft:air
fill 131 70 -313 135 70 -313 minecraft:air
fill 92 70 -314 94 70 -314 minecraft:air
fill 102 70 -314 104 70 -314 minecraft:air
fill 112 70 -314 114 70 -314 minecraft:air
fill 122 70 -314 123 70 -314 minecraft:air
setblock 124 70 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 132 70 -314 134 70 -314 minecraft:air
setblock 123 70 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 70 -315 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 70 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 70 -316 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 122 70 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 70 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 70 -316 minecraft:birch_log[axis=y]
setblock 125 70 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 70 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 76 70 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 119 70 -317 minecraft:birch_log[axis=y]
setblock 123 70 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 70 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 70 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 70 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 70 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 74 70 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 70 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 69 -294 minecraft:birch_log[axis=y]
setblock 82 69 -295 minecraft:air
setblock 94 69 -295 minecraft:air
fill 81 69 -296 83 69 -296 minecraft:air
fill 93 69 -296 95 69 -296 minecraft:air
setblock 103 69 -296 minecraft:air
setblock 113 69 -296 minecraft:air
setblock 123 69 -296 minecraft:air
setblock 133 69 -296 minecraft:air
setblock 78 69 -297 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 80 69 -297 84 69 -297 minecraft:air
fill 92 69 -297 96 69 -297 minecraft:air
fill 102 69 -297 104 69 -297 minecraft:air
fill 112 69 -297 114 69 -297 minecraft:air
fill 122 69 -297 124 69 -297 minecraft:air
fill 132 69 -297 134 69 -297 minecraft:air
fill 81 69 -298 83 69 -298 minecraft:air
fill 93 69 -298 95 69 -298 minecraft:air
fill 101 69 -298 105 69 -298 minecraft:air
fill 111 69 -298 115 69 -298 minecraft:air
fill 121 69 -298 125 69 -298 minecraft:air
fill 131 69 -298 135 69 -298 minecraft:air
setblock 82 69 -299 minecraft:air
setblock 94 69 -299 minecraft:air
fill 102 69 -299 104 69 -299 minecraft:air
fill 112 69 -299 114 69 -299 minecraft:air
fill 122 69 -299 124 69 -299 minecraft:air
fill 132 69 -299 134 69 -299 minecraft:air
setblock 73 69 -300 minecraft:birch_log[axis=y]
setblock 103 69 -300 minecraft:air
setblock 113 69 -300 minecraft:air
setblock 123 69 -300 minecraft:air
setblock 133 69 -300 minecraft:air
setblock 72 69 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 69 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 69 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 69 -304 minecraft:birch_log[axis=y]
setblock 73 69 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 74 69 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 69 -304 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 72 69 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 69 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 69 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 69 -309 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 78 69 -310 80 69 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 69 -310 minecraft:air
setblock 103 69 -310 minecraft:air
setblock 113 69 -310 minecraft:air
setblock 123 69 -310 minecraft:air
setblock 133 69 -310 minecraft:air
fill 77 69 -311 78 69 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 69 -311 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 80 69 -311 81 69 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 92 69 -311 94 69 -311 minecraft:air
fill 102 69 -311 104 69 -311 minecraft:air
fill 112 69 -311 114 69 -311 minecraft:air
fill 122 69 -311 124 69 -311 minecraft:air
fill 132 69 -311 134 69 -311 minecraft:air
fill 78 69 -312 80 69 -312 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 91 69 -312 95 69 -312 minecraft:air
fill 101 69 -312 105 69 -312 minecraft:air
fill 111 69 -312 115 69 -312 minecraft:air
fill 121 69 -312 125 69 -312 minecraft:air
fill 131 69 -312 135 69 -312 minecraft:air
setblock 79 69 -313 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 92 69 -313 94 69 -313 minecraft:air
fill 102 69 -313 104 69 -313 minecraft:air
fill 112 69 -313 114 69 -313 minecraft:air
fill 122 69 -313 124 69 -313 minecraft:air
fill 132 69 -313 134 69 -313 minecraft:air
setblock 93 69 -314 minecraft:air
setblock 103 69 -314 minecraft:air
setblock 113 69 -314 minecraft:air
setblock 123 69 -314 minecraft:air
setblock 133 69 -314 minecraft:air
setblock 76 69 -316 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 124 69 -316 minecraft:birch_log[axis=y]
setblock 86 69 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 119 69 -317 minecraft:birch_log[axis=y]
setblock 73 69 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 77 68 -286 minecraft:campfire[facing=north,lit=false,signal_fire=false,waterlogged=false]
setblock 78 68 -294 minecraft:birch_log[axis=y]
setblock 76 68 -296 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 74 68 -297 minecraft:short_grass
setblock 75 68 -297 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 76 68 -297 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
setblock 77 68 -297 regions_unexplored:grass_sprouts
setblock 78 68 -297 regions_unexplored:silver_birch_log[axis=y,is_base=true]
setblock 79 68 -297 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 82 68 -297 minecraft:air
setblock 94 68 -297 minecraft:air
setblock 75 68 -298 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 79 68 -298 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 103 68 -298 minecraft:air
setblock 113 68 -298 minecraft:air
setblock 123 68 -298 minecraft:air
setblock 133 68 -298 minecraft:air
setblock 77 68 -299 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=2]
setblock 73 68 -300 minecraft:birch_log[axis=y]
setblock 81 68 -301 regions_unexplored:silver_birch_log[axis=x,is_base=false]
setblock 72 68 -304 minecraft:birch_log[axis=y]
setblock 80 68 -304 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 79 68 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 68 -311 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 93 68 -312 minecraft:air
setblock 103 68 -312 minecraft:air
setblock 113 68 -312 minecraft:air
setblock 123 68 -312 minecraft:air
setblock 133 68 -312 minecraft:air
setblock 76 68 -316 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 124 68 -316 minecraft:birch_log[axis=y]
setblock 86 68 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 119 68 -317 minecraft:birch_log[axis=y]
fill 134 68 -317 135 68 -317 minecraft:grass_block[snowy=false]
setblock 73 68 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 74 68 -318 regions_unexplored:silver_birch_log[axis=x,is_base=false]
fill 134 68 -318 135 68 -318 minecraft:grass_block[snowy=false]
setblock 82 67 -289 minecraft:campfire[facing=west,lit=false,signal_fire=false,waterlogged=false]
setblock 79 67 -290 minecraft:campfire[facing=east,lit=false,signal_fire=false,waterlogged=false]
fill 72 67 -294 73 67 -294 minecraft:grass_block[snowy=false]
setblock 78 67 -294 minecraft:birch_log[axis=y]
fill 72 67 -295 75 67 -295 minecraft:grass_block[snowy=false]
fill 72 67 -296 78 67 -296 minecraft:grass_block[snowy=false]
setblock 79 67 -296 regions_unexplored:silt_grass_block[snowy=false]
setblock 81 67 -296 regions_unexplored:grass_sprouts
fill 72 67 -297 75 67 -297 minecraft:grass_block[snowy=false]
fill 76 67 -297 77 67 -297 regions_unexplored:silt_grass_block[snowy=false]
setblock 78 67 -297 regions_unexplored:silt_dirt
setblock 79 67 -297 regions_unexplored:silt_grass_block[snowy=false]
setblock 81 67 -297 minecraft:short_grass
setblock 82 67 -297 minecraft:air
setblock 94 67 -297 minecraft:air
setblock 72 67 -298 regions_unexplored:grass_sprouts
setblock 74 67 -298 minecraft:grass_block[snowy=false]
fill 75 67 -298 79 67 -298 regions_unexplored:silt_grass_block[snowy=false]
setblock 80 67 -298 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 103 67 -298 minecraft:air
setblock 113 67 -298 minecraft:air
setblock 123 67 -298 minecraft:air
setblock 133 67 -298 minecraft:air
fill 75 67 -299 78 67 -299 regions_unexplored:silt_grass_block[snowy=false]
setblock 79 67 -299 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 73 67 -300 minecraft:birch_log[axis=y]
setblock 76 67 -300 regions_unexplored:silt_grass_block[snowy=false]
setblock 77 67 -300 regions_unexplored:grass_sprouts
setblock 79 67 -300 minecraft:short_grass
setblock 78 67 -301 regions_unexplored:grass_sprouts
setblock 72 67 -304 minecraft:birch_log[axis=y]
setblock 80 67 -304 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 80 67 -305 regions_unexplored:silver_birch_log[axis=z,is_base=false]
setblock 79 67 -309 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 67 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 67 -310 regions_unexplored:silver_birch_branch[facing=south]
setblock 80 67 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 67 -311 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 93 67 -312 minecraft:air
setblock 103 67 -312 minecraft:air
setblock 113 67 -312 minecraft:air
setblock 123 67 -312 minecraft:air
setblock 133 67 -312 minecraft:air
setblock 76 67 -315 regions_unexplored:silver_birch_log[axis=z,is_base=false]
setblock 76 67 -316 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 124 67 -316 minecraft:birch_log[axis=y]
setblock 86 67 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 119 67 -317 minecraft:birch_log[axis=y]
fill 131 67 -317 133 67 -317 minecraft:grass_block[snowy=false]
fill 134 67 -317 135 67 -317 minecraft:dirt
setblock 73 67 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 86 67 -318 regions_unexplored:silver_birch_log[axis=z,is_base=false]
fill 131 67 -318 133 67 -318 minecraft:grass_block[snowy=false]
fill 134 67 -318 135 67 -318 minecraft:dirt
fill 72 66 -294 73 66 -294 minecraft:dirt
fill 74 66 -294 77 66 -294 minecraft:grass_block[snowy=false]
setblock 78 66 -294 minecraft:dirt
fill 79 66 -294 80 66 -294 minecraft:grass_block[snowy=false]
setblock 81 66 -294 regions_unexplored:silt_grass_block[snowy=false]
fill 72 66 -295 75 66 -295 minecraft:dirt
fill 76 66 -295 80 66 -295 minecraft:grass_block[snowy=false]
setblock 81 66 -295 regions_unexplored:silt_grass_block[snowy=false]
fill 72 66 -296 79 66 -296 minecraft:dirt
fill 80 66 -296 81 66 -296 regions_unexplored:silt_grass_block[snowy=false]
fill 72 66 -297 75 66 -297 minecraft:dirt
fill 76 66 -297 79 66 -297 regions_unexplored:silt_dirt
fill 80 66 -297 81 66 -297 regions_unexplored:silt_grass_block[snowy=false]
setblock 82 66 -297 minecraft:air
setblock 94 66 -297 minecraft:air
fill 72 66 -298 73 66 -298 minecraft:grass_block[snowy=false]
setblock 74 66 -298 minecraft:dirt
fill 75 66 -298 79 66 -298 regions_unexplored:silt_dirt
fill 80 66 -298 81 66 -298 regions_unexplored:silt_grass_block[snowy=false]
setblock 103 66 -298 minecraft:air
setblock 113 66 -298 minecraft:air
setblock 123 66 -298 minecraft:air
setblock 133 66 -298 minecraft:air
setblock 73 66 -299 minecraft:grass_block[snowy=false]
setblock 74 66 -299 regions_unexplored:silt_grass_block[snowy=false]
fill 75 66 -299 78 66 -299 regions_unexplored:silt_dirt
fill 79 66 -299 81 66 -299 regions_unexplored:silt_grass_block[snowy=false]
setblock 73 66 -300 minecraft:birch_log[axis=y]
fill 74 66 -300 75 66 -300 regions_unexplored:silt_grass_block[snowy=false]
setblock 76 66 -300 regions_unexplored:silt_dirt
fill 77 66 -300 80 66 -300 regions_unexplored:silt_grass_block[snowy=false]
fill 75 66 -301 78 66 -301 regions_unexplored:silt_grass_block[snowy=false]
setblock 79 66 -301 regions_unexplored:grass_sprouts
setblock 75 66 -302 regions_unexplored:grass_sprouts
setblock 72 66 -304 minecraft:birch_log[axis=y]
setblock 80 66 -304 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 72 66 -309 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
setblock 79 66 -311 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 73 66 -312 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 93 66 -312 minecraft:air
setblock 103 66 -312 minecraft:air
setblock 113 66 -312 minecraft:air
setblock 123 66 -312 minecraft:air
setblock 133 66 -312 minecraft:air
setblock 73 66 -313 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
setblock 76 66 -316 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 124 66 -316 minecraft:birch_log[axis=y]
setblock 86 66 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 119 66 -317 minecraft:birch_log[axis=y]
fill 128 66 -317 130 66 -317 minecraft:grass_block[snowy=false]
fill 131 66 -317 135 66 -317 minecraft:dirt
setblock 73 66 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 128 66 -318 130 66 -318 minecraft:grass_block[snowy=false]
fill 131 66 -318 135 66 -318 minecraft:dirt
setblock 135 65 -261 minecraft:air
fill 134 65 -262 135 65 -262 minecraft:air
fill 133 65 -263 135 65 -263 minecraft:air
fill 132 65 -264 135 65 -264 minecraft:air
fill 131 65 -265 135 65 -265 minecraft:air
fill 130 65 -266 135 65 -266 minecraft:air
fill 129 65 -267 135 65 -267 minecraft:air
fill 128 65 -268 135 65 -268 minecraft:air
fill 127 65 -269 135 65 -269 minecraft:air
fill 126 65 -270 135 65 -270 minecraft:air
fill 124 65 -271 135 65 -271 minecraft:air
fill 123 65 -272 135 65 -272 minecraft:air
fill 121 65 -273 135 65 -273 minecraft:air
fill 120 65 -274 135 65 -274 minecraft:air
fill 118 65 -275 135 65 -275 minecraft:air
fill 116 65 -276 135 65 -276 minecraft:air
fill 114 65 -277 135 65 -277 minecraft:air
fill 112 65 -278 135 65 -278 minecraft:air
fill 109 65 -279 135 65 -279 minecraft:air
fill 106 65 -280 135 65 -280 minecraft:air
fill 72 65 -281 74 65 -281 minecraft:air
fill 102 65 -281 135 65 -281 minecraft:air
fill 72 65 -282 80 65 -282 minecraft:air
fill 96 65 -282 135 65 -282 minecraft:air
fill 72 65 -283 91 65 -283 minecraft:air
fill 97 65 -283 135 65 -283 minecraft:air
setblock 72 65 -284 minecraft:air
setblock 96 65 -284 minecraft:air
setblock 97 65 -284 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
fill 98 65 -284 135 65 -284 minecraft:air
setblock 72 65 -285 minecraft:air
fill 84 65 -285 96 65 -285 regions_unexplored:silt_grass_block[snowy=false]
fill 97 65 -285 135 65 -285 minecraft:air
fill 84 65 -286 96 65 -286 regions_unexplored:silt_grass_block[snowy=false]
setblock 97 65 -286 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 98 65 -286 135 65 -286 minecraft:air
fill 84 65 -287 96 65 -287 regions_unexplored:silt_grass_block[snowy=false]
fill 97 65 -287 118 65 -287 minecraft:air
setblock 119 65 -287 minecraft:vine[east=false,north=true,south=false,up=false,west=false]
fill 120 65 -287 135 65 -287 minecraft:air
fill 84 65 -288 96 65 -288 regions_unexplored:silt_grass_block[snowy=false]
fill 97 65 -288 117 65 -288 minecraft:air
setblock 118 65 -288 minecraft:vine[east=true,north=false,south=false,up=false,west=false]
setblock 119 65 -288 minecraft:cobblestone
setblock 120 65 -288 minecraft:vine[east=false,north=false,south=false,up=false,west=true]
fill 121 65 -288 126 65 -288 minecraft:air
setblock 127 65 -288 minecraft:cobblestone
fill 128 65 -288 135 65 -288 minecraft:air
fill 81 65 -289 82 65 -289 regions_unexplored:silt_grass_block[snowy=false]
fill 84 65 -289 95 65 -289 regions_unexplored:silt_grass_block[snowy=false]
fill 96 65 -289 135 65 -289 minecraft:air
fill 81 65 -290 95 65 -290 regions_unexplored:silt_grass_block[snowy=false]
fill 96 65 -290 135 65 -290 minecraft:air
fill 82 65 -291 94 65 -291 regions_unexplored:silt_grass_block[snowy=false]
setblock 95 65 -291 regions_unexplored:grass_sprouts
fill 96 65 -291 135 65 -291 minecraft:air
fill 82 65 -292 94 65 -292 regions_unexplored:silt_grass_block[snowy=false]
setblock 95 65 -292 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
fill 96 65 -292 135 65 -292 minecraft:air
fill 81 65 -293 93 65 -293 regions_unexplored:silt_grass_block[snowy=false]
setblock 94 65 -293 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
fill 95 65 -293 134 65 -293 minecraft:air
setblock 135 65 -293 regions_unexplored:grass_sprouts
fill 72 65 -294 79 65 -294 minecraft:dirt
fill 80 65 -294 81 65 -294 regions_unexplored:silt_dirt
fill 82 65 -294 92 65 -294 regions_unexplored:silt_grass_block[snowy=false]
setblock 93 65 -294 minecraft:air
setblock 94 65 -294 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 95 65 -294 96 65 -294 minecraft:air
setblock 97 65 -294 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 98 65 -294 135 65 -294 minecraft:air
fill 72 65 -295 80 65 -295 minecraft:dirt
setblock 81 65 -295 regions_unexplored:silt_dirt
fill 82 65 -295 92 65 -295 regions_unexplored:silt_grass_block[snowy=false]
fill 93 65 -295 126 65 -295 minecraft:air
setblock 127 65 -295 minecraft:vine[east=false,north=true,south=false,up=false,west=false]
fill 128 65 -295 135 65 -295 minecraft:air
fill 72 65 -296 79 65 -296 minecraft:dirt
fill 80 65 -296 81 65 -296 regions_unexplored:silt_dirt
fill 82 65 -296 90 65 -296 regions_unexplored:silt_grass_block[snowy=false]
fill 91 65 -296 92 65 -296 minecraft:air
setblock 93 65 -296 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 94 65 -296 118 65 -296 minecraft:air
setblock 119 65 -296 minecraft:cobblestone
fill 120 65 -296 126 65 -296 minecraft:air
setblock 127 65 -296 minecraft:cobblestone
setblock 128 65 -296 minecraft:vine[east=false,north=false,south=false,up=false,west=true]
fill 129 65 -296 134 65 -296 minecraft:air
setblock 135 65 -296 railcraft:quarried_stone
fill 72 65 -297 75 65 -297 minecraft:dirt
fill 76 65 -297 81 65 -297 regions_unexplored:silt_dirt
fill 82 65 -297 89 65 -297 regions_unexplored:silt_grass_block[snowy=false]
fill 90 65 -297 126 65 -297 minecraft:air
setblock 127 65 -297 minecraft:vine[east=false,north=false,south=true,up=false,west=false]
fill 128 65 -297 134 65 -297 minecraft:air
setblock 135 65 -297 railcraft:quarried_stone
fill 72 65 -298 75 65 -298 minecraft:dirt
fill 76 65 -298 81 65 -298 regions_unexplored:silt_dirt
fill 82 65 -298 87 65 -298 regions_unexplored:silt_grass_block[snowy=false]
fill 88 65 -298 89 65 -298 minecraft:air
setblock 90 65 -298 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
setblock 91 65 -298 minecraft:air
setblock 92 65 -298 minecraft:tall_grass[half=upper]
fill 93 65 -298 133 65 -298 minecraft:air
fill 134 65 -298 135 65 -298 railcraft:quarried_stone
fill 73 65 -299 74 65 -299 minecraft:dirt
fill 75 65 -299 81 65 -299 regions_unexplored:silt_dirt
fill 82 65 -299 85 65 -299 regions_unexplored:silt_grass_block[snowy=false]
setblock 86 65 -299 minecraft:air
setblock 87 65 -299 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
fill 88 65 -299 133 65 -299 minecraft:air
fill 134 65 -299 135 65 -299 railcraft:quarried_stone
setblock 72 65 -300 minecraft:air
setblock 73 65 -300 minecraft:dirt
fill 74 65 -300 80 65 -300 regions_unexplored:silt_dirt
fill 81 65 -300 83 65 -300 regions_unexplored:silt_grass_block[snowy=false]
setblock 84 65 -300 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
fill 85 65 -300 133 65 -300 minecraft:air
fill 134 65 -300 135 65 -300 railcraft:quarried_stone
setblock 72 65 -301 minecraft:air
setblock 73 65 -301 regions_unexplored:grass_sprouts
setblock 74 65 -301 regions_unexplored:silt_grass_block[snowy=false]
fill 75 65 -301 78 65 -301 regions_unexplored:silt_dirt
fill 79 65 -301 82 65 -301 regions_unexplored:silt_grass_block[snowy=false]
setblock 83 65 -301 minecraft:air
setblock 84 65 -301 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
fill 85 65 -301 86 65 -301 minecraft:air
setblock 87 65 -301 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 88 65 -301 132 65 -301 minecraft:air
fill 133 65 -301 135 65 -301 railcraft:quarried_stone
fill 72 65 -302 74 65 -302 minecraft:air
fill 75 65 -302 81 65 -302 regions_unexplored:silt_grass_block[snowy=false]
fill 82 65 -302 83 65 -302 minecraft:air
setblock 84 65 -302 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
fill 85 65 -302 131 65 -302 minecraft:air
fill 132 65 -302 135 65 -302 railcraft:quarried_stone
fill 72 65 -303 76 65 -303 minecraft:air
setblock 77 65 -303 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 78 65 -303 minecraft:air
setblock 79 65 -303 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 80 65 -303 regions_unexplored:silt_grass_block[snowy=false]
fill 81 65 -303 88 65 -303 minecraft:air
setblock 89 65 -303 regions_unexplored:silver_birch_log[axis=z,is_base=false]
fill 90 65 -303 131 65 -303 minecraft:air
fill 132 65 -303 135 65 -303 railcraft:quarried_stone
setblock 72 65 -304 minecraft:birch_log[axis=y]
fill 73 65 -304 77 65 -304 minecraft:air
setblock 78 65 -304 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 79 65 -304 minecraft:air
setblock 80 65 -304 regions_unexplored:silver_birch_log[axis=y,is_base=true]
fill 81 65 -304 82 65 -304 minecraft:air
setblock 83 65 -304 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
fill 84 65 -304 88 65 -304 minecraft:air
setblock 89 65 -304 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 90 65 -304 130 65 -304 minecraft:air
fill 131 65 -304 135 65 -304 railcraft:quarried_stone
fill 72 65 -305 76 65 -305 minecraft:air
setblock 77 65 -305 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 78 65 -305 regions_unexplored:grass_sprouts
fill 79 65 -305 80 65 -305 minecraft:air
setblock 81 65 -305 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 82 65 -305 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 83 65 -305 130 65 -305 minecraft:air
fill 131 65 -305 135 65 -305 railcraft:quarried_stone
fill 72 65 -306 130 65 -306 minecraft:air
fill 131 65 -306 135 65 -306 railcraft:quarried_stone
fill 72 65 -307 77 65 -307 minecraft:air
setblock 78 65 -307 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
fill 79 65 -307 129 65 -307 minecraft:air
setblock 130 65 -307 minecraft:grass_block[snowy=false]
fill 131 65 -307 135 65 -307 railcraft:quarried_stone
fill 72 65 -308 75 65 -308 regions_unexplored:silt_grass_block[snowy=false]
setblock 76 65 -308 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
setblock 77 65 -308 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 78 65 -308 regions_unexplored:grass_sprouts
setblock 79 65 -308 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
fill 80 65 -308 129 65 -308 minecraft:air
fill 133 65 -308 135 65 -308 railcraft:quarried_stone
fill 72 65 -309 74 65 -309 regions_unexplored:silt_grass_block[snowy=false]
fill 75 65 -309 76 65 -309 minecraft:air
setblock 77 65 -309 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
fill 78 65 -309 117 65 -309 minecraft:air
setblock 118 65 -309 minecraft:birch_log[axis=y]
fill 119 65 -309 128 65 -309 minecraft:air
fill 72 65 -310 74 65 -310 regions_unexplored:silt_grass_block[snowy=false]
setblock 75 65 -310 minecraft:air
setblock 76 65 -310 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 77 65 -310 minecraft:short_grass
fill 78 65 -310 128 65 -310 minecraft:air
fill 72 65 -311 74 65 -311 regions_unexplored:silt_grass_block[snowy=false]
fill 75 65 -311 76 65 -311 minecraft:air
setblock 77 65 -311 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 78 65 -311 minecraft:air
setblock 79 65 -311 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 80 65 -311 127 65 -311 minecraft:air
fill 72 65 -312 73 65 -312 regions_unexplored:silt_grass_block[snowy=false]
fill 74 65 -312 114 65 -312 minecraft:air
setblock 115 65 -312 minecraft:tall_grass[half=upper]
fill 116 65 -312 118 65 -312 minecraft:air
setblock 119 65 -312 minecraft:birch_log[axis=y]
fill 120 65 -312 127 65 -312 minecraft:air
fill 72 65 -313 73 65 -313 regions_unexplored:silt_grass_block[snowy=false]
setblock 74 65 -313 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
setblock 75 65 -313 minecraft:short_grass
fill 76 65 -313 126 65 -313 minecraft:air
setblock 72 65 -314 regions_unexplored:silt_grass_block[snowy=false]
fill 73 65 -314 116 65 -314 minecraft:air
setblock 117 65 -314 regions_unexplored:grass_sprouts
fill 118 65 -314 126 65 -314 minecraft:air
setblock 72 65 -315 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 73 65 -315 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 74 65 -315 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
fill 75 65 -315 126 65 -315 minecraft:air
fill 72 65 -316 75 65 -316 minecraft:air
setblock 76 65 -316 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 77 65 -316 116 65 -316 minecraft:air
setblock 117 65 -316 regions_unexplored:grass_sprouts
fill 118 65 -316 123 65 -316 minecraft:air
setblock 124 65 -316 minecraft:birch_log[axis=y]
setblock 125 65 -316 minecraft:air
setblock 72 65 -317 regions_unexplored:grass_sprouts
fill 73 65 -317 85 65 -317 minecraft:air
setblock 86 65 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 87 65 -317 116 65 -317 minecraft:air
setblock 117 65 -317 regions_unexplored:grass_sprouts
setblock 118 65 -317 minecraft:air
setblock 119 65 -317 minecraft:birch_log[axis=y]
setblock 120 65 -317 minecraft:short_grass
fill 121 65 -317 123 65 -317 minecraft:air
setblock 124 65 -317 regions_unexplored:grass_sprouts
setblock 125 65 -317 minecraft:air
fill 128 65 -317 135 65 -317 minecraft:dirt
setblock 72 65 -318 minecraft:deepslate[axis=y]
fill 73 65 -318 115 65 -318 minecraft:air
setblock 116 65 -318 minecraft:short_grass
fill 117 65 -318 121 65 -318 minecraft:air
fill 122 65 -318 123 65 -318 regions_unexplored:grass_sprouts
setblock 124 65 -318 minecraft:short_grass
fill 128 65 -318 135 65 -318 minecraft:dirt
fill 72 64 -255 76 64 -255 minecraft:air
fill 104 64 -255 129 64 -255 minecraft:air
fill 132 64 -255 135 64 -255 minecraft:air
setblock 72 64 -256 minecraft:air
fill 74 64 -256 77 64 -256 minecraft:air
fill 104 64 -256 107 64 -256 minecraft:air
fill 109 64 -256 112 64 -256 minecraft:air
fill 114 64 -256 117 64 -256 minecraft:air
fill 119 64 -256 122 64 -256 minecraft:air
fill 124 64 -256 127 64 -256 minecraft:air
fill 131 64 -256 135 64 -256 minecraft:air
fill 72 64 -257 78 64 -257 minecraft:air
fill 103 64 -257 127 64 -257 minecraft:air
fill 130 64 -257 135 64 -257 minecraft:air
fill 72 64 -258 79 64 -258 minecraft:air
fill 103 64 -258 126 64 -258 minecraft:air
fill 129 64 -258 135 64 -258 minecraft:air
fill 72 64 -259 80 64 -259 minecraft:air
fill 102 64 -259 125 64 -259 minecraft:air
fill 128 64 -259 135 64 -259 minecraft:air
fill 72 64 -260 80 64 -260 minecraft:air
fill 101 64 -260 124 64 -260 minecraft:air
fill 127 64 -260 135 64 -260 minecraft:air
setblock 72 64 -261 minecraft:air
fill 74 64 -261 77 64 -261 minecraft:air
fill 79 64 -261 81 64 -261 minecraft:air
fill 101 64 -261 102 64 -261 minecraft:air
fill 104 64 -261 107 64 -261 minecraft:air
fill 109 64 -261 112 64 -261 minecraft:air
fill 114 64 -261 117 64 -261 minecraft:air
fill 119 64 -261 122 64 -261 minecraft:air
fill 126 64 -261 135 64 -261 minecraft:air
fill 72 64 -262 82 64 -262 minecraft:air
fill 100 64 -262 122 64 -262 minecraft:air
fill 125 64 -262 135 64 -262 minecraft:air
fill 72 64 -263 83 64 -263 minecraft:air
fill 100 64 -263 114 64 -263 minecraft:air
fill 116 64 -263 121 64 -263 minecraft:air
fill 124 64 -263 135 64 -263 minecraft:air
fill 72 64 -264 84 64 -264 minecraft:air
fill 99 64 -264 120 64 -264 minecraft:air
fill 123 64 -264 135 64 -264 minecraft:air
fill 72 64 -265 84 64 -265 minecraft:air
fill 99 64 -265 118 64 -265 minecraft:air
fill 122 64 -265 135 64 -265 minecraft:air
setblock 72 64 -266 minecraft:air
fill 74 64 -266 77 64 -266 minecraft:air
fill 79 64 -266 82 64 -266 minecraft:air
fill 84 64 -266 85 64 -266 minecraft:air
fill 99 64 -266 102 64 -266 minecraft:air
fill 104 64 -266 107 64 -266 minecraft:air
fill 109 64 -266 112 64 -266 minecraft:air
fill 114 64 -266 117 64 -266 minecraft:air
fill 120 64 -266 135 64 -266 minecraft:air
fill 72 64 -267 86 64 -267 minecraft:air
fill 98 64 -267 115 64 -267 minecraft:air
fill 119 64 -267 135 64 -267 minecraft:air
fill 72 64 -268 87 64 -268 minecraft:air
fill 97 64 -268 113 64 -268 minecraft:air
fill 117 64 -268 135 64 -268 minecraft:air
fill 72 64 -269 88 64 -269 minecraft:air
fill 97 64 -269 112 64 -269 minecraft:air
fill 115 64 -269 135 64 -269 minecraft:air
fill 72 64 -270 89 64 -270 minecraft:air
fill 96 64 -270 109 64 -270 minecraft:air
fill 113 64 -270 135 64 -270 minecraft:air
setblock 72 64 -271 minecraft:air
fill 74 64 -271 77 64 -271 minecraft:air
fill 79 64 -271 82 64 -271 minecraft:air
fill 84 64 -271 87 64 -271 minecraft:air
setblock 89 64 -271 minecraft:air
fill 95 64 -271 97 64 -271 minecraft:air
fill 99 64 -271 102 64 -271 minecraft:air
fill 104 64 -271 107 64 -271 minecraft:air
fill 111 64 -271 135 64 -271 minecraft:air
fill 72 64 -272 90 64 -272 minecraft:air
fill 95 64 -272 104 64 -272 minecraft:air
fill 109 64 -272 135 64 -272 minecraft:air
fill 75 64 -273 91 64 -273 minecraft:air
fill 94 64 -273 101 64 -273 minecraft:air
fill 106 64 -273 135 64 -273 minecraft:air
fill 72 64 -274 73 64 -274 minecraft:air
fill 80 64 -274 92 64 -274 minecraft:air
fill 94 64 -274 96 64 -274 minecraft:air
fill 103 64 -274 135 64 -274 minecraft:air
fill 72 64 -275 77 64 -275 minecraft:air
fill 99 64 -275 135 64 -275 minecraft:air
fill 72 64 -276 87 64 -276 minecraft:air
fill 89 64 -276 135 64 -276 minecraft:air
fill 72 64 -277 135 64 -277 minecraft:air
fill 72 64 -278 135 64 -278 minecraft:air
fill 72 64 -279 135 64 -279 minecraft:air
fill 72 64 -280 135 64 -280 minecraft:air
fill 72 64 -281 135 64 -281 minecraft:air
fill 72 64 -282 135 64 -282 minecraft:air
fill 72 64 -283 91 64 -283 minecraft:air
fill 97 64 -283 135 64 -283 minecraft:air
setblock 72 64 -284 minecraft:air
fill 98 64 -284 99 64 -284 minecraft:air
setblock 100 64 -284 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
fill 101 64 -284 135 64 -284 minecraft:air
setblock 72 64 -285 minecraft:air
fill 98 64 -285 135 64 -285 minecraft:air
setblock 98 64 -286 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
fill 99 64 -286 135 64 -286 minecraft:air
fill 98 64 -287 118 64 -287 minecraft:air
setblock 119 64 -287 minecraft:vine[east=false,north=true,south=false,up=false,west=false]
fill 120 64 -287 134 64 -287 minecraft:air
fill 98 64 -288 117 64 -288 minecraft:air
setblock 118 64 -288 minecraft:vine[east=true,north=false,south=false,up=false,west=false]
setblock 120 64 -288 minecraft:vine[east=false,north=false,south=false,up=false,west=true]
fill 121 64 -288 126 64 -288 minecraft:air
fill 128 64 -288 134 64 -288 minecraft:air
fill 97 64 -289 134 64 -289 minecraft:air
fill 97 64 -290 134 64 -290 minecraft:air
fill 97 64 -291 134 64 -291 minecraft:air
setblock 97 64 -292 minecraft:air
setblock 98 64 -292 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
fill 99 64 -292 135 64 -292 minecraft:air
setblock 96 64 -293 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
fill 97 64 -293 134 64 -293 minecraft:air
fill 95 64 -294 96 64 -294 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
fill 98 64 -294 134 64 -294 minecraft:air
fill 94 64 -295 126 64 -295 minecraft:air
setblock 127 64 -295 minecraft:vine[east=false,north=true,south=false,up=false,west=false]
fill 128 64 -295 133 64 -295 minecraft:air
fill 94 64 -296 118 64 -296 minecraft:air
fill 120 64 -296 126 64 -296 minecraft:air
setblock 128 64 -296 minecraft:vine[east=false,north=false,south=false,up=false,west=true]
fill 129 64 -296 133 64 -296 minecraft:air
fill 93 64 -297 126 64 -297 minecraft:air
setblock 127 64 -297 minecraft:vine[east=false,north=false,south=true,up=false,west=false]
fill 128 64 -297 132 64 -297 minecraft:air
setblock 91 64 -298 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 92 64 -298 minecraft:tall_grass[half=lower]
fill 93 64 -298 132 64 -298 minecraft:air
fill 89 64 -299 91 64 -299 minecraft:air
setblock 92 64 -299 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
fill 93 64 -299 132 64 -299 minecraft:air
setblock 87 64 -300 regions_unexplored:grass_sprouts
setblock 88 64 -300 minecraft:air
setblock 89 64 -300 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 90 64 -300 minecraft:tall_grass[half=upper]
fill 91 64 -300 131 64 -300 minecraft:air
setblock 72 64 -301 minecraft:air
setblock 86 64 -301 minecraft:air
setblock 88 64 -301 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
fill 89 64 -301 131 64 -301 minecraft:air
fill 72 64 -302 73 64 -302 minecraft:air
setblock 85 64 -302 minecraft:air
setblock 86 64 -302 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
fill 87 64 -302 130 64 -302 minecraft:air
fill 72 64 -303 74 64 -303 minecraft:air
setblock 85 64 -303 minecraft:short_grass
setblock 86 64 -303 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 87 64 -303 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
fill 88 64 -303 89 64 -303 minecraft:air
fill 91 64 -303 130 64 -303 minecraft:air
fill 73 64 -304 76 64 -304 minecraft:air
fill 84 64 -304 88 64 -304 minecraft:air
fill 90 64 -304 130 64 -304 minecraft:air
fill 72 64 -305 75 64 -305 minecraft:air
setblock 83 64 -305 regions_unexplored:grass_sprouts
fill 84 64 -305 85 64 -305 minecraft:air
setblock 86 64 -305 regions_unexplored:grass_sprouts
fill 87 64 -305 129 64 -305 minecraft:air
fill 72 64 -306 73 64 -306 minecraft:air
setblock 82 64 -306 minecraft:air
setblock 83 64 -306 regions_unexplored:grass_sprouts
fill 84 64 -306 129 64 -306 minecraft:air
fill 81 64 -307 113 64 -307 minecraft:air
setblock 114 64 -307 minecraft:tall_grass[half=upper]
fill 115 64 -307 129 64 -307 minecraft:air
setblock 80 64 -308 minecraft:air
setblock 81 64 -308 minecraft:short_grass
setblock 82 64 -308 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
fill 83 64 -308 128 64 -308 minecraft:air
setblock 79 64 -309 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 80 64 -309 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 81 64 -309 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
setblock 82 64 -309 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
fill 83 64 -309 117 64 -309 minecraft:air
fill 119 64 -309 127 64 -309 minecraft:air
setblock 78 64 -310 minecraft:air
setblock 79 64 -310 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 80 64 -310 81 64 -310 minecraft:air
setblock 82 64 -310 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 83 64 -310 84 64 -310 minecraft:air
setblock 85 64 -310 minecraft:short_grass
fill 86 64 -310 87 64 -310 minecraft:air
fill 89 64 -310 115 64 -310 minecraft:air
setblock 116 64 -310 regions_unexplored:grass_sprouts
fill 117 64 -310 127 64 -310 minecraft:air
setblock 78 64 -311 minecraft:air
setblock 80 64 -311 minecraft:air
setblock 81 64 -311 regions_unexplored:grass_sprouts
setblock 82 64 -311 minecraft:air
setblock 83 64 -311 minecraft:short_grass
fill 84 64 -311 116 64 -311 minecraft:air
setblock 117 64 -311 regions_unexplored:grass_sprouts
fill 118 64 -311 126 64 -311 minecraft:air
setblock 76 64 -312 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
setblock 77 64 -312 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 78 64 -312 regions_unexplored:grass_sprouts
setblock 79 64 -312 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 80 64 -312 minecraft:air
setblock 81 64 -312 minecraft:short_grass
setblock 82 64 -312 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
fill 83 64 -312 113 64 -312 minecraft:air
setblock 115 64 -312 minecraft:tall_grass[half=lower]
setblock 117 64 -312 minecraft:air
setblock 118 64 -312 minecraft:short_grass
fill 120 64 -312 126 64 -312 minecraft:air
setblock 76 64 -313 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 77 64 -313 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
fill 78 64 -313 80 64 -313 minecraft:air
setblock 81 64 -313 minecraft:short_grass
setblock 82 64 -313 regions_unexplored:grass_sprouts
fill 83 64 -313 115 64 -313 minecraft:air
fill 117 64 -313 125 64 -313 minecraft:air
fill 76 64 -314 78 64 -314 minecraft:air
setblock 79 64 -314 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 80 64 -314 minecraft:air
setblock 81 64 -314 minecraft:short_grass
setblock 82 64 -314 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 83 64 -314 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
setblock 84 64 -314 minecraft:short_grass
fill 85 64 -314 115 64 -314 minecraft:air
fill 118 64 -314 119 64 -314 minecraft:air
setblock 120 64 -314 minecraft:short_grass
setblock 121 64 -314 minecraft:air
setblock 122 64 -314 minecraft:short_grass
fill 123 64 -314 125 64 -314 minecraft:air
setblock 75 64 -315 minecraft:short_grass
fill 76 64 -315 77 64 -315 minecraft:air
setblock 78 64 -315 minecraft:short_grass
fill 79 64 -315 81 64 -315 minecraft:air
setblock 82 64 -315 minecraft:short_grass
fill 83 64 -315 85 64 -315 minecraft:air
setblock 86 64 -315 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
fill 87 64 -315 112 64 -315 minecraft:air
fill 114 64 -315 115 64 -315 minecraft:air
fill 119 64 -315 120 64 -315 minecraft:air
setblock 121 64 -315 regions_unexplored:grass_sprouts
fill 122 64 -315 125 64 -315 minecraft:air
fill 74 64 -316 75 64 -316 minecraft:air
setblock 77 64 -316 minecraft:short_grass
fill 78 64 -316 82 64 -316 minecraft:air
setblock 83 64 -316 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 84 64 -316 regions_unexplored:grass_sprouts
fill 85 64 -316 111 64 -316 minecraft:air
fill 113 64 -316 114 64 -316 minecraft:air
setblock 115 64 -316 regions_unexplored:grass_sprouts
setblock 121 64 -316 regions_unexplored:grass_sprouts
fill 122 64 -316 123 64 -316 minecraft:air
setblock 73 64 -317 minecraft:air
setblock 74 64 -317 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 75 64 -317 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 76 64 -317 minecraft:air
setblock 77 64 -317 minecraft:short_grass
fill 78 64 -317 82 64 -317 minecraft:air
setblock 83 64 -317 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 84 64 -317 85 64 -317 minecraft:air
fill 87 64 -317 114 64 -317 minecraft:air
setblock 115 64 -317 regions_unexplored:grass_sprouts
setblock 74 64 -318 minecraft:air
fill 76 64 -318 77 64 -318 minecraft:air
setblock 78 64 -318 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
fill 79 64 -318 80 64 -318 minecraft:air
setblock 81 64 -318 minecraft:short_grass
fill 82 64 -318 83 64 -318 regions_unexplored:grass_sprouts
setblock 84 64 -318 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
fill 85 64 -318 86 64 -318 minecraft:air
setblock 87 64 -318 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
fill 88 64 -318 115 64 -318 minecraft:air
fill 132 63 -255 135 63 -255 minecraft:air
fill 131 63 -256 135 63 -256 minecraft:air
fill 130 63 -257 135 63 -257 minecraft:air
fill 129 63 -258 135 63 -258 minecraft:air
fill 128 63 -259 135 63 -259 minecraft:air
fill 127 63 -260 135 63 -260 minecraft:air
fill 126 63 -261 135 63 -261 minecraft:air
fill 125 63 -262 135 63 -262 minecraft:air
fill 124 63 -263 135 63 -263 minecraft:air
fill 123 63 -264 135 63 -264 minecraft:air
fill 122 63 -265 135 63 -265 minecraft:air
fill 120 63 -266 135 63 -266 minecraft:air
fill 119 63 -267 135 63 -267 minecraft:air
fill 117 63 -268 135 63 -268 minecraft:air
fill 115 63 -269 135 63 -269 minecraft:air
fill 113 63 -270 135 63 -270 minecraft:air
fill 111 63 -271 135 63 -271 minecraft:air
fill 109 63 -272 135 63 -272 minecraft:air
fill 106 63 -273 135 63 -273 minecraft:air
fill 72 63 -274 73 63 -274 minecraft:air
fill 103 63 -274 135 63 -274 minecraft:air
fill 72 63 -275 77 63 -275 minecraft:air
fill 99 63 -275 135 63 -275 minecraft:air
fill 72 63 -276 87 63 -276 minecraft:air
fill 89 63 -276 135 63 -276 minecraft:air
fill 72 63 -277 135 63 -277 minecraft:air
fill 72 63 -278 135 63 -278 minecraft:air
fill 72 63 -279 135 63 -279 minecraft:air
fill 72 63 -280 135 63 -280 minecraft:air
fill 72 63 -281 135 63 -281 minecraft:air
fill 72 63 -282 135 63 -282 minecraft:air
fill 72 63 -283 91 63 -283 minecraft:air
fill 97 63 -283 135 63 -283 minecraft:air
fill 72 63 -284 73 63 -284 minecraft:air
fill 102 63 -284 135 63 -284 minecraft:air
setblock 72 63 -285 minecraft:air
setblock 101 63 -285 minecraft:short_grass
fill 102 63 -285 135 63 -285 minecraft:air
setblock 72 63 -286 minecraft:air
setblock 100 63 -286 minecraft:short_grass
setblock 101 63 -286 minecraft:air
fill 103 63 -286 135 63 -286 minecraft:air
setblock 100 63 -287 minecraft:air
fill 102 63 -287 118 63 -287 minecraft:air
setblock 119 63 -287 minecraft:vine[east=false,north=true,south=false,up=false,west=false]
fill 120 63 -287 135 63 -287 minecraft:air
setblock 99 63 -288 minecraft:air
setblock 100 63 -288 minecraft:short_grass
fill 102 63 -288 117 63 -288 minecraft:air
setblock 118 63 -288 minecraft:vine[east=true,north=false,south=false,up=false,west=false]
setblock 120 63 -288 minecraft:vine[east=false,north=false,south=false,up=false,west=true]
fill 121 63 -288 126 63 -288 minecraft:air
fill 128 63 -288 134 63 -288 minecraft:air
fill 99 63 -289 134 63 -289 minecraft:air
fill 99 63 -290 134 63 -290 minecraft:air
setblock 99 63 -291 minecraft:air
setblock 100 63 -291 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
fill 101 63 -291 134 63 -291 minecraft:air
setblock 99 63 -292 minecraft:air
setblock 100 63 -292 regions_unexplored:grass_sprouts
fill 101 63 -292 134 63 -292 minecraft:air
fill 98 63 -293 134 63 -293 minecraft:air
setblock 98 63 -294 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 99 63 -294 133 63 -294 minecraft:air
fill 96 63 -295 126 63 -295 minecraft:air
setblock 127 63 -295 minecraft:vine[east=false,north=true,south=false,up=false,west=false]
fill 128 63 -295 133 63 -295 minecraft:air
setblock 94 63 -296 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 95 63 -296 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
fill 96 63 -296 118 63 -296 minecraft:air
fill 120 63 -296 126 63 -296 minecraft:air
setblock 128 63 -296 minecraft:vine[east=false,north=false,south=false,up=false,west=true]
fill 129 63 -296 133 63 -296 minecraft:air
fill 94 63 -297 95 63 -297 minecraft:air
fill 97 63 -297 126 63 -297 minecraft:air
setblock 127 63 -297 minecraft:vine[east=false,north=false,south=true,up=false,west=false]
fill 128 63 -297 132 63 -297 minecraft:air
fill 93 63 -298 132 63 -298 minecraft:air
fill 93 63 -299 115 63 -299 minecraft:air
fill 117 63 -299 131 63 -299 minecraft:air
setblock 90 63 -300 minecraft:tall_grass[half=lower]
fill 91 63 -300 115 63 -300 minecraft:air
setblock 117 63 -300 minecraft:air
fill 119 63 -300 131 63 -300 minecraft:air
setblock 72 63 -301 minecraft:air
fill 89 63 -301 92 63 -301 minecraft:air
fill 94 63 -301 112 63 -301 minecraft:air
setblock 114 63 -301 minecraft:air
fill 116 63 -301 131 63 -301 minecraft:air
setblock 72 63 -302 minecraft:air
setblock 88 63 -302 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=2]
setblock 89 63 -302 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 90 63 -302 minecraft:air
setblock 91 63 -302 minecraft:short_grass
fill 92 63 -302 117 63 -302 minecraft:air
fill 119 63 -302 130 63 -302 minecraft:air
fill 72 63 -303 73 63 -303 minecraft:air
fill 88 63 -303 89 63 -303 regions_unexplored:grass_sprouts
fill 91 63 -303 118 63 -303 minecraft:air
fill 120 63 -303 130 63 -303 minecraft:air
fill 73 63 -304 74 63 -304 minecraft:air
setblock 87 63 -304 minecraft:air
setblock 88 63 -304 regions_unexplored:grass_sprouts
fill 90 63 -304 91 63 -304 minecraft:air
fill 93 63 -304 115 63 -304 minecraft:air
fill 117 63 -304 129 63 -304 minecraft:air
fill 72 63 -305 73 63 -305 minecraft:air
setblock 87 63 -305 minecraft:air
setblock 88 63 -305 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 89 63 -305 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
fill 90 63 -305 115 63 -305 minecraft:air
setblock 117 63 -305 minecraft:air
fill 119 63 -305 129 63 -305 minecraft:air
setblock 87 63 -306 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=2]
fill 88 63 -306 111 63 -306 minecraft:air
setblock 113 63 -306 minecraft:air
fill 115 63 -306 129 63 -306 minecraft:air
setblock 86 63 -307 minecraft:air
setblock 87 63 -307 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
setblock 88 63 -307 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
fill 90 63 -307 111 63 -307 minecraft:air
setblock 113 63 -307 minecraft:air
fill 115 63 -307 117 63 -307 minecraft:air
fill 119 63 -307 128 63 -307 minecraft:air
fill 86 63 -308 112 63 -308 minecraft:air
setblock 114 63 -308 minecraft:air
fill 116 63 -308 127 63 -308 minecraft:air
setblock 86 63 -309 regions_unexplored:grass_sprouts
fill 87 63 -309 112 63 -309 minecraft:air
setblock 113 63 -309 minecraft:short_grass
setblock 114 63 -309 minecraft:air
setblock 116 63 -309 minecraft:air
fill 119 63 -309 127 63 -309 minecraft:air
fill 86 63 -310 87 63 -310 minecraft:air
fill 89 63 -310 113 63 -310 minecraft:air
setblock 114 63 -310 regions_unexplored:grass_sprouts
fill 118 63 -310 126 63 -310 minecraft:air
fill 86 63 -311 114 63 -311 minecraft:air
fill 119 63 -311 126 63 -311 minecraft:air
fill 86 63 -312 111 63 -312 minecraft:air
setblock 112 63 -312 minecraft:short_grass
setblock 113 63 -312 minecraft:air
fill 120 63 -312 125 63 -312 minecraft:air
setblock 86 63 -313 regions_unexplored:grass_sprouts
fill 87 63 -313 89 63 -313 minecraft:air
fill 91 63 -313 112 63 -313 minecraft:air
setblock 113 63 -313 regions_unexplored:grass_sprouts
fill 121 63 -313 125 63 -313 minecraft:air
fill 87 63 -314 90 63 -314 minecraft:air
fill 92 63 -314 113 63 -314 minecraft:air
setblock 118 63 -314 minecraft:air
fill 123 63 -314 124 63 -314 minecraft:air
fill 87 63 -315 112 63 -315 minecraft:air
setblock 118 63 -315 minecraft:air
fill 88 63 -316 111 63 -316 minecraft:air
fill 88 63 -317 90 63 -317 minecraft:air
setblock 91 63 -317 minecraft:short_grass
fill 92 63 -317 110 63 -317 minecraft:air
fill 112 63 -317 113 63 -317 minecraft:air
setblock 119 63 -317 minecraft:air
fill 88 63 -318 91 63 -318 minecraft:air
setblock 92 63 -318 regions_unexplored:grass_sprouts
fill 93 63 -318 114 63 -318 minecraft:air
fill 119 63 -318 120 63 -318 minecraft:air
fill 132 62 -255 135 62 -255 minecraft:air
fill 131 62 -256 135 62 -256 minecraft:air
fill 130 62 -257 135 62 -257 minecraft:air
fill 129 62 -258 135 62 -258 minecraft:air
fill 128 62 -259 135 62 -259 minecraft:air
fill 127 62 -260 135 62 -260 minecraft:air
fill 126 62 -261 135 62 -261 minecraft:air
fill 125 62 -262 135 62 -262 minecraft:air
fill 124 62 -263 135 62 -263 minecraft:air
fill 123 62 -264 135 62 -264 minecraft:air
fill 122 62 -265 135 62 -265 minecraft:air
fill 120 62 -266 135 62 -266 minecraft:air
fill 119 62 -267 135 62 -267 minecraft:air
fill 117 62 -268 135 62 -268 minecraft:air
fill 115 62 -269 135 62 -269 minecraft:air
fill 113 62 -270 135 62 -270 minecraft:air
fill 111 62 -271 135 62 -271 minecraft:air
fill 109 62 -272 135 62 -272 minecraft:air
fill 106 62 -273 135 62 -273 minecraft:air
fill 72 62 -274 73 62 -274 minecraft:air
fill 103 62 -274 135 62 -274 minecraft:air
fill 72 62 -275 77 62 -275 minecraft:air
fill 99 62 -275 135 62 -275 minecraft:air
fill 72 62 -276 87 62 -276 minecraft:air
fill 89 62 -276 135 62 -276 minecraft:air
fill 72 62 -277 135 62 -277 minecraft:air
fill 72 62 -278 135 62 -278 minecraft:air
fill 72 62 -279 135 62 -279 minecraft:air
fill 72 62 -280 135 62 -280 minecraft:air
fill 72 62 -281 135 62 -281 minecraft:air
fill 72 62 -282 135 62 -282 minecraft:air
fill 72 62 -283 91 62 -283 minecraft:air
fill 97 62 -283 135 62 -283 minecraft:air
fill 72 62 -284 73 62 -284 minecraft:air
setblock 72 62 -285 minecraft:air
setblock 103 62 -285 minecraft:seagrass
fill 104 62 -285 135 62 -285 minecraft:water[level=0]
setblock 72 62 -286 minecraft:air
fill 103 62 -286 135 62 -286 minecraft:water[level=0]
setblock 72 62 -287 minecraft:air
setblock 102 62 -287 minecraft:seagrass
fill 103 62 -287 135 62 -287 minecraft:water[level=0]
fill 102 62 -288 118 62 -288 minecraft:water[level=0]
fill 120 62 -288 126 62 -288 minecraft:water[level=0]
fill 128 62 -288 135 62 -288 minecraft:water[level=0]
fill 101 62 -289 135 62 -289 minecraft:water[level=0]
fill 101 62 -290 134 62 -290 minecraft:water[level=0]
fill 101 62 -291 134 62 -291 minecraft:water[level=0]
fill 101 62 -292 134 62 -292 minecraft:water[level=0]
fill 100 62 -293 115 62 -293 minecraft:water[level=0]
setblock 116 62 -293 minecraft:tall_seagrass[half=upper]
fill 117 62 -293 133 62 -293 minecraft:water[level=0]
fill 99 62 -294 133 62 -294 minecraft:water[level=0]
fill 98 62 -295 133 62 -295 minecraft:water[level=0]
fill 96 62 -296 115 62 -296 minecraft:water[level=0]
setblock 116 62 -296 minecraft:tall_seagrass[half=upper]
fill 117 62 -296 118 62 -296 minecraft:water[level=0]
fill 120 62 -296 126 62 -296 minecraft:water[level=0]
fill 128 62 -296 132 62 -296 minecraft:water[level=0]
setblock 95 62 -297 minecraft:water[level=0]
fill 97 62 -297 132 62 -297 minecraft:water[level=0]
fill 95 62 -298 113 62 -298 minecraft:water[level=0]
fill 114 62 -298 115 62 -298 minecraft:tall_seagrass[half=upper]
fill 116 62 -298 118 62 -298 minecraft:water[level=0]
setblock 119 62 -298 minecraft:tall_seagrass[half=upper]
fill 120 62 -298 131 62 -298 minecraft:water[level=0]
fill 94 62 -299 113 62 -299 minecraft:water[level=0]
setblock 114 62 -299 minecraft:tall_seagrass[half=upper]
setblock 115 62 -299 minecraft:water[level=0]
fill 117 62 -299 119 62 -299 minecraft:water[level=0]
setblock 120 62 -299 minecraft:tall_seagrass[half=upper]
fill 121 62 -299 131 62 -299 minecraft:water[level=0]
fill 94 62 -300 115 62 -300 minecraft:water[level=0]
setblock 117 62 -300 minecraft:water[level=0]
fill 119 62 -300 131 62 -300 minecraft:water[level=0]
setblock 72 62 -301 minecraft:air
fill 94 62 -301 112 62 -301 minecraft:water[level=0]
setblock 114 62 -301 minecraft:water[level=0]
fill 117 62 -301 130 62 -301 minecraft:water[level=0]
setblock 72 62 -302 minecraft:air
fill 92 62 -302 114 62 -302 minecraft:water[level=0]
fill 119 62 -302 130 62 -302 minecraft:water[level=0]
setblock 72 62 -303 minecraft:air
fill 91 62 -303 112 62 -303 minecraft:water[level=0]
fill 114 62 -303 115 62 -303 minecraft:water[level=0]
setblock 118 62 -303 minecraft:water[level=0]
fill 120 62 -303 129 62 -303 minecraft:water[level=0]
setblock 91 62 -304 minecraft:water[level=0]
fill 93 62 -304 111 62 -304 minecraft:water[level=0]
fill 114 62 -304 115 62 -304 minecraft:water[level=0]
fill 118 62 -304 129 62 -304 minecraft:water[level=0]
fill 90 62 -305 111 62 -305 minecraft:water[level=0]
fill 115 62 -305 116 62 -305 minecraft:water[level=0]
fill 119 62 -305 129 62 -305 minecraft:water[level=0]
fill 90 62 -306 111 62 -306 minecraft:water[level=0]
fill 115 62 -306 116 62 -306 minecraft:water[level=0]
fill 119 62 -306 128 62 -306 minecraft:water[level=0]
fill 90 62 -307 111 62 -307 minecraft:water[level=0]
fill 115 62 -307 116 62 -307 minecraft:water[level=0]
fill 119 62 -307 128 62 -307 minecraft:water[level=0]
fill 89 62 -308 112 62 -308 minecraft:water[level=0]
fill 116 62 -308 117 62 -308 minecraft:water[level=0]
fill 119 62 -308 127 62 -308 minecraft:water[level=0]
fill 89 62 -309 112 62 -309 minecraft:water[level=0]
fill 116 62 -309 117 62 -309 minecraft:water[level=0]
fill 120 62 -309 126 62 -309 minecraft:water[level=0]
fill 89 62 -310 112 62 -310 minecraft:water[level=0]
fill 117 62 -310 118 62 -310 minecraft:water[level=0]
fill 120 62 -310 125 62 -310 minecraft:water[level=0]
fill 89 62 -311 111 62 -311 minecraft:water[level=0]
fill 117 62 -311 118 62 -311 minecraft:water[level=0]
fill 122 62 -311 125 62 -311 minecraft:water[level=0]
fill 89 62 -312 111 62 -312 minecraft:water[level=0]
fill 117 62 -312 118 62 -312 minecraft:water[level=0]
fill 123 62 -312 124 62 -312 minecraft:water[level=0]
fill 91 62 -313 111 62 -313 minecraft:water[level=0]
fill 118 62 -313 119 62 -313 minecraft:water[level=0]
setblock 90 62 -314 minecraft:water[level=0]
fill 92 62 -314 111 62 -314 minecraft:water[level=0]
fill 118 62 -314 119 62 -314 minecraft:water[level=0]
fill 91 62 -315 111 62 -315 minecraft:water[level=0]
fill 118 62 -315 119 62 -315 minecraft:water[level=0]
fill 92 62 -316 111 62 -316 minecraft:water[level=0]
fill 119 62 -316 120 62 -316 minecraft:water[level=0]
fill 92 62 -317 110 62 -317 minecraft:water[level=0]
fill 119 62 -317 120 62 -317 minecraft:water[level=0]
fill 93 62 -318 112 62 -318 minecraft:water[level=0]
fill 119 62 -318 120 62 -318 minecraft:water[level=0]
fill 132 61 -255 135 61 -255 minecraft:air
fill 131 61 -256 135 61 -256 minecraft:air
fill 130 61 -257 135 61 -257 minecraft:air
fill 129 61 -258 135 61 -258 minecraft:air
fill 128 61 -259 135 61 -259 minecraft:air
fill 127 61 -260 135 61 -260 minecraft:air
fill 126 61 -261 135 61 -261 minecraft:air
fill 125 61 -262 135 61 -262 minecraft:air
fill 124 61 -263 135 61 -263 minecraft:air
fill 123 61 -264 135 61 -264 minecraft:air
fill 122 61 -265 135 61 -265 minecraft:air
fill 120 61 -266 135 61 -266 minecraft:air
fill 119 61 -267 135 61 -267 minecraft:air
fill 117 61 -268 135 61 -268 minecraft:air
fill 115 61 -269 135 61 -269 minecraft:air
fill 113 61 -270 135 61 -270 minecraft:air
fill 111 61 -271 135 61 -271 minecraft:air
fill 109 61 -272 135 61 -272 minecraft:air
fill 106 61 -273 135 61 -273 minecraft:air
fill 72 61 -274 73 61 -274 minecraft:air
fill 103 61 -274 135 61 -274 minecraft:air
fill 72 61 -275 77 61 -275 minecraft:air
fill 99 61 -275 135 61 -275 minecraft:air
fill 72 61 -276 87 61 -276 minecraft:air
fill 89 61 -276 135 61 -276 minecraft:air
fill 72 61 -277 135 61 -277 minecraft:air
fill 72 61 -278 135 61 -278 minecraft:air
fill 72 61 -279 135 61 -279 minecraft:air
fill 72 61 -280 135 61 -280 minecraft:air
fill 72 61 -281 135 61 -281 minecraft:air
fill 72 61 -282 135 61 -282 minecraft:air
fill 72 61 -283 91 61 -283 minecraft:air
fill 97 61 -283 135 61 -283 minecraft:air
fill 72 61 -284 73 61 -284 minecraft:air
fill 72 61 -285 73 61 -285 minecraft:air
fill 104 61 -285 135 61 -285 minecraft:water[level=0]
setblock 72 61 -286 minecraft:air
setblock 103 61 -286 minecraft:seagrass
fill 104 61 -286 135 61 -286 minecraft:water[level=0]
setblock 72 61 -287 minecraft:air
fill 103 61 -287 135 61 -287 minecraft:water[level=0]
setblock 72 61 -288 minecraft:air
fill 102 61 -288 118 61 -288 minecraft:water[level=0]
fill 120 61 -288 126 61 -288 minecraft:water[level=0]
fill 128 61 -288 135 61 -288 minecraft:water[level=0]
fill 102 61 -289 135 61 -289 minecraft:water[level=0]
fill 102 61 -290 134 61 -290 minecraft:water[level=0]
fill 102 61 -291 134 61 -291 minecraft:water[level=0]
fill 102 61 -292 115 61 -292 minecraft:water[level=0]
setblock 116 61 -292 minecraft:seagrass
setblock 117 61 -292 minecraft:tall_seagrass[half=upper]
fill 118 61 -292 134 61 -292 minecraft:water[level=0]
fill 102 61 -293 115 61 -293 minecraft:water[level=0]
setblock 116 61 -293 minecraft:tall_seagrass[half=lower]
setblock 117 61 -293 minecraft:tall_seagrass[half=upper]
fill 118 61 -293 133 61 -293 minecraft:water[level=0]
fill 101 61 -294 113 61 -294 minecraft:water[level=0]
setblock 114 61 -294 minecraft:tall_seagrass[half=upper]
setblock 115 61 -294 minecraft:water[level=0]
setblock 116 61 -294 minecraft:seagrass
fill 117 61 -294 133 61 -294 minecraft:water[level=0]
fill 100 61 -295 132 61 -295 minecraft:water[level=0]
fill 98 61 -296 115 61 -296 minecraft:water[level=0]
setblock 116 61 -296 minecraft:tall_seagrass[half=lower]
fill 117 61 -296 118 61 -296 minecraft:water[level=0]
fill 120 61 -296 126 61 -296 minecraft:water[level=0]
fill 128 61 -296 132 61 -296 minecraft:water[level=0]
fill 98 61 -297 111 61 -297 minecraft:water[level=0]
fill 112 61 -297 113 61 -297 minecraft:tall_seagrass[half=upper]
fill 114 61 -297 132 61 -297 minecraft:water[level=0]
fill 97 61 -298 113 61 -298 minecraft:water[level=0]
fill 114 61 -298 115 61 -298 minecraft:tall_seagrass[half=lower]
fill 116 61 -298 118 61 -298 minecraft:water[level=0]
setblock 119 61 -298 minecraft:tall_seagrass[half=lower]
fill 120 61 -298 131 61 -298 minecraft:water[level=0]
setblock 72 61 -299 minecraft:air
fill 97 61 -299 113 61 -299 minecraft:water[level=0]
setblock 114 61 -299 minecraft:tall_seagrass[half=lower]
setblock 115 61 -299 minecraft:water[level=0]
setblock 119 61 -299 minecraft:water[level=0]
setblock 120 61 -299 minecraft:tall_seagrass[half=lower]
fill 121 61 -299 131 61 -299 minecraft:water[level=0]
setblock 72 61 -300 minecraft:air
fill 97 61 -300 113 61 -300 minecraft:water[level=0]
fill 121 61 -300 131 61 -300 minecraft:water[level=0]
setblock 72 61 -301 minecraft:air
fill 95 61 -301 111 61 -301 minecraft:water[level=0]
fill 120 61 -301 130 61 -301 minecraft:water[level=0]
setblock 72 61 -302 minecraft:air
fill 94 61 -302 111 61 -302 minecraft:water[level=0]
fill 120 61 -302 130 61 -302 minecraft:water[level=0]
fill 94 61 -303 110 61 -303 minecraft:water[level=0]
fill 120 61 -303 129 61 -303 minecraft:water[level=0]
fill 93 61 -304 110 61 -304 minecraft:water[level=0]
fill 120 61 -304 129 61 -304 minecraft:water[level=0]
fill 92 61 -305 110 61 -305 minecraft:water[level=0]
setblock 116 61 -305 minecraft:water[level=0]
fill 120 61 -305 128 61 -305 minecraft:water[level=0]
fill 91 61 -306 110 61 -306 minecraft:water[level=0]
setblock 116 61 -306 minecraft:water[level=0]
fill 120 61 -306 128 61 -306 minecraft:water[level=0]
fill 91 61 -307 110 61 -307 minecraft:water[level=0]
setblock 116 61 -307 minecraft:water[level=0]
fill 120 61 -307 127 61 -307 minecraft:water[level=0]
fill 90 61 -308 111 61 -308 minecraft:water[level=0]
fill 116 61 -308 117 61 -308 minecraft:water[level=0]
fill 121 61 -308 126 61 -308 minecraft:water[level=0]
fill 90 61 -309 110 61 -309 minecraft:water[level=0]
fill 116 61 -309 117 61 -309 minecraft:water[level=0]
fill 122 61 -309 125 61 -309 minecraft:water[level=0]
fill 90 61 -310 110 61 -310 minecraft:water[level=0]
fill 117 61 -310 118 61 -310 minecraft:water[level=0]
fill 123 61 -310 124 61 -310 minecraft:water[level=0]
fill 90 61 -311 110 61 -311 minecraft:water[level=0]
fill 117 61 -311 118 61 -311 minecraft:water[level=0]
setblock 124 61 -311 minecraft:water[level=0]
fill 90 61 -312 110 61 -312 minecraft:water[level=0]
fill 117 61 -312 118 61 -312 minecraft:water[level=0]
fill 91 61 -313 110 61 -313 minecraft:water[level=0]
fill 118 61 -313 119 61 -313 minecraft:water[level=0]
fill 92 61 -314 110 61 -314 minecraft:water[level=0]
fill 118 61 -314 119 61 -314 minecraft:water[level=0]
fill 93 61 -315 109 61 -315 minecraft:water[level=0]
fill 118 61 -315 119 61 -315 minecraft:water[level=0]
fill 94 61 -316 109 61 -316 minecraft:water[level=0]
fill 119 61 -316 120 61 -316 minecraft:water[level=0]
fill 94 61 -317 110 61 -317 minecraft:water[level=0]
fill 119 61 -317 120 61 -317 minecraft:water[level=0]
fill 94 61 -318 110 61 -318 minecraft:water[level=0]
fill 119 61 -318 120 61 -318 minecraft:water[level=0]
fill 132 60 -255 135 60 -255 minecraft:air
fill 131 60 -256 135 60 -256 minecraft:air
fill 130 60 -257 135 60 -257 minecraft:air
fill 129 60 -258 135 60 -258 minecraft:air
fill 128 60 -259 135 60 -259 minecraft:air
fill 127 60 -260 135 60 -260 minecraft:air
fill 126 60 -261 135 60 -261 minecraft:air
fill 125 60 -262 135 60 -262 minecraft:air
fill 124 60 -263 135 60 -263 minecraft:air
fill 123 60 -264 135 60 -264 minecraft:air
fill 122 60 -265 135 60 -265 minecraft:air
fill 120 60 -266 135 60 -266 minecraft:air
fill 119 60 -267 135 60 -267 minecraft:air
fill 117 60 -268 135 60 -268 minecraft:air
fill 115 60 -269 135 60 -269 minecraft:air
fill 113 60 -270 135 60 -270 minecraft:air
fill 111 60 -271 135 60 -271 minecraft:air
fill 109 60 -272 135 60 -272 minecraft:air
fill 106 60 -273 135 60 -273 minecraft:air
fill 72 60 -274 73 60 -274 minecraft:air
fill 103 60 -274 135 60 -274 minecraft:air
fill 72 60 -275 77 60 -275 minecraft:air
fill 99 60 -275 135 60 -275 minecraft:air
fill 72 60 -276 87 60 -276 minecraft:air
fill 89 60 -276 135 60 -276 minecraft:air
fill 72 60 -277 135 60 -277 minecraft:air
fill 72 60 -278 135 60 -278 minecraft:air
fill 72 60 -279 135 60 -279 minecraft:air
fill 72 60 -280 135 60 -280 minecraft:air
fill 72 60 -281 135 60 -281 minecraft:air
fill 72 60 -282 135 60 -282 minecraft:air
fill 72 60 -283 91 60 -283 minecraft:air
fill 97 60 -283 135 60 -283 minecraft:air
fill 72 60 -284 73 60 -284 minecraft:air
fill 72 60 -285 73 60 -285 minecraft:air
fill 105 60 -285 135 60 -285 minecraft:water[level=0]
fill 72 60 -286 73 60 -286 minecraft:air
fill 104 60 -286 135 60 -286 minecraft:water[level=0]
setblock 72 60 -287 minecraft:air
fill 104 60 -287 135 60 -287 minecraft:water[level=0]
setblock 72 60 -288 minecraft:air
fill 103 60 -288 118 60 -288 minecraft:water[level=0]
fill 120 60 -288 126 60 -288 minecraft:water[level=0]
fill 128 60 -288 135 60 -288 minecraft:water[level=0]
setblock 103 60 -289 minecraft:seagrass
fill 104 60 -289 135 60 -289 minecraft:water[level=0]
setblock 103 60 -290 minecraft:seagrass
fill 104 60 -290 134 60 -290 minecraft:water[level=0]
fill 103 60 -291 112 60 -291 minecraft:water[level=0]
setblock 113 60 -291 minecraft:tall_seagrass[half=upper]
fill 114 60 -291 134 60 -291 minecraft:water[level=0]
setblock 103 60 -292 minecraft:seagrass
fill 104 60 -292 111 60 -292 minecraft:water[level=0]
setblock 112 60 -292 minecraft:tall_seagrass[half=upper]
fill 113 60 -292 115 60 -292 minecraft:water[level=0]
setblock 117 60 -292 minecraft:tall_seagrass[half=lower]
fill 118 60 -292 133 60 -292 minecraft:water[level=0]
fill 103 60 -293 113 60 -293 minecraft:water[level=0]
setblock 114 60 -293 minecraft:seagrass
setblock 115 60 -293 minecraft:water[level=0]
setblock 117 60 -293 minecraft:tall_seagrass[half=lower]
fill 118 60 -293 133 60 -293 minecraft:water[level=0]
fill 103 60 -294 113 60 -294 minecraft:water[level=0]
setblock 114 60 -294 minecraft:tall_seagrass[half=lower]
setblock 115 60 -294 minecraft:water[level=0]
fill 117 60 -294 133 60 -294 minecraft:water[level=0]
setblock 72 60 -295 minecraft:air
fill 102 60 -295 113 60 -295 minecraft:water[level=0]
fill 114 60 -295 115 60 -295 minecraft:seagrass
fill 117 60 -295 132 60 -295 minecraft:water[level=0]
fill 72 60 -296 73 60 -296 minecraft:air
fill 101 60 -296 115 60 -296 minecraft:water[level=0]
setblock 117 60 -296 minecraft:seagrass
setblock 118 60 -296 minecraft:water[level=0]
fill 120 60 -296 126 60 -296 minecraft:water[level=0]
fill 128 60 -296 132 60 -296 minecraft:water[level=0]
fill 72 60 -297 73 60 -297 minecraft:air
fill 100 60 -297 111 60 -297 minecraft:water[level=0]
fill 112 60 -297 113 60 -297 minecraft:tall_seagrass[half=lower]
setblock 114 60 -297 minecraft:water[level=0]
fill 119 60 -297 131 60 -297 minecraft:water[level=0]
fill 72 60 -298 73 60 -298 minecraft:air
fill 99 60 -298 113 60 -298 minecraft:water[level=0]
fill 120 60 -298 131 60 -298 minecraft:water[level=0]
setblock 72 60 -299 minecraft:air
fill 99 60 -299 111 60 -299 minecraft:water[level=0]
fill 121 60 -299 131 60 -299 minecraft:water[level=0]
setblock 72 60 -300 minecraft:air
fill 98 60 -300 111 60 -300 minecraft:water[level=0]
fill 121 60 -300 130 60 -300 minecraft:water[level=0]
setblock 72 60 -301 minecraft:air
fill 97 60 -301 110 60 -301 minecraft:water[level=0]
fill 121 60 -301 130 60 -301 minecraft:water[level=0]
fill 95 60 -302 110 60 -302 minecraft:water[level=0]
fill 121 60 -302 129 60 -302 minecraft:water[level=0]
fill 95 60 -303 109 60 -303 minecraft:water[level=0]
fill 121 60 -303 129 60 -303 minecraft:water[level=0]
fill 94 60 -304 109 60 -304 minecraft:water[level=0]
fill 121 60 -304 128 60 -304 minecraft:water[level=0]
fill 94 60 -305 109 60 -305 minecraft:water[level=0]
fill 122 60 -305 128 60 -305 minecraft:water[level=0]
fill 93 60 -306 109 60 -306 minecraft:water[level=0]
fill 122 60 -306 127 60 -306 minecraft:water[level=0]
fill 92 60 -307 109 60 -307 minecraft:water[level=0]
fill 122 60 -307 126 60 -307 minecraft:water[level=0]
fill 91 60 -308 110 60 -308 minecraft:water[level=0]
fill 123 60 -308 125 60 -308 minecraft:water[level=0]
fill 91 60 -309 109 60 -309 minecraft:water[level=0]
setblock 124 60 -309 minecraft:water[level=0]
fill 91 60 -310 109 60 -310 minecraft:water[level=0]
fill 91 60 -311 109 60 -311 minecraft:water[level=0]
fill 91 60 -312 109 60 -312 minecraft:water[level=0]
setblock 119 60 -312 minecraft:water[level=0]
fill 92 60 -313 109 60 -313 minecraft:water[level=0]
setblock 119 60 -313 minecraft:water[level=0]
fill 93 60 -314 109 60 -314 minecraft:water[level=0]
setblock 119 60 -314 minecraft:water[level=0]
fill 94 60 -315 107 60 -315 minecraft:water[level=0]
setblock 108 60 -315 minecraft:tall_seagrass[half=upper]
setblock 109 60 -315 minecraft:water[level=0]
fill 95 60 -316 108 60 -316 minecraft:water[level=0]
setblock 120 60 -316 minecraft:water[level=0]
fill 95 60 -317 108 60 -317 minecraft:water[level=0]
setblock 120 60 -317 minecraft:water[level=0]
fill 95 60 -318 109 60 -318 minecraft:water[level=0]
fill 132 59 -255 135 59 -255 minecraft:air
fill 131 59 -256 135 59 -256 minecraft:air
fill 130 59 -257 135 59 -257 minecraft:air
fill 129 59 -258 135 59 -258 minecraft:air
fill 128 59 -259 135 59 -259 minecraft:air
fill 127 59 -260 135 59 -260 minecraft:air
fill 126 59 -261 135 59 -261 minecraft:air
fill 125 59 -262 135 59 -262 minecraft:air
fill 124 59 -263 135 59 -263 minecraft:air
fill 123 59 -264 135 59 -264 minecraft:air
fill 122 59 -265 135 59 -265 minecraft:air
fill 120 59 -266 135 59 -266 minecraft:air
fill 119 59 -267 135 59 -267 minecraft:air
fill 117 59 -268 135 59 -268 minecraft:air
fill 115 59 -269 135 59 -269 minecraft:air
fill 113 59 -270 135 59 -270 minecraft:air
fill 111 59 -271 135 59 -271 minecraft:air
fill 109 59 -272 135 59 -272 minecraft:air
fill 106 59 -273 135 59 -273 minecraft:air
fill 72 59 -274 73 59 -274 minecraft:air
fill 103 59 -274 135 59 -274 minecraft:air
fill 72 59 -275 77 59 -275 minecraft:air
fill 99 59 -275 135 59 -275 minecraft:air
fill 72 59 -276 87 59 -276 minecraft:air
fill 89 59 -276 135 59 -276 minecraft:air
fill 72 59 -277 135 59 -277 minecraft:air
fill 72 59 -278 135 59 -278 minecraft:air
fill 72 59 -279 135 59 -279 minecraft:air
fill 72 59 -280 135 59 -280 minecraft:air
fill 72 59 -281 135 59 -281 minecraft:air
fill 72 59 -282 135 59 -282 minecraft:air
fill 72 59 -283 74 59 -283 minecraft:air
fill 100 59 -283 135 59 -283 minecraft:air
fill 72 59 -284 74 59 -284 minecraft:air
fill 72 59 -285 73 59 -285 minecraft:air
setblock 106 59 -285 minecraft:seagrass
setblock 107 59 -285 minecraft:tall_seagrass[half=upper]
fill 108 59 -285 135 59 -285 minecraft:water[level=0]
fill 72 59 -286 73 59 -286 minecraft:air
fill 105 59 -286 135 59 -286 minecraft:water[level=0]
setblock 72 59 -287 minecraft:air
fill 104 59 -287 135 59 -287 minecraft:water[level=0]
setblock 72 59 -288 minecraft:air
setblock 104 59 -288 minecraft:tall_seagrass[half=upper]
fill 105 59 -288 116 59 -288 minecraft:water[level=0]
setblock 117 59 -288 minecraft:tall_seagrass[half=upper]
setblock 118 59 -288 minecraft:water[level=0]
fill 120 59 -288 126 59 -288 minecraft:water[level=0]
fill 128 59 -288 135 59 -288 minecraft:water[level=0]
fill 104 59 -289 135 59 -289 minecraft:water[level=0]
fill 104 59 -290 134 59 -290 minecraft:water[level=0]
fill 104 59 -291 112 59 -291 minecraft:water[level=0]
setblock 113 59 -291 minecraft:tall_seagrass[half=lower]
fill 114 59 -291 115 59 -291 minecraft:seagrass
fill 118 59 -291 134 59 -291 minecraft:water[level=0]
fill 104 59 -292 111 59 -292 minecraft:water[level=0]
setblock 112 59 -292 minecraft:tall_seagrass[half=lower]
setblock 113 59 -292 minecraft:water[level=0]
fill 120 59 -292 133 59 -292 minecraft:water[level=0]
fill 104 59 -293 113 59 -293 minecraft:water[level=0]
fill 120 59 -293 133 59 -293 minecraft:water[level=0]
fill 72 59 -294 73 59 -294 minecraft:air
fill 104 59 -294 111 59 -294 minecraft:water[level=0]
fill 112 59 -294 113 59 -294 minecraft:seagrass
fill 120 59 -294 132 59 -294 minecraft:water[level=0]
fill 72 59 -295 75 59 -295 minecraft:air
fill 103 59 -295 111 59 -295 minecraft:water[level=0]
fill 112 59 -295 113 59 -295 minecraft:seagrass
fill 120 59 -295 132 59 -295 minecraft:water[level=0]
fill 72 59 -296 77 59 -296 minecraft:air
setblock 103 59 -296 minecraft:water[level=0]
setblock 104 59 -296 minecraft:seagrass
fill 105 59 -296 112 59 -296 minecraft:water[level=0]
setblock 113 59 -296 minecraft:seagrass
fill 120 59 -296 126 59 -296 minecraft:water[level=0]
fill 128 59 -296 132 59 -296 minecraft:water[level=0]
fill 72 59 -297 75 59 -297 minecraft:air
fill 102 59 -297 111 59 -297 minecraft:water[level=0]
fill 121 59 -297 131 59 -297 minecraft:water[level=0]
fill 72 59 -298 74 59 -298 minecraft:air
fill 101 59 -298 109 59 -298 minecraft:water[level=0]
setblock 110 59 -298 minecraft:seagrass
setblock 111 59 -298 minecraft:water[level=0]
fill 122 59 -298 131 59 -298 minecraft:water[level=0]
fill 72 59 -299 73 59 -299 minecraft:air
fill 100 59 -299 110 59 -299 minecraft:water[level=0]
fill 122 59 -299 130 59 -299 minecraft:water[level=0]
setblock 72 59 -300 minecraft:air
fill 99 59 -300 110 59 -300 minecraft:water[level=0]
fill 122 59 -300 130 59 -300 minecraft:water[level=0]
setblock 72 59 -301 minecraft:air
fill 98 59 -301 108 59 -301 minecraft:water[level=0]
setblock 109 59 -301 minecraft:seagrass
fill 122 59 -301 129 59 -301 minecraft:water[level=0]
fill 97 59 -302 109 59 -302 minecraft:water[level=0]
fill 122 59 -302 129 59 -302 minecraft:water[level=0]
fill 96 59 -303 109 59 -303 minecraft:water[level=0]
fill 122 59 -303 128 59 -303 minecraft:water[level=0]
fill 95 59 -304 108 59 -304 minecraft:water[level=0]
fill 122 59 -304 128 59 -304 minecraft:water[level=0]
fill 94 59 -305 108 59 -305 minecraft:water[level=0]
fill 123 59 -305 127 59 -305 minecraft:water[level=0]
fill 94 59 -306 109 59 -306 minecraft:water[level=0]
fill 123 59 -306 126 59 -306 minecraft:water[level=0]
fill 93 59 -307 109 59 -307 minecraft:water[level=0]
setblock 124 59 -307 minecraft:water[level=0]
fill 92 59 -308 109 59 -308 minecraft:water[level=0]
fill 92 59 -309 109 59 -309 minecraft:water[level=0]
fill 92 59 -310 108 59 -310 minecraft:water[level=0]
fill 92 59 -311 108 59 -311 minecraft:water[level=0]
fill 92 59 -312 108 59 -312 minecraft:water[level=0]
fill 92 59 -313 108 59 -313 minecraft:water[level=0]
fill 94 59 -314 108 59 -314 minecraft:water[level=0]
fill 95 59 -315 107 59 -315 minecraft:water[level=0]
setblock 108 59 -315 minecraft:tall_seagrass[half=lower]
fill 95 59 -316 108 59 -316 minecraft:water[level=0]
fill 95 59 -317 108 59 -317 minecraft:water[level=0]
fill 95 59 -318 107 59 -318 minecraft:water[level=0]
setblock 72 58 -269 minecraft:air
setblock 72 58 -270 minecraft:air
fill 72 58 -271 73 58 -271 minecraft:air
setblock 135 58 -271 minecraft:water[level=0]
fill 72 58 -272 73 58 -272 minecraft:air
setblock 135 58 -272 minecraft:seagrass
fill 72 58 -273 73 58 -273 minecraft:air
setblock 134 58 -273 minecraft:seagrass
setblock 135 58 -273 minecraft:water[level=0]
fill 72 58 -274 74 58 -274 minecraft:air
fill 134 58 -274 135 58 -274 minecraft:water[level=0]
fill 72 58 -275 74 58 -275 minecraft:air
setblock 133 58 -275 minecraft:seagrass
fill 134 58 -275 135 58 -275 minecraft:water[level=0]
fill 72 58 -276 74 58 -276 minecraft:air
fill 133 58 -276 135 58 -276 minecraft:water[level=0]
fill 72 58 -277 75 58 -277 minecraft:air
fill 132 58 -277 135 58 -277 minecraft:water[level=0]
fill 72 58 -278 75 58 -278 minecraft:air
fill 131 58 -278 135 58 -278 minecraft:water[level=0]
fill 72 58 -279 75 58 -279 minecraft:air
fill 131 58 -279 135 58 -279 minecraft:water[level=0]
fill 72 58 -280 75 58 -280 minecraft:air
fill 111 58 -280 115 58 -280 minecraft:water[level=0]
setblock 116 58 -280 minecraft:seagrass
fill 130 58 -280 135 58 -280 minecraft:water[level=0]
fill 72 58 -281 75 58 -281 minecraft:air
fill 111 58 -281 112 58 -281 minecraft:water[level=0]
setblock 113 58 -281 minecraft:tall_seagrass[half=upper]
fill 114 58 -281 116 58 -281 minecraft:water[level=0]
setblock 117 58 -281 minecraft:seagrass
setblock 118 58 -281 minecraft:water[level=0]
fill 129 58 -281 135 58 -281 minecraft:water[level=0]
fill 72 58 -282 75 58 -282 minecraft:air
setblock 110 58 -282 minecraft:water[level=0]
setblock 111 58 -282 minecraft:tall_seagrass[half=upper]
fill 112 58 -282 119 58 -282 minecraft:water[level=0]
fill 121 58 -282 135 58 -282 minecraft:water[level=0]
fill 72 58 -283 74 58 -283 minecraft:air
setblock 109 58 -283 minecraft:water[level=0]
setblock 110 58 -283 minecraft:tall_seagrass[half=upper]
fill 111 58 -283 135 58 -283 minecraft:water[level=0]
fill 72 58 -284 74 58 -284 minecraft:air
fill 72 58 -285 73 58 -285 minecraft:air
setblock 107 58 -285 minecraft:tall_seagrass[half=lower]
fill 108 58 -285 135 58 -285 minecraft:water[level=0]
fill 72 58 -286 73 58 -286 minecraft:air
setblock 106 58 -286 minecraft:seagrass
fill 107 58 -286 135 58 -286 minecraft:water[level=0]
setblock 72 58 -287 minecraft:air
fill 105 58 -287 108 58 -287 minecraft:water[level=0]
setblock 109 58 -287 minecraft:tall_seagrass[half=upper]
fill 110 58 -287 135 58 -287 minecraft:water[level=0]
setblock 72 58 -288 minecraft:air
setblock 104 58 -288 minecraft:tall_seagrass[half=lower]
fill 105 58 -288 112 58 -288 minecraft:water[level=0]
setblock 113 58 -288 minecraft:tall_seagrass[half=upper]
fill 114 58 -288 116 58 -288 minecraft:water[level=0]
setblock 117 58 -288 minecraft:tall_seagrass[half=lower]
setblock 118 58 -288 minecraft:water[level=0]
fill 120 58 -288 126 58 -288 minecraft:water[level=0]
fill 128 58 -288 135 58 -288 minecraft:water[level=0]
setblock 72 58 -289 minecraft:air
setblock 104 58 -289 minecraft:seagrass
fill 105 58 -289 113 58 -289 minecraft:water[level=0]
setblock 114 58 -289 minecraft:seagrass
setblock 115 58 -289 minecraft:water[level=0]
setblock 117 58 -289 minecraft:seagrass
fill 118 58 -289 135 58 -289 minecraft:water[level=0]
fill 104 58 -290 105 58 -290 minecraft:water[level=0]
fill 106 58 -290 107 58 -290 minecraft:tall_seagrass[half=upper]
fill 108 58 -290 111 58 -290 minecraft:water[level=0]
setblock 112 58 -290 minecraft:seagrass
fill 113 58 -290 114 58 -290 minecraft:water[level=0]
fill 119 58 -290 135 58 -290 minecraft:water[level=0]
fill 104 58 -291 109 58 -291 minecraft:water[level=0]
setblock 110 58 -291 minecraft:tall_seagrass[half=upper]
fill 111 58 -291 112 58 -291 minecraft:water[level=0]
fill 121 58 -291 134 58 -291 minecraft:water[level=0]
fill 72 58 -292 73 58 -292 minecraft:air
fill 105 58 -292 111 58 -292 minecraft:water[level=0]
fill 122 58 -292 133 58 -292 minecraft:water[level=0]
fill 72 58 -293 75 58 -293 minecraft:air
fill 105 58 -293 111 58 -293 minecraft:water[level=0]
fill 122 58 -293 133 58 -293 minecraft:water[level=0]
fill 72 58 -294 75 58 -294 minecraft:air
setblock 105 58 -294 minecraft:seagrass
fill 106 58 -294 111 58 -294 minecraft:water[level=0]
fill 122 58 -294 132 58 -294 minecraft:water[level=0]
fill 72 58 -295 76 58 -295 minecraft:air
fill 78 58 -295 79 58 -295 minecraft:water[level=0]
fill 105 58 -295 108 58 -295 minecraft:water[level=0]
setblock 109 58 -295 minecraft:tall_seagrass[half=upper]
fill 110 58 -295 111 58 -295 minecraft:water[level=0]
fill 122 58 -295 132 58 -295 minecraft:water[level=0]
fill 72 58 -296 77 58 -296 minecraft:air
fill 79 58 -296 81 58 -296 minecraft:water[level=0]
fill 105 58 -296 109 58 -296 minecraft:water[level=0]
fill 110 58 -296 111 58 -296 minecraft:seagrass
fill 122 58 -296 126 58 -296 minecraft:water[level=0]
fill 128 58 -296 132 58 -296 minecraft:water[level=0]
fill 72 58 -297 77 58 -297 minecraft:air
fill 104 58 -297 110 58 -297 minecraft:water[level=0]
fill 122 58 -297 131 58 -297 minecraft:water[level=0]
fill 72 58 -298 75 58 -298 minecraft:air
fill 102 58 -298 108 58 -298 minecraft:water[level=0]
setblock 109 58 -298 minecraft:seagrass
fill 123 58 -298 130 58 -298 minecraft:water[level=0]
fill 72 58 -299 74 58 -299 minecraft:air
fill 101 58 -299 109 58 -299 minecraft:water[level=0]
fill 123 58 -299 130 58 -299 minecraft:water[level=0]
fill 72 58 -300 73 58 -300 minecraft:air
fill 100 58 -300 108 58 -300 minecraft:water[level=0]
setblock 109 58 -300 minecraft:seagrass
fill 123 58 -300 130 58 -300 minecraft:water[level=0]
setblock 72 58 -301 minecraft:air
fill 100 58 -301 108 58 -301 minecraft:water[level=0]
fill 123 58 -301 129 58 -301 minecraft:water[level=0]
fill 99 58 -302 108 58 -302 minecraft:water[level=0]
fill 124 58 -302 129 58 -302 minecraft:water[level=0]
fill 97 58 -303 108 58 -303 minecraft:water[level=0]
fill 124 58 -303 128 58 -303 minecraft:water[level=0]
fill 96 58 -304 108 58 -304 minecraft:water[level=0]
fill 124 58 -304 128 58 -304 minecraft:water[level=0]
fill 95 58 -305 108 58 -305 minecraft:water[level=0]
setblock 124 58 -305 minecraft:water[level=0]
fill 95 58 -306 108 58 -306 minecraft:water[level=0]
fill 94 58 -307 108 58 -307 minecraft:water[level=0]
fill 92 58 -308 108 58 -308 minecraft:water[level=0]
fill 92 58 -309 108 58 -309 minecraft:water[level=0]
fill 92 58 -310 108 58 -310 minecraft:water[level=0]
fill 92 58 -311 108 58 -311 minecraft:water[level=0]
fill 92 58 -312 108 58 -312 minecraft:water[level=0]
fill 93 58 -313 108 58 -313 minecraft:water[level=0]
fill 95 58 -314 107 58 -314 minecraft:water[level=0]
fill 95 58 -315 107 58 -315 minecraft:water[level=0]
fill 96 58 -316 105 58 -316 minecraft:water[level=0]
setblock 106 58 -316 minecraft:seagrass
setblock 107 58 -316 minecraft:water[level=0]
fill 96 58 -317 106 58 -317 minecraft:water[level=0]
fill 96 58 -318 106 58 -318 minecraft:water[level=0]
setblock 135 57 -255 minecraft:water[level=0]
setblock 72 57 -269 minecraft:air
setblock 72 57 -270 minecraft:air
fill 72 57 -271 73 57 -271 minecraft:air
fill 72 57 -272 73 57 -272 minecraft:air
fill 72 57 -273 74 57 -273 minecraft:air
setblock 135 57 -273 minecraft:water[level=0]
fill 72 57 -274 74 57 -274 minecraft:air
setblock 135 57 -274 minecraft:water[level=0]
fill 72 57 -275 74 57 -275 minecraft:air
fill 134 57 -275 135 57 -275 minecraft:water[level=0]
fill 72 57 -276 75 57 -276 minecraft:air
fill 134 57 -276 135 57 -276 minecraft:water[level=0]
fill 72 57 -277 75 57 -277 minecraft:air
fill 133 57 -277 135 57 -277 minecraft:water[level=0]
fill 72 57 -278 75 57 -278 minecraft:air
fill 132 57 -278 135 57 -278 minecraft:water[level=0]
fill 72 57 -279 75 57 -279 minecraft:air
fill 131 57 -279 135 57 -279 minecraft:water[level=0]
fill 72 57 -280 75 57 -280 minecraft:air
setblock 112 57 -280 minecraft:water[level=0]
fill 131 57 -280 135 57 -280 minecraft:water[level=0]
fill 72 57 -281 75 57 -281 minecraft:air
setblock 112 57 -281 minecraft:water[level=0]
setblock 113 57 -281 minecraft:tall_seagrass[half=lower]
setblock 114 57 -281 minecraft:water[level=0]
fill 130 57 -281 135 57 -281 minecraft:water[level=0]
fill 72 57 -282 75 57 -282 minecraft:air
setblock 111 57 -282 minecraft:tall_seagrass[half=lower]
setblock 112 57 -282 minecraft:tall_seagrass[half=upper]
fill 113 57 -282 115 57 -282 minecraft:water[level=0]
setblock 116 57 -282 minecraft:seagrass
fill 129 57 -282 135 57 -282 minecraft:water[level=0]
fill 72 57 -283 74 57 -283 minecraft:air
setblock 110 57 -283 minecraft:tall_seagrass[half=lower]
fill 111 57 -283 118 57 -283 minecraft:water[level=0]
fill 122 57 -283 125 57 -283 minecraft:water[level=0]
setblock 126 57 -283 minecraft:seagrass
fill 127 57 -283 135 57 -283 minecraft:water[level=0]
fill 72 57 -284 73 57 -284 minecraft:air
fill 72 57 -285 73 57 -285 minecraft:air
fill 108 57 -285 120 57 -285 minecraft:water[level=0]
setblock 121 57 -285 minecraft:seagrass
fill 122 57 -285 135 57 -285 minecraft:water[level=0]
setblock 72 57 -286 minecraft:air
fill 108 57 -286 109 57 -286 minecraft:water[level=0]
setblock 110 57 -286 minecraft:tall_seagrass[half=upper]
fill 111 57 -286 135 57 -286 minecraft:water[level=0]
setblock 72 57 -287 minecraft:air
fill 107 57 -287 108 57 -287 minecraft:water[level=0]
setblock 109 57 -287 minecraft:tall_seagrass[half=lower]
fill 110 57 -287 115 57 -287 minecraft:water[level=0]
fill 117 57 -287 135 57 -287 minecraft:water[level=0]
setblock 72 57 -288 minecraft:air
fill 106 57 -288 107 57 -288 minecraft:water[level=0]
setblock 108 57 -288 minecraft:tall_seagrass[half=upper]
fill 109 57 -288 112 57 -288 minecraft:water[level=0]
setblock 113 57 -288 minecraft:tall_seagrass[half=lower]
setblock 114 57 -288 minecraft:water[level=0]
setblock 118 57 -288 minecraft:water[level=0]
fill 120 57 -288 122 57 -288 minecraft:water[level=0]
fill 125 57 -288 126 57 -288 minecraft:water[level=0]
fill 128 57 -288 135 57 -288 minecraft:water[level=0]
fill 106 57 -289 108 57 -289 minecraft:water[level=0]
setblock 109 57 -289 minecraft:tall_seagrass[half=upper]
fill 110 57 -289 112 57 -289 minecraft:water[level=0]
fill 121 57 -289 135 57 -289 minecraft:water[level=0]
fill 106 57 -290 107 57 -290 minecraft:tall_seagrass[half=lower]
fill 108 57 -290 111 57 -290 minecraft:water[level=0]
fill 122 57 -290 135 57 -290 minecraft:water[level=0]
fill 72 57 -291 73 57 -291 minecraft:air
fill 106 57 -291 109 57 -291 minecraft:water[level=0]
setblock 110 57 -291 minecraft:tall_seagrass[half=lower]
fill 123 57 -291 134 57 -291 minecraft:water[level=0]
fill 72 57 -292 74 57 -292 minecraft:air
setblock 76 57 -292 minecraft:water[level=0]
setblock 106 57 -292 minecraft:seagrass
setblock 107 57 -292 minecraft:tall_seagrass[half=upper]
fill 108 57 -292 110 57 -292 minecraft:water[level=0]
fill 123 57 -292 133 57 -292 minecraft:water[level=0]
fill 72 57 -293 75 57 -293 minecraft:air
setblock 77 57 -293 minecraft:water[level=0]
setblock 106 57 -293 minecraft:seagrass
fill 107 57 -293 109 57 -293 minecraft:water[level=0]
setblock 110 57 -293 minecraft:seagrass
fill 123 57 -293 133 57 -293 minecraft:water[level=0]
fill 72 57 -294 75 57 -294 minecraft:air
fill 77 57 -294 79 57 -294 minecraft:water[level=0]
fill 106 57 -294 107 57 -294 minecraft:seagrass
fill 108 57 -294 109 57 -294 minecraft:water[level=0]
setblock 110 57 -294 minecraft:seagrass
fill 123 57 -294 132 57 -294 minecraft:water[level=0]
fill 72 57 -295 76 57 -295 minecraft:air
fill 78 57 -295 80 57 -295 minecraft:water[level=0]
fill 106 57 -295 108 57 -295 minecraft:water[level=0]
setblock 109 57 -295 minecraft:tall_seagrass[half=lower]
fill 123 57 -295 132 57 -295 minecraft:water[level=0]
fill 72 57 -296 76 57 -296 minecraft:air
fill 79 57 -296 83 57 -296 minecraft:water[level=0]
fill 107 57 -296 109 57 -296 minecraft:water[level=0]
fill 123 57 -296 126 57 -296 minecraft:water[level=0]
fill 128 57 -296 131 57 -296 minecraft:water[level=0]
fill 72 57 -297 76 57 -297 minecraft:air
fill 79 57 -297 80 57 -297 minecraft:water[level=0]
fill 106 57 -297 108 57 -297 minecraft:water[level=0]
setblock 109 57 -297 minecraft:seagrass
fill 123 57 -297 131 57 -297 minecraft:water[level=0]
fill 72 57 -298 76 57 -298 minecraft:air
fill 104 57 -298 106 57 -298 minecraft:water[level=0]
setblock 107 57 -298 minecraft:seagrass
setblock 108 57 -298 minecraft:water[level=0]
fill 124 57 -298 130 57 -298 minecraft:water[level=0]
fill 72 57 -299 75 57 -299 minecraft:air
fill 103 57 -299 108 57 -299 minecraft:water[level=0]
fill 124 57 -299 130 57 -299 minecraft:water[level=0]
fill 72 57 -300 73 57 -300 minecraft:air
fill 102 57 -300 108 57 -300 minecraft:water[level=0]
fill 124 57 -300 129 57 -300 minecraft:water[level=0]
fill 101 57 -301 107 57 -301 minecraft:water[level=0]
fill 125 57 -301 129 57 -301 minecraft:water[level=0]
fill 100 57 -302 107 57 -302 minecraft:water[level=0]
fill 125 57 -302 128 57 -302 minecraft:water[level=0]
fill 99 57 -303 107 57 -303 minecraft:water[level=0]
fill 127 57 -303 128 57 -303 minecraft:water[level=0]
fill 96 57 -304 107 57 -304 minecraft:water[level=0]
fill 96 57 -305 107 57 -305 minecraft:water[level=0]
fill 95 57 -306 106 57 -306 minecraft:water[level=0]
fill 95 57 -307 106 57 -307 minecraft:water[level=0]
fill 93 57 -308 106 57 -308 minecraft:water[level=0]
fill 93 57 -309 106 57 -309 minecraft:water[level=0]
fill 93 57 -310 106 57 -310 minecraft:water[level=0]
fill 93 57 -311 106 57 -311 minecraft:water[level=0]
fill 92 57 -312 106 57 -312 minecraft:water[level=0]
fill 94 57 -313 103 57 -313 minecraft:water[level=0]
setblock 104 57 -313 minecraft:seagrass
setblock 105 57 -313 minecraft:water[level=0]
fill 95 57 -314 105 57 -314 minecraft:water[level=0]
fill 96 57 -315 105 57 -315 minecraft:water[level=0]
fill 96 57 -316 105 57 -316 minecraft:water[level=0]
fill 96 57 -317 102 57 -317 minecraft:water[level=0]
setblock 103 57 -317 minecraft:tall_seagrass[half=upper]
fill 104 57 -317 105 57 -317 minecraft:water[level=0]
fill 96 57 -318 101 57 -318 minecraft:water[level=0]
setblock 102 57 -318 minecraft:tall_seagrass[half=upper]
fill 103 57 -318 105 57 -318 minecraft:water[level=0]
setblock 135 56 -256 minecraft:water[level=0]
setblock 72 56 -268 minecraft:air
setblock 72 56 -269 minecraft:air
setblock 72 56 -270 minecraft:air
fill 72 56 -271 73 56 -271 minecraft:air
fill 72 56 -272 73 56 -272 minecraft:air
fill 72 56 -273 74 56 -273 minecraft:air
fill 72 56 -274 74 56 -274 minecraft:air
setblock 135 56 -274 minecraft:water[level=0]
fill 72 56 -275 74 56 -275 minecraft:air
setblock 135 56 -275 minecraft:water[level=0]
setblock 72 56 -276 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 73 56 -276 75 56 -276 minecraft:air
fill 134 56 -276 135 56 -276 minecraft:water[level=0]
fill 72 56 -277 75 56 -277 minecraft:air
fill 134 56 -277 135 56 -277 minecraft:water[level=0]
fill 72 56 -278 75 56 -278 minecraft:air
fill 133 56 -278 135 56 -278 minecraft:water[level=0]
fill 72 56 -279 75 56 -279 minecraft:air
fill 132 56 -279 135 56 -279 minecraft:water[level=0]
fill 72 56 -280 75 56 -280 minecraft:air
fill 131 56 -280 135 56 -280 minecraft:water[level=0]
fill 72 56 -281 75 56 -281 minecraft:air
fill 131 56 -281 135 56 -281 minecraft:water[level=0]
fill 72 56 -282 74 56 -282 minecraft:air
setblock 112 56 -282 minecraft:tall_seagrass[half=lower]
setblock 113 56 -282 minecraft:water[level=0]
fill 130 56 -282 135 56 -282 minecraft:water[level=0]
fill 72 56 -283 74 56 -283 minecraft:air
fill 111 56 -283 114 56 -283 minecraft:water[level=0]
fill 129 56 -283 135 56 -283 minecraft:water[level=0]
fill 72 56 -284 73 56 -284 minecraft:air
fill 72 56 -285 73 56 -285 minecraft:air
fill 110 56 -285 111 56 -285 minecraft:seagrass
fill 112 56 -285 115 56 -285 minecraft:water[level=0]
fill 123 56 -285 135 56 -285 minecraft:water[level=0]
setblock 72 56 -286 minecraft:air
setblock 110 56 -286 minecraft:tall_seagrass[half=lower]
fill 111 56 -286 113 56 -286 minecraft:water[level=0]
fill 125 56 -286 135 56 -286 minecraft:water[level=0]
setblock 72 56 -287 minecraft:air
fill 110 56 -287 112 56 -287 minecraft:water[level=0]
fill 125 56 -287 135 56 -287 minecraft:water[level=0]
setblock 108 56 -288 minecraft:tall_seagrass[half=lower]
setblock 109 56 -288 minecraft:seagrass
setblock 126 56 -288 minecraft:water[level=0]
fill 128 56 -288 135 56 -288 minecraft:water[level=0]
setblock 108 56 -289 minecraft:water[level=0]
setblock 109 56 -289 minecraft:tall_seagrass[half=lower]
fill 125 56 -289 135 56 -289 minecraft:water[level=0]
setblock 72 56 -290 minecraft:air
setblock 108 56 -290 minecraft:seagrass
setblock 109 56 -290 minecraft:water[level=0]
fill 125 56 -290 135 56 -290 minecraft:water[level=0]
fill 72 56 -291 73 56 -291 minecraft:air
setblock 76 56 -291 minecraft:water[level=0]
fill 107 56 -291 109 56 -291 minecraft:water[level=0]
fill 124 56 -291 134 56 -291 minecraft:water[level=0]
fill 72 56 -292 73 56 -292 minecraft:air
fill 76 56 -292 77 56 -292 minecraft:water[level=0]
setblock 107 56 -292 minecraft:tall_seagrass[half=lower]
setblock 108 56 -292 minecraft:water[level=0]
setblock 109 56 -292 minecraft:seagrass
fill 124 56 -292 133 56 -292 minecraft:water[level=0]
fill 72 56 -293 74 56 -293 minecraft:air
fill 77 56 -293 78 56 -293 minecraft:water[level=0]
setblock 107 56 -293 minecraft:water[level=0]
setblock 108 56 -293 minecraft:seagrass
fill 124 56 -293 133 56 -293 minecraft:water[level=0]
fill 72 56 -294 75 56 -294 minecraft:air
fill 77 56 -294 80 56 -294 minecraft:water[level=0]
setblock 108 56 -294 minecraft:seagrass
fill 124 56 -294 132 56 -294 minecraft:water[level=0]
fill 72 56 -295 75 56 -295 minecraft:air
fill 78 56 -295 82 56 -295 minecraft:water[level=0]
setblock 108 56 -295 minecraft:water[level=0]
fill 124 56 -295 132 56 -295 minecraft:water[level=0]
fill 72 56 -296 76 56 -296 minecraft:air
fill 78 56 -296 84 56 -296 minecraft:water[level=0]
setblock 108 56 -296 minecraft:water[level=0]
fill 124 56 -296 126 56 -296 minecraft:water[level=0]
fill 128 56 -296 131 56 -296 minecraft:water[level=0]
fill 72 56 -297 76 56 -297 minecraft:air
fill 79 56 -297 81 56 -297 minecraft:water[level=0]
fill 124 56 -297 130 56 -297 minecraft:water[level=0]
fill 72 56 -298 75 56 -298 minecraft:air
setblock 78 56 -298 minecraft:water[level=0]
fill 125 56 -298 130 56 -298 minecraft:water[level=0]
fill 72 56 -299 73 56 -299 minecraft:air
setblock 104 56 -299 minecraft:water[level=0]
fill 125 56 -299 130 56 -299 minecraft:water[level=0]
setblock 72 56 -300 minecraft:air
fill 103 56 -300 105 56 -300 minecraft:water[level=0]
fill 125 56 -300 129 56 -300 minecraft:water[level=0]
fill 103 56 -301 105 56 -301 minecraft:water[level=0]
fill 126 56 -301 129 56 -301 minecraft:water[level=0]
fill 102 56 -302 105 56 -302 minecraft:water[level=0]
fill 127 56 -302 128 56 -302 minecraft:water[level=0]
fill 101 56 -303 105 56 -303 minecraft:water[level=0]
fill 99 56 -304 105 56 -304 minecraft:water[level=0]
fill 97 56 -305 105 56 -305 minecraft:water[level=0]
fill 96 56 -306 104 56 -306 minecraft:water[level=0]
fill 96 56 -307 103 56 -307 minecraft:water[level=0]
fill 95 56 -308 102 56 -308 minecraft:water[level=0]
fill 94 56 -309 102 56 -309 minecraft:water[level=0]
fill 94 56 -310 103 56 -310 minecraft:water[level=0]
fill 94 56 -311 103 56 -311 minecraft:water[level=0]
fill 94 56 -312 103 56 -312 minecraft:water[level=0]
fill 95 56 -313 103 56 -313 minecraft:water[level=0]
fill 96 56 -314 100 56 -314 minecraft:water[level=0]
setblock 101 56 -314 minecraft:seagrass
fill 102 56 -314 104 56 -314 minecraft:water[level=0]
fill 96 56 -315 104 56 -315 minecraft:water[level=0]
fill 97 56 -316 102 56 -316 minecraft:water[level=0]
setblock 103 56 -316 minecraft:seagrass
setblock 104 56 -316 minecraft:water[level=0]
fill 97 56 -317 100 56 -317 minecraft:water[level=0]
setblock 101 56 -317 minecraft:tall_seagrass[half=upper]
setblock 102 56 -317 minecraft:water[level=0]
setblock 103 56 -317 minecraft:tall_seagrass[half=lower]
setblock 104 56 -317 minecraft:seagrass
fill 97 56 -318 101 56 -318 minecraft:water[level=0]
setblock 102 56 -318 minecraft:tall_seagrass[half=lower]
setblock 103 56 -318 minecraft:seagrass
setblock 104 56 -318 minecraft:water[level=0]
setblock 72 55 -268 minecraft:air
setblock 72 55 -269 minecraft:air
fill 72 55 -270 73 55 -270 minecraft:air
fill 72 55 -271 73 55 -271 minecraft:air
fill 72 55 -272 74 55 -272 minecraft:air
fill 72 55 -273 74 55 -273 minecraft:air
fill 72 55 -274 74 55 -274 minecraft:air
fill 72 55 -275 75 55 -275 minecraft:air
setblock 135 55 -275 minecraft:water[level=0]
setblock 72 55 -276 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 73 55 -276 75 55 -276 minecraft:air
setblock 135 55 -276 minecraft:water[level=0]
fill 72 55 -277 75 55 -277 minecraft:air
fill 134 55 -277 135 55 -277 minecraft:water[level=0]
fill 72 55 -278 75 55 -278 minecraft:air
fill 133 55 -278 135 55 -278 minecraft:water[level=0]
fill 72 55 -279 75 55 -279 minecraft:air
fill 132 55 -279 135 55 -279 minecraft:water[level=0]
fill 73 55 -280 75 55 -280 minecraft:air
fill 132 55 -280 135 55 -280 minecraft:water[level=0]
fill 72 55 -281 75 55 -281 minecraft:air
fill 131 55 -281 135 55 -281 minecraft:water[level=0]
fill 72 55 -282 75 55 -282 minecraft:air
fill 130 55 -282 135 55 -282 minecraft:water[level=0]
fill 72 55 -283 74 55 -283 minecraft:air
fill 129 55 -283 135 55 -283 minecraft:water[level=0]
fill 72 55 -284 74 55 -284 minecraft:air
fill 125 55 -285 135 55 -285 minecraft:water[level=0]
fill 126 55 -286 135 55 -286 minecraft:water[level=0]
setblock 72 55 -287 minecraft:water[level=0]
fill 126 55 -287 135 55 -287 minecraft:water[level=0]
setblock 126 55 -288 minecraft:water[level=0]
fill 128 55 -288 135 55 -288 minecraft:water[level=0]
fill 126 55 -289 135 55 -289 minecraft:water[level=0]
setblock 72 55 -290 minecraft:water[level=0]
fill 125 55 -290 135 55 -290 minecraft:water[level=0]
fill 72 55 -291 73 55 -291 minecraft:water[level=0]
setblock 76 55 -291 minecraft:water[level=0]
fill 125 55 -291 134 55 -291 minecraft:water[level=0]
fill 72 55 -292 73 55 -292 minecraft:water[level=0]
fill 76 55 -292 77 55 -292 minecraft:water[level=0]
fill 124 55 -292 133 55 -292 minecraft:water[level=0]
fill 72 55 -293 74 55 -293 minecraft:water[level=0]
fill 76 55 -293 78 55 -293 minecraft:water[level=0]
fill 124 55 -293 133 55 -293 minecraft:water[level=0]
fill 72 55 -294 75 55 -294 minecraft:water[level=0]
fill 77 55 -294 80 55 -294 minecraft:water[level=0]
fill 125 55 -294 132 55 -294 minecraft:water[level=0]
fill 72 55 -295 75 55 -295 minecraft:water[level=0]
fill 77 55 -295 81 55 -295 minecraft:water[level=0]
fill 125 55 -295 132 55 -295 minecraft:water[level=0]
fill 72 55 -296 75 55 -296 minecraft:water[level=0]
fill 78 55 -296 83 55 -296 minecraft:water[level=0]
fill 125 55 -296 126 55 -296 minecraft:water[level=0]
fill 128 55 -296 131 55 -296 minecraft:water[level=0]
fill 72 55 -297 73 55 -297 minecraft:water[level=0]
fill 78 55 -297 81 55 -297 minecraft:water[level=0]
fill 125 55 -297 130 55 -297 minecraft:water[level=0]
setblock 72 55 -298 minecraft:water[level=0]
setblock 78 55 -298 minecraft:water[level=0]
fill 125 55 -298 130 55 -298 minecraft:water[level=0]
fill 126 55 -299 129 55 -299 minecraft:water[level=0]
fill 126 55 -300 129 55 -300 minecraft:water[level=0]
fill 127 55 -301 128 55 -301 minecraft:water[level=0]
setblock 128 55 -302 minecraft:water[level=0]
setblock 100 55 -314 minecraft:water[level=0]
setblock 100 55 -315 minecraft:water[level=0]
fill 100 55 -316 101 55 -316 minecraft:water[level=0]
fill 99 55 -317 100 55 -317 minecraft:water[level=0]
setblock 101 55 -317 minecraft:tall_seagrass[half=lower]
fill 99 55 -318 100 55 -318 minecraft:water[level=0]
setblock 101 55 -318 minecraft:seagrass
setblock 72 54 -267 minecraft:air
setblock 72 54 -268 minecraft:air
fill 72 54 -269 73 54 -269 minecraft:air
fill 72 54 -270 73 54 -270 minecraft:air
fill 72 54 -271 73 54 -271 minecraft:air
fill 72 54 -272 74 54 -272 minecraft:air
fill 72 54 -273 74 54 -273 minecraft:air
fill 72 54 -274 74 54 -274 minecraft:air
fill 72 54 -275 75 54 -275 minecraft:air
setblock 135 54 -275 minecraft:water[level=0]
fill 73 54 -276 75 54 -276 minecraft:air
setblock 135 54 -276 minecraft:water[level=0]
fill 73 54 -277 75 54 -277 minecraft:air
fill 134 54 -277 135 54 -277 minecraft:water[level=0]
fill 73 54 -278 75 54 -278 minecraft:air
fill 133 54 -278 135 54 -278 minecraft:water[level=0]
fill 73 54 -279 75 54 -279 minecraft:air
fill 133 54 -279 135 54 -279 minecraft:water[level=0]
fill 73 54 -280 75 54 -280 minecraft:air
fill 132 54 -280 135 54 -280 minecraft:water[level=0]
fill 73 54 -281 75 54 -281 minecraft:air
fill 131 54 -281 135 54 -281 minecraft:water[level=0]
fill 72 54 -282 75 54 -282 minecraft:air
fill 130 54 -282 135 54 -282 minecraft:water[level=0]
fill 72 54 -283 75 54 -283 minecraft:air
fill 129 54 -283 135 54 -283 minecraft:water[level=0]
fill 73 54 -284 74 54 -284 minecraft:air
fill 127 54 -285 135 54 -285 minecraft:water[level=0]
fill 127 54 -286 135 54 -286 minecraft:water[level=0]
setblock 72 54 -287 minecraft:water[level=0]
fill 126 54 -287 135 54 -287 minecraft:water[level=0]
setblock 126 54 -288 minecraft:water[level=0]
fill 128 54 -288 135 54 -288 minecraft:water[level=0]
fill 126 54 -289 135 54 -289 minecraft:water[level=0]
fill 72 54 -290 73 54 -290 minecraft:water[level=0]
fill 126 54 -290 135 54 -290 minecraft:water[level=0]
fill 72 54 -291 73 54 -291 minecraft:water[level=0]
setblock 76 54 -291 minecraft:water[level=0]
fill 126 54 -291 134 54 -291 minecraft:water[level=0]
fill 72 54 -292 73 54 -292 minecraft:water[level=0]
fill 76 54 -292 77 54 -292 minecraft:water[level=0]
fill 126 54 -292 133 54 -292 minecraft:water[level=0]
fill 72 54 -293 73 54 -293 minecraft:water[level=0]
fill 76 54 -293 78 54 -293 minecraft:water[level=0]
fill 126 54 -293 132 54 -293 minecraft:water[level=0]
fill 72 54 -294 74 54 -294 minecraft:water[level=0]
fill 77 54 -294 79 54 -294 minecraft:water[level=0]
fill 125 54 -294 132 54 -294 minecraft:water[level=0]
fill 72 54 -295 74 54 -295 minecraft:water[level=0]
fill 77 54 -295 81 54 -295 minecraft:water[level=0]
fill 125 54 -295 131 54 -295 minecraft:water[level=0]
setblock 72 54 -296 minecraft:water[level=0]
fill 77 54 -296 83 54 -296 minecraft:water[level=0]
fill 125 54 -296 126 54 -296 minecraft:water[level=0]
fill 128 54 -296 131 54 -296 minecraft:water[level=0]
fill 78 54 -297 80 54 -297 minecraft:water[level=0]
fill 126 54 -297 130 54 -297 minecraft:water[level=0]
fill 76 54 -298 77 54 -298 minecraft:water[level=0]
fill 126 54 -298 129 54 -298 minecraft:water[level=0]
setblock 75 54 -299 minecraft:water[level=0]
fill 126 54 -299 129 54 -299 minecraft:water[level=0]
fill 127 54 -300 129 54 -300 minecraft:water[level=0]
setblock 128 54 -301 minecraft:water[level=0]
setblock 72 53 -267 minecraft:air
setblock 72 53 -268 minecraft:air
fill 72 53 -269 73 53 -269 minecraft:air
fill 72 53 -270 73 53 -270 minecraft:air
fill 72 53 -271 74 53 -271 minecraft:air
fill 72 53 -272 74 53 -272 minecraft:air
fill 72 53 -273 74 53 -273 minecraft:air
fill 72 53 -274 75 53 -274 minecraft:air
fill 72 53 -275 75 53 -275 minecraft:air
fill 73 53 -276 75 53 -276 minecraft:air
setblock 135 53 -276 minecraft:water[level=0]
fill 73 53 -277 75 53 -277 minecraft:air
setblock 135 53 -277 minecraft:water[level=0]
fill 73 53 -278 75 53 -278 minecraft:air
fill 134 53 -278 135 53 -278 minecraft:water[level=0]
fill 73 53 -279 75 53 -279 minecraft:air
fill 133 53 -279 135 53 -279 minecraft:water[level=0]
fill 73 53 -280 76 53 -280 minecraft:air
fill 132 53 -280 135 53 -280 minecraft:water[level=0]
fill 73 53 -281 75 53 -281 minecraft:air
fill 131 53 -281 135 53 -281 minecraft:water[level=0]
fill 73 53 -282 75 53 -282 minecraft:air
fill 131 53 -282 135 53 -282 minecraft:water[level=0]
fill 73 53 -283 75 53 -283 minecraft:air
fill 130 53 -283 135 53 -283 minecraft:water[level=0]
setblock 74 53 -284 minecraft:air
fill 128 53 -285 135 53 -285 minecraft:water[level=0]
setblock 72 53 -286 minecraft:water[level=0]
fill 127 53 -286 135 53 -286 minecraft:water[level=0]
setblock 72 53 -287 minecraft:water[level=0]
fill 127 53 -287 135 53 -287 minecraft:water[level=0]
fill 128 53 -288 135 53 -288 minecraft:water[level=0]
fill 127 53 -289 135 53 -289 minecraft:water[level=0]
fill 72 53 -290 73 53 -290 minecraft:water[level=0]
fill 127 53 -290 135 53 -290 minecraft:water[level=0]
fill 72 53 -291 73 53 -291 minecraft:water[level=0]
setblock 76 53 -291 minecraft:water[level=0]
fill 127 53 -291 134 53 -291 minecraft:water[level=0]
fill 72 53 -292 73 53 -292 minecraft:water[level=0]
fill 76 53 -292 77 53 -292 minecraft:water[level=0]
fill 126 53 -292 133 53 -292 minecraft:water[level=0]
fill 72 53 -293 73 53 -293 minecraft:water[level=0]
fill 76 53 -293 78 53 -293 minecraft:water[level=0]
fill 126 53 -293 132 53 -293 minecraft:water[level=0]
fill 75 53 -294 79 53 -294 minecraft:water[level=0]
fill 126 53 -294 132 53 -294 minecraft:water[level=0]
fill 74 53 -295 80 53 -295 minecraft:water[level=0]
fill 126 53 -295 131 53 -295 minecraft:water[level=0]
fill 75 53 -296 82 53 -296 minecraft:water[level=0]
setblock 126 53 -296 minecraft:water[level=0]
fill 128 53 -296 130 53 -296 minecraft:water[level=0]
fill 75 53 -297 79 53 -297 minecraft:water[level=0]
fill 126 53 -297 129 53 -297 minecraft:water[level=0]
fill 73 53 -298 76 53 -298 minecraft:water[level=0]
fill 127 53 -298 129 53 -298 minecraft:water[level=0]
fill 72 53 -299 74 53 -299 minecraft:water[level=0]
fill 127 53 -299 128 53 -299 minecraft:water[level=0]
setblock 128 53 -300 minecraft:water[level=0]
setblock 72 52 -269 minecraft:air
fill 72 52 -270 73 52 -270 minecraft:air
fill 72 52 -271 73 52 -271 minecraft:air
fill 72 52 -272 74 52 -272 minecraft:air
fill 72 52 -273 74 52 -273 minecraft:air
fill 72 52 -274 75 52 -274 minecraft:air
fill 73 52 -275 75 52 -275 minecraft:air
fill 73 52 -276 75 52 -276 minecraft:air
setblock 135 52 -276 minecraft:water[level=0]
fill 73 52 -277 75 52 -277 minecraft:air
setblock 135 52 -277 minecraft:water[level=0]
fill 73 52 -278 75 52 -278 minecraft:air
fill 134 52 -278 135 52 -278 minecraft:water[level=0]
fill 73 52 -279 75 52 -279 minecraft:air
fill 133 52 -279 135 52 -279 minecraft:water[level=0]
fill 73 52 -280 76 52 -280 minecraft:air
fill 132 52 -280 135 52 -280 minecraft:water[level=0]
fill 73 52 -281 75 52 -281 minecraft:air
fill 132 52 -281 135 52 -281 minecraft:water[level=0]
fill 73 52 -282 75 52 -282 minecraft:air
fill 131 52 -282 135 52 -282 minecraft:water[level=0]
setblock 74 52 -283 minecraft:air
fill 130 52 -283 135 52 -283 minecraft:water[level=0]
setblock 72 52 -285 minecraft:water[level=0]
fill 128 52 -285 135 52 -285 minecraft:water[level=0]
fill 72 52 -286 73 52 -286 minecraft:water[level=0]
fill 128 52 -286 135 52 -286 minecraft:water[level=0]
fill 72 52 -287 73 52 -287 minecraft:water[level=0]
fill 127 52 -287 135 52 -287 minecraft:water[level=0]
setblock 72 52 -288 minecraft:water[level=0]
fill 128 52 -288 135 52 -288 minecraft:water[level=0]
setblock 72 52 -289 minecraft:water[level=0]
fill 127 52 -289 135 52 -289 minecraft:water[level=0]
fill 72 52 -290 73 52 -290 minecraft:water[level=0]
fill 127 52 -290 135 52 -290 minecraft:water[level=0]
fill 72 52 -291 73 52 -291 minecraft:water[level=0]
fill 127 52 -291 134 52 -291 minecraft:water[level=0]
fill 72 52 -292 73 52 -292 minecraft:water[level=0]
fill 127 52 -292 133 52 -292 minecraft:water[level=0]
setblock 72 52 -293 minecraft:water[level=0]
setblock 74 52 -293 minecraft:water[level=0]
setblock 78 52 -293 minecraft:water[level=0]
fill 127 52 -293 132 52 -293 minecraft:water[level=0]
fill 72 52 -294 75 52 -294 minecraft:water[level=0]
fill 78 52 -294 79 52 -294 minecraft:water[level=0]
fill 127 52 -294 131 52 -294 minecraft:water[level=0]
fill 72 52 -295 75 52 -295 minecraft:water[level=0]
setblock 80 52 -295 minecraft:water[level=0]
fill 127 52 -295 130 52 -295 minecraft:water[level=0]
fill 72 52 -296 81 52 -296 minecraft:water[level=0]
fill 128 52 -296 129 52 -296 minecraft:water[level=0]
fill 72 52 -297 78 52 -297 minecraft:water[level=0]
setblock 128 52 -297 minecraft:water[level=0]
fill 72 52 -298 75 52 -298 minecraft:water[level=0]
setblock 128 52 -298 minecraft:water[level=0]
setblock 72 52 -299 minecraft:water[level=0]
setblock 128 52 -299 minecraft:water[level=0]
setblock 72 51 -270 minecraft:air
fill 72 51 -271 73 51 -271 minecraft:air
fill 72 51 -272 74 51 -272 minecraft:air
fill 73 51 -273 74 51 -273 minecraft:air
fill 73 51 -274 74 51 -274 minecraft:air
setblock 75 51 -274 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
fill 73 51 -275 75 51 -275 minecraft:air
fill 73 51 -276 75 51 -276 minecraft:air
fill 73 51 -277 75 51 -277 minecraft:air
setblock 135 51 -277 minecraft:water[level=0]
fill 73 51 -278 75 51 -278 minecraft:air
setblock 135 51 -278 minecraft:water[level=0]
fill 73 51 -279 76 51 -279 minecraft:air
fill 134 51 -279 135 51 -279 minecraft:water[level=0]
fill 73 51 -280 76 51 -280 minecraft:air
fill 132 51 -280 135 51 -280 minecraft:water[level=0]
fill 73 51 -281 75 51 -281 minecraft:air
fill 132 51 -281 135 51 -281 minecraft:water[level=0]
fill 75 51 -282 76 51 -282 minecraft:air
fill 131 51 -282 135 51 -282 minecraft:water[level=0]
fill 130 51 -283 135 51 -283 minecraft:water[level=0]
setblock 75 51 -284 minecraft:air
fill 129 51 -284 135 51 -284 minecraft:water[level=0]
setblock 72 51 -285 minecraft:water[level=0]
setblock 75 51 -285 minecraft:air
fill 129 51 -285 135 51 -285 minecraft:water[level=0]
setblock 72 51 -286 minecraft:water[level=0]
fill 128 51 -286 135 51 -286 minecraft:water[level=0]
setblock 72 51 -287 minecraft:water[level=0]
fill 128 51 -287 135 51 -287 minecraft:water[level=0]
setblock 72 51 -288 minecraft:water[level=0]
fill 128 51 -288 135 51 -288 minecraft:water[level=0]
fill 72 51 -289 73 51 -289 minecraft:water[level=0]
fill 128 51 -289 135 51 -289 minecraft:water[level=0]
fill 72 51 -290 73 51 -290 minecraft:water[level=0]
fill 128 51 -290 134 51 -290 minecraft:water[level=0]
fill 72 51 -291 73 51 -291 minecraft:water[level=0]
fill 128 51 -291 133 51 -291 minecraft:water[level=0]
fill 72 51 -292 73 51 -292 minecraft:water[level=0]
fill 128 51 -292 132 51 -292 minecraft:water[level=0]
setblock 72 51 -293 minecraft:water[level=0]
fill 128 51 -293 132 51 -293 minecraft:water[level=0]
fill 72 51 -294 74 51 -294 minecraft:water[level=0]
fill 128 51 -294 130 51 -294 minecraft:water[level=0]
fill 72 51 -295 76 51 -295 minecraft:water[level=0]
setblock 128 51 -295 minecraft:water[level=0]
fill 72 51 -296 78 51 -296 minecraft:water[level=0]
fill 72 51 -297 77 51 -297 minecraft:water[level=0]
fill 72 51 -298 73 51 -298 minecraft:water[level=0]
setblock 72 50 -271 minecraft:air
setblock 73 50 -272 minecraft:air
fill 73 50 -273 74 50 -273 minecraft:air
fill 73 50 -274 74 50 -274 minecraft:air
setblock 75 50 -274 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
fill 73 50 -275 75 50 -275 minecraft:air
fill 73 50 -276 75 50 -276 minecraft:air
fill 73 50 -277 76 50 -277 minecraft:air
fill 73 50 -278 76 50 -278 minecraft:air
setblock 135 50 -278 minecraft:water[level=0]
fill 73 50 -279 76 50 -279 minecraft:air
fill 134 50 -279 135 50 -279 minecraft:water[level=0]
fill 73 50 -280 76 50 -280 minecraft:air
fill 133 50 -280 135 50 -280 minecraft:water[level=0]
fill 74 50 -281 76 50 -281 minecraft:air
fill 132 50 -281 135 50 -281 minecraft:water[level=0]
fill 75 50 -282 76 50 -282 minecraft:air
fill 131 50 -282 135 50 -282 minecraft:water[level=0]
fill 74 50 -283 76 50 -283 minecraft:air
fill 130 50 -283 135 50 -283 minecraft:water[level=0]
fill 74 50 -284 75 50 -284 minecraft:air
fill 129 50 -284 135 50 -284 minecraft:water[level=0]
setblock 72 50 -285 minecraft:water[level=0]
fill 74 50 -285 75 50 -285 minecraft:air
fill 129 50 -285 135 50 -285 minecraft:water[level=0]
setblock 72 50 -286 minecraft:water[level=0]
fill 74 50 -286 75 50 -286 minecraft:air
fill 128 50 -286 135 50 -286 minecraft:water[level=0]
setblock 72 50 -287 minecraft:water[level=0]
setblock 74 50 -287 minecraft:air
fill 128 50 -287 135 50 -287 minecraft:water[level=0]
setblock 72 50 -288 minecraft:glow_lichen[down=true,east=false,north=false,south=false,up=false,waterlogged=true,west=false]
fill 74 50 -288 76 50 -288 minecraft:air
fill 128 50 -288 135 50 -288 minecraft:water[level=0]
setblock 72 50 -289 minecraft:water[level=0]
fill 74 50 -289 76 50 -289 minecraft:air
fill 128 50 -289 135 50 -289 minecraft:water[level=0]
setblock 72 50 -290 minecraft:water[level=0]
setblock 75 50 -290 minecraft:air
fill 128 50 -290 134 50 -290 minecraft:water[level=0]
setblock 72 50 -291 minecraft:water[level=0]
setblock 75 50 -291 minecraft:air
fill 128 50 -291 133 50 -291 minecraft:water[level=0]
setblock 72 50 -292 minecraft:water[level=0]
fill 128 50 -292 132 50 -292 minecraft:water[level=0]
setblock 72 50 -293 minecraft:water[level=0]
setblock 75 50 -293 minecraft:air
fill 72 50 -294 74 50 -294 minecraft:water[level=0]
fill 72 50 -295 75 50 -295 minecraft:water[level=0]
fill 72 50 -296 77 50 -296 minecraft:water[level=0]
fill 72 50 -297 74 50 -297 minecraft:water[level=0]
setblock 73 49 -272 minecraft:air
fill 73 49 -273 74 49 -273 minecraft:air
fill 73 49 -274 75 49 -274 minecraft:air
fill 73 49 -275 75 49 -275 minecraft:air
fill 73 49 -276 76 49 -276 minecraft:air
fill 73 49 -277 76 49 -277 minecraft:air
fill 73 49 -278 76 49 -278 minecraft:air
fill 73 49 -279 76 49 -279 minecraft:air
setblock 135 49 -279 minecraft:water[level=0]
fill 73 49 -280 76 49 -280 minecraft:air
fill 133 49 -280 135 49 -280 minecraft:water[level=0]
fill 73 49 -281 76 49 -281 minecraft:air
fill 132 49 -281 135 49 -281 minecraft:water[level=0]
fill 74 49 -282 76 49 -282 minecraft:air
fill 132 49 -282 135 49 -282 minecraft:water[level=0]
fill 74 49 -283 76 49 -283 minecraft:air
fill 131 49 -283 135 49 -283 minecraft:water[level=0]
fill 74 49 -284 75 49 -284 minecraft:air
fill 129 49 -284 135 49 -284 minecraft:water[level=0]
fill 74 49 -285 75 49 -285 minecraft:air
fill 129 49 -285 135 49 -285 minecraft:water[level=0]
fill 74 49 -286 76 49 -286 minecraft:air
fill 129 49 -286 135 49 -286 minecraft:water[level=0]
fill 74 49 -287 77 49 -287 minecraft:air
fill 129 49 -287 135 49 -287 minecraft:water[level=0]
fill 74 49 -288 79 49 -288 minecraft:air
fill 128 49 -288 135 49 -288 minecraft:water[level=0]
fill 74 49 -289 79 49 -289 minecraft:air
fill 129 49 -289 135 49 -289 minecraft:water[level=0]
fill 74 49 -290 77 49 -290 minecraft:air
fill 130 49 -290 134 49 -290 minecraft:water[level=0]
setblock 72 49 -291 minecraft:water[level=0]
setblock 74 49 -291 minecraft:air
setblock 132 49 -291 minecraft:water[level=0]
setblock 72 49 -292 minecraft:water[level=0]
setblock 72 49 -293 minecraft:water[level=0]
fill 72 49 -294 73 49 -294 minecraft:water[level=0]
setblock 72 49 -295 minecraft:water[level=0]
fill 73 48 -273 74 48 -273 minecraft:air
fill 73 48 -274 75 48 -274 minecraft:air
fill 73 48 -275 75 48 -275 minecraft:air
fill 74 48 -276 76 48 -276 minecraft:air
fill 74 48 -277 76 48 -277 minecraft:air
fill 74 48 -278 76 48 -278 minecraft:air
fill 74 48 -279 76 48 -279 minecraft:air
fill 74 48 -280 76 48 -280 minecraft:air
setblock 135 48 -280 minecraft:water[level=0]
fill 73 48 -281 76 48 -281 minecraft:air
fill 133 48 -281 135 48 -281 minecraft:water[level=0]
fill 73 48 -282 76 48 -282 minecraft:air
fill 132 48 -282 135 48 -282 minecraft:water[level=0]
fill 73 48 -283 76 48 -283 minecraft:air
fill 131 48 -283 135 48 -283 minecraft:water[level=0]
fill 74 48 -284 77 48 -284 minecraft:air
fill 130 48 -284 135 48 -284 minecraft:water[level=0]
fill 74 48 -285 79 48 -285 minecraft:air
fill 130 48 -285 135 48 -285 minecraft:water[level=0]
fill 73 48 -286 82 48 -286 minecraft:air
fill 130 48 -286 135 48 -286 minecraft:water[level=0]
fill 73 48 -287 83 48 -287 minecraft:air
fill 131 48 -287 135 48 -287 minecraft:water[level=0]
fill 73 48 -288 83 48 -288 minecraft:air
fill 133 48 -288 135 48 -288 minecraft:water[level=0]
fill 73 48 -289 83 48 -289 minecraft:air
fill 73 48 -290 82 48 -290 minecraft:air
fill 73 48 -291 74 48 -291 minecraft:air
fill 79 48 -291 81 48 -291 minecraft:air
setblock 73 48 -292 minecraft:air
setblock 72 48 -294 minecraft:water[level=0]
fill 74 47 -274 75 47 -274 minecraft:air
fill 74 47 -275 76 47 -275 minecraft:air
fill 74 47 -276 76 47 -276 minecraft:air
fill 74 47 -277 76 47 -277 minecraft:air
fill 74 47 -278 76 47 -278 minecraft:air
fill 74 47 -279 76 47 -279 minecraft:air
fill 74 47 -280 76 47 -280 minecraft:air
setblock 135 47 -280 minecraft:water[level=0]
fill 74 47 -281 76 47 -281 minecraft:air
fill 134 47 -281 135 47 -281 minecraft:water[level=0]
fill 74 47 -282 76 47 -282 minecraft:air
fill 132 47 -282 135 47 -282 minecraft:water[level=0]
fill 74 47 -283 76 47 -283 minecraft:air
fill 131 47 -283 135 47 -283 minecraft:water[level=0]
fill 73 47 -284 78 47 -284 minecraft:air
fill 130 47 -284 135 47 -284 minecraft:water[level=0]
fill 72 47 -285 79 47 -285 minecraft:air
fill 130 47 -285 135 47 -285 minecraft:water[level=0]
fill 73 47 -286 80 47 -286 minecraft:air
fill 131 47 -286 135 47 -286 minecraft:water[level=0]
fill 73 47 -287 82 47 -287 minecraft:air
fill 132 47 -287 135 47 -287 minecraft:water[level=0]
fill 73 47 -288 83 47 -288 minecraft:air
fill 73 47 -289 82 47 -289 minecraft:air
fill 73 47 -290 80 47 -290 minecraft:air
setblock 73 47 -291 minecraft:air
fill 72 47 -294 73 47 -294 minecraft:water[level=0]
setblock 72 47 -295 minecraft:water[level=0]
setblock 72 47 -296 minecraft:water[level=0]
fill 74 46 -275 76 46 -275 minecraft:air
fill 74 46 -276 76 46 -276 minecraft:air
fill 74 46 -277 76 46 -277 minecraft:air
fill 74 46 -278 76 46 -278 minecraft:air
fill 74 46 -279 76 46 -279 minecraft:air
fill 74 46 -280 76 46 -280 minecraft:air
setblock 135 46 -280 minecraft:water[level=0]
fill 74 46 -281 76 46 -281 minecraft:air
setblock 135 46 -281 minecraft:water[level=0]
fill 74 46 -282 76 46 -282 minecraft:air
fill 132 46 -282 135 46 -282 minecraft:water[level=0]
fill 74 46 -283 76 46 -283 minecraft:air
fill 132 46 -283 135 46 -283 minecraft:water[level=0]
fill 73 46 -284 78 46 -284 minecraft:air
fill 130 46 -284 135 46 -284 minecraft:water[level=0]
fill 72 46 -285 79 46 -285 minecraft:air
fill 131 46 -285 135 46 -285 minecraft:water[level=0]
fill 72 46 -286 80 46 -286 minecraft:air
fill 132 46 -286 135 46 -286 minecraft:water[level=0]
fill 72 46 -287 81 46 -287 minecraft:air
fill 72 46 -288 82 46 -288 minecraft:air
fill 72 46 -289 80 46 -289 minecraft:air
fill 72 46 -290 74 46 -290 minecraft:air
setblock 72 46 -294 minecraft:water[level=0]
fill 72 46 -295 73 46 -295 minecraft:water[level=0]
fill 72 46 -296 73 46 -296 minecraft:water[level=0]
setblock 72 46 -297 minecraft:water[level=0]
setblock 72 46 -298 minecraft:water[level=0]
fill 74 45 -275 76 45 -275 minecraft:air
fill 74 45 -276 77 45 -276 minecraft:air
fill 74 45 -277 77 45 -277 minecraft:air
fill 74 45 -278 77 45 -278 minecraft:air
fill 74 45 -279 77 45 -279 minecraft:air
fill 74 45 -280 77 45 -280 minecraft:air
fill 74 45 -281 77 45 -281 minecraft:air
setblock 135 45 -281 minecraft:seagrass
fill 74 45 -282 77 45 -282 minecraft:air
fill 134 45 -282 135 45 -282 minecraft:water[level=0]
fill 74 45 -283 77 45 -283 minecraft:air
fill 132 45 -283 135 45 -283 minecraft:water[level=0]
fill 73 45 -284 79 45 -284 minecraft:air
fill 131 45 -284 135 45 -284 minecraft:water[level=0]
fill 72 45 -285 79 45 -285 minecraft:air
fill 132 45 -285 135 45 -285 minecraft:water[level=0]
fill 72 45 -286 80 45 -286 minecraft:air
fill 72 45 -287 80 45 -287 minecraft:air
fill 72 45 -288 81 45 -288 minecraft:air
fill 72 45 -289 79 45 -289 minecraft:air
setblock 76 45 -290 minecraft:air
setblock 72 45 -294 minecraft:water[level=0]
fill 72 45 -295 73 45 -295 minecraft:water[level=0]
fill 72 45 -296 74 45 -296 minecraft:water[level=0]
fill 72 45 -297 74 45 -297 minecraft:water[level=0]
fill 72 45 -298 74 45 -298 minecraft:water[level=0]
fill 72 45 -299 73 45 -299 minecraft:water[level=0]
fill 72 45 -300 73 45 -300 minecraft:water[level=0]
setblock 72 45 -301 minecraft:water[level=0]
setblock 95 45 -316 minecraft:water[level=0]
setblock 96 45 -316 minecraft:bubble_column[drag=true]
fill 95 45 -317 97 45 -317 minecraft:water[level=0]
fill 95 45 -318 96 45 -318 minecraft:water[level=0]
setblock 97 45 -318 minecraft:bubble_column[drag=true]
forceload remove 72 -318 135 -255
tellraw @a {"text":"Campus zurueck a16 fertig.","color":"green"}
