setblock 133 79 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 79 -116 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 133 79 -117 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 86 78 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 132 78 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 78 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 78 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 78 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 78 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 78 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 78 -119 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 78 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 78 -125 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 78 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 85 77 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 86 77 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 77 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 77 -116 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 132 77 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 77 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 134 77 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 77 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 132 77 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 77 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 77 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 77 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 94 77 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 77 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 77 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 77 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 77 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 77 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 77 -122 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 77 77 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 77 -124 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 77 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 77 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 77 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 77 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 77 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 76 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 76 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 87 76 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 76 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 76 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 76 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 133 76 -116 minecraft:birch_log[axis=y]
setblock 134 76 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 76 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 76 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 76 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 76 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 76 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 132 76 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 76 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 134 76 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 76 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 76 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 76 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 76 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 76 -118 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 133 76 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 76 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 76 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 76 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 76 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 76 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 76 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 76 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 76 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 76 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 76 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 76 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 76 -124 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 77 76 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 76 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 76 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 76 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 101 76 -124 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 73 76 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 76 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 76 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 76 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 76 -125 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 101 76 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 76 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 81 76 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 76 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 76 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 75 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 75 -116 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 124 75 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 75 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 75 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 75 -116 minecraft:birch_log[axis=y]
setblock 94 75 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 75 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 75 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 75 -117 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 109 75 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 86 75 -118 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 93 75 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 75 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 95 75 -118 minecraft:birch_log[axis=y]
setblock 96 75 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 97 75 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 75 -118 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 128 75 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 75 -119 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 86 75 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 94 75 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 75 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 75 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 75 -119 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 127 75 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 75 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 75 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 86 75 -120 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 95 75 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 75 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 75 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 75 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 75 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 75 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 75 -122 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 76 75 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 75 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 75 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 75 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 75 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 101 75 -123 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 73 75 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 75 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 75 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 75 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 75 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 75 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 75 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 75 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 75 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 75 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 75 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 80 75 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 75 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 82 75 -125 minecraft:birch_log[axis=y]
setblock 83 75 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 84 75 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 75 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 101 75 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 75 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 75 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 75 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 75 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 75 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 75 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 74 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 74 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 74 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 74 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 74 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 74 -116 minecraft:birch_log[axis=y]
setblock 108 74 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 74 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 74 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 74 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 74 -117 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 125 74 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 74 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 74 -118 minecraft:birch_log[axis=y]
setblock 109 74 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 74 -118 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 127 74 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 74 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 74 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 74 -119 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 79 74 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 74 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 86 74 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 74 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 74 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 74 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 74 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 129 74 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 74 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 74 -120 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 86 74 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 74 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 74 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 74 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 74 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 74 -120 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 127 74 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 74 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 74 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 74 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 74 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 74 -121 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 123 74 -121 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 76 74 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 74 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 74 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 74 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 74 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 75 74 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 74 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 77 74 -123 minecraft:birch_log[axis=y]
setblock 78 74 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 74 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 74 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 74 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 74 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 74 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 74 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 74 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 74 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 74 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 74 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 74 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 101 74 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 74 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 74 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 74 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 74 -125 minecraft:birch_log[axis=y]
setblock 95 74 -125 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 100 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 74 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 102 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 74 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 101 74 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 74 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 111 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 112 74 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 117 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 74 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 90 73 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 73 -116 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 106 73 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 108 73 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 73 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 73 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 73 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 73 -116 minecraft:birch_log[axis=y]
setblock 108 73 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 73 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 110 73 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 73 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 73 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 73 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 73 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 73 -117 regions_unexplored:birch_branch[facing=north]
setblock 79 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 86 73 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 73 -118 minecraft:birch_log[axis=y]
setblock 108 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 73 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 73 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 73 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 129 73 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 73 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 73 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 73 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 73 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 73 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 87 73 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 73 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 73 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 73 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 73 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 73 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 73 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 73 -119 minecraft:birch_log[axis=y]
setblock 129 73 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 130 73 -119 131 73 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 73 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 86 73 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 73 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 73 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 73 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 73 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 73 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 73 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 129 73 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 73 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 73 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 73 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 73 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 73 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 73 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 73 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 73 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 73 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 73 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 73 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 73 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 73 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 73 -123 minecraft:birch_log[axis=y]
setblock 99 73 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 73 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 101 73 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 73 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 73 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 73 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 74 73 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 73 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 73 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 73 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 102 73 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 73 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 73 -125 minecraft:birch_log[axis=y]
setblock 74 73 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 75 73 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 73 -125 minecraft:birch_log[axis=y]
setblock 95 73 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 73 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 73 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 101 73 -125 minecraft:birch_log[axis=y]
setblock 102 73 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 103 73 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 73 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 117 73 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 73 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 74 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 73 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 73 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 73 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 102 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 73 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 111 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 112 73 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 73 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 117 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 73 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 103 72 -116 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 104 72 -116 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 105 72 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 106 72 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 72 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 108 72 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 72 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 110 72 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 72 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 72 -116 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 72 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 72 -116 minecraft:birch_log[axis=y]
setblock 86 72 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 72 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 72 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 109 72 -117 minecraft:birch_log[axis=y]
setblock 110 72 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 72 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 72 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 72 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 72 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 72 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 72 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 72 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 87 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 72 -118 minecraft:birch_log[axis=y]
setblock 108 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 72 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 110 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 72 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 72 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 130 72 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 72 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 72 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 72 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 72 -119 minecraft:birch_log[axis=y]
setblock 87 72 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 88 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 72 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 72 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 72 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 72 -119 minecraft:birch_log[axis=y]
setblock 130 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 72 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 132 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 72 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 72 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 72 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 87 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 72 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 115 72 -120 minecraft:birch_log[axis=y]
setblock 116 72 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 117 72 -120 118 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 72 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 72 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 72 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 86 72 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 72 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 72 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 72 -121 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 72 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 72 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 72 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 72 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 72 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 72 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 72 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 72 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 72 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 101 72 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 72 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 72 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 72 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 72 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 72 -123 minecraft:birch_log[axis=y]
setblock 98 72 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 72 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 100 72 -123 minecraft:birch_log[axis=y]
setblock 101 72 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 102 72 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 72 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 72 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 72 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 72 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 100 72 -124 101 72 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 72 -125 minecraft:birch_log[axis=y]
setblock 82 72 -125 minecraft:birch_log[axis=y]
setblock 94 72 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 72 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 72 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 72 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 101 72 -125 minecraft:birch_log[axis=y]
setblock 110 72 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 111 72 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 112 72 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 72 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 117 72 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 72 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 72 -126 minecraft:air
setblock 94 72 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 72 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 72 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 72 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 72 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 112 72 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 72 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 72 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 72 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 72 -126 minecraft:air
setblock 132 72 -126 minecraft:air
setblock 102 71 -116 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 71 -116 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 104 71 -116 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 105 71 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 106 71 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 107 71 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 71 -116 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 71 -116 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 71 -116 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 71 -116 minecraft:birch_log[axis=y]
setblock 79 71 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 106 71 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 71 -117 minecraft:birch_log[axis=y]
setblock 113 71 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 71 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 115 71 -117 minecraft:birch_log[axis=y]
setblock 116 71 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 71 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 71 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 71 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 71 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 71 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 71 -118 minecraft:birch_log[axis=y]
setblock 114 71 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 71 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 71 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 71 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 71 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 71 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 132 71 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 71 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 71 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 71 -119 minecraft:birch_log[axis=y]
setblock 80 71 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 81 71 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 71 -119 minecraft:birch_log[axis=y]
setblock 115 71 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 71 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 71 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 71 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 71 -119 minecraft:birch_log[axis=y]
fill 129 71 -119 130 71 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 131 71 -119 minecraft:birch_log[axis=y]
setblock 132 71 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 133 71 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 71 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 71 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 71 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 71 -120 minecraft:birch_log[axis=y]
setblock 117 71 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 71 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 71 -120 minecraft:birch_log[axis=y]
setblock 120 71 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 121 71 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 71 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 71 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 71 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 132 71 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 71 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 71 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 71 -121 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 71 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 71 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 71 -121 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 71 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 71 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 71 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 71 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 71 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 123 71 -122 minecraft:birch_log[axis=y]
setblock 124 71 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 71 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 71 -123 minecraft:birch_log[axis=y]
setblock 82 71 -123 minecraft:air
setblock 94 71 -123 minecraft:air
setblock 100 71 -123 minecraft:birch_log[axis=y]
setblock 122 71 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 71 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 71 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 71 -124 minecraft:air
fill 81 71 -124 83 71 -124 minecraft:air
fill 93 71 -124 94 71 -124 minecraft:air
setblock 95 71 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 71 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 112 71 -124 minecraft:air
setblock 117 71 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 71 -124 minecraft:air
setblock 123 71 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 71 -124 minecraft:air
setblock 72 71 -125 minecraft:air
setblock 73 71 -125 minecraft:birch_log[axis=y]
fill 80 71 -125 81 71 -125 minecraft:air
setblock 82 71 -125 minecraft:birch_log[axis=y]
fill 83 71 -125 84 71 -125 minecraft:air
fill 92 71 -125 93 71 -125 minecraft:air
setblock 94 71 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 71 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 71 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 71 -125 minecraft:birch_log[axis=y]
setblock 110 71 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 71 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 112 71 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 71 -125 minecraft:air
setblock 116 71 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 71 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 71 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 121 71 -125 123 71 -125 minecraft:air
fill 131 71 -125 133 71 -125 minecraft:air
fill 72 71 -126 74 71 -126 minecraft:air
fill 81 71 -126 83 71 -126 minecraft:air
setblock 93 71 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 71 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 95 71 -126 minecraft:birch_log[axis=y]
setblock 96 71 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 97 71 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 71 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 71 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 71 -126 minecraft:birch_log[axis=y]
setblock 112 71 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 113 71 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 71 -126 minecraft:air
setblock 115 71 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 71 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 71 -126 minecraft:birch_log[axis=y]
setblock 118 71 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 71 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 120 71 -126 124 71 -126 minecraft:air
fill 130 71 -126 134 71 -126 minecraft:air
setblock 101 70 -116 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 102 70 -116 105 70 -116 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 70 -116 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 70 -116 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 70 -116 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 70 -116 regions_unexplored:birch_branch[facing=west]
setblock 133 70 -116 minecraft:birch_log[axis=y]
setblock 101 70 -117 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 102 70 -117 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 103 70 -117 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 104 70 -117 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 70 -117 minecraft:birch_log[axis=y]
setblock 115 70 -117 minecraft:birch_log[axis=y]
setblock 95 70 -118 minecraft:birch_log[axis=y]
setblock 79 70 -119 minecraft:birch_log[axis=y]
setblock 86 70 -119 minecraft:birch_log[axis=y]
setblock 128 70 -119 minecraft:birch_log[axis=y]
setblock 131 70 -119 minecraft:birch_log[axis=y]
setblock 115 70 -120 minecraft:birch_log[axis=y]
setblock 119 70 -120 minecraft:birch_log[axis=y]
setblock 123 70 -122 minecraft:birch_log[axis=y]
setblock 77 70 -123 minecraft:birch_log[axis=y]
fill 81 70 -123 83 70 -123 minecraft:air
fill 93 70 -123 95 70 -123 minecraft:air
setblock 100 70 -123 minecraft:birch_log[axis=y]
fill 72 70 -124 73 70 -124 minecraft:air
fill 80 70 -124 84 70 -124 minecraft:air
fill 92 70 -124 96 70 -124 minecraft:air
fill 111 70 -124 113 70 -124 minecraft:air
fill 121 70 -124 123 70 -124 minecraft:air
fill 131 70 -124 133 70 -124 minecraft:air
setblock 72 70 -125 minecraft:air
setblock 73 70 -125 minecraft:birch_log[axis=y]
setblock 74 70 -125 minecraft:air
fill 80 70 -125 81 70 -125 minecraft:air
setblock 82 70 -125 minecraft:birch_log[axis=y]
fill 83 70 -125 84 70 -125 minecraft:air
fill 92 70 -125 96 70 -125 minecraft:air
setblock 101 70 -125 minecraft:birch_log[axis=y]
fill 110 70 -125 114 70 -125 minecraft:air
fill 120 70 -125 124 70 -125 minecraft:air
fill 130 70 -125 134 70 -125 minecraft:air
fill 72 70 -126 74 70 -126 minecraft:air
fill 80 70 -126 84 70 -126 minecraft:air
fill 92 70 -126 94 70 -126 minecraft:air
setblock 95 70 -126 minecraft:birch_log[axis=y]
setblock 96 70 -126 minecraft:air
setblock 110 70 -126 minecraft:air
setblock 111 70 -126 minecraft:birch_log[axis=y]
fill 112 70 -126 113 70 -126 minecraft:air
setblock 114 70 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 70 -126 minecraft:birch_log[axis=y]
fill 120 70 -126 124 70 -126 minecraft:air
fill 130 70 -126 134 70 -126 minecraft:air
setblock 101 69 -116 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 69 -116 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 103 69 -116 regions_unexplored:maple_branch[facing=north]
setblock 104 69 -116 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 105 69 -116 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 69 -116 minecraft:birch_log[axis=y]
setblock 101 69 -117 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 102 69 -117 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 69 -117 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 104 69 -117 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 105 69 -117 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 69 -117 minecraft:birch_log[axis=y]
setblock 115 69 -117 minecraft:birch_log[axis=y]
setblock 95 69 -118 minecraft:birch_log[axis=y]
setblock 79 69 -119 minecraft:birch_log[axis=y]
setblock 86 69 -119 minecraft:birch_log[axis=y]
setblock 128 69 -119 minecraft:birch_log[axis=y]
setblock 131 69 -119 minecraft:birch_log[axis=y]
setblock 115 69 -120 minecraft:birch_log[axis=y]
setblock 119 69 -120 minecraft:birch_log[axis=y]
setblock 123 69 -122 minecraft:birch_log[axis=y]
setblock 77 69 -123 minecraft:birch_log[axis=y]
setblock 82 69 -123 minecraft:air
setblock 94 69 -123 minecraft:air
setblock 100 69 -123 minecraft:birch_log[axis=y]
setblock 72 69 -124 minecraft:air
fill 81 69 -124 83 69 -124 minecraft:air
fill 93 69 -124 95 69 -124 minecraft:air
setblock 112 69 -124 minecraft:air
setblock 122 69 -124 minecraft:air
setblock 132 69 -124 minecraft:air
setblock 72 69 -125 minecraft:air
setblock 73 69 -125 minecraft:birch_log[axis=y]
fill 80 69 -125 81 69 -125 minecraft:air
setblock 82 69 -125 minecraft:birch_log[axis=y]
fill 83 69 -125 84 69 -125 minecraft:air
fill 92 69 -125 96 69 -125 minecraft:air
setblock 101 69 -125 minecraft:birch_log[axis=y]
fill 111 69 -125 113 69 -125 minecraft:air
fill 121 69 -125 123 69 -125 minecraft:air
fill 131 69 -125 133 69 -125 minecraft:air
fill 72 69 -126 74 69 -126 minecraft:air
fill 81 69 -126 83 69 -126 minecraft:air
fill 93 69 -126 94 69 -126 minecraft:air
setblock 95 69 -126 minecraft:birch_log[axis=y]
setblock 110 69 -126 minecraft:air
setblock 111 69 -126 minecraft:birch_log[axis=y]
fill 112 69 -126 114 69 -126 minecraft:air
setblock 117 69 -126 minecraft:birch_log[axis=y]
fill 120 69 -126 124 69 -126 minecraft:air
fill 130 69 -126 134 69 -126 minecraft:air
setblock 103 68 -116 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 133 68 -116 minecraft:birch_log[axis=y]
setblock 109 68 -117 minecraft:birch_log[axis=y]
setblock 115 68 -117 minecraft:birch_log[axis=y]
setblock 95 68 -118 minecraft:birch_log[axis=y]
setblock 79 68 -119 minecraft:birch_log[axis=y]
setblock 86 68 -119 minecraft:birch_log[axis=y]
setblock 128 68 -119 minecraft:birch_log[axis=y]
setblock 131 68 -119 minecraft:birch_log[axis=y]
setblock 115 68 -120 minecraft:birch_log[axis=y]
setblock 119 68 -120 minecraft:birch_log[axis=y]
setblock 123 68 -122 minecraft:birch_log[axis=y]
setblock 77 68 -123 minecraft:birch_log[axis=y]
setblock 100 68 -123 minecraft:birch_log[axis=y]
setblock 73 68 -125 minecraft:birch_log[axis=y]
setblock 82 68 -125 minecraft:birch_log[axis=y]
setblock 94 68 -125 minecraft:air
setblock 101 68 -125 minecraft:birch_log[axis=y]
setblock 72 68 -126 minecraft:air
setblock 95 68 -126 minecraft:birch_log[axis=y]
setblock 111 68 -126 minecraft:birch_log[axis=y]
setblock 112 68 -126 minecraft:air
setblock 117 68 -126 minecraft:birch_log[axis=y]
setblock 122 68 -126 minecraft:air
setblock 132 68 -126 minecraft:air
setblock 133 67 -116 minecraft:birch_log[axis=y]
setblock 109 67 -117 minecraft:birch_log[axis=y]
setblock 115 67 -117 minecraft:birch_log[axis=y]
setblock 86 67 -118 regions_unexplored:birch_shrub[half=upper]
fill 89 67 -118 90 67 -118 minecraft:rose_bush[half=upper]
setblock 95 67 -118 minecraft:birch_log[axis=y]
setblock 79 67 -119 minecraft:birch_log[axis=y]
setblock 86 67 -119 minecraft:birch_log[axis=y]
setblock 128 67 -119 minecraft:birch_log[axis=y]
setblock 131 67 -119 minecraft:birch_log[axis=y]
setblock 115 67 -120 minecraft:birch_log[axis=y]
setblock 119 67 -120 minecraft:birch_log[axis=y]
setblock 96 67 -122 minecraft:rose_bush[half=upper]
setblock 123 67 -122 minecraft:birch_log[axis=y]
setblock 135 67 -122 minecraft:short_grass
setblock 77 67 -123 minecraft:birch_log[axis=y]
setblock 100 67 -123 minecraft:birch_log[axis=y]
setblock 135 67 -123 minecraft:short_grass
setblock 73 67 -125 minecraft:birch_log[axis=y]
setblock 82 67 -125 minecraft:birch_log[axis=y]
setblock 94 67 -125 minecraft:air
setblock 97 67 -125 minecraft:rose_bush[half=upper]
setblock 101 67 -125 minecraft:birch_log[axis=y]
setblock 72 67 -126 minecraft:air
setblock 95 67 -126 minecraft:birch_log[axis=y]
setblock 111 67 -126 minecraft:birch_log[axis=y]
setblock 112 67 -126 minecraft:air
setblock 117 67 -126 minecraft:birch_log[axis=y]
setblock 122 67 -126 minecraft:air
setblock 132 67 -126 minecraft:air
setblock 78 66 -116 minecraft:short_grass
setblock 81 66 -116 regions_unexplored:grass_sprouts
fill 85 66 -116 91 66 -116 minecraft:grass_block[snowy=false]
setblock 133 66 -116 minecraft:birch_log[axis=y]
setblock 135 66 -116 minecraft:short_grass
setblock 81 66 -117 regions_unexplored:grass_sprouts
setblock 87 66 -117 minecraft:short_grass
setblock 90 66 -117 regions_unexplored:grass_sprouts
setblock 109 66 -117 minecraft:birch_log[axis=y]
setblock 110 66 -117 minecraft:lilac[half=upper]
setblock 113 66 -117 minecraft:lilac[half=upper]
setblock 115 66 -117 minecraft:birch_log[axis=y]
setblock 83 66 -118 minecraft:short_grass
setblock 86 66 -118 regions_unexplored:birch_shrub[half=lower]
setblock 88 66 -118 regions_unexplored:grass_sprouts
fill 89 66 -118 90 66 -118 minecraft:rose_bush[half=lower]
setblock 95 66 -118 minecraft:birch_log[axis=y]
setblock 99 66 -118 minecraft:short_grass
setblock 128 66 -118 regions_unexplored:grass_sprouts
setblock 79 66 -119 minecraft:birch_log[axis=y]
setblock 81 66 -119 regions_unexplored:grass_sprouts
setblock 86 66 -119 minecraft:birch_log[axis=y]
setblock 88 66 -119 minecraft:rose_bush[half=upper]
setblock 90 66 -119 minecraft:rose_bush[half=upper]
setblock 101 66 -119 regions_unexplored:grass_sprouts
setblock 128 66 -119 minecraft:birch_log[axis=y]
setblock 131 66 -119 minecraft:birch_log[axis=y]
fill 86 66 -120 87 66 -120 minecraft:rose_bush[half=upper]
setblock 90 66 -120 minecraft:rose_bush[half=upper]
setblock 115 66 -120 minecraft:birch_log[axis=y]
setblock 119 66 -120 minecraft:birch_log[axis=y]
setblock 86 66 -121 minecraft:rose_bush[half=upper]
setblock 100 66 -121 minecraft:short_grass
setblock 132 66 -121 regions_unexplored:grass_sprouts
setblock 135 66 -121 minecraft:short_grass
setblock 96 66 -122 minecraft:rose_bush[half=lower]
setblock 119 66 -122 regions_unexplored:grass_sprouts
setblock 123 66 -122 minecraft:birch_log[axis=y]
setblock 135 66 -122 minecraft:grass_block[snowy=false]
setblock 77 66 -123 minecraft:birch_log[axis=y]
setblock 96 66 -123 minecraft:rose_bush[half=upper]
setblock 99 66 -123 minecraft:short_grass
setblock 100 66 -123 minecraft:birch_log[axis=y]
fill 134 66 -123 135 66 -123 minecraft:grass_block[snowy=false]
setblock 101 66 -124 minecraft:short_grass
setblock 131 66 -124 minecraft:short_grass
fill 134 66 -124 135 66 -124 minecraft:grass_block[snowy=false]
setblock 73 66 -125 minecraft:birch_log[axis=y]
setblock 82 66 -125 minecraft:birch_log[axis=y]
setblock 94 66 -125 minecraft:air
setblock 96 66 -125 minecraft:rose_bush[half=upper]
setblock 97 66 -125 minecraft:rose_bush[half=lower]
setblock 100 66 -125 minecraft:short_grass
setblock 101 66 -125 minecraft:birch_log[axis=y]
fill 134 66 -125 135 66 -125 minecraft:grass_block[snowy=false]
setblock 72 66 -126 minecraft:air
setblock 95 66 -126 minecraft:birch_log[axis=y]
setblock 112 66 -126 minecraft:air
setblock 122 66 -126 minecraft:air
setblock 132 66 -126 minecraft:air
fill 133 66 -126 135 66 -126 minecraft:grass_block[snowy=false]
fill 72 65 -116 74 65 -116 minecraft:air
setblock 75 65 -116 regions_unexplored:grass_sprouts
setblock 76 65 -116 minecraft:air
setblock 77 65 -116 minecraft:short_grass
fill 78 65 -116 84 65 -116 minecraft:grass_block[snowy=false]
fill 85 65 -116 91 65 -116 minecraft:dirt
fill 92 65 -116 98 65 -116 minecraft:grass_block[snowy=false]
fill 99 65 -116 118 65 -116 minecraft:air
setblock 119 65 -116 regions_unexplored:grass_sprouts
fill 120 65 -116 130 65 -116 minecraft:air
fill 131 65 -116 132 65 -116 minecraft:grass_block[snowy=false]
setblock 133 65 -116 minecraft:dirt
fill 134 65 -116 135 65 -116 minecraft:grass_block[snowy=false]
setblock 72 65 -117 minecraft:air
fill 73 65 -117 74 65 -117 regions_unexplored:grass_sprouts
fill 75 65 -117 76 65 -117 minecraft:air
setblock 77 65 -117 regions_unexplored:grass_sprouts
setblock 78 65 -117 minecraft:air
fill 79 65 -117 98 65 -117 minecraft:grass_block[snowy=false]
fill 99 65 -117 109 65 -117 minecraft:air
setblock 110 65 -117 minecraft:lilac[half=lower]
fill 111 65 -117 112 65 -117 minecraft:air
setblock 113 65 -117 minecraft:lilac[half=lower]
setblock 114 65 -117 minecraft:air
setblock 115 65 -117 minecraft:birch_log[axis=y]
setblock 116 65 -117 regions_unexplored:red_maple_leaf_litter[facing=north,flower_amount=2]
setblock 117 65 -117 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=1]
fill 118 65 -117 128 65 -117 minecraft:air
fill 129 65 -117 135 65 -117 minecraft:grass_block[snowy=false]
fill 72 65 -118 78 65 -118 minecraft:air
setblock 79 65 -118 regions_unexplored:grass_sprouts
fill 80 65 -118 91 65 -118 minecraft:grass_block[snowy=false]
setblock 92 65 -118 minecraft:air
fill 93 65 -118 94 65 -118 minecraft:grass_block[snowy=false]
setblock 95 65 -118 minecraft:dirt
fill 96 65 -118 99 65 -118 minecraft:grass_block[snowy=false]
fill 100 65 -118 115 65 -118 minecraft:air
setblock 116 65 -118 regions_unexplored:grass_sprouts
fill 117 65 -118 119 65 -118 minecraft:air
fill 120 65 -118 121 65 -118 minecraft:short_grass
setblock 122 65 -118 minecraft:air
setblock 123 65 -118 minecraft:short_grass
fill 124 65 -118 126 65 -118 minecraft:air
fill 127 65 -118 135 65 -118 minecraft:grass_block[snowy=false]
fill 72 65 -119 78 65 -119 minecraft:air
setblock 79 65 -119 minecraft:birch_log[axis=y]
setblock 80 65 -119 regions_unexplored:grass_sprouts
fill 81 65 -119 85 65 -119 minecraft:grass_block[snowy=false]
setblock 86 65 -119 minecraft:dirt
setblock 87 65 -119 minecraft:grass_block[snowy=false]
setblock 88 65 -119 minecraft:rose_bush[half=lower]
setblock 89 65 -119 minecraft:short_grass
setblock 90 65 -119 minecraft:rose_bush[half=lower]
fill 91 65 -119 94 65 -119 minecraft:air
fill 95 65 -119 101 65 -119 minecraft:grass_block[snowy=false]
fill 102 65 -119 123 65 -119 minecraft:air
fill 124 65 -119 127 65 -119 minecraft:grass_block[snowy=false]
setblock 128 65 -119 minecraft:dirt
fill 129 65 -119 130 65 -119 minecraft:grass_block[snowy=false]
setblock 131 65 -119 minecraft:dirt
fill 132 65 -119 135 65 -119 minecraft:grass_block[snowy=false]
fill 72 65 -120 77 65 -120 minecraft:air
setblock 78 65 -120 minecraft:short_grass
fill 79 65 -120 83 65 -120 minecraft:air
setblock 84 65 -120 minecraft:grass_block[snowy=false]
setblock 85 65 -120 minecraft:air
fill 86 65 -120 87 65 -120 minecraft:rose_bush[half=lower]
fill 88 65 -120 89 65 -120 minecraft:air
setblock 90 65 -120 minecraft:rose_bush[half=lower]
fill 91 65 -120 95 65 -120 minecraft:air
fill 96 65 -120 100 65 -120 minecraft:grass_block[snowy=false]
fill 101 65 -120 114 65 -120 minecraft:air
setblock 115 65 -120 minecraft:birch_log[axis=y]
setblock 116 65 -120 minecraft:air
setblock 117 65 -120 regions_unexplored:grass_sprouts
setblock 118 65 -120 minecraft:air
setblock 119 65 -120 minecraft:birch_log[axis=y]
fill 120 65 -120 121 65 -120 minecraft:air
fill 122 65 -120 135 65 -120 minecraft:grass_block[snowy=false]
setblock 72 65 -121 minecraft:grass_block[snowy=false]
fill 73 65 -121 80 65 -121 minecraft:air
fill 81 65 -121 82 65 -121 regions_unexplored:grass_sprouts
fill 83 65 -121 85 65 -121 minecraft:air
setblock 86 65 -121 minecraft:rose_bush[half=lower]
setblock 87 65 -121 minecraft:short_grass
setblock 88 65 -121 regions_unexplored:grass_sprouts
fill 89 65 -121 90 65 -121 minecraft:air
setblock 91 65 -121 minecraft:rose_bush[half=upper]
fill 92 65 -121 95 65 -121 minecraft:air
fill 96 65 -121 100 65 -121 minecraft:grass_block[snowy=false]
fill 101 65 -121 116 65 -121 minecraft:air
setblock 117 65 -121 regions_unexplored:grass_sprouts
fill 118 65 -121 119 65 -121 minecraft:air
fill 120 65 -121 135 65 -121 minecraft:grass_block[snowy=false]
setblock 74 65 -122 regions_unexplored:grass_sprouts
setblock 75 65 -122 minecraft:air
setblock 76 65 -122 regions_unexplored:grass_sprouts
fill 77 65 -122 84 65 -122 minecraft:air
setblock 85 65 -122 regions_unexplored:grass_sprouts
fill 86 65 -122 87 65 -122 minecraft:air
setblock 88 65 -122 regions_unexplored:grass_sprouts
fill 89 65 -122 92 65 -122 minecraft:air
setblock 93 65 -122 minecraft:rose_bush[half=upper]
fill 94 65 -122 95 65 -122 minecraft:air
fill 101 65 -122 115 65 -122 minecraft:air
setblock 116 65 -122 minecraft:short_grass
setblock 123 65 -122 minecraft:dirt
setblock 135 65 -122 minecraft:dirt
setblock 76 65 -123 minecraft:air
setblock 77 65 -123 minecraft:birch_log[axis=y]
fill 78 65 -123 83 65 -123 minecraft:air
fill 84 65 -123 85 65 -123 minecraft:short_grass
fill 86 65 -123 89 65 -123 minecraft:air
setblock 90 65 -123 minecraft:rose_bush[half=upper]
fill 91 65 -123 95 65 -123 minecraft:air
setblock 96 65 -123 minecraft:rose_bush[half=lower]
setblock 100 65 -123 minecraft:dirt
fill 102 65 -123 115 65 -123 minecraft:air
fill 134 65 -123 135 65 -123 minecraft:dirt
fill 78 65 -124 88 65 -124 minecraft:air
setblock 89 65 -124 minecraft:rose_bush[half=upper]
fill 90 65 -124 91 65 -124 minecraft:air
setblock 92 65 -124 minecraft:rose_bush[half=upper]
fill 93 65 -124 96 65 -124 minecraft:air
fill 103 65 -124 116 65 -124 minecraft:air
fill 134 65 -124 135 65 -124 minecraft:dirt
setblock 73 65 -125 minecraft:dirt
fill 80 65 -125 81 65 -125 minecraft:air
setblock 82 65 -125 minecraft:birch_log[axis=y]
fill 83 65 -125 84 65 -125 minecraft:air
setblock 85 65 -125 regions_unexplored:grass_sprouts
fill 86 65 -125 95 65 -125 minecraft:air
setblock 96 65 -125 minecraft:rose_bush[half=lower]
setblock 101 65 -125 minecraft:dirt
fill 104 65 -125 129 65 -125 minecraft:air
fill 134 65 -125 135 65 -125 minecraft:dirt
fill 82 65 -126 87 65 -126 minecraft:air
setblock 88 65 -126 regions_unexplored:grass_sprouts
fill 89 65 -126 94 65 -126 minecraft:air
setblock 95 65 -126 minecraft:birch_log[axis=y]
setblock 96 65 -126 minecraft:air
fill 107 65 -126 130 65 -126 minecraft:air
fill 133 65 -126 135 65 -126 minecraft:dirt
fill 99 64 -116 108 64 -116 minecraft:air
fill 111 64 -116 115 64 -116 minecraft:air
fill 99 64 -117 109 64 -117 minecraft:air
setblock 112 64 -117 minecraft:air
fill 100 64 -118 110 64 -118 minecraft:air
fill 102 64 -119 111 64 -119 minecraft:air
fill 91 64 -120 92 64 -120 minecraft:air
setblock 102 64 -120 minecraft:short_grass
fill 103 64 -120 112 64 -120 minecraft:air
setblock 90 64 -121 minecraft:air
setblock 91 64 -121 minecraft:rose_bush[half=lower]
fill 92 64 -121 93 64 -121 minecraft:air
fill 102 64 -121 113 64 -121 minecraft:air
setblock 89 64 -122 regions_unexplored:grass_sprouts
fill 90 64 -122 92 64 -122 minecraft:air
setblock 93 64 -122 minecraft:rose_bush[half=lower]
fill 102 64 -122 114 64 -122 minecraft:air
fill 87 64 -123 89 64 -123 minecraft:air
setblock 90 64 -123 minecraft:rose_bush[half=lower]
fill 91 64 -123 93 64 -123 minecraft:air
fill 102 64 -123 115 64 -123 minecraft:air
fill 85 64 -124 88 64 -124 minecraft:air
setblock 89 64 -124 minecraft:rose_bush[half=lower]
fill 90 64 -124 91 64 -124 minecraft:air
setblock 92 64 -124 minecraft:rose_bush[half=lower]
setblock 93 64 -124 minecraft:air
fill 103 64 -124 116 64 -124 minecraft:air
fill 90 64 -125 92 64 -125 minecraft:air
fill 104 64 -125 117 64 -125 minecraft:air
fill 105 64 -126 127 64 -126 minecraft:air
fill 99 63 -116 108 63 -116 minecraft:air
fill 99 63 -117 109 63 -117 minecraft:air
fill 100 63 -118 110 63 -118 minecraft:air
fill 102 63 -119 111 63 -119 minecraft:air
fill 103 63 -120 112 63 -120 minecraft:air
fill 103 63 -121 113 63 -121 minecraft:air
setblock 103 63 -122 minecraft:short_grass
fill 104 63 -122 114 63 -122 minecraft:air
fill 103 63 -123 115 63 -123 minecraft:air
fill 103 63 -124 116 63 -124 minecraft:air
fill 104 63 -125 116 63 -125 minecraft:air
fill 105 63 -126 117 63 -126 minecraft:air
fill 99 62 -116 108 62 -116 minecraft:air
fill 99 62 -117 109 62 -117 minecraft:air
fill 100 62 -118 110 62 -118 minecraft:air
fill 102 62 -119 111 62 -119 minecraft:air
fill 103 62 -120 112 62 -120 minecraft:air
fill 103 62 -121 112 62 -121 minecraft:air
fill 104 62 -122 112 62 -122 minecraft:air
fill 104 62 -123 112 62 -123 minecraft:air
fill 104 62 -124 112 62 -124 minecraft:air
fill 104 62 -125 112 62 -125 minecraft:air
fill 114 62 -125 115 62 -125 minecraft:air
fill 105 62 -126 109 62 -126 minecraft:air
fill 113 62 -126 116 62 -126 minecraft:air
fill 108 61 -120 109 61 -120 minecraft:air
fill 106 61 -121 111 61 -121 minecraft:air
fill 105 61 -122 111 61 -122 minecraft:air
fill 104 61 -123 112 61 -123 minecraft:air
fill 104 61 -124 112 61 -124 minecraft:air
fill 105 61 -125 111 61 -125 minecraft:air
fill 106 61 -126 110 61 -126 minecraft:air
fill 108 60 -120 111 60 -120 minecraft:air
fill 106 60 -121 112 60 -121 minecraft:air
fill 106 60 -122 112 60 -122 minecraft:air
fill 105 60 -123 112 60 -123 minecraft:air
fill 105 60 -124 112 60 -124 minecraft:air
fill 106 60 -125 111 60 -125 minecraft:air
fill 107 60 -126 110 60 -126 minecraft:air
fill 108 59 -120 111 59 -120 minecraft:air
fill 107 59 -121 112 59 -121 minecraft:air
fill 106 59 -122 112 59 -122 minecraft:air
fill 106 59 -123 112 59 -123 minecraft:air
fill 106 59 -124 112 59 -124 minecraft:air
fill 106 59 -125 111 59 -125 minecraft:air
fill 108 59 -126 110 59 -126 minecraft:air
fill 109 58 -119 110 58 -119 minecraft:air
fill 107 58 -120 112 58 -120 minecraft:air
fill 107 58 -121 112 58 -121 minecraft:air
fill 106 58 -122 112 58 -122 minecraft:air
fill 106 58 -123 112 58 -123 minecraft:air
fill 106 58 -124 112 58 -124 minecraft:air
fill 107 58 -125 111 58 -125 minecraft:air
fill 109 58 -126 110 58 -126 minecraft:air
fill 108 57 -119 111 57 -119 minecraft:air
fill 107 57 -120 112 57 -120 minecraft:air
fill 107 57 -121 113 57 -121 minecraft:air
fill 107 57 -122 113 57 -122 minecraft:air
fill 107 57 -123 112 57 -123 minecraft:air
fill 107 57 -124 112 57 -124 minecraft:air
fill 108 57 -125 111 57 -125 minecraft:air
fill 109 56 -118 111 56 -118 minecraft:air
fill 108 56 -119 112 56 -119 minecraft:air
fill 107 56 -120 113 56 -120 minecraft:air
fill 107 56 -121 113 56 -121 minecraft:air
fill 107 56 -122 113 56 -122 minecraft:air
fill 107 56 -123 113 56 -123 minecraft:air
fill 107 56 -124 112 56 -124 minecraft:air
fill 108 56 -125 111 56 -125 minecraft:air
setblock 109 55 -116 minecraft:water[level=0]
setblock 109 55 -117 minecraft:water[level=1]
fill 110 55 -117 111 55 -117 minecraft:air
fill 108 55 -118 112 55 -118 minecraft:air
fill 107 55 -119 113 55 -119 minecraft:air
fill 107 55 -120 113 55 -120 minecraft:air
fill 107 55 -121 113 55 -121 minecraft:air
fill 107 55 -122 113 55 -122 minecraft:air
fill 107 55 -123 112 55 -123 minecraft:air
fill 108 55 -124 111 55 -124 minecraft:air
fill 109 55 -125 110 55 -125 minecraft:air
setblock 108 54 -117 minecraft:air
setblock 109 54 -117 minecraft:water[level=8]
fill 110 54 -117 112 54 -117 minecraft:air
fill 108 54 -118 113 54 -118 minecraft:air
fill 107 54 -119 113 54 -119 minecraft:air
fill 107 54 -120 113 54 -120 minecraft:air
fill 119 54 -120 120 54 -120 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 107 54 -121 113 54 -121 minecraft:air
fill 119 54 -121 120 54 -121 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 107 54 -122 113 54 -122 minecraft:air
fill 107 54 -123 112 54 -123 minecraft:air
fill 108 54 -124 111 54 -124 minecraft:air
fill 109 53 -116 111 53 -116 minecraft:air
setblock 108 53 -117 minecraft:air
setblock 109 53 -117 minecraft:water[level=8]
fill 110 53 -117 113 53 -117 minecraft:air
fill 107 53 -118 113 53 -118 minecraft:air
fill 107 53 -119 113 53 -119 minecraft:air
fill 107 53 -120 113 53 -120 minecraft:air
fill 119 53 -120 120 53 -120 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 107 53 -121 113 53 -121 minecraft:air
fill 119 53 -121 120 53 -121 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 107 53 -122 113 53 -122 minecraft:air
fill 108 53 -123 111 53 -123 minecraft:air
fill 109 53 -124 111 53 -124 minecraft:air
fill 108 52 -116 112 52 -116 minecraft:air
setblock 108 52 -117 minecraft:air
setblock 109 52 -117 minecraft:water[level=8]
fill 110 52 -117 113 52 -117 minecraft:air
fill 107 52 -118 113 52 -118 minecraft:air
fill 107 52 -119 113 52 -119 minecraft:air
fill 107 52 -120 113 52 -120 minecraft:air
fill 107 52 -121 113 52 -121 minecraft:air
fill 108 52 -122 112 52 -122 minecraft:air
fill 109 52 -123 111 52 -123 minecraft:air
fill 108 51 -116 113 51 -116 minecraft:air
fill 107 51 -117 108 51 -117 minecraft:air
setblock 109 51 -117 minecraft:water[level=8]
fill 110 51 -117 114 51 -117 minecraft:air
fill 107 51 -118 114 51 -118 minecraft:air
fill 107 51 -119 114 51 -119 minecraft:air
fill 107 51 -120 113 51 -120 minecraft:air
fill 107 51 -121 113 51 -121 minecraft:air
fill 108 51 -122 112 51 -122 minecraft:air
fill 108 50 -116 114 50 -116 minecraft:air
fill 107 50 -117 108 50 -117 minecraft:air
setblock 109 50 -117 minecraft:water[level=8]
fill 110 50 -117 114 50 -117 minecraft:air
fill 107 50 -118 114 50 -118 minecraft:air
fill 107 50 -119 114 50 -119 minecraft:air
fill 107 50 -120 113 50 -120 minecraft:air
fill 108 50 -121 113 50 -121 minecraft:air
fill 109 50 -122 111 50 -122 minecraft:air
fill 94 49 -116 95 49 -116 minecraft:air
fill 107 49 -116 114 49 -116 minecraft:air
setblock 95 49 -117 minecraft:air
fill 107 49 -117 108 49 -117 minecraft:air
setblock 109 49 -117 minecraft:water[level=8]
fill 110 49 -117 114 49 -117 minecraft:air
fill 107 49 -118 114 49 -118 minecraft:air
fill 107 49 -119 114 49 -119 minecraft:air
fill 108 49 -120 113 49 -120 minecraft:air
fill 109 49 -121 112 49 -121 minecraft:air
fill 94 48 -116 96 48 -116 minecraft:air
fill 107 48 -116 114 48 -116 minecraft:air
fill 94 48 -117 96 48 -117 minecraft:air
fill 107 48 -117 108 48 -117 minecraft:air
setblock 109 48 -117 minecraft:water[level=8]
fill 110 48 -117 114 48 -117 minecraft:air
fill 108 48 -118 114 48 -118 minecraft:air
fill 94 48 -119 95 48 -119 minecraft:air
fill 108 48 -119 114 48 -119 minecraft:air
setblock 95 48 -120 minecraft:air
fill 108 48 -120 113 48 -120 minecraft:air
setblock 109 48 -121 minecraft:air
setblock 111 48 -121 minecraft:air
fill 121 48 -121 122 48 -121 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 94 47 -116 96 47 -116 minecraft:air
fill 107 47 -116 114 47 -116 minecraft:air
fill 94 47 -117 95 47 -117 minecraft:air
fill 107 47 -117 108 47 -117 minecraft:air
setblock 109 47 -117 minecraft:water[level=8]
fill 110 47 -117 114 47 -117 minecraft:air
fill 94 47 -118 95 47 -118 minecraft:air
fill 108 47 -118 114 47 -118 minecraft:air
fill 94 47 -119 96 47 -119 minecraft:air
fill 108 47 -119 113 47 -119 minecraft:air
fill 94 47 -120 96 47 -120 minecraft:air
fill 109 47 -120 110 47 -120 minecraft:air
setblock 112 47 -120 minecraft:air
fill 93 47 -121 95 47 -121 minecraft:air
fill 94 47 -122 95 47 -122 minecraft:air
fill 121 47 -122 122 47 -122 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 94 47 -124 minecraft:air
fill 107 46 -116 108 46 -116 minecraft:air
setblock 109 46 -116 minecraft:water[level=1]
fill 110 46 -116 113 46 -116 minecraft:air
setblock 108 46 -117 minecraft:air
setblock 109 46 -117 minecraft:water[level=8]
fill 110 46 -117 113 46 -117 minecraft:air
fill 94 46 -118 95 46 -118 minecraft:air
fill 108 46 -118 113 46 -118 minecraft:air
fill 94 46 -119 96 46 -119 minecraft:air
fill 109 46 -119 111 46 -119 minecraft:air
fill 94 46 -120 96 46 -120 minecraft:air
fill 93 46 -121 96 46 -121 minecraft:air
fill 93 46 -122 95 46 -122 minecraft:air
setblock 93 46 -123 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=true]
fill 94 46 -123 95 46 -123 minecraft:air
fill 93 46 -124 95 46 -124 minecraft:air
fill 93 46 -125 95 46 -125 minecraft:air
fill 94 46 -126 96 46 -126 minecraft:air
setblock 108 45 -116 minecraft:water[level=1]
setblock 109 45 -116 minecraft:water[level=8]
setblock 110 45 -116 minecraft:water[level=1]
setblock 111 45 -116 minecraft:water[level=2]
fill 94 45 -120 95 45 -120 minecraft:air
fill 94 45 -121 95 45 -121 minecraft:air
fill 94 45 -122 95 45 -122 minecraft:air
fill 93 45 -123 95 45 -123 minecraft:air
fill 93 45 -124 95 45 -124 minecraft:air
fill 93 45 -125 96 45 -125 minecraft:air
fill 93 45 -126 96 45 -126 minecraft:air
forceload remove 72 -126 135 -63
tellraw @a {"text":"Campus zurueck a37 fertig.","color":"green"}
