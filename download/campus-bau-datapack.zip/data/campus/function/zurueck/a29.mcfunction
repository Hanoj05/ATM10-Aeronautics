# Abschnitt a29: x 8..71, z -190..-127 (18322 Blöcke)
forceload add 8 -190 71 -127
tellraw @a {"text":"Campus zurueck a29: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a29_1 2s
