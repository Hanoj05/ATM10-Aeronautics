setblock 199 86 -255 minecraft:white_concrete
setblock 195 85 -256 minecraft:white_concrete
setblock 195 85 -257 minecraft:white_concrete
setblock 196 85 -258 minecraft:white_concrete
setblock 196 85 -259 minecraft:white_concrete
setblock 197 85 -260 minecraft:white_concrete
setblock 198 85 -261 minecraft:white_concrete
setblock 199 85 -263 minecraft:white_concrete
setblock 199 85 -264 minecraft:white_concrete
setblock 139 73 -317 alltheores:deepslate_nickel_ore
setblock 143 72 -298 minecraft:air
setblock 153 72 -298 minecraft:air
setblock 163 72 -298 minecraft:air
setblock 173 72 -298 minecraft:air
setblock 183 72 -298 minecraft:air
setblock 193 72 -298 minecraft:air
setblock 143 72 -312 minecraft:air
setblock 153 72 -312 minecraft:air
setblock 163 72 -312 minecraft:air
setblock 173 72 -312 minecraft:air
setblock 183 72 -312 minecraft:air
setblock 193 72 -312 minecraft:air
setblock 138 72 -317 minecraft:deepslate_copper_ore
setblock 141 72 -317 minecraft:deepslate_iron_ore
setblock 143 71 -296 minecraft:air
setblock 153 71 -296 minecraft:air
setblock 163 71 -296 minecraft:air
setblock 173 71 -296 minecraft:air
setblock 183 71 -296 minecraft:air
setblock 193 71 -296 minecraft:air
fill 142 71 -297 144 71 -297 minecraft:air
fill 152 71 -297 154 71 -297 minecraft:air
fill 162 71 -297 164 71 -297 minecraft:air
fill 172 71 -297 174 71 -297 minecraft:air
fill 182 71 -297 184 71 -297 minecraft:air
fill 192 71 -297 194 71 -297 minecraft:air
fill 141 71 -298 145 71 -298 minecraft:air
fill 151 71 -298 155 71 -298 minecraft:air
fill 161 71 -298 165 71 -298 minecraft:air
fill 171 71 -298 175 71 -298 minecraft:air
fill 181 71 -298 185 71 -298 minecraft:air
fill 191 71 -298 195 71 -298 minecraft:air
fill 142 71 -299 144 71 -299 minecraft:air
fill 152 71 -299 154 71 -299 minecraft:air
fill 162 71 -299 164 71 -299 minecraft:air
fill 172 71 -299 174 71 -299 minecraft:air
fill 182 71 -299 184 71 -299 minecraft:air
fill 192 71 -299 194 71 -299 minecraft:air
setblock 143 71 -300 minecraft:air
setblock 153 71 -300 minecraft:air
setblock 163 71 -300 minecraft:air
setblock 173 71 -300 minecraft:air
setblock 183 71 -300 minecraft:air
setblock 193 71 -300 minecraft:air
setblock 143 71 -310 minecraft:air
setblock 153 71 -310 minecraft:air
setblock 163 71 -310 minecraft:air
setblock 173 71 -310 minecraft:air
setblock 183 71 -310 minecraft:air
setblock 193 71 -310 minecraft:air
fill 142 71 -311 144 71 -311 minecraft:air
fill 152 71 -311 154 71 -311 minecraft:air
fill 162 71 -311 164 71 -311 minecraft:air
fill 172 71 -311 174 71 -311 minecraft:air
fill 182 71 -311 184 71 -311 minecraft:air
fill 192 71 -311 194 71 -311 minecraft:air
fill 141 71 -312 145 71 -312 minecraft:air
fill 151 71 -312 155 71 -312 minecraft:air
fill 161 71 -312 165 71 -312 minecraft:air
fill 171 71 -312 175 71 -312 minecraft:air
fill 181 71 -312 185 71 -312 minecraft:air
fill 191 71 -312 195 71 -312 minecraft:air
fill 142 71 -313 144 71 -313 minecraft:air
fill 152 71 -313 154 71 -313 minecraft:air
fill 162 71 -313 164 71 -313 minecraft:air
fill 172 71 -313 174 71 -313 minecraft:air
fill 182 71 -313 184 71 -313 minecraft:air
fill 192 71 -313 194 71 -313 minecraft:air
setblock 143 71 -314 minecraft:air
setblock 153 71 -314 minecraft:air
setblock 163 71 -314 minecraft:air
setblock 173 71 -314 minecraft:air
setblock 183 71 -314 minecraft:air
setblock 193 71 -314 minecraft:air
setblock 142 71 -317 minecraft:grass_block[snowy=false]
fill 142 70 -296 144 70 -296 minecraft:air
fill 152 70 -296 154 70 -296 minecraft:air
fill 162 70 -296 164 70 -296 minecraft:air
fill 172 70 -296 174 70 -296 minecraft:air
fill 182 70 -296 184 70 -296 minecraft:air
fill 192 70 -296 194 70 -296 minecraft:air
fill 141 70 -297 145 70 -297 minecraft:air
fill 151 70 -297 155 70 -297 minecraft:air
fill 161 70 -297 165 70 -297 minecraft:air
fill 171 70 -297 175 70 -297 minecraft:air
fill 181 70 -297 185 70 -297 minecraft:air
fill 191 70 -297 195 70 -297 minecraft:air
fill 141 70 -298 145 70 -298 minecraft:air
fill 151 70 -298 155 70 -298 minecraft:air
fill 161 70 -298 165 70 -298 minecraft:air
fill 171 70 -298 175 70 -298 minecraft:air
fill 181 70 -298 185 70 -298 minecraft:air
fill 191 70 -298 195 70 -298 minecraft:air
fill 141 70 -299 145 70 -299 minecraft:air
fill 151 70 -299 155 70 -299 minecraft:air
fill 161 70 -299 165 70 -299 minecraft:air
fill 171 70 -299 175 70 -299 minecraft:air
fill 181 70 -299 185 70 -299 minecraft:air
fill 191 70 -299 195 70 -299 minecraft:air
fill 142 70 -300 144 70 -300 minecraft:air
fill 152 70 -300 154 70 -300 minecraft:air
fill 162 70 -300 164 70 -300 minecraft:air
fill 172 70 -300 174 70 -300 minecraft:air
fill 182 70 -300 184 70 -300 minecraft:air
fill 192 70 -300 194 70 -300 minecraft:air
fill 142 70 -310 144 70 -310 minecraft:air
fill 152 70 -310 154 70 -310 minecraft:air
fill 162 70 -310 164 70 -310 minecraft:air
fill 172 70 -310 174 70 -310 minecraft:air
fill 182 70 -310 184 70 -310 minecraft:air
fill 192 70 -310 194 70 -310 minecraft:air
fill 141 70 -311 145 70 -311 minecraft:air
fill 151 70 -311 155 70 -311 minecraft:air
fill 161 70 -311 165 70 -311 minecraft:air
fill 171 70 -311 175 70 -311 minecraft:air
fill 181 70 -311 185 70 -311 minecraft:air
fill 191 70 -311 195 70 -311 minecraft:air
fill 141 70 -312 145 70 -312 minecraft:air
fill 151 70 -312 155 70 -312 minecraft:air
fill 161 70 -312 165 70 -312 minecraft:air
fill 171 70 -312 175 70 -312 minecraft:air
fill 181 70 -312 185 70 -312 minecraft:air
fill 191 70 -312 195 70 -312 minecraft:air
fill 141 70 -313 145 70 -313 minecraft:air
fill 151 70 -313 155 70 -313 minecraft:air
fill 161 70 -313 165 70 -313 minecraft:air
fill 171 70 -313 175 70 -313 minecraft:air
fill 181 70 -313 185 70 -313 minecraft:air
fill 191 70 -313 195 70 -313 minecraft:air
fill 142 70 -314 144 70 -314 minecraft:air
fill 152 70 -314 154 70 -314 minecraft:air
fill 162 70 -314 164 70 -314 minecraft:air
fill 172 70 -314 174 70 -314 minecraft:air
fill 182 70 -314 184 70 -314 minecraft:air
fill 192 70 -314 194 70 -314 minecraft:air
fill 139 70 -317 141 70 -317 minecraft:grass_block[snowy=false]
setblock 142 70 -317 minecraft:dirt
fill 140 70 -318 142 70 -318 minecraft:grass_block[snowy=false]
setblock 143 69 -296 minecraft:air
setblock 153 69 -296 minecraft:air
setblock 163 69 -296 minecraft:air
setblock 173 69 -296 minecraft:air
setblock 183 69 -296 minecraft:air
setblock 193 69 -296 minecraft:air
fill 142 69 -297 144 69 -297 minecraft:air
fill 152 69 -297 154 69 -297 minecraft:air
fill 162 69 -297 164 69 -297 minecraft:air
fill 172 69 -297 174 69 -297 minecraft:air
fill 182 69 -297 184 69 -297 minecraft:air
fill 192 69 -297 194 69 -297 minecraft:air
fill 141 69 -298 145 69 -298 minecraft:air
fill 151 69 -298 155 69 -298 minecraft:air
fill 161 69 -298 165 69 -298 minecraft:air
fill 171 69 -298 175 69 -298 minecraft:air
fill 181 69 -298 185 69 -298 minecraft:air
fill 191 69 -298 195 69 -298 minecraft:air
fill 142 69 -299 144 69 -299 minecraft:air
fill 152 69 -299 154 69 -299 minecraft:air
fill 162 69 -299 164 69 -299 minecraft:air
fill 172 69 -299 174 69 -299 minecraft:air
fill 182 69 -299 184 69 -299 minecraft:air
fill 192 69 -299 194 69 -299 minecraft:air
setblock 143 69 -300 minecraft:air
setblock 153 69 -300 minecraft:air
setblock 163 69 -300 minecraft:air
setblock 173 69 -300 minecraft:air
setblock 183 69 -300 minecraft:air
setblock 193 69 -300 minecraft:air
setblock 143 69 -310 minecraft:air
setblock 153 69 -310 minecraft:air
setblock 163 69 -310 minecraft:air
setblock 173 69 -310 minecraft:air
setblock 183 69 -310 minecraft:air
setblock 193 69 -310 minecraft:air
fill 142 69 -311 144 69 -311 minecraft:air
fill 152 69 -311 154 69 -311 minecraft:air
fill 162 69 -311 164 69 -311 minecraft:air
fill 172 69 -311 174 69 -311 minecraft:air
fill 182 69 -311 184 69 -311 minecraft:air
fill 192 69 -311 194 69 -311 minecraft:air
fill 141 69 -312 145 69 -312 minecraft:air
fill 151 69 -312 155 69 -312 minecraft:air
fill 161 69 -312 165 69 -312 minecraft:air
fill 171 69 -312 175 69 -312 minecraft:air
fill 181 69 -312 185 69 -312 minecraft:air
fill 191 69 -312 195 69 -312 minecraft:air
fill 142 69 -313 144 69 -313 minecraft:air
fill 152 69 -313 154 69 -313 minecraft:air
fill 162 69 -313 164 69 -313 minecraft:air
fill 172 69 -313 174 69 -313 minecraft:air
fill 182 69 -313 184 69 -313 minecraft:air
fill 192 69 -313 194 69 -313 minecraft:air
setblock 143 69 -314 minecraft:air
setblock 153 69 -314 minecraft:air
setblock 163 69 -314 minecraft:air
setblock 173 69 -314 minecraft:air
setblock 183 69 -314 minecraft:air
setblock 193 69 -314 minecraft:air
fill 136 69 -317 138 69 -317 minecraft:grass_block[snowy=false]
fill 139 69 -317 142 69 -317 minecraft:dirt
fill 136 69 -318 139 69 -318 minecraft:grass_block[snowy=false]
fill 140 69 -318 142 69 -318 minecraft:dirt
setblock 143 68 -298 minecraft:air
setblock 153 68 -298 minecraft:air
setblock 163 68 -298 minecraft:air
setblock 173 68 -298 minecraft:air
setblock 183 68 -298 minecraft:air
setblock 193 68 -298 minecraft:air
setblock 143 68 -312 minecraft:air
setblock 153 68 -312 minecraft:air
setblock 163 68 -312 minecraft:air
setblock 173 68 -312 minecraft:air
setblock 183 68 -312 minecraft:air
setblock 193 68 -312 minecraft:air
fill 136 68 -317 142 68 -317 minecraft:dirt
fill 136 68 -318 142 68 -318 minecraft:dirt
setblock 143 67 -298 minecraft:air
setblock 153 67 -298 minecraft:air
setblock 163 67 -298 minecraft:air
setblock 173 67 -298 minecraft:air
setblock 183 67 -298 minecraft:air
setblock 193 67 -298 minecraft:air
setblock 143 67 -312 minecraft:air
setblock 153 67 -312 minecraft:air
setblock 163 67 -312 minecraft:air
setblock 173 67 -312 minecraft:air
setblock 183 67 -312 minecraft:air
setblock 193 67 -312 minecraft:air
fill 136 67 -317 142 67 -317 minecraft:dirt
fill 136 67 -318 142 67 -318 minecraft:dirt
setblock 143 66 -298 minecraft:air
setblock 153 66 -298 minecraft:air
setblock 163 66 -298 minecraft:air
setblock 173 66 -298 minecraft:air
setblock 183 66 -298 minecraft:air
setblock 193 66 -298 minecraft:air
setblock 143 66 -312 minecraft:air
setblock 153 66 -312 minecraft:air
setblock 163 66 -312 minecraft:air
setblock 173 66 -312 minecraft:air
setblock 183 66 -312 minecraft:air
setblock 193 66 -312 minecraft:air
fill 136 66 -317 142 66 -317 minecraft:dirt
fill 136 66 -318 142 66 -318 minecraft:dirt
fill 140 65 -255 179 65 -255 minecraft:air
fill 180 65 -255 182 65 -255 regions_unexplored:peat_mud
fill 183 65 -255 186 65 -255 minecraft:air
fill 139 65 -256 177 65 -256 minecraft:air
setblock 178 65 -256 regions_unexplored:grass_sprouts
fill 179 65 -256 182 65 -256 regions_unexplored:peat_mud
fill 138 65 -257 177 65 -257 minecraft:air
fill 178 65 -257 181 65 -257 regions_unexplored:peat_mud
fill 138 65 -258 175 65 -258 minecraft:air
setblock 176 65 -258 regions_unexplored:peat_mud
fill 180 65 -258 181 65 -258 regions_unexplored:peat_mud
fill 137 65 -259 175 65 -259 minecraft:air
fill 136 65 -260 174 65 -260 minecraft:air
fill 182 65 -260 183 65 -260 minecraft:stone
fill 136 65 -261 174 65 -261 minecraft:air
fill 178 65 -261 185 65 -261 minecraft:stone
fill 187 65 -261 189 65 -261 minecraft:air
fill 136 65 -262 173 65 -262 minecraft:air
fill 176 65 -262 181 65 -262 minecraft:stone
fill 182 65 -262 184 65 -262 minecraft:dirt
fill 185 65 -262 189 65 -262 minecraft:air
fill 136 65 -263 173 65 -263 minecraft:air
fill 176 65 -263 182 65 -263 minecraft:stone
fill 183 65 -263 190 65 -263 minecraft:air
fill 136 65 -264 171 65 -264 minecraft:air
fill 175 65 -264 180 65 -264 minecraft:stone
fill 181 65 -264 189 65 -264 minecraft:air
fill 136 65 -265 171 65 -265 minecraft:air
fill 174 65 -265 178 65 -265 minecraft:stone
fill 179 65 -265 187 65 -265 minecraft:air
fill 188 65 -265 190 65 -265 minecraft:stone
fill 136 65 -266 171 65 -266 minecraft:air
setblock 175 65 -266 theurgy:sal_ammoniac_ore
setblock 176 65 -266 minecraft:stone
fill 177 65 -266 185 65 -266 minecraft:air
fill 186 65 -266 192 65 -266 minecraft:stone
fill 136 65 -267 171 65 -267 minecraft:air
fill 174 65 -267 183 65 -267 minecraft:air
setblock 184 65 -267 minecraft:stone
setblock 185 65 -267 minecraft:coal_ore
fill 186 65 -267 192 65 -267 minecraft:stone
fill 136 65 -268 181 65 -268 minecraft:air
fill 182 65 -268 193 65 -268 minecraft:stone
fill 136 65 -269 164 65 -269 minecraft:air
setblock 165 65 -269 minecraft:birch_log[axis=y]
fill 166 65 -269 169 65 -269 minecraft:air
setblock 172 65 -269 minecraft:stone
fill 174 65 -269 175 65 -269 minecraft:air
fill 176 65 -269 177 65 -269 minecraft:stone
setblock 178 65 -269 minecraft:air
fill 179 65 -269 187 65 -269 minecraft:stone
setblock 188 65 -269 minecraft:iron_ore
fill 189 65 -269 194 65 -269 minecraft:stone
fill 136 65 -270 169 65 -270 minecraft:air
fill 171 65 -270 172 65 -270 minecraft:air
setblock 173 65 -270 minecraft:gravel
fill 174 65 -270 194 65 -270 minecraft:stone
fill 136 65 -271 173 65 -271 minecraft:air
setblock 174 65 -271 minecraft:gravel
fill 175 65 -271 195 65 -271 minecraft:stone
fill 136 65 -272 170 65 -272 minecraft:air
fill 171 65 -272 175 65 -272 minecraft:gravel
fill 176 65 -272 194 65 -272 minecraft:stone
fill 195 65 -272 196 65 -272 minecraft:air
fill 136 65 -273 163 65 -273 minecraft:air
setblock 164 65 -273 minecraft:birch_log[axis=y]
fill 165 65 -273 170 65 -273 minecraft:air
fill 171 65 -273 175 65 -273 minecraft:gravel
fill 176 65 -273 193 65 -273 minecraft:stone
fill 194 65 -273 197 65 -273 minecraft:air
fill 136 65 -274 165 65 -274 minecraft:air
fill 167 65 -274 170 65 -274 minecraft:air
fill 171 65 -274 172 65 -274 minecraft:stone
fill 173 65 -274 175 65 -274 minecraft:gravel
fill 176 65 -274 191 65 -274 minecraft:stone
fill 192 65 -274 197 65 -274 minecraft:air
fill 136 65 -275 165 65 -275 minecraft:air
fill 167 65 -275 171 65 -275 minecraft:air
fill 172 65 -275 190 65 -275 minecraft:stone
fill 191 65 -275 198 65 -275 minecraft:air
fill 136 65 -276 165 65 -276 minecraft:air
setblock 167 65 -276 minecraft:stone
fill 168 65 -276 181 65 -276 minecraft:air
fill 182 65 -276 183 65 -276 minecraft:stone
setblock 184 65 -276 minecraft:air
fill 185 65 -276 189 65 -276 minecraft:stone
fill 190 65 -276 199 65 -276 minecraft:air
fill 136 65 -277 165 65 -277 minecraft:air
fill 167 65 -277 184 65 -277 minecraft:air
fill 185 65 -277 187 65 -277 minecraft:stone
fill 188 65 -277 199 65 -277 minecraft:air
fill 136 65 -278 165 65 -278 minecraft:air
setblock 166 65 -278 minecraft:stone
fill 167 65 -278 173 65 -278 minecraft:air
fill 174 65 -278 175 65 -278 minecraft:stone
fill 176 65 -278 185 65 -278 minecraft:air
setblock 186 65 -278 minecraft:stone
fill 187 65 -278 199 65 -278 minecraft:air
fill 136 65 -279 164 65 -279 minecraft:air
fill 166 65 -279 179 65 -279 minecraft:stone
fill 180 65 -279 184 65 -279 minecraft:air
fill 187 65 -279 199 65 -279 minecraft:air
fill 136 65 -280 151 65 -280 minecraft:air
setblock 152 65 -280 minecraft:birch_log[axis=y]
fill 153 65 -280 163 65 -280 minecraft:air
fill 166 65 -280 182 65 -280 minecraft:stone
setblock 183 65 -280 minecraft:air
fill 187 65 -280 199 65 -280 minecraft:air
fill 136 65 -281 163 65 -281 minecraft:air
fill 166 65 -281 183 65 -281 minecraft:stone
setblock 184 65 -281 minecraft:coal_ore
fill 188 65 -281 199 65 -281 minecraft:air
fill 136 65 -282 161 65 -282 minecraft:air
setblock 162 65 -282 minecraft:birch_log[axis=y]
fill 163 65 -282 164 65 -282 minecraft:air
fill 166 65 -282 185 65 -282 minecraft:stone
fill 189 65 -282 199 65 -282 minecraft:air
fill 136 65 -283 164 65 -283 minecraft:air
fill 167 65 -283 186 65 -283 minecraft:stone
fill 190 65 -283 199 65 -283 minecraft:air
fill 136 65 -284 138 65 -284 minecraft:air
fill 141 65 -284 149 65 -284 minecraft:air
setblock 150 65 -284 minecraft:birch_log[axis=y]
fill 151 65 -284 164 65 -284 minecraft:air
fill 167 65 -284 186 65 -284 minecraft:stone
fill 191 65 -284 199 65 -284 minecraft:air
fill 136 65 -285 137 65 -285 minecraft:air
fill 141 65 -285 152 65 -285 minecraft:air
setblock 153 65 -285 minecraft:birch_log[axis=y]
fill 154 65 -285 160 65 -285 minecraft:air
fill 166 65 -285 187 65 -285 minecraft:stone
fill 191 65 -285 199 65 -285 minecraft:air
fill 136 65 -286 137 65 -286 minecraft:air
fill 142 65 -286 156 65 -286 minecraft:air
setblock 157 65 -286 regions_unexplored:grass_sprouts
setblock 158 65 -286 minecraft:air
fill 165 65 -286 183 65 -286 minecraft:stone
setblock 184 65 -286 minecraft:coal_ore
fill 185 65 -286 188 65 -286 minecraft:stone
fill 192 65 -286 199 65 -286 minecraft:air
setblock 136 65 -287 minecraft:air
fill 142 65 -287 157 65 -287 minecraft:air
fill 163 65 -287 182 65 -287 minecraft:stone
fill 183 65 -287 184 65 -287 minecraft:coal_ore
setblock 185 65 -287 minecraft:stone
fill 186 65 -287 187 65 -287 minecraft:dirt
fill 188 65 -287 189 65 -287 minecraft:stone
fill 193 65 -287 199 65 -287 minecraft:air
setblock 136 65 -288 minecraft:birch_log[axis=y]
fill 143 65 -288 145 65 -288 minecraft:air
setblock 146 65 -288 minecraft:birch_log[axis=y]
fill 147 65 -288 151 65 -288 minecraft:air
setblock 152 65 -288 minecraft:birch_log[axis=y]
fill 153 65 -288 157 65 -288 minecraft:air
setblock 162 65 -288 minecraft:stone
fill 163 65 -288 165 65 -288 minecraft:copper_ore
fill 166 65 -288 184 65 -288 minecraft:stone
fill 185 65 -288 187 65 -288 minecraft:dirt
fill 188 65 -288 190 65 -288 minecraft:stone
fill 194 65 -288 199 65 -288 minecraft:air
setblock 136 65 -289 minecraft:short_grass
fill 143 65 -289 153 65 -289 minecraft:air
fill 161 65 -289 162 65 -289 minecraft:stone
fill 163 65 -289 165 65 -289 minecraft:copper_ore
fill 166 65 -289 184 65 -289 minecraft:stone
fill 185 65 -289 188 65 -289 minecraft:dirt
fill 189 65 -289 191 65 -289 minecraft:stone
fill 195 65 -289 199 65 -289 minecraft:air
setblock 136 65 -290 minecraft:air
fill 146 65 -290 150 65 -290 minecraft:air
setblock 161 65 -290 minecraft:stone
fill 164 65 -290 184 65 -290 minecraft:stone
fill 185 65 -290 188 65 -290 minecraft:dirt
fill 189 65 -290 192 65 -290 minecraft:stone
fill 196 65 -290 199 65 -290 minecraft:air
setblock 136 65 -291 minecraft:air
fill 147 65 -291 149 65 -291 minecraft:air
fill 165 65 -291 185 65 -291 minecraft:stone
fill 186 65 -291 188 65 -291 minecraft:dirt
fill 189 65 -291 193 65 -291 minecraft:stone
fill 197 65 -291 199 65 -291 minecraft:air
setblock 136 65 -292 minecraft:air
setblock 148 65 -292 minecraft:air
fill 164 65 -292 184 65 -292 minecraft:stone
fill 185 65 -292 188 65 -292 minecraft:dirt
fill 189 65 -292 193 65 -292 minecraft:stone
setblock 194 65 -292 alltheores:aluminum_ore
fill 198 65 -292 199 65 -292 minecraft:air
setblock 136 65 -293 minecraft:air
setblock 156 65 -293 minecraft:stone
fill 158 65 -293 159 65 -293 minecraft:stone
setblock 164 65 -293 minecraft:air
fill 165 65 -293 185 65 -293 minecraft:stone
fill 186 65 -293 188 65 -293 minecraft:dirt
fill 189 65 -293 193 65 -293 minecraft:stone
fill 194 65 -293 195 65 -293 alltheores:aluminum_ore
fill 136 65 -294 139 65 -294 railcraft:quarried_stone
fill 155 65 -294 159 65 -294 minecraft:stone
setblock 164 65 -294 minecraft:stone
setblock 165 65 -294 minecraft:air
fill 166 65 -294 194 65 -294 minecraft:stone
setblock 195 65 -294 alltheores:aluminum_ore
setblock 196 65 -294 minecraft:stone
fill 136 65 -295 141 65 -295 railcraft:quarried_stone
fill 149 65 -295 159 65 -295 minecraft:stone
fill 163 65 -295 164 65 -295 minecraft:stone
fill 165 65 -295 166 65 -295 minecraft:air
fill 167 65 -295 197 65 -295 minecraft:stone
fill 136 65 -296 142 65 -296 railcraft:quarried_stone
fill 147 65 -296 159 65 -296 minecraft:stone
fill 163 65 -296 164 65 -296 minecraft:stone
fill 165 65 -296 167 65 -296 minecraft:air
fill 168 65 -296 198 65 -296 minecraft:stone
fill 136 65 -297 142 65 -297 railcraft:quarried_stone
fill 147 65 -297 158 65 -297 minecraft:stone
fill 162 65 -297 165 65 -297 minecraft:stone
fill 166 65 -297 169 65 -297 minecraft:air
fill 170 65 -297 199 65 -297 minecraft:stone
fill 136 65 -298 143 65 -298 railcraft:quarried_stone
fill 147 65 -298 157 65 -298 minecraft:stone
fill 161 65 -298 166 65 -298 minecraft:stone
fill 167 65 -298 170 65 -298 minecraft:air
fill 171 65 -298 199 65 -298 minecraft:stone
fill 136 65 -299 143 65 -299 railcraft:quarried_stone
fill 147 65 -299 157 65 -299 minecraft:stone
fill 162 65 -299 167 65 -299 minecraft:stone
fill 168 65 -299 171 65 -299 minecraft:air
fill 172 65 -299 173 65 -299 minecraft:stone
setblock 174 65 -299 minecraft:copper_ore
fill 175 65 -299 199 65 -299 minecraft:stone
fill 136 65 -300 143 65 -300 railcraft:quarried_stone
fill 147 65 -300 157 65 -300 minecraft:stone
fill 162 65 -300 168 65 -300 minecraft:stone
fill 169 65 -300 172 65 -300 minecraft:air
fill 174 65 -300 199 65 -300 minecraft:stone
fill 136 65 -301 143 65 -301 railcraft:quarried_stone
fill 146 65 -301 158 65 -301 minecraft:stone
fill 163 65 -301 169 65 -301 minecraft:stone
fill 170 65 -301 174 65 -301 minecraft:air
fill 176 65 -301 199 65 -301 minecraft:stone
fill 136 65 -302 143 65 -302 railcraft:quarried_stone
fill 144 65 -302 158 65 -302 minecraft:stone
fill 164 65 -302 166 65 -302 railcraft:quarried_stone
fill 167 65 -302 170 65 -302 minecraft:stone
fill 171 65 -302 175 65 -302 minecraft:air
fill 180 65 -302 182 65 -302 minecraft:stone
fill 186 65 -302 188 65 -302 minecraft:stone
fill 191 65 -302 199 65 -302 minecraft:stone
fill 136 65 -303 143 65 -303 railcraft:quarried_stone
fill 144 65 -303 148 65 -303 minecraft:stone
fill 149 65 -303 150 65 -303 theurgy:sal_ammoniac_ore
fill 151 65 -303 158 65 -303 minecraft:stone
fill 159 65 -303 161 65 -303 minecraft:grass_block[snowy=false]
fill 162 65 -303 168 65 -303 railcraft:quarried_stone
fill 169 65 -303 171 65 -303 minecraft:stone
fill 172 65 -303 175 65 -303 minecraft:air
fill 176 65 -303 179 65 -303 minecraft:grass_block[snowy=false]
setblock 180 65 -303 minecraft:stone
fill 181 65 -303 185 65 -303 minecraft:grass_block[snowy=false]
fill 186 65 -303 187 65 -303 minecraft:stone
fill 188 65 -303 192 65 -303 minecraft:grass_block[snowy=false]
fill 193 65 -303 199 65 -303 minecraft:stone
fill 136 65 -304 143 65 -304 railcraft:quarried_stone
fill 144 65 -304 148 65 -304 minecraft:stone
fill 149 65 -304 150 65 -304 theurgy:sal_ammoniac_ore
fill 151 65 -304 159 65 -304 minecraft:stone
setblock 160 65 -304 minecraft:grass_block[snowy=false]
fill 161 65 -304 169 65 -304 railcraft:quarried_stone
fill 170 65 -304 172 65 -304 minecraft:stone
fill 173 65 -304 176 65 -304 minecraft:air
fill 177 65 -304 184 65 -304 minecraft:grass_block[snowy=false]
fill 185 65 -304 187 65 -304 minecraft:stone
fill 188 65 -304 193 65 -304 minecraft:grass_block[snowy=false]
fill 194 65 -304 199 65 -304 minecraft:stone
fill 136 65 -305 142 65 -305 railcraft:quarried_stone
fill 143 65 -305 158 65 -305 minecraft:stone
fill 159 65 -305 160 65 -305 minecraft:coal_ore
fill 161 65 -305 169 65 -305 railcraft:quarried_stone
fill 170 65 -305 172 65 -305 minecraft:stone
fill 173 65 -305 174 65 -305 minecraft:grass_block[snowy=false]
setblock 175 65 -305 minecraft:air
fill 176 65 -305 184 65 -305 minecraft:grass_block[snowy=false]
fill 185 65 -305 189 65 -305 minecraft:stone
fill 190 65 -305 194 65 -305 minecraft:grass_block[snowy=false]
fill 195 65 -305 199 65 -305 minecraft:stone
fill 136 65 -306 142 65 -306 railcraft:quarried_stone
fill 143 65 -306 144 65 -306 minecraft:coal_ore
setblock 145 65 -306 minecraft:copper_ore
fill 146 65 -306 159 65 -306 minecraft:stone
fill 160 65 -306 170 65 -306 railcraft:quarried_stone
fill 171 65 -306 173 65 -306 minecraft:stone
fill 174 65 -306 184 65 -306 minecraft:grass_block[snowy=false]
fill 185 65 -306 190 65 -306 minecraft:stone
fill 191 65 -306 197 65 -306 minecraft:grass_block[snowy=false]
fill 198 65 -306 199 65 -306 minecraft:stone
fill 136 65 -307 141 65 -307 railcraft:quarried_stone
fill 142 65 -307 144 65 -307 minecraft:coal_ore
fill 145 65 -307 146 65 -307 minecraft:copper_ore
fill 147 65 -307 159 65 -307 minecraft:stone
fill 160 65 -307 170 65 -307 railcraft:quarried_stone
fill 171 65 -307 174 65 -307 minecraft:stone
fill 175 65 -307 184 65 -307 minecraft:grass_block[snowy=false]
fill 185 65 -307 186 65 -307 minecraft:stone
fill 187 65 -307 188 65 -307 minecraft:coal_ore
fill 189 65 -307 191 65 -307 minecraft:stone
fill 192 65 -307 199 65 -307 minecraft:grass_block[snowy=false]
fill 136 65 -308 139 65 -308 railcraft:quarried_stone
fill 141 65 -308 142 65 -308 minecraft:stone
fill 143 65 -308 145 65 -308 minecraft:coal_ore
fill 146 65 -308 159 65 -308 minecraft:stone
fill 160 65 -308 170 65 -308 railcraft:quarried_stone
fill 171 65 -308 174 65 -308 minecraft:stone
setblock 175 65 -308 alltheores:peridot_ore
fill 180 65 -308 181 65 -308 minecraft:air
setblock 186 65 -308 minecraft:stone
fill 187 65 -308 188 65 -308 minecraft:coal_ore
fill 189 65 -308 191 65 -308 minecraft:stone
setblock 136 65 -309 railcraft:quarried_stone
fill 140 65 -309 142 65 -309 minecraft:stone
fill 143 65 -309 145 65 -309 minecraft:coal_ore
fill 146 65 -309 160 65 -309 minecraft:stone
fill 161 65 -309 169 65 -309 railcraft:quarried_stone
fill 170 65 -309 175 65 -309 minecraft:stone
setblock 180 65 -309 minecraft:air
setblock 186 65 -309 minecraft:stone
fill 187 65 -309 188 65 -309 minecraft:coal_ore
setblock 189 65 -309 minecraft:stone
fill 140 65 -310 160 65 -310 minecraft:stone
fill 161 65 -310 169 65 -310 railcraft:quarried_stone
fill 170 65 -310 175 65 -310 minecraft:stone
setblock 180 65 -310 minecraft:air
fill 139 65 -311 161 65 -311 minecraft:stone
fill 162 65 -311 168 65 -311 railcraft:quarried_stone
fill 169 65 -311 175 65 -311 minecraft:stone
fill 179 65 -311 180 65 -311 minecraft:air
setblock 139 65 -312 minecraft:stone
fill 140 65 -312 141 65 -312 minecraft:andesite
fill 142 65 -312 163 65 -312 minecraft:stone
fill 164 65 -312 166 65 -312 railcraft:quarried_stone
fill 167 65 -312 174 65 -312 minecraft:stone
fill 179 65 -312 180 65 -312 minecraft:air
fill 191 65 -312 193 65 -312 minecraft:air
fill 139 65 -313 142 65 -313 minecraft:andesite
fill 143 65 -313 174 65 -313 minecraft:stone
fill 178 65 -313 180 65 -313 minecraft:air
fill 184 65 -313 185 65 -313 minecraft:stone
setblock 191 65 -313 minecraft:birch_log[axis=y]
fill 192 65 -313 193 65 -313 minecraft:air
fill 139 65 -314 145 65 -314 minecraft:andesite
fill 146 65 -314 175 65 -314 minecraft:stone
fill 178 65 -314 180 65 -314 minecraft:air
fill 183 65 -314 185 65 -314 minecraft:stone
fill 191 65 -314 193 65 -314 minecraft:air
setblock 139 65 -315 minecraft:stone
fill 140 65 -315 146 65 -315 minecraft:andesite
fill 147 65 -315 175 65 -315 minecraft:stone
fill 177 65 -315 180 65 -315 minecraft:air
setblock 182 65 -315 minecraft:coal_ore
fill 183 65 -315 186 65 -315 minecraft:stone
fill 191 65 -315 192 65 -315 minecraft:air
fill 139 65 -316 141 65 -316 minecraft:stone
fill 142 65 -316 146 65 -316 minecraft:andesite
fill 147 65 -316 171 65 -316 minecraft:stone
fill 172 65 -316 180 65 -316 minecraft:air
setblock 182 65 -316 minecraft:coal_ore
fill 183 65 -316 186 65 -316 minecraft:stone
fill 191 65 -316 192 65 -316 minecraft:air
fill 136 65 -317 138 65 -317 minecraft:dirt
setblock 139 65 -317 minecraft:stone
setblock 140 65 -317 minecraft:coal_ore
setblock 141 65 -317 minecraft:stone
fill 142 65 -317 147 65 -317 minecraft:andesite
fill 148 65 -317 165 65 -317 minecraft:stone
fill 166 65 -317 171 65 -317 minecraft:dirt
fill 172 65 -317 173 65 -317 minecraft:air
fill 174 65 -317 177 65 -317 minecraft:stone
fill 181 65 -317 186 65 -317 minecraft:stone
setblock 192 65 -317 minecraft:air
fill 136 65 -318 139 65 -318 minecraft:dirt
setblock 140 65 -318 minecraft:coal_ore
setblock 141 65 -318 minecraft:stone
fill 142 65 -318 146 65 -318 minecraft:andesite
fill 147 65 -318 148 65 -318 alltheores:zinc_ore
fill 149 65 -318 163 65 -318 minecraft:stone
fill 164 65 -318 171 65 -318 minecraft:dirt
fill 172 65 -318 173 65 -318 minecraft:air
fill 174 65 -318 186 65 -318 minecraft:stone
setblock 192 65 -318 minecraft:air
fill 136 64 -255 178 64 -255 minecraft:air
fill 190 64 -255 199 64 -255 minecraft:air
fill 136 64 -256 177 64 -256 minecraft:air
setblock 192 64 -256 minecraft:air
setblock 193 64 -256 minecraft:tall_grass[half=lower]
fill 194 64 -256 199 64 -256 minecraft:air
fill 136 64 -257 176 64 -257 minecraft:air
setblock 193 64 -257 minecraft:air
fill 195 64 -257 199 64 -257 minecraft:air
fill 136 64 -258 175 64 -258 minecraft:air
setblock 193 64 -258 minecraft:tall_grass[half=lower]
fill 194 64 -258 199 64 -258 minecraft:air
fill 136 64 -259 175 64 -259 minecraft:air
fill 194 64 -259 195 64 -259 minecraft:air
fill 198 64 -259 199 64 -259 minecraft:air
fill 136 64 -260 174 64 -260 minecraft:air
fill 190 64 -260 194 64 -260 minecraft:air
setblock 195 64 -260 minecraft:tall_grass[half=lower]
fill 196 64 -260 199 64 -260 minecraft:air
fill 136 64 -261 173 64 -261 minecraft:air
fill 188 64 -261 193 64 -261 minecraft:air
fill 195 64 -261 199 64 -261 minecraft:air
fill 136 64 -262 173 64 -262 minecraft:air
fill 186 64 -262 194 64 -262 minecraft:air
fill 198 64 -262 199 64 -262 minecraft:air
fill 136 64 -263 172 64 -263 minecraft:air
fill 183 64 -263 194 64 -263 minecraft:air
fill 136 64 -264 171 64 -264 minecraft:air
fill 181 64 -264 189 64 -264 minecraft:air
setblock 195 64 -264 minecraft:air
fill 136 64 -265 171 64 -265 minecraft:air
fill 179 64 -265 187 64 -265 minecraft:air
fill 193 64 -265 196 64 -265 minecraft:air
fill 136 64 -266 171 64 -266 minecraft:air
fill 178 64 -266 184 64 -266 minecraft:air
fill 193 64 -266 196 64 -266 minecraft:air
fill 136 64 -267 170 64 -267 minecraft:air
fill 175 64 -267 182 64 -267 minecraft:air
fill 185 64 -267 190 64 -267 minecraft:air
fill 192 64 -267 197 64 -267 minecraft:air
fill 136 64 -268 164 64 -268 minecraft:air
fill 167 64 -268 170 64 -268 minecraft:air
fill 173 64 -268 180 64 -268 minecraft:air
fill 184 64 -268 190 64 -268 minecraft:air
fill 192 64 -268 199 64 -268 minecraft:air
fill 136 64 -269 163 64 -269 minecraft:air
fill 166 64 -269 170 64 -269 minecraft:air
fill 175 64 -269 176 64 -269 minecraft:air
fill 195 64 -269 199 64 -269 minecraft:air
fill 136 64 -270 162 64 -270 minecraft:air
fill 164 64 -270 172 64 -270 minecraft:air
fill 198 64 -270 199 64 -270 minecraft:air
fill 136 64 -271 173 64 -271 minecraft:air
fill 136 64 -272 169 64 -272 minecraft:air
fill 136 64 -273 159 64 -273 minecraft:air
fill 161 64 -273 163 64 -273 minecraft:air
fill 165 64 -273 170 64 -273 minecraft:air
fill 136 64 -274 164 64 -274 minecraft:air
fill 167 64 -274 171 64 -274 minecraft:air
fill 136 64 -275 164 64 -275 minecraft:air
fill 167 64 -275 171 64 -275 minecraft:air
fill 136 64 -276 164 64 -276 minecraft:air
fill 167 64 -276 181 64 -276 minecraft:air
fill 136 64 -277 183 64 -277 minecraft:air
fill 136 64 -278 165 64 -278 minecraft:air
fill 167 64 -278 185 64 -278 minecraft:air
fill 136 64 -279 152 64 -279 minecraft:air
setblock 153 64 -279 minecraft:short_grass
setblock 154 64 -279 minecraft:air
setblock 155 64 -279 regions_unexplored:grass_sprouts
fill 156 64 -279 163 64 -279 minecraft:air
fill 180 64 -279 186 64 -279 minecraft:air
fill 136 64 -280 150 64 -280 minecraft:air
setblock 151 64 -280 regions_unexplored:grass_sprouts
setblock 153 64 -280 minecraft:air
setblock 154 64 -280 minecraft:short_grass
fill 155 64 -280 157 64 -280 minecraft:air
setblock 158 64 -280 regions_unexplored:grass_sprouts
fill 159 64 -280 162 64 -280 minecraft:air
fill 184 64 -280 186 64 -280 minecraft:air
fill 136 64 -281 152 64 -281 minecraft:air
setblock 153 64 -281 minecraft:short_grass
fill 154 64 -281 162 64 -281 minecraft:air
fill 136 64 -282 155 64 -282 minecraft:air
setblock 156 64 -282 minecraft:short_grass
fill 157 64 -282 158 64 -282 minecraft:air
setblock 159 64 -282 regions_unexplored:grass_sprouts
fill 160 64 -282 161 64 -282 minecraft:air
fill 136 64 -283 149 64 -283 minecraft:air
setblock 150 64 -283 regions_unexplored:grass_sprouts
fill 151 64 -283 152 64 -283 minecraft:air
setblock 153 64 -283 regions_unexplored:grass_sprouts
fill 154 64 -283 159 64 -283 minecraft:air
setblock 160 64 -283 minecraft:short_grass
setblock 161 64 -283 minecraft:air
setblock 136 64 -284 minecraft:air
fill 142 64 -284 149 64 -284 minecraft:air
fill 151 64 -284 160 64 -284 minecraft:air
fill 142 64 -285 147 64 -285 minecraft:air
setblock 148 64 -285 minecraft:short_grass
fill 149 64 -285 152 64 -285 minecraft:air
fill 154 64 -285 155 64 -285 minecraft:air
setblock 156 64 -285 regions_unexplored:grass_sprouts
setblock 157 64 -285 minecraft:air
fill 143 64 -286 156 64 -286 minecraft:air
fill 143 64 -287 155 64 -287 minecraft:air
fill 143 64 -288 145 64 -288 minecraft:air
fill 147 64 -288 151 64 -288 minecraft:air
fill 153 64 -288 155 64 -288 minecraft:air
fill 144 64 -289 149 64 -289 minecraft:air
setblock 150 64 -289 regions_unexplored:grass_sprouts
fill 147 64 -290 149 64 -290 minecraft:air
setblock 148 64 -291 minecraft:short_grass
setblock 148 64 -292 minecraft:air
setblock 163 64 -292 minecraft:air
fill 163 64 -293 164 64 -293 minecraft:air
fill 164 64 -294 165 64 -294 minecraft:air
fill 164 64 -295 166 64 -295 minecraft:air
fill 165 64 -296 167 64 -296 minecraft:air
fill 166 64 -297 168 64 -297 minecraft:air
fill 167 64 -298 170 64 -298 minecraft:air
fill 168 64 -299 171 64 -299 minecraft:air
fill 169 64 -300 172 64 -300 minecraft:air
fill 170 64 -301 174 64 -301 minecraft:air
fill 171 64 -302 174 64 -302 minecraft:air
fill 172 64 -303 174 64 -303 minecraft:air
setblock 174 64 -304 minecraft:air
setblock 180 64 -312 minecraft:air
setblock 180 64 -313 minecraft:air
setblock 180 64 -314 minecraft:air
fill 178 64 -315 180 64 -315 minecraft:air
fill 172 64 -316 180 64 -316 minecraft:air
fill 172 64 -317 174 64 -317 minecraft:air
fill 172 64 -318 173 64 -318 minecraft:air
fill 136 63 -255 177 63 -255 minecraft:air
fill 193 63 -255 199 63 -255 minecraft:air
fill 136 63 -256 175 63 -256 minecraft:air
setblock 176 63 -256 minecraft:short_grass
fill 194 63 -256 199 63 -256 minecraft:air
fill 136 63 -257 175 63 -257 minecraft:air
fill 195 63 -257 199 63 -257 minecraft:air
fill 136 63 -258 173 63 -258 minecraft:air
setblock 175 63 -258 minecraft:short_grass
fill 195 63 -258 199 63 -258 minecraft:air
fill 136 63 -259 174 63 -259 minecraft:air
fill 198 63 -259 199 63 -259 minecraft:air
fill 136 63 -260 173 63 -260 minecraft:air
fill 197 63 -260 199 63 -260 minecraft:air
fill 136 63 -261 173 63 -261 minecraft:air
fill 189 63 -261 193 63 -261 minecraft:air
fill 136 63 -262 172 63 -262 minecraft:air
fill 188 63 -262 194 63 -262 minecraft:air
fill 136 63 -263 170 63 -263 minecraft:air
fill 185 63 -263 190 63 -263 minecraft:air
fill 192 63 -263 193 63 -263 minecraft:air
fill 136 63 -264 169 63 -264 minecraft:air
fill 183 63 -264 187 63 -264 minecraft:air
setblock 195 63 -264 minecraft:air
fill 136 63 -265 169 63 -265 minecraft:air
fill 181 63 -265 185 63 -265 minecraft:air
fill 194 63 -265 196 63 -265 minecraft:air
fill 136 63 -266 169 63 -266 minecraft:air
fill 180 63 -266 182 63 -266 minecraft:air
fill 188 63 -266 190 63 -266 minecraft:air
fill 193 63 -266 196 63 -266 minecraft:air
fill 136 63 -267 168 63 -267 minecraft:air
fill 177 63 -267 181 63 -267 minecraft:air
fill 184 63 -267 198 63 -267 minecraft:air
fill 136 63 -268 164 63 -268 minecraft:air
fill 167 63 -268 168 63 -268 minecraft:air
fill 175 63 -268 190 63 -268 minecraft:air
fill 192 63 -268 199 63 -268 minecraft:air
fill 136 63 -269 163 63 -269 minecraft:air
fill 168 63 -269 170 63 -269 minecraft:air
fill 177 63 -269 186 63 -269 minecraft:air
fill 193 63 -269 199 63 -269 minecraft:air
fill 136 63 -270 162 63 -270 minecraft:air
fill 164 63 -270 176 63 -270 minecraft:air
setblock 179 63 -270 minecraft:air
fill 198 63 -270 199 63 -270 minecraft:air
fill 136 63 -271 170 63 -271 minecraft:air
fill 172 63 -271 176 63 -271 minecraft:air
fill 136 63 -272 169 63 -272 minecraft:air
setblock 173 63 -272 minecraft:air
fill 136 63 -273 159 63 -273 minecraft:air
fill 161 63 -273 162 63 -273 minecraft:air
fill 166 63 -273 169 63 -273 minecraft:air
fill 136 63 -274 159 63 -274 minecraft:air
setblock 161 63 -274 minecraft:air
fill 167 63 -274 171 63 -274 minecraft:air
fill 136 63 -275 158 63 -275 minecraft:air
setblock 159 63 -275 minecraft:short_grass
setblock 160 63 -275 minecraft:air
fill 167 63 -275 171 63 -275 minecraft:air
setblock 174 63 -275 minecraft:air
fill 136 63 -276 153 63 -276 minecraft:air
setblock 154 63 -276 regions_unexplored:grass_sprouts
fill 155 63 -276 156 63 -276 minecraft:air
fill 167 63 -276 180 63 -276 minecraft:air
fill 136 63 -277 151 63 -277 minecraft:air
setblock 152 63 -277 regions_unexplored:grass_sprouts
setblock 153 63 -277 minecraft:air
setblock 160 63 -277 minecraft:air
fill 162 63 -277 182 63 -277 minecraft:air
fill 136 63 -278 151 63 -278 minecraft:air
fill 158 63 -278 160 63 -278 minecraft:air
fill 162 63 -278 165 63 -278 minecraft:air
fill 167 63 -278 184 63 -278 minecraft:air
fill 136 63 -279 150 63 -279 minecraft:air
setblock 156 63 -279 regions_unexplored:grass_sprouts
fill 157 63 -279 160 63 -279 minecraft:air
fill 182 63 -279 184 63 -279 minecraft:air
fill 136 63 -280 149 63 -280 minecraft:air
setblock 150 63 -280 regions_unexplored:grass_sprouts
fill 155 63 -280 157 63 -280 minecraft:air
fill 136 63 -281 149 63 -281 minecraft:air
fill 136 63 -282 149 63 -282 minecraft:air
fill 136 63 -283 148 63 -283 minecraft:air
fill 136 63 -284 137 63 -284 minecraft:air
fill 143 63 -284 147 63 -284 minecraft:air
setblock 136 63 -285 minecraft:air
fill 143 63 -285 146 63 -285 minecraft:air
setblock 136 63 -286 minecraft:air
fill 144 63 -286 147 63 -286 minecraft:air
fill 144 63 -287 145 63 -287 minecraft:air
fill 147 63 -287 148 63 -287 minecraft:air
fill 147 63 -288 149 63 -288 minecraft:air
fill 147 63 -289 149 63 -289 minecraft:air
fill 148 63 -290 149 63 -290 minecraft:air
setblock 150 63 -291 minecraft:air
setblock 192 63 -292 minecraft:air
setblock 164 63 -293 minecraft:air
setblock 192 63 -293 minecraft:air
fill 164 63 -294 165 63 -294 minecraft:air
setblock 192 63 -294 minecraft:air
fill 164 63 -295 166 63 -295 minecraft:air
setblock 192 63 -295 minecraft:air
fill 165 63 -296 167 63 -296 minecraft:air
setblock 192 63 -296 minecraft:air
fill 166 63 -297 168 63 -297 minecraft:air
fill 167 63 -298 169 63 -298 minecraft:air
fill 168 63 -299 170 63 -299 minecraft:air
fill 168 63 -300 171 63 -300 minecraft:air
fill 170 63 -301 173 63 -301 minecraft:air
fill 171 63 -302 174 63 -302 minecraft:air
fill 172 63 -303 174 63 -303 minecraft:air
fill 173 63 -304 174 63 -304 minecraft:air
setblock 174 63 -305 minecraft:air
fill 136 62 -255 149 62 -255 minecraft:air
fill 151 62 -255 177 62 -255 minecraft:water[level=0]
fill 194 62 -255 199 62 -255 minecraft:water[level=0]
fill 136 62 -256 149 62 -256 minecraft:air
fill 151 62 -256 175 62 -256 minecraft:water[level=0]
setblock 195 62 -256 minecraft:water[level=0]
setblock 196 62 -256 minecraft:tall_seagrass[half=upper]
fill 197 62 -256 199 62 -256 minecraft:water[level=0]
fill 136 62 -257 149 62 -257 minecraft:air
fill 151 62 -257 175 62 -257 minecraft:water[level=0]
fill 196 62 -257 199 62 -257 minecraft:water[level=0]
fill 136 62 -258 149 62 -258 minecraft:air
fill 151 62 -258 173 62 -258 minecraft:water[level=0]
fill 196 62 -258 199 62 -258 minecraft:water[level=0]
fill 136 62 -259 149 62 -259 minecraft:air
fill 151 62 -259 173 62 -259 minecraft:water[level=0]
fill 198 62 -259 199 62 -259 minecraft:water[level=0]
fill 136 62 -260 149 62 -260 minecraft:air
fill 151 62 -260 173 62 -260 minecraft:water[level=0]
fill 136 62 -261 149 62 -261 minecraft:air
fill 151 62 -261 172 62 -261 minecraft:water[level=0]
fill 136 62 -262 149 62 -262 minecraft:air
fill 151 62 -262 170 62 -262 minecraft:water[level=0]
fill 136 62 -263 149 62 -263 minecraft:air
fill 151 62 -263 169 62 -263 minecraft:water[level=0]
fill 136 62 -264 149 62 -264 minecraft:air
fill 151 62 -264 168 62 -264 minecraft:water[level=0]
fill 136 62 -265 149 62 -265 minecraft:air
fill 151 62 -265 167 62 -265 minecraft:water[level=0]
fill 194 62 -265 195 62 -265 minecraft:water[level=0]
fill 136 62 -266 149 62 -266 minecraft:air
fill 151 62 -266 166 62 -266 minecraft:water[level=0]
fill 194 62 -266 196 62 -266 minecraft:water[level=0]
fill 136 62 -267 149 62 -267 minecraft:air
fill 151 62 -267 164 62 -267 minecraft:water[level=0]
fill 179 62 -267 190 62 -267 minecraft:water[level=0]
fill 192 62 -267 197 62 -267 minecraft:water[level=0]
fill 136 62 -268 149 62 -268 minecraft:air
fill 151 62 -268 158 62 -268 minecraft:water[level=0]
setblock 159 62 -268 minecraft:tall_seagrass[half=upper]
fill 160 62 -268 163 62 -268 minecraft:water[level=0]
fill 176 62 -268 190 62 -268 minecraft:water[level=0]
fill 192 62 -268 199 62 -268 minecraft:water[level=0]
fill 136 62 -269 149 62 -269 minecraft:air
fill 151 62 -269 162 62 -269 minecraft:water[level=0]
fill 178 62 -269 186 62 -269 minecraft:water[level=0]
fill 195 62 -269 199 62 -269 minecraft:water[level=0]
fill 136 62 -270 149 62 -270 minecraft:air
fill 151 62 -270 159 62 -270 minecraft:water[level=0]
fill 160 62 -270 161 62 -270 minecraft:seagrass
setblock 162 62 -270 minecraft:water[level=0]
fill 164 62 -270 167 62 -270 minecraft:water[level=0]
fill 169 62 -270 170 62 -270 minecraft:water[level=0]
fill 173 62 -270 176 62 -270 minecraft:water[level=0]
fill 178 62 -270 182 62 -270 minecraft:water[level=0]
fill 198 62 -270 199 62 -270 minecraft:water[level=0]
fill 136 62 -271 149 62 -271 minecraft:air
fill 151 62 -271 168 62 -271 minecraft:water[level=0]
fill 173 62 -271 176 62 -271 minecraft:water[level=0]
fill 136 62 -272 149 62 -272 minecraft:air
fill 151 62 -272 158 62 -272 minecraft:water[level=0]
fill 161 62 -272 162 62 -272 minecraft:water[level=0]
fill 164 62 -272 168 62 -272 minecraft:water[level=0]
fill 173 62 -272 175 62 -272 minecraft:water[level=0]
fill 136 62 -273 149 62 -273 minecraft:air
fill 151 62 -273 156 62 -273 minecraft:water[level=0]
fill 167 62 -273 169 62 -273 minecraft:water[level=0]
fill 136 62 -274 149 62 -274 minecraft:air
setblock 151 62 -274 minecraft:water[level=0]
fill 167 62 -274 170 62 -274 minecraft:water[level=0]
fill 136 62 -275 149 62 -275 minecraft:air
fill 168 62 -275 170 62 -275 minecraft:water[level=0]
fill 136 62 -276 149 62 -276 minecraft:air
fill 168 62 -276 177 62 -276 minecraft:water[level=0]
fill 136 62 -277 149 62 -277 minecraft:air
setblock 164 62 -277 minecraft:water[level=0]
fill 167 62 -277 179 62 -277 minecraft:water[level=0]
fill 136 62 -278 149 62 -278 minecraft:air
fill 167 62 -278 168 62 -278 minecraft:water[level=0]
fill 170 62 -278 174 62 -278 minecraft:water[level=0]
fill 176 62 -278 177 62 -278 minecraft:water[level=0]
fill 136 62 -279 149 62 -279 minecraft:air
fill 136 62 -280 149 62 -280 minecraft:air
fill 136 62 -281 149 62 -281 minecraft:air
fill 136 62 -282 149 62 -282 minecraft:air
fill 136 62 -283 148 62 -283 minecraft:air
fill 136 62 -285 137 62 -285 minecraft:water[level=0]
setblock 136 62 -286 minecraft:water[level=0]
setblock 193 62 -287 minecraft:water[level=0]
fill 147 62 -288 149 62 -288 minecraft:water[level=0]
setblock 193 62 -288 minecraft:water[level=0]
fill 148 62 -289 149 62 -289 minecraft:water[level=0]
fill 193 62 -289 194 62 -289 minecraft:water[level=0]
fill 148 62 -290 150 62 -290 minecraft:water[level=0]
fill 193 62 -290 194 62 -290 minecraft:water[level=0]
fill 149 62 -291 150 62 -291 minecraft:water[level=0]
fill 193 62 -291 194 62 -291 minecraft:water[level=0]
fill 149 62 -292 150 62 -292 minecraft:water[level=0]
fill 193 62 -292 194 62 -292 minecraft:water[level=0]
setblock 164 62 -293 minecraft:water[level=0]
fill 193 62 -293 194 62 -293 minecraft:water[level=0]
fill 164 62 -294 165 62 -294 minecraft:water[level=0]
fill 193 62 -294 194 62 -294 minecraft:water[level=0]
fill 164 62 -295 166 62 -295 minecraft:water[level=0]
fill 193 62 -295 194 62 -295 minecraft:water[level=0]
fill 164 62 -296 167 62 -296 minecraft:water[level=0]
fill 193 62 -296 194 62 -296 minecraft:water[level=0]
fill 165 62 -297 167 62 -297 minecraft:water[level=0]
fill 193 62 -297 194 62 -297 minecraft:water[level=0]
fill 166 62 -298 169 62 -298 minecraft:water[level=0]
setblock 193 62 -298 minecraft:water[level=0]
fill 167 62 -299 170 62 -299 minecraft:water[level=0]
fill 168 62 -300 171 62 -300 minecraft:water[level=0]
fill 169 62 -301 172 62 -301 minecraft:water[level=0]
fill 170 62 -302 173 62 -302 minecraft:water[level=0]
fill 171 62 -303 173 62 -303 minecraft:water[level=0]
fill 172 62 -304 173 62 -304 minecraft:water[level=0]
fill 136 61 -255 149 61 -255 minecraft:air
fill 151 61 -255 176 61 -255 minecraft:water[level=0]
setblock 196 61 -255 minecraft:seagrass
fill 197 61 -255 199 61 -255 minecraft:water[level=0]
fill 136 61 -256 149 61 -256 minecraft:air
fill 151 61 -256 175 61 -256 minecraft:water[level=0]
setblock 196 61 -256 minecraft:tall_seagrass[half=lower]
setblock 197 61 -256 minecraft:water[level=0]
setblock 198 61 -256 minecraft:tall_seagrass[half=upper]
setblock 199 61 -256 minecraft:water[level=0]
fill 136 61 -257 149 61 -257 minecraft:air
fill 151 61 -257 174 61 -257 minecraft:water[level=0]
fill 197 61 -257 199 61 -257 minecraft:water[level=0]
fill 136 61 -258 149 61 -258 minecraft:air
fill 151 61 -258 173 61 -258 minecraft:water[level=0]
fill 198 61 -258 199 61 -258 minecraft:water[level=0]
fill 136 61 -259 149 61 -259 minecraft:air
fill 151 61 -259 173 61 -259 minecraft:water[level=0]
fill 198 61 -259 199 61 -259 minecraft:water[level=0]
fill 136 61 -260 149 61 -260 minecraft:air
fill 151 61 -260 172 61 -260 minecraft:water[level=0]
fill 136 61 -261 149 61 -261 minecraft:air
fill 151 61 -261 169 61 -261 minecraft:water[level=0]
fill 136 61 -262 149 61 -262 minecraft:air
fill 151 61 -262 168 61 -262 minecraft:water[level=0]
fill 136 61 -263 149 61 -263 minecraft:air
fill 151 61 -263 166 61 -263 minecraft:water[level=0]
fill 136 61 -264 149 61 -264 minecraft:air
fill 151 61 -264 164 61 -264 minecraft:water[level=0]
fill 136 61 -265 149 61 -265 minecraft:air
fill 151 61 -265 163 61 -265 minecraft:water[level=0]
fill 136 61 -266 149 61 -266 minecraft:air
fill 151 61 -266 162 61 -266 minecraft:water[level=0]
fill 136 61 -267 149 61 -267 minecraft:air
fill 151 61 -267 159 61 -267 minecraft:water[level=0]
setblock 160 61 -267 minecraft:seagrass
setblock 161 61 -267 minecraft:water[level=0]
fill 182 61 -267 186 61 -267 minecraft:water[level=0]
fill 194 61 -267 195 61 -267 minecraft:water[level=0]
fill 136 61 -268 149 61 -268 minecraft:air
fill 151 61 -268 158 61 -268 minecraft:water[level=0]
setblock 159 61 -268 minecraft:tall_seagrass[half=lower]
setblock 160 61 -268 minecraft:water[level=0]
fill 179 61 -268 186 61 -268 minecraft:water[level=0]
fill 196 61 -268 197 61 -268 minecraft:water[level=0]
fill 136 61 -269 149 61 -269 minecraft:air
fill 151 61 -269 159 61 -269 minecraft:water[level=0]
fill 178 61 -269 187 61 -269 minecraft:water[level=0]
setblock 198 61 -269 minecraft:water[level=0]
fill 136 61 -270 149 61 -270 minecraft:air
fill 151 61 -270 158 61 -270 minecraft:water[level=0]
fill 173 61 -270 176 61 -270 minecraft:water[level=0]
fill 178 61 -270 181 61 -270 minecraft:water[level=0]
setblock 183 61 -270 minecraft:water[level=0]
fill 136 61 -271 149 61 -271 minecraft:air
fill 151 61 -271 156 61 -271 minecraft:water[level=0]
fill 174 61 -271 176 61 -271 minecraft:water[level=0]
fill 136 61 -272 149 61 -272 minecraft:air
setblock 168 61 -272 minecraft:water[level=0]
fill 136 61 -273 149 61 -273 minecraft:air
fill 168 61 -273 169 61 -273 minecraft:water[level=0]
fill 136 61 -274 149 61 -274 minecraft:air
fill 168 61 -274 169 61 -274 minecraft:water[level=0]
fill 136 61 -275 149 61 -275 minecraft:air
fill 168 61 -275 170 61 -275 minecraft:water[level=0]
fill 136 61 -276 149 61 -276 minecraft:air
fill 168 61 -276 170 61 -276 minecraft:water[level=0]
fill 136 61 -277 149 61 -277 minecraft:air
setblock 169 61 -277 minecraft:water[level=0]
fill 136 61 -278 149 61 -278 minecraft:air
fill 136 61 -279 149 61 -279 minecraft:air
fill 136 61 -280 149 61 -280 minecraft:air
fill 136 61 -281 149 61 -281 minecraft:air
fill 136 61 -282 149 61 -282 minecraft:air
fill 136 61 -283 148 61 -283 minecraft:air
setblock 193 61 -283 minecraft:water[level=0]
fill 193 61 -284 194 61 -284 minecraft:water[level=0]
fill 136 61 -285 137 61 -285 minecraft:water[level=0]
fill 193 61 -285 194 61 -285 minecraft:water[level=0]
setblock 136 61 -286 minecraft:water[level=0]
fill 193 61 -286 195 61 -286 minecraft:water[level=0]
setblock 136 61 -287 minecraft:water[level=0]
fill 193 61 -287 195 61 -287 minecraft:water[level=0]
fill 193 61 -288 195 61 -288 minecraft:water[level=0]
fill 193 61 -289 195 61 -289 minecraft:water[level=0]
fill 149 61 -290 150 61 -290 minecraft:water[level=0]
fill 193 61 -290 195 61 -290 minecraft:water[level=0]
fill 149 61 -291 151 61 -291 minecraft:water[level=0]
fill 193 61 -291 195 61 -291 minecraft:water[level=0]
fill 148 61 -292 150 61 -292 minecraft:water[level=0]
fill 193 61 -292 195 61 -292 minecraft:water[level=0]
fill 148 61 -293 150 61 -293 minecraft:water[level=0]
fill 193 61 -293 195 61 -293 minecraft:water[level=0]
setblock 164 61 -294 minecraft:water[level=0]
fill 193 61 -294 195 61 -294 minecraft:water[level=0]
fill 164 61 -295 165 61 -295 minecraft:water[level=0]
fill 193 61 -295 195 61 -295 minecraft:water[level=0]
fill 164 61 -296 166 61 -296 minecraft:water[level=0]
fill 193 61 -296 195 61 -296 minecraft:water[level=0]
fill 165 61 -297 167 61 -297 minecraft:water[level=0]
fill 194 61 -297 196 61 -297 minecraft:water[level=0]
fill 166 61 -298 168 61 -298 minecraft:water[level=0]
fill 194 61 -298 195 61 -298 minecraft:water[level=0]
fill 167 61 -299 169 61 -299 minecraft:water[level=0]
setblock 194 61 -299 minecraft:water[level=0]
fill 168 61 -300 170 61 -300 minecraft:water[level=0]
fill 169 61 -301 171 61 -301 minecraft:water[level=0]
fill 170 61 -302 173 61 -302 minecraft:water[level=0]
fill 171 61 -303 173 61 -303 minecraft:water[level=0]
fill 172 61 -304 173 61 -304 minecraft:water[level=0]
setblock 173 61 -305 minecraft:water[level=0]
fill 136 60 -255 149 60 -255 minecraft:air
fill 151 60 -255 175 60 -255 minecraft:water[level=0]
fill 197 60 -255 199 60 -255 minecraft:water[level=0]
fill 136 60 -256 149 60 -256 minecraft:air
fill 151 60 -256 174 60 -256 minecraft:water[level=0]
setblock 197 60 -256 minecraft:seagrass
setblock 198 60 -256 minecraft:tall_seagrass[half=lower]
setblock 199 60 -256 minecraft:water[level=0]
fill 136 60 -257 149 60 -257 minecraft:air
fill 151 60 -257 174 60 -257 minecraft:water[level=0]
setblock 199 60 -257 minecraft:water[level=0]
fill 136 60 -258 149 60 -258 minecraft:air
fill 151 60 -258 173 60 -258 minecraft:water[level=0]
setblock 199 60 -258 minecraft:seagrass
fill 136 60 -259 149 60 -259 minecraft:air
fill 151 60 -259 172 60 -259 minecraft:water[level=0]
setblock 199 60 -259 minecraft:water[level=0]
fill 136 60 -260 149 60 -260 minecraft:air
fill 151 60 -260 169 60 -260 minecraft:water[level=0]
fill 198 60 -260 199 60 -260 minecraft:water[level=0]
fill 136 60 -261 149 60 -261 minecraft:air
fill 151 60 -261 167 60 -261 minecraft:water[level=0]
setblock 197 60 -261 minecraft:water[level=0]
fill 136 60 -262 149 60 -262 minecraft:air
fill 151 60 -262 165 60 -262 minecraft:water[level=0]
fill 136 60 -263 149 60 -263 minecraft:air
fill 151 60 -263 163 60 -263 minecraft:water[level=0]
fill 136 60 -264 149 60 -264 minecraft:air
fill 151 60 -264 162 60 -264 minecraft:water[level=0]
fill 136 60 -265 149 60 -265 minecraft:air
fill 151 60 -265 161 60 -265 minecraft:water[level=0]
fill 136 60 -266 149 60 -266 minecraft:air
fill 151 60 -266 160 60 -266 minecraft:water[level=0]
fill 136 60 -267 149 60 -267 minecraft:air
fill 151 60 -267 159 60 -267 minecraft:water[level=0]
fill 185 60 -267 188 60 -267 minecraft:water[level=0]
fill 136 60 -268 149 60 -268 minecraft:air
fill 151 60 -268 155 60 -268 minecraft:water[level=0]
setblock 156 60 -268 minecraft:tall_seagrass[half=upper]
fill 157 60 -268 158 60 -268 minecraft:water[level=0]
fill 181 60 -268 189 60 -268 minecraft:water[level=0]
fill 136 60 -269 149 60 -269 minecraft:air
fill 151 60 -269 156 60 -269 minecraft:water[level=0]
fill 183 60 -269 189 60 -269 minecraft:water[level=0]
fill 136 60 -270 149 60 -270 minecraft:air
setblock 151 60 -270 minecraft:water[level=0]
fill 185 60 -270 190 60 -270 minecraft:water[level=0]
fill 136 60 -271 149 60 -271 minecraft:air
fill 136 60 -272 149 60 -272 minecraft:air
fill 136 60 -273 149 60 -273 minecraft:air
fill 136 60 -274 149 60 -274 minecraft:air
fill 136 60 -275 149 60 -275 minecraft:air
fill 136 60 -276 149 60 -276 minecraft:air
fill 136 60 -277 149 60 -277 minecraft:air
fill 136 60 -278 149 60 -278 minecraft:air
fill 136 60 -279 149 60 -279 minecraft:air
setblock 193 60 -279 minecraft:water[level=0]
fill 136 60 -280 149 60 -280 minecraft:air
fill 193 60 -280 194 60 -280 minecraft:water[level=0]
fill 136 60 -281 149 60 -281 minecraft:air
fill 193 60 -281 194 60 -281 minecraft:water[level=0]
fill 136 60 -282 149 60 -282 minecraft:air
fill 193 60 -282 195 60 -282 minecraft:water[level=0]
fill 136 60 -283 148 60 -283 minecraft:air
fill 193 60 -283 195 60 -283 minecraft:water[level=0]
fill 193 60 -284 195 60 -284 minecraft:water[level=0]
fill 136 60 -285 137 60 -285 minecraft:water[level=0]
fill 193 60 -285 195 60 -285 minecraft:water[level=0]
fill 136 60 -286 137 60 -286 minecraft:water[level=0]
fill 193 60 -286 195 60 -286 minecraft:water[level=0]
setblock 136 60 -287 minecraft:water[level=0]
fill 193 60 -287 195 60 -287 minecraft:water[level=0]
fill 194 60 -288 195 60 -288 minecraft:water[level=0]
fill 194 60 -289 195 60 -289 minecraft:water[level=0]
fill 149 60 -290 150 60 -290 minecraft:water[level=0]
fill 194 60 -290 195 60 -290 minecraft:water[level=0]
fill 149 60 -291 150 60 -291 minecraft:water[level=0]
fill 194 60 -291 195 60 -291 minecraft:water[level=0]
fill 148 60 -292 150 60 -292 minecraft:water[level=0]
fill 194 60 -292 195 60 -292 minecraft:water[level=0]
fill 147 60 -293 150 60 -293 minecraft:water[level=0]
fill 194 60 -293 195 60 -293 minecraft:water[level=0]
fill 147 60 -294 149 60 -294 minecraft:water[level=0]
setblock 164 60 -294 minecraft:water[level=0]
fill 194 60 -294 195 60 -294 minecraft:water[level=0]
fill 164 60 -295 165 60 -295 minecraft:water[level=0]
fill 194 60 -295 196 60 -295 minecraft:water[level=0]
fill 164 60 -296 166 60 -296 minecraft:water[level=0]
fill 194 60 -296 196 60 -296 minecraft:water[level=0]
fill 165 60 -297 167 60 -297 minecraft:water[level=0]
fill 194 60 -297 196 60 -297 minecraft:water[level=0]
fill 166 60 -298 168 60 -298 minecraft:water[level=0]
fill 195 60 -298 197 60 -298 minecraft:water[level=0]
fill 167 60 -299 169 60 -299 minecraft:water[level=0]
fill 195 60 -299 197 60 -299 minecraft:water[level=0]
fill 168 60 -300 170 60 -300 minecraft:water[level=0]
fill 168 60 -301 171 60 -301 minecraft:water[level=0]
fill 169 60 -302 172 60 -302 minecraft:water[level=0]
fill 170 60 -303 173 60 -303 minecraft:water[level=0]
fill 172 60 -304 173 60 -304 minecraft:water[level=0]
setblock 172 60 -305 minecraft:water[level=0]
fill 136 59 -255 149 59 -255 minecraft:air
fill 151 59 -255 175 59 -255 minecraft:water[level=0]
fill 198 59 -255 199 59 -255 minecraft:water[level=0]
fill 136 59 -256 149 59 -256 minecraft:air
fill 151 59 -256 174 59 -256 minecraft:water[level=0]
setblock 199 59 -256 minecraft:water[level=0]
fill 136 59 -257 149 59 -257 minecraft:air
fill 151 59 -257 173 59 -257 minecraft:water[level=0]
fill 136 59 -258 149 59 -258 minecraft:air
fill 151 59 -258 172 59 -258 minecraft:water[level=0]
fill 136 59 -259 149 59 -259 minecraft:air
fill 151 59 -259 169 59 -259 minecraft:water[level=0]
setblock 199 59 -259 minecraft:seagrass
fill 136 59 -260 149 59 -260 minecraft:air
fill 151 59 -260 166 59 -260 minecraft:water[level=0]
fill 198 59 -260 199 59 -260 minecraft:water[level=0]
fill 136 59 -261 149 59 -261 minecraft:air
fill 151 59 -261 165 59 -261 minecraft:water[level=0]
fill 198 59 -261 199 59 -261 minecraft:water[level=0]
fill 136 59 -262 149 59 -262 minecraft:air
fill 151 59 -262 163 59 -262 minecraft:water[level=0]
fill 197 59 -262 198 59 -262 minecraft:water[level=0]
fill 136 59 -263 149 59 -263 minecraft:air
fill 151 59 -263 162 59 -263 minecraft:water[level=0]
setblock 196 59 -263 minecraft:water[level=0]
fill 136 59 -264 149 59 -264 minecraft:air
fill 151 59 -264 159 59 -264 minecraft:water[level=0]
fill 160 59 -264 161 59 -264 minecraft:seagrass
fill 136 59 -265 149 59 -265 minecraft:air
fill 151 59 -265 158 59 -265 minecraft:water[level=0]
setblock 159 59 -265 minecraft:seagrass
setblock 160 59 -265 minecraft:water[level=0]
fill 136 59 -266 149 59 -266 minecraft:air
fill 151 59 -266 157 59 -266 minecraft:water[level=0]
setblock 158 59 -266 minecraft:seagrass
setblock 159 59 -266 minecraft:water[level=0]
setblock 191 59 -266 minecraft:water[level=0]
fill 136 59 -267 149 59 -267 minecraft:air
fill 151 59 -267 153 59 -267 minecraft:water[level=0]
setblock 154 59 -267 minecraft:seagrass
fill 155 59 -267 157 59 -267 minecraft:water[level=0]
fill 189 59 -267 191 59 -267 minecraft:water[level=0]
fill 136 59 -268 149 59 -268 minecraft:air
setblock 151 59 -268 minecraft:seagrass
fill 152 59 -268 154 59 -268 minecraft:water[level=0]
setblock 155 59 -268 minecraft:seagrass
setblock 156 59 -268 minecraft:tall_seagrass[half=lower]
fill 185 59 -268 191 59 -268 minecraft:water[level=0]
fill 136 59 -269 149 59 -269 minecraft:air
fill 186 59 -269 192 59 -269 minecraft:water[level=0]
fill 136 59 -270 149 59 -270 minecraft:air
fill 187 59 -270 192 59 -270 minecraft:water[level=0]
fill 136 59 -271 149 59 -271 minecraft:air
fill 188 59 -271 192 59 -271 minecraft:water[level=0]
fill 136 59 -272 149 59 -272 minecraft:air
fill 188 59 -272 192 59 -272 minecraft:water[level=0]
fill 136 59 -273 149 59 -273 minecraft:air
fill 189 59 -273 193 59 -273 minecraft:water[level=0]
fill 136 59 -274 149 59 -274 minecraft:air
fill 191 59 -274 193 59 -274 minecraft:water[level=0]
fill 136 59 -275 149 59 -275 minecraft:air
fill 192 59 -275 194 59 -275 minecraft:water[level=0]
fill 136 59 -276 149 59 -276 minecraft:air
fill 192 59 -276 194 59 -276 minecraft:water[level=0]
fill 136 59 -277 149 59 -277 minecraft:air
fill 192 59 -277 194 59 -277 minecraft:water[level=0]
fill 136 59 -278 149 59 -278 minecraft:air
fill 192 59 -278 195 59 -278 minecraft:water[level=0]
fill 136 59 -279 149 59 -279 minecraft:air
fill 192 59 -279 195 59 -279 minecraft:water[level=0]
fill 136 59 -280 149 59 -280 minecraft:air
fill 192 59 -280 196 59 -280 minecraft:water[level=0]
fill 136 59 -281 149 59 -281 minecraft:air
fill 193 59 -281 196 59 -281 minecraft:water[level=0]
fill 136 59 -282 149 59 -282 minecraft:air
fill 193 59 -282 196 59 -282 minecraft:water[level=0]
fill 136 59 -283 147 59 -283 minecraft:air
fill 194 59 -283 195 59 -283 minecraft:water[level=0]
fill 194 59 -284 195 59 -284 minecraft:water[level=0]
fill 136 59 -285 137 59 -285 minecraft:water[level=0]
setblock 195 59 -285 minecraft:water[level=0]
fill 136 59 -286 137 59 -286 minecraft:water[level=0]
setblock 195 59 -286 minecraft:water[level=0]
setblock 136 59 -287 minecraft:water[level=0]
setblock 195 59 -287 minecraft:water[level=0]
setblock 136 59 -288 minecraft:water[level=0]
fill 148 59 -292 150 59 -292 minecraft:water[level=0]
fill 146 59 -293 150 59 -293 minecraft:water[level=0]
setblock 196 59 -293 minecraft:water[level=0]
fill 145 59 -294 149 59 -294 minecraft:water[level=0]
setblock 196 59 -294 minecraft:water[level=0]
fill 144 59 -295 146 59 -295 minecraft:water[level=0]
fill 164 59 -295 165 59 -295 minecraft:water[level=0]
setblock 196 59 -295 minecraft:water[level=0]
fill 164 59 -296 166 59 -296 minecraft:water[level=0]
fill 195 59 -296 196 59 -296 minecraft:water[level=0]
fill 165 59 -297 167 59 -297 minecraft:water[level=0]
fill 195 59 -297 197 59 -297 minecraft:water[level=0]
fill 166 59 -298 167 59 -298 minecraft:water[level=0]
fill 195 59 -298 197 59 -298 minecraft:water[level=0]
fill 161 59 -299 162 59 -299 minecraft:water[level=0]
fill 166 59 -299 168 59 -299 minecraft:water[level=0]
fill 196 59 -299 198 59 -299 minecraft:water[level=0]
fill 160 59 -300 163 59 -300 minecraft:water[level=0]
fill 167 59 -300 169 59 -300 minecraft:water[level=0]
fill 196 59 -300 198 59 -300 minecraft:water[level=0]
fill 160 59 -301 164 59 -301 minecraft:water[level=0]
fill 168 59 -301 170 59 -301 minecraft:water[level=0]
fill 161 59 -302 164 59 -302 minecraft:water[level=0]
fill 169 59 -302 172 59 -302 minecraft:water[level=0]
fill 163 59 -303 165 59 -303 minecraft:water[level=0]
fill 170 59 -303 172 59 -303 minecraft:water[level=0]
fill 164 59 -304 165 59 -304 minecraft:water[level=0]
fill 171 59 -304 172 59 -304 minecraft:water[level=0]
setblock 172 59 -305 minecraft:water[level=0]
fill 151 58 -255 174 58 -255 minecraft:water[level=0]
fill 151 58 -256 173 58 -256 minecraft:water[level=0]
fill 151 58 -257 173 58 -257 minecraft:water[level=0]
fill 151 58 -258 172 58 -258 minecraft:water[level=0]
fill 151 58 -259 166 58 -259 minecraft:water[level=0]
fill 151 58 -260 165 58 -260 minecraft:water[level=0]
setblock 199 58 -260 minecraft:water[level=0]
fill 151 58 -261 163 58 -261 minecraft:water[level=0]
fill 198 58 -261 199 58 -261 minecraft:water[level=0]
fill 151 58 -262 162 58 -262 minecraft:water[level=0]
fill 198 58 -262 199 58 -262 minecraft:water[level=0]
fill 151 58 -263 161 58 -263 minecraft:water[level=0]
fill 197 58 -263 199 58 -263 minecraft:water[level=0]
fill 151 58 -264 158 58 -264 minecraft:water[level=0]
setblock 159 58 -264 minecraft:seagrass
fill 196 58 -264 197 58 -264 minecraft:water[level=0]
fill 151 58 -265 158 58 -265 minecraft:water[level=0]
fill 195 58 -265 196 58 -265 minecraft:water[level=0]
fill 151 58 -266 152 58 -266 minecraft:water[level=0]
fill 153 58 -266 154 58 -266 minecraft:tall_seagrass[half=upper]
setblock 155 58 -266 minecraft:water[level=0]
setblock 156 58 -266 minecraft:seagrass
setblock 157 58 -266 minecraft:water[level=0]
fill 193 58 -266 195 58 -266 minecraft:water[level=0]
setblock 151 58 -267 minecraft:seagrass
fill 192 58 -267 194 58 -267 minecraft:water[level=0]
fill 189 58 -268 194 58 -268 minecraft:water[level=0]
fill 188 58 -269 194 58 -269 minecraft:water[level=0]
fill 136 58 -270 147 58 -270 minecraft:water[level=0]
fill 189 58 -270 194 58 -270 minecraft:water[level=0]
fill 136 58 -271 145 58 -271 minecraft:water[level=0]
fill 190 58 -271 194 58 -271 minecraft:water[level=0]
fill 136 58 -272 144 58 -272 minecraft:water[level=0]
fill 190 58 -272 194 58 -272 minecraft:water[level=0]
fill 136 58 -273 143 58 -273 minecraft:water[level=0]
fill 191 58 -273 195 58 -273 minecraft:water[level=0]
fill 136 58 -274 143 58 -274 minecraft:water[level=0]
fill 191 58 -274 195 58 -274 minecraft:water[level=0]
fill 136 58 -275 143 58 -275 minecraft:water[level=0]
fill 192 58 -275 195 58 -275 minecraft:water[level=0]
fill 136 58 -276 142 58 -276 minecraft:water[level=0]
fill 192 58 -276 196 58 -276 minecraft:water[level=0]
fill 136 58 -277 142 58 -277 minecraft:water[level=0]
fill 193 58 -277 197 58 -277 minecraft:water[level=0]
fill 136 58 -278 141 58 -278 minecraft:water[level=0]
fill 193 58 -278 196 58 -278 minecraft:water[level=0]
fill 136 58 -279 141 58 -279 minecraft:water[level=0]
fill 194 58 -279 196 58 -279 minecraft:water[level=0]
fill 136 58 -280 140 58 -280 minecraft:water[level=0]
fill 194 58 -280 195 58 -280 minecraft:water[level=0]
fill 136 58 -281 140 58 -281 minecraft:water[level=0]
setblock 195 58 -281 minecraft:water[level=0]
fill 136 58 -282 139 58 -282 minecraft:water[level=0]
setblock 195 58 -282 minecraft:water[level=0]
fill 136 58 -283 139 58 -283 minecraft:water[level=0]
fill 136 58 -285 138 58 -285 minecraft:water[level=0]
fill 136 58 -286 137 58 -286 minecraft:water[level=0]
setblock 136 58 -287 minecraft:water[level=0]
setblock 136 58 -288 minecraft:water[level=0]
fill 145 58 -293 149 58 -293 minecraft:water[level=0]
fill 144 58 -294 148 58 -294 minecraft:water[level=0]
fill 144 58 -295 146 58 -295 minecraft:water[level=0]
setblock 142 58 -296 minecraft:water[level=0]
fill 164 58 -296 165 58 -296 minecraft:water[level=0]
fill 164 58 -297 166 58 -297 minecraft:water[level=0]
fill 196 58 -297 197 58 -297 minecraft:water[level=0]
fill 165 58 -298 167 58 -298 minecraft:water[level=0]
fill 196 58 -298 198 58 -298 minecraft:water[level=0]
fill 160 58 -299 162 58 -299 minecraft:water[level=0]
fill 166 58 -299 168 58 -299 minecraft:water[level=0]
fill 197 58 -299 198 58 -299 minecraft:water[level=0]
fill 160 58 -300 163 58 -300 minecraft:water[level=0]
fill 167 58 -300 169 58 -300 minecraft:water[level=0]
fill 197 58 -300 199 58 -300 minecraft:water[level=0]
fill 160 58 -301 164 58 -301 minecraft:water[level=0]
fill 168 58 -301 170 58 -301 minecraft:water[level=0]
fill 198 58 -301 199 58 -301 minecraft:water[level=0]
fill 161 58 -302 165 58 -302 minecraft:water[level=0]
fill 169 58 -302 171 58 -302 minecraft:water[level=0]
fill 162 58 -303 166 58 -303 minecraft:water[level=0]
fill 170 58 -303 172 58 -303 minecraft:water[level=0]
fill 163 58 -304 166 58 -304 minecraft:water[level=0]
fill 171 58 -304 172 58 -304 minecraft:water[level=0]
fill 163 58 -305 168 58 -305 minecraft:water[level=0]
setblock 172 58 -305 minecraft:water[level=0]
fill 164 58 -306 175 58 -306 minecraft:water[level=0]
fill 165 58 -307 174 58 -307 minecraft:water[level=0]
fill 166 58 -308 174 58 -308 minecraft:water[level=0]
fill 168 58 -309 172 58 -309 minecraft:water[level=0]
fill 136 57 -255 138 57 -255 minecraft:water[level=0]
fill 151 57 -255 174 57 -255 minecraft:water[level=0]
fill 151 57 -256 173 57 -256 minecraft:water[level=0]
fill 151 57 -257 172 57 -257 minecraft:water[level=0]
fill 136 57 -258 147 57 -258 minecraft:water[level=0]
fill 151 57 -258 167 57 -258 minecraft:water[level=0]
fill 137 57 -259 147 57 -259 minecraft:water[level=0]
fill 151 57 -259 165 57 -259 minecraft:water[level=0]
fill 151 57 -260 164 57 -260 minecraft:water[level=0]
setblock 199 57 -260 minecraft:water[level=0]
fill 151 57 -261 162 57 -261 minecraft:water[level=0]
setblock 199 57 -261 minecraft:water[level=0]
fill 151 57 -262 161 57 -262 minecraft:water[level=0]
fill 198 57 -262 199 57 -262 minecraft:water[level=0]
fill 151 57 -263 159 57 -263 minecraft:water[level=0]
fill 198 57 -263 199 57 -263 minecraft:water[level=0]
fill 151 57 -264 158 57 -264 minecraft:water[level=0]
fill 197 57 -264 199 57 -264 minecraft:water[level=0]
fill 151 57 -265 152 57 -265 minecraft:water[level=0]
setblock 153 57 -265 minecraft:tall_seagrass[half=upper]
setblock 154 57 -265 minecraft:water[level=0]
setblock 155 57 -265 minecraft:tall_seagrass[half=upper]
fill 156 57 -265 157 57 -265 minecraft:water[level=0]
fill 196 57 -265 199 57 -265 minecraft:water[level=0]
fill 151 57 -266 152 57 -266 minecraft:water[level=0]
fill 153 57 -266 154 57 -266 minecraft:tall_seagrass[half=lower]
setblock 155 57 -266 minecraft:water[level=0]
fill 195 57 -266 198 57 -266 minecraft:water[level=0]
fill 194 57 -267 197 57 -267 minecraft:water[level=0]
fill 192 57 -268 196 57 -268 minecraft:water[level=0]
fill 137 57 -269 148 57 -269 minecraft:water[level=0]
fill 191 57 -269 196 57 -269 minecraft:water[level=0]
fill 137 57 -270 145 57 -270 minecraft:water[level=0]
fill 191 57 -270 196 57 -270 minecraft:water[level=0]
setblock 137 57 -271 minecraft:tall_seagrass[half=upper]
fill 138 57 -271 144 57 -271 minecraft:water[level=0]
fill 191 57 -271 197 57 -271 minecraft:water[level=0]
fill 136 57 -272 143 57 -272 minecraft:water[level=0]
fill 192 57 -272 197 57 -272 minecraft:water[level=0]
fill 136 57 -273 143 57 -273 minecraft:water[level=0]
fill 192 57 -273 197 57 -273 minecraft:water[level=0]
fill 136 57 -274 143 57 -274 minecraft:water[level=0]
fill 193 57 -274 198 57 -274 minecraft:water[level=0]
fill 136 57 -275 142 57 -275 minecraft:water[level=0]
fill 194 57 -275 197 57 -275 minecraft:water[level=0]
fill 136 57 -276 142 57 -276 minecraft:water[level=0]
fill 194 57 -276 196 57 -276 minecraft:water[level=0]
fill 136 57 -277 142 57 -277 minecraft:water[level=0]
setblock 195 57 -277 minecraft:water[level=0]
fill 136 57 -278 141 57 -278 minecraft:water[level=0]
setblock 195 57 -278 minecraft:water[level=0]
fill 136 57 -279 141 57 -279 minecraft:water[level=0]
fill 136 57 -280 140 57 -280 minecraft:water[level=0]
fill 136 57 -281 140 57 -281 minecraft:water[level=0]
fill 136 57 -282 139 57 -282 minecraft:water[level=0]
fill 136 57 -283 139 57 -283 minecraft:water[level=0]
fill 136 57 -285 138 57 -285 minecraft:water[level=0]
fill 136 57 -286 137 57 -286 minecraft:water[level=0]
setblock 136 57 -287 minecraft:water[level=0]
setblock 136 57 -288 minecraft:water[level=0]
fill 146 57 -293 147 57 -293 minecraft:water[level=0]
fill 144 57 -294 147 57 -294 minecraft:water[level=0]
setblock 142 57 -295 minecraft:water[level=0]
fill 144 57 -295 146 57 -295 minecraft:water[level=0]
fill 141 57 -296 143 57 -296 minecraft:water[level=0]
setblock 165 57 -296 minecraft:water[level=0]
fill 140 57 -297 142 57 -297 minecraft:water[level=0]
fill 165 57 -297 166 57 -297 minecraft:water[level=0]
setblock 140 57 -298 minecraft:water[level=0]
fill 165 57 -298 167 57 -298 minecraft:water[level=0]
fill 166 57 -299 168 57 -299 minecraft:water[level=0]
fill 197 57 -299 199 57 -299 minecraft:water[level=0]
setblock 162 57 -300 minecraft:water[level=0]
fill 167 57 -300 169 57 -300 minecraft:water[level=0]
fill 198 57 -300 199 57 -300 minecraft:water[level=0]
fill 161 57 -301 163 57 -301 minecraft:water[level=0]
fill 168 57 -301 170 57 -301 minecraft:water[level=0]
fill 198 57 -301 199 57 -301 minecraft:water[level=0]
fill 162 57 -302 165 57 -302 minecraft:water[level=0]
fill 168 57 -302 171 57 -302 minecraft:water[level=0]
setblock 199 57 -302 minecraft:water[level=0]
fill 163 57 -303 166 57 -303 minecraft:water[level=0]
fill 169 57 -303 172 57 -303 minecraft:water[level=0]
fill 163 57 -304 167 57 -304 minecraft:water[level=0]
fill 170 57 -304 172 57 -304 minecraft:water[level=0]
fill 174 57 -304 176 57 -304 minecraft:water[level=0]
fill 163 57 -305 168 57 -305 minecraft:water[level=0]
fill 171 57 -305 177 57 -305 minecraft:water[level=0]
fill 165 57 -306 177 57 -306 minecraft:water[level=0]
fill 165 57 -307 176 57 -307 minecraft:water[level=0]
fill 166 57 -308 175 57 -308 minecraft:water[level=0]
fill 167 57 -309 174 57 -309 minecraft:water[level=0]
setblock 169 57 -310 minecraft:water[level=0]
setblock 171 57 -310 minecraft:water[level=0]
fill 151 56 -255 173 56 -255 minecraft:water[level=0]
fill 136 56 -256 148 56 -256 minecraft:water[level=0]
fill 151 56 -256 173 56 -256 minecraft:water[level=0]
fill 136 56 -257 148 56 -257 minecraft:water[level=0]
fill 151 56 -257 172 56 -257 minecraft:water[level=0]
fill 137 56 -258 148 56 -258 minecraft:water[level=0]
fill 151 56 -258 166 56 -258 minecraft:water[level=0]
fill 151 56 -259 160 56 -259 minecraft:water[level=0]
setblock 161 56 -259 minecraft:tall_seagrass[half=upper]
fill 162 56 -259 164 56 -259 minecraft:water[level=0]
fill 151 56 -260 159 56 -260 minecraft:water[level=0]
setblock 160 56 -260 minecraft:tall_seagrass[half=upper]
fill 161 56 -260 163 56 -260 minecraft:water[level=0]
fill 151 56 -261 161 56 -261 minecraft:water[level=0]
fill 151 56 -262 160 56 -262 minecraft:water[level=0]
setblock 199 56 -262 minecraft:water[level=0]
fill 151 56 -263 154 56 -263 minecraft:water[level=0]
setblock 155 56 -263 minecraft:tall_seagrass[half=upper]
fill 156 56 -263 158 56 -263 minecraft:water[level=0]
fill 198 56 -263 199 56 -263 minecraft:water[level=0]
fill 151 56 -264 157 56 -264 minecraft:water[level=0]
fill 198 56 -264 199 56 -264 minecraft:water[level=0]
setblock 151 56 -265 minecraft:water[level=0]
setblock 152 56 -265 minecraft:tall_seagrass[half=upper]
setblock 153 56 -265 minecraft:tall_seagrass[half=lower]
setblock 154 56 -265 minecraft:seagrass
setblock 155 56 -265 minecraft:tall_seagrass[half=lower]
setblock 156 56 -265 minecraft:water[level=0]
fill 197 56 -265 199 56 -265 minecraft:water[level=0]
fill 197 56 -266 199 56 -266 minecraft:water[level=0]
fill 196 56 -267 199 56 -267 minecraft:water[level=0]
fill 138 56 -268 148 56 -268 minecraft:water[level=0]
fill 195 56 -268 199 56 -268 minecraft:water[level=0]
fill 138 56 -269 146 56 -269 minecraft:water[level=0]
fill 195 56 -269 199 56 -269 minecraft:water[level=0]
fill 138 56 -270 144 56 -270 minecraft:water[level=0]
fill 194 56 -270 199 56 -270 minecraft:water[level=0]
setblock 137 56 -271 minecraft:tall_seagrass[half=lower]
fill 138 56 -271 144 56 -271 minecraft:water[level=0]
fill 194 56 -271 199 56 -271 minecraft:water[level=0]
fill 137 56 -272 143 56 -272 minecraft:water[level=0]
fill 194 56 -272 199 56 -272 minecraft:water[level=0]
fill 136 56 -273 143 56 -273 minecraft:water[level=0]
fill 194 56 -273 196 56 -273 minecraft:water[level=0]
fill 136 56 -274 142 56 -274 minecraft:water[level=0]
fill 136 56 -275 142 56 -275 minecraft:water[level=0]
fill 136 56 -276 142 56 -276 minecraft:water[level=0]
fill 136 56 -277 142 56 -277 minecraft:water[level=0]
fill 136 56 -278 141 56 -278 minecraft:water[level=0]
fill 136 56 -279 141 56 -279 minecraft:water[level=0]
fill 136 56 -280 141 56 -280 minecraft:water[level=0]
fill 136 56 -281 140 56 -281 minecraft:water[level=0]
fill 136 56 -282 140 56 -282 minecraft:water[level=0]
fill 136 56 -283 139 56 -283 minecraft:water[level=0]
setblock 139 56 -284 minecraft:water[level=0]
fill 136 56 -285 138 56 -285 minecraft:water[level=0]
fill 136 56 -286 137 56 -286 minecraft:water[level=0]
fill 136 56 -287 137 56 -287 minecraft:water[level=0]
setblock 136 56 -288 minecraft:water[level=0]
fill 144 56 -295 145 56 -295 minecraft:water[level=0]
fill 140 56 -296 143 56 -296 minecraft:water[level=0]
setblock 165 56 -296 minecraft:water[level=0]
fill 139 56 -297 142 56 -297 minecraft:water[level=0]
fill 165 56 -297 166 56 -297 minecraft:water[level=0]
fill 139 56 -298 141 56 -298 minecraft:water[level=0]
fill 165 56 -298 166 56 -298 minecraft:water[level=0]
fill 166 56 -299 167 56 -299 minecraft:water[level=0]
fill 166 56 -300 168 56 -300 minecraft:water[level=0]
setblock 199 56 -300 minecraft:water[level=0]
fill 167 56 -301 169 56 -301 minecraft:water[level=0]
setblock 199 56 -301 minecraft:water[level=0]
fill 168 56 -302 170 56 -302 minecraft:water[level=0]
setblock 137 56 -303 minecraft:water[level=0]
fill 169 56 -303 171 56 -303 minecraft:water[level=0]
fill 175 56 -303 177 56 -303 minecraft:water[level=0]
fill 170 56 -304 171 56 -304 minecraft:water[level=0]
fill 174 56 -304 178 56 -304 minecraft:water[level=0]
fill 166 56 -305 167 56 -305 minecraft:water[level=0]
fill 171 56 -305 178 56 -305 minecraft:water[level=0]
fill 166 56 -306 178 56 -306 minecraft:water[level=0]
fill 166 56 -307 177 56 -307 minecraft:water[level=0]
fill 167 56 -308 176 56 -308 minecraft:water[level=0]
fill 168 56 -309 173 56 -309 minecraft:water[level=0]
fill 137 55 -255 141 55 -255 minecraft:water[level=0]
fill 151 55 -255 172 55 -255 minecraft:water[level=0]
fill 136 55 -256 141 55 -256 minecraft:water[level=0]
fill 151 55 -256 172 55 -256 minecraft:water[level=0]
fill 137 55 -257 148 55 -257 minecraft:water[level=0]
fill 151 55 -257 165 55 -257 minecraft:water[level=0]
fill 138 55 -258 148 55 -258 minecraft:water[level=0]
fill 151 55 -258 162 55 -258 minecraft:water[level=0]
fill 138 55 -259 148 55 -259 minecraft:water[level=0]
fill 151 55 -259 160 55 -259 minecraft:water[level=0]
setblock 161 55 -259 minecraft:tall_seagrass[half=lower]
fill 151 55 -260 159 55 -260 minecraft:water[level=0]
setblock 160 55 -260 minecraft:tall_seagrass[half=lower]
fill 151 55 -261 156 55 -261 minecraft:water[level=0]
setblock 157 55 -261 minecraft:seagrass
fill 158 55 -261 159 55 -261 minecraft:water[level=0]
fill 151 55 -262 157 55 -262 minecraft:water[level=0]
fill 151 55 -263 154 55 -263 minecraft:water[level=0]
setblock 155 55 -263 minecraft:tall_seagrass[half=lower]
setblock 156 55 -263 minecraft:water[level=0]
fill 151 55 -264 153 55 -264 minecraft:water[level=0]
fill 154 55 -264 156 55 -264 minecraft:seagrass
fill 198 55 -264 199 55 -264 minecraft:water[level=0]
setblock 151 55 -265 minecraft:water[level=0]
setblock 152 55 -265 minecraft:tall_seagrass[half=lower]
fill 197 55 -265 199 55 -265 minecraft:water[level=0]
fill 197 55 -266 199 55 -266 minecraft:water[level=0]
fill 196 55 -267 199 55 -267 minecraft:water[level=0]
fill 138 55 -268 148 55 -268 minecraft:water[level=0]
fill 154 55 -268 156 55 -268 minecraft:water[level=0]
fill 196 55 -268 199 55 -268 minecraft:water[level=0]
setblock 138 55 -269 minecraft:seagrass
fill 139 55 -269 146 55 -269 minecraft:water[level=0]
fill 153 55 -269 156 55 -269 minecraft:water[level=0]
fill 196 55 -269 199 55 -269 minecraft:water[level=0]
fill 138 55 -270 144 55 -270 minecraft:water[level=0]
fill 153 55 -270 156 55 -270 minecraft:water[level=0]
fill 196 55 -270 199 55 -270 minecraft:water[level=0]
fill 138 55 -271 144 55 -271 minecraft:water[level=0]
fill 153 55 -271 155 55 -271 minecraft:water[level=0]
fill 196 55 -271 199 55 -271 minecraft:water[level=0]
fill 137 55 -272 143 55 -272 minecraft:water[level=0]
fill 152 55 -272 154 55 -272 minecraft:water[level=0]
fill 196 55 -272 199 55 -272 minecraft:water[level=0]
fill 136 55 -273 143 55 -273 minecraft:water[level=0]
fill 151 55 -273 154 55 -273 minecraft:water[level=0]
fill 136 55 -274 142 55 -274 minecraft:water[level=0]
fill 149 55 -274 154 55 -274 minecraft:water[level=0]
fill 136 55 -275 142 55 -275 minecraft:water[level=0]
fill 149 55 -275 153 55 -275 minecraft:water[level=0]
fill 136 55 -276 142 55 -276 minecraft:water[level=0]
fill 149 55 -276 151 55 -276 minecraft:water[level=0]
fill 136 55 -277 142 55 -277 minecraft:water[level=0]
fill 136 55 -278 141 55 -278 minecraft:water[level=0]
fill 136 55 -279 141 55 -279 minecraft:water[level=0]
fill 136 55 -280 141 55 -280 minecraft:water[level=0]
fill 136 55 -281 140 55 -281 minecraft:water[level=0]
fill 136 55 -282 140 55 -282 minecraft:water[level=0]
fill 136 55 -283 139 55 -283 minecraft:water[level=0]
setblock 139 55 -284 minecraft:water[level=0]
fill 136 55 -285 138 55 -285 minecraft:water[level=0]
fill 136 55 -286 137 55 -286 minecraft:water[level=0]
fill 136 55 -287 137 55 -287 minecraft:water[level=0]
setblock 136 55 -288 minecraft:water[level=0]
fill 173 55 -293 175 55 -293 minecraft:water[level=0]
fill 173 55 -294 177 55 -294 minecraft:water[level=0]
fill 174 55 -295 178 55 -295 minecraft:water[level=0]
setblock 179 55 -295 minecraft:bubble_column[drag=true]
fill 141 55 -296 142 55 -296 minecraft:water[level=0]
fill 174 55 -296 179 55 -296 minecraft:water[level=0]
fill 139 55 -297 141 55 -297 minecraft:water[level=0]
fill 175 55 -297 178 55 -297 minecraft:water[level=0]
setblock 179 55 -297 minecraft:bubble_column[drag=true]
fill 139 55 -298 140 55 -298 minecraft:water[level=0]
fill 166 55 -299 167 55 -299 minecraft:water[level=0]
fill 166 55 -300 168 55 -300 minecraft:water[level=0]
fill 137 55 -301 138 55 -301 minecraft:water[level=0]
fill 167 55 -301 169 55 -301 minecraft:water[level=0]
fill 136 55 -302 138 55 -302 minecraft:water[level=0]
fill 168 55 -302 170 55 -302 minecraft:water[level=0]
fill 176 55 -302 179 55 -302 minecraft:water[level=0]
fill 136 55 -303 137 55 -303 minecraft:water[level=0]
fill 168 55 -303 171 55 -303 minecraft:water[level=0]
fill 175 55 -303 179 55 -303 minecraft:water[level=0]
fill 169 55 -304 172 55 -304 minecraft:water[level=0]
fill 174 55 -304 179 55 -304 minecraft:water[level=0]
fill 170 55 -305 171 55 -305 minecraft:water[level=0]
fill 174 55 -305 179 55 -305 minecraft:water[level=0]
setblock 171 55 -306 minecraft:water[level=0]
fill 173 55 -306 178 55 -306 minecraft:water[level=0]
fill 173 55 -307 177 55 -307 minecraft:water[level=0]
setblock 175 55 -308 minecraft:water[level=0]
fill 140 54 -255 141 54 -255 minecraft:water[level=0]
fill 151 54 -255 157 54 -255 minecraft:water[level=0]
setblock 158 54 -255 minecraft:tall_seagrass[half=upper]
fill 159 54 -255 163 54 -255 minecraft:water[level=0]
fill 137 54 -256 141 54 -256 minecraft:water[level=0]
fill 151 54 -256 159 54 -256 minecraft:water[level=0]
setblock 160 54 -256 minecraft:seagrass
fill 161 54 -256 162 54 -256 minecraft:water[level=0]
setblock 138 54 -257 minecraft:water[level=0]
fill 151 54 -257 161 54 -257 minecraft:water[level=0]
setblock 138 54 -258 minecraft:water[level=0]
fill 151 54 -258 160 54 -258 minecraft:water[level=0]
fill 151 54 -259 159 54 -259 minecraft:water[level=0]
fill 151 54 -260 154 54 -260 minecraft:water[level=0]
setblock 155 54 -260 minecraft:tall_seagrass[half=upper]
fill 156 54 -260 157 54 -260 minecraft:water[level=0]
fill 151 54 -261 156 54 -261 minecraft:water[level=0]
fill 151 54 -262 155 54 -262 minecraft:water[level=0]
fill 151 54 -263 154 54 -263 minecraft:water[level=0]
fill 151 54 -264 152 54 -264 minecraft:water[level=0]
setblock 153 54 -264 minecraft:seagrass
setblock 151 54 -265 minecraft:tall_seagrass[half=upper]
fill 155 54 -266 157 54 -266 minecraft:water[level=0]
fill 154 54 -267 157 54 -267 minecraft:water[level=0]
fill 153 54 -268 156 54 -268 minecraft:water[level=0]
setblock 199 54 -268 minecraft:water[level=0]
fill 139 54 -269 146 54 -269 minecraft:water[level=0]
fill 153 54 -269 157 54 -269 minecraft:water[level=0]
setblock 199 54 -269 minecraft:water[level=0]
fill 138 54 -270 144 54 -270 minecraft:water[level=0]
fill 152 54 -270 156 54 -270 minecraft:water[level=0]
setblock 199 54 -270 minecraft:water[level=0]
fill 138 54 -271 144 54 -271 minecraft:water[level=0]
fill 153 54 -271 156 54 -271 minecraft:water[level=0]
setblock 199 54 -271 minecraft:water[level=0]
fill 138 54 -272 143 54 -272 minecraft:water[level=0]
fill 152 54 -272 155 54 -272 minecraft:water[level=0]
setblock 199 54 -272 minecraft:water[level=0]
fill 137 54 -273 143 54 -273 minecraft:water[level=0]
fill 150 54 -273 154 54 -273 minecraft:water[level=0]
fill 136 54 -274 143 54 -274 minecraft:water[level=0]
fill 149 54 -274 154 54 -274 minecraft:water[level=0]
fill 136 54 -275 142 54 -275 minecraft:water[level=0]
fill 149 54 -275 153 54 -275 minecraft:water[level=0]
fill 136 54 -276 142 54 -276 minecraft:water[level=0]
fill 149 54 -276 152 54 -276 minecraft:water[level=0]
fill 136 54 -277 142 54 -277 minecraft:water[level=0]
fill 136 54 -278 141 54 -278 minecraft:water[level=0]
fill 136 54 -279 141 54 -279 minecraft:water[level=0]
fill 136 54 -280 141 54 -280 minecraft:water[level=0]
fill 136 54 -281 140 54 -281 minecraft:water[level=0]
fill 136 54 -282 140 54 -282 minecraft:water[level=0]
fill 136 54 -283 139 54 -283 minecraft:water[level=0]
setblock 139 54 -284 minecraft:water[level=0]
fill 136 54 -285 138 54 -285 minecraft:water[level=0]
fill 136 54 -286 137 54 -286 minecraft:water[level=0]
fill 136 54 -287 137 54 -287 minecraft:water[level=0]
setblock 136 54 -288 minecraft:water[level=0]
fill 171 54 -290 172 54 -290 minecraft:water[level=0]
fill 170 54 -291 174 54 -291 minecraft:water[level=0]
fill 170 54 -292 175 54 -292 minecraft:water[level=0]
fill 171 54 -293 177 54 -293 minecraft:water[level=0]
fill 171 54 -294 179 54 -294 minecraft:water[level=0]
fill 172 54 -295 178 54 -295 minecraft:water[level=0]
fill 179 54 -295 180 54 -295 minecraft:bubble_column[drag=true]
fill 172 54 -296 179 54 -296 minecraft:water[level=0]
setblock 180 54 -296 minecraft:bubble_column[drag=true]
setblock 181 54 -296 minecraft:water[level=0]
fill 174 54 -297 178 54 -297 minecraft:water[level=0]
setblock 179 54 -297 minecraft:bubble_column[drag=true]
fill 180 54 -297 182 54 -297 minecraft:water[level=0]
setblock 140 54 -298 minecraft:water[level=0]
fill 175 54 -298 181 54 -298 minecraft:water[level=0]
fill 178 54 -299 182 54 -299 minecraft:water[level=0]
fill 179 54 -300 182 54 -300 minecraft:water[level=0]
fill 137 54 -301 138 54 -301 minecraft:water[level=0]
setblock 168 54 -301 minecraft:water[level=0]
fill 177 54 -301 182 54 -301 minecraft:water[level=0]
fill 137 54 -302 138 54 -302 minecraft:water[level=0]
fill 168 54 -302 169 54 -302 minecraft:water[level=0]
fill 176 54 -302 181 54 -302 minecraft:water[level=0]
fill 136 54 -303 137 54 -303 minecraft:water[level=0]
fill 168 54 -303 170 54 -303 minecraft:water[level=0]
fill 175 54 -303 181 54 -303 minecraft:water[level=0]
fill 169 54 -304 171 54 -304 minecraft:water[level=0]
fill 175 54 -304 180 54 -304 minecraft:water[level=0]
fill 170 54 -305 172 54 -305 minecraft:water[level=0]
fill 175 54 -305 179 54 -305 minecraft:water[level=0]
fill 171 54 -306 172 54 -306 minecraft:water[level=0]
fill 175 54 -306 179 54 -306 minecraft:water[level=0]
setblock 172 54 -307 minecraft:water[level=0]
setblock 176 54 -307 minecraft:water[level=0]
fill 151 53 -255 157 53 -255 minecraft:water[level=0]
setblock 158 53 -255 minecraft:tall_seagrass[half=lower]
setblock 159 53 -255 minecraft:water[level=0]
fill 140 53 -256 141 53 -256 minecraft:water[level=0]
fill 151 53 -256 152 53 -256 minecraft:water[level=0]
setblock 153 53 -256 minecraft:tall_seagrass[half=upper]
fill 154 53 -256 158 53 -256 minecraft:water[level=0]
fill 139 53 -257 141 53 -257 minecraft:water[level=0]
fill 151 53 -257 156 53 -257 minecraft:water[level=0]
setblock 157 53 -257 minecraft:seagrass
fill 151 53 -258 157 53 -258 minecraft:water[level=0]
fill 151 53 -259 153 53 -259 minecraft:water[level=0]
setblock 154 53 -259 minecraft:seagrass
fill 155 53 -259 156 53 -259 minecraft:water[level=0]
fill 151 53 -260 154 53 -260 minecraft:water[level=0]
setblock 155 53 -260 minecraft:tall_seagrass[half=lower]
fill 161 53 -260 166 53 -260 minecraft:water[level=0]
fill 151 53 -261 154 53 -261 minecraft:water[level=0]
fill 159 53 -261 167 53 -261 minecraft:water[level=0]
fill 151 53 -262 152 53 -262 minecraft:water[level=0]
setblock 153 53 -262 minecraft:seagrass
fill 158 53 -262 169 53 -262 minecraft:water[level=0]
fill 151 53 -263 153 53 -263 minecraft:water[level=0]
fill 156 53 -263 170 53 -263 minecraft:water[level=0]
fill 151 53 -264 152 53 -264 minecraft:water[level=0]
fill 155 53 -264 162 53 -264 minecraft:water[level=0]
fill 164 53 -264 171 53 -264 minecraft:water[level=0]
setblock 151 53 -265 minecraft:tall_seagrass[half=lower]
fill 154 53 -265 159 53 -265 minecraft:water[level=0]
fill 167 53 -265 171 53 -265 minecraft:water[level=0]
fill 154 53 -266 158 53 -266 minecraft:water[level=0]
fill 169 53 -266 172 53 -266 minecraft:water[level=0]
fill 154 53 -267 157 53 -267 minecraft:water[level=0]
fill 170 53 -267 171 53 -267 minecraft:water[level=0]
fill 154 53 -268 157 53 -268 minecraft:water[level=0]
fill 139 53 -269 146 53 -269 minecraft:water[level=0]
fill 153 53 -269 156 53 -269 minecraft:water[level=0]
fill 139 53 -270 145 53 -270 minecraft:water[level=0]
fill 153 53 -270 156 53 -270 minecraft:water[level=0]
fill 138 53 -271 144 53 -271 minecraft:water[level=0]
fill 153 53 -271 155 53 -271 minecraft:water[level=0]
fill 138 53 -272 143 53 -272 minecraft:water[level=0]
fill 137 53 -273 143 53 -273 minecraft:water[level=0]
fill 136 53 -274 143 53 -274 minecraft:water[level=0]
fill 136 53 -275 142 53 -275 minecraft:water[level=0]
fill 136 53 -276 142 53 -276 minecraft:water[level=0]
fill 136 53 -277 142 53 -277 minecraft:water[level=0]
fill 136 53 -278 141 53 -278 minecraft:water[level=0]
fill 136 53 -279 141 53 -279 minecraft:water[level=0]
fill 136 53 -280 141 53 -280 minecraft:water[level=0]
fill 136 53 -281 140 53 -281 minecraft:water[level=0]
fill 136 53 -282 140 53 -282 minecraft:water[level=0]
fill 136 53 -283 139 53 -283 minecraft:water[level=0]
setblock 139 53 -284 minecraft:water[level=0]
fill 136 53 -285 138 53 -285 minecraft:water[level=0]
fill 136 53 -286 137 53 -286 minecraft:water[level=0]
fill 136 53 -287 137 53 -287 minecraft:water[level=0]
fill 170 53 -287 171 53 -287 minecraft:water[level=0]
setblock 136 53 -288 minecraft:water[level=0]
fill 169 53 -288 172 53 -288 minecraft:water[level=0]
fill 168 53 -289 173 53 -289 minecraft:water[level=0]
setblock 169 53 -290 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=true,west=true]
fill 170 53 -290 174 53 -290 minecraft:water[level=0]
fill 169 53 -291 174 53 -291 minecraft:water[level=0]
fill 169 53 -292 175 53 -292 minecraft:water[level=0]
fill 170 53 -293 177 53 -293 minecraft:water[level=0]
fill 170 53 -294 180 53 -294 minecraft:water[level=0]
fill 171 53 -295 178 53 -295 minecraft:water[level=0]
fill 179 53 -295 181 53 -295 minecraft:bubble_column[drag=true]
fill 172 53 -296 179 53 -296 minecraft:water[level=0]
setblock 180 53 -296 minecraft:bubble_column[drag=true]
fill 181 53 -296 182 53 -296 minecraft:water[level=0]
fill 174 53 -297 178 53 -297 minecraft:water[level=0]
setblock 179 53 -297 minecraft:bubble_column[drag=true]
fill 180 53 -297 182 53 -297 minecraft:water[level=0]
fill 175 53 -298 182 53 -298 minecraft:water[level=0]
fill 178 53 -299 183 53 -299 minecraft:water[level=0]
fill 178 53 -300 183 53 -300 minecraft:water[level=0]
fill 177 53 -301 183 53 -301 minecraft:water[level=0]
setblock 169 53 -302 minecraft:water[level=0]
fill 177 53 -302 182 53 -302 minecraft:water[level=0]
fill 169 53 -303 170 53 -303 minecraft:water[level=0]
fill 176 53 -303 181 53 -303 minecraft:water[level=0]
fill 169 53 -304 171 53 -304 minecraft:water[level=0]
fill 176 53 -304 181 53 -304 minecraft:water[level=0]
fill 169 53 -305 172 53 -305 minecraft:water[level=0]
fill 176 53 -305 180 53 -305 minecraft:water[level=0]
fill 170 53 -306 172 53 -306 minecraft:water[level=0]
setblock 177 53 -306 minecraft:water[level=0]
fill 171 53 -307 172 53 -307 minecraft:water[level=0]
fill 144 52 -255 146 52 -255 minecraft:water[level=0]
fill 151 52 -256 152 52 -256 minecraft:water[level=0]
setblock 153 52 -256 minecraft:tall_seagrass[half=lower]
fill 154 52 -256 156 52 -256 minecraft:water[level=0]
setblock 141 52 -257 minecraft:water[level=0]
fill 151 52 -257 154 52 -257 minecraft:water[level=0]
setblock 155 52 -257 minecraft:seagrass
fill 151 52 -258 154 52 -258 minecraft:water[level=0]
fill 151 52 -259 153 52 -259 minecraft:water[level=0]
fill 151 52 -260 153 52 -260 minecraft:water[level=0]
fill 160 52 -260 167 52 -260 minecraft:water[level=0]
fill 151 52 -261 152 52 -261 minecraft:water[level=0]
fill 158 52 -261 169 52 -261 minecraft:water[level=0]
fill 151 52 -262 152 52 -262 minecraft:seagrass
fill 157 52 -262 170 52 -262 minecraft:water[level=0]
fill 151 52 -263 152 52 -263 minecraft:water[level=0]
fill 156 52 -263 171 52 -263 minecraft:water[level=0]
setblock 151 52 -264 minecraft:seagrass
fill 155 52 -264 172 52 -264 minecraft:water[level=0]
fill 154 52 -265 160 52 -265 minecraft:water[level=0]
fill 166 52 -265 173 52 -265 minecraft:water[level=0]
fill 154 52 -266 159 52 -266 minecraft:water[level=0]
fill 167 52 -266 173 52 -266 minecraft:water[level=0]
fill 154 52 -267 157 52 -267 minecraft:water[level=0]
fill 169 52 -267 173 52 -267 minecraft:water[level=0]
fill 155 52 -268 157 52 -268 minecraft:water[level=0]
fill 170 52 -268 173 52 -268 minecraft:water[level=0]
fill 170 52 -269 173 52 -269 minecraft:water[level=0]
fill 139 52 -270 145 52 -270 minecraft:water[level=0]
fill 171 52 -270 173 52 -270 minecraft:water[level=0]
fill 139 52 -271 144 52 -271 minecraft:water[level=0]
setblock 172 52 -271 minecraft:water[level=0]
fill 138 52 -272 143 52 -272 minecraft:water[level=0]
fill 138 52 -273 143 52 -273 minecraft:water[level=0]
fill 137 52 -274 143 52 -274 minecraft:water[level=0]
fill 136 52 -275 143 52 -275 minecraft:water[level=0]
fill 136 52 -276 142 52 -276 minecraft:water[level=0]
fill 136 52 -277 142 52 -277 minecraft:water[level=0]
fill 136 52 -278 142 52 -278 minecraft:water[level=0]
fill 136 52 -279 141 52 -279 minecraft:water[level=0]
fill 136 52 -280 141 52 -280 minecraft:water[level=0]
fill 136 52 -281 140 52 -281 minecraft:water[level=0]
fill 136 52 -282 140 52 -282 minecraft:water[level=0]
fill 136 52 -283 139 52 -283 minecraft:water[level=0]
setblock 139 52 -284 minecraft:water[level=0]
fill 136 52 -285 138 52 -285 minecraft:water[level=0]
fill 167 52 -285 169 52 -285 minecraft:water[level=0]
fill 136 52 -286 137 52 -286 minecraft:water[level=0]
fill 167 52 -286 171 52 -286 minecraft:water[level=0]
fill 136 52 -287 137 52 -287 minecraft:water[level=0]
fill 167 52 -287 172 52 -287 minecraft:water[level=0]
setblock 136 52 -288 minecraft:water[level=0]
fill 167 52 -288 173 52 -288 minecraft:water[level=0]
fill 167 52 -289 173 52 -289 minecraft:water[level=0]
fill 168 52 -290 174 52 -290 minecraft:water[level=0]
fill 168 52 -291 174 52 -291 minecraft:water[level=0]
fill 169 52 -292 175 52 -292 minecraft:water[level=0]
fill 170 52 -293 176 52 -293 minecraft:water[level=0]
fill 170 52 -294 178 52 -294 minecraft:water[level=0]
fill 171 52 -295 178 52 -295 minecraft:water[level=0]
fill 179 52 -295 181 52 -295 minecraft:bubble_column[drag=true]
fill 172 52 -296 179 52 -296 minecraft:water[level=0]
setblock 180 52 -296 minecraft:bubble_column[drag=true]
setblock 181 52 -296 minecraft:water[level=0]
fill 175 52 -297 178 52 -297 minecraft:water[level=0]
setblock 179 52 -297 minecraft:bubble_column[drag=true]
fill 180 52 -297 182 52 -297 minecraft:water[level=0]
fill 177 52 -298 182 52 -298 minecraft:water[level=0]
fill 178 52 -299 183 52 -299 minecraft:water[level=0]
fill 178 52 -300 183 52 -300 minecraft:water[level=0]
fill 178 52 -301 183 52 -301 minecraft:water[level=0]
fill 177 52 -302 182 52 -302 minecraft:water[level=0]
fill 177 52 -303 181 52 -303 minecraft:water[level=0]
setblock 170 52 -304 minecraft:water[level=0]
fill 177 52 -304 180 52 -304 minecraft:water[level=0]
fill 169 52 -305 171 52 -305 minecraft:water[level=0]
fill 170 52 -306 173 52 -306 minecraft:water[level=0]
fill 171 52 -307 172 52 -307 minecraft:water[level=0]
setblock 172 52 -308 minecraft:water[level=0]
fill 143 51 -256 147 51 -256 minecraft:water[level=0]
setblock 141 51 -260 minecraft:water[level=0]
setblock 151 51 -260 minecraft:water[level=0]
fill 162 51 -260 166 51 -260 minecraft:water[level=0]
setblock 141 51 -261 minecraft:water[level=0]
setblock 151 51 -261 minecraft:water[level=0]
fill 159 51 -261 168 51 -261 minecraft:water[level=0]
fill 158 51 -262 170 51 -262 minecraft:water[level=0]
fill 157 51 -263 171 51 -263 minecraft:water[level=0]
fill 156 51 -264 161 51 -264 minecraft:water[level=0]
fill 165 51 -264 172 51 -264 minecraft:water[level=0]
fill 155 51 -265 160 51 -265 minecraft:water[level=0]
fill 167 51 -265 173 51 -265 minecraft:water[level=0]
fill 155 51 -266 158 51 -266 minecraft:water[level=0]
fill 168 51 -266 174 51 -266 minecraft:water[level=0]
fill 140 51 -267 141 51 -267 minecraft:water[level=0]
fill 169 51 -267 174 51 -267 minecraft:water[level=0]
fill 140 51 -268 148 51 -268 minecraft:water[level=0]
fill 169 51 -268 174 51 -268 minecraft:water[level=0]
fill 140 51 -269 147 51 -269 minecraft:water[level=0]
fill 170 51 -269 174 51 -269 minecraft:water[level=0]
fill 139 51 -270 145 51 -270 minecraft:water[level=0]
fill 170 51 -270 174 51 -270 minecraft:water[level=0]
setblock 139 51 -271 minecraft:tall_seagrass[half=upper]
fill 140 51 -271 144 51 -271 minecraft:water[level=0]
fill 170 51 -271 174 51 -271 minecraft:water[level=0]
fill 139 51 -272 144 51 -272 minecraft:water[level=0]
fill 170 51 -272 174 51 -272 minecraft:water[level=0]
fill 138 51 -273 143 51 -273 minecraft:water[level=0]
fill 170 51 -273 173 51 -273 minecraft:water[level=0]
setblock 138 51 -274 minecraft:tall_seagrass[half=upper]
fill 139 51 -274 143 51 -274 minecraft:water[level=0]
fill 170 51 -274 172 51 -274 minecraft:water[level=0]
fill 136 51 -275 143 51 -275 minecraft:water[level=0]
fill 170 51 -275 171 51 -275 minecraft:water[level=0]
fill 136 51 -276 143 51 -276 minecraft:water[level=0]
setblock 170 51 -276 minecraft:water[level=0]
fill 136 51 -277 142 51 -277 minecraft:water[level=0]
fill 136 51 -278 142 51 -278 minecraft:water[level=0]
fill 136 51 -279 141 51 -279 minecraft:water[level=0]
fill 136 51 -280 141 51 -280 minecraft:water[level=0]
setblock 167 51 -280 minecraft:water[level=0]
fill 136 51 -281 140 51 -281 minecraft:water[level=0]
fill 166 51 -281 168 51 -281 minecraft:water[level=0]
fill 136 51 -282 140 51 -282 minecraft:water[level=0]
fill 166 51 -282 168 51 -282 minecraft:water[level=0]
fill 136 51 -283 140 51 -283 minecraft:water[level=0]
fill 166 51 -283 169 51 -283 minecraft:water[level=0]
fill 136 51 -284 139 51 -284 minecraft:water[level=0]
fill 165 51 -284 170 51 -284 minecraft:water[level=0]
fill 136 51 -285 138 51 -285 minecraft:water[level=0]
fill 165 51 -285 170 51 -285 minecraft:water[level=0]
fill 136 51 -286 137 51 -286 minecraft:water[level=0]
fill 166 51 -286 171 51 -286 minecraft:water[level=0]
fill 136 51 -287 137 51 -287 minecraft:water[level=0]
fill 166 51 -287 172 51 -287 minecraft:water[level=0]
setblock 136 51 -288 minecraft:water[level=0]
fill 167 51 -288 173 51 -288 minecraft:water[level=0]
fill 167 51 -289 173 51 -289 minecraft:water[level=0]
fill 168 51 -290 173 51 -290 minecraft:water[level=0]
fill 168 51 -291 174 51 -291 minecraft:water[level=0]
fill 169 51 -292 174 51 -292 minecraft:water[level=0]
fill 170 51 -293 174 51 -293 minecraft:water[level=0]
fill 171 51 -294 174 51 -294 minecraft:water[level=0]
setblock 181 51 -298 minecraft:water[level=0]
fill 180 51 -299 182 51 -299 minecraft:water[level=0]
fill 179 51 -300 182 51 -300 minecraft:water[level=0]
fill 179 51 -301 181 51 -301 minecraft:water[level=0]
setblock 170 51 -304 minecraft:water[level=0]
setblock 170 51 -305 minecraft:water[level=0]
fill 170 51 -306 171 51 -306 minecraft:water[level=0]
fill 170 51 -307 171 51 -307 minecraft:water[level=0]
setblock 171 51 -308 minecraft:water[level=0]
fill 144 50 -256 145 50 -256 minecraft:water[level=0]
fill 144 50 -257 145 50 -257 minecraft:water[level=0]
fill 144 50 -258 146 50 -258 minecraft:water[level=0]
fill 143 50 -259 147 50 -259 minecraft:water[level=0]
fill 143 50 -260 148 50 -260 minecraft:water[level=0]
fill 143 50 -261 148 50 -261 minecraft:water[level=0]
fill 143 50 -262 148 50 -262 minecraft:water[level=0]
fill 143 50 -263 148 50 -263 minecraft:water[level=0]
fill 169 50 -263 170 50 -263 minecraft:water[level=0]
fill 168 50 -264 171 50 -264 minecraft:water[level=0]
fill 143 50 -265 148 50 -265 minecraft:water[level=0]
fill 168 50 -265 173 50 -265 minecraft:water[level=0]
fill 143 50 -266 148 50 -266 minecraft:water[level=0]
fill 169 50 -266 173 50 -266 minecraft:water[level=0]
fill 142 50 -267 148 50 -267 minecraft:water[level=0]
fill 169 50 -267 174 50 -267 minecraft:water[level=0]
fill 140 50 -268 148 50 -268 minecraft:water[level=0]
fill 169 50 -268 174 50 -268 minecraft:water[level=0]
fill 140 50 -269 147 50 -269 minecraft:water[level=0]
fill 170 50 -269 174 50 -269 minecraft:water[level=0]
fill 140 50 -270 145 50 -270 minecraft:water[level=0]
fill 170 50 -270 174 50 -270 minecraft:water[level=0]
setblock 139 50 -271 minecraft:tall_seagrass[half=lower]
fill 140 50 -271 144 50 -271 minecraft:water[level=0]
fill 169 50 -271 174 50 -271 minecraft:water[level=0]
fill 139 50 -272 144 50 -272 minecraft:water[level=0]
fill 169 50 -272 174 50 -272 minecraft:water[level=0]
fill 139 50 -273 144 50 -273 minecraft:water[level=0]
fill 169 50 -273 174 50 -273 minecraft:water[level=0]
setblock 138 50 -274 minecraft:tall_seagrass[half=lower]
fill 139 50 -274 143 50 -274 minecraft:water[level=0]
fill 169 50 -274 173 50 -274 minecraft:water[level=0]
setblock 137 50 -275 minecraft:seagrass
fill 138 50 -275 143 50 -275 minecraft:water[level=0]
fill 168 50 -275 173 50 -275 minecraft:water[level=0]
fill 136 50 -276 143 50 -276 minecraft:water[level=0]
fill 168 50 -276 173 50 -276 minecraft:water[level=0]
fill 136 50 -277 143 50 -277 minecraft:water[level=0]
fill 167 50 -277 172 50 -277 minecraft:water[level=0]
fill 136 50 -278 142 50 -278 minecraft:water[level=0]
fill 166 50 -278 171 50 -278 minecraft:water[level=0]
fill 136 50 -279 142 50 -279 minecraft:water[level=0]
fill 166 50 -279 171 50 -279 minecraft:water[level=0]
fill 136 50 -280 141 50 -280 minecraft:water[level=0]
fill 165 50 -280 170 50 -280 minecraft:water[level=0]
fill 136 50 -281 141 50 -281 minecraft:water[level=0]
fill 165 50 -281 170 50 -281 minecraft:water[level=0]
fill 136 50 -282 140 50 -282 minecraft:water[level=0]
fill 165 50 -282 169 50 -282 minecraft:water[level=0]
fill 136 50 -283 140 50 -283 minecraft:water[level=0]
setblock 165 50 -283 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=true,west=true]
fill 166 50 -283 170 50 -283 minecraft:water[level=0]
fill 136 50 -284 140 50 -284 minecraft:water[level=0]
fill 165 50 -284 170 50 -284 minecraft:water[level=0]
fill 136 50 -285 138 50 -285 minecraft:water[level=0]
fill 165 50 -285 170 50 -285 minecraft:water[level=0]
fill 136 50 -286 138 50 -286 minecraft:water[level=0]
fill 165 50 -286 171 50 -286 minecraft:water[level=0]
fill 136 50 -287 137 50 -287 minecraft:water[level=0]
fill 166 50 -287 171 50 -287 minecraft:water[level=0]
setblock 136 50 -288 minecraft:water[level=0]
fill 167 50 -288 172 50 -288 minecraft:water[level=0]
fill 167 50 -289 172 50 -289 minecraft:water[level=0]
fill 168 50 -290 172 50 -290 minecraft:water[level=0]
fill 169 50 -291 172 50 -291 minecraft:water[level=0]
setblock 144 49 -258 minecraft:water[level=0]
setblock 144 49 -259 minecraft:water[level=0]
fill 144 49 -260 145 49 -260 minecraft:water[level=0]
fill 144 49 -261 145 49 -261 minecraft:water[level=0]
fill 144 49 -262 146 49 -262 minecraft:water[level=0]
fill 144 49 -263 146 49 -263 minecraft:water[level=0]
fill 144 49 -264 147 49 -264 minecraft:water[level=0]
fill 144 49 -265 147 49 -265 minecraft:water[level=0]
fill 143 49 -266 148 49 -266 minecraft:water[level=0]
fill 143 49 -267 148 49 -267 minecraft:water[level=0]
fill 171 49 -267 173 49 -267 minecraft:water[level=0]
fill 142 49 -268 148 49 -268 minecraft:water[level=0]
fill 171 49 -268 173 49 -268 minecraft:water[level=0]
fill 140 49 -269 147 49 -269 minecraft:water[level=0]
fill 170 49 -269 174 49 -269 minecraft:water[level=0]
fill 140 49 -270 146 49 -270 minecraft:water[level=0]
fill 170 49 -270 174 49 -270 minecraft:water[level=0]
fill 140 49 -271 145 49 -271 minecraft:water[level=0]
fill 169 49 -271 174 49 -271 minecraft:water[level=0]
fill 139 49 -272 144 49 -272 minecraft:water[level=0]
fill 169 49 -272 174 49 -272 minecraft:water[level=0]
fill 139 49 -273 144 49 -273 minecraft:water[level=0]
fill 169 49 -273 174 49 -273 minecraft:water[level=0]
fill 139 49 -274 144 49 -274 minecraft:water[level=0]
fill 168 49 -274 174 49 -274 minecraft:water[level=0]
fill 138 49 -275 144 49 -275 minecraft:water[level=0]
fill 168 49 -275 173 49 -275 minecraft:water[level=0]
fill 136 49 -276 144 49 -276 minecraft:water[level=0]
fill 167 49 -276 173 49 -276 minecraft:water[level=0]
fill 136 49 -277 144 49 -277 minecraft:water[level=0]
fill 166 49 -277 172 49 -277 minecraft:water[level=0]
fill 136 49 -278 143 49 -278 minecraft:water[level=0]
fill 166 49 -278 172 49 -278 minecraft:water[level=0]
fill 136 49 -279 142 49 -279 minecraft:water[level=0]
fill 166 49 -279 171 49 -279 minecraft:water[level=0]
fill 136 49 -280 142 49 -280 minecraft:water[level=0]
fill 165 49 -280 171 49 -280 minecraft:water[level=0]
fill 136 49 -281 141 49 -281 minecraft:water[level=0]
fill 165 49 -281 170 49 -281 minecraft:water[level=0]
fill 136 49 -282 141 49 -282 minecraft:water[level=0]
fill 164 49 -282 170 49 -282 minecraft:water[level=0]
fill 136 49 -283 140 49 -283 minecraft:water[level=0]
fill 165 49 -283 170 49 -283 minecraft:water[level=0]
fill 136 49 -284 140 49 -284 minecraft:water[level=0]
fill 165 49 -284 170 49 -284 minecraft:water[level=0]
fill 136 49 -285 139 49 -285 minecraft:water[level=0]
fill 165 49 -285 170 49 -285 minecraft:water[level=0]
fill 136 49 -286 138 49 -286 minecraft:water[level=0]
fill 165 49 -286 170 49 -286 minecraft:water[level=0]
fill 136 49 -287 137 49 -287 minecraft:water[level=0]
fill 166 49 -287 170 49 -287 minecraft:water[level=0]
setblock 136 49 -288 minecraft:water[level=0]
fill 168 49 -288 170 49 -288 minecraft:water[level=0]
setblock 136 49 -289 minecraft:water[level=0]
fill 169 49 -289 170 49 -289 minecraft:water[level=0]
setblock 173 49 -307 minecraft:air
setblock 173 49 -308 minecraft:air
setblock 173 49 -309 minecraft:air
fill 172 49 -310 173 49 -310 minecraft:air
setblock 144 48 -262 minecraft:water[level=0]
setblock 144 48 -263 minecraft:water[level=0]
fill 144 48 -264 145 48 -264 minecraft:water[level=0]
fill 144 48 -265 146 48 -265 minecraft:water[level=0]
fill 144 48 -266 146 48 -266 minecraft:water[level=0]
fill 143 48 -267 147 48 -267 minecraft:water[level=0]
fill 143 48 -268 148 48 -268 minecraft:water[level=0]
fill 142 48 -269 148 48 -269 minecraft:water[level=0]
setblock 140 48 -270 minecraft:water[level=0]
setblock 141 48 -270 minecraft:tall_seagrass[half=upper]
fill 142 48 -270 148 48 -270 minecraft:water[level=0]
fill 171 48 -270 172 48 -270 minecraft:water[level=0]
fill 140 48 -271 147 48 -271 minecraft:water[level=0]
fill 170 48 -271 173 48 -271 minecraft:water[level=0]
fill 140 48 -272 147 48 -272 minecraft:water[level=0]
fill 169 48 -272 173 48 -272 minecraft:water[level=0]
fill 139 48 -273 146 48 -273 minecraft:water[level=0]
fill 169 48 -273 173 48 -273 minecraft:water[level=0]
fill 139 48 -274 146 48 -274 minecraft:water[level=0]
fill 169 48 -274 173 48 -274 minecraft:water[level=0]
fill 139 48 -275 146 48 -275 minecraft:water[level=0]
fill 168 48 -275 173 48 -275 minecraft:water[level=0]
fill 138 48 -276 146 48 -276 minecraft:water[level=0]
fill 167 48 -276 173 48 -276 minecraft:water[level=0]
fill 137 48 -277 145 48 -277 minecraft:water[level=0]
fill 167 48 -277 172 48 -277 minecraft:water[level=0]
fill 136 48 -278 145 48 -278 minecraft:water[level=0]
fill 166 48 -278 172 48 -278 minecraft:water[level=0]
fill 136 48 -279 144 48 -279 minecraft:water[level=0]
fill 166 48 -279 171 48 -279 minecraft:water[level=0]
fill 136 48 -280 144 48 -280 minecraft:water[level=0]
fill 165 48 -280 171 48 -280 minecraft:water[level=0]
fill 136 48 -281 143 48 -281 minecraft:water[level=0]
fill 165 48 -281 170 48 -281 minecraft:water[level=0]
fill 136 48 -282 142 48 -282 minecraft:water[level=0]
fill 165 48 -282 169 48 -282 minecraft:water[level=0]
fill 136 48 -283 142 48 -283 minecraft:water[level=0]
fill 165 48 -283 169 48 -283 minecraft:water[level=0]
fill 136 48 -284 141 48 -284 minecraft:water[level=0]
fill 166 48 -284 169 48 -284 minecraft:water[level=0]
fill 136 48 -285 140 48 -285 minecraft:water[level=0]
fill 166 48 -285 169 48 -285 minecraft:water[level=0]
fill 136 48 -286 140 48 -286 minecraft:water[level=0]
fill 167 48 -286 169 48 -286 minecraft:water[level=0]
fill 136 48 -287 138 48 -287 minecraft:water[level=0]
fill 136 48 -288 137 48 -288 minecraft:water[level=0]
setblock 136 48 -289 minecraft:water[level=0]
fill 170 48 -289 171 48 -289 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 170 48 -290 171 48 -290 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 172 48 -307 minecraft:air
fill 173 48 -308 174 48 -308 minecraft:air
fill 171 48 -309 174 48 -309 minecraft:air
fill 172 48 -310 173 48 -310 minecraft:air
setblock 144 47 -263 minecraft:water[level=0]
fill 144 47 -264 145 47 -264 minecraft:water[level=0]
fill 144 47 -265 145 47 -265 minecraft:water[level=0]
fill 144 47 -266 146 47 -266 minecraft:water[level=0]
fill 144 47 -267 147 47 -267 minecraft:water[level=0]
fill 143 47 -268 148 47 -268 minecraft:water[level=0]
fill 143 47 -269 148 47 -269 minecraft:water[level=0]
setblock 141 47 -270 minecraft:tall_seagrass[half=lower]
fill 142 47 -270 148 47 -270 minecraft:water[level=0]
fill 163 47 -270 164 47 -270 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 140 47 -271 148 47 -271 minecraft:water[level=0]
fill 163 47 -271 164 47 -271 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 140 47 -272 147 47 -272 minecraft:water[level=0]
fill 140 47 -273 147 47 -273 minecraft:water[level=0]
fill 139 47 -274 146 47 -274 minecraft:water[level=0]
fill 139 47 -275 146 47 -275 minecraft:water[level=0]
fill 169 47 -275 171 47 -275 minecraft:water[level=0]
fill 138 47 -276 146 47 -276 minecraft:water[level=0]
fill 169 47 -276 171 47 -276 minecraft:water[level=0]
fill 137 47 -277 145 47 -277 minecraft:water[level=0]
fill 168 47 -277 171 47 -277 minecraft:water[level=0]
fill 136 47 -278 145 47 -278 minecraft:water[level=0]
fill 167 47 -278 170 47 -278 minecraft:water[level=0]
fill 136 47 -279 144 47 -279 minecraft:water[level=0]
fill 167 47 -279 170 47 -279 minecraft:water[level=0]
fill 136 47 -280 144 47 -280 minecraft:water[level=0]
fill 167 47 -280 169 47 -280 minecraft:water[level=0]
fill 136 47 -281 143 47 -281 minecraft:water[level=0]
fill 167 47 -281 169 47 -281 minecraft:water[level=0]
fill 136 47 -282 142 47 -282 minecraft:water[level=0]
fill 136 47 -283 142 47 -283 minecraft:water[level=0]
fill 136 47 -284 141 47 -284 minecraft:water[level=0]
setblock 150 47 -284 minecraft:water[level=0]
fill 136 47 -285 140 47 -285 minecraft:water[level=0]
fill 136 47 -286 139 47 -286 minecraft:water[level=0]
setblock 151 47 -286 minecraft:water[level=0]
fill 136 47 -287 137 47 -287 minecraft:water[level=0]
setblock 136 47 -288 minecraft:water[level=0]
setblock 171 47 -290 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 173 47 -308 174 47 -308 minecraft:air
fill 172 47 -309 174 47 -309 minecraft:air
fill 172 47 -310 174 47 -310 minecraft:air
fill 173 47 -311 174 47 -311 minecraft:air
setblock 144 46 -264 minecraft:water[level=0]
fill 144 46 -265 145 46 -265 minecraft:water[level=0]
fill 144 46 -266 146 46 -266 minecraft:water[level=0]
fill 144 46 -267 147 46 -267 minecraft:water[level=0]
fill 143 46 -268 148 46 -268 minecraft:water[level=0]
fill 143 46 -269 148 46 -269 minecraft:water[level=0]
fill 142 46 -270 148 46 -270 minecraft:water[level=0]
fill 163 46 -270 164 46 -270 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 140 46 -271 148 46 -271 minecraft:water[level=0]
fill 163 46 -271 164 46 -271 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 140 46 -272 147 46 -272 minecraft:water[level=0]
fill 140 46 -273 147 46 -273 minecraft:water[level=0]
fill 140 46 -274 146 46 -274 minecraft:water[level=0]
fill 139 46 -275 146 46 -275 minecraft:water[level=0]
fill 139 46 -276 146 46 -276 minecraft:water[level=0]
fill 138 46 -277 145 46 -277 minecraft:water[level=0]
fill 137 46 -278 145 46 -278 minecraft:water[level=0]
setblock 136 46 -279 minecraft:water[level=0]
setblock 137 46 -279 minecraft:tall_seagrass[half=upper]
fill 138 46 -279 144 46 -279 minecraft:water[level=0]
fill 136 46 -280 144 46 -280 minecraft:water[level=0]
fill 136 46 -281 143 46 -281 minecraft:water[level=0]
setblock 149 46 -281 minecraft:water[level=0]
fill 136 46 -282 142 46 -282 minecraft:water[level=0]
setblock 149 46 -282 minecraft:water[level=0]
fill 136 46 -283 141 46 -283 minecraft:water[level=0]
fill 149 46 -283 150 46 -283 minecraft:water[level=0]
fill 136 46 -284 141 46 -284 minecraft:water[level=0]
fill 149 46 -284 150 46 -284 minecraft:water[level=0]
fill 136 46 -285 140 46 -285 minecraft:water[level=0]
fill 149 46 -285 150 46 -285 minecraft:water[level=0]
setblock 136 46 -286 minecraft:water[level=0]
fill 150 46 -286 151 46 -286 minecraft:water[level=0]
fill 150 46 -287 151 46 -287 minecraft:water[level=0]
fill 150 46 -288 151 46 -288 minecraft:water[level=0]
setblock 151 46 -289 minecraft:water[level=0]
setblock 173 46 -308 minecraft:air
fill 173 46 -309 175 46 -309 minecraft:air
fill 173 46 -310 175 46 -310 minecraft:air
fill 173 46 -311 175 46 -311 minecraft:air
setblock 144 45 -265 minecraft:water[level=0]
fill 144 45 -266 145 45 -266 minecraft:water[level=0]
fill 144 45 -267 147 45 -267 minecraft:water[level=0]
fill 144 45 -268 148 45 -268 minecraft:water[level=0]
fill 144 45 -269 148 45 -269 minecraft:water[level=0]
fill 143 45 -270 148 45 -270 minecraft:water[level=0]
fill 140 45 -271 148 45 -271 minecraft:water[level=0]
fill 140 45 -272 148 45 -272 minecraft:water[level=0]
setblock 140 45 -273 minecraft:tall_seagrass[half=upper]
fill 141 45 -273 147 45 -273 minecraft:water[level=0]
fill 140 45 -274 147 45 -274 minecraft:water[level=0]
fill 140 45 -275 146 45 -275 minecraft:water[level=0]
fill 139 45 -276 146 45 -276 minecraft:water[level=0]
fill 139 45 -277 146 45 -277 minecraft:water[level=0]
fill 138 45 -278 145 45 -278 minecraft:water[level=0]
setblock 136 45 -279 minecraft:water[level=0]
setblock 137 45 -279 minecraft:tall_seagrass[half=lower]
fill 138 45 -279 145 45 -279 minecraft:water[level=0]
fill 147 45 -279 148 45 -279 minecraft:water[level=0]
fill 136 45 -280 144 45 -280 minecraft:water[level=0]
fill 147 45 -280 148 45 -280 minecraft:water[level=0]
fill 136 45 -281 143 45 -281 minecraft:water[level=0]
fill 147 45 -281 149 45 -281 minecraft:water[level=0]
fill 136 45 -282 142 45 -282 minecraft:water[level=0]
fill 148 45 -282 149 45 -282 minecraft:water[level=0]
fill 136 45 -283 141 45 -283 minecraft:water[level=0]
fill 148 45 -283 150 45 -283 minecraft:water[level=0]
fill 136 45 -284 141 45 -284 minecraft:water[level=0]
fill 149 45 -284 150 45 -284 minecraft:water[level=0]
fill 149 45 -285 150 45 -285 minecraft:water[level=0]
fill 149 45 -286 150 45 -286 minecraft:water[level=0]
fill 149 45 -287 151 45 -287 minecraft:water[level=0]
fill 150 45 -288 151 45 -288 minecraft:water[level=0]
fill 150 45 -289 151 45 -289 minecraft:water[level=0]
fill 150 45 -290 151 45 -290 minecraft:water[level=0]
setblock 151 45 -291 minecraft:water[level=0]
fill 174 45 -309 175 45 -309 minecraft:air
fill 174 45 -310 175 45 -310 minecraft:air
fill 174 45 -311 175 45 -311 minecraft:air
setblock 175 45 -312 minecraft:air
forceload remove 136 -318 199 -255
tellraw @a {"text":"Campus zurueck a17 fertig.","color":"green"}
