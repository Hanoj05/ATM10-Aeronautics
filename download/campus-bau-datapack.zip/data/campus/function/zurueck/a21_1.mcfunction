setblock 412 72 -256 minecraft:air
setblock 412 72 -296 minecraft:air
setblock 412 72 -306 minecraft:air
setblock 412 72 -316 minecraft:air
fill 411 71 -255 413 71 -255 minecraft:air
fill 410 71 -256 414 71 -256 minecraft:air
fill 411 71 -257 413 71 -257 minecraft:air
setblock 412 71 -258 minecraft:air
setblock 412 71 -294 minecraft:air
fill 411 71 -295 413 71 -295 minecraft:air
fill 410 71 -296 414 71 -296 minecraft:air
fill 411 71 -297 413 71 -297 minecraft:air
setblock 412 71 -298 minecraft:air
setblock 412 71 -304 minecraft:air
fill 411 71 -305 413 71 -305 minecraft:air
fill 410 71 -306 414 71 -306 minecraft:air
fill 411 71 -307 413 71 -307 minecraft:air
setblock 412 71 -308 minecraft:air
setblock 412 71 -314 minecraft:air
fill 411 71 -315 413 71 -315 minecraft:air
fill 410 71 -316 414 71 -316 minecraft:air
fill 411 71 -317 413 71 -317 minecraft:air
setblock 412 71 -318 minecraft:air
fill 410 70 -255 414 70 -255 minecraft:air
fill 410 70 -256 414 70 -256 minecraft:air
fill 410 70 -257 414 70 -257 minecraft:air
fill 411 70 -258 413 70 -258 minecraft:air
fill 411 70 -294 413 70 -294 minecraft:air
fill 410 70 -295 414 70 -295 minecraft:air
fill 410 70 -296 414 70 -296 minecraft:air
fill 410 70 -297 414 70 -297 minecraft:air
fill 411 70 -298 413 70 -298 minecraft:air
fill 411 70 -304 413 70 -304 minecraft:air
fill 410 70 -305 414 70 -305 minecraft:air
fill 410 70 -306 414 70 -306 minecraft:air
fill 410 70 -307 414 70 -307 minecraft:air
fill 411 70 -308 413 70 -308 minecraft:air
fill 411 70 -314 413 70 -314 minecraft:air
fill 410 70 -315 414 70 -315 minecraft:air
fill 410 70 -316 414 70 -316 minecraft:air
fill 410 70 -317 414 70 -317 minecraft:air
fill 411 70 -318 413 70 -318 minecraft:air
fill 411 69 -255 413 69 -255 minecraft:air
fill 410 69 -256 414 69 -256 minecraft:air
fill 411 69 -257 413 69 -257 minecraft:air
setblock 412 69 -258 minecraft:air
setblock 412 69 -294 minecraft:air
fill 411 69 -295 413 69 -295 minecraft:air
fill 410 69 -296 414 69 -296 minecraft:air
fill 411 69 -297 413 69 -297 minecraft:air
setblock 412 69 -298 minecraft:air
setblock 412 69 -304 minecraft:air
fill 411 69 -305 413 69 -305 minecraft:air
fill 410 69 -306 414 69 -306 minecraft:air
fill 411 69 -307 413 69 -307 minecraft:air
setblock 412 69 -308 minecraft:air
setblock 412 69 -314 minecraft:air
fill 411 69 -315 413 69 -315 minecraft:air
fill 410 69 -316 414 69 -316 minecraft:air
fill 411 69 -317 413 69 -317 minecraft:air
setblock 412 69 -318 minecraft:air
setblock 412 68 -256 minecraft:air
setblock 412 68 -296 minecraft:air
setblock 412 68 -306 minecraft:air
setblock 412 68 -316 minecraft:air
setblock 412 67 -256 minecraft:air
setblock 412 67 -296 minecraft:air
setblock 412 67 -306 minecraft:air
setblock 412 67 -316 minecraft:air
setblock 412 66 -256 minecraft:air
setblock 412 66 -296 minecraft:air
setblock 421 66 -298 regions_unexplored:grass_sprouts
setblock 412 66 -306 minecraft:air
setblock 412 66 -316 minecraft:air
fill 417 65 -255 421 65 -255 minecraft:grass_block[snowy=false]
setblock 422 65 -255 minecraft:air
fill 417 65 -256 419 65 -256 minecraft:grass_block[snowy=false]
fill 420 65 -256 422 65 -256 minecraft:air
fill 417 65 -257 418 65 -257 minecraft:grass_block[snowy=false]
fill 419 65 -257 422 65 -257 minecraft:air
fill 417 65 -258 418 65 -258 minecraft:grass_block[snowy=false]
fill 419 65 -258 422 65 -258 minecraft:air
fill 417 65 -259 418 65 -259 minecraft:grass_block[snowy=false]
fill 419 65 -259 422 65 -259 minecraft:air
fill 417 65 -260 418 65 -260 minecraft:grass_block[snowy=false]
setblock 419 65 -260 minecraft:air
setblock 420 65 -260 regions_unexplored:grass_sprouts
fill 421 65 -260 422 65 -260 minecraft:air
setblock 417 65 -261 minecraft:grass_block[snowy=false]
fill 418 65 -261 422 65 -261 minecraft:air
setblock 417 65 -262 minecraft:grass_block[snowy=false]
fill 418 65 -262 422 65 -262 minecraft:air
fill 417 65 -263 422 65 -263 minecraft:air
fill 416 65 -264 422 65 -264 minecraft:air
fill 416 65 -265 418 65 -265 minecraft:air
setblock 419 65 -265 regions_unexplored:grass_sprouts
fill 420 65 -265 422 65 -265 minecraft:air
setblock 416 65 -266 minecraft:short_grass
fill 417 65 -266 422 65 -266 minecraft:air
setblock 415 65 -267 regions_unexplored:grass_sprouts
fill 416 65 -267 417 65 -267 minecraft:air
setblock 418 65 -267 regions_unexplored:grass_sprouts
fill 419 65 -267 422 65 -267 minecraft:air
setblock 415 65 -268 minecraft:air
setblock 416 65 -268 minecraft:short_grass
setblock 417 65 -268 regions_unexplored:grass_sprouts
fill 418 65 -268 420 65 -268 minecraft:air
setblock 421 65 -268 regions_unexplored:grass_sprouts
setblock 422 65 -268 minecraft:air
fill 415 65 -269 419 65 -269 minecraft:air
setblock 420 65 -269 minecraft:short_grass
fill 421 65 -269 422 65 -269 minecraft:air
setblock 415 65 -270 minecraft:air
setblock 416 65 -270 regions_unexplored:grass_sprouts
fill 417 65 -270 422 65 -270 minecraft:air
fill 415 65 -271 422 65 -271 minecraft:air
fill 415 65 -272 422 65 -272 minecraft:air
fill 415 65 -273 422 65 -273 minecraft:air
fill 415 65 -274 422 65 -274 minecraft:air
setblock 415 65 -275 minecraft:air
setblock 416 65 -275 regions_unexplored:grass_sprouts
fill 417 65 -275 422 65 -275 minecraft:air
fill 415 65 -276 422 65 -276 minecraft:air
setblock 415 65 -277 regions_unexplored:grass_sprouts
setblock 416 65 -277 minecraft:air
setblock 417 65 -277 minecraft:short_grass
fill 418 65 -277 422 65 -277 minecraft:air
fill 415 65 -278 422 65 -278 minecraft:air
fill 415 65 -279 422 65 -279 minecraft:air
fill 415 65 -280 422 65 -280 minecraft:air
fill 414 65 -281 422 65 -281 minecraft:air
fill 412 65 -282 422 65 -282 minecraft:air
fill 410 65 -283 415 65 -283 minecraft:air
setblock 416 65 -283 regions_unexplored:grass_sprouts
fill 417 65 -283 422 65 -283 minecraft:air
fill 408 65 -284 422 65 -284 minecraft:air
fill 406 65 -285 422 65 -285 minecraft:air
fill 406 65 -286 422 65 -286 minecraft:air
fill 407 65 -287 422 65 -287 minecraft:air
fill 406 65 -288 422 65 -288 minecraft:air
fill 406 65 -289 422 65 -289 minecraft:air
fill 406 65 -290 422 65 -290 minecraft:air
fill 406 65 -291 419 65 -291 minecraft:air
fill 420 65 -291 422 65 -291 minecraft:grass_block[snowy=false]
fill 406 65 -292 418 65 -292 minecraft:air
fill 419 65 -292 422 65 -292 minecraft:grass_block[snowy=false]
fill 406 65 -293 419 65 -293 minecraft:air
fill 420 65 -293 422 65 -293 minecraft:grass_block[snowy=false]
fill 406 65 -294 417 65 -294 minecraft:air
fill 418 65 -294 422 65 -294 minecraft:grass_block[snowy=false]
fill 406 65 -295 417 65 -295 minecraft:air
fill 418 65 -295 422 65 -295 minecraft:grass_block[snowy=false]
fill 406 65 -296 416 65 -296 minecraft:air
setblock 417 65 -296 minecraft:short_grass
fill 418 65 -296 421 65 -296 minecraft:grass_block[snowy=false]
setblock 422 65 -296 regions_unexplored:peat_mud
fill 406 65 -297 418 65 -297 minecraft:air
fill 419 65 -297 420 65 -297 minecraft:grass_block[snowy=false]
fill 421 65 -297 422 65 -297 regions_unexplored:peat_mud
fill 406 65 -298 418 65 -298 minecraft:air
setblock 419 65 -298 regions_unexplored:grass_sprouts
fill 420 65 -298 422 65 -298 regions_unexplored:peat_mud
fill 406 65 -299 419 65 -299 minecraft:air
setblock 420 65 -299 regions_unexplored:grass_sprouts
setblock 421 65 -299 minecraft:short_grass
setblock 422 65 -299 regions_unexplored:peat_mud
fill 407 65 -300 421 65 -300 minecraft:air
setblock 422 65 -300 regions_unexplored:grass_sprouts
fill 406 65 -301 422 65 -301 minecraft:air
fill 405 65 -302 422 65 -302 minecraft:air
fill 404 65 -303 422 65 -303 minecraft:air
fill 403 65 -304 422 65 -304 minecraft:air
fill 403 65 -305 422 65 -305 minecraft:air
fill 404 65 -306 422 65 -306 minecraft:air
fill 404 65 -307 422 65 -307 minecraft:air
fill 405 65 -308 422 65 -308 minecraft:air
fill 404 65 -309 422 65 -309 minecraft:air
fill 405 65 -310 422 65 -310 minecraft:air
fill 405 65 -311 422 65 -311 minecraft:air
fill 404 65 -312 422 65 -312 minecraft:air
setblock 399 65 -313 regions_unexplored:peat_mud
fill 402 65 -313 422 65 -313 minecraft:air
setblock 399 65 -314 regions_unexplored:peat_mud
fill 401 65 -314 403 65 -314 minecraft:air
setblock 404 65 -314 minecraft:short_grass
fill 405 65 -314 422 65 -314 minecraft:air
fill 400 65 -315 422 65 -315 minecraft:air
fill 400 65 -316 415 65 -316 minecraft:air
fill 417 65 -316 422 65 -316 minecraft:air
fill 400 65 -317 422 65 -317 minecraft:air
fill 399 65 -318 422 65 -318 minecraft:air
setblock 392 64 -255 minecraft:air
fill 413 64 -256 416 64 -256 minecraft:air
fill 413 64 -257 418 64 -257 minecraft:air
fill 413 64 -258 418 64 -258 minecraft:air
fill 414 64 -259 418 64 -259 minecraft:air
setblock 416 64 -260 minecraft:air
setblock 421 64 -260 minecraft:air
fill 421 64 -261 422 64 -261 minecraft:air
fill 421 64 -262 422 64 -262 minecraft:air
fill 420 64 -263 422 64 -263 minecraft:air
fill 421 64 -264 422 64 -264 minecraft:air
setblock 422 64 -265 minecraft:air
setblock 422 64 -272 minecraft:air
fill 421 64 -273 422 64 -273 minecraft:air
fill 414 64 -274 415 64 -274 minecraft:air
fill 419 64 -274 422 64 -274 minecraft:air
fill 414 64 -275 415 64 -275 minecraft:air
fill 419 64 -275 422 64 -275 minecraft:air
fill 413 64 -276 414 64 -276 minecraft:air
fill 418 64 -276 422 64 -276 minecraft:air
fill 412 64 -277 414 64 -277 minecraft:air
fill 418 64 -277 422 64 -277 minecraft:air
fill 412 64 -278 413 64 -278 minecraft:air
fill 418 64 -278 422 64 -278 minecraft:air
fill 411 64 -279 412 64 -279 minecraft:air
fill 418 64 -279 422 64 -279 minecraft:air
fill 410 64 -280 412 64 -280 minecraft:air
fill 418 64 -280 422 64 -280 minecraft:air
fill 410 64 -281 412 64 -281 minecraft:air
fill 417 64 -281 422 64 -281 minecraft:air
fill 409 64 -282 411 64 -282 minecraft:air
fill 417 64 -282 422 64 -282 minecraft:air
fill 409 64 -283 412 64 -283 minecraft:air
fill 417 64 -283 422 64 -283 minecraft:air
fill 409 64 -284 410 64 -284 minecraft:air
fill 415 64 -284 422 64 -284 minecraft:air
fill 408 64 -285 410 64 -285 minecraft:air
fill 413 64 -285 422 64 -285 minecraft:air
fill 406 64 -286 422 64 -286 minecraft:air
fill 407 64 -287 420 64 -287 minecraft:air
setblock 422 64 -287 minecraft:air
fill 404 64 -288 422 64 -288 minecraft:air
fill 403 64 -289 422 64 -289 minecraft:air
fill 402 64 -290 420 64 -290 minecraft:air
fill 400 64 -291 416 64 -291 minecraft:air
setblock 418 64 -291 minecraft:air
fill 400 64 -292 415 64 -292 minecraft:air
setblock 417 64 -292 regions_unexplored:grass_sprouts
fill 399 64 -293 417 64 -293 minecraft:air
fill 397 64 -294 416 64 -294 minecraft:air
setblock 417 64 -294 regions_unexplored:grass_sprouts
fill 396 64 -295 402 64 -295 minecraft:air
fill 405 64 -295 413 64 -295 minecraft:air
setblock 414 64 -295 minecraft:short_grass
fill 415 64 -295 417 64 -295 regions_unexplored:grass_sprouts
fill 393 64 -296 402 64 -296 minecraft:air
fill 406 64 -296 414 64 -296 minecraft:air
setblock 415 64 -296 regions_unexplored:grass_sprouts
setblock 416 64 -296 minecraft:air
fill 393 64 -297 400 64 -297 minecraft:air
fill 407 64 -297 412 64 -297 minecraft:air
setblock 413 64 -297 minecraft:short_grass
fill 414 64 -297 415 64 -297 minecraft:air
setblock 416 64 -297 minecraft:short_grass
setblock 417 64 -297 minecraft:air
fill 392 64 -298 399 64 -298 minecraft:air
fill 407 64 -298 417 64 -298 minecraft:air
setblock 418 64 -298 minecraft:short_grass
fill 392 64 -299 397 64 -299 minecraft:air
fill 408 64 -299 419 64 -299 minecraft:air
fill 392 64 -300 400 64 -300 minecraft:air
fill 408 64 -300 421 64 -300 minecraft:air
fill 392 64 -301 394 64 -301 minecraft:air
fill 397 64 -301 400 64 -301 minecraft:air
fill 407 64 -301 421 64 -301 minecraft:air
setblock 392 64 -302 minecraft:air
fill 398 64 -302 400 64 -302 minecraft:air
fill 406 64 -302 422 64 -302 minecraft:air
setblock 392 64 -303 minecraft:air
fill 404 64 -303 422 64 -303 minecraft:air
setblock 392 64 -304 minecraft:air
fill 403 64 -304 422 64 -304 minecraft:air
fill 404 64 -305 422 64 -305 minecraft:air
fill 405 64 -306 422 64 -306 minecraft:air
fill 405 64 -307 406 64 -307 minecraft:air
fill 408 64 -307 419 64 -307 minecraft:air
setblock 420 64 -307 minecraft:short_grass
fill 421 64 -307 422 64 -307 minecraft:air
fill 406 64 -308 420 64 -308 minecraft:air
setblock 421 64 -308 minecraft:short_grass
setblock 422 64 -308 minecraft:air
fill 406 64 -309 422 64 -309 minecraft:air
fill 407 64 -310 422 64 -310 minecraft:air
fill 392 64 -311 393 64 -311 minecraft:air
fill 407 64 -311 410 64 -311 minecraft:air
setblock 411 64 -311 minecraft:short_grass
fill 412 64 -311 419 64 -311 minecraft:air
setblock 422 64 -311 minecraft:air
fill 392 64 -312 395 64 -312 minecraft:air
fill 407 64 -312 419 64 -312 minecraft:air
setblock 422 64 -312 minecraft:air
fill 392 64 -313 397 64 -313 minecraft:air
fill 406 64 -313 419 64 -313 minecraft:air
fill 421 64 -313 422 64 -313 minecraft:air
fill 392 64 -314 399 64 -314 minecraft:air
setblock 405 64 -314 minecraft:air
setblock 406 64 -314 regions_unexplored:grass_sprouts
fill 407 64 -314 422 64 -314 minecraft:air
fill 392 64 -315 399 64 -315 minecraft:air
fill 403 64 -315 414 64 -315 minecraft:air
fill 419 64 -315 422 64 -315 minecraft:air
fill 394 64 -316 399 64 -316 minecraft:air
fill 402 64 -316 404 64 -316 minecraft:air
setblock 405 64 -316 regions_unexplored:grass_sprouts
fill 406 64 -316 413 64 -316 minecraft:air
fill 419 64 -316 422 64 -316 minecraft:air
fill 395 64 -317 399 64 -317 minecraft:air
fill 402 64 -317 404 64 -317 minecraft:air
setblock 405 64 -317 minecraft:short_grass
fill 406 64 -317 415 64 -317 minecraft:air
setblock 418 64 -317 minecraft:air
setblock 419 64 -317 regions_unexplored:grass_sprouts
fill 420 64 -317 422 64 -317 minecraft:air
fill 396 64 -318 398 64 -318 minecraft:air
fill 401 64 -318 422 64 -318 minecraft:air
setblock 416 63 -256 minecraft:air
fill 415 63 -257 419 63 -257 minecraft:air
fill 414 63 -258 420 63 -258 minecraft:air
fill 415 63 -259 422 63 -259 minecraft:air
fill 417 63 -260 418 63 -260 minecraft:air
fill 420 63 -260 422 63 -260 minecraft:air
fill 419 63 -262 422 63 -262 minecraft:air
fill 421 63 -263 422 63 -263 minecraft:air
setblock 415 63 -273 minecraft:air
fill 414 63 -274 416 63 -274 minecraft:air
fill 413 63 -275 415 63 -275 minecraft:air
fill 412 63 -276 414 63 -276 minecraft:air
fill 412 63 -277 414 63 -277 minecraft:air
fill 412 63 -278 413 63 -278 minecraft:air
fill 410 63 -279 412 63 -279 minecraft:air
fill 410 63 -280 413 63 -280 minecraft:air
fill 409 63 -281 412 63 -281 minecraft:air
fill 408 63 -282 411 63 -282 minecraft:air
fill 408 63 -283 411 63 -283 minecraft:air
fill 408 63 -284 411 63 -284 minecraft:air
fill 407 63 -285 410 63 -285 minecraft:air
fill 407 63 -286 410 63 -286 minecraft:air
fill 406 63 -287 410 63 -287 minecraft:air
fill 405 63 -288 410 63 -288 minecraft:air
fill 404 63 -289 409 63 -289 minecraft:air
fill 403 63 -290 409 63 -290 minecraft:air
fill 401 63 -291 409 63 -291 minecraft:air
fill 399 63 -292 408 63 -292 minecraft:air
fill 397 63 -293 407 63 -293 minecraft:air
fill 396 63 -294 406 63 -294 minecraft:air
fill 393 63 -295 405 63 -295 minecraft:air
fill 392 63 -296 404 63 -296 minecraft:air
fill 392 63 -297 402 63 -297 minecraft:air
setblock 412 63 -297 minecraft:air
fill 392 63 -298 401 63 -298 minecraft:air
fill 412 63 -298 417 63 -298 minecraft:air
fill 392 63 -299 399 63 -299 minecraft:air
fill 411 63 -299 417 63 -299 minecraft:air
fill 392 63 -300 398 63 -300 minecraft:air
fill 410 63 -300 418 63 -300 minecraft:air
fill 392 63 -301 397 63 -301 minecraft:air
fill 411 63 -301 419 63 -301 minecraft:air
fill 392 63 -302 394 63 -302 minecraft:air
setblock 411 63 -302 minecraft:air
setblock 412 63 -302 minecraft:short_grass
fill 413 63 -302 419 63 -302 minecraft:air
fill 392 63 -303 393 63 -303 minecraft:air
fill 410 63 -303 419 63 -303 minecraft:air
fill 392 63 -304 393 63 -304 minecraft:air
fill 412 63 -304 419 63 -304 minecraft:air
fill 411 63 -305 420 63 -305 minecraft:air
fill 408 63 -306 419 63 -306 minecraft:air
fill 408 63 -307 419 63 -307 minecraft:air
fill 408 63 -308 419 63 -308 minecraft:air
fill 408 63 -309 419 63 -309 minecraft:air
fill 409 63 -310 418 63 -310 minecraft:air
setblock 422 63 -310 minecraft:air
fill 392 63 -311 393 63 -311 minecraft:air
fill 413 63 -311 418 63 -311 minecraft:air
fill 392 63 -312 395 63 -312 minecraft:air
fill 415 63 -312 416 63 -312 minecraft:air
fill 392 63 -313 397 63 -313 minecraft:air
fill 392 63 -314 399 63 -314 minecraft:air
setblock 408 63 -314 minecraft:air
fill 392 63 -315 401 63 -315 minecraft:air
fill 407 63 -315 409 63 -315 minecraft:air
fill 394 63 -316 400 63 -316 minecraft:air
setblock 406 63 -316 minecraft:short_grass
fill 407 63 -316 409 63 -316 minecraft:air
fill 421 63 -316 422 63 -316 minecraft:air
fill 395 63 -317 400 63 -317 minecraft:air
fill 406 63 -317 411 63 -317 minecraft:air
fill 420 63 -317 422 63 -317 minecraft:air
fill 396 63 -318 400 63 -318 minecraft:air
fill 404 63 -318 414 63 -318 minecraft:air
setblock 417 63 -318 minecraft:air
fill 419 63 -318 422 63 -318 minecraft:air
fill 416 62 -257 422 62 -257 minecraft:air
fill 416 62 -258 422 62 -258 minecraft:air
fill 416 62 -259 422 62 -259 minecraft:air
fill 417 62 -260 422 62 -260 minecraft:air
fill 417 62 -261 418 62 -261 minecraft:air
setblock 422 62 -262 minecraft:water[level=0]
setblock 415 62 -273 minecraft:water[level=0]
fill 414 62 -274 416 62 -274 minecraft:water[level=0]
fill 413 62 -275 416 62 -275 minecraft:water[level=0]
fill 412 62 -276 414 62 -276 minecraft:water[level=0]
fill 412 62 -277 414 62 -277 minecraft:water[level=0]
fill 412 62 -278 413 62 -278 minecraft:water[level=0]
fill 410 62 -279 412 62 -279 minecraft:water[level=0]
fill 409 62 -280 413 62 -280 minecraft:water[level=0]
fill 409 62 -281 413 62 -281 minecraft:water[level=0]
fill 408 62 -282 412 62 -282 minecraft:water[level=0]
fill 408 62 -283 411 62 -283 minecraft:water[level=0]
fill 408 62 -284 411 62 -284 minecraft:water[level=0]
fill 407 62 -285 410 62 -285 minecraft:water[level=0]
fill 407 62 -286 410 62 -286 minecraft:water[level=0]
fill 406 62 -287 410 62 -287 minecraft:water[level=0]
fill 405 62 -288 410 62 -288 minecraft:water[level=0]
fill 404 62 -289 409 62 -289 minecraft:water[level=0]
fill 402 62 -290 409 62 -290 minecraft:water[level=0]
fill 401 62 -291 408 62 -291 minecraft:water[level=0]
fill 399 62 -292 408 62 -292 minecraft:water[level=0]
fill 397 62 -293 407 62 -293 minecraft:water[level=0]
fill 395 62 -294 406 62 -294 minecraft:water[level=0]
fill 393 62 -295 405 62 -295 minecraft:water[level=0]
fill 392 62 -296 404 62 -296 minecraft:water[level=0]
fill 392 62 -297 403 62 -297 minecraft:water[level=0]
fill 392 62 -298 401 62 -298 minecraft:water[level=0]
fill 392 62 -299 399 62 -299 minecraft:water[level=0]
fill 392 62 -300 398 62 -300 minecraft:water[level=0]
fill 392 62 -301 397 62 -301 minecraft:water[level=0]
fill 392 62 -302 395 62 -302 minecraft:water[level=0]
fill 392 62 -303 394 62 -303 minecraft:water[level=0]
fill 392 62 -304 393 62 -304 minecraft:water[level=0]
setblock 393 62 -305 minecraft:water[level=0]
setblock 392 62 -306 minecraft:water[level=0]
setblock 392 62 -311 minecraft:water[level=0]
fill 392 62 -312 394 62 -312 minecraft:water[level=0]
fill 392 62 -313 396 62 -313 minecraft:water[level=0]
fill 392 62 -314 398 62 -314 minecraft:water[level=0]
fill 393 62 -315 400 62 -315 minecraft:water[level=0]
fill 394 62 -316 401 62 -316 minecraft:water[level=0]
fill 396 62 -317 402 62 -317 minecraft:water[level=0]
fill 397 62 -318 405 62 -318 minecraft:water[level=0]
fill 421 62 -318 422 62 -318 minecraft:water[level=0]
setblock 419 61 -255 minecraft:air
fill 416 61 -256 421 61 -256 minecraft:air
fill 416 61 -257 421 61 -257 minecraft:air
fill 417 61 -258 422 61 -258 minecraft:air
fill 417 61 -259 421 61 -259 minecraft:air
fill 417 61 -260 419 61 -260 minecraft:air
fill 421 61 -260 422 61 -260 minecraft:air
setblock 421 61 -261 minecraft:air
fill 414 61 -274 416 61 -274 minecraft:water[level=0]
fill 413 61 -275 415 61 -275 minecraft:water[level=0]
fill 412 61 -276 414 61 -276 minecraft:water[level=0]
fill 412 61 -277 414 61 -277 minecraft:water[level=0]
fill 412 61 -278 413 61 -278 minecraft:water[level=0]
fill 410 61 -279 412 61 -279 minecraft:water[level=0]
fill 410 61 -280 412 61 -280 minecraft:water[level=0]
fill 409 61 -281 412 61 -281 minecraft:water[level=0]
fill 408 61 -282 411 61 -282 minecraft:water[level=0]
fill 408 61 -283 411 61 -283 minecraft:water[level=0]
fill 408 61 -284 411 61 -284 minecraft:water[level=0]
fill 407 61 -285 410 61 -285 minecraft:water[level=0]
fill 407 61 -286 410 61 -286 minecraft:water[level=0]
fill 406 61 -287 410 61 -287 minecraft:water[level=0]
fill 405 61 -288 409 61 -288 minecraft:water[level=0]
fill 405 61 -289 409 61 -289 minecraft:water[level=0]
fill 403 61 -290 409 61 -290 minecraft:water[level=0]
fill 402 61 -291 408 61 -291 minecraft:water[level=0]
fill 400 61 -292 407 61 -292 minecraft:water[level=0]
fill 398 61 -293 407 61 -293 minecraft:water[level=0]
fill 397 61 -294 406 61 -294 minecraft:water[level=0]
setblock 392 61 -295 minecraft:water[level=0]
fill 394 61 -295 404 61 -295 minecraft:water[level=0]
fill 393 61 -296 403 61 -296 minecraft:water[level=0]
fill 392 61 -297 402 61 -297 minecraft:water[level=0]
fill 392 61 -298 400 61 -298 minecraft:water[level=0]
fill 392 61 -299 398 61 -299 minecraft:water[level=0]
fill 392 61 -300 397 61 -300 minecraft:water[level=0]
fill 392 61 -301 396 61 -301 minecraft:water[level=0]
fill 392 61 -302 394 61 -302 minecraft:water[level=0]
fill 392 61 -303 393 61 -303 minecraft:water[level=0]
fill 392 61 -304 393 61 -304 minecraft:water[level=0]
fill 392 61 -311 393 61 -311 minecraft:water[level=0]
fill 392 61 -312 395 61 -312 minecraft:water[level=0]
fill 392 61 -313 397 61 -313 minecraft:water[level=0]
fill 392 61 -314 399 61 -314 minecraft:water[level=0]
fill 392 61 -315 401 61 -315 minecraft:water[level=0]
fill 394 61 -316 402 61 -316 minecraft:water[level=0]
fill 395 61 -317 403 61 -317 minecraft:water[level=0]
fill 396 61 -318 406 61 -318 minecraft:water[level=0]
fill 415 60 -255 418 60 -255 minecraft:air
fill 415 60 -256 420 60 -256 minecraft:air
fill 415 60 -257 421 60 -257 minecraft:air
fill 416 60 -258 421 60 -258 minecraft:air
fill 418 60 -259 421 60 -259 minecraft:air
setblock 419 60 -260 minecraft:air
fill 414 60 -274 416 60 -274 minecraft:water[level=0]
fill 413 60 -275 415 60 -275 minecraft:water[level=0]
fill 412 60 -276 414 60 -276 minecraft:water[level=0]
fill 412 60 -277 414 60 -277 minecraft:water[level=0]
fill 412 60 -278 413 60 -278 minecraft:water[level=0]
fill 410 60 -279 412 60 -279 minecraft:water[level=0]
fill 410 60 -280 412 60 -280 minecraft:water[level=0]
fill 409 60 -281 412 60 -281 minecraft:water[level=0]
fill 408 60 -282 411 60 -282 minecraft:water[level=0]
fill 408 60 -283 411 60 -283 minecraft:water[level=0]
fill 408 60 -284 411 60 -284 minecraft:water[level=0]
fill 407 60 -285 410 60 -285 minecraft:water[level=0]
fill 407 60 -286 410 60 -286 minecraft:water[level=0]
fill 406 60 -287 410 60 -287 minecraft:water[level=0]
fill 405 60 -288 409 60 -288 minecraft:water[level=0]
fill 405 60 -289 409 60 -289 minecraft:water[level=0]
setblock 395 60 -290 minecraft:water[level=0]
fill 403 60 -290 409 60 -290 minecraft:water[level=0]
fill 402 60 -291 408 60 -291 minecraft:water[level=0]
setblock 394 60 -292 minecraft:water[level=0]
fill 400 60 -292 407 60 -292 minecraft:water[level=0]
setblock 394 60 -293 minecraft:water[level=0]
fill 398 60 -293 406 60 -293 minecraft:water[level=0]
setblock 393 60 -294 minecraft:water[level=0]
fill 397 60 -294 406 60 -294 minecraft:water[level=0]
fill 393 60 -295 404 60 -295 minecraft:water[level=0]
fill 392 60 -296 403 60 -296 minecraft:water[level=0]
fill 392 60 -297 402 60 -297 minecraft:water[level=0]
fill 392 60 -298 400 60 -298 minecraft:water[level=0]
fill 392 60 -299 398 60 -299 minecraft:water[level=0]
fill 392 60 -300 397 60 -300 minecraft:water[level=0]
fill 392 60 -301 396 60 -301 minecraft:water[level=0]
fill 392 60 -302 394 60 -302 minecraft:water[level=0]
fill 392 60 -303 393 60 -303 minecraft:water[level=0]
fill 392 60 -304 393 60 -304 minecraft:water[level=0]
fill 392 60 -311 393 60 -311 minecraft:water[level=0]
fill 392 60 -312 395 60 -312 minecraft:water[level=0]
fill 392 60 -313 397 60 -313 minecraft:water[level=0]
fill 392 60 -314 399 60 -314 minecraft:water[level=0]
fill 392 60 -315 401 60 -315 minecraft:water[level=0]
fill 394 60 -316 402 60 -316 minecraft:water[level=0]
fill 395 60 -317 403 60 -317 minecraft:water[level=0]
fill 396 60 -318 406 60 -318 minecraft:water[level=0]
fill 414 59 -255 417 59 -255 minecraft:air
fill 414 59 -256 421 59 -256 minecraft:air
fill 415 59 -257 422 59 -257 minecraft:air
fill 418 59 -258 422 59 -258 minecraft:air
fill 419 59 -259 421 59 -259 minecraft:air
fill 414 59 -274 416 59 -274 minecraft:water[level=0]
fill 413 59 -275 415 59 -275 minecraft:water[level=0]
fill 412 59 -276 414 59 -276 minecraft:water[level=0]
fill 412 59 -277 414 59 -277 minecraft:water[level=0]
fill 412 59 -278 413 59 -278 minecraft:water[level=0]
fill 410 59 -279 412 59 -279 minecraft:water[level=0]
fill 410 59 -280 412 59 -280 minecraft:water[level=0]
fill 409 59 -281 412 59 -281 minecraft:water[level=0]
fill 408 59 -282 411 59 -282 minecraft:water[level=0]
fill 408 59 -283 411 59 -283 minecraft:water[level=0]
fill 408 59 -284 411 59 -284 minecraft:water[level=0]
fill 407 59 -285 410 59 -285 minecraft:water[level=0]
fill 407 59 -286 410 59 -286 minecraft:water[level=0]
fill 406 59 -287 410 59 -287 minecraft:water[level=0]
fill 405 59 -288 409 59 -288 minecraft:water[level=0]
setblock 396 59 -289 minecraft:water[level=0]
fill 405 59 -289 409 59 -289 minecraft:water[level=0]
fill 395 59 -290 396 59 -290 minecraft:water[level=0]
fill 403 59 -290 409 59 -290 minecraft:water[level=0]
fill 395 59 -291 396 59 -291 minecraft:water[level=0]
fill 402 59 -291 408 59 -291 minecraft:water[level=0]
fill 394 59 -292 396 59 -292 minecraft:water[level=0]
fill 400 59 -292 407 59 -292 minecraft:water[level=0]
fill 394 59 -293 395 59 -293 minecraft:water[level=0]
fill 398 59 -293 406 59 -293 minecraft:water[level=0]
fill 393 59 -294 395 59 -294 minecraft:water[level=0]
fill 397 59 -294 406 59 -294 minecraft:water[level=0]
fill 393 59 -295 404 59 -295 minecraft:water[level=0]
fill 392 59 -296 403 59 -296 minecraft:water[level=0]
fill 392 59 -297 402 59 -297 minecraft:water[level=0]
fill 392 59 -298 400 59 -298 minecraft:water[level=0]
fill 392 59 -299 398 59 -299 minecraft:water[level=0]
fill 392 59 -300 397 59 -300 minecraft:water[level=0]
fill 392 59 -301 396 59 -301 minecraft:water[level=0]
fill 392 59 -302 394 59 -302 minecraft:water[level=0]
fill 392 59 -303 393 59 -303 minecraft:water[level=0]
fill 392 59 -304 393 59 -304 minecraft:water[level=0]
setblock 392 59 -310 minecraft:water[level=0]
fill 392 59 -311 394 59 -311 minecraft:water[level=0]
fill 392 59 -312 397 59 -312 minecraft:water[level=0]
fill 392 59 -313 398 59 -313 minecraft:water[level=0]
fill 392 59 -314 400 59 -314 minecraft:water[level=0]
fill 392 59 -315 402 59 -315 minecraft:water[level=0]
fill 393 59 -316 403 59 -316 minecraft:water[level=0]
fill 394 59 -317 405 59 -317 minecraft:water[level=0]
fill 395 59 -318 407 59 -318 minecraft:water[level=0]
fill 413 58 -255 416 58 -255 minecraft:air
fill 414 58 -256 416 58 -256 minecraft:air
fill 420 58 -256 422 58 -256 minecraft:air
setblock 414 58 -257 minecraft:air
fill 419 58 -257 422 58 -257 minecraft:air
fill 419 58 -258 422 58 -258 minecraft:air
fill 420 58 -259 421 58 -259 minecraft:air
fill 414 58 -274 416 58 -274 minecraft:water[level=0]
fill 413 58 -275 415 58 -275 minecraft:water[level=0]
fill 412 58 -276 414 58 -276 minecraft:water[level=0]
fill 412 58 -277 414 58 -277 minecraft:water[level=0]
fill 412 58 -278 413 58 -278 minecraft:water[level=0]
fill 410 58 -279 412 58 -279 minecraft:water[level=0]
fill 410 58 -280 412 58 -280 minecraft:water[level=0]
fill 409 58 -281 412 58 -281 minecraft:water[level=0]
fill 408 58 -282 411 58 -282 minecraft:water[level=0]
fill 408 58 -283 411 58 -283 minecraft:water[level=0]
fill 408 58 -284 411 58 -284 minecraft:water[level=0]
fill 407 58 -285 410 58 -285 minecraft:water[level=0]
fill 407 58 -286 410 58 -286 minecraft:water[level=0]
setblock 397 58 -287 minecraft:water[level=0]
fill 406 58 -287 410 58 -287 minecraft:water[level=0]
setblock 397 58 -288 minecraft:water[level=0]
fill 405 58 -288 409 58 -288 minecraft:water[level=0]
fill 396 58 -289 397 58 -289 minecraft:water[level=0]
fill 405 58 -289 409 58 -289 minecraft:water[level=0]
fill 396 58 -290 397 58 -290 minecraft:water[level=0]
fill 403 58 -290 409 58 -290 minecraft:water[level=0]
fill 395 58 -291 397 58 -291 minecraft:water[level=0]
fill 402 58 -291 408 58 -291 minecraft:water[level=0]
fill 394 58 -292 396 58 -292 minecraft:water[level=0]
fill 400 58 -292 407 58 -292 minecraft:water[level=0]
fill 394 58 -293 396 58 -293 minecraft:water[level=0]
fill 398 58 -293 406 58 -293 minecraft:water[level=0]
fill 394 58 -294 395 58 -294 minecraft:water[level=0]
fill 397 58 -294 406 58 -294 minecraft:water[level=0]
fill 393 58 -295 404 58 -295 minecraft:water[level=0]
fill 393 58 -296 403 58 -296 minecraft:water[level=0]
fill 392 58 -297 402 58 -297 minecraft:water[level=0]
fill 392 58 -298 400 58 -298 minecraft:water[level=0]
fill 392 58 -299 398 58 -299 minecraft:water[level=0]
fill 392 58 -300 397 58 -300 minecraft:water[level=0]
fill 392 58 -301 396 58 -301 minecraft:water[level=0]
fill 392 58 -302 394 58 -302 minecraft:water[level=0]
fill 392 58 -303 393 58 -303 minecraft:water[level=0]
fill 392 58 -304 393 58 -304 minecraft:water[level=0]
setblock 392 58 -310 minecraft:water[level=0]
fill 392 58 -311 394 58 -311 minecraft:water[level=0]
fill 392 58 -312 397 58 -312 minecraft:water[level=0]
fill 392 58 -313 398 58 -313 minecraft:water[level=0]
fill 392 58 -314 400 58 -314 minecraft:water[level=0]
fill 392 58 -315 402 58 -315 minecraft:water[level=0]
fill 393 58 -316 403 58 -316 minecraft:water[level=0]
fill 394 58 -317 405 58 -317 minecraft:water[level=0]
fill 395 58 -318 407 58 -318 minecraft:water[level=0]
fill 412 57 -255 415 57 -255 minecraft:air
fill 413 57 -256 414 57 -256 minecraft:air
fill 420 57 -256 422 57 -256 minecraft:air
fill 420 57 -257 422 57 -257 minecraft:air
fill 420 57 -258 422 57 -258 minecraft:air
fill 421 57 -259 422 57 -259 minecraft:air
fill 414 57 -274 415 57 -274 minecraft:water[level=0]
fill 414 57 -275 415 57 -275 minecraft:water[level=0]
fill 412 57 -276 414 57 -276 minecraft:water[level=0]
fill 412 57 -277 414 57 -277 minecraft:water[level=0]
fill 412 57 -278 413 57 -278 minecraft:water[level=0]
fill 410 57 -279 412 57 -279 minecraft:water[level=0]
fill 410 57 -280 412 57 -280 minecraft:water[level=0]
fill 409 57 -281 412 57 -281 minecraft:water[level=0]
fill 409 57 -282 411 57 -282 minecraft:water[level=0]
setblock 399 57 -283 minecraft:water[level=0]
fill 408 57 -283 411 57 -283 minecraft:water[level=0]
setblock 399 57 -284 minecraft:water[level=0]
fill 408 57 -284 411 57 -284 minecraft:water[level=0]
setblock 398 57 -285 minecraft:water[level=0]
fill 407 57 -285 410 57 -285 minecraft:water[level=0]
setblock 398 57 -286 minecraft:water[level=0]
fill 407 57 -286 410 57 -286 minecraft:water[level=0]
fill 397 57 -287 398 57 -287 minecraft:water[level=0]
fill 406 57 -287 409 57 -287 minecraft:water[level=0]
fill 397 57 -288 398 57 -288 minecraft:water[level=0]
fill 406 57 -288 409 57 -288 minecraft:water[level=0]
fill 396 57 -289 397 57 -289 minecraft:water[level=0]
fill 405 57 -289 409 57 -289 minecraft:water[level=0]
fill 396 57 -290 397 57 -290 minecraft:water[level=0]
fill 403 57 -290 409 57 -290 minecraft:water[level=0]
fill 395 57 -291 397 57 -291 minecraft:water[level=0]
fill 402 57 -291 408 57 -291 minecraft:water[level=0]
fill 395 57 -292 396 57 -292 minecraft:water[level=0]
fill 400 57 -292 407 57 -292 minecraft:water[level=0]
fill 394 57 -293 396 57 -293 minecraft:water[level=0]
fill 398 57 -293 406 57 -293 minecraft:water[level=0]
fill 394 57 -294 395 57 -294 minecraft:water[level=0]
fill 397 57 -294 406 57 -294 minecraft:water[level=0]
fill 393 57 -295 404 57 -295 minecraft:water[level=0]
fill 393 57 -296 403 57 -296 minecraft:water[level=0]
fill 392 57 -297 402 57 -297 minecraft:water[level=0]
fill 392 57 -298 400 57 -298 minecraft:water[level=0]
fill 392 57 -299 398 57 -299 minecraft:water[level=0]
fill 392 57 -300 397 57 -300 minecraft:water[level=0]
fill 392 57 -301 396 57 -301 minecraft:water[level=0]
fill 392 57 -302 394 57 -302 minecraft:water[level=0]
fill 392 57 -303 393 57 -303 minecraft:water[level=0]
fill 392 57 -304 393 57 -304 minecraft:water[level=0]
setblock 392 57 -310 minecraft:water[level=0]
fill 392 57 -311 394 57 -311 minecraft:water[level=0]
fill 392 57 -312 397 57 -312 minecraft:water[level=0]
fill 392 57 -313 398 57 -313 minecraft:water[level=0]
fill 392 57 -314 400 57 -314 minecraft:water[level=0]
fill 392 57 -315 402 57 -315 minecraft:water[level=0]
fill 393 57 -316 403 57 -316 minecraft:water[level=0]
fill 394 57 -317 405 57 -317 minecraft:water[level=0]
fill 395 57 -318 407 57 -318 minecraft:water[level=0]
fill 412 56 -255 413 56 -255 minecraft:air
fill 414 56 -274 415 56 -274 minecraft:water[level=0]
fill 414 56 -275 415 56 -275 minecraft:water[level=0]
fill 412 56 -276 414 56 -276 minecraft:water[level=0]
fill 412 56 -277 414 56 -277 minecraft:water[level=0]
fill 412 56 -278 413 56 -278 minecraft:water[level=0]
fill 410 56 -279 412 56 -279 minecraft:water[level=0]
fill 410 56 -280 412 56 -280 minecraft:water[level=0]
fill 409 56 -281 412 56 -281 minecraft:water[level=0]
fill 409 56 -282 411 56 -282 minecraft:water[level=0]
setblock 399 56 -283 minecraft:water[level=0]
fill 408 56 -283 411 56 -283 minecraft:water[level=0]
setblock 399 56 -284 minecraft:water[level=0]
fill 408 56 -284 411 56 -284 minecraft:water[level=0]
fill 398 56 -285 399 56 -285 minecraft:water[level=0]
fill 407 56 -285 410 56 -285 minecraft:water[level=0]
fill 398 56 -286 399 56 -286 minecraft:water[level=0]
fill 407 56 -286 410 56 -286 minecraft:water[level=0]
fill 397 56 -287 398 56 -287 minecraft:water[level=0]
fill 406 56 -287 409 56 -287 minecraft:water[level=0]
fill 397 56 -288 398 56 -288 minecraft:water[level=0]
fill 406 56 -288 409 56 -288 minecraft:water[level=0]
fill 396 56 -289 397 56 -289 minecraft:water[level=0]
fill 405 56 -289 409 56 -289 minecraft:water[level=0]
fill 396 56 -290 397 56 -290 minecraft:water[level=0]
fill 403 56 -290 409 56 -290 minecraft:water[level=0]
fill 395 56 -291 397 56 -291 minecraft:water[level=0]
fill 402 56 -291 408 56 -291 minecraft:water[level=0]
fill 395 56 -292 396 56 -292 minecraft:water[level=0]
fill 400 56 -292 407 56 -292 minecraft:water[level=0]
fill 395 56 -293 396 56 -293 minecraft:water[level=0]
fill 398 56 -293 406 56 -293 minecraft:water[level=0]
fill 394 56 -294 395 56 -294 minecraft:water[level=0]
fill 397 56 -294 405 56 -294 minecraft:water[level=0]
fill 394 56 -295 404 56 -295 minecraft:water[level=0]
fill 393 56 -296 403 56 -296 minecraft:water[level=0]
fill 392 56 -297 402 56 -297 minecraft:water[level=0]
fill 392 56 -298 400 56 -298 minecraft:water[level=0]
fill 392 56 -299 398 56 -299 minecraft:water[level=0]
fill 392 56 -300 397 56 -300 minecraft:water[level=0]
fill 392 56 -301 396 56 -301 minecraft:water[level=0]
fill 392 56 -302 393 56 -302 minecraft:water[level=0]
fill 392 56 -303 393 56 -303 minecraft:water[level=0]
fill 392 56 -304 393 56 -304 minecraft:water[level=0]
setblock 392 56 -311 minecraft:water[level=0]
fill 392 56 -312 393 56 -312 minecraft:water[level=0]
fill 392 56 -313 396 56 -313 minecraft:water[level=0]
fill 392 56 -314 397 56 -314 minecraft:water[level=0]
fill 393 56 -315 399 56 -315 minecraft:water[level=0]
fill 395 56 -316 401 56 -316 minecraft:water[level=0]
fill 396 56 -317 402 56 -317 minecraft:water[level=0]
fill 398 56 -318 403 56 -318 minecraft:water[level=0]
setblock 412 55 -255 minecraft:air
fill 414 55 -274 415 55 -274 minecraft:water[level=0]
fill 414 55 -275 415 55 -275 minecraft:water[level=0]
fill 413 55 -276 414 55 -276 minecraft:water[level=0]
fill 412 55 -277 414 55 -277 minecraft:water[level=0]
fill 412 55 -278 413 55 -278 minecraft:water[level=0]
fill 410 55 -279 412 55 -279 minecraft:water[level=0]
setblock 401 55 -280 minecraft:water[level=0]
fill 410 55 -280 412 55 -280 minecraft:water[level=0]
fill 400 55 -281 401 55 -281 minecraft:water[level=0]
fill 409 55 -281 412 55 -281 minecraft:water[level=0]
fill 400 55 -282 401 55 -282 minecraft:water[level=0]
fill 409 55 -282 411 55 -282 minecraft:water[level=0]
fill 399 55 -283 401 55 -283 minecraft:water[level=0]
fill 408 55 -283 411 55 -283 minecraft:water[level=0]
fill 399 55 -284 400 55 -284 minecraft:water[level=0]
fill 408 55 -284 411 55 -284 minecraft:water[level=0]
fill 398 55 -285 399 55 -285 minecraft:water[level=0]
fill 407 55 -285 410 55 -285 minecraft:water[level=0]
fill 398 55 -286 399 55 -286 minecraft:water[level=0]
fill 407 55 -286 410 55 -286 minecraft:water[level=0]
fill 397 55 -287 398 55 -287 minecraft:water[level=0]
fill 406 55 -287 409 55 -287 minecraft:water[level=0]
fill 397 55 -288 398 55 -288 minecraft:water[level=0]
fill 406 55 -288 409 55 -288 minecraft:water[level=0]
setblock 397 55 -289 minecraft:water[level=0]
fill 405 55 -289 409 55 -289 minecraft:water[level=0]
setblock 397 55 -290 minecraft:water[level=0]
fill 403 55 -290 409 55 -290 minecraft:water[level=0]
setblock 397 55 -291 minecraft:water[level=0]
fill 402 55 -291 408 55 -291 minecraft:water[level=0]
fill 400 55 -292 407 55 -292 minecraft:water[level=0]
setblock 396 55 -293 minecraft:water[level=0]
fill 398 55 -293 406 55 -293 minecraft:water[level=0]
fill 397 55 -294 405 55 -294 minecraft:water[level=0]
fill 394 55 -295 404 55 -295 minecraft:water[level=0]
fill 393 55 -296 403 55 -296 minecraft:water[level=0]
fill 392 55 -297 402 55 -297 minecraft:water[level=0]
fill 392 55 -298 400 55 -298 minecraft:water[level=0]
fill 392 55 -299 398 55 -299 minecraft:water[level=0]
fill 392 55 -300 397 55 -300 minecraft:water[level=0]
fill 392 55 -301 396 55 -301 minecraft:water[level=0]
fill 392 55 -302 393 55 -302 minecraft:water[level=0]
fill 392 55 -303 393 55 -303 minecraft:water[level=0]
setblock 392 55 -304 minecraft:water[level=0]
setblock 392 55 -310 minecraft:water[level=0]
fill 392 55 -311 394 55 -311 minecraft:water[level=0]
fill 392 55 -312 397 55 -312 minecraft:water[level=0]
fill 392 55 -313 398 55 -313 minecraft:water[level=0]
fill 392 55 -314 400 55 -314 minecraft:water[level=0]
fill 392 55 -315 402 55 -315 minecraft:water[level=0]
fill 393 55 -316 403 55 -316 minecraft:water[level=0]
fill 394 55 -317 405 55 -317 minecraft:water[level=0]
fill 395 55 -318 407 55 -318 minecraft:water[level=0]
setblock 411 54 -255 minecraft:air
setblock 401 54 -279 minecraft:water[level=0]
fill 401 54 -280 402 54 -280 minecraft:water[level=0]
fill 400 54 -281 402 54 -281 minecraft:water[level=0]
setblock 410 54 -281 minecraft:water[level=0]
fill 400 54 -282 401 54 -282 minecraft:water[level=0]
fill 409 54 -282 411 54 -282 minecraft:water[level=0]
fill 399 54 -283 401 54 -283 minecraft:water[level=0]
fill 409 54 -283 411 54 -283 minecraft:water[level=0]
fill 399 54 -284 400 54 -284 minecraft:water[level=0]
fill 409 54 -284 410 54 -284 minecraft:water[level=0]
setblock 399 54 -285 minecraft:water[level=0]
fill 408 54 -285 409 54 -285 minecraft:water[level=0]
setblock 399 54 -286 minecraft:water[level=0]
fill 407 54 -286 410 54 -286 minecraft:water[level=0]
fill 407 54 -287 409 54 -287 minecraft:water[level=0]
fill 406 54 -288 409 54 -288 minecraft:water[level=0]
setblock 398 54 -289 minecraft:water[level=0]
fill 405 54 -289 408 54 -289 minecraft:water[level=0]
fill 404 54 -290 408 54 -290 minecraft:water[level=0]
fill 403 54 -291 407 54 -291 minecraft:water[level=0]
fill 401 54 -292 407 54 -292 minecraft:water[level=0]
fill 399 54 -293 406 54 -293 minecraft:water[level=0]
fill 398 54 -294 405 54 -294 minecraft:water[level=0]
fill 396 54 -295 403 54 -295 minecraft:water[level=0]
fill 394 54 -296 402 54 -296 minecraft:water[level=0]
fill 393 54 -297 401 54 -297 minecraft:water[level=0]
fill 392 54 -298 399 54 -298 minecraft:water[level=0]
fill 392 54 -299 397 54 -299 minecraft:water[level=0]
fill 392 54 -300 396 54 -300 minecraft:water[level=0]
fill 392 54 -301 394 54 -301 minecraft:water[level=0]
fill 392 54 -302 393 54 -302 minecraft:water[level=0]
fill 392 54 -303 393 54 -303 minecraft:water[level=0]
setblock 392 54 -304 minecraft:water[level=0]
setblock 392 54 -310 minecraft:water[level=0]
fill 392 54 -311 394 54 -311 minecraft:water[level=0]
fill 393 54 -312 397 54 -312 minecraft:water[level=0]
fill 392 54 -313 398 54 -313 minecraft:water[level=0]
fill 392 54 -314 400 54 -314 minecraft:water[level=0]
fill 392 54 -315 402 54 -315 minecraft:water[level=0]
fill 393 54 -316 403 54 -316 minecraft:water[level=0]
fill 394 54 -317 405 54 -317 minecraft:water[level=0]
fill 395 54 -318 407 54 -318 minecraft:water[level=0]
setblock 402 53 -277 minecraft:water[level=0]
setblock 402 53 -278 minecraft:water[level=0]
fill 401 53 -279 403 53 -279 minecraft:water[level=0]
fill 401 53 -280 402 53 -280 minecraft:water[level=0]
fill 400 53 -281 402 53 -281 minecraft:water[level=0]
fill 409 53 -281 411 53 -281 minecraft:water[level=0]
fill 400 53 -282 401 53 -282 minecraft:water[level=0]
fill 408 53 -282 411 53 -282 minecraft:water[level=0]
setblock 400 53 -283 minecraft:water[level=0]
fill 408 53 -283 411 53 -283 minecraft:water[level=0]
setblock 400 53 -284 minecraft:water[level=0]
fill 408 53 -284 411 53 -284 minecraft:water[level=0]
fill 407 53 -285 410 53 -285 minecraft:water[level=0]
fill 407 53 -286 410 53 -286 minecraft:water[level=0]
fill 406 53 -287 410 53 -287 minecraft:water[level=0]
fill 405 53 -288 409 53 -288 minecraft:water[level=0]
fill 404 53 -289 409 53 -289 minecraft:water[level=0]
fill 402 53 -290 409 53 -290 minecraft:water[level=0]
fill 401 53 -291 408 53 -291 minecraft:water[level=0]
fill 399 53 -292 408 53 -292 minecraft:water[level=0]
fill 397 53 -293 407 53 -293 minecraft:water[level=0]
fill 396 53 -294 406 53 -294 minecraft:water[level=0]
fill 393 53 -295 405 53 -295 minecraft:water[level=0]
fill 392 53 -296 404 53 -296 minecraft:water[level=0]
fill 392 53 -297 402 53 -297 minecraft:water[level=0]
fill 392 53 -298 401 53 -298 minecraft:water[level=0]
fill 392 53 -299 399 53 -299 minecraft:water[level=0]
fill 392 53 -300 398 53 -300 minecraft:water[level=0]
fill 392 53 -301 397 53 -301 minecraft:water[level=0]
fill 392 53 -302 394 53 -302 minecraft:water[level=0]
fill 392 53 -303 394 53 -303 minecraft:water[level=0]
fill 392 53 -304 393 53 -304 minecraft:water[level=0]
setblock 393 53 -305 minecraft:water[level=0]
setblock 392 53 -306 minecraft:water[level=0]
setblock 395 53 -312 minecraft:water[level=0]
fill 392 53 -313 393 53 -313 minecraft:water[level=0]
fill 395 53 -313 397 53 -313 minecraft:water[level=0]
fill 392 53 -314 393 53 -314 minecraft:water[level=0]
fill 395 53 -314 399 53 -314 minecraft:water[level=0]
fill 392 53 -315 401 53 -315 minecraft:water[level=0]
fill 394 53 -316 402 53 -316 minecraft:water[level=0]
fill 395 53 -317 403 53 -317 minecraft:water[level=0]
fill 396 53 -318 406 53 -318 minecraft:water[level=0]
setblock 403 52 -276 minecraft:water[level=0]
fill 402 52 -277 403 52 -277 minecraft:water[level=0]
fill 402 52 -278 403 52 -278 minecraft:water[level=0]
fill 401 52 -279 402 52 -279 minecraft:water[level=0]
fill 401 52 -280 402 52 -280 minecraft:water[level=0]
setblock 401 52 -281 minecraft:water[level=0]
setblock 401 52 -282 minecraft:water[level=0]
fill 408 52 -285 409 52 -285 minecraft:water[level=0]
fill 407 52 -286 410 52 -286 minecraft:water[level=0]
fill 406 52 -287 410 52 -287 minecraft:water[level=0]
fill 405 52 -288 409 52 -288 minecraft:water[level=0]
fill 404 52 -289 409 52 -289 minecraft:water[level=0]
fill 403 52 -290 408 52 -290 minecraft:water[level=0]
fill 401 52 -291 408 52 -291 minecraft:water[level=0]
fill 399 52 -292 407 52 -292 minecraft:water[level=0]
fill 397 52 -293 407 52 -293 minecraft:water[level=0]
fill 396 52 -294 406 52 -294 minecraft:water[level=0]
fill 393 52 -295 405 52 -295 minecraft:water[level=0]
fill 392 52 -296 404 52 -296 minecraft:water[level=0]
fill 392 52 -297 402 52 -297 minecraft:water[level=0]
fill 392 52 -298 401 52 -298 minecraft:water[level=0]
fill 392 52 -299 399 52 -299 minecraft:water[level=0]
fill 392 52 -300 398 52 -300 minecraft:water[level=0]
fill 392 52 -301 397 52 -301 minecraft:water[level=0]
fill 392 52 -302 394 52 -302 minecraft:water[level=0]
fill 392 52 -303 394 52 -303 minecraft:water[level=0]
fill 392 52 -304 394 52 -304 minecraft:water[level=0]
fill 393 52 -305 394 52 -305 minecraft:water[level=0]
setblock 392 52 -306 minecraft:water[level=0]
setblock 395 52 -312 minecraft:water[level=0]
fill 395 52 -313 397 52 -313 minecraft:water[level=0]
fill 396 52 -314 399 52 -314 minecraft:water[level=0]
fill 392 52 -315 401 52 -315 minecraft:water[level=0]
fill 394 52 -316 402 52 -316 minecraft:water[level=0]
fill 395 52 -317 403 52 -317 minecraft:water[level=0]
fill 396 52 -318 406 52 -318 minecraft:water[level=0]
setblock 403 51 -275 minecraft:water[level=0]
fill 403 51 -276 404 51 -276 minecraft:water[level=0]
fill 402 51 -277 403 51 -277 minecraft:water[level=0]
fill 402 51 -278 403 51 -278 minecraft:water[level=0]
setblock 402 51 -279 minecraft:water[level=0]
setblock 402 51 -280 minecraft:water[level=0]
fill 404 51 -289 406 51 -289 minecraft:water[level=0]
fill 403 51 -290 407 51 -290 minecraft:water[level=0]
fill 401 51 -291 407 51 -291 minecraft:water[level=0]
fill 399 51 -292 407 51 -292 minecraft:water[level=0]
fill 397 51 -293 407 51 -293 minecraft:water[level=0]
setblock 396 51 -294 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=true,west=true]
fill 397 51 -294 406 51 -294 minecraft:water[level=0]
fill 393 51 -295 405 51 -295 minecraft:water[level=0]
fill 392 51 -296 403 51 -296 minecraft:water[level=0]
fill 392 51 -297 402 51 -297 minecraft:water[level=0]
fill 392 51 -298 401 51 -298 minecraft:water[level=0]
fill 392 51 -299 399 51 -299 minecraft:water[level=0]
fill 392 51 -300 398 51 -300 minecraft:water[level=0]
fill 392 51 -301 397 51 -301 minecraft:water[level=0]
fill 392 51 -302 394 51 -302 minecraft:water[level=0]
fill 392 51 -303 394 51 -303 minecraft:water[level=0]
fill 392 51 -304 394 51 -304 minecraft:water[level=0]
fill 393 51 -305 394 51 -305 minecraft:water[level=0]
setblock 393 51 -306 minecraft:water[level=0]
fill 392 51 -311 393 51 -311 minecraft:air
fill 392 51 -312 394 51 -312 minecraft:air
fill 396 51 -313 397 51 -313 minecraft:water[level=0]
fill 396 51 -314 399 51 -314 minecraft:water[level=0]
fill 396 51 -315 401 51 -315 minecraft:water[level=0]
fill 396 51 -316 402 51 -316 minecraft:water[level=0]
fill 396 51 -317 403 51 -317 minecraft:water[level=0]
fill 396 51 -318 406 51 -318 minecraft:water[level=0]
setblock 404 50 -273 minecraft:water[level=0]
setblock 404 50 -274 minecraft:water[level=0]
fill 403 50 -275 404 50 -275 minecraft:water[level=0]
fill 403 50 -276 404 50 -276 minecraft:water[level=0]
fill 402 50 -277 403 50 -277 minecraft:water[level=0]
setblock 403 50 -278 minecraft:water[level=0]
setblock 420 50 -281 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 402 50 -291 404 50 -291 minecraft:water[level=0]
fill 402 50 -292 405 50 -292 minecraft:water[level=0]
fill 399 50 -293 405 50 -293 minecraft:water[level=0]
fill 397 50 -294 405 50 -294 minecraft:water[level=0]
fill 396 50 -295 402 50 -295 minecraft:water[level=0]
fill 393 50 -296 402 50 -296 minecraft:water[level=0]
fill 393 50 -297 401 50 -297 minecraft:water[level=0]
fill 392 50 -298 399 50 -298 minecraft:water[level=0]
fill 392 50 -299 397 50 -299 minecraft:water[level=0]
fill 392 50 -300 397 50 -300 minecraft:water[level=0]
fill 392 50 -301 394 50 -301 minecraft:water[level=0]
fill 392 50 -302 393 50 -302 minecraft:water[level=0]
setblock 392 50 -303 minecraft:water[level=0]
setblock 394 50 -303 minecraft:water[level=0]
fill 392 50 -304 394 50 -304 minecraft:water[level=0]
fill 393 50 -305 394 50 -305 minecraft:water[level=0]
fill 393 50 -306 394 50 -306 minecraft:water[level=0]
setblock 393 50 -307 minecraft:water[level=0]
fill 392 50 -311 393 50 -311 minecraft:air
fill 392 50 -312 394 50 -312 minecraft:air
fill 392 50 -313 394 50 -313 minecraft:air
setblock 397 50 -313 minecraft:water[level=0]
fill 393 50 -314 394 50 -314 minecraft:air
fill 397 50 -314 399 50 -314 minecraft:water[level=0]
fill 397 50 -315 401 50 -315 minecraft:water[level=0]
fill 397 50 -316 402 50 -316 minecraft:water[level=0]
fill 397 50 -317 403 50 -317 minecraft:water[level=0]
fill 397 50 -318 406 50 -318 minecraft:water[level=0]
setblock 404 49 -273 minecraft:water[level=0]
fill 404 49 -274 405 49 -274 minecraft:water[level=0]
fill 403 49 -275 404 49 -275 minecraft:water[level=0]
fill 403 49 -276 404 49 -276 minecraft:water[level=0]
fill 419 49 -281 420 49 -281 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 419 49 -282 420 49 -282 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 399 49 -293 401 49 -293 minecraft:water[level=0]
fill 397 49 -294 402 49 -294 minecraft:water[level=0]
fill 396 49 -295 402 49 -295 minecraft:water[level=0]
fill 393 49 -296 402 49 -296 minecraft:water[level=0]
fill 393 49 -297 401 49 -297 minecraft:water[level=0]
fill 392 49 -298 399 49 -298 minecraft:water[level=0]
fill 392 49 -299 397 49 -299 minecraft:water[level=0]
fill 392 49 -300 396 49 -300 minecraft:water[level=0]
fill 392 49 -301 394 49 -301 minecraft:water[level=0]
fill 392 49 -302 393 49 -302 minecraft:water[level=0]
setblock 392 49 -303 minecraft:water[level=0]
setblock 392 49 -304 minecraft:water[level=0]
setblock 394 49 -304 minecraft:water[level=0]
fill 393 49 -305 394 49 -305 minecraft:water[level=0]
fill 393 49 -306 394 49 -306 minecraft:water[level=0]
fill 392 49 -311 393 49 -311 minecraft:air
fill 392 49 -312 395 49 -312 minecraft:air
fill 392 49 -313 395 49 -313 minecraft:air
setblock 397 49 -313 minecraft:water[level=0]
fill 392 49 -314 395 49 -314 minecraft:air
fill 397 49 -314 399 49 -314 minecraft:water[level=0]
fill 392 49 -315 395 49 -315 minecraft:air
fill 397 49 -315 401 49 -315 minecraft:water[level=0]
fill 394 49 -316 395 49 -316 minecraft:air
fill 397 49 -316 402 49 -316 minecraft:water[level=0]
fill 398 49 -317 403 49 -317 minecraft:water[level=0]
fill 397 49 -318 406 49 -318 minecraft:water[level=0]
setblock 405 48 -272 minecraft:water[level=0]
fill 404 48 -273 405 48 -273 minecraft:water[level=0]
fill 404 48 -274 405 48 -274 minecraft:water[level=0]
fill 403 48 -275 404 48 -275 minecraft:water[level=0]
setblock 404 48 -276 minecraft:water[level=0]
fill 399 48 -293 401 48 -293 minecraft:water[level=0]
fill 397 48 -294 402 48 -294 minecraft:water[level=0]
fill 396 48 -295 402 48 -295 minecraft:water[level=0]
fill 394 48 -296 402 48 -296 minecraft:water[level=0]
fill 394 48 -297 401 48 -297 minecraft:water[level=0]
fill 394 48 -298 399 48 -298 minecraft:water[level=0]
fill 394 48 -299 397 48 -299 minecraft:water[level=0]
setblock 392 48 -300 minecraft:water[level=0]
setblock 392 48 -301 minecraft:water[level=0]
setblock 392 48 -302 minecraft:water[level=0]
setblock 392 48 -303 minecraft:water[level=0]
setblock 392 48 -304 minecraft:water[level=0]
fill 393 48 -305 395 48 -305 minecraft:water[level=0]
setblock 394 48 -308 minecraft:air
fill 392 48 -311 393 48 -311 minecraft:air
fill 392 48 -312 395 48 -312 minecraft:air
fill 392 48 -313 396 48 -313 minecraft:air
fill 392 48 -314 396 48 -314 minecraft:air
setblock 399 48 -314 minecraft:water[level=0]
fill 392 48 -315 396 48 -315 minecraft:air
fill 398 48 -315 401 48 -315 minecraft:water[level=0]
fill 394 48 -316 396 48 -316 minecraft:air
fill 398 48 -316 402 48 -316 minecraft:water[level=0]
setblock 395 48 -317 minecraft:air
fill 398 48 -317 403 48 -317 minecraft:water[level=0]
fill 397 48 -318 406 48 -318 minecraft:water[level=0]
fill 405 47 -271 406 47 -271 minecraft:water[level=0]
fill 405 47 -272 406 47 -272 minecraft:water[level=0]
fill 404 47 -273 405 47 -273 minecraft:water[level=0]
fill 404 47 -274 405 47 -274 minecraft:water[level=0]
fill 395 47 -295 397 47 -295 minecraft:water[level=0]
fill 394 47 -296 398 47 -296 minecraft:water[level=0]
fill 394 47 -297 398 47 -297 minecraft:water[level=0]
fill 394 47 -298 398 47 -298 minecraft:water[level=0]
fill 394 47 -299 398 47 -299 minecraft:water[level=0]
setblock 392 47 -300 minecraft:water[level=0]
fill 395 47 -300 397 47 -300 minecraft:water[level=0]
fill 392 47 -301 393 47 -301 minecraft:water[level=0]
fill 392 47 -302 393 47 -302 minecraft:water[level=0]
fill 392 47 -303 393 47 -303 minecraft:water[level=0]
setblock 392 47 -304 minecraft:water[level=0]
fill 394 47 -307 395 47 -307 minecraft:water[level=0]
fill 394 47 -308 395 47 -308 minecraft:water[level=0]
setblock 394 47 -309 minecraft:water[level=0]
fill 392 47 -311 393 47 -311 minecraft:water[level=0]
fill 392 47 -312 395 47 -312 minecraft:water[level=0]
fill 392 47 -313 396 47 -313 minecraft:water[level=0]
fill 392 47 -314 396 47 -314 minecraft:water[level=0]
setblock 399 47 -314 minecraft:water[level=0]
fill 392 47 -315 396 47 -315 minecraft:water[level=0]
fill 399 47 -315 401 47 -315 minecraft:water[level=0]
fill 394 47 -316 395 47 -316 minecraft:water[level=0]
fill 398 47 -316 402 47 -316 minecraft:water[level=0]
setblock 395 47 -317 minecraft:water[level=0]
fill 397 47 -317 403 47 -317 minecraft:water[level=0]
fill 397 47 -318 406 47 -318 minecraft:water[level=0]
setblock 406 46 -269 minecraft:water[level=0]
setblock 406 46 -270 minecraft:water[level=0]
fill 405 46 -271 406 46 -271 minecraft:water[level=0]
fill 405 46 -272 406 46 -272 minecraft:water[level=0]
setblock 405 46 -273 minecraft:water[level=0]
setblock 405 46 -274 minecraft:water[level=0]
fill 392 46 -302 393 46 -302 minecraft:water[level=0]
setblock 395 46 -306 minecraft:water[level=0]
fill 394 46 -307 395 46 -307 minecraft:water[level=0]
fill 394 46 -308 395 46 -308 minecraft:water[level=0]
fill 394 46 -309 395 46 -309 minecraft:water[level=0]
setblock 394 46 -310 minecraft:water[level=0]
fill 392 46 -312 395 46 -312 minecraft:water[level=0]
fill 392 46 -313 397 46 -313 minecraft:water[level=0]
fill 392 46 -314 396 46 -314 minecraft:water[level=0]
fill 398 46 -314 399 46 -314 minecraft:water[level=0]
fill 392 46 -315 396 46 -315 minecraft:water[level=0]
fill 398 46 -315 401 46 -315 minecraft:water[level=0]
fill 394 46 -316 395 46 -316 minecraft:water[level=0]
fill 398 46 -316 402 46 -316 minecraft:water[level=0]
setblock 395 46 -317 minecraft:water[level=0]
fill 397 46 -317 403 46 -317 minecraft:water[level=0]
fill 397 46 -318 404 46 -318 minecraft:water[level=0]
fill 406 45 -269 407 45 -269 minecraft:water[level=0]
fill 406 45 -270 407 45 -270 minecraft:water[level=0]
fill 405 45 -271 406 45 -271 minecraft:water[level=0]
setblock 406 45 -272 minecraft:water[level=0]
fill 394 45 -307 395 45 -307 minecraft:water[level=0]
fill 394 45 -308 395 45 -308 minecraft:water[level=0]
fill 394 45 -309 396 45 -309 minecraft:water[level=0]
setblock 395 45 -310 minecraft:water[level=0]
fill 398 45 -315 401 45 -315 minecraft:water[level=0]
fill 398 45 -316 402 45 -316 minecraft:water[level=0]
fill 397 45 -317 402 45 -317 minecraft:water[level=0]
fill 397 45 -318 402 45 -318 minecraft:water[level=0]
forceload remove 392 -318 455 -255
tellraw @a {"text":"Campus zurueck a21 fertig.","color":"green"}
