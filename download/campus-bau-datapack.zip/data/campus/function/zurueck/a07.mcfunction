# Abschnitt a07: x 392..455, z -446..-383 (12728 Blöcke)
forceload add 392 -446 455 -383
tellraw @a {"text":"Campus zurueck a07: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a07_1 2s
