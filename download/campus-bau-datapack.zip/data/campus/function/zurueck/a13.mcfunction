# Abschnitt a13: x 328..391, z -382..-319 (28779 Blöcke)
forceload add 328 -382 391 -319
tellraw @a {"text":"Campus zurueck a13: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a13_1 2s
