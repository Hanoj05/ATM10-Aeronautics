setblock 325 80 -444 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 326 80 -444 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 327 80 -444 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 327 80 -445 torchmaster:invisible_light
setblock 319 79 -430 torchmaster:invisible_light
setblock 326 79 -432 torchmaster:invisible_light
setblock 317 79 -438 torchmaster:invisible_light
setblock 327 79 -439 torchmaster:invisible_light
setblock 325 79 -444 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 326 79 -444 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 327 79 -444 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 326 79 -445 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 323 78 -444 torchmaster:invisible_light
setblock 325 78 -444 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 326 78 -444 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 327 78 -444 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 325 78 -445 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 326 78 -445 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 327 78 -445 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 317 77 -428 torchmaster:invisible_light
setblock 317 77 -434 torchmaster:invisible_light
setblock 324 77 -444 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 325 77 -444 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 326 77 -444 minecraft:birch_log[axis=y]
setblock 327 77 -444 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 325 77 -445 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 326 77 -445 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 327 77 -445 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 326 77 -446 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 324 76 -433 torchmaster:invisible_light
setblock 317 76 -444 torchmaster:invisible_light
setblock 326 76 -444 minecraft:birch_log[axis=y]
setblock 319 75 -426 torchmaster:invisible_light
setblock 321 75 -439 torchmaster:invisible_light
setblock 317 75 -441 torchmaster:invisible_light
setblock 326 75 -444 minecraft:birch_log[axis=y]
setblock 325 75 -445 torchmaster:invisible_light
setblock 325 74 -444 regions_unexplored:birch_branch[facing=west]
setblock 326 74 -444 minecraft:birch_log[axis=y]
setblock 326 73 -444 minecraft:birch_log[axis=y]
setblock 287 72 -394 minecraft:air
setblock 311 72 -394 minecraft:air
setblock 272 72 -436 minecraft:air
setblock 282 72 -436 minecraft:air
setblock 292 72 -436 minecraft:air
setblock 302 72 -436 minecraft:air
setblock 312 72 -436 minecraft:air
setblock 322 72 -436 minecraft:air
setblock 326 72 -444 minecraft:birch_log[axis=y]
setblock 320 72 -445 torchmaster:invisible_light
setblock 287 71 -392 minecraft:air
setblock 311 71 -392 minecraft:air
fill 286 71 -393 288 71 -393 minecraft:air
fill 310 71 -393 312 71 -393 minecraft:air
fill 285 71 -394 289 71 -394 minecraft:air
fill 309 71 -394 313 71 -394 minecraft:air
fill 286 71 -395 288 71 -395 minecraft:air
fill 310 71 -395 312 71 -395 minecraft:air
setblock 287 71 -396 minecraft:air
setblock 311 71 -396 minecraft:air
setblock 321 71 -427 torchmaster:invisible_light
setblock 272 71 -434 minecraft:air
setblock 282 71 -434 minecraft:air
setblock 292 71 -434 minecraft:air
setblock 302 71 -434 minecraft:air
setblock 312 71 -434 minecraft:air
setblock 322 71 -434 minecraft:air
fill 271 71 -435 273 71 -435 minecraft:air
fill 281 71 -435 283 71 -435 minecraft:air
fill 291 71 -435 293 71 -435 minecraft:air
fill 301 71 -435 303 71 -435 minecraft:air
fill 311 71 -435 313 71 -435 minecraft:air
fill 321 71 -435 323 71 -435 minecraft:air
setblock 264 71 -436 minecraft:air
fill 270 71 -436 274 71 -436 minecraft:air
fill 280 71 -436 284 71 -436 minecraft:air
fill 290 71 -436 294 71 -436 minecraft:air
fill 300 71 -436 304 71 -436 minecraft:air
fill 310 71 -436 314 71 -436 minecraft:air
fill 320 71 -436 324 71 -436 minecraft:air
fill 271 71 -437 273 71 -437 minecraft:air
fill 281 71 -437 283 71 -437 minecraft:air
fill 291 71 -437 293 71 -437 minecraft:air
fill 301 71 -437 303 71 -437 minecraft:air
fill 311 71 -437 313 71 -437 minecraft:air
fill 321 71 -437 323 71 -437 minecraft:air
setblock 272 71 -438 minecraft:air
setblock 282 71 -438 minecraft:air
setblock 292 71 -438 minecraft:air
setblock 302 71 -438 minecraft:air
setblock 312 71 -438 minecraft:air
setblock 322 71 -438 minecraft:air
setblock 320 71 -440 torchmaster:invisible_light
setblock 316 71 -444 minecraft:short_grass
setblock 326 71 -444 minecraft:birch_log[axis=y]
fill 286 70 -392 288 70 -392 minecraft:air
fill 310 70 -392 312 70 -392 minecraft:air
fill 285 70 -393 289 70 -393 minecraft:air
fill 309 70 -393 313 70 -393 minecraft:air
fill 285 70 -394 289 70 -394 minecraft:air
fill 309 70 -394 313 70 -394 minecraft:air
fill 285 70 -395 289 70 -395 minecraft:air
fill 309 70 -395 313 70 -395 minecraft:air
fill 286 70 -396 288 70 -396 minecraft:air
fill 310 70 -396 312 70 -396 minecraft:air
fill 271 70 -434 273 70 -434 minecraft:air
fill 281 70 -434 283 70 -434 minecraft:air
fill 291 70 -434 293 70 -434 minecraft:air
fill 301 70 -434 303 70 -434 minecraft:air
fill 311 70 -434 313 70 -434 minecraft:air
setblock 317 70 -434 torchmaster:invisible_light
fill 321 70 -434 323 70 -434 minecraft:air
setblock 324 70 -434 torchmaster:invisible_light
setblock 264 70 -435 minecraft:air
fill 270 70 -435 274 70 -435 minecraft:air
fill 280 70 -435 284 70 -435 minecraft:air
fill 290 70 -435 294 70 -435 minecraft:air
fill 300 70 -435 304 70 -435 minecraft:air
fill 310 70 -435 314 70 -435 minecraft:air
fill 320 70 -435 324 70 -435 minecraft:air
setblock 264 70 -436 minecraft:air
fill 270 70 -436 274 70 -436 minecraft:air
fill 280 70 -436 284 70 -436 minecraft:air
fill 290 70 -436 294 70 -436 minecraft:air
fill 300 70 -436 304 70 -436 minecraft:air
fill 310 70 -436 314 70 -436 minecraft:air
fill 320 70 -436 324 70 -436 minecraft:air
setblock 264 70 -437 minecraft:air
fill 270 70 -437 274 70 -437 minecraft:air
fill 280 70 -437 284 70 -437 minecraft:air
fill 290 70 -437 294 70 -437 minecraft:air
fill 300 70 -437 304 70 -437 minecraft:air
fill 310 70 -437 314 70 -437 minecraft:air
fill 320 70 -437 324 70 -437 minecraft:air
fill 271 70 -438 273 70 -438 minecraft:air
fill 281 70 -438 283 70 -438 minecraft:air
fill 291 70 -438 293 70 -438 minecraft:air
fill 301 70 -438 303 70 -438 minecraft:air
fill 311 70 -438 313 70 -438 minecraft:air
fill 321 70 -438 323 70 -438 minecraft:air
setblock 325 70 -442 torchmaster:invisible_light
fill 315 70 -444 316 70 -444 minecraft:grass_block[snowy=false]
setblock 317 70 -444 torchmaster:invisible_light
setblock 326 70 -444 minecraft:birch_log[axis=y]
setblock 318 70 -445 regions_unexplored:grass_sprouts
setblock 327 70 -446 regions_unexplored:grass_sprouts
setblock 287 69 -392 minecraft:air
setblock 311 69 -392 minecraft:air
fill 286 69 -393 288 69 -393 minecraft:air
fill 310 69 -393 312 69 -393 minecraft:air
fill 285 69 -394 289 69 -394 minecraft:air
fill 309 69 -394 313 69 -394 minecraft:air
fill 286 69 -395 288 69 -395 minecraft:air
fill 310 69 -395 312 69 -395 minecraft:air
setblock 287 69 -396 minecraft:air
setblock 311 69 -396 minecraft:air
setblock 320 69 -430 torchmaster:invisible_light
setblock 272 69 -434 minecraft:air
setblock 282 69 -434 minecraft:air
setblock 292 69 -434 minecraft:air
setblock 302 69 -434 minecraft:air
setblock 312 69 -434 minecraft:air
setblock 322 69 -434 minecraft:air
fill 271 69 -435 273 69 -435 minecraft:air
fill 281 69 -435 283 69 -435 minecraft:air
fill 291 69 -435 293 69 -435 minecraft:air
fill 301 69 -435 303 69 -435 minecraft:air
fill 311 69 -435 313 69 -435 minecraft:air
fill 321 69 -435 323 69 -435 minecraft:air
setblock 264 69 -436 minecraft:air
fill 270 69 -436 274 69 -436 minecraft:air
fill 280 69 -436 284 69 -436 minecraft:air
fill 290 69 -436 294 69 -436 minecraft:air
fill 300 69 -436 304 69 -436 minecraft:air
fill 310 69 -436 314 69 -436 minecraft:air
fill 320 69 -436 324 69 -436 minecraft:air
fill 271 69 -437 273 69 -437 minecraft:air
fill 281 69 -437 283 69 -437 minecraft:air
fill 291 69 -437 293 69 -437 minecraft:air
fill 301 69 -437 303 69 -437 minecraft:air
fill 311 69 -437 313 69 -437 minecraft:air
fill 321 69 -437 323 69 -437 minecraft:air
setblock 272 69 -438 minecraft:air
setblock 282 69 -438 minecraft:air
setblock 292 69 -438 minecraft:air
setblock 302 69 -438 minecraft:air
setblock 312 69 -438 minecraft:air
setblock 322 69 -438 minecraft:air
setblock 323 69 -439 torchmaster:invisible_light
setblock 321 69 -443 torchmaster:invisible_light
fill 315 69 -444 316 69 -444 minecraft:dirt
fill 317 69 -444 325 69 -444 minecraft:grass_block[snowy=false]
setblock 326 69 -444 minecraft:dirt
setblock 327 69 -444 minecraft:grass_block[snowy=false]
fill 315 69 -445 327 69 -445 minecraft:grass_block[snowy=false]
fill 315 69 -446 327 69 -446 minecraft:grass_block[snowy=false]
setblock 287 68 -394 minecraft:air
setblock 311 68 -394 minecraft:air
setblock 321 68 -435 torchmaster:invisible_light
setblock 272 68 -436 minecraft:air
setblock 282 68 -436 minecraft:air
setblock 292 68 -436 minecraft:air
setblock 302 68 -436 minecraft:air
setblock 312 68 -436 minecraft:air
setblock 322 68 -436 minecraft:air
fill 315 68 -444 327 68 -444 minecraft:dirt
fill 315 68 -445 327 68 -445 minecraft:dirt
fill 315 68 -446 327 68 -446 minecraft:dirt
setblock 287 67 -394 minecraft:air
setblock 311 67 -394 minecraft:air
setblock 318 67 -427 torchmaster:invisible_light
setblock 327 67 -433 torchmaster:invisible_light
setblock 272 67 -436 minecraft:air
setblock 282 67 -436 minecraft:air
setblock 292 67 -436 minecraft:air
setblock 302 67 -436 minecraft:air
setblock 312 67 -436 minecraft:air
setblock 322 67 -436 minecraft:air
setblock 318 67 -440 torchmaster:invisible_light
setblock 327 67 -441 torchmaster:invisible_light
fill 315 67 -444 327 67 -444 minecraft:dirt
fill 315 67 -445 327 67 -445 minecraft:dirt
fill 316 67 -446 327 67 -446 minecraft:dirt
setblock 283 66 -388 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 287 66 -394 minecraft:air
setblock 311 66 -394 minecraft:air
setblock 273 66 -396 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 323 66 -402 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 265 66 -406 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 293 66 -409 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 317 66 -411 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 270 66 -412 regions_unexplored:peat_mud
setblock 303 66 -412 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 271 66 -423 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 319 66 -432 torchmaster:invisible_light
setblock 272 66 -436 minecraft:air
setblock 282 66 -436 minecraft:air
setblock 292 66 -436 minecraft:air
setblock 302 66 -436 minecraft:air
setblock 312 66 -436 minecraft:air
setblock 317 66 -436 torchmaster:invisible_light
setblock 322 66 -436 minecraft:air
setblock 325 66 -438 torchmaster:invisible_light
setblock 322 66 -441 torchmaster:invisible_light
fill 315 66 -444 316 66 -444 minecraft:stone
fill 317 66 -444 327 66 -444 minecraft:dirt
fill 315 66 -445 327 66 -445 minecraft:dirt
fill 316 66 -446 327 66 -446 minecraft:dirt
fill 267 65 -383 276 65 -383 minecraft:black_concrete
setblock 277 65 -383 minecraft:stone
setblock 297 65 -383 minecraft:stone
fill 298 65 -383 310 65 -383 minecraft:black_concrete
fill 311 65 -383 312 65 -383 minecraft:sandstone
fill 313 65 -383 327 65 -383 minecraft:black_concrete
fill 266 65 -384 275 65 -384 minecraft:stone
fill 276 65 -384 278 65 -384 minecraft:coal_ore
fill 296 65 -384 313 65 -384 minecraft:sandstone
fill 314 65 -384 316 65 -384 minecraft:air
fill 317 65 -384 327 65 -384 minecraft:black_concrete
fill 265 65 -385 275 65 -385 minecraft:stone
setblock 276 65 -385 minecraft:coal_ore
fill 277 65 -385 279 65 -385 minecraft:stone
setblock 281 65 -385 minecraft:stone
setblock 293 65 -385 minecraft:stone
setblock 295 65 -385 minecraft:stone
fill 296 65 -385 312 65 -385 minecraft:sandstone
fill 313 65 -385 315 65 -385 minecraft:air
fill 316 65 -385 320 65 -385 minecraft:grass_block[snowy=false]
fill 321 65 -385 327 65 -385 minecraft:black_concrete
fill 264 65 -386 282 65 -386 minecraft:stone
setblock 284 65 -386 minecraft:stone
setblock 290 65 -386 minecraft:stone
fill 292 65 -386 294 65 -386 minecraft:stone
fill 295 65 -386 310 65 -386 minecraft:sandstone
fill 311 65 -386 315 65 -386 minecraft:air
setblock 316 65 -386 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 317 65 -386 minecraft:air
fill 318 65 -386 320 65 -386 minecraft:grass_block[snowy=false]
fill 321 65 -386 326 65 -386 minecraft:black_concrete
fill 264 65 -387 285 65 -387 minecraft:stone
setblock 287 65 -387 minecraft:stone
fill 289 65 -387 294 65 -387 minecraft:stone
fill 295 65 -387 303 65 -387 minecraft:sandstone
fill 304 65 -387 317 65 -387 minecraft:air
fill 318 65 -387 326 65 -387 minecraft:grass_block[snowy=false]
fill 264 65 -388 290 65 -388 minecraft:stone
fill 291 65 -388 292 65 -388 minecraft:sandstone
fill 293 65 -388 294 65 -388 minecraft:stone
fill 295 65 -388 302 65 -388 minecraft:sandstone
fill 303 65 -388 317 65 -388 minecraft:air
fill 318 65 -388 326 65 -388 minecraft:grass_block[snowy=false]
fill 264 65 -389 288 65 -389 minecraft:stone
fill 289 65 -389 301 65 -389 minecraft:sandstone
fill 302 65 -389 317 65 -389 minecraft:air
fill 318 65 -389 326 65 -389 minecraft:grass_block[snowy=false]
fill 264 65 -390 275 65 -390 minecraft:stone
fill 276 65 -390 277 65 -390 theurgy:sal_ammoniac_ore
fill 278 65 -390 287 65 -390 minecraft:stone
fill 288 65 -390 300 65 -390 minecraft:sandstone
fill 301 65 -390 317 65 -390 minecraft:air
fill 318 65 -390 326 65 -390 minecraft:grass_block[snowy=false]
fill 264 65 -391 286 65 -391 minecraft:stone
fill 287 65 -391 298 65 -391 minecraft:sandstone
setblock 299 65 -391 ars_nouveau:light_block[level=14,waterlogged=false]
fill 300 65 -391 317 65 -391 minecraft:air
fill 318 65 -391 326 65 -391 minecraft:grass_block[snowy=false]
fill 264 65 -392 279 65 -392 minecraft:stone
fill 280 65 -392 281 65 -392 minecraft:sandstone
fill 282 65 -392 285 65 -392 minecraft:stone
fill 286 65 -392 296 65 -392 minecraft:sandstone
setblock 297 65 -392 minecraft:sand
fill 298 65 -392 317 65 -392 minecraft:air
fill 318 65 -392 325 65 -392 minecraft:grass_block[snowy=false]
fill 326 65 -392 327 65 -392 minecraft:stone
fill 264 65 -393 279 65 -393 minecraft:stone
fill 280 65 -393 282 65 -393 minecraft:sandstone
fill 283 65 -393 285 65 -393 minecraft:stone
fill 286 65 -393 292 65 -393 minecraft:sandstone
fill 293 65 -393 297 65 -393 minecraft:sand
fill 298 65 -393 318 65 -393 minecraft:air
fill 319 65 -393 320 65 -393 minecraft:grass_block[snowy=false]
fill 321 65 -393 322 65 -393 minecraft:air
setblock 323 65 -393 minecraft:sandstone
setblock 324 65 -393 minecraft:air
setblock 325 65 -393 minecraft:sandstone
fill 326 65 -393 327 65 -393 minecraft:stone
fill 264 65 -394 270 65 -394 minecraft:stone
fill 271 65 -394 274 65 -394 minecraft:coal_ore
fill 275 65 -394 279 65 -394 minecraft:stone
fill 280 65 -394 283 65 -394 minecraft:sandstone
setblock 284 65 -394 minecraft:stone
fill 285 65 -394 289 65 -394 minecraft:sandstone
fill 290 65 -394 295 65 -394 minecraft:air
fill 296 65 -394 297 65 -394 minecraft:sand
fill 298 65 -394 300 65 -394 minecraft:air
setblock 301 65 -394 minecraft:sandstone
fill 302 65 -394 323 65 -394 minecraft:air
setblock 324 65 -394 minecraft:sandstone
fill 325 65 -394 327 65 -394 minecraft:stone
fill 264 65 -395 266 65 -395 minecraft:stone
fill 267 65 -395 273 65 -395 minecraft:grass_block[snowy=false]
setblock 274 65 -395 minecraft:coal_ore
fill 275 65 -395 280 65 -395 minecraft:stone
fill 281 65 -395 286 65 -395 minecraft:sandstone
setblock 287 65 -395 minecraft:sand
fill 288 65 -395 296 65 -395 minecraft:air
setblock 297 65 -395 minecraft:sand
fill 298 65 -395 322 65 -395 minecraft:air
setblock 323 65 -395 minecraft:sandstone
fill 324 65 -395 327 65 -395 minecraft:stone
setblock 264 65 -396 minecraft:stone
fill 265 65 -396 278 65 -396 minecraft:grass_block[snowy=false]
fill 279 65 -396 281 65 -396 minecraft:stone
fill 282 65 -396 285 65 -396 minecraft:sandstone
setblock 286 65 -396 minecraft:sand
fill 287 65 -396 296 65 -396 minecraft:air
fill 297 65 -396 300 65 -396 minecraft:sand
fill 301 65 -396 320 65 -396 minecraft:air
fill 321 65 -396 322 65 -396 minecraft:sandstone
setblock 323 65 -396 minecraft:air
fill 324 65 -396 327 65 -396 minecraft:stone
fill 264 65 -397 281 65 -397 minecraft:grass_block[snowy=false]
setblock 282 65 -397 minecraft:sand
fill 283 65 -397 284 65 -397 minecraft:sandstone
fill 285 65 -397 290 65 -397 minecraft:air
setblock 291 65 -397 minecraft:sand
fill 292 65 -397 296 65 -397 minecraft:air
fill 297 65 -397 299 65 -397 minecraft:sand
fill 300 65 -397 302 65 -397 minecraft:air
setblock 303 65 -397 minecraft:sandstone
fill 304 65 -397 318 65 -397 minecraft:air
fill 319 65 -397 320 65 -397 minecraft:sandstone
setblock 321 65 -397 minecraft:air
fill 322 65 -397 323 65 -397 minecraft:sandstone
setblock 324 65 -397 minecraft:stone
fill 325 65 -397 327 65 -397 minecraft:sandstone
fill 264 65 -398 281 65 -398 minecraft:grass_block[snowy=false]
setblock 282 65 -398 minecraft:sand
fill 283 65 -398 288 65 -398 minecraft:air
setblock 289 65 -398 ars_nouveau:light_block[level=14,waterlogged=false]
fill 290 65 -398 298 65 -398 minecraft:air
setblock 299 65 -398 minecraft:sand
fill 300 65 -398 302 65 -398 minecraft:air
setblock 303 65 -398 minecraft:sandstone
fill 304 65 -398 317 65 -398 minecraft:air
fill 318 65 -398 319 65 -398 minecraft:sandstone
fill 320 65 -398 321 65 -398 minecraft:air
fill 322 65 -398 327 65 -398 minecraft:sandstone
setblock 264 65 -399 minecraft:stone
fill 265 65 -399 281 65 -399 minecraft:grass_block[snowy=false]
fill 282 65 -399 303 65 -399 minecraft:air
setblock 304 65 -399 minecraft:sandstone
fill 305 65 -399 315 65 -399 minecraft:air
fill 316 65 -399 317 65 -399 minecraft:sandstone
fill 318 65 -399 319 65 -399 minecraft:air
setblock 320 65 -399 minecraft:sandstone
setblock 321 65 -399 minecraft:air
fill 322 65 -399 327 65 -399 minecraft:sandstone
fill 264 65 -400 280 65 -400 minecraft:grass_block[snowy=false]
fill 281 65 -400 303 65 -400 minecraft:air
fill 304 65 -400 306 65 -400 minecraft:sandstone
fill 307 65 -400 313 65 -400 minecraft:air
fill 314 65 -400 315 65 -400 minecraft:sandstone
setblock 316 65 -400 alltheores:salt_ore
fill 317 65 -400 319 65 -400 minecraft:air
fill 320 65 -400 327 65 -400 minecraft:sandstone
fill 264 65 -401 280 65 -401 minecraft:grass_block[snowy=false]
fill 281 65 -401 302 65 -401 minecraft:air
fill 303 65 -401 305 65 -401 minecraft:sandstone
fill 306 65 -401 312 65 -401 minecraft:air
fill 313 65 -401 315 65 -401 minecraft:sandstone
fill 316 65 -401 317 65 -401 alltheores:salt_ore
fill 318 65 -401 319 65 -401 minecraft:air
fill 320 65 -401 327 65 -401 minecraft:sandstone
setblock 264 65 -402 minecraft:stone
fill 265 65 -402 281 65 -402 minecraft:grass_block[snowy=false]
fill 282 65 -402 301 65 -402 minecraft:air
setblock 302 65 -402 minecraft:sandstone
fill 303 65 -402 312 65 -402 minecraft:air
fill 313 65 -402 314 65 -402 minecraft:sandstone
fill 315 65 -402 318 65 -402 alltheores:salt_ore
setblock 319 65 -402 minecraft:air
fill 320 65 -402 327 65 -402 minecraft:sandstone
fill 264 65 -403 281 65 -403 minecraft:grass_block[snowy=false]
fill 282 65 -403 312 65 -403 minecraft:air
fill 313 65 -403 314 65 -403 minecraft:sandstone
fill 315 65 -403 317 65 -403 alltheores:salt_ore
fill 318 65 -403 327 65 -403 minecraft:sandstone
fill 264 65 -404 276 65 -404 minecraft:grass_block[snowy=false]
setblock 277 65 -404 minecraft:sand
fill 278 65 -404 281 65 -404 minecraft:grass_block[snowy=false]
fill 282 65 -404 312 65 -404 minecraft:air
fill 313 65 -404 319 65 -404 minecraft:sandstone
setblock 320 65 -404 minecraft:dirt
fill 321 65 -404 323 65 -404 minecraft:stone
fill 324 65 -404 327 65 -404 minecraft:sandstone
fill 264 65 -405 266 65 -405 minecraft:grass_block[snowy=false]
fill 277 65 -405 278 65 -405 minecraft:sand
setblock 281 65 -405 minecraft:sand
fill 282 65 -405 313 65 -405 minecraft:air
fill 314 65 -405 319 65 -405 minecraft:sandstone
fill 320 65 -405 321 65 -405 minecraft:dirt
fill 322 65 -405 323 65 -405 minecraft:stone
setblock 324 65 -405 minecraft:sandstone
setblock 325 65 -405 minecraft:stone
fill 326 65 -405 327 65 -405 minecraft:sandstone
fill 264 65 -406 266 65 -406 minecraft:grass_block[snowy=false]
fill 277 65 -406 280 65 -406 minecraft:sand
fill 281 65 -406 314 65 -406 minecraft:air
fill 315 65 -406 319 65 -406 minecraft:sandstone
fill 320 65 -406 321 65 -406 minecraft:dirt
fill 322 65 -406 327 65 -406 minecraft:stone
fill 264 65 -407 266 65 -407 minecraft:grass_block[snowy=false]
fill 277 65 -407 280 65 -407 minecraft:sand
fill 281 65 -407 313 65 -407 minecraft:air
fill 314 65 -407 319 65 -407 minecraft:sandstone
fill 320 65 -407 327 65 -407 minecraft:stone
fill 264 65 -408 266 65 -408 minecraft:grass_block[snowy=false]
fill 277 65 -408 279 65 -408 minecraft:sand
fill 280 65 -408 286 65 -408 minecraft:air
fill 287 65 -408 289 65 -408 minecraft:sand
fill 290 65 -408 299 65 -408 minecraft:sandstone
fill 300 65 -408 313 65 -408 minecraft:air
fill 314 65 -408 316 65 -408 minecraft:sandstone
fill 317 65 -408 327 65 -408 minecraft:stone
fill 264 65 -409 268 65 -409 minecraft:grass_block[snowy=false]
fill 277 65 -409 279 65 -409 minecraft:sand
fill 280 65 -409 286 65 -409 minecraft:air
fill 287 65 -409 297 65 -409 minecraft:sand
fill 298 65 -409 301 65 -409 minecraft:air
fill 302 65 -409 305 65 -409 minecraft:sand
setblock 306 65 -409 minecraft:sandstone
fill 307 65 -409 312 65 -409 minecraft:air
fill 313 65 -409 316 65 -409 minecraft:sandstone
fill 317 65 -409 327 65 -409 minecraft:stone
fill 264 65 -410 270 65 -410 minecraft:grass_block[snowy=false]
fill 273 65 -410 279 65 -410 minecraft:sand
fill 280 65 -410 284 65 -410 minecraft:air
fill 285 65 -410 292 65 -410 minecraft:sand
fill 293 65 -410 301 65 -410 minecraft:air
fill 302 65 -410 306 65 -410 minecraft:sand
fill 307 65 -410 309 65 -410 minecraft:sandstone
setblock 310 65 -410 minecraft:sand
fill 311 65 -410 312 65 -410 minecraft:air
fill 313 65 -410 315 65 -410 minecraft:sandstone
fill 316 65 -410 327 65 -410 minecraft:stone
fill 264 65 -411 271 65 -411 minecraft:grass_block[snowy=false]
fill 273 65 -411 279 65 -411 minecraft:sand
fill 280 65 -411 284 65 -411 minecraft:air
fill 285 65 -411 292 65 -411 minecraft:sand
fill 293 65 -411 302 65 -411 minecraft:air
fill 303 65 -411 306 65 -411 minecraft:sand
fill 307 65 -411 315 65 -411 minecraft:sandstone
fill 316 65 -411 327 65 -411 minecraft:stone
fill 264 65 -412 269 65 -412 minecraft:grass_block[snowy=false]
setblock 270 65 -412 minecraft:dirt
fill 271 65 -412 272 65 -412 minecraft:grass_block[snowy=false]
fill 273 65 -412 279 65 -412 minecraft:sand
fill 280 65 -412 285 65 -412 minecraft:air
fill 286 65 -412 292 65 -412 minecraft:sand
fill 293 65 -412 302 65 -412 minecraft:air
fill 303 65 -412 306 65 -412 minecraft:sand
fill 307 65 -412 315 65 -412 minecraft:sandstone
fill 316 65 -412 318 65 -412 minecraft:dirt
fill 319 65 -412 327 65 -412 minecraft:stone
fill 264 65 -413 271 65 -413 minecraft:grass_block[snowy=false]
fill 272 65 -413 279 65 -413 minecraft:sand
fill 280 65 -413 285 65 -413 minecraft:air
fill 286 65 -413 291 65 -413 minecraft:sand
fill 292 65 -413 302 65 -413 minecraft:air
fill 303 65 -413 306 65 -413 minecraft:sand
fill 307 65 -413 316 65 -413 minecraft:sandstone
fill 317 65 -413 320 65 -413 minecraft:dirt
fill 321 65 -413 327 65 -413 minecraft:stone
fill 264 65 -414 271 65 -414 minecraft:grass_block[snowy=false]
fill 272 65 -414 279 65 -414 minecraft:sand
fill 280 65 -414 286 65 -414 minecraft:air
fill 287 65 -414 291 65 -414 minecraft:sand
fill 292 65 -414 302 65 -414 minecraft:air
fill 303 65 -414 306 65 -414 minecraft:sand
fill 307 65 -414 315 65 -414 minecraft:sandstone
fill 316 65 -414 320 65 -414 minecraft:dirt
fill 321 65 -414 327 65 -414 minecraft:stone
fill 264 65 -415 271 65 -415 minecraft:grass_block[snowy=false]
fill 272 65 -415 275 65 -415 minecraft:sand
setblock 276 65 -415 minecraft:air
fill 277 65 -415 279 65 -415 minecraft:sand
fill 280 65 -415 286 65 -415 minecraft:air
fill 287 65 -415 289 65 -415 minecraft:sand
fill 290 65 -415 301 65 -415 minecraft:air
fill 302 65 -415 306 65 -415 minecraft:sand
fill 307 65 -415 311 65 -415 minecraft:sandstone
fill 312 65 -415 313 65 -415 minecraft:sand
fill 314 65 -415 315 65 -415 minecraft:sandstone
fill 316 65 -415 320 65 -415 minecraft:dirt
fill 321 65 -415 327 65 -415 minecraft:stone
fill 264 65 -416 271 65 -416 minecraft:grass_block[snowy=false]
fill 272 65 -416 273 65 -416 minecraft:sand
fill 274 65 -416 277 65 -416 minecraft:air
fill 278 65 -416 279 65 -416 minecraft:sand
fill 280 65 -416 314 65 -416 minecraft:air
setblock 315 65 -416 supplementaries:barnacles[down=true,east=false,north=false,south=false,up=false,waterlogged=false,west=false]
setblock 316 65 -416 minecraft:stone
setblock 317 65 -416 minecraft:dirt
fill 318 65 -416 319 65 -416 minecraft:stone
setblock 320 65 -416 minecraft:sandstone
fill 321 65 -416 327 65 -416 minecraft:stone
fill 264 65 -417 272 65 -417 minecraft:grass_block[snowy=false]
fill 273 65 -417 278 65 -417 minecraft:sand
fill 279 65 -417 315 65 -417 minecraft:air
fill 316 65 -417 318 65 -417 minecraft:stone
fill 319 65 -417 320 65 -417 minecraft:sandstone
fill 321 65 -417 327 65 -417 minecraft:stone
fill 264 65 -418 273 65 -418 minecraft:grass_block[snowy=false]
fill 274 65 -418 275 65 -418 minecraft:sand
fill 276 65 -418 314 65 -418 minecraft:air
setblock 315 65 -418 minecraft:sand
setblock 316 65 -418 minecraft:air
fill 317 65 -418 327 65 -418 minecraft:stone
fill 264 65 -419 273 65 -419 minecraft:grass_block[snowy=false]
setblock 274 65 -419 minecraft:sand
fill 275 65 -419 314 65 -419 minecraft:air
setblock 315 65 -419 minecraft:sand
setblock 316 65 -419 supplementaries:barnacles[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
setblock 317 65 -419 minecraft:sandstone
fill 318 65 -419 326 65 -419 minecraft:stone
fill 264 65 -420 272 65 -420 minecraft:grass_block[snowy=false]
fill 273 65 -420 315 65 -420 minecraft:air
fill 316 65 -420 318 65 -420 minecraft:sandstone
fill 319 65 -420 321 65 -420 minecraft:stone
fill 322 65 -420 324 65 -420 minecraft:diorite
fill 325 65 -420 327 65 -420 minecraft:stone
fill 264 65 -421 272 65 -421 minecraft:grass_block[snowy=false]
fill 273 65 -421 315 65 -421 minecraft:air
fill 316 65 -421 319 65 -421 minecraft:sandstone
fill 320 65 -421 321 65 -421 minecraft:stone
fill 322 65 -421 324 65 -421 minecraft:sandstone
setblock 325 65 -421 minecraft:stone
fill 264 65 -422 272 65 -422 minecraft:grass_block[snowy=false]
fill 273 65 -422 314 65 -422 minecraft:air
fill 315 65 -422 324 65 -422 minecraft:sandstone
setblock 325 65 -422 minecraft:sand
setblock 327 65 -422 minecraft:air
fill 264 65 -423 273 65 -423 minecraft:grass_block[snowy=false]
fill 274 65 -423 314 65 -423 minecraft:air
fill 315 65 -423 324 65 -423 minecraft:sandstone
setblock 325 65 -423 minecraft:sand
fill 326 65 -423 327 65 -423 minecraft:air
fill 264 65 -424 273 65 -424 minecraft:grass_block[snowy=false]
fill 274 65 -424 314 65 -424 minecraft:air
fill 315 65 -424 323 65 -424 minecraft:sandstone
setblock 324 65 -424 minecraft:sand
fill 325 65 -424 327 65 -424 minecraft:air
fill 264 65 -425 273 65 -425 minecraft:grass_block[snowy=false]
fill 274 65 -425 314 65 -425 minecraft:air
fill 315 65 -425 322 65 -425 minecraft:sandstone
setblock 323 65 -425 minecraft:sand
fill 324 65 -425 327 65 -425 minecraft:air
fill 264 65 -426 273 65 -426 minecraft:grass_block[snowy=false]
fill 274 65 -426 314 65 -426 minecraft:air
fill 315 65 -426 320 65 -426 minecraft:sandstone
fill 321 65 -426 322 65 -426 minecraft:sand
fill 323 65 -426 327 65 -426 minecraft:air
setblock 264 65 -427 minecraft:birch_log[axis=y]
fill 265 65 -427 273 65 -427 minecraft:grass_block[snowy=false]
fill 274 65 -427 280 65 -427 minecraft:air
setblock 281 65 -427 minecraft:sand
fill 282 65 -427 314 65 -427 minecraft:air
fill 315 65 -427 319 65 -427 minecraft:sandstone
fill 320 65 -427 321 65 -427 minecraft:sand
setblock 322 65 -427 torchmaster:invisible_light
fill 323 65 -427 327 65 -427 minecraft:air
setblock 264 65 -428 minecraft:air
setblock 265 65 -428 regions_unexplored:grass_sprouts
fill 266 65 -428 268 65 -428 minecraft:grass_block[snowy=false]
fill 269 65 -428 270 65 -428 minecraft:sand
fill 271 65 -428 314 65 -428 minecraft:air
fill 315 65 -428 318 65 -428 minecraft:sandstone
fill 319 65 -428 320 65 -428 minecraft:sand
fill 321 65 -428 327 65 -428 minecraft:air
setblock 264 65 -429 minecraft:air
setblock 265 65 -429 regions_unexplored:grass_sprouts
setblock 266 65 -429 minecraft:air
fill 267 65 -429 268 65 -429 minecraft:grass_block[snowy=false]
fill 269 65 -429 270 65 -429 minecraft:sand
fill 271 65 -429 314 65 -429 minecraft:air
fill 315 65 -429 318 65 -429 minecraft:sandstone
fill 319 65 -429 320 65 -429 minecraft:sand
fill 321 65 -429 327 65 -429 minecraft:air
fill 264 65 -430 267 65 -430 minecraft:air
setblock 268 65 -430 minecraft:grass_block[snowy=false]
fill 269 65 -430 270 65 -430 minecraft:sand
fill 271 65 -430 314 65 -430 minecraft:air
fill 315 65 -430 318 65 -430 minecraft:sandstone
setblock 319 65 -430 minecraft:sand
fill 320 65 -430 327 65 -430 minecraft:air
fill 264 65 -431 265 65 -431 minecraft:air
setblock 266 65 -431 minecraft:short_grass
setblock 267 65 -431 regions_unexplored:grass_sprouts
setblock 268 65 -431 minecraft:short_grass
fill 269 65 -431 270 65 -431 minecraft:sand
setblock 271 65 -431 minecraft:air
fill 274 65 -431 314 65 -431 minecraft:air
fill 315 65 -431 316 65 -431 minecraft:sandstone
fill 317 65 -431 319 65 -431 minecraft:sand
fill 320 65 -431 327 65 -431 minecraft:air
fill 264 65 -432 266 65 -432 minecraft:air
setblock 267 65 -432 regions_unexplored:grass_sprouts
fill 268 65 -432 269 65 -432 minecraft:air
setblock 270 65 -432 minecraft:sand
fill 274 65 -432 314 65 -432 minecraft:air
fill 315 65 -432 317 65 -432 minecraft:sand
fill 318 65 -432 327 65 -432 minecraft:air
fill 264 65 -433 270 65 -433 minecraft:air
fill 274 65 -433 314 65 -433 minecraft:air
setblock 315 65 -433 minecraft:sandstone
fill 316 65 -433 319 65 -433 minecraft:sand
fill 320 65 -433 323 65 -433 minecraft:air
setblock 324 65 -433 minecraft:short_grass
fill 264 65 -434 272 65 -434 minecraft:air
fill 274 65 -434 314 65 -434 minecraft:air
setblock 315 65 -434 minecraft:sandstone
fill 316 65 -434 320 65 -434 minecraft:sand
setblock 264 65 -435 minecraft:birch_log[axis=y]
fill 265 65 -435 314 65 -435 minecraft:air
fill 315 65 -435 320 65 -435 minecraft:sand
setblock 327 65 -435 minecraft:stone
fill 264 65 -436 314 65 -436 minecraft:air
fill 315 65 -436 318 65 -436 minecraft:dirt
fill 319 65 -436 321 65 -436 minecraft:sand
fill 325 65 -436 327 65 -436 minecraft:stone
fill 264 65 -437 314 65 -437 minecraft:air
fill 315 65 -437 317 65 -437 minecraft:dirt
setblock 318 65 -437 minecraft:stone
fill 319 65 -437 320 65 -437 minecraft:sandstone
fill 321 65 -437 327 65 -437 minecraft:stone
fill 264 65 -438 314 65 -438 minecraft:air
fill 315 65 -438 327 65 -438 minecraft:stone
fill 264 65 -439 277 65 -439 minecraft:air
fill 278 65 -439 280 65 -439 minecraft:sand
fill 281 65 -439 314 65 -439 minecraft:air
fill 315 65 -439 327 65 -439 minecraft:stone
fill 264 65 -440 277 65 -440 minecraft:air
fill 278 65 -440 281 65 -440 minecraft:sand
fill 282 65 -440 314 65 -440 minecraft:air
setblock 315 65 -440 minecraft:sandstone
fill 316 65 -440 327 65 -440 minecraft:stone
fill 264 65 -441 278 65 -441 minecraft:air
fill 279 65 -441 281 65 -441 minecraft:sand
fill 282 65 -441 314 65 -441 minecraft:air
fill 315 65 -441 316 65 -441 minecraft:sandstone
fill 317 65 -441 327 65 -441 minecraft:stone
fill 264 65 -442 278 65 -442 minecraft:air
setblock 279 65 -442 minecraft:sandstone
fill 280 65 -442 281 65 -442 minecraft:sand
fill 282 65 -442 314 65 -442 minecraft:air
fill 315 65 -442 316 65 -442 minecraft:sandstone
fill 317 65 -442 327 65 -442 minecraft:stone
fill 264 65 -443 279 65 -443 minecraft:air
fill 280 65 -443 281 65 -443 minecraft:sandstone
fill 282 65 -443 314 65 -443 minecraft:air
fill 315 65 -443 316 65 -443 minecraft:sandstone
fill 317 65 -443 327 65 -443 minecraft:stone
fill 264 65 -444 279 65 -444 minecraft:air
fill 280 65 -444 281 65 -444 minecraft:sand
fill 282 65 -444 314 65 -444 minecraft:air
fill 315 65 -444 316 65 -444 minecraft:sandstone
fill 317 65 -444 324 65 -444 minecraft:stone
fill 325 65 -444 327 65 -444 minecraft:dirt
fill 264 65 -445 314 65 -445 minecraft:air
fill 315 65 -445 322 65 -445 minecraft:stone
fill 323 65 -445 327 65 -445 minecraft:dirt
fill 264 65 -446 315 65 -446 minecraft:air
fill 316 65 -446 323 65 -446 minecraft:stone
fill 324 65 -446 327 65 -446 minecraft:dirt
fill 308 64 -391 309 64 -391 minecraft:air
fill 307 64 -392 312 64 -392 minecraft:air
fill 308 64 -393 312 64 -393 minecraft:air
setblock 301 64 -394 minecraft:air
fill 310 64 -394 311 64 -394 minecraft:air
setblock 313 64 -394 minecraft:air
setblock 324 64 -394 minecraft:air
setblock 311 64 -395 minecraft:air
fill 313 64 -395 315 64 -395 minecraft:air
setblock 323 64 -395 minecraft:air
setblock 292 64 -396 minecraft:air
fill 311 64 -396 316 64 -396 minecraft:air
setblock 321 64 -396 minecraft:air
setblock 292 64 -397 minecraft:air
setblock 303 64 -397 minecraft:air
setblock 311 64 -397 ars_nouveau:light_block[level=14,waterlogged=false]
fill 312 64 -397 315 64 -397 minecraft:air
fill 319 64 -397 320 64 -397 minecraft:air
fill 292 64 -398 294 64 -398 minecraft:air
setblock 303 64 -398 minecraft:air
fill 311 64 -398 313 64 -398 minecraft:air
fill 318 64 -398 319 64 -398 minecraft:air
fill 292 64 -399 300 64 -399 minecraft:air
fill 304 64 -399 307 64 -399 minecraft:air
setblock 312 64 -399 minecraft:air
fill 316 64 -399 317 64 -399 minecraft:air
fill 291 64 -400 300 64 -400 minecraft:air
fill 304 64 -400 310 64 -400 minecraft:air
fill 314 64 -400 315 64 -400 minecraft:air
fill 290 64 -401 301 64 -401 minecraft:air
fill 303 64 -401 308 64 -401 minecraft:air
fill 313 64 -401 315 64 -401 minecraft:air
fill 287 64 -402 298 64 -402 minecraft:air
setblock 299 64 -402 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 300 64 -402 minecraft:air
fill 302 64 -402 309 64 -402 minecraft:air
fill 311 64 -402 314 64 -402 minecraft:air
fill 282 64 -403 283 64 -403 minecraft:air
fill 285 64 -403 298 64 -403 minecraft:air
fill 300 64 -403 314 64 -403 minecraft:air
fill 282 64 -404 312 64 -404 minecraft:air
setblock 314 64 -404 minecraft:air
fill 282 64 -405 315 64 -405 minecraft:air
fill 281 64 -406 314 64 -406 minecraft:air
fill 281 64 -407 288 64 -407 minecraft:air
fill 290 64 -407 313 64 -407 minecraft:air
fill 280 64 -408 286 64 -408 minecraft:air
fill 290 64 -408 313 64 -408 minecraft:air
fill 280 64 -409 286 64 -409 minecraft:air
fill 298 64 -409 301 64 -409 minecraft:air
fill 307 64 -409 311 64 -409 minecraft:air
fill 280 64 -410 283 64 -410 minecraft:air
fill 293 64 -410 301 64 -410 minecraft:air
fill 311 64 -410 312 64 -410 minecraft:air
fill 280 64 -411 284 64 -411 minecraft:air
fill 293 64 -411 297 64 -411 minecraft:air
fill 299 64 -411 302 64 -411 minecraft:air
fill 280 64 -412 285 64 -412 minecraft:air
fill 293 64 -412 297 64 -412 minecraft:air
fill 299 64 -412 302 64 -412 minecraft:air
setblock 280 64 -413 ars_nouveau:light_block[level=14,waterlogged=false]
fill 281 64 -413 285 64 -413 minecraft:air
fill 292 64 -413 301 64 -413 minecraft:air
fill 280 64 -414 286 64 -414 minecraft:air
fill 292 64 -414 299 64 -414 minecraft:air
fill 280 64 -415 286 64 -415 minecraft:air
fill 290 64 -415 300 64 -415 minecraft:air
fill 280 64 -416 314 64 -416 minecraft:air
fill 279 64 -417 314 64 -417 minecraft:air
fill 276 64 -418 314 64 -418 minecraft:air
fill 275 64 -419 314 64 -419 minecraft:air
fill 273 64 -420 314 64 -420 minecraft:air
fill 272 64 -421 314 64 -421 minecraft:air
fill 273 64 -422 314 64 -422 minecraft:air
setblock 327 64 -422 minecraft:air
fill 274 64 -423 314 64 -423 minecraft:air
fill 326 64 -423 327 64 -423 minecraft:air
fill 274 64 -424 314 64 -424 minecraft:air
fill 325 64 -424 327 64 -424 minecraft:air
fill 274 64 -425 314 64 -425 minecraft:air
fill 324 64 -425 327 64 -425 minecraft:air
fill 273 64 -426 314 64 -426 minecraft:air
fill 323 64 -426 327 64 -426 minecraft:air
fill 271 64 -427 280 64 -427 minecraft:air
fill 282 64 -427 314 64 -427 minecraft:air
fill 322 64 -427 327 64 -427 minecraft:air
fill 271 64 -428 314 64 -428 minecraft:air
fill 321 64 -428 327 64 -428 minecraft:air
setblock 264 64 -429 minecraft:air
fill 272 64 -429 314 64 -429 minecraft:air
fill 321 64 -429 327 64 -429 minecraft:air
setblock 264 64 -430 minecraft:air
fill 271 64 -430 314 64 -430 minecraft:air
fill 321 64 -430 327 64 -430 minecraft:air
setblock 264 64 -431 minecraft:air
setblock 271 64 -431 minecraft:air
fill 273 64 -431 314 64 -431 minecraft:air
fill 320 64 -431 327 64 -431 minecraft:air
fill 264 64 -432 265 64 -432 minecraft:air
fill 274 64 -432 314 64 -432 minecraft:air
fill 319 64 -432 327 64 -432 minecraft:air
fill 264 64 -433 266 64 -433 minecraft:air
fill 274 64 -433 314 64 -433 minecraft:air
fill 264 64 -434 267 64 -434 minecraft:air
fill 273 64 -434 314 64 -434 minecraft:air
fill 265 64 -435 269 64 -435 minecraft:air
fill 273 64 -435 314 64 -435 minecraft:air
fill 264 64 -436 314 64 -436 minecraft:air
fill 264 64 -437 314 64 -437 minecraft:air
fill 264 64 -438 314 64 -438 minecraft:air
fill 264 64 -439 274 64 -439 minecraft:air
fill 281 64 -439 314 64 -439 minecraft:air
fill 264 64 -440 274 64 -440 minecraft:air
fill 282 64 -440 314 64 -440 minecraft:air
fill 264 64 -441 277 64 -441 minecraft:air
fill 282 64 -441 314 64 -441 minecraft:air
fill 264 64 -442 277 64 -442 minecraft:air
setblock 279 64 -442 minecraft:air
fill 282 64 -442 314 64 -442 minecraft:air
fill 264 64 -443 314 64 -443 minecraft:air
fill 264 64 -444 276 64 -444 minecraft:air
fill 282 64 -444 314 64 -444 minecraft:air
fill 264 64 -445 277 64 -445 minecraft:air
fill 282 64 -445 314 64 -445 minecraft:air
fill 264 64 -446 278 64 -446 minecraft:air
fill 282 64 -446 315 64 -446 minecraft:air
setblock 297 63 -389 minecraft:air
setblock 298 63 -390 minecraft:air
setblock 298 63 -391 minecraft:air
setblock 299 63 -392 minecraft:air
setblock 300 63 -393 minecraft:air
setblock 327 63 -393 minecraft:air
fill 300 63 -394 301 63 -394 minecraft:air
fill 324 63 -394 326 63 -394 minecraft:air
setblock 301 63 -395 minecraft:air
fill 323 63 -395 325 63 -395 minecraft:air
setblock 302 63 -396 minecraft:air
fill 321 63 -396 323 63 -396 minecraft:air
setblock 302 63 -397 minecraft:air
fill 319 63 -397 322 63 -397 minecraft:air
setblock 303 63 -398 minecraft:air
fill 318 63 -398 321 63 -398 minecraft:air
setblock 302 63 -399 minecraft:air
fill 317 63 -399 319 63 -399 minecraft:air
fill 303 63 -400 306 63 -400 minecraft:air
fill 315 63 -400 318 63 -400 minecraft:air
fill 302 63 -401 307 63 -401 minecraft:air
fill 313 63 -401 317 63 -401 minecraft:air
fill 301 63 -402 317 63 -402 minecraft:air
fill 299 63 -403 316 63 -403 minecraft:air
fill 282 63 -404 291 63 -404 minecraft:air
fill 294 63 -404 316 63 -404 minecraft:air
fill 282 63 -405 315 63 -405 minecraft:air
fill 281 63 -406 315 63 -406 minecraft:air
fill 281 63 -407 314 63 -407 minecraft:air
fill 281 63 -408 290 63 -408 minecraft:air
fill 292 63 -408 313 63 -408 minecraft:air
fill 281 63 -409 286 63 -409 minecraft:air
fill 298 63 -409 302 63 -409 minecraft:air
fill 307 63 -409 313 63 -409 minecraft:air
fill 280 63 -410 283 63 -410 minecraft:air
fill 293 63 -410 296 63 -410 minecraft:air
fill 299 63 -410 302 63 -410 minecraft:air
setblock 312 63 -410 minecraft:air
fill 280 63 -411 284 63 -411 minecraft:air
fill 293 63 -411 296 63 -411 minecraft:air
fill 299 63 -411 302 63 -411 minecraft:air
fill 280 63 -412 284 63 -412 minecraft:air
fill 293 63 -412 296 63 -412 minecraft:air
fill 299 63 -412 302 63 -412 minecraft:air
fill 280 63 -413 285 63 -413 minecraft:air
fill 292 63 -413 296 63 -413 minecraft:air
fill 300 63 -413 301 63 -413 minecraft:air
fill 280 63 -414 285 63 -414 minecraft:air
fill 292 63 -414 297 63 -414 minecraft:air
setblock 299 63 -414 minecraft:air
fill 280 63 -415 285 63 -415 minecraft:air
fill 290 63 -415 295 63 -415 minecraft:air
fill 280 63 -416 314 63 -416 minecraft:air
fill 279 63 -417 314 63 -417 minecraft:air
fill 276 63 -418 314 63 -418 minecraft:air
fill 275 63 -419 314 63 -419 minecraft:air
fill 272 63 -420 314 63 -420 minecraft:air
fill 272 63 -421 314 63 -421 minecraft:air
fill 273 63 -422 314 63 -422 minecraft:air
setblock 327 63 -422 minecraft:air
fill 274 63 -423 314 63 -423 minecraft:air
fill 326 63 -423 327 63 -423 minecraft:air
fill 277 63 -424 314 63 -424 minecraft:air
fill 325 63 -424 327 63 -424 minecraft:air
fill 277 63 -425 314 63 -425 minecraft:air
fill 324 63 -425 327 63 -425 minecraft:air
fill 273 63 -426 314 63 -426 minecraft:air
fill 323 63 -426 327 63 -426 minecraft:air
fill 271 63 -427 280 63 -427 minecraft:air
fill 282 63 -427 314 63 -427 minecraft:air
fill 322 63 -427 327 63 -427 minecraft:air
fill 272 63 -428 280 63 -428 minecraft:air
fill 282 63 -428 314 63 -428 minecraft:air
fill 321 63 -428 327 63 -428 minecraft:air
fill 272 63 -429 314 63 -429 minecraft:air
fill 321 63 -429 327 63 -429 minecraft:air
fill 271 63 -430 314 63 -430 minecraft:air
fill 321 63 -430 327 63 -430 minecraft:air
fill 271 63 -431 314 63 -431 minecraft:air
fill 320 63 -431 327 63 -431 minecraft:air
fill 273 63 -432 314 63 -432 minecraft:air
fill 319 63 -432 327 63 -432 minecraft:air
fill 273 63 -433 314 63 -433 minecraft:air
setblock 323 63 -433 torchmaster:invisible_light
setblock 324 63 -433 minecraft:air
fill 273 63 -434 314 63 -434 minecraft:air
fill 273 63 -435 314 63 -435 minecraft:air
fill 271 63 -436 314 63 -436 minecraft:air
fill 270 63 -437 314 63 -437 minecraft:air
fill 264 63 -438 266 63 -438 minecraft:air
fill 269 63 -438 314 63 -438 minecraft:air
fill 264 63 -439 267 63 -439 minecraft:air
fill 269 63 -439 274 63 -439 minecraft:air
fill 281 63 -439 314 63 -439 minecraft:air
fill 264 63 -440 270 63 -440 minecraft:air
fill 277 63 -440 278 63 -440 minecraft:air
fill 282 63 -440 314 63 -440 minecraft:air
fill 264 63 -441 270 63 -441 minecraft:air
setblock 274 63 -441 minecraft:air
fill 276 63 -441 280 63 -441 minecraft:air
fill 282 63 -441 314 63 -441 minecraft:air
fill 264 63 -442 270 63 -442 minecraft:air
fill 276 63 -442 314 63 -442 minecraft:air
fill 264 63 -443 268 63 -443 minecraft:air
fill 270 63 -443 271 63 -443 minecraft:air
fill 278 63 -443 314 63 -443 minecraft:air
fill 264 63 -444 268 63 -444 minecraft:air
fill 270 63 -444 271 63 -444 minecraft:air
fill 282 63 -444 314 63 -444 minecraft:air
fill 264 63 -445 268 63 -445 minecraft:air
fill 270 63 -445 272 63 -445 minecraft:air
fill 282 63 -445 314 63 -445 minecraft:air
fill 264 63 -446 274 63 -446 minecraft:air
fill 282 63 -446 314 63 -446 minecraft:air
setblock 295 62 -386 minecraft:air
setblock 296 62 -387 minecraft:air
setblock 296 62 -388 minecraft:air
setblock 297 62 -389 minecraft:air
fill 297 62 -390 298 62 -390 minecraft:air
fill 298 62 -391 299 62 -391 minecraft:air
fill 298 62 -392 299 62 -392 minecraft:air
fill 299 62 -393 300 62 -393 minecraft:air
setblock 327 62 -393 minecraft:air
fill 299 62 -394 301 62 -394 minecraft:air
fill 325 62 -394 327 62 -394 minecraft:air
fill 300 62 -395 301 62 -395 minecraft:air
fill 323 62 -395 327 62 -395 minecraft:air
fill 301 62 -396 302 62 -396 minecraft:air
fill 321 62 -396 323 62 -396 minecraft:air
setblock 325 62 -396 minecraft:air
fill 301 62 -397 302 62 -397 minecraft:air
fill 320 62 -397 324 62 -397 minecraft:air
fill 301 62 -398 303 62 -398 minecraft:air
fill 318 62 -398 322 62 -398 minecraft:air
fill 301 62 -399 303 62 -399 minecraft:air
fill 317 62 -399 321 62 -399 minecraft:air
fill 303 62 -400 306 62 -400 minecraft:air
fill 315 62 -400 320 62 -400 minecraft:air
fill 301 62 -401 307 62 -401 minecraft:air
fill 314 62 -401 319 62 -401 minecraft:air
fill 300 62 -402 310 62 -402 minecraft:air
fill 313 62 -402 318 62 -402 minecraft:air
fill 299 62 -403 317 62 -403 minecraft:air
fill 282 62 -404 285 62 -404 minecraft:air
fill 294 62 -404 317 62 -404 minecraft:air
fill 281 62 -405 315 62 -405 minecraft:air
fill 281 62 -406 316 62 -406 minecraft:air
fill 281 62 -407 315 62 -407 minecraft:air
fill 281 62 -408 285 62 -408 minecraft:air
fill 287 62 -408 314 62 -408 minecraft:air
fill 290 62 -409 291 62 -409 minecraft:air
fill 294 62 -409 295 62 -409 minecraft:air
fill 298 62 -409 308 62 -409 minecraft:air
fill 310 62 -409 314 62 -409 minecraft:air
fill 280 62 -410 281 62 -410 minecraft:air
fill 300 62 -410 302 62 -410 minecraft:air
fill 310 62 -410 313 62 -410 minecraft:air
fill 280 62 -411 283 62 -411 minecraft:air
fill 299 62 -411 303 62 -411 minecraft:air
fill 280 62 -412 284 62 -412 minecraft:air
fill 299 62 -412 302 62 -412 minecraft:air
fill 280 62 -413 284 62 -413 minecraft:air
fill 300 62 -413 301 62 -413 minecraft:air
setblock 280 62 -414 minecraft:air
fill 282 62 -414 285 62 -414 minecraft:air
fill 280 62 -415 285 62 -415 minecraft:air
setblock 290 62 -415 minecraft:air
fill 280 62 -416 314 62 -416 minecraft:air
fill 280 62 -417 314 62 -417 minecraft:air
fill 279 62 -418 314 62 -418 minecraft:air
fill 275 62 -419 314 62 -419 minecraft:air
fill 272 62 -420 274 62 -420 minecraft:air
fill 277 62 -420 314 62 -420 minecraft:air
fill 278 62 -421 314 62 -421 minecraft:air
fill 279 62 -422 314 62 -422 minecraft:air
setblock 327 62 -422 minecraft:air
fill 280 62 -423 314 62 -423 minecraft:air
fill 326 62 -423 327 62 -423 minecraft:air
fill 282 62 -424 314 62 -424 minecraft:air
fill 325 62 -424 327 62 -424 minecraft:air
fill 282 62 -425 314 62 -425 minecraft:air
fill 324 62 -425 327 62 -425 minecraft:air
fill 282 62 -426 314 62 -426 minecraft:air
fill 323 62 -426 327 62 -426 minecraft:air
fill 282 62 -427 314 62 -427 minecraft:air
fill 322 62 -427 327 62 -427 minecraft:air
fill 282 62 -428 314 62 -428 minecraft:air
fill 321 62 -428 327 62 -428 minecraft:air
fill 282 62 -429 314 62 -429 minecraft:air
fill 321 62 -429 327 62 -429 minecraft:air
fill 282 62 -430 314 62 -430 minecraft:air
fill 321 62 -430 327 62 -430 minecraft:air
fill 272 62 -431 273 62 -431 minecraft:air
fill 282 62 -431 314 62 -431 minecraft:air
fill 320 62 -431 327 62 -431 minecraft:air
fill 273 62 -432 274 62 -432 minecraft:air
fill 282 62 -432 314 62 -432 minecraft:air
fill 319 62 -432 327 62 -432 minecraft:air
fill 273 62 -433 276 62 -433 minecraft:air
fill 282 62 -433 314 62 -433 minecraft:air
fill 323 62 -433 324 62 -433 minecraft:air
fill 273 62 -434 277 62 -434 minecraft:air
fill 282 62 -434 314 62 -434 minecraft:air
fill 273 62 -435 278 62 -435 minecraft:air
fill 282 62 -435 314 62 -435 minecraft:air
fill 272 62 -436 278 62 -436 minecraft:air
fill 282 62 -436 314 62 -436 minecraft:air
fill 270 62 -437 279 62 -437 minecraft:air
fill 281 62 -437 314 62 -437 minecraft:air
fill 269 62 -438 279 62 -438 minecraft:air
setblock 281 62 -438 minecraft:air
setblock 282 62 -438 minecraft:water[level=3]
fill 283 62 -438 314 62 -438 minecraft:air
setblock 264 62 -439 minecraft:water[level=0]
fill 269 62 -439 274 62 -439 minecraft:air
setblock 282 62 -439 minecraft:water[level=2]
setblock 283 62 -439 minecraft:water[level=3]
fill 284 62 -439 314 62 -439 minecraft:air
fill 264 62 -440 265 62 -440 minecraft:water[level=0]
setblock 269 62 -440 minecraft:air
fill 276 62 -440 281 62 -440 minecraft:water[level=0]
setblock 282 62 -440 minecraft:water[level=1]
setblock 283 62 -440 minecraft:water[level=2]
fill 284 62 -440 314 62 -440 minecraft:air
fill 264 62 -441 267 62 -441 minecraft:water[level=0]
fill 276 62 -441 281 62 -441 minecraft:water[level=0]
setblock 282 62 -441 minecraft:water[level=1]
setblock 283 62 -441 minecraft:water[level=2]
fill 284 62 -441 314 62 -441 minecraft:air
fill 264 62 -442 267 62 -442 minecraft:water[level=0]
fill 278 62 -442 281 62 -442 minecraft:water[level=0]
setblock 282 62 -442 minecraft:water[level=1]
setblock 283 62 -442 minecraft:water[level=2]
fill 284 62 -442 314 62 -442 minecraft:air
fill 264 62 -443 268 62 -443 minecraft:water[level=0]
setblock 281 62 -443 minecraft:water[level=0]
setblock 282 62 -443 minecraft:water[level=1]
setblock 283 62 -443 minecraft:water[level=2]
fill 284 62 -443 314 62 -443 minecraft:air
fill 264 62 -444 268 62 -444 minecraft:water[level=0]
fill 282 62 -444 314 62 -444 minecraft:air
fill 264 62 -445 268 62 -445 minecraft:water[level=0]
setblock 270 62 -445 minecraft:water[level=0]
fill 282 62 -445 314 62 -445 minecraft:air
fill 264 62 -446 271 62 -446 minecraft:water[level=0]
fill 282 62 -446 313 62 -446 minecraft:air
setblock 314 62 -446 minecraft:water[level=3]
setblock 294 61 -385 minecraft:air
fill 294 61 -386 295 61 -386 minecraft:air
fill 295 61 -387 296 61 -387 minecraft:air
fill 295 61 -388 297 61 -388 minecraft:air
setblock 296 61 -389 minecraft:air
fill 296 61 -390 298 61 -390 minecraft:air
fill 297 61 -391 299 61 -391 minecraft:air
fill 297 61 -392 299 61 -392 minecraft:air
fill 298 61 -393 299 61 -393 minecraft:air
setblock 327 61 -393 minecraft:air
fill 298 61 -394 300 61 -394 minecraft:air
fill 325 61 -394 327 61 -394 minecraft:air
fill 300 61 -395 301 61 -395 minecraft:air
fill 323 61 -395 327 61 -395 minecraft:air
fill 300 61 -396 301 61 -396 minecraft:air
fill 322 61 -396 326 61 -396 minecraft:air
fill 300 61 -397 302 61 -397 minecraft:air
fill 320 61 -397 324 61 -397 minecraft:air
fill 300 61 -398 302 61 -398 minecraft:air
fill 318 61 -398 321 61 -398 minecraft:air
setblock 323 61 -398 minecraft:air
setblock 302 61 -399 minecraft:air
fill 317 61 -399 321 61 -399 minecraft:air
fill 301 61 -400 306 61 -400 minecraft:air
fill 316 61 -400 319 61 -400 minecraft:air
fill 301 61 -401 307 61 -401 minecraft:air
fill 315 61 -401 319 61 -401 minecraft:air
fill 300 61 -402 309 61 -402 minecraft:air
fill 314 61 -402 319 61 -402 minecraft:air
fill 299 61 -403 309 61 -403 minecraft:air
fill 313 61 -403 318 61 -403 minecraft:air
fill 282 61 -404 284 61 -404 minecraft:air
fill 296 61 -404 309 61 -404 minecraft:air
fill 311 61 -404 316 61 -404 minecraft:air
setblock 281 61 -405 minecraft:air
fill 283 61 -405 317 61 -405 minecraft:air
fill 282 61 -406 316 61 -406 minecraft:air
fill 282 61 -407 316 61 -407 minecraft:air
fill 281 61 -408 285 61 -408 minecraft:air
fill 287 61 -408 315 61 -408 minecraft:air
setblock 289 61 -409 minecraft:air
fill 291 61 -409 315 61 -409 minecraft:air
fill 292 61 -410 294 61 -410 minecraft:air
fill 300 61 -410 302 61 -410 minecraft:air
fill 310 61 -410 314 61 -410 minecraft:air
setblock 292 61 -411 minecraft:air
setblock 294 61 -411 minecraft:air
fill 299 61 -411 302 61 -411 minecraft:air
setblock 314 61 -411 minecraft:air
fill 292 61 -412 295 61 -412 minecraft:air
fill 299 61 -412 302 61 -412 minecraft:air
setblock 280 61 -413 minecraft:air
fill 292 61 -413 295 61 -413 minecraft:air
fill 300 61 -413 301 61 -413 minecraft:air
fill 292 61 -414 295 61 -414 minecraft:air
fill 293 61 -415 295 61 -415 minecraft:air
fill 282 61 -416 314 61 -416 minecraft:air
fill 282 61 -417 314 61 -417 minecraft:air
fill 282 61 -418 314 61 -418 minecraft:air
fill 282 61 -419 314 61 -419 minecraft:air
fill 280 61 -420 314 61 -420 minecraft:air
fill 282 61 -421 314 61 -421 minecraft:air
fill 282 61 -422 314 61 -422 minecraft:air
fill 282 61 -423 314 61 -423 minecraft:air
setblock 327 61 -423 minecraft:air
fill 282 61 -424 314 61 -424 minecraft:air
fill 325 61 -424 327 61 -424 minecraft:air
fill 282 61 -425 314 61 -425 minecraft:air
fill 325 61 -425 327 61 -425 minecraft:air
fill 282 61 -426 314 61 -426 minecraft:air
fill 324 61 -426 327 61 -426 minecraft:air
fill 282 61 -427 314 61 -427 minecraft:air
setblock 323 61 -427 minecraft:air
setblock 324 61 -427 torchmaster:invisible_light
fill 325 61 -427 327 61 -427 minecraft:air
fill 282 61 -428 314 61 -428 minecraft:air
fill 322 61 -428 327 61 -428 minecraft:air
fill 282 61 -429 314 61 -429 minecraft:air
fill 321 61 -429 327 61 -429 minecraft:air
fill 282 61 -430 314 61 -430 minecraft:air
fill 321 61 -430 327 61 -430 minecraft:air
fill 282 61 -431 314 61 -431 minecraft:air
setblock 320 61 -431 minecraft:air
setblock 321 61 -431 torchmaster:invisible_light
fill 322 61 -431 327 61 -431 minecraft:air
fill 282 61 -432 314 61 -432 minecraft:air
fill 320 61 -432 327 61 -432 minecraft:air
fill 282 61 -433 314 61 -433 minecraft:air
fill 322 61 -433 325 61 -433 minecraft:air
fill 282 61 -434 314 61 -434 minecraft:air
fill 273 61 -435 277 61 -435 minecraft:air
fill 282 61 -435 314 61 -435 minecraft:air
fill 273 61 -436 274 61 -436 minecraft:air
fill 276 61 -436 277 61 -436 minecraft:air
fill 282 61 -436 314 61 -436 minecraft:air
fill 270 61 -437 275 61 -437 minecraft:air
setblock 277 61 -437 minecraft:air
setblock 282 61 -437 minecraft:water[level=1]
fill 283 61 -437 314 61 -437 minecraft:air
fill 269 61 -438 275 61 -438 minecraft:air
setblock 276 61 -438 minecraft:water[level=2]
fill 277 61 -438 278 61 -438 minecraft:water[level=1]
setblock 282 61 -438 minecraft:water[level=8]
setblock 283 61 -438 minecraft:water[level=1]
fill 284 61 -438 314 61 -438 minecraft:air
fill 269 61 -439 273 61 -439 minecraft:air
fill 277 61 -439 281 61 -439 minecraft:water[level=0]
fill 282 61 -439 283 61 -439 minecraft:water[level=8]
fill 284 61 -439 314 61 -439 minecraft:air
setblock 264 61 -440 minecraft:water[level=0]
setblock 269 61 -440 minecraft:air
fill 277 61 -440 281 61 -440 minecraft:water[level=0]
fill 282 61 -440 283 61 -440 minecraft:water[level=8]
setblock 284 61 -440 minecraft:water[level=1]
fill 285 61 -440 314 61 -440 minecraft:air
fill 264 61 -441 265 61 -441 minecraft:water[level=0]
fill 279 61 -441 281 61 -441 minecraft:water[level=0]
fill 282 61 -441 283 61 -441 minecraft:water[level=8]
setblock 284 61 -441 minecraft:water[level=1]
fill 285 61 -441 314 61 -441 minecraft:air
fill 264 61 -442 266 61 -442 minecraft:water[level=0]
fill 282 61 -442 283 61 -442 minecraft:water[level=8]
setblock 284 61 -442 minecraft:water[level=1]
fill 285 61 -442 314 61 -442 minecraft:air
fill 264 61 -443 267 61 -443 minecraft:water[level=0]
fill 282 61 -443 283 61 -443 minecraft:water[level=8]
fill 284 61 -443 314 61 -443 minecraft:air
fill 264 61 -444 267 61 -444 minecraft:water[level=0]
fill 282 61 -444 314 61 -444 minecraft:air
fill 264 61 -445 268 61 -445 minecraft:water[level=0]
fill 282 61 -445 313 61 -445 minecraft:air
setblock 314 61 -445 minecraft:water[level=1]
fill 264 61 -446 269 61 -446 minecraft:water[level=0]
fill 282 61 -446 312 61 -446 minecraft:air
setblock 313 61 -446 minecraft:water[level=1]
setblock 314 61 -446 minecraft:water[level=8]
fill 293 60 -385 295 60 -385 minecraft:air
fill 294 60 -386 296 60 -386 minecraft:air
fill 294 60 -387 296 60 -387 minecraft:air
fill 294 60 -388 297 60 -388 minecraft:air
fill 295 60 -389 298 60 -389 minecraft:air
fill 295 60 -390 298 60 -390 minecraft:air
fill 296 60 -391 298 60 -391 minecraft:air
fill 296 60 -392 300 60 -392 minecraft:air
fill 297 60 -393 300 60 -393 minecraft:air
setblock 327 60 -393 minecraft:air
fill 297 60 -394 300 60 -394 minecraft:air
fill 325 60 -394 327 60 -394 minecraft:air
fill 298 60 -395 300 60 -395 minecraft:air
fill 325 60 -395 327 60 -395 minecraft:air
fill 299 60 -396 301 60 -396 minecraft:air
fill 323 60 -396 324 60 -396 minecraft:air
setblock 326 60 -396 minecraft:air
fill 299 60 -397 301 60 -397 minecraft:air
fill 320 60 -397 324 60 -397 minecraft:air
fill 299 60 -398 301 60 -398 minecraft:air
setblock 318 60 -398 minecraft:air
fill 320 60 -398 323 60 -398 minecraft:air
fill 301 60 -399 302 60 -399 minecraft:air
fill 318 60 -399 322 60 -399 minecraft:air
fill 301 60 -400 302 60 -400 minecraft:air
fill 304 60 -400 306 60 -400 minecraft:air
fill 317 60 -400 320 60 -400 minecraft:air
fill 301 60 -401 302 60 -401 minecraft:air
fill 304 60 -401 307 60 -401 minecraft:air
fill 315 60 -401 320 60 -401 minecraft:air
fill 300 60 -402 306 60 -402 minecraft:air
fill 315 60 -402 319 60 -402 minecraft:air
fill 299 60 -403 309 60 -403 minecraft:air
fill 314 60 -403 318 60 -403 minecraft:air
fill 283 60 -404 284 60 -404 minecraft:air
fill 295 60 -404 309 60 -404 minecraft:air
fill 313 60 -404 317 60 -404 minecraft:air
fill 283 60 -405 309 60 -405 minecraft:air
fill 312 60 -405 316 60 -405 minecraft:air
fill 284 60 -406 309 60 -406 minecraft:air
fill 311 60 -406 317 60 -406 minecraft:air
fill 283 60 -407 309 60 -407 minecraft:air
fill 311 60 -407 315 60 -407 minecraft:air
fill 282 60 -408 285 60 -408 minecraft:air
fill 287 60 -408 316 60 -408 minecraft:air
fill 289 60 -409 314 60 -409 minecraft:air
fill 291 60 -410 296 60 -410 minecraft:air
fill 300 60 -410 304 60 -410 minecraft:air
fill 309 60 -410 310 60 -410 minecraft:air
fill 312 60 -410 314 60 -410 minecraft:air
fill 291 60 -411 296 60 -411 minecraft:air
fill 299 60 -411 303 60 -411 minecraft:air
fill 291 60 -412 302 60 -412 minecraft:air
fill 292 60 -413 302 60 -413 minecraft:air
fill 291 60 -414 292 60 -414 minecraft:air
fill 294 60 -414 300 60 -414 minecraft:air
fill 289 60 -415 291 60 -415 minecraft:air
fill 282 60 -416 309 60 -416 minecraft:air
fill 312 60 -416 314 60 -416 minecraft:air
fill 282 60 -417 314 60 -417 minecraft:air
fill 282 60 -418 314 60 -418 minecraft:air
fill 282 60 -419 314 60 -419 minecraft:air
fill 282 60 -420 314 60 -420 minecraft:air
fill 282 60 -421 314 60 -421 minecraft:air
fill 282 60 -422 314 60 -422 minecraft:air
fill 282 60 -423 314 60 -423 minecraft:air
setblock 327 60 -423 minecraft:air
fill 282 60 -424 314 60 -424 minecraft:air
fill 326 60 -424 327 60 -424 minecraft:air
fill 282 60 -425 314 60 -425 minecraft:air
fill 325 60 -425 327 60 -425 minecraft:air
fill 282 60 -426 314 60 -426 minecraft:air
fill 324 60 -426 327 60 -426 minecraft:air
fill 282 60 -427 314 60 -427 minecraft:air
fill 323 60 -427 327 60 -427 minecraft:air
fill 282 60 -428 314 60 -428 minecraft:air
fill 322 60 -428 327 60 -428 minecraft:air
fill 282 60 -429 314 60 -429 minecraft:air
fill 322 60 -429 327 60 -429 minecraft:air
fill 282 60 -430 314 60 -430 minecraft:air
fill 321 60 -430 327 60 -430 minecraft:air
fill 282 60 -431 314 60 -431 minecraft:air
fill 321 60 -431 327 60 -431 minecraft:air
fill 282 60 -432 314 60 -432 minecraft:air
fill 320 60 -432 327 60 -432 minecraft:air
fill 282 60 -433 314 60 -433 minecraft:air
fill 322 60 -433 325 60 -433 minecraft:air
setblock 272 60 -434 minecraft:air
fill 282 60 -434 314 60 -434 minecraft:air
fill 272 60 -435 273 60 -435 minecraft:air
fill 282 60 -435 314 60 -435 minecraft:air
fill 272 60 -436 274 60 -436 minecraft:air
fill 282 60 -436 314 60 -436 minecraft:air
fill 271 60 -437 275 60 -437 minecraft:air
setblock 282 60 -437 minecraft:water[level=8]
fill 283 60 -437 314 60 -437 minecraft:air
setblock 271 60 -438 minecraft:air
setblock 272 60 -438 minecraft:water[level=4]
setblock 273 60 -438 minecraft:water[level=3]
setblock 274 60 -438 minecraft:water[level=2]
setblock 275 60 -438 minecraft:water[level=1]
setblock 276 60 -438 minecraft:water[level=8]
fill 279 60 -438 281 60 -438 minecraft:water[level=0]
fill 282 60 -438 283 60 -438 minecraft:water[level=8]
fill 284 60 -438 314 60 -438 minecraft:air
fill 270 60 -439 272 60 -439 minecraft:air
setblock 273 60 -439 minecraft:water[level=4]
fill 278 60 -439 281 60 -439 minecraft:water[level=0]
fill 282 60 -439 283 60 -439 minecraft:water[level=8]
setblock 284 60 -439 minecraft:water[level=1]
fill 285 60 -439 314 60 -439 minecraft:air
fill 280 60 -440 281 60 -440 minecraft:water[level=0]
fill 282 60 -440 284 60 -440 minecraft:water[level=8]
fill 285 60 -440 314 60 -440 minecraft:air
setblock 264 60 -441 minecraft:water[level=0]
fill 282 60 -441 284 60 -441 minecraft:water[level=8]
fill 285 60 -441 314 60 -441 minecraft:air
fill 264 60 -442 265 60 -442 minecraft:water[level=0]
fill 282 60 -442 284 60 -442 minecraft:water[level=8]
fill 285 60 -442 314 60 -442 minecraft:air
fill 264 60 -443 266 60 -443 minecraft:water[level=0]
fill 282 60 -443 283 60 -443 minecraft:water[level=8]
fill 284 60 -443 313 60 -443 minecraft:air
setblock 314 60 -443 minecraft:water[level=2]
fill 264 60 -444 267 60 -444 minecraft:water[level=0]
fill 282 60 -444 313 60 -444 minecraft:air
setblock 314 60 -444 minecraft:water[level=1]
fill 264 60 -445 267 60 -445 minecraft:water[level=0]
fill 282 60 -445 311 60 -445 minecraft:air
setblock 312 60 -445 minecraft:water[level=2]
setblock 313 60 -445 minecraft:water[level=1]
setblock 314 60 -445 minecraft:water[level=8]
fill 264 60 -446 267 60 -446 minecraft:water[level=0]
fill 282 60 -446 310 60 -446 minecraft:air
setblock 311 60 -446 minecraft:water[level=2]
setblock 312 60 -446 minecraft:water[level=1]
fill 313 60 -446 314 60 -446 minecraft:water[level=8]
fill 292 59 -383 293 59 -383 minecraft:water[level=0]
setblock 295 59 -385 minecraft:air
fill 294 59 -386 296 59 -386 minecraft:air
fill 293 59 -387 296 59 -387 minecraft:air
fill 294 59 -388 297 59 -388 minecraft:air
fill 294 59 -389 297 59 -389 minecraft:air
fill 295 59 -390 297 59 -390 minecraft:air
fill 295 59 -391 298 59 -391 minecraft:air
fill 296 59 -392 300 59 -392 minecraft:air
fill 296 59 -393 298 59 -393 minecraft:air
setblock 300 59 -393 minecraft:air
fill 297 59 -394 300 59 -394 minecraft:air
fill 326 59 -394 327 59 -394 minecraft:air
fill 297 59 -395 301 59 -395 minecraft:air
fill 325 59 -395 327 59 -395 minecraft:air
fill 298 59 -396 301 59 -396 minecraft:air
fill 324 59 -396 326 59 -396 minecraft:air
fill 298 59 -397 301 59 -397 minecraft:air
fill 323 59 -397 325 59 -397 minecraft:air
fill 299 59 -398 301 59 -398 minecraft:air
fill 320 59 -398 323 59 -398 minecraft:air
fill 299 59 -399 302 59 -399 minecraft:air
fill 319 59 -399 320 59 -399 minecraft:air
setblock 322 59 -399 minecraft:air
fill 300 59 -400 301 59 -400 minecraft:air
fill 317 59 -400 321 59 -400 minecraft:air
setblock 301 59 -401 minecraft:air
fill 316 59 -401 319 59 -401 minecraft:air
fill 299 59 -402 306 59 -402 minecraft:air
fill 315 59 -402 320 59 -402 minecraft:air
fill 299 59 -403 309 59 -403 minecraft:air
fill 314 59 -403 319 59 -403 minecraft:air
fill 296 59 -404 309 59 -404 minecraft:air
fill 314 59 -404 318 59 -404 minecraft:air
fill 290 59 -405 309 59 -405 minecraft:air
fill 313 59 -405 318 59 -405 minecraft:air
fill 286 59 -406 309 59 -406 minecraft:air
fill 313 59 -406 317 59 -406 minecraft:air
fill 287 59 -407 309 59 -407 minecraft:air
fill 313 59 -407 317 59 -407 minecraft:air
setblock 280 59 -408 minecraft:air
fill 287 59 -408 310 59 -408 minecraft:air
fill 312 59 -408 316 59 -408 minecraft:air
setblock 280 59 -409 minecraft:air
fill 289 59 -409 315 59 -409 minecraft:air
fill 291 59 -410 296 59 -410 minecraft:air
fill 299 59 -410 305 59 -410 minecraft:air
fill 311 59 -410 316 59 -410 minecraft:air
fill 291 59 -411 304 59 -411 minecraft:air
fill 291 59 -412 298 59 -412 minecraft:air
fill 300 59 -412 303 59 -412 minecraft:air
fill 291 59 -413 299 59 -413 minecraft:air
fill 301 59 -413 303 59 -413 minecraft:air
fill 289 59 -414 301 59 -414 minecraft:air
setblock 288 59 -415 minecraft:air
fill 292 59 -415 295 59 -415 minecraft:air
fill 297 59 -415 300 59 -415 minecraft:air
fill 282 59 -416 309 59 -416 minecraft:air
fill 312 59 -416 314 59 -416 minecraft:air
fill 282 59 -417 309 59 -417 minecraft:air
fill 311 59 -417 314 59 -417 minecraft:air
fill 282 59 -418 300 59 -418 minecraft:air
fill 302 59 -418 314 59 -418 minecraft:air
fill 282 59 -419 314 59 -419 minecraft:air
fill 282 59 -420 309 59 -420 minecraft:air
fill 311 59 -420 314 59 -420 minecraft:air
fill 282 59 -421 314 59 -421 minecraft:air
fill 282 59 -422 302 59 -422 minecraft:air
fill 304 59 -422 314 59 -422 minecraft:air
fill 282 59 -423 314 59 -423 minecraft:air
setblock 327 59 -423 minecraft:air
fill 282 59 -424 314 59 -424 minecraft:air
fill 326 59 -424 327 59 -424 minecraft:air
fill 282 59 -425 314 59 -425 minecraft:air
fill 325 59 -425 327 59 -425 minecraft:air
fill 282 59 -426 314 59 -426 minecraft:air
fill 324 59 -426 327 59 -426 minecraft:air
fill 282 59 -427 314 59 -427 minecraft:air
fill 323 59 -427 327 59 -427 minecraft:air
fill 282 59 -428 314 59 -428 minecraft:air
fill 322 59 -428 327 59 -428 minecraft:air
fill 282 59 -429 314 59 -429 minecraft:air
fill 322 59 -429 327 59 -429 minecraft:air
fill 282 59 -430 314 59 -430 minecraft:air
fill 321 59 -430 327 59 -430 minecraft:air
fill 282 59 -431 314 59 -431 minecraft:air
fill 321 59 -431 327 59 -431 minecraft:air
fill 282 59 -432 314 59 -432 minecraft:air
fill 320 59 -432 327 59 -432 minecraft:air
fill 282 59 -433 314 59 -433 minecraft:air
fill 321 59 -433 326 59 -433 minecraft:air
fill 282 59 -434 314 59 -434 minecraft:air
setblock 324 59 -434 minecraft:air
fill 282 59 -435 314 59 -435 minecraft:air
fill 282 59 -436 287 59 -436 minecraft:air
setblock 288 59 -436 minecraft:water[level=7]
fill 289 59 -436 313 59 -436 minecraft:air
setblock 314 59 -436 minecraft:water[level=7]
setblock 271 59 -437 minecraft:water[level=2]
fill 280 59 -437 281 59 -437 minecraft:water[level=0]
setblock 282 59 -437 minecraft:water[level=8]
fill 283 59 -437 285 59 -437 minecraft:air
setblock 286 59 -437 minecraft:water[level=4]
setblock 287 59 -437 minecraft:water[level=5]
setblock 288 59 -437 minecraft:water[level=6]
setblock 289 59 -437 minecraft:water[level=7]
fill 290 59 -437 312 59 -437 minecraft:air
setblock 313 59 -437 minecraft:water[level=7]
setblock 314 59 -437 minecraft:water[level=6]
setblock 271 59 -438 minecraft:water[level=1]
setblock 272 59 -438 minecraft:water[level=8]
fill 278 59 -438 281 59 -438 minecraft:water[level=0]
fill 282 59 -438 283 59 -438 minecraft:water[level=8]
setblock 284 59 -438 minecraft:water[level=1]
setblock 285 59 -438 minecraft:water[level=2]
setblock 286 59 -438 minecraft:water[level=3]
setblock 287 59 -438 minecraft:water[level=4]
setblock 288 59 -438 minecraft:water[level=5]
setblock 289 59 -438 minecraft:water[level=6]
setblock 290 59 -438 minecraft:water[level=7]
fill 291 59 -438 311 59 -438 minecraft:air
setblock 312 59 -438 minecraft:water[level=7]
setblock 313 59 -438 minecraft:water[level=6]
setblock 314 59 -438 minecraft:water[level=5]
setblock 271 59 -439 minecraft:water[level=2]
setblock 272 59 -439 minecraft:water[level=1]
setblock 273 59 -439 minecraft:water[level=8]
setblock 281 59 -439 minecraft:water[level=0]
fill 282 59 -439 284 59 -439 minecraft:water[level=8]
setblock 285 59 -439 minecraft:water[level=1]
setblock 286 59 -439 minecraft:water[level=2]
setblock 287 59 -439 minecraft:water[level=3]
setblock 288 59 -439 minecraft:water[level=4]
setblock 289 59 -439 minecraft:water[level=5]
setblock 290 59 -439 minecraft:water[level=6]
setblock 291 59 -439 minecraft:water[level=7]
fill 292 59 -439 310 59 -439 minecraft:air
setblock 311 59 -439 minecraft:water[level=7]
setblock 312 59 -439 minecraft:water[level=6]
setblock 313 59 -439 minecraft:water[level=5]
setblock 314 59 -439 minecraft:water[level=4]
fill 282 59 -440 284 59 -440 minecraft:water[level=8]
setblock 285 59 -440 minecraft:water[level=1]
setblock 286 59 -440 minecraft:water[level=2]
setblock 287 59 -440 minecraft:water[level=3]
setblock 288 59 -440 minecraft:water[level=4]
setblock 289 59 -440 minecraft:water[level=5]
setblock 290 59 -440 minecraft:water[level=6]
setblock 291 59 -440 minecraft:water[level=7]
fill 292 59 -440 309 59 -440 minecraft:air
setblock 310 59 -440 minecraft:water[level=7]
setblock 311 59 -440 minecraft:water[level=6]
setblock 312 59 -440 minecraft:water[level=5]
setblock 313 59 -440 minecraft:water[level=4]
setblock 314 59 -440 minecraft:water[level=3]
fill 282 59 -441 284 59 -441 minecraft:water[level=8]
setblock 285 59 -441 minecraft:water[level=1]
setblock 286 59 -441 minecraft:air
setblock 287 59 -441 minecraft:water[level=4]
setblock 288 59 -441 minecraft:water[level=5]
setblock 289 59 -441 minecraft:water[level=6]
setblock 290 59 -441 minecraft:water[level=7]
fill 291 59 -441 308 59 -441 minecraft:air
setblock 309 59 -441 minecraft:water[level=7]
setblock 310 59 -441 minecraft:water[level=6]
setblock 311 59 -441 minecraft:water[level=5]
setblock 312 59 -441 minecraft:water[level=4]
setblock 313 59 -441 minecraft:water[level=3]
setblock 314 59 -441 minecraft:water[level=2]
setblock 264 59 -442 minecraft:water[level=0]
fill 282 59 -442 284 59 -442 minecraft:water[level=8]
setblock 285 59 -442 minecraft:water[level=1]
fill 286 59 -442 287 59 -442 minecraft:air
setblock 288 59 -442 minecraft:water[level=6]
setblock 289 59 -442 minecraft:water[level=7]
fill 290 59 -442 307 59 -442 minecraft:air
setblock 308 59 -442 minecraft:water[level=7]
setblock 309 59 -442 minecraft:water[level=6]
setblock 312 59 -442 minecraft:water[level=3]
setblock 313 59 -442 minecraft:water[level=2]
setblock 314 59 -442 minecraft:water[level=1]
fill 264 59 -443 265 59 -443 minecraft:water[level=0]
fill 282 59 -443 283 59 -443 minecraft:water[level=8]
fill 284 59 -443 306 59 -443 minecraft:air
setblock 307 59 -443 minecraft:water[level=7]
setblock 308 59 -443 minecraft:water[level=6]
setblock 309 59 -443 minecraft:water[level=5]
setblock 310 59 -443 minecraft:water[level=4]
setblock 311 59 -443 minecraft:water[level=3]
setblock 314 59 -443 minecraft:water[level=8]
fill 264 59 -444 266 59 -444 minecraft:water[level=0]
fill 282 59 -444 305 59 -444 minecraft:air
setblock 306 59 -444 minecraft:water[level=7]
setblock 307 59 -444 minecraft:water[level=6]
setblock 308 59 -444 minecraft:water[level=5]
setblock 309 59 -444 minecraft:water[level=4]
setblock 310 59 -444 minecraft:water[level=3]
setblock 311 59 -444 minecraft:water[level=2]
setblock 312 59 -444 minecraft:water[level=1]
fill 264 59 -445 266 59 -445 minecraft:water[level=0]
fill 282 59 -445 304 59 -445 minecraft:air
setblock 305 59 -445 minecraft:water[level=7]
setblock 306 59 -445 minecraft:water[level=6]
setblock 307 59 -445 minecraft:water[level=5]
setblock 308 59 -445 minecraft:water[level=4]
setblock 309 59 -445 minecraft:water[level=3]
setblock 310 59 -445 minecraft:water[level=2]
setblock 311 59 -445 minecraft:water[level=1]
setblock 312 59 -445 minecraft:water[level=8]
setblock 314 59 -445 minecraft:water[level=8]
fill 264 59 -446 267 59 -446 minecraft:water[level=0]
fill 282 59 -446 303 59 -446 minecraft:air
setblock 304 59 -446 minecraft:water[level=7]
setblock 305 59 -446 minecraft:water[level=6]
setblock 306 59 -446 minecraft:water[level=5]
setblock 307 59 -446 minecraft:water[level=4]
setblock 308 59 -446 minecraft:water[level=3]
setblock 309 59 -446 minecraft:water[level=2]
setblock 310 59 -446 minecraft:water[level=1]
fill 311 59 -446 314 59 -446 minecraft:water[level=8]
fill 291 58 -383 293 58 -383 minecraft:water[level=0]
setblock 296 58 -386 minecraft:air
fill 293 58 -387 296 58 -387 minecraft:air
fill 293 58 -388 295 58 -388 minecraft:air
fill 293 58 -389 295 58 -389 minecraft:air
fill 294 58 -390 297 58 -390 minecraft:air
fill 294 58 -391 298 58 -391 minecraft:air
fill 295 58 -392 298 58 -392 minecraft:air
fill 295 58 -393 298 58 -393 minecraft:air
fill 296 58 -394 300 58 -394 minecraft:air
fill 297 58 -395 301 58 -395 minecraft:air
setblock 327 58 -395 minecraft:air
fill 297 58 -396 300 58 -396 minecraft:air
setblock 327 58 -396 minecraft:air
fill 298 58 -397 300 58 -397 minecraft:air
fill 298 58 -398 300 58 -398 minecraft:air
fill 323 58 -398 324 58 -398 minecraft:air
fill 299 58 -399 300 58 -399 minecraft:air
setblock 322 58 -399 minecraft:air
fill 299 58 -400 300 58 -400 minecraft:air
fill 319 58 -400 321 58 -400 minecraft:air
setblock 299 58 -401 minecraft:air
fill 317 58 -401 319 58 -401 minecraft:air
setblock 321 58 -401 minecraft:air
setblock 299 58 -402 minecraft:air
fill 302 58 -402 305 58 -402 minecraft:air
fill 316 58 -402 320 58 -402 minecraft:air
fill 299 58 -403 306 58 -403 minecraft:air
fill 315 58 -403 318 58 -403 minecraft:air
fill 298 58 -404 306 58 -404 minecraft:air
fill 315 58 -404 319 58 -404 minecraft:air
fill 293 58 -405 306 58 -405 minecraft:air
fill 313 58 -405 318 58 -405 minecraft:air
fill 287 58 -406 307 58 -406 minecraft:air
fill 314 58 -406 318 58 -406 minecraft:air
fill 287 58 -407 309 58 -407 minecraft:air
fill 313 58 -407 317 58 -407 minecraft:air
fill 288 58 -408 310 58 -408 minecraft:air
fill 313 58 -408 317 58 -408 minecraft:air
fill 289 58 -409 317 58 -409 minecraft:air
fill 291 58 -410 296 58 -410 minecraft:air
fill 299 58 -410 306 58 -410 minecraft:air
fill 311 58 -410 312 58 -410 minecraft:air
fill 314 58 -410 316 58 -410 minecraft:air
fill 291 58 -411 295 58 -411 minecraft:air
fill 297 58 -411 305 58 -411 minecraft:air
fill 291 58 -412 298 58 -412 minecraft:air
fill 303 58 -412 304 58 -412 minecraft:air
fill 291 58 -413 296 58 -413 minecraft:air
fill 298 58 -413 299 58 -413 minecraft:air
setblock 302 58 -413 minecraft:air
fill 289 58 -414 301 58 -414 minecraft:air
fill 294 58 -415 300 58 -415 minecraft:air
fill 294 58 -416 299 58 -416 minecraft:air
fill 286 58 -417 287 58 -417 minecraft:water[level=0]
fill 285 58 -418 288 58 -418 minecraft:water[level=0]
fill 284 58 -419 290 58 -419 minecraft:water[level=0]
fill 283 58 -420 290 58 -420 minecraft:water[level=0]
setblock 273 58 -421 minecraft:water[level=0]
fill 282 58 -421 289 58 -421 minecraft:water[level=0]
fill 272 58 -422 288 58 -422 minecraft:water[level=0]
fill 272 58 -423 287 58 -423 minecraft:water[level=0]
setblock 327 58 -423 minecraft:air
fill 274 58 -424 286 58 -424 minecraft:water[level=0]
fill 326 58 -424 327 58 -424 minecraft:air
fill 277 58 -425 284 58 -425 minecraft:water[level=0]
fill 325 58 -425 327 58 -425 minecraft:air
fill 324 58 -426 327 58 -426 minecraft:air
fill 295 58 -427 296 58 -427 minecraft:water[level=0]
fill 323 58 -427 327 58 -427 minecraft:air
fill 294 58 -428 297 58 -428 minecraft:water[level=0]
fill 322 58 -428 327 58 -428 minecraft:air
fill 294 58 -429 298 58 -429 minecraft:water[level=0]
fill 322 58 -429 327 58 -429 minecraft:air
fill 295 58 -430 298 58 -430 minecraft:water[level=0]
fill 322 58 -430 327 58 -430 minecraft:air
fill 295 58 -431 298 58 -431 minecraft:water[level=0]
fill 321 58 -431 327 58 -431 minecraft:air
fill 296 58 -432 298 58 -432 minecraft:water[level=0]
fill 320 58 -432 327 58 -432 minecraft:air
fill 297 58 -433 298 58 -433 minecraft:water[level=0]
fill 321 58 -433 324 58 -433 minecraft:air
setblock 325 58 -433 torchmaster:invisible_light
fill 326 58 -433 327 58 -433 minecraft:air
fill 298 58 -434 300 58 -434 minecraft:water[level=0]
fill 323 58 -434 325 58 -434 minecraft:air
fill 283 58 -435 284 58 -435 minecraft:water[level=0]
fill 299 58 -435 300 58 -435 minecraft:water[level=0]
setblock 301 58 -435 minecraft:bubble_column[drag=true]
fill 277 58 -436 288 58 -436 minecraft:water[level=0]
fill 290 58 -436 293 58 -436 minecraft:water[level=0]
setblock 299 58 -436 minecraft:bubble_column[drag=true]
fill 300 58 -436 301 58 -436 minecraft:water[level=0]
fill 279 58 -437 292 58 -437 minecraft:water[level=0]
fill 300 58 -437 301 58 -437 minecraft:water[level=0]
fill 282 58 -438 285 58 -438 minecraft:water[level=0]
fill 287 58 -438 290 58 -438 minecraft:water[level=0]
fill 300 58 -438 301 58 -438 minecraft:water[level=0]
setblock 285 58 -439 minecraft:water[level=0]
fill 287 58 -439 289 58 -439 minecraft:water[level=0]
fill 299 58 -439 301 58 -439 minecraft:water[level=0]
fill 299 58 -440 301 58 -440 minecraft:water[level=0]
fill 299 58 -441 301 58 -441 minecraft:water[level=0]
setblock 264 58 -442 minecraft:water[level=0]
fill 299 58 -442 301 58 -442 minecraft:water[level=0]
fill 264 58 -443 265 58 -443 minecraft:water[level=0]
fill 299 58 -443 301 58 -443 minecraft:water[level=0]
fill 264 58 -444 266 58 -444 minecraft:water[level=0]
fill 298 58 -444 302 58 -444 minecraft:water[level=0]
fill 264 58 -445 266 58 -445 minecraft:water[level=0]
fill 298 58 -445 302 58 -445 minecraft:water[level=0]
fill 264 58 -446 266 58 -446 minecraft:water[level=0]
fill 298 58 -446 301 58 -446 minecraft:water[level=0]
fill 290 57 -383 292 57 -383 minecraft:water[level=0]
fill 291 57 -384 293 57 -384 minecraft:water[level=0]
fill 291 57 -385 292 57 -385 minecraft:water[level=0]
fill 292 57 -387 294 57 -387 minecraft:air
fill 292 57 -388 295 57 -388 minecraft:air
fill 293 57 -389 295 57 -389 minecraft:air
fill 293 57 -390 297 57 -390 minecraft:air
fill 294 57 -391 296 57 -391 minecraft:air
fill 293 57 -392 298 57 -392 minecraft:air
fill 295 57 -393 298 57 -393 minecraft:air
fill 295 57 -394 299 57 -394 minecraft:air
fill 296 57 -395 300 57 -395 minecraft:air
fill 297 57 -396 300 57 -396 minecraft:air
fill 297 57 -397 300 57 -397 minecraft:air
fill 298 57 -398 300 57 -398 minecraft:air
setblock 298 57 -399 minecraft:air
setblock 299 57 -400 minecraft:air
setblock 319 57 -401 minecraft:air
setblock 321 57 -401 minecraft:air
fill 302 57 -402 303 57 -402 minecraft:air
fill 319 57 -402 320 57 -402 minecraft:air
fill 299 57 -403 303 57 -403 minecraft:air
fill 316 57 -403 320 57 -403 minecraft:air
fill 298 57 -404 304 57 -404 minecraft:air
fill 315 57 -404 319 57 -404 minecraft:air
fill 294 57 -405 304 57 -405 minecraft:air
fill 315 57 -405 319 57 -405 minecraft:air
fill 287 57 -406 308 57 -406 minecraft:air
fill 315 57 -406 318 57 -406 minecraft:air
fill 288 57 -407 309 57 -407 minecraft:air
fill 314 57 -407 318 57 -407 minecraft:air
fill 288 57 -408 303 57 -408 minecraft:air
fill 305 57 -408 310 57 -408 minecraft:air
fill 314 57 -408 318 57 -408 minecraft:air
fill 289 57 -409 297 57 -409 minecraft:air
fill 299 57 -409 303 57 -409 minecraft:air
fill 305 57 -409 312 57 -409 minecraft:air
fill 314 57 -409 317 57 -409 minecraft:air
fill 300 57 -410 307 57 -410 minecraft:air
fill 311 57 -410 316 57 -410 minecraft:air
fill 299 57 -411 305 57 -411 minecraft:air
setblock 303 57 -412 minecraft:air
setblock 302 57 -413 minecraft:air
fill 290 57 -415 291 57 -415 minecraft:air
fill 286 57 -417 288 57 -417 minecraft:water[level=0]
fill 285 57 -418 290 57 -418 minecraft:water[level=0]
fill 284 57 -419 291 57 -419 minecraft:water[level=0]
fill 269 57 -420 274 57 -420 minecraft:water[level=0]
fill 283 57 -420 288 57 -420 minecraft:water[level=0]
setblock 290 57 -420 minecraft:water[level=0]
fill 269 57 -421 288 57 -421 minecraft:water[level=0]
fill 269 57 -422 288 57 -422 minecraft:water[level=0]
fill 270 57 -423 287 57 -423 minecraft:water[level=0]
fill 271 57 -424 286 57 -424 minecraft:water[level=0]
fill 326 57 -424 327 57 -424 minecraft:air
fill 273 57 -425 285 57 -425 minecraft:water[level=0]
fill 326 57 -425 327 57 -425 minecraft:air
fill 277 57 -426 281 57 -426 minecraft:water[level=0]
fill 325 57 -426 327 57 -426 minecraft:air
fill 324 57 -427 327 57 -427 minecraft:air
fill 295 57 -428 296 57 -428 minecraft:water[level=0]
fill 323 57 -428 327 57 -428 minecraft:air
fill 295 57 -429 297 57 -429 minecraft:water[level=0]
fill 322 57 -429 327 57 -429 minecraft:air
fill 272 57 -430 273 57 -430 minecraft:water[level=0]
fill 295 57 -430 298 57 -430 minecraft:water[level=0]
setblock 322 57 -430 torchmaster:invisible_light
fill 323 57 -430 327 57 -430 minecraft:air
fill 271 57 -431 275 57 -431 minecraft:water[level=0]
fill 296 57 -431 298 57 -431 minecraft:water[level=0]
fill 321 57 -431 327 57 -431 minecraft:air
fill 272 57 -432 277 57 -432 minecraft:water[level=0]
fill 296 57 -432 299 57 -432 minecraft:water[level=0]
fill 320 57 -432 327 57 -432 minecraft:air
fill 274 57 -433 279 57 -433 minecraft:water[level=0]
fill 282 57 -433 283 57 -433 minecraft:water[level=0]
fill 297 57 -433 300 57 -433 minecraft:water[level=0]
fill 321 57 -433 327 57 -433 minecraft:air
fill 276 57 -434 295 57 -434 minecraft:water[level=0]
fill 298 57 -434 301 57 -434 minecraft:water[level=0]
fill 321 57 -434 326 57 -434 minecraft:air
fill 278 57 -435 294 57 -435 minecraft:water[level=0]
fill 299 57 -435 300 57 -435 minecraft:water[level=0]
setblock 301 57 -435 minecraft:bubble_column[drag=true]
fill 323 57 -435 324 57 -435 minecraft:air
fill 280 57 -436 293 57 -436 minecraft:water[level=0]
setblock 299 57 -436 minecraft:bubble_column[drag=true]
fill 300 57 -436 301 57 -436 minecraft:water[level=0]
fill 283 57 -437 291 57 -437 minecraft:water[level=0]
fill 299 57 -437 302 57 -437 minecraft:water[level=0]
fill 288 57 -438 290 57 -438 minecraft:water[level=0]
fill 299 57 -438 302 57 -438 minecraft:water[level=0]
fill 299 57 -439 302 57 -439 minecraft:water[level=0]
fill 299 57 -440 302 57 -440 minecraft:water[level=0]
fill 299 57 -441 301 57 -441 minecraft:water[level=0]
fill 298 57 -442 301 57 -442 minecraft:water[level=0]
setblock 264 57 -443 minecraft:water[level=0]
fill 298 57 -443 304 57 -443 minecraft:water[level=0]
fill 264 57 -444 265 57 -444 minecraft:water[level=0]
fill 298 57 -444 304 57 -444 minecraft:water[level=0]
fill 264 57 -445 265 57 -445 minecraft:water[level=0]
fill 298 57 -445 303 57 -445 minecraft:water[level=0]
fill 264 57 -446 266 57 -446 minecraft:water[level=0]
fill 297 57 -446 303 57 -446 minecraft:water[level=0]
fill 290 56 -383 292 56 -383 minecraft:water[level=0]
fill 290 56 -384 292 56 -384 minecraft:water[level=0]
fill 291 56 -385 292 56 -385 minecraft:water[level=0]
setblock 291 56 -386 minecraft:water[level=0]
setblock 294 56 -388 minecraft:air
fill 292 56 -389 294 56 -389 minecraft:air
fill 293 56 -390 295 56 -390 minecraft:air
fill 293 56 -391 296 56 -391 minecraft:air
fill 294 56 -392 297 56 -392 minecraft:air
fill 294 56 -393 298 56 -393 minecraft:air
fill 295 56 -394 298 56 -394 minecraft:air
fill 295 56 -395 300 56 -395 minecraft:air
fill 296 56 -396 300 56 -396 minecraft:air
fill 296 56 -397 298 56 -397 minecraft:air
fill 297 56 -398 300 56 -398 minecraft:air
setblock 298 56 -399 minecraft:air
setblock 298 56 -400 minecraft:air
fill 299 56 -403 302 56 -403 minecraft:air
fill 298 56 -404 302 56 -404 minecraft:air
fill 318 56 -404 320 56 -404 minecraft:air
fill 295 56 -405 301 56 -405 minecraft:air
setblock 307 56 -405 minecraft:air
fill 316 56 -405 319 56 -405 minecraft:air
fill 291 56 -406 300 56 -406 minecraft:air
fill 305 56 -406 309 56 -406 minecraft:air
fill 315 56 -406 319 56 -406 minecraft:air
setblock 288 56 -407 minecraft:air
fill 290 56 -407 299 56 -407 minecraft:air
fill 305 56 -407 310 56 -407 minecraft:air
fill 315 56 -407 319 56 -407 minecraft:air
fill 291 56 -408 297 56 -408 minecraft:air
fill 306 56 -408 310 56 -408 minecraft:air
fill 315 56 -408 318 56 -408 minecraft:air
fill 290 56 -409 296 56 -409 minecraft:air
fill 305 56 -409 312 56 -409 minecraft:air
fill 314 56 -409 317 56 -409 minecraft:air
setblock 303 56 -410 minecraft:air
fill 305 56 -410 309 56 -410 minecraft:air
fill 311 56 -410 314 56 -410 minecraft:air
fill 268 56 -418 270 56 -418 minecraft:water[level=0]
fill 285 56 -418 286 56 -418 minecraft:water[level=0]
setblock 267 56 -419 minecraft:water[level=0]
fill 268 56 -419 269 56 -419 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=true,west=false]
fill 270 56 -419 272 56 -419 minecraft:water[level=0]
fill 284 56 -419 287 56 -419 minecraft:water[level=0]
fill 267 56 -420 275 56 -420 minecraft:water[level=0]
fill 283 56 -420 288 56 -420 minecraft:water[level=0]
fill 267 56 -421 288 56 -421 minecraft:water[level=0]
fill 268 56 -422 288 56 -422 minecraft:water[level=0]
fill 269 56 -423 287 56 -423 minecraft:water[level=0]
fill 270 56 -424 286 56 -424 minecraft:water[level=0]
setblock 327 56 -424 minecraft:air
fill 272 56 -425 285 56 -425 minecraft:water[level=0]
setblock 327 56 -425 minecraft:air
fill 275 56 -426 281 56 -426 minecraft:water[level=0]
setblock 326 56 -426 minecraft:air
setblock 327 56 -426 torchmaster:invisible_light
fill 268 56 -427 271 56 -427 minecraft:water[level=0]
fill 325 56 -427 327 56 -427 minecraft:air
fill 268 56 -428 274 56 -428 minecraft:water[level=0]
fill 324 56 -428 327 56 -428 minecraft:air
fill 267 56 -429 277 56 -429 minecraft:water[level=0]
fill 323 56 -429 327 56 -429 minecraft:air
fill 270 56 -430 280 56 -430 minecraft:water[level=0]
fill 297 56 -430 298 56 -430 minecraft:water[level=0]
fill 322 56 -430 327 56 -430 minecraft:air
fill 273 56 -431 283 56 -431 minecraft:water[level=0]
fill 296 56 -431 299 56 -431 minecraft:water[level=0]
fill 322 56 -431 327 56 -431 minecraft:air
fill 275 56 -432 299 56 -432 minecraft:water[level=0]
fill 321 56 -432 327 56 -432 minecraft:air
fill 277 56 -433 300 56 -433 minecraft:water[level=0]
fill 321 56 -433 327 56 -433 minecraft:air
fill 279 56 -434 295 56 -434 minecraft:water[level=0]
fill 298 56 -434 301 56 -434 minecraft:water[level=0]
fill 320 56 -434 327 56 -434 minecraft:air
fill 282 56 -435 293 56 -435 minecraft:water[level=0]
fill 299 56 -435 300 56 -435 minecraft:water[level=0]
setblock 301 56 -435 minecraft:bubble_column[drag=true]
fill 320 56 -435 321 56 -435 minecraft:air
setblock 322 56 -435 torchmaster:invisible_light
fill 323 56 -435 326 56 -435 minecraft:air
fill 285 56 -436 292 56 -436 minecraft:water[level=0]
setblock 299 56 -436 minecraft:bubble_column[drag=true]
fill 300 56 -436 301 56 -436 minecraft:water[level=0]
fill 320 56 -436 325 56 -436 minecraft:air
fill 299 56 -437 302 56 -437 minecraft:water[level=0]
fill 322 56 -437 324 56 -437 minecraft:air
fill 299 56 -438 302 56 -438 minecraft:water[level=0]
fill 299 56 -439 302 56 -439 minecraft:water[level=0]
fill 299 56 -440 302 56 -440 minecraft:water[level=0]
fill 299 56 -441 301 56 -441 minecraft:water[level=0]
setblock 304 56 -441 minecraft:water[level=0]
fill 299 56 -442 305 56 -442 minecraft:water[level=0]
setblock 264 56 -443 minecraft:water[level=0]
fill 298 56 -443 305 56 -443 minecraft:water[level=0]
fill 264 56 -444 265 56 -444 minecraft:water[level=0]
fill 298 56 -444 304 56 -444 minecraft:water[level=0]
fill 264 56 -445 265 56 -445 minecraft:water[level=0]
fill 298 56 -445 304 56 -445 minecraft:water[level=0]
fill 264 56 -446 265 56 -446 minecraft:water[level=0]
fill 298 56 -446 303 56 -446 minecraft:water[level=0]
fill 289 55 -383 291 55 -383 minecraft:water[level=0]
fill 290 55 -384 291 55 -384 minecraft:water[level=0]
fill 290 55 -385 292 55 -385 minecraft:water[level=0]
fill 290 55 -386 292 55 -386 minecraft:water[level=0]
setblock 294 55 -388 minecraft:air
fill 292 55 -389 295 55 -389 minecraft:air
fill 292 55 -390 294 55 -390 minecraft:air
fill 293 55 -391 296 55 -391 minecraft:air
fill 293 55 -392 297 55 -392 minecraft:air
fill 294 55 -393 297 55 -393 minecraft:air
fill 294 55 -394 298 55 -394 minecraft:air
fill 295 55 -395 298 55 -395 minecraft:air
fill 296 55 -396 299 55 -396 minecraft:air
fill 296 55 -397 298 55 -397 minecraft:air
setblock 297 55 -398 minecraft:air
fill 296 55 -405 297 55 -405 minecraft:air
fill 293 55 -406 297 55 -406 minecraft:air
fill 306 55 -406 310 55 -406 minecraft:air
fill 292 55 -407 296 55 -407 minecraft:air
fill 305 55 -407 311 55 -407 minecraft:air
setblock 292 55 -408 minecraft:air
fill 307 55 -408 311 55 -408 minecraft:air
setblock 316 55 -408 minecraft:air
fill 305 55 -409 307 55 -409 minecraft:air
fill 309 55 -409 312 55 -409 minecraft:air
fill 306 55 -410 314 55 -410 minecraft:air
setblock 284 55 -415 minecraft:water[level=0]
fill 267 55 -417 269 55 -417 minecraft:water[level=0]
fill 266 55 -418 271 55 -418 minecraft:water[level=0]
fill 265 55 -419 272 55 -419 minecraft:water[level=0]
fill 265 55 -420 274 55 -420 minecraft:water[level=0]
fill 265 55 -421 281 55 -421 minecraft:water[level=0]
fill 268 55 -422 282 55 -422 minecraft:water[level=0]
fill 269 55 -423 283 55 -423 minecraft:water[level=0]
fill 271 55 -424 283 55 -424 minecraft:water[level=0]
fill 266 55 -425 267 55 -425 minecraft:water[level=0]
fill 273 55 -425 282 55 -425 minecraft:water[level=0]
setblock 327 55 -425 minecraft:air
fill 265 55 -426 273 55 -426 minecraft:water[level=0]
fill 326 55 -426 327 55 -426 minecraft:air
fill 265 55 -427 277 55 -427 minecraft:water[level=0]
fill 325 55 -427 327 55 -427 minecraft:air
fill 267 55 -428 280 55 -428 minecraft:water[level=0]
fill 324 55 -428 327 55 -428 minecraft:air
fill 270 55 -429 287 55 -429 minecraft:water[level=0]
fill 289 55 -429 301 55 -429 minecraft:water[level=0]
fill 323 55 -429 327 55 -429 minecraft:air
fill 273 55 -430 300 55 -430 minecraft:water[level=0]
fill 323 55 -430 327 55 -430 minecraft:air
fill 276 55 -431 299 55 -431 minecraft:water[level=0]
fill 322 55 -431 327 55 -431 minecraft:air
fill 278 55 -432 298 55 -432 minecraft:water[level=0]
fill 321 55 -432 327 55 -432 minecraft:air
fill 280 55 -433 296 55 -433 minecraft:water[level=0]
fill 321 55 -433 327 55 -433 minecraft:air
fill 284 55 -434 288 55 -434 minecraft:water[level=0]
fill 291 55 -434 295 55 -434 minecraft:water[level=0]
setblock 300 55 -434 minecraft:water[level=0]
fill 321 55 -434 327 55 -434 minecraft:air
fill 299 55 -435 300 55 -435 minecraft:water[level=0]
setblock 301 55 -435 minecraft:bubble_column[drag=true]
fill 320 55 -435 326 55 -435 minecraft:air
setblock 327 55 -435 torchmaster:invisible_light
setblock 299 55 -436 minecraft:bubble_column[drag=true]
fill 300 55 -436 301 55 -436 minecraft:water[level=0]
fill 320 55 -436 326 55 -436 minecraft:air
fill 300 55 -437 301 55 -437 minecraft:water[level=0]
fill 321 55 -437 325 55 -437 minecraft:air
fill 300 55 -438 301 55 -438 minecraft:water[level=0]
setblock 324 55 -438 minecraft:air
fill 300 55 -439 301 55 -439 minecraft:water[level=0]
fill 300 55 -440 301 55 -440 minecraft:water[level=0]
fill 304 55 -440 305 55 -440 minecraft:water[level=0]
fill 303 55 -441 305 55 -441 minecraft:water[level=0]
fill 302 55 -442 305 55 -442 minecraft:water[level=0]
fill 301 55 -443 305 55 -443 minecraft:water[level=0]
setblock 264 55 -444 minecraft:water[level=0]
fill 299 55 -444 305 55 -444 minecraft:water[level=0]
setblock 264 55 -445 minecraft:water[level=0]
fill 299 55 -445 304 55 -445 minecraft:water[level=0]
fill 264 55 -446 265 55 -446 minecraft:water[level=0]
fill 299 55 -446 303 55 -446 minecraft:water[level=0]
fill 289 54 -383 290 54 -383 minecraft:water[level=0]
fill 289 54 -384 291 54 -384 minecraft:water[level=0]
fill 289 54 -385 291 54 -385 minecraft:water[level=0]
fill 290 54 -386 292 54 -386 minecraft:water[level=0]
fill 291 54 -388 293 54 -388 minecraft:air
fill 291 54 -389 294 54 -389 minecraft:air
fill 292 54 -390 294 54 -390 minecraft:air
fill 292 54 -391 295 54 -391 minecraft:air
fill 293 54 -392 296 54 -392 minecraft:air
fill 293 54 -393 296 54 -393 minecraft:air
fill 294 54 -394 297 54 -394 minecraft:air
fill 295 54 -395 297 54 -395 minecraft:air
fill 295 54 -396 298 54 -396 minecraft:air
fill 296 54 -397 297 54 -397 minecraft:air
fill 308 54 -406 310 54 -406 minecraft:air
fill 306 54 -407 311 54 -407 minecraft:air
fill 310 54 -408 312 54 -408 minecraft:air
fill 309 54 -409 312 54 -409 minecraft:air
fill 307 54 -410 314 54 -410 minecraft:air
fill 309 54 -411 312 54 -411 minecraft:air
fill 278 54 -413 284 54 -413 minecraft:water[level=0]
fill 279 54 -414 285 54 -414 minecraft:water[level=0]
fill 281 54 -415 285 54 -415 minecraft:water[level=0]
fill 282 54 -416 285 54 -416 minecraft:water[level=0]
fill 266 54 -417 269 54 -417 minecraft:water[level=0]
fill 283 54 -417 286 54 -417 minecraft:water[level=0]
fill 265 54 -418 270 54 -418 minecraft:water[level=0]
fill 284 54 -418 287 54 -418 minecraft:water[level=0]
fill 264 54 -419 271 54 -419 minecraft:water[level=0]
fill 286 54 -419 287 54 -419 minecraft:water[level=0]
fill 264 54 -420 272 54 -420 minecraft:water[level=0]
fill 264 54 -421 272 54 -421 minecraft:water[level=0]
fill 264 54 -422 272 54 -422 minecraft:water[level=0]
setblock 264 54 -423 minecraft:water[level=0]
fill 270 54 -423 271 54 -423 minecraft:water[level=0]
fill 264 54 -424 268 54 -424 minecraft:water[level=0]
fill 302 54 -424 303 54 -424 minecraft:water[level=0]
fill 264 54 -425 271 54 -425 minecraft:water[level=0]
fill 273 54 -425 279 54 -425 minecraft:water[level=0]
fill 285 54 -425 290 54 -425 minecraft:water[level=0]
fill 299 54 -425 303 54 -425 minecraft:water[level=0]
setblock 305 54 -425 minecraft:air
setblock 327 54 -425 minecraft:air
fill 264 54 -426 270 54 -426 minecraft:water[level=0]
fill 274 54 -426 302 54 -426 minecraft:water[level=0]
setblock 305 54 -426 minecraft:air
fill 326 54 -426 327 54 -426 minecraft:air
fill 267 54 -427 269 54 -427 minecraft:water[level=0]
fill 275 54 -427 302 54 -427 minecraft:water[level=0]
fill 305 54 -427 306 54 -427 minecraft:air
fill 325 54 -427 327 54 -427 minecraft:air
fill 275 54 -428 302 54 -428 minecraft:water[level=0]
fill 304 54 -428 305 54 -428 minecraft:air
fill 324 54 -428 327 54 -428 minecraft:air
setblock 264 54 -429 minecraft:water[level=0]
fill 275 54 -429 301 54 -429 minecraft:water[level=0]
setblock 324 54 -429 torchmaster:invisible_light
fill 325 54 -429 327 54 -429 minecraft:air
setblock 264 54 -430 minecraft:water[level=0]
fill 277 54 -430 301 54 -430 minecraft:water[level=0]
fill 323 54 -430 327 54 -430 minecraft:air
setblock 264 54 -431 minecraft:water[level=0]
fill 280 54 -431 300 54 -431 minecraft:water[level=0]
fill 322 54 -431 327 54 -431 minecraft:air
fill 283 54 -432 287 54 -432 minecraft:water[level=0]
fill 289 54 -432 299 54 -432 minecraft:water[level=0]
fill 321 54 -432 327 54 -432 minecraft:air
fill 321 54 -433 327 54 -433 minecraft:air
fill 321 54 -434 327 54 -434 minecraft:air
fill 318 54 -435 327 54 -435 minecraft:air
setblock 318 54 -436 minecraft:air
setblock 319 54 -436 torchmaster:invisible_light
fill 320 54 -436 326 54 -436 minecraft:air
fill 319 54 -437 325 54 -437 minecraft:air
fill 323 54 -438 324 54 -438 minecraft:air
fill 304 54 -439 306 54 -439 minecraft:water[level=0]
fill 303 54 -440 306 54 -440 minecraft:water[level=0]
fill 303 54 -441 306 54 -441 minecraft:water[level=0]
fill 302 54 -442 306 54 -442 minecraft:water[level=0]
fill 301 54 -443 305 54 -443 minecraft:water[level=0]
fill 300 54 -444 305 54 -444 minecraft:water[level=0]
fill 300 54 -445 304 54 -445 minecraft:water[level=0]
setblock 264 54 -446 minecraft:water[level=0]
fill 300 54 -446 303 54 -446 minecraft:water[level=0]
fill 322 54 -446 323 54 -446 minecraft:water[level=0]
fill 288 53 -383 290 53 -383 minecraft:water[level=0]
fill 288 53 -384 290 53 -384 minecraft:water[level=0]
fill 289 53 -385 291 53 -385 minecraft:water[level=0]
fill 289 53 -386 291 53 -386 minecraft:water[level=0]
fill 290 53 -388 292 53 -388 minecraft:air
fill 291 53 -389 294 53 -389 minecraft:air
fill 291 53 -390 294 53 -390 minecraft:air
fill 292 53 -391 294 53 -391 minecraft:air
fill 292 53 -392 295 53 -392 minecraft:air
fill 293 53 -393 296 53 -393 minecraft:air
fill 293 53 -394 297 53 -394 minecraft:air
fill 294 53 -395 297 53 -395 minecraft:air
fill 295 53 -396 296 53 -396 minecraft:air
fill 310 53 -407 312 53 -407 minecraft:air
fill 311 53 -408 312 53 -408 minecraft:air
setblock 313 53 -409 minecraft:air
fill 308 53 -410 310 53 -410 minecraft:air
setblock 312 53 -410 minecraft:air
setblock 314 53 -410 minecraft:air
setblock 280 53 -411 minecraft:water[level=0]
fill 309 53 -411 313 53 -411 minecraft:air
fill 276 53 -412 284 53 -412 minecraft:water[level=0]
fill 310 53 -412 313 53 -412 minecraft:air
fill 276 53 -413 285 53 -413 minecraft:water[level=0]
fill 311 53 -413 312 53 -413 minecraft:air
fill 277 53 -414 286 53 -414 minecraft:water[level=0]
fill 278 53 -415 286 53 -415 minecraft:water[level=0]
fill 279 53 -416 285 53 -416 minecraft:water[level=0]
fill 279 53 -417 286 53 -417 minecraft:water[level=0]
fill 265 53 -418 269 53 -418 minecraft:water[level=0]
fill 279 53 -418 288 53 -418 minecraft:water[level=0]
fill 264 53 -419 270 53 -419 minecraft:water[level=0]
fill 280 53 -419 288 53 -419 minecraft:water[level=0]
fill 264 53 -420 270 53 -420 minecraft:water[level=0]
fill 280 53 -420 288 53 -420 minecraft:water[level=0]
fill 264 53 -421 269 53 -421 minecraft:water[level=0]
fill 279 53 -421 289 53 -421 minecraft:water[level=0]
fill 264 53 -422 267 53 -422 minecraft:water[level=0]
fill 278 53 -422 289 53 -422 minecraft:water[level=0]
setblock 309 53 -422 minecraft:air
fill 264 53 -423 267 53 -423 minecraft:water[level=0]
fill 279 53 -423 290 53 -423 minecraft:water[level=0]
fill 307 53 -423 308 53 -423 minecraft:air
fill 264 53 -424 266 53 -424 minecraft:water[level=0]
fill 280 53 -424 290 53 -424 minecraft:water[level=0]
fill 305 53 -424 308 53 -424 minecraft:air
fill 264 53 -425 265 53 -425 minecraft:water[level=0]
fill 280 53 -425 291 53 -425 minecraft:water[level=0]
setblock 303 53 -425 minecraft:water[level=0]
fill 305 53 -425 308 53 -425 minecraft:air
setblock 264 53 -426 minecraft:water[level=0]
fill 280 53 -426 293 53 -426 minecraft:water[level=0]
fill 299 53 -426 303 53 -426 minecraft:water[level=0]
setblock 304 53 -426 minecraft:water[level=1]
fill 305 53 -426 309 53 -426 minecraft:air
setblock 327 53 -426 minecraft:air
setblock 264 53 -427 minecraft:water[level=0]
fill 280 53 -427 302 53 -427 minecraft:water[level=0]
fill 304 53 -427 308 53 -427 minecraft:air
fill 326 53 -427 327 53 -427 minecraft:air
setblock 264 53 -428 minecraft:water[level=0]
fill 281 53 -428 302 53 -428 minecraft:water[level=0]
fill 304 53 -428 307 53 -428 minecraft:air
fill 325 53 -428 327 53 -428 minecraft:air
setblock 264 53 -429 minecraft:water[level=0]
fill 281 53 -429 301 53 -429 minecraft:water[level=0]
fill 303 53 -429 305 53 -429 minecraft:air
fill 324 53 -429 327 53 -429 minecraft:air
setblock 264 53 -430 minecraft:water[level=0]
fill 283 53 -430 293 53 -430 minecraft:water[level=0]
setblock 301 53 -430 minecraft:water[level=0]
fill 303 53 -430 304 53 -430 minecraft:air
fill 323 53 -430 327 53 -430 minecraft:air
setblock 264 53 -431 minecraft:water[level=0]
fill 322 53 -431 327 53 -431 minecraft:air
setblock 322 53 -432 torchmaster:invisible_light
fill 323 53 -432 327 53 -432 minecraft:air
fill 317 53 -433 319 53 -433 minecraft:air
fill 321 53 -433 327 53 -433 minecraft:air
fill 317 53 -434 327 53 -434 minecraft:air
fill 317 53 -435 327 53 -435 minecraft:air
fill 318 53 -436 326 53 -436 minecraft:air
fill 318 53 -437 325 53 -437 minecraft:air
fill 305 53 -438 308 53 -438 minecraft:water[level=0]
setblock 322 53 -438 torchmaster:invisible_light
fill 323 53 -438 325 53 -438 minecraft:air
fill 304 53 -439 308 53 -439 minecraft:water[level=0]
fill 303 53 -440 307 53 -440 minecraft:water[level=0]
fill 303 53 -441 306 53 -441 minecraft:water[level=0]
fill 302 53 -442 306 53 -442 minecraft:water[level=0]
fill 302 53 -443 305 53 -443 minecraft:water[level=0]
fill 302 53 -444 304 53 -444 minecraft:water[level=0]
setblock 303 53 -445 minecraft:water[level=0]
fill 322 53 -445 323 53 -445 minecraft:water[level=0]
fill 321 53 -446 323 53 -446 minecraft:water[level=0]
fill 287 52 -383 289 52 -383 minecraft:water[level=0]
fill 288 52 -384 290 52 -384 minecraft:water[level=0]
fill 288 52 -385 290 52 -385 minecraft:water[level=0]
fill 289 52 -388 292 52 -388 minecraft:air
fill 290 52 -389 291 52 -389 minecraft:air
fill 291 52 -390 293 52 -390 minecraft:air
fill 291 52 -391 294 52 -391 minecraft:air
fill 292 52 -392 294 52 -392 minecraft:air
fill 292 52 -393 296 52 -393 minecraft:air
fill 293 52 -394 297 52 -394 minecraft:air
fill 295 52 -395 296 52 -395 minecraft:air
setblock 311 52 -407 minecraft:air
fill 311 52 -408 312 52 -408 minecraft:air
setblock 313 52 -409 minecraft:air
fill 309 52 -410 310 52 -410 minecraft:air
fill 274 52 -411 280 52 -411 minecraft:water[level=0]
fill 309 52 -411 314 52 -411 minecraft:air
fill 275 52 -412 282 52 -412 minecraft:water[level=0]
fill 310 52 -412 314 52 -412 minecraft:air
fill 275 52 -413 284 52 -413 minecraft:water[level=0]
fill 310 52 -413 314 52 -413 minecraft:air
fill 275 52 -414 286 52 -414 minecraft:water[level=0]
fill 311 52 -414 313 52 -414 minecraft:air
fill 276 52 -415 286 52 -415 minecraft:water[level=0]
fill 311 52 -415 313 52 -415 minecraft:air
fill 276 52 -416 285 52 -416 minecraft:water[level=0]
fill 276 52 -417 285 52 -417 minecraft:water[level=0]
fill 279 52 -418 285 52 -418 minecraft:water[level=0]
fill 287 52 -418 288 52 -418 minecraft:water[level=0]
fill 280 52 -419 288 52 -419 minecraft:water[level=0]
setblock 264 52 -420 minecraft:water[level=0]
fill 281 52 -420 289 52 -420 minecraft:water[level=0]
fill 264 52 -421 265 52 -421 minecraft:water[level=0]
fill 282 52 -421 289 52 -421 minecraft:water[level=0]
fill 264 52 -422 265 52 -422 minecraft:water[level=0]
fill 282 52 -422 290 52 -422 minecraft:water[level=0]
setblock 309 52 -422 minecraft:air
setblock 311 52 -422 minecraft:air
fill 264 52 -423 265 52 -423 minecraft:water[level=0]
fill 282 52 -423 290 52 -423 minecraft:water[level=0]
fill 307 52 -423 311 52 -423 minecraft:air
setblock 264 52 -424 minecraft:water[level=0]
fill 283 52 -424 291 52 -424 minecraft:water[level=0]
fill 307 52 -424 311 52 -424 minecraft:air
setblock 264 52 -425 minecraft:water[level=0]
fill 283 52 -425 291 52 -425 minecraft:water[level=0]
fill 306 52 -425 311 52 -425 minecraft:air
setblock 264 52 -426 minecraft:water[level=0]
fill 283 52 -426 293 52 -426 minecraft:water[level=0]
setblock 304 52 -426 minecraft:water[level=8]
setblock 306 52 -426 minecraft:water[level=4]
setblock 307 52 -426 minecraft:water[level=5]
fill 308 52 -426 311 52 -426 minecraft:air
setblock 327 52 -426 minecraft:air
setblock 264 52 -427 minecraft:water[level=0]
fill 283 52 -427 290 52 -427 minecraft:water[level=0]
setblock 304 52 -427 minecraft:water[level=1]
setblock 305 52 -427 minecraft:water[level=2]
setblock 306 52 -427 minecraft:water[level=3]
setblock 307 52 -427 minecraft:water[level=4]
setblock 308 52 -427 minecraft:water[level=5]
fill 309 52 -427 310 52 -427 minecraft:air
setblock 326 52 -427 torchmaster:invisible_light
setblock 327 52 -427 minecraft:air
setblock 264 52 -428 minecraft:water[level=0]
setblock 284 52 -428 minecraft:water[level=0]
fill 305 52 -428 309 52 -428 minecraft:air
fill 325 52 -428 327 52 -428 minecraft:air
setblock 264 52 -429 minecraft:water[level=0]
fill 306 52 -429 308 52 -429 minecraft:air
fill 324 52 -429 327 52 -429 minecraft:air
setblock 316 52 -430 minecraft:air
fill 323 52 -430 327 52 -430 minecraft:air
fill 315 52 -431 318 52 -431 minecraft:air
fill 323 52 -431 327 52 -431 minecraft:air
fill 315 52 -432 319 52 -432 minecraft:air
fill 322 52 -432 327 52 -432 minecraft:air
fill 316 52 -433 319 52 -433 minecraft:air
fill 322 52 -433 327 52 -433 minecraft:air
fill 317 52 -434 327 52 -434 minecraft:air
fill 317 52 -435 327 52 -435 minecraft:air
fill 318 52 -436 327 52 -436 minecraft:air
setblock 310 52 -437 minecraft:air
fill 320 52 -437 326 52 -437 minecraft:air
fill 305 52 -438 307 52 -438 minecraft:water[level=0]
fill 322 52 -438 325 52 -438 minecraft:air
fill 304 52 -439 308 52 -439 minecraft:water[level=0]
fill 303 52 -440 307 52 -440 minecraft:water[level=0]
fill 303 52 -441 306 52 -441 minecraft:water[level=0]
fill 303 52 -442 305 52 -442 minecraft:water[level=0]
setblock 322 52 -443 minecraft:water[level=0]
fill 321 52 -444 323 52 -444 minecraft:water[level=0]
fill 321 52 -445 323 52 -445 minecraft:water[level=0]
fill 321 52 -446 323 52 -446 minecraft:water[level=0]
fill 287 51 -383 289 51 -383 minecraft:water[level=0]
fill 287 51 -384 289 51 -384 minecraft:water[level=0]
fill 288 51 -385 290 51 -385 minecraft:water[level=0]
fill 289 51 -388 291 51 -388 minecraft:air
fill 289 51 -389 291 51 -389 minecraft:air
fill 290 51 -390 293 51 -390 minecraft:air
fill 291 51 -391 293 51 -391 minecraft:air
fill 291 51 -392 294 51 -392 minecraft:air
fill 292 51 -393 295 51 -393 minecraft:air
fill 293 51 -394 296 51 -394 minecraft:air
setblock 313 51 -409 minecraft:air
fill 272 51 -410 277 51 -410 minecraft:water[level=0]
setblock 310 51 -410 minecraft:air
fill 273 51 -411 278 51 -411 minecraft:water[level=0]
fill 309 51 -411 314 51 -411 minecraft:air
fill 273 51 -412 280 51 -412 minecraft:water[level=0]
fill 310 51 -412 314 51 -412 minecraft:air
fill 273 51 -413 281 51 -413 minecraft:water[level=0]
fill 310 51 -413 314 51 -413 minecraft:air
fill 274 51 -414 282 51 -414 minecraft:water[level=0]
fill 310 51 -414 314 51 -414 minecraft:air
fill 277 51 -415 283 51 -415 minecraft:water[level=0]
fill 310 51 -415 314 51 -415 minecraft:air
fill 280 51 -416 285 51 -416 minecraft:water[level=0]
fill 310 51 -416 313 51 -416 minecraft:air
fill 281 51 -417 284 51 -417 minecraft:water[level=0]
fill 310 51 -417 313 51 -417 minecraft:air
fill 282 51 -418 284 51 -418 minecraft:water[level=0]
setblock 287 51 -418 minecraft:water[level=0]
fill 310 51 -418 312 51 -418 minecraft:air
fill 282 51 -419 288 51 -419 minecraft:water[level=0]
fill 310 51 -419 311 51 -419 minecraft:air
fill 283 51 -420 289 51 -420 minecraft:water[level=0]
fill 284 51 -421 288 51 -421 minecraft:water[level=0]
fill 284 51 -422 287 51 -422 minecraft:water[level=0]
setblock 309 51 -422 minecraft:air
fill 284 51 -423 287 51 -423 minecraft:water[level=0]
fill 307 51 -423 312 51 -423 minecraft:air
fill 285 51 -424 286 51 -424 minecraft:water[level=0]
fill 307 51 -424 312 51 -424 minecraft:air
fill 307 51 -425 313 51 -425 minecraft:air
setblock 307 51 -426 minecraft:water[level=8]
fill 308 51 -426 313 51 -426 minecraft:air
setblock 308 51 -427 minecraft:water[level=8]
fill 309 51 -427 313 51 -427 minecraft:air
setblock 327 51 -427 minecraft:air
fill 308 51 -428 313 51 -428 minecraft:air
fill 325 51 -428 327 51 -428 minecraft:air
fill 309 51 -429 315 51 -429 minecraft:air
fill 324 51 -429 327 51 -429 minecraft:air
fill 312 51 -430 317 51 -430 minecraft:air
fill 323 51 -430 327 51 -430 minecraft:air
fill 313 51 -431 318 51 -431 minecraft:air
fill 323 51 -431 327 51 -431 minecraft:air
fill 315 51 -432 316 51 -432 minecraft:air
setblock 317 51 -432 torchmaster:invisible_light
setblock 318 51 -432 minecraft:air
fill 322 51 -432 327 51 -432 minecraft:air
fill 315 51 -433 319 51 -433 minecraft:air
fill 322 51 -433 327 51 -433 minecraft:air
setblock 317 51 -434 minecraft:air
setblock 319 51 -434 minecraft:air
fill 321 51 -434 327 51 -434 minecraft:air
setblock 318 51 -435 minecraft:air
setblock 321 51 -435 torchmaster:invisible_light
fill 322 51 -435 327 51 -435 minecraft:air
fill 309 51 -436 311 51 -436 minecraft:air
fill 320 51 -436 327 51 -436 minecraft:air
fill 309 51 -437 311 51 -437 minecraft:air
fill 320 51 -437 326 51 -437 minecraft:air
fill 305 51 -438 306 51 -438 minecraft:water[level=0]
setblock 311 51 -438 minecraft:air
fill 321 51 -438 325 51 -438 minecraft:air
fill 304 51 -439 308 51 -439 minecraft:water[level=0]
fill 304 51 -440 308 51 -440 minecraft:water[level=0]
fill 323 51 -440 324 51 -440 minecraft:water[level=0]
fill 304 51 -441 306 51 -441 minecraft:water[level=0]
fill 321 51 -442 322 51 -442 minecraft:water[level=0]
fill 320 51 -443 322 51 -443 minecraft:water[level=0]
fill 321 51 -444 323 51 -444 minecraft:water[level=0]
fill 321 51 -445 323 51 -445 minecraft:water[level=0]
setblock 322 51 -446 minecraft:water[level=0]
fill 286 50 -383 288 50 -383 minecraft:water[level=0]
fill 286 50 -384 288 50 -384 minecraft:water[level=0]
fill 289 50 -387 290 50 -387 minecraft:air
fill 288 50 -388 291 50 -388 minecraft:air
fill 289 50 -389 291 50 -389 minecraft:air
fill 290 50 -390 292 50 -390 minecraft:air
fill 290 50 -391 292 50 -391 minecraft:air
fill 291 50 -392 294 50 -392 minecraft:air
fill 292 50 -393 295 50 -393 minecraft:air
fill 272 50 -409 275 50 -409 minecraft:water[level=0]
fill 271 50 -410 276 50 -410 minecraft:water[level=0]
fill 271 50 -411 277 50 -411 minecraft:water[level=0]
fill 311 50 -411 314 50 -411 minecraft:air
fill 272 50 -412 278 50 -412 minecraft:water[level=0]
fill 310 50 -412 314 50 -412 minecraft:air
fill 273 50 -413 276 50 -413 minecraft:water[level=0]
setblock 277 50 -413 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=false,waterlogged=true,west=false]
setblock 278 50 -413 minecraft:water[level=0]
fill 310 50 -413 314 50 -413 minecraft:air
fill 278 50 -414 279 50 -414 minecraft:water[level=0]
fill 310 50 -414 314 50 -414 minecraft:air
fill 310 50 -415 314 50 -415 minecraft:air
fill 309 50 -416 314 50 -416 minecraft:air
fill 309 50 -417 313 50 -417 minecraft:air
fill 308 50 -418 313 50 -418 minecraft:air
fill 308 50 -419 312 50 -419 minecraft:air
fill 307 50 -420 311 50 -420 minecraft:air
fill 307 50 -421 310 50 -421 minecraft:air
fill 307 50 -422 310 50 -422 minecraft:air
fill 307 50 -423 310 50 -423 minecraft:air
setblock 314 50 -423 minecraft:air
fill 307 50 -424 310 50 -424 minecraft:air
fill 313 50 -424 314 50 -424 minecraft:air
fill 307 50 -425 314 50 -425 minecraft:air
setblock 307 50 -426 minecraft:water[level=8]
fill 308 50 -426 314 50 -426 minecraft:air
setblock 308 50 -427 minecraft:water[level=8]
fill 309 50 -427 315 50 -427 minecraft:air
setblock 327 50 -427 minecraft:air
fill 309 50 -428 314 50 -428 minecraft:air
fill 326 50 -428 327 50 -428 minecraft:air
fill 310 50 -429 315 50 -429 minecraft:air
fill 324 50 -429 327 50 -429 minecraft:air
fill 311 50 -430 317 50 -430 minecraft:air
fill 324 50 -430 327 50 -430 minecraft:air
fill 312 50 -431 317 50 -431 minecraft:air
fill 323 50 -431 327 50 -431 minecraft:air
fill 315 50 -432 317 50 -432 minecraft:air
fill 322 50 -432 327 50 -432 minecraft:air
setblock 316 50 -433 minecraft:air
fill 322 50 -433 327 50 -433 minecraft:air
fill 321 50 -434 327 50 -434 minecraft:air
fill 310 50 -435 313 50 -435 minecraft:air
fill 321 50 -435 327 50 -435 minecraft:air
fill 309 50 -436 313 50 -436 minecraft:air
fill 320 50 -436 327 50 -436 minecraft:air
fill 309 50 -437 312 50 -437 minecraft:air
fill 320 50 -437 324 50 -437 minecraft:air
setblock 325 50 -437 torchmaster:invisible_light
setblock 326 50 -437 minecraft:air
setblock 306 50 -438 minecraft:water[level=0]
fill 310 50 -438 311 50 -438 minecraft:air
fill 321 50 -438 325 50 -438 minecraft:air
fill 305 50 -439 307 50 -439 minecraft:water[level=0]
fill 305 50 -440 307 50 -440 minecraft:water[level=0]
fill 323 50 -440 324 50 -440 minecraft:water[level=0]
fill 320 50 -441 322 50 -441 minecraft:water[level=0]
setblock 324 50 -441 minecraft:water[level=0]
fill 320 50 -442 322 50 -442 minecraft:water[level=0]
fill 321 50 -443 323 50 -443 minecraft:water[level=0]
fill 321 50 -444 322 50 -444 minecraft:water[level=0]
setblock 286 49 -383 minecraft:water[level=0]
fill 288 49 -386 289 49 -386 minecraft:air
fill 289 49 -387 290 49 -387 minecraft:air
fill 289 49 -388 290 49 -388 minecraft:air
setblock 290 49 -389 minecraft:air
fill 290 49 -390 292 49 -390 minecraft:air
fill 291 49 -391 292 49 -391 minecraft:air
setblock 293 49 -392 minecraft:air
fill 275 49 -399 276 49 -399 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 275 49 -400 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 273 49 -408 minecraft:water[level=0]
fill 272 49 -409 274 49 -409 minecraft:water[level=0]
fill 271 49 -410 275 49 -410 minecraft:water[level=0]
fill 270 49 -411 275 49 -411 minecraft:water[level=0]
fill 275 49 -412 276 49 -412 minecraft:water[level=0]
setblock 312 49 -412 minecraft:air
fill 311 49 -413 314 49 -413 minecraft:air
fill 310 49 -414 314 49 -414 minecraft:air
fill 310 49 -415 314 49 -415 minecraft:air
fill 309 49 -416 314 49 -416 minecraft:air
fill 308 49 -417 313 49 -417 minecraft:air
fill 308 49 -418 313 49 -418 minecraft:air
fill 307 49 -419 312 49 -419 minecraft:air
fill 307 49 -420 312 49 -420 minecraft:air
fill 307 49 -421 311 49 -421 minecraft:air
fill 306 49 -422 308 49 -422 minecraft:air
setblock 310 49 -422 minecraft:air
setblock 306 49 -423 minecraft:air
fill 309 49 -423 310 49 -423 minecraft:air
setblock 315 49 -423 minecraft:air
setblock 306 49 -424 minecraft:air
fill 308 49 -424 310 49 -424 minecraft:air
fill 314 49 -424 315 49 -424 minecraft:air
fill 307 49 -425 311 49 -425 minecraft:air
fill 313 49 -425 315 49 -425 minecraft:air
setblock 307 49 -426 minecraft:water[level=8]
fill 308 49 -426 315 49 -426 minecraft:air
setblock 308 49 -427 minecraft:water[level=8]
fill 309 49 -427 316 49 -427 minecraft:air
fill 309 49 -428 316 49 -428 minecraft:air
fill 326 49 -428 327 49 -428 minecraft:air
fill 310 49 -429 316 49 -429 minecraft:air
fill 325 49 -429 327 49 -429 minecraft:air
fill 311 49 -430 315 49 -430 minecraft:air
fill 324 49 -430 327 49 -430 minecraft:air
fill 313 49 -431 314 49 -431 minecraft:air
fill 323 49 -431 327 49 -431 minecraft:air
fill 322 49 -432 327 49 -432 minecraft:air
setblock 313 49 -433 minecraft:air
fill 322 49 -433 323 49 -433 minecraft:air
setblock 324 49 -433 torchmaster:invisible_light
fill 325 49 -433 327 49 -433 minecraft:air
fill 312 49 -434 314 49 -434 minecraft:air
fill 321 49 -434 327 49 -434 minecraft:air
fill 310 49 -435 314 49 -435 minecraft:air
fill 321 49 -435 327 49 -435 minecraft:air
fill 309 49 -436 313 49 -436 minecraft:air
fill 320 49 -436 327 49 -436 minecraft:air
setblock 308 49 -437 minecraft:air
fill 310 49 -437 312 49 -437 minecraft:air
fill 320 49 -437 327 49 -437 minecraft:air
fill 309 49 -438 311 49 -438 minecraft:air
setblock 320 49 -438 torchmaster:invisible_light
fill 321 49 -438 322 49 -438 minecraft:air
setblock 319 49 -439 torchmaster:invisible_light
fill 320 49 -440 325 49 -440 minecraft:water[level=0]
fill 320 49 -441 322 49 -441 minecraft:water[level=0]
setblock 324 49 -441 minecraft:water[level=0]
fill 321 49 -442 323 49 -442 minecraft:water[level=0]
setblock 321 49 -443 minecraft:water[level=0]
setblock 288 48 -386 minecraft:air
setblock 289 48 -387 minecraft:air
fill 289 48 -388 290 48 -388 minecraft:air
setblock 290 48 -389 minecraft:air
setblock 291 48 -390 minecraft:air
fill 275 48 -399 276 48 -399 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 275 48 -400 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 309 48 -417 311 48 -417 minecraft:air
fill 308 48 -418 312 48 -418 minecraft:air
fill 308 48 -419 312 48 -419 minecraft:air
fill 307 48 -420 311 48 -420 minecraft:air
fill 307 48 -421 311 48 -421 minecraft:air
fill 306 48 -422 308 48 -422 minecraft:air
setblock 310 48 -422 minecraft:air
setblock 306 48 -423 minecraft:air
setblock 310 48 -424 minecraft:water[level=5]
setblock 316 48 -424 minecraft:air
setblock 309 48 -425 minecraft:water[level=3]
setblock 310 48 -425 minecraft:water[level=4]
setblock 316 48 -425 minecraft:air
setblock 307 48 -426 minecraft:water[level=8]
setblock 308 48 -426 minecraft:water[level=1]
setblock 309 48 -426 minecraft:water[level=2]
setblock 310 48 -426 minecraft:water[level=3]
setblock 311 48 -426 minecraft:water[level=4]
fill 315 48 -426 316 48 -426 minecraft:air
setblock 308 48 -427 minecraft:water[level=8]
setblock 309 48 -427 minecraft:water[level=1]
setblock 310 48 -427 minecraft:water[level=2]
fill 314 48 -427 317 48 -427 minecraft:air
fill 314 48 -428 317 48 -428 minecraft:air
setblock 327 48 -428 minecraft:air
fill 314 48 -429 317 48 -429 minecraft:air
fill 325 48 -429 327 48 -429 minecraft:air
fill 315 48 -430 318 48 -430 minecraft:air
fill 324 48 -430 327 48 -430 minecraft:air
fill 313 48 -431 318 48 -431 minecraft:air
fill 323 48 -431 327 48 -431 minecraft:air
fill 313 48 -432 318 48 -432 minecraft:air
fill 323 48 -432 327 48 -432 minecraft:air
fill 312 48 -433 314 48 -433 minecraft:air
fill 316 48 -433 319 48 -433 minecraft:air
fill 322 48 -433 327 48 -433 minecraft:air
fill 312 48 -434 314 48 -434 minecraft:air
fill 317 48 -434 319 48 -434 minecraft:air
fill 322 48 -434 327 48 -434 minecraft:air
fill 311 48 -435 314 48 -435 minecraft:air
fill 317 48 -435 327 48 -435 minecraft:air
fill 310 48 -436 313 48 -436 minecraft:air
fill 317 48 -436 327 48 -436 minecraft:air
fill 310 48 -437 311 48 -437 minecraft:air
fill 318 48 -437 327 48 -437 minecraft:air
setblock 319 48 -438 minecraft:air
setblock 319 48 -439 minecraft:air
fill 320 48 -440 325 48 -440 minecraft:water[level=0]
fill 321 48 -441 324 48 -441 minecraft:water[level=0]
setblock 322 47 -405 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 272 47 -407 minecraft:air
setblock 268 47 -408 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 269 47 -408 273 47 -408 minecraft:air
fill 269 47 -409 272 47 -409 minecraft:air
fill 269 47 -410 271 47 -410 minecraft:air
setblock 317 47 -424 minecraft:air
setblock 317 47 -425 minecraft:air
fill 316 47 -426 317 47 -426 minecraft:air
fill 314 47 -427 318 47 -427 minecraft:air
fill 313 47 -428 318 47 -428 minecraft:air
setblock 327 47 -428 minecraft:air
fill 313 47 -429 314 47 -429 minecraft:air
fill 316 47 -429 318 47 -429 minecraft:air
setblock 325 47 -429 minecraft:air
setblock 326 47 -429 torchmaster:invisible_light
setblock 327 47 -429 minecraft:air
fill 313 47 -430 314 47 -430 minecraft:air
fill 316 47 -430 319 47 -430 minecraft:air
fill 324 47 -430 327 47 -430 minecraft:air
fill 313 47 -431 314 47 -431 minecraft:air
fill 316 47 -431 319 47 -431 minecraft:air
fill 323 47 -431 327 47 -431 minecraft:air
fill 313 47 -432 315 47 -432 minecraft:air
fill 317 47 -432 319 47 -432 minecraft:air
fill 323 47 -432 327 47 -432 minecraft:air
fill 312 47 -433 314 47 -433 minecraft:air
fill 317 47 -433 320 47 -433 minecraft:air
fill 322 47 -433 327 47 -433 minecraft:air
fill 312 47 -434 314 47 -434 minecraft:air
fill 318 47 -434 320 47 -434 minecraft:air
fill 322 47 -434 327 47 -434 minecraft:air
fill 312 47 -435 314 47 -435 minecraft:air
fill 318 47 -435 327 47 -435 minecraft:air
setblock 313 47 -436 minecraft:air
fill 319 47 -436 327 47 -436 minecraft:air
fill 319 47 -437 327 47 -437 minecraft:air
setblock 326 47 -439 minecraft:water[level=0]
fill 321 47 -440 325 47 -440 minecraft:water[level=0]
fill 322 47 -441 324 47 -441 minecraft:water[level=0]
setblock 324 47 -442 minecraft:water[level=0]
fill 322 46 -404 323 46 -404 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 322 46 -405 323 46 -405 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 270 46 -407 272 46 -407 minecraft:air
fill 268 46 -408 273 46 -408 minecraft:air
setblock 268 46 -409 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 269 46 -409 273 46 -409 minecraft:air
fill 268 46 -410 271 46 -410 minecraft:air
setblock 273 46 -410 minecraft:air
setblock 318 46 -424 minecraft:air
fill 314 46 -425 315 46 -425 minecraft:air
setblock 318 46 -425 minecraft:air
fill 314 46 -426 315 46 -426 minecraft:air
fill 317 46 -426 319 46 -426 minecraft:air
fill 313 46 -427 319 46 -427 minecraft:air
fill 313 46 -428 319 46 -428 minecraft:air
fill 313 46 -429 314 46 -429 minecraft:air
fill 317 46 -429 319 46 -429 minecraft:air
fill 326 46 -429 327 46 -429 minecraft:air
fill 313 46 -430 314 46 -430 minecraft:air
fill 317 46 -430 320 46 -430 minecraft:air
fill 324 46 -430 327 46 -430 minecraft:air
fill 313 46 -431 314 46 -431 minecraft:air
fill 318 46 -431 320 46 -431 minecraft:air
fill 324 46 -431 327 46 -431 minecraft:air
fill 313 46 -432 314 46 -432 minecraft:air
fill 318 46 -432 320 46 -432 minecraft:air
fill 323 46 -432 327 46 -432 minecraft:air
fill 313 46 -433 314 46 -433 minecraft:air
fill 318 46 -433 327 46 -433 minecraft:air
fill 313 46 -434 314 46 -434 minecraft:air
fill 319 46 -434 327 46 -434 minecraft:air
fill 319 46 -435 327 46 -435 minecraft:air
fill 320 46 -436 327 46 -436 minecraft:air
fill 320 46 -437 326 46 -437 minecraft:air
setblock 320 46 -438 minecraft:air
setblock 323 46 -439 minecraft:water[level=0]
fill 321 46 -440 325 46 -440 minecraft:water[level=0]
fill 322 46 -441 324 46 -441 minecraft:water[level=0]
setblock 324 46 -442 minecraft:water[level=0]
setblock 323 45 -404 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 268 45 -407 272 45 -407 minecraft:air
fill 268 45 -408 273 45 -408 minecraft:air
fill 268 45 -409 273 45 -409 minecraft:air
setblock 319 45 -424 minecraft:air
fill 314 45 -425 315 45 -425 minecraft:air
setblock 319 45 -425 minecraft:air
fill 314 45 -426 315 45 -426 minecraft:air
fill 318 45 -426 319 45 -426 minecraft:air
fill 313 45 -427 314 45 -427 minecraft:air
fill 318 45 -427 320 45 -427 minecraft:air
setblock 313 45 -428 minecraft:air
setblock 315 45 -428 minecraft:air
fill 317 45 -428 320 45 -428 minecraft:air
fill 313 45 -429 314 45 -429 minecraft:air
fill 318 45 -429 320 45 -429 minecraft:air
fill 326 45 -429 327 45 -429 minecraft:air
fill 313 45 -430 314 45 -430 minecraft:air
fill 318 45 -430 321 45 -430 minecraft:air
fill 324 45 -430 327 45 -430 minecraft:air
fill 313 45 -431 314 45 -431 minecraft:air
fill 319 45 -431 321 45 -431 minecraft:air
fill 324 45 -431 327 45 -431 minecraft:air
fill 319 45 -432 321 45 -432 minecraft:air
fill 323 45 -432 327 45 -432 minecraft:air
fill 319 45 -433 327 45 -433 minecraft:air
setblock 294 45 -434 minecraft:air
fill 320 45 -434 327 45 -434 minecraft:air
setblock 295 45 -435 minecraft:air
fill 320 45 -435 327 45 -435 minecraft:air
fill 320 45 -436 326 45 -436 minecraft:air
setblock 320 45 -437 minecraft:air
setblock 320 45 -438 minecraft:air
fill 322 45 -439 326 45 -439 minecraft:water[level=0]
fill 320 45 -440 325 45 -440 minecraft:water[level=0]
fill 322 45 -441 324 45 -441 minecraft:water[level=0]
setblock 324 45 -442 minecraft:water[level=0]
forceload remove 264 -446 327 -383
tellraw @a {"text":"Campus zurueck a05 fertig.","color":"green"}
