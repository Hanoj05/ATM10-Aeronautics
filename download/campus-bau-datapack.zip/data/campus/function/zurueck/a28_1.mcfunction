setblock 412 72 -246 minecraft:air
setblock 412 71 -244 minecraft:air
fill 411 71 -245 413 71 -245 minecraft:air
fill 410 71 -246 414 71 -246 minecraft:air
fill 411 71 -247 413 71 -247 minecraft:air
setblock 412 71 -248 minecraft:air
setblock 412 71 -254 minecraft:air
fill 411 70 -244 413 70 -244 minecraft:air
fill 410 70 -245 414 70 -245 minecraft:air
fill 410 70 -246 414 70 -246 minecraft:air
fill 410 70 -247 414 70 -247 minecraft:air
fill 411 70 -248 413 70 -248 minecraft:air
fill 411 70 -254 413 70 -254 minecraft:air
setblock 412 69 -244 minecraft:air
fill 411 69 -245 413 69 -245 minecraft:air
fill 410 69 -246 414 69 -246 minecraft:air
fill 411 69 -247 413 69 -247 minecraft:air
setblock 412 69 -248 minecraft:air
setblock 412 69 -254 minecraft:air
setblock 412 68 -246 minecraft:air
setblock 412 67 -246 minecraft:air
setblock 392 66 -191 minecraft:air
fill 396 66 -191 399 66 -191 minecraft:air
setblock 402 66 -191 minecraft:air
setblock 407 66 -191 minecraft:air
fill 409 66 -191 411 66 -191 minecraft:air
fill 413 66 -191 414 66 -191 minecraft:air
setblock 395 66 -192 minecraft:air
setblock 400 66 -192 minecraft:air
fill 403 66 -192 407 66 -192 minecraft:air
fill 409 66 -192 411 66 -192 minecraft:air
fill 413 66 -192 414 66 -192 minecraft:air
setblock 394 66 -193 minecraft:air
fill 396 66 -193 399 66 -193 minecraft:air
fill 401 66 -193 403 66 -193 minecraft:air
fill 406 66 -193 408 66 -193 minecraft:air
fill 410 66 -193 411 66 -193 minecraft:air
setblock 413 66 -193 minecraft:air
fill 392 66 -194 393 66 -194 minecraft:air
fill 397 66 -194 399 66 -194 minecraft:air
fill 403 66 -194 405 66 -194 minecraft:air
setblock 407 66 -194 minecraft:air
fill 410 66 -194 411 66 -194 minecraft:air
setblock 414 66 -194 minecraft:air
fill 392 66 -195 396 66 -195 minecraft:air
fill 399 66 -195 401 66 -195 minecraft:air
setblock 403 66 -195 minecraft:air
fill 406 66 -195 407 66 -195 minecraft:air
setblock 410 66 -195 minecraft:air
setblock 412 66 -195 minecraft:air
setblock 414 66 -195 minecraft:air
fill 392 66 -196 394 66 -196 minecraft:air
fill 396 66 -196 397 66 -196 minecraft:air
fill 399 66 -196 400 66 -196 minecraft:air
setblock 404 66 -196 minecraft:air
setblock 406 66 -196 minecraft:air
fill 408 66 -196 409 66 -196 minecraft:air
fill 413 66 -196 414 66 -196 minecraft:air
setblock 393 66 -197 minecraft:air
fill 395 66 -197 398 66 -197 minecraft:air
setblock 400 66 -197 minecraft:air
setblock 403 66 -197 minecraft:air
fill 405 66 -197 406 66 -197 minecraft:air
setblock 409 66 -197 minecraft:air
fill 411 66 -197 413 66 -197 minecraft:air
setblock 415 66 -197 minecraft:air
fill 393 66 -198 394 66 -198 minecraft:air
fill 396 66 -198 398 66 -198 minecraft:air
setblock 401 66 -198 minecraft:air
setblock 404 66 -198 minecraft:air
fill 406 66 -198 407 66 -198 minecraft:air
fill 410 66 -198 412 66 -198 minecraft:air
setblock 414 66 -198 minecraft:air
setblock 393 66 -199 minecraft:air
fill 395 66 -199 399 66 -199 minecraft:air
setblock 401 66 -199 minecraft:air
setblock 409 66 -199 minecraft:air
fill 411 66 -199 413 66 -199 minecraft:air
setblock 392 66 -200 minecraft:air
fill 394 66 -200 395 66 -200 minecraft:air
fill 397 66 -200 398 66 -200 minecraft:air
fill 400 66 -200 401 66 -200 minecraft:air
fill 403 66 -200 404 66 -200 minecraft:air
fill 406 66 -200 408 66 -200 minecraft:air
fill 411 66 -200 412 66 -200 minecraft:air
fill 414 66 -200 415 66 -200 minecraft:air
fill 392 66 -201 395 66 -201 minecraft:air
fill 397 66 -201 400 66 -201 minecraft:air
setblock 402 66 -201 minecraft:air
setblock 404 66 -201 minecraft:air
fill 406 66 -201 411 66 -201 minecraft:air
setblock 415 66 -201 minecraft:air
setblock 392 66 -202 minecraft:air
setblock 394 66 -202 minecraft:air
fill 398 66 -202 399 66 -202 minecraft:air
fill 401 66 -202 404 66 -202 minecraft:air
setblock 406 66 -202 minecraft:air
setblock 408 66 -202 minecraft:air
fill 411 66 -202 414 66 -202 minecraft:air
setblock 392 66 -203 minecraft:air
fill 394 66 -203 396 66 -203 minecraft:air
setblock 401 66 -203 minecraft:air
setblock 403 66 -203 minecraft:air
fill 405 66 -203 406 66 -203 minecraft:air
setblock 409 66 -203 minecraft:air
fill 413 66 -203 415 66 -203 minecraft:air
fill 395 66 -204 401 66 -204 minecraft:air
fill 404 66 -204 405 66 -204 minecraft:air
fill 409 66 -204 412 66 -204 minecraft:air
setblock 392 66 -205 minecraft:air
setblock 394 66 -205 minecraft:air
fill 396 66 -205 397 66 -205 minecraft:air
setblock 399 66 -205 minecraft:air
fill 403 66 -205 404 66 -205 minecraft:air
fill 407 66 -205 408 66 -205 minecraft:air
fill 412 66 -205 413 66 -205 minecraft:air
fill 392 66 -206 395 66 -206 minecraft:air
fill 397 66 -206 399 66 -206 minecraft:air
setblock 401 66 -206 minecraft:air
fill 406 66 -206 407 66 -206 minecraft:air
setblock 409 66 -206 minecraft:air
fill 413 66 -206 415 66 -206 minecraft:air
fill 392 66 -207 395 66 -207 minecraft:air
fill 398 66 -207 399 66 -207 minecraft:air
fill 402 66 -207 405 66 -207 minecraft:air
fill 407 66 -207 408 66 -207 minecraft:air
setblock 410 66 -207 minecraft:air
fill 412 66 -207 415 66 -207 minecraft:air
fill 392 66 -208 395 66 -208 minecraft:air
fill 397 66 -208 401 66 -208 minecraft:air
setblock 403 66 -208 minecraft:air
fill 405 66 -208 406 66 -208 minecraft:air
fill 408 66 -208 410 66 -208 minecraft:air
setblock 412 66 -208 minecraft:air
setblock 414 66 -208 minecraft:air
fill 393 66 -209 395 66 -209 minecraft:air
fill 397 66 -209 406 66 -209 minecraft:air
fill 408 66 -209 409 66 -209 minecraft:air
setblock 414 66 -209 minecraft:air
fill 392 66 -210 394 66 -210 minecraft:air
setblock 397 66 -210 minecraft:air
setblock 399 66 -210 minecraft:air
fill 403 66 -210 404 66 -210 minecraft:air
setblock 406 66 -210 minecraft:air
setblock 408 66 -210 minecraft:air
setblock 410 66 -210 minecraft:air
fill 413 66 -210 415 66 -210 minecraft:air
fill 392 66 -211 394 66 -211 minecraft:air
fill 396 66 -211 398 66 -211 minecraft:air
fill 400 66 -211 403 66 -211 minecraft:air
fill 405 66 -211 410 66 -211 minecraft:air
fill 413 66 -211 415 66 -211 minecraft:air
setblock 393 66 -212 minecraft:air
fill 396 66 -212 399 66 -212 minecraft:air
setblock 402 66 -212 minecraft:air
fill 404 66 -212 406 66 -212 minecraft:air
setblock 410 66 -212 minecraft:air
setblock 412 66 -212 minecraft:air
fill 414 66 -212 415 66 -212 minecraft:air
fill 394 66 -213 395 66 -213 minecraft:air
fill 401 66 -213 402 66 -213 minecraft:air
fill 404 66 -213 406 66 -213 minecraft:air
setblock 408 66 -213 minecraft:air
fill 410 66 -213 411 66 -213 minecraft:air
fill 413 66 -213 415 66 -213 minecraft:air
setblock 392 66 -214 minecraft:air
fill 395 66 -214 396 66 -214 minecraft:air
setblock 400 66 -214 minecraft:air
fill 402 66 -214 403 66 -214 minecraft:air
setblock 405 66 -214 minecraft:air
setblock 408 66 -214 minecraft:air
fill 410 66 -214 415 66 -214 minecraft:air
fill 393 66 -215 394 66 -215 minecraft:air
setblock 397 66 -215 minecraft:air
setblock 399 66 -215 minecraft:air
setblock 406 66 -215 minecraft:air
fill 408 66 -215 411 66 -215 minecraft:air
fill 413 66 -215 414 66 -215 minecraft:air
fill 395 66 -216 400 66 -216 minecraft:air
fill 402 66 -216 403 66 -216 minecraft:air
setblock 406 66 -216 minecraft:air
fill 410 66 -216 412 66 -216 minecraft:air
fill 414 66 -216 415 66 -216 minecraft:air
setblock 392 66 -217 minecraft:air
fill 394 66 -217 397 66 -217 minecraft:air
setblock 400 66 -217 minecraft:air
fill 402 66 -217 403 66 -217 minecraft:air
setblock 405 66 -217 minecraft:air
setblock 408 66 -217 minecraft:air
setblock 410 66 -217 minecraft:air
fill 413 66 -217 415 66 -217 minecraft:air
fill 392 66 -218 393 66 -218 minecraft:air
fill 396 66 -218 397 66 -218 minecraft:air
fill 402 66 -218 403 66 -218 minecraft:air
fill 405 66 -218 406 66 -218 minecraft:air
fill 412 66 -218 413 66 -218 minecraft:air
setblock 415 66 -218 minecraft:air
fill 392 66 -219 396 66 -219 minecraft:air
setblock 398 66 -219 minecraft:air
fill 400 66 -219 403 66 -219 minecraft:air
setblock 405 66 -219 minecraft:air
fill 409 66 -219 411 66 -219 minecraft:air
fill 414 66 -219 415 66 -219 minecraft:air
fill 392 66 -220 398 66 -220 minecraft:air
setblock 402 66 -220 minecraft:air
setblock 404 66 -220 minecraft:air
setblock 410 66 -220 minecraft:air
setblock 412 66 -220 minecraft:air
fill 414 66 -220 415 66 -220 minecraft:air
fill 393 66 -221 399 66 -221 minecraft:air
fill 405 66 -221 407 66 -221 minecraft:air
setblock 410 66 -221 minecraft:air
setblock 412 66 -221 minecraft:air
fill 414 66 -221 415 66 -221 minecraft:air
setblock 392 66 -222 minecraft:air
setblock 394 66 -222 minecraft:air
fill 397 66 -222 398 66 -222 minecraft:air
setblock 400 66 -222 minecraft:air
setblock 403 66 -222 minecraft:air
setblock 408 66 -222 minecraft:air
fill 410 66 -222 415 66 -222 minecraft:air
setblock 395 66 -223 minecraft:air
fill 399 66 -223 400 66 -223 minecraft:air
fill 402 66 -223 403 66 -223 minecraft:air
setblock 408 66 -223 minecraft:air
fill 411 66 -223 412 66 -223 minecraft:air
setblock 414 66 -223 minecraft:air
fill 393 66 -224 395 66 -224 minecraft:air
setblock 397 66 -224 minecraft:air
fill 399 66 -224 402 66 -224 minecraft:air
fill 404 66 -224 405 66 -224 minecraft:air
setblock 407 66 -224 minecraft:air
setblock 410 66 -224 minecraft:air
fill 412 66 -224 413 66 -224 minecraft:air
setblock 395 66 -225 minecraft:air
setblock 399 66 -225 minecraft:grass_block[snowy=false]
setblock 400 66 -225 minecraft:air
setblock 402 66 -225 minecraft:air
fill 404 66 -225 407 66 -225 minecraft:air
fill 410 66 -225 411 66 -225 minecraft:air
setblock 394 66 -226 minecraft:air
setblock 396 66 -226 minecraft:air
fill 398 66 -226 399 66 -226 minecraft:air
fill 401 66 -226 402 66 -226 minecraft:air
setblock 407 66 -226 minecraft:air
fill 410 66 -226 412 66 -226 minecraft:air
setblock 414 66 -226 minecraft:air
setblock 392 66 -227 minecraft:air
fill 398 66 -227 399 66 -227 minecraft:air
fill 405 66 -227 407 66 -227 minecraft:air
setblock 411 66 -227 minecraft:air
setblock 414 66 -227 minecraft:air
fill 393 66 -228 394 66 -228 minecraft:air
setblock 400 66 -228 minecraft:air
fill 403 66 -228 405 66 -228 minecraft:air
setblock 408 66 -228 minecraft:air
setblock 410 66 -228 minecraft:air
setblock 412 66 -228 minecraft:air
setblock 393 66 -229 minecraft:air
setblock 395 66 -229 minecraft:air
fill 397 66 -229 399 66 -229 minecraft:air
fill 401 66 -229 402 66 -229 minecraft:air
setblock 404 66 -229 minecraft:air
fill 406 66 -229 409 66 -229 minecraft:air
fill 411 66 -229 412 66 -229 minecraft:air
setblock 414 66 -229 minecraft:air
setblock 392 66 -230 minecraft:air
fill 394 66 -230 397 66 -230 minecraft:air
fill 399 66 -230 406 66 -230 minecraft:air
fill 408 66 -230 410 66 -230 minecraft:air
fill 414 66 -230 415 66 -230 minecraft:air
setblock 392 66 -231 minecraft:air
fill 394 66 -231 397 66 -231 minecraft:air
fill 399 66 -231 401 66 -231 minecraft:air
setblock 404 66 -231 minecraft:air
fill 406 66 -231 408 66 -231 minecraft:air
fill 411 66 -231 412 66 -231 minecraft:air
fill 392 66 -232 393 66 -232 minecraft:air
fill 396 66 -232 401 66 -232 minecraft:air
setblock 404 66 -232 minecraft:air
setblock 407 66 -232 minecraft:air
fill 409 66 -232 410 66 -232 minecraft:air
fill 412 66 -232 413 66 -232 minecraft:air
fill 392 66 -233 393 66 -233 minecraft:air
setblock 395 66 -233 minecraft:air
fill 397 66 -233 398 66 -233 minecraft:air
fill 400 66 -233 401 66 -233 minecraft:air
setblock 403 66 -233 minecraft:air
fill 405 66 -233 406 66 -233 minecraft:air
fill 414 66 -233 415 66 -233 minecraft:air
setblock 392 66 -234 minecraft:air
setblock 399 66 -234 minecraft:air
fill 401 66 -234 402 66 -234 minecraft:air
setblock 404 66 -234 minecraft:air
setblock 406 66 -234 minecraft:air
fill 408 66 -234 409 66 -234 minecraft:air
setblock 411 66 -234 minecraft:air
setblock 413 66 -234 minecraft:air
setblock 415 66 -234 minecraft:air
setblock 412 66 -246 minecraft:air
fill 392 65 -191 422 65 -191 minecraft:air
fill 392 65 -192 422 65 -192 minecraft:air
fill 392 65 -193 422 65 -193 minecraft:air
fill 392 65 -194 422 65 -194 minecraft:air
fill 392 65 -195 422 65 -195 minecraft:air
fill 392 65 -196 422 65 -196 minecraft:air
fill 392 65 -197 422 65 -197 minecraft:air
fill 392 65 -198 422 65 -198 minecraft:air
fill 392 65 -199 422 65 -199 minecraft:air
fill 392 65 -200 422 65 -200 minecraft:air
fill 392 65 -201 422 65 -201 minecraft:air
fill 392 65 -202 422 65 -202 minecraft:air
fill 392 65 -203 422 65 -203 minecraft:air
fill 392 65 -204 422 65 -204 minecraft:air
fill 392 65 -205 422 65 -205 minecraft:air
fill 392 65 -206 422 65 -206 minecraft:air
fill 392 65 -207 422 65 -207 minecraft:air
fill 392 65 -208 422 65 -208 minecraft:air
fill 392 65 -209 422 65 -209 minecraft:air
fill 392 65 -210 422 65 -210 minecraft:air
fill 392 65 -211 422 65 -211 minecraft:air
fill 392 65 -212 407 65 -212 minecraft:air
fill 408 65 -212 410 65 -212 minecraft:gravel
fill 411 65 -212 422 65 -212 minecraft:air
fill 392 65 -213 407 65 -213 minecraft:air
fill 408 65 -213 410 65 -213 minecraft:gravel
fill 411 65 -213 422 65 -213 minecraft:air
fill 392 65 -214 407 65 -214 minecraft:air
fill 408 65 -214 410 65 -214 minecraft:gravel
fill 411 65 -214 422 65 -214 minecraft:air
fill 392 65 -215 407 65 -215 minecraft:air
fill 408 65 -215 410 65 -215 minecraft:gravel
fill 411 65 -215 422 65 -215 minecraft:air
fill 392 65 -216 407 65 -216 minecraft:air
fill 408 65 -216 410 65 -216 minecraft:gravel
fill 411 65 -216 422 65 -216 minecraft:air
fill 392 65 -217 406 65 -217 minecraft:air
fill 411 65 -217 422 65 -217 minecraft:air
fill 392 65 -218 405 65 -218 minecraft:air
fill 412 65 -218 422 65 -218 minecraft:air
fill 392 65 -219 401 65 -219 minecraft:air
fill 412 65 -219 421 65 -219 minecraft:air
setblock 422 65 -219 minecraft:grass_block[snowy=false]
fill 392 65 -220 398 65 -220 minecraft:air
fill 414 65 -220 420 65 -220 minecraft:air
fill 421 65 -220 422 65 -220 minecraft:grass_block[snowy=false]
fill 392 65 -221 398 65 -221 minecraft:air
fill 417 65 -221 422 65 -221 minecraft:grass_block[snowy=false]
fill 392 65 -222 398 65 -222 minecraft:air
fill 417 65 -222 422 65 -222 minecraft:grass_block[snowy=false]
fill 393 65 -223 398 65 -223 minecraft:air
fill 417 65 -223 422 65 -223 minecraft:grass_block[snowy=false]
fill 394 65 -224 398 65 -224 minecraft:air
fill 417 65 -224 422 65 -224 minecraft:grass_block[snowy=false]
fill 395 65 -225 398 65 -225 minecraft:air
setblock 399 65 -225 minecraft:dirt
fill 417 65 -225 422 65 -225 minecraft:grass_block[snowy=false]
setblock 396 65 -226 minecraft:air
fill 417 65 -226 422 65 -226 minecraft:grass_block[snowy=false]
fill 417 65 -227 422 65 -227 minecraft:grass_block[snowy=false]
fill 417 65 -228 422 65 -228 minecraft:grass_block[snowy=false]
fill 417 65 -229 422 65 -229 minecraft:grass_block[snowy=false]
fill 417 65 -230 422 65 -230 minecraft:grass_block[snowy=false]
fill 417 65 -231 422 65 -231 minecraft:grass_block[snowy=false]
fill 417 65 -232 422 65 -232 minecraft:grass_block[snowy=false]
fill 417 65 -233 422 65 -233 minecraft:grass_block[snowy=false]
fill 417 65 -234 422 65 -234 minecraft:grass_block[snowy=false]
fill 417 65 -235 422 65 -235 minecraft:grass_block[snowy=false]
fill 417 65 -236 422 65 -236 minecraft:grass_block[snowy=false]
fill 417 65 -237 422 65 -237 minecraft:grass_block[snowy=false]
fill 417 65 -238 422 65 -238 minecraft:grass_block[snowy=false]
fill 417 65 -239 422 65 -239 minecraft:grass_block[snowy=false]
fill 417 65 -240 422 65 -240 minecraft:grass_block[snowy=false]
fill 417 65 -241 422 65 -241 minecraft:grass_block[snowy=false]
fill 417 65 -242 422 65 -242 minecraft:grass_block[snowy=false]
fill 417 65 -243 422 65 -243 minecraft:grass_block[snowy=false]
fill 417 65 -244 422 65 -244 minecraft:grass_block[snowy=false]
fill 417 65 -245 422 65 -245 minecraft:grass_block[snowy=false]
fill 417 65 -246 422 65 -246 minecraft:grass_block[snowy=false]
fill 417 65 -247 422 65 -247 minecraft:grass_block[snowy=false]
fill 417 65 -248 422 65 -248 minecraft:grass_block[snowy=false]
fill 417 65 -249 422 65 -249 minecraft:grass_block[snowy=false]
fill 417 65 -250 422 65 -250 minecraft:grass_block[snowy=false]
fill 417 65 -251 422 65 -251 minecraft:grass_block[snowy=false]
fill 417 65 -252 422 65 -252 minecraft:grass_block[snowy=false]
fill 417 65 -253 422 65 -253 minecraft:grass_block[snowy=false]
fill 417 65 -254 422 65 -254 minecraft:grass_block[snowy=false]
fill 392 64 -191 422 64 -191 minecraft:air
fill 392 64 -192 422 64 -192 minecraft:air
fill 392 64 -193 422 64 -193 minecraft:air
fill 392 64 -194 422 64 -194 minecraft:air
fill 392 64 -195 422 64 -195 minecraft:air
fill 392 64 -196 422 64 -196 minecraft:air
fill 392 64 -197 422 64 -197 minecraft:air
fill 392 64 -198 422 64 -198 minecraft:air
fill 392 64 -199 422 64 -199 minecraft:air
fill 392 64 -200 422 64 -200 minecraft:air
fill 392 64 -201 422 64 -201 minecraft:air
fill 392 64 -202 422 64 -202 minecraft:air
fill 392 64 -203 422 64 -203 minecraft:air
fill 392 64 -204 422 64 -204 minecraft:air
fill 392 64 -205 422 64 -205 minecraft:air
fill 392 64 -206 422 64 -206 minecraft:air
fill 392 64 -207 422 64 -207 minecraft:air
fill 392 64 -208 422 64 -208 minecraft:air
fill 392 64 -209 422 64 -209 minecraft:air
fill 392 64 -210 422 64 -210 minecraft:air
fill 392 64 -211 422 64 -211 minecraft:air
fill 392 64 -212 407 64 -212 minecraft:air
fill 416 64 -212 417 64 -212 minecraft:air
fill 392 64 -213 406 64 -213 minecraft:air
fill 416 64 -213 418 64 -213 minecraft:air
fill 392 64 -214 406 64 -214 minecraft:air
fill 415 64 -214 419 64 -214 minecraft:air
fill 392 64 -215 406 64 -215 minecraft:air
fill 415 64 -215 419 64 -215 minecraft:air
fill 392 64 -216 405 64 -216 minecraft:air
fill 415 64 -216 419 64 -216 minecraft:air
fill 392 64 -217 403 64 -217 minecraft:air
fill 416 64 -217 417 64 -217 minecraft:air
fill 392 64 -218 400 64 -218 minecraft:air
fill 392 64 -219 399 64 -219 minecraft:air
fill 392 64 -220 398 64 -220 minecraft:air
fill 392 64 -221 398 64 -221 minecraft:air
fill 392 64 -222 398 64 -222 minecraft:air
fill 393 64 -223 398 64 -223 minecraft:air
fill 402 64 -223 403 64 -223 minecraft:air
fill 394 64 -224 398 64 -224 minecraft:air
fill 401 64 -224 403 64 -224 minecraft:air
fill 395 64 -225 398 64 -225 minecraft:air
setblock 396 64 -226 minecraft:air
setblock 392 64 -254 minecraft:air
fill 392 63 -191 422 63 -191 minecraft:air
fill 392 63 -192 422 63 -192 minecraft:air
fill 392 63 -193 422 63 -193 minecraft:air
fill 392 63 -194 422 63 -194 minecraft:air
fill 392 63 -195 422 63 -195 minecraft:air
fill 392 63 -196 422 63 -196 minecraft:air
fill 392 63 -197 422 63 -197 minecraft:air
fill 392 63 -198 422 63 -198 minecraft:air
fill 392 63 -199 422 63 -199 minecraft:air
fill 392 63 -200 422 63 -200 minecraft:air
fill 392 63 -201 422 63 -201 minecraft:air
fill 392 63 -202 422 63 -202 minecraft:air
fill 392 63 -203 422 63 -203 minecraft:air
fill 392 63 -204 422 63 -204 minecraft:air
fill 392 63 -205 422 63 -205 minecraft:air
fill 392 63 -206 422 63 -206 minecraft:air
fill 392 63 -207 422 63 -207 minecraft:air
fill 392 63 -208 422 63 -208 minecraft:air
fill 392 63 -209 422 63 -209 minecraft:air
fill 392 63 -210 414 63 -210 minecraft:air
fill 416 63 -210 421 63 -210 minecraft:air
fill 392 63 -211 407 63 -211 minecraft:air
fill 392 63 -212 406 63 -212 minecraft:air
fill 392 63 -213 406 63 -213 minecraft:air
fill 392 63 -214 405 63 -214 minecraft:air
fill 392 63 -215 405 63 -215 minecraft:air
fill 392 63 -216 403 63 -216 minecraft:air
fill 392 63 -217 402 63 -217 minecraft:air
fill 392 63 -218 399 63 -218 minecraft:air
fill 392 63 -219 399 63 -219 minecraft:air
fill 392 63 -220 398 63 -220 minecraft:air
fill 392 63 -221 398 63 -221 minecraft:air
fill 392 63 -222 398 63 -222 minecraft:air
fill 393 63 -223 398 63 -223 minecraft:air
fill 402 63 -223 403 63 -223 minecraft:air
fill 395 63 -224 398 63 -224 minecraft:air
fill 401 63 -224 403 63 -224 minecraft:air
fill 395 63 -225 397 63 -225 minecraft:air
fill 392 62 -191 422 62 -191 minecraft:water[level=0]
fill 392 62 -192 422 62 -192 minecraft:water[level=0]
fill 392 62 -193 397 62 -193 minecraft:water[level=0]
setblock 398 62 -193 minecraft:kelp[age=23]
fill 399 62 -193 416 62 -193 minecraft:water[level=0]
setblock 417 62 -193 minecraft:kelp[age=25]
fill 418 62 -193 422 62 -193 minecraft:water[level=0]
fill 392 62 -194 402 62 -194 minecraft:water[level=0]
setblock 403 62 -194 minecraft:kelp[age=21]
fill 404 62 -194 417 62 -194 minecraft:water[level=0]
setblock 418 62 -194 minecraft:kelp[age=22]
fill 419 62 -194 420 62 -194 minecraft:water[level=0]
setblock 421 62 -194 minecraft:kelp[age=22]
setblock 422 62 -194 minecraft:water[level=0]
fill 392 62 -195 418 62 -195 minecraft:water[level=0]
setblock 419 62 -195 minecraft:kelp[age=21]
fill 420 62 -195 422 62 -195 minecraft:water[level=0]
fill 392 62 -196 405 62 -196 minecraft:water[level=0]
setblock 406 62 -196 minecraft:kelp[age=24]
fill 407 62 -196 420 62 -196 minecraft:water[level=0]
setblock 421 62 -196 minecraft:kelp[age=23]
setblock 422 62 -196 minecraft:water[level=0]
fill 392 62 -197 407 62 -197 minecraft:water[level=0]
setblock 408 62 -197 minecraft:kelp[age=25]
fill 409 62 -197 411 62 -197 minecraft:water[level=0]
setblock 412 62 -197 minecraft:kelp[age=21]
fill 413 62 -197 422 62 -197 minecraft:water[level=0]
fill 392 62 -198 422 62 -198 minecraft:water[level=0]
fill 392 62 -199 399 62 -199 minecraft:water[level=0]
setblock 400 62 -199 minecraft:kelp[age=24]
fill 401 62 -199 420 62 -199 minecraft:water[level=0]
setblock 421 62 -199 minecraft:kelp[age=25]
setblock 422 62 -199 minecraft:kelp[age=23]
fill 392 62 -200 422 62 -200 minecraft:water[level=0]
fill 392 62 -201 414 62 -201 minecraft:water[level=0]
setblock 415 62 -201 minecraft:kelp[age=23]
fill 416 62 -201 420 62 -201 minecraft:water[level=0]
setblock 421 62 -201 minecraft:kelp[age=24]
setblock 422 62 -201 minecraft:water[level=0]
fill 392 62 -202 422 62 -202 minecraft:water[level=0]
fill 392 62 -203 400 62 -203 minecraft:water[level=0]
setblock 401 62 -203 minecraft:kelp[age=24]
fill 402 62 -203 419 62 -203 minecraft:water[level=0]
setblock 420 62 -203 minecraft:kelp[age=22]
fill 421 62 -203 422 62 -203 minecraft:water[level=0]
fill 392 62 -204 402 62 -204 minecraft:water[level=0]
setblock 403 62 -204 minecraft:kelp[age=22]
fill 404 62 -204 422 62 -204 minecraft:water[level=0]
fill 392 62 -205 421 62 -205 minecraft:water[level=0]
setblock 422 62 -205 minecraft:kelp[age=25]
fill 392 62 -206 422 62 -206 minecraft:water[level=0]
fill 392 62 -207 422 62 -207 minecraft:water[level=0]
fill 392 62 -208 421 62 -208 minecraft:water[level=0]
fill 392 62 -209 411 62 -209 minecraft:water[level=0]
setblock 414 62 -209 minecraft:water[level=0]
fill 416 62 -209 420 62 -209 minecraft:water[level=0]
fill 392 62 -210 410 62 -210 minecraft:water[level=0]
fill 392 62 -211 406 62 -211 minecraft:water[level=0]
fill 392 62 -212 404 62 -212 minecraft:water[level=0]
setblock 405 62 -212 minecraft:tall_seagrass[half=upper]
fill 392 62 -213 405 62 -213 minecraft:water[level=0]
fill 392 62 -214 404 62 -214 minecraft:water[level=0]
fill 392 62 -215 403 62 -215 minecraft:water[level=0]
fill 392 62 -216 402 62 -216 minecraft:water[level=0]
fill 392 62 -217 399 62 -217 minecraft:water[level=0]
setblock 401 62 -217 minecraft:water[level=0]
fill 392 62 -218 399 62 -218 minecraft:water[level=0]
fill 392 62 -219 398 62 -219 minecraft:water[level=0]
fill 392 62 -220 398 62 -220 minecraft:water[level=0]
fill 392 62 -221 398 62 -221 minecraft:water[level=0]
fill 392 62 -222 398 62 -222 minecraft:water[level=0]
fill 394 62 -223 398 62 -223 minecraft:water[level=0]
setblock 402 62 -223 minecraft:water[level=0]
fill 395 62 -224 398 62 -224 minecraft:water[level=0]
fill 401 62 -224 402 62 -224 minecraft:water[level=0]
fill 396 62 -225 397 62 -225 minecraft:water[level=0]
setblock 402 62 -225 minecraft:water[level=0]
fill 392 61 -191 418 61 -191 minecraft:water[level=0]
setblock 419 61 -191 minecraft:kelp[age=25]
fill 420 61 -191 422 61 -191 minecraft:water[level=0]
fill 392 61 -192 422 61 -192 minecraft:water[level=0]
fill 392 61 -193 397 61 -193 minecraft:water[level=0]
setblock 398 61 -193 minecraft:kelp_plant
fill 399 61 -193 416 61 -193 minecraft:water[level=0]
setblock 417 61 -193 minecraft:kelp_plant
fill 418 61 -193 422 61 -193 minecraft:water[level=0]
fill 392 61 -194 396 61 -194 minecraft:water[level=0]
setblock 397 61 -194 minecraft:kelp[age=25]
fill 398 61 -194 402 61 -194 minecraft:water[level=0]
setblock 403 61 -194 minecraft:kelp_plant
setblock 404 61 -194 minecraft:water[level=0]
setblock 405 61 -194 minecraft:kelp[age=25]
fill 406 61 -194 417 61 -194 minecraft:water[level=0]
setblock 418 61 -194 minecraft:kelp_plant
fill 419 61 -194 420 61 -194 minecraft:water[level=0]
setblock 421 61 -194 minecraft:kelp_plant
setblock 422 61 -194 minecraft:water[level=0]
fill 392 61 -195 418 61 -195 minecraft:water[level=0]
setblock 419 61 -195 minecraft:kelp_plant
fill 420 61 -195 422 61 -195 minecraft:water[level=0]
fill 392 61 -196 405 61 -196 minecraft:water[level=0]
setblock 406 61 -196 minecraft:kelp_plant
fill 407 61 -196 419 61 -196 minecraft:water[level=0]
setblock 420 61 -196 minecraft:kelp[age=25]
setblock 421 61 -196 minecraft:kelp_plant
setblock 422 61 -196 minecraft:water[level=0]
fill 392 61 -197 407 61 -197 minecraft:water[level=0]
setblock 408 61 -197 minecraft:kelp_plant
fill 409 61 -197 411 61 -197 minecraft:water[level=0]
setblock 412 61 -197 minecraft:kelp_plant
fill 413 61 -197 422 61 -197 minecraft:water[level=0]
fill 392 61 -198 422 61 -198 minecraft:water[level=0]
fill 392 61 -199 399 61 -199 minecraft:water[level=0]
setblock 400 61 -199 minecraft:kelp_plant
fill 401 61 -199 420 61 -199 minecraft:water[level=0]
fill 421 61 -199 422 61 -199 minecraft:kelp_plant
fill 392 61 -200 422 61 -200 minecraft:water[level=0]
fill 392 61 -201 414 61 -201 minecraft:water[level=0]
setblock 415 61 -201 minecraft:kelp_plant
fill 416 61 -201 420 61 -201 minecraft:water[level=0]
setblock 421 61 -201 minecraft:kelp_plant
setblock 422 61 -201 minecraft:water[level=0]
fill 392 61 -202 422 61 -202 minecraft:water[level=0]
fill 392 61 -203 400 61 -203 minecraft:water[level=0]
setblock 401 61 -203 minecraft:kelp_plant
fill 402 61 -203 415 61 -203 minecraft:water[level=0]
setblock 416 61 -203 minecraft:kelp[age=25]
fill 417 61 -203 419 61 -203 minecraft:water[level=0]
setblock 420 61 -203 minecraft:kelp_plant
fill 421 61 -203 422 61 -203 minecraft:water[level=0]
fill 392 61 -204 402 61 -204 minecraft:water[level=0]
setblock 403 61 -204 minecraft:kelp_plant
fill 404 61 -204 422 61 -204 minecraft:water[level=0]
fill 392 61 -205 421 61 -205 minecraft:water[level=0]
setblock 422 61 -205 minecraft:kelp_plant
fill 392 61 -206 422 61 -206 minecraft:water[level=0]
fill 392 61 -207 422 61 -207 minecraft:water[level=0]
fill 392 61 -208 412 61 -208 minecraft:water[level=0]
fill 414 61 -208 420 61 -208 minecraft:water[level=0]
fill 392 61 -209 411 61 -209 minecraft:water[level=0]
setblock 415 61 -209 minecraft:water[level=0]
setblock 417 61 -209 minecraft:water[level=0]
setblock 419 61 -209 minecraft:water[level=0]
fill 392 61 -210 408 61 -210 minecraft:water[level=0]
fill 392 61 -211 406 61 -211 minecraft:water[level=0]
fill 392 61 -212 404 61 -212 minecraft:water[level=0]
setblock 405 61 -212 minecraft:tall_seagrass[half=lower]
fill 392 61 -213 404 61 -213 minecraft:water[level=0]
fill 392 61 -214 403 61 -214 minecraft:water[level=0]
fill 392 61 -215 402 61 -215 minecraft:water[level=0]
fill 392 61 -216 401 61 -216 minecraft:water[level=0]
fill 392 61 -217 399 61 -217 minecraft:water[level=0]
fill 392 61 -218 398 61 -218 minecraft:water[level=0]
fill 392 61 -219 398 61 -219 minecraft:water[level=0]
fill 392 61 -220 397 61 -220 minecraft:water[level=0]
fill 392 61 -221 397 61 -221 minecraft:water[level=0]
fill 392 61 -222 397 61 -222 minecraft:water[level=0]
fill 394 61 -223 398 61 -223 minecraft:water[level=0]
setblock 396 61 -224 minecraft:water[level=0]
fill 401 61 -224 402 61 -224 minecraft:water[level=0]
setblock 396 61 -225 minecraft:water[level=0]
fill 401 61 -225 402 61 -225 minecraft:water[level=0]
fill 392 60 -191 393 60 -191 minecraft:water[level=0]
setblock 394 60 -191 minecraft:kelp[age=25]
fill 395 60 -191 418 60 -191 minecraft:water[level=0]
setblock 419 60 -191 minecraft:kelp_plant
fill 420 60 -191 422 60 -191 minecraft:water[level=0]
fill 392 60 -192 422 60 -192 minecraft:water[level=0]
fill 392 60 -193 397 60 -193 minecraft:water[level=0]
setblock 398 60 -193 minecraft:kelp_plant
fill 399 60 -193 416 60 -193 minecraft:water[level=0]
setblock 417 60 -193 minecraft:kelp_plant
fill 418 60 -193 422 60 -193 minecraft:water[level=0]
fill 392 60 -194 396 60 -194 minecraft:water[level=0]
setblock 397 60 -194 minecraft:kelp_plant
fill 398 60 -194 402 60 -194 minecraft:water[level=0]
setblock 403 60 -194 minecraft:kelp_plant
setblock 404 60 -194 minecraft:water[level=0]
setblock 405 60 -194 minecraft:kelp_plant
setblock 406 60 -194 minecraft:water[level=0]
setblock 407 60 -194 minecraft:kelp[age=25]
fill 408 60 -194 417 60 -194 minecraft:water[level=0]
setblock 418 60 -194 minecraft:kelp_plant
fill 419 60 -194 420 60 -194 minecraft:water[level=0]
setblock 421 60 -194 minecraft:kelp_plant
setblock 422 60 -194 minecraft:water[level=0]
fill 392 60 -195 418 60 -195 minecraft:water[level=0]
setblock 419 60 -195 minecraft:kelp_plant
fill 420 60 -195 422 60 -195 minecraft:water[level=0]
fill 392 60 -196 405 60 -196 minecraft:water[level=0]
setblock 406 60 -196 minecraft:kelp_plant
fill 407 60 -196 419 60 -196 minecraft:water[level=0]
fill 420 60 -196 421 60 -196 minecraft:kelp_plant
setblock 422 60 -196 minecraft:water[level=0]
fill 392 60 -197 407 60 -197 minecraft:water[level=0]
setblock 408 60 -197 minecraft:kelp_plant
fill 409 60 -197 411 60 -197 minecraft:water[level=0]
setblock 412 60 -197 minecraft:kelp_plant
fill 413 60 -197 422 60 -197 minecraft:water[level=0]
fill 392 60 -198 422 60 -198 minecraft:water[level=0]
fill 392 60 -199 399 60 -199 minecraft:water[level=0]
setblock 400 60 -199 minecraft:kelp_plant
fill 401 60 -199 420 60 -199 minecraft:water[level=0]
fill 421 60 -199 422 60 -199 minecraft:kelp_plant
fill 392 60 -200 422 60 -200 minecraft:water[level=0]
fill 392 60 -201 414 60 -201 minecraft:water[level=0]
setblock 415 60 -201 minecraft:kelp_plant
fill 416 60 -201 420 60 -201 minecraft:water[level=0]
setblock 421 60 -201 minecraft:kelp_plant
setblock 422 60 -201 minecraft:water[level=0]
fill 392 60 -202 413 60 -202 minecraft:water[level=0]
setblock 414 60 -202 minecraft:kelp[age=25]
fill 415 60 -202 416 60 -202 minecraft:water[level=0]
setblock 417 60 -202 minecraft:kelp[age=25]
fill 418 60 -202 422 60 -202 minecraft:water[level=0]
fill 392 60 -203 400 60 -203 minecraft:water[level=0]
setblock 401 60 -203 minecraft:kelp_plant
fill 402 60 -203 415 60 -203 minecraft:water[level=0]
setblock 416 60 -203 minecraft:kelp_plant
fill 417 60 -203 419 60 -203 minecraft:water[level=0]
setblock 420 60 -203 minecraft:kelp_plant
fill 421 60 -203 422 60 -203 minecraft:water[level=0]
fill 392 60 -204 402 60 -204 minecraft:water[level=0]
setblock 403 60 -204 minecraft:kelp_plant
fill 404 60 -204 422 60 -204 minecraft:water[level=0]
fill 392 60 -205 421 60 -205 minecraft:water[level=0]
setblock 422 60 -205 minecraft:kelp_plant
fill 392 60 -206 422 60 -206 minecraft:water[level=0]
fill 392 60 -207 421 60 -207 minecraft:water[level=0]
fill 392 60 -208 415 60 -208 minecraft:water[level=0]
fill 417 60 -208 420 60 -208 minecraft:water[level=0]
fill 392 60 -209 409 60 -209 minecraft:water[level=0]
fill 392 60 -210 407 60 -210 minecraft:water[level=0]
fill 392 60 -211 405 60 -211 minecraft:water[level=0]
fill 392 60 -212 404 60 -212 minecraft:water[level=0]
fill 392 60 -213 404 60 -213 minecraft:water[level=0]
fill 392 60 -214 402 60 -214 minecraft:water[level=0]
fill 392 60 -215 401 60 -215 minecraft:water[level=0]
fill 392 60 -216 400 60 -216 minecraft:water[level=0]
fill 392 60 -217 398 60 -217 minecraft:water[level=0]
fill 392 60 -218 398 60 -218 minecraft:water[level=0]
fill 392 60 -219 399 60 -219 minecraft:water[level=0]
fill 392 60 -220 397 60 -220 minecraft:water[level=0]
fill 392 60 -221 397 60 -221 minecraft:water[level=0]
fill 392 60 -222 397 60 -222 minecraft:water[level=0]
fill 395 60 -223 396 60 -223 minecraft:water[level=0]
fill 401 60 -225 402 60 -225 minecraft:water[level=0]
setblock 402 60 -226 minecraft:water[level=0]
setblock 417 60 -254 minecraft:air
fill 392 59 -191 393 59 -191 minecraft:water[level=0]
setblock 394 59 -191 minecraft:kelp_plant
fill 395 59 -191 418 59 -191 minecraft:water[level=0]
setblock 419 59 -191 minecraft:kelp_plant
fill 420 59 -191 422 59 -191 minecraft:water[level=0]
fill 392 59 -192 422 59 -192 minecraft:water[level=0]
fill 392 59 -193 397 59 -193 minecraft:water[level=0]
setblock 398 59 -193 minecraft:kelp_plant
fill 399 59 -193 416 59 -193 minecraft:water[level=0]
setblock 417 59 -193 minecraft:kelp_plant
fill 418 59 -193 422 59 -193 minecraft:water[level=0]
fill 392 59 -194 396 59 -194 minecraft:water[level=0]
setblock 397 59 -194 minecraft:kelp_plant
fill 398 59 -194 402 59 -194 minecraft:water[level=0]
setblock 403 59 -194 minecraft:kelp_plant
setblock 404 59 -194 minecraft:water[level=0]
setblock 405 59 -194 minecraft:kelp_plant
setblock 406 59 -194 minecraft:water[level=0]
setblock 407 59 -194 minecraft:kelp_plant
fill 408 59 -194 417 59 -194 minecraft:water[level=0]
setblock 418 59 -194 minecraft:kelp_plant
fill 419 59 -194 420 59 -194 minecraft:water[level=0]
setblock 421 59 -194 minecraft:kelp_plant
setblock 422 59 -194 minecraft:water[level=0]
fill 392 59 -195 416 59 -195 minecraft:water[level=0]
setblock 417 59 -195 minecraft:kelp[age=25]
setblock 418 59 -195 minecraft:water[level=0]
setblock 419 59 -195 minecraft:kelp_plant
fill 420 59 -195 422 59 -195 minecraft:water[level=0]
fill 392 59 -196 396 59 -196 minecraft:water[level=0]
setblock 397 59 -196 minecraft:kelp[age=25]
fill 398 59 -196 405 59 -196 minecraft:water[level=0]
setblock 406 59 -196 minecraft:kelp_plant
fill 407 59 -196 419 59 -196 minecraft:water[level=0]
fill 420 59 -196 421 59 -196 minecraft:kelp_plant
setblock 422 59 -196 minecraft:water[level=0]
fill 392 59 -197 407 59 -197 minecraft:water[level=0]
setblock 408 59 -197 minecraft:kelp_plant
fill 409 59 -197 411 59 -197 minecraft:water[level=0]
setblock 412 59 -197 minecraft:kelp_plant
fill 413 59 -197 422 59 -197 minecraft:water[level=0]
fill 392 59 -198 422 59 -198 minecraft:water[level=0]
fill 392 59 -199 399 59 -199 minecraft:water[level=0]
setblock 400 59 -199 minecraft:kelp_plant
fill 401 59 -199 420 59 -199 minecraft:water[level=0]
fill 421 59 -199 422 59 -199 minecraft:kelp_plant
fill 392 59 -200 406 59 -200 minecraft:water[level=0]
setblock 407 59 -200 minecraft:kelp[age=25]
fill 408 59 -200 422 59 -200 minecraft:water[level=0]
fill 392 59 -201 414 59 -201 minecraft:water[level=0]
setblock 415 59 -201 minecraft:kelp_plant
fill 416 59 -201 420 59 -201 minecraft:water[level=0]
setblock 421 59 -201 minecraft:kelp_plant
setblock 422 59 -201 minecraft:water[level=0]
fill 392 59 -202 413 59 -202 minecraft:water[level=0]
setblock 414 59 -202 minecraft:kelp_plant
fill 415 59 -202 416 59 -202 minecraft:water[level=0]
setblock 417 59 -202 minecraft:kelp_plant
fill 418 59 -202 422 59 -202 minecraft:water[level=0]
fill 392 59 -203 400 59 -203 minecraft:water[level=0]
setblock 401 59 -203 minecraft:kelp_plant
fill 402 59 -203 415 59 -203 minecraft:water[level=0]
setblock 416 59 -203 minecraft:kelp_plant
setblock 417 59 -203 minecraft:kelp[age=25]
fill 418 59 -203 419 59 -203 minecraft:water[level=0]
setblock 420 59 -203 minecraft:kelp_plant
fill 421 59 -203 422 59 -203 minecraft:water[level=0]
fill 392 59 -204 402 59 -204 minecraft:water[level=0]
setblock 403 59 -204 minecraft:kelp_plant
fill 404 59 -204 422 59 -204 minecraft:water[level=0]
fill 392 59 -205 421 59 -205 minecraft:water[level=0]
setblock 422 59 -205 minecraft:kelp_plant
fill 392 59 -206 422 59 -206 minecraft:water[level=0]
fill 392 59 -207 420 59 -207 minecraft:water[level=0]
fill 392 59 -208 411 59 -208 minecraft:water[level=0]
setblock 414 59 -208 minecraft:water[level=0]
fill 417 59 -208 419 59 -208 minecraft:water[level=0]
fill 392 59 -209 408 59 -209 minecraft:water[level=0]
fill 392 59 -210 406 59 -210 minecraft:water[level=0]
fill 392 59 -211 404 59 -211 minecraft:water[level=0]
fill 392 59 -212 404 59 -212 minecraft:water[level=0]
fill 392 59 -213 403 59 -213 minecraft:water[level=0]
fill 392 59 -214 402 59 -214 minecraft:water[level=0]
fill 392 59 -215 400 59 -215 minecraft:water[level=0]
fill 392 59 -216 399 59 -216 minecraft:water[level=0]
fill 392 59 -217 399 59 -217 minecraft:water[level=0]
fill 392 59 -218 399 59 -218 minecraft:water[level=0]
fill 392 59 -219 398 59 -219 minecraft:water[level=0]
fill 392 59 -220 397 59 -220 minecraft:water[level=0]
fill 392 59 -221 398 59 -221 minecraft:water[level=0]
fill 395 59 -222 396 59 -222 minecraft:water[level=0]
setblock 397 59 -223 minecraft:water[level=0]
fill 401 59 -225 402 59 -225 minecraft:water[level=0]
fill 401 59 -226 402 59 -226 minecraft:water[level=0]
fill 415 59 -254 416 59 -254 minecraft:air
fill 392 58 -191 393 58 -191 minecraft:water[level=0]
setblock 394 58 -191 minecraft:kelp_plant
fill 395 58 -191 418 58 -191 minecraft:water[level=0]
setblock 419 58 -191 minecraft:kelp_plant
fill 420 58 -191 422 58 -191 minecraft:water[level=0]
fill 392 58 -192 422 58 -192 minecraft:water[level=0]
fill 392 58 -193 397 58 -193 minecraft:water[level=0]
setblock 398 58 -193 minecraft:kelp_plant
fill 399 58 -193 411 58 -193 minecraft:water[level=0]
setblock 412 58 -193 minecraft:kelp[age=25]
fill 413 58 -193 416 58 -193 minecraft:water[level=0]
setblock 417 58 -193 minecraft:kelp_plant
fill 418 58 -193 422 58 -193 minecraft:water[level=0]
fill 392 58 -194 396 58 -194 minecraft:water[level=0]
setblock 397 58 -194 minecraft:kelp_plant
fill 398 58 -194 402 58 -194 minecraft:water[level=0]
setblock 403 58 -194 minecraft:kelp_plant
setblock 404 58 -194 minecraft:water[level=0]
setblock 405 58 -194 minecraft:kelp_plant
setblock 406 58 -194 minecraft:water[level=0]
setblock 407 58 -194 minecraft:kelp_plant
fill 408 58 -194 417 58 -194 minecraft:water[level=0]
setblock 418 58 -194 minecraft:kelp_plant
fill 419 58 -194 420 58 -194 minecraft:water[level=0]
setblock 421 58 -194 minecraft:kelp_plant
setblock 422 58 -194 minecraft:water[level=0]
fill 392 58 -195 416 58 -195 minecraft:water[level=0]
setblock 417 58 -195 minecraft:kelp_plant
setblock 418 58 -195 minecraft:water[level=0]
setblock 419 58 -195 minecraft:kelp_plant
fill 420 58 -195 422 58 -195 minecraft:water[level=0]
fill 392 58 -196 396 58 -196 minecraft:water[level=0]
setblock 397 58 -196 minecraft:kelp_plant
fill 398 58 -196 405 58 -196 minecraft:water[level=0]
setblock 406 58 -196 minecraft:kelp_plant
fill 407 58 -196 419 58 -196 minecraft:water[level=0]
fill 420 58 -196 421 58 -196 minecraft:kelp_plant
setblock 422 58 -196 minecraft:water[level=0]
fill 392 58 -197 407 58 -197 minecraft:water[level=0]
setblock 408 58 -197 minecraft:kelp_plant
fill 409 58 -197 411 58 -197 minecraft:water[level=0]
setblock 412 58 -197 minecraft:kelp_plant
fill 413 58 -197 422 58 -197 minecraft:water[level=0]
fill 392 58 -198 418 58 -198 minecraft:water[level=0]
setblock 419 58 -198 minecraft:kelp[age=25]
fill 420 58 -198 422 58 -198 minecraft:water[level=0]
fill 392 58 -199 399 58 -199 minecraft:water[level=0]
setblock 400 58 -199 minecraft:kelp_plant
fill 401 58 -199 420 58 -199 minecraft:water[level=0]
fill 421 58 -199 422 58 -199 minecraft:kelp_plant
fill 392 58 -200 406 58 -200 minecraft:water[level=0]
setblock 407 58 -200 minecraft:kelp_plant
fill 408 58 -200 422 58 -200 minecraft:water[level=0]
fill 392 58 -201 414 58 -201 minecraft:water[level=0]
setblock 415 58 -201 minecraft:kelp_plant
fill 416 58 -201 420 58 -201 minecraft:water[level=0]
setblock 421 58 -201 minecraft:kelp_plant
setblock 422 58 -201 minecraft:water[level=0]
fill 392 58 -202 413 58 -202 minecraft:water[level=0]
setblock 414 58 -202 minecraft:kelp_plant
fill 415 58 -202 416 58 -202 minecraft:water[level=0]
setblock 417 58 -202 minecraft:kelp_plant
fill 418 58 -202 422 58 -202 minecraft:water[level=0]
fill 392 58 -203 400 58 -203 minecraft:water[level=0]
setblock 401 58 -203 minecraft:kelp_plant
fill 402 58 -203 415 58 -203 minecraft:water[level=0]
fill 416 58 -203 417 58 -203 minecraft:kelp_plant
fill 418 58 -203 419 58 -203 minecraft:water[level=0]
setblock 420 58 -203 minecraft:kelp_plant
fill 421 58 -203 422 58 -203 minecraft:water[level=0]
fill 392 58 -204 402 58 -204 minecraft:water[level=0]
setblock 403 58 -204 minecraft:kelp_plant
fill 404 58 -204 422 58 -204 minecraft:water[level=0]
fill 392 58 -205 421 58 -205 minecraft:water[level=0]
setblock 422 58 -205 minecraft:kelp_plant
fill 392 58 -206 421 58 -206 minecraft:water[level=0]
fill 392 58 -207 411 58 -207 minecraft:water[level=0]
fill 413 58 -207 420 58 -207 minecraft:water[level=0]
fill 392 58 -208 410 58 -208 minecraft:water[level=0]
fill 415 58 -208 417 58 -208 minecraft:water[level=0]
fill 392 58 -209 407 58 -209 minecraft:water[level=0]
fill 392 58 -210 405 58 -210 minecraft:water[level=0]
fill 392 58 -211 404 58 -211 minecraft:water[level=0]
fill 392 58 -212 403 58 -212 minecraft:water[level=0]
fill 392 58 -213 402 58 -213 minecraft:water[level=0]
fill 392 58 -214 401 58 -214 minecraft:water[level=0]
fill 392 58 -215 400 58 -215 minecraft:water[level=0]
fill 392 58 -216 399 58 -216 minecraft:water[level=0]
fill 392 58 -217 399 58 -217 minecraft:water[level=0]
fill 392 58 -218 399 58 -218 minecraft:water[level=0]
fill 392 58 -219 398 58 -219 minecraft:water[level=0]
fill 392 58 -220 398 58 -220 minecraft:water[level=0]
fill 392 58 -221 393 58 -221 minecraft:water[level=0]
fill 395 58 -221 398 58 -221 minecraft:water[level=0]
setblock 396 58 -222 minecraft:water[level=0]
fill 401 58 -225 402 58 -225 minecraft:water[level=0]
fill 401 58 -226 402 58 -226 minecraft:water[level=0]
setblock 415 58 -253 minecraft:air
fill 413 58 -254 415 58 -254 minecraft:air
fill 392 57 -191 393 57 -191 minecraft:water[level=0]
setblock 394 57 -191 minecraft:kelp_plant
fill 395 57 -191 405 57 -191 minecraft:water[level=0]
fill 407 57 -191 418 57 -191 minecraft:water[level=0]
setblock 419 57 -191 minecraft:kelp_plant
fill 420 57 -191 422 57 -191 minecraft:water[level=0]
fill 392 57 -192 422 57 -192 minecraft:water[level=0]
fill 392 57 -193 397 57 -193 minecraft:water[level=0]
setblock 398 57 -193 minecraft:kelp_plant
fill 399 57 -193 411 57 -193 minecraft:water[level=0]
setblock 412 57 -193 minecraft:kelp_plant
fill 413 57 -193 416 57 -193 minecraft:water[level=0]
setblock 417 57 -193 minecraft:kelp_plant
fill 418 57 -193 422 57 -193 minecraft:water[level=0]
fill 392 57 -194 396 57 -194 minecraft:water[level=0]
setblock 397 57 -194 minecraft:kelp_plant
fill 398 57 -194 402 57 -194 minecraft:water[level=0]
setblock 403 57 -194 minecraft:kelp_plant
setblock 404 57 -194 minecraft:water[level=0]
setblock 405 57 -194 minecraft:kelp_plant
setblock 406 57 -194 minecraft:water[level=0]
setblock 407 57 -194 minecraft:kelp_plant
fill 408 57 -194 409 57 -194 minecraft:water[level=0]
setblock 410 57 -194 minecraft:kelp[age=25]
fill 411 57 -194 417 57 -194 minecraft:water[level=0]
setblock 418 57 -194 minecraft:kelp_plant
fill 419 57 -194 420 57 -194 minecraft:water[level=0]
setblock 421 57 -194 minecraft:kelp_plant
setblock 422 57 -194 minecraft:water[level=0]
fill 392 57 -195 416 57 -195 minecraft:water[level=0]
setblock 417 57 -195 minecraft:kelp_plant
setblock 418 57 -195 minecraft:water[level=0]
setblock 419 57 -195 minecraft:kelp_plant
fill 420 57 -195 422 57 -195 minecraft:water[level=0]
fill 392 57 -196 396 57 -196 minecraft:water[level=0]
setblock 397 57 -196 minecraft:kelp_plant
fill 398 57 -196 405 57 -196 minecraft:water[level=0]
setblock 406 57 -196 minecraft:kelp_plant
fill 407 57 -196 419 57 -196 minecraft:water[level=0]
fill 420 57 -196 421 57 -196 minecraft:kelp_plant
setblock 422 57 -196 minecraft:water[level=0]
fill 392 57 -197 407 57 -197 minecraft:water[level=0]
setblock 408 57 -197 minecraft:kelp_plant
fill 409 57 -197 411 57 -197 minecraft:water[level=0]
setblock 412 57 -197 minecraft:kelp_plant
fill 413 57 -197 422 57 -197 minecraft:water[level=0]
fill 392 57 -198 418 57 -198 minecraft:water[level=0]
setblock 419 57 -198 minecraft:kelp_plant
fill 420 57 -198 422 57 -198 minecraft:water[level=0]
fill 392 57 -199 399 57 -199 minecraft:water[level=0]
setblock 400 57 -199 minecraft:kelp_plant
fill 401 57 -199 420 57 -199 minecraft:water[level=0]
fill 421 57 -199 422 57 -199 minecraft:kelp_plant
fill 392 57 -200 406 57 -200 minecraft:water[level=0]
setblock 407 57 -200 minecraft:kelp_plant
fill 408 57 -200 422 57 -200 minecraft:water[level=0]
fill 392 57 -201 414 57 -201 minecraft:water[level=0]
setblock 415 57 -201 minecraft:kelp_plant
fill 416 57 -201 420 57 -201 minecraft:water[level=0]
setblock 421 57 -201 minecraft:kelp_plant
setblock 422 57 -201 minecraft:water[level=0]
fill 392 57 -202 413 57 -202 minecraft:water[level=0]
setblock 414 57 -202 minecraft:kelp_plant
fill 415 57 -202 416 57 -202 minecraft:water[level=0]
setblock 417 57 -202 minecraft:kelp_plant
fill 418 57 -202 422 57 -202 minecraft:water[level=0]
fill 392 57 -203 400 57 -203 minecraft:water[level=0]
setblock 401 57 -203 minecraft:kelp_plant
fill 402 57 -203 415 57 -203 minecraft:water[level=0]
fill 416 57 -203 417 57 -203 minecraft:kelp_plant
fill 418 57 -203 419 57 -203 minecraft:water[level=0]
setblock 420 57 -203 minecraft:kelp_plant
fill 421 57 -203 422 57 -203 minecraft:water[level=0]
fill 392 57 -204 402 57 -204 minecraft:water[level=0]
setblock 403 57 -204 minecraft:kelp_plant
fill 404 57 -204 416 57 -204 minecraft:water[level=0]
setblock 417 57 -204 minecraft:kelp[age=25]
fill 418 57 -204 422 57 -204 minecraft:water[level=0]
fill 392 57 -205 421 57 -205 minecraft:water[level=0]
setblock 422 57 -205 minecraft:kelp_plant
fill 392 57 -206 420 57 -206 minecraft:water[level=0]
fill 392 57 -207 410 57 -207 minecraft:water[level=0]
fill 415 57 -207 418 57 -207 minecraft:water[level=0]
fill 392 57 -208 394 57 -208 minecraft:water[level=0]
setblock 395 57 -208 minecraft:kelp[age=25]
fill 396 57 -208 409 57 -208 minecraft:water[level=0]
fill 392 57 -209 406 57 -209 minecraft:water[level=0]
fill 392 57 -210 404 57 -210 minecraft:water[level=0]
fill 392 57 -211 403 57 -211 minecraft:water[level=0]
fill 392 57 -212 402 57 -212 minecraft:water[level=0]
fill 392 57 -213 401 57 -213 minecraft:water[level=0]
fill 392 57 -214 400 57 -214 minecraft:water[level=0]
fill 392 57 -215 399 57 -215 minecraft:water[level=0]
fill 392 57 -216 399 57 -216 minecraft:water[level=0]
fill 392 57 -217 398 57 -217 minecraft:water[level=0]
fill 392 57 -218 398 57 -218 minecraft:water[level=0]
fill 392 57 -219 398 57 -219 minecraft:water[level=0]
fill 392 57 -220 398 57 -220 minecraft:water[level=0]
fill 392 57 -221 397 57 -221 minecraft:water[level=0]
setblock 396 57 -222 minecraft:water[level=0]
setblock 401 57 -225 minecraft:water[level=0]
fill 401 57 -226 402 57 -226 minecraft:water[level=0]
fill 401 57 -227 402 57 -227 minecraft:water[level=0]
fill 413 57 -253 414 57 -253 minecraft:air
fill 412 57 -254 415 57 -254 minecraft:air
fill 392 56 -191 393 56 -191 minecraft:water[level=0]
setblock 394 56 -191 minecraft:kelp_plant
fill 395 56 -191 404 56 -191 minecraft:water[level=0]
fill 407 56 -191 408 56 -191 minecraft:water[level=0]
fill 410 56 -191 418 56 -191 minecraft:water[level=0]
setblock 419 56 -191 minecraft:kelp_plant
fill 420 56 -191 422 56 -191 minecraft:water[level=0]
fill 392 56 -192 422 56 -192 minecraft:water[level=0]
fill 392 56 -193 397 56 -193 minecraft:water[level=0]
setblock 398 56 -193 minecraft:kelp_plant
fill 399 56 -193 411 56 -193 minecraft:water[level=0]
setblock 412 56 -193 minecraft:kelp_plant
fill 413 56 -193 416 56 -193 minecraft:water[level=0]
setblock 417 56 -193 minecraft:kelp_plant
fill 418 56 -193 422 56 -193 minecraft:water[level=0]
fill 392 56 -194 396 56 -194 minecraft:water[level=0]
setblock 397 56 -194 minecraft:kelp_plant
fill 398 56 -194 402 56 -194 minecraft:water[level=0]
setblock 403 56 -194 minecraft:kelp_plant
setblock 404 56 -194 minecraft:water[level=0]
setblock 405 56 -194 minecraft:kelp_plant
setblock 406 56 -194 minecraft:water[level=0]
setblock 407 56 -194 minecraft:kelp_plant
fill 408 56 -194 409 56 -194 minecraft:water[level=0]
setblock 410 56 -194 minecraft:kelp_plant
fill 411 56 -194 417 56 -194 minecraft:water[level=0]
setblock 418 56 -194 minecraft:kelp_plant
fill 419 56 -194 420 56 -194 minecraft:water[level=0]
setblock 421 56 -194 minecraft:kelp_plant
setblock 422 56 -194 minecraft:water[level=0]
fill 392 56 -195 416 56 -195 minecraft:water[level=0]
setblock 417 56 -195 minecraft:kelp_plant
setblock 418 56 -195 minecraft:water[level=0]
setblock 419 56 -195 minecraft:kelp_plant
fill 420 56 -195 422 56 -195 minecraft:water[level=0]
fill 392 56 -196 396 56 -196 minecraft:water[level=0]
setblock 397 56 -196 minecraft:kelp_plant
fill 398 56 -196 405 56 -196 minecraft:water[level=0]
setblock 406 56 -196 minecraft:kelp_plant
fill 407 56 -196 419 56 -196 minecraft:water[level=0]
fill 420 56 -196 421 56 -196 minecraft:kelp_plant
setblock 422 56 -196 minecraft:water[level=0]
fill 392 56 -197 407 56 -197 minecraft:water[level=0]
setblock 408 56 -197 minecraft:kelp_plant
fill 409 56 -197 411 56 -197 minecraft:water[level=0]
setblock 412 56 -197 minecraft:kelp_plant
fill 413 56 -197 422 56 -197 minecraft:water[level=0]
setblock 392 56 -198 minecraft:kelp[age=25]
fill 393 56 -198 418 56 -198 minecraft:water[level=0]
setblock 419 56 -198 minecraft:kelp_plant
fill 420 56 -198 422 56 -198 minecraft:water[level=0]
fill 392 56 -199 399 56 -199 minecraft:water[level=0]
setblock 400 56 -199 minecraft:kelp_plant
fill 401 56 -199 420 56 -199 minecraft:water[level=0]
fill 421 56 -199 422 56 -199 minecraft:kelp_plant
fill 392 56 -200 406 56 -200 minecraft:water[level=0]
setblock 407 56 -200 minecraft:kelp_plant
fill 408 56 -200 422 56 -200 minecraft:water[level=0]
fill 392 56 -201 414 56 -201 minecraft:water[level=0]
setblock 415 56 -201 minecraft:kelp_plant
fill 416 56 -201 420 56 -201 minecraft:water[level=0]
setblock 421 56 -201 minecraft:kelp_plant
setblock 422 56 -201 minecraft:water[level=0]
fill 392 56 -202 413 56 -202 minecraft:water[level=0]
setblock 414 56 -202 minecraft:kelp_plant
fill 415 56 -202 416 56 -202 minecraft:water[level=0]
setblock 417 56 -202 minecraft:kelp_plant
fill 418 56 -202 422 56 -202 minecraft:water[level=0]
fill 392 56 -203 400 56 -203 minecraft:water[level=0]
setblock 401 56 -203 minecraft:kelp_plant
fill 402 56 -203 415 56 -203 minecraft:water[level=0]
fill 416 56 -203 417 56 -203 minecraft:kelp_plant
fill 418 56 -203 419 56 -203 minecraft:water[level=0]
setblock 420 56 -203 minecraft:kelp_plant
fill 421 56 -203 422 56 -203 minecraft:water[level=0]
fill 392 56 -204 402 56 -204 minecraft:water[level=0]
setblock 403 56 -204 minecraft:kelp_plant
fill 404 56 -204 416 56 -204 minecraft:water[level=0]
setblock 417 56 -204 minecraft:kelp_plant
fill 418 56 -204 422 56 -204 minecraft:water[level=0]
fill 392 56 -205 421 56 -205 minecraft:water[level=0]
setblock 422 56 -205 minecraft:kelp_plant
fill 392 56 -206 411 56 -206 minecraft:water[level=0]
fill 413 56 -206 420 56 -206 minecraft:water[level=0]
fill 392 56 -207 394 56 -207 minecraft:water[level=0]
setblock 395 56 -207 minecraft:kelp[age=25]
fill 396 56 -207 409 56 -207 minecraft:water[level=0]
setblock 416 56 -207 minecraft:water[level=0]
fill 392 56 -208 394 56 -208 minecraft:water[level=0]
setblock 395 56 -208 minecraft:kelp_plant
fill 396 56 -208 408 56 -208 minecraft:water[level=0]
fill 392 56 -209 405 56 -209 minecraft:water[level=0]
fill 392 56 -210 404 56 -210 minecraft:water[level=0]
fill 392 56 -211 402 56 -211 minecraft:water[level=0]
fill 392 56 -212 401 56 -212 minecraft:water[level=0]
fill 392 56 -213 400 56 -213 minecraft:water[level=0]
fill 392 56 -214 400 56 -214 minecraft:water[level=0]
fill 392 56 -215 399 56 -215 minecraft:water[level=0]
fill 392 56 -216 398 56 -216 minecraft:water[level=0]
fill 392 56 -217 398 56 -217 minecraft:water[level=0]
fill 392 56 -218 398 56 -218 minecraft:water[level=0]
fill 392 56 -219 398 56 -219 minecraft:water[level=0]
fill 392 56 -220 398 56 -220 minecraft:water[level=0]
fill 394 56 -221 397 56 -221 minecraft:water[level=0]
fill 401 56 -226 402 56 -226 minecraft:water[level=0]
fill 401 56 -227 402 56 -227 minecraft:water[level=0]
setblock 413 56 -252 minecraft:air
fill 412 56 -253 413 56 -253 minecraft:air
fill 411 56 -254 414 56 -254 minecraft:air
fill 392 55 -191 393 55 -191 minecraft:water[level=0]
setblock 394 55 -191 minecraft:kelp_plant
fill 395 55 -191 403 55 -191 minecraft:water[level=0]
setblock 406 55 -191 minecraft:water[level=0]
setblock 408 55 -191 minecraft:water[level=0]
fill 410 55 -191 418 55 -191 minecraft:water[level=0]
setblock 419 55 -191 minecraft:kelp_plant
fill 420 55 -191 422 55 -191 minecraft:water[level=0]
fill 392 55 -192 422 55 -192 minecraft:water[level=0]
fill 392 55 -193 397 55 -193 minecraft:water[level=0]
setblock 398 55 -193 minecraft:kelp_plant
fill 399 55 -193 411 55 -193 minecraft:water[level=0]
setblock 412 55 -193 minecraft:kelp_plant
fill 413 55 -193 416 55 -193 minecraft:water[level=0]
setblock 417 55 -193 minecraft:kelp_plant
fill 418 55 -193 422 55 -193 minecraft:water[level=0]
fill 392 55 -194 396 55 -194 minecraft:water[level=0]
setblock 397 55 -194 minecraft:kelp_plant
fill 398 55 -194 402 55 -194 minecraft:water[level=0]
setblock 403 55 -194 minecraft:kelp_plant
setblock 404 55 -194 minecraft:water[level=0]
setblock 405 55 -194 minecraft:kelp_plant
setblock 406 55 -194 minecraft:water[level=0]
setblock 407 55 -194 minecraft:kelp_plant
fill 408 55 -194 409 55 -194 minecraft:water[level=0]
setblock 410 55 -194 minecraft:kelp_plant
fill 411 55 -194 417 55 -194 minecraft:water[level=0]
setblock 418 55 -194 minecraft:kelp_plant
fill 419 55 -194 420 55 -194 minecraft:water[level=0]
setblock 421 55 -194 minecraft:kelp_plant
setblock 422 55 -194 minecraft:water[level=0]
setblock 392 55 -195 minecraft:kelp[age=25]
fill 393 55 -195 416 55 -195 minecraft:water[level=0]
setblock 417 55 -195 minecraft:kelp_plant
setblock 418 55 -195 minecraft:water[level=0]
setblock 419 55 -195 minecraft:kelp_plant
fill 420 55 -195 422 55 -195 minecraft:water[level=0]
fill 392 55 -196 396 55 -196 minecraft:water[level=0]
setblock 397 55 -196 minecraft:kelp_plant
fill 398 55 -196 405 55 -196 minecraft:water[level=0]
setblock 406 55 -196 minecraft:kelp_plant
fill 407 55 -196 415 55 -196 minecraft:water[level=0]
setblock 416 55 -196 minecraft:kelp[age=25]
fill 417 55 -196 419 55 -196 minecraft:water[level=0]
fill 420 55 -196 421 55 -196 minecraft:kelp_plant
setblock 422 55 -196 minecraft:water[level=0]
fill 392 55 -197 407 55 -197 minecraft:water[level=0]
setblock 408 55 -197 minecraft:kelp_plant
fill 409 55 -197 411 55 -197 minecraft:water[level=0]
setblock 412 55 -197 minecraft:kelp_plant
fill 413 55 -197 422 55 -197 minecraft:water[level=0]
setblock 392 55 -198 minecraft:kelp_plant
fill 393 55 -198 418 55 -198 minecraft:water[level=0]
setblock 419 55 -198 minecraft:kelp_plant
fill 420 55 -198 422 55 -198 minecraft:water[level=0]
fill 392 55 -199 393 55 -199 minecraft:water[level=0]
setblock 394 55 -199 minecraft:kelp[age=25]
fill 395 55 -199 399 55 -199 minecraft:water[level=0]
setblock 400 55 -199 minecraft:kelp_plant
fill 401 55 -199 420 55 -199 minecraft:water[level=0]
fill 421 55 -199 422 55 -199 minecraft:kelp_plant
fill 392 55 -200 406 55 -200 minecraft:water[level=0]
setblock 407 55 -200 minecraft:kelp_plant
fill 408 55 -200 422 55 -200 minecraft:water[level=0]
fill 392 55 -201 404 55 -201 minecraft:water[level=0]
setblock 405 55 -201 minecraft:kelp[age=25]
fill 406 55 -201 414 55 -201 minecraft:water[level=0]
setblock 415 55 -201 minecraft:kelp_plant
fill 416 55 -201 420 55 -201 minecraft:water[level=0]
setblock 421 55 -201 minecraft:kelp_plant
setblock 422 55 -201 minecraft:water[level=0]
fill 392 55 -202 413 55 -202 minecraft:water[level=0]
setblock 414 55 -202 minecraft:kelp_plant
fill 415 55 -202 416 55 -202 minecraft:water[level=0]
setblock 417 55 -202 minecraft:kelp_plant
fill 418 55 -202 422 55 -202 minecraft:water[level=0]
fill 392 55 -203 400 55 -203 minecraft:water[level=0]
setblock 401 55 -203 minecraft:kelp_plant
fill 402 55 -203 415 55 -203 minecraft:water[level=0]
fill 416 55 -203 417 55 -203 minecraft:kelp_plant
fill 418 55 -203 419 55 -203 minecraft:water[level=0]
setblock 420 55 -203 minecraft:kelp_plant
fill 421 55 -203 422 55 -203 minecraft:water[level=0]
fill 392 55 -204 402 55 -204 minecraft:water[level=0]
setblock 403 55 -204 minecraft:kelp_plant
fill 404 55 -204 416 55 -204 minecraft:water[level=0]
setblock 417 55 -204 minecraft:kelp_plant
fill 418 55 -204 422 55 -204 minecraft:water[level=0]
fill 392 55 -205 421 55 -205 minecraft:water[level=0]
fill 392 55 -206 410 55 -206 minecraft:water[level=0]
setblock 416 55 -206 minecraft:water[level=0]
fill 392 55 -207 394 55 -207 minecraft:water[level=0]
setblock 395 55 -207 minecraft:kelp_plant
fill 396 55 -207 409 55 -207 minecraft:water[level=0]
fill 392 55 -208 394 55 -208 minecraft:water[level=0]
setblock 395 55 -208 minecraft:kelp_plant
fill 396 55 -208 408 55 -208 minecraft:water[level=0]
fill 392 55 -209 405 55 -209 minecraft:water[level=0]
fill 392 55 -210 403 55 -210 minecraft:water[level=0]
setblock 404 55 -210 minecraft:seagrass
fill 392 55 -211 402 55 -211 minecraft:water[level=0]
fill 392 55 -212 401 55 -212 minecraft:water[level=0]
fill 392 55 -213 401 55 -213 minecraft:water[level=0]
fill 392 55 -214 400 55 -214 minecraft:water[level=0]
fill 392 55 -215 399 55 -215 minecraft:water[level=0]
fill 392 55 -216 398 55 -216 minecraft:water[level=0]
fill 392 55 -217 398 55 -217 minecraft:water[level=0]
fill 392 55 -218 398 55 -218 minecraft:water[level=0]
fill 392 55 -219 398 55 -219 minecraft:water[level=0]
fill 392 55 -220 398 55 -220 minecraft:water[level=0]
fill 393 55 -221 398 55 -221 minecraft:water[level=0]
setblock 396 55 -222 minecraft:water[level=0]
setblock 401 55 -226 minecraft:water[level=0]
fill 401 55 -227 402 55 -227 minecraft:water[level=0]
fill 401 55 -228 402 55 -228 minecraft:water[level=0]
setblock 412 55 -252 minecraft:air
fill 411 55 -253 413 55 -253 minecraft:air
fill 411 55 -254 413 55 -254 minecraft:air
fill 392 54 -191 393 54 -191 minecraft:water[level=0]
setblock 394 54 -191 minecraft:kelp_plant
fill 395 54 -191 403 54 -191 minecraft:water[level=0]
setblock 406 54 -191 minecraft:water[level=0]
setblock 408 54 -191 minecraft:water[level=0]
fill 411 54 -191 418 54 -191 minecraft:water[level=0]
setblock 419 54 -191 minecraft:kelp_plant
fill 420 54 -191 422 54 -191 minecraft:water[level=0]
fill 392 54 -192 402 54 -192 minecraft:water[level=0]
fill 405 54 -192 422 54 -192 minecraft:water[level=0]
fill 392 54 -193 397 54 -193 minecraft:water[level=0]
setblock 398 54 -193 minecraft:kelp_plant
fill 399 54 -193 403 54 -193 minecraft:water[level=0]
fill 405 54 -193 411 54 -193 minecraft:water[level=0]
setblock 412 54 -193 minecraft:kelp_plant
fill 413 54 -193 416 54 -193 minecraft:water[level=0]
setblock 417 54 -193 minecraft:kelp_plant
fill 418 54 -193 422 54 -193 minecraft:water[level=0]
fill 392 54 -194 396 54 -194 minecraft:water[level=0]
setblock 397 54 -194 minecraft:kelp_plant
fill 398 54 -194 402 54 -194 minecraft:water[level=0]
setblock 403 54 -194 minecraft:kelp_plant
setblock 404 54 -194 minecraft:water[level=0]
setblock 405 54 -194 minecraft:kelp_plant
setblock 406 54 -194 minecraft:water[level=0]
setblock 407 54 -194 minecraft:kelp_plant
fill 408 54 -194 409 54 -194 minecraft:water[level=0]
setblock 410 54 -194 minecraft:kelp_plant
fill 411 54 -194 417 54 -194 minecraft:water[level=0]
setblock 418 54 -194 minecraft:kelp_plant
fill 419 54 -194 420 54 -194 minecraft:water[level=0]
setblock 421 54 -194 minecraft:kelp_plant
setblock 422 54 -194 minecraft:water[level=0]
setblock 392 54 -195 minecraft:kelp_plant
fill 393 54 -195 416 54 -195 minecraft:water[level=0]
setblock 417 54 -195 minecraft:kelp_plant
setblock 418 54 -195 minecraft:water[level=0]
setblock 419 54 -195 minecraft:kelp_plant
fill 420 54 -195 422 54 -195 minecraft:water[level=0]
fill 392 54 -196 396 54 -196 minecraft:water[level=0]
setblock 397 54 -196 minecraft:kelp_plant
fill 398 54 -196 405 54 -196 minecraft:water[level=0]
setblock 406 54 -196 minecraft:kelp_plant
fill 407 54 -196 415 54 -196 minecraft:water[level=0]
setblock 416 54 -196 minecraft:kelp_plant
fill 417 54 -196 419 54 -196 minecraft:water[level=0]
fill 420 54 -196 421 54 -196 minecraft:kelp_plant
setblock 422 54 -196 minecraft:water[level=0]
fill 392 54 -197 407 54 -197 minecraft:water[level=0]
setblock 408 54 -197 minecraft:kelp_plant
fill 409 54 -197 411 54 -197 minecraft:water[level=0]
setblock 412 54 -197 minecraft:kelp_plant
fill 413 54 -197 422 54 -197 minecraft:water[level=0]
setblock 392 54 -198 minecraft:kelp_plant
fill 393 54 -198 418 54 -198 minecraft:water[level=0]
setblock 419 54 -198 minecraft:kelp_plant
fill 420 54 -198 422 54 -198 minecraft:water[level=0]
fill 392 54 -199 393 54 -199 minecraft:water[level=0]
setblock 394 54 -199 minecraft:kelp_plant
fill 395 54 -199 399 54 -199 minecraft:water[level=0]
setblock 400 54 -199 minecraft:kelp_plant
fill 401 54 -199 420 54 -199 minecraft:water[level=0]
fill 421 54 -199 422 54 -199 minecraft:kelp_plant
fill 392 54 -200 406 54 -200 minecraft:water[level=0]
setblock 407 54 -200 minecraft:kelp_plant
fill 408 54 -200 422 54 -200 minecraft:water[level=0]
fill 392 54 -201 404 54 -201 minecraft:water[level=0]
setblock 405 54 -201 minecraft:kelp_plant
fill 406 54 -201 414 54 -201 minecraft:water[level=0]
setblock 415 54 -201 minecraft:kelp_plant
fill 416 54 -201 420 54 -201 minecraft:water[level=0]
setblock 421 54 -201 minecraft:kelp_plant
setblock 422 54 -201 minecraft:water[level=0]
fill 392 54 -202 413 54 -202 minecraft:water[level=0]
setblock 414 54 -202 minecraft:kelp_plant
fill 415 54 -202 416 54 -202 minecraft:water[level=0]
setblock 417 54 -202 minecraft:kelp_plant
fill 418 54 -202 422 54 -202 minecraft:water[level=0]
fill 392 54 -203 400 54 -203 minecraft:water[level=0]
setblock 401 54 -203 minecraft:kelp_plant
fill 402 54 -203 415 54 -203 minecraft:water[level=0]
fill 416 54 -203 417 54 -203 minecraft:kelp_plant
fill 418 54 -203 419 54 -203 minecraft:water[level=0]
setblock 420 54 -203 minecraft:kelp_plant
fill 421 54 -203 422 54 -203 minecraft:water[level=0]
fill 392 54 -204 396 54 -204 minecraft:water[level=0]
setblock 397 54 -204 minecraft:kelp[age=25]
fill 398 54 -204 402 54 -204 minecraft:water[level=0]
setblock 403 54 -204 minecraft:kelp_plant
fill 404 54 -204 416 54 -204 minecraft:water[level=0]
setblock 417 54 -204 minecraft:kelp_plant
fill 418 54 -204 422 54 -204 minecraft:water[level=0]
fill 392 54 -205 418 54 -205 minecraft:water[level=0]
fill 392 54 -206 409 54 -206 minecraft:water[level=0]
fill 392 54 -207 394 54 -207 minecraft:water[level=0]
setblock 395 54 -207 minecraft:kelp_plant
setblock 396 54 -207 minecraft:water[level=0]
setblock 397 54 -207 minecraft:kelp[age=25]
fill 398 54 -207 408 54 -207 minecraft:water[level=0]
fill 392 54 -208 394 54 -208 minecraft:water[level=0]
setblock 395 54 -208 minecraft:kelp_plant
fill 396 54 -208 407 54 -208 minecraft:water[level=0]
fill 392 54 -209 404 54 -209 minecraft:water[level=0]
fill 392 54 -210 403 54 -210 minecraft:water[level=0]
fill 392 54 -211 402 54 -211 minecraft:water[level=0]
fill 392 54 -212 402 54 -212 minecraft:water[level=0]
fill 392 54 -213 401 54 -213 minecraft:water[level=0]
fill 392 54 -214 400 54 -214 minecraft:water[level=0]
fill 392 54 -215 399 54 -215 minecraft:water[level=0]
fill 392 54 -216 399 54 -216 minecraft:water[level=0]
fill 392 54 -217 399 54 -217 minecraft:water[level=0]
fill 392 54 -218 399 54 -218 minecraft:water[level=0]
fill 392 54 -219 399 54 -219 minecraft:water[level=0]
fill 392 54 -220 399 54 -220 minecraft:water[level=0]
fill 393 54 -221 399 54 -221 minecraft:water[level=0]
fill 395 54 -222 398 54 -222 minecraft:water[level=0]
setblock 401 54 -227 minecraft:water[level=0]
fill 401 54 -228 402 54 -228 minecraft:water[level=0]
fill 401 54 -229 402 54 -229 minecraft:water[level=0]
setblock 411 54 -251 minecraft:air
fill 410 54 -252 412 54 -252 minecraft:air
fill 410 54 -253 412 54 -253 minecraft:air
fill 411 54 -254 412 54 -254 minecraft:air
fill 392 53 -191 393 53 -191 minecraft:water[level=0]
setblock 394 53 -191 minecraft:kelp_plant
fill 395 53 -191 399 53 -191 minecraft:water[level=0]
fill 402 53 -191 405 53 -191 minecraft:water[level=0]
setblock 407 53 -191 minecraft:water[level=0]
fill 411 53 -191 412 53 -191 minecraft:water[level=0]
setblock 415 53 -191 minecraft:water[level=0]
setblock 418 53 -191 minecraft:water[level=0]
setblock 419 53 -191 minecraft:kelp_plant
fill 420 53 -191 422 53 -191 minecraft:water[level=0]
fill 392 53 -192 403 53 -192 minecraft:water[level=0]
fill 405 53 -192 406 53 -192 minecraft:water[level=0]
fill 408 53 -192 414 53 -192 minecraft:water[level=0]
fill 418 53 -192 422 53 -192 minecraft:water[level=0]
fill 392 53 -193 397 53 -193 minecraft:water[level=0]
setblock 398 53 -193 minecraft:kelp_plant
fill 399 53 -193 403 53 -193 minecraft:water[level=0]
setblock 404 53 -193 minecraft:kelp[age=22]
fill 405 53 -193 411 53 -193 minecraft:water[level=0]
setblock 412 53 -193 minecraft:kelp_plant
fill 413 53 -193 414 53 -193 minecraft:water[level=0]
setblock 416 53 -193 minecraft:water[level=0]
setblock 417 53 -193 minecraft:kelp_plant
fill 418 53 -193 422 53 -193 minecraft:water[level=0]
fill 392 53 -194 396 53 -194 minecraft:water[level=0]
setblock 397 53 -194 minecraft:kelp_plant
fill 398 53 -194 402 53 -194 minecraft:water[level=0]
setblock 403 53 -194 minecraft:kelp_plant
setblock 404 53 -194 minecraft:water[level=0]
setblock 405 53 -194 minecraft:kelp_plant
setblock 406 53 -194 minecraft:water[level=0]
setblock 407 53 -194 minecraft:kelp_plant
fill 408 53 -194 409 53 -194 minecraft:water[level=0]
setblock 410 53 -194 minecraft:kelp_plant
fill 411 53 -194 417 53 -194 minecraft:water[level=0]
setblock 418 53 -194 minecraft:kelp_plant
fill 419 53 -194 420 53 -194 minecraft:water[level=0]
setblock 421 53 -194 minecraft:kelp_plant
setblock 422 53 -194 minecraft:water[level=0]
setblock 392 53 -195 minecraft:kelp_plant
fill 393 53 -195 416 53 -195 minecraft:water[level=0]
setblock 417 53 -195 minecraft:kelp_plant
setblock 418 53 -195 minecraft:water[level=0]
setblock 419 53 -195 minecraft:kelp_plant
fill 420 53 -195 422 53 -195 minecraft:water[level=0]
fill 392 53 -196 396 53 -196 minecraft:water[level=0]
setblock 397 53 -196 minecraft:kelp_plant
fill 398 53 -196 405 53 -196 minecraft:water[level=0]
setblock 406 53 -196 minecraft:kelp_plant
fill 407 53 -196 415 53 -196 minecraft:water[level=0]
setblock 416 53 -196 minecraft:kelp_plant
fill 417 53 -196 419 53 -196 minecraft:water[level=0]
fill 420 53 -196 421 53 -196 minecraft:kelp_plant
setblock 422 53 -196 minecraft:water[level=0]
fill 392 53 -197 407 53 -197 minecraft:water[level=0]
setblock 408 53 -197 minecraft:kelp_plant
fill 409 53 -197 411 53 -197 minecraft:water[level=0]
setblock 412 53 -197 minecraft:kelp_plant
fill 413 53 -197 422 53 -197 minecraft:water[level=0]
setblock 392 53 -198 minecraft:kelp_plant
fill 393 53 -198 418 53 -198 minecraft:water[level=0]
setblock 419 53 -198 minecraft:kelp_plant
fill 420 53 -198 422 53 -198 minecraft:water[level=0]
fill 392 53 -199 393 53 -199 minecraft:water[level=0]
setblock 394 53 -199 minecraft:kelp_plant
fill 395 53 -199 399 53 -199 minecraft:water[level=0]
setblock 400 53 -199 minecraft:kelp_plant
fill 401 53 -199 420 53 -199 minecraft:water[level=0]
fill 421 53 -199 422 53 -199 minecraft:kelp_plant
fill 392 53 -200 406 53 -200 minecraft:water[level=0]
setblock 407 53 -200 minecraft:kelp_plant
fill 408 53 -200 422 53 -200 minecraft:water[level=0]
fill 392 53 -201 404 53 -201 minecraft:water[level=0]
setblock 405 53 -201 minecraft:kelp_plant
fill 406 53 -201 414 53 -201 minecraft:water[level=0]
setblock 415 53 -201 minecraft:kelp_plant
fill 416 53 -201 420 53 -201 minecraft:water[level=0]
setblock 421 53 -201 minecraft:kelp_plant
setblock 422 53 -201 minecraft:water[level=0]
fill 392 53 -202 413 53 -202 minecraft:water[level=0]
setblock 414 53 -202 minecraft:kelp_plant
fill 415 53 -202 416 53 -202 minecraft:water[level=0]
setblock 417 53 -202 minecraft:kelp_plant
fill 418 53 -202 422 53 -202 minecraft:water[level=0]
fill 392 53 -203 400 53 -203 minecraft:water[level=0]
setblock 401 53 -203 minecraft:kelp_plant
fill 402 53 -203 415 53 -203 minecraft:water[level=0]
fill 416 53 -203 417 53 -203 minecraft:kelp_plant
fill 418 53 -203 419 53 -203 minecraft:water[level=0]
setblock 420 53 -203 minecraft:kelp_plant
fill 421 53 -203 422 53 -203 minecraft:water[level=0]
fill 392 53 -204 396 53 -204 minecraft:water[level=0]
setblock 397 53 -204 minecraft:kelp_plant
fill 398 53 -204 402 53 -204 minecraft:water[level=0]
setblock 403 53 -204 minecraft:kelp_plant
fill 404 53 -204 416 53 -204 minecraft:water[level=0]
setblock 417 53 -204 minecraft:kelp_plant
fill 418 53 -204 422 53 -204 minecraft:water[level=0]
fill 392 53 -205 410 53 -205 minecraft:water[level=0]
fill 392 53 -206 408 53 -206 minecraft:water[level=0]
fill 392 53 -207 394 53 -207 minecraft:water[level=0]
setblock 395 53 -207 minecraft:kelp_plant
setblock 396 53 -207 minecraft:water[level=0]
setblock 397 53 -207 minecraft:kelp_plant
fill 398 53 -207 406 53 -207 minecraft:water[level=0]
fill 392 53 -208 394 53 -208 minecraft:water[level=0]
setblock 395 53 -208 minecraft:kelp_plant
fill 396 53 -208 406 53 -208 minecraft:water[level=0]
fill 392 53 -209 404 53 -209 minecraft:water[level=0]
fill 392 53 -210 403 53 -210 minecraft:water[level=0]
fill 392 53 -211 402 53 -211 minecraft:water[level=0]
fill 392 53 -212 402 53 -212 minecraft:water[level=0]
fill 392 53 -213 401 53 -213 minecraft:water[level=0]
fill 392 53 -214 400 53 -214 minecraft:water[level=0]
fill 392 53 -215 400 53 -215 minecraft:water[level=0]
fill 392 53 -216 399 53 -216 minecraft:water[level=0]
fill 392 53 -217 399 53 -217 minecraft:water[level=0]
fill 392 53 -218 399 53 -218 minecraft:water[level=0]
fill 392 53 -219 399 53 -219 minecraft:water[level=0]
fill 392 53 -220 399 53 -220 minecraft:water[level=0]
fill 392 53 -221 399 53 -221 minecraft:water[level=0]
fill 394 53 -222 399 53 -222 minecraft:water[level=0]
fill 396 53 -223 398 53 -223 minecraft:water[level=0]
setblock 400 53 -227 minecraft:water[level=0]
fill 400 53 -228 401 53 -228 minecraft:water[level=0]
fill 400 53 -229 402 53 -229 minecraft:water[level=0]
fill 401 53 -230 402 53 -230 minecraft:water[level=0]
setblock 404 53 -232 minecraft:water[level=0]
fill 410 53 -251 411 53 -251 minecraft:air
fill 409 53 -252 411 53 -252 minecraft:air
fill 410 53 -253 411 53 -253 minecraft:air
fill 410 53 -254 411 53 -254 minecraft:air
fill 392 52 -191 393 52 -191 minecraft:water[level=0]
setblock 394 52 -191 minecraft:kelp_plant
fill 395 52 -191 398 52 -191 minecraft:water[level=0]
fill 403 52 -191 405 52 -191 minecraft:water[level=0]
setblock 419 52 -191 minecraft:kelp_plant
fill 420 52 -191 422 52 -191 minecraft:water[level=0]
fill 392 52 -192 400 52 -192 minecraft:water[level=0]
fill 402 52 -192 405 52 -192 minecraft:water[level=0]
setblock 418 52 -192 minecraft:water[level=0]
setblock 421 52 -192 minecraft:water[level=0]
fill 392 52 -193 397 52 -193 minecraft:water[level=0]
setblock 398 52 -193 minecraft:kelp_plant
setblock 399 52 -193 minecraft:water[level=0]
setblock 400 52 -193 minecraft:seagrass
fill 402 52 -193 403 52 -193 minecraft:water[level=0]
setblock 404 52 -193 minecraft:kelp_plant
fill 405 52 -193 411 52 -193 minecraft:water[level=0]
setblock 412 52 -193 minecraft:kelp_plant
fill 413 52 -193 414 52 -193 minecraft:water[level=0]
setblock 417 52 -193 minecraft:kelp_plant
fill 392 52 -194 396 52 -194 minecraft:water[level=0]
setblock 397 52 -194 minecraft:kelp_plant
fill 398 52 -194 400 52 -194 minecraft:water[level=0]
setblock 402 52 -194 minecraft:water[level=0]
setblock 403 52 -194 minecraft:kelp_plant
setblock 404 52 -194 minecraft:water[level=0]
setblock 405 52 -194 minecraft:kelp_plant
setblock 406 52 -194 minecraft:water[level=0]
setblock 407 52 -194 minecraft:kelp_plant
fill 408 52 -194 409 52 -194 minecraft:water[level=0]
setblock 410 52 -194 minecraft:kelp_plant
fill 411 52 -194 413 52 -194 minecraft:water[level=0]
fill 415 52 -194 417 52 -194 minecraft:water[level=0]
setblock 418 52 -194 minecraft:kelp_plant
fill 419 52 -194 420 52 -194 minecraft:water[level=0]
setblock 421 52 -194 minecraft:kelp_plant
setblock 392 52 -195 minecraft:kelp_plant
fill 393 52 -195 413 52 -195 minecraft:water[level=0]
fill 415 52 -195 416 52 -195 minecraft:water[level=0]
setblock 417 52 -195 minecraft:kelp_plant
setblock 418 52 -195 minecraft:water[level=0]
setblock 419 52 -195 minecraft:kelp_plant
setblock 420 52 -195 minecraft:water[level=0]
fill 392 52 -196 396 52 -196 minecraft:water[level=0]
setblock 397 52 -196 minecraft:kelp_plant
fill 398 52 -196 405 52 -196 minecraft:water[level=0]
setblock 406 52 -196 minecraft:kelp_plant
fill 407 52 -196 415 52 -196 minecraft:water[level=0]
setblock 416 52 -196 minecraft:kelp_plant
setblock 417 52 -196 minecraft:water[level=0]
fill 420 52 -196 421 52 -196 minecraft:kelp_plant
setblock 422 52 -196 minecraft:water[level=0]
fill 392 52 -197 407 52 -197 minecraft:water[level=0]
setblock 408 52 -197 minecraft:kelp_plant
fill 409 52 -197 411 52 -197 minecraft:water[level=0]
setblock 412 52 -197 minecraft:kelp_plant
fill 413 52 -197 415 52 -197 minecraft:water[level=0]
fill 418 52 -197 422 52 -197 minecraft:water[level=0]
setblock 392 52 -198 minecraft:kelp_plant
fill 393 52 -198 414 52 -198 minecraft:water[level=0]
fill 416 52 -198 418 52 -198 minecraft:water[level=0]
setblock 419 52 -198 minecraft:kelp_plant
fill 420 52 -198 422 52 -198 minecraft:water[level=0]
fill 392 52 -199 393 52 -199 minecraft:water[level=0]
setblock 394 52 -199 minecraft:kelp_plant
fill 395 52 -199 399 52 -199 minecraft:water[level=0]
setblock 400 52 -199 minecraft:kelp_plant
fill 401 52 -199 414 52 -199 minecraft:water[level=0]
fill 416 52 -199 420 52 -199 minecraft:water[level=0]
fill 421 52 -199 422 52 -199 minecraft:kelp_plant
fill 392 52 -200 394 52 -200 minecraft:water[level=0]
setblock 395 52 -200 minecraft:kelp[age=25]
fill 396 52 -200 406 52 -200 minecraft:water[level=0]
setblock 407 52 -200 minecraft:kelp_plant
fill 408 52 -200 422 52 -200 minecraft:water[level=0]
fill 392 52 -201 404 52 -201 minecraft:water[level=0]
setblock 405 52 -201 minecraft:kelp_plant
fill 406 52 -201 414 52 -201 minecraft:water[level=0]
setblock 415 52 -201 minecraft:kelp_plant
fill 416 52 -201 420 52 -201 minecraft:water[level=0]
setblock 421 52 -201 minecraft:kelp_plant
setblock 422 52 -201 minecraft:water[level=0]
fill 392 52 -202 413 52 -202 minecraft:water[level=0]
setblock 414 52 -202 minecraft:kelp_plant
fill 415 52 -202 416 52 -202 minecraft:water[level=0]
setblock 417 52 -202 minecraft:kelp_plant
fill 418 52 -202 422 52 -202 minecraft:water[level=0]
fill 392 52 -203 400 52 -203 minecraft:water[level=0]
setblock 401 52 -203 minecraft:kelp_plant
fill 402 52 -203 415 52 -203 minecraft:water[level=0]
fill 416 52 -203 417 52 -203 minecraft:kelp_plant
fill 418 52 -203 419 52 -203 minecraft:water[level=0]
setblock 420 52 -203 minecraft:kelp_plant
fill 421 52 -203 422 52 -203 minecraft:water[level=0]
fill 392 52 -204 396 52 -204 minecraft:water[level=0]
setblock 397 52 -204 minecraft:kelp_plant
fill 398 52 -204 402 52 -204 minecraft:water[level=0]
setblock 403 52 -204 minecraft:kelp_plant
fill 404 52 -204 416 52 -204 minecraft:water[level=0]
setblock 417 52 -204 minecraft:kelp_plant
fill 418 52 -204 422 52 -204 minecraft:water[level=0]
fill 392 52 -205 408 52 -205 minecraft:water[level=0]
fill 392 52 -206 406 52 -206 minecraft:water[level=0]
fill 392 52 -207 394 52 -207 minecraft:water[level=0]
setblock 395 52 -207 minecraft:kelp_plant
setblock 396 52 -207 minecraft:water[level=0]
setblock 397 52 -207 minecraft:kelp_plant
fill 398 52 -207 405 52 -207 minecraft:water[level=0]
fill 392 52 -208 394 52 -208 minecraft:water[level=0]
setblock 395 52 -208 minecraft:kelp_plant
fill 396 52 -208 403 52 -208 minecraft:water[level=0]
setblock 404 52 -208 minecraft:tall_seagrass[half=upper]
setblock 405 52 -208 minecraft:water[level=0]
fill 392 52 -209 404 52 -209 minecraft:water[level=0]
fill 392 52 -210 403 52 -210 minecraft:water[level=0]
fill 392 52 -211 402 52 -211 minecraft:water[level=0]
fill 392 52 -212 402 52 -212 minecraft:water[level=0]
fill 392 52 -213 401 52 -213 minecraft:water[level=0]
fill 392 52 -214 401 52 -214 minecraft:water[level=0]
fill 392 52 -215 400 52 -215 minecraft:water[level=0]
fill 392 52 -216 399 52 -216 minecraft:water[level=0]
fill 392 52 -217 399 52 -217 minecraft:water[level=0]
fill 392 52 -218 399 52 -218 minecraft:water[level=0]
fill 392 52 -219 399 52 -219 minecraft:water[level=0]
fill 392 52 -220 399 52 -220 minecraft:water[level=0]
fill 392 52 -221 400 52 -221 minecraft:water[level=0]
fill 393 52 -222 400 52 -222 minecraft:water[level=0]
fill 395 52 -223 400 52 -223 minecraft:water[level=0]
setblock 400 52 -224 minecraft:water[level=0]
fill 400 52 -225 401 52 -225 minecraft:water[level=0]
fill 400 52 -226 401 52 -226 minecraft:water[level=0]
fill 400 52 -227 401 52 -227 minecraft:water[level=0]
fill 400 52 -228 401 52 -228 minecraft:water[level=0]
fill 400 52 -229 402 52 -229 minecraft:water[level=0]
fill 400 52 -230 403 52 -230 minecraft:water[level=0]
fill 400 52 -231 404 52 -231 minecraft:water[level=0]
fill 402 52 -232 404 52 -232 minecraft:water[level=0]
fill 403 52 -233 404 52 -233 minecraft:water[level=0]
setblock 410 52 -250 minecraft:air
fill 409 52 -251 410 52 -251 minecraft:air
fill 409 52 -252 411 52 -252 minecraft:air
setblock 410 52 -253 minecraft:air
setblock 410 52 -254 minecraft:air
fill 392 51 -191 393 51 -191 minecraft:water[level=0]
setblock 394 51 -191 minecraft:kelp_plant
fill 395 51 -191 397 51 -191 minecraft:water[level=0]
fill 392 51 -192 397 51 -192 minecraft:water[level=0]
fill 392 51 -193 397 51 -193 minecraft:water[level=0]
setblock 398 51 -193 minecraft:kelp_plant
fill 392 51 -194 396 51 -194 minecraft:water[level=0]
setblock 397 51 -194 minecraft:kelp_plant
setblock 398 51 -194 minecraft:water[level=0]
setblock 392 51 -195 minecraft:kelp_plant
fill 393 51 -195 395 51 -195 minecraft:water[level=0]
setblock 396 51 -195 minecraft:kelp[age=25]
fill 397 51 -195 399 51 -195 minecraft:water[level=0]
fill 392 51 -196 396 51 -196 minecraft:water[level=0]
setblock 397 51 -196 minecraft:kelp_plant
fill 398 51 -196 399 51 -196 minecraft:water[level=0]
fill 392 51 -197 399 51 -197 minecraft:water[level=0]
setblock 407 51 -197 minecraft:water[level=0]
setblock 408 51 -197 minecraft:kelp_plant
setblock 392 51 -198 minecraft:kelp_plant
fill 393 51 -198 399 51 -198 minecraft:water[level=0]
fill 406 51 -198 409 51 -198 minecraft:water[level=0]
fill 392 51 -199 393 51 -199 minecraft:water[level=0]
setblock 394 51 -199 minecraft:kelp_plant
fill 395 51 -199 399 51 -199 minecraft:water[level=0]
fill 405 51 -199 410 51 -199 minecraft:water[level=0]
fill 392 51 -200 394 51 -200 minecraft:water[level=0]
setblock 395 51 -200 minecraft:kelp_plant
fill 396 51 -200 399 51 -200 minecraft:water[level=0]
fill 403 51 -200 406 51 -200 minecraft:water[level=0]
setblock 407 51 -200 minecraft:kelp_plant
fill 408 51 -200 411 51 -200 minecraft:water[level=0]
fill 392 51 -201 404 51 -201 minecraft:water[level=0]
setblock 405 51 -201 minecraft:kelp_plant
fill 406 51 -201 411 51 -201 minecraft:water[level=0]
fill 392 51 -202 412 51 -202 minecraft:water[level=0]
fill 392 51 -203 400 51 -203 minecraft:water[level=0]
setblock 401 51 -203 minecraft:kelp_plant
fill 402 51 -203 412 51 -203 minecraft:water[level=0]
fill 392 51 -204 396 51 -204 minecraft:water[level=0]
setblock 397 51 -204 minecraft:kelp_plant
fill 398 51 -204 402 51 -204 minecraft:water[level=0]
setblock 403 51 -204 minecraft:kelp_plant
fill 404 51 -204 413 51 -204 minecraft:water[level=0]
fill 392 51 -205 402 51 -205 minecraft:water[level=0]
setblock 403 51 -205 minecraft:seagrass
setblock 404 51 -205 minecraft:water[level=0]
fill 392 51 -206 404 51 -206 minecraft:water[level=0]
fill 392 51 -207 394 51 -207 minecraft:water[level=0]
setblock 395 51 -207 minecraft:kelp_plant
setblock 396 51 -207 minecraft:water[level=0]
setblock 397 51 -207 minecraft:kelp_plant
fill 398 51 -207 404 51 -207 minecraft:water[level=0]
fill 392 51 -208 394 51 -208 minecraft:water[level=0]
setblock 395 51 -208 minecraft:kelp_plant
fill 396 51 -208 403 51 -208 minecraft:water[level=0]
setblock 404 51 -208 minecraft:tall_seagrass[half=lower]
fill 392 51 -209 403 51 -209 minecraft:water[level=0]
fill 392 51 -210 403 51 -210 minecraft:water[level=0]
fill 392 51 -211 402 51 -211 minecraft:water[level=0]
fill 392 51 -212 402 51 -212 minecraft:water[level=0]
fill 392 51 -213 402 51 -213 minecraft:water[level=0]
fill 392 51 -214 401 51 -214 minecraft:water[level=0]
fill 392 51 -215 400 51 -215 minecraft:water[level=0]
fill 392 51 -216 399 51 -216 minecraft:water[level=0]
fill 392 51 -217 400 51 -217 minecraft:water[level=0]
fill 392 51 -218 400 51 -218 minecraft:water[level=0]
fill 392 51 -219 400 51 -219 minecraft:water[level=0]
fill 392 51 -220 401 51 -220 minecraft:water[level=0]
fill 392 51 -221 401 51 -221 minecraft:water[level=0]
fill 393 51 -222 401 51 -222 minecraft:water[level=0]
fill 394 51 -223 402 51 -223 minecraft:water[level=0]
fill 397 51 -224 402 51 -224 minecraft:water[level=0]
fill 399 51 -225 402 51 -225 minecraft:water[level=0]
fill 400 51 -226 402 51 -226 minecraft:water[level=0]
fill 400 51 -227 402 51 -227 minecraft:water[level=0]
fill 400 51 -228 403 51 -228 minecraft:water[level=0]
fill 400 51 -229 403 51 -229 minecraft:water[level=0]
fill 400 51 -230 404 51 -230 minecraft:water[level=0]
fill 400 51 -231 404 51 -231 minecraft:water[level=0]
fill 400 51 -232 405 51 -232 minecraft:water[level=0]
fill 401 51 -233 405 51 -233 minecraft:water[level=0]
fill 403 51 -234 404 51 -234 minecraft:water[level=0]
setblock 404 51 -235 minecraft:water[level=0]
setblock 409 51 -249 minecraft:air
fill 408 51 -250 410 51 -250 minecraft:air
fill 408 51 -251 410 51 -251 minecraft:air
fill 409 51 -252 410 51 -252 minecraft:air
setblock 409 51 -253 minecraft:air
fill 392 50 -191 393 50 -191 minecraft:water[level=0]
setblock 394 50 -191 minecraft:kelp_plant
fill 395 50 -191 397 50 -191 minecraft:water[level=0]
fill 392 50 -192 397 50 -192 minecraft:water[level=0]
fill 392 50 -193 397 50 -193 minecraft:water[level=0]
setblock 398 50 -193 minecraft:kelp_plant
fill 392 50 -194 396 50 -194 minecraft:water[level=0]
setblock 397 50 -194 minecraft:kelp_plant
setblock 392 50 -195 minecraft:kelp_plant
fill 393 50 -195 395 50 -195 minecraft:water[level=0]
setblock 396 50 -195 minecraft:kelp_plant
fill 397 50 -195 398 50 -195 minecraft:water[level=0]
fill 392 50 -196 396 50 -196 minecraft:water[level=0]
setblock 397 50 -196 minecraft:kelp_plant
setblock 398 50 -196 minecraft:water[level=0]
fill 392 50 -197 398 50 -197 minecraft:water[level=0]
setblock 392 50 -198 minecraft:kelp_plant
fill 393 50 -198 399 50 -198 minecraft:water[level=0]
fill 392 50 -199 393 50 -199 minecraft:water[level=0]
setblock 394 50 -199 minecraft:kelp_plant
fill 395 50 -199 399 50 -199 minecraft:water[level=0]
fill 392 50 -200 394 50 -200 minecraft:water[level=0]
setblock 395 50 -200 minecraft:kelp_plant
fill 396 50 -200 399 50 -200 minecraft:water[level=0]
fill 392 50 -201 399 50 -201 minecraft:water[level=0]
fill 392 50 -202 399 50 -202 minecraft:water[level=0]
fill 392 50 -203 400 50 -203 minecraft:water[level=0]
fill 392 50 -204 396 50 -204 minecraft:water[level=0]
setblock 397 50 -204 minecraft:kelp_plant
fill 398 50 -204 401 50 -204 minecraft:water[level=0]
fill 392 50 -205 402 50 -205 minecraft:water[level=0]
fill 392 50 -206 402 50 -206 minecraft:water[level=0]
fill 392 50 -207 394 50 -207 minecraft:water[level=0]
setblock 395 50 -207 minecraft:kelp_plant
setblock 396 50 -207 minecraft:water[level=0]
setblock 397 50 -207 minecraft:kelp_plant
fill 398 50 -207 403 50 -207 minecraft:water[level=0]
fill 392 50 -208 394 50 -208 minecraft:water[level=0]
setblock 395 50 -208 minecraft:kelp_plant
fill 396 50 -208 403 50 -208 minecraft:water[level=0]
fill 392 50 -209 403 50 -209 minecraft:water[level=0]
fill 392 50 -210 402 50 -210 minecraft:water[level=0]
fill 392 50 -211 402 50 -211 minecraft:water[level=0]
fill 392 50 -212 402 50 -212 minecraft:water[level=0]
fill 392 50 -213 402 50 -213 minecraft:water[level=0]
fill 392 50 -214 402 50 -214 minecraft:water[level=0]
fill 392 50 -215 401 50 -215 minecraft:water[level=0]
fill 392 50 -216 400 50 -216 minecraft:water[level=0]
fill 392 50 -217 400 50 -217 minecraft:water[level=0]
fill 392 50 -218 401 50 -218 minecraft:water[level=0]
fill 392 50 -219 401 50 -219 minecraft:water[level=0]
fill 392 50 -220 402 50 -220 minecraft:water[level=0]
fill 392 50 -221 402 50 -221 minecraft:water[level=0]
fill 392 50 -222 403 50 -222 minecraft:water[level=0]
fill 393 50 -223 403 50 -223 minecraft:water[level=0]
fill 396 50 -224 403 50 -224 minecraft:water[level=0]
setblock 398 50 -225 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=true,west=true]
fill 399 50 -225 403 50 -225 minecraft:water[level=0]
fill 399 50 -226 403 50 -226 minecraft:water[level=0]
fill 399 50 -227 403 50 -227 minecraft:water[level=0]
fill 400 50 -228 404 50 -228 minecraft:water[level=0]
fill 400 50 -229 404 50 -229 minecraft:water[level=0]
fill 400 50 -230 404 50 -230 minecraft:water[level=0]
fill 399 50 -231 405 50 -231 minecraft:water[level=0]
fill 398 50 -232 405 50 -232 minecraft:water[level=0]
fill 399 50 -233 405 50 -233 minecraft:water[level=0]
fill 400 50 -234 405 50 -234 minecraft:water[level=0]
fill 402 50 -235 405 50 -235 minecraft:water[level=0]
fill 403 50 -236 406 50 -236 minecraft:water[level=0]
setblock 404 50 -237 minecraft:water[level=0]
setblock 408 50 -248 minecraft:air
fill 408 50 -249 409 50 -249 minecraft:air
fill 408 50 -250 409 50 -250 minecraft:air
fill 408 50 -251 409 50 -251 minecraft:air
setblock 409 50 -252 minecraft:air
fill 392 49 -191 393 49 -191 minecraft:water[level=0]
setblock 394 49 -191 minecraft:kelp_plant
fill 395 49 -191 396 49 -191 minecraft:water[level=0]
setblock 397 49 -191 minecraft:seagrass
fill 392 49 -192 397 49 -192 minecraft:water[level=0]
fill 392 49 -193 397 49 -193 minecraft:water[level=0]
fill 392 49 -194 396 49 -194 minecraft:water[level=0]
setblock 397 49 -194 minecraft:kelp_plant
setblock 392 49 -195 minecraft:kelp_plant
fill 393 49 -195 395 49 -195 minecraft:water[level=0]
setblock 396 49 -195 minecraft:kelp_plant
fill 397 49 -195 398 49 -195 minecraft:water[level=0]
fill 392 49 -196 396 49 -196 minecraft:water[level=0]
setblock 397 49 -196 minecraft:kelp_plant
setblock 398 49 -196 minecraft:water[level=0]
fill 392 49 -197 398 49 -197 minecraft:water[level=0]
setblock 392 49 -198 minecraft:kelp_plant
fill 393 49 -198 398 49 -198 minecraft:water[level=0]
fill 392 49 -199 393 49 -199 minecraft:water[level=0]
setblock 394 49 -199 minecraft:kelp_plant
fill 395 49 -199 398 49 -199 minecraft:water[level=0]
fill 392 49 -200 394 49 -200 minecraft:water[level=0]
setblock 395 49 -200 minecraft:kelp_plant
fill 396 49 -200 399 49 -200 minecraft:water[level=0]
fill 392 49 -201 399 49 -201 minecraft:water[level=0]
fill 392 49 -202 399 49 -202 minecraft:water[level=0]
fill 392 49 -203 399 49 -203 minecraft:water[level=0]
fill 392 49 -204 396 49 -204 minecraft:water[level=0]
setblock 397 49 -204 minecraft:kelp_plant
setblock 398 49 -204 minecraft:water[level=0]
setblock 399 49 -204 minecraft:tall_seagrass[half=upper]
fill 392 49 -205 399 49 -205 minecraft:water[level=0]
setblock 400 49 -205 minecraft:seagrass
fill 392 49 -206 401 49 -206 minecraft:water[level=0]
fill 392 49 -207 394 49 -207 minecraft:water[level=0]
setblock 395 49 -207 minecraft:kelp_plant
setblock 396 49 -207 minecraft:water[level=0]
setblock 397 49 -207 minecraft:kelp_plant
fill 398 49 -207 399 49 -207 minecraft:water[level=0]
setblock 400 49 -207 minecraft:tall_seagrass[half=upper]
setblock 401 49 -207 minecraft:water[level=0]
fill 392 49 -208 394 49 -208 minecraft:water[level=0]
setblock 395 49 -208 minecraft:kelp_plant
fill 396 49 -208 401 49 -208 minecraft:water[level=0]
setblock 402 49 -208 minecraft:seagrass
fill 392 49 -209 402 49 -209 minecraft:water[level=0]
fill 392 49 -210 402 49 -210 minecraft:water[level=0]
fill 392 49 -211 402 49 -211 minecraft:water[level=0]
fill 392 49 -212 403 49 -212 minecraft:water[level=0]
fill 392 49 -213 402 49 -213 minecraft:water[level=0]
fill 392 49 -214 402 49 -214 minecraft:water[level=0]
fill 392 49 -215 402 49 -215 minecraft:water[level=0]
fill 392 49 -216 401 49 -216 minecraft:water[level=0]
fill 392 49 -217 402 49 -217 minecraft:water[level=0]
fill 392 49 -218 402 49 -218 minecraft:water[level=0]
fill 392 49 -219 403 49 -219 minecraft:water[level=0]
fill 392 49 -220 403 49 -220 minecraft:water[level=0]
fill 392 49 -221 403 49 -221 minecraft:water[level=0]
fill 392 49 -222 403 49 -222 minecraft:water[level=0]
fill 392 49 -223 404 49 -223 minecraft:water[level=0]
fill 394 49 -224 404 49 -224 minecraft:water[level=0]
fill 397 49 -225 404 49 -225 minecraft:water[level=0]
fill 398 49 -226 404 49 -226 minecraft:water[level=0]
fill 399 49 -227 404 49 -227 minecraft:water[level=0]
fill 399 49 -228 404 49 -228 minecraft:water[level=0]
fill 399 49 -229 405 49 -229 minecraft:water[level=0]
fill 399 49 -230 405 49 -230 minecraft:water[level=0]
fill 399 49 -231 405 49 -231 minecraft:water[level=0]
fill 397 49 -232 406 49 -232 minecraft:water[level=0]
fill 398 49 -233 406 49 -233 minecraft:water[level=0]
fill 399 49 -234 406 49 -234 minecraft:water[level=0]
fill 400 49 -235 407 49 -235 minecraft:water[level=0]
fill 401 49 -236 408 49 -236 minecraft:water[level=0]
fill 402 49 -237 408 49 -237 minecraft:water[level=0]
fill 404 49 -238 408 49 -238 minecraft:water[level=0]
fill 407 49 -239 408 49 -239 minecraft:water[level=0]
fill 407 49 -240 408 49 -240 minecraft:water[level=0]
setblock 408 49 -247 minecraft:air
fill 407 49 -248 408 49 -248 minecraft:air
fill 407 49 -249 409 49 -249 minecraft:air
setblock 408 49 -250 minecraft:air
setblock 408 49 -251 minecraft:air
setblock 408 49 -252 minecraft:air
fill 392 48 -191 393 48 -191 minecraft:water[level=0]
setblock 394 48 -191 minecraft:kelp_plant
fill 395 48 -191 396 48 -191 minecraft:seagrass
fill 392 48 -192 397 48 -192 minecraft:water[level=0]
fill 392 48 -193 396 48 -193 minecraft:water[level=0]
setblock 397 48 -193 minecraft:seagrass
fill 392 48 -194 396 48 -194 minecraft:water[level=0]
setblock 397 48 -194 minecraft:kelp_plant
setblock 392 48 -195 minecraft:kelp_plant
fill 393 48 -195 395 48 -195 minecraft:water[level=0]
setblock 396 48 -195 minecraft:kelp_plant
setblock 397 48 -195 minecraft:water[level=0]
fill 392 48 -196 396 48 -196 minecraft:water[level=0]
setblock 397 48 -196 minecraft:kelp_plant
setblock 398 48 -196 minecraft:water[level=0]
fill 392 48 -197 398 48 -197 minecraft:water[level=0]
setblock 392 48 -198 minecraft:kelp_plant
fill 393 48 -198 398 48 -198 minecraft:water[level=0]
fill 392 48 -199 393 48 -199 minecraft:water[level=0]
setblock 394 48 -199 minecraft:kelp_plant
fill 395 48 -199 398 48 -199 minecraft:water[level=0]
fill 392 48 -200 394 48 -200 minecraft:water[level=0]
setblock 395 48 -200 minecraft:kelp_plant
fill 396 48 -200 398 48 -200 minecraft:water[level=0]
fill 392 48 -201 399 48 -201 minecraft:water[level=0]
fill 392 48 -202 398 48 -202 minecraft:water[level=0]
setblock 399 48 -202 minecraft:seagrass
fill 392 48 -203 399 48 -203 minecraft:water[level=0]
fill 392 48 -204 396 48 -204 minecraft:water[level=0]
setblock 397 48 -204 minecraft:kelp_plant
setblock 398 48 -204 minecraft:water[level=0]
setblock 399 48 -204 minecraft:tall_seagrass[half=lower]
fill 392 48 -205 399 48 -205 minecraft:water[level=0]
fill 392 48 -206 400 48 -206 minecraft:water[level=0]
fill 392 48 -207 394 48 -207 minecraft:water[level=0]
setblock 395 48 -207 minecraft:kelp_plant
setblock 396 48 -207 minecraft:water[level=0]
setblock 397 48 -207 minecraft:kelp_plant
fill 398 48 -207 399 48 -207 minecraft:water[level=0]
setblock 400 48 -207 minecraft:tall_seagrass[half=lower]
setblock 401 48 -207 minecraft:water[level=0]
fill 392 48 -208 394 48 -208 minecraft:water[level=0]
setblock 395 48 -208 minecraft:kelp_plant
fill 396 48 -208 401 48 -208 minecraft:water[level=0]
fill 392 48 -209 402 48 -209 minecraft:water[level=0]
fill 392 48 -210 402 48 -210 minecraft:water[level=0]
fill 392 48 -211 403 48 -211 minecraft:water[level=0]
fill 392 48 -212 403 48 -212 minecraft:water[level=0]
setblock 392 48 -213 minecraft:tall_seagrass[half=upper]
fill 393 48 -213 403 48 -213 minecraft:water[level=0]
setblock 392 48 -214 minecraft:tall_seagrass[half=upper]
fill 393 48 -214 403 48 -214 minecraft:water[level=0]
fill 392 48 -215 403 48 -215 minecraft:water[level=0]
fill 392 48 -216 403 48 -216 minecraft:water[level=0]
fill 392 48 -217 404 48 -217 minecraft:water[level=0]
fill 392 48 -218 404 48 -218 minecraft:water[level=0]
fill 392 48 -219 404 48 -219 minecraft:water[level=0]
fill 392 48 -220 404 48 -220 minecraft:water[level=0]
fill 392 48 -221 404 48 -221 minecraft:water[level=0]
fill 392 48 -222 404 48 -222 minecraft:water[level=0]
fill 392 48 -223 404 48 -223 minecraft:water[level=0]
fill 392 48 -224 404 48 -224 minecraft:water[level=0]
fill 392 48 -225 405 48 -225 minecraft:water[level=0]
fill 398 48 -226 405 48 -226 minecraft:water[level=0]
fill 399 48 -227 405 48 -227 minecraft:water[level=0]
fill 399 48 -228 405 48 -228 minecraft:water[level=0]
fill 399 48 -229 405 48 -229 minecraft:water[level=0]
fill 399 48 -230 406 48 -230 minecraft:water[level=0]
fill 398 48 -231 406 48 -231 minecraft:water[level=0]
fill 396 48 -232 406 48 -232 minecraft:water[level=0]
fill 396 48 -233 407 48 -233 minecraft:water[level=0]
fill 397 48 -234 407 48 -234 minecraft:water[level=0]
fill 398 48 -235 408 48 -235 minecraft:water[level=0]
fill 399 48 -236 408 48 -236 minecraft:water[level=0]
fill 401 48 -237 408 48 -237 minecraft:water[level=0]
fill 402 48 -238 409 48 -238 minecraft:water[level=0]
fill 404 48 -239 408 48 -239 minecraft:water[level=0]
fill 405 48 -240 407 48 -240 minecraft:water[level=0]
setblock 407 48 -245 minecraft:air
setblock 407 48 -246 minecraft:air
fill 406 48 -247 407 48 -247 minecraft:air
fill 407 48 -248 408 48 -248 minecraft:air
fill 407 48 -249 408 48 -249 minecraft:air
fill 407 48 -250 408 48 -250 minecraft:air
setblock 396 47 -192 minecraft:seagrass
fill 394 47 -193 396 47 -193 minecraft:water[level=0]
fill 392 47 -194 396 47 -194 minecraft:water[level=0]
setblock 392 47 -195 minecraft:kelp_plant
fill 393 47 -195 395 47 -195 minecraft:water[level=0]
setblock 396 47 -195 minecraft:kelp_plant
fill 392 47 -196 396 47 -196 minecraft:water[level=0]
setblock 397 47 -196 minecraft:kelp_plant
fill 392 47 -197 397 47 -197 minecraft:water[level=0]
setblock 392 47 -198 minecraft:kelp_plant
fill 393 47 -198 397 47 -198 minecraft:water[level=0]
fill 392 47 -199 393 47 -199 minecraft:water[level=0]
setblock 394 47 -199 minecraft:kelp_plant
fill 395 47 -199 397 47 -199 minecraft:water[level=0]
fill 392 47 -200 394 47 -200 minecraft:water[level=0]
setblock 395 47 -200 minecraft:kelp_plant
fill 396 47 -200 398 47 -200 minecraft:water[level=0]
fill 392 47 -201 398 47 -201 minecraft:water[level=0]
fill 392 47 -202 396 47 -202 minecraft:water[level=0]
setblock 397 47 -202 minecraft:tall_seagrass[half=upper]
setblock 398 47 -202 minecraft:seagrass
fill 392 47 -203 398 47 -203 minecraft:water[level=0]
fill 392 47 -204 396 47 -204 minecraft:water[level=0]
setblock 397 47 -204 minecraft:kelp_plant
setblock 398 47 -204 minecraft:water[level=0]
fill 392 47 -205 398 47 -205 minecraft:water[level=0]
setblock 399 47 -205 minecraft:seagrass
fill 392 47 -206 399 47 -206 minecraft:water[level=0]
fill 392 47 -207 394 47 -207 minecraft:water[level=0]
setblock 395 47 -207 minecraft:kelp_plant
setblock 396 47 -207 minecraft:water[level=0]
setblock 397 47 -207 minecraft:kelp_plant
setblock 398 47 -207 minecraft:water[level=0]
setblock 399 47 -207 minecraft:seagrass
fill 392 47 -208 394 47 -208 minecraft:water[level=0]
setblock 395 47 -208 minecraft:kelp_plant
fill 396 47 -208 399 47 -208 minecraft:water[level=0]
setblock 400 47 -208 minecraft:seagrass
fill 392 47 -209 401 47 -209 minecraft:water[level=0]
setblock 392 47 -210 minecraft:seagrass
fill 393 47 -210 401 47 -210 minecraft:water[level=0]
fill 392 47 -211 402 47 -211 minecraft:water[level=0]
fill 392 47 -212 402 47 -212 minecraft:water[level=0]
setblock 392 47 -213 minecraft:tall_seagrass[half=lower]
fill 393 47 -213 402 47 -213 minecraft:water[level=0]
setblock 392 47 -214 minecraft:tall_seagrass[half=lower]
fill 393 47 -214 403 47 -214 minecraft:water[level=0]
fill 392 47 -215 403 47 -215 minecraft:water[level=0]
fill 392 47 -216 403 47 -216 minecraft:water[level=0]
fill 392 47 -217 403 47 -217 minecraft:water[level=0]
fill 392 47 -218 403 47 -218 minecraft:water[level=0]
fill 392 47 -219 403 47 -219 minecraft:water[level=0]
fill 392 47 -220 403 47 -220 minecraft:water[level=0]
fill 392 47 -221 404 47 -221 minecraft:water[level=0]
fill 392 47 -222 404 47 -222 minecraft:water[level=0]
fill 392 47 -223 404 47 -223 minecraft:water[level=0]
fill 393 47 -224 404 47 -224 minecraft:water[level=0]
fill 395 47 -225 404 47 -225 minecraft:water[level=0]
fill 398 47 -226 405 47 -226 minecraft:water[level=0]
fill 399 47 -227 405 47 -227 minecraft:water[level=0]
fill 399 47 -228 405 47 -228 minecraft:water[level=0]
fill 399 47 -229 405 47 -229 minecraft:water[level=0]
fill 399 47 -230 406 47 -230 minecraft:water[level=0]
fill 398 47 -231 406 47 -231 minecraft:water[level=0]
fill 396 47 -232 406 47 -232 minecraft:water[level=0]
fill 397 47 -233 407 47 -233 minecraft:water[level=0]
fill 398 47 -234 407 47 -234 minecraft:water[level=0]
fill 399 47 -235 408 47 -235 minecraft:water[level=0]
fill 400 47 -236 408 47 -236 minecraft:water[level=0]
fill 401 47 -237 408 47 -237 minecraft:water[level=0]
fill 402 47 -238 407 47 -238 minecraft:water[level=0]
fill 403 47 -239 406 47 -239 minecraft:water[level=0]
setblock 404 47 -240 minecraft:water[level=0]
fill 408 47 -241 410 47 -241 minecraft:air
fill 408 47 -242 410 47 -242 minecraft:air
setblock 406 47 -243 minecraft:air
fill 411 47 -243 412 47 -243 minecraft:air
setblock 406 47 -244 minecraft:air
fill 411 47 -244 412 47 -244 minecraft:air
fill 406 47 -245 407 47 -245 minecraft:air
fill 406 47 -246 407 47 -246 minecraft:air
fill 406 47 -247 408 47 -247 minecraft:air
fill 407 47 -248 408 47 -248 minecraft:air
setblock 407 47 -249 minecraft:air
setblock 407 47 -250 minecraft:air
fill 408 47 -252 409 47 -252 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 408 47 -253 409 47 -253 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 396 46 -195 minecraft:kelp_plant
fill 395 46 -196 396 46 -196 minecraft:water[level=0]
fill 394 46 -197 396 46 -197 minecraft:water[level=0]
fill 394 46 -198 396 46 -198 minecraft:water[level=0]
setblock 393 46 -199 minecraft:water[level=0]
setblock 394 46 -199 minecraft:kelp_plant
fill 395 46 -199 397 46 -199 minecraft:water[level=0]
fill 392 46 -200 394 46 -200 minecraft:water[level=0]
setblock 395 46 -200 minecraft:kelp_plant
fill 396 46 -200 397 46 -200 minecraft:water[level=0]
fill 392 46 -201 396 46 -201 minecraft:water[level=0]
setblock 397 46 -201 minecraft:seagrass
fill 392 46 -202 396 46 -202 minecraft:water[level=0]
setblock 397 46 -202 minecraft:tall_seagrass[half=lower]
fill 392 46 -203 397 46 -203 minecraft:water[level=0]
setblock 392 46 -204 minecraft:seagrass
fill 393 46 -204 396 46 -204 minecraft:water[level=0]
setblock 397 46 -204 minecraft:kelp_plant
setblock 398 46 -204 minecraft:water[level=0]
fill 392 46 -205 397 46 -205 minecraft:water[level=0]
setblock 398 46 -205 minecraft:seagrass
setblock 392 46 -206 minecraft:water[level=0]
setblock 393 46 -206 minecraft:seagrass
fill 394 46 -206 398 46 -206 minecraft:water[level=0]
fill 392 46 -207 394 46 -207 minecraft:water[level=0]
setblock 395 46 -207 minecraft:kelp_plant
setblock 396 46 -207 minecraft:water[level=0]
setblock 397 46 -207 minecraft:kelp_plant
setblock 398 46 -207 minecraft:water[level=0]
fill 392 46 -208 394 46 -208 minecraft:water[level=0]
setblock 395 46 -208 minecraft:kelp_plant
fill 396 46 -208 399 46 -208 minecraft:water[level=0]
setblock 392 46 -209 minecraft:seagrass
fill 393 46 -209 399 46 -209 minecraft:water[level=0]
fill 393 46 -210 398 46 -210 minecraft:water[level=0]
setblock 399 46 -210 minecraft:tall_seagrass[half=upper]
setblock 400 46 -210 minecraft:water[level=0]
fill 393 46 -211 401 46 -211 minecraft:water[level=0]
fill 393 46 -212 402 46 -212 minecraft:water[level=0]
fill 393 46 -213 402 46 -213 minecraft:water[level=0]
fill 393 46 -214 402 46 -214 minecraft:water[level=0]
fill 393 46 -215 402 46 -215 minecraft:water[level=0]
fill 392 46 -216 402 46 -216 minecraft:water[level=0]
fill 392 46 -217 402 46 -217 minecraft:water[level=0]
fill 392 46 -218 403 46 -218 minecraft:water[level=0]
fill 392 46 -219 403 46 -219 minecraft:water[level=0]
fill 392 46 -220 403 46 -220 minecraft:water[level=0]
fill 392 46 -221 403 46 -221 minecraft:water[level=0]
fill 392 46 -222 403 46 -222 minecraft:water[level=0]
fill 392 46 -223 404 46 -223 minecraft:water[level=0]
fill 393 46 -224 404 46 -224 minecraft:water[level=0]
fill 397 46 -225 404 46 -225 minecraft:water[level=0]
fill 398 46 -226 404 46 -226 minecraft:water[level=0]
fill 399 46 -227 405 46 -227 minecraft:water[level=0]
fill 399 46 -228 405 46 -228 minecraft:water[level=0]
fill 399 46 -229 405 46 -229 minecraft:water[level=0]
fill 399 46 -230 406 46 -230 minecraft:water[level=0]
fill 399 46 -231 406 46 -231 minecraft:water[level=0]
fill 397 46 -232 407 46 -232 minecraft:water[level=0]
fill 398 46 -233 407 46 -233 minecraft:water[level=0]
fill 399 46 -234 408 46 -234 minecraft:water[level=0]
fill 399 46 -235 408 46 -235 minecraft:water[level=0]
fill 400 46 -236 408 46 -236 minecraft:water[level=0]
fill 401 46 -237 406 46 -237 minecraft:water[level=0]
fill 402 46 -238 404 46 -238 minecraft:water[level=0]
setblock 403 46 -239 minecraft:water[level=0]
setblock 409 46 -239 minecraft:air
fill 407 46 -240 410 46 -240 minecraft:air
fill 405 46 -241 411 46 -241 minecraft:air
fill 405 46 -242 412 46 -242 minecraft:air
fill 405 46 -243 406 46 -243 minecraft:air
fill 408 46 -243 412 46 -243 minecraft:air
fill 405 46 -244 407 46 -244 minecraft:air
fill 409 46 -244 413 46 -244 minecraft:air
fill 406 46 -245 407 46 -245 minecraft:air
fill 411 46 -245 412 46 -245 minecraft:air
fill 406 46 -246 407 46 -246 minecraft:air
setblock 412 46 -246 minecraft:air
fill 406 46 -247 407 46 -247 minecraft:air
setblock 407 46 -248 minecraft:air
setblock 407 46 -249 minecraft:air
fill 408 46 -252 409 46 -252 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 408 46 -253 409 46 -253 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 392 45 -192 394 45 -192 minecraft:water[level=0]
fill 392 45 -193 395 45 -193 minecraft:water[level=0]
fill 392 45 -194 395 45 -194 minecraft:water[level=0]
fill 392 45 -195 394 45 -195 minecraft:water[level=0]
fill 392 45 -196 394 45 -196 minecraft:water[level=0]
fill 392 45 -197 394 45 -197 minecraft:water[level=0]
fill 392 45 -198 394 45 -198 minecraft:water[level=0]
fill 392 45 -199 393 45 -199 minecraft:water[level=0]
setblock 394 45 -199 minecraft:kelp_plant
setblock 396 45 -199 minecraft:water[level=0]
fill 392 45 -200 393 45 -200 minecraft:water[level=0]
setblock 395 45 -200 minecraft:kelp_plant
setblock 396 45 -200 minecraft:water[level=0]
fill 392 45 -201 393 45 -201 minecraft:water[level=0]
fill 395 45 -201 396 45 -201 minecraft:water[level=0]
fill 392 45 -202 393 45 -202 minecraft:water[level=0]
fill 395 45 -202 396 45 -202 minecraft:water[level=0]
setblock 392 45 -203 minecraft:water[level=0]
fill 394 45 -203 397 45 -203 minecraft:water[level=0]
fill 394 45 -204 396 45 -204 minecraft:water[level=0]
setblock 397 45 -204 minecraft:kelp_plant
fill 394 45 -205 397 45 -205 minecraft:water[level=0]
fill 394 45 -206 397 45 -206 minecraft:water[level=0]
setblock 394 45 -207 minecraft:seagrass
setblock 395 45 -207 minecraft:kelp_plant
setblock 396 45 -207 minecraft:water[level=0]
setblock 397 45 -207 minecraft:kelp_plant
setblock 398 45 -207 minecraft:water[level=0]
setblock 394 45 -208 minecraft:seagrass
setblock 395 45 -208 minecraft:kelp_plant
fill 396 45 -208 398 45 -208 minecraft:water[level=0]
fill 394 45 -209 397 45 -209 minecraft:water[level=0]
setblock 398 45 -209 minecraft:seagrass
fill 394 45 -210 398 45 -210 minecraft:water[level=0]
setblock 399 45 -210 minecraft:tall_seagrass[half=lower]
setblock 394 45 -211 minecraft:seagrass
fill 395 45 -211 399 45 -211 minecraft:water[level=0]
fill 394 45 -212 400 45 -212 minecraft:water[level=0]
fill 394 45 -213 400 45 -213 minecraft:water[level=0]
fill 393 45 -214 401 45 -214 minecraft:water[level=0]
fill 393 45 -215 401 45 -215 minecraft:water[level=0]
fill 393 45 -216 401 45 -216 minecraft:water[level=0]
fill 393 45 -217 402 45 -217 minecraft:water[level=0]
fill 393 45 -218 402 45 -218 minecraft:water[level=0]
fill 392 45 -219 402 45 -219 minecraft:water[level=0]
fill 392 45 -220 402 45 -220 minecraft:water[level=0]
fill 392 45 -221 403 45 -221 minecraft:water[level=0]
fill 392 45 -222 403 45 -222 minecraft:water[level=0]
fill 393 45 -223 403 45 -223 minecraft:water[level=0]
fill 394 45 -224 404 45 -224 minecraft:water[level=0]
fill 397 45 -225 404 45 -225 minecraft:water[level=0]
fill 399 45 -226 404 45 -226 minecraft:water[level=0]
fill 399 45 -227 405 45 -227 minecraft:water[level=0]
fill 399 45 -228 405 45 -228 minecraft:water[level=0]
fill 399 45 -229 405 45 -229 minecraft:water[level=0]
fill 399 45 -230 406 45 -230 minecraft:water[level=0]
fill 399 45 -231 406 45 -231 minecraft:water[level=0]
fill 398 45 -232 407 45 -232 minecraft:water[level=0]
fill 399 45 -233 407 45 -233 minecraft:water[level=0]
fill 399 45 -234 407 45 -234 minecraft:water[level=0]
fill 400 45 -235 406 45 -235 minecraft:water[level=0]
fill 400 45 -236 405 45 -236 minecraft:water[level=0]
fill 401 45 -237 403 45 -237 minecraft:water[level=0]
setblock 402 45 -238 minecraft:water[level=0]
fill 407 45 -238 409 45 -238 minecraft:air
fill 406 45 -239 410 45 -239 minecraft:air
fill 404 45 -240 411 45 -240 minecraft:air
fill 405 45 -241 412 45 -241 minecraft:air
fill 405 45 -242 412 45 -242 minecraft:air
fill 405 45 -243 413 45 -243 minecraft:air
setblock 406 45 -244 minecraft:air
fill 408 45 -244 413 45 -244 minecraft:air
setblock 406 45 -245 minecraft:air
fill 409 45 -245 413 45 -245 minecraft:air
setblock 406 45 -246 minecraft:air
fill 410 45 -246 413 45 -246 minecraft:air
fill 412 45 -247 413 45 -247 minecraft:air
setblock 416 45 -248 minecraft:air
setblock 409 45 -252 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
forceload remove 392 -254 455 -191
tellraw @a {"text":"Campus zurueck a28 fertig.","color":"green"}
