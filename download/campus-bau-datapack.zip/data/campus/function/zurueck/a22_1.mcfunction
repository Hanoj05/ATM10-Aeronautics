setblock 8 87 -245 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 87 -246 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 87 -247 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 87 -254 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 86 -245 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 86 -246 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 86 -246 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 86 -247 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 85 -191 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 85 -191 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 85 -193 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 25 85 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 85 -194 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 22 85 -201 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 85 -201 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 85 -201 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 85 -202 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 85 -245 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 85 -245 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 85 -246 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 85 -246 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 85 -247 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 85 -247 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 85 -248 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 84 -191 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 84 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 84 -191 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 84 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 84 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 84 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 84 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 84 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 84 -195 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 84 -200 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 84 -201 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 84 -201 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 84 -201 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 84 -202 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 84 -218 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 84 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 84 -219 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 84 -220 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 84 -244 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 84 -245 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 84 -245 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 84 -246 minecraft:birch_log[axis=y]
setblock 9 84 -246 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 84 -246 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 84 -247 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 84 -247 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 84 -248 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 84 -249 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 84 -249 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 84 -249 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 84 -250 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 84 -252 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 25 84 -253 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 84 -253 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 83 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 83 -191 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 83 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 83 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 83 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 83 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 83 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 83 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 83 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 83 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 83 -194 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 83 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 83 -195 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 83 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 83 -195 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 83 -197 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 83 -197 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 83 -200 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 83 -200 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 83 -200 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 83 -201 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 83 -201 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 83 -201 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 83 -202 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 83 -202 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 83 -202 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 83 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 83 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 83 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 83 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 83 -220 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 83 -220 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 83 -220 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 83 -221 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 13 83 -229 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 83 -229 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 83 -229 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 83 -230 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 83 -234 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 83 -234 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 83 -235 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 83 -235 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 83 -235 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 83 -235 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 83 -235 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 83 -235 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 83 -236 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 83 -236 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 83 -237 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 83 -246 minecraft:birch_log[axis=y]
setblock 23 83 -248 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 83 -249 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 83 -249 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 83 -249 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 83 -250 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 83 -252 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 83 -253 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 83 -253 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 83 -253 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 83 -254 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 83 -254 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 82 -191 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 82 -191 minecraft:birch_log[axis=y]
setblock 18 82 -191 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 82 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 82 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 82 -192 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 82 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 82 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 82 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -193 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 82 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 82 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 82 -194 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 82 -194 minecraft:birch_log[axis=y]
setblock 26 82 -194 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 82 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 82 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -195 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 82 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 82 -196 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 82 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 82 -197 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 82 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -197 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 82 -198 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 82 -199 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 82 -200 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 82 -200 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 82 -200 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -201 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 82 -201 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 82 -201 minecraft:birch_log[axis=y]
setblock 24 82 -201 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 82 -201 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 82 -202 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 82 -202 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 82 -202 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 82 -203 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 82 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 82 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 82 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 82 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 82 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 82 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 82 -220 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 82 -220 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 82 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 82 -220 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -221 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 82 -228 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 82 -229 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 82 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -229 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 82 -230 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -234 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 82 -234 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 82 -235 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 82 -235 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 82 -235 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 82 -235 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 82 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 82 -235 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 82 -236 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 82 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -236 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -236 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 82 -236 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 82 -237 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 82 -239 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 82 -240 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 82 -240 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 82 -240 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 82 -241 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 82 -246 minecraft:birch_log[axis=y]
setblock 22 82 -248 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 82 -248 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 82 -248 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 82 -249 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 82 -249 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 82 -249 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 82 -250 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 82 -250 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 82 -250 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 82 -252 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 82 -252 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 82 -252 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 82 -253 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 82 -253 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 82 -253 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -254 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 82 -254 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 82 -254 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 81 -191 minecraft:birch_log[axis=y]
setblock 53 81 -191 minecraft:air
setblock 53 81 -192 minecraft:air
setblock 54 81 -193 minecraft:air
setblock 25 81 -194 minecraft:birch_log[axis=y]
setblock 54 81 -194 minecraft:air
setblock 17 81 -195 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 81 -195 minecraft:air
setblock 13 81 -196 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 81 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -196 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 81 -196 minecraft:air
setblock 9 81 -197 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 81 -197 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 13 81 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 81 -197 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 81 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 81 -197 minecraft:air
setblock 13 81 -198 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 81 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -198 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 81 -198 minecraft:air
setblock 54 81 -199 minecraft:air
setblock 54 81 -200 minecraft:air
setblock 23 81 -201 minecraft:birch_log[axis=y]
setblock 55 81 -201 minecraft:air
setblock 55 81 -202 minecraft:air
setblock 55 81 -203 minecraft:air
setblock 55 81 -204 minecraft:air
setblock 26 81 -205 minecraft:birch_log[axis=y]
setblock 55 81 -205 minecraft:air
setblock 55 81 -206 minecraft:air
setblock 55 81 -207 minecraft:air
setblock 56 81 -208 minecraft:air
setblock 56 81 -209 minecraft:air
setblock 56 81 -210 minecraft:air
setblock 56 81 -211 minecraft:air
setblock 56 81 -212 minecraft:air
setblock 56 81 -213 minecraft:air
setblock 56 81 -214 minecraft:air
setblock 10 81 -215 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 55 81 -215 minecraft:air
setblock 10 81 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 81 -216 minecraft:air
setblock 17 81 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 81 -217 minecraft:air
setblock 12 81 -218 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 81 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 81 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 81 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 81 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 81 -218 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 53 81 -218 minecraft:air
setblock 12 81 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 81 -219 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 81 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 81 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 81 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 81 -219 minecraft:birch_log[axis=y]
setblock 18 81 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 81 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 81 -219 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 53 81 -219 minecraft:air
setblock 12 81 -220 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 81 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -220 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 81 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 81 -220 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 81 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 81 -220 minecraft:air
setblock 14 81 -221 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 81 -221 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 81 -221 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 81 -221 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 81 -221 minecraft:air
setblock 51 81 -222 minecraft:air
setblock 50 81 -223 minecraft:air
setblock 50 81 -224 minecraft:air
setblock 49 81 -225 minecraft:air
setblock 48 81 -226 minecraft:air
setblock 48 81 -227 minecraft:air
setblock 13 81 -228 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 81 -228 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -228 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 81 -228 minecraft:air
setblock 13 81 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 81 -229 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 81 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 81 -229 minecraft:air
setblock 13 81 -230 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 81 -230 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -230 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 81 -230 minecraft:air
setblock 45 81 -231 minecraft:air
setblock 44 81 -232 minecraft:air
setblock 17 81 -233 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 18 81 -233 19 81 -233 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 81 -233 minecraft:air
setblock 14 81 -234 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 81 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 81 -234 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 81 -234 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 81 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 81 -234 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 81 -234 minecraft:air
setblock 9 81 -235 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 81 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 81 -235 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 81 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -235 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 81 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 81 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 81 -235 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 81 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 81 -235 minecraft:air
setblock 9 81 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -236 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 81 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 81 -236 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 81 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 81 -236 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 81 -236 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 81 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 81 -236 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 42 81 -236 minecraft:air
setblock 9 81 -237 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 81 -237 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 81 -237 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 81 -237 minecraft:air
setblock 40 81 -238 minecraft:air
setblock 8 81 -239 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 81 -239 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 81 -239 minecraft:air
setblock 8 81 -240 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 81 -240 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 81 -240 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 81 -240 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 81 -240 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 81 -240 minecraft:air
setblock 8 81 -241 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 81 -241 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 81 -241 minecraft:air
setblock 38 81 -242 minecraft:air
fill 38 81 -243 42 81 -243 minecraft:air
fill 43 81 -244 47 81 -244 minecraft:air
fill 48 81 -245 52 81 -245 minecraft:air
setblock 8 81 -246 minecraft:birch_log[axis=y]
fill 53 81 -246 58 81 -246 minecraft:air
setblock 23 81 -247 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 59 81 -247 63 81 -247 minecraft:air
setblock 22 81 -248 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 81 -248 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 81 -248 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 64 81 -248 68 81 -248 minecraft:air
setblock 21 81 -249 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 81 -249 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 81 -249 minecraft:birch_log[axis=y]
setblock 24 81 -249 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 81 -249 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 69 81 -249 71 81 -249 minecraft:air
setblock 22 81 -250 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 81 -250 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 81 -250 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 81 -251 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 81 -251 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 81 -252 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 81 -252 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 81 -253 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 81 -253 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 81 -253 minecraft:birch_log[axis=y]
setblock 27 81 -253 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 81 -254 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 81 -254 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 81 -254 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 80 -191 minecraft:birch_log[axis=y]
setblock 53 80 -191 minecraft:white_concrete
setblock 8 80 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 80 -192 minecraft:white_concrete
setblock 54 80 -193 minecraft:white_concrete
setblock 17 80 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 80 -194 minecraft:birch_log[axis=y]
setblock 54 80 -194 minecraft:white_concrete
setblock 14 80 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 80 -195 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 80 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 80 -195 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 80 -195 minecraft:white_concrete
setblock 9 80 -196 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 80 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -196 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 80 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 80 -196 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 80 -196 minecraft:white_concrete
setblock 8 80 -197 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 80 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 80 -197 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 80 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 80 -197 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 80 -197 minecraft:birch_log[axis=y]
setblock 15 80 -197 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 80 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 80 -197 minecraft:white_concrete
setblock 9 80 -198 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 80 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -198 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 80 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 80 -198 minecraft:white_concrete
setblock 14 80 -199 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 80 -199 minecraft:white_concrete
setblock 54 80 -200 minecraft:white_concrete
setblock 23 80 -201 minecraft:birch_log[axis=y]
setblock 55 80 -201 minecraft:white_concrete
setblock 55 80 -202 minecraft:white_concrete
setblock 55 80 -203 minecraft:white_concrete
setblock 55 80 -204 minecraft:white_concrete
setblock 26 80 -205 minecraft:birch_log[axis=y]
setblock 55 80 -205 minecraft:white_concrete
setblock 55 80 -206 minecraft:white_concrete
setblock 55 80 -207 minecraft:white_concrete
setblock 56 80 -208 minecraft:white_concrete
setblock 56 80 -209 minecraft:white_concrete
setblock 56 80 -210 minecraft:white_concrete
setblock 8 80 -211 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 80 -211 minecraft:white_concrete
setblock 10 80 -212 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 80 -212 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 25 80 -212 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 56 80 -212 minecraft:white_concrete
setblock 56 80 -213 minecraft:white_concrete
setblock 56 80 -214 minecraft:white_concrete
setblock 10 80 -215 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 80 -215 minecraft:white_concrete
setblock 9 80 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 80 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 80 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 80 -216 minecraft:white_concrete
setblock 10 80 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 80 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 80 -217 minecraft:white_concrete
setblock 12 80 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 80 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 80 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 80 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 80 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 80 -218 minecraft:white_concrete
setblock 11 80 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 80 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 80 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 80 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 15 80 -219 16 80 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 80 -219 minecraft:birch_log[axis=y]
setblock 23 80 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 80 -219 minecraft:white_concrete
setblock 12 80 -220 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 80 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -220 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 80 -220 minecraft:birch_log[axis=y]
fill 16 80 -220 17 80 -220 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 80 -220 minecraft:white_concrete
setblock 14 80 -221 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 80 -221 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 80 -221 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 80 -221 minecraft:white_concrete
setblock 15 80 -222 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 80 -222 minecraft:white_concrete
setblock 50 80 -223 minecraft:white_concrete
setblock 50 80 -224 minecraft:white_concrete
setblock 49 80 -225 minecraft:white_concrete
setblock 48 80 -226 minecraft:white_concrete
setblock 14 80 -227 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 80 -227 minecraft:white_concrete
setblock 13 80 -228 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -228 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 80 -228 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 80 -228 minecraft:white_concrete
setblock 8 80 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 80 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 80 -229 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 80 -229 minecraft:birch_log[axis=y]
setblock 15 80 -229 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 80 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 80 -229 minecraft:white_concrete
setblock 13 80 -230 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -230 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 80 -230 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 80 -230 minecraft:white_concrete
setblock 14 80 -231 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 80 -231 minecraft:white_concrete
setblock 18 80 -232 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 80 -232 minecraft:white_concrete
setblock 15 80 -233 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 80 -233 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 18 80 -233 19 80 -233 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 80 -233 minecraft:white_concrete
setblock 10 80 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 80 -234 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 80 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 80 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -234 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 80 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 80 -234 minecraft:white_concrete
setblock 9 80 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 80 -235 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 80 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 80 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -235 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 80 -235 minecraft:birch_log[axis=y]
setblock 16 80 -235 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 80 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 80 -235 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 80 -235 minecraft:birch_log[axis=y]
setblock 20 80 -235 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 80 -235 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 80 -235 minecraft:white_concrete
setblock 8 80 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 80 -236 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 80 -236 minecraft:birch_log[axis=y]
setblock 11 80 -236 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 80 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 80 -236 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 80 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 80 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -236 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 80 -236 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 80 -236 minecraft:white_concrete
setblock 9 80 -237 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 80 -237 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 80 -237 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 80 -237 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -237 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 80 -237 minecraft:white_concrete
setblock 10 80 -238 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 80 -238 minecraft:white_concrete
setblock 8 80 -239 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 80 -239 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 80 -239 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 80 -239 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 80 -239 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 80 -239 minecraft:white_concrete
setblock 8 80 -240 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 80 -240 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 80 -240 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 80 -240 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 80 -240 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 80 -240 minecraft:white_concrete
setblock 8 80 -241 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 80 -241 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 80 -241 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 80 -241 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 80 -241 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 80 -241 minecraft:white_concrete
setblock 38 80 -242 minecraft:white_concrete
fill 38 80 -243 42 80 -243 minecraft:white_concrete
fill 43 80 -244 47 80 -244 minecraft:white_concrete
fill 48 80 -245 52 80 -245 minecraft:white_concrete
setblock 8 80 -246 minecraft:birch_log[axis=y]
fill 53 80 -246 58 80 -246 minecraft:white_concrete
fill 59 80 -247 63 80 -247 minecraft:white_concrete
fill 64 80 -248 68 80 -248 minecraft:white_concrete
setblock 23 80 -249 minecraft:birch_log[axis=y]
fill 69 80 -249 71 80 -249 minecraft:white_concrete
setblock 26 80 -253 minecraft:birch_log[axis=y]
setblock 17 79 -191 minecraft:birch_log[axis=y]
setblock 16 79 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 79 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 79 -194 minecraft:birch_log[axis=y]
setblock 16 79 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -195 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 79 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -196 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 79 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 79 -196 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 79 -196 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 79 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -196 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 79 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 79 -197 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 79 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 79 -197 minecraft:birch_log[axis=y]
setblock 8 79 -198 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 79 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 79 -198 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 79 -198 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 22 79 -198 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 79 -198 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 79 -199 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 79 -199 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 9 79 -201 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 79 -201 minecraft:birch_log[axis=y]
setblock 9 79 -202 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 79 -205 minecraft:birch_log[axis=y]
setblock 10 79 -208 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 79 -209 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 79 -211 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 79 -212 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 79 -212 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 79 -212 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 79 -212 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 79 -213 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 79 -214 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 79 -214 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 79 -215 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 79 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 79 -215 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 79 -215 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 9 79 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 79 -216 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 79 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 79 -216 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 9 79 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 79 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 79 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 79 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 21 79 -217 22 79 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 79 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 79 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 79 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 79 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 79 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 79 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 79 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 79 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 79 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 79 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 79 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -219 minecraft:birch_log[axis=y]
setblock 22 79 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 79 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 79 -219 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 79 -220 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 79 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 79 -220 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 79 -220 minecraft:birch_log[axis=y]
setblock 11 79 -228 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 11 79 -229 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 79 -229 minecraft:birch_log[axis=y]
setblock 11 79 -230 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 79 -232 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 79 -232 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 79 -232 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 79 -233 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -233 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 79 -233 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -234 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 79 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 79 -234 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 79 -235 minecraft:birch_log[axis=y]
setblock 19 79 -235 minecraft:birch_log[axis=y]
setblock 10 79 -236 minecraft:birch_log[axis=y]
setblock 8 79 -238 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -238 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -239 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 79 -239 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 79 -239 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -239 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 79 -239 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -240 minecraft:birch_log[axis=y]
setblock 9 79 -240 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 79 -240 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 79 -240 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 79 -240 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 79 -240 minecraft:birch_log[axis=y]
setblock 18 79 -240 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 79 -240 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -241 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 79 -241 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 79 -241 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -241 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 79 -241 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -242 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -242 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -246 minecraft:birch_log[axis=y]
setblock 9 79 -246 regions_unexplored:birch_branch[facing=east]
setblock 23 79 -249 minecraft:birch_log[axis=y]
setblock 26 79 -253 minecraft:birch_log[axis=y]
setblock 17 78 -191 minecraft:birch_log[axis=y]
setblock 17 78 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 78 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 78 -194 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 78 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 78 -194 minecraft:birch_log[axis=y]
setblock 9 78 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 78 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 78 -195 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 78 -195 minecraft:birch_log[axis=y]
setblock 18 78 -195 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 78 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 78 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 78 -196 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 78 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 78 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 78 -196 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 78 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 78 -197 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 78 -197 minecraft:birch_log[axis=y]
setblock 10 78 -197 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 78 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 78 -197 minecraft:birch_log[axis=y]
setblock 17 78 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 78 -197 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 78 -198 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 78 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 78 -198 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 78 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 78 -198 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 8 78 -199 9 78 -199 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 78 -199 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -200 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -201 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 78 -201 minecraft:birch_log[axis=y]
setblock 8 78 -202 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -202 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 78 -202 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -203 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 78 -205 minecraft:birch_log[axis=y]
setblock 10 78 -207 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -208 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -208 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 78 -208 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -209 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -211 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -211 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 78 -211 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 78 -211 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -212 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 78 -212 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 78 -212 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 78 -212 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 78 -213 9 78 -213 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -213 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 78 -213 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 78 -213 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 78 -213 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -214 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 78 -214 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -214 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 78 -214 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 78 -214 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 78 -214 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -215 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 78 -215 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 78 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 78 -215 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 78 -216 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 78 -216 minecraft:birch_log[axis=y]
setblock 11 78 -216 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 78 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 78 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 78 -216 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 21 78 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 78 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 78 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 78 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 11 78 -217 12 78 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 78 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 78 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 78 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 78 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 78 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 21 78 -217 22 78 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 78 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 78 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 10 78 -218 11 78 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 78 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 78 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 78 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 78 -218 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 21 78 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 78 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 78 -218 minecraft:birch_log[axis=y]
setblock 24 78 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 78 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 78 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 78 -219 minecraft:birch_log[axis=y]
setblock 13 78 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 78 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 78 -219 minecraft:birch_log[axis=y]
setblock 22 78 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 78 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 78 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 78 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 78 -220 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 78 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 78 -220 minecraft:birch_log[axis=y]
setblock 23 78 -220 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 78 -221 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 78 -227 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 78 -228 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -229 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 78 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 78 -229 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 78 -229 minecraft:birch_log[axis=y]
setblock 11 78 -230 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 78 -231 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 78 -232 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 78 -232 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 78 -232 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 78 -233 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 78 -233 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 78 -233 minecraft:birch_log[axis=y]
setblock 19 78 -233 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 78 -233 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 78 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 78 -234 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 18 78 -234 19 78 -234 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 78 -235 minecraft:birch_log[axis=y]
setblock 18 78 -235 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 78 -235 minecraft:birch_log[axis=y]
setblock 10 78 -236 minecraft:birch_log[axis=y]
setblock 11 78 -238 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -239 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 78 -239 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 78 -239 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -240 minecraft:birch_log[axis=y]
setblock 11 78 -240 herbsandharvest:cherry_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 17 78 -240 minecraft:birch_log[axis=y]
setblock 8 78 -246 minecraft:birch_log[axis=y]
setblock 23 78 -249 minecraft:birch_log[axis=y]
setblock 26 78 -253 minecraft:birch_log[axis=y]
setblock 17 77 -191 minecraft:birch_log[axis=y]
setblock 25 77 -194 minecraft:birch_log[axis=y]
setblock 17 77 -195 minecraft:birch_log[axis=y]
setblock 9 77 -197 minecraft:birch_log[axis=y]
setblock 14 77 -197 minecraft:birch_log[axis=y]
setblock 21 77 -197 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 77 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 77 -197 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 77 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 77 -198 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 77 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 77 -198 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 77 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 77 -199 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 77 -199 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 77 -199 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 77 -199 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 77 -199 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 77 -200 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 77 -200 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 77 -201 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -201 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -201 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 77 -201 minecraft:birch_log[axis=y]
setblock 8 77 -202 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 77 -202 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 77 -202 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 77 -203 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -203 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -203 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 77 -205 minecraft:birch_log[axis=y]
setblock 8 77 -206 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 77 -207 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 77 -207 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 77 -207 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -208 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -208 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 77 -208 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 77 -209 9 77 -209 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 77 -209 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 77 -209 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 77 -210 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 77 -210 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 77 -211 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -211 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 77 -211 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 77 -211 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 77 -212 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 77 -212 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 77 -212 minecraft:birch_log[axis=y]
setblock 11 77 -212 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 77 -212 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 77 -212 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 77 -212 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 77 -213 9 77 -213 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -213 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 77 -213 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 77 -213 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 77 -213 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 77 -213 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 77 -213 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 77 -214 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 9 77 -214 10 77 -214 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 77 -214 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -214 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 77 -214 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 77 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 77 -215 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -215 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 77 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 77 -215 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 77 -216 minecraft:birch_log[axis=y]
setblock 14 77 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 77 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 77 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 77 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 77 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 77 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 77 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 77 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 77 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 77 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -217 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 77 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 77 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 77 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 77 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 77 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 77 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 77 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 77 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 77 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 77 -218 minecraft:birch_log[axis=y]
setblock 12 77 -219 minecraft:birch_log[axis=y]
setblock 17 77 -219 minecraft:birch_log[axis=y]
setblock 15 77 -220 minecraft:birch_log[axis=y]
setblock 21 77 -226 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 77 -227 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 77 -227 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 77 -227 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 77 -228 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 77 -228 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 77 -228 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 77 -228 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 77 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 77 -229 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 77 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 77 -229 minecraft:birch_log[axis=y]
setblock 10 77 -230 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 77 -230 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 77 -230 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -233 minecraft:birch_log[axis=y]
setblock 15 77 -235 minecraft:birch_log[axis=y]
setblock 19 77 -235 minecraft:birch_log[axis=y]
setblock 10 77 -236 minecraft:birch_log[axis=y]
setblock 24 77 -236 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 77 -236 minecraft:flowering_azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 77 -236 minecraft:azalea_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 77 -237 herbsandharvest:cherry_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 11 77 -237 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 77 -237 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 77 -237 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 77 -237 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 77 -237 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 77 -237 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 77 -237 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -238 herbsandharvest:cherry_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
fill 10 77 -238 11 77 -238 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 77 -238 herbsandharvest:cherry_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 13 77 -238 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 22 77 -238 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 77 -238 minecraft:flowering_azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 77 -238 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 77 -238 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 77 -238 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -239 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -239 herbsandharvest:cherry_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 11 77 -239 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 77 -239 herbsandharvest:cherry_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 13 77 -239 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 77 -239 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 77 -239 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 77 -239 minecraft:azalea_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 77 -240 minecraft:birch_log[axis=y]
setblock 9 77 -240 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
fill 10 77 -240 11 77 -240 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 77 -240 herbsandharvest:cherry_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 13 77 -240 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 77 -240 minecraft:birch_log[axis=y]
fill 10 77 -241 11 77 -241 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 77 -241 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 77 -246 minecraft:birch_log[axis=y]
setblock 23 77 -249 minecraft:birch_log[axis=y]
setblock 26 77 -253 minecraft:birch_log[axis=y]
setblock 12 77 -254 minecraft:short_grass
setblock 17 76 -191 minecraft:birch_log[axis=y]
setblock 25 76 -194 minecraft:birch_log[axis=y]
setblock 17 76 -195 minecraft:birch_log[axis=y]
setblock 22 76 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -197 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 76 -197 minecraft:birch_log[axis=y]
setblock 14 76 -197 minecraft:birch_log[axis=y]
setblock 21 76 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 76 -197 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 76 -197 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 76 -198 9 76 -198 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 76 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 76 -198 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 76 -198 minecraft:birch_log[axis=y]
setblock 23 76 -198 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 76 -198 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -199 minecraft:birch_log[axis=y]
setblock 9 76 -199 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -199 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 76 -199 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 76 -199 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 76 -199 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -200 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 76 -200 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 76 -200 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -201 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -201 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -201 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 76 -201 minecraft:birch_log[axis=y]
setblock 8 76 -202 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 76 -202 minecraft:birch_log[axis=y]
setblock 10 76 -202 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 76 -202 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -203 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -203 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -203 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -204 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 76 -205 minecraft:birch_log[axis=y]
setblock 10 76 -206 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -207 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -207 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 76 -207 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -208 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -208 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -208 minecraft:birch_log[axis=y]
setblock 11 76 -208 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 76 -208 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 76 -209 9 76 -209 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -209 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 76 -209 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -210 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 76 -210 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -212 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -212 minecraft:birch_log[axis=y]
setblock 19 76 -212 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -213 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 76 -213 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -213 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 76 -213 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 76 -213 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -214 minecraft:birch_log[axis=y]
setblock 9 76 -214 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -214 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 76 -214 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -214 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 76 -214 minecraft:birch_log[axis=y]
setblock 20 76 -214 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 76 -214 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -215 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 76 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 76 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 76 -215 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 20 76 -215 21 76 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -216 minecraft:birch_log[axis=y]
setblock 14 76 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 76 -216 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 76 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 76 -216 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 18 76 -216 20 76 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 76 -216 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 76 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 76 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 76 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 76 -217 minecraft:birch_log[axis=y]
setblock 16 76 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 76 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 76 -217 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 76 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 76 -217 minecraft:birch_log[axis=y]
fill 22 76 -217 23 76 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 76 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 76 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 76 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 76 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 76 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 76 -218 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 76 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 21 76 -218 22 76 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 76 -218 minecraft:birch_log[axis=y]
setblock 24 76 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 76 -219 minecraft:birch_log[axis=y]
setblock 15 76 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 76 -219 minecraft:birch_log[axis=y]
setblock 21 76 -219 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 76 -220 minecraft:birch_log[axis=y]
setblock 20 76 -226 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 76 -226 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 76 -226 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 76 -227 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 76 -227 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 76 -227 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 76 -227 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -228 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 76 -228 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 76 -228 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 76 -228 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 76 -228 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 76 -228 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 76 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -229 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 76 -229 minecraft:birch_log[axis=y]
fill 12 76 -229 13 76 -229 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 76 -229 minecraft:birch_log[axis=y]
setblock 10 76 -230 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 76 -230 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 76 -230 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 76 -231 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -233 minecraft:birch_log[axis=y]
setblock 15 76 -235 minecraft:birch_log[axis=y]
setblock 19 76 -235 minecraft:birch_log[axis=y]
setblock 22 76 -235 minecraft:azalea_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 76 -235 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 76 -236 minecraft:birch_log[axis=y]
setblock 22 76 -236 minecraft:flowering_azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 76 -236 minecraft:flowering_azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 76 -236 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -237 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 76 -237 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 76 -237 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 76 -237 minecraft:flowering_azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 76 -237 minecraft:flowering_azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 76 -237 minecraft:oak_log[axis=y]
setblock 25 76 -237 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 76 -237 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -238 herbsandharvest:cherry_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 10 76 -238 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 76 -238 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 76 -238 herbsandharvest:cherry_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 13 76 -238 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 76 -238 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 76 -238 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 76 -238 minecraft:oak_log[axis=y]
setblock 25 76 -238 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 76 -238 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -239 herbsandharvest:cherry_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 10 76 -239 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 76 -239 minecraft:oak_log[axis=y]
setblock 12 76 -239 herbsandharvest:cherry_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 13 76 -239 herbsandharvest:cherry_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 22 76 -239 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 76 -239 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 76 -239 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 76 -239 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -240 minecraft:birch_log[axis=y]
setblock 9 76 -240 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -240 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 76 -240 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 76 -240 herbsandharvest:cherry_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 13 76 -240 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 76 -240 minecraft:birch_log[axis=y]
setblock 22 76 -240 minecraft:azalea_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 76 -240 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 76 -240 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 76 -240 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 76 -241 herbsandharvest:cherry_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 11 76 -241 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 76 -241 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 76 -246 minecraft:birch_log[axis=y]
setblock 10 76 -248 minecraft:short_grass
setblock 19 76 -248 regions_unexplored:birch_shrub[half=upper]
setblock 23 76 -249 minecraft:birch_log[axis=y]
setblock 17 76 -250 minecraft:short_grass
fill 8 76 -251 13 76 -251 minecraft:grass_block[snowy=false]
fill 16 76 -251 18 76 -251 minecraft:short_grass
fill 8 76 -252 16 76 -252 minecraft:grass_block[snowy=false]
fill 8 76 -253 16 76 -253 minecraft:grass_block[snowy=false]
setblock 26 76 -253 minecraft:birch_log[axis=y]
fill 8 76 -254 16 76 -254 minecraft:grass_block[snowy=false]
setblock 17 75 -191 minecraft:birch_log[axis=y]
setblock 25 75 -194 minecraft:birch_log[axis=y]
setblock 17 75 -195 minecraft:birch_log[axis=y]
setblock 9 75 -197 minecraft:birch_log[axis=y]
setblock 14 75 -197 minecraft:birch_log[axis=y]
setblock 22 75 -198 minecraft:birch_log[axis=y]
setblock 8 75 -199 minecraft:birch_log[axis=y]
setblock 23 75 -201 minecraft:birch_log[axis=y]
setblock 9 75 -202 minecraft:birch_log[axis=y]
setblock 26 75 -205 minecraft:birch_log[axis=y]
setblock 8 75 -208 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 75 -208 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 75 -208 minecraft:birch_log[axis=y]
setblock 8 75 -209 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 75 -209 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 75 -210 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 75 -210 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 75 -210 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 75 -212 minecraft:birch_log[axis=y]
setblock 8 75 -214 minecraft:birch_log[axis=y]
setblock 19 75 -214 minecraft:birch_log[axis=y]
setblock 18 75 -215 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 75 -216 minecraft:birch_log[axis=y]
setblock 17 75 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 75 -216 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 75 -216 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 75 -217 minecraft:birch_log[axis=y]
fill 16 75 -217 17 75 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 75 -217 minecraft:birch_log[axis=y]
fill 19 75 -217 20 75 -217 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 75 -217 minecraft:birch_log[axis=y]
fill 17 75 -218 18 75 -218 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 75 -218 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 75 -218 minecraft:birch_log[axis=y]
setblock 11 75 -219 regions_unexplored:birch_branch[facing=west]
setblock 12 75 -219 minecraft:birch_log[axis=y]
setblock 17 75 -219 minecraft:birch_log[axis=y]
setblock 18 75 -219 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 75 -220 minecraft:birch_log[axis=y]
setblock 21 75 -225 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 75 -226 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 75 -226 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 75 -226 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 75 -227 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 75 -227 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 75 -227 minecraft:birch_log[axis=y]
setblock 22 75 -227 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 75 -227 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 75 -228 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 75 -228 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 75 -228 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 75 -229 minecraft:birch_log[axis=y]
setblock 14 75 -229 minecraft:birch_log[axis=y]
setblock 21 75 -229 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 75 -233 minecraft:birch_log[axis=y]
setblock 15 75 -235 minecraft:birch_log[axis=y]
setblock 18 75 -235 regions_unexplored:birch_branch[facing=west]
setblock 19 75 -235 minecraft:birch_log[axis=y]
setblock 10 75 -236 minecraft:birch_log[axis=y]
setblock 22 75 -236 minecraft:azalea_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 75 -236 minecraft:flowering_azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 75 -236 minecraft:flowering_azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 75 -236 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 75 -236 minecraft:azalea_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 75 -237 herbsandharvest:cherry_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 11 75 -237 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 75 -237 herbsandharvest:cherry_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 22 75 -237 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 75 -237 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 75 -237 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 75 -237 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 75 -237 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 75 -238 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 75 -238 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 75 -238 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 75 -238 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 75 -238 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 75 -238 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 75 -238 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 75 -238 minecraft:oak_log[axis=y]
setblock 25 75 -238 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 75 -238 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 75 -239 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 75 -239 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 75 -239 minecraft:oak_log[axis=y]
setblock 12 75 -239 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 75 -239 herbsandharvest:cherry_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 22 75 -239 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 75 -239 minecraft:flowering_azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 75 -239 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 75 -239 minecraft:flowering_azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 75 -240 minecraft:birch_log[axis=y]
setblock 9 75 -240 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 75 -240 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 75 -240 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 75 -240 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 75 -240 herbsandharvest:cherry_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 17 75 -240 minecraft:birch_log[axis=y]
fill 23 75 -240 24 75 -240 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 75 -241 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 75 -241 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 75 -241 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 75 -245 regions_unexplored:grass_sprouts
setblock 12 75 -245 regions_unexplored:grass_sprouts
setblock 8 75 -246 minecraft:birch_log[axis=y]
setblock 13 75 -246 minecraft:short_grass
setblock 8 75 -247 minecraft:grass_block[snowy=false]
fill 16 75 -247 17 75 -247 regions_unexplored:grass_sprouts
fill 8 75 -248 11 75 -248 minecraft:grass_block[snowy=false]
fill 13 75 -248 14 75 -248 minecraft:short_grass
setblock 17 75 -248 regions_unexplored:grass_sprouts
setblock 19 75 -248 regions_unexplored:birch_shrub[half=lower]
fill 8 75 -249 15 75 -249 minecraft:grass_block[snowy=false]
setblock 23 75 -249 minecraft:birch_log[axis=y]
fill 8 75 -250 17 75 -250 minecraft:grass_block[snowy=false]
setblock 18 75 -250 minecraft:short_grass
fill 8 75 -251 13 75 -251 minecraft:dirt
fill 14 75 -251 18 75 -251 minecraft:grass_block[snowy=false]
fill 8 75 -252 16 75 -252 minecraft:dirt
fill 17 75 -252 18 75 -252 minecraft:grass_block[snowy=false]
setblock 19 75 -252 minecraft:short_grass
fill 8 75 -253 16 75 -253 minecraft:dirt
fill 17 75 -253 19 75 -253 minecraft:grass_block[snowy=false]
setblock 26 75 -253 minecraft:birch_log[axis=y]
fill 8 75 -254 16 75 -254 minecraft:dirt
fill 17 75 -254 19 75 -254 minecraft:grass_block[snowy=false]
setblock 21 75 -254 minecraft:short_grass
setblock 17 74 -191 minecraft:birch_log[axis=y]
setblock 25 74 -194 minecraft:birch_log[axis=y]
setblock 17 74 -195 minecraft:birch_log[axis=y]
setblock 9 74 -197 minecraft:birch_log[axis=y]
setblock 14 74 -197 minecraft:birch_log[axis=y]
setblock 22 74 -198 minecraft:birch_log[axis=y]
setblock 8 74 -199 minecraft:birch_log[axis=y]
setblock 23 74 -201 minecraft:birch_log[axis=y]
setblock 9 74 -202 minecraft:birch_log[axis=y]
setblock 26 74 -205 minecraft:birch_log[axis=y]
setblock 8 74 -207 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 74 -208 9 74 -208 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 74 -208 minecraft:birch_log[axis=y]
setblock 8 74 -209 minecraft:birch_log[axis=y]
fill 9 74 -209 10 74 -209 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 8 74 -210 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 74 -210 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 74 -211 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 74 -212 minecraft:birch_log[axis=y]
setblock 8 74 -214 minecraft:birch_log[axis=y]
setblock 19 74 -214 minecraft:birch_log[axis=y]
setblock 10 74 -216 minecraft:birch_log[axis=y]
setblock 15 74 -217 minecraft:birch_log[axis=y]
setblock 18 74 -217 minecraft:birch_log[axis=y]
setblock 21 74 -217 minecraft:birch_log[axis=y]
setblock 23 74 -218 minecraft:birch_log[axis=y]
setblock 12 74 -219 minecraft:birch_log[axis=y]
setblock 17 74 -219 minecraft:birch_log[axis=y]
setblock 18 74 -219 regions_unexplored:birch_branch[facing=east]
setblock 15 74 -220 minecraft:birch_log[axis=y]
setblock 21 74 -227 minecraft:birch_log[axis=y]
setblock 11 74 -229 minecraft:birch_log[axis=y]
setblock 14 74 -229 minecraft:birch_log[axis=y]
setblock 18 74 -233 minecraft:birch_log[axis=y]
setblock 15 74 -235 minecraft:birch_log[axis=y]
setblock 19 74 -235 minecraft:birch_log[axis=y]
setblock 10 74 -236 minecraft:birch_log[axis=y]
setblock 24 74 -236 minecraft:flowering_azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 74 -236 minecraft:flowering_azalea_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 74 -236 minecraft:azalea_leaves[distance=5,persistent=false,waterlogged=false]
setblock 24 74 -237 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 74 -238 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 74 -238 minecraft:flowering_azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 74 -238 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 74 -239 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 74 -239 minecraft:oak_log[axis=y]
setblock 12 74 -239 herbsandharvest:cherry_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 23 74 -239 minecraft:azalea_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 74 -239 minecraft:oak_log[axis=y]
setblock 8 74 -240 minecraft:birch_log[axis=y]
setblock 11 74 -240 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 74 -240 minecraft:birch_log[axis=y]
setblock 22 74 -240 minecraft:azalea_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 74 -240 minecraft:azalea_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 74 -243 regions_unexplored:grass_sprouts
setblock 14 74 -244 regions_unexplored:grass_sprouts
fill 8 74 -245 12 74 -245 minecraft:grass_block[snowy=false]
setblock 8 74 -246 minecraft:dirt
fill 9 74 -246 14 74 -246 minecraft:grass_block[snowy=false]
setblock 16 74 -246 regions_unexplored:grass_sprouts
setblock 8 74 -247 minecraft:dirt
fill 9 74 -247 17 74 -247 minecraft:grass_block[snowy=false]
fill 8 74 -248 11 74 -248 minecraft:dirt
fill 12 74 -248 19 74 -248 minecraft:grass_block[snowy=false]
setblock 20 74 -248 minecraft:short_grass
fill 8 74 -249 15 74 -249 minecraft:dirt
fill 16 74 -249 20 74 -249 minecraft:grass_block[snowy=false]
setblock 21 74 -249 minecraft:short_grass
setblock 23 74 -249 minecraft:birch_log[axis=y]
fill 8 74 -250 17 74 -250 minecraft:dirt
fill 18 74 -250 20 74 -250 minecraft:grass_block[snowy=false]
fill 8 74 -251 18 74 -251 minecraft:dirt
fill 19 74 -251 21 74 -251 minecraft:grass_block[snowy=false]
fill 9 74 -252 18 74 -252 minecraft:dirt
fill 19 74 -252 21 74 -252 minecraft:grass_block[snowy=false]
fill 10 74 -253 19 74 -253 minecraft:dirt
fill 20 74 -253 21 74 -253 minecraft:grass_block[snowy=false]
setblock 26 74 -253 minecraft:birch_log[axis=y]
fill 11 74 -254 19 74 -254 minecraft:dirt
fill 20 74 -254 21 74 -254 minecraft:grass_block[snowy=false]
setblock 17 73 -191 minecraft:birch_log[axis=y]
setblock 25 73 -194 minecraft:birch_log[axis=y]
setblock 17 73 -195 minecraft:birch_log[axis=y]
setblock 9 73 -197 minecraft:birch_log[axis=y]
setblock 14 73 -197 minecraft:birch_log[axis=y]
setblock 22 73 -198 minecraft:birch_log[axis=y]
setblock 8 73 -199 minecraft:birch_log[axis=y]
setblock 23 73 -201 minecraft:birch_log[axis=y]
setblock 9 73 -202 minecraft:birch_log[axis=y]
setblock 26 73 -205 minecraft:birch_log[axis=y]
setblock 10 73 -208 minecraft:birch_log[axis=y]
setblock 8 73 -209 minecraft:birch_log[axis=y]
setblock 10 73 -212 minecraft:birch_log[axis=y]
setblock 8 73 -214 minecraft:birch_log[axis=y]
setblock 19 73 -214 minecraft:birch_log[axis=y]
setblock 10 73 -216 minecraft:birch_log[axis=y]
setblock 15 73 -217 minecraft:birch_log[axis=y]
setblock 18 73 -217 minecraft:birch_log[axis=y]
setblock 21 73 -217 minecraft:birch_log[axis=y]
setblock 23 73 -218 minecraft:birch_log[axis=y]
setblock 12 73 -219 minecraft:birch_log[axis=y]
setblock 17 73 -219 minecraft:birch_log[axis=y]
setblock 15 73 -220 minecraft:birch_log[axis=y]
setblock 21 73 -227 minecraft:birch_log[axis=y]
setblock 11 73 -229 minecraft:birch_log[axis=y]
setblock 14 73 -229 minecraft:birch_log[axis=y]
setblock 18 73 -233 minecraft:birch_log[axis=y]
setblock 15 73 -235 minecraft:birch_log[axis=y]
setblock 19 73 -235 minecraft:birch_log[axis=y]
setblock 10 73 -236 minecraft:birch_log[axis=y]
setblock 11 73 -239 minecraft:oak_log[axis=y]
setblock 24 73 -239 minecraft:oak_log[axis=y]
setblock 8 73 -240 minecraft:birch_log[axis=y]
setblock 12 73 -240 minecraft:short_grass
setblock 17 73 -240 minecraft:birch_log[axis=y]
fill 11 73 -242 12 73 -242 minecraft:grass_block[snowy=false]
fill 8 73 -243 15 73 -243 minecraft:grass_block[snowy=false]
setblock 16 73 -243 minecraft:short_grass
fill 8 73 -244 17 73 -244 minecraft:grass_block[snowy=false]
setblock 18 73 -244 regions_unexplored:grass_sprouts
fill 21 73 -244 22 73 -244 minecraft:short_grass
setblock 24 73 -244 regions_unexplored:grass_sprouts
fill 8 73 -245 12 73 -245 minecraft:dirt
fill 13 73 -245 20 73 -245 minecraft:grass_block[snowy=false]
setblock 23 73 -245 regions_unexplored:grass_sprouts
fill 8 73 -246 14 73 -246 minecraft:dirt
fill 15 73 -246 21 73 -246 minecraft:grass_block[snowy=false]
fill 8 73 -247 17 73 -247 minecraft:dirt
fill 18 73 -247 22 73 -247 minecraft:grass_block[snowy=false]
fill 8 73 -248 19 73 -248 minecraft:dirt
fill 20 73 -248 23 73 -248 minecraft:grass_block[snowy=false]
fill 8 73 -249 20 73 -249 minecraft:dirt
fill 21 73 -249 22 73 -249 minecraft:grass_block[snowy=false]
setblock 23 73 -249 minecraft:dirt
fill 8 73 -250 20 73 -250 minecraft:dirt
fill 21 73 -250 23 73 -250 minecraft:grass_block[snowy=false]
fill 8 73 -251 21 73 -251 minecraft:dirt
fill 22 73 -251 23 73 -251 minecraft:grass_block[snowy=false]
fill 9 73 -252 21 73 -252 minecraft:dirt
fill 22 73 -252 23 73 -252 minecraft:grass_block[snowy=false]
fill 11 73 -253 21 73 -253 minecraft:dirt
fill 22 73 -253 23 73 -253 minecraft:grass_block[snowy=false]
setblock 26 73 -253 minecraft:birch_log[axis=y]
fill 11 73 -254 21 73 -254 minecraft:dirt
fill 22 73 -254 23 73 -254 minecraft:grass_block[snowy=false]
setblock 17 72 -191 minecraft:birch_log[axis=y]
setblock 13 72 -194 regions_unexplored:grass_sprouts
setblock 18 72 -194 minecraft:air
setblock 25 72 -194 minecraft:birch_log[axis=y]
setblock 11 72 -195 regions_unexplored:grass_sprouts
setblock 12 72 -195 minecraft:short_grass
setblock 15 72 -195 regions_unexplored:grass_sprouts
setblock 17 72 -195 minecraft:birch_log[axis=y]
setblock 19 72 -196 regions_unexplored:grass_sprouts
setblock 9 72 -197 minecraft:birch_log[axis=y]
setblock 14 72 -197 minecraft:birch_log[axis=y]
setblock 22 72 -198 minecraft:birch_log[axis=y]
setblock 8 72 -199 minecraft:birch_log[axis=y]
setblock 23 72 -201 minecraft:birch_log[axis=y]
setblock 9 72 -202 minecraft:birch_log[axis=y]
setblock 18 72 -204 minecraft:air
setblock 26 72 -205 minecraft:birch_log[axis=y]
setblock 10 72 -208 minecraft:birch_log[axis=y]
setblock 8 72 -209 minecraft:birch_log[axis=y]
setblock 10 72 -212 minecraft:birch_log[axis=y]
setblock 8 72 -214 minecraft:birch_log[axis=y]
setblock 17 72 -214 minecraft:air
setblock 19 72 -214 minecraft:birch_log[axis=y]
setblock 10 72 -216 minecraft:birch_log[axis=y]
setblock 15 72 -217 minecraft:birch_log[axis=y]
setblock 18 72 -217 minecraft:birch_log[axis=y]
setblock 21 72 -217 minecraft:birch_log[axis=y]
setblock 23 72 -218 minecraft:birch_log[axis=y]
setblock 12 72 -219 minecraft:birch_log[axis=y]
setblock 17 72 -219 minecraft:birch_log[axis=y]
setblock 15 72 -220 minecraft:birch_log[axis=y]
setblock 21 72 -227 minecraft:birch_log[axis=y]
setblock 17 72 -228 minecraft:air
setblock 11 72 -229 minecraft:birch_log[axis=y]
setblock 14 72 -229 minecraft:birch_log[axis=y]
setblock 18 72 -233 minecraft:birch_log[axis=y]
setblock 15 72 -235 minecraft:birch_log[axis=y]
setblock 19 72 -235 minecraft:birch_log[axis=y]
setblock 9 72 -236 regions_unexplored:grass_sprouts
setblock 10 72 -236 minecraft:birch_log[axis=y]
setblock 13 72 -236 minecraft:short_grass
setblock 9 72 -237 minecraft:short_grass
setblock 11 72 -238 minecraft:short_grass
setblock 25 72 -238 regions_unexplored:birch_shrub[half=upper]
setblock 11 72 -239 minecraft:oak_log[axis=y]
fill 13 72 -239 16 72 -239 minecraft:grass_block[snowy=false]
setblock 18 72 -239 minecraft:air
fill 20 72 -239 22 72 -239 regions_unexplored:grass_sprouts
setblock 24 72 -239 minecraft:oak_log[axis=y]
setblock 8 72 -240 minecraft:birch_log[axis=y]
fill 10 72 -240 16 72 -240 minecraft:grass_block[snowy=false]
setblock 17 72 -240 minecraft:dirt
setblock 23 72 -240 minecraft:short_grass
fill 8 72 -241 18 72 -241 minecraft:grass_block[snowy=false]
setblock 22 72 -241 regions_unexplored:grass_sprouts
setblock 25 72 -241 minecraft:short_grass
fill 8 72 -242 10 72 -242 minecraft:grass_block[snowy=false]
fill 11 72 -242 12 72 -242 minecraft:dirt
fill 13 72 -242 19 72 -242 minecraft:grass_block[snowy=false]
setblock 21 72 -242 minecraft:short_grass
fill 8 72 -243 15 72 -243 minecraft:dirt
fill 16 72 -243 23 72 -243 minecraft:grass_block[snowy=false]
setblock 24 72 -243 minecraft:short_grass
setblock 26 72 -243 minecraft:short_grass
fill 8 72 -244 17 72 -244 minecraft:dirt
fill 18 72 -244 25 72 -244 minecraft:grass_block[snowy=false]
fill 8 72 -245 20 72 -245 minecraft:dirt
fill 21 72 -245 26 72 -245 minecraft:grass_block[snowy=false]
fill 8 72 -246 21 72 -246 minecraft:dirt
fill 22 72 -246 26 72 -246 minecraft:grass_block[snowy=false]
fill 8 72 -247 22 72 -247 minecraft:dirt
fill 23 72 -247 26 72 -247 minecraft:grass_block[snowy=false]
fill 8 72 -248 23 72 -248 minecraft:dirt
fill 24 72 -248 26 72 -248 minecraft:grass_block[snowy=false]
fill 8 72 -249 23 72 -249 minecraft:dirt
fill 24 72 -249 26 72 -249 minecraft:grass_block[snowy=false]
fill 8 72 -250 23 72 -250 minecraft:dirt
fill 24 72 -250 26 72 -250 minecraft:grass_block[snowy=false]
fill 8 72 -251 13 72 -251 minecraft:stone
fill 14 72 -251 23 72 -251 minecraft:dirt
fill 24 72 -251 26 72 -251 minecraft:grass_block[snowy=false]
fill 8 72 -252 10 72 -252 minecraft:stone
setblock 11 72 -252 minecraft:copper_ore
fill 12 72 -252 16 72 -252 minecraft:stone
fill 17 72 -252 23 72 -252 minecraft:dirt
fill 24 72 -252 26 72 -252 minecraft:grass_block[snowy=false]
fill 10 72 -253 16 72 -253 minecraft:stone
fill 17 72 -253 23 72 -253 minecraft:dirt
fill 24 72 -253 25 72 -253 minecraft:grass_block[snowy=false]
setblock 26 72 -253 minecraft:dirt
fill 11 72 -254 16 72 -254 minecraft:stone
fill 17 72 -254 23 72 -254 minecraft:dirt
fill 24 72 -254 26 72 -254 minecraft:grass_block[snowy=false]
fill 12 71 -191 13 71 -191 minecraft:grass_block[snowy=false]
setblock 17 71 -191 minecraft:birch_log[axis=y]
setblock 21 71 -191 regions_unexplored:grass_sprouts
fill 12 71 -192 16 71 -192 minecraft:grass_block[snowy=false]
setblock 18 71 -192 minecraft:air
setblock 21 71 -192 minecraft:short_grass
setblock 23 71 -192 regions_unexplored:grass_sprouts
setblock 9 71 -193 minecraft:short_grass
setblock 11 71 -193 minecraft:short_grass
fill 12 71 -193 17 71 -193 minecraft:grass_block[snowy=false]
fill 18 71 -193 19 71 -193 minecraft:air
setblock 21 71 -193 regions_unexplored:grass_sprouts
setblock 23 71 -193 regions_unexplored:grass_sprouts
fill 12 71 -194 18 71 -194 minecraft:grass_block[snowy=false]
fill 19 71 -194 20 71 -194 minecraft:air
setblock 22 71 -194 minecraft:short_grass
setblock 25 71 -194 minecraft:birch_log[axis=y]
fill 11 71 -195 16 71 -195 minecraft:grass_block[snowy=false]
setblock 17 71 -195 minecraft:dirt
fill 18 71 -195 19 71 -195 minecraft:grass_block[snowy=false]
fill 22 71 -195 23 71 -195 regions_unexplored:grass_sprouts
setblock 25 71 -195 minecraft:short_grass
fill 11 71 -196 19 71 -196 minecraft:grass_block[snowy=false]
setblock 24 71 -196 regions_unexplored:grass_sprouts
setblock 26 71 -196 minecraft:short_grass
setblock 9 71 -197 minecraft:birch_log[axis=y]
fill 11 71 -197 13 71 -197 minecraft:grass_block[snowy=false]
setblock 14 71 -197 minecraft:dirt
fill 15 71 -197 19 71 -197 minecraft:grass_block[snowy=false]
setblock 20 71 -197 regions_unexplored:grass_sprouts
setblock 26 71 -197 minecraft:short_grass
fill 12 71 -198 18 71 -198 minecraft:grass_block[snowy=false]
setblock 22 71 -198 minecraft:birch_log[axis=y]
setblock 8 71 -199 minecraft:birch_log[axis=y]
fill 12 71 -199 17 71 -199 minecraft:grass_block[snowy=false]
setblock 11 71 -200 regions_unexplored:grass_sprouts
fill 12 71 -200 16 71 -200 minecraft:grass_block[snowy=false]
fill 18 71 -200 19 71 -200 minecraft:short_grass
setblock 21 71 -200 regions_unexplored:grass_sprouts
fill 12 71 -201 13 71 -201 minecraft:grass_block[snowy=false]
setblock 23 71 -201 minecraft:birch_log[axis=y]
setblock 24 71 -201 regions_unexplored:grass_sprouts
setblock 25 71 -201 minecraft:short_grass
setblock 9 71 -202 minecraft:birch_log[axis=y]
setblock 18 71 -202 minecraft:air
setblock 22 71 -202 minecraft:short_grass
setblock 17 71 -203 minecraft:air
setblock 18 71 -203 regions_unexplored:grass_sprouts
setblock 19 71 -203 minecraft:air
fill 22 71 -203 23 71 -203 minecraft:short_grass
fill 16 71 -204 19 71 -204 minecraft:air
setblock 20 71 -204 regions_unexplored:grass_sprouts
setblock 23 71 -204 regions_unexplored:grass_sprouts
fill 17 71 -205 19 71 -205 minecraft:air
setblock 26 71 -205 minecraft:birch_log[axis=y]
setblock 18 71 -206 minecraft:air
setblock 10 71 -208 minecraft:birch_log[axis=y]
setblock 8 71 -209 minecraft:birch_log[axis=y]
setblock 10 71 -212 minecraft:birch_log[axis=y]
setblock 17 71 -212 minecraft:air
fill 16 71 -213 18 71 -213 minecraft:air
setblock 8 71 -214 minecraft:birch_log[axis=y]
fill 15 71 -214 18 71 -214 minecraft:air
setblock 19 71 -214 minecraft:birch_log[axis=y]
fill 16 71 -215 18 71 -215 minecraft:air
setblock 10 71 -216 minecraft:birch_log[axis=y]
setblock 17 71 -216 minecraft:air
setblock 15 71 -217 minecraft:birch_log[axis=y]
setblock 18 71 -217 minecraft:birch_log[axis=y]
setblock 21 71 -217 minecraft:birch_log[axis=y]
setblock 23 71 -218 minecraft:birch_log[axis=y]
setblock 12 71 -219 minecraft:birch_log[axis=y]
setblock 17 71 -219 minecraft:birch_log[axis=y]
setblock 15 71 -220 minecraft:birch_log[axis=y]
setblock 17 71 -226 minecraft:air
fill 16 71 -227 18 71 -227 minecraft:air
setblock 21 71 -227 minecraft:birch_log[axis=y]
fill 15 71 -228 19 71 -228 minecraft:air
setblock 11 71 -229 minecraft:birch_log[axis=y]
setblock 14 71 -229 minecraft:birch_log[axis=y]
fill 16 71 -229 18 71 -229 minecraft:air
setblock 17 71 -230 minecraft:air
setblock 20 71 -230 regions_unexplored:grass_sprouts
setblock 25 71 -231 regions_unexplored:grass_sprouts
fill 12 71 -233 16 71 -233 minecraft:grass_block[snowy=false]
setblock 18 71 -233 minecraft:birch_log[axis=y]
fill 8 71 -234 17 71 -234 minecraft:grass_block[snowy=false]
fill 8 71 -235 14 71 -235 minecraft:grass_block[snowy=false]
setblock 15 71 -235 minecraft:dirt
fill 16 71 -235 17 71 -235 minecraft:grass_block[snowy=false]
setblock 19 71 -235 minecraft:birch_log[axis=y]
setblock 25 71 -235 minecraft:short_grass
fill 8 71 -236 9 71 -236 minecraft:grass_block[snowy=false]
setblock 10 71 -236 minecraft:dirt
fill 11 71 -236 18 71 -236 minecraft:grass_block[snowy=false]
setblock 26 71 -236 minecraft:short_grass
fill 8 71 -237 19 71 -237 minecraft:grass_block[snowy=false]
fill 8 71 -238 22 71 -238 minecraft:grass_block[snowy=false]
setblock 25 71 -238 regions_unexplored:birch_shrub[half=lower]
setblock 26 71 -238 minecraft:grass_block[snowy=false]
fill 8 71 -239 10 71 -239 minecraft:grass_block[snowy=false]
setblock 11 71 -239 minecraft:dirt
setblock 12 71 -239 minecraft:grass_block[snowy=false]
fill 13 71 -239 16 71 -239 minecraft:dirt
fill 17 71 -239 23 71 -239 minecraft:grass_block[snowy=false]
setblock 24 71 -239 minecraft:rooted_dirt
fill 25 71 -239 26 71 -239 minecraft:grass_block[snowy=false]
setblock 8 71 -240 minecraft:dirt
setblock 9 71 -240 minecraft:grass_block[snowy=false]
fill 10 71 -240 17 71 -240 minecraft:dirt
fill 18 71 -240 26 71 -240 minecraft:grass_block[snowy=false]
fill 8 71 -241 18 71 -241 minecraft:dirt
fill 19 71 -241 26 71 -241 minecraft:grass_block[snowy=false]
fill 8 71 -242 19 71 -242 minecraft:dirt
fill 20 71 -242 26 71 -242 minecraft:grass_block[snowy=false]
fill 8 71 -243 23 71 -243 minecraft:dirt
fill 24 71 -243 26 71 -243 minecraft:grass_block[snowy=false]
fill 8 71 -244 25 71 -244 minecraft:dirt
setblock 26 71 -244 minecraft:grass_block[snowy=false]
fill 8 71 -245 26 71 -245 minecraft:dirt
fill 8 71 -246 26 71 -246 minecraft:dirt
setblock 8 71 -247 minecraft:stone
fill 9 71 -247 26 71 -247 minecraft:dirt
fill 8 71 -248 11 71 -248 minecraft:stone
fill 12 71 -248 26 71 -248 minecraft:dirt
fill 8 71 -249 15 71 -249 minecraft:stone
fill 16 71 -249 26 71 -249 minecraft:dirt
fill 8 71 -250 17 71 -250 minecraft:stone
fill 18 71 -250 26 71 -250 minecraft:dirt
fill 8 71 -251 18 71 -251 minecraft:stone
fill 19 71 -251 26 71 -251 minecraft:dirt
fill 8 71 -252 18 71 -252 minecraft:stone
fill 19 71 -252 26 71 -252 minecraft:dirt
fill 8 71 -253 19 71 -253 minecraft:stone
fill 20 71 -253 26 71 -253 minecraft:dirt
fill 8 71 -254 19 71 -254 minecraft:stone
fill 20 71 -254 26 71 -254 minecraft:dirt
fill 10 70 -191 11 70 -191 minecraft:grass_block[snowy=false]
fill 12 70 -191 13 70 -191 minecraft:dirt
fill 14 70 -191 16 70 -191 minecraft:grass_block[snowy=false]
setblock 17 70 -191 minecraft:dirt
fill 18 70 -191 26 70 -191 minecraft:grass_block[snowy=false]
fill 9 70 -192 11 70 -192 minecraft:grass_block[snowy=false]
fill 12 70 -192 16 70 -192 minecraft:dirt
fill 17 70 -192 26 70 -192 minecraft:grass_block[snowy=false]
fill 9 70 -193 11 70 -193 minecraft:grass_block[snowy=false]
fill 12 70 -193 17 70 -193 minecraft:dirt
fill 18 70 -193 26 70 -193 minecraft:grass_block[snowy=false]
fill 9 70 -194 11 70 -194 minecraft:grass_block[snowy=false]
fill 12 70 -194 18 70 -194 minecraft:dirt
fill 19 70 -194 24 70 -194 minecraft:grass_block[snowy=false]
setblock 25 70 -194 minecraft:dirt
setblock 26 70 -194 minecraft:grass_block[snowy=false]
setblock 8 70 -195 regions_unexplored:grass_sprouts
fill 9 70 -195 10 70 -195 minecraft:grass_block[snowy=false]
fill 11 70 -195 19 70 -195 minecraft:dirt
fill 20 70 -195 26 70 -195 minecraft:grass_block[snowy=false]
fill 9 70 -196 10 70 -196 minecraft:grass_block[snowy=false]
fill 11 70 -196 19 70 -196 minecraft:dirt
fill 20 70 -196 26 70 -196 minecraft:grass_block[snowy=false]
setblock 9 70 -197 minecraft:dirt
setblock 10 70 -197 minecraft:grass_block[snowy=false]
fill 11 70 -197 19 70 -197 minecraft:dirt
fill 20 70 -197 26 70 -197 minecraft:grass_block[snowy=false]
fill 9 70 -198 11 70 -198 minecraft:grass_block[snowy=false]
fill 12 70 -198 18 70 -198 minecraft:dirt
fill 19 70 -198 21 70 -198 minecraft:grass_block[snowy=false]
setblock 22 70 -198 minecraft:dirt
fill 23 70 -198 26 70 -198 minecraft:grass_block[snowy=false]
setblock 8 70 -199 minecraft:birch_log[axis=y]
fill 10 70 -199 11 70 -199 minecraft:grass_block[snowy=false]
fill 12 70 -199 17 70 -199 minecraft:dirt
fill 18 70 -199 26 70 -199 minecraft:grass_block[snowy=false]
fill 10 70 -200 11 70 -200 minecraft:grass_block[snowy=false]
fill 12 70 -200 16 70 -200 minecraft:dirt
fill 17 70 -200 25 70 -200 minecraft:grass_block[snowy=false]
fill 10 70 -201 11 70 -201 minecraft:grass_block[snowy=false]
fill 12 70 -201 13 70 -201 minecraft:dirt
fill 14 70 -201 22 70 -201 minecraft:grass_block[snowy=false]
setblock 23 70 -201 minecraft:dirt
fill 24 70 -201 25 70 -201 minecraft:grass_block[snowy=false]
setblock 9 70 -202 minecraft:birch_log[axis=y]
fill 11 70 -202 25 70 -202 minecraft:grass_block[snowy=false]
fill 12 70 -203 25 70 -203 minecraft:grass_block[snowy=false]
fill 13 70 -204 24 70 -204 minecraft:grass_block[snowy=false]
fill 16 70 -205 18 70 -205 minecraft:air
setblock 19 70 -205 regions_unexplored:grass_sprouts
setblock 20 70 -205 minecraft:air
setblock 25 70 -205 minecraft:short_grass
setblock 26 70 -205 minecraft:birch_log[axis=y]
fill 17 70 -206 19 70 -206 minecraft:air
setblock 26 70 -206 regions_unexplored:grass_sprouts
setblock 24 70 -207 minecraft:short_grass
setblock 10 70 -208 minecraft:birch_log[axis=y]
setblock 8 70 -209 minecraft:birch_log[axis=y]
setblock 23 70 -209 regions_unexplored:grass_sprouts
setblock 10 70 -212 minecraft:birch_log[axis=y]
fill 16 70 -212 18 70 -212 minecraft:air
fill 15 70 -213 19 70 -213 minecraft:air
setblock 8 70 -214 minecraft:birch_log[axis=y]
fill 15 70 -214 18 70 -214 minecraft:air
setblock 19 70 -214 minecraft:birch_log[axis=y]
fill 15 70 -215 19 70 -215 minecraft:air
setblock 10 70 -216 minecraft:birch_log[axis=y]
fill 16 70 -216 18 70 -216 minecraft:air
setblock 15 70 -217 minecraft:birch_log[axis=y]
setblock 18 70 -217 minecraft:birch_log[axis=y]
setblock 21 70 -217 minecraft:birch_log[axis=y]
setblock 23 70 -218 minecraft:birch_log[axis=y]
setblock 12 70 -219 minecraft:birch_log[axis=y]
setblock 17 70 -219 minecraft:birch_log[axis=y]
setblock 15 70 -220 minecraft:birch_log[axis=y]
setblock 21 70 -222 minecraft:short_grass
setblock 23 70 -222 regions_unexplored:grass_sprouts
setblock 17 70 -223 regions_unexplored:grass_sprouts
setblock 20 70 -224 minecraft:short_grass
fill 20 70 -225 21 70 -225 regions_unexplored:grass_sprouts
fill 16 70 -226 18 70 -226 minecraft:air
setblock 20 70 -226 minecraft:short_grass
fill 15 70 -227 19 70 -227 minecraft:air
setblock 20 70 -227 minecraft:short_grass
setblock 21 70 -227 minecraft:birch_log[axis=y]
fill 15 70 -228 19 70 -228 minecraft:air
setblock 11 70 -229 minecraft:birch_log[axis=y]
fill 12 70 -229 13 70 -229 minecraft:grass_block[snowy=false]
setblock 14 70 -229 minecraft:dirt
fill 15 70 -229 18 70 -229 minecraft:grass_block[snowy=false]
setblock 19 70 -229 minecraft:air
setblock 21 70 -229 regions_unexplored:grass_sprouts
setblock 24 70 -229 regions_unexplored:grass_sprouts
fill 10 70 -230 20 70 -230 minecraft:grass_block[snowy=false]
setblock 21 70 -230 minecraft:short_grass
fill 9 70 -231 25 70 -231 minecraft:grass_block[snowy=false]
fill 8 70 -232 25 70 -232 minecraft:grass_block[snowy=false]
fill 8 70 -233 11 70 -233 minecraft:grass_block[snowy=false]
fill 12 70 -233 16 70 -233 minecraft:dirt
setblock 17 70 -233 minecraft:grass_block[snowy=false]
setblock 18 70 -233 minecraft:dirt
fill 19 70 -233 25 70 -233 minecraft:grass_block[snowy=false]
fill 8 70 -234 17 70 -234 minecraft:dirt
fill 18 70 -234 25 70 -234 minecraft:grass_block[snowy=false]
fill 8 70 -235 17 70 -235 minecraft:dirt
setblock 18 70 -235 minecraft:grass_block[snowy=false]
setblock 19 70 -235 minecraft:dirt
fill 20 70 -235 25 70 -235 minecraft:grass_block[snowy=false]
fill 8 70 -236 18 70 -236 minecraft:dirt
fill 19 70 -236 26 70 -236 minecraft:grass_block[snowy=false]
fill 8 70 -237 19 70 -237 minecraft:dirt
fill 20 70 -237 23 70 -237 minecraft:grass_block[snowy=false]
setblock 24 70 -237 minecraft:rooted_dirt
setblock 25 70 -237 minecraft:grass_block[snowy=false]
setblock 26 70 -237 minecraft:rooted_dirt
fill 8 70 -238 22 70 -238 minecraft:dirt
fill 23 70 -238 26 70 -238 minecraft:rooted_dirt
fill 8 70 -239 22 70 -239 minecraft:dirt
fill 23 70 -239 26 70 -239 minecraft:rooted_dirt
fill 8 70 -240 21 70 -240 minecraft:dirt
setblock 22 70 -240 minecraft:rooted_dirt
setblock 23 70 -240 minecraft:dirt
setblock 24 70 -240 minecraft:rooted_dirt
setblock 25 70 -240 minecraft:dirt
setblock 26 70 -240 minecraft:rooted_dirt
fill 8 70 -241 22 70 -241 minecraft:dirt
setblock 23 70 -241 minecraft:rooted_dirt
fill 24 70 -241 26 70 -241 minecraft:dirt
fill 8 70 -242 26 70 -242 minecraft:dirt
fill 8 70 -243 26 70 -243 minecraft:dirt
fill 8 70 -244 26 70 -244 minecraft:dirt
fill 8 70 -245 12 70 -245 minecraft:stone
fill 13 70 -245 26 70 -245 minecraft:dirt
fill 8 70 -246 14 70 -246 minecraft:stone
fill 15 70 -246 26 70 -246 minecraft:dirt
fill 8 70 -247 17 70 -247 minecraft:stone
fill 18 70 -247 26 70 -247 minecraft:dirt
fill 8 70 -248 19 70 -248 minecraft:stone
fill 20 70 -248 26 70 -248 minecraft:dirt
fill 8 70 -249 20 70 -249 minecraft:stone
fill 21 70 -249 26 70 -249 minecraft:dirt
fill 8 70 -250 20 70 -250 minecraft:stone
fill 21 70 -250 26 70 -250 minecraft:dirt
fill 8 70 -251 21 70 -251 minecraft:stone
fill 22 70 -251 26 70 -251 minecraft:dirt
fill 8 70 -252 21 70 -252 minecraft:stone
fill 22 70 -252 26 70 -252 minecraft:dirt
fill 8 70 -253 21 70 -253 minecraft:stone
fill 22 70 -253 26 70 -253 minecraft:dirt
fill 8 70 -254 21 70 -254 minecraft:stone
fill 22 70 -254 26 70 -254 minecraft:dirt
fill 8 69 -191 9 69 -191 minecraft:grass_block[snowy=false]
fill 10 69 -191 26 69 -191 minecraft:dirt
setblock 8 69 -192 minecraft:grass_block[snowy=false]
fill 9 69 -192 26 69 -192 minecraft:dirt
setblock 8 69 -193 minecraft:grass_block[snowy=false]
fill 9 69 -193 26 69 -193 minecraft:dirt
setblock 8 69 -194 minecraft:grass_block[snowy=false]
fill 9 69 -194 26 69 -194 minecraft:dirt
setblock 8 69 -195 minecraft:grass_block[snowy=false]
fill 9 69 -195 26 69 -195 minecraft:dirt
setblock 8 69 -196 minecraft:grass_block[snowy=false]
fill 9 69 -196 26 69 -196 minecraft:dirt
setblock 8 69 -197 minecraft:grass_block[snowy=false]
fill 9 69 -197 26 69 -197 minecraft:dirt
setblock 8 69 -198 minecraft:grass_block[snowy=false]
fill 9 69 -198 26 69 -198 minecraft:dirt
setblock 8 69 -199 minecraft:dirt
setblock 9 69 -199 minecraft:grass_block[snowy=false]
fill 10 69 -199 26 69 -199 minecraft:dirt
fill 8 69 -200 9 69 -200 minecraft:grass_block[snowy=false]
fill 10 69 -200 25 69 -200 minecraft:dirt
setblock 26 69 -200 minecraft:grass_block[snowy=false]
fill 8 69 -201 9 69 -201 minecraft:grass_block[snowy=false]
fill 10 69 -201 25 69 -201 minecraft:dirt
setblock 26 69 -201 minecraft:grass_block[snowy=false]
setblock 8 69 -202 minecraft:grass_block[snowy=false]
setblock 9 69 -202 minecraft:dirt
setblock 10 69 -202 minecraft:grass_block[snowy=false]
fill 11 69 -202 25 69 -202 minecraft:dirt
setblock 26 69 -202 minecraft:grass_block[snowy=false]
fill 8 69 -203 11 69 -203 minecraft:grass_block[snowy=false]
fill 12 69 -203 25 69 -203 minecraft:dirt
setblock 26 69 -203 minecraft:grass_block[snowy=false]
fill 8 69 -204 12 69 -204 minecraft:grass_block[snowy=false]
fill 13 69 -204 24 69 -204 minecraft:dirt
fill 25 69 -204 26 69 -204 minecraft:grass_block[snowy=false]
fill 9 69 -205 25 69 -205 minecraft:grass_block[snowy=false]
setblock 26 69 -205 minecraft:dirt
fill 9 69 -206 26 69 -206 minecraft:grass_block[snowy=false]
fill 10 69 -207 26 69 -207 minecraft:grass_block[snowy=false]
setblock 10 69 -208 minecraft:birch_log[axis=y]
fill 14 69 -208 25 69 -208 minecraft:grass_block[snowy=false]
setblock 8 69 -209 minecraft:birch_log[axis=y]
fill 15 69 -209 25 69 -209 minecraft:grass_block[snowy=false]
fill 16 69 -210 17 69 -210 minecraft:grass_block[snowy=false]
setblock 18 69 -210 minecraft:dirt
fill 19 69 -210 25 69 -210 minecraft:grass_block[snowy=false]
fill 17 69 -211 25 69 -211 minecraft:grass_block[snowy=false]
setblock 10 69 -212 minecraft:birch_log[axis=y]
fill 17 69 -212 19 69 -212 minecraft:grass_block[snowy=false]
fill 22 69 -212 25 69 -212 minecraft:grass_block[snowy=false]
setblock 16 69 -213 minecraft:air
fill 17 69 -213 19 69 -213 minecraft:grass_block[snowy=false]
setblock 8 69 -214 minecraft:birch_log[axis=y]
fill 15 69 -214 18 69 -214 minecraft:grass_block[snowy=false]
setblock 19 69 -214 minecraft:dirt
fill 14 69 -215 23 69 -215 minecraft:grass_block[snowy=false]
setblock 10 69 -216 minecraft:birch_log[axis=y]
fill 13 69 -216 24 69 -216 minecraft:grass_block[snowy=false]
fill 12 69 -217 14 69 -217 minecraft:grass_block[snowy=false]
setblock 15 69 -217 minecraft:dirt
fill 16 69 -217 17 69 -217 minecraft:grass_block[snowy=false]
setblock 18 69 -217 minecraft:dirt
fill 19 69 -217 20 69 -217 minecraft:grass_block[snowy=false]
setblock 21 69 -217 minecraft:dirt
fill 22 69 -217 24 69 -217 minecraft:grass_block[snowy=false]
fill 11 69 -218 22 69 -218 minecraft:grass_block[snowy=false]
setblock 23 69 -218 minecraft:dirt
setblock 24 69 -218 minecraft:grass_block[snowy=false]
fill 10 69 -219 11 69 -219 minecraft:grass_block[snowy=false]
setblock 12 69 -219 minecraft:dirt
fill 13 69 -219 16 69 -219 minecraft:grass_block[snowy=false]
setblock 17 69 -219 minecraft:dirt
fill 18 69 -219 24 69 -219 minecraft:grass_block[snowy=false]
fill 8 69 -220 14 69 -220 minecraft:grass_block[snowy=false]
setblock 15 69 -220 minecraft:dirt
fill 16 69 -220 24 69 -220 minecraft:grass_block[snowy=false]
fill 13 69 -221 24 69 -221 minecraft:grass_block[snowy=false]
fill 13 69 -222 24 69 -222 minecraft:grass_block[snowy=false]
fill 13 69 -223 24 69 -223 minecraft:grass_block[snowy=false]
fill 13 69 -224 24 69 -224 minecraft:grass_block[snowy=false]
fill 13 69 -225 24 69 -225 minecraft:grass_block[snowy=false]
fill 13 69 -226 24 69 -226 minecraft:grass_block[snowy=false]
fill 13 69 -227 20 69 -227 minecraft:grass_block[snowy=false]
setblock 21 69 -227 minecraft:dirt
fill 22 69 -227 24 69 -227 minecraft:grass_block[snowy=false]
fill 12 69 -228 24 69 -228 minecraft:grass_block[snowy=false]
fill 11 69 -229 18 69 -229 minecraft:dirt
fill 19 69 -229 24 69 -229 minecraft:grass_block[snowy=false]
fill 8 69 -230 9 69 -230 minecraft:grass_block[snowy=false]
fill 10 69 -230 20 69 -230 minecraft:dirt
fill 21 69 -230 25 69 -230 minecraft:grass_block[snowy=false]
setblock 8 69 -231 minecraft:grass_block[snowy=false]
fill 9 69 -231 25 69 -231 minecraft:dirt
fill 8 69 -232 25 69 -232 minecraft:dirt
fill 8 69 -233 25 69 -233 minecraft:dirt
fill 8 69 -234 25 69 -234 minecraft:dirt
fill 8 69 -235 25 69 -235 minecraft:dirt
fill 8 69 -236 26 69 -236 minecraft:dirt
fill 8 69 -237 22 69 -237 minecraft:dirt
setblock 23 69 -237 minecraft:rooted_dirt
fill 24 69 -237 25 69 -237 minecraft:dirt
setblock 26 69 -237 minecraft:rooted_dirt
fill 8 69 -238 22 69 -238 minecraft:dirt
fill 23 69 -238 26 69 -238 minecraft:rooted_dirt
fill 8 69 -239 22 69 -239 minecraft:dirt
fill 23 69 -239 26 69 -239 minecraft:rooted_dirt
fill 8 69 -240 23 69 -240 minecraft:dirt
fill 24 69 -240 25 69 -240 minecraft:rooted_dirt
setblock 26 69 -240 minecraft:dirt
fill 8 69 -241 26 69 -241 minecraft:dirt
fill 8 69 -242 10 69 -242 minecraft:dirt
fill 11 69 -242 12 69 -242 minecraft:stone
fill 13 69 -242 26 69 -242 minecraft:dirt
fill 8 69 -243 15 69 -243 minecraft:stone
fill 16 69 -243 26 69 -243 minecraft:dirt
fill 8 69 -244 17 69 -244 minecraft:stone
fill 18 69 -244 26 69 -244 minecraft:dirt
fill 8 69 -245 20 69 -245 minecraft:stone
fill 21 69 -245 24 69 -245 minecraft:dirt
setblock 25 69 -245 minecraft:calcite
setblock 26 69 -245 minecraft:dirt
fill 8 69 -246 21 69 -246 minecraft:stone
fill 22 69 -246 25 69 -246 minecraft:dirt
setblock 26 69 -246 create:limestone
fill 8 69 -247 22 69 -247 minecraft:stone
fill 23 69 -247 26 69 -247 minecraft:dirt
fill 8 69 -248 23 69 -248 minecraft:stone
fill 24 69 -248 26 69 -248 minecraft:dirt
fill 8 69 -249 23 69 -249 minecraft:stone
fill 24 69 -249 26 69 -249 minecraft:dirt
fill 8 69 -250 23 69 -250 minecraft:stone
fill 24 69 -250 26 69 -250 minecraft:dirt
fill 8 69 -251 23 69 -251 minecraft:stone
fill 24 69 -251 26 69 -251 minecraft:dirt
fill 8 69 -252 23 69 -252 minecraft:stone
fill 24 69 -252 26 69 -252 minecraft:dirt
fill 8 69 -253 22 69 -253 minecraft:stone
setblock 23 69 -253 alltheores:zinc_ore
fill 24 69 -253 26 69 -253 minecraft:dirt
fill 8 69 -254 20 69 -254 minecraft:stone
fill 21 69 -254 23 69 -254 alltheores:zinc_ore
fill 24 69 -254 26 69 -254 minecraft:dirt
fill 8 68 -191 26 68 -191 minecraft:dirt
fill 8 68 -192 26 68 -192 minecraft:dirt
fill 8 68 -193 26 68 -193 minecraft:dirt
fill 8 68 -194 26 68 -194 minecraft:dirt
fill 8 68 -195 26 68 -195 minecraft:dirt
fill 8 68 -196 26 68 -196 minecraft:dirt
fill 8 68 -197 26 68 -197 minecraft:dirt
fill 8 68 -198 26 68 -198 minecraft:dirt
fill 8 68 -199 26 68 -199 minecraft:dirt
fill 8 68 -200 26 68 -200 minecraft:dirt
fill 8 68 -201 26 68 -201 minecraft:dirt
fill 8 68 -202 26 68 -202 minecraft:dirt
fill 8 68 -203 26 68 -203 minecraft:dirt
fill 8 68 -204 26 68 -204 minecraft:dirt
setblock 8 68 -205 minecraft:grass_block[snowy=false]
fill 9 68 -205 26 68 -205 minecraft:dirt
setblock 8 68 -206 minecraft:grass_block[snowy=false]
fill 9 68 -206 26 68 -206 minecraft:dirt
fill 8 68 -207 9 68 -207 minecraft:grass_block[snowy=false]
fill 10 68 -207 26 68 -207 minecraft:dirt
fill 8 68 -208 9 68 -208 minecraft:grass_block[snowy=false]
setblock 10 68 -208 minecraft:dirt
fill 11 68 -208 13 68 -208 minecraft:grass_block[snowy=false]
fill 14 68 -208 25 68 -208 minecraft:dirt
setblock 8 68 -209 minecraft:dirt
fill 9 68 -209 14 68 -209 minecraft:grass_block[snowy=false]
fill 15 68 -209 25 68 -209 minecraft:dirt
fill 8 68 -210 15 68 -210 minecraft:grass_block[snowy=false]
fill 16 68 -210 25 68 -210 minecraft:dirt
fill 8 68 -211 16 68 -211 minecraft:grass_block[snowy=false]
fill 17 68 -211 25 68 -211 minecraft:dirt
fill 8 68 -212 9 68 -212 minecraft:grass_block[snowy=false]
setblock 10 68 -212 minecraft:dirt
fill 11 68 -212 16 68 -212 minecraft:grass_block[snowy=false]
fill 17 68 -212 19 68 -212 minecraft:dirt
fill 20 68 -212 21 68 -212 minecraft:grass_block[snowy=false]
fill 22 68 -212 25 68 -212 minecraft:dirt
fill 8 68 -213 16 68 -213 minecraft:grass_block[snowy=false]
fill 17 68 -213 19 68 -213 minecraft:dirt
setblock 20 68 -213 minecraft:grass_block[snowy=false]
setblock 8 68 -214 minecraft:dirt
fill 9 68 -214 14 68 -214 minecraft:grass_block[snowy=false]
fill 15 68 -214 19 68 -214 minecraft:dirt
setblock 20 68 -214 minecraft:grass_block[snowy=false]
fill 8 68 -215 13 68 -215 minecraft:grass_block[snowy=false]
fill 14 68 -215 22 68 -215 minecraft:dirt
fill 8 68 -216 9 68 -216 minecraft:grass_block[snowy=false]
setblock 10 68 -216 minecraft:dirt
fill 11 68 -216 12 68 -216 minecraft:grass_block[snowy=false]
fill 16 68 -216 24 68 -216 minecraft:dirt
fill 8 68 -217 10 68 -217 minecraft:grass_block[snowy=false]
fill 17 68 -217 24 68 -217 minecraft:dirt
fill 8 68 -218 9 68 -218 minecraft:grass_block[snowy=false]
fill 17 68 -218 24 68 -218 minecraft:dirt
setblock 8 68 -219 minecraft:grass_block[snowy=false]
fill 17 68 -219 24 68 -219 minecraft:dirt
fill 16 68 -220 24 68 -220 minecraft:dirt
fill 16 68 -221 24 68 -221 minecraft:dirt
fill 16 68 -222 24 68 -222 minecraft:dirt
fill 15 68 -223 24 68 -223 minecraft:dirt
fill 15 68 -224 24 68 -224 minecraft:dirt
fill 14 68 -225 24 68 -225 minecraft:dirt
fill 14 68 -226 24 68 -226 minecraft:dirt
fill 13 68 -227 24 68 -227 minecraft:dirt
fill 12 68 -228 24 68 -228 minecraft:dirt
fill 11 68 -229 24 68 -229 minecraft:dirt
fill 8 68 -230 25 68 -230 minecraft:dirt
fill 8 68 -231 25 68 -231 minecraft:dirt
fill 8 68 -232 25 68 -232 minecraft:dirt
fill 8 68 -233 25 68 -233 minecraft:dirt
fill 8 68 -234 25 68 -234 minecraft:dirt
fill 8 68 -235 25 68 -235 minecraft:dirt
fill 8 68 -236 26 68 -236 minecraft:dirt
fill 8 68 -237 22 68 -237 minecraft:dirt
fill 23 68 -237 24 68 -237 minecraft:rooted_dirt
fill 25 68 -237 26 68 -237 minecraft:dirt
fill 8 68 -238 21 68 -238 minecraft:dirt
fill 22 68 -238 26 68 -238 minecraft:rooted_dirt
fill 8 68 -239 12 68 -239 minecraft:dirt
fill 13 68 -239 16 68 -239 minecraft:stone
fill 17 68 -239 22 68 -239 minecraft:dirt
setblock 23 68 -239 minecraft:rooted_dirt
setblock 24 68 -239 minecraft:dirt
fill 25 68 -239 26 68 -239 minecraft:rooted_dirt
fill 8 68 -240 9 68 -240 minecraft:dirt
fill 10 68 -240 11 68 -240 alltheores:ruby_ore
fill 12 68 -240 17 68 -240 minecraft:stone
fill 18 68 -240 23 68 -240 minecraft:dirt
fill 24 68 -240 25 68 -240 minecraft:rooted_dirt
setblock 26 68 -240 minecraft:dirt
fill 8 68 -241 18 68 -241 minecraft:stone
fill 19 68 -241 22 68 -241 minecraft:dirt
fill 23 68 -241 24 68 -241 minecraft:stone
fill 25 68 -241 26 68 -241 minecraft:dirt
fill 8 68 -242 19 68 -242 minecraft:stone
fill 20 68 -242 26 68 -242 minecraft:dirt
fill 8 68 -243 23 68 -243 minecraft:stone
fill 24 68 -243 26 68 -243 minecraft:dirt
fill 8 68 -244 24 68 -244 minecraft:stone
setblock 25 68 -244 minecraft:calcite
setblock 26 68 -244 create:limestone
fill 8 68 -245 24 68 -245 minecraft:stone
setblock 25 68 -245 minecraft:calcite
setblock 26 68 -245 create:limestone
fill 8 68 -246 24 68 -246 minecraft:stone
setblock 25 68 -246 minecraft:calcite
setblock 26 68 -246 create:limestone
fill 8 68 -247 23 68 -247 minecraft:stone
fill 24 68 -247 25 68 -247 minecraft:calcite
setblock 26 68 -247 create:limestone
fill 8 68 -248 23 68 -248 minecraft:stone
fill 24 68 -248 25 68 -248 minecraft:calcite
setblock 26 68 -248 create:limestone
fill 8 68 -249 23 68 -249 minecraft:stone
fill 24 68 -249 25 68 -249 minecraft:calcite
setblock 26 68 -249 create:limestone
fill 8 68 -250 24 68 -250 minecraft:stone
setblock 25 68 -250 minecraft:calcite
setblock 26 68 -250 create:limestone
fill 8 68 -251 25 68 -251 minecraft:stone
setblock 26 68 -251 create:limestone
fill 8 68 -252 25 68 -252 minecraft:stone
setblock 26 68 -252 create:limestone
fill 8 68 -253 21 68 -253 minecraft:stone
fill 22 68 -253 23 68 -253 alltheores:zinc_ore
fill 24 68 -253 26 68 -253 minecraft:stone
fill 8 68 -254 19 68 -254 minecraft:stone
fill 20 68 -254 23 68 -254 alltheores:zinc_ore
fill 24 68 -254 26 68 -254 minecraft:stone
fill 8 67 -191 11 67 -191 minecraft:dirt
fill 12 67 -191 13 67 -191 minecraft:stone
fill 14 67 -191 26 67 -191 minecraft:dirt
fill 8 67 -192 11 67 -192 minecraft:dirt
fill 12 67 -192 16 67 -192 minecraft:stone
fill 17 67 -192 26 67 -192 minecraft:dirt
fill 8 67 -193 12 67 -193 minecraft:dirt
setblock 13 67 -193 minecraft:stone
setblock 14 67 -193 minecraft:dirt
fill 15 67 -193 17 67 -193 minecraft:stone
fill 18 67 -193 25 67 -193 minecraft:dirt
setblock 26 67 -193 minecraft:stone
fill 8 67 -194 11 67 -194 minecraft:dirt
fill 12 67 -194 18 67 -194 minecraft:stone
fill 19 67 -194 26 67 -194 minecraft:dirt
fill 8 67 -195 10 67 -195 minecraft:dirt
setblock 11 67 -195 minecraft:coal_ore
fill 12 67 -195 19 67 -195 minecraft:stone
fill 20 67 -195 26 67 -195 minecraft:dirt
fill 8 67 -196 11 67 -196 minecraft:dirt
fill 12 67 -196 19 67 -196 minecraft:stone
fill 20 67 -196 26 67 -196 minecraft:dirt
fill 8 67 -197 10 67 -197 minecraft:dirt
setblock 11 67 -197 minecraft:coal_ore
fill 12 67 -197 19 67 -197 minecraft:stone
fill 20 67 -197 26 67 -197 minecraft:dirt
fill 8 67 -198 11 67 -198 minecraft:dirt
fill 12 67 -198 18 67 -198 minecraft:stone
fill 19 67 -198 26 67 -198 minecraft:dirt
fill 8 67 -199 11 67 -199 minecraft:dirt
setblock 12 67 -199 theurgy:sal_ammoniac_ore
fill 13 67 -199 17 67 -199 minecraft:stone
fill 18 67 -199 26 67 -199 minecraft:dirt
fill 8 67 -200 11 67 -200 minecraft:dirt
setblock 12 67 -200 theurgy:sal_ammoniac_ore
fill 13 67 -200 16 67 -200 minecraft:stone
fill 17 67 -200 26 67 -200 minecraft:dirt
fill 8 67 -201 11 67 -201 minecraft:dirt
fill 12 67 -201 13 67 -201 minecraft:stone
fill 14 67 -201 26 67 -201 minecraft:dirt
fill 8 67 -202 26 67 -202 minecraft:dirt
fill 8 67 -203 26 67 -203 minecraft:dirt
fill 8 67 -204 26 67 -204 minecraft:dirt
fill 8 67 -205 26 67 -205 minecraft:dirt
fill 8 67 -206 26 67 -206 minecraft:dirt
fill 8 67 -207 26 67 -207 minecraft:dirt
fill 8 67 -208 25 67 -208 minecraft:dirt
fill 8 67 -209 25 67 -209 minecraft:dirt
fill 8 67 -210 25 67 -210 minecraft:dirt
fill 8 67 -211 25 67 -211 minecraft:dirt
fill 8 67 -212 25 67 -212 minecraft:dirt
fill 8 67 -213 20 67 -213 minecraft:dirt
fill 21 67 -213 22 67 -213 minecraft:grass_block[snowy=false]
setblock 25 67 -213 minecraft:grass_block[snowy=false]
fill 8 67 -214 12 67 -214 minecraft:dirt
setblock 17 67 -214 minecraft:air
fill 18 67 -214 20 67 -214 minecraft:dirt
setblock 21 67 -214 minecraft:grass_block[snowy=false]
fill 22 67 -214 23 67 -214 minecraft:short_grass
fill 8 67 -215 11 67 -215 minecraft:dirt
fill 19 67 -215 21 67 -215 minecraft:dirt
fill 8 67 -216 10 67 -216 minecraft:dirt
fill 19 67 -216 24 67 -216 minecraft:dirt
fill 8 67 -217 9 67 -217 minecraft:dirt
fill 19 67 -217 24 67 -217 minecraft:dirt
setblock 8 67 -218 minecraft:dirt
fill 19 67 -218 24 67 -218 minecraft:dirt
fill 19 67 -219 24 67 -219 minecraft:dirt
fill 18 67 -220 24 67 -220 minecraft:dirt
fill 18 67 -221 24 67 -221 minecraft:dirt
fill 17 67 -222 24 67 -222 minecraft:dirt
fill 16 67 -223 24 67 -223 minecraft:dirt
fill 16 67 -224 24 67 -224 minecraft:dirt
fill 15 67 -225 24 67 -225 minecraft:dirt
fill 14 67 -226 24 67 -226 minecraft:dirt
fill 13 67 -227 24 67 -227 minecraft:dirt
fill 12 67 -228 24 67 -228 minecraft:dirt
setblock 10 67 -229 minecraft:grass_block[snowy=false]
fill 11 67 -229 24 67 -229 minecraft:dirt
fill 8 67 -230 25 67 -230 minecraft:dirt
fill 8 67 -231 25 67 -231 minecraft:dirt
fill 8 67 -232 25 67 -232 minecraft:dirt
fill 8 67 -233 11 67 -233 minecraft:dirt
fill 12 67 -233 16 67 -233 minecraft:stone
fill 17 67 -233 25 67 -233 minecraft:dirt
fill 8 67 -234 17 67 -234 minecraft:stone
fill 18 67 -234 25 67 -234 minecraft:dirt
fill 8 67 -235 17 67 -235 minecraft:stone
fill 18 67 -235 25 67 -235 minecraft:dirt
fill 8 67 -236 18 67 -236 minecraft:stone
fill 19 67 -236 26 67 -236 minecraft:dirt
fill 8 67 -237 18 67 -237 minecraft:stone
setblock 19 67 -237 minecraft:iron_ore
fill 20 67 -237 22 67 -237 minecraft:dirt
setblock 23 67 -237 minecraft:rooted_dirt
fill 24 67 -237 26 67 -237 minecraft:dirt
fill 8 67 -238 22 67 -238 minecraft:stone
setblock 23 67 -238 minecraft:dirt
fill 24 67 -238 25 67 -238 minecraft:rooted_dirt
setblock 26 67 -238 create:limestone
fill 8 67 -239 21 67 -239 minecraft:stone
fill 22 67 -239 26 67 -239 minecraft:rooted_dirt
fill 8 67 -240 23 67 -240 minecraft:stone
fill 24 67 -240 25 67 -240 minecraft:rooted_dirt
setblock 26 67 -240 create:limestone
fill 8 67 -241 23 67 -241 minecraft:stone
setblock 24 67 -241 minecraft:rooted_dirt
fill 25 67 -241 26 67 -241 create:limestone
fill 8 67 -242 23 67 -242 minecraft:stone
setblock 24 67 -242 minecraft:calcite
fill 25 67 -242 26 67 -242 create:limestone
fill 8 67 -243 23 67 -243 minecraft:stone
setblock 24 67 -243 minecraft:calcite
fill 25 67 -243 26 67 -243 create:limestone
fill 8 67 -244 23 67 -244 minecraft:stone
setblock 24 67 -244 minecraft:calcite
fill 25 67 -244 26 67 -244 create:limestone
fill 8 67 -245 23 67 -245 minecraft:stone
setblock 24 67 -245 minecraft:calcite
fill 25 67 -245 26 67 -245 create:limestone
fill 8 67 -246 23 67 -246 minecraft:stone
setblock 24 67 -246 minecraft:calcite
fill 25 67 -246 26 67 -246 create:limestone
fill 8 67 -247 23 67 -247 minecraft:stone
setblock 24 67 -247 minecraft:calcite
fill 25 67 -247 26 67 -247 create:limestone
fill 8 67 -248 10 67 -248 minecraft:stone
setblock 11 67 -248 alltheores:peridot_ore
fill 12 67 -248 23 67 -248 minecraft:stone
setblock 24 67 -248 minecraft:calcite
fill 25 67 -248 26 67 -248 create:limestone
fill 8 67 -249 23 67 -249 minecraft:stone
setblock 24 67 -249 minecraft:calcite
fill 25 67 -249 26 67 -249 create:limestone
fill 8 67 -250 23 67 -250 minecraft:stone
setblock 24 67 -250 minecraft:calcite
fill 25 67 -250 26 67 -250 create:limestone
fill 8 67 -251 23 67 -251 minecraft:stone
setblock 24 67 -251 minecraft:calcite
fill 25 67 -251 26 67 -251 create:limestone
setblock 8 67 -252 minecraft:stone
fill 9 67 -252 10 67 -252 theurgy:sal_ammoniac_ore
fill 11 67 -252 24 67 -252 minecraft:stone
setblock 25 67 -252 minecraft:calcite
setblock 26 67 -252 create:limestone
setblock 8 67 -253 minecraft:stone
fill 9 67 -253 10 67 -253 theurgy:sal_ammoniac_ore
fill 11 67 -253 24 67 -253 minecraft:stone
setblock 25 67 -253 minecraft:calcite
setblock 26 67 -253 create:limestone
fill 8 67 -254 20 67 -254 minecraft:stone
fill 21 67 -254 22 67 -254 alltheores:zinc_ore
fill 23 67 -254 25 67 -254 minecraft:stone
setblock 26 67 -254 create:limestone
fill 8 66 -191 9 66 -191 minecraft:dirt
fill 10 66 -191 26 66 -191 minecraft:stone
setblock 8 66 -192 minecraft:dirt
setblock 9 66 -192 minecraft:stone
setblock 10 66 -192 minecraft:dirt
fill 11 66 -192 26 66 -192 minecraft:stone
setblock 8 66 -193 minecraft:dirt
setblock 9 66 -193 minecraft:stone
fill 10 66 -193 11 66 -193 minecraft:dirt
fill 12 66 -193 26 66 -193 minecraft:stone
setblock 8 66 -194 minecraft:dirt
fill 9 66 -194 26 66 -194 minecraft:stone
setblock 8 66 -195 minecraft:dirt
setblock 9 66 -195 minecraft:stone
fill 10 66 -195 11 66 -195 minecraft:coal_ore
fill 12 66 -195 24 66 -195 minecraft:stone
fill 25 66 -195 26 66 -195 minecraft:coal_ore
setblock 8 66 -196 minecraft:dirt
setblock 9 66 -196 minecraft:stone
fill 10 66 -196 11 66 -196 minecraft:coal_ore
fill 12 66 -196 24 66 -196 minecraft:stone
fill 25 66 -196 26 66 -196 minecraft:coal_ore
setblock 8 66 -197 minecraft:dirt
setblock 9 66 -197 minecraft:stone
fill 10 66 -197 11 66 -197 minecraft:coal_ore
fill 12 66 -197 26 66 -197 minecraft:stone
setblock 8 66 -198 minecraft:dirt
setblock 9 66 -198 minecraft:stone
fill 10 66 -198 11 66 -198 minecraft:coal_ore
fill 12 66 -198 26 66 -198 minecraft:stone
fill 8 66 -199 9 66 -199 minecraft:dirt
setblock 10 66 -199 minecraft:stone
setblock 11 66 -199 theurgy:sal_ammoniac_ore
fill 12 66 -199 26 66 -199 minecraft:stone
fill 8 66 -200 9 66 -200 minecraft:dirt
fill 10 66 -200 25 66 -200 minecraft:stone
setblock 26 66 -200 minecraft:dirt
fill 8 66 -201 9 66 -201 minecraft:dirt
fill 10 66 -201 24 66 -201 minecraft:stone
setblock 25 66 -201 alltheores:fluorite_ore
setblock 26 66 -201 minecraft:dirt
fill 8 66 -202 10 66 -202 minecraft:dirt
fill 11 66 -202 24 66 -202 minecraft:stone
setblock 25 66 -202 alltheores:fluorite_ore
setblock 26 66 -202 minecraft:dirt
fill 8 66 -203 11 66 -203 minecraft:dirt
fill 12 66 -203 24 66 -203 minecraft:stone
setblock 25 66 -203 alltheores:fluorite_ore
setblock 26 66 -203 minecraft:dirt
fill 8 66 -204 12 66 -204 minecraft:dirt
fill 13 66 -204 24 66 -204 minecraft:stone
fill 25 66 -204 26 66 -204 minecraft:dirt
fill 8 66 -205 26 66 -205 minecraft:dirt
fill 8 66 -206 26 66 -206 minecraft:dirt
fill 8 66 -207 9 66 -207 minecraft:dirt
fill 10 66 -207 14 66 -207 minecraft:stone
fill 15 66 -207 26 66 -207 minecraft:dirt
fill 8 66 -208 14 66 -208 minecraft:dirt
fill 15 66 -208 16 66 -208 minecraft:stone
fill 17 66 -208 25 66 -208 minecraft:dirt
fill 8 66 -209 14 66 -209 minecraft:dirt
setblock 15 66 -209 minecraft:stone
fill 16 66 -209 25 66 -209 minecraft:dirt
fill 8 66 -210 15 66 -210 minecraft:dirt
fill 16 66 -210 17 66 -210 minecraft:stone
fill 18 66 -210 25 66 -210 minecraft:dirt
fill 8 66 -211 16 66 -211 minecraft:dirt
fill 17 66 -211 19 66 -211 minecraft:stone
fill 20 66 -211 25 66 -211 minecraft:dirt
fill 8 66 -212 16 66 -212 minecraft:dirt
fill 17 66 -212 19 66 -212 minecraft:stone
fill 20 66 -212 25 66 -212 minecraft:dirt
fill 8 66 -213 12 66 -213 minecraft:dirt
fill 20 66 -213 22 66 -213 minecraft:dirt
fill 23 66 -213 24 66 -213 minecraft:grass_block[snowy=false]
setblock 25 66 -213 minecraft:dirt
fill 8 66 -214 11 66 -214 minecraft:dirt
setblock 17 66 -214 minecraft:air
setblock 21 66 -214 minecraft:dirt
fill 22 66 -214 23 66 -214 minecraft:grass_block[snowy=false]
fill 8 66 -215 10 66 -215 minecraft:dirt
setblock 21 66 -215 minecraft:stone
fill 22 66 -215 23 66 -215 minecraft:grass_block[snowy=false]
fill 8 66 -216 9 66 -216 minecraft:dirt
fill 21 66 -216 23 66 -216 minecraft:stone
setblock 24 66 -216 minecraft:dirt
setblock 8 66 -217 minecraft:dirt
fill 21 66 -217 22 66 -217 minecraft:stone
fill 23 66 -217 24 66 -217 minecraft:dirt
setblock 21 66 -218 minecraft:stone
fill 22 66 -218 24 66 -218 minecraft:gravel
fill 20 66 -219 21 66 -219 minecraft:stone
fill 22 66 -219 24 66 -219 minecraft:gravel
fill 20 66 -220 21 66 -220 minecraft:stone
fill 22 66 -220 23 66 -220 minecraft:gravel
setblock 24 66 -220 minecraft:dirt
fill 19 66 -221 23 66 -221 minecraft:stone
setblock 24 66 -221 minecraft:dirt
fill 18 66 -222 24 66 -222 minecraft:stone
fill 17 66 -223 22 66 -223 minecraft:stone
setblock 23 66 -223 minecraft:dirt
setblock 24 66 -223 minecraft:stone
fill 16 66 -224 21 66 -224 minecraft:stone
setblock 22 66 -224 minecraft:dirt
setblock 23 66 -224 minecraft:stone
setblock 24 66 -224 minecraft:dirt
fill 15 66 -225 16 66 -225 minecraft:dirt
setblock 17 66 -225 minecraft:stone
fill 18 66 -225 19 66 -225 minecraft:dirt
fill 20 66 -225 21 66 -225 minecraft:stone
fill 22 66 -225 24 66 -225 minecraft:dirt
fill 14 66 -226 24 66 -226 minecraft:dirt
fill 13 66 -227 24 66 -227 minecraft:dirt
setblock 11 66 -228 minecraft:stone
fill 12 66 -228 24 66 -228 minecraft:dirt
fill 8 66 -229 9 66 -229 minecraft:grass_block[snowy=false]
fill 10 66 -229 11 66 -229 minecraft:dirt
fill 12 66 -229 18 66 -229 minecraft:stone
fill 19 66 -229 24 66 -229 minecraft:dirt
setblock 8 66 -230 minecraft:dirt
fill 9 66 -230 20 66 -230 minecraft:stone
fill 21 66 -230 25 66 -230 minecraft:dirt
fill 8 66 -231 11 66 -231 minecraft:stone
setblock 12 66 -231 alltheores:peridot_ore
fill 13 66 -231 25 66 -231 minecraft:stone
fill 8 66 -232 25 66 -232 minecraft:stone
fill 8 66 -233 25 66 -233 minecraft:stone
fill 8 66 -234 25 66 -234 minecraft:stone
fill 8 66 -235 25 66 -235 minecraft:stone
fill 8 66 -236 10 66 -236 minecraft:stone
setblock 11 66 -236 minecraft:iron_ore
fill 12 66 -236 14 66 -236 minecraft:stone
fill 15 66 -236 16 66 -236 minecraft:coal_ore
fill 17 66 -236 26 66 -236 minecraft:stone
fill 8 66 -237 13 66 -237 minecraft:stone
fill 14 66 -237 16 66 -237 minecraft:coal_ore
fill 17 66 -237 18 66 -237 minecraft:stone
setblock 19 66 -237 minecraft:iron_ore
fill 20 66 -237 24 66 -237 minecraft:stone
fill 25 66 -237 26 66 -237 minecraft:rooted_dirt
fill 8 66 -238 13 66 -238 minecraft:stone
fill 14 66 -238 15 66 -238 minecraft:coal_ore
fill 16 66 -238 21 66 -238 minecraft:stone
setblock 22 66 -238 minecraft:rooted_dirt
setblock 23 66 -238 minecraft:stone
setblock 24 66 -238 minecraft:rooted_dirt
setblock 25 66 -238 create:limestone
setblock 26 66 -238 minecraft:stone
fill 8 66 -239 21 66 -239 minecraft:stone
fill 22 66 -239 24 66 -239 minecraft:rooted_dirt
setblock 25 66 -239 create:limestone
setblock 26 66 -239 minecraft:stone
fill 8 66 -240 21 66 -240 minecraft:stone
setblock 22 66 -240 minecraft:rooted_dirt
fill 23 66 -240 26 66 -240 create:limestone
fill 8 66 -241 22 66 -241 minecraft:stone
setblock 23 66 -241 create:limestone
fill 24 66 -241 25 66 -241 minecraft:rooted_dirt
setblock 26 66 -241 create:limestone
fill 8 66 -242 22 66 -242 minecraft:stone
setblock 23 66 -242 minecraft:calcite
fill 24 66 -242 26 66 -242 create:limestone
fill 8 66 -243 22 66 -243 minecraft:stone
setblock 23 66 -243 minecraft:calcite
fill 24 66 -243 26 66 -243 create:limestone
fill 8 66 -244 11 66 -244 minecraft:stone
fill 12 66 -244 14 66 -244 minecraft:coal_ore
fill 15 66 -244 22 66 -244 minecraft:stone
setblock 23 66 -244 minecraft:calcite
fill 24 66 -244 26 66 -244 create:limestone
fill 8 66 -245 10 66 -245 minecraft:stone
fill 11 66 -245 14 66 -245 minecraft:coal_ore
fill 15 66 -245 22 66 -245 minecraft:stone
setblock 23 66 -245 minecraft:calcite
fill 24 66 -245 25 66 -245 minecraft:copper_ore
setblock 26 66 -245 create:limestone
fill 8 66 -246 10 66 -246 minecraft:stone
setblock 11 66 -246 minecraft:coal_ore
fill 12 66 -246 22 66 -246 minecraft:stone
setblock 23 66 -246 minecraft:calcite
fill 24 66 -246 25 66 -246 minecraft:copper_ore
setblock 26 66 -246 minecraft:calcite
fill 8 66 -247 22 66 -247 minecraft:stone
setblock 23 66 -247 minecraft:calcite
fill 24 66 -247 25 66 -247 create:limestone
setblock 26 66 -247 minecraft:calcite
fill 8 66 -248 10 66 -248 minecraft:stone
fill 11 66 -248 12 66 -248 alltheores:peridot_ore
fill 13 66 -248 22 66 -248 minecraft:stone
setblock 23 66 -248 minecraft:calcite
fill 24 66 -248 25 66 -248 create:limestone
setblock 26 66 -248 minecraft:calcite
fill 8 66 -249 10 66 -249 minecraft:stone
fill 11 66 -249 12 66 -249 alltheores:peridot_ore
fill 13 66 -249 22 66 -249 minecraft:stone
setblock 23 66 -249 minecraft:calcite
fill 24 66 -249 26 66 -249 create:limestone
fill 8 66 -250 22 66 -250 minecraft:stone
setblock 23 66 -250 minecraft:calcite
fill 24 66 -250 26 66 -250 create:limestone
fill 8 66 -251 23 66 -251 minecraft:stone
setblock 24 66 -251 minecraft:calcite
fill 25 66 -251 26 66 -251 create:limestone
setblock 8 66 -252 minecraft:stone
fill 9 66 -252 10 66 -252 theurgy:sal_ammoniac_ore
fill 11 66 -252 23 66 -252 minecraft:stone
setblock 24 66 -252 minecraft:calcite
fill 25 66 -252 26 66 -252 create:limestone
setblock 8 66 -253 minecraft:stone
fill 9 66 -253 10 66 -253 theurgy:sal_ammoniac_ore
fill 11 66 -253 23 66 -253 minecraft:stone
setblock 24 66 -253 minecraft:calcite
fill 25 66 -253 26 66 -253 create:limestone
fill 8 66 -254 24 66 -254 minecraft:stone
setblock 25 66 -254 minecraft:calcite
setblock 26 66 -254 create:limestone
fill 8 65 -191 26 65 -191 minecraft:stone
fill 27 65 -191 34 65 -191 minecraft:air
fill 8 65 -192 26 65 -192 minecraft:stone
fill 27 65 -192 33 65 -192 minecraft:air
fill 8 65 -193 26 65 -193 minecraft:stone
fill 27 65 -193 33 65 -193 minecraft:air
fill 8 65 -194 26 65 -194 minecraft:stone
fill 27 65 -194 32 65 -194 minecraft:air
fill 8 65 -195 26 65 -195 minecraft:stone
fill 27 65 -195 32 65 -195 minecraft:air
fill 8 65 -196 10 65 -196 minecraft:stone
setblock 11 65 -196 minecraft:coal_ore
fill 12 65 -196 26 65 -196 minecraft:stone
fill 27 65 -196 31 65 -196 minecraft:air
fill 8 65 -197 9 65 -197 minecraft:stone
fill 10 65 -197 11 65 -197 minecraft:coal_ore
fill 12 65 -197 26 65 -197 minecraft:stone
fill 27 65 -197 31 65 -197 minecraft:air
fill 8 65 -198 10 65 -198 minecraft:stone
setblock 11 65 -198 minecraft:coal_ore
fill 12 65 -198 26 65 -198 minecraft:stone
fill 27 65 -198 30 65 -198 minecraft:air
fill 8 65 -199 26 65 -199 minecraft:stone
fill 27 65 -199 30 65 -199 minecraft:air
fill 8 65 -200 26 65 -200 minecraft:stone
fill 27 65 -200 30 65 -200 minecraft:air
fill 8 65 -201 26 65 -201 minecraft:stone
fill 27 65 -201 29 65 -201 minecraft:air
fill 8 65 -202 26 65 -202 minecraft:stone
fill 27 65 -202 29 65 -202 minecraft:air
fill 8 65 -203 26 65 -203 minecraft:stone
fill 27 65 -203 29 65 -203 minecraft:air
fill 8 65 -204 26 65 -204 minecraft:stone
fill 27 65 -204 28 65 -204 minecraft:air
setblock 8 65 -205 minecraft:dirt
fill 9 65 -205 26 65 -205 minecraft:stone
fill 27 65 -205 28 65 -205 minecraft:air
fill 8 65 -206 23 65 -206 minecraft:stone
setblock 24 65 -206 minecraft:copper_ore
fill 25 65 -206 26 65 -206 minecraft:stone
fill 27 65 -206 28 65 -206 minecraft:air
fill 8 65 -207 23 65 -207 minecraft:stone
setblock 24 65 -207 minecraft:copper_ore
fill 25 65 -207 26 65 -207 minecraft:stone
fill 27 65 -207 28 65 -207 minecraft:air
fill 8 65 -208 12 65 -208 minecraft:stone
setblock 13 65 -208 minecraft:dirt
fill 14 65 -208 22 65 -208 minecraft:stone
fill 23 65 -208 24 65 -208 minecraft:copper_ore
setblock 25 65 -208 minecraft:stone
setblock 27 65 -208 minecraft:air
fill 8 65 -209 25 65 -209 minecraft:stone
setblock 27 65 -209 minecraft:air
fill 8 65 -210 14 65 -210 minecraft:stone
setblock 15 65 -210 minecraft:dirt
fill 16 65 -210 25 65 -210 minecraft:stone
setblock 27 65 -210 minecraft:air
fill 8 65 -211 15 65 -211 minecraft:stone
fill 16 65 -211 18 65 -211 minecraft:air
fill 19 65 -211 25 65 -211 minecraft:stone
fill 8 65 -212 13 65 -212 minecraft:stone
fill 14 65 -212 20 65 -212 minecraft:air
setblock 21 65 -212 minecraft:dirt
fill 22 65 -212 25 65 -212 minecraft:stone
fill 8 65 -213 11 65 -213 minecraft:stone
fill 12 65 -213 21 65 -213 minecraft:air
fill 22 65 -213 25 65 -213 minecraft:dirt
fill 8 65 -214 10 65 -214 minecraft:stone
fill 11 65 -214 21 65 -214 minecraft:air
fill 22 65 -214 23 65 -214 minecraft:dirt
fill 8 65 -215 9 65 -215 minecraft:stone
fill 10 65 -215 21 65 -215 minecraft:air
fill 22 65 -215 23 65 -215 minecraft:dirt
fill 8 65 -216 9 65 -216 minecraft:stone
fill 10 65 -216 21 65 -216 minecraft:air
fill 22 65 -216 24 65 -216 minecraft:stone
setblock 8 65 -217 minecraft:stone
fill 9 65 -217 21 65 -217 minecraft:air
fill 22 65 -217 24 65 -217 minecraft:stone
setblock 8 65 -218 minecraft:stone
fill 9 65 -218 21 65 -218 minecraft:air
fill 22 65 -218 24 65 -218 minecraft:stone
fill 8 65 -219 20 65 -219 minecraft:air
fill 21 65 -219 24 65 -219 minecraft:stone
fill 8 65 -220 19 65 -220 minecraft:air
fill 20 65 -220 24 65 -220 minecraft:stone
fill 8 65 -221 18 65 -221 minecraft:air
fill 19 65 -221 24 65 -221 minecraft:stone
fill 8 65 -222 17 65 -222 minecraft:air
fill 18 65 -222 24 65 -222 minecraft:stone
fill 8 65 -223 16 65 -223 minecraft:air
fill 17 65 -223 24 65 -223 minecraft:stone
fill 8 65 -224 15 65 -224 minecraft:air
fill 16 65 -224 24 65 -224 minecraft:stone
fill 8 65 -225 14 65 -225 minecraft:air
fill 15 65 -225 24 65 -225 minecraft:stone
setblock 8 65 -226 minecraft:stone
fill 9 65 -226 12 65 -226 minecraft:air
fill 13 65 -226 24 65 -226 minecraft:stone
fill 8 65 -227 24 65 -227 minecraft:stone
fill 8 65 -228 23 65 -228 minecraft:stone
setblock 24 65 -228 minecraft:copper_ore
fill 8 65 -229 23 65 -229 minecraft:stone
setblock 24 65 -229 minecraft:copper_ore
setblock 27 65 -229 minecraft:air
fill 8 65 -230 25 65 -230 minecraft:stone
setblock 27 65 -230 minecraft:air
fill 8 65 -231 25 65 -231 minecraft:stone
setblock 27 65 -231 minecraft:air
fill 8 65 -232 25 65 -232 minecraft:stone
setblock 27 65 -232 minecraft:air
fill 8 65 -233 25 65 -233 minecraft:stone
setblock 27 65 -233 minecraft:air
fill 8 65 -234 25 65 -234 minecraft:stone
setblock 27 65 -234 minecraft:air
fill 8 65 -235 25 65 -235 minecraft:stone
fill 27 65 -235 28 65 -235 minecraft:air
fill 8 65 -236 9 65 -236 minecraft:stone
fill 10 65 -236 11 65 -236 minecraft:iron_ore
fill 12 65 -236 14 65 -236 minecraft:stone
fill 15 65 -236 16 65 -236 minecraft:coal_ore
fill 17 65 -236 26 65 -236 minecraft:stone
fill 27 65 -236 28 65 -236 minecraft:air
fill 8 65 -237 9 65 -237 minecraft:stone
fill 10 65 -237 11 65 -237 minecraft:iron_ore
setblock 12 65 -237 minecraft:stone
fill 13 65 -237 16 65 -237 minecraft:coal_ore
fill 17 65 -237 19 65 -237 minecraft:stone
setblock 20 65 -237 minecraft:copper_ore
fill 21 65 -237 22 65 -237 minecraft:stone
setblock 23 65 -237 minecraft:rooted_dirt
fill 24 65 -237 25 65 -237 minecraft:stone
setblock 26 65 -237 create:limestone
fill 27 65 -237 28 65 -237 minecraft:air
fill 8 65 -238 12 65 -238 minecraft:stone
fill 13 65 -238 16 65 -238 minecraft:coal_ore
fill 17 65 -238 18 65 -238 minecraft:stone
fill 19 65 -238 20 65 -238 minecraft:copper_ore
fill 21 65 -238 22 65 -238 minecraft:stone
fill 23 65 -238 26 65 -238 minecraft:rooted_dirt
fill 27 65 -238 28 65 -238 minecraft:air
fill 8 65 -239 12 65 -239 minecraft:stone
fill 13 65 -239 14 65 -239 minecraft:coal_ore
fill 15 65 -239 18 65 -239 minecraft:stone
fill 19 65 -239 20 65 -239 minecraft:copper_ore
fill 21 65 -239 22 65 -239 minecraft:stone
fill 23 65 -239 25 65 -239 minecraft:rooted_dirt
setblock 26 65 -239 minecraft:stone
fill 27 65 -239 29 65 -239 minecraft:air
fill 8 65 -240 22 65 -240 minecraft:stone
setblock 23 65 -240 minecraft:rooted_dirt
setblock 24 65 -240 create:limestone
setblock 25 65 -240 minecraft:rooted_dirt
setblock 26 65 -240 minecraft:calcite
fill 27 65 -240 29 65 -240 minecraft:air
fill 8 65 -241 21 65 -241 minecraft:stone
setblock 22 65 -241 minecraft:rooted_dirt
fill 23 65 -241 24 65 -241 create:limestone
setblock 25 65 -241 minecraft:rooted_dirt
setblock 26 65 -241 minecraft:calcite
fill 27 65 -241 29 65 -241 minecraft:air
fill 8 65 -242 21 65 -242 minecraft:stone
setblock 22 65 -242 minecraft:calcite
fill 23 65 -242 25 65 -242 create:limestone
setblock 26 65 -242 minecraft:calcite
fill 27 65 -242 30 65 -242 minecraft:air
fill 8 65 -243 22 65 -243 minecraft:stone
setblock 23 65 -243 minecraft:calcite
fill 24 65 -243 25 65 -243 create:limestone
setblock 26 65 -243 minecraft:calcite
fill 27 65 -243 30 65 -243 minecraft:air
fill 8 65 -244 11 65 -244 minecraft:stone
fill 12 65 -244 14 65 -244 minecraft:coal_ore
fill 15 65 -244 22 65 -244 minecraft:stone
setblock 23 65 -244 minecraft:calcite
fill 24 65 -244 25 65 -244 create:limestone
setblock 26 65 -244 minecraft:calcite
fill 27 65 -244 30 65 -244 minecraft:air
fill 8 65 -245 10 65 -245 minecraft:stone
fill 11 65 -245 14 65 -245 minecraft:coal_ore
fill 15 65 -245 22 65 -245 minecraft:stone
setblock 23 65 -245 minecraft:calcite
fill 24 65 -245 25 65 -245 minecraft:copper_ore
setblock 26 65 -245 minecraft:calcite
fill 27 65 -245 31 65 -245 minecraft:air
fill 8 65 -246 10 65 -246 minecraft:stone
setblock 11 65 -246 minecraft:coal_ore
fill 12 65 -246 21 65 -246 minecraft:stone
fill 22 65 -246 23 65 -246 create:limestone
fill 24 65 -246 25 65 -246 minecraft:copper_ore
setblock 26 65 -246 minecraft:calcite
fill 27 65 -246 31 65 -246 minecraft:air
fill 8 65 -247 21 65 -247 minecraft:stone
setblock 22 65 -247 minecraft:calcite
fill 23 65 -247 24 65 -247 create:limestone
fill 25 65 -247 26 65 -247 minecraft:calcite
fill 27 65 -247 32 65 -247 minecraft:air
fill 8 65 -248 21 65 -248 minecraft:stone
setblock 22 65 -248 minecraft:calcite
fill 23 65 -248 25 65 -248 create:limestone
setblock 26 65 -248 minecraft:calcite
fill 27 65 -248 32 65 -248 minecraft:air
fill 8 65 -249 11 65 -249 minecraft:stone
setblock 12 65 -249 alltheores:peridot_ore
fill 13 65 -249 21 65 -249 minecraft:stone
setblock 22 65 -249 minecraft:calcite
fill 23 65 -249 25 65 -249 create:limestone
setblock 26 65 -249 minecraft:calcite
fill 27 65 -249 33 65 -249 minecraft:air
fill 8 65 -250 22 65 -250 minecraft:stone
setblock 23 65 -250 minecraft:calcite
fill 24 65 -250 25 65 -250 create:limestone
setblock 26 65 -250 minecraft:calcite
fill 27 65 -250 33 65 -250 minecraft:air
fill 8 65 -251 22 65 -251 minecraft:stone
setblock 23 65 -251 minecraft:calcite
fill 24 65 -251 26 65 -251 create:limestone
fill 27 65 -251 34 65 -251 minecraft:air
fill 8 65 -252 23 65 -252 minecraft:stone
setblock 24 65 -252 minecraft:calcite
fill 25 65 -252 26 65 -252 create:limestone
fill 27 65 -252 34 65 -252 minecraft:air
fill 8 65 -253 23 65 -253 minecraft:stone
setblock 24 65 -253 minecraft:calcite
fill 25 65 -253 26 65 -253 create:limestone
fill 27 65 -253 35 65 -253 minecraft:air
fill 8 65 -254 23 65 -254 minecraft:stone
setblock 24 65 -254 minecraft:calcite
fill 25 65 -254 26 65 -254 create:limestone
fill 27 65 -254 36 65 -254 minecraft:air
fill 27 64 -191 36 64 -191 minecraft:air
fill 44 64 -191 47 64 -191 minecraft:air
fill 49 64 -191 52 64 -191 minecraft:air
fill 27 64 -192 36 64 -192 minecraft:air
fill 43 64 -192 53 64 -192 minecraft:air
fill 27 64 -193 35 64 -193 minecraft:air
fill 43 64 -193 54 64 -193 minecraft:air
fill 27 64 -194 35 64 -194 minecraft:air
fill 42 64 -194 54 64 -194 minecraft:air
fill 27 64 -195 34 64 -195 minecraft:air
fill 42 64 -195 54 64 -195 minecraft:air
fill 27 64 -196 34 64 -196 minecraft:air
fill 41 64 -196 42 64 -196 minecraft:air
fill 44 64 -196 47 64 -196 minecraft:air
fill 49 64 -196 52 64 -196 minecraft:air
setblock 54 64 -196 minecraft:air
fill 27 64 -197 33 64 -197 minecraft:air
fill 40 64 -197 54 64 -197 minecraft:air
fill 27 64 -198 33 64 -198 minecraft:air
fill 40 64 -198 54 64 -198 minecraft:air
fill 27 64 -199 33 64 -199 minecraft:air
fill 40 64 -199 54 64 -199 minecraft:air
fill 27 64 -200 32 64 -200 minecraft:air
fill 39 64 -200 54 64 -200 minecraft:air
fill 27 64 -201 32 64 -201 minecraft:air
fill 39 64 -201 42 64 -201 minecraft:air
fill 44 64 -201 47 64 -201 minecraft:air
fill 49 64 -201 52 64 -201 minecraft:air
fill 54 64 -201 55 64 -201 minecraft:air
fill 27 64 -202 31 64 -202 minecraft:air
fill 38 64 -202 55 64 -202 minecraft:air
fill 27 64 -203 31 64 -203 minecraft:air
fill 38 64 -203 40 64 -203 minecraft:air
fill 42 64 -203 55 64 -203 minecraft:air
fill 27 64 -204 31 64 -204 minecraft:air
fill 38 64 -204 55 64 -204 minecraft:air
fill 27 64 -205 31 64 -205 minecraft:air
fill 37 64 -205 55 64 -205 minecraft:air
fill 27 64 -206 30 64 -206 minecraft:air
setblock 37 64 -206 minecraft:air
fill 39 64 -206 42 64 -206 minecraft:air
fill 44 64 -206 47 64 -206 minecraft:air
fill 49 64 -206 52 64 -206 minecraft:air
fill 54 64 -206 55 64 -206 minecraft:air
fill 27 64 -207 30 64 -207 minecraft:air
fill 37 64 -207 55 64 -207 minecraft:air
fill 27 64 -208 30 64 -208 minecraft:air
fill 36 64 -208 56 64 -208 minecraft:air
fill 27 64 -209 30 64 -209 minecraft:air
fill 36 64 -209 56 64 -209 minecraft:air
fill 27 64 -210 29 64 -210 minecraft:air
fill 36 64 -210 56 64 -210 minecraft:air
fill 15 64 -211 21 64 -211 minecraft:air
fill 27 64 -211 29 64 -211 minecraft:air
fill 36 64 -211 37 64 -211 minecraft:air
fill 39 64 -211 42 64 -211 minecraft:air
fill 44 64 -211 47 64 -211 minecraft:air
fill 49 64 -211 52 64 -211 minecraft:air
fill 54 64 -211 56 64 -211 minecraft:air
fill 14 64 -212 22 64 -212 minecraft:air
fill 27 64 -212 29 64 -212 minecraft:air
fill 36 64 -212 46 64 -212 minecraft:air
fill 48 64 -212 56 64 -212 minecraft:air
fill 12 64 -213 22 64 -213 minecraft:air
fill 27 64 -213 29 64 -213 minecraft:air
fill 35 64 -213 56 64 -213 minecraft:air
fill 12 64 -214 23 64 -214 minecraft:air
fill 27 64 -214 29 64 -214 minecraft:air
fill 35 64 -214 56 64 -214 minecraft:air
fill 11 64 -215 23 64 -215 minecraft:air
fill 27 64 -215 29 64 -215 minecraft:air
fill 35 64 -215 56 64 -215 minecraft:air
fill 10 64 -216 23 64 -216 minecraft:air
fill 27 64 -216 29 64 -216 minecraft:air
fill 35 64 -216 37 64 -216 minecraft:air
fill 39 64 -216 42 64 -216 minecraft:air
fill 44 64 -216 47 64 -216 minecraft:air
fill 49 64 -216 52 64 -216 minecraft:air
fill 54 64 -216 55 64 -216 minecraft:air
fill 10 64 -217 22 64 -217 minecraft:air
fill 27 64 -217 28 64 -217 minecraft:air
fill 35 64 -217 37 64 -217 minecraft:air
fill 39 64 -217 54 64 -217 minecraft:air
fill 9 64 -218 22 64 -218 minecraft:air
fill 27 64 -218 28 64 -218 minecraft:air
fill 35 64 -218 54 64 -218 minecraft:air
fill 9 64 -219 21 64 -219 minecraft:air
fill 27 64 -219 28 64 -219 minecraft:air
fill 35 64 -219 53 64 -219 minecraft:air
fill 9 64 -220 20 64 -220 minecraft:air
fill 27 64 -220 28 64 -220 minecraft:air
fill 35 64 -220 52 64 -220 minecraft:air
fill 9 64 -221 18 64 -221 minecraft:air
fill 27 64 -221 28 64 -221 minecraft:air
fill 35 64 -221 37 64 -221 minecraft:air
fill 39 64 -221 42 64 -221 minecraft:air
fill 44 64 -221 47 64 -221 minecraft:air
fill 49 64 -221 52 64 -221 minecraft:air
fill 9 64 -222 16 64 -222 minecraft:air
fill 27 64 -222 28 64 -222 minecraft:air
fill 35 64 -222 51 64 -222 minecraft:air
fill 9 64 -223 15 64 -223 minecraft:air
fill 27 64 -223 28 64 -223 minecraft:air
fill 35 64 -223 50 64 -223 minecraft:air
fill 10 64 -224 14 64 -224 minecraft:air
fill 27 64 -224 28 64 -224 minecraft:air
fill 35 64 -224 50 64 -224 minecraft:air
fill 27 64 -225 28 64 -225 minecraft:air
fill 35 64 -225 49 64 -225 minecraft:air
fill 27 64 -226 29 64 -226 minecraft:air
fill 35 64 -226 37 64 -226 minecraft:air
fill 39 64 -226 42 64 -226 minecraft:air
fill 44 64 -226 47 64 -226 minecraft:air
fill 27 64 -227 29 64 -227 minecraft:air
fill 35 64 -227 48 64 -227 minecraft:air
fill 27 64 -228 29 64 -228 minecraft:air
fill 35 64 -228 47 64 -228 minecraft:air
fill 27 64 -229 29 64 -229 minecraft:air
fill 35 64 -229 46 64 -229 minecraft:air
fill 27 64 -230 29 64 -230 minecraft:air
fill 36 64 -230 46 64 -230 minecraft:air
fill 27 64 -231 29 64 -231 minecraft:air
fill 36 64 -231 37 64 -231 minecraft:air
fill 39 64 -231 42 64 -231 minecraft:air
fill 44 64 -231 45 64 -231 minecraft:air
fill 27 64 -232 29 64 -232 minecraft:air
fill 36 64 -232 45 64 -232 minecraft:air
fill 27 64 -233 30 64 -233 minecraft:air
fill 36 64 -233 44 64 -233 minecraft:air
fill 27 64 -234 30 64 -234 minecraft:air
fill 36 64 -234 43 64 -234 minecraft:air
fill 27 64 -235 30 64 -235 minecraft:air
fill 37 64 -235 43 64 -235 minecraft:air
fill 27 64 -236 35 64 -236 minecraft:air
setblock 37 64 -236 minecraft:air
fill 39 64 -236 42 64 -236 minecraft:air
fill 27 64 -237 35 64 -237 minecraft:air
fill 37 64 -237 41 64 -237 minecraft:air
fill 27 64 -238 35 64 -238 minecraft:air
fill 38 64 -238 41 64 -238 minecraft:air
fill 27 64 -239 36 64 -239 minecraft:air
fill 38 64 -239 40 64 -239 minecraft:air
fill 27 64 -240 36 64 -240 minecraft:air
fill 38 64 -240 39 64 -240 minecraft:air
fill 27 64 -241 36 64 -241 minecraft:air
setblock 39 64 -241 minecraft:air
fill 27 64 -242 37 64 -242 minecraft:air
fill 27 64 -243 37 64 -243 minecraft:air
fill 40 64 -243 42 64 -243 minecraft:air
fill 27 64 -244 38 64 -244 minecraft:air
fill 40 64 -244 47 64 -244 minecraft:air
fill 27 64 -245 38 64 -245 minecraft:air
fill 40 64 -245 52 64 -245 minecraft:air
fill 27 64 -246 39 64 -246 minecraft:air
fill 41 64 -246 42 64 -246 minecraft:air
fill 44 64 -246 47 64 -246 minecraft:air
fill 49 64 -246 52 64 -246 minecraft:air
fill 54 64 -246 57 64 -246 minecraft:air
fill 27 64 -247 39 64 -247 minecraft:air
fill 42 64 -247 63 64 -247 minecraft:air
fill 27 64 -248 40 64 -248 minecraft:air
fill 42 64 -248 69 64 -248 minecraft:air
fill 27 64 -249 40 64 -249 minecraft:air
fill 43 64 -249 71 64 -249 minecraft:air
fill 27 64 -250 41 64 -250 minecraft:air
fill 43 64 -250 71 64 -250 minecraft:air
fill 27 64 -251 41 64 -251 minecraft:air
fill 44 64 -251 47 64 -251 minecraft:air
fill 49 64 -251 52 64 -251 minecraft:air
fill 54 64 -251 57 64 -251 minecraft:air
fill 59 64 -251 62 64 -251 minecraft:air
fill 64 64 -251 67 64 -251 minecraft:air
fill 69 64 -251 71 64 -251 minecraft:air
fill 27 64 -252 42 64 -252 minecraft:air
fill 45 64 -252 71 64 -252 minecraft:air
fill 27 64 -253 43 64 -253 minecraft:air
fill 45 64 -253 71 64 -253 minecraft:air
fill 27 64 -254 43 64 -254 minecraft:air
fill 46 64 -254 71 64 -254 minecraft:air
fill 27 63 -191 36 63 -191 minecraft:air
fill 27 63 -192 36 63 -192 minecraft:air
fill 27 63 -193 35 63 -193 minecraft:air
fill 27 63 -194 35 63 -194 minecraft:air
fill 27 63 -195 34 63 -195 minecraft:air
fill 27 63 -196 34 63 -196 minecraft:air
fill 27 63 -197 33 63 -197 minecraft:air
fill 27 63 -198 33 63 -198 minecraft:air
fill 27 63 -199 33 63 -199 minecraft:air
fill 27 63 -200 32 63 -200 minecraft:air
fill 27 63 -201 32 63 -201 minecraft:air
fill 27 63 -202 31 63 -202 minecraft:air
fill 27 63 -203 31 63 -203 minecraft:air
fill 27 63 -204 31 63 -204 minecraft:air
fill 27 63 -205 31 63 -205 minecraft:air
fill 27 63 -206 30 63 -206 minecraft:air
fill 27 63 -207 30 63 -207 minecraft:air
fill 27 63 -208 30 63 -208 minecraft:air
fill 27 63 -209 30 63 -209 minecraft:air
fill 16 63 -210 21 63 -210 minecraft:air
fill 27 63 -210 29 63 -210 minecraft:air
fill 15 63 -211 22 63 -211 minecraft:air
fill 27 63 -211 29 63 -211 minecraft:air
fill 14 63 -212 23 63 -212 minecraft:air
fill 27 63 -212 29 63 -212 minecraft:air
fill 13 63 -213 23 63 -213 minecraft:air
fill 27 63 -213 29 63 -213 minecraft:air
fill 12 63 -214 24 63 -214 minecraft:air
fill 27 63 -214 29 63 -214 minecraft:air
fill 12 63 -215 24 63 -215 minecraft:air
fill 27 63 -215 29 63 -215 minecraft:air
fill 11 63 -216 24 63 -216 minecraft:air
fill 27 63 -216 29 63 -216 minecraft:air
fill 11 63 -217 23 63 -217 minecraft:air
fill 27 63 -217 28 63 -217 minecraft:air
fill 11 63 -218 23 63 -218 minecraft:air
setblock 28 63 -218 minecraft:air
fill 11 63 -219 22 63 -219 minecraft:air
setblock 28 63 -219 minecraft:air
fill 12 63 -220 20 63 -220 minecraft:air
fill 27 63 -220 28 63 -220 minecraft:air
fill 13 63 -221 18 63 -221 minecraft:air
fill 27 63 -221 28 63 -221 minecraft:air
fill 27 63 -222 28 63 -222 minecraft:air
fill 27 63 -223 28 63 -223 minecraft:air
fill 27 63 -224 28 63 -224 minecraft:air
fill 27 63 -225 28 63 -225 minecraft:air
fill 27 63 -226 29 63 -226 minecraft:air
fill 27 63 -227 29 63 -227 minecraft:air
fill 27 63 -228 29 63 -228 minecraft:air
fill 27 63 -229 29 63 -229 minecraft:air
fill 27 63 -230 29 63 -230 minecraft:air
fill 27 63 -231 29 63 -231 minecraft:air
setblock 27 63 -232 minecraft:air
fill 27 63 -233 30 63 -233 minecraft:air
fill 27 63 -234 30 63 -234 minecraft:air
fill 27 63 -235 30 63 -235 minecraft:air
fill 27 63 -236 35 63 -236 minecraft:air
fill 27 63 -237 35 63 -237 minecraft:air
fill 27 63 -238 35 63 -238 minecraft:air
fill 27 63 -239 36 63 -239 minecraft:air
fill 27 63 -240 36 63 -240 minecraft:air
fill 27 63 -241 36 63 -241 minecraft:air
fill 27 63 -242 37 63 -242 minecraft:air
fill 27 63 -243 37 63 -243 minecraft:air
fill 27 63 -244 38 63 -244 minecraft:air
fill 27 63 -245 38 63 -245 minecraft:air
fill 27 63 -246 39 63 -246 minecraft:air
fill 27 63 -247 39 63 -247 minecraft:air
fill 27 63 -248 40 63 -248 minecraft:air
fill 27 63 -249 40 63 -249 minecraft:air
fill 27 63 -250 41 63 -250 minecraft:air
fill 27 63 -251 41 63 -251 minecraft:air
fill 27 63 -252 42 63 -252 minecraft:air
fill 27 63 -253 43 63 -253 minecraft:air
fill 27 63 -254 43 63 -254 minecraft:air
fill 27 62 -191 36 62 -191 minecraft:air
fill 27 62 -192 36 62 -192 minecraft:air
fill 27 62 -193 35 62 -193 minecraft:air
fill 27 62 -194 35 62 -194 minecraft:air
fill 27 62 -195 34 62 -195 minecraft:air
fill 27 62 -196 34 62 -196 minecraft:air
fill 27 62 -197 33 62 -197 minecraft:air
fill 27 62 -198 33 62 -198 minecraft:air
fill 27 62 -199 33 62 -199 minecraft:air
fill 27 62 -200 32 62 -200 minecraft:air
fill 27 62 -201 32 62 -201 minecraft:air
fill 27 62 -202 31 62 -202 minecraft:air
fill 27 62 -203 31 62 -203 minecraft:air
fill 27 62 -204 31 62 -204 minecraft:air
fill 27 62 -205 31 62 -205 minecraft:air
fill 27 62 -206 30 62 -206 minecraft:air
fill 27 62 -207 30 62 -207 minecraft:air
fill 27 62 -208 30 62 -208 minecraft:air
fill 27 62 -209 30 62 -209 minecraft:air
fill 16 62 -210 22 62 -210 minecraft:air
fill 27 62 -210 29 62 -210 minecraft:air
fill 15 62 -211 23 62 -211 minecraft:air
fill 27 62 -211 29 62 -211 minecraft:air
fill 14 62 -212 24 62 -212 minecraft:air
fill 27 62 -212 29 62 -212 minecraft:air
fill 13 62 -213 25 62 -213 minecraft:air
fill 27 62 -213 29 62 -213 minecraft:air
fill 13 62 -214 25 62 -214 minecraft:air
fill 27 62 -214 29 62 -214 minecraft:air
fill 13 62 -215 25 62 -215 minecraft:air
fill 27 62 -215 29 62 -215 minecraft:air
fill 13 62 -216 25 62 -216 minecraft:air
fill 27 62 -216 29 62 -216 minecraft:air
fill 13 62 -217 24 62 -217 minecraft:air
fill 27 62 -217 28 62 -217 minecraft:air
fill 13 62 -218 23 62 -218 minecraft:air
setblock 28 62 -218 minecraft:air
fill 14 62 -219 22 62 -219 minecraft:air
setblock 28 62 -219 minecraft:air
fill 15 62 -220 21 62 -220 minecraft:air
fill 27 62 -220 28 62 -220 minecraft:air
fill 27 62 -221 28 62 -221 minecraft:air
fill 27 62 -222 28 62 -222 minecraft:air
fill 27 62 -223 28 62 -223 minecraft:air
fill 27 62 -224 28 62 -224 minecraft:air
fill 27 62 -225 28 62 -225 minecraft:air
fill 27 62 -226 29 62 -226 minecraft:air
fill 27 62 -227 29 62 -227 minecraft:air
fill 27 62 -228 29 62 -228 minecraft:air
fill 27 62 -229 29 62 -229 minecraft:air
fill 27 62 -230 29 62 -230 minecraft:air
fill 27 62 -231 29 62 -231 minecraft:air
setblock 27 62 -232 minecraft:air
fill 27 62 -233 30 62 -233 minecraft:air
fill 27 62 -234 30 62 -234 minecraft:air
fill 27 62 -235 30 62 -235 minecraft:air
fill 27 62 -236 35 62 -236 minecraft:air
fill 27 62 -237 35 62 -237 minecraft:air
fill 27 62 -238 35 62 -238 minecraft:air
fill 27 62 -239 36 62 -239 minecraft:air
fill 27 62 -240 36 62 -240 minecraft:air
fill 27 62 -241 36 62 -241 minecraft:air
fill 27 62 -242 37 62 -242 minecraft:air
fill 27 62 -243 37 62 -243 minecraft:air
fill 27 62 -244 38 62 -244 minecraft:air
fill 27 62 -245 38 62 -245 minecraft:air
fill 27 62 -246 39 62 -246 minecraft:air
fill 27 62 -247 39 62 -247 minecraft:air
fill 27 62 -248 40 62 -248 minecraft:air
fill 27 62 -249 40 62 -249 minecraft:air
fill 27 62 -250 41 62 -250 minecraft:air
fill 27 62 -251 41 62 -251 minecraft:air
fill 27 62 -252 42 62 -252 minecraft:air
fill 27 62 -253 43 62 -253 minecraft:air
fill 27 62 -254 43 62 -254 minecraft:air
fill 27 61 -191 36 61 -191 minecraft:air
fill 27 61 -192 36 61 -192 minecraft:air
fill 27 61 -193 35 61 -193 minecraft:air
fill 27 61 -194 35 61 -194 minecraft:air
fill 27 61 -195 34 61 -195 minecraft:air
fill 27 61 -196 34 61 -196 minecraft:air
fill 27 61 -197 33 61 -197 minecraft:air
fill 27 61 -198 33 61 -198 minecraft:air
fill 27 61 -199 33 61 -199 minecraft:air
fill 27 61 -200 32 61 -200 minecraft:air
fill 27 61 -201 32 61 -201 minecraft:air
fill 27 61 -202 31 61 -202 minecraft:air
fill 27 61 -203 31 61 -203 minecraft:air
fill 27 61 -204 31 61 -204 minecraft:air
fill 27 61 -205 31 61 -205 minecraft:air
fill 27 61 -206 30 61 -206 minecraft:air
fill 27 61 -207 30 61 -207 minecraft:air
fill 27 61 -208 30 61 -208 minecraft:air
fill 27 61 -209 30 61 -209 minecraft:air
fill 17 61 -210 23 61 -210 minecraft:air
fill 27 61 -210 29 61 -210 minecraft:air
fill 15 61 -211 25 61 -211 minecraft:air
fill 27 61 -211 29 61 -211 minecraft:air
fill 15 61 -212 25 61 -212 minecraft:air
fill 27 61 -212 29 61 -212 minecraft:air
fill 14 61 -213 29 61 -213 minecraft:air
fill 14 61 -214 29 61 -214 minecraft:air
fill 14 61 -215 29 61 -215 minecraft:air
fill 14 61 -216 29 61 -216 minecraft:air
fill 14 61 -217 25 61 -217 minecraft:air
fill 27 61 -217 28 61 -217 minecraft:air
fill 14 61 -218 25 61 -218 minecraft:air
setblock 28 61 -218 minecraft:air
fill 15 61 -219 24 61 -219 minecraft:air
setblock 28 61 -219 minecraft:air
fill 18 61 -220 20 61 -220 minecraft:air
fill 27 61 -220 28 61 -220 minecraft:air
fill 27 61 -221 28 61 -221 minecraft:air
fill 27 61 -222 28 61 -222 minecraft:air
fill 27 61 -223 28 61 -223 minecraft:air
fill 27 61 -224 28 61 -224 minecraft:air
fill 27 61 -225 28 61 -225 minecraft:air
fill 27 61 -226 29 61 -226 minecraft:air
fill 27 61 -227 29 61 -227 minecraft:air
fill 27 61 -228 29 61 -228 minecraft:air
fill 27 61 -229 29 61 -229 minecraft:air
fill 27 61 -230 29 61 -230 minecraft:air
fill 27 61 -231 29 61 -231 minecraft:air
setblock 27 61 -232 minecraft:air
fill 27 61 -233 30 61 -233 minecraft:air
fill 27 61 -234 30 61 -234 minecraft:air
fill 27 61 -235 30 61 -235 minecraft:air
fill 27 61 -236 35 61 -236 minecraft:air
fill 27 61 -237 35 61 -237 minecraft:air
fill 27 61 -238 35 61 -238 minecraft:air
fill 27 61 -239 36 61 -239 minecraft:air
fill 27 61 -240 36 61 -240 minecraft:air
fill 27 61 -241 36 61 -241 minecraft:air
fill 27 61 -242 37 61 -242 minecraft:air
fill 27 61 -243 37 61 -243 minecraft:air
fill 27 61 -244 38 61 -244 minecraft:air
fill 27 61 -245 38 61 -245 minecraft:air
fill 27 61 -246 39 61 -246 minecraft:air
fill 27 61 -247 39 61 -247 minecraft:air
fill 27 61 -248 40 61 -248 minecraft:air
fill 27 61 -249 40 61 -249 minecraft:air
fill 27 61 -250 41 61 -250 minecraft:air
fill 27 61 -251 41 61 -251 minecraft:air
fill 27 61 -252 42 61 -252 minecraft:air
fill 27 61 -253 43 61 -253 minecraft:air
fill 27 61 -254 43 61 -254 minecraft:air
fill 27 60 -191 36 60 -191 minecraft:air
fill 27 60 -192 36 60 -192 minecraft:air
fill 27 60 -193 35 60 -193 minecraft:air
fill 27 60 -194 35 60 -194 minecraft:air
fill 27 60 -195 34 60 -195 minecraft:air
fill 27 60 -196 34 60 -196 minecraft:air
fill 27 60 -197 33 60 -197 minecraft:air
fill 27 60 -198 33 60 -198 minecraft:air
fill 27 60 -199 33 60 -199 minecraft:air
fill 27 60 -200 32 60 -200 minecraft:air
fill 27 60 -201 32 60 -201 minecraft:air
fill 27 60 -202 31 60 -202 minecraft:air
fill 27 60 -203 31 60 -203 minecraft:air
fill 27 60 -204 31 60 -204 minecraft:air
fill 27 60 -205 31 60 -205 minecraft:air
fill 27 60 -206 30 60 -206 minecraft:air
fill 27 60 -207 30 60 -207 minecraft:air
fill 27 60 -208 30 60 -208 minecraft:air
fill 20 60 -209 22 60 -209 minecraft:air
fill 27 60 -209 30 60 -209 minecraft:air
fill 18 60 -210 25 60 -210 minecraft:air
fill 27 60 -210 29 60 -210 minecraft:air
fill 16 60 -211 29 60 -211 minecraft:air
fill 15 60 -212 29 60 -212 minecraft:air
fill 15 60 -213 29 60 -213 minecraft:air
fill 15 60 -214 29 60 -214 minecraft:air
fill 15 60 -215 29 60 -215 minecraft:air
fill 15 60 -216 29 60 -216 minecraft:air
fill 15 60 -217 28 60 -217 minecraft:air
fill 16 60 -218 25 60 -218 minecraft:air
setblock 28 60 -218 minecraft:air
fill 17 60 -219 24 60 -219 minecraft:air
setblock 28 60 -219 minecraft:air
fill 20 60 -220 23 60 -220 minecraft:air
fill 27 60 -220 28 60 -220 minecraft:air
fill 27 60 -221 28 60 -221 minecraft:air
fill 27 60 -222 28 60 -222 minecraft:air
fill 27 60 -223 28 60 -223 minecraft:air
fill 27 60 -224 28 60 -224 minecraft:air
fill 27 60 -225 28 60 -225 minecraft:air
fill 27 60 -226 29 60 -226 minecraft:air
fill 27 60 -227 29 60 -227 minecraft:air
fill 27 60 -228 29 60 -228 minecraft:air
fill 27 60 -229 29 60 -229 minecraft:air
fill 27 60 -230 29 60 -230 minecraft:air
fill 27 60 -231 29 60 -231 minecraft:air
setblock 27 60 -232 minecraft:air
fill 27 60 -233 30 60 -233 minecraft:air
fill 27 60 -234 30 60 -234 minecraft:air
fill 27 60 -235 30 60 -235 minecraft:air
fill 27 60 -236 35 60 -236 minecraft:air
fill 27 60 -237 35 60 -237 minecraft:air
fill 27 60 -238 35 60 -238 minecraft:air
fill 27 60 -239 36 60 -239 minecraft:air
fill 27 60 -240 36 60 -240 minecraft:air
fill 27 60 -241 36 60 -241 minecraft:air
fill 27 60 -242 37 60 -242 minecraft:air
fill 27 60 -243 37 60 -243 minecraft:air
fill 27 60 -244 38 60 -244 minecraft:air
fill 27 60 -245 38 60 -245 minecraft:air
fill 27 60 -246 39 60 -246 minecraft:air
fill 27 60 -247 39 60 -247 minecraft:air
fill 27 60 -248 40 60 -248 minecraft:air
fill 27 60 -249 40 60 -249 minecraft:air
fill 27 60 -250 41 60 -250 minecraft:air
fill 27 60 -251 41 60 -251 minecraft:air
fill 27 60 -252 42 60 -252 minecraft:air
fill 27 60 -253 43 60 -253 minecraft:air
fill 27 60 -254 43 60 -254 minecraft:air
fill 21 59 -209 25 59 -209 minecraft:air
fill 18 59 -210 27 59 -210 minecraft:air
fill 17 59 -211 27 59 -211 minecraft:air
fill 17 59 -212 28 59 -212 minecraft:air
fill 16 59 -213 28 59 -213 minecraft:air
fill 16 59 -214 28 59 -214 minecraft:air
fill 16 59 -215 28 59 -215 minecraft:air
fill 16 59 -216 27 59 -216 minecraft:air
fill 17 59 -217 27 59 -217 minecraft:air
fill 17 59 -218 26 59 -218 minecraft:air
fill 18 59 -219 25 59 -219 minecraft:air
fill 20 59 -220 22 59 -220 minecraft:air
fill 27 59 -236 35 59 -236 minecraft:air
fill 27 59 -237 35 59 -237 minecraft:air
fill 27 59 -238 35 59 -238 minecraft:air
fill 27 59 -239 36 59 -239 minecraft:air
fill 27 59 -240 36 59 -240 minecraft:air
fill 27 59 -241 36 59 -241 minecraft:air
fill 27 59 -242 37 59 -242 minecraft:air
fill 27 59 -243 37 59 -243 minecraft:air
fill 27 59 -244 38 59 -244 minecraft:air
fill 27 59 -245 38 59 -245 minecraft:air
fill 27 59 -246 39 59 -246 minecraft:air
fill 27 59 -247 39 59 -247 minecraft:air
fill 27 59 -248 40 59 -248 minecraft:air
fill 27 59 -249 40 59 -249 minecraft:air
fill 27 59 -250 41 59 -250 minecraft:air
fill 27 59 -251 41 59 -251 minecraft:air
fill 27 59 -252 42 59 -252 minecraft:air
fill 27 59 -253 43 59 -253 minecraft:air
fill 27 59 -254 43 59 -254 minecraft:air
setblock 33 58 -202 minecraft:air
fill 31 58 -203 34 58 -203 minecraft:air
fill 31 58 -204 35 58 -204 minecraft:air
fill 31 58 -205 36 58 -205 minecraft:air
fill 31 58 -206 36 58 -206 minecraft:air
fill 30 58 -207 35 58 -207 minecraft:air
fill 22 58 -208 27 58 -208 minecraft:air
fill 29 58 -208 35 58 -208 minecraft:air
fill 49 58 -208 51 58 -208 minecraft:air
fill 20 58 -209 35 58 -209 minecraft:air
fill 49 58 -209 51 58 -209 minecraft:air
fill 19 58 -210 34 58 -210 minecraft:air
fill 49 58 -210 50 58 -210 minecraft:air
fill 18 58 -211 33 58 -211 minecraft:air
fill 48 58 -211 50 58 -211 minecraft:air
fill 17 58 -212 29 58 -212 minecraft:air
fill 48 58 -212 50 58 -212 minecraft:air
fill 17 58 -213 29 58 -213 minecraft:air
fill 47 58 -213 50 58 -213 minecraft:air
fill 17 58 -214 29 58 -214 minecraft:air
fill 47 58 -214 50 58 -214 minecraft:air
fill 17 58 -215 28 58 -215 minecraft:air
fill 48 58 -215 50 58 -215 minecraft:air
fill 17 58 -216 28 58 -216 minecraft:air
fill 48 58 -216 50 58 -216 minecraft:air
fill 17 58 -217 27 58 -217 minecraft:air
fill 48 58 -217 50 58 -217 minecraft:air
fill 18 58 -218 26 58 -218 minecraft:air
fill 48 58 -218 50 58 -218 minecraft:air
fill 19 58 -219 25 58 -219 minecraft:air
fill 48 58 -219 50 58 -219 minecraft:air
fill 48 58 -220 49 58 -220 minecraft:air
fill 48 58 -221 49 58 -221 minecraft:air
fill 47 58 -222 49 58 -222 minecraft:air
fill 47 58 -223 49 58 -223 minecraft:air
fill 47 58 -224 48 58 -224 minecraft:air
fill 46 58 -225 47 58 -225 minecraft:air
fill 30 57 -200 34 57 -200 minecraft:air
fill 29 57 -201 35 57 -201 minecraft:air
fill 28 57 -202 36 57 -202 minecraft:air
fill 28 57 -203 37 57 -203 minecraft:air
fill 29 57 -204 37 57 -204 minecraft:air
fill 29 57 -205 37 57 -205 minecraft:air
fill 25 57 -206 37 57 -206 minecraft:air
fill 22 57 -207 37 57 -207 minecraft:air
fill 21 57 -208 37 57 -208 minecraft:air
fill 49 57 -208 51 57 -208 minecraft:air
fill 20 57 -209 37 57 -209 minecraft:air
fill 49 57 -209 51 57 -209 minecraft:air
fill 19 57 -210 36 57 -210 minecraft:air
fill 49 57 -210 51 57 -210 minecraft:air
fill 19 57 -211 36 57 -211 minecraft:air
fill 48 57 -211 50 57 -211 minecraft:air
fill 18 57 -212 35 57 -212 minecraft:air
fill 48 57 -212 50 57 -212 minecraft:air
fill 18 57 -213 33 57 -213 minecraft:air
fill 48 57 -213 50 57 -213 minecraft:air
fill 18 57 -214 29 57 -214 minecraft:air
fill 48 57 -214 50 57 -214 minecraft:air
setblock 18 57 -215 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 19 57 -215 29 57 -215 minecraft:air
fill 49 57 -215 50 57 -215 minecraft:air
fill 18 57 -216 28 57 -216 minecraft:air
fill 49 57 -216 50 57 -216 minecraft:air
fill 19 57 -217 27 57 -217 minecraft:air
fill 49 57 -217 50 57 -217 minecraft:air
setblock 19 57 -218 minecraft:air
setblock 20 57 -218 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=false,waterlogged=false,west=false]
fill 21 57 -218 26 57 -218 minecraft:air
fill 49 57 -218 50 57 -218 minecraft:air
fill 21 57 -219 25 57 -219 minecraft:air
fill 49 57 -219 50 57 -219 minecraft:air
fill 49 57 -220 50 57 -220 minecraft:air
fill 49 57 -221 50 57 -221 minecraft:air
fill 49 57 -222 50 57 -222 minecraft:air
fill 48 57 -223 50 57 -223 minecraft:air
fill 48 57 -224 49 57 -224 minecraft:air
fill 47 57 -225 48 57 -225 minecraft:air
fill 46 57 -226 47 57 -226 minecraft:air
fill 30 56 -198 32 56 -198 minecraft:air
fill 28 56 -199 34 56 -199 minecraft:air
fill 27 56 -200 36 56 -200 minecraft:air
fill 26 56 -201 36 56 -201 minecraft:air
fill 26 56 -202 37 56 -202 minecraft:air
fill 26 56 -203 38 56 -203 minecraft:air
fill 27 56 -204 38 56 -204 minecraft:air
setblock 25 56 -205 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=false,west=true]
fill 26 56 -205 38 56 -205 minecraft:air
fill 23 56 -206 38 56 -206 minecraft:air
fill 22 56 -207 38 56 -207 minecraft:air
fill 21 56 -208 38 56 -208 minecraft:air
fill 50 56 -208 51 56 -208 minecraft:air
fill 20 56 -209 38 56 -209 minecraft:air
fill 49 56 -209 51 56 -209 minecraft:air
fill 19 56 -210 37 56 -210 minecraft:air
fill 49 56 -210 51 56 -210 minecraft:air
fill 19 56 -211 37 56 -211 minecraft:air
fill 49 56 -211 51 56 -211 minecraft:air
fill 19 56 -212 36 56 -212 minecraft:air
fill 48 56 -212 50 56 -212 minecraft:air
fill 18 56 -213 35 56 -213 minecraft:air
fill 48 56 -213 50 56 -213 minecraft:air
fill 19 56 -214 33 56 -214 minecraft:air
fill 48 56 -214 50 56 -214 minecraft:air
fill 19 56 -215 29 56 -215 minecraft:air
fill 49 56 -215 50 56 -215 minecraft:air
fill 19 56 -216 28 56 -216 minecraft:air
setblock 50 56 -216 minecraft:air
fill 20 56 -217 27 56 -217 minecraft:air
setblock 50 56 -217 minecraft:air
fill 21 56 -218 26 56 -218 minecraft:air
setblock 50 56 -218 minecraft:air
setblock 50 56 -219 minecraft:air
fill 50 56 -220 51 56 -220 minecraft:air
fill 50 56 -221 51 56 -221 minecraft:air
setblock 50 56 -222 minecraft:air
fill 49 56 -223 50 56 -223 minecraft:air
fill 49 56 -224 50 56 -224 minecraft:air
fill 48 56 -225 50 56 -225 minecraft:air
fill 48 56 -226 49 56 -226 minecraft:air
fill 27 55 -198 33 55 -198 minecraft:air
fill 26 55 -199 35 55 -199 minecraft:air
fill 25 55 -200 36 55 -200 minecraft:air
fill 24 55 -201 37 55 -201 minecraft:air
fill 24 55 -202 37 55 -202 minecraft:air
fill 25 55 -203 38 55 -203 minecraft:air
fill 25 55 -204 38 55 -204 minecraft:air
fill 24 55 -205 38 55 -205 minecraft:air
fill 23 55 -206 38 55 -206 minecraft:air
fill 21 55 -207 38 55 -207 minecraft:air
fill 21 55 -208 38 55 -208 minecraft:air
fill 20 55 -209 38 55 -209 minecraft:air
fill 50 55 -209 51 55 -209 minecraft:air
fill 20 55 -210 37 55 -210 minecraft:air
fill 50 55 -210 51 55 -210 minecraft:air
fill 19 55 -211 37 55 -211 minecraft:air
fill 49 55 -211 51 55 -211 minecraft:air
fill 19 55 -212 36 55 -212 minecraft:air
fill 49 55 -212 51 55 -212 minecraft:air
fill 19 55 -213 35 55 -213 minecraft:air
fill 48 55 -213 51 55 -213 minecraft:air
setblock 19 55 -214 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 20 55 -214 34 55 -214 minecraft:air
fill 48 55 -214 51 55 -214 minecraft:air
fill 20 55 -215 31 55 -215 minecraft:air
fill 49 55 -215 51 55 -215 minecraft:air
fill 20 55 -216 28 55 -216 minecraft:air
fill 50 55 -216 51 55 -216 minecraft:air
fill 21 55 -217 27 55 -217 minecraft:air
fill 50 55 -217 51 55 -217 minecraft:air
fill 23 55 -218 24 55 -218 minecraft:air
fill 50 55 -218 51 55 -218 minecraft:air
fill 50 55 -219 51 55 -219 minecraft:air
setblock 51 55 -220 minecraft:air
fill 50 55 -221 51 55 -221 minecraft:air
fill 50 55 -222 51 55 -222 minecraft:air
fill 50 55 -223 51 55 -223 minecraft:air
fill 50 55 -224 52 55 -224 minecraft:air
fill 50 55 -225 51 55 -225 minecraft:air
fill 49 55 -226 51 55 -226 minecraft:air
fill 49 55 -227 50 55 -227 minecraft:air
fill 28 54 -197 31 54 -197 minecraft:air
fill 25 54 -198 33 54 -198 minecraft:air
fill 24 54 -199 35 54 -199 minecraft:air
fill 23 54 -200 36 54 -200 minecraft:air
fill 23 54 -201 37 54 -201 minecraft:air
fill 23 54 -202 37 54 -202 minecraft:air
fill 23 54 -203 37 54 -203 minecraft:air
fill 24 54 -204 38 54 -204 minecraft:air
fill 24 54 -205 38 54 -205 minecraft:air
fill 23 54 -206 38 54 -206 minecraft:air
fill 22 54 -207 38 54 -207 minecraft:air
fill 21 54 -208 38 54 -208 minecraft:air
fill 21 54 -209 38 54 -209 minecraft:air
setblock 50 54 -209 minecraft:air
fill 20 54 -210 37 54 -210 minecraft:air
fill 50 54 -210 51 54 -210 minecraft:air
fill 20 54 -211 36 54 -211 minecraft:air
fill 49 54 -211 51 54 -211 minecraft:air
fill 20 54 -212 36 54 -212 minecraft:air
fill 49 54 -212 51 54 -212 minecraft:air
fill 20 54 -213 35 54 -213 minecraft:air
fill 49 54 -213 51 54 -213 minecraft:air
fill 20 54 -214 33 54 -214 minecraft:air
fill 48 54 -214 51 54 -214 minecraft:air
fill 21 54 -215 30 54 -215 minecraft:air
fill 49 54 -215 51 54 -215 minecraft:air
fill 22 54 -216 27 54 -216 minecraft:air
fill 50 54 -216 51 54 -216 minecraft:air
setblock 24 54 -217 minecraft:air
fill 50 54 -217 51 54 -217 minecraft:air
setblock 51 54 -218 minecraft:air
fill 51 54 -219 52 54 -219 minecraft:air
fill 51 54 -220 52 54 -220 minecraft:air
fill 51 54 -221 52 54 -221 minecraft:air
fill 51 54 -222 52 54 -222 minecraft:air
fill 51 54 -223 53 54 -223 minecraft:air
fill 51 54 -224 53 54 -224 minecraft:air
fill 51 54 -225 53 54 -225 minecraft:air
fill 50 54 -226 54 54 -226 minecraft:air
fill 50 54 -227 56 54 -227 minecraft:air
fill 50 54 -228 56 54 -228 minecraft:air
fill 52 54 -229 55 54 -229 minecraft:air
fill 53 54 -230 55 54 -230 minecraft:air
fill 53 54 -231 55 54 -231 minecraft:air
fill 53 54 -232 54 54 -232 minecraft:air
fill 53 54 -233 54 54 -233 minecraft:air
setblock 53 54 -234 minecraft:air
setblock 53 54 -235 minecraft:air
fill 26 53 -197 29 53 -197 minecraft:air
fill 24 53 -198 32 53 -198 minecraft:air
fill 23 53 -199 34 53 -199 minecraft:air
fill 23 53 -200 35 53 -200 minecraft:air
fill 22 53 -201 36 53 -201 minecraft:air
fill 22 53 -202 36 53 -202 minecraft:air
fill 22 53 -203 37 53 -203 minecraft:air
fill 23 53 -204 37 53 -204 minecraft:air
fill 23 53 -205 37 53 -205 minecraft:air
fill 24 53 -206 37 53 -206 minecraft:air
fill 23 53 -207 37 53 -207 minecraft:air
fill 22 53 -208 37 53 -208 minecraft:air
fill 22 53 -209 37 53 -209 minecraft:air
fill 21 53 -210 36 53 -210 minecraft:air
setblock 50 53 -210 minecraft:air
fill 21 53 -211 35 53 -211 minecraft:air
fill 49 53 -211 52 53 -211 minecraft:air
fill 21 53 -212 35 53 -212 minecraft:air
fill 49 53 -212 52 53 -212 minecraft:air
fill 22 53 -213 34 53 -213 minecraft:air
fill 49 53 -213 52 53 -213 minecraft:air
fill 22 53 -214 31 53 -214 minecraft:air
fill 49 53 -214 52 53 -214 minecraft:air
fill 24 53 -215 27 53 -215 minecraft:air
fill 49 53 -215 52 53 -215 minecraft:air
fill 50 53 -216 52 53 -216 minecraft:air
fill 50 53 -217 52 53 -217 minecraft:air
fill 51 53 -218 52 53 -218 minecraft:air
fill 51 53 -219 52 53 -219 minecraft:air
fill 52 53 -220 53 53 -220 minecraft:air
fill 52 53 -221 53 53 -221 minecraft:air
fill 52 53 -222 53 53 -222 minecraft:air
setblock 71 53 -222 minecraft:air
fill 52 53 -223 54 53 -223 minecraft:air
fill 70 53 -223 71 53 -223 minecraft:air
fill 52 53 -224 55 53 -224 minecraft:air
fill 70 53 -224 71 53 -224 minecraft:air
fill 52 53 -225 59 53 -225 minecraft:air
setblock 70 53 -225 minecraft:air
fill 52 53 -226 59 53 -226 minecraft:air
fill 52 53 -227 59 53 -227 minecraft:air
fill 51 53 -228 59 53 -228 minecraft:air
fill 51 53 -229 59 53 -229 minecraft:air
fill 51 53 -230 59 53 -230 minecraft:air
fill 52 53 -231 59 53 -231 minecraft:air
setblock 61 53 -231 minecraft:air
fill 52 53 -232 61 53 -232 minecraft:air
fill 53 53 -233 60 53 -233 minecraft:air
fill 53 53 -234 59 53 -234 minecraft:air
fill 53 53 -235 59 53 -235 minecraft:air
fill 53 53 -236 59 53 -236 minecraft:air
fill 53 53 -237 58 53 -237 minecraft:air
fill 53 53 -238 58 53 -238 minecraft:air
fill 53 53 -239 58 53 -239 minecraft:air
fill 53 53 -240 58 53 -240 minecraft:air
fill 53 53 -241 55 53 -241 minecraft:air
fill 57 53 -241 58 53 -241 minecraft:air
fill 53 53 -242 55 53 -242 minecraft:air
setblock 58 53 -242 minecraft:air
setblock 54 53 -243 minecraft:air
setblock 54 53 -244 minecraft:air
setblock 61 53 -251 minecraft:air
setblock 61 53 -252 minecraft:air
setblock 62 53 -253 minecraft:air
fill 62 53 -254 63 53 -254 minecraft:air
fill 26 52 -195 28 52 -195 minecraft:air
fill 25 52 -196 28 52 -196 minecraft:air
fill 25 52 -197 28 52 -197 minecraft:air
fill 24 52 -198 30 52 -198 minecraft:air
fill 23 52 -199 32 52 -199 minecraft:air
fill 23 52 -200 33 52 -200 minecraft:air
fill 22 52 -201 34 52 -201 minecraft:air
fill 44 52 -201 49 52 -201 minecraft:air
fill 22 52 -202 34 52 -202 minecraft:air
fill 44 52 -202 51 52 -202 minecraft:air
fill 22 52 -203 34 52 -203 minecraft:air
fill 45 52 -203 50 52 -203 minecraft:air
fill 23 52 -204 33 52 -204 minecraft:air
fill 23 52 -205 33 52 -205 minecraft:air
fill 23 52 -206 31 52 -206 minecraft:air
fill 23 52 -207 27 52 -207 minecraft:air
fill 23 52 -208 27 52 -208 minecraft:air
fill 22 52 -209 26 52 -209 minecraft:air
fill 22 52 -210 26 52 -210 minecraft:air
fill 22 52 -211 26 52 -211 minecraft:air
fill 50 52 -211 51 52 -211 minecraft:air
fill 22 52 -212 25 52 -212 minecraft:air
fill 49 52 -212 52 52 -212 minecraft:air
fill 23 52 -213 25 52 -213 minecraft:air
fill 49 52 -213 52 52 -213 minecraft:air
fill 49 52 -214 52 52 -214 minecraft:air
fill 49 52 -215 52 52 -215 minecraft:air
fill 50 52 -216 52 52 -216 minecraft:air
fill 51 52 -217 52 52 -217 minecraft:air
fill 51 52 -218 53 52 -218 minecraft:air
fill 52 52 -219 53 52 -219 minecraft:air
fill 52 52 -220 54 52 -220 minecraft:air
fill 52 52 -221 54 52 -221 minecraft:air
fill 53 52 -222 55 52 -222 minecraft:air
fill 69 52 -222 71 52 -222 minecraft:air
fill 53 52 -223 56 52 -223 minecraft:air
fill 65 52 -223 71 52 -223 minecraft:air
fill 53 52 -224 71 52 -224 minecraft:air
fill 53 52 -225 69 52 -225 minecraft:air
fill 53 52 -226 67 52 -226 minecraft:air
fill 53 52 -227 65 52 -227 minecraft:air
fill 53 52 -228 64 52 -228 minecraft:air
fill 53 52 -229 62 52 -229 minecraft:air
fill 52 52 -230 61 52 -230 minecraft:air
fill 52 52 -231 60 52 -231 minecraft:air
fill 52 52 -232 60 52 -232 minecraft:air
fill 52 52 -233 53 52 -233 minecraft:air
fill 55 52 -233 59 52 -233 minecraft:air
fill 52 52 -234 59 52 -234 minecraft:air
fill 53 52 -235 58 52 -235 minecraft:air
fill 53 52 -236 58 52 -236 minecraft:air
fill 53 52 -237 58 52 -237 minecraft:air
fill 53 52 -238 58 52 -238 minecraft:air
fill 53 52 -239 58 52 -239 minecraft:air
fill 53 52 -240 57 52 -240 minecraft:air
fill 53 52 -241 58 52 -241 minecraft:air
fill 53 52 -242 58 52 -242 minecraft:air
fill 54 52 -243 58 52 -243 minecraft:air
fill 54 52 -244 58 52 -244 minecraft:air
fill 54 52 -245 58 52 -245 minecraft:air
fill 54 52 -246 59 52 -246 minecraft:air
fill 55 52 -247 59 52 -247 minecraft:air
fill 55 52 -248 59 52 -248 minecraft:air
fill 56 52 -249 60 52 -249 minecraft:air
fill 56 52 -250 60 52 -250 minecraft:air
fill 57 52 -251 61 52 -251 minecraft:air
fill 58 52 -252 62 52 -252 minecraft:air
fill 59 52 -253 63 52 -253 minecraft:air
fill 60 52 -254 63 52 -254 minecraft:air
setblock 26 51 -191 minecraft:air
fill 25 51 -192 27 51 -192 minecraft:air
fill 25 51 -193 27 51 -193 minecraft:air
fill 41 51 -193 47 51 -193 minecraft:air
fill 25 51 -194 28 51 -194 minecraft:air
fill 41 51 -194 47 51 -194 minecraft:air
fill 25 51 -195 29 51 -195 minecraft:air
fill 42 51 -195 48 51 -195 minecraft:air
fill 25 51 -196 29 51 -196 minecraft:air
fill 45 51 -196 47 51 -196 minecraft:air
fill 25 51 -197 29 51 -197 minecraft:air
fill 24 51 -198 29 51 -198 minecraft:air
fill 24 51 -199 30 51 -199 minecraft:air
fill 23 51 -200 31 51 -200 minecraft:air
fill 41 51 -200 49 51 -200 minecraft:air
fill 23 51 -201 31 51 -201 minecraft:air
fill 41 51 -201 51 51 -201 minecraft:air
fill 23 51 -202 31 51 -202 minecraft:air
fill 41 51 -202 52 51 -202 minecraft:air
fill 23 51 -203 31 51 -203 minecraft:air
fill 42 51 -203 52 51 -203 minecraft:air
fill 23 51 -204 30 51 -204 minecraft:air
fill 45 51 -204 52 51 -204 minecraft:air
fill 23 51 -205 30 51 -205 minecraft:air
fill 23 51 -206 28 51 -206 minecraft:air
fill 23 51 -207 27 51 -207 minecraft:air
fill 23 51 -208 27 51 -208 minecraft:air
fill 22 51 -209 26 51 -209 minecraft:air
fill 22 51 -210 26 51 -210 minecraft:air
fill 22 51 -211 26 51 -211 minecraft:air
setblock 50 51 -211 minecraft:air
fill 22 51 -212 26 51 -212 minecraft:air
fill 50 51 -212 52 51 -212 minecraft:air
fill 23 51 -213 25 51 -213 minecraft:air
fill 49 51 -213 52 51 -213 minecraft:air
fill 22 51 -214 26 51 -214 minecraft:air
fill 49 51 -214 53 51 -214 minecraft:air
fill 22 51 -215 26 51 -215 minecraft:air
fill 49 51 -215 53 51 -215 minecraft:air
fill 23 51 -216 26 51 -216 minecraft:air
fill 50 51 -216 53 51 -216 minecraft:air
fill 51 51 -217 53 51 -217 minecraft:air
fill 52 51 -218 53 51 -218 minecraft:air
fill 52 51 -219 54 51 -219 minecraft:air
fill 53 51 -220 55 51 -220 minecraft:air
fill 53 51 -221 55 51 -221 minecraft:air
fill 70 51 -221 71 51 -221 minecraft:air
fill 54 51 -222 57 51 -222 minecraft:air
fill 66 51 -222 71 51 -222 minecraft:air
fill 54 51 -223 71 51 -223 minecraft:air
fill 55 51 -224 69 51 -224 minecraft:air
fill 55 51 -225 67 51 -225 minecraft:air
fill 55 51 -226 65 51 -226 minecraft:air
fill 55 51 -227 64 51 -227 minecraft:air
fill 55 51 -228 62 51 -228 minecraft:air
fill 55 51 -229 61 51 -229 minecraft:air
fill 55 51 -230 60 51 -230 minecraft:air
fill 55 51 -231 59 51 -231 minecraft:air
fill 55 51 -232 59 51 -232 minecraft:air
fill 55 51 -233 58 51 -233 minecraft:air
fill 55 51 -234 58 51 -234 minecraft:air
fill 55 51 -235 58 51 -235 minecraft:air
fill 55 51 -236 57 51 -236 minecraft:air
fill 54 51 -237 57 51 -237 minecraft:air
fill 54 51 -238 57 51 -238 minecraft:air
fill 54 51 -239 57 51 -239 minecraft:air
fill 53 51 -240 57 51 -240 minecraft:air
fill 53 51 -241 57 51 -241 minecraft:air
fill 53 51 -242 58 51 -242 minecraft:air
fill 54 51 -243 58 51 -243 minecraft:air
fill 54 51 -244 58 51 -244 minecraft:air
fill 54 51 -245 58 51 -245 minecraft:air
fill 54 51 -246 59 51 -246 minecraft:air
fill 55 51 -247 59 51 -247 minecraft:air
fill 55 51 -248 59 51 -248 minecraft:air
fill 56 51 -249 60 51 -249 minecraft:air
fill 57 51 -250 61 51 -250 minecraft:air
fill 57 51 -251 61 51 -251 minecraft:air
fill 58 51 -252 62 51 -252 minecraft:air
fill 59 51 -253 63 51 -253 minecraft:air
fill 60 51 -254 63 51 -254 minecraft:air
fill 24 50 -191 27 50 -191 minecraft:air
fill 41 50 -191 45 50 -191 minecraft:air
fill 24 50 -192 28 50 -192 minecraft:air
fill 40 50 -192 48 50 -192 minecraft:air
fill 24 50 -193 28 50 -193 minecraft:air
fill 40 50 -193 49 50 -193 minecraft:air
fill 24 50 -194 28 50 -194 minecraft:air
fill 40 50 -194 50 50 -194 minecraft:air
fill 25 50 -195 28 50 -195 minecraft:air
fill 40 50 -195 50 50 -195 minecraft:air
fill 25 50 -196 28 50 -196 minecraft:air
fill 39 50 -196 50 50 -196 minecraft:air
fill 25 50 -197 28 50 -197 minecraft:air
fill 39 50 -197 40 50 -197 minecraft:air
fill 43 50 -197 50 50 -197 minecraft:air
setblock 27 50 -198 minecraft:air
fill 39 50 -198 41 50 -198 minecraft:air
fill 47 50 -198 49 50 -198 minecraft:air
fill 38 50 -199 44 50 -199 minecraft:air
fill 39 50 -200 49 50 -200 minecraft:air
fill 39 50 -201 52 50 -201 minecraft:air
fill 40 50 -202 53 50 -202 minecraft:air
fill 41 50 -203 54 50 -203 minecraft:air
setblock 46 50 -204 minecraft:air
fill 49 50 -204 53 50 -204 minecraft:air
setblock 52 50 -205 minecraft:air
setblock 50 50 -211 minecraft:air
fill 50 50 -212 51 50 -212 minecraft:air
fill 23 50 -213 25 50 -213 minecraft:air
fill 50 50 -213 53 50 -213 minecraft:air
fill 22 50 -214 26 50 -214 minecraft:air
fill 50 50 -214 53 50 -214 minecraft:air
setblock 22 50 -215 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=false,waterlogged=false,west=false]
fill 23 50 -215 26 50 -215 minecraft:air
fill 49 50 -215 53 50 -215 minecraft:air
fill 23 50 -216 27 50 -216 minecraft:air
fill 50 50 -216 53 50 -216 minecraft:air
fill 24 50 -217 27 50 -217 minecraft:air
fill 51 50 -217 54 50 -217 minecraft:air
fill 24 50 -218 26 50 -218 minecraft:air
fill 52 50 -218 54 50 -218 minecraft:air
fill 53 50 -219 55 50 -219 minecraft:air
fill 54 50 -220 56 50 -220 minecraft:air
fill 70 50 -220 71 50 -220 minecraft:air
fill 54 50 -221 58 50 -221 minecraft:air
fill 67 50 -221 71 50 -221 minecraft:air
fill 55 50 -222 71 50 -222 minecraft:air
fill 55 50 -223 69 50 -223 minecraft:air
fill 56 50 -224 67 50 -224 minecraft:air
fill 56 50 -225 65 50 -225 minecraft:air
fill 57 50 -226 64 50 -226 minecraft:air
fill 57 50 -227 62 50 -227 minecraft:air
fill 58 50 -228 60 50 -228 minecraft:air
fill 59 50 -229 60 50 -229 minecraft:air
fill 55 50 -248 56 50 -248 minecraft:air
fill 56 50 -249 57 50 -249 minecraft:air
fill 57 50 -250 58 50 -250 minecraft:air
fill 58 50 -251 59 50 -251 minecraft:air
fill 58 50 -252 59 50 -252 minecraft:air
fill 59 50 -253 60 50 -253 minecraft:air
fill 60 50 -254 61 50 -254 minecraft:air
fill 23 49 -191 27 49 -191 minecraft:air
fill 40 49 -191 47 49 -191 minecraft:air
fill 24 49 -192 27 49 -192 minecraft:air
fill 39 49 -192 49 49 -192 minecraft:air
fill 24 49 -193 27 49 -193 minecraft:air
fill 39 49 -193 50 49 -193 minecraft:air
fill 25 49 -194 27 49 -194 minecraft:air
fill 39 49 -194 51 49 -194 minecraft:air
setblock 26 49 -195 minecraft:air
fill 38 49 -195 51 49 -195 minecraft:air
fill 38 49 -196 52 49 -196 minecraft:air
fill 38 49 -197 52 49 -197 minecraft:air
fill 38 49 -198 42 49 -198 minecraft:air
fill 45 49 -198 52 49 -198 minecraft:air
fill 38 49 -199 43 49 -199 minecraft:air
fill 47 49 -199 52 49 -199 minecraft:air
fill 38 49 -200 44 49 -200 minecraft:air
fill 49 49 -200 51 49 -200 minecraft:air
fill 38 49 -201 44 49 -201 minecraft:air
fill 51 49 -201 53 49 -201 minecraft:air
fill 39 49 -202 44 49 -202 minecraft:air
fill 50 49 -202 54 49 -202 minecraft:air
fill 42 49 -203 43 49 -203 minecraft:air
fill 50 49 -203 54 49 -203 minecraft:air
fill 50 49 -204 54 49 -204 minecraft:air
fill 52 49 -205 54 49 -205 minecraft:air
fill 50 49 -212 51 49 -212 minecraft:air
fill 50 49 -213 52 49 -213 minecraft:air
fill 50 49 -214 54 49 -214 minecraft:air
fill 24 49 -215 26 49 -215 minecraft:air
fill 50 49 -215 54 49 -215 minecraft:air
fill 24 49 -216 27 49 -216 minecraft:air
fill 50 49 -216 54 49 -216 minecraft:air
fill 24 49 -217 27 49 -217 minecraft:air
setblock 28 49 -217 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 29 49 -217 30 49 -217 minecraft:air
fill 51 49 -217 55 49 -217 minecraft:air
fill 24 49 -218 31 49 -218 minecraft:air
fill 52 49 -218 55 49 -218 minecraft:air
fill 28 49 -219 33 49 -219 minecraft:air
fill 53 49 -219 56 49 -219 minecraft:air
setblock 71 49 -219 minecraft:air
fill 31 49 -220 34 49 -220 minecraft:air
fill 54 49 -220 58 49 -220 minecraft:air
fill 67 49 -220 71 49 -220 minecraft:air
fill 55 49 -221 71 49 -221 minecraft:air
fill 56 49 -222 70 49 -222 minecraft:air
fill 57 49 -223 68 49 -223 minecraft:air
fill 58 49 -224 65 49 -224 minecraft:air
fill 59 49 -225 63 49 -225 minecraft:air
fill 60 49 -226 61 49 -226 minecraft:air
fill 24 48 -191 26 48 -191 minecraft:air
fill 40 48 -191 69 48 -191 minecraft:air
fill 39 48 -192 69 48 -192 minecraft:air
fill 39 48 -193 67 48 -193 minecraft:air
fill 39 48 -194 66 48 -194 minecraft:air
fill 38 48 -195 66 48 -195 minecraft:air
fill 38 48 -196 67 48 -196 minecraft:air
fill 38 48 -197 65 48 -197 minecraft:air
fill 67 48 -197 68 48 -197 minecraft:air
fill 38 48 -198 65 48 -198 minecraft:air
fill 38 48 -199 65 48 -199 minecraft:air
fill 38 48 -200 64 48 -200 minecraft:air
fill 36 48 -201 62 48 -201 minecraft:air
fill 34 48 -202 60 48 -202 minecraft:air
fill 32 48 -203 57 48 -203 minecraft:air
fill 31 48 -204 55 48 -204 minecraft:air
fill 32 48 -205 55 48 -205 minecraft:air
fill 33 48 -206 54 48 -206 minecraft:air
fill 34 48 -207 54 48 -207 minecraft:air
fill 11 48 -208 12 48 -208 minecraft:air
fill 35 48 -208 54 48 -208 minecraft:air
fill 10 48 -209 12 48 -209 minecraft:air
fill 36 48 -209 53 48 -209 minecraft:air
fill 8 48 -210 12 48 -210 minecraft:air
fill 37 48 -210 52 48 -210 minecraft:air
fill 8 48 -211 12 48 -211 minecraft:air
fill 37 48 -211 52 48 -211 minecraft:air
fill 8 48 -212 12 48 -212 minecraft:air
fill 38 48 -212 52 48 -212 minecraft:air
fill 8 48 -213 10 48 -213 minecraft:air
fill 39 48 -213 52 48 -213 minecraft:air
fill 8 48 -214 9 48 -214 minecraft:air
fill 40 48 -214 54 48 -214 minecraft:air
setblock 8 48 -215 minecraft:air
fill 42 48 -215 55 48 -215 minecraft:air
setblock 8 48 -216 minecraft:air
setblock 29 48 -216 minecraft:air
fill 43 48 -216 55 48 -216 minecraft:air
fill 28 48 -217 31 48 -217 minecraft:air
fill 51 48 -217 56 48 -217 minecraft:air
fill 27 48 -218 33 48 -218 minecraft:air
fill 53 48 -218 57 48 -218 minecraft:air
fill 27 48 -219 35 48 -219 minecraft:air
fill 54 48 -219 58 48 -219 minecraft:air
fill 68 48 -219 71 48 -219 minecraft:air
fill 28 48 -220 35 48 -220 minecraft:air
fill 55 48 -220 71 48 -220 minecraft:air
fill 31 48 -221 35 48 -221 minecraft:air
fill 56 48 -221 71 48 -221 minecraft:air
fill 57 48 -222 68 48 -222 minecraft:air
fill 59 48 -223 65 48 -223 minecraft:air
fill 62 48 -224 63 48 -224 minecraft:air
fill 40 47 -191 69 47 -191 minecraft:air
fill 40 47 -192 69 47 -192 minecraft:air
fill 39 47 -193 67 47 -193 minecraft:air
fill 39 47 -194 66 47 -194 minecraft:air
fill 40 47 -195 67 47 -195 minecraft:air
fill 40 47 -196 69 47 -196 minecraft:air
fill 42 47 -197 71 47 -197 minecraft:air
fill 42 47 -198 65 47 -198 minecraft:air
fill 68 47 -198 71 47 -198 minecraft:air
fill 41 47 -199 65 47 -199 minecraft:air
setblock 71 47 -199 minecraft:air
fill 36 47 -200 64 47 -200 minecraft:air
fill 34 47 -201 62 47 -201 minecraft:air
fill 32 47 -202 61 47 -202 minecraft:air
fill 31 47 -203 58 47 -203 minecraft:air
fill 30 47 -204 56 47 -204 minecraft:air
fill 31 47 -205 56 47 -205 minecraft:air
fill 32 47 -206 55 47 -206 minecraft:air
fill 32 47 -207 54 47 -207 minecraft:air
fill 11 47 -208 12 47 -208 minecraft:air
fill 34 47 -208 54 47 -208 minecraft:air
fill 10 47 -209 11 47 -209 minecraft:air
setblock 12 47 -209 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
fill 35 47 -209 53 47 -209 minecraft:air
fill 8 47 -210 12 47 -210 minecraft:air
fill 36 47 -210 53 47 -210 minecraft:air
fill 8 47 -211 12 47 -211 minecraft:air
fill 37 47 -211 52 47 -211 minecraft:air
fill 8 47 -212 13 47 -212 minecraft:air
setblock 38 47 -212 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 39 47 -212 52 47 -212 minecraft:air
fill 8 47 -213 11 47 -213 minecraft:air
fill 39 47 -213 51 47 -213 minecraft:air
fill 8 47 -214 9 47 -214 minecraft:air
fill 40 47 -214 53 47 -214 minecraft:air
setblock 8 47 -215 minecraft:air
fill 41 47 -215 49 47 -215 minecraft:air
fill 51 47 -215 54 47 -215 minecraft:air
setblock 8 47 -216 minecraft:air
fill 43 47 -216 49 47 -216 minecraft:air
fill 51 47 -216 56 47 -216 minecraft:air
fill 47 47 -217 48 47 -217 minecraft:air
fill 51 47 -217 56 47 -217 minecraft:air
fill 52 47 -218 58 47 -218 minecraft:air
fill 70 47 -218 71 47 -218 minecraft:air
fill 54 47 -219 60 47 -219 minecraft:air
fill 66 47 -219 71 47 -219 minecraft:air
fill 55 47 -220 71 47 -220 minecraft:air
fill 56 47 -221 70 47 -221 minecraft:air
fill 58 47 -222 67 47 -222 minecraft:air
fill 60 47 -223 65 47 -223 minecraft:air
setblock 45 46 -191 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=false,west=false]
fill 46 46 -191 69 46 -191 minecraft:air
fill 44 46 -192 69 46 -192 minecraft:air
fill 44 46 -193 67 46 -193 minecraft:air
fill 43 46 -194 66 46 -194 minecraft:air
fill 43 46 -195 68 46 -195 minecraft:air
fill 42 46 -196 70 46 -196 minecraft:air
fill 42 46 -197 71 46 -197 minecraft:air
fill 41 46 -198 65 46 -198 minecraft:air
fill 67 46 -198 71 46 -198 minecraft:air
fill 38 46 -199 65 46 -199 minecraft:air
fill 69 46 -199 71 46 -199 minecraft:air
fill 34 46 -200 64 46 -200 minecraft:air
fill 31 46 -201 62 46 -201 minecraft:air
fill 30 46 -202 61 46 -202 minecraft:air
fill 30 46 -203 59 46 -203 minecraft:air
fill 29 46 -204 57 46 -204 minecraft:air
fill 30 46 -205 57 46 -205 minecraft:air
fill 31 46 -206 57 46 -206 minecraft:air
fill 32 46 -207 54 46 -207 minecraft:air
setblock 12 46 -208 minecraft:air
fill 33 46 -208 54 46 -208 minecraft:air
fill 11 46 -209 12 46 -209 minecraft:air
fill 34 46 -209 53 46 -209 minecraft:air
fill 8 46 -210 12 46 -210 minecraft:air
fill 35 46 -210 53 46 -210 minecraft:air
fill 8 46 -211 13 46 -211 minecraft:air
fill 36 46 -211 52 46 -211 minecraft:air
fill 8 46 -212 13 46 -212 minecraft:air
fill 37 46 -212 52 46 -212 minecraft:air
fill 8 46 -213 11 46 -213 minecraft:air
fill 39 46 -213 51 46 -213 minecraft:air
fill 8 46 -214 9 46 -214 minecraft:air
fill 40 46 -214 51 46 -214 minecraft:air
fill 8 46 -215 9 46 -215 minecraft:air
fill 41 46 -215 49 46 -215 minecraft:air
fill 51 46 -215 53 46 -215 minecraft:air
setblock 8 46 -216 minecraft:air
fill 43 46 -216 49 46 -216 minecraft:air
fill 51 46 -216 55 46 -216 minecraft:air
setblock 8 46 -217 minecraft:air
fill 46 46 -217 48 46 -217 minecraft:air
fill 51 46 -217 57 46 -217 minecraft:air
fill 52 46 -218 59 46 -218 minecraft:air
fill 69 46 -218 71 46 -218 minecraft:air
fill 53 46 -219 71 46 -219 minecraft:air
fill 55 46 -220 71 46 -220 minecraft:air
fill 56 46 -221 69 46 -221 minecraft:air
fill 59 46 -222 66 46 -222 minecraft:air
setblock 49 46 -246 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 44 45 -191 69 45 -191 minecraft:air
fill 43 45 -192 69 45 -192 minecraft:air
fill 43 45 -193 67 45 -193 minecraft:air
fill 42 45 -194 66 45 -194 minecraft:air
fill 42 45 -195 68 45 -195 minecraft:air
fill 42 45 -196 70 45 -196 minecraft:air
fill 41 45 -197 71 45 -197 minecraft:air
fill 39 45 -198 65 45 -198 minecraft:air
fill 67 45 -198 71 45 -198 minecraft:air
fill 34 45 -199 64 45 -199 minecraft:air
fill 69 45 -199 71 45 -199 minecraft:air
fill 31 45 -200 64 45 -200 minecraft:air
fill 30 45 -201 62 45 -201 minecraft:air
fill 29 45 -202 61 45 -202 minecraft:air
fill 29 45 -203 59 45 -203 minecraft:air
fill 28 45 -204 58 45 -204 minecraft:air
fill 29 45 -205 58 45 -205 minecraft:air
fill 30 45 -206 58 45 -206 minecraft:air
fill 31 45 -207 57 45 -207 minecraft:air
fill 32 45 -208 54 45 -208 minecraft:air
setblock 12 45 -209 minecraft:air
fill 33 45 -209 53 45 -209 minecraft:air
fill 9 45 -210 12 45 -210 minecraft:air
fill 34 45 -210 53 45 -210 minecraft:air
fill 8 45 -211 13 45 -211 minecraft:air
fill 35 45 -211 52 45 -211 minecraft:air
fill 8 45 -212 13 45 -212 minecraft:air
fill 37 45 -212 52 45 -212 minecraft:air
fill 8 45 -213 11 45 -213 minecraft:air
fill 38 45 -213 51 45 -213 minecraft:air
fill 8 45 -214 10 45 -214 minecraft:air
fill 40 45 -214 50 45 -214 minecraft:air
fill 8 45 -215 9 45 -215 minecraft:air
fill 41 45 -215 49 45 -215 minecraft:air
setblock 52 45 -215 minecraft:air
fill 8 45 -216 9 45 -216 minecraft:air
fill 42 45 -216 49 45 -216 minecraft:air
fill 52 45 -216 55 45 -216 minecraft:air
setblock 8 45 -217 minecraft:air
fill 44 45 -217 48 45 -217 minecraft:air
fill 52 45 -217 58 45 -217 minecraft:air
setblock 71 45 -217 minecraft:air
setblock 8 45 -218 minecraft:air
fill 52 45 -218 61 45 -218 minecraft:air
fill 66 45 -218 71 45 -218 minecraft:air
fill 53 45 -219 61 45 -219 minecraft:air
fill 62 45 -219 63 45 -219 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=false,west=false]
fill 64 45 -219 71 45 -219 minecraft:air
fill 55 45 -220 70 45 -220 minecraft:air
fill 57 45 -221 68 45 -221 minecraft:air
fill 60 45 -222 65 45 -222 minecraft:air
setblock 67 45 -224 minecraft:air
fill 66 45 -225 67 45 -225 minecraft:air
setblock 68 45 -229 minecraft:air
setblock 68 45 -230 minecraft:air
setblock 68 45 -231 minecraft:air
setblock 68 45 -232 minecraft:air
fill 48 45 -233 50 45 -233 minecraft:air
setblock 68 45 -233 minecraft:air
fill 47 45 -234 50 45 -234 minecraft:air
setblock 68 45 -234 minecraft:air
setblock 48 45 -235 minecraft:air
fill 49 45 -246 50 45 -246 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 49 45 -247 50 45 -247 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
forceload remove 8 -254 71 -191
tellraw @a {"text":"Campus zurueck a22 fertig.","color":"green"}
