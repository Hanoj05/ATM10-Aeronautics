setblock 21 85 -183 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 85 -184 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 21 85 -184 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 85 -184 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 85 -190 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 84 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 84 -177 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 84 -178 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 21 84 -183 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 84 -184 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 84 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 84 -184 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 84 -185 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 84 -190 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 83 -176 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 83 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 83 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 83 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 83 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 83 -183 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 83 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 83 -183 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 83 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 83 -184 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 83 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 83 -185 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 83 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 83 -185 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 83 -190 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 83 -190 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 83 -190 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 82 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 66 82 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 67 82 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 82 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 82 -176 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 82 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 82 -176 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 82 -177 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 82 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 82 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 82 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 82 -179 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 82 -179 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 82 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 82 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -183 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 82 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 82 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 82 -184 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 82 -184 minecraft:birch_log[axis=y]
setblock 22 82 -184 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 82 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 82 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -185 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 82 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 82 -189 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 82 -190 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 82 -190 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 82 -190 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 81 -136 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 70 81 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 81 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 67 81 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 81 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 81 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 81 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 81 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 81 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 55 81 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 81 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 55 81 -148 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 81 -175 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 81 -176 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 81 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 81 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -177 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 81 -177 minecraft:birch_log[axis=y]
setblock 17 81 -177 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 81 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 81 -178 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 81 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 81 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 81 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 81 -179 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 81 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 81 -179 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 81 -180 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 52 81 -180 54 81 -180 minecraft:air
setblock 52 81 -181 minecraft:air
fill 55 81 -181 58 81 -181 minecraft:air
setblock 52 81 -182 minecraft:air
fill 59 81 -182 62 81 -182 minecraft:air
setblock 52 81 -183 minecraft:air
fill 63 81 -183 66 81 -183 minecraft:air
setblock 21 81 -184 minecraft:birch_log[axis=y]
setblock 52 81 -184 minecraft:air
fill 67 81 -184 69 81 -184 minecraft:air
setblock 53 81 -185 minecraft:air
fill 70 81 -185 71 81 -185 minecraft:air
setblock 53 81 -186 minecraft:air
setblock 53 81 -187 minecraft:air
setblock 53 81 -188 minecraft:air
setblock 53 81 -189 minecraft:air
setblock 53 81 -190 minecraft:air
setblock 70 80 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 80 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 80 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 80 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 80 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 80 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 80 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 80 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 80 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 80 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 80 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 80 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 80 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 80 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 80 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 80 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 58 80 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 59 80 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 71 80 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 80 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 80 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 80 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 80 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 80 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 62 80 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 80 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 80 -160 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 62 80 -161 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 66 80 -161 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 80 -168 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 80 -168 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 80 -168 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 80 -174 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 80 -177 minecraft:birch_log[axis=y]
setblock 18 80 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 80 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 80 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 80 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -179 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 80 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 80 -180 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 80 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 80 -180 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 52 80 -180 54 80 -180 minecraft:white_concrete
setblock 52 80 -181 minecraft:white_concrete
fill 55 80 -181 58 80 -181 minecraft:white_concrete
setblock 52 80 -182 minecraft:white_concrete
fill 59 80 -182 62 80 -182 minecraft:white_concrete
setblock 52 80 -183 minecraft:white_concrete
fill 63 80 -183 66 80 -183 minecraft:white_concrete
setblock 21 80 -184 minecraft:birch_log[axis=y]
setblock 52 80 -184 minecraft:white_concrete
fill 67 80 -184 69 80 -184 minecraft:white_concrete
setblock 53 80 -185 minecraft:white_concrete
fill 70 80 -185 71 80 -185 minecraft:white_concrete
setblock 53 80 -186 minecraft:white_concrete
setblock 53 80 -187 minecraft:white_concrete
setblock 53 80 -188 minecraft:white_concrete
setblock 53 80 -189 minecraft:white_concrete
setblock 53 80 -190 minecraft:white_concrete
setblock 38 79 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 79 -127 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 54 79 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 79 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 79 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 79 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 79 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 79 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 71 79 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 79 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 79 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 79 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 79 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 79 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 79 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 79 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 79 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 79 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 79 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 67 79 -144 minecraft:birch_log[axis=y]
setblock 68 79 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 79 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 79 -145 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 58 79 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 79 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 79 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 79 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 79 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 53 79 -146 54 79 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 79 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 56 79 -146 57 79 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 58 79 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 79 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 79 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 79 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 79 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 79 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 79 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 79 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 79 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 79 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 79 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 79 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 79 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 79 -148 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 65 79 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 79 -153 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 66 79 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 67 79 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 79 -155 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 53 79 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 79 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 68 79 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 79 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 79 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 53 79 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 62 79 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 79 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 79 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 79 -160 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 61 79 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 79 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 79 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 79 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 79 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 79 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 79 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 79 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 79 -167 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 79 -168 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 79 -168 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 79 -168 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 79 -169 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 79 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 79 -172 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 79 -173 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 22 79 -173 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 79 -173 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 79 -174 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 79 -177 minecraft:birch_log[axis=y]
setblock 19 79 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 79 -178 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 79 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -179 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 79 -179 minecraft:birch_log[axis=y]
setblock 20 79 -179 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 79 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 79 -180 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 79 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 79 -181 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 79 -181 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 79 -181 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 79 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 79 -184 minecraft:birch_log[axis=y]
setblock 9 79 -186 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 79 -187 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 78 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 78 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 78 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 78 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 78 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 78 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 78 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 78 -135 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 47 78 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 78 -135 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 70 78 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 78 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 78 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 71 78 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 78 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 78 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 70 78 -137 minecraft:birch_log[axis=y]
setblock 71 78 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 78 -138 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 69 78 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 78 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 71 78 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 78 -139 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 53 78 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 78 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 78 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 78 -140 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 13 78 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 78 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 78 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 78 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 78 -140 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 68 78 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 78 -140 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 64 78 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 78 -141 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 78 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 67 78 -144 minecraft:birch_log[axis=y]
setblock 10 78 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 78 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 78 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 78 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 78 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 58 78 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 78 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 78 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 78 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 51 78 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 52 78 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 53 78 -146 54 78 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 78 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 56 78 -146 57 78 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 78 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 59 78 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 78 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 78 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 78 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 78 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 78 -147 minecraft:birch_log[axis=y]
setblock 56 78 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 57 78 -147 58 78 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 78 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 78 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 78 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 78 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 78 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 78 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 78 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 78 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 78 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 78 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 78 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 78 -153 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 67 78 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 78 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 52 78 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 78 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 66 78 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 78 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 78 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 78 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 78 -155 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 52 78 -155 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 67 78 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 78 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 78 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 78 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 78 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 78 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 78 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 78 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 78 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 78 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 78 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 78 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 78 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 78 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 78 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 78 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 67 78 -159 68 78 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 78 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 78 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 78 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 78 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 78 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 78 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 78 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 78 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 67 78 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 78 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 59 78 -161 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 61 78 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 78 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 78 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 78 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 78 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 78 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 59 78 -162 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 60 78 -162 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 19 78 -167 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 78 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 78 -167 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 78 -168 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 78 -168 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 78 -168 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 78 -169 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 78 -169 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 78 -169 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 78 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 78 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 78 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 78 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 78 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 78 -173 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 78 -173 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 78 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 78 -173 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 78 -174 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 78 -177 minecraft:birch_log[axis=y]
setblock 19 78 -179 minecraft:birch_log[axis=y]
setblock 12 78 -180 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 78 -181 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 78 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 78 -181 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 78 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 78 -184 minecraft:birch_log[axis=y]
setblock 9 78 -185 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -186 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 78 -186 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 77 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 77 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 77 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 77 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 77 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 77 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 77 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 77 -127 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 77 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 77 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 77 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 77 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 77 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 77 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 77 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 77 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 70 77 -137 minecraft:birch_log[axis=y]
setblock 53 77 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 77 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 77 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 77 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 77 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 77 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 77 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 77 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 77 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 77 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 77 -140 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 53 77 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 77 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 77 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 77 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 77 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 77 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 77 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 77 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 77 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 77 -141 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 63 77 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 77 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 77 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 77 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 77 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 77 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 58 77 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 77 -144 minecraft:birch_log[axis=y]
setblock 9 77 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 77 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 77 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 77 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 77 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 77 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 77 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 77 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 77 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 77 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 59 77 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 77 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 51 77 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 77 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 77 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 77 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 77 -146 minecraft:birch_log[axis=y]
setblock 59 77 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 60 77 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 77 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 77 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 77 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 77 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 77 -147 minecraft:birch_log[axis=y]
setblock 57 77 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 77 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 59 77 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 77 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 77 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 77 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 58 77 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 77 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 77 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 66 77 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 77 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 77 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 77 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 77 -151 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 24 77 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 77 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 77 -152 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 52 77 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 77 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 77 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 77 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 77 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 77 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 77 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 77 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 77 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 77 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 77 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 77 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 77 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 77 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 77 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 77 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 77 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 77 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 77 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 77 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 77 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 77 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 66 77 -158 67 77 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 77 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 77 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 77 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 77 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 77 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 77 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 77 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 77 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 77 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 77 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 77 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 77 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 67 77 -159 68 77 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 77 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 77 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 77 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 77 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 62 77 -160 minecraft:birch_log[axis=y]
setblock 63 77 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 77 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 77 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 66 77 -160 minecraft:birch_log[axis=y]
setblock 67 77 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 77 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 77 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 77 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 77 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 58 77 -161 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 59 77 -161 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 60 77 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 77 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 77 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 77 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 77 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 77 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 67 77 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 77 -162 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 59 77 -162 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 60 77 -162 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 62 77 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 77 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 77 -163 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 60 77 -163 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 20 77 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 77 -167 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 77 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 77 -168 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -168 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 77 -168 minecraft:birch_log[axis=y]
setblock 21 77 -168 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 77 -168 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -169 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 77 -169 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 77 -169 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 77 -170 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 77 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 77 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 77 -172 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 77 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 77 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 77 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 77 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 77 -173 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -173 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 77 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 77 -173 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 77 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 77 -174 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 77 -174 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 77 -174 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -177 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 77 -177 minecraft:birch_log[axis=y]
setblock 9 77 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -179 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 77 -179 minecraft:birch_log[axis=y]
setblock 11 77 -180 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 77 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 77 -180 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 77 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 77 -181 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 77 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 77 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 77 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 77 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 77 -184 minecraft:birch_log[axis=y]
setblock 8 77 -185 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -185 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 77 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 77 -186 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 77 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 77 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 76 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 76 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 76 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 76 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 76 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 76 -127 minecraft:birch_log[axis=y]
setblock 39 76 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 76 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 76 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 76 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 76 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 76 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 76 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 76 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 76 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 76 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 76 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 76 -130 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 56 76 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 76 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 76 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 76 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 76 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 76 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 76 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 76 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 76 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 76 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 76 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 76 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 76 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 76 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 76 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 76 -137 minecraft:birch_log[axis=y]
setblock 52 76 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 76 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 76 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 76 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 76 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 76 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 76 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 76 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 76 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 76 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 76 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 76 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 76 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 76 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 76 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 76 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 76 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 76 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 76 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 76 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 76 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 76 -140 minecraft:birch_log[axis=y]
setblock 65 76 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 66 76 -140 67 76 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 76 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 76 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 76 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 76 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 76 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 76 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 76 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 76 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 76 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 76 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 76 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 76 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 50 76 -143 51 76 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 76 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 76 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 76 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 76 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 76 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 48 76 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 76 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 76 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 76 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 76 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 76 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 76 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 76 -144 minecraft:birch_log[axis=y]
setblock 9 76 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 76 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 76 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 76 -145 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 50 76 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 76 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 76 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 76 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 76 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 76 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 76 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 76 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 11 76 -146 12 76 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 76 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 76 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 76 -146 minecraft:birch_log[axis=y]
fill 54 76 -146 55 76 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 76 -146 minecraft:birch_log[axis=y]
setblock 65 76 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 76 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 76 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 76 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 76 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 53 76 -147 54 76 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 76 -147 minecraft:birch_log[axis=y]
setblock 62 76 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 63 76 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 76 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 76 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 66 76 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 76 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 76 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 76 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 76 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 76 -148 minecraft:birch_log[axis=y]
setblock 66 76 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 67 76 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 76 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 76 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 66 76 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 76 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 76 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 76 -150 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 65 76 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 76 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 76 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 76 -151 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 44 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 76 -151 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 24 76 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 76 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 76 -152 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 67 76 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 76 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 76 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 76 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 76 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 76 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 76 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 76 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 76 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 76 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 76 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 76 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 76 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 67 76 -154 minecraft:birch_log[axis=y]
setblock 68 76 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 76 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 76 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 76 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 76 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 76 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 76 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 76 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 76 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 76 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 76 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 76 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 76 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 76 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 67 76 -156 68 76 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 76 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 76 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 76 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 76 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 76 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 76 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 76 -158 minecraft:birch_log[axis=y]
setblock 54 76 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 76 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 76 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 76 -158 minecraft:birch_log[axis=y]
setblock 69 76 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 70 76 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 76 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 76 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 50 76 -159 51 76 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 76 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 76 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 76 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 76 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 76 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 76 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 76 -160 minecraft:birch_log[axis=y]
setblock 20 76 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 76 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 76 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 76 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 76 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 76 -168 minecraft:birch_log[axis=y]
setblock 18 76 -170 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 76 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -171 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 76 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 76 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 76 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 76 -172 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 76 -172 minecraft:birch_log[axis=y]
setblock 19 76 -172 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 76 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 76 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 76 -172 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 76 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 76 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -173 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 76 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 76 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 76 -173 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 76 -173 minecraft:birch_log[axis=y]
setblock 24 76 -173 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 76 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -174 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 76 -174 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 76 -174 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 76 -174 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 76 -175 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 76 -177 minecraft:birch_log[axis=y]
setblock 8 76 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 76 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 76 -179 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 76 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 76 -179 minecraft:birch_log[axis=y]
setblock 11 76 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 76 -180 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 76 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 76 -181 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 76 -181 minecraft:birch_log[axis=y]
setblock 13 76 -181 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 76 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -182 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 11 76 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 76 -182 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 76 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 76 -183 9 76 -183 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 76 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 76 -184 minecraft:birch_log[axis=y]
setblock 8 76 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -185 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -186 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 76 -186 minecraft:birch_log[axis=y]
setblock 10 76 -186 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 76 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 76 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -187 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 75 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 75 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 34 75 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 75 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 75 -127 minecraft:birch_log[axis=y]
setblock 55 75 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 75 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 75 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 75 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 75 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 75 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 75 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 75 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 75 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 75 -128 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 56 75 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 75 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 75 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 75 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 75 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 75 -130 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 56 75 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 75 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 75 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 75 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 75 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 75 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 75 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 75 -135 minecraft:birch_log[axis=y]
setblock 48 75 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 75 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 75 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 75 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 75 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 75 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 75 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 75 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 75 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 75 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 75 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 75 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 75 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 75 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 75 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 75 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 75 -137 minecraft:birch_log[axis=y]
setblock 13 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 75 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 75 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 75 -139 minecraft:birch_log[axis=y]
setblock 54 75 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 75 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 75 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 75 -140 minecraft:birch_log[axis=y]
setblock 14 75 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 75 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 75 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 75 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 75 -140 minecraft:birch_log[axis=y]
setblock 66 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 75 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 75 -140 minecraft:birch_log[axis=y]
setblock 69 75 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 70 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 75 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 75 -141 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 34 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 75 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 75 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 75 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 75 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 75 -142 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 29 75 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 75 -142 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 34 75 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 75 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 75 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 75 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 75 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 75 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 75 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 75 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 75 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 75 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 48 75 -143 49 75 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 50 75 -143 51 75 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 75 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 75 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 75 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 75 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 75 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 75 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 75 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 75 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 75 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 75 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 75 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 75 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 75 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 75 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 75 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 75 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 75 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 75 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 75 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 75 -144 minecraft:birch_log[axis=y]
setblock 9 75 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 75 -145 minecraft:birch_log[axis=y]
setblock 11 75 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 75 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 75 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 75 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 75 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 75 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 75 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 75 -145 minecraft:birch_log[axis=y]
fill 52 75 -145 53 75 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 75 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 75 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 75 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 75 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 75 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 11 75 -146 12 75 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 75 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 75 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 75 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 51 75 -146 52 75 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 75 -146 minecraft:birch_log[axis=y]
setblock 58 75 -146 minecraft:birch_log[axis=y]
setblock 63 75 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 10 75 -147 11 75 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 75 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 75 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 75 -147 regions_unexplored:birch_branch[facing=west]
setblock 55 75 -147 minecraft:birch_log[axis=y]
setblock 62 75 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 75 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 75 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 75 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 75 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 75 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 75 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 75 -148 minecraft:birch_log[axis=y]
setblock 40 75 -149 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 75 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 75 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 75 -150 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 40 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 75 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 75 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 75 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 75 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 75 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 75 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 75 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 75 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 75 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 75 -153 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 39 75 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 75 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 75 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 75 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 38 75 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 75 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 75 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 75 -154 minecraft:birch_log[axis=y]
setblock 53 75 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 75 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 75 -154 minecraft:birch_log[axis=y]
setblock 17 75 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 75 -155 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 75 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 75 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 75 -155 minecraft:birch_log[axis=y]
setblock 40 75 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 75 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 75 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 75 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 75 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 75 -157 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 39 75 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 75 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 75 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 50 75 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 75 -158 minecraft:birch_log[axis=y]
setblock 68 75 -158 minecraft:birch_log[axis=y]
setblock 49 75 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 75 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 75 -160 minecraft:birch_log[axis=y]
setblock 20 75 -168 minecraft:birch_log[axis=y]
setblock 18 75 -172 minecraft:birch_log[axis=y]
setblock 23 75 -173 minecraft:birch_log[axis=y]
setblock 8 75 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 75 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 75 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 75 -177 minecraft:birch_log[axis=y]
setblock 8 75 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 75 -178 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 75 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 75 -179 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 75 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 75 -179 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 75 -179 minecraft:birch_log[axis=y]
setblock 12 75 -181 minecraft:birch_log[axis=y]
setblock 8 75 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 75 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 75 -183 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 75 -184 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 75 -184 minecraft:birch_log[axis=y]
setblock 9 75 -186 minecraft:birch_log[axis=y]
setblock 17 75 -190 regions_unexplored:birch_branch[facing=south]
setblock 31 74 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 74 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 74 -127 minecraft:birch_log[axis=y]
setblock 34 74 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 74 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 74 -127 minecraft:birch_log[axis=y]
fill 54 74 -127 55 74 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 74 -127 minecraft:birch_log[axis=y]
setblock 57 74 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 74 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 74 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 74 -128 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 32 74 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 74 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 34 74 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 74 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 74 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 74 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 74 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 74 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 74 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 74 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 74 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 74 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 74 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 74 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 74 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 74 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 74 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 74 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 74 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 74 -132 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 74 -133 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 74 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 74 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 74 -133 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 74 -134 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 64 74 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 74 -135 minecraft:birch_log[axis=y]
setblock 63 74 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 74 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 74 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 74 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 74 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 74 -136 minecraft:birch_log[axis=y]
setblock 65 74 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 66 74 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 74 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 74 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 74 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 74 -137 minecraft:birch_log[axis=y]
setblock 64 74 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 74 -139 minecraft:birch_log[axis=y]
setblock 13 74 -140 minecraft:birch_log[axis=y]
setblock 34 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 74 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 74 -140 minecraft:birch_log[axis=y]
setblock 68 74 -140 minecraft:birch_log[axis=y]
setblock 29 74 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 74 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 74 -141 minecraft:birch_log[axis=y]
setblock 36 74 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 74 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 74 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 74 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 74 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 74 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 74 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 74 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 74 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 74 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 74 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 74 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 48 74 -143 49 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 74 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 74 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 74 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 18 74 -144 19 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 74 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 49 74 -144 50 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 74 -144 minecraft:birch_log[axis=y]
setblock 58 74 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 59 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 74 -144 minecraft:birch_log[axis=y]
setblock 10 74 -145 minecraft:birch_log[axis=y]
setblock 12 74 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 74 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 74 -145 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 74 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 74 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 74 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 74 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 74 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 74 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 74 -145 minecraft:birch_log[axis=y]
setblock 56 74 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 57 74 -145 58 74 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 74 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 74 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 74 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 74 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 74 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 74 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 74 -146 minecraft:birch_log[axis=y]
setblock 57 74 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 74 -146 minecraft:birch_log[axis=y]
setblock 62 74 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 74 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 74 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 74 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 74 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 74 -147 minecraft:birch_log[axis=y]
setblock 13 74 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 74 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 74 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 74 -147 minecraft:birch_log[axis=y]
setblock 62 74 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 74 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 74 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 74 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 14 74 -148 15 74 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 74 -148 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 62 74 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 74 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 74 -148 minecraft:birch_log[axis=y]
setblock 12 74 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 74 -149 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 24 74 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 74 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 74 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 74 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 74 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 74 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 74 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 74 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 74 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 74 -150 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 22 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 74 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 74 -151 minecraft:birch_log[axis=y]
setblock 25 74 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 74 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 74 -151 minecraft:birch_log[axis=y]
setblock 33 74 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 34 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 74 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 74 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 74 -151 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 49 74 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 74 -151 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 21 74 -152 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 22 74 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 74 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 74 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 74 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 74 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 74 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 74 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 74 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 74 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 74 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 74 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 74 -153 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 24 74 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 74 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 74 -153 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 9 74 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 74 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 74 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 74 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 74 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 74 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 74 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 52 74 -154 minecraft:birch_log[axis=y]
setblock 67 74 -154 minecraft:birch_log[axis=y]
setblock 9 74 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 74 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 74 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 74 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 74 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 74 -155 minecraft:birch_log[axis=y]
setblock 17 74 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 74 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 74 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 74 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 74 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 74 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 74 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 74 -158 minecraft:birch_log[axis=y]
setblock 68 74 -158 minecraft:birch_log[axis=y]
setblock 14 74 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 74 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 49 74 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 74 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 74 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 74 -160 minecraft:birch_log[axis=y]
setblock 8 74 -162 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 9 74 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 74 -163 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 74 -168 minecraft:birch_log[axis=y]
setblock 18 74 -172 minecraft:birch_log[axis=y]
setblock 23 74 -173 minecraft:birch_log[axis=y]
setblock 9 74 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 74 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 74 -177 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 74 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 74 -177 minecraft:birch_log[axis=y]
setblock 8 74 -178 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 74 -178 minecraft:birch_log[axis=y]
setblock 10 74 -178 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 74 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 74 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 74 -179 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 74 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 74 -179 minecraft:birch_log[axis=y]
setblock 9 74 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 74 -181 minecraft:birch_log[axis=y]
setblock 8 74 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 74 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 74 -183 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 74 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 74 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 74 -184 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 74 -184 minecraft:birch_log[axis=y]
setblock 9 74 -186 minecraft:birch_log[axis=y]
setblock 19 73 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 73 -127 minecraft:birch_log[axis=y]
setblock 34 73 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 73 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 73 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 73 -127 minecraft:birch_log[axis=y]
setblock 56 73 -127 minecraft:birch_log[axis=y]
setblock 18 73 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 73 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 73 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 73 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 73 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 73 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 73 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 73 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 73 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 73 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 73 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 73 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 73 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 73 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 73 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 73 -130 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 54 73 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 73 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 73 -130 minecraft:birch_log[axis=y]
setblock 57 73 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 73 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 73 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 73 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 73 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 73 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 73 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 73 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 73 -132 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 73 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 73 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 73 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 73 -133 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 73 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 73 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 73 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 73 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 73 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 73 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 73 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 73 -134 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 73 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 73 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 73 -135 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 73 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 73 -135 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 38 73 -135 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 47 73 -135 minecraft:birch_log[axis=y]
setblock 29 73 -136 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 38 73 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 73 -136 minecraft:birch_log[axis=y]
setblock 28 73 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 29 73 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 73 -137 minecraft:birch_log[axis=y]
setblock 53 73 -139 minecraft:birch_log[axis=y]
setblock 13 73 -140 minecraft:birch_log[axis=y]
setblock 64 73 -140 minecraft:birch_log[axis=y]
setblock 68 73 -140 minecraft:birch_log[axis=y]
setblock 20 73 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 73 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 73 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 73 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 73 -141 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 35 73 -141 minecraft:birch_log[axis=y]
setblock 50 73 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 73 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 73 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 73 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 73 -142 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 48 73 -142 49 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 73 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 73 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 73 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 73 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 73 -143 minecraft:birch_log[axis=y]
setblock 21 73 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 73 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 73 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 48 73 -143 49 73 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 73 -143 minecraft:birch_log[axis=y]
setblock 51 73 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 73 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 73 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 18 73 -144 19 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 73 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 73 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 73 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 73 -144 minecraft:birch_log[axis=y]
fill 49 73 -144 51 73 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 73 -144 minecraft:birch_log[axis=y]
setblock 67 73 -144 minecraft:birch_log[axis=y]
setblock 10 73 -145 minecraft:birch_log[axis=y]
setblock 14 73 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 73 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 73 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 73 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 73 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 73 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 73 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 73 -145 minecraft:birch_log[axis=y]
setblock 39 73 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 73 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 73 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 73 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 73 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 73 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 73 -145 minecraft:birch_log[axis=y]
setblock 63 73 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 73 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 73 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 73 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 73 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 73 -146 regions_unexplored:birch_branch[facing=west]
setblock 53 73 -146 minecraft:birch_log[axis=y]
setblock 58 73 -146 minecraft:birch_log[axis=y]
setblock 62 73 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 73 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 73 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 73 -147 minecraft:birch_log[axis=y]
setblock 15 73 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 73 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 73 -147 minecraft:birch_log[axis=y]
setblock 61 73 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 73 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 73 -147 minecraft:birch_log[axis=y]
fill 64 73 -147 65 73 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 73 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 73 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 73 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 73 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 63 73 -148 64 73 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 73 -148 minecraft:birch_log[axis=y]
setblock 15 73 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 73 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 73 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 73 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 73 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 73 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 73 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 73 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 73 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 73 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 73 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 73 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 73 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 73 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 73 -151 minecraft:birch_log[axis=y]
setblock 32 73 -151 minecraft:birch_log[axis=y]
setblock 39 73 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 73 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 42 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 73 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 73 -151 minecraft:birch_log[axis=y]
setblock 45 73 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 73 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 73 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 73 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 73 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 73 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 73 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 73 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 73 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 73 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 73 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 73 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 73 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 73 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 73 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 73 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 73 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 73 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 73 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 73 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 73 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 73 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 73 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 73 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 73 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 73 -154 minecraft:birch_log[axis=y]
setblock 67 73 -154 minecraft:birch_log[axis=y]
setblock 8 73 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 73 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 73 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 73 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 73 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 73 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 73 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 73 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 73 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 73 -155 minecraft:birch_log[axis=y]
setblock 43 73 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 73 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 73 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 73 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 73 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 73 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 73 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 73 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 73 -157 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 46 73 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 73 -157 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 50 73 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 73 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 73 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 73 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 73 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 73 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 73 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 73 -158 minecraft:birch_log[axis=y]
setblock 68 73 -158 minecraft:birch_log[axis=y]
setblock 13 73 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 73 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 73 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 73 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 47 73 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 73 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 73 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 73 -159 minecraft:birch_log[axis=y]
setblock 51 73 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 73 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 73 -160 minecraft:birch_log[axis=y]
setblock 9 73 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 73 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 73 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 73 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 73 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 73 -168 minecraft:birch_log[axis=y]
setblock 18 73 -172 minecraft:birch_log[axis=y]
setblock 23 73 -173 minecraft:birch_log[axis=y]
setblock 16 73 -177 minecraft:birch_log[axis=y]
setblock 9 73 -178 minecraft:birch_log[axis=y]
setblock 19 73 -179 minecraft:birch_log[axis=y]
setblock 8 73 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 73 -181 minecraft:birch_log[axis=y]
setblock 8 73 -182 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 73 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 73 -183 minecraft:birch_log[axis=y]
setblock 9 73 -183 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 73 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 73 -184 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 73 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 73 -184 minecraft:birch_log[axis=y]
setblock 8 73 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 73 -186 minecraft:birch_log[axis=y]
setblock 19 72 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 72 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 72 -127 minecraft:birch_log[axis=y]
fill 34 72 -127 35 72 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 72 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 72 -127 minecraft:birch_log[axis=y]
setblock 56 72 -127 minecraft:birch_log[axis=y]
setblock 64 72 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 72 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 72 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 72 -128 minecraft:air
setblock 63 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 72 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 72 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 72 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 72 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 72 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 72 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 72 -129 minecraft:birch_log[axis=y]
setblock 65 72 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 66 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 72 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 72 -130 minecraft:birch_log[axis=y]
setblock 63 72 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 72 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 72 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 72 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 72 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 72 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 72 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 72 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 72 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 72 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 72 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 72 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 72 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 72 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 72 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 72 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 72 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 72 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 72 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 72 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 72 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 72 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 72 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 72 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 72 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 72 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 72 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 72 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 72 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 72 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 72 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 72 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 72 -135 minecraft:birch_log[axis=y]
setblock 14 72 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 72 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 72 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 72 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 72 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 72 -136 minecraft:birch_log[axis=y]
setblock 28 72 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 72 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 72 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 72 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 72 -137 minecraft:birch_log[axis=y]
setblock 29 72 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 72 -139 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 34 72 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 72 -139 minecraft:birch_log[axis=y]
setblock 11 72 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 72 -140 minecraft:birch_log[axis=y]
setblock 14 72 -140 regions_unexplored:birch_branch[facing=east]
setblock 26 72 -140 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 27 72 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 72 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 72 -140 minecraft:birch_log[axis=y]
setblock 68 72 -140 minecraft:birch_log[axis=y]
setblock 10 72 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 72 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 72 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 72 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 72 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 72 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 72 -141 minecraft:birch_log[axis=y]
setblock 11 72 -142 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 72 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 72 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 72 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 72 -142 minecraft:birch_log[axis=y]
setblock 30 72 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 31 72 -142 32 72 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 72 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 72 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 72 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 72 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 72 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 72 -143 minecraft:birch_log[axis=y]
setblock 28 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 72 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 72 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 72 -143 minecraft:birch_log[axis=y]
setblock 11 72 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 13 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 72 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 72 -144 minecraft:birch_log[axis=y]
setblock 16 72 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 72 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 72 -144 minecraft:birch_log[axis=y]
setblock 57 72 -144 minecraft:birch_log[axis=y]
setblock 67 72 -144 minecraft:birch_log[axis=y]
setblock 10 72 -145 minecraft:birch_log[axis=y]
setblock 14 72 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 72 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 72 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 72 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 72 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 72 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 72 -145 minecraft:birch_log[axis=y]
setblock 51 72 -145 minecraft:birch_log[axis=y]
setblock 52 72 -145 regions_unexplored:birch_branch[facing=east]
setblock 15 72 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 72 -146 minecraft:birch_log[axis=y]
setblock 58 72 -146 minecraft:birch_log[axis=y]
setblock 12 72 -147 minecraft:birch_log[axis=y]
setblock 14 72 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 72 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 72 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 72 -147 regions_unexplored:birch_branch[facing=north]
setblock 55 72 -147 minecraft:birch_log[axis=y]
setblock 63 72 -147 minecraft:birch_log[axis=y]
setblock 14 72 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 72 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 72 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 72 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 72 -148 minecraft:birch_log[axis=y]
setblock 14 72 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 72 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 72 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 72 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 72 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 72 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 72 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 72 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 72 -150 minecraft:birch_log[axis=y]
setblock 41 72 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 42 72 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 72 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 72 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 72 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 72 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 72 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 72 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 72 -151 minecraft:birch_log[axis=y]
setblock 32 72 -151 minecraft:birch_log[axis=y]
setblock 39 72 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 72 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 72 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 72 -151 minecraft:birch_log[axis=y]
setblock 48 72 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 72 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 72 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 72 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 72 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 72 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 72 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 72 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 72 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 72 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 72 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 72 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 72 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 72 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 72 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 42 72 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 72 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 72 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 72 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 72 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 72 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 18 72 -154 19 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 72 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 72 -154 minecraft:birch_log[axis=y]
setblock 22 72 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 72 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 72 -154 minecraft:birch_log[axis=y]
setblock 67 72 -154 minecraft:birch_log[axis=y]
setblock 8 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 72 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 72 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 72 -155 minecraft:birch_log[axis=y]
setblock 18 72 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 19 72 -155 20 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 72 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 72 -155 minecraft:birch_log[axis=y]
setblock 42 72 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 72 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 72 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 72 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 72 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 72 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 72 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 72 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 72 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 72 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 72 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 72 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 72 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 72 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 72 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 72 -158 minecraft:birch_log[axis=y]
setblock 15 72 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 72 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 72 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 72 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 53 72 -158 minecraft:birch_log[axis=y]
setblock 68 72 -158 minecraft:birch_log[axis=y]
setblock 13 72 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 72 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 72 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 46 72 -159 47 72 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 48 72 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 72 -159 minecraft:birch_log[axis=y]
setblock 14 72 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 72 -160 minecraft:birch_log[axis=y]
setblock 8 72 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 72 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 72 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 72 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 72 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 72 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 72 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 72 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 72 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 72 -164 minecraft:air
setblock 20 72 -168 minecraft:birch_log[axis=y]
setblock 18 72 -172 minecraft:birch_log[axis=y]
setblock 23 72 -173 minecraft:birch_log[axis=y]
setblock 18 72 -174 minecraft:air
setblock 16 72 -177 minecraft:birch_log[axis=y]
setblock 9 72 -178 minecraft:birch_log[axis=y]
setblock 19 72 -179 minecraft:birch_log[axis=y]
setblock 12 72 -181 minecraft:birch_log[axis=y]
setblock 8 72 -183 minecraft:birch_log[axis=y]
setblock 18 72 -184 minecraft:air
setblock 21 72 -184 minecraft:birch_log[axis=y]
setblock 9 72 -186 minecraft:birch_log[axis=y]
setblock 19 71 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 71 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 71 -127 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 71 -127 minecraft:birch_log[axis=y]
fill 35 71 -127 37 71 -127 minecraft:air
setblock 38 71 -127 minecraft:birch_log[axis=y]
fill 51 71 -127 53 71 -127 minecraft:air
setblock 56 71 -127 minecraft:birch_log[axis=y]
fill 61 71 -127 63 71 -127 minecraft:air
setblock 71 71 -127 minecraft:air
setblock 18 71 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 71 -128 minecraft:birch_log[axis=y]
setblock 20 71 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 71 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 71 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 71 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 71 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 34 71 -128 38 71 -128 minecraft:air
setblock 52 71 -128 minecraft:air
setblock 62 71 -128 minecraft:air
setblock 18 71 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 71 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 71 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 71 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 71 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 71 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 35 71 -129 37 71 -129 minecraft:air
setblock 64 71 -129 minecraft:birch_log[axis=y]
setblock 19 71 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 71 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 71 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 71 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 71 -130 minecraft:air
setblock 56 71 -130 minecraft:birch_log[axis=y]
setblock 19 71 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 71 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 71 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 71 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 71 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 71 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 71 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 71 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 71 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 71 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 71 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 71 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 71 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 71 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 71 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 71 -133 minecraft:birch_log[axis=y]
setblock 20 71 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 71 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 71 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 71 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 71 -133 minecraft:birch_log[axis=y]
setblock 37 71 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 71 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 71 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 71 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 71 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 71 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 71 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 71 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 71 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 71 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 71 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 71 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 71 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 71 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 71 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 71 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 71 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 71 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 71 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 71 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 71 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 71 -135 minecraft:birch_log[axis=y]
setblock 13 71 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 71 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 71 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 71 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 71 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 71 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 71 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 71 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 71 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 71 -136 minecraft:birch_log[axis=y]
setblock 28 71 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 71 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 71 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 71 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 71 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 71 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 71 -137 minecraft:birch_log[axis=y]
setblock 11 71 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 71 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 71 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 71 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 71 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 71 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 71 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 71 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 71 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 71 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 71 -139 minecraft:birch_log[axis=y]
setblock 11 71 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 71 -140 minecraft:birch_log[axis=y]
setblock 26 71 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 71 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 71 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 71 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 71 -140 minecraft:birch_log[axis=y]
setblock 68 71 -140 minecraft:birch_log[axis=y]
setblock 10 71 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 71 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 71 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 71 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 71 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 71 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 71 -141 minecraft:birch_log[axis=y]
setblock 11 71 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 71 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 71 -142 minecraft:birch_log[axis=y]
setblock 31 71 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 71 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 71 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 71 -142 regions_unexplored:birch_branch[facing=north]
setblock 10 71 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 71 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 71 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 71 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 18 71 -143 19 71 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 71 -143 minecraft:birch_log[axis=y]
setblock 31 71 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 71 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 71 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 71 -143 minecraft:birch_log[axis=y]
setblock 9 71 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 71 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 71 -144 minecraft:birch_log[axis=y]
fill 16 71 -144 17 71 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 71 -144 minecraft:birch_log[axis=y]
fill 19 71 -144 20 71 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 71 -144 minecraft:birch_log[axis=y]
setblock 57 71 -144 minecraft:birch_log[axis=y]
setblock 67 71 -144 minecraft:birch_log[axis=y]
setblock 10 71 -145 minecraft:birch_log[axis=y]
setblock 17 71 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 71 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 71 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 71 -145 minecraft:birch_log[axis=y]
setblock 51 71 -145 minecraft:birch_log[axis=y]
setblock 15 71 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 71 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 71 -146 minecraft:birch_log[axis=y]
setblock 58 71 -146 minecraft:birch_log[axis=y]
setblock 12 71 -147 minecraft:birch_log[axis=y]
setblock 14 71 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 71 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 71 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 71 -147 minecraft:birch_log[axis=y]
setblock 58 71 -147 regions_unexplored:birch_branch[facing=north]
setblock 63 71 -147 minecraft:birch_log[axis=y]
setblock 13 71 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 71 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 71 -148 minecraft:birch_log[axis=y]
setblock 16 71 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 71 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 71 -148 minecraft:birch_log[axis=y]
setblock 14 71 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 71 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 71 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 71 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 71 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 71 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 71 -150 minecraft:birch_log[axis=y]
setblock 48 71 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 71 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 71 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 71 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 22 71 -151 23 71 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 71 -151 minecraft:birch_log[axis=y]
setblock 32 71 -151 minecraft:birch_log[axis=y]
setblock 44 71 -151 minecraft:birch_log[axis=y]
setblock 47 71 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 71 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 71 -151 minecraft:birch_log[axis=y]
setblock 50 71 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 71 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 71 -152 minecraft:air
setblock 20 71 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 71 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 71 -152 minecraft:birch_log[axis=y]
fill 23 71 -152 24 71 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 43 71 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 71 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 71 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 71 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 71 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 17 71 -153 19 71 -153 minecraft:air
fill 21 71 -153 22 71 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 71 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 71 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 71 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 71 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 71 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 71 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 71 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 71 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 16 71 -154 20 71 -154 minecraft:air
setblock 21 71 -154 minecraft:birch_log[axis=y]
setblock 22 71 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 71 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 71 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 43 71 -154 minecraft:birch_log[axis=y]
setblock 44 71 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 71 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 71 -154 minecraft:birch_log[axis=y]
setblock 67 71 -154 minecraft:birch_log[axis=y]
setblock 8 71 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 71 -155 minecraft:birch_log[axis=y]
setblock 10 71 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 71 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 71 -155 minecraft:birch_log[axis=y]
fill 18 71 -155 19 71 -155 minecraft:air
setblock 39 71 -155 minecraft:birch_log[axis=y]
setblock 42 71 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 71 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 71 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 71 -155 regions_unexplored:birch_branch[facing=north]
setblock 8 71 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 71 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 71 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 71 -156 minecraft:air
setblock 43 71 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 71 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 71 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 71 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 71 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 71 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 71 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 71 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 71 -158 minecraft:birch_log[axis=y]
setblock 45 71 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 71 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 71 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 71 -158 minecraft:birch_log[axis=y]
setblock 68 71 -158 minecraft:birch_log[axis=y]
setblock 50 71 -159 minecraft:birch_log[axis=y]
setblock 9 71 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 71 -160 minecraft:birch_log[axis=y]
setblock 8 71 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 71 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 71 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 71 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 71 -162 minecraft:birch_log[axis=y]
setblock 10 71 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 71 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 71 -162 minecraft:air
setblock 8 71 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 71 -163 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 71 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 17 71 -163 19 71 -163 minecraft:air
fill 8 71 -164 9 71 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 16 71 -164 20 71 -164 minecraft:air
fill 17 71 -165 19 71 -165 minecraft:air
setblock 18 71 -166 minecraft:air
setblock 20 71 -168 minecraft:birch_log[axis=y]
setblock 18 71 -172 minecraft:birch_log[axis=y]
fill 17 71 -173 19 71 -173 minecraft:air
setblock 23 71 -173 minecraft:birch_log[axis=y]
fill 16 71 -174 20 71 -174 minecraft:air
setblock 23 71 -174 regions_unexplored:birch_shrub[half=upper]
fill 17 71 -175 19 71 -175 minecraft:air
setblock 18 71 -176 minecraft:air
setblock 16 71 -177 minecraft:birch_log[axis=y]
setblock 9 71 -178 minecraft:birch_log[axis=y]
setblock 14 71 -179 minecraft:short_grass
setblock 19 71 -179 minecraft:birch_log[axis=y]
setblock 14 71 -180 minecraft:short_grass
setblock 12 71 -181 minecraft:birch_log[axis=y]
setblock 20 71 -181 regions_unexplored:birch_shrub[half=upper]
setblock 18 71 -182 minecraft:air
setblock 8 71 -183 minecraft:birch_log[axis=y]
fill 16 71 -183 17 71 -183 minecraft:short_grass
setblock 18 71 -183 regions_unexplored:grass_sprouts
setblock 19 71 -183 minecraft:air
setblock 14 71 -184 minecraft:short_grass
fill 16 71 -184 18 71 -184 minecraft:air
setblock 19 71 -184 regions_unexplored:grass_sprouts
setblock 20 71 -184 minecraft:air
setblock 21 71 -184 minecraft:birch_log[axis=y]
fill 17 71 -185 19 71 -185 minecraft:air
setblock 9 71 -186 minecraft:birch_log[axis=y]
setblock 16 71 -186 regions_unexplored:grass_sprouts
setblock 18 71 -186 minecraft:air
setblock 13 71 -187 regions_unexplored:grass_sprouts
setblock 15 71 -189 regions_unexplored:grass_sprouts
setblock 12 71 -190 regions_unexplored:grass_sprouts
setblock 14 71 -190 minecraft:short_grass
setblock 25 71 -190 regions_unexplored:grass_sprouts
setblock 21 70 -127 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 22 70 -127 herbsandharvest:avocado_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 23 70 -127 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 70 -127 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 70 -127 herbsandharvest:avocado_fruit_leaves[age=2,distance=4,persistent=false,waterlogged=false]
setblock 28 70 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 70 -127 minecraft:birch_log[axis=y]
fill 34 70 -127 37 70 -127 minecraft:air
setblock 38 70 -127 minecraft:birch_log[axis=y]
fill 50 70 -127 54 70 -127 minecraft:air
setblock 56 70 -127 minecraft:birch_log[axis=y]
fill 60 70 -127 64 70 -127 minecraft:air
fill 70 70 -127 71 70 -127 minecraft:air
setblock 19 70 -128 minecraft:birch_log[axis=y]
setblock 22 70 -128 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 70 -128 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 70 -128 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 27 70 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 70 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 34 70 -128 38 70 -128 minecraft:air
fill 51 70 -128 53 70 -128 minecraft:air
fill 61 70 -128 63 70 -128 minecraft:air
setblock 71 70 -128 minecraft:air
setblock 26 70 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 70 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 70 -129 minecraft:birch_log[axis=y]
setblock 29 70 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 70 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 34 70 -129 38 70 -129 minecraft:air
setblock 64 70 -129 minecraft:birch_log[axis=y]
setblock 27 70 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 70 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 35 70 -130 37 70 -130 minecraft:air
setblock 56 70 -130 minecraft:birch_log[axis=y]
setblock 16 70 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 70 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 70 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 70 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 70 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 70 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 70 -133 minecraft:birch_log[axis=y]
fill 17 70 -133 18 70 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 70 -133 minecraft:birch_log[axis=y]
setblock 36 70 -133 minecraft:birch_log[axis=y]
setblock 13 70 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 70 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 70 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 70 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 70 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 70 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 70 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 70 -135 minecraft:birch_log[axis=y]
setblock 15 70 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 70 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 70 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 70 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 70 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 70 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 70 -135 minecraft:birch_log[axis=y]
setblock 13 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 70 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 70 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 70 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 70 -136 minecraft:birch_log[axis=y]
setblock 39 70 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 70 -136 minecraft:birch_log[axis=y]
setblock 12 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 70 -137 minecraft:birch_log[axis=y]
setblock 30 70 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 70 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 70 -137 minecraft:birch_log[axis=y]
setblock 11 70 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 70 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 70 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 70 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 70 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 70 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 70 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 70 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 70 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 70 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 70 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 70 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 70 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 70 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 70 -139 minecraft:birch_log[axis=y]
fill 11 70 -140 12 70 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 70 -140 minecraft:birch_log[axis=y]
setblock 26 70 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 70 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 70 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 70 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 70 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 70 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 70 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 70 -140 minecraft:birch_log[axis=y]
setblock 68 70 -140 minecraft:birch_log[axis=y]
setblock 10 70 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 70 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 70 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 70 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 70 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 70 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 70 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 70 -141 minecraft:birch_log[axis=y]
fill 10 70 -142 11 70 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 70 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 70 -142 minecraft:birch_log[axis=y]
fill 30 70 -142 31 70 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 70 -142 minecraft:birch_log[axis=y]
setblock 33 70 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 34 70 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 70 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 70 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 70 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 70 -143 minecraft:birch_log[axis=y]
setblock 31 70 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 70 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 70 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 70 -143 minecraft:birch_log[axis=y]
setblock 10 70 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 70 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 70 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 70 -144 minecraft:birch_log[axis=y]
setblock 18 70 -144 minecraft:birch_log[axis=y]
setblock 32 70 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 70 -144 minecraft:birch_log[axis=y]
setblock 57 70 -144 minecraft:birch_log[axis=y]
setblock 67 70 -144 minecraft:birch_log[axis=y]
setblock 10 70 -145 minecraft:birch_log[axis=y]
setblock 38 70 -145 minecraft:birch_log[axis=y]
setblock 48 70 -145 regions_unexplored:birch_branch[facing=north]
setblock 51 70 -145 minecraft:birch_log[axis=y]
setblock 53 70 -146 minecraft:birch_log[axis=y]
setblock 58 70 -146 minecraft:birch_log[axis=y]
setblock 12 70 -147 minecraft:birch_log[axis=y]
setblock 55 70 -147 minecraft:birch_log[axis=y]
setblock 63 70 -147 minecraft:birch_log[axis=y]
setblock 15 70 -148 minecraft:birch_log[axis=y]
setblock 65 70 -148 minecraft:birch_log[axis=y]
setblock 40 70 -150 minecraft:birch_log[axis=y]
setblock 24 70 -151 minecraft:birch_log[axis=y]
setblock 32 70 -151 minecraft:birch_log[axis=y]
setblock 44 70 -151 minecraft:birch_log[axis=y]
setblock 49 70 -151 minecraft:birch_log[axis=y]
fill 17 70 -152 19 70 -152 minecraft:air
setblock 22 70 -152 minecraft:birch_log[axis=y]
fill 16 70 -153 20 70 -153 minecraft:air
fill 16 70 -154 20 70 -154 minecraft:air
setblock 21 70 -154 minecraft:birch_log[axis=y]
setblock 43 70 -154 minecraft:birch_log[axis=y]
setblock 52 70 -154 minecraft:birch_log[axis=y]
setblock 67 70 -154 minecraft:birch_log[axis=y]
setblock 9 70 -155 minecraft:birch_log[axis=y]
setblock 16 70 -155 minecraft:air
setblock 17 70 -155 minecraft:birch_log[axis=y]
fill 18 70 -155 20 70 -155 minecraft:air
setblock 39 70 -155 minecraft:birch_log[axis=y]
setblock 46 70 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 17 70 -156 19 70 -156 minecraft:air
setblock 45 70 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 70 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 70 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 70 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 70 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 70 -157 minecraft:birch_log[axis=y]
setblock 47 70 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 70 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 70 -158 minecraft:birch_log[axis=y]
setblock 45 70 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 70 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 70 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 70 -158 minecraft:birch_log[axis=y]
setblock 68 70 -158 minecraft:birch_log[axis=y]
setblock 46 70 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 70 -159 minecraft:birch_log[axis=y]
setblock 19 70 -160 minecraft:birch_log[axis=y]
setblock 9 70 -162 minecraft:birch_log[axis=y]
fill 17 70 -162 19 70 -162 minecraft:air
fill 16 70 -163 20 70 -163 minecraft:air
fill 16 70 -164 20 70 -164 minecraft:air
fill 16 70 -165 20 70 -165 minecraft:air
fill 17 70 -166 19 70 -166 minecraft:air
setblock 20 70 -168 minecraft:birch_log[axis=y]
setblock 23 70 -168 regions_unexplored:grass_sprouts
setblock 24 70 -168 minecraft:short_grass
setblock 24 70 -169 regions_unexplored:grass_sprouts
fill 24 70 -170 25 70 -170 regions_unexplored:grass_sprouts
setblock 12 70 -172 minecraft:grass_block[snowy=false]
setblock 17 70 -172 minecraft:air
setblock 18 70 -172 minecraft:birch_log[axis=y]
setblock 19 70 -172 minecraft:air
setblock 24 70 -172 minecraft:short_grass
setblock 25 70 -172 regions_unexplored:grass_sprouts
setblock 12 70 -173 minecraft:grass_block[snowy=false]
fill 16 70 -173 20 70 -173 minecraft:air
fill 21 70 -173 22 70 -173 regions_unexplored:grass_sprouts
setblock 23 70 -173 minecraft:birch_log[axis=y]
fill 12 70 -174 13 70 -174 minecraft:grass_block[snowy=false]
fill 16 70 -174 20 70 -174 minecraft:air
fill 21 70 -174 22 70 -174 minecraft:short_grass
setblock 23 70 -174 regions_unexplored:birch_shrub[half=lower]
fill 12 70 -175 13 70 -175 minecraft:grass_block[snowy=false]
fill 16 70 -175 20 70 -175 minecraft:air
setblock 23 70 -175 minecraft:short_grass
fill 12 70 -176 13 70 -176 minecraft:grass_block[snowy=false]
fill 17 70 -176 19 70 -176 minecraft:air
fill 12 70 -177 13 70 -177 minecraft:grass_block[snowy=false]
setblock 16 70 -177 minecraft:birch_log[axis=y]
fill 25 70 -177 26 70 -177 minecraft:short_grass
setblock 9 70 -178 minecraft:birch_log[axis=y]
fill 12 70 -178 14 70 -178 minecraft:grass_block[snowy=false]
fill 12 70 -179 14 70 -179 minecraft:grass_block[snowy=false]
setblock 19 70 -179 minecraft:birch_log[axis=y]
setblock 24 70 -179 minecraft:short_grass
setblock 25 70 -179 regions_unexplored:grass_sprouts
fill 12 70 -180 14 70 -180 minecraft:grass_block[snowy=false]
setblock 22 70 -180 minecraft:short_grass
setblock 12 70 -181 minecraft:dirt
fill 13 70 -181 15 70 -181 minecraft:grass_block[snowy=false]
setblock 16 70 -181 minecraft:short_grass
setblock 19 70 -181 minecraft:short_grass
setblock 20 70 -181 regions_unexplored:birch_shrub[half=lower]
setblock 21 70 -181 minecraft:short_grass
fill 12 70 -182 16 70 -182 minecraft:grass_block[snowy=false]
setblock 17 70 -182 minecraft:short_grass
setblock 18 70 -182 minecraft:air
setblock 19 70 -182 regions_unexplored:grass_sprouts
setblock 26 70 -182 minecraft:short_grass
setblock 8 70 -183 minecraft:birch_log[axis=y]
setblock 10 70 -183 regions_unexplored:grass_sprouts
fill 12 70 -183 18 70 -183 minecraft:grass_block[snowy=false]
setblock 19 70 -183 minecraft:air
setblock 20 70 -183 minecraft:short_grass
fill 12 70 -184 20 70 -184 minecraft:grass_block[snowy=false]
setblock 21 70 -184 minecraft:dirt
fill 12 70 -185 23 70 -185 minecraft:grass_block[snowy=false]
setblock 9 70 -186 minecraft:birch_log[axis=y]
setblock 10 70 -186 minecraft:short_grass
fill 12 70 -186 24 70 -186 minecraft:grass_block[snowy=false]
fill 12 70 -187 24 70 -187 minecraft:grass_block[snowy=false]
fill 12 70 -188 25 70 -188 minecraft:grass_block[snowy=false]
fill 11 70 -189 25 70 -189 minecraft:grass_block[snowy=false]
setblock 10 70 -190 regions_unexplored:grass_sprouts
fill 11 70 -190 25 70 -190 minecraft:grass_block[snowy=false]
setblock 19 69 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 69 -127 herbsandharvest:avocado_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 22 69 -127 herbsandharvest:avocado_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 23 69 -127 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 69 -127 herbsandharvest:avocado_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 25 69 -127 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 69 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 69 -127 minecraft:birch_log[axis=y]
fill 35 69 -127 37 69 -127 minecraft:air
setblock 38 69 -127 minecraft:birch_log[axis=y]
fill 51 69 -127 53 69 -127 minecraft:air
setblock 56 69 -127 minecraft:birch_log[axis=y]
fill 61 69 -127 63 69 -127 minecraft:air
setblock 71 69 -127 minecraft:air
setblock 19 69 -128 minecraft:birch_log[axis=y]
setblock 22 69 -128 herbsandharvest:avocado_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 23 69 -128 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 69 -128 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
fill 34 69 -128 38 69 -128 minecraft:air
setblock 52 69 -128 minecraft:air
setblock 62 69 -128 minecraft:air
setblock 28 69 -129 minecraft:birch_log[axis=y]
fill 35 69 -129 37 69 -129 minecraft:air
setblock 64 69 -129 minecraft:birch_log[axis=y]
setblock 36 69 -130 minecraft:air
setblock 56 69 -130 minecraft:birch_log[axis=y]
setblock 16 69 -133 minecraft:birch_log[axis=y]
setblock 19 69 -133 minecraft:birch_log[axis=y]
setblock 36 69 -133 minecraft:birch_log[axis=y]
setblock 14 69 -134 minecraft:bee_nest[facing=south,honey_level=5]
setblock 14 69 -135 minecraft:birch_log[axis=y]
setblock 47 69 -135 minecraft:birch_log[axis=y]
setblock 38 69 -136 minecraft:birch_log[axis=y]
setblock 64 69 -136 minecraft:birch_log[axis=y]
setblock 29 69 -137 minecraft:birch_log[axis=y]
setblock 34 69 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 69 -137 minecraft:birch_log[axis=y]
setblock 27 69 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 69 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 69 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 69 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 69 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 69 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 69 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 69 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 69 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 34 69 -139 minecraft:birch_log[axis=y]
setblock 35 69 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 69 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 69 -139 minecraft:birch_log[axis=y]
setblock 12 69 -140 regions_unexplored:birch_branch[facing=west]
setblock 13 69 -140 minecraft:birch_log[axis=y]
setblock 25 69 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 69 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 69 -140 minecraft:birch_log[axis=y]
setblock 28 69 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 69 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 69 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 34 69 -140 35 69 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 69 -140 minecraft:birch_log[axis=y]
setblock 68 69 -140 minecraft:birch_log[axis=y]
setblock 11 69 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 69 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 69 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 69 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 69 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 69 -141 minecraft:birch_log[axis=y]
setblock 10 69 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 69 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 69 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 69 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 69 -142 minecraft:birch_log[axis=y]
setblock 32 69 -142 minecraft:birch_log[axis=y]
setblock 10 69 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 69 -143 minecraft:birch_log[axis=y]
setblock 12 69 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 69 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 69 -143 minecraft:birch_log[axis=y]
setblock 50 69 -143 minecraft:birch_log[axis=y]
fill 10 69 -144 11 69 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 69 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 69 -144 minecraft:birch_log[axis=y]
setblock 18 69 -144 minecraft:birch_log[axis=y]
setblock 48 69 -144 minecraft:birch_log[axis=y]
setblock 57 69 -144 minecraft:birch_log[axis=y]
setblock 67 69 -144 minecraft:birch_log[axis=y]
setblock 10 69 -145 minecraft:birch_log[axis=y]
setblock 11 69 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 69 -145 minecraft:birch_log[axis=y]
setblock 39 69 -145 regions_unexplored:birch_branch[facing=east]
setblock 51 69 -145 minecraft:birch_log[axis=y]
setblock 53 69 -146 minecraft:birch_log[axis=y]
setblock 58 69 -146 minecraft:birch_log[axis=y]
setblock 11 69 -147 regions_unexplored:birch_branch[facing=west]
setblock 12 69 -147 minecraft:birch_log[axis=y]
setblock 55 69 -147 minecraft:birch_log[axis=y]
setblock 63 69 -147 minecraft:birch_log[axis=y]
setblock 15 69 -148 minecraft:birch_log[axis=y]
setblock 65 69 -148 minecraft:birch_log[axis=y]
setblock 40 69 -150 minecraft:birch_log[axis=y]
setblock 24 69 -151 minecraft:birch_log[axis=y]
setblock 32 69 -151 minecraft:birch_log[axis=y]
setblock 44 69 -151 minecraft:birch_log[axis=y]
setblock 49 69 -151 minecraft:birch_log[axis=y]
setblock 18 69 -152 minecraft:air
setblock 22 69 -152 minecraft:birch_log[axis=y]
fill 17 69 -153 19 69 -153 minecraft:air
fill 16 69 -154 20 69 -154 minecraft:air
setblock 21 69 -154 minecraft:birch_log[axis=y]
setblock 43 69 -154 minecraft:birch_log[axis=y]
setblock 52 69 -154 minecraft:birch_log[axis=y]
setblock 67 69 -154 minecraft:birch_log[axis=y]
setblock 9 69 -155 minecraft:birch_log[axis=y]
setblock 17 69 -155 minecraft:birch_log[axis=y]
fill 18 69 -155 19 69 -155 minecraft:air
setblock 39 69 -155 minecraft:birch_log[axis=y]
setblock 18 69 -156 minecraft:air
setblock 46 69 -157 minecraft:birch_log[axis=y]
setblock 14 69 -158 minecraft:birch_log[axis=y]
setblock 53 69 -158 minecraft:birch_log[axis=y]
setblock 68 69 -158 minecraft:birch_log[axis=y]
setblock 50 69 -159 minecraft:birch_log[axis=y]
setblock 19 69 -160 minecraft:birch_log[axis=y]
setblock 9 69 -162 minecraft:birch_log[axis=y]
setblock 18 69 -162 minecraft:air
fill 17 69 -163 19 69 -163 minecraft:air
fill 16 69 -164 20 69 -164 minecraft:air
fill 17 69 -165 19 69 -165 minecraft:air
setblock 18 69 -166 minecraft:air
setblock 26 69 -166 minecraft:short_grass
setblock 19 69 -167 minecraft:short_grass
setblock 24 69 -167 minecraft:short_grass
setblock 12 69 -168 regions_unexplored:grass_sprouts
fill 16 69 -168 19 69 -168 minecraft:grass_block[snowy=false]
setblock 20 69 -168 minecraft:dirt
fill 21 69 -168 25 69 -168 minecraft:grass_block[snowy=false]
fill 15 69 -169 25 69 -169 minecraft:grass_block[snowy=false]
fill 14 69 -170 25 69 -170 minecraft:grass_block[snowy=false]
fill 11 69 -171 25 69 -171 minecraft:grass_block[snowy=false]
fill 9 69 -172 11 69 -172 minecraft:grass_block[snowy=false]
setblock 12 69 -172 minecraft:dirt
fill 13 69 -172 17 69 -172 minecraft:grass_block[snowy=false]
setblock 18 69 -172 minecraft:dirt
fill 19 69 -172 25 69 -172 minecraft:grass_block[snowy=false]
setblock 26 69 -172 regions_unexplored:grass_sprouts
fill 9 69 -173 11 69 -173 minecraft:grass_block[snowy=false]
setblock 12 69 -173 minecraft:dirt
fill 13 69 -173 22 69 -173 minecraft:grass_block[snowy=false]
setblock 23 69 -173 minecraft:dirt
fill 24 69 -173 25 69 -173 minecraft:grass_block[snowy=false]
fill 9 69 -174 11 69 -174 minecraft:grass_block[snowy=false]
fill 12 69 -174 13 69 -174 minecraft:dirt
fill 14 69 -174 25 69 -174 minecraft:grass_block[snowy=false]
fill 10 69 -175 11 69 -175 minecraft:grass_block[snowy=false]
fill 12 69 -175 13 69 -175 minecraft:dirt
fill 14 69 -175 17 69 -175 minecraft:grass_block[snowy=false]
fill 18 69 -175 19 69 -175 minecraft:air
fill 23 69 -175 25 69 -175 minecraft:grass_block[snowy=false]
fill 10 69 -176 11 69 -176 minecraft:grass_block[snowy=false]
fill 12 69 -176 13 69 -176 minecraft:dirt
fill 14 69 -176 17 69 -176 minecraft:grass_block[snowy=false]
setblock 18 69 -176 minecraft:air
fill 22 69 -176 25 69 -176 minecraft:grass_block[snowy=false]
fill 10 69 -177 11 69 -177 minecraft:grass_block[snowy=false]
fill 12 69 -177 13 69 -177 minecraft:dirt
fill 14 69 -177 15 69 -177 minecraft:grass_block[snowy=false]
setblock 16 69 -177 minecraft:dirt
fill 22 69 -177 26 69 -177 minecraft:grass_block[snowy=false]
setblock 9 69 -178 minecraft:birch_log[axis=y]
fill 10 69 -178 11 69 -178 minecraft:grass_block[snowy=false]
fill 12 69 -178 14 69 -178 minecraft:dirt
fill 15 69 -178 16 69 -178 minecraft:grass_block[snowy=false]
fill 18 69 -178 26 69 -178 minecraft:grass_block[snowy=false]
setblock 9 69 -179 regions_unexplored:grass_sprouts
fill 10 69 -179 11 69 -179 minecraft:grass_block[snowy=false]
fill 12 69 -179 14 69 -179 minecraft:dirt
fill 15 69 -179 18 69 -179 minecraft:grass_block[snowy=false]
setblock 19 69 -179 minecraft:dirt
fill 20 69 -179 26 69 -179 minecraft:grass_block[snowy=false]
fill 10 69 -180 11 69 -180 minecraft:grass_block[snowy=false]
fill 12 69 -180 14 69 -180 minecraft:dirt
fill 15 69 -180 26 69 -180 minecraft:grass_block[snowy=false]
fill 10 69 -181 11 69 -181 minecraft:grass_block[snowy=false]
fill 12 69 -181 15 69 -181 minecraft:dirt
fill 16 69 -181 26 69 -181 minecraft:grass_block[snowy=false]
fill 10 69 -182 11 69 -182 minecraft:grass_block[snowy=false]
fill 12 69 -182 16 69 -182 minecraft:dirt
fill 17 69 -182 26 69 -182 minecraft:grass_block[snowy=false]
setblock 8 69 -183 minecraft:birch_log[axis=y]
fill 10 69 -183 11 69 -183 minecraft:grass_block[snowy=false]
fill 12 69 -183 18 69 -183 minecraft:dirt
fill 19 69 -183 26 69 -183 minecraft:grass_block[snowy=false]
fill 10 69 -184 11 69 -184 minecraft:grass_block[snowy=false]
fill 12 69 -184 21 69 -184 minecraft:dirt
fill 22 69 -184 26 69 -184 minecraft:grass_block[snowy=false]
fill 10 69 -185 11 69 -185 minecraft:grass_block[snowy=false]
fill 12 69 -185 23 69 -185 minecraft:dirt
fill 24 69 -185 26 69 -185 minecraft:grass_block[snowy=false]
setblock 9 69 -186 minecraft:birch_log[axis=y]
fill 10 69 -186 11 69 -186 minecraft:grass_block[snowy=false]
fill 12 69 -186 24 69 -186 minecraft:dirt
fill 25 69 -186 26 69 -186 minecraft:grass_block[snowy=false]
fill 10 69 -187 11 69 -187 minecraft:grass_block[snowy=false]
fill 12 69 -187 24 69 -187 minecraft:dirt
fill 25 69 -187 26 69 -187 minecraft:grass_block[snowy=false]
fill 10 69 -188 11 69 -188 minecraft:grass_block[snowy=false]
fill 12 69 -188 25 69 -188 minecraft:dirt
setblock 26 69 -188 minecraft:grass_block[snowy=false]
setblock 10 69 -189 minecraft:grass_block[snowy=false]
fill 11 69 -189 25 69 -189 minecraft:dirt
setblock 26 69 -189 minecraft:grass_block[snowy=false]
fill 9 69 -190 10 69 -190 minecraft:grass_block[snowy=false]
fill 11 69 -190 25 69 -190 minecraft:dirt
setblock 26 69 -190 minecraft:grass_block[snowy=false]
setblock 21 68 -127 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 68 -127 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 68 -127 herbsandharvest:avocado_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 24 68 -127 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 68 -127 herbsandharvest:avocado_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 33 68 -127 minecraft:birch_log[axis=y]
setblock 38 68 -127 minecraft:birch_log[axis=y]
setblock 56 68 -127 minecraft:birch_log[axis=y]
setblock 19 68 -128 minecraft:birch_log[axis=y]
setblock 22 68 -128 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 68 -128 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 68 -128 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 68 -128 minecraft:air
setblock 28 68 -129 minecraft:birch_log[axis=y]
setblock 64 68 -129 minecraft:birch_log[axis=y]
setblock 56 68 -130 minecraft:birch_log[axis=y]
setblock 16 68 -133 minecraft:birch_log[axis=y]
setblock 19 68 -133 minecraft:birch_log[axis=y]
setblock 36 68 -133 minecraft:birch_log[axis=y]
setblock 63 68 -133 minecraft:short_grass
setblock 14 68 -135 minecraft:birch_log[axis=y]
setblock 47 68 -135 minecraft:birch_log[axis=y]
setblock 38 68 -136 minecraft:birch_log[axis=y]
setblock 64 68 -136 minecraft:birch_log[axis=y]
setblock 29 68 -137 minecraft:birch_log[axis=y]
setblock 70 68 -137 minecraft:birch_log[axis=y]
setblock 34 68 -139 minecraft:birch_log[axis=y]
setblock 53 68 -139 minecraft:birch_log[axis=y]
setblock 13 68 -140 minecraft:birch_log[axis=y]
setblock 27 68 -140 minecraft:birch_log[axis=y]
setblock 64 68 -140 minecraft:birch_log[axis=y]
setblock 68 68 -140 minecraft:birch_log[axis=y]
setblock 69 68 -140 regions_unexplored:grass_sprouts
setblock 35 68 -141 minecraft:birch_log[axis=y]
fill 66 68 -141 67 68 -141 regions_unexplored:grass_sprouts
setblock 69 68 -141 regions_unexplored:grass_sprouts
setblock 29 68 -142 minecraft:birch_log[axis=y]
setblock 32 68 -142 minecraft:birch_log[axis=y]
setblock 66 68 -142 minecraft:short_grass
setblock 11 68 -143 minecraft:birch_log[axis=y]
setblock 20 68 -143 minecraft:birch_log[axis=y]
setblock 50 68 -143 minecraft:birch_log[axis=y]
setblock 63 68 -143 regions_unexplored:grass_sprouts
fill 66 68 -143 68 68 -143 regions_unexplored:grass_sprouts
setblock 15 68 -144 minecraft:birch_log[axis=y]
setblock 18 68 -144 minecraft:birch_log[axis=y]
setblock 48 68 -144 minecraft:birch_log[axis=y]
setblock 57 68 -144 minecraft:birch_log[axis=y]
setblock 64 68 -144 minecraft:short_grass
setblock 67 68 -144 minecraft:birch_log[axis=y]
setblock 10 68 -145 minecraft:birch_log[axis=y]
setblock 38 68 -145 minecraft:birch_log[axis=y]
setblock 51 68 -145 minecraft:birch_log[axis=y]
setblock 69 68 -145 regions_unexplored:grass_sprouts
setblock 53 68 -146 minecraft:birch_log[axis=y]
setblock 58 68 -146 minecraft:birch_log[axis=y]
setblock 12 68 -147 minecraft:birch_log[axis=y]
setblock 55 68 -147 minecraft:birch_log[axis=y]
setblock 63 68 -147 minecraft:birch_log[axis=y]
setblock 71 68 -147 minecraft:grass_block[snowy=false]
setblock 15 68 -148 minecraft:birch_log[axis=y]
setblock 65 68 -148 minecraft:birch_log[axis=y]
setblock 71 68 -148 minecraft:grass_block[snowy=false]
setblock 68 68 -149 minecraft:short_grass
setblock 40 68 -150 minecraft:birch_log[axis=y]
setblock 64 68 -150 regions_unexplored:grass_sprouts
setblock 69 68 -150 regions_unexplored:grass_sprouts
setblock 24 68 -151 minecraft:birch_log[axis=y]
setblock 32 68 -151 minecraft:birch_log[axis=y]
setblock 44 68 -151 minecraft:birch_log[axis=y]
setblock 49 68 -151 minecraft:birch_log[axis=y]
setblock 67 68 -151 regions_unexplored:grass_sprouts
setblock 22 68 -152 minecraft:birch_log[axis=y]
setblock 63 68 -152 regions_unexplored:grass_sprouts
setblock 18 68 -154 minecraft:air
setblock 21 68 -154 minecraft:birch_log[axis=y]
setblock 43 68 -154 minecraft:birch_log[axis=y]
setblock 52 68 -154 minecraft:birch_log[axis=y]
setblock 67 68 -154 minecraft:birch_log[axis=y]
setblock 9 68 -155 minecraft:birch_log[axis=y]
setblock 17 68 -155 minecraft:birch_log[axis=y]
setblock 39 68 -155 minecraft:birch_log[axis=y]
setblock 71 68 -155 minecraft:short_grass
setblock 46 68 -157 minecraft:birch_log[axis=y]
setblock 14 68 -158 minecraft:birch_log[axis=y]
setblock 53 68 -158 minecraft:birch_log[axis=y]
setblock 68 68 -158 minecraft:birch_log[axis=y]
setblock 50 68 -159 minecraft:birch_log[axis=y]
setblock 19 68 -160 minecraft:birch_log[axis=y]
setblock 9 68 -162 minecraft:birch_log[axis=y]
setblock 18 68 -164 minecraft:air
setblock 16 68 -166 regions_unexplored:grass_sprouts
setblock 26 68 -166 minecraft:grass_block[snowy=false]
setblock 12 68 -167 minecraft:short_grass
fill 15 68 -167 26 68 -167 minecraft:grass_block[snowy=false]
fill 12 68 -168 15 68 -168 minecraft:grass_block[snowy=false]
fill 16 68 -168 25 68 -168 minecraft:dirt
setblock 26 68 -168 minecraft:grass_block[snowy=false]
fill 10 68 -169 14 68 -169 minecraft:grass_block[snowy=false]
fill 15 68 -169 25 68 -169 minecraft:dirt
setblock 26 68 -169 minecraft:grass_block[snowy=false]
fill 8 68 -170 13 68 -170 minecraft:grass_block[snowy=false]
fill 14 68 -170 25 68 -170 minecraft:dirt
setblock 26 68 -170 minecraft:grass_block[snowy=false]
fill 8 68 -171 10 68 -171 minecraft:grass_block[snowy=false]
fill 11 68 -171 25 68 -171 minecraft:dirt
setblock 26 68 -171 minecraft:grass_block[snowy=false]
setblock 8 68 -172 minecraft:grass_block[snowy=false]
fill 9 68 -172 25 68 -172 minecraft:dirt
setblock 26 68 -172 minecraft:grass_block[snowy=false]
setblock 8 68 -173 minecraft:grass_block[snowy=false]
fill 9 68 -173 25 68 -173 minecraft:dirt
setblock 26 68 -173 minecraft:grass_block[snowy=false]
setblock 8 68 -174 minecraft:grass_block[snowy=false]
fill 9 68 -174 25 68 -174 minecraft:dirt
setblock 26 68 -174 minecraft:grass_block[snowy=false]
fill 8 68 -175 9 68 -175 minecraft:grass_block[snowy=false]
fill 10 68 -175 17 68 -175 minecraft:dirt
setblock 22 68 -175 minecraft:grass_block[snowy=false]
fill 23 68 -175 25 68 -175 minecraft:dirt
setblock 26 68 -175 minecraft:grass_block[snowy=false]
fill 8 68 -176 9 68 -176 minecraft:grass_block[snowy=false]
fill 10 68 -176 16 68 -176 minecraft:dirt
fill 22 68 -176 25 68 -176 minecraft:dirt
setblock 26 68 -176 minecraft:grass_block[snowy=false]
fill 8 68 -177 9 68 -177 minecraft:grass_block[snowy=false]
fill 10 68 -177 16 68 -177 minecraft:dirt
setblock 21 68 -177 minecraft:grass_block[snowy=false]
fill 22 68 -177 26 68 -177 minecraft:dirt
setblock 8 68 -178 minecraft:grass_block[snowy=false]
fill 9 68 -178 15 68 -178 minecraft:dirt
fill 18 68 -178 26 68 -178 minecraft:dirt
fill 8 68 -179 9 68 -179 minecraft:grass_block[snowy=false]
fill 10 68 -179 26 68 -179 minecraft:dirt
fill 8 68 -180 9 68 -180 minecraft:grass_block[snowy=false]
fill 10 68 -180 26 68 -180 minecraft:dirt
fill 8 68 -181 9 68 -181 minecraft:grass_block[snowy=false]
fill 10 68 -181 26 68 -181 minecraft:dirt
fill 8 68 -182 9 68 -182 minecraft:grass_block[snowy=false]
fill 10 68 -182 26 68 -182 minecraft:dirt
setblock 8 68 -183 minecraft:birch_log[axis=y]
setblock 9 68 -183 minecraft:grass_block[snowy=false]
fill 10 68 -183 26 68 -183 minecraft:dirt
setblock 9 68 -184 minecraft:grass_block[snowy=false]
fill 10 68 -184 26 68 -184 minecraft:dirt
setblock 9 68 -185 minecraft:grass_block[snowy=false]
fill 10 68 -185 26 68 -185 minecraft:dirt
fill 9 68 -186 26 68 -186 minecraft:dirt
setblock 9 68 -187 minecraft:grass_block[snowy=false]
fill 10 68 -187 26 68 -187 minecraft:dirt
setblock 8 68 -188 minecraft:short_grass
setblock 9 68 -188 minecraft:grass_block[snowy=false]
fill 10 68 -188 26 68 -188 minecraft:dirt
fill 8 68 -189 9 68 -189 minecraft:grass_block[snowy=false]
fill 10 68 -189 26 68 -189 minecraft:dirt
setblock 8 68 -190 minecraft:grass_block[snowy=false]
fill 9 68 -190 26 68 -190 minecraft:dirt
setblock 23 67 -127 herbsandharvest:avocado_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 33 67 -127 minecraft:birch_log[axis=y]
setblock 38 67 -127 minecraft:birch_log[axis=y]
setblock 56 67 -127 minecraft:birch_log[axis=y]
fill 57 67 -127 58 67 -127 regions_unexplored:grass_sprouts
setblock 19 67 -128 minecraft:birch_log[axis=y]
setblock 36 67 -128 minecraft:air
fill 56 67 -128 57 67 -128 regions_unexplored:grass_sprouts
setblock 59 67 -128 minecraft:short_grass
setblock 28 67 -129 minecraft:birch_log[axis=y]
setblock 55 67 -129 regions_unexplored:grass_sprouts
setblock 64 67 -129 minecraft:birch_log[axis=y]
setblock 55 67 -130 regions_unexplored:grass_sprouts
setblock 56 67 -130 minecraft:birch_log[axis=y]
setblock 58 67 -130 minecraft:short_grass
setblock 60 67 -130 minecraft:short_grass
setblock 63 67 -130 regions_unexplored:grass_sprouts
setblock 56 67 -131 minecraft:short_grass
setblock 58 67 -131 minecraft:short_grass
setblock 59 67 -131 regions_unexplored:grass_sprouts
fill 61 67 -132 65 67 -132 minecraft:grass_block[snowy=false]
setblock 16 67 -133 minecraft:birch_log[axis=y]
setblock 19 67 -133 minecraft:birch_log[axis=y]
setblock 36 67 -133 minecraft:birch_log[axis=y]
setblock 59 67 -133 regions_unexplored:grass_sprouts
fill 62 67 -133 67 67 -133 minecraft:grass_block[snowy=false]
fill 63 67 -134 69 67 -134 minecraft:grass_block[snowy=false]
setblock 14 67 -135 minecraft:birch_log[axis=y]
setblock 47 67 -135 minecraft:birch_log[axis=y]
fill 63 67 -135 71 67 -135 minecraft:grass_block[snowy=false]
setblock 38 67 -136 minecraft:birch_log[axis=y]
setblock 63 67 -136 minecraft:grass_block[snowy=false]
setblock 64 67 -136 minecraft:dirt
fill 65 67 -136 71 67 -136 minecraft:grass_block[snowy=false]
setblock 29 67 -137 minecraft:birch_log[axis=y]
setblock 61 67 -137 minecraft:short_grass
fill 63 67 -137 69 67 -137 minecraft:grass_block[snowy=false]
setblock 70 67 -137 minecraft:dirt
setblock 71 67 -137 minecraft:grass_block[snowy=false]
fill 63 67 -138 71 67 -138 minecraft:grass_block[snowy=false]
setblock 34 67 -139 minecraft:birch_log[axis=y]
setblock 53 67 -139 minecraft:birch_log[axis=y]
fill 63 67 -139 71 67 -139 minecraft:grass_block[snowy=false]
setblock 13 67 -140 minecraft:birch_log[axis=y]
setblock 27 67 -140 minecraft:birch_log[axis=y]
setblock 63 67 -140 minecraft:grass_block[snowy=false]
setblock 64 67 -140 minecraft:dirt
fill 65 67 -140 67 67 -140 minecraft:grass_block[snowy=false]
setblock 68 67 -140 minecraft:dirt
fill 69 67 -140 71 67 -140 minecraft:grass_block[snowy=false]
setblock 35 67 -141 minecraft:birch_log[axis=y]
fill 63 67 -141 71 67 -141 minecraft:grass_block[snowy=false]
setblock 29 67 -142 minecraft:birch_log[axis=y]
setblock 32 67 -142 minecraft:birch_log[axis=y]
setblock 61 67 -142 regions_unexplored:grass_sprouts
fill 63 67 -142 71 67 -142 minecraft:grass_block[snowy=false]
setblock 11 67 -143 minecraft:birch_log[axis=y]
setblock 20 67 -143 minecraft:birch_log[axis=y]
setblock 50 67 -143 minecraft:birch_log[axis=y]
fill 63 67 -143 71 67 -143 minecraft:grass_block[snowy=false]
setblock 15 67 -144 minecraft:birch_log[axis=y]
setblock 18 67 -144 minecraft:birch_log[axis=y]
setblock 48 67 -144 minecraft:birch_log[axis=y]
setblock 57 67 -144 minecraft:birch_log[axis=y]
setblock 61 67 -144 minecraft:short_grass
fill 62 67 -144 66 67 -144 minecraft:grass_block[snowy=false]
setblock 67 67 -144 minecraft:dirt
fill 68 67 -144 71 67 -144 minecraft:grass_block[snowy=false]
setblock 10 67 -145 minecraft:birch_log[axis=y]
setblock 38 67 -145 minecraft:birch_log[axis=y]
setblock 51 67 -145 minecraft:birch_log[axis=y]
setblock 57 67 -145 regions_unexplored:grass_sprouts
fill 62 67 -145 71 67 -145 minecraft:grass_block[snowy=false]
setblock 53 67 -146 minecraft:birch_log[axis=y]
setblock 56 67 -146 regions_unexplored:grass_sprouts
setblock 58 67 -146 minecraft:birch_log[axis=y]
fill 62 67 -146 71 67 -146 minecraft:grass_block[snowy=false]
setblock 12 67 -147 minecraft:birch_log[axis=y]
setblock 55 67 -147 minecraft:birch_log[axis=y]
setblock 56 67 -147 regions_unexplored:grass_sprouts
setblock 61 67 -147 minecraft:short_grass
setblock 62 67 -147 minecraft:grass_block[snowy=false]
setblock 63 67 -147 minecraft:dirt
fill 64 67 -147 70 67 -147 minecraft:grass_block[snowy=false]
setblock 71 67 -147 minecraft:dirt
setblock 15 67 -148 minecraft:birch_log[axis=y]
fill 61 67 -148 64 67 -148 minecraft:grass_block[snowy=false]
setblock 65 67 -148 minecraft:dirt
fill 66 67 -148 70 67 -148 minecraft:grass_block[snowy=false]
setblock 71 67 -148 minecraft:dirt
fill 62 67 -149 71 67 -149 minecraft:grass_block[snowy=false]
setblock 40 67 -150 minecraft:birch_log[axis=y]
fill 62 67 -150 71 67 -150 minecraft:grass_block[snowy=false]
setblock 24 67 -151 minecraft:birch_log[axis=y]
setblock 32 67 -151 minecraft:birch_log[axis=y]
setblock 44 67 -151 minecraft:birch_log[axis=y]
setblock 49 67 -151 minecraft:birch_log[axis=y]
fill 63 67 -151 67 67 -151 minecraft:grass_block[snowy=false]
fill 69 67 -151 71 67 -151 minecraft:grass_block[snowy=false]
setblock 22 67 -152 minecraft:birch_log[axis=y]
fill 63 67 -152 65 67 -152 minecraft:grass_block[snowy=false]
setblock 64 67 -153 minecraft:grass_block[snowy=false]
setblock 18 67 -154 minecraft:air
setblock 21 67 -154 minecraft:birch_log[axis=y]
setblock 43 67 -154 minecraft:birch_log[axis=y]
setblock 52 67 -154 minecraft:birch_log[axis=y]
setblock 65 67 -154 regions_unexplored:grass_sprouts
setblock 67 67 -154 minecraft:birch_log[axis=y]
setblock 69 67 -154 minecraft:short_grass
setblock 71 67 -154 minecraft:grass_block[snowy=false]
setblock 9 67 -155 minecraft:birch_log[axis=y]
setblock 17 67 -155 minecraft:birch_log[axis=y]
setblock 39 67 -155 minecraft:birch_log[axis=y]
setblock 62 67 -155 regions_unexplored:grass_sprouts
setblock 65 67 -155 regions_unexplored:grass_sprouts
setblock 70 67 -155 minecraft:short_grass
setblock 71 67 -155 minecraft:grass_block[snowy=false]
setblock 68 67 -156 regions_unexplored:grass_sprouts
setblock 70 67 -156 minecraft:short_grass
setblock 71 67 -156 minecraft:grass_block[snowy=false]
setblock 46 67 -157 minecraft:birch_log[axis=y]
setblock 67 67 -157 minecraft:short_grass
setblock 71 67 -157 minecraft:grass_block[snowy=false]
setblock 14 67 -158 minecraft:birch_log[axis=y]
setblock 53 67 -158 minecraft:birch_log[axis=y]
setblock 68 67 -158 minecraft:birch_log[axis=y]
setblock 50 67 -159 minecraft:birch_log[axis=y]
setblock 19 67 -160 minecraft:birch_log[axis=y]
setblock 9 67 -162 minecraft:birch_log[axis=y]
setblock 24 67 -162 regions_unexplored:grass_sprouts
fill 25 67 -162 26 67 -162 silentgear:wild_fluffy_plant
setblock 18 67 -164 minecraft:air
setblock 12 67 -165 regions_unexplored:grass_sprouts
setblock 13 67 -165 minecraft:short_grass
fill 19 67 -165 26 67 -165 minecraft:grass_block[snowy=false]
setblock 11 67 -166 minecraft:short_grass
fill 12 67 -166 25 67 -166 minecraft:grass_block[snowy=false]
setblock 26 67 -166 minecraft:dirt
fill 9 67 -167 14 67 -167 minecraft:grass_block[snowy=false]
fill 15 67 -167 26 67 -167 minecraft:dirt
fill 8 67 -168 11 67 -168 minecraft:grass_block[snowy=false]
fill 12 67 -168 26 67 -168 minecraft:dirt
fill 8 67 -169 9 67 -169 minecraft:grass_block[snowy=false]
fill 10 67 -169 26 67 -169 minecraft:dirt
fill 8 67 -170 26 67 -170 minecraft:dirt
fill 8 67 -171 26 67 -171 minecraft:dirt
fill 8 67 -172 11 67 -172 minecraft:dirt
setblock 12 67 -172 minecraft:stone
fill 13 67 -172 26 67 -172 minecraft:dirt
fill 8 67 -173 11 67 -173 minecraft:dirt
setblock 12 67 -173 minecraft:stone
fill 13 67 -173 26 67 -173 minecraft:dirt
fill 8 67 -174 11 67 -174 minecraft:dirt
fill 12 67 -174 13 67 -174 minecraft:stone
fill 14 67 -174 26 67 -174 minecraft:dirt
fill 8 67 -175 11 67 -175 minecraft:dirt
fill 12 67 -175 13 67 -175 minecraft:stone
fill 14 67 -175 17 67 -175 minecraft:dirt
fill 22 67 -175 26 67 -175 minecraft:dirt
fill 8 67 -176 11 67 -176 minecraft:dirt
setblock 12 67 -176 minecraft:stone
fill 13 67 -176 16 67 -176 minecraft:dirt
setblock 21 67 -176 minecraft:grass_block[snowy=false]
fill 22 67 -176 26 67 -176 minecraft:dirt
fill 8 67 -177 11 67 -177 minecraft:dirt
fill 12 67 -177 13 67 -177 minecraft:stone
fill 14 67 -177 15 67 -177 minecraft:dirt
setblock 20 67 -177 minecraft:grass_block[snowy=false]
fill 21 67 -177 26 67 -177 minecraft:dirt
fill 8 67 -178 11 67 -178 minecraft:dirt
fill 12 67 -178 13 67 -178 minecraft:stone
fill 14 67 -178 15 67 -178 minecraft:dirt
fill 18 67 -178 26 67 -178 minecraft:dirt
fill 8 67 -179 11 67 -179 minecraft:dirt
fill 12 67 -179 13 67 -179 minecraft:stone
setblock 14 67 -179 minecraft:dirt
fill 16 67 -179 26 67 -179 minecraft:dirt
fill 8 67 -180 12 67 -180 minecraft:dirt
setblock 13 67 -180 minecraft:stone
fill 14 67 -180 26 67 -180 minecraft:dirt
fill 8 67 -181 26 67 -181 minecraft:dirt
fill 8 67 -182 26 67 -182 minecraft:dirt
fill 8 67 -183 26 67 -183 minecraft:dirt
setblock 8 67 -184 minecraft:grass_block[snowy=false]
fill 9 67 -184 26 67 -184 minecraft:dirt
setblock 8 67 -185 minecraft:grass_block[snowy=false]
fill 9 67 -185 26 67 -185 minecraft:dirt
setblock 8 67 -186 minecraft:grass_block[snowy=false]
fill 9 67 -186 26 67 -186 minecraft:dirt
setblock 8 67 -187 minecraft:grass_block[snowy=false]
fill 9 67 -187 26 67 -187 minecraft:dirt
setblock 8 67 -188 minecraft:grass_block[snowy=false]
fill 9 67 -188 26 67 -188 minecraft:dirt
fill 8 67 -189 26 67 -189 minecraft:dirt
fill 8 67 -190 26 67 -190 minecraft:dirt
setblock 33 66 -127 productivebees:birch_wood_nest[axis=y,facing=north]
setblock 38 66 -127 minecraft:birch_log[axis=y]
setblock 40 66 -127 regions_unexplored:grass_sprouts
setblock 41 66 -127 minecraft:short_grass
fill 52 66 -127 55 66 -127 minecraft:grass_block[snowy=false]
setblock 56 66 -127 minecraft:dirt
fill 57 66 -127 70 66 -127 minecraft:grass_block[snowy=false]
setblock 19 66 -128 minecraft:birch_log[axis=y]
setblock 36 66 -128 minecraft:air
fill 53 66 -128 71 66 -128 minecraft:grass_block[snowy=false]
setblock 28 66 -129 minecraft:birch_log[axis=y]
fill 54 66 -129 63 66 -129 minecraft:grass_block[snowy=false]
setblock 64 66 -129 minecraft:dirt
fill 65 66 -129 71 66 -129 minecraft:grass_block[snowy=false]
setblock 55 66 -130 minecraft:grass_block[snowy=false]
setblock 56 66 -130 minecraft:dirt
fill 57 66 -130 71 66 -130 minecraft:grass_block[snowy=false]
fill 55 66 -131 71 66 -131 minecraft:grass_block[snowy=false]
fill 56 66 -132 60 66 -132 minecraft:grass_block[snowy=false]
fill 61 66 -132 65 66 -132 minecraft:dirt
fill 66 66 -132 71 66 -132 minecraft:grass_block[snowy=false]
setblock 16 66 -133 minecraft:birch_log[axis=y]
setblock 19 66 -133 minecraft:birch_log[axis=y]
setblock 36 66 -133 minecraft:birch_log[axis=y]
fill 58 66 -133 61 66 -133 minecraft:grass_block[snowy=false]
fill 62 66 -133 67 66 -133 minecraft:dirt
fill 68 66 -133 69 66 -133 minecraft:grass_block[snowy=false]
fill 58 66 -134 62 66 -134 minecraft:grass_block[snowy=false]
fill 63 66 -134 66 66 -134 minecraft:dirt
setblock 14 66 -135 minecraft:birch_log[axis=y]
setblock 47 66 -135 minecraft:birch_log[axis=y]
fill 59 66 -135 62 66 -135 minecraft:grass_block[snowy=false]
fill 63 66 -135 66 66 -135 minecraft:dirt
setblock 38 66 -136 minecraft:birch_log[axis=y]
fill 59 66 -136 62 66 -136 minecraft:grass_block[snowy=false]
fill 63 66 -136 70 66 -136 minecraft:dirt
setblock 29 66 -137 minecraft:birch_log[axis=y]
fill 60 66 -137 62 66 -137 minecraft:grass_block[snowy=false]
fill 63 66 -137 71 66 -137 minecraft:dirt
setblock 51 66 -138 minecraft:grass_block[snowy=false]
fill 55 66 -138 57 66 -138 minecraft:dripstone_block
fill 60 66 -138 62 66 -138 minecraft:grass_block[snowy=false]
fill 63 66 -138 71 66 -138 minecraft:dirt
setblock 34 66 -139 minecraft:birch_log[axis=y]
fill 51 66 -139 52 66 -139 minecraft:grass_block[snowy=false]
setblock 53 66 -139 minecraft:dirt
setblock 55 66 -139 minecraft:dripstone_block
setblock 56 66 -139 xycraft_world:geyser
setblock 57 66 -139 minecraft:dripstone_block
fill 60 66 -139 62 66 -139 minecraft:grass_block[snowy=false]
fill 63 66 -139 71 66 -139 minecraft:dirt
setblock 13 66 -140 minecraft:birch_log[axis=y]
setblock 27 66 -140 minecraft:birch_log[axis=y]
fill 51 66 -140 54 66 -140 minecraft:grass_block[snowy=false]
fill 55 66 -140 57 66 -140 minecraft:dripstone_block
fill 60 66 -140 62 66 -140 minecraft:grass_block[snowy=false]
fill 63 66 -140 71 66 -140 minecraft:dirt
setblock 35 66 -141 minecraft:birch_log[axis=y]
fill 50 66 -141 55 66 -141 minecraft:grass_block[snowy=false]
fill 60 66 -141 62 66 -141 minecraft:grass_block[snowy=false]
fill 63 66 -141 71 66 -141 minecraft:dirt
setblock 29 66 -142 minecraft:birch_log[axis=y]
setblock 32 66 -142 minecraft:birch_log[axis=y]
fill 50 66 -142 56 66 -142 minecraft:grass_block[snowy=false]
fill 60 66 -142 62 66 -142 minecraft:grass_block[snowy=false]
fill 63 66 -142 71 66 -142 minecraft:dirt
setblock 11 66 -143 minecraft:birch_log[axis=y]
setblock 20 66 -143 minecraft:birch_log[axis=y]
setblock 49 66 -143 minecraft:grass_block[snowy=false]
setblock 50 66 -143 minecraft:dirt
fill 51 66 -143 62 66 -143 minecraft:grass_block[snowy=false]
fill 63 66 -143 71 66 -143 minecraft:dirt
setblock 15 66 -144 minecraft:birch_log[axis=y]
setblock 18 66 -144 minecraft:birch_log[axis=y]
setblock 48 66 -144 minecraft:dirt
fill 49 66 -144 56 66 -144 minecraft:grass_block[snowy=false]
setblock 57 66 -144 minecraft:dirt
fill 58 66 -144 61 66 -144 minecraft:grass_block[snowy=false]
fill 62 66 -144 71 66 -144 minecraft:dirt
setblock 10 66 -145 minecraft:birch_log[axis=y]
setblock 38 66 -145 minecraft:birch_log[axis=y]
setblock 50 66 -145 minecraft:grass_block[snowy=false]
setblock 51 66 -145 minecraft:dirt
fill 52 66 -145 61 66 -145 minecraft:grass_block[snowy=false]
fill 62 66 -145 71 66 -145 minecraft:dirt
fill 51 66 -146 52 66 -146 minecraft:grass_block[snowy=false]
setblock 53 66 -146 minecraft:dirt
fill 54 66 -146 57 66 -146 minecraft:grass_block[snowy=false]
setblock 58 66 -146 minecraft:dirt
fill 59 66 -146 61 66 -146 minecraft:grass_block[snowy=false]
fill 62 66 -146 71 66 -146 minecraft:dirt
setblock 12 66 -147 minecraft:birch_log[axis=y]
fill 52 66 -147 54 66 -147 minecraft:grass_block[snowy=false]
setblock 55 66 -147 minecraft:dirt
fill 56 66 -147 61 66 -147 minecraft:grass_block[snowy=false]
fill 62 66 -147 71 66 -147 minecraft:dirt
setblock 15 66 -148 minecraft:birch_log[axis=y]
fill 58 66 -148 60 66 -148 minecraft:grass_block[snowy=false]
fill 61 66 -148 71 66 -148 minecraft:dirt
setblock 19 66 -149 regions_unexplored:birch_shrub[half=upper]
fill 59 66 -149 61 66 -149 minecraft:grass_block[snowy=false]
fill 62 66 -149 71 66 -149 minecraft:dirt
setblock 26 66 -150 regions_unexplored:grass_sprouts
setblock 29 66 -150 minecraft:short_grass
setblock 40 66 -150 minecraft:birch_log[axis=y]
setblock 52 66 -150 regions_unexplored:grass_sprouts
setblock 55 66 -150 minecraft:short_grass
fill 59 66 -150 61 66 -150 minecraft:grass_block[snowy=false]
fill 62 66 -150 71 66 -150 minecraft:dirt
setblock 24 66 -151 minecraft:birch_log[axis=y]
setblock 27 66 -151 regions_unexplored:grass_sprouts
setblock 32 66 -151 minecraft:birch_log[axis=y]
setblock 44 66 -151 minecraft:birch_log[axis=y]
setblock 49 66 -151 minecraft:birch_log[axis=y]
setblock 59 66 -151 minecraft:short_grass
fill 60 66 -151 62 66 -151 minecraft:grass_block[snowy=false]
fill 63 66 -151 67 66 -151 minecraft:dirt
setblock 68 66 -151 minecraft:grass_block[snowy=false]
fill 69 66 -151 71 66 -151 minecraft:dirt
setblock 22 66 -152 minecraft:birch_log[axis=y]
setblock 28 66 -152 regions_unexplored:grass_sprouts
setblock 32 66 -152 minecraft:short_grass
setblock 57 66 -152 minecraft:short_grass
fill 60 66 -152 62 66 -152 minecraft:grass_block[snowy=false]
fill 63 66 -152 65 66 -152 minecraft:dirt
fill 66 66 -152 71 66 -152 minecraft:grass_block[snowy=false]
setblock 24 66 -153 minecraft:short_grass
setblock 26 66 -153 regions_unexplored:grass_sprouts
fill 60 66 -153 63 66 -153 minecraft:grass_block[snowy=false]
setblock 64 66 -153 minecraft:dirt
fill 65 66 -153 71 66 -153 minecraft:grass_block[snowy=false]
setblock 18 66 -154 minecraft:air
setblock 21 66 -154 minecraft:birch_log[axis=y]
setblock 43 66 -154 minecraft:birch_log[axis=y]
setblock 52 66 -154 minecraft:birch_log[axis=y]
fill 61 66 -154 66 66 -154 minecraft:grass_block[snowy=false]
setblock 67 66 -154 minecraft:dirt
fill 68 66 -154 70 66 -154 minecraft:grass_block[snowy=false]
setblock 71 66 -154 minecraft:dirt
setblock 9 66 -155 minecraft:birch_log[axis=y]
setblock 17 66 -155 minecraft:birch_log[axis=y]
setblock 39 66 -155 minecraft:birch_log[axis=y]
setblock 53 66 -155 minecraft:short_grass
setblock 55 66 -155 minecraft:short_grass
setblock 59 66 -155 regions_unexplored:grass_sprouts
fill 61 66 -155 70 66 -155 minecraft:grass_block[snowy=false]
setblock 71 66 -155 minecraft:dirt
setblock 30 66 -156 minecraft:short_grass
setblock 36 66 -156 regions_unexplored:grass_sprouts
setblock 59 66 -156 minecraft:short_grass
fill 61 66 -156 70 66 -156 minecraft:grass_block[snowy=false]
setblock 71 66 -156 minecraft:dirt
setblock 12 66 -157 regions_unexplored:birch_shrub[half=upper]
setblock 29 66 -157 minecraft:short_grass
fill 34 66 -157 35 66 -157 regions_unexplored:grass_sprouts
setblock 38 66 -157 minecraft:short_grass
setblock 46 66 -157 minecraft:birch_log[axis=y]
fill 61 66 -157 70 66 -157 minecraft:grass_block[snowy=false]
setblock 71 66 -157 minecraft:dirt
setblock 14 66 -158 minecraft:birch_log[axis=y]
setblock 27 66 -158 regions_unexplored:grass_sprouts
setblock 35 66 -158 regions_unexplored:grass_sprouts
setblock 53 66 -158 minecraft:birch_log[axis=y]
fill 61 66 -158 67 66 -158 minecraft:grass_block[snowy=false]
setblock 68 66 -158 minecraft:dirt
fill 69 66 -158 71 66 -158 minecraft:grass_block[snowy=false]
setblock 29 66 -159 minecraft:short_grass
setblock 33 66 -159 regions_unexplored:grass_sprouts
setblock 37 66 -159 minecraft:short_grass
fill 48 66 -159 49 66 -159 regions_unexplored:grass_sprouts
setblock 50 66 -159 minecraft:birch_log[axis=y]
setblock 52 66 -159 minecraft:short_grass
fill 61 66 -159 71 66 -159 minecraft:grass_block[snowy=false]
setblock 19 66 -160 minecraft:birch_log[axis=y]
fill 25 66 -160 26 66 -160 silentgear:wild_fluffy_plant
setblock 9 66 -162 minecraft:birch_log[axis=y]
fill 23 66 -162 26 66 -162 minecraft:grass_block[snowy=false]
setblock 10 66 -163 minecraft:short_grass
setblock 12 66 -163 regions_unexplored:grass_sprouts
setblock 13 66 -163 minecraft:short_grass
fill 19 66 -163 26 66 -163 minecraft:grass_block[snowy=false]
setblock 14 66 -164 regions_unexplored:grass_sprouts
fill 17 66 -164 26 66 -164 minecraft:grass_block[snowy=false]
fill 9 66 -165 18 66 -165 minecraft:grass_block[snowy=false]
fill 19 66 -165 26 66 -165 minecraft:dirt
fill 8 66 -166 11 66 -166 minecraft:grass_block[snowy=false]
fill 12 66 -166 26 66 -166 minecraft:dirt
setblock 8 66 -167 minecraft:grass_block[snowy=false]
fill 9 66 -167 26 66 -167 minecraft:dirt
fill 8 66 -168 15 66 -168 minecraft:dirt
fill 16 66 -168 22 66 -168 minecraft:stone
setblock 23 66 -168 minecraft:dirt
fill 24 66 -168 25 66 -168 minecraft:stone
setblock 26 66 -168 minecraft:dirt
fill 8 66 -169 14 66 -169 minecraft:dirt
fill 15 66 -169 22 66 -169 minecraft:stone
fill 23 66 -169 26 66 -169 minecraft:dirt
fill 8 66 -170 13 66 -170 minecraft:dirt
fill 14 66 -170 21 66 -170 minecraft:stone
setblock 22 66 -170 minecraft:dirt
fill 23 66 -170 25 66 -170 minecraft:stone
setblock 26 66 -170 minecraft:dirt
fill 8 66 -171 10 66 -171 minecraft:dirt
setblock 11 66 -171 minecraft:copper_ore
fill 12 66 -171 19 66 -171 minecraft:stone
fill 20 66 -171 26 66 -171 minecraft:dirt
setblock 8 66 -172 minecraft:dirt
fill 9 66 -172 10 66 -172 minecraft:stone
setblock 11 66 -172 minecraft:copper_ore
fill 12 66 -172 18 66 -172 minecraft:stone
fill 19 66 -172 21 66 -172 minecraft:dirt
setblock 22 66 -172 minecraft:stone
fill 23 66 -172 24 66 -172 minecraft:dirt
setblock 25 66 -172 minecraft:stone
setblock 26 66 -172 minecraft:dirt
setblock 8 66 -173 minecraft:dirt
fill 9 66 -173 17 66 -173 minecraft:stone
fill 18 66 -173 26 66 -173 minecraft:dirt
setblock 8 66 -174 minecraft:dirt
fill 9 66 -174 16 66 -174 minecraft:stone
fill 17 66 -174 22 66 -174 minecraft:dirt
setblock 23 66 -174 minecraft:stone
fill 24 66 -174 26 66 -174 minecraft:dirt
fill 8 66 -175 9 66 -175 minecraft:dirt
fill 10 66 -175 16 66 -175 minecraft:stone
setblock 17 66 -175 minecraft:dirt
setblock 21 66 -175 minecraft:grass_block[snowy=false]
fill 22 66 -175 23 66 -175 minecraft:dirt
fill 24 66 -175 25 66 -175 minecraft:stone
setblock 26 66 -175 minecraft:dirt
fill 8 66 -176 9 66 -176 minecraft:dirt
fill 10 66 -176 14 66 -176 minecraft:stone
setblock 15 66 -176 minecraft:dirt
setblock 20 66 -176 minecraft:grass_block[snowy=false]
fill 21 66 -176 26 66 -176 minecraft:dirt
fill 8 66 -177 9 66 -177 minecraft:dirt
fill 10 66 -177 13 66 -177 minecraft:stone
fill 14 66 -177 15 66 -177 minecraft:dirt
fill 20 66 -177 24 66 -177 minecraft:dirt
setblock 25 66 -177 minecraft:stone
setblock 26 66 -177 minecraft:dirt
fill 8 66 -178 9 66 -178 minecraft:dirt
fill 10 66 -178 14 66 -178 minecraft:stone
fill 19 66 -178 26 66 -178 minecraft:dirt
fill 8 66 -179 11 66 -179 minecraft:dirt
fill 12 66 -179 14 66 -179 minecraft:stone
fill 16 66 -179 26 66 -179 minecraft:dirt
fill 8 66 -180 10 66 -180 minecraft:dirt
fill 11 66 -180 14 66 -180 minecraft:stone
fill 15 66 -180 24 66 -180 minecraft:dirt
fill 25 66 -180 26 66 -180 minecraft:stone
fill 8 66 -181 11 66 -181 minecraft:dirt
fill 12 66 -181 15 66 -181 minecraft:stone
fill 16 66 -181 26 66 -181 minecraft:dirt
fill 8 66 -182 11 66 -182 minecraft:dirt
fill 12 66 -182 15 66 -182 minecraft:stone
fill 16 66 -182 26 66 -182 minecraft:dirt
fill 8 66 -183 11 66 -183 minecraft:dirt
fill 12 66 -183 16 66 -183 minecraft:stone
fill 17 66 -183 25 66 -183 minecraft:dirt
setblock 26 66 -183 minecraft:stone
fill 8 66 -184 11 66 -184 minecraft:dirt
fill 12 66 -184 21 66 -184 minecraft:stone
fill 22 66 -184 26 66 -184 minecraft:dirt
fill 8 66 -185 11 66 -185 minecraft:dirt
fill 12 66 -185 24 66 -185 minecraft:stone
fill 25 66 -185 26 66 -185 minecraft:dirt
fill 8 66 -186 11 66 -186 minecraft:dirt
fill 12 66 -186 25 66 -186 minecraft:stone
setblock 26 66 -186 minecraft:dirt
fill 8 66 -187 11 66 -187 minecraft:dirt
fill 12 66 -187 24 66 -187 minecraft:stone
fill 25 66 -187 26 66 -187 minecraft:dirt
fill 8 66 -188 11 66 -188 minecraft:dirt
fill 12 66 -188 18 66 -188 minecraft:stone
setblock 19 66 -188 minecraft:copper_ore
fill 20 66 -188 26 66 -188 minecraft:stone
fill 8 66 -189 10 66 -189 minecraft:dirt
fill 11 66 -189 26 66 -189 minecraft:stone
fill 8 66 -190 10 66 -190 minecraft:dirt
fill 11 66 -190 26 66 -190 minecraft:stone
fill 19 65 -127 32 65 -127 minecraft:air
setblock 33 65 -127 minecraft:birch_log[axis=y]
fill 34 65 -127 37 65 -127 minecraft:air
setblock 38 65 -127 minecraft:birch_log[axis=y]
setblock 39 65 -127 minecraft:air
fill 44 65 -127 52 65 -127 minecraft:air
fill 53 65 -127 70 65 -127 minecraft:dirt
setblock 18 65 -128 minecraft:air
setblock 19 65 -128 minecraft:birch_log[axis=y]
fill 20 65 -128 38 65 -128 minecraft:air
setblock 39 65 -128 regions_unexplored:grass_sprouts
fill 43 65 -128 53 65 -128 minecraft:air
fill 54 65 -128 71 65 -128 minecraft:dirt
fill 17 65 -129 27 65 -129 minecraft:air
setblock 28 65 -129 minecraft:birch_log[axis=y]
fill 29 65 -129 53 65 -129 minecraft:air
fill 54 65 -129 71 65 -129 minecraft:dirt
fill 16 65 -130 37 65 -130 minecraft:air
setblock 38 65 -130 regions_unexplored:grass_sprouts
fill 39 65 -130 54 65 -130 minecraft:air
fill 55 65 -130 71 65 -130 minecraft:dirt
fill 15 65 -131 39 65 -131 minecraft:air
setblock 40 65 -131 minecraft:short_grass
fill 41 65 -131 55 65 -131 minecraft:air
fill 56 65 -131 71 65 -131 minecraft:dirt
fill 15 65 -132 56 65 -132 minecraft:air
fill 57 65 -132 71 65 -132 minecraft:dirt
fill 14 65 -133 15 65 -133 minecraft:air
setblock 16 65 -133 minecraft:birch_log[axis=y]
fill 17 65 -133 18 65 -133 minecraft:air
setblock 19 65 -133 minecraft:birch_log[axis=y]
fill 20 65 -133 35 65 -133 minecraft:air
setblock 36 65 -133 minecraft:birch_log[axis=y]
fill 37 65 -133 57 65 -133 minecraft:air
fill 58 65 -133 65 65 -133 minecraft:dirt
fill 66 65 -133 71 65 -133 minecraft:air
fill 13 65 -134 58 65 -134 minecraft:air
fill 59 65 -134 63 65 -134 minecraft:dirt
fill 64 65 -134 71 65 -134 minecraft:air
setblock 13 65 -135 minecraft:air
setblock 14 65 -135 minecraft:birch_log[axis=y]
fill 15 65 -135 46 65 -135 minecraft:air
setblock 47 65 -135 minecraft:birch_log[axis=y]
fill 48 65 -135 59 65 -135 minecraft:air
fill 60 65 -135 62 65 -135 minecraft:dirt
fill 63 65 -135 71 65 -135 minecraft:air
fill 12 65 -136 37 65 -136 minecraft:air
setblock 38 65 -136 minecraft:birch_log[axis=y]
fill 39 65 -136 59 65 -136 minecraft:air
fill 60 65 -136 62 65 -136 minecraft:dirt
fill 63 65 -136 71 65 -136 minecraft:air
fill 12 65 -137 22 65 -137 minecraft:air
setblock 23 65 -137 minecraft:short_grass
fill 24 65 -137 28 65 -137 minecraft:air
setblock 29 65 -137 minecraft:birch_log[axis=y]
fill 30 65 -137 48 65 -137 minecraft:air
fill 50 65 -137 59 65 -137 minecraft:air
fill 60 65 -137 71 65 -137 minecraft:dirt
fill 11 65 -138 44 65 -138 minecraft:air
setblock 45 65 -138 minecraft:short_grass
setblock 46 65 -138 minecraft:air
setblock 47 65 -138 regions_unexplored:grass_sprouts
setblock 48 65 -138 minecraft:air
fill 51 65 -138 59 65 -138 minecraft:air
fill 60 65 -138 71 65 -138 minecraft:dirt
fill 11 65 -139 33 65 -139 minecraft:air
setblock 34 65 -139 minecraft:birch_log[axis=y]
fill 35 65 -139 48 65 -139 minecraft:air
fill 51 65 -139 52 65 -139 minecraft:dirt
fill 53 65 -139 60 65 -139 minecraft:air
fill 61 65 -139 71 65 -139 minecraft:dirt
fill 11 65 -140 12 65 -140 minecraft:air
setblock 13 65 -140 minecraft:birch_log[axis=y]
fill 14 65 -140 22 65 -140 minecraft:air
fill 23 65 -140 24 65 -140 minecraft:short_grass
setblock 25 65 -140 regions_unexplored:birch_shrub[half=upper]
setblock 26 65 -140 minecraft:air
setblock 27 65 -140 minecraft:birch_log[axis=y]
fill 28 65 -140 48 65 -140 minecraft:air
fill 51 65 -140 53 65 -140 minecraft:dirt
fill 54 65 -140 60 65 -140 minecraft:air
fill 61 65 -140 71 65 -140 minecraft:dirt
fill 10 65 -141 34 65 -141 minecraft:air
setblock 35 65 -141 minecraft:birch_log[axis=y]
fill 36 65 -141 39 65 -141 minecraft:air
setblock 40 65 -141 minecraft:short_grass
fill 41 65 -141 47 65 -141 minecraft:air
fill 50 65 -141 54 65 -141 minecraft:dirt
fill 55 65 -141 60 65 -141 minecraft:air
fill 61 65 -141 71 65 -141 minecraft:dirt
fill 10 65 -142 21 65 -142 minecraft:air
setblock 22 65 -142 regions_unexplored:grass_sprouts
fill 23 65 -142 25 65 -142 minecraft:air
setblock 26 65 -142 regions_unexplored:grass_sprouts
fill 27 65 -142 28 65 -142 minecraft:air
setblock 29 65 -142 minecraft:birch_log[axis=y]
fill 30 65 -142 31 65 -142 minecraft:air
setblock 32 65 -142 minecraft:birch_log[axis=y]
fill 33 65 -142 39 65 -142 minecraft:air
setblock 40 65 -142 regions_unexplored:grass_sprouts
setblock 41 65 -142 minecraft:short_grass
fill 42 65 -142 45 65 -142 minecraft:air
setblock 46 65 -142 minecraft:short_grass
fill 50 65 -142 54 65 -142 minecraft:dirt
fill 55 65 -142 60 65 -142 minecraft:air
fill 61 65 -142 71 65 -142 minecraft:dirt
setblock 10 65 -143 minecraft:air
setblock 11 65 -143 minecraft:birch_log[axis=y]
fill 12 65 -143 19 65 -143 minecraft:air
setblock 20 65 -143 minecraft:birch_log[axis=y]
fill 21 65 -143 26 65 -143 minecraft:air
setblock 27 65 -143 minecraft:short_grass
setblock 28 65 -143 regions_unexplored:grass_sprouts
fill 29 65 -143 41 65 -143 minecraft:air
setblock 42 65 -143 regions_unexplored:grass_sprouts
fill 43 65 -143 45 65 -143 minecraft:air
setblock 46 65 -143 regions_unexplored:grass_sprouts
fill 49 65 -143 55 65 -143 minecraft:dirt
fill 56 65 -143 59 65 -143 minecraft:air
fill 60 65 -143 71 65 -143 minecraft:dirt
fill 9 65 -144 14 65 -144 minecraft:air
setblock 15 65 -144 minecraft:birch_log[axis=y]
fill 16 65 -144 17 65 -144 minecraft:air
setblock 18 65 -144 minecraft:birch_log[axis=y]
fill 19 65 -144 26 65 -144 minecraft:air
setblock 27 65 -144 regions_unexplored:grass_sprouts
fill 28 65 -144 29 65 -144 minecraft:air
setblock 30 65 -144 regions_unexplored:grass_sprouts
fill 31 65 -144 42 65 -144 minecraft:air
setblock 43 65 -144 regions_unexplored:grass_sprouts
fill 44 65 -144 45 65 -144 minecraft:air
fill 48 65 -144 71 65 -144 minecraft:dirt
setblock 9 65 -145 minecraft:air
setblock 10 65 -145 minecraft:birch_log[axis=y]
fill 11 65 -145 22 65 -145 minecraft:air
setblock 23 65 -145 minecraft:short_grass
setblock 24 65 -145 minecraft:air
fill 25 65 -145 26 65 -145 minecraft:short_grass
fill 27 65 -145 28 65 -145 minecraft:air
setblock 29 65 -145 regions_unexplored:grass_sprouts
fill 30 65 -145 31 65 -145 minecraft:air
setblock 32 65 -145 regions_unexplored:grass_sprouts
fill 33 65 -145 37 65 -145 minecraft:air
setblock 38 65 -145 minecraft:birch_log[axis=y]
fill 39 65 -145 46 65 -145 minecraft:air
fill 50 65 -145 71 65 -145 minecraft:dirt
fill 9 65 -146 20 65 -146 minecraft:air
fill 21 65 -146 22 65 -146 regions_unexplored:grass_sprouts
fill 23 65 -146 24 65 -146 minecraft:air
setblock 25 65 -146 regions_unexplored:grass_sprouts
fill 26 65 -146 30 65 -146 minecraft:air
setblock 31 65 -146 regions_unexplored:grass_sprouts
setblock 32 65 -146 minecraft:air
setblock 33 65 -146 minecraft:short_grass
fill 34 65 -146 39 65 -146 minecraft:air
setblock 40 65 -146 regions_unexplored:grass_sprouts
fill 41 65 -146 43 65 -146 minecraft:air
setblock 44 65 -146 regions_unexplored:grass_sprouts
fill 45 65 -146 46 65 -146 minecraft:air
fill 51 65 -146 71 65 -146 minecraft:dirt
fill 9 65 -147 11 65 -147 minecraft:air
setblock 12 65 -147 minecraft:birch_log[axis=y]
fill 13 65 -147 26 65 -147 minecraft:air
fill 27 65 -147 28 65 -147 regions_unexplored:grass_sprouts
fill 29 65 -147 44 65 -147 minecraft:air
setblock 45 65 -147 minecraft:short_grass
fill 46 65 -147 48 65 -147 minecraft:air
fill 52 65 -147 71 65 -147 minecraft:dirt
fill 9 65 -148 14 65 -148 minecraft:air
setblock 15 65 -148 minecraft:birch_log[axis=y]
fill 16 65 -148 24 65 -148 minecraft:air
fill 25 65 -148 26 65 -148 regions_unexplored:grass_sprouts
setblock 27 65 -148 minecraft:short_grass
fill 29 65 -148 46 65 -148 minecraft:air
setblock 47 65 -148 regions_unexplored:grass_sprouts
fill 48 65 -148 50 65 -148 minecraft:air
fill 58 65 -148 71 65 -148 minecraft:dirt
fill 9 65 -149 18 65 -149 minecraft:air
setblock 19 65 -149 regions_unexplored:birch_shrub[half=lower]
fill 20 65 -149 25 65 -149 minecraft:air
setblock 33 65 -149 regions_unexplored:grass_sprouts
fill 34 65 -149 50 65 -149 minecraft:air
fill 59 65 -149 71 65 -149 minecraft:dirt
fill 9 65 -150 23 65 -150 minecraft:air
setblock 24 65 -150 regions_unexplored:grass_sprouts
fill 36 65 -150 39 65 -150 minecraft:air
setblock 40 65 -150 minecraft:birch_log[axis=y]
fill 41 65 -150 42 65 -150 minecraft:air
setblock 43 65 -150 minecraft:short_grass
fill 44 65 -150 45 65 -150 minecraft:air
setblock 46 65 -150 regions_unexplored:grass_sprouts
fill 47 65 -150 49 65 -150 minecraft:air
setblock 50 65 -150 minecraft:short_grass
setblock 51 65 -150 minecraft:air
fill 59 65 -150 71 65 -150 minecraft:dirt
fill 9 65 -151 23 65 -151 minecraft:air
setblock 24 65 -151 minecraft:dirt
setblock 32 65 -151 minecraft:dirt
fill 37 65 -151 43 65 -151 minecraft:air
setblock 44 65 -151 minecraft:birch_log[axis=y]
fill 45 65 -151 48 65 -151 minecraft:air
setblock 49 65 -151 minecraft:birch_log[axis=y]
setblock 50 65 -151 minecraft:short_grass
setblock 51 65 -151 minecraft:air
setblock 52 65 -151 regions_unexplored:grass_sprouts
setblock 53 65 -151 minecraft:air
fill 60 65 -151 71 65 -151 minecraft:dirt
fill 8 65 -152 21 65 -152 minecraft:air
setblock 22 65 -152 minecraft:birch_log[axis=y]
fill 37 65 -152 38 65 -152 minecraft:air
fill 39 65 -152 40 65 -152 regions_unexplored:grass_sprouts
setblock 41 65 -152 minecraft:air
setblock 42 65 -152 regions_unexplored:grass_sprouts
fill 43 65 -152 45 65 -152 minecraft:air
setblock 46 65 -152 minecraft:short_grass
fill 47 65 -152 48 65 -152 regions_unexplored:grass_sprouts
setblock 49 65 -152 minecraft:air
setblock 50 65 -152 minecraft:short_grass
fill 51 65 -152 52 65 -152 minecraft:air
setblock 53 65 -152 minecraft:short_grass
setblock 54 65 -152 regions_unexplored:grass_sprouts
fill 60 65 -152 71 65 -152 minecraft:dirt
fill 8 65 -153 21 65 -153 minecraft:air
setblock 38 65 -153 regions_unexplored:grass_sprouts
fill 39 65 -153 41 65 -153 minecraft:air
setblock 42 65 -153 minecraft:short_grass
setblock 43 65 -153 minecraft:air
fill 44 65 -153 45 65 -153 regions_unexplored:grass_sprouts
fill 46 65 -153 54 65 -153 minecraft:air
fill 60 65 -153 71 65 -153 minecraft:dirt
fill 8 65 -154 20 65 -154 minecraft:air
setblock 21 65 -154 minecraft:dirt
fill 38 65 -154 42 65 -154 minecraft:air
setblock 43 65 -154 minecraft:birch_log[axis=y]
fill 44 65 -154 51 65 -154 minecraft:air
setblock 52 65 -154 minecraft:birch_log[axis=y]
setblock 53 65 -154 minecraft:air
fill 61 65 -154 71 65 -154 minecraft:dirt
setblock 8 65 -155 minecraft:air
setblock 9 65 -155 minecraft:birch_log[axis=y]
fill 10 65 -155 16 65 -155 minecraft:air
setblock 17 65 -155 minecraft:birch_log[axis=y]
setblock 38 65 -155 minecraft:air
setblock 39 65 -155 minecraft:birch_log[axis=y]
fill 40 65 -155 42 65 -155 minecraft:air
setblock 43 65 -155 regions_unexplored:grass_sprouts
fill 44 65 -155 46 65 -155 minecraft:air
setblock 47 65 -155 minecraft:short_grass
setblock 48 65 -155 regions_unexplored:grass_sprouts
setblock 49 65 -155 minecraft:short_grass
fill 50 65 -155 51 65 -155 minecraft:air
setblock 52 65 -155 regions_unexplored:grass_sprouts
fill 61 65 -155 71 65 -155 minecraft:dirt
fill 8 65 -156 16 65 -156 minecraft:air
fill 39 65 -156 45 65 -156 minecraft:air
setblock 46 65 -156 regions_unexplored:grass_sprouts
setblock 47 65 -156 minecraft:short_grass
setblock 48 65 -156 minecraft:air
setblock 49 65 -156 minecraft:short_grass
setblock 50 65 -156 minecraft:air
setblock 51 65 -156 minecraft:short_grass
fill 61 65 -156 71 65 -156 minecraft:dirt
fill 8 65 -157 11 65 -157 minecraft:air
setblock 12 65 -157 regions_unexplored:birch_shrub[half=lower]
fill 13 65 -157 16 65 -157 minecraft:air
fill 39 65 -157 44 65 -157 minecraft:air
setblock 45 65 -157 regions_unexplored:grass_sprouts
setblock 46 65 -157 minecraft:birch_log[axis=y]
fill 47 65 -157 49 65 -157 minecraft:air
fill 61 65 -157 71 65 -157 minecraft:dirt
fill 8 65 -158 13 65 -158 minecraft:air
setblock 14 65 -158 minecraft:birch_log[axis=y]
fill 15 65 -158 17 65 -158 minecraft:air
fill 40 65 -158 44 65 -158 minecraft:air
fill 45 65 -158 47 65 -158 minecraft:short_grass
setblock 48 65 -158 minecraft:air
setblock 53 65 -158 minecraft:dirt
fill 61 65 -158 71 65 -158 minecraft:dirt
fill 8 65 -159 17 65 -159 minecraft:air
setblock 41 65 -159 minecraft:short_grass
setblock 42 65 -159 regions_unexplored:grass_sprouts
fill 43 65 -159 45 65 -159 minecraft:air
setblock 46 65 -159 minecraft:short_grass
setblock 47 65 -159 regions_unexplored:grass_sprouts
setblock 50 65 -159 minecraft:dirt
setblock 58 65 -159 minecraft:air
fill 61 65 -159 71 65 -159 minecraft:dirt
fill 8 65 -160 17 65 -160 minecraft:air
setblock 19 65 -160 minecraft:dirt
fill 27 65 -160 71 65 -160 minecraft:air
fill 8 65 -161 14 65 -161 minecraft:air
fill 27 65 -161 71 65 -161 minecraft:air
setblock 8 65 -162 minecraft:air
setblock 9 65 -162 minecraft:birch_log[axis=y]
setblock 10 65 -162 regions_unexplored:grass_sprouts
fill 11 65 -162 13 65 -162 minecraft:grass_block[snowy=false]
fill 23 65 -162 26 65 -162 minecraft:dirt
fill 27 65 -162 70 65 -162 minecraft:air
fill 8 65 -163 13 65 -163 minecraft:grass_block[snowy=false]
fill 19 65 -163 26 65 -163 minecraft:dirt
fill 27 65 -163 67 65 -163 minecraft:air
fill 8 65 -164 13 65 -164 minecraft:grass_block[snowy=false]
fill 17 65 -164 26 65 -164 minecraft:dirt
fill 27 65 -164 64 65 -164 minecraft:air
setblock 8 65 -165 minecraft:grass_block[snowy=false]
fill 9 65 -165 26 65 -165 minecraft:dirt
fill 27 65 -165 62 65 -165 minecraft:air
fill 8 65 -166 26 65 -166 minecraft:dirt
fill 27 65 -166 60 65 -166 minecraft:air
fill 8 65 -167 14 65 -167 minecraft:dirt
fill 15 65 -167 24 65 -167 minecraft:stone
fill 25 65 -167 26 65 -167 minecraft:dirt
fill 27 65 -167 58 65 -167 minecraft:air
fill 8 65 -168 11 65 -168 minecraft:dirt
fill 12 65 -168 25 65 -168 minecraft:stone
setblock 26 65 -168 minecraft:dirt
fill 27 65 -168 56 65 -168 minecraft:air
fill 8 65 -169 9 65 -169 minecraft:dirt
fill 10 65 -169 26 65 -169 minecraft:stone
fill 27 65 -169 55 65 -169 minecraft:air
fill 8 65 -170 25 65 -170 minecraft:stone
setblock 26 65 -170 minecraft:dirt
fill 27 65 -170 53 65 -170 minecraft:air
fill 8 65 -171 15 65 -171 minecraft:stone
fill 16 65 -171 17 65 -171 minecraft:gravel
fill 18 65 -171 26 65 -171 minecraft:stone
fill 27 65 -171 52 65 -171 minecraft:air
fill 8 65 -172 15 65 -172 minecraft:stone
fill 16 65 -172 17 65 -172 minecraft:gravel
fill 18 65 -172 26 65 -172 minecraft:stone
fill 27 65 -172 50 65 -172 minecraft:air
fill 8 65 -173 26 65 -173 minecraft:stone
fill 27 65 -173 49 65 -173 minecraft:air
fill 8 65 -174 25 65 -174 minecraft:stone
setblock 26 65 -174 minecraft:dirt
fill 27 65 -174 48 65 -174 minecraft:air
fill 8 65 -175 17 65 -175 minecraft:stone
fill 18 65 -175 19 65 -175 minecraft:air
fill 21 65 -175 22 65 -175 minecraft:dirt
fill 23 65 -175 26 65 -175 minecraft:stone
fill 27 65 -175 47 65 -175 minecraft:air
fill 8 65 -176 15 65 -176 minecraft:stone
fill 16 65 -176 19 65 -176 minecraft:air
fill 20 65 -176 21 65 -176 minecraft:dirt
fill 22 65 -176 26 65 -176 minecraft:stone
fill 27 65 -176 46 65 -176 minecraft:air
fill 8 65 -177 14 65 -177 minecraft:stone
fill 15 65 -177 18 65 -177 minecraft:air
fill 20 65 -177 21 65 -177 minecraft:dirt
fill 22 65 -177 26 65 -177 minecraft:stone
fill 27 65 -177 45 65 -177 minecraft:air
fill 8 65 -178 14 65 -178 minecraft:stone
fill 15 65 -178 18 65 -178 minecraft:air
fill 19 65 -178 26 65 -178 minecraft:stone
fill 27 65 -178 44 65 -178 minecraft:air
fill 8 65 -179 13 65 -179 minecraft:stone
fill 14 65 -179 15 65 -179 minecraft:air
fill 16 65 -179 26 65 -179 minecraft:stone
fill 27 65 -179 43 65 -179 minecraft:air
setblock 8 65 -180 minecraft:stone
setblock 9 65 -180 minecraft:dirt
fill 10 65 -180 26 65 -180 minecraft:stone
fill 27 65 -180 42 65 -180 minecraft:air
setblock 8 65 -181 minecraft:stone
setblock 9 65 -181 minecraft:dirt
fill 10 65 -181 17 65 -181 minecraft:stone
fill 18 65 -181 21 65 -181 minecraft:dirt
fill 22 65 -181 26 65 -181 minecraft:stone
fill 27 65 -181 41 65 -181 minecraft:air
setblock 8 65 -182 minecraft:dirt
fill 9 65 -182 17 65 -182 minecraft:stone
fill 18 65 -182 19 65 -182 minecraft:dirt
fill 20 65 -182 21 65 -182 alltheores:tin_ore
fill 22 65 -182 26 65 -182 minecraft:stone
fill 27 65 -182 40 65 -182 minecraft:air
fill 8 65 -183 9 65 -183 minecraft:dirt
fill 10 65 -183 19 65 -183 minecraft:stone
setblock 20 65 -183 alltheores:tin_ore
fill 21 65 -183 26 65 -183 minecraft:stone
fill 27 65 -183 39 65 -183 minecraft:air
fill 8 65 -184 9 65 -184 minecraft:dirt
fill 10 65 -184 26 65 -184 minecraft:stone
fill 27 65 -184 38 65 -184 minecraft:air
fill 8 65 -185 9 65 -185 minecraft:dirt
fill 10 65 -185 26 65 -185 minecraft:stone
fill 27 65 -185 38 65 -185 minecraft:air
fill 8 65 -186 9 65 -186 minecraft:dirt
fill 10 65 -186 26 65 -186 minecraft:stone
fill 27 65 -186 37 65 -186 minecraft:air
fill 8 65 -187 9 65 -187 minecraft:dirt
fill 10 65 -187 26 65 -187 minecraft:stone
fill 27 65 -187 36 65 -187 minecraft:air
fill 8 65 -188 9 65 -188 minecraft:dirt
fill 10 65 -188 23 65 -188 minecraft:stone
fill 24 65 -188 25 65 -188 minecraft:copper_ore
setblock 26 65 -188 minecraft:stone
fill 27 65 -188 36 65 -188 minecraft:air
fill 8 65 -189 9 65 -189 minecraft:dirt
fill 10 65 -189 26 65 -189 minecraft:stone
fill 27 65 -189 35 65 -189 minecraft:air
setblock 8 65 -190 minecraft:dirt
fill 9 65 -190 26 65 -190 minecraft:stone
fill 27 65 -190 34 65 -190 minecraft:air
fill 19 64 -127 32 64 -127 minecraft:air
setblock 34 64 -127 minecraft:air
fill 42 64 -127 52 64 -127 minecraft:air
setblock 18 64 -128 minecraft:air
fill 20 64 -128 35 64 -128 minecraft:air
fill 44 64 -128 53 64 -128 minecraft:air
fill 17 64 -129 27 64 -129 minecraft:air
fill 29 64 -129 35 64 -129 minecraft:air
fill 45 64 -129 54 64 -129 minecraft:air
fill 16 64 -130 36 64 -130 minecraft:air
fill 45 64 -130 54 64 -130 minecraft:air
fill 15 64 -131 36 64 -131 minecraft:air
fill 46 64 -131 55 64 -131 minecraft:air
fill 15 64 -132 36 64 -132 minecraft:air
fill 46 64 -132 57 64 -132 minecraft:air
fill 14 64 -133 15 64 -133 minecraft:air
fill 17 64 -133 18 64 -133 minecraft:air
fill 20 64 -133 35 64 -133 minecraft:air
fill 47 64 -133 58 64 -133 minecraft:air
fill 64 64 -133 71 64 -133 minecraft:air
fill 13 64 -134 36 64 -134 minecraft:air
fill 47 64 -134 58 64 -134 minecraft:air
fill 62 64 -134 71 64 -134 minecraft:air
setblock 13 64 -135 minecraft:air
fill 15 64 -135 19 64 -135 minecraft:air
fill 22 64 -135 37 64 -135 minecraft:air
fill 48 64 -135 59 64 -135 minecraft:air
fill 61 64 -135 71 64 -135 minecraft:air
fill 12 64 -136 17 64 -136 minecraft:air
fill 25 64 -136 30 64 -136 minecraft:air
setblock 31 64 -136 regions_unexplored:grass_sprouts
fill 32 64 -136 37 64 -136 minecraft:air
fill 49 64 -136 59 64 -136 minecraft:air
fill 61 64 -136 71 64 -136 minecraft:air
fill 12 64 -137 17 64 -137 minecraft:air
fill 25 64 -137 28 64 -137 minecraft:air
fill 30 64 -137 37 64 -137 minecraft:air
fill 50 64 -137 64 64 -137 minecraft:air
fill 11 64 -138 17 64 -138 minecraft:air
fill 25 64 -138 26 64 -138 minecraft:air
setblock 27 64 -138 minecraft:short_grass
fill 28 64 -138 29 64 -138 minecraft:air
setblock 30 64 -138 regions_unexplored:grass_sprouts
fill 31 64 -138 37 64 -138 minecraft:air
fill 51 64 -138 61 64 -138 minecraft:air
fill 11 64 -139 18 64 -139 minecraft:air
fill 25 64 -139 29 64 -139 minecraft:air
setblock 30 64 -139 regions_unexplored:grass_sprouts
fill 31 64 -139 33 64 -139 minecraft:air
fill 35 64 -139 36 64 -139 minecraft:air
fill 53 64 -139 61 64 -139 minecraft:air
fill 11 64 -140 12 64 -140 minecraft:air
fill 14 64 -140 15 64 -140 minecraft:air
fill 17 64 -140 22 64 -140 minecraft:air
setblock 26 64 -140 minecraft:air
setblock 28 64 -140 minecraft:air
fill 29 64 -140 30 64 -140 minecraft:short_grass
fill 31 64 -140 32 64 -140 minecraft:air
setblock 33 64 -140 regions_unexplored:grass_sprouts
fill 34 64 -140 36 64 -140 minecraft:air
fill 53 64 -140 61 64 -140 minecraft:air
fill 10 64 -141 15 64 -141 minecraft:air
setblock 20 64 -141 minecraft:air
fill 25 64 -141 27 64 -141 minecraft:air
setblock 28 64 -141 minecraft:short_grass
fill 29 64 -141 30 64 -141 minecraft:air
setblock 31 64 -141 regions_unexplored:grass_sprouts
setblock 32 64 -141 minecraft:short_grass
fill 33 64 -141 34 64 -141 minecraft:air
fill 54 64 -141 61 64 -141 minecraft:air
fill 10 64 -142 15 64 -142 minecraft:air
setblock 27 64 -142 minecraft:air
setblock 28 64 -142 minecraft:short_grass
fill 30 64 -142 31 64 -142 minecraft:air
fill 33 64 -142 34 64 -142 minecraft:air
fill 54 64 -142 61 64 -142 minecraft:air
setblock 10 64 -143 minecraft:air
fill 12 64 -143 15 64 -143 minecraft:air
fill 55 64 -143 60 64 -143 minecraft:air
fill 9 64 -144 14 64 -144 minecraft:air
fill 57 64 -144 59 64 -144 minecraft:air
setblock 9 64 -145 minecraft:air
fill 11 64 -145 14 64 -145 minecraft:air
fill 9 64 -146 13 64 -146 minecraft:air
setblock 57 64 -146 minecraft:air
fill 9 64 -147 10 64 -147 minecraft:air
setblock 11 64 -147 minecraft:short_grass
setblock 57 64 -147 minecraft:air
fill 9 64 -148 11 64 -148 minecraft:air
fill 56 64 -148 58 64 -148 minecraft:air
fill 9 64 -149 11 64 -149 minecraft:air
fill 56 64 -149 58 64 -149 minecraft:air
fill 9 64 -150 11 64 -150 minecraft:air
fill 56 64 -150 58 64 -150 minecraft:air
fill 9 64 -151 10 64 -151 minecraft:air
fill 56 64 -151 58 64 -151 minecraft:air
fill 8 64 -152 10 64 -152 minecraft:air
fill 57 64 -152 58 64 -152 minecraft:air
fill 8 64 -153 10 64 -153 minecraft:air
fill 57 64 -153 59 64 -153 minecraft:air
fill 8 64 -154 10 64 -154 minecraft:air
fill 57 64 -154 59 64 -154 minecraft:air
setblock 8 64 -155 minecraft:air
fill 58 64 -155 59 64 -155 minecraft:air
fill 8 64 -156 9 64 -156 minecraft:air
fill 58 64 -156 59 64 -156 minecraft:air
fill 8 64 -157 9 64 -157 minecraft:air
setblock 8 64 -158 minecraft:air
setblock 58 64 -158 minecraft:air
setblock 57 64 -159 minecraft:air
fill 27 64 -160 71 64 -160 minecraft:air
fill 27 64 -161 71 64 -161 minecraft:air
fill 27 64 -162 71 64 -162 minecraft:air
fill 27 64 -163 71 64 -163 minecraft:air
fill 27 64 -164 71 64 -164 minecraft:air
fill 27 64 -165 68 64 -165 minecraft:air
fill 27 64 -166 66 64 -166 minecraft:air
fill 27 64 -167 63 64 -167 minecraft:air
fill 27 64 -168 61 64 -168 minecraft:air
fill 27 64 -169 59 64 -169 minecraft:air
fill 27 64 -170 57 64 -170 minecraft:air
fill 27 64 -171 56 64 -171 minecraft:air
fill 69 64 -171 71 64 -171 minecraft:air
fill 27 64 -172 54 64 -172 minecraft:air
fill 67 64 -172 71 64 -172 minecraft:air
fill 27 64 -173 53 64 -173 minecraft:air
fill 64 64 -173 71 64 -173 minecraft:air
fill 27 64 -174 52 64 -174 minecraft:air
fill 63 64 -174 71 64 -174 minecraft:air
setblock 19 64 -175 minecraft:air
fill 27 64 -175 50 64 -175 minecraft:air
fill 61 64 -175 71 64 -175 minecraft:air
fill 15 64 -176 18 64 -176 minecraft:air
fill 27 64 -176 49 64 -176 minecraft:air
fill 59 64 -176 62 64 -176 minecraft:air
fill 64 64 -176 67 64 -176 minecraft:air
fill 69 64 -176 71 64 -176 minecraft:air
fill 15 64 -177 18 64 -177 minecraft:air
fill 27 64 -177 48 64 -177 minecraft:air
fill 58 64 -177 71 64 -177 minecraft:air
fill 14 64 -178 17 64 -178 minecraft:air
fill 27 64 -178 47 64 -178 minecraft:air
fill 56 64 -178 71 64 -178 minecraft:air
fill 14 64 -179 15 64 -179 minecraft:air
fill 27 64 -179 46 64 -179 minecraft:air
fill 55 64 -179 71 64 -179 minecraft:air
fill 13 64 -180 14 64 -180 minecraft:air
fill 27 64 -180 45 64 -180 minecraft:air
fill 54 64 -180 71 64 -180 minecraft:air
fill 27 64 -181 44 64 -181 minecraft:air
fill 55 64 -181 57 64 -181 minecraft:air
fill 59 64 -181 62 64 -181 minecraft:air
fill 64 64 -181 67 64 -181 minecraft:air
fill 69 64 -181 71 64 -181 minecraft:air
fill 27 64 -182 43 64 -182 minecraft:air
setblock 52 64 -182 minecraft:air
fill 59 64 -182 71 64 -182 minecraft:air
fill 27 64 -183 42 64 -183 minecraft:air
fill 51 64 -183 52 64 -183 minecraft:air
fill 63 64 -183 71 64 -183 minecraft:air
fill 27 64 -184 41 64 -184 minecraft:air
fill 50 64 -184 52 64 -184 minecraft:air
fill 66 64 -184 71 64 -184 minecraft:air
fill 27 64 -185 41 64 -185 minecraft:air
fill 49 64 -185 53 64 -185 minecraft:air
fill 70 64 -185 71 64 -185 minecraft:air
fill 27 64 -186 40 64 -186 minecraft:air
fill 49 64 -186 52 64 -186 minecraft:air
fill 27 64 -187 39 64 -187 minecraft:air
fill 47 64 -187 53 64 -187 minecraft:air
fill 27 64 -188 38 64 -188 minecraft:air
fill 46 64 -188 53 64 -188 minecraft:air
fill 27 64 -189 38 64 -189 minecraft:air
fill 45 64 -189 53 64 -189 minecraft:air
fill 27 64 -190 37 64 -190 minecraft:air
fill 45 64 -190 53 64 -190 minecraft:air
fill 26 63 -127 28 63 -127 minecraft:air
fill 38 63 -127 53 63 -127 minecraft:air
fill 23 63 -128 24 63 -128 minecraft:air
fill 26 63 -128 28 63 -128 minecraft:air
fill 38 63 -128 53 63 -128 minecraft:air
fill 22 63 -129 24 63 -129 minecraft:air
fill 26 63 -129 27 63 -129 minecraft:air
fill 38 63 -129 40 63 -129 minecraft:air
fill 45 63 -129 54 63 -129 minecraft:air
fill 21 63 -130 24 63 -130 minecraft:air
fill 45 63 -130 54 63 -130 minecraft:air
fill 20 63 -131 23 63 -131 minecraft:air
fill 46 63 -131 55 63 -131 minecraft:air
fill 19 63 -132 21 63 -132 minecraft:air
fill 46 63 -132 57 63 -132 minecraft:air
fill 47 63 -133 58 63 -133 minecraft:air
fill 63 63 -133 71 63 -133 minecraft:air
fill 47 63 -134 59 63 -134 minecraft:air
fill 61 63 -134 71 63 -134 minecraft:air
fill 48 63 -135 59 63 -135 minecraft:air
fill 61 63 -135 71 63 -135 minecraft:air
fill 49 63 -136 70 63 -136 minecraft:air
fill 50 63 -137 65 63 -137 minecraft:air
fill 51 63 -138 62 63 -138 minecraft:air
fill 52 63 -139 62 63 -139 minecraft:air
fill 53 63 -140 61 63 -140 minecraft:air
fill 54 63 -141 61 63 -141 minecraft:air
fill 54 63 -142 61 63 -142 minecraft:air
fill 55 63 -143 61 63 -143 minecraft:air
fill 56 63 -144 60 63 -144 minecraft:air
fill 56 63 -145 58 63 -145 minecraft:air
fill 56 63 -146 58 63 -146 minecraft:air
fill 56 63 -147 58 63 -147 minecraft:air
fill 55 63 -148 58 63 -148 minecraft:air
fill 56 63 -149 59 63 -149 minecraft:air
fill 56 63 -150 59 63 -150 minecraft:air
fill 56 63 -151 59 63 -151 minecraft:air
fill 56 63 -152 59 63 -152 minecraft:air
fill 57 63 -153 60 63 -153 minecraft:air
fill 57 63 -154 60 63 -154 minecraft:air
fill 57 63 -155 60 63 -155 minecraft:air
fill 57 63 -156 60 63 -156 minecraft:air
fill 57 63 -157 59 63 -157 minecraft:air
fill 57 63 -158 59 63 -158 minecraft:air
setblock 57 63 -159 minecraft:air
fill 27 63 -160 71 63 -160 minecraft:air
fill 27 63 -161 71 63 -161 minecraft:air
fill 27 63 -162 71 63 -162 minecraft:air
fill 27 63 -163 71 63 -163 minecraft:air
fill 27 63 -164 71 63 -164 minecraft:air
fill 27 63 -165 68 63 -165 minecraft:air
fill 27 63 -166 66 63 -166 minecraft:air
fill 27 63 -167 63 63 -167 minecraft:air
fill 27 63 -168 61 63 -168 minecraft:air
fill 27 63 -169 59 63 -169 minecraft:air
fill 27 63 -170 57 63 -170 minecraft:air
fill 27 63 -171 56 63 -171 minecraft:air
fill 27 63 -172 54 63 -172 minecraft:air
fill 27 63 -173 53 63 -173 minecraft:air
fill 27 63 -174 52 63 -174 minecraft:air
fill 27 63 -175 50 63 -175 minecraft:air
fill 16 63 -176 17 63 -176 minecraft:air
fill 27 63 -176 49 63 -176 minecraft:air
fill 13 63 -177 16 63 -177 minecraft:air
fill 27 63 -177 48 63 -177 minecraft:air
fill 13 63 -178 16 63 -178 minecraft:air
fill 27 63 -178 47 63 -178 minecraft:air
fill 12 63 -179 15 63 -179 minecraft:air
fill 27 63 -179 46 63 -179 minecraft:air
fill 12 63 -180 14 63 -180 minecraft:air
fill 27 63 -180 45 63 -180 minecraft:air
setblock 12 63 -181 minecraft:air
fill 27 63 -181 44 63 -181 minecraft:air
setblock 11 63 -182 minecraft:air
fill 27 63 -182 43 63 -182 minecraft:air
fill 27 63 -183 42 63 -183 minecraft:air
fill 27 63 -184 41 63 -184 minecraft:air
fill 27 63 -185 41 63 -185 minecraft:air
fill 27 63 -186 40 63 -186 minecraft:air
fill 27 63 -187 39 63 -187 minecraft:air
fill 27 63 -188 38 63 -188 minecraft:air
fill 27 63 -189 38 63 -189 minecraft:air
fill 27 63 -190 37 63 -190 minecraft:air
fill 26 62 -127 29 62 -127 minecraft:air
fill 36 62 -127 53 62 -127 minecraft:air
setblock 24 62 -128 minecraft:water[level=0]
fill 26 62 -128 28 62 -128 minecraft:air
fill 36 62 -128 53 62 -128 minecraft:air
fill 23 62 -129 24 62 -129 minecraft:water[level=0]
fill 26 62 -129 27 62 -129 minecraft:air
fill 35 62 -129 54 62 -129 minecraft:air
fill 22 62 -130 24 62 -130 minecraft:water[level=0]
fill 35 62 -130 41 62 -130 minecraft:air
fill 45 62 -130 54 62 -130 minecraft:air
fill 21 62 -131 25 62 -131 minecraft:water[level=0]
fill 35 62 -131 38 62 -131 minecraft:air
fill 46 62 -131 55 62 -131 minecraft:air
fill 19 62 -132 23 62 -132 minecraft:water[level=0]
fill 36 62 -132 37 62 -132 minecraft:air
fill 46 62 -132 57 62 -132 minecraft:air
fill 18 62 -133 20 62 -133 minecraft:water[level=0]
fill 47 62 -133 58 62 -133 minecraft:air
fill 63 62 -133 68 62 -133 minecraft:air
setblock 16 62 -134 minecraft:water[level=0]
fill 47 62 -134 58 62 -134 minecraft:air
fill 61 62 -134 68 62 -134 minecraft:air
fill 48 62 -135 59 62 -135 minecraft:air
fill 61 62 -135 68 62 -135 minecraft:air
fill 49 62 -136 68 62 -136 minecraft:air
fill 50 62 -137 64 62 -137 minecraft:air
fill 51 62 -138 63 62 -138 minecraft:air
fill 52 62 -139 62 62 -139 minecraft:air
fill 53 62 -140 62 62 -140 minecraft:air
fill 53 62 -141 62 62 -141 minecraft:air
fill 54 62 -142 61 62 -142 minecraft:air
fill 55 62 -143 61 62 -143 minecraft:air
fill 55 62 -144 60 62 -144 minecraft:air
fill 55 62 -145 59 62 -145 minecraft:air
fill 55 62 -146 59 62 -146 minecraft:air
fill 55 62 -147 59 62 -147 minecraft:air
fill 55 62 -148 59 62 -148 minecraft:air
fill 55 62 -149 59 62 -149 minecraft:air
fill 55 62 -150 59 62 -150 minecraft:air
fill 56 62 -151 59 62 -151 minecraft:air
fill 56 62 -152 59 62 -152 minecraft:air
fill 57 62 -153 60 62 -153 minecraft:air
fill 56 62 -154 60 62 -154 minecraft:air
fill 57 62 -155 60 62 -155 minecraft:air
fill 57 62 -156 60 62 -156 minecraft:air
fill 56 62 -157 60 62 -157 minecraft:air
fill 56 62 -158 59 62 -158 minecraft:air
fill 57 62 -159 58 62 -159 minecraft:air
fill 27 62 -160 71 62 -160 minecraft:air
fill 27 62 -161 71 62 -161 minecraft:air
fill 27 62 -162 71 62 -162 minecraft:air
fill 27 62 -163 71 62 -163 minecraft:air
fill 27 62 -164 71 62 -164 minecraft:air
fill 27 62 -165 68 62 -165 minecraft:air
fill 27 62 -166 66 62 -166 minecraft:air
fill 27 62 -167 63 62 -167 minecraft:air
fill 27 62 -168 61 62 -168 minecraft:air
fill 27 62 -169 59 62 -169 minecraft:air
fill 27 62 -170 57 62 -170 minecraft:air
fill 27 62 -171 56 62 -171 minecraft:air
fill 27 62 -172 54 62 -172 minecraft:air
fill 27 62 -173 53 62 -173 minecraft:air
fill 27 62 -174 52 62 -174 minecraft:air
fill 27 62 -175 50 62 -175 minecraft:air
setblock 16 62 -176 minecraft:air
fill 27 62 -176 49 62 -176 minecraft:air
fill 14 62 -177 15 62 -177 minecraft:air
fill 27 62 -177 48 62 -177 minecraft:air
fill 12 62 -178 15 62 -178 minecraft:air
fill 27 62 -178 47 62 -178 minecraft:air
fill 11 62 -179 14 62 -179 minecraft:air
fill 27 62 -179 46 62 -179 minecraft:air
fill 11 62 -180 14 62 -180 minecraft:air
fill 27 62 -180 45 62 -180 minecraft:air
fill 11 62 -181 13 62 -181 minecraft:air
fill 27 62 -181 44 62 -181 minecraft:air
fill 10 62 -182 12 62 -182 minecraft:air
fill 27 62 -182 43 62 -182 minecraft:air
setblock 10 62 -183 minecraft:air
fill 27 62 -183 42 62 -183 minecraft:air
setblock 10 62 -184 minecraft:air
fill 27 62 -184 41 62 -184 minecraft:air
fill 27 62 -185 41 62 -185 minecraft:air
fill 27 62 -186 40 62 -186 minecraft:air
fill 27 62 -187 39 62 -187 minecraft:air
fill 27 62 -188 38 62 -188 minecraft:air
fill 27 62 -189 38 62 -189 minecraft:air
fill 27 62 -190 37 62 -190 minecraft:air
fill 27 61 -127 29 61 -127 minecraft:air
fill 36 61 -127 52 61 -127 minecraft:air
fill 26 61 -128 29 61 -128 minecraft:air
fill 35 61 -128 53 61 -128 minecraft:air
setblock 24 61 -129 minecraft:water[level=0]
fill 26 61 -129 27 61 -129 minecraft:air
fill 34 61 -129 53 61 -129 minecraft:air
fill 22 61 -130 24 61 -130 minecraft:water[level=0]
setblock 27 61 -130 minecraft:air
fill 34 61 -130 43 61 -130 minecraft:air
fill 45 61 -130 54 61 -130 minecraft:air
fill 21 61 -131 25 61 -131 minecraft:water[level=0]
fill 34 61 -131 40 61 -131 minecraft:air
fill 46 61 -131 55 61 -131 minecraft:air
fill 20 61 -132 24 61 -132 minecraft:water[level=0]
fill 34 61 -132 39 61 -132 minecraft:air
fill 47 61 -132 56 61 -132 minecraft:air
fill 18 61 -133 22 61 -133 minecraft:water[level=0]
fill 34 61 -133 38 61 -133 minecraft:air
fill 47 61 -133 57 61 -133 minecraft:air
fill 16 61 -134 20 61 -134 minecraft:water[level=0]
fill 48 61 -134 58 61 -134 minecraft:air
fill 62 61 -134 64 61 -134 minecraft:air
fill 13 61 -135 16 61 -135 minecraft:water[level=0]
fill 48 61 -135 59 61 -135 minecraft:air
fill 61 61 -135 65 61 -135 minecraft:air
fill 49 61 -136 64 61 -136 minecraft:air
fill 50 61 -137 63 61 -137 minecraft:air
setblock 51 61 -138 regions_unexplored:grass_sprouts
fill 52 61 -138 63 61 -138 minecraft:air
fill 53 61 -139 62 61 -139 minecraft:air
fill 53 61 -140 62 61 -140 minecraft:air
fill 54 61 -141 62 61 -141 minecraft:air
fill 54 61 -142 61 61 -142 minecraft:air
fill 55 61 -143 61 61 -143 minecraft:air
fill 55 61 -144 60 61 -144 minecraft:air
fill 55 61 -145 59 61 -145 minecraft:air
fill 55 61 -146 59 61 -146 minecraft:air
fill 55 61 -147 59 61 -147 minecraft:air
fill 55 61 -148 59 61 -148 minecraft:air
fill 56 61 -149 59 61 -149 minecraft:air
fill 56 61 -150 59 61 -150 minecraft:air
fill 56 61 -151 59 61 -151 minecraft:air
fill 56 61 -152 59 61 -152 minecraft:air
fill 57 61 -153 59 61 -153 minecraft:air
fill 57 61 -154 59 61 -154 minecraft:air
fill 57 61 -155 60 61 -155 minecraft:air
fill 57 61 -156 60 61 -156 minecraft:air
fill 56 61 -157 60 61 -157 minecraft:air
fill 55 61 -158 59 61 -158 minecraft:air
fill 55 61 -159 58 61 -159 minecraft:air
fill 27 61 -160 71 61 -160 minecraft:air
fill 27 61 -161 71 61 -161 minecraft:air
fill 27 61 -162 71 61 -162 minecraft:air
fill 27 61 -163 71 61 -163 minecraft:air
fill 27 61 -164 71 61 -164 minecraft:air
fill 27 61 -165 68 61 -165 minecraft:air
fill 27 61 -166 66 61 -166 minecraft:air
fill 27 61 -167 63 61 -167 minecraft:air
fill 27 61 -168 61 61 -168 minecraft:air
fill 27 61 -169 59 61 -169 minecraft:air
fill 27 61 -170 57 61 -170 minecraft:air
fill 27 61 -171 56 61 -171 minecraft:air
fill 27 61 -172 54 61 -172 minecraft:air
fill 27 61 -173 53 61 -173 minecraft:air
fill 27 61 -174 52 61 -174 minecraft:air
fill 27 61 -175 50 61 -175 minecraft:air
fill 27 61 -176 49 61 -176 minecraft:air
setblock 14 61 -177 minecraft:air
fill 27 61 -177 48 61 -177 minecraft:air
fill 12 61 -178 14 61 -178 minecraft:air
fill 27 61 -178 47 61 -178 minecraft:air
fill 11 61 -179 13 61 -179 minecraft:air
fill 27 61 -179 46 61 -179 minecraft:air
fill 10 61 -180 13 61 -180 minecraft:air
fill 27 61 -180 45 61 -180 minecraft:air
fill 9 61 -181 12 61 -181 minecraft:air
fill 27 61 -181 44 61 -181 minecraft:air
fill 9 61 -182 12 61 -182 minecraft:air
fill 27 61 -182 43 61 -182 minecraft:air
fill 9 61 -183 11 61 -183 minecraft:air
fill 27 61 -183 42 61 -183 minecraft:air
fill 9 61 -184 10 61 -184 minecraft:air
fill 27 61 -184 41 61 -184 minecraft:air
setblock 9 61 -185 minecraft:air
fill 27 61 -185 41 61 -185 minecraft:air
fill 27 61 -186 40 61 -186 minecraft:air
fill 27 61 -187 39 61 -187 minecraft:air
fill 27 61 -188 38 61 -188 minecraft:air
fill 27 61 -189 38 61 -189 minecraft:air
fill 27 61 -190 37 61 -190 minecraft:air
fill 29 60 -127 30 60 -127 minecraft:air
fill 35 60 -127 52 60 -127 minecraft:air
fill 27 60 -128 29 60 -128 minecraft:air
fill 34 60 -128 52 60 -128 minecraft:air
fill 27 60 -129 28 60 -129 minecraft:air
fill 34 60 -129 46 60 -129 minecraft:air
fill 48 60 -129 53 60 -129 minecraft:air
fill 23 60 -130 25 60 -130 minecraft:water[level=0]
setblock 27 60 -130 minecraft:air
fill 34 60 -130 43 60 -130 minecraft:air
fill 46 60 -130 53 60 -130 minecraft:air
fill 21 60 -131 25 60 -131 minecraft:water[level=0]
fill 33 60 -131 41 60 -131 minecraft:air
fill 46 60 -131 54 60 -131 minecraft:air
fill 20 60 -132 25 60 -132 minecraft:water[level=0]
fill 33 60 -132 39 60 -132 minecraft:air
fill 47 60 -132 54 60 -132 minecraft:air
setblock 55 60 -132 regions_unexplored:grass_sprouts
fill 18 60 -133 24 60 -133 minecraft:water[level=0]
fill 33 60 -133 38 60 -133 minecraft:air
fill 48 60 -133 54 60 -133 minecraft:air
setblock 55 60 -133 regions_unexplored:grass_sprouts
fill 56 60 -133 57 60 -133 minecraft:air
fill 16 60 -134 22 60 -134 minecraft:water[level=0]
fill 34 60 -134 37 60 -134 minecraft:air
fill 48 60 -134 58 60 -134 minecraft:air
fill 13 60 -135 20 60 -135 minecraft:water[level=0]
fill 49 60 -135 52 60 -135 minecraft:air
setblock 53 60 -135 regions_unexplored:grass_sprouts
setblock 54 60 -135 minecraft:air
setblock 55 60 -135 regions_unexplored:grass_sprouts
fill 56 60 -135 58 60 -135 minecraft:air
fill 12 60 -136 16 60 -136 minecraft:water[level=0]
fill 50 60 -136 59 60 -136 minecraft:air
setblock 61 60 -136 minecraft:air
fill 51 60 -137 62 60 -137 minecraft:air
fill 52 60 -138 62 60 -138 minecraft:air
fill 53 60 -139 62 60 -139 minecraft:air
fill 54 60 -140 61 60 -140 minecraft:air
fill 54 60 -141 61 60 -141 minecraft:air
fill 54 60 -142 61 60 -142 minecraft:air
fill 55 60 -143 61 60 -143 minecraft:air
fill 56 60 -144 60 60 -144 minecraft:air
fill 55 60 -145 58 60 -145 minecraft:air
fill 55 60 -146 58 60 -146 minecraft:air
fill 56 60 -147 58 60 -147 minecraft:air
fill 56 60 -148 58 60 -148 minecraft:air
fill 57 60 -156 58 60 -156 minecraft:air
fill 55 60 -157 59 60 -157 minecraft:air
fill 54 60 -158 59 60 -158 minecraft:air
fill 54 60 -159 58 60 -159 minecraft:air
fill 27 60 -160 71 60 -160 minecraft:air
fill 27 60 -161 71 60 -161 minecraft:air
fill 27 60 -162 71 60 -162 minecraft:air
fill 27 60 -163 71 60 -163 minecraft:air
fill 27 60 -164 71 60 -164 minecraft:air
fill 27 60 -165 68 60 -165 minecraft:air
fill 27 60 -166 66 60 -166 minecraft:air
fill 27 60 -167 63 60 -167 minecraft:air
fill 27 60 -168 61 60 -168 minecraft:air
fill 27 60 -169 59 60 -169 minecraft:air
fill 27 60 -170 57 60 -170 minecraft:air
fill 27 60 -171 56 60 -171 minecraft:air
fill 27 60 -172 54 60 -172 minecraft:air
fill 27 60 -173 53 60 -173 minecraft:air
fill 27 60 -174 52 60 -174 minecraft:air
fill 27 60 -175 50 60 -175 minecraft:air
fill 27 60 -176 49 60 -176 minecraft:air
fill 27 60 -177 48 60 -177 minecraft:air
setblock 13 60 -178 minecraft:air
fill 27 60 -178 47 60 -178 minecraft:air
fill 11 60 -179 12 60 -179 minecraft:air
fill 27 60 -179 46 60 -179 minecraft:air
fill 10 60 -180 12 60 -180 minecraft:air
fill 27 60 -180 45 60 -180 minecraft:air
fill 9 60 -181 11 60 -181 minecraft:air
fill 27 60 -181 44 60 -181 minecraft:air
fill 8 60 -182 11 60 -182 minecraft:air
fill 27 60 -182 43 60 -182 minecraft:air
fill 8 60 -183 11 60 -183 minecraft:air
fill 27 60 -183 42 60 -183 minecraft:air
fill 8 60 -184 10 60 -184 minecraft:air
fill 27 60 -184 41 60 -184 minecraft:air
fill 8 60 -185 9 60 -185 minecraft:air
fill 27 60 -185 41 60 -185 minecraft:air
fill 8 60 -186 9 60 -186 minecraft:air
fill 27 60 -186 40 60 -186 minecraft:air
setblock 8 60 -187 minecraft:air
fill 27 60 -187 39 60 -187 minecraft:air
fill 27 60 -188 38 60 -188 minecraft:air
fill 27 60 -189 38 60 -189 minecraft:air
fill 27 60 -190 37 60 -190 minecraft:air
setblock 30 59 -127 minecraft:air
fill 35 59 -127 46 59 -127 minecraft:air
fill 48 59 -127 51 59 -127 minecraft:air
fill 28 59 -128 30 59 -128 minecraft:air
fill 34 59 -128 45 59 -128 minecraft:air
fill 50 59 -128 51 59 -128 minecraft:air
fill 27 59 -129 28 59 -129 minecraft:air
fill 34 59 -129 44 59 -129 minecraft:air
fill 50 59 -129 51 59 -129 minecraft:air
setblock 25 59 -130 minecraft:water[level=0]
setblock 27 59 -130 minecraft:air
fill 33 59 -130 43 59 -130 minecraft:air
setblock 50 59 -130 minecraft:air
fill 23 59 -131 24 59 -131 minecraft:water[level=0]
fill 33 59 -131 41 59 -131 minecraft:air
fill 21 59 -132 25 59 -132 minecraft:water[level=0]
fill 33 59 -132 40 59 -132 minecraft:air
fill 18 59 -133 24 59 -133 minecraft:water[level=0]
fill 33 59 -133 39 59 -133 minecraft:air
fill 17 59 -134 23 59 -134 minecraft:water[level=0]
fill 32 59 -134 38 59 -134 minecraft:air
fill 13 59 -135 21 59 -135 minecraft:water[level=0]
fill 31 59 -135 37 59 -135 minecraft:air
fill 12 59 -136 19 59 -136 minecraft:water[level=0]
fill 31 59 -136 33 59 -136 minecraft:air
fill 12 59 -137 16 59 -137 minecraft:water[level=0]
fill 56 59 -137 59 59 -137 minecraft:air
fill 11 59 -138 12 59 -138 minecraft:water[level=0]
fill 55 59 -138 60 59 -138 minecraft:air
fill 54 59 -139 61 59 -139 minecraft:air
fill 54 59 -140 61 59 -140 minecraft:air
fill 54 59 -141 61 59 -141 minecraft:air
fill 55 59 -142 61 59 -142 minecraft:air
fill 56 59 -143 60 59 -143 minecraft:air
fill 57 59 -144 59 59 -144 minecraft:air
fill 55 59 -157 57 59 -157 minecraft:air
fill 54 59 -158 57 59 -158 minecraft:air
fill 54 59 -159 57 59 -159 minecraft:air
setblock 27 59 -160 minecraft:air
fill 55 59 -160 56 59 -160 minecraft:air
setblock 53 59 -162 minecraft:air
fill 51 59 -163 52 59 -163 minecraft:air
fill 49 59 -164 52 59 -164 minecraft:air
fill 48 59 -165 51 59 -165 minecraft:air
fill 47 59 -166 50 59 -166 minecraft:air
fill 45 59 -167 49 59 -167 minecraft:air
setblock 11 59 -180 minecraft:air
setblock 10 59 -181 minecraft:air
fill 9 59 -182 10 59 -182 minecraft:air
fill 8 59 -183 10 59 -183 minecraft:air
fill 8 59 -184 9 59 -184 minecraft:air
fill 8 59 -185 9 59 -185 minecraft:air
fill 8 59 -186 9 59 -186 minecraft:air
setblock 8 59 -187 minecraft:air
setblock 8 59 -188 minecraft:air
setblock 31 58 -127 minecraft:air
fill 35 58 -127 44 58 -127 minecraft:air
setblock 49 58 -127 minecraft:air
fill 29 58 -128 30 58 -128 minecraft:air
fill 34 58 -128 44 58 -128 minecraft:air
fill 28 58 -129 29 58 -129 minecraft:air
fill 34 58 -129 44 58 -129 minecraft:air
fill 26 58 -130 28 58 -130 minecraft:air
fill 33 58 -130 43 58 -130 minecraft:air
fill 26 58 -131 27 58 -131 minecraft:air
fill 32 58 -131 41 58 -131 minecraft:air
fill 23 58 -132 24 58 -132 minecraft:water[level=0]
fill 32 58 -132 40 58 -132 minecraft:air
fill 21 58 -133 24 58 -133 minecraft:water[level=0]
fill 32 58 -133 39 58 -133 minecraft:air
fill 17 58 -134 23 58 -134 minecraft:water[level=0]
fill 30 58 -134 38 58 -134 minecraft:air
fill 13 58 -135 22 58 -135 minecraft:water[level=0]
fill 30 58 -135 37 58 -135 minecraft:air
fill 12 58 -136 21 58 -136 minecraft:water[level=0]
fill 30 58 -136 34 58 -136 minecraft:air
fill 12 58 -137 19 58 -137 minecraft:water[level=0]
fill 30 58 -137 34 58 -137 minecraft:air
fill 11 58 -138 16 58 -138 minecraft:water[level=0]
setblock 31 58 -138 minecraft:air
fill 11 58 -139 13 58 -139 minecraft:water[level=0]
fill 53 58 -157 56 58 -157 minecraft:air
fill 53 58 -158 57 58 -158 minecraft:air
fill 53 58 -159 57 58 -159 minecraft:air
setblock 56 58 -160 minecraft:air
fill 51 58 -163 52 58 -163 minecraft:air
fill 49 58 -164 51 58 -164 minecraft:air
fill 47 58 -165 50 58 -165 minecraft:air
fill 46 58 -166 49 58 -166 minecraft:air
fill 45 58 -167 48 58 -167 minecraft:air
fill 66 58 -178 67 58 -178 minecraft:air
fill 65 58 -179 66 58 -179 minecraft:air
fill 64 58 -180 66 58 -180 minecraft:air
fill 63 58 -181 66 58 -181 minecraft:air
setblock 9 58 -182 minecraft:air
fill 63 58 -182 65 58 -182 minecraft:air
fill 8 58 -183 9 58 -183 minecraft:air
fill 63 58 -183 64 58 -183 minecraft:air
setblock 8 58 -184 minecraft:air
setblock 63 58 -184 minecraft:air
setblock 8 58 -185 minecraft:air
setblock 8 58 -186 minecraft:air
setblock 8 58 -187 minecraft:air
setblock 8 58 -188 minecraft:air
fill 35 57 -127 44 57 -127 minecraft:air
setblock 30 57 -128 minecraft:air
fill 34 57 -128 44 57 -128 minecraft:air
setblock 29 57 -129 minecraft:air
fill 34 57 -129 43 57 -129 minecraft:air
fill 27 57 -130 28 57 -130 minecraft:air
fill 33 57 -130 42 57 -130 minecraft:air
fill 26 57 -131 27 57 -131 minecraft:air
fill 32 57 -131 40 57 -131 minecraft:air
setblock 24 57 -132 minecraft:water[level=0]
setblock 26 57 -132 minecraft:air
fill 32 57 -132 39 57 -132 minecraft:air
fill 22 57 -133 24 57 -133 minecraft:water[level=0]
fill 31 57 -133 39 57 -133 minecraft:air
fill 20 57 -134 23 57 -134 minecraft:water[level=0]
fill 30 57 -134 38 57 -134 minecraft:air
fill 17 57 -135 22 57 -135 minecraft:water[level=0]
fill 29 57 -135 37 57 -135 minecraft:air
fill 12 57 -136 21 57 -136 minecraft:water[level=0]
fill 29 57 -136 35 57 -136 minecraft:air
fill 12 57 -137 20 57 -137 minecraft:water[level=0]
fill 28 57 -137 34 57 -137 minecraft:air
fill 11 57 -138 18 57 -138 minecraft:water[level=0]
fill 29 57 -138 33 57 -138 minecraft:air
fill 11 57 -139 16 57 -139 minecraft:water[level=0]
fill 11 57 -140 13 57 -140 minecraft:water[level=0]
fill 53 57 -157 55 57 -157 minecraft:air
fill 53 57 -158 56 57 -158 minecraft:air
fill 53 57 -159 55 57 -159 minecraft:air
setblock 51 57 -163 minecraft:air
fill 49 57 -164 50 57 -164 minecraft:air
fill 46 57 -165 49 57 -165 minecraft:air
fill 45 57 -166 48 57 -166 minecraft:air
fill 44 57 -167 47 57 -167 minecraft:air
setblock 67 57 -179 minecraft:air
fill 65 57 -180 66 57 -180 minecraft:air
fill 64 57 -181 66 57 -181 minecraft:air
fill 63 57 -182 66 57 -182 minecraft:air
fill 63 57 -183 65 57 -183 minecraft:air
fill 63 57 -184 64 57 -184 minecraft:air
setblock 63 57 -185 minecraft:air
setblock 8 57 -189 minecraft:air
setblock 32 56 -127 minecraft:air
fill 36 56 -127 42 56 -127 minecraft:air
setblock 31 56 -128 minecraft:air
fill 35 56 -128 42 56 -128 minecraft:air
setblock 30 56 -129 minecraft:air
fill 34 56 -129 41 56 -129 minecraft:air
setblock 28 56 -130 minecraft:air
fill 33 56 -130 41 56 -130 minecraft:air
setblock 27 56 -131 minecraft:air
fill 33 56 -131 39 56 -131 minecraft:air
setblock 26 56 -132 minecraft:air
fill 33 56 -132 39 56 -132 minecraft:air
fill 30 56 -133 38 56 -133 minecraft:air
fill 22 56 -134 23 56 -134 minecraft:water[level=0]
fill 29 56 -134 38 56 -134 minecraft:air
fill 20 56 -135 22 56 -135 minecraft:water[level=0]
fill 29 56 -135 37 56 -135 minecraft:air
fill 17 56 -136 21 56 -136 minecraft:water[level=0]
fill 28 56 -136 35 56 -136 minecraft:air
fill 13 56 -137 20 56 -137 minecraft:water[level=0]
fill 27 56 -137 34 56 -137 minecraft:air
fill 11 56 -138 18 56 -138 minecraft:water[level=0]
fill 27 56 -138 33 56 -138 minecraft:air
fill 11 56 -139 16 56 -139 minecraft:water[level=0]
fill 28 56 -139 32 56 -139 minecraft:air
fill 11 56 -140 13 56 -140 minecraft:water[level=0]
setblock 52 56 -156 minecraft:air
fill 51 56 -157 55 56 -157 minecraft:air
setblock 45 56 -158 minecraft:air
fill 51 56 -158 55 56 -158 minecraft:air
fill 53 56 -159 55 56 -159 minecraft:air
setblock 49 56 -164 minecraft:air
fill 45 56 -165 48 56 -165 minecraft:air
fill 44 56 -166 48 56 -166 minecraft:air
fill 43 56 -167 47 56 -167 minecraft:air
setblock 67 56 -180 minecraft:air
fill 66 56 -181 67 56 -181 minecraft:air
fill 64 56 -182 66 56 -182 minecraft:air
fill 63 56 -183 66 56 -183 minecraft:air
fill 63 56 -184 65 56 -184 minecraft:air
fill 63 56 -185 64 56 -185 minecraft:air
setblock 63 56 -186 minecraft:air
setblock 31 55 -129 minecraft:air
setblock 30 55 -130 minecraft:air
fill 34 55 -130 37 55 -130 minecraft:air
setblock 29 55 -131 minecraft:air
fill 33 55 -131 38 55 -131 minecraft:air
fill 27 55 -132 28 55 -132 minecraft:air
fill 33 55 -132 38 55 -132 minecraft:air
setblock 26 55 -133 minecraft:air
fill 30 55 -133 38 55 -133 minecraft:air
fill 29 55 -134 37 55 -134 minecraft:air
fill 22 55 -135 23 55 -135 minecraft:water[level=0]
fill 28 55 -135 35 55 -135 minecraft:air
fill 20 55 -136 23 55 -136 minecraft:water[level=0]
fill 27 55 -136 35 55 -136 minecraft:air
fill 17 55 -137 24 55 -137 minecraft:water[level=0]
fill 27 55 -137 34 55 -137 minecraft:air
fill 13 55 -138 20 55 -138 minecraft:water[level=0]
fill 22 55 -138 24 55 -138 minecraft:water[level=0]
fill 27 55 -138 33 55 -138 minecraft:air
fill 11 55 -139 18 55 -139 minecraft:water[level=0]
fill 27 55 -139 32 55 -139 minecraft:air
fill 11 55 -140 16 55 -140 minecraft:water[level=0]
fill 27 55 -140 30 55 -140 minecraft:air
fill 10 55 -141 13 55 -141 minecraft:water[level=0]
fill 50 55 -156 53 55 -156 minecraft:air
fill 45 55 -157 53 55 -157 minecraft:air
fill 44 55 -158 53 55 -158 minecraft:air
fill 45 55 -159 47 55 -159 minecraft:air
fill 50 55 -159 53 55 -159 minecraft:air
setblock 49 55 -164 minecraft:air
fill 45 55 -165 48 55 -165 minecraft:air
fill 44 55 -166 47 55 -166 minecraft:air
fill 42 55 -167 46 55 -167 minecraft:air
setblock 67 55 -181 minecraft:air
fill 65 55 -182 67 55 -182 minecraft:air
fill 64 55 -183 67 55 -183 minecraft:air
fill 64 55 -184 66 55 -184 minecraft:air
fill 64 55 -185 65 55 -185 minecraft:air
setblock 64 55 -186 minecraft:air
setblock 63 55 -187 minecraft:air
setblock 34 54 -128 minecraft:air
setblock 33 54 -129 minecraft:air
fill 31 54 -130 32 54 -130 minecraft:air
fill 30 54 -131 31 54 -131 minecraft:air
fill 28 54 -132 29 54 -132 minecraft:air
fill 27 54 -133 28 54 -133 minecraft:air
fill 31 54 -133 33 54 -133 minecraft:air
fill 26 54 -134 27 54 -134 minecraft:air
fill 30 54 -134 34 54 -134 minecraft:air
fill 28 54 -135 34 54 -135 minecraft:air
fill 19 54 -136 20 54 -136 minecraft:water[level=0]
fill 22 54 -136 24 54 -136 minecraft:water[level=0]
fill 26 54 -136 34 54 -136 minecraft:air
fill 16 54 -137 24 54 -137 minecraft:water[level=0]
fill 26 54 -137 34 54 -137 minecraft:air
fill 16 54 -138 24 54 -138 minecraft:water[level=0]
fill 26 54 -138 33 54 -138 minecraft:air
fill 13 54 -139 20 54 -139 minecraft:water[level=0]
fill 22 54 -139 24 54 -139 minecraft:water[level=0]
fill 27 54 -139 32 54 -139 minecraft:air
fill 11 54 -140 19 54 -140 minecraft:water[level=0]
fill 27 54 -140 30 54 -140 minecraft:air
fill 10 54 -141 17 54 -141 minecraft:water[level=0]
fill 10 54 -142 14 54 -142 minecraft:water[level=0]
fill 48 54 -156 53 54 -156 minecraft:air
fill 44 54 -157 53 54 -157 minecraft:air
fill 44 54 -158 53 54 -158 minecraft:air
fill 44 54 -159 45 54 -159 minecraft:air
setblock 46 54 -159 minecraft:water[level=1]
fill 47 54 -159 52 54 -159 minecraft:air
setblock 46 54 -160 minecraft:water[level=0]
fill 44 54 -165 47 54 -165 minecraft:air
fill 43 54 -166 46 54 -166 minecraft:air
fill 42 54 -167 45 54 -167 minecraft:air
setblock 68 54 -181 minecraft:air
fill 66 54 -182 68 54 -182 minecraft:air
fill 65 54 -183 67 54 -183 minecraft:air
fill 65 54 -184 67 54 -184 minecraft:air
fill 64 54 -185 66 54 -185 minecraft:air
fill 64 54 -186 65 54 -186 minecraft:air
setblock 64 54 -187 minecraft:air
setblock 36 53 -127 minecraft:air
setblock 35 53 -128 minecraft:air
setblock 34 53 -129 minecraft:air
setblock 33 53 -130 minecraft:air
fill 31 53 -131 32 53 -131 minecraft:air
fill 30 53 -132 31 53 -132 minecraft:air
fill 28 53 -133 30 53 -133 minecraft:air
fill 27 53 -134 28 53 -134 minecraft:air
setblock 31 53 -134 minecraft:air
fill 26 53 -135 32 53 -135 minecraft:air
fill 16 53 -136 24 53 -136 minecraft:water[level=0]
fill 26 53 -136 33 53 -136 minecraft:air
fill 15 53 -137 23 53 -137 minecraft:water[level=0]
fill 26 53 -137 33 53 -137 minecraft:air
fill 15 53 -138 24 53 -138 minecraft:water[level=0]
fill 26 53 -138 32 53 -138 minecraft:air
fill 16 53 -139 24 53 -139 minecraft:water[level=0]
fill 27 53 -139 31 53 -139 minecraft:air
fill 13 53 -140 21 53 -140 minecraft:water[level=0]
fill 27 53 -140 30 53 -140 minecraft:air
fill 10 53 -141 18 53 -141 minecraft:water[level=0]
fill 10 53 -142 16 53 -142 minecraft:water[level=0]
fill 10 53 -143 13 53 -143 minecraft:water[level=0]
setblock 49 53 -156 minecraft:water[level=6]
setblock 50 53 -156 minecraft:water[level=7]
setblock 51 53 -156 minecraft:air
setblock 45 53 -157 minecraft:water[level=3]
setblock 46 53 -157 minecraft:water[level=2]
setblock 47 53 -157 minecraft:water[level=3]
setblock 48 53 -157 minecraft:water[level=4]
setblock 49 53 -157 minecraft:water[level=5]
setblock 50 53 -157 minecraft:water[level=6]
setblock 51 53 -157 minecraft:water[level=7]
setblock 52 53 -157 minecraft:air
setblock 45 53 -158 minecraft:water[level=2]
setblock 46 53 -158 minecraft:water[level=1]
setblock 47 53 -158 minecraft:water[level=2]
setblock 48 53 -158 minecraft:water[level=3]
setblock 49 53 -158 minecraft:water[level=4]
setblock 50 53 -158 minecraft:water[level=5]
setblock 51 53 -158 minecraft:water[level=6]
setblock 52 53 -158 minecraft:water[level=7]
setblock 45 53 -159 minecraft:water[level=1]
setblock 46 53 -159 minecraft:water[level=8]
setblock 47 53 -159 minecraft:water[level=1]
setblock 48 53 -159 minecraft:water[level=2]
setblock 49 53 -159 minecraft:water[level=3]
setblock 50 53 -159 minecraft:water[level=4]
fill 44 53 -165 46 53 -165 minecraft:air
fill 43 53 -166 46 53 -166 minecraft:air
fill 41 53 -167 45 53 -167 minecraft:air
fill 67 53 -182 68 53 -182 minecraft:air
fill 66 53 -183 68 53 -183 minecraft:air
fill 65 53 -184 67 53 -184 minecraft:air
setblock 68 53 -184 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
fill 65 53 -185 67 53 -185 minecraft:air
fill 65 53 -186 66 53 -186 minecraft:air
setblock 65 53 -187 minecraft:air
setblock 37 52 -127 minecraft:air
setblock 36 52 -128 minecraft:air
fill 35 52 -129 36 52 -129 minecraft:air
fill 34 52 -130 35 52 -130 minecraft:air
fill 33 52 -131 34 52 -131 minecraft:air
fill 31 52 -132 33 52 -132 minecraft:air
fill 30 52 -133 31 52 -133 minecraft:air
fill 28 52 -134 30 52 -134 minecraft:air
fill 27 52 -135 28 52 -135 minecraft:air
fill 16 52 -136 23 52 -136 minecraft:water[level=0]
fill 26 52 -136 31 52 -136 minecraft:air
fill 15 52 -137 24 52 -137 minecraft:water[level=0]
fill 26 52 -137 31 52 -137 minecraft:air
fill 15 52 -138 24 52 -138 minecraft:water[level=0]
fill 27 52 -138 31 52 -138 minecraft:air
fill 17 52 -139 24 52 -139 minecraft:water[level=0]
fill 27 52 -139 30 52 -139 minecraft:air
fill 15 52 -140 22 52 -140 minecraft:water[level=0]
setblock 25 52 -140 minecraft:water[level=0]
fill 27 52 -140 28 52 -140 minecraft:air
fill 12 52 -141 20 52 -141 minecraft:water[level=0]
fill 10 52 -142 17 52 -142 minecraft:water[level=0]
fill 10 52 -143 15 52 -143 minecraft:water[level=0]
fill 10 52 -144 12 52 -144 minecraft:water[level=0]
fill 43 52 -165 46 52 -165 minecraft:air
fill 42 52 -166 45 52 -166 minecraft:air
fill 42 52 -167 44 52 -167 minecraft:air
fill 64 52 -170 66 52 -170 minecraft:air
fill 63 52 -171 66 52 -171 minecraft:air
fill 64 52 -172 65 52 -172 minecraft:air
fill 68 52 -174 69 52 -174 minecraft:air
setblock 71 52 -174 minecraft:air
setblock 67 52 -175 minecraft:air
setblock 69 52 -175 minecraft:air
setblock 65 52 -176 minecraft:air
fill 68 52 -182 69 52 -182 minecraft:air
fill 67 52 -183 69 52 -183 minecraft:air
fill 66 52 -184 69 52 -184 minecraft:air
fill 66 52 -185 68 52 -185 minecraft:air
fill 65 52 -186 67 52 -186 minecraft:air
fill 65 52 -187 66 52 -187 minecraft:air
setblock 65 52 -188 minecraft:air
setblock 38 51 -127 minecraft:air
setblock 37 51 -128 minecraft:air
fill 36 51 -129 37 51 -129 minecraft:air
fill 35 51 -130 36 51 -130 minecraft:air
fill 34 51 -131 35 51 -131 minecraft:air
fill 33 51 -132 34 51 -132 minecraft:air
fill 31 51 -133 33 51 -133 minecraft:air
fill 30 51 -134 31 51 -134 minecraft:air
fill 28 51 -135 30 51 -135 minecraft:air
setblock 22 51 -136 minecraft:water[level=0]
fill 27 51 -136 29 51 -136 minecraft:air
fill 21 51 -137 23 51 -137 minecraft:water[level=0]
fill 27 51 -137 28 51 -137 minecraft:air
fill 21 51 -138 24 51 -138 minecraft:water[level=0]
fill 27 51 -138 28 51 -138 minecraft:air
fill 20 51 -139 24 51 -139 minecraft:water[level=0]
fill 27 51 -139 28 51 -139 minecraft:air
fill 17 51 -140 24 51 -140 minecraft:water[level=0]
fill 14 51 -141 21 51 -141 minecraft:water[level=0]
fill 11 51 -142 19 51 -142 minecraft:water[level=0]
fill 10 51 -143 16 51 -143 minecraft:water[level=0]
fill 9 51 -144 13 51 -144 minecraft:water[level=0]
fill 9 51 -145 11 51 -145 minecraft:water[level=0]
fill 43 51 -165 45 51 -165 minecraft:air
fill 42 51 -166 45 51 -166 minecraft:air
fill 43 51 -167 44 51 -167 minecraft:air
setblock 64 51 -169 minecraft:air
fill 63 51 -170 66 51 -170 minecraft:air
fill 63 51 -171 66 51 -171 minecraft:air
fill 64 51 -172 65 51 -172 minecraft:air
fill 69 51 -173 71 51 -173 minecraft:air
fill 67 51 -174 71 51 -174 minecraft:air
fill 65 51 -175 69 51 -175 minecraft:air
fill 63 51 -176 68 51 -176 minecraft:air
fill 62 51 -177 65 51 -177 minecraft:air
fill 61 51 -178 64 51 -178 minecraft:air
setblock 70 51 -182 minecraft:air
fill 68 51 -183 70 51 -183 minecraft:air
fill 67 51 -184 69 51 -184 minecraft:air
fill 66 51 -185 69 51 -185 minecraft:air
fill 66 51 -186 68 51 -186 minecraft:air
fill 66 51 -187 67 51 -187 minecraft:air
setblock 66 51 -188 minecraft:air
setblock 39 50 -127 minecraft:air
setblock 38 50 -128 minecraft:air
fill 37 50 -129 38 50 -129 minecraft:air
fill 36 50 -130 37 50 -130 minecraft:air
setblock 35 50 -131 minecraft:glow_lichen[down=true,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
setblock 36 50 -131 minecraft:air
fill 34 50 -132 35 50 -132 minecraft:air
fill 33 50 -133 34 50 -133 minecraft:air
fill 31 50 -134 33 50 -134 minecraft:air
fill 30 50 -135 31 50 -135 minecraft:air
fill 28 50 -136 30 50 -136 minecraft:air
fill 27 50 -137 29 50 -137 minecraft:air
setblock 27 50 -138 minecraft:air
fill 22 50 -139 23 50 -139 minecraft:water[level=0]
fill 19 50 -140 24 50 -140 minecraft:water[level=0]
fill 17 50 -141 23 50 -141 minecraft:water[level=0]
fill 13 50 -142 20 50 -142 minecraft:water[level=0]
fill 10 50 -143 17 50 -143 minecraft:water[level=0]
fill 9 50 -144 15 50 -144 minecraft:water[level=0]
fill 9 50 -145 12 50 -145 minecraft:water[level=0]
fill 9 50 -146 10 50 -146 minecraft:water[level=0]
setblock 71 50 -160 minecraft:air
setblock 71 50 -161 minecraft:air
fill 42 50 -165 45 50 -165 minecraft:air
fill 41 50 -166 44 50 -166 minecraft:air
setblock 43 50 -167 minecraft:air
fill 61 50 -169 62 50 -169 minecraft:air
fill 60 50 -170 63 50 -170 minecraft:air
fill 60 50 -171 62 50 -171 minecraft:air
setblock 71 50 -172 minecraft:air
fill 69 50 -173 71 50 -173 minecraft:air
fill 66 50 -174 71 50 -174 minecraft:air
fill 64 50 -175 71 50 -175 minecraft:air
fill 62 50 -176 68 50 -176 minecraft:air
fill 61 50 -177 66 50 -177 minecraft:air
fill 59 50 -178 64 50 -178 minecraft:air
fill 58 50 -179 62 50 -179 minecraft:air
fill 58 50 -180 60 50 -180 minecraft:air
setblock 71 50 -182 minecraft:air
fill 69 50 -183 71 50 -183 minecraft:air
fill 68 50 -184 70 50 -184 minecraft:air
fill 67 50 -185 70 50 -185 minecraft:air
fill 67 50 -186 69 50 -186 minecraft:air
fill 67 50 -187 68 50 -187 minecraft:air
setblock 67 50 -188 minecraft:air
fill 24 50 -189 26 50 -189 minecraft:air
fill 24 50 -190 27 50 -190 minecraft:air
setblock 39 49 -128 minecraft:air
setblock 38 49 -129 minecraft:air
fill 37 49 -130 38 49 -130 minecraft:air
fill 36 49 -131 37 49 -131 minecraft:air
fill 35 49 -132 36 49 -132 minecraft:air
fill 34 49 -133 35 49 -133 minecraft:air
fill 33 49 -134 34 49 -134 minecraft:air
fill 31 49 -135 33 49 -135 minecraft:air
fill 29 49 -136 32 49 -136 minecraft:air
fill 27 49 -137 30 49 -137 minecraft:air
fill 27 49 -138 29 49 -138 minecraft:air
fill 27 49 -139 28 49 -139 minecraft:air
setblock 22 49 -140 minecraft:water[level=0]
setblock 27 49 -140 minecraft:air
fill 20 49 -141 23 49 -141 minecraft:water[level=0]
fill 18 49 -142 22 49 -142 minecraft:water[level=0]
fill 12 49 -143 19 49 -143 minecraft:water[level=0]
fill 9 49 -144 16 49 -144 minecraft:water[level=0]
fill 9 49 -145 13 49 -145 minecraft:water[level=0]
fill 9 49 -146 11 49 -146 minecraft:water[level=0]
setblock 9 49 -147 minecraft:water[level=0]
setblock 71 49 -160 minecraft:air
setblock 71 49 -161 minecraft:air
setblock 71 49 -162 minecraft:air
fill 42 49 -165 44 49 -165 minecraft:air
fill 41 49 -166 44 49 -166 minecraft:air
setblock 51 49 -169 minecraft:air
fill 55 49 -169 56 49 -169 minecraft:air
fill 59 49 -169 62 49 -169 minecraft:air
fill 50 49 -170 52 49 -170 minecraft:air
fill 55 49 -170 63 49 -170 minecraft:air
fill 48 49 -171 52 49 -171 minecraft:air
fill 58 49 -171 63 49 -171 minecraft:air
fill 48 49 -172 51 49 -172 minecraft:air
setblock 61 49 -172 minecraft:air
fill 47 49 -173 50 49 -173 minecraft:air
fill 70 49 -173 71 49 -173 minecraft:air
fill 47 49 -174 49 49 -174 minecraft:air
fill 67 49 -174 71 49 -174 minecraft:air
fill 47 49 -175 49 49 -175 minecraft:air
fill 64 49 -175 69 49 -175 minecraft:air
fill 47 49 -176 48 49 -176 minecraft:air
fill 62 49 -176 67 49 -176 minecraft:air
fill 47 49 -177 48 49 -177 minecraft:air
fill 60 49 -177 66 49 -177 minecraft:air
fill 59 49 -178 64 49 -178 minecraft:air
setblock 48 49 -179 minecraft:air
fill 58 49 -179 62 49 -179 minecraft:air
fill 47 49 -180 48 49 -180 minecraft:air
fill 57 49 -180 61 49 -180 minecraft:air
fill 47 49 -181 49 49 -181 minecraft:air
fill 56 49 -181 59 49 -181 minecraft:air
fill 47 49 -182 48 49 -182 minecraft:air
fill 56 49 -182 57 49 -182 minecraft:air
fill 47 49 -183 48 49 -183 minecraft:air
fill 70 49 -183 71 49 -183 minecraft:air
fill 46 49 -184 48 49 -184 minecraft:air
fill 69 49 -184 71 49 -184 minecraft:air
fill 46 49 -185 48 49 -185 minecraft:air
fill 68 49 -185 71 49 -185 minecraft:air
fill 46 49 -186 48 49 -186 minecraft:air
fill 68 49 -186 70 49 -186 minecraft:air
fill 24 49 -187 26 49 -187 minecraft:air
fill 44 49 -187 46 49 -187 minecraft:air
fill 67 49 -187 69 49 -187 minecraft:air
fill 23 49 -188 26 49 -188 minecraft:air
fill 43 49 -188 47 49 -188 minecraft:air
fill 67 49 -188 68 49 -188 minecraft:air
fill 23 49 -189 27 49 -189 minecraft:air
fill 42 49 -189 46 49 -189 minecraft:air
setblock 67 49 -189 minecraft:air
fill 23 49 -190 27 49 -190 minecraft:air
fill 41 49 -190 46 49 -190 minecraft:air
setblock 40 48 -127 minecraft:air
setblock 40 48 -128 minecraft:air
setblock 39 48 -129 minecraft:air
fill 38 48 -130 39 48 -130 minecraft:air
fill 37 48 -131 38 48 -131 minecraft:air
fill 36 48 -132 37 48 -132 minecraft:air
fill 35 48 -133 36 48 -133 minecraft:air
fill 34 48 -134 35 48 -134 minecraft:air
fill 32 48 -135 34 48 -135 minecraft:air
fill 31 48 -136 33 48 -136 minecraft:air
fill 29 48 -137 32 48 -137 minecraft:air
fill 27 48 -138 30 48 -138 minecraft:air
fill 25 48 -139 29 48 -139 minecraft:air
fill 26 48 -140 28 48 -140 minecraft:air
setblock 22 48 -141 minecraft:water[level=0]
fill 21 48 -142 22 48 -142 minecraft:water[level=0]
fill 19 48 -143 20 48 -143 minecraft:water[level=0]
fill 10 48 -144 17 48 -144 minecraft:water[level=0]
fill 9 48 -145 14 48 -145 minecraft:water[level=0]
fill 9 48 -146 11 48 -146 minecraft:water[level=0]
fill 9 48 -147 10 48 -147 minecraft:water[level=0]
setblock 71 48 -160 minecraft:air
setblock 71 48 -161 minecraft:air
setblock 43 48 -164 minecraft:air
fill 41 48 -165 44 48 -165 minecraft:air
fill 40 48 -166 43 48 -166 minecraft:air
fill 54 48 -168 57 48 -168 minecraft:air
fill 50 48 -169 52 48 -169 minecraft:air
fill 54 48 -169 60 48 -169 minecraft:air
fill 49 48 -170 61 48 -170 minecraft:air
fill 48 48 -171 53 48 -171 minecraft:air
fill 55 48 -171 61 48 -171 minecraft:air
fill 47 48 -172 52 48 -172 minecraft:air
setblock 60 48 -172 minecraft:air
fill 47 48 -173 50 48 -173 minecraft:air
fill 46 48 -174 50 48 -174 minecraft:air
fill 46 48 -175 49 48 -175 minecraft:air
fill 46 48 -176 49 48 -176 minecraft:air
fill 63 48 -176 65 48 -176 minecraft:air
fill 46 48 -177 49 48 -177 minecraft:air
fill 60 48 -177 65 48 -177 minecraft:air
fill 46 48 -178 49 48 -178 minecraft:air
fill 59 48 -178 63 48 -178 minecraft:air
fill 46 48 -179 49 48 -179 minecraft:air
fill 57 48 -179 62 48 -179 minecraft:air
fill 46 48 -180 49 48 -180 minecraft:air
fill 56 48 -180 60 48 -180 minecraft:air
fill 46 48 -181 49 48 -181 minecraft:air
fill 55 48 -181 58 48 -181 minecraft:air
setblock 59 48 -181 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
fill 46 48 -182 49 48 -182 minecraft:air
fill 55 48 -182 58 48 -182 minecraft:air
fill 46 48 -183 49 48 -183 minecraft:air
fill 54 48 -183 56 48 -183 minecraft:air
setblock 71 48 -183 minecraft:air
fill 45 48 -184 49 48 -184 minecraft:air
fill 54 48 -184 55 48 -184 minecraft:air
fill 60 48 -184 61 48 -184 minecraft:air
fill 70 48 -184 71 48 -184 minecraft:air
fill 24 48 -185 25 48 -185 minecraft:air
fill 45 48 -185 49 48 -185 minecraft:air
fill 54 48 -185 65 48 -185 minecraft:air
fill 69 48 -185 71 48 -185 minecraft:air
fill 23 48 -186 26 48 -186 minecraft:air
fill 45 48 -186 48 48 -186 minecraft:air
fill 54 48 -186 71 48 -186 minecraft:air
fill 23 48 -187 26 48 -187 minecraft:air
fill 44 48 -187 47 48 -187 minecraft:air
fill 53 48 -187 70 48 -187 minecraft:air
fill 23 48 -188 27 48 -188 minecraft:air
fill 43 48 -188 47 48 -188 minecraft:air
fill 52 48 -188 69 48 -188 minecraft:air
fill 23 48 -189 27 48 -189 minecraft:air
fill 42 48 -189 47 48 -189 minecraft:air
fill 50 48 -189 68 48 -189 minecraft:air
fill 23 48 -190 26 48 -190 minecraft:air
fill 41 48 -190 46 48 -190 minecraft:air
fill 48 48 -190 68 48 -190 minecraft:air
setblock 41 47 -127 minecraft:air
fill 40 47 -128 41 47 -128 minecraft:air
fill 40 47 -129 41 47 -129 minecraft:air
fill 39 47 -130 40 47 -130 minecraft:air
fill 38 47 -131 40 47 -131 minecraft:air
fill 37 47 -132 39 47 -132 minecraft:air
fill 36 47 -133 38 47 -133 minecraft:air
fill 35 47 -134 37 47 -134 minecraft:air
fill 34 47 -135 36 47 -135 minecraft:air
fill 32 47 -136 35 47 -136 minecraft:air
fill 30 47 -137 34 47 -137 minecraft:air
fill 28 47 -138 33 47 -138 minecraft:air
fill 27 47 -139 31 47 -139 minecraft:air
fill 26 47 -140 30 47 -140 minecraft:air
fill 25 47 -141 27 47 -141 minecraft:air
fill 9 47 -145 11 47 -145 minecraft:water[level=0]
fill 9 47 -146 12 47 -146 minecraft:water[level=0]
fill 9 47 -147 10 47 -147 minecraft:water[level=0]
fill 42 47 -164 43 47 -164 minecraft:air
fill 41 47 -165 44 47 -165 minecraft:air
fill 40 47 -166 43 47 -166 minecraft:air
setblock 48 47 -174 minecraft:air
fill 46 47 -175 49 47 -175 minecraft:air
fill 46 47 -176 49 47 -176 minecraft:air
fill 46 47 -177 49 47 -177 minecraft:air
fill 46 47 -178 49 47 -178 minecraft:air
fill 59 47 -178 60 47 -178 minecraft:air
fill 46 47 -179 49 47 -179 minecraft:air
fill 57 47 -179 61 47 -179 minecraft:air
fill 46 47 -180 49 47 -180 minecraft:air
fill 56 47 -180 60 47 -180 minecraft:air
fill 46 47 -181 49 47 -181 minecraft:air
fill 55 47 -181 59 47 -181 minecraft:air
fill 46 47 -182 49 47 -182 minecraft:air
fill 54 47 -182 58 47 -182 minecraft:air
fill 46 47 -183 49 47 -183 minecraft:air
fill 54 47 -183 57 47 -183 minecraft:air
fill 23 47 -184 25 47 -184 minecraft:air
fill 53 47 -184 56 47 -184 minecraft:air
fill 58 47 -184 63 47 -184 minecraft:air
setblock 71 47 -184 minecraft:air
fill 23 47 -185 26 47 -185 minecraft:air
fill 53 47 -185 66 47 -185 minecraft:air
fill 70 47 -185 71 47 -185 minecraft:air
fill 23 47 -186 26 47 -186 minecraft:air
fill 54 47 -186 67 47 -186 minecraft:air
fill 69 47 -186 71 47 -186 minecraft:air
fill 23 47 -187 26 47 -187 minecraft:air
fill 53 47 -187 71 47 -187 minecraft:air
fill 23 47 -188 26 47 -188 minecraft:air
fill 51 47 -188 70 47 -188 minecraft:air
fill 24 47 -189 26 47 -189 minecraft:air
fill 49 47 -189 68 47 -189 minecraft:air
fill 42 47 -190 43 47 -190 minecraft:air
fill 47 47 -190 68 47 -190 minecraft:air
setblock 42 46 -127 minecraft:air
fill 41 46 -128 42 46 -128 minecraft:air
fill 40 46 -129 42 46 -129 minecraft:air
fill 40 46 -130 41 46 -130 minecraft:air
fill 39 46 -131 41 46 -131 minecraft:air
fill 38 46 -132 40 46 -132 minecraft:air
fill 37 46 -133 40 46 -133 minecraft:air
fill 36 46 -134 39 46 -134 minecraft:air
fill 35 46 -135 38 46 -135 minecraft:air
fill 33 46 -136 37 46 -136 minecraft:air
fill 32 46 -137 36 46 -137 minecraft:air
fill 30 46 -138 35 46 -138 minecraft:air
fill 29 46 -139 33 46 -139 minecraft:air
fill 28 46 -140 32 46 -140 minecraft:air
fill 27 46 -141 29 46 -141 minecraft:air
setblock 26 46 -142 minecraft:air
setblock 10 46 -147 minecraft:water[level=0]
fill 42 46 -164 43 46 -164 minecraft:air
fill 41 46 -165 43 46 -165 minecraft:air
fill 40 46 -166 43 46 -166 minecraft:air
fill 56 46 -180 58 46 -180 minecraft:air
fill 55 46 -181 58 46 -181 minecraft:air
setblock 64 46 -181 minecraft:air
fill 54 46 -182 57 46 -182 minecraft:air
fill 63 46 -182 64 46 -182 minecraft:air
fill 23 46 -183 25 46 -183 minecraft:air
fill 53 46 -183 57 46 -183 minecraft:air
fill 60 46 -183 65 46 -183 minecraft:air
fill 23 46 -184 26 46 -184 minecraft:air
fill 53 46 -184 67 46 -184 minecraft:air
setblock 71 46 -184 minecraft:air
fill 23 46 -185 26 46 -185 minecraft:air
fill 53 46 -185 68 46 -185 minecraft:air
setblock 71 46 -185 minecraft:air
fill 23 46 -186 26 46 -186 minecraft:air
fill 53 46 -186 68 46 -186 minecraft:air
setblock 71 46 -186 minecraft:air
fill 23 46 -187 26 46 -187 minecraft:air
fill 52 46 -187 68 46 -187 minecraft:air
setblock 71 46 -187 minecraft:air
fill 50 46 -188 68 46 -188 minecraft:air
fill 48 46 -189 68 46 -189 minecraft:air
fill 46 46 -190 68 46 -190 minecraft:air
fill 42 45 -127 43 45 -127 minecraft:air
fill 42 45 -128 43 45 -128 minecraft:air
fill 41 45 -129 43 45 -129 minecraft:air
fill 40 45 -130 42 45 -130 minecraft:air
fill 39 45 -131 42 45 -131 minecraft:air
fill 39 45 -132 41 45 -132 minecraft:air
fill 38 45 -133 40 45 -133 minecraft:air
fill 37 45 -134 40 45 -134 minecraft:air
fill 36 45 -135 39 45 -135 minecraft:air
fill 35 45 -136 38 45 -136 minecraft:air
fill 33 45 -137 37 45 -137 minecraft:air
fill 32 45 -138 36 45 -138 minecraft:air
fill 31 45 -139 35 45 -139 minecraft:air
fill 30 45 -140 33 45 -140 minecraft:air
fill 29 45 -141 31 45 -141 minecraft:air
setblock 28 45 -142 minecraft:air
fill 42 45 -164 43 45 -164 minecraft:air
fill 40 45 -165 43 45 -165 minecraft:air
fill 41 45 -166 42 45 -166 minecraft:air
setblock 64 45 -180 minecraft:air
setblock 24 45 -181 minecraft:air
setblock 25 45 -181 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=true,waterlogged=false,west=false]
fill 63 45 -181 65 45 -181 minecraft:air
fill 23 45 -182 26 45 -182 minecraft:air
fill 54 45 -182 56 45 -182 minecraft:air
fill 60 45 -182 66 45 -182 minecraft:air
fill 23 45 -183 26 45 -183 minecraft:air
fill 54 45 -183 56 45 -183 minecraft:air
fill 59 45 -183 67 45 -183 minecraft:air
fill 23 45 -184 26 45 -184 minecraft:air
fill 53 45 -184 68 45 -184 minecraft:air
fill 23 45 -185 26 45 -185 minecraft:air
fill 53 45 -185 68 45 -185 minecraft:air
fill 24 45 -186 25 45 -186 minecraft:air
fill 53 45 -186 68 45 -186 minecraft:air
fill 51 45 -187 68 45 -187 minecraft:air
fill 49 45 -188 68 45 -188 minecraft:air
fill 47 45 -189 68 45 -189 minecraft:air
fill 46 45 -190 68 45 -190 minecraft:air
forceload remove 8 -190 71 -127
tellraw @a {"text":"Campus zurueck a29 fertig.","color":"green"}
