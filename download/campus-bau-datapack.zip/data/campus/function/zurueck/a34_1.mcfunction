setblock 329 85 -184 minecraft:white_concrete
setblock 330 85 -186 minecraft:white_concrete
setblock 331 85 -189 minecraft:white_concrete
fill 331 71 -127 333 71 -127 minecraft:air
fill 341 71 -127 343 71 -127 minecraft:air
setblock 332 71 -128 minecraft:air
setblock 342 71 -128 minecraft:air
fill 330 70 -127 334 70 -127 minecraft:air
fill 340 70 -127 344 70 -127 minecraft:air
fill 331 70 -128 333 70 -128 minecraft:air
fill 341 70 -128 343 70 -128 minecraft:air
fill 331 69 -127 333 69 -127 minecraft:air
fill 341 69 -127 343 69 -127 minecraft:air
setblock 332 69 -128 minecraft:air
setblock 342 69 -128 minecraft:air
fill 349 66 -127 351 66 -127 minecraft:air
setblock 354 66 -127 minecraft:air
setblock 356 66 -127 minecraft:air
fill 358 66 -127 362 66 -127 minecraft:air
fill 364 66 -127 365 66 -127 minecraft:air
setblock 367 66 -127 minecraft:air
fill 369 66 -127 371 66 -127 minecraft:air
setblock 376 66 -127 minecraft:air
setblock 378 66 -127 minecraft:air
fill 384 66 -127 385 66 -127 minecraft:air
setblock 388 66 -127 minecraft:air
setblock 349 66 -128 minecraft:air
setblock 353 66 -128 minecraft:air
fill 356 66 -128 357 66 -128 minecraft:air
fill 364 66 -128 365 66 -128 minecraft:air
fill 367 66 -128 368 66 -128 minecraft:air
setblock 372 66 -128 minecraft:air
setblock 378 66 -128 minecraft:air
fill 384 66 -128 385 66 -128 minecraft:air
fill 387 66 -128 391 66 -128 minecraft:air
setblock 348 66 -129 minecraft:air
setblock 351 66 -129 minecraft:air
fill 353 66 -129 356 66 -129 minecraft:air
setblock 359 66 -129 minecraft:air
fill 361 66 -129 362 66 -129 minecraft:air
fill 364 66 -129 366 66 -129 minecraft:air
fill 368 66 -129 370 66 -129 minecraft:air
fill 373 66 -129 374 66 -129 minecraft:air
fill 376 66 -129 378 66 -129 minecraft:air
setblock 384 66 -129 minecraft:air
setblock 386 66 -129 minecraft:air
fill 390 66 -129 391 66 -129 minecraft:air
fill 349 66 -130 351 66 -130 minecraft:air
fill 353 66 -130 356 66 -130 minecraft:air
fill 358 66 -130 360 66 -130 minecraft:air
setblock 362 66 -130 minecraft:air
fill 364 66 -130 365 66 -130 minecraft:air
setblock 367 66 -130 minecraft:air
setblock 370 66 -130 minecraft:air
setblock 373 66 -130 minecraft:air
fill 377 66 -130 378 66 -130 minecraft:air
setblock 384 66 -130 minecraft:air
fill 386 66 -130 388 66 -130 minecraft:air
setblock 391 66 -130 minecraft:air
fill 348 66 -131 350 66 -131 minecraft:air
setblock 354 66 -131 minecraft:air
fill 357 66 -131 359 66 -131 minecraft:air
setblock 362 66 -131 minecraft:air
fill 367 66 -131 368 66 -131 minecraft:air
fill 370 66 -131 371 66 -131 minecraft:air
fill 373 66 -131 374 66 -131 minecraft:air
setblock 376 66 -131 minecraft:air
setblock 378 66 -131 minecraft:air
fill 384 66 -131 386 66 -131 minecraft:air
fill 388 66 -131 391 66 -131 minecraft:air
fill 349 66 -132 350 66 -132 minecraft:air
setblock 352 66 -132 minecraft:air
fill 355 66 -132 356 66 -132 minecraft:air
setblock 358 66 -132 minecraft:air
setblock 361 66 -132 minecraft:air
fill 364 66 -132 366 66 -132 minecraft:air
setblock 369 66 -132 minecraft:air
fill 372 66 -132 373 66 -132 minecraft:air
fill 375 66 -132 378 66 -132 minecraft:air
fill 388 66 -132 389 66 -132 minecraft:air
setblock 350 66 -133 minecraft:air
setblock 354 66 -133 minecraft:air
setblock 357 66 -133 minecraft:air
fill 364 66 -133 366 66 -133 minecraft:air
setblock 369 66 -133 minecraft:air
fill 372 66 -133 374 66 -133 minecraft:air
fill 388 66 -133 389 66 -133 minecraft:air
setblock 391 66 -133 minecraft:air
setblock 348 66 -134 minecraft:air
setblock 350 66 -134 minecraft:air
fill 352 66 -134 354 66 -134 minecraft:air
setblock 357 66 -134 minecraft:air
setblock 360 66 -134 minecraft:air
setblock 362 66 -134 minecraft:air
fill 364 66 -134 367 66 -134 minecraft:air
fill 371 66 -134 372 66 -134 minecraft:air
setblock 374 66 -134 minecraft:air
fill 376 66 -134 378 66 -134 minecraft:air
fill 385 66 -134 387 66 -134 minecraft:air
setblock 391 66 -134 minecraft:air
fill 348 66 -135 349 66 -135 minecraft:air
fill 351 66 -135 355 66 -135 minecraft:air
setblock 357 66 -135 minecraft:air
setblock 360 66 -135 minecraft:air
fill 363 66 -135 364 66 -135 minecraft:air
setblock 366 66 -135 minecraft:air
setblock 371 66 -135 minecraft:air
setblock 373 66 -135 minecraft:air
fill 375 66 -135 378 66 -135 minecraft:air
fill 384 66 -135 388 66 -135 minecraft:air
setblock 390 66 -135 minecraft:air
setblock 350 66 -136 minecraft:air
fill 353 66 -136 356 66 -136 minecraft:air
fill 358 66 -136 363 66 -136 minecraft:air
fill 366 66 -136 367 66 -136 minecraft:air
fill 374 66 -136 378 66 -136 minecraft:air
fill 386 66 -136 387 66 -136 minecraft:air
fill 389 66 -136 391 66 -136 minecraft:air
setblock 348 66 -137 minecraft:air
setblock 352 66 -137 minecraft:air
fill 355 66 -137 356 66 -137 minecraft:air
setblock 358 66 -137 minecraft:air
fill 360 66 -137 362 66 -137 minecraft:air
setblock 367 66 -137 minecraft:air
setblock 369 66 -137 minecraft:air
fill 376 66 -137 378 66 -137 minecraft:air
setblock 384 66 -137 minecraft:air
setblock 386 66 -137 minecraft:air
fill 388 66 -137 391 66 -137 minecraft:air
fill 348 66 -138 350 66 -138 minecraft:air
fill 352 66 -138 354 66 -138 minecraft:air
fill 356 66 -138 357 66 -138 minecraft:air
setblock 359 66 -138 minecraft:air
fill 361 66 -138 362 66 -138 minecraft:air
fill 365 66 -138 369 66 -138 minecraft:air
fill 371 66 -138 373 66 -138 minecraft:air
setblock 375 66 -138 minecraft:air
setblock 378 66 -138 minecraft:air
fill 384 66 -138 387 66 -138 minecraft:air
setblock 390 66 -138 minecraft:air
fill 348 66 -139 349 66 -139 minecraft:air
fill 351 66 -139 352 66 -139 minecraft:air
fill 354 66 -139 358 66 -139 minecraft:air
setblock 362 66 -139 minecraft:air
setblock 364 66 -139 minecraft:air
setblock 366 66 -139 minecraft:air
fill 368 66 -139 369 66 -139 minecraft:air
setblock 371 66 -139 minecraft:air
setblock 375 66 -139 minecraft:air
setblock 377 66 -139 minecraft:air
fill 384 66 -139 387 66 -139 minecraft:air
fill 389 66 -139 391 66 -139 minecraft:air
setblock 348 66 -140 minecraft:air
fill 350 66 -140 352 66 -140 minecraft:air
setblock 354 66 -140 minecraft:air
setblock 357 66 -140 minecraft:air
setblock 360 66 -140 minecraft:air
setblock 362 66 -140 minecraft:air
fill 365 66 -140 367 66 -140 minecraft:air
setblock 371 66 -140 minecraft:air
fill 373 66 -140 374 66 -140 minecraft:air
fill 376 66 -140 377 66 -140 minecraft:air
setblock 384 66 -140 minecraft:air
setblock 387 66 -140 minecraft:air
fill 390 66 -140 391 66 -140 minecraft:air
fill 348 66 -141 349 66 -141 minecraft:air
setblock 352 66 -141 minecraft:air
fill 356 66 -141 357 66 -141 minecraft:air
fill 359 66 -141 363 66 -141 minecraft:air
fill 365 66 -141 367 66 -141 minecraft:air
fill 369 66 -141 371 66 -141 minecraft:air
setblock 373 66 -141 minecraft:air
setblock 375 66 -141 minecraft:air
fill 377 66 -141 378 66 -141 minecraft:air
setblock 386 66 -141 minecraft:air
setblock 388 66 -141 minecraft:air
fill 390 66 -141 391 66 -141 minecraft:air
setblock 348 66 -142 minecraft:air
setblock 351 66 -142 minecraft:air
fill 354 66 -142 355 66 -142 minecraft:air
fill 357 66 -142 364 66 -142 minecraft:air
fill 367 66 -142 368 66 -142 minecraft:air
fill 372 66 -142 373 66 -142 minecraft:air
fill 375 66 -142 376 66 -142 minecraft:air
setblock 378 66 -142 minecraft:air
fill 384 66 -142 386 66 -142 minecraft:air
setblock 391 66 -142 minecraft:air
setblock 349 66 -143 minecraft:air
setblock 351 66 -143 minecraft:air
setblock 353 66 -143 minecraft:air
fill 355 66 -143 358 66 -143 minecraft:air
setblock 361 66 -143 minecraft:air
fill 365 66 -143 369 66 -143 minecraft:air
fill 371 66 -143 372 66 -143 minecraft:air
fill 377 66 -143 378 66 -143 minecraft:air
fill 384 66 -143 385 66 -143 minecraft:air
setblock 389 66 -143 minecraft:air
setblock 348 66 -144 minecraft:air
fill 350 66 -144 351 66 -144 minecraft:air
fill 355 66 -144 356 66 -144 minecraft:air
setblock 358 66 -144 minecraft:air
fill 360 66 -144 363 66 -144 minecraft:air
setblock 365 66 -144 minecraft:air
setblock 367 66 -144 minecraft:air
setblock 370 66 -144 minecraft:air
setblock 372 66 -144 minecraft:air
fill 375 66 -144 378 66 -144 minecraft:air
setblock 384 66 -144 minecraft:air
fill 387 66 -144 388 66 -144 minecraft:air
setblock 390 66 -144 minecraft:air
fill 350 66 -145 351 66 -145 minecraft:air
fill 353 66 -145 356 66 -145 minecraft:air
fill 358 66 -145 360 66 -145 minecraft:air
setblock 362 66 -145 minecraft:air
setblock 364 66 -145 minecraft:air
fill 369 66 -145 370 66 -145 minecraft:air
setblock 374 66 -145 minecraft:air
setblock 384 66 -145 minecraft:air
fill 387 66 -145 388 66 -145 minecraft:air
setblock 391 66 -145 minecraft:air
setblock 350 66 -146 minecraft:air
fill 352 66 -146 353 66 -146 minecraft:air
fill 355 66 -146 360 66 -146 minecraft:air
setblock 362 66 -146 minecraft:air
fill 364 66 -146 368 66 -146 minecraft:air
fill 370 66 -146 375 66 -146 minecraft:air
fill 377 66 -146 378 66 -146 minecraft:air
setblock 384 66 -146 minecraft:air
fill 386 66 -146 389 66 -146 minecraft:air
setblock 348 66 -147 minecraft:air
fill 351 66 -147 353 66 -147 minecraft:air
fill 355 66 -147 356 66 -147 minecraft:air
fill 358 66 -147 360 66 -147 minecraft:air
setblock 362 66 -147 minecraft:air
fill 364 66 -147 367 66 -147 minecraft:air
setblock 370 66 -147 minecraft:air
setblock 373 66 -147 minecraft:air
fill 377 66 -147 378 66 -147 minecraft:air
fill 387 66 -147 389 66 -147 minecraft:air
fill 348 66 -148 354 66 -148 minecraft:air
fill 358 66 -148 360 66 -148 minecraft:air
setblock 365 66 -148 minecraft:air
setblock 369 66 -148 minecraft:air
setblock 371 66 -148 minecraft:air
fill 373 66 -148 375 66 -148 minecraft:air
fill 377 66 -148 378 66 -148 minecraft:air
fill 385 66 -148 386 66 -148 minecraft:air
fill 390 66 -148 391 66 -148 minecraft:air
fill 348 66 -149 350 66 -149 minecraft:air
fill 352 66 -149 353 66 -149 minecraft:air
fill 355 66 -149 356 66 -149 minecraft:air
setblock 358 66 -149 minecraft:air
fill 360 66 -149 361 66 -149 minecraft:air
fill 363 66 -149 364 66 -149 minecraft:air
fill 366 66 -149 367 66 -149 minecraft:air
setblock 372 66 -149 minecraft:air
fill 374 66 -149 378 66 -149 minecraft:air
fill 385 66 -149 386 66 -149 minecraft:air
fill 390 66 -149 391 66 -149 minecraft:air
setblock 348 66 -150 minecraft:air
setblock 351 66 -150 minecraft:air
setblock 354 66 -150 minecraft:air
fill 356 66 -150 359 66 -150 minecraft:air
setblock 361 66 -150 minecraft:air
fill 363 66 -150 367 66 -150 minecraft:air
setblock 370 66 -150 minecraft:air
fill 372 66 -150 373 66 -150 minecraft:air
fill 375 66 -150 376 66 -150 minecraft:air
setblock 378 66 -150 minecraft:air
fill 384 66 -150 389 66 -150 minecraft:air
fill 348 66 -151 357 66 -151 minecraft:air
setblock 362 66 -151 minecraft:air
setblock 364 66 -151 minecraft:air
setblock 367 66 -151 minecraft:air
fill 370 66 -151 371 66 -151 minecraft:air
fill 375 66 -151 376 66 -151 minecraft:air
setblock 378 66 -151 minecraft:air
fill 385 66 -151 386 66 -151 minecraft:air
fill 389 66 -151 391 66 -151 minecraft:air
setblock 349 66 -152 minecraft:air
setblock 351 66 -152 minecraft:air
setblock 354 66 -152 minecraft:air
fill 356 66 -152 359 66 -152 minecraft:air
fill 361 66 -152 363 66 -152 minecraft:air
setblock 365 66 -152 minecraft:air
setblock 372 66 -152 minecraft:air
setblock 376 66 -152 minecraft:air
setblock 378 66 -152 minecraft:air
fill 385 66 -152 387 66 -152 minecraft:air
setblock 389 66 -152 minecraft:air
fill 348 66 -153 349 66 -153 minecraft:air
setblock 352 66 -153 minecraft:air
fill 354 66 -153 355 66 -153 minecraft:air
fill 357 66 -153 358 66 -153 minecraft:air
setblock 361 66 -153 minecraft:air
setblock 363 66 -153 minecraft:air
setblock 366 66 -153 minecraft:air
setblock 371 66 -153 minecraft:air
setblock 373 66 -153 minecraft:air
fill 375 66 -153 376 66 -153 minecraft:air
setblock 378 66 -153 minecraft:air
setblock 386 66 -153 minecraft:air
setblock 388 66 -153 minecraft:air
fill 390 66 -153 391 66 -153 minecraft:air
setblock 348 66 -154 minecraft:air
fill 350 66 -154 353 66 -154 minecraft:air
fill 358 66 -154 359 66 -154 minecraft:air
setblock 361 66 -154 minecraft:air
setblock 363 66 -154 minecraft:air
fill 365 66 -154 366 66 -154 minecraft:air
fill 370 66 -154 376 66 -154 minecraft:air
setblock 378 66 -154 minecraft:air
fill 384 66 -154 385 66 -154 minecraft:air
fill 387 66 -154 388 66 -154 minecraft:air
setblock 348 66 -155 minecraft:air
fill 351 66 -155 356 66 -155 minecraft:air
fill 358 66 -155 360 66 -155 minecraft:air
setblock 362 66 -155 minecraft:air
fill 364 66 -155 365 66 -155 minecraft:air
setblock 368 66 -155 minecraft:air
fill 370 66 -155 372 66 -155 minecraft:air
fill 374 66 -155 375 66 -155 minecraft:air
setblock 378 66 -155 minecraft:air
setblock 386 66 -155 minecraft:air
setblock 388 66 -155 minecraft:air
fill 351 66 -156 353 66 -156 minecraft:air
fill 355 66 -156 359 66 -156 minecraft:air
fill 362 66 -156 366 66 -156 minecraft:air
fill 368 66 -156 370 66 -156 minecraft:air
setblock 372 66 -156 minecraft:air
fill 385 66 -156 387 66 -156 minecraft:air
setblock 389 66 -156 minecraft:air
setblock 391 66 -156 minecraft:air
fill 350 66 -157 351 66 -157 minecraft:air
fill 355 66 -157 357 66 -157 minecraft:air
setblock 359 66 -157 minecraft:air
fill 363 66 -157 365 66 -157 minecraft:air
fill 367 66 -157 370 66 -157 minecraft:air
fill 373 66 -157 374 66 -157 minecraft:air
fill 376 66 -157 378 66 -157 minecraft:air
fill 388 66 -157 391 66 -157 minecraft:air
fill 348 66 -158 349 66 -158 minecraft:air
setblock 351 66 -158 minecraft:air
setblock 353 66 -158 minecraft:air
setblock 356 66 -158 minecraft:air
fill 360 66 -158 364 66 -158 minecraft:air
fill 367 66 -158 368 66 -158 minecraft:air
setblock 370 66 -158 minecraft:air
fill 372 66 -158 378 66 -158 minecraft:air
fill 384 66 -158 387 66 -158 minecraft:air
setblock 348 66 -159 minecraft:air
setblock 350 66 -159 minecraft:air
setblock 352 66 -159 minecraft:air
fill 354 66 -159 356 66 -159 minecraft:air
setblock 358 66 -159 minecraft:air
fill 360 66 -159 362 66 -159 minecraft:air
fill 364 66 -159 365 66 -159 minecraft:air
setblock 367 66 -159 minecraft:air
fill 369 66 -159 373 66 -159 minecraft:air
fill 376 66 -159 378 66 -159 minecraft:air
setblock 384 66 -159 minecraft:air
fill 387 66 -159 391 66 -159 minecraft:air
setblock 349 66 -160 minecraft:air
fill 351 66 -160 353 66 -160 minecraft:air
setblock 358 66 -160 minecraft:air
setblock 360 66 -160 minecraft:air
setblock 362 66 -160 minecraft:air
fill 364 66 -160 366 66 -160 minecraft:air
fill 372 66 -160 373 66 -160 minecraft:air
fill 375 66 -160 376 66 -160 minecraft:air
setblock 378 66 -160 minecraft:air
fill 384 66 -160 389 66 -160 minecraft:air
setblock 391 66 -160 minecraft:air
setblock 350 66 -161 minecraft:air
fill 354 66 -161 357 66 -161 minecraft:air
fill 359 66 -161 366 66 -161 minecraft:air
setblock 368 66 -161 minecraft:air
setblock 384 66 -161 minecraft:air
fill 389 66 -161 391 66 -161 minecraft:air
setblock 348 66 -162 minecraft:air
fill 350 66 -162 353 66 -162 minecraft:air
setblock 355 66 -162 minecraft:air
setblock 357 66 -162 minecraft:air
fill 359 66 -162 360 66 -162 minecraft:air
fill 363 66 -162 364 66 -162 minecraft:air
setblock 367 66 -162 minecraft:air
fill 369 66 -162 374 66 -162 minecraft:air
fill 376 66 -162 377 66 -162 minecraft:air
fill 387 66 -162 389 66 -162 minecraft:air
setblock 391 66 -162 minecraft:air
setblock 349 66 -163 minecraft:air
fill 351 66 -163 352 66 -163 minecraft:air
fill 355 66 -163 356 66 -163 minecraft:air
fill 359 66 -163 360 66 -163 minecraft:air
setblock 364 66 -163 minecraft:air
fill 366 66 -163 367 66 -163 minecraft:air
setblock 373 66 -163 minecraft:air
setblock 375 66 -163 minecraft:air
setblock 377 66 -163 minecraft:air
setblock 384 66 -163 minecraft:air
fill 388 66 -163 391 66 -163 minecraft:air
setblock 350 66 -164 minecraft:air
fill 353 66 -164 355 66 -164 minecraft:air
fill 359 66 -164 361 66 -164 minecraft:air
setblock 364 66 -164 minecraft:air
fill 368 66 -164 369 66 -164 minecraft:air
fill 371 66 -164 374 66 -164 minecraft:air
setblock 376 66 -164 minecraft:air
setblock 378 66 -164 minecraft:air
fill 384 66 -164 387 66 -164 minecraft:air
fill 348 66 -165 349 66 -165 minecraft:air
fill 351 66 -165 352 66 -165 minecraft:air
fill 354 66 -165 362 66 -165 minecraft:air
setblock 364 66 -165 minecraft:air
fill 366 66 -165 371 66 -165 minecraft:air
setblock 373 66 -165 minecraft:air
fill 384 66 -165 385 66 -165 minecraft:air
setblock 389 66 -165 minecraft:air
fill 348 66 -166 350 66 -166 minecraft:air
fill 352 66 -166 353 66 -166 minecraft:air
setblock 356 66 -166 minecraft:air
setblock 359 66 -166 minecraft:air
fill 361 66 -166 364 66 -166 minecraft:air
fill 370 66 -166 371 66 -166 minecraft:air
setblock 374 66 -166 minecraft:air
setblock 378 66 -166 minecraft:air
fill 386 66 -166 387 66 -166 minecraft:air
fill 389 66 -166 391 66 -166 minecraft:air
fill 349 66 -167 350 66 -167 minecraft:air
setblock 352 66 -167 minecraft:air
setblock 354 66 -167 minecraft:air
setblock 356 66 -167 minecraft:air
fill 359 66 -167 361 66 -167 minecraft:air
setblock 364 66 -167 minecraft:air
setblock 366 66 -167 minecraft:air
fill 369 66 -167 370 66 -167 minecraft:air
setblock 373 66 -167 minecraft:air
fill 376 66 -167 378 66 -167 minecraft:air
fill 384 66 -167 386 66 -167 minecraft:air
setblock 388 66 -167 minecraft:air
fill 390 66 -167 391 66 -167 minecraft:air
fill 352 66 -168 355 66 -168 minecraft:air
fill 361 66 -168 363 66 -168 minecraft:air
fill 366 66 -168 370 66 -168 minecraft:air
fill 377 66 -168 378 66 -168 minecraft:air
fill 384 66 -168 387 66 -168 minecraft:air
fill 390 66 -168 391 66 -168 minecraft:air
fill 348 66 -169 350 66 -169 minecraft:air
fill 359 66 -169 365 66 -169 minecraft:air
fill 367 66 -169 368 66 -169 minecraft:air
fill 372 66 -169 374 66 -169 minecraft:air
setblock 378 66 -169 minecraft:air
fill 384 66 -169 386 66 -169 minecraft:air
fill 388 66 -169 391 66 -169 minecraft:air
fill 348 66 -170 350 66 -170 minecraft:air
setblock 352 66 -170 minecraft:air
fill 354 66 -170 356 66 -170 minecraft:air
setblock 358 66 -170 minecraft:air
fill 360 66 -170 361 66 -170 minecraft:air
fill 366 66 -170 367 66 -170 minecraft:air
setblock 369 66 -170 minecraft:air
fill 371 66 -170 373 66 -170 minecraft:air
setblock 378 66 -170 minecraft:air
setblock 386 66 -170 minecraft:air
fill 388 66 -170 391 66 -170 minecraft:air
setblock 348 66 -171 minecraft:air
fill 350 66 -171 351 66 -171 minecraft:air
fill 356 66 -171 357 66 -171 minecraft:air
setblock 360 66 -171 minecraft:air
setblock 362 66 -171 minecraft:air
fill 364 66 -171 369 66 -171 minecraft:air
fill 371 66 -171 373 66 -171 minecraft:air
setblock 375 66 -171 minecraft:air
setblock 378 66 -171 minecraft:air
fill 387 66 -171 390 66 -171 minecraft:air
setblock 349 66 -172 minecraft:air
fill 356 66 -172 360 66 -172 minecraft:air
fill 363 66 -172 364 66 -172 minecraft:air
fill 366 66 -172 367 66 -172 minecraft:air
setblock 370 66 -172 minecraft:air
setblock 373 66 -172 minecraft:air
setblock 378 66 -172 minecraft:air
setblock 385 66 -172 minecraft:air
setblock 388 66 -172 minecraft:air
fill 348 66 -173 349 66 -173 minecraft:air
setblock 351 66 -173 minecraft:air
fill 353 66 -173 354 66 -173 minecraft:air
setblock 356 66 -173 minecraft:air
fill 359 66 -173 360 66 -173 minecraft:air
fill 364 66 -173 365 66 -173 minecraft:air
setblock 367 66 -173 minecraft:air
fill 369 66 -173 370 66 -173 minecraft:air
setblock 372 66 -173 minecraft:air
setblock 378 66 -173 minecraft:air
setblock 384 66 -173 minecraft:air
setblock 386 66 -173 minecraft:air
fill 388 66 -173 389 66 -173 minecraft:air
fill 348 66 -174 353 66 -174 minecraft:air
setblock 356 66 -174 minecraft:air
fill 358 66 -174 359 66 -174 minecraft:air
fill 363 66 -174 366 66 -174 minecraft:air
setblock 369 66 -174 minecraft:air
setblock 371 66 -174 minecraft:air
fill 373 66 -174 375 66 -174 minecraft:air
fill 377 66 -174 378 66 -174 minecraft:air
setblock 386 66 -174 minecraft:air
fill 390 66 -174 391 66 -174 minecraft:air
setblock 348 66 -175 minecraft:air
setblock 351 66 -175 minecraft:air
setblock 353 66 -175 minecraft:air
fill 355 66 -175 358 66 -175 minecraft:air
fill 360 66 -175 362 66 -175 minecraft:air
fill 365 66 -175 366 66 -175 minecraft:air
setblock 369 66 -175 minecraft:air
setblock 371 66 -175 minecraft:air
setblock 374 66 -175 minecraft:air
fill 384 66 -175 385 66 -175 minecraft:air
fill 388 66 -175 389 66 -175 minecraft:air
setblock 391 66 -175 minecraft:air
fill 348 66 -176 349 66 -176 minecraft:air
setblock 353 66 -176 minecraft:air
fill 355 66 -176 357 66 -176 minecraft:air
setblock 360 66 -176 minecraft:air
setblock 362 66 -176 minecraft:air
fill 365 66 -176 369 66 -176 minecraft:air
fill 371 66 -176 372 66 -176 minecraft:air
setblock 375 66 -176 minecraft:air
fill 377 66 -176 378 66 -176 minecraft:air
setblock 384 66 -176 minecraft:air
setblock 387 66 -176 minecraft:air
setblock 389 66 -176 minecraft:air
setblock 391 66 -176 minecraft:air
fill 350 66 -177 351 66 -177 minecraft:air
fill 353 66 -177 355 66 -177 minecraft:air
fill 357 66 -177 358 66 -177 minecraft:air
setblock 360 66 -177 minecraft:air
fill 362 66 -177 363 66 -177 minecraft:air
fill 365 66 -177 366 66 -177 minecraft:air
setblock 372 66 -177 minecraft:air
fill 374 66 -177 375 66 -177 minecraft:air
fill 377 66 -177 378 66 -177 minecraft:air
fill 384 66 -177 385 66 -177 minecraft:air
fill 390 66 -177 391 66 -177 minecraft:air
setblock 348 66 -178 minecraft:air
fill 350 66 -178 355 66 -178 minecraft:air
fill 357 66 -178 359 66 -178 minecraft:air
setblock 361 66 -178 minecraft:air
setblock 364 66 -178 minecraft:air
setblock 366 66 -178 minecraft:air
fill 368 66 -178 369 66 -178 minecraft:air
setblock 372 66 -178 minecraft:air
fill 376 66 -178 377 66 -178 minecraft:air
fill 387 66 -178 389 66 -178 minecraft:air
setblock 391 66 -178 minecraft:air
setblock 348 66 -179 minecraft:air
fill 352 66 -179 354 66 -179 minecraft:air
setblock 357 66 -179 minecraft:air
fill 359 66 -179 360 66 -179 minecraft:air
fill 363 66 -179 364 66 -179 minecraft:air
fill 368 66 -179 369 66 -179 minecraft:air
setblock 372 66 -179 minecraft:air
fill 374 66 -179 378 66 -179 minecraft:air
fill 384 66 -179 387 66 -179 minecraft:air
setblock 390 66 -179 minecraft:air
setblock 348 66 -180 minecraft:air
fill 350 66 -180 351 66 -180 minecraft:air
fill 353 66 -180 357 66 -180 minecraft:air
setblock 360 66 -180 minecraft:air
fill 362 66 -180 365 66 -180 minecraft:air
fill 367 66 -180 368 66 -180 minecraft:air
fill 372 66 -180 374 66 -180 minecraft:air
fill 377 66 -180 378 66 -180 minecraft:air
fill 385 66 -180 386 66 -180 minecraft:air
setblock 388 66 -180 minecraft:air
fill 390 66 -180 391 66 -180 minecraft:air
fill 348 66 -181 350 66 -181 minecraft:air
setblock 354 66 -181 minecraft:air
setblock 357 66 -181 minecraft:air
fill 359 66 -181 361 66 -181 minecraft:air
fill 366 66 -181 368 66 -181 minecraft:air
fill 370 66 -181 371 66 -181 minecraft:air
setblock 373 66 -181 minecraft:air
setblock 376 66 -181 minecraft:air
setblock 386 66 -181 minecraft:air
fill 388 66 -181 390 66 -181 minecraft:air
setblock 350 66 -182 minecraft:air
setblock 353 66 -182 minecraft:air
fill 355 66 -182 361 66 -182 minecraft:air
fill 363 66 -182 365 66 -182 minecraft:air
fill 368 66 -182 369 66 -182 minecraft:air
fill 371 66 -182 372 66 -182 minecraft:air
fill 375 66 -182 377 66 -182 minecraft:air
fill 386 66 -182 389 66 -182 minecraft:air
fill 348 66 -183 349 66 -183 minecraft:air
fill 351 66 -183 355 66 -183 minecraft:air
fill 359 66 -183 361 66 -183 minecraft:air
fill 364 66 -183 366 66 -183 minecraft:air
setblock 368 66 -183 minecraft:air
fill 371 66 -183 373 66 -183 minecraft:air
fill 377 66 -183 378 66 -183 minecraft:air
fill 384 66 -183 385 66 -183 minecraft:air
fill 387 66 -183 388 66 -183 minecraft:air
fill 348 66 -184 349 66 -184 minecraft:air
fill 352 66 -184 355 66 -184 minecraft:air
setblock 358 66 -184 minecraft:air
setblock 361 66 -184 minecraft:air
setblock 364 66 -184 minecraft:air
setblock 367 66 -184 minecraft:air
setblock 369 66 -184 minecraft:air
setblock 371 66 -184 minecraft:air
setblock 373 66 -184 minecraft:air
fill 384 66 -184 386 66 -184 minecraft:air
setblock 388 66 -184 minecraft:air
fill 390 66 -184 391 66 -184 minecraft:air
setblock 348 66 -185 minecraft:air
fill 350 66 -185 352 66 -185 minecraft:air
setblock 354 66 -185 minecraft:air
setblock 356 66 -185 minecraft:air
fill 358 66 -185 360 66 -185 minecraft:air
setblock 364 66 -185 minecraft:air
fill 366 66 -185 369 66 -185 minecraft:air
fill 371 66 -185 372 66 -185 minecraft:air
setblock 378 66 -185 minecraft:air
fill 384 66 -185 385 66 -185 minecraft:air
setblock 388 66 -185 minecraft:air
fill 390 66 -185 391 66 -185 minecraft:air
setblock 350 66 -186 minecraft:air
fill 353 66 -186 354 66 -186 minecraft:air
fill 356 66 -186 357 66 -186 minecraft:air
fill 360 66 -186 361 66 -186 minecraft:air
fill 364 66 -186 367 66 -186 minecraft:air
setblock 371 66 -186 minecraft:air
setblock 375 66 -186 minecraft:air
setblock 378 66 -186 minecraft:air
fill 384 66 -186 391 66 -186 minecraft:air
fill 348 66 -187 350 66 -187 minecraft:air
setblock 352 66 -187 minecraft:air
fill 354 66 -187 355 66 -187 minecraft:air
setblock 358 66 -187 minecraft:air
setblock 360 66 -187 minecraft:air
setblock 362 66 -187 minecraft:air
fill 364 66 -187 367 66 -187 minecraft:air
fill 369 66 -187 370 66 -187 minecraft:air
setblock 372 66 -187 minecraft:air
fill 376 66 -187 378 66 -187 minecraft:air
setblock 388 66 -187 minecraft:air
fill 390 66 -187 391 66 -187 minecraft:air
setblock 348 66 -188 minecraft:air
fill 350 66 -188 351 66 -188 minecraft:air
fill 353 66 -188 354 66 -188 minecraft:air
fill 356 66 -188 357 66 -188 minecraft:air
setblock 359 66 -188 minecraft:air
setblock 361 66 -188 minecraft:air
setblock 364 66 -188 minecraft:air
fill 367 66 -188 368 66 -188 minecraft:air
fill 370 66 -188 373 66 -188 minecraft:air
fill 375 66 -188 376 66 -188 minecraft:air
setblock 384 66 -188 minecraft:air
fill 386 66 -188 387 66 -188 minecraft:air
setblock 389 66 -188 minecraft:air
setblock 391 66 -188 minecraft:air
fill 352 66 -189 355 66 -189 minecraft:air
fill 358 66 -189 363 66 -189 minecraft:air
fill 365 66 -189 369 66 -189 minecraft:air
fill 371 66 -189 375 66 -189 minecraft:air
fill 377 66 -189 378 66 -189 minecraft:air
setblock 385 66 -189 minecraft:air
fill 387 66 -189 388 66 -189 minecraft:air
setblock 390 66 -189 minecraft:air
fill 348 66 -190 350 66 -190 minecraft:air
fill 352 66 -190 353 66 -190 minecraft:air
setblock 355 66 -190 minecraft:air
fill 358 66 -190 359 66 -190 minecraft:air
setblock 361 66 -190 minecraft:air
setblock 363 66 -190 minecraft:air
fill 366 66 -190 367 66 -190 minecraft:air
fill 370 66 -190 371 66 -190 minecraft:air
fill 374 66 -190 375 66 -190 minecraft:air
setblock 378 66 -190 minecraft:air
setblock 384 66 -190 minecraft:air
setblock 388 66 -190 minecraft:air
fill 390 66 -190 391 66 -190 minecraft:air
fill 328 65 -127 391 65 -127 minecraft:air
fill 328 65 -128 391 65 -128 minecraft:air
fill 328 65 -129 391 65 -129 minecraft:air
fill 328 65 -130 391 65 -130 minecraft:air
fill 328 65 -131 391 65 -131 minecraft:air
fill 328 65 -132 391 65 -132 minecraft:air
fill 328 65 -133 391 65 -133 minecraft:air
fill 328 65 -134 391 65 -134 minecraft:air
fill 328 65 -135 391 65 -135 minecraft:air
fill 328 65 -136 391 65 -136 minecraft:air
fill 328 65 -137 391 65 -137 minecraft:air
fill 328 65 -138 391 65 -138 minecraft:air
fill 328 65 -139 391 65 -139 minecraft:air
fill 328 65 -140 391 65 -140 minecraft:air
fill 328 65 -141 391 65 -141 minecraft:air
fill 328 65 -142 391 65 -142 minecraft:air
fill 328 65 -143 391 65 -143 minecraft:air
fill 328 65 -144 391 65 -144 minecraft:air
fill 328 65 -145 391 65 -145 minecraft:air
fill 328 65 -146 391 65 -146 minecraft:air
fill 328 65 -147 391 65 -147 minecraft:air
fill 328 65 -148 391 65 -148 minecraft:air
fill 328 65 -149 391 65 -149 minecraft:air
fill 328 65 -150 391 65 -150 minecraft:air
fill 328 65 -151 391 65 -151 minecraft:air
fill 328 65 -152 391 65 -152 minecraft:air
fill 328 65 -153 391 65 -153 minecraft:air
fill 328 65 -154 391 65 -154 minecraft:air
fill 328 65 -155 391 65 -155 minecraft:air
fill 328 65 -156 391 65 -156 minecraft:air
fill 328 65 -157 391 65 -157 minecraft:air
fill 328 65 -158 391 65 -158 minecraft:air
fill 328 65 -159 391 65 -159 minecraft:air
fill 328 65 -160 391 65 -160 minecraft:air
fill 328 65 -161 391 65 -161 minecraft:air
fill 328 65 -162 391 65 -162 minecraft:air
setblock 328 65 -163 minecraft:stone
fill 329 65 -163 391 65 -163 minecraft:air
setblock 328 65 -164 minecraft:stone
fill 329 65 -164 391 65 -164 minecraft:air
fill 328 65 -165 391 65 -165 minecraft:air
fill 328 65 -166 391 65 -166 minecraft:air
fill 328 65 -167 391 65 -167 minecraft:air
fill 329 65 -168 391 65 -168 minecraft:air
fill 329 65 -169 391 65 -169 minecraft:air
fill 330 65 -170 391 65 -170 minecraft:air
fill 331 65 -171 391 65 -171 minecraft:air
fill 332 65 -172 391 65 -172 minecraft:air
fill 332 65 -173 391 65 -173 minecraft:air
fill 333 65 -174 391 65 -174 minecraft:air
fill 334 65 -175 391 65 -175 minecraft:air
fill 334 65 -176 391 65 -176 minecraft:air
fill 335 65 -177 391 65 -177 minecraft:air
fill 336 65 -178 391 65 -178 minecraft:air
fill 336 65 -179 391 65 -179 minecraft:air
fill 337 65 -180 391 65 -180 minecraft:air
fill 337 65 -181 391 65 -181 minecraft:air
fill 338 65 -182 391 65 -182 minecraft:air
fill 338 65 -183 391 65 -183 minecraft:air
fill 339 65 -184 391 65 -184 minecraft:air
fill 339 65 -185 391 65 -185 minecraft:air
fill 340 65 -186 391 65 -186 minecraft:air
fill 340 65 -187 391 65 -187 minecraft:air
fill 341 65 -188 391 65 -188 minecraft:air
fill 341 65 -189 391 65 -189 minecraft:air
fill 342 65 -190 391 65 -190 minecraft:air
fill 328 64 -127 391 64 -127 minecraft:air
fill 328 64 -128 391 64 -128 minecraft:air
fill 328 64 -129 391 64 -129 minecraft:air
fill 328 64 -130 391 64 -130 minecraft:air
fill 328 64 -131 391 64 -131 minecraft:air
fill 328 64 -132 391 64 -132 minecraft:air
fill 328 64 -133 391 64 -133 minecraft:air
fill 328 64 -134 391 64 -134 minecraft:air
fill 328 64 -135 391 64 -135 minecraft:air
fill 328 64 -136 391 64 -136 minecraft:air
fill 328 64 -137 391 64 -137 minecraft:air
fill 328 64 -138 391 64 -138 minecraft:air
fill 328 64 -139 391 64 -139 minecraft:air
fill 328 64 -140 391 64 -140 minecraft:air
fill 328 64 -141 391 64 -141 minecraft:air
fill 328 64 -142 391 64 -142 minecraft:air
fill 328 64 -143 391 64 -143 minecraft:air
fill 328 64 -144 391 64 -144 minecraft:air
fill 328 64 -145 391 64 -145 minecraft:air
fill 328 64 -146 391 64 -146 minecraft:air
fill 328 64 -147 391 64 -147 minecraft:air
fill 328 64 -148 391 64 -148 minecraft:air
fill 328 64 -149 391 64 -149 minecraft:air
fill 328 64 -150 391 64 -150 minecraft:air
fill 328 64 -151 391 64 -151 minecraft:air
fill 328 64 -152 391 64 -152 minecraft:air
fill 328 64 -153 391 64 -153 minecraft:air
fill 328 64 -154 391 64 -154 minecraft:air
fill 328 64 -155 391 64 -155 minecraft:air
fill 328 64 -156 391 64 -156 minecraft:air
fill 328 64 -157 391 64 -157 minecraft:air
fill 328 64 -158 391 64 -158 minecraft:air
fill 328 64 -159 391 64 -159 minecraft:air
fill 328 64 -160 391 64 -160 minecraft:air
fill 328 64 -161 391 64 -161 minecraft:air
fill 328 64 -162 391 64 -162 minecraft:air
fill 329 64 -163 391 64 -163 minecraft:air
fill 329 64 -164 391 64 -164 minecraft:air
fill 329 64 -165 391 64 -165 minecraft:air
fill 328 64 -166 391 64 -166 minecraft:air
fill 328 64 -167 391 64 -167 minecraft:air
fill 328 64 -168 391 64 -168 minecraft:air
fill 328 64 -169 391 64 -169 minecraft:air
fill 328 64 -170 391 64 -170 minecraft:air
fill 328 64 -171 391 64 -171 minecraft:air
fill 328 64 -172 391 64 -172 minecraft:air
fill 328 64 -173 391 64 -173 minecraft:air
fill 328 64 -174 391 64 -174 minecraft:air
fill 328 64 -175 391 64 -175 minecraft:air
fill 328 64 -176 391 64 -176 minecraft:air
fill 328 64 -177 391 64 -177 minecraft:air
fill 328 64 -178 391 64 -178 minecraft:air
fill 328 64 -179 391 64 -179 minecraft:air
fill 328 64 -180 391 64 -180 minecraft:air
fill 328 64 -181 391 64 -181 minecraft:air
fill 328 64 -182 391 64 -182 minecraft:air
setblock 328 64 -183 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
fill 329 64 -183 391 64 -183 minecraft:air
fill 328 64 -184 391 64 -184 minecraft:air
setblock 328 64 -185 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
fill 329 64 -185 391 64 -185 minecraft:air
fill 328 64 -186 391 64 -186 minecraft:air
fill 328 64 -187 391 64 -187 minecraft:air
fill 328 64 -188 391 64 -188 minecraft:air
fill 328 64 -189 391 64 -189 minecraft:air
fill 328 64 -190 391 64 -190 minecraft:air
fill 328 63 -127 391 63 -127 minecraft:air
fill 328 63 -128 391 63 -128 minecraft:air
fill 328 63 -129 391 63 -129 minecraft:air
fill 328 63 -130 391 63 -130 minecraft:air
fill 328 63 -131 391 63 -131 minecraft:air
fill 328 63 -132 391 63 -132 minecraft:air
fill 328 63 -133 391 63 -133 minecraft:air
fill 328 63 -134 391 63 -134 minecraft:air
fill 328 63 -135 391 63 -135 minecraft:air
fill 328 63 -136 391 63 -136 minecraft:air
fill 328 63 -137 391 63 -137 minecraft:air
fill 328 63 -138 391 63 -138 minecraft:air
fill 328 63 -139 391 63 -139 minecraft:air
fill 328 63 -140 391 63 -140 minecraft:air
fill 328 63 -141 391 63 -141 minecraft:air
fill 328 63 -142 391 63 -142 minecraft:air
fill 328 63 -143 391 63 -143 minecraft:air
fill 328 63 -144 391 63 -144 minecraft:air
fill 328 63 -145 391 63 -145 minecraft:air
fill 328 63 -146 391 63 -146 minecraft:air
fill 328 63 -147 391 63 -147 minecraft:air
fill 328 63 -148 391 63 -148 minecraft:air
fill 328 63 -149 391 63 -149 minecraft:air
fill 328 63 -150 391 63 -150 minecraft:air
fill 328 63 -151 391 63 -151 minecraft:air
fill 328 63 -152 391 63 -152 minecraft:air
fill 328 63 -153 391 63 -153 minecraft:air
fill 328 63 -154 391 63 -154 minecraft:air
fill 328 63 -155 391 63 -155 minecraft:air
fill 328 63 -156 391 63 -156 minecraft:air
fill 328 63 -157 391 63 -157 minecraft:air
fill 328 63 -158 391 63 -158 minecraft:air
fill 328 63 -159 391 63 -159 minecraft:air
fill 328 63 -160 391 63 -160 minecraft:air
fill 329 63 -161 391 63 -161 minecraft:air
fill 329 63 -162 391 63 -162 minecraft:air
fill 330 63 -163 391 63 -163 minecraft:air
fill 330 63 -164 391 63 -164 minecraft:air
fill 330 63 -165 391 63 -165 minecraft:air
fill 329 63 -166 391 63 -166 minecraft:air
fill 328 63 -167 391 63 -167 minecraft:air
fill 328 63 -168 391 63 -168 minecraft:air
fill 328 63 -169 391 63 -169 minecraft:air
fill 328 63 -170 391 63 -170 minecraft:air
fill 328 63 -171 391 63 -171 minecraft:air
fill 328 63 -172 391 63 -172 minecraft:air
fill 328 63 -173 391 63 -173 minecraft:air
fill 328 63 -174 391 63 -174 minecraft:air
fill 329 63 -175 391 63 -175 minecraft:air
fill 329 63 -176 391 63 -176 minecraft:air
fill 329 63 -177 391 63 -177 minecraft:air
fill 329 63 -178 391 63 -178 minecraft:air
fill 329 63 -179 391 63 -179 minecraft:air
fill 329 63 -180 391 63 -180 minecraft:air
fill 329 63 -181 391 63 -181 minecraft:air
fill 329 63 -182 391 63 -182 minecraft:air
fill 329 63 -183 391 63 -183 minecraft:air
fill 329 63 -184 391 63 -184 minecraft:air
fill 329 63 -185 391 63 -185 minecraft:air
fill 329 63 -186 391 63 -186 minecraft:air
fill 329 63 -187 391 63 -187 minecraft:air
fill 329 63 -188 391 63 -188 minecraft:air
fill 329 63 -189 391 63 -189 minecraft:air
fill 330 63 -190 391 63 -190 minecraft:air
fill 328 62 -127 346 62 -127 minecraft:water[level=0]
setblock 347 62 -127 minecraft:kelp[age=22]
setblock 348 62 -127 minecraft:water[level=0]
setblock 349 62 -127 minecraft:kelp[age=24]
fill 350 62 -127 353 62 -127 minecraft:water[level=0]
setblock 354 62 -127 minecraft:kelp[age=24]
fill 355 62 -127 368 62 -127 minecraft:water[level=0]
setblock 369 62 -127 minecraft:kelp[age=23]
fill 370 62 -127 391 62 -127 minecraft:water[level=0]
fill 328 62 -128 337 62 -128 minecraft:water[level=0]
setblock 338 62 -128 minecraft:kelp[age=22]
fill 339 62 -128 345 62 -128 minecraft:water[level=0]
setblock 346 62 -128 minecraft:kelp[age=23]
fill 347 62 -128 356 62 -128 minecraft:water[level=0]
setblock 357 62 -128 minecraft:kelp[age=25]
fill 358 62 -128 359 62 -128 minecraft:water[level=0]
setblock 360 62 -128 minecraft:kelp[age=24]
fill 361 62 -128 366 62 -128 minecraft:water[level=0]
setblock 367 62 -128 minecraft:kelp[age=24]
fill 368 62 -128 371 62 -128 minecraft:water[level=0]
setblock 372 62 -128 minecraft:kelp[age=24]
fill 373 62 -128 379 62 -128 minecraft:water[level=0]
setblock 380 62 -128 minecraft:kelp[age=25]
fill 381 62 -128 391 62 -128 minecraft:water[level=0]
fill 328 62 -129 341 62 -129 minecraft:water[level=0]
setblock 342 62 -129 minecraft:kelp[age=22]
fill 343 62 -129 358 62 -129 minecraft:water[level=0]
setblock 359 62 -129 minecraft:kelp[age=25]
fill 360 62 -129 368 62 -129 minecraft:water[level=0]
setblock 369 62 -129 minecraft:kelp[age=25]
fill 370 62 -129 389 62 -129 minecraft:water[level=0]
setblock 390 62 -129 minecraft:kelp[age=24]
setblock 391 62 -129 minecraft:water[level=0]
fill 328 62 -130 362 62 -130 minecraft:water[level=0]
setblock 363 62 -130 minecraft:kelp[age=23]
fill 364 62 -130 365 62 -130 minecraft:water[level=0]
setblock 366 62 -130 minecraft:kelp[age=25]
fill 367 62 -130 391 62 -130 minecraft:water[level=0]
setblock 328 62 -131 minecraft:kelp[age=22]
fill 329 62 -131 391 62 -131 minecraft:water[level=0]
fill 328 62 -132 362 62 -132 minecraft:water[level=0]
setblock 363 62 -132 minecraft:kelp[age=22]
fill 364 62 -132 391 62 -132 minecraft:water[level=0]
fill 328 62 -133 391 62 -133 minecraft:water[level=0]
fill 328 62 -134 336 62 -134 minecraft:water[level=0]
setblock 337 62 -134 minecraft:kelp[age=25]
fill 338 62 -134 383 62 -134 minecraft:water[level=0]
setblock 384 62 -134 minecraft:kelp[age=25]
fill 385 62 -134 391 62 -134 minecraft:water[level=0]
fill 328 62 -135 349 62 -135 minecraft:water[level=0]
setblock 350 62 -135 minecraft:kelp[age=22]
fill 351 62 -135 391 62 -135 minecraft:water[level=0]
fill 328 62 -136 342 62 -136 minecraft:water[level=0]
setblock 343 62 -136 minecraft:kelp[age=24]
fill 344 62 -136 345 62 -136 minecraft:water[level=0]
setblock 346 62 -136 minecraft:kelp[age=21]
fill 347 62 -136 348 62 -136 minecraft:water[level=0]
setblock 349 62 -136 minecraft:kelp[age=22]
fill 350 62 -136 374 62 -136 minecraft:water[level=0]
setblock 375 62 -136 minecraft:kelp[age=24]
fill 376 62 -136 391 62 -136 minecraft:water[level=0]
fill 328 62 -137 330 62 -137 minecraft:water[level=0]
setblock 331 62 -137 minecraft:kelp[age=25]
fill 332 62 -137 391 62 -137 minecraft:water[level=0]
fill 328 62 -138 366 62 -138 minecraft:water[level=0]
setblock 367 62 -138 minecraft:kelp[age=22]
fill 368 62 -138 391 62 -138 minecraft:water[level=0]
fill 328 62 -139 371 62 -139 minecraft:water[level=0]
setblock 372 62 -139 minecraft:kelp[age=21]
fill 373 62 -139 391 62 -139 minecraft:water[level=0]
fill 328 62 -140 354 62 -140 minecraft:water[level=0]
setblock 355 62 -140 minecraft:kelp[age=22]
fill 356 62 -140 368 62 -140 minecraft:water[level=0]
setblock 369 62 -140 minecraft:kelp[age=22]
setblock 370 62 -140 minecraft:water[level=0]
setblock 371 62 -140 minecraft:kelp[age=22]
fill 372 62 -140 377 62 -140 minecraft:water[level=0]
setblock 378 62 -140 minecraft:kelp[age=24]
fill 379 62 -140 391 62 -140 minecraft:water[level=0]
fill 328 62 -141 355 62 -141 minecraft:water[level=0]
setblock 356 62 -141 minecraft:kelp[age=24]
fill 357 62 -141 368 62 -141 minecraft:water[level=0]
setblock 369 62 -141 minecraft:kelp[age=22]
fill 370 62 -141 382 62 -141 minecraft:water[level=0]
setblock 383 62 -141 minecraft:kelp[age=24]
fill 384 62 -141 387 62 -141 minecraft:water[level=0]
setblock 388 62 -141 minecraft:kelp[age=21]
fill 389 62 -141 391 62 -141 minecraft:water[level=0]
fill 328 62 -142 352 62 -142 minecraft:water[level=0]
setblock 353 62 -142 minecraft:kelp[age=24]
fill 354 62 -142 371 62 -142 minecraft:water[level=0]
setblock 372 62 -142 minecraft:kelp[age=25]
fill 373 62 -142 391 62 -142 minecraft:water[level=0]
fill 328 62 -143 331 62 -143 minecraft:water[level=0]
setblock 332 62 -143 minecraft:kelp[age=23]
fill 333 62 -143 337 62 -143 minecraft:water[level=0]
setblock 338 62 -143 minecraft:kelp[age=24]
fill 339 62 -143 382 62 -143 minecraft:water[level=0]
setblock 383 62 -143 minecraft:kelp[age=25]
fill 384 62 -143 385 62 -143 minecraft:water[level=0]
setblock 386 62 -143 minecraft:kelp[age=21]
fill 387 62 -143 391 62 -143 minecraft:water[level=0]
fill 328 62 -144 351 62 -144 minecraft:water[level=0]
setblock 352 62 -144 minecraft:kelp[age=23]
fill 353 62 -144 370 62 -144 minecraft:water[level=0]
setblock 371 62 -144 minecraft:kelp[age=21]
fill 372 62 -144 391 62 -144 minecraft:water[level=0]
fill 328 62 -145 388 62 -145 minecraft:water[level=0]
setblock 389 62 -145 minecraft:kelp[age=25]
fill 390 62 -145 391 62 -145 minecraft:water[level=0]
fill 328 62 -146 371 62 -146 minecraft:water[level=0]
setblock 372 62 -146 minecraft:kelp[age=24]
fill 373 62 -146 391 62 -146 minecraft:water[level=0]
fill 328 62 -147 374 62 -147 minecraft:water[level=0]
setblock 375 62 -147 minecraft:kelp[age=22]
fill 376 62 -147 385 62 -147 minecraft:water[level=0]
setblock 386 62 -147 minecraft:kelp[age=23]
fill 387 62 -147 391 62 -147 minecraft:water[level=0]
fill 328 62 -148 374 62 -148 minecraft:water[level=0]
setblock 375 62 -148 minecraft:kelp[age=21]
fill 376 62 -148 377 62 -148 minecraft:water[level=0]
setblock 378 62 -148 minecraft:kelp[age=21]
fill 379 62 -148 386 62 -148 minecraft:water[level=0]
setblock 387 62 -148 minecraft:kelp[age=23]
setblock 388 62 -148 minecraft:water[level=0]
setblock 389 62 -148 minecraft:kelp[age=22]
fill 390 62 -148 391 62 -148 minecraft:water[level=0]
fill 328 62 -149 368 62 -149 minecraft:water[level=0]
setblock 369 62 -149 minecraft:kelp[age=23]
fill 370 62 -149 391 62 -149 minecraft:water[level=0]
fill 328 62 -150 391 62 -150 minecraft:water[level=0]
fill 328 62 -151 385 62 -151 minecraft:water[level=0]
setblock 386 62 -151 minecraft:kelp[age=23]
fill 387 62 -151 391 62 -151 minecraft:water[level=0]
fill 328 62 -152 367 62 -152 minecraft:water[level=0]
setblock 368 62 -152 minecraft:kelp[age=24]
fill 369 62 -152 370 62 -152 minecraft:water[level=0]
setblock 371 62 -152 minecraft:kelp[age=24]
fill 372 62 -152 376 62 -152 minecraft:water[level=0]
setblock 377 62 -152 minecraft:kelp[age=23]
fill 378 62 -152 385 62 -152 minecraft:water[level=0]
setblock 386 62 -152 minecraft:kelp[age=24]
fill 387 62 -152 390 62 -152 minecraft:water[level=0]
setblock 391 62 -152 minecraft:kelp[age=24]
fill 328 62 -153 369 62 -153 minecraft:water[level=0]
setblock 370 62 -153 minecraft:kelp[age=23]
setblock 371 62 -153 minecraft:water[level=0]
setblock 372 62 -153 minecraft:kelp[age=21]
fill 373 62 -153 380 62 -153 minecraft:water[level=0]
setblock 381 62 -153 minecraft:kelp[age=24]
setblock 382 62 -153 minecraft:kelp[age=23]
setblock 383 62 -153 minecraft:water[level=0]
setblock 384 62 -153 minecraft:kelp[age=21]
setblock 385 62 -153 minecraft:kelp[age=25]
fill 386 62 -153 389 62 -153 minecraft:water[level=0]
setblock 390 62 -153 minecraft:kelp[age=23]
setblock 391 62 -153 minecraft:water[level=0]
fill 328 62 -154 372 62 -154 minecraft:water[level=0]
setblock 373 62 -154 minecraft:kelp[age=25]
fill 374 62 -154 375 62 -154 minecraft:water[level=0]
setblock 376 62 -154 minecraft:kelp[age=23]
fill 377 62 -154 391 62 -154 minecraft:water[level=0]
fill 328 62 -155 376 62 -155 minecraft:water[level=0]
setblock 377 62 -155 minecraft:kelp[age=23]
setblock 378 62 -155 minecraft:kelp[age=21]
setblock 379 62 -155 minecraft:kelp[age=22]
setblock 380 62 -155 minecraft:water[level=0]
setblock 381 62 -155 minecraft:kelp[age=24]
fill 382 62 -155 391 62 -155 minecraft:water[level=0]
fill 328 62 -156 368 62 -156 minecraft:water[level=0]
setblock 369 62 -156 minecraft:kelp[age=23]
fill 370 62 -156 372 62 -156 minecraft:water[level=0]
setblock 373 62 -156 minecraft:kelp[age=25]
fill 374 62 -156 381 62 -156 minecraft:water[level=0]
setblock 382 62 -156 minecraft:kelp[age=24]
setblock 383 62 -156 minecraft:kelp[age=23]
fill 384 62 -156 391 62 -156 minecraft:water[level=0]
fill 328 62 -157 368 62 -157 minecraft:water[level=0]
setblock 369 62 -157 minecraft:kelp[age=23]
fill 370 62 -157 376 62 -157 minecraft:water[level=0]
setblock 377 62 -157 minecraft:kelp[age=25]
fill 378 62 -157 380 62 -157 minecraft:water[level=0]
setblock 381 62 -157 minecraft:kelp[age=24]
fill 382 62 -157 390 62 -157 minecraft:water[level=0]
setblock 391 62 -157 minecraft:kelp[age=23]
fill 328 62 -158 379 62 -158 minecraft:water[level=0]
setblock 380 62 -158 minecraft:kelp[age=25]
fill 381 62 -158 391 62 -158 minecraft:water[level=0]
fill 328 62 -159 369 62 -159 minecraft:water[level=0]
setblock 370 62 -159 minecraft:kelp[age=21]
setblock 371 62 -159 minecraft:kelp[age=24]
fill 372 62 -159 391 62 -159 minecraft:water[level=0]
fill 328 62 -160 369 62 -160 minecraft:water[level=0]
setblock 370 62 -160 minecraft:kelp[age=23]
fill 371 62 -160 375 62 -160 minecraft:water[level=0]
setblock 376 62 -160 minecraft:kelp[age=23]
fill 377 62 -160 389 62 -160 minecraft:water[level=0]
setblock 390 62 -160 minecraft:kelp[age=23]
setblock 391 62 -160 minecraft:water[level=0]
fill 329 62 -161 369 62 -161 minecraft:water[level=0]
setblock 370 62 -161 minecraft:kelp[age=23]
setblock 371 62 -161 minecraft:water[level=0]
setblock 372 62 -161 minecraft:kelp[age=22]
fill 373 62 -161 376 62 -161 minecraft:water[level=0]
setblock 377 62 -161 minecraft:kelp[age=24]
fill 378 62 -161 391 62 -161 minecraft:water[level=0]
fill 330 62 -162 369 62 -162 minecraft:water[level=0]
setblock 370 62 -162 minecraft:kelp[age=24]
setblock 371 62 -162 minecraft:kelp[age=21]
fill 372 62 -162 377 62 -162 minecraft:water[level=0]
setblock 378 62 -162 minecraft:kelp[age=23]
setblock 379 62 -162 minecraft:water[level=0]
setblock 380 62 -162 minecraft:kelp[age=21]
fill 381 62 -162 391 62 -162 minecraft:water[level=0]
fill 331 62 -163 391 62 -163 minecraft:water[level=0]
fill 331 62 -164 371 62 -164 minecraft:water[level=0]
setblock 372 62 -164 minecraft:kelp[age=22]
fill 373 62 -164 377 62 -164 minecraft:water[level=0]
setblock 378 62 -164 minecraft:kelp[age=23]
fill 379 62 -164 391 62 -164 minecraft:water[level=0]
fill 330 62 -165 375 62 -165 minecraft:water[level=0]
setblock 376 62 -165 minecraft:kelp[age=22]
fill 377 62 -165 380 62 -165 minecraft:water[level=0]
setblock 381 62 -165 minecraft:kelp[age=23]
fill 382 62 -165 391 62 -165 minecraft:water[level=0]
fill 330 62 -166 380 62 -166 minecraft:water[level=0]
setblock 381 62 -166 minecraft:kelp[age=23]
fill 382 62 -166 391 62 -166 minecraft:water[level=0]
fill 329 62 -167 385 62 -167 minecraft:water[level=0]
setblock 386 62 -167 minecraft:kelp[age=21]
fill 387 62 -167 391 62 -167 minecraft:water[level=0]
fill 328 62 -168 376 62 -168 minecraft:water[level=0]
setblock 377 62 -168 minecraft:kelp[age=22]
fill 378 62 -168 380 62 -168 minecraft:water[level=0]
setblock 381 62 -168 minecraft:kelp[age=22]
setblock 382 62 -168 minecraft:water[level=0]
setblock 383 62 -168 minecraft:kelp[age=22]
fill 384 62 -168 391 62 -168 minecraft:water[level=0]
fill 328 62 -169 351 62 -169 minecraft:water[level=0]
setblock 352 62 -169 minecraft:kelp[age=24]
fill 353 62 -169 375 62 -169 minecraft:water[level=0]
setblock 376 62 -169 minecraft:kelp[age=25]
fill 377 62 -169 379 62 -169 minecraft:water[level=0]
setblock 380 62 -169 minecraft:kelp[age=24]
setblock 381 62 -169 minecraft:kelp[age=21]
fill 382 62 -169 391 62 -169 minecraft:water[level=0]
fill 328 62 -170 369 62 -170 minecraft:water[level=0]
setblock 370 62 -170 minecraft:kelp[age=23]
fill 371 62 -170 374 62 -170 minecraft:water[level=0]
setblock 375 62 -170 minecraft:kelp[age=24]
setblock 376 62 -170 minecraft:water[level=0]
setblock 377 62 -170 minecraft:kelp[age=21]
fill 378 62 -170 383 62 -170 minecraft:water[level=0]
setblock 384 62 -170 minecraft:kelp[age=23]
fill 385 62 -170 390 62 -170 minecraft:water[level=0]
setblock 391 62 -170 minecraft:kelp[age=25]
fill 328 62 -171 368 62 -171 minecraft:water[level=0]
fill 369 62 -171 370 62 -171 minecraft:kelp[age=21]
fill 371 62 -171 383 62 -171 minecraft:water[level=0]
setblock 384 62 -171 minecraft:kelp[age=23]
fill 385 62 -171 391 62 -171 minecraft:water[level=0]
fill 328 62 -172 367 62 -172 minecraft:water[level=0]
setblock 368 62 -172 minecraft:kelp[age=24]
fill 369 62 -172 374 62 -172 minecraft:water[level=0]
setblock 375 62 -172 minecraft:kelp[age=21]
fill 376 62 -172 379 62 -172 minecraft:water[level=0]
fill 380 62 -172 381 62 -172 minecraft:kelp[age=22]
fill 382 62 -172 383 62 -172 minecraft:water[level=0]
setblock 384 62 -172 minecraft:kelp[age=25]
fill 385 62 -172 386 62 -172 minecraft:water[level=0]
setblock 387 62 -172 minecraft:kelp[age=23]
fill 388 62 -172 391 62 -172 minecraft:water[level=0]
fill 328 62 -173 367 62 -173 minecraft:water[level=0]
setblock 368 62 -173 minecraft:kelp[age=24]
fill 369 62 -173 370 62 -173 minecraft:water[level=0]
setblock 371 62 -173 minecraft:kelp[age=21]
fill 372 62 -173 382 62 -173 minecraft:water[level=0]
setblock 383 62 -173 minecraft:kelp[age=21]
fill 384 62 -173 385 62 -173 minecraft:water[level=0]
setblock 386 62 -173 minecraft:kelp[age=25]
fill 387 62 -173 391 62 -173 minecraft:water[level=0]
fill 329 62 -174 376 62 -174 minecraft:water[level=0]
setblock 377 62 -174 minecraft:kelp[age=23]
fill 378 62 -174 388 62 -174 minecraft:water[level=0]
setblock 389 62 -174 minecraft:kelp[age=21]
fill 390 62 -174 391 62 -174 minecraft:water[level=0]
fill 330 62 -175 356 62 -175 minecraft:water[level=0]
setblock 357 62 -175 minecraft:kelp[age=23]
fill 358 62 -175 366 62 -175 minecraft:water[level=0]
setblock 367 62 -175 minecraft:kelp[age=24]
setblock 368 62 -175 minecraft:kelp[age=25]
fill 369 62 -175 379 62 -175 minecraft:water[level=0]
setblock 380 62 -175 minecraft:kelp[age=23]
fill 381 62 -175 384 62 -175 minecraft:water[level=0]
setblock 385 62 -175 minecraft:kelp[age=25]
setblock 386 62 -175 minecraft:water[level=0]
setblock 387 62 -175 minecraft:kelp[age=24]
fill 388 62 -175 391 62 -175 minecraft:water[level=0]
fill 330 62 -176 370 62 -176 minecraft:water[level=0]
setblock 371 62 -176 minecraft:kelp[age=25]
fill 372 62 -176 376 62 -176 minecraft:water[level=0]
setblock 377 62 -176 minecraft:kelp[age=22]
fill 378 62 -176 380 62 -176 minecraft:water[level=0]
setblock 381 62 -176 minecraft:kelp[age=21]
fill 382 62 -176 386 62 -176 minecraft:water[level=0]
setblock 387 62 -176 minecraft:kelp[age=25]
setblock 388 62 -176 minecraft:water[level=0]
setblock 389 62 -176 minecraft:kelp[age=21]
fill 390 62 -176 391 62 -176 minecraft:water[level=0]
fill 330 62 -177 363 62 -177 minecraft:water[level=0]
setblock 364 62 -177 minecraft:kelp[age=22]
fill 365 62 -177 366 62 -177 minecraft:water[level=0]
setblock 367 62 -177 minecraft:kelp[age=25]
setblock 368 62 -177 minecraft:kelp[age=21]
fill 369 62 -177 371 62 -177 minecraft:water[level=0]
setblock 372 62 -177 minecraft:kelp[age=23]
setblock 373 62 -177 minecraft:kelp[age=24]
fill 374 62 -177 379 62 -177 minecraft:water[level=0]
setblock 380 62 -177 minecraft:kelp[age=21]
setblock 381 62 -177 minecraft:water[level=0]
setblock 382 62 -177 minecraft:kelp[age=25]
setblock 383 62 -177 minecraft:kelp[age=24]
fill 384 62 -177 388 62 -177 minecraft:water[level=0]
setblock 389 62 -177 minecraft:kelp[age=24]
fill 390 62 -177 391 62 -177 minecraft:water[level=0]
fill 330 62 -178 356 62 -178 minecraft:water[level=0]
setblock 357 62 -178 minecraft:kelp[age=21]
fill 358 62 -178 366 62 -178 minecraft:water[level=0]
fill 367 62 -178 368 62 -178 minecraft:kelp[age=21]
fill 369 62 -178 372 62 -178 minecraft:water[level=0]
setblock 373 62 -178 minecraft:kelp[age=25]
fill 374 62 -178 376 62 -178 minecraft:water[level=0]
setblock 377 62 -178 minecraft:kelp[age=23]
setblock 378 62 -178 minecraft:kelp[age=22]
fill 379 62 -178 381 62 -178 minecraft:water[level=0]
setblock 382 62 -178 minecraft:kelp[age=22]
fill 383 62 -178 391 62 -178 minecraft:water[level=0]
fill 330 62 -179 353 62 -179 minecraft:water[level=0]
setblock 354 62 -179 minecraft:kelp[age=24]
fill 355 62 -179 366 62 -179 minecraft:water[level=0]
setblock 367 62 -179 minecraft:kelp[age=24]
fill 368 62 -179 378 62 -179 minecraft:water[level=0]
setblock 379 62 -179 minecraft:kelp[age=24]
fill 380 62 -179 381 62 -179 minecraft:water[level=0]
fill 382 62 -179 383 62 -179 minecraft:kelp[age=22]
fill 384 62 -179 391 62 -179 minecraft:water[level=0]
fill 330 62 -180 354 62 -180 minecraft:water[level=0]
setblock 355 62 -180 minecraft:kelp[age=24]
fill 356 62 -180 359 62 -180 minecraft:water[level=0]
setblock 360 62 -180 minecraft:kelp[age=23]
fill 361 62 -180 368 62 -180 minecraft:water[level=0]
setblock 369 62 -180 minecraft:kelp[age=22]
setblock 370 62 -180 minecraft:water[level=0]
setblock 371 62 -180 minecraft:kelp[age=23]
fill 372 62 -180 376 62 -180 minecraft:water[level=0]
setblock 377 62 -180 minecraft:kelp[age=25]
fill 378 62 -180 379 62 -180 minecraft:water[level=0]
setblock 380 62 -180 minecraft:kelp[age=23]
fill 381 62 -180 391 62 -180 minecraft:water[level=0]
fill 330 62 -181 348 62 -181 minecraft:water[level=0]
setblock 349 62 -181 minecraft:kelp[age=22]
fill 350 62 -181 352 62 -181 minecraft:water[level=0]
setblock 353 62 -181 minecraft:kelp[age=22]
setblock 354 62 -181 minecraft:water[level=0]
setblock 355 62 -181 minecraft:kelp[age=21]
setblock 356 62 -181 minecraft:water[level=0]
setblock 357 62 -181 minecraft:kelp[age=25]
fill 358 62 -181 376 62 -181 minecraft:water[level=0]
setblock 377 62 -181 minecraft:kelp[age=23]
fill 378 62 -181 379 62 -181 minecraft:water[level=0]
setblock 380 62 -181 minecraft:kelp[age=25]
fill 381 62 -181 389 62 -181 minecraft:water[level=0]
setblock 390 62 -181 minecraft:kelp[age=21]
setblock 391 62 -181 minecraft:water[level=0]
fill 330 62 -182 353 62 -182 minecraft:water[level=0]
setblock 354 62 -182 minecraft:kelp[age=21]
fill 355 62 -182 359 62 -182 minecraft:water[level=0]
setblock 360 62 -182 minecraft:kelp[age=23]
setblock 361 62 -182 minecraft:kelp[age=25]
setblock 362 62 -182 minecraft:kelp[age=24]
fill 363 62 -182 365 62 -182 minecraft:water[level=0]
setblock 366 62 -182 minecraft:kelp[age=23]
setblock 367 62 -182 minecraft:kelp[age=21]
setblock 368 62 -182 minecraft:kelp[age=23]
setblock 369 62 -182 minecraft:water[level=0]
setblock 370 62 -182 minecraft:kelp[age=24]
fill 371 62 -182 376 62 -182 minecraft:water[level=0]
setblock 377 62 -182 minecraft:kelp[age=24]
fill 378 62 -182 382 62 -182 minecraft:water[level=0]
setblock 383 62 -182 minecraft:kelp[age=24]
fill 384 62 -182 386 62 -182 minecraft:water[level=0]
setblock 387 62 -182 minecraft:kelp[age=21]
fill 388 62 -182 391 62 -182 minecraft:water[level=0]
fill 330 62 -183 346 62 -183 minecraft:water[level=0]
setblock 347 62 -183 minecraft:kelp[age=25]
fill 348 62 -183 368 62 -183 minecraft:water[level=0]
setblock 369 62 -183 minecraft:kelp[age=24]
setblock 370 62 -183 minecraft:water[level=0]
setblock 371 62 -183 minecraft:kelp[age=23]
fill 372 62 -183 386 62 -183 minecraft:water[level=0]
setblock 387 62 -183 minecraft:kelp[age=24]
fill 388 62 -183 391 62 -183 minecraft:water[level=0]
fill 330 62 -184 345 62 -184 minecraft:water[level=0]
setblock 346 62 -184 minecraft:kelp[age=25]
fill 347 62 -184 348 62 -184 minecraft:water[level=0]
setblock 349 62 -184 minecraft:kelp[age=23]
fill 350 62 -184 359 62 -184 minecraft:water[level=0]
fill 360 62 -184 361 62 -184 minecraft:kelp[age=22]
fill 362 62 -184 369 62 -184 minecraft:water[level=0]
setblock 370 62 -184 minecraft:kelp[age=23]
fill 371 62 -184 375 62 -184 minecraft:water[level=0]
setblock 376 62 -184 minecraft:kelp[age=25]
fill 377 62 -184 379 62 -184 minecraft:water[level=0]
setblock 380 62 -184 minecraft:kelp[age=24]
fill 381 62 -184 387 62 -184 minecraft:water[level=0]
setblock 388 62 -184 minecraft:kelp[age=24]
fill 389 62 -184 391 62 -184 minecraft:water[level=0]
fill 330 62 -185 356 62 -185 minecraft:water[level=0]
setblock 357 62 -185 minecraft:kelp[age=21]
fill 358 62 -185 363 62 -185 minecraft:water[level=0]
setblock 364 62 -185 minecraft:kelp[age=22]
fill 365 62 -185 370 62 -185 minecraft:water[level=0]
setblock 371 62 -185 minecraft:kelp[age=23]
fill 372 62 -185 379 62 -185 minecraft:water[level=0]
setblock 380 62 -185 minecraft:kelp[age=23]
setblock 381 62 -185 minecraft:water[level=0]
setblock 382 62 -185 minecraft:kelp[age=24]
setblock 383 62 -185 minecraft:water[level=0]
setblock 384 62 -185 minecraft:kelp[age=23]
fill 385 62 -185 391 62 -185 minecraft:water[level=0]
fill 330 62 -186 359 62 -186 minecraft:water[level=0]
setblock 360 62 -186 minecraft:kelp[age=22]
fill 361 62 -186 376 62 -186 minecraft:water[level=0]
setblock 377 62 -186 minecraft:kelp[age=21]
setblock 378 62 -186 minecraft:kelp[age=23]
fill 379 62 -186 391 62 -186 minecraft:water[level=0]
fill 330 62 -187 353 62 -187 minecraft:water[level=0]
setblock 354 62 -187 minecraft:kelp[age=24]
fill 355 62 -187 356 62 -187 minecraft:water[level=0]
setblock 357 62 -187 minecraft:kelp[age=24]
setblock 358 62 -187 minecraft:kelp[age=23]
fill 359 62 -187 369 62 -187 minecraft:water[level=0]
setblock 370 62 -187 minecraft:kelp[age=24]
fill 371 62 -187 373 62 -187 minecraft:water[level=0]
setblock 374 62 -187 minecraft:kelp[age=24]
fill 375 62 -187 380 62 -187 minecraft:water[level=0]
setblock 381 62 -187 minecraft:kelp[age=23]
fill 382 62 -187 387 62 -187 minecraft:water[level=0]
setblock 388 62 -187 minecraft:kelp[age=23]
fill 389 62 -187 391 62 -187 minecraft:water[level=0]
fill 330 62 -188 352 62 -188 minecraft:water[level=0]
setblock 353 62 -188 minecraft:kelp[age=21]
setblock 354 62 -188 minecraft:water[level=0]
setblock 355 62 -188 minecraft:kelp[age=21]
setblock 356 62 -188 minecraft:kelp[age=23]
fill 357 62 -188 364 62 -188 minecraft:water[level=0]
setblock 365 62 -188 minecraft:kelp[age=24]
fill 366 62 -188 368 62 -188 minecraft:water[level=0]
setblock 369 62 -188 minecraft:kelp[age=23]
fill 370 62 -188 371 62 -188 minecraft:water[level=0]
setblock 372 62 -188 minecraft:kelp[age=23]
setblock 373 62 -188 minecraft:water[level=0]
setblock 374 62 -188 minecraft:kelp[age=24]
fill 375 62 -188 376 62 -188 minecraft:water[level=0]
setblock 377 62 -188 minecraft:kelp[age=21]
setblock 378 62 -188 minecraft:kelp[age=22]
fill 379 62 -188 380 62 -188 minecraft:water[level=0]
setblock 381 62 -188 minecraft:kelp[age=25]
setblock 382 62 -188 minecraft:water[level=0]
setblock 383 62 -188 minecraft:kelp[age=24]
setblock 384 62 -188 minecraft:kelp[age=21]
fill 385 62 -188 391 62 -188 minecraft:water[level=0]
fill 330 62 -189 351 62 -189 minecraft:water[level=0]
setblock 352 62 -189 minecraft:kelp[age=24]
fill 353 62 -189 356 62 -189 minecraft:water[level=0]
setblock 357 62 -189 minecraft:kelp[age=21]
fill 358 62 -189 368 62 -189 minecraft:water[level=0]
setblock 369 62 -189 minecraft:kelp[age=25]
fill 370 62 -189 375 62 -189 minecraft:water[level=0]
setblock 376 62 -189 minecraft:kelp[age=21]
fill 377 62 -189 381 62 -189 minecraft:water[level=0]
setblock 382 62 -189 minecraft:kelp[age=24]
fill 383 62 -189 391 62 -189 minecraft:water[level=0]
fill 330 62 -190 357 62 -190 minecraft:water[level=0]
setblock 358 62 -190 minecraft:kelp[age=22]
fill 359 62 -190 364 62 -190 minecraft:water[level=0]
setblock 365 62 -190 minecraft:kelp[age=24]
setblock 366 62 -190 minecraft:kelp[age=23]
fill 367 62 -190 368 62 -190 minecraft:water[level=0]
setblock 369 62 -190 minecraft:kelp[age=23]
fill 370 62 -190 375 62 -190 minecraft:water[level=0]
setblock 376 62 -190 minecraft:kelp[age=24]
fill 377 62 -190 380 62 -190 minecraft:water[level=0]
setblock 381 62 -190 minecraft:kelp[age=23]
setblock 382 62 -190 minecraft:kelp[age=22]
fill 383 62 -190 387 62 -190 minecraft:water[level=0]
setblock 388 62 -190 minecraft:kelp[age=23]
fill 389 62 -190 391 62 -190 minecraft:water[level=0]
fill 328 61 -127 340 61 -127 minecraft:water[level=0]
setblock 341 61 -127 minecraft:kelp[age=25]
fill 342 61 -127 346 61 -127 minecraft:water[level=0]
setblock 347 61 -127 minecraft:kelp_plant
setblock 348 61 -127 minecraft:water[level=0]
setblock 349 61 -127 minecraft:kelp_plant
fill 350 61 -127 353 61 -127 minecraft:water[level=0]
setblock 354 61 -127 minecraft:kelp_plant
fill 355 61 -127 368 61 -127 minecraft:water[level=0]
setblock 369 61 -127 minecraft:kelp_plant
fill 370 61 -127 390 61 -127 minecraft:water[level=0]
setblock 391 61 -127 minecraft:kelp[age=25]
fill 328 61 -128 337 61 -128 minecraft:water[level=0]
setblock 338 61 -128 minecraft:kelp_plant
fill 339 61 -128 345 61 -128 minecraft:water[level=0]
setblock 346 61 -128 minecraft:kelp_plant
fill 347 61 -128 356 61 -128 minecraft:water[level=0]
setblock 357 61 -128 minecraft:kelp_plant
fill 358 61 -128 359 61 -128 minecraft:water[level=0]
setblock 360 61 -128 minecraft:kelp_plant
fill 361 61 -128 366 61 -128 minecraft:water[level=0]
setblock 367 61 -128 minecraft:kelp_plant
fill 368 61 -128 371 61 -128 minecraft:water[level=0]
setblock 372 61 -128 minecraft:kelp_plant
fill 373 61 -128 378 61 -128 minecraft:water[level=0]
setblock 379 61 -128 minecraft:kelp[age=25]
setblock 380 61 -128 minecraft:kelp_plant
fill 381 61 -128 391 61 -128 minecraft:water[level=0]
fill 328 61 -129 341 61 -129 minecraft:water[level=0]
setblock 342 61 -129 minecraft:kelp_plant
fill 343 61 -129 348 61 -129 minecraft:water[level=0]
setblock 349 61 -129 minecraft:kelp[age=25]
fill 350 61 -129 358 61 -129 minecraft:water[level=0]
setblock 359 61 -129 minecraft:kelp_plant
fill 360 61 -129 368 61 -129 minecraft:water[level=0]
setblock 369 61 -129 minecraft:kelp_plant
fill 370 61 -129 389 61 -129 minecraft:water[level=0]
setblock 390 61 -129 minecraft:kelp_plant
setblock 391 61 -129 minecraft:water[level=0]
fill 328 61 -130 333 61 -130 minecraft:water[level=0]
setblock 334 61 -130 minecraft:kelp[age=25]
fill 335 61 -130 362 61 -130 minecraft:water[level=0]
setblock 363 61 -130 minecraft:kelp_plant
fill 364 61 -130 365 61 -130 minecraft:water[level=0]
setblock 366 61 -130 minecraft:kelp_plant
fill 367 61 -130 368 61 -130 minecraft:water[level=0]
setblock 369 61 -130 minecraft:kelp[age=25]
fill 370 61 -130 391 61 -130 minecraft:water[level=0]
setblock 328 61 -131 minecraft:kelp_plant
fill 329 61 -131 391 61 -131 minecraft:water[level=0]
fill 328 61 -132 362 61 -132 minecraft:water[level=0]
setblock 363 61 -132 minecraft:kelp_plant
fill 364 61 -132 391 61 -132 minecraft:water[level=0]
fill 328 61 -133 387 61 -133 minecraft:water[level=0]
setblock 388 61 -133 minecraft:kelp[age=25]
fill 389 61 -133 391 61 -133 minecraft:water[level=0]
fill 328 61 -134 336 61 -134 minecraft:water[level=0]
setblock 337 61 -134 minecraft:kelp_plant
fill 338 61 -134 368 61 -134 minecraft:water[level=0]
setblock 369 61 -134 minecraft:kelp[age=25]
fill 370 61 -134 383 61 -134 minecraft:water[level=0]
setblock 384 61 -134 minecraft:kelp_plant
fill 385 61 -134 391 61 -134 minecraft:water[level=0]
fill 328 61 -135 331 61 -135 minecraft:water[level=0]
setblock 332 61 -135 minecraft:kelp[age=25]
fill 333 61 -135 347 61 -135 minecraft:water[level=0]
setblock 348 61 -135 minecraft:kelp[age=25]
setblock 349 61 -135 minecraft:water[level=0]
setblock 350 61 -135 minecraft:kelp_plant
fill 351 61 -135 391 61 -135 minecraft:water[level=0]
fill 328 61 -136 342 61 -136 minecraft:water[level=0]
setblock 343 61 -136 minecraft:kelp_plant
fill 344 61 -136 345 61 -136 minecraft:water[level=0]
setblock 346 61 -136 minecraft:kelp_plant
fill 347 61 -136 348 61 -136 minecraft:water[level=0]
setblock 349 61 -136 minecraft:kelp_plant
fill 350 61 -136 364 61 -136 minecraft:water[level=0]
setblock 365 61 -136 minecraft:kelp[age=25]
fill 366 61 -136 374 61 -136 minecraft:water[level=0]
setblock 375 61 -136 minecraft:kelp_plant
fill 376 61 -136 391 61 -136 minecraft:water[level=0]
setblock 328 61 -137 minecraft:kelp[age=25]
fill 329 61 -137 330 61 -137 minecraft:water[level=0]
setblock 331 61 -137 minecraft:kelp_plant
fill 332 61 -137 391 61 -137 minecraft:water[level=0]
fill 328 61 -138 366 61 -138 minecraft:water[level=0]
setblock 367 61 -138 minecraft:kelp_plant
fill 368 61 -138 391 61 -138 minecraft:water[level=0]
fill 328 61 -139 371 61 -139 minecraft:water[level=0]
setblock 372 61 -139 minecraft:kelp_plant
fill 373 61 -139 383 61 -139 minecraft:water[level=0]
setblock 384 61 -139 minecraft:kelp[age=25]
fill 385 61 -139 391 61 -139 minecraft:water[level=0]
fill 328 61 -140 354 61 -140 minecraft:water[level=0]
setblock 355 61 -140 minecraft:kelp_plant
fill 356 61 -140 368 61 -140 minecraft:water[level=0]
setblock 369 61 -140 minecraft:kelp_plant
setblock 370 61 -140 minecraft:water[level=0]
setblock 371 61 -140 minecraft:kelp_plant
fill 372 61 -140 377 61 -140 minecraft:water[level=0]
setblock 378 61 -140 minecraft:kelp_plant
fill 379 61 -140 391 61 -140 minecraft:water[level=0]
fill 328 61 -141 355 61 -141 minecraft:water[level=0]
setblock 356 61 -141 minecraft:kelp_plant
fill 357 61 -141 368 61 -141 minecraft:water[level=0]
setblock 369 61 -141 minecraft:kelp_plant
fill 370 61 -141 382 61 -141 minecraft:water[level=0]
setblock 383 61 -141 minecraft:kelp_plant
fill 384 61 -141 387 61 -141 minecraft:water[level=0]
setblock 388 61 -141 minecraft:kelp_plant
fill 389 61 -141 391 61 -141 minecraft:water[level=0]
fill 328 61 -142 352 61 -142 minecraft:water[level=0]
setblock 353 61 -142 minecraft:kelp_plant
fill 354 61 -142 367 61 -142 minecraft:water[level=0]
setblock 368 61 -142 minecraft:kelp[age=25]
fill 369 61 -142 370 61 -142 minecraft:water[level=0]
setblock 371 61 -142 minecraft:kelp[age=25]
setblock 372 61 -142 minecraft:kelp_plant
fill 373 61 -142 391 61 -142 minecraft:water[level=0]
fill 328 61 -143 331 61 -143 minecraft:water[level=0]
setblock 332 61 -143 minecraft:kelp_plant
fill 333 61 -143 337 61 -143 minecraft:water[level=0]
setblock 338 61 -143 minecraft:kelp_plant
fill 339 61 -143 377 61 -143 minecraft:water[level=0]
setblock 378 61 -143 minecraft:kelp[age=25]
fill 379 61 -143 382 61 -143 minecraft:water[level=0]
setblock 383 61 -143 minecraft:kelp_plant
fill 384 61 -143 385 61 -143 minecraft:water[level=0]
setblock 386 61 -143 minecraft:kelp_plant
fill 387 61 -143 391 61 -143 minecraft:water[level=0]
fill 328 61 -144 351 61 -144 minecraft:water[level=0]
setblock 352 61 -144 minecraft:kelp_plant
fill 353 61 -144 370 61 -144 minecraft:water[level=0]
setblock 371 61 -144 minecraft:kelp_plant
fill 372 61 -144 391 61 -144 minecraft:water[level=0]
fill 328 61 -145 385 61 -145 minecraft:water[level=0]
setblock 386 61 -145 minecraft:kelp[age=25]
fill 387 61 -145 388 61 -145 minecraft:water[level=0]
setblock 389 61 -145 minecraft:kelp_plant
fill 390 61 -145 391 61 -145 minecraft:water[level=0]
fill 328 61 -146 371 61 -146 minecraft:water[level=0]
setblock 372 61 -146 minecraft:kelp_plant
fill 373 61 -146 391 61 -146 minecraft:water[level=0]
fill 328 61 -147 374 61 -147 minecraft:water[level=0]
setblock 375 61 -147 minecraft:kelp_plant
fill 376 61 -147 385 61 -147 minecraft:water[level=0]
setblock 386 61 -147 minecraft:kelp_plant
fill 387 61 -147 391 61 -147 minecraft:water[level=0]
fill 328 61 -148 374 61 -148 minecraft:water[level=0]
setblock 375 61 -148 minecraft:kelp_plant
fill 376 61 -148 377 61 -148 minecraft:water[level=0]
setblock 378 61 -148 minecraft:kelp_plant
fill 379 61 -148 386 61 -148 minecraft:water[level=0]
setblock 387 61 -148 minecraft:kelp_plant
setblock 388 61 -148 minecraft:water[level=0]
setblock 389 61 -148 minecraft:kelp_plant
fill 390 61 -148 391 61 -148 minecraft:water[level=0]
fill 328 61 -149 368 61 -149 minecraft:water[level=0]
setblock 369 61 -149 minecraft:kelp_plant
setblock 370 61 -149 minecraft:kelp[age=25]
fill 371 61 -149 391 61 -149 minecraft:water[level=0]
fill 328 61 -150 391 61 -150 minecraft:water[level=0]
fill 328 61 -151 385 61 -151 minecraft:water[level=0]
setblock 386 61 -151 minecraft:kelp_plant
fill 387 61 -151 391 61 -151 minecraft:water[level=0]
fill 328 61 -152 367 61 -152 minecraft:water[level=0]
setblock 368 61 -152 minecraft:kelp_plant
setblock 369 61 -152 minecraft:kelp[age=25]
setblock 370 61 -152 minecraft:water[level=0]
setblock 371 61 -152 minecraft:kelp_plant
fill 372 61 -152 376 61 -152 minecraft:water[level=0]
setblock 377 61 -152 minecraft:kelp_plant
fill 378 61 -152 385 61 -152 minecraft:water[level=0]
setblock 386 61 -152 minecraft:kelp_plant
fill 387 61 -152 390 61 -152 minecraft:water[level=0]
setblock 391 61 -152 minecraft:kelp_plant
fill 328 61 -153 369 61 -153 minecraft:water[level=0]
setblock 370 61 -153 minecraft:kelp_plant
setblock 371 61 -153 minecraft:water[level=0]
setblock 372 61 -153 minecraft:kelp_plant
fill 373 61 -153 380 61 -153 minecraft:water[level=0]
fill 381 61 -153 382 61 -153 minecraft:kelp_plant
setblock 383 61 -153 minecraft:water[level=0]
fill 384 61 -153 385 61 -153 minecraft:kelp_plant
fill 386 61 -153 389 61 -153 minecraft:water[level=0]
setblock 390 61 -153 minecraft:kelp_plant
setblock 391 61 -153 minecraft:water[level=0]
fill 328 61 -154 372 61 -154 minecraft:water[level=0]
setblock 373 61 -154 minecraft:kelp_plant
fill 374 61 -154 375 61 -154 minecraft:water[level=0]
setblock 376 61 -154 minecraft:kelp_plant
fill 377 61 -154 391 61 -154 minecraft:water[level=0]
fill 328 61 -155 376 61 -155 minecraft:water[level=0]
fill 377 61 -155 379 61 -155 minecraft:kelp_plant
setblock 380 61 -155 minecraft:water[level=0]
setblock 381 61 -155 minecraft:kelp_plant
fill 382 61 -155 391 61 -155 minecraft:water[level=0]
fill 328 61 -156 368 61 -156 minecraft:water[level=0]
setblock 369 61 -156 minecraft:kelp_plant
fill 370 61 -156 372 61 -156 minecraft:water[level=0]
setblock 373 61 -156 minecraft:kelp_plant
fill 374 61 -156 381 61 -156 minecraft:water[level=0]
fill 382 61 -156 383 61 -156 minecraft:kelp_plant
fill 384 61 -156 391 61 -156 minecraft:water[level=0]
fill 328 61 -157 368 61 -157 minecraft:water[level=0]
setblock 369 61 -157 minecraft:kelp_plant
fill 370 61 -157 376 61 -157 minecraft:water[level=0]
setblock 377 61 -157 minecraft:kelp_plant
fill 378 61 -157 380 61 -157 minecraft:water[level=0]
setblock 381 61 -157 minecraft:kelp_plant
fill 382 61 -157 390 61 -157 minecraft:water[level=0]
setblock 391 61 -157 minecraft:kelp_plant
fill 328 61 -158 379 61 -158 minecraft:water[level=0]
setblock 380 61 -158 minecraft:kelp_plant
fill 381 61 -158 391 61 -158 minecraft:water[level=0]
fill 328 61 -159 369 61 -159 minecraft:water[level=0]
fill 370 61 -159 371 61 -159 minecraft:kelp_plant
fill 372 61 -159 391 61 -159 minecraft:water[level=0]
fill 329 61 -160 369 61 -160 minecraft:water[level=0]
setblock 370 61 -160 minecraft:kelp_plant
fill 371 61 -160 375 61 -160 minecraft:water[level=0]
setblock 376 61 -160 minecraft:kelp_plant
fill 377 61 -160 389 61 -160 minecraft:water[level=0]
setblock 390 61 -160 minecraft:kelp_plant
setblock 391 61 -160 minecraft:water[level=0]
fill 330 61 -161 366 61 -161 minecraft:water[level=0]
fill 367 61 -161 368 61 -161 minecraft:kelp[age=25]
setblock 369 61 -161 minecraft:water[level=0]
setblock 370 61 -161 minecraft:kelp_plant
setblock 371 61 -161 minecraft:water[level=0]
setblock 372 61 -161 minecraft:kelp_plant
fill 373 61 -161 376 61 -161 minecraft:water[level=0]
setblock 377 61 -161 minecraft:kelp_plant
fill 378 61 -161 391 61 -161 minecraft:water[level=0]
fill 331 61 -162 369 61 -162 minecraft:water[level=0]
fill 370 61 -162 371 61 -162 minecraft:kelp_plant
setblock 372 61 -162 minecraft:water[level=0]
setblock 373 61 -162 minecraft:kelp[age=25]
fill 374 61 -162 377 61 -162 minecraft:water[level=0]
setblock 378 61 -162 minecraft:kelp_plant
setblock 379 61 -162 minecraft:water[level=0]
setblock 380 61 -162 minecraft:kelp_plant
fill 381 61 -162 391 61 -162 minecraft:water[level=0]
fill 331 61 -163 391 61 -163 minecraft:water[level=0]
fill 331 61 -164 371 61 -164 minecraft:water[level=0]
setblock 372 61 -164 minecraft:kelp_plant
setblock 373 61 -164 minecraft:kelp[age=25]
fill 374 61 -164 377 61 -164 minecraft:water[level=0]
setblock 378 61 -164 minecraft:kelp_plant
fill 379 61 -164 391 61 -164 minecraft:water[level=0]
fill 331 61 -165 375 61 -165 minecraft:water[level=0]
setblock 376 61 -165 minecraft:kelp_plant
fill 377 61 -165 380 61 -165 minecraft:water[level=0]
setblock 381 61 -165 minecraft:kelp_plant
fill 382 61 -165 391 61 -165 minecraft:water[level=0]
fill 331 61 -166 380 61 -166 minecraft:water[level=0]
setblock 381 61 -166 minecraft:kelp_plant
fill 382 61 -166 391 61 -166 minecraft:water[level=0]
fill 330 61 -167 385 61 -167 minecraft:water[level=0]
setblock 386 61 -167 minecraft:kelp_plant
fill 387 61 -167 391 61 -167 minecraft:water[level=0]
fill 328 61 -168 376 61 -168 minecraft:water[level=0]
setblock 377 61 -168 minecraft:kelp_plant
fill 378 61 -168 380 61 -168 minecraft:water[level=0]
setblock 381 61 -168 minecraft:kelp_plant
setblock 382 61 -168 minecraft:kelp[age=25]
setblock 383 61 -168 minecraft:kelp_plant
fill 384 61 -168 391 61 -168 minecraft:water[level=0]
fill 328 61 -169 351 61 -169 minecraft:water[level=0]
setblock 352 61 -169 minecraft:kelp_plant
fill 353 61 -169 375 61 -169 minecraft:water[level=0]
setblock 376 61 -169 minecraft:kelp_plant
fill 377 61 -169 379 61 -169 minecraft:water[level=0]
fill 380 61 -169 381 61 -169 minecraft:kelp_plant
fill 382 61 -169 391 61 -169 minecraft:water[level=0]
fill 328 61 -170 369 61 -170 minecraft:water[level=0]
setblock 370 61 -170 minecraft:kelp_plant
fill 371 61 -170 374 61 -170 minecraft:water[level=0]
setblock 375 61 -170 minecraft:kelp_plant
setblock 376 61 -170 minecraft:water[level=0]
setblock 377 61 -170 minecraft:kelp_plant
fill 378 61 -170 383 61 -170 minecraft:water[level=0]
setblock 384 61 -170 minecraft:kelp_plant
fill 385 61 -170 390 61 -170 minecraft:water[level=0]
setblock 391 61 -170 minecraft:kelp_plant
fill 328 61 -171 368 61 -171 minecraft:water[level=0]
fill 369 61 -171 370 61 -171 minecraft:kelp_plant
setblock 371 61 -171 minecraft:water[level=0]
setblock 372 61 -171 minecraft:kelp[age=25]
fill 373 61 -171 383 61 -171 minecraft:water[level=0]
setblock 384 61 -171 minecraft:kelp_plant
fill 385 61 -171 391 61 -171 minecraft:water[level=0]
fill 328 61 -172 367 61 -172 minecraft:water[level=0]
setblock 368 61 -172 minecraft:kelp_plant
fill 369 61 -172 370 61 -172 minecraft:water[level=0]
setblock 371 61 -172 minecraft:kelp[age=25]
fill 372 61 -172 374 61 -172 minecraft:water[level=0]
setblock 375 61 -172 minecraft:kelp_plant
fill 376 61 -172 379 61 -172 minecraft:water[level=0]
fill 380 61 -172 381 61 -172 minecraft:kelp_plant
setblock 382 61 -172 minecraft:kelp[age=25]
setblock 383 61 -172 minecraft:water[level=0]
setblock 384 61 -172 minecraft:kelp_plant
fill 385 61 -172 386 61 -172 minecraft:water[level=0]
setblock 387 61 -172 minecraft:kelp_plant
fill 388 61 -172 391 61 -172 minecraft:water[level=0]
fill 328 61 -173 367 61 -173 minecraft:water[level=0]
setblock 368 61 -173 minecraft:kelp_plant
fill 369 61 -173 370 61 -173 minecraft:water[level=0]
setblock 371 61 -173 minecraft:kelp_plant
fill 372 61 -173 382 61 -173 minecraft:water[level=0]
setblock 383 61 -173 minecraft:kelp_plant
fill 384 61 -173 385 61 -173 minecraft:water[level=0]
setblock 386 61 -173 minecraft:kelp_plant
fill 387 61 -173 391 61 -173 minecraft:water[level=0]
fill 330 61 -174 376 61 -174 minecraft:water[level=0]
setblock 377 61 -174 minecraft:kelp_plant
fill 378 61 -174 387 61 -174 minecraft:water[level=0]
setblock 388 61 -174 minecraft:kelp[age=25]
setblock 389 61 -174 minecraft:kelp_plant
fill 390 61 -174 391 61 -174 minecraft:water[level=0]
fill 330 61 -175 356 61 -175 minecraft:water[level=0]
setblock 357 61 -175 minecraft:kelp_plant
fill 358 61 -175 366 61 -175 minecraft:water[level=0]
fill 367 61 -175 368 61 -175 minecraft:kelp_plant
fill 369 61 -175 379 61 -175 minecraft:water[level=0]
setblock 380 61 -175 minecraft:kelp_plant
setblock 381 61 -175 minecraft:water[level=0]
setblock 382 61 -175 minecraft:kelp[age=25]
fill 383 61 -175 384 61 -175 minecraft:water[level=0]
setblock 385 61 -175 minecraft:kelp_plant
setblock 386 61 -175 minecraft:water[level=0]
setblock 387 61 -175 minecraft:kelp_plant
fill 388 61 -175 391 61 -175 minecraft:water[level=0]
fill 331 61 -176 370 61 -176 minecraft:water[level=0]
setblock 371 61 -176 minecraft:kelp_plant
fill 372 61 -176 376 61 -176 minecraft:water[level=0]
setblock 377 61 -176 minecraft:kelp_plant
fill 378 61 -176 380 61 -176 minecraft:water[level=0]
setblock 381 61 -176 minecraft:kelp_plant
fill 382 61 -176 386 61 -176 minecraft:water[level=0]
setblock 387 61 -176 minecraft:kelp_plant
setblock 388 61 -176 minecraft:water[level=0]
setblock 389 61 -176 minecraft:kelp_plant
fill 390 61 -176 391 61 -176 minecraft:water[level=0]
fill 331 61 -177 363 61 -177 minecraft:water[level=0]
setblock 364 61 -177 minecraft:kelp_plant
setblock 365 61 -177 minecraft:kelp[age=25]
setblock 366 61 -177 minecraft:water[level=0]
fill 367 61 -177 368 61 -177 minecraft:kelp_plant
fill 369 61 -177 371 61 -177 minecraft:water[level=0]
fill 372 61 -177 373 61 -177 minecraft:kelp_plant
fill 374 61 -177 379 61 -177 minecraft:water[level=0]
setblock 380 61 -177 minecraft:kelp_plant
setblock 381 61 -177 minecraft:water[level=0]
fill 382 61 -177 383 61 -177 minecraft:kelp_plant
fill 384 61 -177 388 61 -177 minecraft:water[level=0]
setblock 389 61 -177 minecraft:kelp_plant
fill 390 61 -177 391 61 -177 minecraft:water[level=0]
fill 331 61 -178 356 61 -178 minecraft:water[level=0]
setblock 357 61 -178 minecraft:kelp_plant
fill 358 61 -178 366 61 -178 minecraft:water[level=0]
fill 367 61 -178 368 61 -178 minecraft:kelp_plant
fill 369 61 -178 372 61 -178 minecraft:water[level=0]
setblock 373 61 -178 minecraft:kelp_plant
fill 374 61 -178 376 61 -178 minecraft:water[level=0]
fill 377 61 -178 378 61 -178 minecraft:kelp_plant
fill 379 61 -178 381 61 -178 minecraft:water[level=0]
setblock 382 61 -178 minecraft:kelp_plant
fill 383 61 -178 391 61 -178 minecraft:water[level=0]
fill 331 61 -179 353 61 -179 minecraft:water[level=0]
setblock 354 61 -179 minecraft:kelp_plant
fill 355 61 -179 366 61 -179 minecraft:water[level=0]
setblock 367 61 -179 minecraft:kelp_plant
fill 368 61 -179 369 61 -179 minecraft:water[level=0]
setblock 370 61 -179 minecraft:kelp[age=25]
fill 371 61 -179 378 61 -179 minecraft:water[level=0]
setblock 379 61 -179 minecraft:kelp_plant
fill 380 61 -179 381 61 -179 minecraft:water[level=0]
fill 382 61 -179 383 61 -179 minecraft:kelp_plant
fill 384 61 -179 391 61 -179 minecraft:water[level=0]
fill 331 61 -180 354 61 -180 minecraft:water[level=0]
setblock 355 61 -180 minecraft:kelp_plant
fill 356 61 -180 359 61 -180 minecraft:water[level=0]
setblock 360 61 -180 minecraft:kelp_plant
fill 361 61 -180 368 61 -180 minecraft:water[level=0]
setblock 369 61 -180 minecraft:kelp_plant
setblock 370 61 -180 minecraft:water[level=0]
setblock 371 61 -180 minecraft:kelp_plant
fill 372 61 -180 376 61 -180 minecraft:water[level=0]
setblock 377 61 -180 minecraft:kelp_plant
fill 378 61 -180 379 61 -180 minecraft:water[level=0]
setblock 380 61 -180 minecraft:kelp_plant
fill 381 61 -180 391 61 -180 minecraft:water[level=0]
fill 331 61 -181 348 61 -181 minecraft:water[level=0]
setblock 349 61 -181 minecraft:kelp_plant
fill 350 61 -181 352 61 -181 minecraft:water[level=0]
setblock 353 61 -181 minecraft:kelp_plant
setblock 354 61 -181 minecraft:water[level=0]
setblock 355 61 -181 minecraft:kelp_plant
setblock 356 61 -181 minecraft:water[level=0]
setblock 357 61 -181 minecraft:kelp_plant
fill 358 61 -181 376 61 -181 minecraft:water[level=0]
setblock 377 61 -181 minecraft:kelp_plant
setblock 378 61 -181 minecraft:water[level=0]
setblock 379 61 -181 minecraft:kelp[age=25]
setblock 380 61 -181 minecraft:kelp_plant
setblock 381 61 -181 minecraft:water[level=0]
setblock 382 61 -181 minecraft:kelp[age=25]
fill 383 61 -181 389 61 -181 minecraft:water[level=0]
setblock 390 61 -181 minecraft:kelp_plant
setblock 391 61 -181 minecraft:water[level=0]
fill 331 61 -182 353 61 -182 minecraft:water[level=0]
setblock 354 61 -182 minecraft:kelp_plant
fill 355 61 -182 359 61 -182 minecraft:water[level=0]
fill 360 61 -182 362 61 -182 minecraft:kelp_plant
fill 363 61 -182 365 61 -182 minecraft:water[level=0]
fill 366 61 -182 368 61 -182 minecraft:kelp_plant
setblock 369 61 -182 minecraft:water[level=0]
setblock 370 61 -182 minecraft:kelp_plant
fill 371 61 -182 376 61 -182 minecraft:water[level=0]
setblock 377 61 -182 minecraft:kelp_plant
fill 378 61 -182 382 61 -182 minecraft:water[level=0]
setblock 383 61 -182 minecraft:kelp_plant
fill 384 61 -182 386 61 -182 minecraft:water[level=0]
setblock 387 61 -182 minecraft:kelp_plant
fill 388 61 -182 391 61 -182 minecraft:water[level=0]
fill 331 61 -183 346 61 -183 minecraft:water[level=0]
setblock 347 61 -183 minecraft:kelp_plant
fill 348 61 -183 366 61 -183 minecraft:water[level=0]
setblock 367 61 -183 minecraft:kelp[age=25]
setblock 368 61 -183 minecraft:water[level=0]
setblock 369 61 -183 minecraft:kelp_plant
setblock 370 61 -183 minecraft:water[level=0]
setblock 371 61 -183 minecraft:kelp_plant
fill 372 61 -183 386 61 -183 minecraft:water[level=0]
setblock 387 61 -183 minecraft:kelp_plant
fill 388 61 -183 391 61 -183 minecraft:water[level=0]
fill 331 61 -184 345 61 -184 minecraft:water[level=0]
setblock 346 61 -184 minecraft:kelp_plant
fill 347 61 -184 348 61 -184 minecraft:water[level=0]
setblock 349 61 -184 minecraft:kelp_plant
fill 350 61 -184 359 61 -184 minecraft:water[level=0]
fill 360 61 -184 361 61 -184 minecraft:kelp_plant
fill 362 61 -184 369 61 -184 minecraft:water[level=0]
setblock 370 61 -184 minecraft:kelp_plant
fill 371 61 -184 375 61 -184 minecraft:water[level=0]
setblock 376 61 -184 minecraft:kelp_plant
fill 377 61 -184 379 61 -184 minecraft:water[level=0]
setblock 380 61 -184 minecraft:kelp_plant
fill 381 61 -184 386 61 -184 minecraft:water[level=0]
setblock 387 61 -184 minecraft:kelp[age=25]
setblock 388 61 -184 minecraft:kelp_plant
fill 389 61 -184 391 61 -184 minecraft:water[level=0]
fill 331 61 -185 356 61 -185 minecraft:water[level=0]
setblock 357 61 -185 minecraft:kelp_plant
fill 358 61 -185 363 61 -185 minecraft:water[level=0]
setblock 364 61 -185 minecraft:kelp_plant
fill 365 61 -185 370 61 -185 minecraft:water[level=0]
setblock 371 61 -185 minecraft:kelp_plant
fill 372 61 -185 379 61 -185 minecraft:water[level=0]
setblock 380 61 -185 minecraft:kelp_plant
setblock 381 61 -185 minecraft:water[level=0]
setblock 382 61 -185 minecraft:kelp_plant
setblock 383 61 -185 minecraft:water[level=0]
setblock 384 61 -185 minecraft:kelp_plant
fill 385 61 -185 391 61 -185 minecraft:water[level=0]
fill 331 61 -186 359 61 -186 minecraft:water[level=0]
setblock 360 61 -186 minecraft:kelp_plant
fill 361 61 -186 368 61 -186 minecraft:water[level=0]
setblock 369 61 -186 minecraft:kelp[age=25]
fill 370 61 -186 376 61 -186 minecraft:water[level=0]
fill 377 61 -186 378 61 -186 minecraft:kelp_plant
setblock 379 61 -186 minecraft:kelp[age=25]
fill 380 61 -186 391 61 -186 minecraft:water[level=0]
fill 331 61 -187 353 61 -187 minecraft:water[level=0]
setblock 354 61 -187 minecraft:kelp_plant
fill 355 61 -187 356 61 -187 minecraft:water[level=0]
fill 357 61 -187 358 61 -187 minecraft:kelp_plant
fill 359 61 -187 369 61 -187 minecraft:water[level=0]
setblock 370 61 -187 minecraft:kelp_plant
fill 371 61 -187 373 61 -187 minecraft:water[level=0]
setblock 374 61 -187 minecraft:kelp_plant
fill 375 61 -187 380 61 -187 minecraft:water[level=0]
setblock 381 61 -187 minecraft:kelp_plant
fill 382 61 -187 387 61 -187 minecraft:water[level=0]
setblock 388 61 -187 minecraft:kelp_plant
fill 389 61 -187 391 61 -187 minecraft:water[level=0]
fill 330 61 -188 352 61 -188 minecraft:water[level=0]
setblock 353 61 -188 minecraft:kelp_plant
setblock 354 61 -188 minecraft:water[level=0]
fill 355 61 -188 356 61 -188 minecraft:kelp_plant
fill 357 61 -188 362 61 -188 minecraft:water[level=0]
setblock 363 61 -188 minecraft:kelp[age=25]
setblock 364 61 -188 minecraft:water[level=0]
setblock 365 61 -188 minecraft:kelp_plant
setblock 366 61 -188 minecraft:water[level=0]
setblock 367 61 -188 minecraft:kelp[age=25]
setblock 368 61 -188 minecraft:water[level=0]
setblock 369 61 -188 minecraft:kelp_plant
setblock 370 61 -188 minecraft:water[level=0]
setblock 371 61 -188 minecraft:kelp[age=25]
setblock 372 61 -188 minecraft:kelp_plant
setblock 373 61 -188 minecraft:kelp[age=25]
setblock 374 61 -188 minecraft:kelp_plant
fill 375 61 -188 376 61 -188 minecraft:water[level=0]
fill 377 61 -188 378 61 -188 minecraft:kelp_plant
fill 379 61 -188 380 61 -188 minecraft:water[level=0]
setblock 381 61 -188 minecraft:kelp_plant
setblock 382 61 -188 minecraft:water[level=0]
fill 383 61 -188 384 61 -188 minecraft:kelp_plant
fill 385 61 -188 391 61 -188 minecraft:water[level=0]
fill 331 61 -189 351 61 -189 minecraft:water[level=0]
setblock 352 61 -189 minecraft:kelp_plant
fill 353 61 -189 356 61 -189 minecraft:water[level=0]
setblock 357 61 -189 minecraft:kelp_plant
fill 358 61 -189 368 61 -189 minecraft:water[level=0]
setblock 369 61 -189 minecraft:kelp_plant
fill 370 61 -189 375 61 -189 minecraft:water[level=0]
setblock 376 61 -189 minecraft:kelp_plant
fill 377 61 -189 381 61 -189 minecraft:water[level=0]
setblock 382 61 -189 minecraft:kelp_plant
setblock 383 61 -189 minecraft:kelp[age=25]
fill 384 61 -189 391 61 -189 minecraft:water[level=0]
fill 331 61 -190 357 61 -190 minecraft:water[level=0]
setblock 358 61 -190 minecraft:kelp_plant
fill 359 61 -190 364 61 -190 minecraft:water[level=0]
fill 365 61 -190 366 61 -190 minecraft:kelp_plant
setblock 367 61 -190 minecraft:kelp[age=25]
setblock 368 61 -190 minecraft:water[level=0]
setblock 369 61 -190 minecraft:kelp_plant
setblock 370 61 -190 minecraft:kelp[age=25]
fill 371 61 -190 375 61 -190 minecraft:water[level=0]
setblock 376 61 -190 minecraft:kelp_plant
fill 377 61 -190 380 61 -190 minecraft:water[level=0]
fill 381 61 -190 382 61 -190 minecraft:kelp_plant
fill 383 61 -190 387 61 -190 minecraft:water[level=0]
setblock 388 61 -190 minecraft:kelp_plant
fill 389 61 -190 391 61 -190 minecraft:water[level=0]
fill 328 60 -127 340 60 -127 minecraft:water[level=0]
setblock 341 60 -127 minecraft:kelp_plant
fill 342 60 -127 346 60 -127 minecraft:water[level=0]
setblock 347 60 -127 minecraft:kelp_plant
setblock 348 60 -127 minecraft:water[level=0]
setblock 349 60 -127 minecraft:kelp_plant
fill 350 60 -127 353 60 -127 minecraft:water[level=0]
setblock 354 60 -127 minecraft:kelp_plant
fill 355 60 -127 368 60 -127 minecraft:water[level=0]
setblock 369 60 -127 minecraft:kelp_plant
fill 370 60 -127 383 60 -127 minecraft:water[level=0]
setblock 384 60 -127 minecraft:kelp[age=25]
fill 385 60 -127 390 60 -127 minecraft:water[level=0]
setblock 391 60 -127 minecraft:kelp_plant
fill 328 60 -128 337 60 -128 minecraft:water[level=0]
setblock 338 60 -128 minecraft:kelp_plant
fill 339 60 -128 345 60 -128 minecraft:water[level=0]
setblock 346 60 -128 minecraft:kelp_plant
fill 347 60 -128 356 60 -128 minecraft:water[level=0]
setblock 357 60 -128 minecraft:kelp_plant
fill 358 60 -128 359 60 -128 minecraft:water[level=0]
setblock 360 60 -128 minecraft:kelp_plant
fill 361 60 -128 366 60 -128 minecraft:water[level=0]
setblock 367 60 -128 minecraft:kelp_plant
fill 368 60 -128 369 60 -128 minecraft:water[level=0]
setblock 370 60 -128 minecraft:kelp[age=25]
setblock 371 60 -128 minecraft:water[level=0]
setblock 372 60 -128 minecraft:kelp_plant
fill 373 60 -128 377 60 -128 minecraft:water[level=0]
setblock 378 60 -128 minecraft:kelp[age=25]
fill 379 60 -128 380 60 -128 minecraft:kelp_plant
fill 381 60 -128 386 60 -128 minecraft:water[level=0]
setblock 387 60 -128 minecraft:kelp[age=25]
fill 388 60 -128 391 60 -128 minecraft:water[level=0]
fill 328 60 -129 341 60 -129 minecraft:water[level=0]
setblock 342 60 -129 minecraft:kelp_plant
fill 343 60 -129 348 60 -129 minecraft:water[level=0]
setblock 349 60 -129 minecraft:kelp_plant
fill 350 60 -129 358 60 -129 minecraft:water[level=0]
setblock 359 60 -129 minecraft:kelp_plant
fill 360 60 -129 368 60 -129 minecraft:water[level=0]
setblock 369 60 -129 minecraft:kelp_plant
fill 370 60 -129 376 60 -129 minecraft:water[level=0]
setblock 377 60 -129 minecraft:kelp[age=25]
fill 378 60 -129 386 60 -129 minecraft:water[level=0]
setblock 387 60 -129 minecraft:kelp[age=25]
fill 388 60 -129 389 60 -129 minecraft:water[level=0]
setblock 390 60 -129 minecraft:kelp_plant
setblock 391 60 -129 minecraft:water[level=0]
fill 328 60 -130 333 60 -130 minecraft:water[level=0]
setblock 334 60 -130 minecraft:kelp_plant
fill 335 60 -130 362 60 -130 minecraft:water[level=0]
setblock 363 60 -130 minecraft:kelp_plant
fill 364 60 -130 365 60 -130 minecraft:water[level=0]
setblock 366 60 -130 minecraft:kelp_plant
fill 367 60 -130 368 60 -130 minecraft:water[level=0]
setblock 369 60 -130 minecraft:kelp_plant
fill 370 60 -130 391 60 -130 minecraft:water[level=0]
setblock 328 60 -131 minecraft:kelp_plant
fill 329 60 -131 367 60 -131 minecraft:water[level=0]
setblock 368 60 -131 minecraft:kelp[age=25]
fill 369 60 -131 391 60 -131 minecraft:water[level=0]
fill 328 60 -132 362 60 -132 minecraft:water[level=0]
setblock 363 60 -132 minecraft:kelp_plant
fill 364 60 -132 382 60 -132 minecraft:water[level=0]
setblock 383 60 -132 minecraft:kelp[age=25]
fill 384 60 -132 391 60 -132 minecraft:water[level=0]
fill 328 60 -133 356 60 -133 minecraft:water[level=0]
setblock 357 60 -133 minecraft:kelp[age=25]
fill 358 60 -133 387 60 -133 minecraft:water[level=0]
setblock 388 60 -133 minecraft:kelp_plant
fill 389 60 -133 391 60 -133 minecraft:water[level=0]
fill 328 60 -134 336 60 -134 minecraft:water[level=0]
setblock 337 60 -134 minecraft:kelp_plant
fill 338 60 -134 368 60 -134 minecraft:water[level=0]
setblock 369 60 -134 minecraft:kelp_plant
fill 370 60 -134 383 60 -134 minecraft:water[level=0]
setblock 384 60 -134 minecraft:kelp_plant
fill 385 60 -134 391 60 -134 minecraft:water[level=0]
fill 328 60 -135 331 60 -135 minecraft:water[level=0]
setblock 332 60 -135 minecraft:kelp_plant
fill 333 60 -135 347 60 -135 minecraft:water[level=0]
setblock 348 60 -135 minecraft:kelp_plant
setblock 349 60 -135 minecraft:water[level=0]
setblock 350 60 -135 minecraft:kelp_plant
fill 351 60 -135 376 60 -135 minecraft:water[level=0]
setblock 377 60 -135 minecraft:kelp[age=25]
fill 378 60 -135 379 60 -135 minecraft:water[level=0]
setblock 380 60 -135 minecraft:kelp[age=25]
fill 381 60 -135 391 60 -135 minecraft:water[level=0]
fill 328 60 -136 342 60 -136 minecraft:water[level=0]
setblock 343 60 -136 minecraft:kelp_plant
fill 344 60 -136 345 60 -136 minecraft:water[level=0]
setblock 346 60 -136 minecraft:kelp_plant
fill 347 60 -136 348 60 -136 minecraft:water[level=0]
setblock 349 60 -136 minecraft:kelp_plant
fill 350 60 -136 364 60 -136 minecraft:water[level=0]
setblock 365 60 -136 minecraft:kelp_plant
fill 366 60 -136 374 60 -136 minecraft:water[level=0]
setblock 375 60 -136 minecraft:kelp_plant
fill 376 60 -136 387 60 -136 minecraft:water[level=0]
setblock 388 60 -136 minecraft:kelp[age=25]
fill 389 60 -136 391 60 -136 minecraft:water[level=0]
setblock 328 60 -137 minecraft:kelp_plant
fill 329 60 -137 330 60 -137 minecraft:water[level=0]
setblock 331 60 -137 minecraft:kelp_plant
fill 332 60 -137 391 60 -137 minecraft:water[level=0]
fill 328 60 -138 366 60 -138 minecraft:water[level=0]
setblock 367 60 -138 minecraft:kelp_plant
fill 368 60 -138 388 60 -138 minecraft:water[level=0]
setblock 389 60 -138 minecraft:kelp[age=25]
fill 390 60 -138 391 60 -138 minecraft:water[level=0]
fill 328 60 -139 371 60 -139 minecraft:water[level=0]
setblock 372 60 -139 minecraft:kelp_plant
fill 373 60 -139 383 60 -139 minecraft:water[level=0]
setblock 384 60 -139 minecraft:kelp_plant
fill 385 60 -139 391 60 -139 minecraft:water[level=0]
fill 328 60 -140 354 60 -140 minecraft:water[level=0]
setblock 355 60 -140 minecraft:kelp_plant
fill 356 60 -140 368 60 -140 minecraft:water[level=0]
setblock 369 60 -140 minecraft:kelp_plant
setblock 370 60 -140 minecraft:water[level=0]
setblock 371 60 -140 minecraft:kelp_plant
fill 372 60 -140 377 60 -140 minecraft:water[level=0]
setblock 378 60 -140 minecraft:kelp_plant
fill 379 60 -140 391 60 -140 minecraft:water[level=0]
fill 328 60 -141 355 60 -141 minecraft:water[level=0]
setblock 356 60 -141 minecraft:kelp_plant
fill 357 60 -141 368 60 -141 minecraft:water[level=0]
setblock 369 60 -141 minecraft:kelp_plant
fill 370 60 -141 382 60 -141 minecraft:water[level=0]
setblock 383 60 -141 minecraft:kelp_plant
fill 384 60 -141 387 60 -141 minecraft:water[level=0]
setblock 388 60 -141 minecraft:kelp_plant
setblock 389 60 -141 minecraft:kelp[age=25]
fill 390 60 -141 391 60 -141 minecraft:water[level=0]
fill 328 60 -142 352 60 -142 minecraft:water[level=0]
setblock 353 60 -142 minecraft:kelp_plant
fill 354 60 -142 367 60 -142 minecraft:water[level=0]
setblock 368 60 -142 minecraft:kelp_plant
fill 369 60 -142 370 60 -142 minecraft:water[level=0]
fill 371 60 -142 372 60 -142 minecraft:kelp_plant
fill 373 60 -142 391 60 -142 minecraft:water[level=0]
fill 328 60 -143 331 60 -143 minecraft:water[level=0]
setblock 332 60 -143 minecraft:kelp_plant
fill 333 60 -143 337 60 -143 minecraft:water[level=0]
setblock 338 60 -143 minecraft:kelp_plant
fill 339 60 -143 377 60 -143 minecraft:water[level=0]
setblock 378 60 -143 minecraft:kelp_plant
setblock 379 60 -143 minecraft:kelp[age=25]
fill 380 60 -143 382 60 -143 minecraft:water[level=0]
setblock 383 60 -143 minecraft:kelp_plant
fill 384 60 -143 385 60 -143 minecraft:water[level=0]
setblock 386 60 -143 minecraft:kelp_plant
fill 387 60 -143 391 60 -143 minecraft:water[level=0]
fill 328 60 -144 351 60 -144 minecraft:water[level=0]
setblock 352 60 -144 minecraft:kelp_plant
fill 353 60 -144 370 60 -144 minecraft:water[level=0]
setblock 371 60 -144 minecraft:kelp_plant
fill 372 60 -144 391 60 -144 minecraft:water[level=0]
fill 328 60 -145 383 60 -145 minecraft:water[level=0]
setblock 384 60 -145 minecraft:kelp[age=25]
setblock 385 60 -145 minecraft:water[level=0]
setblock 386 60 -145 minecraft:kelp_plant
fill 387 60 -145 388 60 -145 minecraft:water[level=0]
setblock 389 60 -145 minecraft:kelp_plant
fill 390 60 -145 391 60 -145 minecraft:water[level=0]
fill 328 60 -146 371 60 -146 minecraft:water[level=0]
setblock 372 60 -146 minecraft:kelp_plant
fill 373 60 -146 391 60 -146 minecraft:water[level=0]
fill 328 60 -147 374 60 -147 minecraft:water[level=0]
setblock 375 60 -147 minecraft:kelp_plant
fill 376 60 -147 385 60 -147 minecraft:water[level=0]
setblock 386 60 -147 minecraft:kelp_plant
fill 387 60 -147 391 60 -147 minecraft:water[level=0]
fill 328 60 -148 374 60 -148 minecraft:water[level=0]
setblock 375 60 -148 minecraft:kelp_plant
fill 376 60 -148 377 60 -148 minecraft:water[level=0]
setblock 378 60 -148 minecraft:kelp_plant
fill 379 60 -148 386 60 -148 minecraft:water[level=0]
setblock 387 60 -148 minecraft:kelp_plant
setblock 388 60 -148 minecraft:water[level=0]
setblock 389 60 -148 minecraft:kelp_plant
fill 390 60 -148 391 60 -148 minecraft:water[level=0]
fill 328 60 -149 368 60 -149 minecraft:water[level=0]
fill 369 60 -149 370 60 -149 minecraft:kelp_plant
fill 371 60 -149 377 60 -149 minecraft:water[level=0]
setblock 378 60 -149 minecraft:kelp[age=25]
fill 379 60 -149 391 60 -149 minecraft:water[level=0]
fill 328 60 -150 391 60 -150 minecraft:water[level=0]
fill 328 60 -151 385 60 -151 minecraft:water[level=0]
setblock 386 60 -151 minecraft:kelp_plant
fill 387 60 -151 391 60 -151 minecraft:water[level=0]
fill 328 60 -152 367 60 -152 minecraft:water[level=0]
fill 368 60 -152 369 60 -152 minecraft:kelp_plant
setblock 370 60 -152 minecraft:water[level=0]
setblock 371 60 -152 minecraft:kelp_plant
fill 372 60 -152 376 60 -152 minecraft:water[level=0]
setblock 377 60 -152 minecraft:kelp_plant
fill 378 60 -152 385 60 -152 minecraft:water[level=0]
setblock 386 60 -152 minecraft:kelp_plant
fill 387 60 -152 390 60 -152 minecraft:water[level=0]
setblock 391 60 -152 minecraft:kelp_plant
fill 328 60 -153 369 60 -153 minecraft:water[level=0]
setblock 370 60 -153 minecraft:kelp_plant
setblock 371 60 -153 minecraft:water[level=0]
setblock 372 60 -153 minecraft:kelp_plant
fill 373 60 -153 380 60 -153 minecraft:water[level=0]
fill 381 60 -153 382 60 -153 minecraft:kelp_plant
setblock 383 60 -153 minecraft:water[level=0]
fill 384 60 -153 385 60 -153 minecraft:kelp_plant
fill 386 60 -153 389 60 -153 minecraft:water[level=0]
setblock 390 60 -153 minecraft:kelp_plant
setblock 391 60 -153 minecraft:water[level=0]
fill 328 60 -154 372 60 -154 minecraft:water[level=0]
setblock 373 60 -154 minecraft:kelp_plant
fill 374 60 -154 375 60 -154 minecraft:water[level=0]
setblock 376 60 -154 minecraft:kelp_plant
fill 377 60 -154 391 60 -154 minecraft:water[level=0]
fill 328 60 -155 376 60 -155 minecraft:water[level=0]
fill 377 60 -155 379 60 -155 minecraft:kelp_plant
setblock 380 60 -155 minecraft:water[level=0]
setblock 381 60 -155 minecraft:kelp_plant
fill 382 60 -155 391 60 -155 minecraft:water[level=0]
fill 328 60 -156 368 60 -156 minecraft:water[level=0]
setblock 369 60 -156 minecraft:kelp_plant
fill 370 60 -156 372 60 -156 minecraft:water[level=0]
setblock 373 60 -156 minecraft:kelp_plant
fill 374 60 -156 381 60 -156 minecraft:water[level=0]
fill 382 60 -156 383 60 -156 minecraft:kelp_plant
fill 384 60 -156 391 60 -156 minecraft:water[level=0]
fill 328 60 -157 368 60 -157 minecraft:water[level=0]
setblock 369 60 -157 minecraft:kelp_plant
fill 370 60 -157 376 60 -157 minecraft:water[level=0]
setblock 377 60 -157 minecraft:kelp_plant
fill 378 60 -157 380 60 -157 minecraft:water[level=0]
setblock 381 60 -157 minecraft:kelp_plant
fill 382 60 -157 390 60 -157 minecraft:water[level=0]
setblock 391 60 -157 minecraft:kelp_plant
fill 328 60 -158 379 60 -158 minecraft:water[level=0]
setblock 380 60 -158 minecraft:kelp_plant
fill 381 60 -158 391 60 -158 minecraft:water[level=0]
fill 328 60 -159 369 60 -159 minecraft:water[level=0]
fill 370 60 -159 371 60 -159 minecraft:kelp_plant
fill 372 60 -159 374 60 -159 minecraft:water[level=0]
setblock 375 60 -159 minecraft:kelp[age=25]
fill 376 60 -159 391 60 -159 minecraft:water[level=0]
fill 329 60 -160 369 60 -160 minecraft:water[level=0]
setblock 370 60 -160 minecraft:kelp_plant
fill 371 60 -160 375 60 -160 minecraft:water[level=0]
setblock 376 60 -160 minecraft:kelp_plant
fill 377 60 -160 389 60 -160 minecraft:water[level=0]
setblock 390 60 -160 minecraft:kelp_plant
setblock 391 60 -160 minecraft:water[level=0]
fill 331 60 -161 366 60 -161 minecraft:water[level=0]
fill 367 60 -161 368 60 -161 minecraft:kelp_plant
setblock 369 60 -161 minecraft:water[level=0]
setblock 370 60 -161 minecraft:kelp_plant
setblock 371 60 -161 minecraft:water[level=0]
setblock 372 60 -161 minecraft:kelp_plant
fill 373 60 -161 376 60 -161 minecraft:water[level=0]
setblock 377 60 -161 minecraft:kelp_plant
fill 378 60 -161 391 60 -161 minecraft:water[level=0]
fill 331 60 -162 369 60 -162 minecraft:water[level=0]
fill 370 60 -162 371 60 -162 minecraft:kelp_plant
setblock 372 60 -162 minecraft:water[level=0]
setblock 373 60 -162 minecraft:kelp_plant
fill 374 60 -162 377 60 -162 minecraft:water[level=0]
setblock 378 60 -162 minecraft:kelp_plant
setblock 379 60 -162 minecraft:water[level=0]
setblock 380 60 -162 minecraft:kelp_plant
fill 381 60 -162 391 60 -162 minecraft:water[level=0]
fill 331 60 -163 391 60 -163 minecraft:water[level=0]
fill 332 60 -164 368 60 -164 minecraft:water[level=0]
setblock 369 60 -164 minecraft:kelp[age=25]
fill 370 60 -164 371 60 -164 minecraft:water[level=0]
fill 372 60 -164 373 60 -164 minecraft:kelp_plant
fill 374 60 -164 377 60 -164 minecraft:water[level=0]
setblock 378 60 -164 minecraft:kelp_plant
fill 379 60 -164 380 60 -164 minecraft:water[level=0]
setblock 381 60 -164 minecraft:kelp[age=25]
fill 382 60 -164 391 60 -164 minecraft:water[level=0]
fill 331 60 -165 363 60 -165 minecraft:water[level=0]
setblock 364 60 -165 minecraft:kelp[age=25]
fill 365 60 -165 375 60 -165 minecraft:water[level=0]
setblock 376 60 -165 minecraft:kelp_plant
fill 377 60 -165 380 60 -165 minecraft:water[level=0]
setblock 381 60 -165 minecraft:kelp_plant
fill 382 60 -165 391 60 -165 minecraft:water[level=0]
fill 331 60 -166 380 60 -166 minecraft:water[level=0]
setblock 381 60 -166 minecraft:kelp_plant
fill 382 60 -166 391 60 -166 minecraft:water[level=0]
fill 330 60 -167 379 60 -167 minecraft:water[level=0]
fill 380 60 -167 381 60 -167 minecraft:kelp[age=25]
fill 382 60 -167 383 60 -167 minecraft:water[level=0]
setblock 384 60 -167 minecraft:kelp[age=25]
setblock 385 60 -167 minecraft:water[level=0]
setblock 386 60 -167 minecraft:kelp_plant
fill 387 60 -167 391 60 -167 minecraft:water[level=0]
fill 329 60 -168 376 60 -168 minecraft:water[level=0]
setblock 377 60 -168 minecraft:kelp_plant
fill 378 60 -168 380 60 -168 minecraft:water[level=0]
fill 381 60 -168 383 60 -168 minecraft:kelp_plant
fill 384 60 -168 391 60 -168 minecraft:water[level=0]
fill 328 60 -169 351 60 -169 minecraft:water[level=0]
setblock 352 60 -169 minecraft:kelp_plant
fill 353 60 -169 375 60 -169 minecraft:water[level=0]
setblock 376 60 -169 minecraft:kelp_plant
fill 377 60 -169 379 60 -169 minecraft:water[level=0]
fill 380 60 -169 381 60 -169 minecraft:kelp_plant
fill 382 60 -169 391 60 -169 minecraft:water[level=0]
fill 328 60 -170 369 60 -170 minecraft:water[level=0]
setblock 370 60 -170 minecraft:kelp_plant
fill 371 60 -170 374 60 -170 minecraft:water[level=0]
setblock 375 60 -170 minecraft:kelp_plant
setblock 376 60 -170 minecraft:water[level=0]
setblock 377 60 -170 minecraft:kelp_plant
setblock 378 60 -170 minecraft:kelp[age=25]
fill 379 60 -170 383 60 -170 minecraft:water[level=0]
setblock 384 60 -170 minecraft:kelp_plant
fill 385 60 -170 390 60 -170 minecraft:water[level=0]
setblock 391 60 -170 minecraft:kelp_plant
fill 328 60 -171 368 60 -171 minecraft:water[level=0]
fill 369 60 -171 370 60 -171 minecraft:kelp_plant
setblock 371 60 -171 minecraft:water[level=0]
setblock 372 60 -171 minecraft:kelp_plant
fill 373 60 -171 374 60 -171 minecraft:water[level=0]
setblock 375 60 -171 minecraft:kelp[age=25]
fill 376 60 -171 383 60 -171 minecraft:water[level=0]
setblock 384 60 -171 minecraft:kelp_plant
fill 385 60 -171 391 60 -171 minecraft:water[level=0]
fill 328 60 -172 356 60 -172 minecraft:water[level=0]
setblock 357 60 -172 minecraft:kelp[age=25]
fill 358 60 -172 367 60 -172 minecraft:water[level=0]
setblock 368 60 -172 minecraft:kelp_plant
fill 369 60 -172 370 60 -172 minecraft:water[level=0]
setblock 371 60 -172 minecraft:kelp_plant
fill 372 60 -172 374 60 -172 minecraft:water[level=0]
setblock 375 60 -172 minecraft:kelp_plant
fill 376 60 -172 379 60 -172 minecraft:water[level=0]
fill 380 60 -172 382 60 -172 minecraft:kelp_plant
setblock 383 60 -172 minecraft:water[level=0]
setblock 384 60 -172 minecraft:kelp_plant
fill 385 60 -172 386 60 -172 minecraft:water[level=0]
setblock 387 60 -172 minecraft:kelp_plant
fill 388 60 -172 391 60 -172 minecraft:water[level=0]
fill 329 60 -173 367 60 -173 minecraft:water[level=0]
setblock 368 60 -173 minecraft:kelp_plant
fill 369 60 -173 370 60 -173 minecraft:water[level=0]
setblock 371 60 -173 minecraft:kelp_plant
fill 372 60 -173 382 60 -173 minecraft:water[level=0]
setblock 383 60 -173 minecraft:kelp_plant
fill 384 60 -173 385 60 -173 minecraft:water[level=0]
setblock 386 60 -173 minecraft:kelp_plant
fill 387 60 -173 391 60 -173 minecraft:water[level=0]
fill 330 60 -174 358 60 -174 minecraft:water[level=0]
setblock 359 60 -174 minecraft:kelp[age=25]
fill 360 60 -174 376 60 -174 minecraft:water[level=0]
setblock 377 60 -174 minecraft:kelp_plant
fill 378 60 -174 387 60 -174 minecraft:water[level=0]
fill 388 60 -174 389 60 -174 minecraft:kelp_plant
fill 390 60 -174 391 60 -174 minecraft:water[level=0]
fill 331 60 -175 356 60 -175 minecraft:water[level=0]
setblock 357 60 -175 minecraft:kelp_plant
fill 358 60 -175 366 60 -175 minecraft:water[level=0]
fill 367 60 -175 368 60 -175 minecraft:kelp_plant
fill 369 60 -175 379 60 -175 minecraft:water[level=0]
setblock 380 60 -175 minecraft:kelp_plant
setblock 381 60 -175 minecraft:water[level=0]
setblock 382 60 -175 minecraft:kelp_plant
fill 383 60 -175 384 60 -175 minecraft:water[level=0]
setblock 385 60 -175 minecraft:kelp_plant
setblock 386 60 -175 minecraft:water[level=0]
setblock 387 60 -175 minecraft:kelp_plant
fill 388 60 -175 391 60 -175 minecraft:water[level=0]
fill 331 60 -176 370 60 -176 minecraft:water[level=0]
setblock 371 60 -176 minecraft:kelp_plant
setblock 372 60 -176 minecraft:kelp[age=25]
fill 373 60 -176 376 60 -176 minecraft:water[level=0]
setblock 377 60 -176 minecraft:kelp_plant
fill 378 60 -176 380 60 -176 minecraft:water[level=0]
setblock 381 60 -176 minecraft:kelp_plant
fill 382 60 -176 386 60 -176 minecraft:water[level=0]
setblock 387 60 -176 minecraft:kelp_plant
setblock 388 60 -176 minecraft:water[level=0]
setblock 389 60 -176 minecraft:kelp_plant
fill 390 60 -176 391 60 -176 minecraft:water[level=0]
fill 331 60 -177 363 60 -177 minecraft:water[level=0]
fill 364 60 -177 365 60 -177 minecraft:kelp_plant
setblock 366 60 -177 minecraft:water[level=0]
fill 367 60 -177 368 60 -177 minecraft:kelp_plant
fill 369 60 -177 371 60 -177 minecraft:water[level=0]
fill 372 60 -177 373 60 -177 minecraft:kelp_plant
fill 374 60 -177 379 60 -177 minecraft:water[level=0]
setblock 380 60 -177 minecraft:kelp_plant
setblock 381 60 -177 minecraft:water[level=0]
fill 382 60 -177 383 60 -177 minecraft:kelp_plant
fill 384 60 -177 388 60 -177 minecraft:water[level=0]
setblock 389 60 -177 minecraft:kelp_plant
fill 390 60 -177 391 60 -177 minecraft:water[level=0]
fill 331 60 -178 356 60 -178 minecraft:water[level=0]
setblock 357 60 -178 minecraft:kelp_plant
fill 358 60 -178 366 60 -178 minecraft:water[level=0]
fill 367 60 -178 368 60 -178 minecraft:kelp_plant
fill 369 60 -178 372 60 -178 minecraft:water[level=0]
setblock 373 60 -178 minecraft:kelp_plant
fill 374 60 -178 376 60 -178 minecraft:water[level=0]
fill 377 60 -178 378 60 -178 minecraft:kelp_plant
fill 379 60 -178 381 60 -178 minecraft:water[level=0]
setblock 382 60 -178 minecraft:kelp_plant
fill 383 60 -178 391 60 -178 minecraft:water[level=0]
fill 331 60 -179 353 60 -179 minecraft:water[level=0]
setblock 354 60 -179 minecraft:kelp_plant
fill 355 60 -179 366 60 -179 minecraft:water[level=0]
setblock 367 60 -179 minecraft:kelp_plant
fill 368 60 -179 369 60 -179 minecraft:water[level=0]
setblock 370 60 -179 minecraft:kelp_plant
fill 371 60 -179 378 60 -179 minecraft:water[level=0]
setblock 379 60 -179 minecraft:kelp_plant
fill 380 60 -179 381 60 -179 minecraft:water[level=0]
fill 382 60 -179 383 60 -179 minecraft:kelp_plant
fill 384 60 -179 386 60 -179 minecraft:water[level=0]
setblock 387 60 -179 minecraft:kelp[age=25]
fill 388 60 -179 391 60 -179 minecraft:water[level=0]
fill 331 60 -180 353 60 -180 minecraft:water[level=0]
setblock 354 60 -180 minecraft:kelp[age=25]
setblock 355 60 -180 minecraft:kelp_plant
fill 356 60 -180 359 60 -180 minecraft:water[level=0]
setblock 360 60 -180 minecraft:kelp_plant
fill 361 60 -180 368 60 -180 minecraft:water[level=0]
setblock 369 60 -180 minecraft:kelp_plant
setblock 370 60 -180 minecraft:water[level=0]
setblock 371 60 -180 minecraft:kelp_plant
fill 372 60 -180 376 60 -180 minecraft:water[level=0]
setblock 377 60 -180 minecraft:kelp_plant
fill 378 60 -180 379 60 -180 minecraft:water[level=0]
setblock 380 60 -180 minecraft:kelp_plant
fill 381 60 -180 391 60 -180 minecraft:water[level=0]
fill 331 60 -181 348 60 -181 minecraft:water[level=0]
setblock 349 60 -181 minecraft:kelp_plant
fill 350 60 -181 352 60 -181 minecraft:water[level=0]
setblock 353 60 -181 minecraft:kelp_plant
setblock 354 60 -181 minecraft:water[level=0]
setblock 355 60 -181 minecraft:kelp_plant
setblock 356 60 -181 minecraft:water[level=0]
setblock 357 60 -181 minecraft:kelp_plant
fill 358 60 -181 374 60 -181 minecraft:water[level=0]
setblock 375 60 -181 minecraft:kelp[age=25]
setblock 376 60 -181 minecraft:water[level=0]
setblock 377 60 -181 minecraft:kelp_plant
setblock 378 60 -181 minecraft:water[level=0]
fill 379 60 -181 380 60 -181 minecraft:kelp_plant
setblock 381 60 -181 minecraft:water[level=0]
setblock 382 60 -181 minecraft:kelp_plant
fill 383 60 -181 389 60 -181 minecraft:water[level=0]
setblock 390 60 -181 minecraft:kelp_plant
setblock 391 60 -181 minecraft:water[level=0]
fill 331 60 -182 353 60 -182 minecraft:water[level=0]
setblock 354 60 -182 minecraft:kelp_plant
fill 355 60 -182 359 60 -182 minecraft:water[level=0]
fill 360 60 -182 362 60 -182 minecraft:kelp_plant
fill 363 60 -182 365 60 -182 minecraft:water[level=0]
fill 366 60 -182 368 60 -182 minecraft:kelp_plant
setblock 369 60 -182 minecraft:water[level=0]
setblock 370 60 -182 minecraft:kelp_plant
fill 371 60 -182 376 60 -182 minecraft:water[level=0]
setblock 377 60 -182 minecraft:kelp_plant
fill 378 60 -182 382 60 -182 minecraft:water[level=0]
setblock 383 60 -182 minecraft:kelp_plant
fill 384 60 -182 386 60 -182 minecraft:water[level=0]
setblock 387 60 -182 minecraft:kelp_plant
fill 388 60 -182 391 60 -182 minecraft:water[level=0]
fill 331 60 -183 346 60 -183 minecraft:water[level=0]
setblock 347 60 -183 minecraft:kelp_plant
fill 348 60 -183 359 60 -183 minecraft:water[level=0]
setblock 360 60 -183 minecraft:kelp[age=25]
fill 361 60 -183 366 60 -183 minecraft:water[level=0]
setblock 367 60 -183 minecraft:kelp_plant
setblock 368 60 -183 minecraft:water[level=0]
setblock 369 60 -183 minecraft:kelp_plant
setblock 370 60 -183 minecraft:water[level=0]
setblock 371 60 -183 minecraft:kelp_plant
fill 372 60 -183 386 60 -183 minecraft:water[level=0]
setblock 387 60 -183 minecraft:kelp_plant
fill 388 60 -183 391 60 -183 minecraft:water[level=0]
fill 331 60 -184 345 60 -184 minecraft:water[level=0]
setblock 346 60 -184 minecraft:kelp_plant
fill 347 60 -184 348 60 -184 minecraft:water[level=0]
setblock 349 60 -184 minecraft:kelp_plant
fill 350 60 -184 359 60 -184 minecraft:water[level=0]
fill 360 60 -184 361 60 -184 minecraft:kelp_plant
fill 362 60 -184 369 60 -184 minecraft:water[level=0]
setblock 370 60 -184 minecraft:kelp_plant
fill 371 60 -184 375 60 -184 minecraft:water[level=0]
setblock 376 60 -184 minecraft:kelp_plant
fill 377 60 -184 379 60 -184 minecraft:water[level=0]
setblock 380 60 -184 minecraft:kelp_plant
fill 381 60 -184 386 60 -184 minecraft:water[level=0]
fill 387 60 -184 388 60 -184 minecraft:kelp_plant
setblock 389 60 -184 minecraft:kelp[age=25]
fill 390 60 -184 391 60 -184 minecraft:water[level=0]
fill 331 60 -185 356 60 -185 minecraft:water[level=0]
setblock 357 60 -185 minecraft:kelp_plant
fill 358 60 -185 363 60 -185 minecraft:water[level=0]
setblock 364 60 -185 minecraft:kelp_plant
fill 365 60 -185 370 60 -185 minecraft:water[level=0]
setblock 371 60 -185 minecraft:kelp_plant
fill 372 60 -185 379 60 -185 minecraft:water[level=0]
setblock 380 60 -185 minecraft:kelp_plant
setblock 381 60 -185 minecraft:water[level=0]
setblock 382 60 -185 minecraft:kelp_plant
setblock 383 60 -185 minecraft:water[level=0]
setblock 384 60 -185 minecraft:kelp_plant
fill 385 60 -185 391 60 -185 minecraft:water[level=0]
fill 331 60 -186 359 60 -186 minecraft:water[level=0]
setblock 360 60 -186 minecraft:kelp_plant
fill 361 60 -186 368 60 -186 minecraft:water[level=0]
setblock 369 60 -186 minecraft:kelp_plant
fill 370 60 -186 376 60 -186 minecraft:water[level=0]
fill 377 60 -186 379 60 -186 minecraft:kelp_plant
fill 380 60 -186 391 60 -186 minecraft:water[level=0]
fill 331 60 -187 353 60 -187 minecraft:water[level=0]
setblock 354 60 -187 minecraft:kelp_plant
fill 355 60 -187 356 60 -187 minecraft:water[level=0]
fill 357 60 -187 358 60 -187 minecraft:kelp_plant
fill 359 60 -187 369 60 -187 minecraft:water[level=0]
setblock 370 60 -187 minecraft:kelp_plant
fill 371 60 -187 373 60 -187 minecraft:water[level=0]
setblock 374 60 -187 minecraft:kelp_plant
fill 375 60 -187 379 60 -187 minecraft:water[level=0]
setblock 380 60 -187 minecraft:kelp[age=25]
setblock 381 60 -187 minecraft:kelp_plant
fill 382 60 -187 387 60 -187 minecraft:water[level=0]
setblock 388 60 -187 minecraft:kelp_plant
fill 389 60 -187 391 60 -187 minecraft:water[level=0]
fill 331 60 -188 352 60 -188 minecraft:water[level=0]
setblock 353 60 -188 minecraft:kelp_plant
setblock 354 60 -188 minecraft:water[level=0]
fill 355 60 -188 356 60 -188 minecraft:kelp_plant
fill 357 60 -188 362 60 -188 minecraft:water[level=0]
setblock 363 60 -188 minecraft:kelp_plant
setblock 364 60 -188 minecraft:kelp[age=25]
setblock 365 60 -188 minecraft:kelp_plant
setblock 366 60 -188 minecraft:water[level=0]
setblock 367 60 -188 minecraft:kelp_plant
setblock 368 60 -188 minecraft:water[level=0]
setblock 369 60 -188 minecraft:kelp_plant
setblock 370 60 -188 minecraft:water[level=0]
fill 371 60 -188 374 60 -188 minecraft:kelp_plant
fill 375 60 -188 376 60 -188 minecraft:water[level=0]
fill 377 60 -188 378 60 -188 minecraft:kelp_plant
fill 379 60 -188 380 60 -188 minecraft:water[level=0]
setblock 381 60 -188 minecraft:kelp_plant
setblock 382 60 -188 minecraft:water[level=0]
fill 383 60 -188 384 60 -188 minecraft:kelp_plant
fill 385 60 -188 391 60 -188 minecraft:water[level=0]
fill 331 60 -189 351 60 -189 minecraft:water[level=0]
setblock 352 60 -189 minecraft:kelp_plant
fill 353 60 -189 356 60 -189 minecraft:water[level=0]
setblock 357 60 -189 minecraft:kelp_plant
fill 358 60 -189 363 60 -189 minecraft:water[level=0]
fill 364 60 -189 365 60 -189 minecraft:kelp[age=25]
fill 366 60 -189 368 60 -189 minecraft:water[level=0]
setblock 369 60 -189 minecraft:kelp_plant
fill 370 60 -189 375 60 -189 minecraft:water[level=0]
setblock 376 60 -189 minecraft:kelp_plant
fill 377 60 -189 381 60 -189 minecraft:water[level=0]
fill 382 60 -189 383 60 -189 minecraft:kelp_plant
fill 384 60 -189 391 60 -189 minecraft:water[level=0]
fill 331 60 -190 357 60 -190 minecraft:water[level=0]
setblock 358 60 -190 minecraft:kelp_plant
fill 359 60 -190 361 60 -190 minecraft:water[level=0]
setblock 362 60 -190 minecraft:kelp[age=25]
fill 363 60 -190 364 60 -190 minecraft:water[level=0]
fill 365 60 -190 367 60 -190 minecraft:kelp_plant
setblock 368 60 -190 minecraft:kelp[age=25]
fill 369 60 -190 370 60 -190 minecraft:kelp_plant
fill 371 60 -190 375 60 -190 minecraft:water[level=0]
setblock 376 60 -190 minecraft:kelp_plant
fill 377 60 -190 380 60 -190 minecraft:water[level=0]
fill 381 60 -190 382 60 -190 minecraft:kelp_plant
fill 383 60 -190 387 60 -190 minecraft:water[level=0]
setblock 388 60 -190 minecraft:kelp_plant
fill 389 60 -190 391 60 -190 minecraft:water[level=0]
fill 328 59 -127 340 59 -127 minecraft:water[level=0]
setblock 341 59 -127 minecraft:kelp_plant
fill 342 59 -127 346 59 -127 minecraft:water[level=0]
setblock 347 59 -127 minecraft:kelp_plant
setblock 348 59 -127 minecraft:kelp[age=25]
setblock 349 59 -127 minecraft:kelp_plant
fill 350 59 -127 353 59 -127 minecraft:water[level=0]
setblock 354 59 -127 minecraft:kelp_plant
fill 355 59 -127 368 59 -127 minecraft:water[level=0]
setblock 369 59 -127 minecraft:kelp_plant
fill 370 59 -127 383 59 -127 minecraft:water[level=0]
setblock 384 59 -127 minecraft:kelp_plant
fill 385 59 -127 390 59 -127 minecraft:water[level=0]
setblock 391 59 -127 minecraft:kelp_plant
fill 328 59 -128 337 59 -128 minecraft:water[level=0]
setblock 338 59 -128 minecraft:kelp_plant
fill 339 59 -128 345 59 -128 minecraft:water[level=0]
setblock 346 59 -128 minecraft:kelp_plant
fill 347 59 -128 356 59 -128 minecraft:water[level=0]
setblock 357 59 -128 minecraft:kelp_plant
fill 358 59 -128 359 59 -128 minecraft:water[level=0]
setblock 360 59 -128 minecraft:kelp_plant
fill 361 59 -128 366 59 -128 minecraft:water[level=0]
setblock 367 59 -128 minecraft:kelp_plant
fill 368 59 -128 369 59 -128 minecraft:water[level=0]
setblock 370 59 -128 minecraft:kelp_plant
setblock 371 59 -128 minecraft:water[level=0]
setblock 372 59 -128 minecraft:kelp_plant
fill 373 59 -128 377 59 -128 minecraft:water[level=0]
fill 378 59 -128 380 59 -128 minecraft:kelp_plant
fill 381 59 -128 386 59 -128 minecraft:water[level=0]
setblock 387 59 -128 minecraft:kelp_plant
fill 388 59 -128 391 59 -128 minecraft:water[level=0]
fill 328 59 -129 341 59 -129 minecraft:water[level=0]
setblock 342 59 -129 minecraft:kelp_plant
fill 343 59 -129 348 59 -129 minecraft:water[level=0]
setblock 349 59 -129 minecraft:kelp_plant
fill 350 59 -129 358 59 -129 minecraft:water[level=0]
setblock 359 59 -129 minecraft:kelp_plant
fill 360 59 -129 368 59 -129 minecraft:water[level=0]
setblock 369 59 -129 minecraft:kelp_plant
fill 370 59 -129 376 59 -129 minecraft:water[level=0]
setblock 377 59 -129 minecraft:kelp_plant
fill 378 59 -129 386 59 -129 minecraft:water[level=0]
setblock 387 59 -129 minecraft:kelp_plant
fill 388 59 -129 389 59 -129 minecraft:water[level=0]
setblock 390 59 -129 minecraft:kelp_plant
setblock 391 59 -129 minecraft:water[level=0]
fill 328 59 -130 333 59 -130 minecraft:water[level=0]
setblock 334 59 -130 minecraft:kelp_plant
fill 335 59 -130 350 59 -130 minecraft:water[level=0]
setblock 351 59 -130 minecraft:kelp[age=25]
fill 352 59 -130 362 59 -130 minecraft:water[level=0]
setblock 363 59 -130 minecraft:kelp_plant
fill 364 59 -130 365 59 -130 minecraft:water[level=0]
setblock 366 59 -130 minecraft:kelp_plant
fill 367 59 -130 368 59 -130 minecraft:water[level=0]
setblock 369 59 -130 minecraft:kelp_plant
fill 370 59 -130 391 59 -130 minecraft:water[level=0]
setblock 328 59 -131 minecraft:kelp_plant
fill 329 59 -131 367 59 -131 minecraft:water[level=0]
setblock 368 59 -131 minecraft:kelp_plant
fill 369 59 -131 391 59 -131 minecraft:water[level=0]
fill 328 59 -132 362 59 -132 minecraft:water[level=0]
setblock 363 59 -132 minecraft:kelp_plant
fill 364 59 -132 382 59 -132 minecraft:water[level=0]
setblock 383 59 -132 minecraft:kelp_plant
fill 384 59 -132 391 59 -132 minecraft:water[level=0]
fill 328 59 -133 356 59 -133 minecraft:water[level=0]
setblock 357 59 -133 minecraft:kelp_plant
fill 358 59 -133 387 59 -133 minecraft:water[level=0]
setblock 388 59 -133 minecraft:kelp_plant
fill 389 59 -133 391 59 -133 minecraft:water[level=0]
fill 328 59 -134 336 59 -134 minecraft:water[level=0]
setblock 337 59 -134 minecraft:kelp_plant
fill 338 59 -134 368 59 -134 minecraft:water[level=0]
setblock 369 59 -134 minecraft:kelp_plant
fill 370 59 -134 383 59 -134 minecraft:water[level=0]
setblock 384 59 -134 minecraft:kelp_plant
setblock 385 59 -134 minecraft:kelp[age=25]
fill 386 59 -134 391 59 -134 minecraft:water[level=0]
fill 328 59 -135 331 59 -135 minecraft:water[level=0]
setblock 332 59 -135 minecraft:kelp_plant
fill 333 59 -135 347 59 -135 minecraft:water[level=0]
setblock 348 59 -135 minecraft:kelp_plant
setblock 349 59 -135 minecraft:kelp[age=25]
setblock 350 59 -135 minecraft:kelp_plant
fill 351 59 -135 376 59 -135 minecraft:water[level=0]
setblock 377 59 -135 minecraft:kelp_plant
fill 378 59 -135 379 59 -135 minecraft:water[level=0]
setblock 380 59 -135 minecraft:kelp_plant
fill 381 59 -135 391 59 -135 minecraft:water[level=0]
fill 328 59 -136 342 59 -136 minecraft:water[level=0]
setblock 343 59 -136 minecraft:kelp_plant
fill 344 59 -136 345 59 -136 minecraft:water[level=0]
setblock 346 59 -136 minecraft:kelp_plant
fill 347 59 -136 348 59 -136 minecraft:water[level=0]
setblock 349 59 -136 minecraft:kelp_plant
fill 350 59 -136 364 59 -136 minecraft:water[level=0]
setblock 365 59 -136 minecraft:kelp_plant
fill 366 59 -136 374 59 -136 minecraft:water[level=0]
setblock 375 59 -136 minecraft:kelp_plant
fill 376 59 -136 387 59 -136 minecraft:water[level=0]
setblock 388 59 -136 minecraft:kelp_plant
fill 389 59 -136 391 59 -136 minecraft:water[level=0]
setblock 328 59 -137 minecraft:kelp_plant
fill 329 59 -137 330 59 -137 minecraft:water[level=0]
setblock 331 59 -137 minecraft:kelp_plant
fill 332 59 -137 391 59 -137 minecraft:water[level=0]
fill 328 59 -138 366 59 -138 minecraft:water[level=0]
setblock 367 59 -138 minecraft:kelp_plant
fill 368 59 -138 384 59 -138 minecraft:water[level=0]
setblock 385 59 -138 minecraft:kelp[age=25]
fill 386 59 -138 388 59 -138 minecraft:water[level=0]
setblock 389 59 -138 minecraft:kelp_plant
fill 390 59 -138 391 59 -138 minecraft:water[level=0]
fill 328 59 -139 359 59 -139 minecraft:water[level=0]
setblock 360 59 -139 minecraft:kelp[age=25]
fill 361 59 -139 371 59 -139 minecraft:water[level=0]
setblock 372 59 -139 minecraft:kelp_plant
fill 373 59 -139 383 59 -139 minecraft:water[level=0]
setblock 384 59 -139 minecraft:kelp_plant
fill 385 59 -139 391 59 -139 minecraft:water[level=0]
fill 328 59 -140 354 59 -140 minecraft:water[level=0]
setblock 355 59 -140 minecraft:kelp_plant
fill 356 59 -140 368 59 -140 minecraft:water[level=0]
setblock 369 59 -140 minecraft:kelp_plant
setblock 370 59 -140 minecraft:water[level=0]
setblock 371 59 -140 minecraft:kelp_plant
fill 372 59 -140 377 59 -140 minecraft:water[level=0]
setblock 378 59 -140 minecraft:kelp_plant
fill 379 59 -140 391 59 -140 minecraft:water[level=0]
fill 328 59 -141 355 59 -141 minecraft:water[level=0]
setblock 356 59 -141 minecraft:kelp_plant
fill 357 59 -141 368 59 -141 minecraft:water[level=0]
setblock 369 59 -141 minecraft:kelp_plant
fill 370 59 -141 378 59 -141 minecraft:water[level=0]
setblock 379 59 -141 minecraft:kelp[age=25]
fill 380 59 -141 382 59 -141 minecraft:water[level=0]
setblock 383 59 -141 minecraft:kelp_plant
fill 384 59 -141 387 59 -141 minecraft:water[level=0]
fill 388 59 -141 389 59 -141 minecraft:kelp_plant
fill 390 59 -141 391 59 -141 minecraft:water[level=0]
fill 328 59 -142 352 59 -142 minecraft:water[level=0]
setblock 353 59 -142 minecraft:kelp_plant
fill 354 59 -142 367 59 -142 minecraft:water[level=0]
setblock 368 59 -142 minecraft:kelp_plant
fill 369 59 -142 370 59 -142 minecraft:water[level=0]
fill 371 59 -142 372 59 -142 minecraft:kelp_plant
fill 373 59 -142 391 59 -142 minecraft:water[level=0]
fill 328 59 -143 331 59 -143 minecraft:water[level=0]
setblock 332 59 -143 minecraft:kelp_plant
fill 333 59 -143 337 59 -143 minecraft:water[level=0]
setblock 338 59 -143 minecraft:kelp_plant
fill 339 59 -143 377 59 -143 minecraft:water[level=0]
fill 378 59 -143 379 59 -143 minecraft:kelp_plant
fill 380 59 -143 382 59 -143 minecraft:water[level=0]
setblock 383 59 -143 minecraft:kelp_plant
fill 384 59 -143 385 59 -143 minecraft:water[level=0]
setblock 386 59 -143 minecraft:kelp_plant
fill 387 59 -143 391 59 -143 minecraft:water[level=0]
fill 328 59 -144 351 59 -144 minecraft:water[level=0]
setblock 352 59 -144 minecraft:kelp_plant
fill 353 59 -144 370 59 -144 minecraft:water[level=0]
setblock 371 59 -144 minecraft:kelp_plant
fill 372 59 -144 391 59 -144 minecraft:water[level=0]
fill 328 59 -145 383 59 -145 minecraft:water[level=0]
setblock 384 59 -145 minecraft:kelp_plant
setblock 385 59 -145 minecraft:water[level=0]
setblock 386 59 -145 minecraft:kelp_plant
fill 387 59 -145 388 59 -145 minecraft:water[level=0]
setblock 389 59 -145 minecraft:kelp_plant
fill 390 59 -145 391 59 -145 minecraft:water[level=0]
fill 328 59 -146 367 59 -146 minecraft:water[level=0]
setblock 368 59 -146 minecraft:kelp[age=25]
fill 369 59 -146 371 59 -146 minecraft:water[level=0]
setblock 372 59 -146 minecraft:kelp_plant
fill 373 59 -146 391 59 -146 minecraft:water[level=0]
fill 328 59 -147 368 59 -147 minecraft:water[level=0]
setblock 369 59 -147 minecraft:kelp[age=25]
fill 370 59 -147 374 59 -147 minecraft:water[level=0]
setblock 375 59 -147 minecraft:kelp_plant
fill 376 59 -147 385 59 -147 minecraft:water[level=0]
setblock 386 59 -147 minecraft:kelp_plant
fill 387 59 -147 391 59 -147 minecraft:water[level=0]
fill 328 59 -148 374 59 -148 minecraft:water[level=0]
setblock 375 59 -148 minecraft:kelp_plant
fill 376 59 -148 377 59 -148 minecraft:water[level=0]
setblock 378 59 -148 minecraft:kelp_plant
fill 379 59 -148 386 59 -148 minecraft:water[level=0]
setblock 387 59 -148 minecraft:kelp_plant
setblock 388 59 -148 minecraft:water[level=0]
setblock 389 59 -148 minecraft:kelp_plant
fill 390 59 -148 391 59 -148 minecraft:water[level=0]
fill 328 59 -149 368 59 -149 minecraft:water[level=0]
fill 369 59 -149 370 59 -149 minecraft:kelp_plant
fill 371 59 -149 377 59 -149 minecraft:water[level=0]
setblock 378 59 -149 minecraft:kelp_plant
fill 379 59 -149 391 59 -149 minecraft:water[level=0]
fill 328 59 -150 391 59 -150 minecraft:water[level=0]
fill 328 59 -151 381 59 -151 minecraft:water[level=0]
setblock 382 59 -151 minecraft:kelp[age=25]
fill 383 59 -151 385 59 -151 minecraft:water[level=0]
setblock 386 59 -151 minecraft:kelp_plant
fill 387 59 -151 391 59 -151 minecraft:water[level=0]
fill 328 59 -152 367 59 -152 minecraft:water[level=0]
fill 368 59 -152 369 59 -152 minecraft:kelp_plant
setblock 370 59 -152 minecraft:water[level=0]
setblock 371 59 -152 minecraft:kelp_plant
fill 372 59 -152 376 59 -152 minecraft:water[level=0]
setblock 377 59 -152 minecraft:kelp_plant
fill 378 59 -152 385 59 -152 minecraft:water[level=0]
setblock 386 59 -152 minecraft:kelp_plant
fill 387 59 -152 390 59 -152 minecraft:water[level=0]
setblock 391 59 -152 minecraft:kelp_plant
fill 328 59 -153 369 59 -153 minecraft:water[level=0]
setblock 370 59 -153 minecraft:kelp_plant
setblock 371 59 -153 minecraft:water[level=0]
setblock 372 59 -153 minecraft:kelp_plant
fill 373 59 -153 380 59 -153 minecraft:water[level=0]
fill 381 59 -153 382 59 -153 minecraft:kelp_plant
setblock 383 59 -153 minecraft:water[level=0]
fill 384 59 -153 385 59 -153 minecraft:kelp_plant
setblock 386 59 -153 minecraft:kelp[age=25]
fill 387 59 -153 389 59 -153 minecraft:water[level=0]
setblock 390 59 -153 minecraft:kelp_plant
setblock 391 59 -153 minecraft:water[level=0]
fill 328 59 -154 372 59 -154 minecraft:water[level=0]
setblock 373 59 -154 minecraft:kelp_plant
fill 374 59 -154 375 59 -154 minecraft:water[level=0]
setblock 376 59 -154 minecraft:kelp_plant
fill 377 59 -154 391 59 -154 minecraft:water[level=0]
fill 328 59 -155 376 59 -155 minecraft:water[level=0]
fill 377 59 -155 379 59 -155 minecraft:kelp_plant
setblock 380 59 -155 minecraft:water[level=0]
setblock 381 59 -155 minecraft:kelp_plant
fill 382 59 -155 391 59 -155 minecraft:water[level=0]
fill 328 59 -156 368 59 -156 minecraft:water[level=0]
setblock 369 59 -156 minecraft:kelp_plant
fill 370 59 -156 372 59 -156 minecraft:water[level=0]
setblock 373 59 -156 minecraft:kelp_plant
fill 374 59 -156 381 59 -156 minecraft:water[level=0]
fill 382 59 -156 383 59 -156 minecraft:kelp_plant
fill 384 59 -156 391 59 -156 minecraft:water[level=0]
fill 328 59 -157 368 59 -157 minecraft:water[level=0]
setblock 369 59 -157 minecraft:kelp_plant
fill 370 59 -157 376 59 -157 minecraft:water[level=0]
setblock 377 59 -157 minecraft:kelp_plant
fill 378 59 -157 380 59 -157 minecraft:water[level=0]
setblock 381 59 -157 minecraft:kelp_plant
fill 382 59 -157 390 59 -157 minecraft:water[level=0]
setblock 391 59 -157 minecraft:kelp_plant
fill 328 59 -158 379 59 -158 minecraft:water[level=0]
setblock 380 59 -158 minecraft:kelp_plant
fill 381 59 -158 391 59 -158 minecraft:water[level=0]
fill 329 59 -159 369 59 -159 minecraft:water[level=0]
fill 370 59 -159 371 59 -159 minecraft:kelp_plant
fill 372 59 -159 374 59 -159 minecraft:water[level=0]
setblock 375 59 -159 minecraft:kelp_plant
fill 376 59 -159 391 59 -159 minecraft:water[level=0]
fill 330 59 -160 369 59 -160 minecraft:water[level=0]
setblock 370 59 -160 minecraft:kelp_plant
fill 371 59 -160 375 59 -160 minecraft:water[level=0]
setblock 376 59 -160 minecraft:kelp_plant
fill 377 59 -160 389 59 -160 minecraft:water[level=0]
setblock 390 59 -160 minecraft:kelp_plant
setblock 391 59 -160 minecraft:water[level=0]
fill 331 59 -161 366 59 -161 minecraft:water[level=0]
fill 367 59 -161 368 59 -161 minecraft:kelp_plant
setblock 369 59 -161 minecraft:water[level=0]
setblock 370 59 -161 minecraft:kelp_plant
setblock 371 59 -161 minecraft:water[level=0]
setblock 372 59 -161 minecraft:kelp_plant
fill 373 59 -161 376 59 -161 minecraft:water[level=0]
setblock 377 59 -161 minecraft:kelp_plant
fill 378 59 -161 391 59 -161 minecraft:water[level=0]
fill 331 59 -162 369 59 -162 minecraft:water[level=0]
fill 370 59 -162 371 59 -162 minecraft:kelp_plant
setblock 372 59 -162 minecraft:water[level=0]
setblock 373 59 -162 minecraft:kelp_plant
fill 374 59 -162 377 59 -162 minecraft:water[level=0]
setblock 378 59 -162 minecraft:kelp_plant
setblock 379 59 -162 minecraft:water[level=0]
setblock 380 59 -162 minecraft:kelp_plant
fill 381 59 -162 384 59 -162 minecraft:water[level=0]
setblock 385 59 -162 minecraft:kelp[age=25]
fill 386 59 -162 391 59 -162 minecraft:water[level=0]
fill 332 59 -163 370 59 -163 minecraft:water[level=0]
setblock 371 59 -163 minecraft:kelp[age=25]
fill 372 59 -163 391 59 -163 minecraft:water[level=0]
fill 332 59 -164 368 59 -164 minecraft:water[level=0]
setblock 369 59 -164 minecraft:kelp_plant
fill 370 59 -164 371 59 -164 minecraft:water[level=0]
fill 372 59 -164 373 59 -164 minecraft:kelp_plant
fill 374 59 -164 377 59 -164 minecraft:water[level=0]
setblock 378 59 -164 minecraft:kelp_plant
fill 379 59 -164 380 59 -164 minecraft:water[level=0]
setblock 381 59 -164 minecraft:kelp_plant
fill 382 59 -164 391 59 -164 minecraft:water[level=0]
fill 332 59 -165 363 59 -165 minecraft:water[level=0]
setblock 364 59 -165 minecraft:kelp_plant
fill 365 59 -165 375 59 -165 minecraft:water[level=0]
setblock 376 59 -165 minecraft:kelp_plant
fill 377 59 -165 380 59 -165 minecraft:water[level=0]
setblock 381 59 -165 minecraft:kelp_plant
fill 382 59 -165 391 59 -165 minecraft:water[level=0]
fill 331 59 -166 380 59 -166 minecraft:water[level=0]
setblock 381 59 -166 minecraft:kelp_plant
fill 382 59 -166 391 59 -166 minecraft:water[level=0]
fill 331 59 -167 379 59 -167 minecraft:water[level=0]
fill 380 59 -167 381 59 -167 minecraft:kelp_plant
fill 382 59 -167 383 59 -167 minecraft:water[level=0]
setblock 384 59 -167 minecraft:kelp_plant
setblock 385 59 -167 minecraft:water[level=0]
setblock 386 59 -167 minecraft:kelp_plant
fill 387 59 -167 391 59 -167 minecraft:water[level=0]
fill 330 59 -168 376 59 -168 minecraft:water[level=0]
setblock 377 59 -168 minecraft:kelp_plant
fill 378 59 -168 380 59 -168 minecraft:water[level=0]
fill 381 59 -168 383 59 -168 minecraft:kelp_plant
fill 384 59 -168 391 59 -168 minecraft:water[level=0]
fill 329 59 -169 351 59 -169 minecraft:water[level=0]
setblock 352 59 -169 minecraft:kelp_plant
fill 353 59 -169 375 59 -169 minecraft:water[level=0]
setblock 376 59 -169 minecraft:kelp_plant
fill 377 59 -169 379 59 -169 minecraft:water[level=0]
fill 380 59 -169 381 59 -169 minecraft:kelp_plant
fill 382 59 -169 391 59 -169 minecraft:water[level=0]
fill 329 59 -170 369 59 -170 minecraft:water[level=0]
setblock 370 59 -170 minecraft:kelp_plant
fill 371 59 -170 374 59 -170 minecraft:water[level=0]
setblock 375 59 -170 minecraft:kelp_plant
setblock 376 59 -170 minecraft:water[level=0]
fill 377 59 -170 378 59 -170 minecraft:kelp_plant
fill 379 59 -170 383 59 -170 minecraft:water[level=0]
setblock 384 59 -170 minecraft:kelp_plant
fill 385 59 -170 390 59 -170 minecraft:water[level=0]
setblock 391 59 -170 minecraft:kelp_plant
fill 328 59 -171 368 59 -171 minecraft:water[level=0]
fill 369 59 -171 370 59 -171 minecraft:kelp_plant
setblock 371 59 -171 minecraft:water[level=0]
setblock 372 59 -171 minecraft:kelp_plant
fill 373 59 -171 374 59 -171 minecraft:water[level=0]
setblock 375 59 -171 minecraft:kelp_plant
fill 376 59 -171 383 59 -171 minecraft:water[level=0]
setblock 384 59 -171 minecraft:kelp_plant
fill 385 59 -171 391 59 -171 minecraft:water[level=0]
fill 328 59 -172 356 59 -172 minecraft:water[level=0]
setblock 357 59 -172 minecraft:kelp_plant
fill 358 59 -172 367 59 -172 minecraft:water[level=0]
setblock 368 59 -172 minecraft:kelp_plant
fill 369 59 -172 370 59 -172 minecraft:water[level=0]
setblock 371 59 -172 minecraft:kelp_plant
fill 372 59 -172 374 59 -172 minecraft:water[level=0]
setblock 375 59 -172 minecraft:kelp_plant
fill 376 59 -172 379 59 -172 minecraft:water[level=0]
fill 380 59 -172 382 59 -172 minecraft:kelp_plant
setblock 383 59 -172 minecraft:water[level=0]
setblock 384 59 -172 minecraft:kelp_plant
fill 385 59 -172 386 59 -172 minecraft:water[level=0]
setblock 387 59 -172 minecraft:kelp_plant
fill 388 59 -172 391 59 -172 minecraft:water[level=0]
fill 330 59 -173 367 59 -173 minecraft:water[level=0]
setblock 368 59 -173 minecraft:kelp_plant
fill 369 59 -173 370 59 -173 minecraft:water[level=0]
setblock 371 59 -173 minecraft:kelp_plant
fill 372 59 -173 382 59 -173 minecraft:water[level=0]
setblock 383 59 -173 minecraft:kelp_plant
fill 384 59 -173 385 59 -173 minecraft:water[level=0]
setblock 386 59 -173 minecraft:kelp_plant
fill 387 59 -173 391 59 -173 minecraft:water[level=0]
fill 331 59 -174 358 59 -174 minecraft:water[level=0]
setblock 359 59 -174 minecraft:kelp_plant
fill 360 59 -174 376 59 -174 minecraft:water[level=0]
setblock 377 59 -174 minecraft:kelp_plant
fill 378 59 -174 387 59 -174 minecraft:water[level=0]
fill 388 59 -174 389 59 -174 minecraft:kelp_plant
fill 390 59 -174 391 59 -174 minecraft:water[level=0]
fill 331 59 -175 356 59 -175 minecraft:water[level=0]
setblock 357 59 -175 minecraft:kelp_plant
fill 358 59 -175 366 59 -175 minecraft:water[level=0]
fill 367 59 -175 368 59 -175 minecraft:kelp_plant
fill 369 59 -175 379 59 -175 minecraft:water[level=0]
setblock 380 59 -175 minecraft:kelp_plant
setblock 381 59 -175 minecraft:water[level=0]
setblock 382 59 -175 minecraft:kelp_plant
fill 383 59 -175 384 59 -175 minecraft:water[level=0]
setblock 385 59 -175 minecraft:kelp_plant
setblock 386 59 -175 minecraft:water[level=0]
setblock 387 59 -175 minecraft:kelp_plant
fill 388 59 -175 391 59 -175 minecraft:water[level=0]
fill 331 59 -176 370 59 -176 minecraft:water[level=0]
fill 371 59 -176 372 59 -176 minecraft:kelp_plant
fill 373 59 -176 376 59 -176 minecraft:water[level=0]
setblock 377 59 -176 minecraft:kelp_plant
fill 378 59 -176 380 59 -176 minecraft:water[level=0]
setblock 381 59 -176 minecraft:kelp_plant
fill 382 59 -176 386 59 -176 minecraft:water[level=0]
setblock 387 59 -176 minecraft:kelp_plant
setblock 388 59 -176 minecraft:water[level=0]
setblock 389 59 -176 minecraft:kelp_plant
fill 390 59 -176 391 59 -176 minecraft:water[level=0]
fill 331 59 -177 363 59 -177 minecraft:water[level=0]
fill 364 59 -177 365 59 -177 minecraft:kelp_plant
setblock 366 59 -177 minecraft:water[level=0]
fill 367 59 -177 368 59 -177 minecraft:kelp_plant
fill 369 59 -177 371 59 -177 minecraft:water[level=0]
fill 372 59 -177 373 59 -177 minecraft:kelp_plant
fill 374 59 -177 379 59 -177 minecraft:water[level=0]
setblock 380 59 -177 minecraft:kelp_plant
setblock 381 59 -177 minecraft:water[level=0]
fill 382 59 -177 383 59 -177 minecraft:kelp_plant
fill 384 59 -177 388 59 -177 minecraft:water[level=0]
setblock 389 59 -177 minecraft:kelp_plant
fill 390 59 -177 391 59 -177 minecraft:water[level=0]
fill 331 59 -178 356 59 -178 minecraft:water[level=0]
setblock 357 59 -178 minecraft:kelp_plant
fill 358 59 -178 366 59 -178 minecraft:water[level=0]
fill 367 59 -178 368 59 -178 minecraft:kelp_plant
fill 369 59 -178 372 59 -178 minecraft:water[level=0]
setblock 373 59 -178 minecraft:kelp_plant
fill 374 59 -178 376 59 -178 minecraft:water[level=0]
fill 377 59 -178 378 59 -178 minecraft:kelp_plant
fill 379 59 -178 381 59 -178 minecraft:water[level=0]
setblock 382 59 -178 minecraft:kelp_plant
fill 383 59 -178 391 59 -178 minecraft:water[level=0]
fill 331 59 -179 353 59 -179 minecraft:water[level=0]
setblock 354 59 -179 minecraft:kelp_plant
fill 355 59 -179 366 59 -179 minecraft:water[level=0]
setblock 367 59 -179 minecraft:kelp_plant
fill 368 59 -179 369 59 -179 minecraft:water[level=0]
setblock 370 59 -179 minecraft:kelp_plant
fill 371 59 -179 372 59 -179 minecraft:water[level=0]
setblock 373 59 -179 minecraft:kelp[age=25]
fill 374 59 -179 378 59 -179 minecraft:water[level=0]
setblock 379 59 -179 minecraft:kelp_plant
fill 380 59 -179 381 59 -179 minecraft:water[level=0]
fill 382 59 -179 383 59 -179 minecraft:kelp_plant
fill 384 59 -179 386 59 -179 minecraft:water[level=0]
setblock 387 59 -179 minecraft:kelp_plant
fill 388 59 -179 391 59 -179 minecraft:water[level=0]
fill 331 59 -180 353 59 -180 minecraft:water[level=0]
fill 354 59 -180 355 59 -180 minecraft:kelp_plant
fill 356 59 -180 359 59 -180 minecraft:water[level=0]
setblock 360 59 -180 minecraft:kelp_plant
fill 361 59 -180 366 59 -180 minecraft:water[level=0]
setblock 367 59 -180 minecraft:kelp[age=25]
setblock 368 59 -180 minecraft:water[level=0]
setblock 369 59 -180 minecraft:kelp_plant
setblock 370 59 -180 minecraft:water[level=0]
setblock 371 59 -180 minecraft:kelp_plant
fill 372 59 -180 376 59 -180 minecraft:water[level=0]
setblock 377 59 -180 minecraft:kelp_plant
fill 378 59 -180 379 59 -180 minecraft:water[level=0]
setblock 380 59 -180 minecraft:kelp_plant
fill 381 59 -180 391 59 -180 minecraft:water[level=0]
fill 331 59 -181 348 59 -181 minecraft:water[level=0]
setblock 349 59 -181 minecraft:kelp_plant
fill 350 59 -181 352 59 -181 minecraft:water[level=0]
setblock 353 59 -181 minecraft:kelp_plant
setblock 354 59 -181 minecraft:water[level=0]
setblock 355 59 -181 minecraft:kelp_plant
setblock 356 59 -181 minecraft:water[level=0]
setblock 357 59 -181 minecraft:kelp_plant
fill 358 59 -181 364 59 -181 minecraft:water[level=0]
setblock 365 59 -181 minecraft:kelp[age=25]
fill 366 59 -181 374 59 -181 minecraft:water[level=0]
setblock 375 59 -181 minecraft:kelp_plant
setblock 376 59 -181 minecraft:water[level=0]
setblock 377 59 -181 minecraft:kelp_plant
setblock 378 59 -181 minecraft:water[level=0]
fill 379 59 -181 380 59 -181 minecraft:kelp_plant
setblock 381 59 -181 minecraft:water[level=0]
setblock 382 59 -181 minecraft:kelp_plant
fill 383 59 -181 389 59 -181 minecraft:water[level=0]
setblock 390 59 -181 minecraft:kelp_plant
setblock 391 59 -181 minecraft:water[level=0]
fill 331 59 -182 353 59 -182 minecraft:water[level=0]
setblock 354 59 -182 minecraft:kelp_plant
setblock 355 59 -182 minecraft:water[level=0]
setblock 356 59 -182 minecraft:kelp[age=25]
fill 357 59 -182 359 59 -182 minecraft:water[level=0]
fill 360 59 -182 362 59 -182 minecraft:kelp_plant
fill 363 59 -182 365 59 -182 minecraft:water[level=0]
fill 366 59 -182 368 59 -182 minecraft:kelp_plant
setblock 369 59 -182 minecraft:water[level=0]
setblock 370 59 -182 minecraft:kelp_plant
fill 371 59 -182 372 59 -182 minecraft:water[level=0]
setblock 373 59 -182 minecraft:kelp[age=25]
fill 374 59 -182 376 59 -182 minecraft:water[level=0]
setblock 377 59 -182 minecraft:kelp_plant
fill 378 59 -182 382 59 -182 minecraft:water[level=0]
setblock 383 59 -182 minecraft:kelp_plant
fill 384 59 -182 386 59 -182 minecraft:water[level=0]
setblock 387 59 -182 minecraft:kelp_plant
fill 388 59 -182 391 59 -182 minecraft:water[level=0]
fill 331 59 -183 346 59 -183 minecraft:water[level=0]
setblock 347 59 -183 minecraft:kelp_plant
fill 348 59 -183 359 59 -183 minecraft:water[level=0]
setblock 360 59 -183 minecraft:kelp_plant
fill 361 59 -183 366 59 -183 minecraft:water[level=0]
setblock 367 59 -183 minecraft:kelp_plant
setblock 368 59 -183 minecraft:water[level=0]
setblock 369 59 -183 minecraft:kelp_plant
setblock 370 59 -183 minecraft:water[level=0]
setblock 371 59 -183 minecraft:kelp_plant
fill 372 59 -183 377 59 -183 minecraft:water[level=0]
setblock 378 59 -183 minecraft:kelp[age=25]
fill 379 59 -183 386 59 -183 minecraft:water[level=0]
setblock 387 59 -183 minecraft:kelp_plant
fill 388 59 -183 391 59 -183 minecraft:water[level=0]
fill 331 59 -184 345 59 -184 minecraft:water[level=0]
setblock 346 59 -184 minecraft:kelp_plant
fill 347 59 -184 348 59 -184 minecraft:water[level=0]
setblock 349 59 -184 minecraft:kelp_plant
fill 350 59 -184 359 59 -184 minecraft:water[level=0]
fill 360 59 -184 361 59 -184 minecraft:kelp_plant
fill 362 59 -184 369 59 -184 minecraft:water[level=0]
setblock 370 59 -184 minecraft:kelp_plant
fill 371 59 -184 375 59 -184 minecraft:water[level=0]
setblock 376 59 -184 minecraft:kelp_plant
fill 377 59 -184 379 59 -184 minecraft:water[level=0]
setblock 380 59 -184 minecraft:kelp_plant
fill 381 59 -184 386 59 -184 minecraft:water[level=0]
fill 387 59 -184 389 59 -184 minecraft:kelp_plant
fill 390 59 -184 391 59 -184 minecraft:water[level=0]
fill 331 59 -185 356 59 -185 minecraft:water[level=0]
setblock 357 59 -185 minecraft:kelp_plant
fill 358 59 -185 363 59 -185 minecraft:water[level=0]
setblock 364 59 -185 minecraft:kelp_plant
fill 365 59 -185 370 59 -185 minecraft:water[level=0]
setblock 371 59 -185 minecraft:kelp_plant
fill 372 59 -185 373 59 -185 minecraft:water[level=0]
setblock 374 59 -185 minecraft:kelp[age=25]
fill 375 59 -185 379 59 -185 minecraft:water[level=0]
setblock 380 59 -185 minecraft:kelp_plant
setblock 381 59 -185 minecraft:water[level=0]
setblock 382 59 -185 minecraft:kelp_plant
setblock 383 59 -185 minecraft:water[level=0]
setblock 384 59 -185 minecraft:kelp_plant
fill 385 59 -185 391 59 -185 minecraft:water[level=0]
fill 331 59 -186 359 59 -186 minecraft:water[level=0]
setblock 360 59 -186 minecraft:kelp_plant
fill 361 59 -186 368 59 -186 minecraft:water[level=0]
setblock 369 59 -186 minecraft:kelp_plant
fill 370 59 -186 376 59 -186 minecraft:water[level=0]
fill 377 59 -186 379 59 -186 minecraft:kelp_plant
fill 380 59 -186 391 59 -186 minecraft:water[level=0]
fill 331 59 -187 353 59 -187 minecraft:water[level=0]
setblock 354 59 -187 minecraft:kelp_plant
fill 355 59 -187 356 59 -187 minecraft:water[level=0]
fill 357 59 -187 358 59 -187 minecraft:kelp_plant
fill 359 59 -187 365 59 -187 minecraft:water[level=0]
setblock 366 59 -187 minecraft:kelp[age=25]
fill 367 59 -187 369 59 -187 minecraft:water[level=0]
setblock 370 59 -187 minecraft:kelp_plant
fill 371 59 -187 373 59 -187 minecraft:water[level=0]
setblock 374 59 -187 minecraft:kelp_plant
fill 375 59 -187 379 59 -187 minecraft:water[level=0]
fill 380 59 -187 381 59 -187 minecraft:kelp_plant
fill 382 59 -187 387 59 -187 minecraft:water[level=0]
setblock 388 59 -187 minecraft:kelp_plant
fill 389 59 -187 391 59 -187 minecraft:water[level=0]
fill 331 59 -188 352 59 -188 minecraft:water[level=0]
setblock 353 59 -188 minecraft:kelp_plant
setblock 354 59 -188 minecraft:water[level=0]
fill 355 59 -188 356 59 -188 minecraft:kelp_plant
fill 357 59 -188 362 59 -188 minecraft:water[level=0]
fill 363 59 -188 365 59 -188 minecraft:kelp_plant
setblock 366 59 -188 minecraft:water[level=0]
setblock 367 59 -188 minecraft:kelp_plant
setblock 368 59 -188 minecraft:water[level=0]
setblock 369 59 -188 minecraft:kelp_plant
setblock 370 59 -188 minecraft:water[level=0]
fill 371 59 -188 374 59 -188 minecraft:kelp_plant
fill 375 59 -188 376 59 -188 minecraft:water[level=0]
fill 377 59 -188 378 59 -188 minecraft:kelp_plant
fill 379 59 -188 380 59 -188 minecraft:water[level=0]
setblock 381 59 -188 minecraft:kelp_plant
setblock 382 59 -188 minecraft:water[level=0]
fill 383 59 -188 384 59 -188 minecraft:kelp_plant
fill 385 59 -188 391 59 -188 minecraft:water[level=0]
fill 331 59 -189 351 59 -189 minecraft:water[level=0]
setblock 352 59 -189 minecraft:kelp_plant
fill 353 59 -189 356 59 -189 minecraft:water[level=0]
setblock 357 59 -189 minecraft:kelp_plant
fill 358 59 -189 363 59 -189 minecraft:water[level=0]
fill 364 59 -189 365 59 -189 minecraft:kelp_plant
fill 366 59 -189 368 59 -189 minecraft:water[level=0]
setblock 369 59 -189 minecraft:kelp_plant
fill 370 59 -189 375 59 -189 minecraft:water[level=0]
setblock 376 59 -189 minecraft:kelp_plant
fill 377 59 -189 381 59 -189 minecraft:water[level=0]
fill 382 59 -189 383 59 -189 minecraft:kelp_plant
fill 384 59 -189 391 59 -189 minecraft:water[level=0]
fill 332 59 -190 357 59 -190 minecraft:water[level=0]
setblock 358 59 -190 minecraft:kelp_plant
fill 359 59 -190 361 59 -190 minecraft:water[level=0]
setblock 362 59 -190 minecraft:kelp_plant
fill 363 59 -190 364 59 -190 minecraft:water[level=0]
fill 365 59 -190 370 59 -190 minecraft:kelp_plant
fill 371 59 -190 375 59 -190 minecraft:water[level=0]
setblock 376 59 -190 minecraft:kelp_plant
fill 377 59 -190 380 59 -190 minecraft:water[level=0]
fill 381 59 -190 382 59 -190 minecraft:kelp_plant
fill 383 59 -190 386 59 -190 minecraft:water[level=0]
setblock 387 59 -190 minecraft:kelp[age=25]
setblock 388 59 -190 minecraft:kelp_plant
fill 389 59 -190 391 59 -190 minecraft:water[level=0]
fill 328 58 -127 340 58 -127 minecraft:water[level=0]
setblock 341 58 -127 minecraft:kelp_plant
fill 342 58 -127 346 58 -127 minecraft:water[level=0]
fill 347 58 -127 349 58 -127 minecraft:kelp_plant
fill 350 58 -127 353 58 -127 minecraft:water[level=0]
setblock 354 58 -127 minecraft:kelp_plant
fill 355 58 -127 368 58 -127 minecraft:water[level=0]
setblock 369 58 -127 minecraft:kelp_plant
fill 370 58 -127 383 58 -127 minecraft:water[level=0]
setblock 384 58 -127 minecraft:kelp_plant
fill 385 58 -127 390 58 -127 minecraft:water[level=0]
setblock 391 58 -127 minecraft:kelp_plant
fill 328 58 -128 337 58 -128 minecraft:water[level=0]
setblock 338 58 -128 minecraft:kelp_plant
fill 339 58 -128 345 58 -128 minecraft:water[level=0]
setblock 346 58 -128 minecraft:kelp_plant
fill 347 58 -128 356 58 -128 minecraft:water[level=0]
setblock 357 58 -128 minecraft:kelp_plant
fill 358 58 -128 359 58 -128 minecraft:water[level=0]
setblock 360 58 -128 minecraft:kelp_plant
fill 361 58 -128 366 58 -128 minecraft:water[level=0]
setblock 367 58 -128 minecraft:kelp_plant
fill 368 58 -128 369 58 -128 minecraft:water[level=0]
setblock 370 58 -128 minecraft:kelp_plant
setblock 371 58 -128 minecraft:water[level=0]
setblock 372 58 -128 minecraft:kelp_plant
fill 373 58 -128 374 58 -128 minecraft:water[level=0]
setblock 375 58 -128 minecraft:kelp[age=25]
fill 376 58 -128 377 58 -128 minecraft:water[level=0]
fill 378 58 -128 380 58 -128 minecraft:kelp_plant
fill 381 58 -128 386 58 -128 minecraft:water[level=0]
setblock 387 58 -128 minecraft:kelp_plant
fill 388 58 -128 391 58 -128 minecraft:water[level=0]
fill 328 58 -129 341 58 -129 minecraft:water[level=0]
setblock 342 58 -129 minecraft:kelp_plant
fill 343 58 -129 348 58 -129 minecraft:water[level=0]
setblock 349 58 -129 minecraft:kelp_plant
fill 350 58 -129 358 58 -129 minecraft:water[level=0]
setblock 359 58 -129 minecraft:kelp_plant
fill 360 58 -129 368 58 -129 minecraft:water[level=0]
setblock 369 58 -129 minecraft:kelp_plant
fill 370 58 -129 376 58 -129 minecraft:water[level=0]
setblock 377 58 -129 minecraft:kelp_plant
fill 378 58 -129 386 58 -129 minecraft:water[level=0]
setblock 387 58 -129 minecraft:kelp_plant
fill 388 58 -129 389 58 -129 minecraft:water[level=0]
setblock 390 58 -129 minecraft:kelp_plant
setblock 391 58 -129 minecraft:water[level=0]
fill 328 58 -130 333 58 -130 minecraft:water[level=0]
setblock 334 58 -130 minecraft:kelp_plant
fill 335 58 -130 342 58 -130 minecraft:water[level=0]
setblock 343 58 -130 minecraft:kelp[age=25]
fill 344 58 -130 350 58 -130 minecraft:water[level=0]
setblock 351 58 -130 minecraft:kelp_plant
fill 352 58 -130 362 58 -130 minecraft:water[level=0]
setblock 363 58 -130 minecraft:kelp_plant
fill 364 58 -130 365 58 -130 minecraft:water[level=0]
setblock 366 58 -130 minecraft:kelp_plant
fill 367 58 -130 368 58 -130 minecraft:water[level=0]
setblock 369 58 -130 minecraft:kelp_plant
fill 370 58 -130 391 58 -130 minecraft:water[level=0]
setblock 328 58 -131 minecraft:kelp_plant
fill 329 58 -131 367 58 -131 minecraft:water[level=0]
setblock 368 58 -131 minecraft:kelp_plant
fill 369 58 -131 391 58 -131 minecraft:water[level=0]
fill 328 58 -132 362 58 -132 minecraft:water[level=0]
setblock 363 58 -132 minecraft:kelp_plant
fill 364 58 -132 382 58 -132 minecraft:water[level=0]
setblock 383 58 -132 minecraft:kelp_plant
fill 384 58 -132 391 58 -132 minecraft:water[level=0]
fill 328 58 -133 348 58 -133 minecraft:water[level=0]
setblock 349 58 -133 minecraft:kelp[age=25]
fill 350 58 -133 351 58 -133 minecraft:water[level=0]
setblock 352 58 -133 minecraft:kelp[age=25]
fill 353 58 -133 356 58 -133 minecraft:water[level=0]
setblock 357 58 -133 minecraft:kelp_plant
fill 358 58 -133 387 58 -133 minecraft:water[level=0]
setblock 388 58 -133 minecraft:kelp_plant
fill 389 58 -133 391 58 -133 minecraft:water[level=0]
fill 328 58 -134 336 58 -134 minecraft:water[level=0]
setblock 337 58 -134 minecraft:kelp_plant
fill 338 58 -134 368 58 -134 minecraft:water[level=0]
setblock 369 58 -134 minecraft:kelp_plant
fill 370 58 -134 383 58 -134 minecraft:water[level=0]
fill 384 58 -134 385 58 -134 minecraft:kelp_plant
fill 386 58 -134 391 58 -134 minecraft:water[level=0]
fill 328 58 -135 331 58 -135 minecraft:water[level=0]
setblock 332 58 -135 minecraft:kelp_plant
fill 333 58 -135 336 58 -135 minecraft:water[level=0]
setblock 337 58 -135 minecraft:kelp[age=25]
fill 338 58 -135 347 58 -135 minecraft:water[level=0]
fill 348 58 -135 350 58 -135 minecraft:kelp_plant
fill 351 58 -135 376 58 -135 minecraft:water[level=0]
setblock 377 58 -135 minecraft:kelp_plant
fill 378 58 -135 379 58 -135 minecraft:water[level=0]
setblock 380 58 -135 minecraft:kelp_plant
fill 381 58 -135 384 58 -135 minecraft:water[level=0]
setblock 385 58 -135 minecraft:kelp[age=25]
fill 386 58 -135 391 58 -135 minecraft:water[level=0]
fill 328 58 -136 342 58 -136 minecraft:water[level=0]
setblock 343 58 -136 minecraft:kelp_plant
fill 344 58 -136 345 58 -136 minecraft:water[level=0]
setblock 346 58 -136 minecraft:kelp_plant
fill 347 58 -136 348 58 -136 minecraft:water[level=0]
setblock 349 58 -136 minecraft:kelp_plant
fill 350 58 -136 361 58 -136 minecraft:water[level=0]
setblock 362 58 -136 minecraft:kelp[age=25]
fill 363 58 -136 364 58 -136 minecraft:water[level=0]
setblock 365 58 -136 minecraft:kelp_plant
fill 366 58 -136 374 58 -136 minecraft:water[level=0]
setblock 375 58 -136 minecraft:kelp_plant
fill 376 58 -136 384 58 -136 minecraft:water[level=0]
setblock 385 58 -136 minecraft:kelp[age=25]
fill 386 58 -136 387 58 -136 minecraft:water[level=0]
setblock 388 58 -136 minecraft:kelp_plant
fill 389 58 -136 391 58 -136 minecraft:water[level=0]
setblock 328 58 -137 minecraft:kelp_plant
fill 329 58 -137 330 58 -137 minecraft:water[level=0]
setblock 331 58 -137 minecraft:kelp_plant
fill 332 58 -137 367 58 -137 minecraft:water[level=0]
setblock 368 58 -137 minecraft:kelp[age=25]
fill 369 58 -137 391 58 -137 minecraft:water[level=0]
fill 328 58 -138 366 58 -138 minecraft:water[level=0]
setblock 367 58 -138 minecraft:kelp_plant
fill 368 58 -138 384 58 -138 minecraft:water[level=0]
setblock 385 58 -138 minecraft:kelp_plant
fill 386 58 -138 388 58 -138 minecraft:water[level=0]
setblock 389 58 -138 minecraft:kelp_plant
fill 390 58 -138 391 58 -138 minecraft:water[level=0]
fill 328 58 -139 359 58 -139 minecraft:water[level=0]
setblock 360 58 -139 minecraft:kelp_plant
fill 361 58 -139 371 58 -139 minecraft:water[level=0]
setblock 372 58 -139 minecraft:kelp_plant
fill 373 58 -139 383 58 -139 minecraft:water[level=0]
setblock 384 58 -139 minecraft:kelp_plant
fill 385 58 -139 391 58 -139 minecraft:water[level=0]
fill 328 58 -140 343 58 -140 minecraft:water[level=0]
setblock 344 58 -140 minecraft:kelp[age=25]
fill 345 58 -140 354 58 -140 minecraft:water[level=0]
setblock 355 58 -140 minecraft:kelp_plant
fill 356 58 -140 368 58 -140 minecraft:water[level=0]
setblock 369 58 -140 minecraft:kelp_plant
setblock 370 58 -140 minecraft:water[level=0]
setblock 371 58 -140 minecraft:kelp_plant
fill 372 58 -140 377 58 -140 minecraft:water[level=0]
setblock 378 58 -140 minecraft:kelp_plant
fill 379 58 -140 391 58 -140 minecraft:water[level=0]
fill 328 58 -141 355 58 -141 minecraft:water[level=0]
setblock 356 58 -141 minecraft:kelp_plant
fill 357 58 -141 368 58 -141 minecraft:water[level=0]
setblock 369 58 -141 minecraft:kelp_plant
fill 370 58 -141 378 58 -141 minecraft:water[level=0]
setblock 379 58 -141 minecraft:kelp_plant
fill 380 58 -141 382 58 -141 minecraft:water[level=0]
setblock 383 58 -141 minecraft:kelp_plant
fill 384 58 -141 387 58 -141 minecraft:water[level=0]
fill 388 58 -141 389 58 -141 minecraft:kelp_plant
fill 390 58 -141 391 58 -141 minecraft:water[level=0]
fill 328 58 -142 352 58 -142 minecraft:water[level=0]
setblock 353 58 -142 minecraft:kelp_plant
fill 354 58 -142 367 58 -142 minecraft:water[level=0]
setblock 368 58 -142 minecraft:kelp_plant
fill 369 58 -142 370 58 -142 minecraft:water[level=0]
fill 371 58 -142 372 58 -142 minecraft:kelp_plant
fill 373 58 -142 391 58 -142 minecraft:water[level=0]
fill 328 58 -143 331 58 -143 minecraft:water[level=0]
setblock 332 58 -143 minecraft:kelp_plant
fill 333 58 -143 337 58 -143 minecraft:water[level=0]
setblock 338 58 -143 minecraft:kelp_plant
fill 339 58 -143 377 58 -143 minecraft:water[level=0]
fill 378 58 -143 379 58 -143 minecraft:kelp_plant
fill 380 58 -143 382 58 -143 minecraft:water[level=0]
setblock 383 58 -143 minecraft:kelp_plant
fill 384 58 -143 385 58 -143 minecraft:water[level=0]
setblock 386 58 -143 minecraft:kelp_plant
fill 387 58 -143 391 58 -143 minecraft:water[level=0]
fill 328 58 -144 351 58 -144 minecraft:water[level=0]
setblock 352 58 -144 minecraft:kelp_plant
fill 353 58 -144 370 58 -144 minecraft:water[level=0]
setblock 371 58 -144 minecraft:kelp_plant
fill 372 58 -144 391 58 -144 minecraft:water[level=0]
fill 328 58 -145 383 58 -145 minecraft:water[level=0]
setblock 384 58 -145 minecraft:kelp_plant
setblock 385 58 -145 minecraft:water[level=0]
setblock 386 58 -145 minecraft:kelp_plant
fill 387 58 -145 388 58 -145 minecraft:water[level=0]
setblock 389 58 -145 minecraft:kelp_plant
fill 390 58 -145 391 58 -145 minecraft:water[level=0]
fill 328 58 -146 367 58 -146 minecraft:water[level=0]
setblock 368 58 -146 minecraft:kelp_plant
fill 369 58 -146 371 58 -146 minecraft:water[level=0]
setblock 372 58 -146 minecraft:kelp_plant
fill 373 58 -146 391 58 -146 minecraft:water[level=0]
fill 328 58 -147 368 58 -147 minecraft:water[level=0]
setblock 369 58 -147 minecraft:kelp_plant
fill 370 58 -147 373 58 -147 minecraft:water[level=0]
setblock 374 58 -147 minecraft:kelp[age=25]
setblock 375 58 -147 minecraft:kelp_plant
fill 376 58 -147 385 58 -147 minecraft:water[level=0]
setblock 386 58 -147 minecraft:kelp_plant
fill 387 58 -147 391 58 -147 minecraft:water[level=0]
fill 328 58 -148 374 58 -148 minecraft:water[level=0]
setblock 375 58 -148 minecraft:kelp_plant
fill 376 58 -148 377 58 -148 minecraft:water[level=0]
setblock 378 58 -148 minecraft:kelp_plant
fill 379 58 -148 386 58 -148 minecraft:water[level=0]
setblock 387 58 -148 minecraft:kelp_plant
setblock 388 58 -148 minecraft:water[level=0]
setblock 389 58 -148 minecraft:kelp_plant
fill 390 58 -148 391 58 -148 minecraft:water[level=0]
fill 328 58 -149 368 58 -149 minecraft:water[level=0]
fill 369 58 -149 370 58 -149 minecraft:kelp_plant
fill 371 58 -149 377 58 -149 minecraft:water[level=0]
setblock 378 58 -149 minecraft:kelp_plant
fill 379 58 -149 391 58 -149 minecraft:water[level=0]
fill 328 58 -150 370 58 -150 minecraft:water[level=0]
setblock 371 58 -150 minecraft:kelp[age=25]
fill 372 58 -150 391 58 -150 minecraft:water[level=0]
fill 328 58 -151 381 58 -151 minecraft:water[level=0]
setblock 382 58 -151 minecraft:kelp_plant
fill 383 58 -151 385 58 -151 minecraft:water[level=0]
setblock 386 58 -151 minecraft:kelp_plant
fill 387 58 -151 391 58 -151 minecraft:water[level=0]
fill 328 58 -152 367 58 -152 minecraft:water[level=0]
fill 368 58 -152 369 58 -152 minecraft:kelp_plant
setblock 370 58 -152 minecraft:water[level=0]
setblock 371 58 -152 minecraft:kelp_plant
fill 372 58 -152 376 58 -152 minecraft:water[level=0]
setblock 377 58 -152 minecraft:kelp_plant
fill 378 58 -152 385 58 -152 minecraft:water[level=0]
setblock 386 58 -152 minecraft:kelp_plant
fill 387 58 -152 390 58 -152 minecraft:water[level=0]
setblock 391 58 -152 minecraft:kelp_plant
fill 328 58 -153 369 58 -153 minecraft:water[level=0]
setblock 370 58 -153 minecraft:kelp_plant
setblock 371 58 -153 minecraft:water[level=0]
setblock 372 58 -153 minecraft:kelp_plant
fill 373 58 -153 380 58 -153 minecraft:water[level=0]
fill 381 58 -153 382 58 -153 minecraft:kelp_plant
setblock 383 58 -153 minecraft:water[level=0]
fill 384 58 -153 386 58 -153 minecraft:kelp_plant
fill 387 58 -153 389 58 -153 minecraft:water[level=0]
setblock 390 58 -153 minecraft:kelp_plant
setblock 391 58 -153 minecraft:water[level=0]
fill 328 58 -154 372 58 -154 minecraft:water[level=0]
setblock 373 58 -154 minecraft:kelp_plant
fill 374 58 -154 375 58 -154 minecraft:water[level=0]
setblock 376 58 -154 minecraft:kelp_plant
fill 377 58 -154 391 58 -154 minecraft:water[level=0]
fill 328 58 -155 376 58 -155 minecraft:water[level=0]
fill 377 58 -155 379 58 -155 minecraft:kelp_plant
setblock 380 58 -155 minecraft:water[level=0]
setblock 381 58 -155 minecraft:kelp_plant
fill 382 58 -155 391 58 -155 minecraft:water[level=0]
fill 328 58 -156 368 58 -156 minecraft:water[level=0]
setblock 369 58 -156 minecraft:kelp_plant
fill 370 58 -156 372 58 -156 minecraft:water[level=0]
setblock 373 58 -156 minecraft:kelp_plant
fill 374 58 -156 381 58 -156 minecraft:water[level=0]
fill 382 58 -156 383 58 -156 minecraft:kelp_plant
fill 384 58 -156 391 58 -156 minecraft:water[level=0]
fill 328 58 -157 368 58 -157 minecraft:water[level=0]
setblock 369 58 -157 minecraft:kelp_plant
fill 370 58 -157 376 58 -157 minecraft:water[level=0]
setblock 377 58 -157 minecraft:kelp_plant
fill 378 58 -157 380 58 -157 minecraft:water[level=0]
setblock 381 58 -157 minecraft:kelp_plant
fill 382 58 -157 390 58 -157 minecraft:water[level=0]
setblock 391 58 -157 minecraft:kelp_plant
fill 329 58 -158 379 58 -158 minecraft:water[level=0]
setblock 380 58 -158 minecraft:kelp_plant
fill 381 58 -158 391 58 -158 minecraft:water[level=0]
fill 330 58 -159 369 58 -159 minecraft:water[level=0]
fill 370 58 -159 371 58 -159 minecraft:kelp_plant
fill 372 58 -159 374 58 -159 minecraft:water[level=0]
setblock 375 58 -159 minecraft:kelp_plant
fill 376 58 -159 391 58 -159 minecraft:water[level=0]
fill 331 58 -160 369 58 -160 minecraft:water[level=0]
setblock 370 58 -160 minecraft:kelp_plant
fill 371 58 -160 375 58 -160 minecraft:water[level=0]
setblock 376 58 -160 minecraft:kelp_plant
fill 377 58 -160 389 58 -160 minecraft:water[level=0]
setblock 390 58 -160 minecraft:kelp_plant
setblock 391 58 -160 minecraft:water[level=0]
fill 331 58 -161 366 58 -161 minecraft:water[level=0]
fill 367 58 -161 368 58 -161 minecraft:kelp_plant
setblock 369 58 -161 minecraft:water[level=0]
setblock 370 58 -161 minecraft:kelp_plant
setblock 371 58 -161 minecraft:kelp[age=25]
setblock 372 58 -161 minecraft:kelp_plant
fill 373 58 -161 376 58 -161 minecraft:water[level=0]
setblock 377 58 -161 minecraft:kelp_plant
fill 378 58 -161 391 58 -161 minecraft:water[level=0]
fill 332 58 -162 369 58 -162 minecraft:water[level=0]
fill 370 58 -162 371 58 -162 minecraft:kelp_plant
setblock 372 58 -162 minecraft:water[level=0]
setblock 373 58 -162 minecraft:kelp_plant
fill 374 58 -162 377 58 -162 minecraft:water[level=0]
setblock 378 58 -162 minecraft:kelp_plant
setblock 379 58 -162 minecraft:water[level=0]
setblock 380 58 -162 minecraft:kelp_plant
fill 381 58 -162 384 58 -162 minecraft:water[level=0]
setblock 385 58 -162 minecraft:kelp_plant
fill 386 58 -162 391 58 -162 minecraft:water[level=0]
fill 332 58 -163 370 58 -163 minecraft:water[level=0]
setblock 371 58 -163 minecraft:kelp_plant
fill 372 58 -163 391 58 -163 minecraft:water[level=0]
fill 332 58 -164 368 58 -164 minecraft:water[level=0]
setblock 369 58 -164 minecraft:kelp_plant
fill 370 58 -164 371 58 -164 minecraft:water[level=0]
fill 372 58 -164 373 58 -164 minecraft:kelp_plant
fill 374 58 -164 377 58 -164 minecraft:water[level=0]
setblock 378 58 -164 minecraft:kelp_plant
fill 379 58 -164 380 58 -164 minecraft:water[level=0]
setblock 381 58 -164 minecraft:kelp_plant
fill 382 58 -164 391 58 -164 minecraft:water[level=0]
fill 332 58 -165 363 58 -165 minecraft:water[level=0]
setblock 364 58 -165 minecraft:kelp_plant
fill 365 58 -165 375 58 -165 minecraft:water[level=0]
setblock 376 58 -165 minecraft:kelp_plant
fill 377 58 -165 380 58 -165 minecraft:water[level=0]
setblock 381 58 -165 minecraft:kelp_plant
fill 382 58 -165 391 58 -165 minecraft:water[level=0]
fill 332 58 -166 380 58 -166 minecraft:water[level=0]
setblock 381 58 -166 minecraft:kelp_plant
fill 382 58 -166 391 58 -166 minecraft:water[level=0]
fill 331 58 -167 379 58 -167 minecraft:water[level=0]
fill 380 58 -167 381 58 -167 minecraft:kelp_plant
fill 382 58 -167 383 58 -167 minecraft:water[level=0]
setblock 384 58 -167 minecraft:kelp_plant
setblock 385 58 -167 minecraft:water[level=0]
setblock 386 58 -167 minecraft:kelp_plant
fill 387 58 -167 391 58 -167 minecraft:water[level=0]
fill 330 58 -168 367 58 -168 minecraft:water[level=0]
setblock 368 58 -168 minecraft:kelp[age=25]
fill 369 58 -168 376 58 -168 minecraft:water[level=0]
setblock 377 58 -168 minecraft:kelp_plant
fill 378 58 -168 380 58 -168 minecraft:water[level=0]
fill 381 58 -168 383 58 -168 minecraft:kelp_plant
fill 384 58 -168 391 58 -168 minecraft:water[level=0]
fill 330 58 -169 351 58 -169 minecraft:water[level=0]
setblock 352 58 -169 minecraft:kelp_plant
fill 353 58 -169 375 58 -169 minecraft:water[level=0]
setblock 376 58 -169 minecraft:kelp_plant
fill 377 58 -169 379 58 -169 minecraft:water[level=0]
fill 380 58 -169 381 58 -169 minecraft:kelp_plant
fill 382 58 -169 391 58 -169 minecraft:water[level=0]
fill 329 58 -170 367 58 -170 minecraft:water[level=0]
setblock 368 58 -170 minecraft:kelp[age=25]
setblock 369 58 -170 minecraft:water[level=0]
setblock 370 58 -170 minecraft:kelp_plant
fill 371 58 -170 374 58 -170 minecraft:water[level=0]
setblock 375 58 -170 minecraft:kelp_plant
setblock 376 58 -170 minecraft:water[level=0]
fill 377 58 -170 378 58 -170 minecraft:kelp_plant
fill 379 58 -170 383 58 -170 minecraft:water[level=0]
setblock 384 58 -170 minecraft:kelp_plant
fill 385 58 -170 390 58 -170 minecraft:water[level=0]
setblock 391 58 -170 minecraft:kelp_plant
fill 329 58 -171 368 58 -171 minecraft:water[level=0]
fill 369 58 -171 370 58 -171 minecraft:kelp_plant
setblock 371 58 -171 minecraft:water[level=0]
setblock 372 58 -171 minecraft:kelp_plant
fill 373 58 -171 374 58 -171 minecraft:water[level=0]
setblock 375 58 -171 minecraft:kelp_plant
fill 376 58 -171 383 58 -171 minecraft:water[level=0]
setblock 384 58 -171 minecraft:kelp_plant
fill 385 58 -171 391 58 -171 minecraft:water[level=0]
fill 329 58 -172 356 58 -172 minecraft:water[level=0]
setblock 357 58 -172 minecraft:kelp_plant
fill 358 58 -172 367 58 -172 minecraft:water[level=0]
setblock 368 58 -172 minecraft:kelp_plant
fill 369 58 -172 370 58 -172 minecraft:water[level=0]
setblock 371 58 -172 minecraft:kelp_plant
fill 372 58 -172 374 58 -172 minecraft:water[level=0]
setblock 375 58 -172 minecraft:kelp_plant
fill 376 58 -172 379 58 -172 minecraft:water[level=0]
fill 380 58 -172 382 58 -172 minecraft:kelp_plant
setblock 383 58 -172 minecraft:water[level=0]
setblock 384 58 -172 minecraft:kelp_plant
fill 385 58 -172 386 58 -172 minecraft:water[level=0]
setblock 387 58 -172 minecraft:kelp_plant
fill 388 58 -172 391 58 -172 minecraft:water[level=0]
fill 330 58 -173 367 58 -173 minecraft:water[level=0]
setblock 368 58 -173 minecraft:kelp_plant
fill 369 58 -173 370 58 -173 minecraft:water[level=0]
setblock 371 58 -173 minecraft:kelp_plant
fill 372 58 -173 382 58 -173 minecraft:water[level=0]
setblock 383 58 -173 minecraft:kelp_plant
fill 384 58 -173 385 58 -173 minecraft:water[level=0]
setblock 386 58 -173 minecraft:kelp_plant
fill 387 58 -173 391 58 -173 minecraft:water[level=0]
fill 331 58 -174 358 58 -174 minecraft:water[level=0]
setblock 359 58 -174 minecraft:kelp_plant
fill 360 58 -174 366 58 -174 minecraft:water[level=0]
setblock 367 58 -174 minecraft:kelp[age=25]
setblock 368 58 -174 minecraft:water[level=0]
setblock 369 58 -174 minecraft:kelp[age=25]
fill 370 58 -174 376 58 -174 minecraft:water[level=0]
setblock 377 58 -174 minecraft:kelp_plant
fill 378 58 -174 387 58 -174 minecraft:water[level=0]
fill 388 58 -174 389 58 -174 minecraft:kelp_plant
fill 390 58 -174 391 58 -174 minecraft:water[level=0]
fill 331 58 -175 356 58 -175 minecraft:water[level=0]
setblock 357 58 -175 minecraft:kelp_plant
fill 358 58 -175 366 58 -175 minecraft:water[level=0]
fill 367 58 -175 368 58 -175 minecraft:kelp_plant
fill 369 58 -175 379 58 -175 minecraft:water[level=0]
setblock 380 58 -175 minecraft:kelp_plant
setblock 381 58 -175 minecraft:water[level=0]
setblock 382 58 -175 minecraft:kelp_plant
fill 383 58 -175 384 58 -175 minecraft:water[level=0]
setblock 385 58 -175 minecraft:kelp_plant
setblock 386 58 -175 minecraft:water[level=0]
setblock 387 58 -175 minecraft:kelp_plant
fill 388 58 -175 391 58 -175 minecraft:water[level=0]
fill 331 58 -176 370 58 -176 minecraft:water[level=0]
fill 371 58 -176 372 58 -176 minecraft:kelp_plant
fill 373 58 -176 376 58 -176 minecraft:water[level=0]
setblock 377 58 -176 minecraft:kelp_plant
fill 378 58 -176 380 58 -176 minecraft:water[level=0]
setblock 381 58 -176 minecraft:kelp_plant
fill 382 58 -176 386 58 -176 minecraft:water[level=0]
setblock 387 58 -176 minecraft:kelp_plant
setblock 388 58 -176 minecraft:water[level=0]
setblock 389 58 -176 minecraft:kelp_plant
fill 390 58 -176 391 58 -176 minecraft:water[level=0]
fill 331 58 -177 363 58 -177 minecraft:water[level=0]
fill 364 58 -177 365 58 -177 minecraft:kelp_plant
setblock 366 58 -177 minecraft:water[level=0]
fill 367 58 -177 368 58 -177 minecraft:kelp_plant
fill 369 58 -177 371 58 -177 minecraft:water[level=0]
fill 372 58 -177 373 58 -177 minecraft:kelp_plant
fill 374 58 -177 379 58 -177 minecraft:water[level=0]
setblock 380 58 -177 minecraft:kelp_plant
setblock 381 58 -177 minecraft:water[level=0]
fill 382 58 -177 383 58 -177 minecraft:kelp_plant
fill 384 58 -177 388 58 -177 minecraft:water[level=0]
setblock 389 58 -177 minecraft:kelp_plant
fill 390 58 -177 391 58 -177 minecraft:water[level=0]
fill 331 58 -178 356 58 -178 minecraft:water[level=0]
setblock 357 58 -178 minecraft:kelp_plant
fill 358 58 -178 366 58 -178 minecraft:water[level=0]
fill 367 58 -178 368 58 -178 minecraft:kelp_plant
fill 369 58 -178 372 58 -178 minecraft:water[level=0]
setblock 373 58 -178 minecraft:kelp_plant
fill 374 58 -178 376 58 -178 minecraft:water[level=0]
fill 377 58 -178 378 58 -178 minecraft:kelp_plant
fill 379 58 -178 381 58 -178 minecraft:water[level=0]
setblock 382 58 -178 minecraft:kelp_plant
fill 383 58 -178 391 58 -178 minecraft:water[level=0]
fill 331 58 -179 353 58 -179 minecraft:water[level=0]
setblock 354 58 -179 minecraft:kelp_plant
fill 355 58 -179 366 58 -179 minecraft:water[level=0]
setblock 367 58 -179 minecraft:kelp_plant
fill 368 58 -179 369 58 -179 minecraft:water[level=0]
setblock 370 58 -179 minecraft:kelp_plant
fill 371 58 -179 372 58 -179 minecraft:water[level=0]
setblock 373 58 -179 minecraft:kelp_plant
fill 374 58 -179 378 58 -179 minecraft:water[level=0]
setblock 379 58 -179 minecraft:kelp_plant
fill 380 58 -179 381 58 -179 minecraft:water[level=0]
fill 382 58 -179 383 58 -179 minecraft:kelp_plant
fill 384 58 -179 386 58 -179 minecraft:water[level=0]
setblock 387 58 -179 minecraft:kelp_plant
fill 388 58 -179 391 58 -179 minecraft:water[level=0]
fill 331 58 -180 353 58 -180 minecraft:water[level=0]
fill 354 58 -180 355 58 -180 minecraft:kelp_plant
fill 356 58 -180 359 58 -180 minecraft:water[level=0]
setblock 360 58 -180 minecraft:kelp_plant
fill 361 58 -180 366 58 -180 minecraft:water[level=0]
setblock 367 58 -180 minecraft:kelp_plant
setblock 368 58 -180 minecraft:water[level=0]
setblock 369 58 -180 minecraft:kelp_plant
setblock 370 58 -180 minecraft:water[level=0]
setblock 371 58 -180 minecraft:kelp_plant
fill 372 58 -180 376 58 -180 minecraft:water[level=0]
setblock 377 58 -180 minecraft:kelp_plant
fill 378 58 -180 379 58 -180 minecraft:water[level=0]
setblock 380 58 -180 minecraft:kelp_plant
fill 381 58 -180 391 58 -180 minecraft:water[level=0]
fill 331 58 -181 348 58 -181 minecraft:water[level=0]
setblock 349 58 -181 minecraft:kelp_plant
fill 350 58 -181 352 58 -181 minecraft:water[level=0]
setblock 353 58 -181 minecraft:kelp_plant
setblock 354 58 -181 minecraft:water[level=0]
setblock 355 58 -181 minecraft:kelp_plant
setblock 356 58 -181 minecraft:water[level=0]
setblock 357 58 -181 minecraft:kelp_plant
fill 358 58 -181 364 58 -181 minecraft:water[level=0]
setblock 365 58 -181 minecraft:kelp_plant
fill 366 58 -181 374 58 -181 minecraft:water[level=0]
setblock 375 58 -181 minecraft:kelp_plant
setblock 376 58 -181 minecraft:water[level=0]
setblock 377 58 -181 minecraft:kelp_plant
setblock 378 58 -181 minecraft:water[level=0]
fill 379 58 -181 380 58 -181 minecraft:kelp_plant
setblock 381 58 -181 minecraft:water[level=0]
setblock 382 58 -181 minecraft:kelp_plant
fill 383 58 -181 389 58 -181 minecraft:water[level=0]
setblock 390 58 -181 minecraft:kelp_plant
setblock 391 58 -181 minecraft:water[level=0]
fill 331 58 -182 352 58 -182 minecraft:water[level=0]
setblock 353 58 -182 minecraft:kelp[age=25]
setblock 354 58 -182 minecraft:kelp_plant
setblock 355 58 -182 minecraft:water[level=0]
setblock 356 58 -182 minecraft:kelp_plant
fill 357 58 -182 359 58 -182 minecraft:water[level=0]
fill 360 58 -182 362 58 -182 minecraft:kelp_plant
fill 363 58 -182 365 58 -182 minecraft:water[level=0]
fill 366 58 -182 368 58 -182 minecraft:kelp_plant
setblock 369 58 -182 minecraft:water[level=0]
setblock 370 58 -182 minecraft:kelp_plant
fill 371 58 -182 372 58 -182 minecraft:water[level=0]
setblock 373 58 -182 minecraft:kelp_plant
fill 374 58 -182 376 58 -182 minecraft:water[level=0]
setblock 377 58 -182 minecraft:kelp_plant
fill 378 58 -182 379 58 -182 minecraft:water[level=0]
setblock 380 58 -182 minecraft:kelp[age=25]
fill 381 58 -182 382 58 -182 minecraft:water[level=0]
setblock 383 58 -182 minecraft:kelp_plant
fill 384 58 -182 386 58 -182 minecraft:water[level=0]
setblock 387 58 -182 minecraft:kelp_plant
fill 388 58 -182 391 58 -182 minecraft:water[level=0]
fill 331 58 -183 346 58 -183 minecraft:water[level=0]
setblock 347 58 -183 minecraft:kelp_plant
fill 348 58 -183 359 58 -183 minecraft:water[level=0]
setblock 360 58 -183 minecraft:kelp_plant
fill 361 58 -183 366 58 -183 minecraft:water[level=0]
setblock 367 58 -183 minecraft:kelp_plant
setblock 368 58 -183 minecraft:water[level=0]
setblock 369 58 -183 minecraft:kelp_plant
setblock 370 58 -183 minecraft:water[level=0]
setblock 371 58 -183 minecraft:kelp_plant
fill 372 58 -183 377 58 -183 minecraft:water[level=0]
setblock 378 58 -183 minecraft:kelp_plant
fill 379 58 -183 386 58 -183 minecraft:water[level=0]
setblock 387 58 -183 minecraft:kelp_plant
fill 388 58 -183 391 58 -183 minecraft:water[level=0]
fill 331 58 -184 345 58 -184 minecraft:water[level=0]
setblock 346 58 -184 minecraft:kelp_plant
fill 347 58 -184 348 58 -184 minecraft:water[level=0]
setblock 349 58 -184 minecraft:kelp_plant
fill 350 58 -184 359 58 -184 minecraft:water[level=0]
fill 360 58 -184 361 58 -184 minecraft:kelp_plant
fill 362 58 -184 369 58 -184 minecraft:water[level=0]
setblock 370 58 -184 minecraft:kelp_plant
fill 371 58 -184 375 58 -184 minecraft:water[level=0]
setblock 376 58 -184 minecraft:kelp_plant
fill 377 58 -184 379 58 -184 minecraft:water[level=0]
setblock 380 58 -184 minecraft:kelp_plant
fill 381 58 -184 386 58 -184 minecraft:water[level=0]
fill 387 58 -184 389 58 -184 minecraft:kelp_plant
fill 390 58 -184 391 58 -184 minecraft:water[level=0]
fill 331 58 -185 356 58 -185 minecraft:water[level=0]
setblock 357 58 -185 minecraft:kelp_plant
fill 358 58 -185 363 58 -185 minecraft:water[level=0]
setblock 364 58 -185 minecraft:kelp_plant
fill 365 58 -185 370 58 -185 minecraft:water[level=0]
setblock 371 58 -185 minecraft:kelp_plant
fill 372 58 -185 373 58 -185 minecraft:water[level=0]
setblock 374 58 -185 minecraft:kelp_plant
fill 375 58 -185 379 58 -185 minecraft:water[level=0]
setblock 380 58 -185 minecraft:kelp_plant
setblock 381 58 -185 minecraft:water[level=0]
setblock 382 58 -185 minecraft:kelp_plant
setblock 383 58 -185 minecraft:water[level=0]
setblock 384 58 -185 minecraft:kelp_plant
fill 385 58 -185 391 58 -185 minecraft:water[level=0]
fill 331 58 -186 341 58 -186 minecraft:water[level=0]
setblock 342 58 -186 minecraft:kelp[age=25]
fill 343 58 -186 359 58 -186 minecraft:water[level=0]
setblock 360 58 -186 minecraft:kelp_plant
fill 361 58 -186 368 58 -186 minecraft:water[level=0]
setblock 369 58 -186 minecraft:kelp_plant
fill 370 58 -186 376 58 -186 minecraft:water[level=0]
fill 377 58 -186 379 58 -186 minecraft:kelp_plant
fill 380 58 -186 390 58 -186 minecraft:water[level=0]
setblock 391 58 -186 minecraft:kelp[age=25]
fill 331 58 -187 353 58 -187 minecraft:water[level=0]
setblock 354 58 -187 minecraft:kelp_plant
fill 355 58 -187 356 58 -187 minecraft:water[level=0]
fill 357 58 -187 358 58 -187 minecraft:kelp_plant
fill 359 58 -187 364 58 -187 minecraft:water[level=0]
setblock 365 58 -187 minecraft:kelp[age=25]
setblock 366 58 -187 minecraft:kelp_plant
fill 367 58 -187 369 58 -187 minecraft:water[level=0]
setblock 370 58 -187 minecraft:kelp_plant
fill 371 58 -187 373 58 -187 minecraft:water[level=0]
setblock 374 58 -187 minecraft:kelp_plant
fill 375 58 -187 379 58 -187 minecraft:water[level=0]
fill 380 58 -187 381 58 -187 minecraft:kelp_plant
fill 382 58 -187 387 58 -187 minecraft:water[level=0]
setblock 388 58 -187 minecraft:kelp_plant
fill 389 58 -187 391 58 -187 minecraft:water[level=0]
fill 331 58 -188 352 58 -188 minecraft:water[level=0]
setblock 353 58 -188 minecraft:kelp_plant
setblock 354 58 -188 minecraft:water[level=0]
fill 355 58 -188 356 58 -188 minecraft:kelp_plant
fill 357 58 -188 362 58 -188 minecraft:water[level=0]
fill 363 58 -188 365 58 -188 minecraft:kelp_plant
setblock 366 58 -188 minecraft:water[level=0]
setblock 367 58 -188 minecraft:kelp_plant
setblock 368 58 -188 minecraft:water[level=0]
setblock 369 58 -188 minecraft:kelp_plant
setblock 370 58 -188 minecraft:water[level=0]
fill 371 58 -188 374 58 -188 minecraft:kelp_plant
fill 375 58 -188 376 58 -188 minecraft:water[level=0]
fill 377 58 -188 378 58 -188 minecraft:kelp_plant
fill 379 58 -188 380 58 -188 minecraft:water[level=0]
setblock 381 58 -188 minecraft:kelp_plant
setblock 382 58 -188 minecraft:water[level=0]
fill 383 58 -188 384 58 -188 minecraft:kelp_plant
fill 385 58 -188 391 58 -188 minecraft:water[level=0]
fill 332 58 -189 351 58 -189 minecraft:water[level=0]
setblock 352 58 -189 minecraft:kelp_plant
fill 353 58 -189 356 58 -189 minecraft:water[level=0]
setblock 357 58 -189 minecraft:kelp_plant
fill 358 58 -189 363 58 -189 minecraft:water[level=0]
fill 364 58 -189 365 58 -189 minecraft:kelp_plant
fill 366 58 -189 368 58 -189 minecraft:water[level=0]
setblock 369 58 -189 minecraft:kelp_plant
fill 370 58 -189 375 58 -189 minecraft:water[level=0]
setblock 376 58 -189 minecraft:kelp_plant
fill 377 58 -189 381 58 -189 minecraft:water[level=0]
fill 382 58 -189 383 58 -189 minecraft:kelp_plant
fill 384 58 -189 391 58 -189 minecraft:water[level=0]
fill 332 58 -190 357 58 -190 minecraft:water[level=0]
setblock 358 58 -190 minecraft:kelp_plant
fill 359 58 -190 361 58 -190 minecraft:water[level=0]
setblock 362 58 -190 minecraft:kelp_plant
fill 363 58 -190 364 58 -190 minecraft:water[level=0]
fill 365 58 -190 370 58 -190 minecraft:kelp_plant
fill 371 58 -190 375 58 -190 minecraft:water[level=0]
setblock 376 58 -190 minecraft:kelp_plant
fill 377 58 -190 380 58 -190 minecraft:water[level=0]
fill 381 58 -190 382 58 -190 minecraft:kelp_plant
fill 383 58 -190 386 58 -190 minecraft:water[level=0]
fill 387 58 -190 388 58 -190 minecraft:kelp_plant
fill 389 58 -190 391 58 -190 minecraft:water[level=0]
fill 328 57 -127 340 57 -127 minecraft:water[level=0]
setblock 341 57 -127 minecraft:kelp_plant
fill 342 57 -127 346 57 -127 minecraft:water[level=0]
fill 347 57 -127 349 57 -127 minecraft:kelp_plant
fill 350 57 -127 353 57 -127 minecraft:water[level=0]
setblock 354 57 -127 minecraft:kelp_plant
fill 355 57 -127 368 57 -127 minecraft:water[level=0]
setblock 369 57 -127 minecraft:kelp_plant
fill 370 57 -127 372 57 -127 minecraft:water[level=0]
setblock 373 57 -127 minecraft:kelp[age=25]
fill 374 57 -127 383 57 -127 minecraft:water[level=0]
setblock 384 57 -127 minecraft:kelp_plant
fill 385 57 -127 390 57 -127 minecraft:water[level=0]
setblock 391 57 -127 minecraft:kelp_plant
fill 328 57 -128 334 57 -128 minecraft:water[level=0]
setblock 335 57 -128 minecraft:tall_seagrass[half=upper]
fill 336 57 -128 337 57 -128 minecraft:water[level=0]
setblock 338 57 -128 minecraft:kelp_plant
fill 339 57 -128 345 57 -128 minecraft:water[level=0]
setblock 346 57 -128 minecraft:kelp_plant
fill 347 57 -128 354 57 -128 minecraft:water[level=0]
setblock 355 57 -128 minecraft:kelp[age=25]
setblock 356 57 -128 minecraft:water[level=0]
setblock 357 57 -128 minecraft:kelp_plant
fill 358 57 -128 359 57 -128 minecraft:water[level=0]
setblock 360 57 -128 minecraft:kelp_plant
fill 361 57 -128 366 57 -128 minecraft:water[level=0]
setblock 367 57 -128 minecraft:kelp_plant
fill 368 57 -128 369 57 -128 minecraft:water[level=0]
setblock 370 57 -128 minecraft:kelp_plant
setblock 371 57 -128 minecraft:water[level=0]
setblock 372 57 -128 minecraft:kelp_plant
setblock 373 57 -128 minecraft:kelp[age=25]
setblock 374 57 -128 minecraft:water[level=0]
setblock 375 57 -128 minecraft:kelp_plant
fill 376 57 -128 377 57 -128 minecraft:water[level=0]
fill 378 57 -128 380 57 -128 minecraft:kelp_plant
fill 381 57 -128 386 57 -128 minecraft:water[level=0]
setblock 387 57 -128 minecraft:kelp_plant
fill 388 57 -128 391 57 -128 minecraft:water[level=0]
fill 328 57 -129 341 57 -129 minecraft:water[level=0]
setblock 342 57 -129 minecraft:kelp_plant
fill 343 57 -129 348 57 -129 minecraft:water[level=0]
setblock 349 57 -129 minecraft:kelp_plant
fill 350 57 -129 358 57 -129 minecraft:water[level=0]
setblock 359 57 -129 minecraft:kelp_plant
fill 360 57 -129 368 57 -129 minecraft:water[level=0]
setblock 369 57 -129 minecraft:kelp_plant
fill 370 57 -129 376 57 -129 minecraft:water[level=0]
setblock 377 57 -129 minecraft:kelp_plant
fill 378 57 -129 386 57 -129 minecraft:water[level=0]
setblock 387 57 -129 minecraft:kelp_plant
fill 388 57 -129 389 57 -129 minecraft:water[level=0]
setblock 390 57 -129 minecraft:kelp_plant
setblock 391 57 -129 minecraft:water[level=0]
fill 328 57 -130 333 57 -130 minecraft:water[level=0]
setblock 334 57 -130 minecraft:kelp_plant
fill 335 57 -130 342 57 -130 minecraft:water[level=0]
setblock 343 57 -130 minecraft:kelp_plant
fill 344 57 -130 350 57 -130 minecraft:water[level=0]
setblock 351 57 -130 minecraft:kelp_plant
fill 352 57 -130 362 57 -130 minecraft:water[level=0]
setblock 363 57 -130 minecraft:kelp_plant
fill 364 57 -130 365 57 -130 minecraft:water[level=0]
setblock 366 57 -130 minecraft:kelp_plant
fill 367 57 -130 368 57 -130 minecraft:water[level=0]
setblock 369 57 -130 minecraft:kelp_plant
fill 370 57 -130 391 57 -130 minecraft:water[level=0]
setblock 328 57 -131 minecraft:kelp_plant
fill 329 57 -131 367 57 -131 minecraft:water[level=0]
setblock 368 57 -131 minecraft:kelp_plant
fill 369 57 -131 391 57 -131 minecraft:water[level=0]
fill 328 57 -132 362 57 -132 minecraft:water[level=0]
setblock 363 57 -132 minecraft:kelp_plant
fill 364 57 -132 382 57 -132 minecraft:water[level=0]
setblock 383 57 -132 minecraft:kelp_plant
fill 384 57 -132 386 57 -132 minecraft:water[level=0]
setblock 387 57 -132 minecraft:kelp[age=25]
fill 388 57 -132 391 57 -132 minecraft:water[level=0]
fill 328 57 -133 348 57 -133 minecraft:water[level=0]
setblock 349 57 -133 minecraft:kelp_plant
fill 350 57 -133 351 57 -133 minecraft:water[level=0]
setblock 352 57 -133 minecraft:kelp_plant
fill 353 57 -133 356 57 -133 minecraft:water[level=0]
setblock 357 57 -133 minecraft:kelp_plant
fill 358 57 -133 387 57 -133 minecraft:water[level=0]
setblock 388 57 -133 minecraft:kelp_plant
fill 389 57 -133 391 57 -133 minecraft:water[level=0]
fill 328 57 -134 336 57 -134 minecraft:water[level=0]
setblock 337 57 -134 minecraft:kelp_plant
fill 338 57 -134 368 57 -134 minecraft:water[level=0]
setblock 369 57 -134 minecraft:kelp_plant
fill 370 57 -134 383 57 -134 minecraft:water[level=0]
fill 384 57 -134 385 57 -134 minecraft:kelp_plant
fill 386 57 -134 391 57 -134 minecraft:water[level=0]
fill 328 57 -135 331 57 -135 minecraft:water[level=0]
setblock 332 57 -135 minecraft:kelp_plant
fill 333 57 -135 336 57 -135 minecraft:water[level=0]
setblock 337 57 -135 minecraft:kelp_plant
fill 338 57 -135 347 57 -135 minecraft:water[level=0]
fill 348 57 -135 350 57 -135 minecraft:kelp_plant
fill 351 57 -135 376 57 -135 minecraft:water[level=0]
setblock 377 57 -135 minecraft:kelp_plant
fill 378 57 -135 379 57 -135 minecraft:water[level=0]
setblock 380 57 -135 minecraft:kelp_plant
fill 381 57 -135 384 57 -135 minecraft:water[level=0]
setblock 385 57 -135 minecraft:kelp_plant
fill 386 57 -135 391 57 -135 minecraft:water[level=0]
fill 328 57 -136 342 57 -136 minecraft:water[level=0]
setblock 343 57 -136 minecraft:kelp_plant
fill 344 57 -136 345 57 -136 minecraft:water[level=0]
setblock 346 57 -136 minecraft:kelp_plant
fill 347 57 -136 348 57 -136 minecraft:water[level=0]
setblock 349 57 -136 minecraft:kelp_plant
fill 350 57 -136 361 57 -136 minecraft:water[level=0]
setblock 362 57 -136 minecraft:kelp_plant
fill 363 57 -136 364 57 -136 minecraft:water[level=0]
setblock 365 57 -136 minecraft:kelp_plant
fill 366 57 -136 374 57 -136 minecraft:water[level=0]
setblock 375 57 -136 minecraft:kelp_plant
fill 376 57 -136 377 57 -136 minecraft:water[level=0]
setblock 378 57 -136 minecraft:kelp[age=25]
fill 379 57 -136 384 57 -136 minecraft:water[level=0]
setblock 385 57 -136 minecraft:kelp_plant
fill 386 57 -136 387 57 -136 minecraft:water[level=0]
setblock 388 57 -136 minecraft:kelp_plant
fill 389 57 -136 391 57 -136 minecraft:water[level=0]
setblock 328 57 -137 minecraft:kelp_plant
fill 329 57 -137 330 57 -137 minecraft:water[level=0]
setblock 331 57 -137 minecraft:kelp_plant
fill 332 57 -137 367 57 -137 minecraft:water[level=0]
setblock 368 57 -137 minecraft:kelp_plant
fill 369 57 -137 384 57 -137 minecraft:water[level=0]
setblock 385 57 -137 minecraft:kelp[age=25]
fill 386 57 -137 391 57 -137 minecraft:water[level=0]
fill 328 57 -138 366 57 -138 minecraft:water[level=0]
setblock 367 57 -138 minecraft:kelp_plant
fill 368 57 -138 384 57 -138 minecraft:water[level=0]
setblock 385 57 -138 minecraft:kelp_plant
fill 386 57 -138 388 57 -138 minecraft:water[level=0]
setblock 389 57 -138 minecraft:kelp_plant
fill 390 57 -138 391 57 -138 minecraft:water[level=0]
fill 328 57 -139 359 57 -139 minecraft:water[level=0]
setblock 360 57 -139 minecraft:kelp_plant
fill 361 57 -139 371 57 -139 minecraft:water[level=0]
setblock 372 57 -139 minecraft:kelp_plant
fill 373 57 -139 383 57 -139 minecraft:water[level=0]
setblock 384 57 -139 minecraft:kelp_plant
fill 385 57 -139 391 57 -139 minecraft:water[level=0]
fill 328 57 -140 343 57 -140 minecraft:water[level=0]
setblock 344 57 -140 minecraft:kelp_plant
fill 345 57 -140 354 57 -140 minecraft:water[level=0]
setblock 355 57 -140 minecraft:kelp_plant
fill 356 57 -140 368 57 -140 minecraft:water[level=0]
setblock 369 57 -140 minecraft:kelp_plant
setblock 370 57 -140 minecraft:water[level=0]
setblock 371 57 -140 minecraft:kelp_plant
fill 372 57 -140 377 57 -140 minecraft:water[level=0]
setblock 378 57 -140 minecraft:kelp_plant
fill 379 57 -140 380 57 -140 minecraft:water[level=0]
setblock 381 57 -140 minecraft:kelp[age=25]
fill 382 57 -140 391 57 -140 minecraft:water[level=0]
fill 328 57 -141 355 57 -141 minecraft:water[level=0]
setblock 356 57 -141 minecraft:kelp_plant
fill 357 57 -141 368 57 -141 minecraft:water[level=0]
setblock 369 57 -141 minecraft:kelp_plant
fill 370 57 -141 378 57 -141 minecraft:water[level=0]
setblock 379 57 -141 minecraft:kelp_plant
fill 380 57 -141 382 57 -141 minecraft:water[level=0]
setblock 383 57 -141 minecraft:kelp_plant
fill 384 57 -141 387 57 -141 minecraft:water[level=0]
fill 388 57 -141 389 57 -141 minecraft:kelp_plant
fill 390 57 -141 391 57 -141 minecraft:water[level=0]
fill 328 57 -142 352 57 -142 minecraft:water[level=0]
setblock 353 57 -142 minecraft:kelp_plant
fill 354 57 -142 367 57 -142 minecraft:water[level=0]
setblock 368 57 -142 minecraft:kelp_plant
setblock 369 57 -142 minecraft:kelp[age=25]
setblock 370 57 -142 minecraft:water[level=0]
fill 371 57 -142 372 57 -142 minecraft:kelp_plant
fill 373 57 -142 391 57 -142 minecraft:water[level=0]
fill 328 57 -143 331 57 -143 minecraft:water[level=0]
setblock 332 57 -143 minecraft:kelp_plant
fill 333 57 -143 337 57 -143 minecraft:water[level=0]
setblock 338 57 -143 minecraft:kelp_plant
fill 339 57 -143 341 57 -143 minecraft:water[level=0]
setblock 342 57 -143 minecraft:kelp[age=25]
fill 343 57 -143 377 57 -143 minecraft:water[level=0]
fill 378 57 -143 379 57 -143 minecraft:kelp_plant
fill 380 57 -143 382 57 -143 minecraft:water[level=0]
setblock 383 57 -143 minecraft:kelp_plant
fill 384 57 -143 385 57 -143 minecraft:water[level=0]
setblock 386 57 -143 minecraft:kelp_plant
fill 387 57 -143 391 57 -143 minecraft:water[level=0]
fill 328 57 -144 351 57 -144 minecraft:water[level=0]
setblock 352 57 -144 minecraft:kelp_plant
fill 353 57 -144 370 57 -144 minecraft:water[level=0]
setblock 371 57 -144 minecraft:kelp_plant
fill 372 57 -144 391 57 -144 minecraft:water[level=0]
fill 328 57 -145 383 57 -145 minecraft:water[level=0]
setblock 384 57 -145 minecraft:kelp_plant
setblock 385 57 -145 minecraft:water[level=0]
setblock 386 57 -145 minecraft:kelp_plant
fill 387 57 -145 388 57 -145 minecraft:water[level=0]
setblock 389 57 -145 minecraft:kelp_plant
fill 390 57 -145 391 57 -145 minecraft:water[level=0]
fill 328 57 -146 367 57 -146 minecraft:water[level=0]
setblock 368 57 -146 minecraft:kelp_plant
fill 369 57 -146 371 57 -146 minecraft:water[level=0]
setblock 372 57 -146 minecraft:kelp_plant
fill 373 57 -146 391 57 -146 minecraft:water[level=0]
fill 328 57 -147 368 57 -147 minecraft:water[level=0]
setblock 369 57 -147 minecraft:kelp_plant
fill 370 57 -147 373 57 -147 minecraft:water[level=0]
fill 374 57 -147 375 57 -147 minecraft:kelp_plant
fill 376 57 -147 385 57 -147 minecraft:water[level=0]
setblock 386 57 -147 minecraft:kelp_plant
fill 387 57 -147 391 57 -147 minecraft:water[level=0]
fill 328 57 -148 374 57 -148 minecraft:water[level=0]
setblock 375 57 -148 minecraft:kelp_plant
fill 376 57 -148 377 57 -148 minecraft:water[level=0]
setblock 378 57 -148 minecraft:kelp_plant
fill 379 57 -148 386 57 -148 minecraft:water[level=0]
setblock 387 57 -148 minecraft:kelp_plant
setblock 388 57 -148 minecraft:water[level=0]
setblock 389 57 -148 minecraft:kelp_plant
fill 390 57 -148 391 57 -148 minecraft:water[level=0]
fill 328 57 -149 368 57 -149 minecraft:water[level=0]
fill 369 57 -149 370 57 -149 minecraft:kelp_plant
fill 371 57 -149 377 57 -149 minecraft:water[level=0]
setblock 378 57 -149 minecraft:kelp_plant
fill 379 57 -149 391 57 -149 minecraft:water[level=0]
fill 328 57 -150 369 57 -150 minecraft:water[level=0]
setblock 370 57 -150 minecraft:kelp[age=25]
setblock 371 57 -150 minecraft:kelp_plant
fill 372 57 -150 391 57 -150 minecraft:water[level=0]
fill 328 57 -151 381 57 -151 minecraft:water[level=0]
setblock 382 57 -151 minecraft:kelp_plant
fill 383 57 -151 385 57 -151 minecraft:water[level=0]
setblock 386 57 -151 minecraft:kelp_plant
fill 387 57 -151 391 57 -151 minecraft:water[level=0]
fill 328 57 -152 367 57 -152 minecraft:water[level=0]
fill 368 57 -152 369 57 -152 minecraft:kelp_plant
setblock 370 57 -152 minecraft:water[level=0]
setblock 371 57 -152 minecraft:kelp_plant
fill 372 57 -152 376 57 -152 minecraft:water[level=0]
setblock 377 57 -152 minecraft:kelp_plant
fill 378 57 -152 385 57 -152 minecraft:water[level=0]
setblock 386 57 -152 minecraft:kelp_plant
fill 387 57 -152 390 57 -152 minecraft:water[level=0]
setblock 391 57 -152 minecraft:kelp_plant
fill 328 57 -153 369 57 -153 minecraft:water[level=0]
setblock 370 57 -153 minecraft:kelp_plant
setblock 371 57 -153 minecraft:water[level=0]
setblock 372 57 -153 minecraft:kelp_plant
fill 373 57 -153 380 57 -153 minecraft:water[level=0]
fill 381 57 -153 382 57 -153 minecraft:kelp_plant
setblock 383 57 -153 minecraft:water[level=0]
fill 384 57 -153 386 57 -153 minecraft:kelp_plant
fill 387 57 -153 389 57 -153 minecraft:water[level=0]
setblock 390 57 -153 minecraft:kelp_plant
setblock 391 57 -153 minecraft:water[level=0]
fill 328 57 -154 372 57 -154 minecraft:water[level=0]
setblock 373 57 -154 minecraft:kelp_plant
fill 374 57 -154 375 57 -154 minecraft:water[level=0]
setblock 376 57 -154 minecraft:kelp_plant
fill 377 57 -154 391 57 -154 minecraft:water[level=0]
fill 328 57 -155 376 57 -155 minecraft:water[level=0]
fill 377 57 -155 379 57 -155 minecraft:kelp_plant
setblock 380 57 -155 minecraft:water[level=0]
setblock 381 57 -155 minecraft:kelp_plant
fill 382 57 -155 391 57 -155 minecraft:water[level=0]
fill 328 57 -156 368 57 -156 minecraft:water[level=0]
setblock 369 57 -156 minecraft:kelp_plant
fill 370 57 -156 372 57 -156 minecraft:water[level=0]
setblock 373 57 -156 minecraft:kelp_plant
fill 374 57 -156 381 57 -156 minecraft:water[level=0]
fill 382 57 -156 383 57 -156 minecraft:kelp_plant
fill 384 57 -156 391 57 -156 minecraft:water[level=0]
fill 328 57 -157 368 57 -157 minecraft:water[level=0]
setblock 369 57 -157 minecraft:kelp_plant
fill 370 57 -157 376 57 -157 minecraft:water[level=0]
setblock 377 57 -157 minecraft:kelp_plant
fill 378 57 -157 380 57 -157 minecraft:water[level=0]
setblock 381 57 -157 minecraft:kelp_plant
fill 382 57 -157 390 57 -157 minecraft:water[level=0]
setblock 391 57 -157 minecraft:kelp_plant
fill 330 57 -158 379 57 -158 minecraft:water[level=0]
setblock 380 57 -158 minecraft:kelp_plant
fill 381 57 -158 391 57 -158 minecraft:water[level=0]
fill 331 57 -159 369 57 -159 minecraft:water[level=0]
fill 370 57 -159 371 57 -159 minecraft:kelp_plant
fill 372 57 -159 374 57 -159 minecraft:water[level=0]
setblock 375 57 -159 minecraft:kelp_plant
fill 376 57 -159 391 57 -159 minecraft:water[level=0]
fill 331 57 -160 369 57 -160 minecraft:water[level=0]
setblock 370 57 -160 minecraft:kelp_plant
setblock 371 57 -160 minecraft:kelp[age=25]
fill 372 57 -160 375 57 -160 minecraft:water[level=0]
setblock 376 57 -160 minecraft:kelp_plant
fill 377 57 -160 389 57 -160 minecraft:water[level=0]
setblock 390 57 -160 minecraft:kelp_plant
setblock 391 57 -160 minecraft:water[level=0]
fill 332 57 -161 366 57 -161 minecraft:water[level=0]
fill 367 57 -161 368 57 -161 minecraft:kelp_plant
setblock 369 57 -161 minecraft:water[level=0]
fill 370 57 -161 372 57 -161 minecraft:kelp_plant
fill 373 57 -161 376 57 -161 minecraft:water[level=0]
setblock 377 57 -161 minecraft:kelp_plant
fill 378 57 -161 388 57 -161 minecraft:water[level=0]
setblock 389 57 -161 minecraft:kelp[age=25]
fill 390 57 -161 391 57 -161 minecraft:water[level=0]
fill 332 57 -162 369 57 -162 minecraft:water[level=0]
fill 370 57 -162 371 57 -162 minecraft:kelp_plant
setblock 372 57 -162 minecraft:water[level=0]
setblock 373 57 -162 minecraft:kelp_plant
fill 374 57 -162 377 57 -162 minecraft:water[level=0]
setblock 378 57 -162 minecraft:kelp_plant
setblock 379 57 -162 minecraft:water[level=0]
setblock 380 57 -162 minecraft:kelp_plant
fill 381 57 -162 384 57 -162 minecraft:water[level=0]
setblock 385 57 -162 minecraft:kelp_plant
fill 386 57 -162 391 57 -162 minecraft:water[level=0]
fill 332 57 -163 370 57 -163 minecraft:water[level=0]
setblock 371 57 -163 minecraft:kelp_plant
fill 372 57 -163 391 57 -163 minecraft:water[level=0]
fill 332 57 -164 368 57 -164 minecraft:water[level=0]
setblock 369 57 -164 minecraft:kelp_plant
fill 370 57 -164 371 57 -164 minecraft:water[level=0]
fill 372 57 -164 373 57 -164 minecraft:kelp_plant
fill 374 57 -164 377 57 -164 minecraft:water[level=0]
setblock 378 57 -164 minecraft:kelp_plant
fill 379 57 -164 380 57 -164 minecraft:water[level=0]
setblock 381 57 -164 minecraft:kelp_plant
fill 382 57 -164 391 57 -164 minecraft:water[level=0]
fill 332 57 -165 363 57 -165 minecraft:water[level=0]
setblock 364 57 -165 minecraft:kelp_plant
fill 365 57 -165 375 57 -165 minecraft:water[level=0]
setblock 376 57 -165 minecraft:kelp_plant
fill 377 57 -165 380 57 -165 minecraft:water[level=0]
setblock 381 57 -165 minecraft:kelp_plant
fill 382 57 -165 391 57 -165 minecraft:water[level=0]
fill 332 57 -166 380 57 -166 minecraft:water[level=0]
setblock 381 57 -166 minecraft:kelp_plant
fill 382 57 -166 391 57 -166 minecraft:water[level=0]
fill 332 57 -167 379 57 -167 minecraft:water[level=0]
fill 380 57 -167 381 57 -167 minecraft:kelp_plant
fill 382 57 -167 383 57 -167 minecraft:water[level=0]
setblock 384 57 -167 minecraft:kelp_plant
setblock 385 57 -167 minecraft:water[level=0]
setblock 386 57 -167 minecraft:kelp_plant
fill 387 57 -167 391 57 -167 minecraft:water[level=0]
fill 331 57 -168 367 57 -168 minecraft:water[level=0]
setblock 368 57 -168 minecraft:kelp_plant
fill 369 57 -168 376 57 -168 minecraft:water[level=0]
setblock 377 57 -168 minecraft:kelp_plant
fill 378 57 -168 380 57 -168 minecraft:water[level=0]
fill 381 57 -168 383 57 -168 minecraft:kelp_plant
fill 384 57 -168 391 57 -168 minecraft:water[level=0]
fill 331 57 -169 351 57 -169 minecraft:water[level=0]
setblock 352 57 -169 minecraft:kelp_plant
fill 353 57 -169 375 57 -169 minecraft:water[level=0]
setblock 376 57 -169 minecraft:kelp_plant
fill 377 57 -169 379 57 -169 minecraft:water[level=0]
fill 380 57 -169 381 57 -169 minecraft:kelp_plant
fill 382 57 -169 391 57 -169 minecraft:water[level=0]
fill 330 57 -170 367 57 -170 minecraft:water[level=0]
setblock 368 57 -170 minecraft:kelp_plant
setblock 369 57 -170 minecraft:water[level=0]
setblock 370 57 -170 minecraft:kelp_plant
fill 371 57 -170 374 57 -170 minecraft:water[level=0]
setblock 375 57 -170 minecraft:kelp_plant
setblock 376 57 -170 minecraft:water[level=0]
fill 377 57 -170 378 57 -170 minecraft:kelp_plant
fill 379 57 -170 383 57 -170 minecraft:water[level=0]
setblock 384 57 -170 minecraft:kelp_plant
fill 385 57 -170 390 57 -170 minecraft:water[level=0]
setblock 391 57 -170 minecraft:kelp_plant
fill 330 57 -171 368 57 -171 minecraft:water[level=0]
fill 369 57 -171 370 57 -171 minecraft:kelp_plant
setblock 371 57 -171 minecraft:water[level=0]
setblock 372 57 -171 minecraft:kelp_plant
fill 373 57 -171 374 57 -171 minecraft:water[level=0]
setblock 375 57 -171 minecraft:kelp_plant
fill 376 57 -171 383 57 -171 minecraft:water[level=0]
setblock 384 57 -171 minecraft:kelp_plant
fill 385 57 -171 391 57 -171 minecraft:water[level=0]
fill 329 57 -172 356 57 -172 minecraft:water[level=0]
setblock 357 57 -172 minecraft:kelp_plant
fill 358 57 -172 367 57 -172 minecraft:water[level=0]
setblock 368 57 -172 minecraft:kelp_plant
fill 369 57 -172 370 57 -172 minecraft:water[level=0]
setblock 371 57 -172 minecraft:kelp_plant
fill 372 57 -172 374 57 -172 minecraft:water[level=0]
setblock 375 57 -172 minecraft:kelp_plant
fill 376 57 -172 379 57 -172 minecraft:water[level=0]
fill 380 57 -172 382 57 -172 minecraft:kelp_plant
setblock 383 57 -172 minecraft:water[level=0]
setblock 384 57 -172 minecraft:kelp_plant
fill 385 57 -172 386 57 -172 minecraft:water[level=0]
setblock 387 57 -172 minecraft:kelp_plant
fill 388 57 -172 391 57 -172 minecraft:water[level=0]
fill 331 57 -173 367 57 -173 minecraft:water[level=0]
setblock 368 57 -173 minecraft:kelp_plant
fill 369 57 -173 370 57 -173 minecraft:water[level=0]
setblock 371 57 -173 minecraft:kelp_plant
fill 372 57 -173 382 57 -173 minecraft:water[level=0]
setblock 383 57 -173 minecraft:kelp_plant
fill 384 57 -173 385 57 -173 minecraft:water[level=0]
setblock 386 57 -173 minecraft:kelp_plant
fill 387 57 -173 391 57 -173 minecraft:water[level=0]
fill 331 57 -174 358 57 -174 minecraft:water[level=0]
setblock 359 57 -174 minecraft:kelp_plant
fill 360 57 -174 366 57 -174 minecraft:water[level=0]
setblock 367 57 -174 minecraft:kelp_plant
setblock 368 57 -174 minecraft:water[level=0]
setblock 369 57 -174 minecraft:kelp_plant
fill 370 57 -174 376 57 -174 minecraft:water[level=0]
setblock 377 57 -174 minecraft:kelp_plant
fill 378 57 -174 387 57 -174 minecraft:water[level=0]
fill 388 57 -174 389 57 -174 minecraft:kelp_plant
fill 390 57 -174 391 57 -174 minecraft:water[level=0]
fill 331 57 -175 356 57 -175 minecraft:water[level=0]
setblock 357 57 -175 minecraft:kelp_plant
fill 358 57 -175 366 57 -175 minecraft:water[level=0]
fill 367 57 -175 368 57 -175 minecraft:kelp_plant
fill 369 57 -175 379 57 -175 minecraft:water[level=0]
setblock 380 57 -175 minecraft:kelp_plant
setblock 381 57 -175 minecraft:water[level=0]
setblock 382 57 -175 minecraft:kelp_plant
fill 383 57 -175 384 57 -175 minecraft:water[level=0]
setblock 385 57 -175 minecraft:kelp_plant
setblock 386 57 -175 minecraft:water[level=0]
setblock 387 57 -175 minecraft:kelp_plant
fill 388 57 -175 391 57 -175 minecraft:water[level=0]
fill 332 57 -176 370 57 -176 minecraft:water[level=0]
fill 371 57 -176 372 57 -176 minecraft:kelp_plant
fill 373 57 -176 376 57 -176 minecraft:water[level=0]
setblock 377 57 -176 minecraft:kelp_plant
fill 378 57 -176 380 57 -176 minecraft:water[level=0]
setblock 381 57 -176 minecraft:kelp_plant
fill 382 57 -176 386 57 -176 minecraft:water[level=0]
setblock 387 57 -176 minecraft:kelp_plant
setblock 388 57 -176 minecraft:water[level=0]
setblock 389 57 -176 minecraft:kelp_plant
fill 390 57 -176 391 57 -176 minecraft:water[level=0]
fill 332 57 -177 363 57 -177 minecraft:water[level=0]
fill 364 57 -177 365 57 -177 minecraft:kelp_plant
setblock 366 57 -177 minecraft:water[level=0]
fill 367 57 -177 368 57 -177 minecraft:kelp_plant
fill 369 57 -177 371 57 -177 minecraft:water[level=0]
fill 372 57 -177 373 57 -177 minecraft:kelp_plant
fill 374 57 -177 379 57 -177 minecraft:water[level=0]
setblock 380 57 -177 minecraft:kelp_plant
setblock 381 57 -177 minecraft:water[level=0]
fill 382 57 -177 383 57 -177 minecraft:kelp_plant
fill 384 57 -177 388 57 -177 minecraft:water[level=0]
setblock 389 57 -177 minecraft:kelp_plant
fill 390 57 -177 391 57 -177 minecraft:water[level=0]
fill 332 57 -178 356 57 -178 minecraft:water[level=0]
setblock 357 57 -178 minecraft:kelp_plant
fill 358 57 -178 366 57 -178 minecraft:water[level=0]
fill 367 57 -178 368 57 -178 minecraft:kelp_plant
fill 369 57 -178 372 57 -178 minecraft:water[level=0]
setblock 373 57 -178 minecraft:kelp_plant
fill 374 57 -178 376 57 -178 minecraft:water[level=0]
fill 377 57 -178 378 57 -178 minecraft:kelp_plant
fill 379 57 -178 381 57 -178 minecraft:water[level=0]
setblock 382 57 -178 minecraft:kelp_plant
fill 383 57 -178 391 57 -178 minecraft:water[level=0]
fill 332 57 -179 351 57 -179 minecraft:water[level=0]
setblock 352 57 -179 minecraft:kelp[age=25]
setblock 353 57 -179 minecraft:water[level=0]
setblock 354 57 -179 minecraft:kelp_plant
fill 355 57 -179 366 57 -179 minecraft:water[level=0]
setblock 367 57 -179 minecraft:kelp_plant
fill 368 57 -179 369 57 -179 minecraft:water[level=0]
setblock 370 57 -179 minecraft:kelp_plant
fill 371 57 -179 372 57 -179 minecraft:water[level=0]
setblock 373 57 -179 minecraft:kelp_plant
fill 374 57 -179 378 57 -179 minecraft:water[level=0]
setblock 379 57 -179 minecraft:kelp_plant
fill 380 57 -179 381 57 -179 minecraft:water[level=0]
fill 382 57 -179 383 57 -179 minecraft:kelp_plant
fill 384 57 -179 386 57 -179 minecraft:water[level=0]
setblock 387 57 -179 minecraft:kelp_plant
fill 388 57 -179 391 57 -179 minecraft:water[level=0]
fill 332 57 -180 353 57 -180 minecraft:water[level=0]
fill 354 57 -180 355 57 -180 minecraft:kelp_plant
fill 356 57 -180 359 57 -180 minecraft:water[level=0]
setblock 360 57 -180 minecraft:kelp_plant
fill 361 57 -180 366 57 -180 minecraft:water[level=0]
setblock 367 57 -180 minecraft:kelp_plant
setblock 368 57 -180 minecraft:water[level=0]
setblock 369 57 -180 minecraft:kelp_plant
setblock 370 57 -180 minecraft:water[level=0]
setblock 371 57 -180 minecraft:kelp_plant
fill 372 57 -180 376 57 -180 minecraft:water[level=0]
setblock 377 57 -180 minecraft:kelp_plant
fill 378 57 -180 379 57 -180 minecraft:water[level=0]
setblock 380 57 -180 minecraft:kelp_plant
fill 381 57 -180 391 57 -180 minecraft:water[level=0]
fill 332 57 -181 348 57 -181 minecraft:water[level=0]
setblock 349 57 -181 minecraft:kelp_plant
fill 350 57 -181 352 57 -181 minecraft:water[level=0]
setblock 353 57 -181 minecraft:kelp_plant
setblock 354 57 -181 minecraft:water[level=0]
setblock 355 57 -181 minecraft:kelp_plant
setblock 356 57 -181 minecraft:water[level=0]
setblock 357 57 -181 minecraft:kelp_plant
fill 358 57 -181 364 57 -181 minecraft:water[level=0]
setblock 365 57 -181 minecraft:kelp_plant
fill 366 57 -181 374 57 -181 minecraft:water[level=0]
setblock 375 57 -181 minecraft:kelp_plant
setblock 376 57 -181 minecraft:water[level=0]
setblock 377 57 -181 minecraft:kelp_plant
setblock 378 57 -181 minecraft:water[level=0]
fill 379 57 -181 380 57 -181 minecraft:kelp_plant
setblock 381 57 -181 minecraft:water[level=0]
setblock 382 57 -181 minecraft:kelp_plant
setblock 383 57 -181 minecraft:water[level=0]
setblock 384 57 -181 minecraft:tall_seagrass[half=upper]
fill 385 57 -181 389 57 -181 minecraft:water[level=0]
setblock 390 57 -181 minecraft:kelp_plant
setblock 391 57 -181 minecraft:water[level=0]
fill 332 57 -182 336 57 -182 minecraft:water[level=0]
setblock 337 57 -182 minecraft:kelp[age=25]
fill 338 57 -182 352 57 -182 minecraft:water[level=0]
fill 353 57 -182 354 57 -182 minecraft:kelp_plant
setblock 355 57 -182 minecraft:water[level=0]
setblock 356 57 -182 minecraft:kelp_plant
fill 357 57 -182 359 57 -182 minecraft:water[level=0]
fill 360 57 -182 362 57 -182 minecraft:kelp_plant
fill 363 57 -182 365 57 -182 minecraft:water[level=0]
fill 366 57 -182 368 57 -182 minecraft:kelp_plant
setblock 369 57 -182 minecraft:water[level=0]
setblock 370 57 -182 minecraft:kelp_plant
fill 371 57 -182 372 57 -182 minecraft:water[level=0]
setblock 373 57 -182 minecraft:kelp_plant
fill 374 57 -182 376 57 -182 minecraft:water[level=0]
setblock 377 57 -182 minecraft:kelp_plant
fill 378 57 -182 379 57 -182 minecraft:water[level=0]
setblock 380 57 -182 minecraft:kelp_plant
fill 381 57 -182 382 57 -182 minecraft:water[level=0]
setblock 383 57 -182 minecraft:kelp_plant
fill 384 57 -182 386 57 -182 minecraft:water[level=0]
setblock 387 57 -182 minecraft:kelp_plant
fill 388 57 -182 391 57 -182 minecraft:water[level=0]
fill 332 57 -183 346 57 -183 minecraft:water[level=0]
setblock 347 57 -183 minecraft:kelp_plant
fill 348 57 -183 359 57 -183 minecraft:water[level=0]
setblock 360 57 -183 minecraft:kelp_plant
fill 361 57 -183 366 57 -183 minecraft:water[level=0]
setblock 367 57 -183 minecraft:kelp_plant
setblock 368 57 -183 minecraft:water[level=0]
setblock 369 57 -183 minecraft:kelp_plant
setblock 370 57 -183 minecraft:water[level=0]
setblock 371 57 -183 minecraft:kelp_plant
fill 372 57 -183 377 57 -183 minecraft:water[level=0]
setblock 378 57 -183 minecraft:kelp_plant
fill 379 57 -183 386 57 -183 minecraft:water[level=0]
setblock 387 57 -183 minecraft:kelp_plant
fill 388 57 -183 391 57 -183 minecraft:water[level=0]
fill 332 57 -184 345 57 -184 minecraft:water[level=0]
setblock 346 57 -184 minecraft:kelp_plant
fill 347 57 -184 348 57 -184 minecraft:water[level=0]
setblock 349 57 -184 minecraft:kelp_plant
fill 350 57 -184 359 57 -184 minecraft:water[level=0]
fill 360 57 -184 361 57 -184 minecraft:kelp_plant
fill 362 57 -184 369 57 -184 minecraft:water[level=0]
setblock 370 57 -184 minecraft:kelp_plant
fill 371 57 -184 375 57 -184 minecraft:water[level=0]
setblock 376 57 -184 minecraft:kelp_plant
fill 377 57 -184 379 57 -184 minecraft:water[level=0]
setblock 380 57 -184 minecraft:kelp_plant
fill 381 57 -184 386 57 -184 minecraft:water[level=0]
fill 387 57 -184 389 57 -184 minecraft:kelp_plant
fill 390 57 -184 391 57 -184 minecraft:water[level=0]
fill 332 57 -185 356 57 -185 minecraft:water[level=0]
setblock 357 57 -185 minecraft:kelp_plant
fill 358 57 -185 363 57 -185 minecraft:water[level=0]
setblock 364 57 -185 minecraft:kelp_plant
fill 365 57 -185 370 57 -185 minecraft:water[level=0]
setblock 371 57 -185 minecraft:kelp_plant
fill 372 57 -185 373 57 -185 minecraft:water[level=0]
setblock 374 57 -185 minecraft:kelp_plant
fill 375 57 -185 379 57 -185 minecraft:water[level=0]
setblock 380 57 -185 minecraft:kelp_plant
setblock 381 57 -185 minecraft:water[level=0]
setblock 382 57 -185 minecraft:kelp_plant
setblock 383 57 -185 minecraft:water[level=0]
setblock 384 57 -185 minecraft:kelp_plant
fill 385 57 -185 391 57 -185 minecraft:water[level=0]
fill 332 57 -186 341 57 -186 minecraft:water[level=0]
setblock 342 57 -186 minecraft:kelp_plant
fill 343 57 -186 359 57 -186 minecraft:water[level=0]
setblock 360 57 -186 minecraft:kelp_plant
fill 361 57 -186 368 57 -186 minecraft:water[level=0]
setblock 369 57 -186 minecraft:kelp_plant
fill 370 57 -186 376 57 -186 minecraft:water[level=0]
fill 377 57 -186 379 57 -186 minecraft:kelp_plant
fill 380 57 -186 390 57 -186 minecraft:water[level=0]
setblock 391 57 -186 minecraft:kelp_plant
fill 332 57 -187 353 57 -187 minecraft:water[level=0]
setblock 354 57 -187 minecraft:kelp_plant
fill 355 57 -187 356 57 -187 minecraft:water[level=0]
fill 357 57 -187 358 57 -187 minecraft:kelp_plant
fill 359 57 -187 364 57 -187 minecraft:water[level=0]
fill 365 57 -187 366 57 -187 minecraft:kelp_plant
fill 367 57 -187 369 57 -187 minecraft:water[level=0]
setblock 370 57 -187 minecraft:kelp_plant
fill 371 57 -187 373 57 -187 minecraft:water[level=0]
setblock 374 57 -187 minecraft:kelp_plant
fill 375 57 -187 379 57 -187 minecraft:water[level=0]
fill 380 57 -187 381 57 -187 minecraft:kelp_plant
fill 382 57 -187 387 57 -187 minecraft:water[level=0]
setblock 388 57 -187 minecraft:kelp_plant
fill 389 57 -187 390 57 -187 minecraft:water[level=0]
setblock 391 57 -187 minecraft:kelp[age=25]
fill 332 57 -188 352 57 -188 minecraft:water[level=0]
setblock 353 57 -188 minecraft:kelp_plant
setblock 354 57 -188 minecraft:water[level=0]
fill 355 57 -188 356 57 -188 minecraft:kelp_plant
fill 357 57 -188 362 57 -188 minecraft:water[level=0]
fill 363 57 -188 365 57 -188 minecraft:kelp_plant
setblock 366 57 -188 minecraft:water[level=0]
setblock 367 57 -188 minecraft:kelp_plant
setblock 368 57 -188 minecraft:water[level=0]
setblock 369 57 -188 minecraft:kelp_plant
setblock 370 57 -188 minecraft:water[level=0]
fill 371 57 -188 374 57 -188 minecraft:kelp_plant
fill 375 57 -188 376 57 -188 minecraft:water[level=0]
fill 377 57 -188 378 57 -188 minecraft:kelp_plant
fill 379 57 -188 380 57 -188 minecraft:water[level=0]
setblock 381 57 -188 minecraft:kelp_plant
setblock 382 57 -188 minecraft:water[level=0]
fill 383 57 -188 384 57 -188 minecraft:kelp_plant
fill 385 57 -188 391 57 -188 minecraft:water[level=0]
fill 332 57 -189 351 57 -189 minecraft:water[level=0]
setblock 352 57 -189 minecraft:kelp_plant
fill 353 57 -189 356 57 -189 minecraft:water[level=0]
setblock 357 57 -189 minecraft:kelp_plant
fill 358 57 -189 363 57 -189 minecraft:water[level=0]
fill 364 57 -189 365 57 -189 minecraft:kelp_plant
fill 366 57 -189 368 57 -189 minecraft:water[level=0]
setblock 369 57 -189 minecraft:kelp_plant
fill 370 57 -189 375 57 -189 minecraft:water[level=0]
setblock 376 57 -189 minecraft:kelp_plant
fill 377 57 -189 381 57 -189 minecraft:water[level=0]
fill 382 57 -189 383 57 -189 minecraft:kelp_plant
fill 384 57 -189 391 57 -189 minecraft:water[level=0]
fill 332 57 -190 357 57 -190 minecraft:water[level=0]
setblock 358 57 -190 minecraft:kelp_plant
fill 359 57 -190 361 57 -190 minecraft:water[level=0]
setblock 362 57 -190 minecraft:kelp_plant
fill 363 57 -190 364 57 -190 minecraft:water[level=0]
fill 365 57 -190 370 57 -190 minecraft:kelp_plant
fill 371 57 -190 375 57 -190 minecraft:water[level=0]
setblock 376 57 -190 minecraft:kelp_plant
fill 377 57 -190 380 57 -190 minecraft:water[level=0]
fill 381 57 -190 382 57 -190 minecraft:kelp_plant
fill 383 57 -190 386 57 -190 minecraft:water[level=0]
fill 387 57 -190 388 57 -190 minecraft:kelp_plant
fill 389 57 -190 391 57 -190 minecraft:water[level=0]
fill 328 56 -127 330 56 -127 minecraft:water[level=0]
setblock 331 56 -127 minecraft:tall_seagrass[half=upper]
setblock 332 56 -127 minecraft:seagrass
setblock 333 56 -127 minecraft:water[level=0]
setblock 334 56 -127 minecraft:tall_seagrass[half=upper]
fill 335 56 -127 340 56 -127 minecraft:water[level=0]
setblock 341 56 -127 minecraft:kelp_plant
fill 342 56 -127 343 56 -127 minecraft:water[level=0]
setblock 344 56 -127 minecraft:tall_seagrass[half=upper]
fill 345 56 -127 346 56 -127 minecraft:water[level=0]
fill 347 56 -127 349 56 -127 minecraft:kelp_plant
fill 350 56 -127 353 56 -127 minecraft:water[level=0]
setblock 354 56 -127 minecraft:kelp_plant
fill 355 56 -127 360 56 -127 minecraft:water[level=0]
setblock 361 56 -127 minecraft:kelp[age=25]
fill 362 56 -127 368 56 -127 minecraft:water[level=0]
setblock 369 56 -127 minecraft:kelp_plant
fill 370 56 -127 372 56 -127 minecraft:water[level=0]
setblock 373 56 -127 minecraft:kelp_plant
fill 374 56 -127 383 56 -127 minecraft:water[level=0]
setblock 384 56 -127 minecraft:kelp_plant
setblock 385 56 -127 minecraft:kelp[age=25]
fill 386 56 -127 390 56 -127 minecraft:water[level=0]
setblock 391 56 -127 minecraft:kelp_plant
fill 328 56 -128 330 56 -128 minecraft:water[level=0]
fill 331 56 -128 332 56 -128 minecraft:seagrass
setblock 333 56 -128 minecraft:water[level=0]
setblock 334 56 -128 minecraft:seagrass
setblock 335 56 -128 minecraft:tall_seagrass[half=lower]
setblock 336 56 -128 minecraft:seagrass
setblock 337 56 -128 minecraft:water[level=0]
setblock 338 56 -128 minecraft:kelp_plant
setblock 339 56 -128 minecraft:water[level=0]
setblock 340 56 -128 minecraft:seagrass
fill 341 56 -128 345 56 -128 minecraft:water[level=0]
setblock 346 56 -128 minecraft:kelp_plant
fill 347 56 -128 354 56 -128 minecraft:water[level=0]
setblock 355 56 -128 minecraft:kelp_plant
setblock 356 56 -128 minecraft:water[level=0]
setblock 357 56 -128 minecraft:kelp_plant
fill 358 56 -128 359 56 -128 minecraft:water[level=0]
setblock 360 56 -128 minecraft:kelp_plant
fill 361 56 -128 366 56 -128 minecraft:water[level=0]
setblock 367 56 -128 minecraft:kelp_plant
fill 368 56 -128 369 56 -128 minecraft:water[level=0]
setblock 370 56 -128 minecraft:kelp_plant
setblock 371 56 -128 minecraft:water[level=0]
fill 372 56 -128 373 56 -128 minecraft:kelp_plant
setblock 374 56 -128 minecraft:water[level=0]
setblock 375 56 -128 minecraft:kelp_plant
setblock 376 56 -128 minecraft:kelp[age=25]
setblock 377 56 -128 minecraft:water[level=0]
fill 378 56 -128 380 56 -128 minecraft:kelp_plant
fill 381 56 -128 386 56 -128 minecraft:water[level=0]
setblock 387 56 -128 minecraft:kelp_plant
fill 388 56 -128 391 56 -128 minecraft:water[level=0]
fill 328 56 -129 334 56 -129 minecraft:water[level=0]
setblock 335 56 -129 minecraft:tall_seagrass[half=upper]
fill 336 56 -129 337 56 -129 minecraft:water[level=0]
setblock 338 56 -129 minecraft:seagrass
fill 339 56 -129 341 56 -129 minecraft:water[level=0]
setblock 342 56 -129 minecraft:kelp_plant
fill 343 56 -129 348 56 -129 minecraft:water[level=0]
setblock 349 56 -129 minecraft:kelp_plant
fill 350 56 -129 358 56 -129 minecraft:water[level=0]
setblock 359 56 -129 minecraft:kelp_plant
fill 360 56 -129 368 56 -129 minecraft:water[level=0]
setblock 369 56 -129 minecraft:kelp_plant
fill 370 56 -129 376 56 -129 minecraft:water[level=0]
setblock 377 56 -129 minecraft:kelp_plant
fill 378 56 -129 386 56 -129 minecraft:water[level=0]
setblock 387 56 -129 minecraft:kelp_plant
fill 388 56 -129 389 56 -129 minecraft:water[level=0]
setblock 390 56 -129 minecraft:kelp_plant
setblock 391 56 -129 minecraft:water[level=0]
fill 328 56 -130 333 56 -130 minecraft:water[level=0]
setblock 334 56 -130 minecraft:kelp_plant
fill 335 56 -130 342 56 -130 minecraft:water[level=0]
setblock 343 56 -130 minecraft:kelp_plant
fill 344 56 -130 350 56 -130 minecraft:water[level=0]
setblock 351 56 -130 minecraft:kelp_plant
fill 352 56 -130 362 56 -130 minecraft:water[level=0]
setblock 363 56 -130 minecraft:kelp_plant
fill 364 56 -130 365 56 -130 minecraft:water[level=0]
setblock 366 56 -130 minecraft:kelp_plant
fill 367 56 -130 368 56 -130 minecraft:water[level=0]
setblock 369 56 -130 minecraft:kelp_plant
fill 370 56 -130 391 56 -130 minecraft:water[level=0]
setblock 328 56 -131 minecraft:kelp_plant
fill 329 56 -131 337 56 -131 minecraft:water[level=0]
setblock 338 56 -131 minecraft:tall_seagrass[half=upper]
fill 339 56 -131 367 56 -131 minecraft:water[level=0]
setblock 368 56 -131 minecraft:kelp_plant
fill 369 56 -131 391 56 -131 minecraft:water[level=0]
fill 328 56 -132 362 56 -132 minecraft:water[level=0]
setblock 363 56 -132 minecraft:kelp_plant
fill 364 56 -132 377 56 -132 minecraft:water[level=0]
setblock 378 56 -132 minecraft:kelp[age=25]
fill 379 56 -132 382 56 -132 minecraft:water[level=0]
setblock 383 56 -132 minecraft:kelp_plant
setblock 384 56 -132 minecraft:water[level=0]
setblock 385 56 -132 minecraft:kelp[age=25]
setblock 386 56 -132 minecraft:water[level=0]
setblock 387 56 -132 minecraft:kelp_plant
setblock 388 56 -132 minecraft:kelp[age=25]
fill 389 56 -132 391 56 -132 minecraft:water[level=0]
fill 328 56 -133 348 56 -133 minecraft:water[level=0]
setblock 349 56 -133 minecraft:kelp_plant
fill 350 56 -133 351 56 -133 minecraft:water[level=0]
setblock 352 56 -133 minecraft:kelp_plant
fill 353 56 -133 356 56 -133 minecraft:water[level=0]
setblock 357 56 -133 minecraft:kelp_plant
fill 358 56 -133 381 56 -133 minecraft:water[level=0]
setblock 382 56 -133 minecraft:kelp[age=25]
fill 383 56 -133 387 56 -133 minecraft:water[level=0]
setblock 388 56 -133 minecraft:kelp_plant
fill 389 56 -133 391 56 -133 minecraft:water[level=0]
fill 328 56 -134 336 56 -134 minecraft:water[level=0]
setblock 337 56 -134 minecraft:kelp_plant
fill 338 56 -134 368 56 -134 minecraft:water[level=0]
setblock 369 56 -134 minecraft:kelp_plant
fill 370 56 -134 371 56 -134 minecraft:water[level=0]
setblock 372 56 -134 minecraft:kelp[age=25]
fill 373 56 -134 383 56 -134 minecraft:water[level=0]
fill 384 56 -134 385 56 -134 minecraft:kelp_plant
fill 386 56 -134 391 56 -134 minecraft:water[level=0]
fill 328 56 -135 331 56 -135 minecraft:water[level=0]
setblock 332 56 -135 minecraft:kelp_plant
fill 333 56 -135 336 56 -135 minecraft:water[level=0]
setblock 337 56 -135 minecraft:kelp_plant
fill 338 56 -135 347 56 -135 minecraft:water[level=0]
fill 348 56 -135 350 56 -135 minecraft:kelp_plant
setblock 351 56 -135 minecraft:tall_seagrass[half=upper]
fill 352 56 -135 376 56 -135 minecraft:water[level=0]
setblock 377 56 -135 minecraft:kelp_plant
fill 378 56 -135 379 56 -135 minecraft:water[level=0]
setblock 380 56 -135 minecraft:kelp_plant
fill 381 56 -135 384 56 -135 minecraft:water[level=0]
setblock 385 56 -135 minecraft:kelp_plant
fill 386 56 -135 391 56 -135 minecraft:water[level=0]
fill 328 56 -136 342 56 -136 minecraft:water[level=0]
setblock 343 56 -136 minecraft:kelp_plant
fill 344 56 -136 345 56 -136 minecraft:water[level=0]
setblock 346 56 -136 minecraft:kelp_plant
fill 347 56 -136 348 56 -136 minecraft:water[level=0]
setblock 349 56 -136 minecraft:kelp_plant
fill 350 56 -136 361 56 -136 minecraft:water[level=0]
setblock 362 56 -136 minecraft:kelp_plant
fill 363 56 -136 364 56 -136 minecraft:water[level=0]
setblock 365 56 -136 minecraft:kelp_plant
fill 366 56 -136 374 56 -136 minecraft:water[level=0]
setblock 375 56 -136 minecraft:kelp_plant
fill 376 56 -136 377 56 -136 minecraft:water[level=0]
setblock 378 56 -136 minecraft:kelp_plant
fill 379 56 -136 381 56 -136 minecraft:water[level=0]
setblock 382 56 -136 minecraft:kelp[age=25]
fill 383 56 -136 384 56 -136 minecraft:water[level=0]
setblock 385 56 -136 minecraft:kelp_plant
fill 386 56 -136 387 56 -136 minecraft:water[level=0]
setblock 388 56 -136 minecraft:kelp_plant
setblock 389 56 -136 minecraft:kelp[age=25]
fill 390 56 -136 391 56 -136 minecraft:water[level=0]
setblock 328 56 -137 minecraft:kelp_plant
fill 329 56 -137 330 56 -137 minecraft:water[level=0]
setblock 331 56 -137 minecraft:kelp_plant
fill 332 56 -137 367 56 -137 minecraft:water[level=0]
setblock 368 56 -137 minecraft:kelp_plant
fill 369 56 -137 381 56 -137 minecraft:water[level=0]
setblock 382 56 -137 minecraft:kelp[age=25]
fill 383 56 -137 384 56 -137 minecraft:water[level=0]
setblock 385 56 -137 minecraft:kelp_plant
fill 386 56 -137 391 56 -137 minecraft:water[level=0]
fill 328 56 -138 351 56 -138 minecraft:water[level=0]
setblock 352 56 -138 minecraft:tall_seagrass[half=upper]
fill 353 56 -138 366 56 -138 minecraft:water[level=0]
setblock 367 56 -138 minecraft:kelp_plant
fill 368 56 -138 384 56 -138 minecraft:water[level=0]
setblock 385 56 -138 minecraft:kelp_plant
fill 386 56 -138 388 56 -138 minecraft:water[level=0]
setblock 389 56 -138 minecraft:kelp_plant
fill 390 56 -138 391 56 -138 minecraft:water[level=0]
fill 328 56 -139 352 56 -139 minecraft:water[level=0]
setblock 353 56 -139 minecraft:tall_seagrass[half=upper]
fill 354 56 -139 359 56 -139 minecraft:water[level=0]
setblock 360 56 -139 minecraft:kelp_plant
fill 361 56 -139 371 56 -139 minecraft:water[level=0]
setblock 372 56 -139 minecraft:kelp_plant
fill 373 56 -139 383 56 -139 minecraft:water[level=0]
setblock 384 56 -139 minecraft:kelp_plant
fill 385 56 -139 391 56 -139 minecraft:water[level=0]
fill 328 56 -140 343 56 -140 minecraft:water[level=0]
setblock 344 56 -140 minecraft:kelp_plant
fill 345 56 -140 354 56 -140 minecraft:water[level=0]
setblock 355 56 -140 minecraft:kelp_plant
fill 356 56 -140 368 56 -140 minecraft:water[level=0]
setblock 369 56 -140 minecraft:kelp_plant
setblock 370 56 -140 minecraft:water[level=0]
setblock 371 56 -140 minecraft:kelp_plant
fill 372 56 -140 377 56 -140 minecraft:water[level=0]
setblock 378 56 -140 minecraft:kelp_plant
fill 379 56 -140 380 56 -140 minecraft:water[level=0]
setblock 381 56 -140 minecraft:kelp_plant
fill 382 56 -140 391 56 -140 minecraft:water[level=0]
fill 328 56 -141 355 56 -141 minecraft:water[level=0]
setblock 356 56 -141 minecraft:kelp_plant
fill 357 56 -141 368 56 -141 minecraft:water[level=0]
setblock 369 56 -141 minecraft:kelp_plant
fill 370 56 -141 378 56 -141 minecraft:water[level=0]
setblock 379 56 -141 minecraft:kelp_plant
fill 380 56 -141 382 56 -141 minecraft:water[level=0]
setblock 383 56 -141 minecraft:kelp_plant
fill 384 56 -141 387 56 -141 minecraft:water[level=0]
fill 388 56 -141 389 56 -141 minecraft:kelp_plant
fill 390 56 -141 391 56 -141 minecraft:water[level=0]
fill 328 56 -142 352 56 -142 minecraft:water[level=0]
setblock 353 56 -142 minecraft:kelp_plant
fill 354 56 -142 367 56 -142 minecraft:water[level=0]
fill 368 56 -142 369 56 -142 minecraft:kelp_plant
setblock 370 56 -142 minecraft:water[level=0]
fill 371 56 -142 372 56 -142 minecraft:kelp_plant
fill 373 56 -142 391 56 -142 minecraft:water[level=0]
fill 328 56 -143 331 56 -143 minecraft:water[level=0]
setblock 332 56 -143 minecraft:kelp_plant
fill 333 56 -143 337 56 -143 minecraft:water[level=0]
setblock 338 56 -143 minecraft:kelp_plant
fill 339 56 -143 341 56 -143 minecraft:water[level=0]
setblock 342 56 -143 minecraft:kelp_plant
fill 343 56 -143 377 56 -143 minecraft:water[level=0]
fill 378 56 -143 379 56 -143 minecraft:kelp_plant
fill 380 56 -143 382 56 -143 minecraft:water[level=0]
setblock 383 56 -143 minecraft:kelp_plant
fill 384 56 -143 385 56 -143 minecraft:water[level=0]
setblock 386 56 -143 minecraft:kelp_plant
fill 387 56 -143 391 56 -143 minecraft:water[level=0]
fill 328 56 -144 345 56 -144 minecraft:water[level=0]
setblock 346 56 -144 minecraft:tall_seagrass[half=upper]
fill 347 56 -144 351 56 -144 minecraft:water[level=0]
setblock 352 56 -144 minecraft:kelp_plant
fill 353 56 -144 370 56 -144 minecraft:water[level=0]
setblock 371 56 -144 minecraft:kelp_plant
fill 372 56 -144 391 56 -144 minecraft:water[level=0]
fill 328 56 -145 343 56 -145 minecraft:water[level=0]
setblock 344 56 -145 minecraft:tall_seagrass[half=upper]
fill 345 56 -145 368 56 -145 minecraft:water[level=0]
fill 369 56 -145 370 56 -145 minecraft:kelp[age=25]
fill 371 56 -145 383 56 -145 minecraft:water[level=0]
setblock 384 56 -145 minecraft:kelp_plant
setblock 385 56 -145 minecraft:water[level=0]
setblock 386 56 -145 minecraft:kelp_plant
fill 387 56 -145 388 56 -145 minecraft:water[level=0]
setblock 389 56 -145 minecraft:kelp_plant
fill 390 56 -145 391 56 -145 minecraft:water[level=0]
fill 328 56 -146 367 56 -146 minecraft:water[level=0]
setblock 368 56 -146 minecraft:kelp_plant
fill 369 56 -146 371 56 -146 minecraft:water[level=0]
setblock 372 56 -146 minecraft:kelp_plant
fill 373 56 -146 391 56 -146 minecraft:water[level=0]
fill 328 56 -147 352 56 -147 minecraft:water[level=0]
setblock 353 56 -147 minecraft:tall_seagrass[half=upper]
fill 354 56 -147 368 56 -147 minecraft:water[level=0]
setblock 369 56 -147 minecraft:kelp_plant
fill 370 56 -147 373 56 -147 minecraft:water[level=0]
fill 374 56 -147 375 56 -147 minecraft:kelp_plant
fill 376 56 -147 385 56 -147 minecraft:water[level=0]
setblock 386 56 -147 minecraft:kelp_plant
fill 387 56 -147 391 56 -147 minecraft:water[level=0]
fill 328 56 -148 374 56 -148 minecraft:water[level=0]
setblock 375 56 -148 minecraft:kelp_plant
fill 376 56 -148 377 56 -148 minecraft:water[level=0]
setblock 378 56 -148 minecraft:kelp_plant
fill 379 56 -148 386 56 -148 minecraft:water[level=0]
setblock 387 56 -148 minecraft:kelp_plant
setblock 388 56 -148 minecraft:water[level=0]
setblock 389 56 -148 minecraft:kelp_plant
fill 390 56 -148 391 56 -148 minecraft:water[level=0]
fill 328 56 -149 368 56 -149 minecraft:water[level=0]
fill 369 56 -149 370 56 -149 minecraft:kelp_plant
fill 371 56 -149 377 56 -149 minecraft:water[level=0]
setblock 378 56 -149 minecraft:kelp_plant
fill 379 56 -149 390 56 -149 minecraft:water[level=0]
setblock 391 56 -149 minecraft:kelp[age=25]
fill 328 56 -150 346 56 -150 minecraft:water[level=0]
setblock 347 56 -150 minecraft:tall_seagrass[half=upper]
fill 348 56 -150 369 56 -150 minecraft:water[level=0]
fill 370 56 -150 371 56 -150 minecraft:kelp_plant
fill 372 56 -150 391 56 -150 minecraft:water[level=0]
fill 328 56 -151 381 56 -151 minecraft:water[level=0]
setblock 382 56 -151 minecraft:kelp_plant
fill 383 56 -151 385 56 -151 minecraft:water[level=0]
setblock 386 56 -151 minecraft:kelp_plant
fill 387 56 -151 391 56 -151 minecraft:water[level=0]
fill 328 56 -152 367 56 -152 minecraft:water[level=0]
fill 368 56 -152 369 56 -152 minecraft:kelp_plant
setblock 370 56 -152 minecraft:water[level=0]
setblock 371 56 -152 minecraft:kelp_plant
fill 372 56 -152 376 56 -152 minecraft:water[level=0]
setblock 377 56 -152 minecraft:kelp_plant
fill 378 56 -152 385 56 -152 minecraft:water[level=0]
setblock 386 56 -152 minecraft:kelp_plant
fill 387 56 -152 390 56 -152 minecraft:water[level=0]
setblock 391 56 -152 minecraft:kelp_plant
fill 328 56 -153 369 56 -153 minecraft:water[level=0]
setblock 370 56 -153 minecraft:kelp_plant
setblock 371 56 -153 minecraft:water[level=0]
setblock 372 56 -153 minecraft:kelp_plant
fill 373 56 -153 380 56 -153 minecraft:water[level=0]
fill 381 56 -153 382 56 -153 minecraft:kelp_plant
setblock 383 56 -153 minecraft:water[level=0]
fill 384 56 -153 386 56 -153 minecraft:kelp_plant
fill 387 56 -153 389 56 -153 minecraft:water[level=0]
setblock 390 56 -153 minecraft:kelp_plant
setblock 391 56 -153 minecraft:water[level=0]
fill 328 56 -154 372 56 -154 minecraft:water[level=0]
setblock 373 56 -154 minecraft:kelp_plant
fill 374 56 -154 375 56 -154 minecraft:water[level=0]
setblock 376 56 -154 minecraft:kelp_plant
fill 377 56 -154 391 56 -154 minecraft:water[level=0]
fill 328 56 -155 376 56 -155 minecraft:water[level=0]
fill 377 56 -155 379 56 -155 minecraft:kelp_plant
setblock 380 56 -155 minecraft:water[level=0]
setblock 381 56 -155 minecraft:kelp_plant
fill 382 56 -155 391 56 -155 minecraft:water[level=0]
fill 328 56 -156 368 56 -156 minecraft:water[level=0]
setblock 369 56 -156 minecraft:kelp_plant
fill 370 56 -156 372 56 -156 minecraft:water[level=0]
setblock 373 56 -156 minecraft:kelp_plant
fill 374 56 -156 381 56 -156 minecraft:water[level=0]
fill 382 56 -156 383 56 -156 minecraft:kelp_plant
fill 384 56 -156 391 56 -156 minecraft:water[level=0]
fill 329 56 -157 368 56 -157 minecraft:water[level=0]
setblock 369 56 -157 minecraft:kelp_plant
fill 370 56 -157 376 56 -157 minecraft:water[level=0]
setblock 377 56 -157 minecraft:kelp_plant
fill 378 56 -157 380 56 -157 minecraft:water[level=0]
setblock 381 56 -157 minecraft:kelp_plant
fill 382 56 -157 390 56 -157 minecraft:water[level=0]
setblock 391 56 -157 minecraft:kelp_plant
fill 331 56 -158 379 56 -158 minecraft:water[level=0]
setblock 380 56 -158 minecraft:kelp_plant
fill 381 56 -158 391 56 -158 minecraft:water[level=0]
fill 331 56 -159 369 56 -159 minecraft:water[level=0]
fill 370 56 -159 371 56 -159 minecraft:kelp_plant
fill 372 56 -159 374 56 -159 minecraft:water[level=0]
setblock 375 56 -159 minecraft:kelp_plant
fill 376 56 -159 386 56 -159 minecraft:water[level=0]
setblock 387 56 -159 minecraft:kelp[age=25]
fill 388 56 -159 391 56 -159 minecraft:water[level=0]
fill 332 56 -160 369 56 -160 minecraft:water[level=0]
fill 370 56 -160 371 56 -160 minecraft:kelp_plant
fill 372 56 -160 375 56 -160 minecraft:water[level=0]
setblock 376 56 -160 minecraft:kelp_plant
fill 377 56 -160 389 56 -160 minecraft:water[level=0]
setblock 390 56 -160 minecraft:kelp_plant
setblock 391 56 -160 minecraft:water[level=0]
fill 332 56 -161 366 56 -161 minecraft:water[level=0]
fill 367 56 -161 368 56 -161 minecraft:kelp_plant
setblock 369 56 -161 minecraft:water[level=0]
fill 370 56 -161 372 56 -161 minecraft:kelp_plant
fill 373 56 -161 376 56 -161 minecraft:water[level=0]
setblock 377 56 -161 minecraft:kelp_plant
fill 378 56 -161 388 56 -161 minecraft:water[level=0]
setblock 389 56 -161 minecraft:kelp_plant
fill 390 56 -161 391 56 -161 minecraft:water[level=0]
fill 332 56 -162 369 56 -162 minecraft:water[level=0]
fill 370 56 -162 371 56 -162 minecraft:kelp_plant
setblock 372 56 -162 minecraft:water[level=0]
setblock 373 56 -162 minecraft:kelp_plant
fill 374 56 -162 377 56 -162 minecraft:water[level=0]
setblock 378 56 -162 minecraft:kelp_plant
setblock 379 56 -162 minecraft:water[level=0]
setblock 380 56 -162 minecraft:kelp_plant
fill 381 56 -162 384 56 -162 minecraft:water[level=0]
setblock 385 56 -162 minecraft:kelp_plant
fill 386 56 -162 391 56 -162 minecraft:water[level=0]
fill 332 56 -163 370 56 -163 minecraft:water[level=0]
setblock 371 56 -163 minecraft:kelp_plant
fill 372 56 -163 391 56 -163 minecraft:water[level=0]
fill 332 56 -164 368 56 -164 minecraft:water[level=0]
setblock 369 56 -164 minecraft:kelp_plant
fill 370 56 -164 371 56 -164 minecraft:water[level=0]
fill 372 56 -164 373 56 -164 minecraft:kelp_plant
fill 374 56 -164 377 56 -164 minecraft:water[level=0]
setblock 378 56 -164 minecraft:kelp_plant
fill 379 56 -164 380 56 -164 minecraft:water[level=0]
setblock 381 56 -164 minecraft:kelp_plant
fill 382 56 -164 391 56 -164 minecraft:water[level=0]
fill 332 56 -165 363 56 -165 minecraft:water[level=0]
setblock 364 56 -165 minecraft:kelp_plant
fill 365 56 -165 375 56 -165 minecraft:water[level=0]
setblock 376 56 -165 minecraft:kelp_plant
fill 377 56 -165 380 56 -165 minecraft:water[level=0]
setblock 381 56 -165 minecraft:kelp_plant
fill 382 56 -165 391 56 -165 minecraft:water[level=0]
fill 332 56 -166 380 56 -166 minecraft:water[level=0]
setblock 381 56 -166 minecraft:kelp_plant
fill 382 56 -166 391 56 -166 minecraft:water[level=0]
fill 332 56 -167 379 56 -167 minecraft:water[level=0]
fill 380 56 -167 381 56 -167 minecraft:kelp_plant
fill 382 56 -167 383 56 -167 minecraft:water[level=0]
setblock 384 56 -167 minecraft:kelp_plant
setblock 385 56 -167 minecraft:water[level=0]
setblock 386 56 -167 minecraft:kelp_plant
fill 387 56 -167 391 56 -167 minecraft:water[level=0]
fill 332 56 -168 367 56 -168 minecraft:water[level=0]
setblock 368 56 -168 minecraft:kelp_plant
fill 369 56 -168 376 56 -168 minecraft:water[level=0]
setblock 377 56 -168 minecraft:kelp_plant
setblock 378 56 -168 minecraft:tall_seagrass[half=upper]
fill 379 56 -168 380 56 -168 minecraft:water[level=0]
fill 381 56 -168 383 56 -168 minecraft:kelp_plant
fill 384 56 -168 391 56 -168 minecraft:water[level=0]
fill 331 56 -169 351 56 -169 minecraft:water[level=0]
setblock 352 56 -169 minecraft:kelp_plant
fill 353 56 -169 375 56 -169 minecraft:water[level=0]
setblock 376 56 -169 minecraft:kelp_plant
fill 377 56 -169 379 56 -169 minecraft:water[level=0]
fill 380 56 -169 381 56 -169 minecraft:kelp_plant
fill 382 56 -169 391 56 -169 minecraft:water[level=0]
fill 331 56 -170 367 56 -170 minecraft:water[level=0]
setblock 368 56 -170 minecraft:kelp_plant
setblock 369 56 -170 minecraft:water[level=0]
setblock 370 56 -170 minecraft:kelp_plant
fill 371 56 -170 374 56 -170 minecraft:water[level=0]
setblock 375 56 -170 minecraft:kelp_plant
setblock 376 56 -170 minecraft:water[level=0]
fill 377 56 -170 378 56 -170 minecraft:kelp_plant
fill 379 56 -170 383 56 -170 minecraft:water[level=0]
setblock 384 56 -170 minecraft:kelp_plant
fill 385 56 -170 390 56 -170 minecraft:water[level=0]
setblock 391 56 -170 minecraft:kelp_plant
fill 330 56 -171 368 56 -171 minecraft:water[level=0]
fill 369 56 -171 370 56 -171 minecraft:kelp_plant
setblock 371 56 -171 minecraft:water[level=0]
setblock 372 56 -171 minecraft:kelp_plant
fill 373 56 -171 374 56 -171 minecraft:water[level=0]
setblock 375 56 -171 minecraft:kelp_plant
fill 376 56 -171 377 56 -171 minecraft:water[level=0]
setblock 378 56 -171 minecraft:tall_seagrass[half=upper]
fill 379 56 -171 383 56 -171 minecraft:water[level=0]
setblock 384 56 -171 minecraft:kelp_plant
fill 385 56 -171 391 56 -171 minecraft:water[level=0]
fill 330 56 -172 356 56 -172 minecraft:water[level=0]
setblock 357 56 -172 minecraft:kelp_plant
fill 358 56 -172 367 56 -172 minecraft:water[level=0]
setblock 368 56 -172 minecraft:kelp_plant
fill 369 56 -172 370 56 -172 minecraft:water[level=0]
setblock 371 56 -172 minecraft:kelp_plant
setblock 372 56 -172 minecraft:water[level=0]
setblock 373 56 -172 minecraft:tall_seagrass[half=upper]
setblock 374 56 -172 minecraft:water[level=0]
setblock 375 56 -172 minecraft:kelp_plant
fill 376 56 -172 379 56 -172 minecraft:water[level=0]
fill 380 56 -172 382 56 -172 minecraft:kelp_plant
setblock 383 56 -172 minecraft:water[level=0]
setblock 384 56 -172 minecraft:kelp_plant
fill 385 56 -172 386 56 -172 minecraft:water[level=0]
setblock 387 56 -172 minecraft:kelp_plant
fill 388 56 -172 391 56 -172 minecraft:water[level=0]
fill 331 56 -173 367 56 -173 minecraft:water[level=0]
setblock 368 56 -173 minecraft:kelp_plant
fill 369 56 -173 370 56 -173 minecraft:water[level=0]
setblock 371 56 -173 minecraft:kelp_plant
fill 372 56 -173 382 56 -173 minecraft:water[level=0]
setblock 383 56 -173 minecraft:kelp_plant
fill 384 56 -173 385 56 -173 minecraft:water[level=0]
setblock 386 56 -173 minecraft:kelp_plant
fill 387 56 -173 391 56 -173 minecraft:water[level=0]
fill 331 56 -174 358 56 -174 minecraft:water[level=0]
setblock 359 56 -174 minecraft:kelp_plant
fill 360 56 -174 366 56 -174 minecraft:water[level=0]
setblock 367 56 -174 minecraft:kelp_plant
setblock 368 56 -174 minecraft:water[level=0]
setblock 369 56 -174 minecraft:kelp_plant
setblock 370 56 -174 minecraft:water[level=0]
setblock 371 56 -174 minecraft:tall_seagrass[half=upper]
fill 372 56 -174 376 56 -174 minecraft:water[level=0]
setblock 377 56 -174 minecraft:kelp_plant
fill 378 56 -174 387 56 -174 minecraft:water[level=0]
fill 388 56 -174 389 56 -174 minecraft:kelp_plant
fill 390 56 -174 391 56 -174 minecraft:water[level=0]
fill 332 56 -175 356 56 -175 minecraft:water[level=0]
setblock 357 56 -175 minecraft:kelp_plant
fill 358 56 -175 366 56 -175 minecraft:water[level=0]
fill 367 56 -175 368 56 -175 minecraft:kelp_plant
fill 369 56 -175 379 56 -175 minecraft:water[level=0]
setblock 380 56 -175 minecraft:kelp_plant
setblock 381 56 -175 minecraft:water[level=0]
setblock 382 56 -175 minecraft:kelp_plant
fill 383 56 -175 384 56 -175 minecraft:water[level=0]
setblock 385 56 -175 minecraft:kelp_plant
setblock 386 56 -175 minecraft:water[level=0]
setblock 387 56 -175 minecraft:kelp_plant
fill 388 56 -175 391 56 -175 minecraft:water[level=0]
fill 332 56 -176 370 56 -176 minecraft:water[level=0]
fill 371 56 -176 372 56 -176 minecraft:kelp_plant
fill 373 56 -176 376 56 -176 minecraft:water[level=0]
setblock 377 56 -176 minecraft:kelp_plant
fill 378 56 -176 380 56 -176 minecraft:water[level=0]
setblock 381 56 -176 minecraft:kelp_plant
fill 382 56 -176 386 56 -176 minecraft:water[level=0]
setblock 387 56 -176 minecraft:kelp_plant
setblock 388 56 -176 minecraft:water[level=0]
setblock 389 56 -176 minecraft:kelp_plant
fill 390 56 -176 391 56 -176 minecraft:water[level=0]
fill 332 56 -177 363 56 -177 minecraft:water[level=0]
fill 364 56 -177 365 56 -177 minecraft:kelp_plant
setblock 366 56 -177 minecraft:water[level=0]
fill 367 56 -177 368 56 -177 minecraft:kelp_plant
fill 369 56 -177 371 56 -177 minecraft:water[level=0]
fill 372 56 -177 373 56 -177 minecraft:kelp_plant
setblock 374 56 -177 minecraft:tall_seagrass[half=upper]
fill 375 56 -177 379 56 -177 minecraft:water[level=0]
setblock 380 56 -177 minecraft:kelp_plant
setblock 381 56 -177 minecraft:water[level=0]
fill 382 56 -177 383 56 -177 minecraft:kelp_plant
fill 384 56 -177 388 56 -177 minecraft:water[level=0]
setblock 389 56 -177 minecraft:kelp_plant
fill 390 56 -177 391 56 -177 minecraft:water[level=0]
fill 332 56 -178 356 56 -178 minecraft:water[level=0]
setblock 357 56 -178 minecraft:kelp_plant
fill 358 56 -178 366 56 -178 minecraft:water[level=0]
fill 367 56 -178 368 56 -178 minecraft:kelp_plant
fill 369 56 -178 372 56 -178 minecraft:water[level=0]
setblock 373 56 -178 minecraft:kelp_plant
setblock 374 56 -178 minecraft:water[level=0]
setblock 375 56 -178 minecraft:tall_seagrass[half=upper]
setblock 376 56 -178 minecraft:water[level=0]
fill 377 56 -178 378 56 -178 minecraft:kelp_plant
fill 379 56 -178 381 56 -178 minecraft:water[level=0]
setblock 382 56 -178 minecraft:kelp_plant
fill 383 56 -178 391 56 -178 minecraft:water[level=0]
fill 332 56 -179 351 56 -179 minecraft:water[level=0]
setblock 352 56 -179 minecraft:kelp_plant
setblock 353 56 -179 minecraft:water[level=0]
setblock 354 56 -179 minecraft:kelp_plant
fill 355 56 -179 366 56 -179 minecraft:water[level=0]
setblock 367 56 -179 minecraft:kelp_plant
fill 368 56 -179 369 56 -179 minecraft:water[level=0]
setblock 370 56 -179 minecraft:kelp_plant
fill 371 56 -179 372 56 -179 minecraft:water[level=0]
setblock 373 56 -179 minecraft:kelp_plant
fill 374 56 -179 378 56 -179 minecraft:water[level=0]
setblock 379 56 -179 minecraft:kelp_plant
fill 380 56 -179 381 56 -179 minecraft:water[level=0]
fill 382 56 -179 383 56 -179 minecraft:kelp_plant
fill 384 56 -179 386 56 -179 minecraft:water[level=0]
setblock 387 56 -179 minecraft:kelp_plant
fill 388 56 -179 391 56 -179 minecraft:water[level=0]
fill 332 56 -180 353 56 -180 minecraft:water[level=0]
fill 354 56 -180 355 56 -180 minecraft:kelp_plant
fill 356 56 -180 359 56 -180 minecraft:water[level=0]
setblock 360 56 -180 minecraft:kelp_plant
fill 361 56 -180 364 56 -180 minecraft:water[level=0]
fill 365 56 -180 366 56 -180 minecraft:tall_seagrass[half=upper]
setblock 367 56 -180 minecraft:kelp_plant
setblock 368 56 -180 minecraft:water[level=0]
setblock 369 56 -180 minecraft:kelp_plant
setblock 370 56 -180 minecraft:water[level=0]
setblock 371 56 -180 minecraft:kelp_plant
setblock 372 56 -180 minecraft:water[level=0]
setblock 373 56 -180 minecraft:tall_seagrass[half=upper]
fill 374 56 -180 376 56 -180 minecraft:water[level=0]
setblock 377 56 -180 minecraft:kelp_plant
fill 378 56 -180 379 56 -180 minecraft:water[level=0]
setblock 380 56 -180 minecraft:kelp_plant
fill 381 56 -180 391 56 -180 minecraft:water[level=0]
fill 332 56 -181 348 56 -181 minecraft:water[level=0]
setblock 349 56 -181 minecraft:kelp_plant
fill 350 56 -181 352 56 -181 minecraft:water[level=0]
setblock 353 56 -181 minecraft:kelp_plant
setblock 354 56 -181 minecraft:water[level=0]
setblock 355 56 -181 minecraft:kelp_plant
setblock 356 56 -181 minecraft:water[level=0]
setblock 357 56 -181 minecraft:kelp_plant
fill 358 56 -181 364 56 -181 minecraft:water[level=0]
setblock 365 56 -181 minecraft:kelp_plant
fill 366 56 -181 367 56 -181 minecraft:water[level=0]
setblock 368 56 -181 minecraft:tall_seagrass[half=upper]
fill 369 56 -181 373 56 -181 minecraft:water[level=0]
setblock 374 56 -181 minecraft:tall_seagrass[half=upper]
setblock 375 56 -181 minecraft:kelp_plant
setblock 376 56 -181 minecraft:water[level=0]
setblock 377 56 -181 minecraft:kelp_plant
setblock 378 56 -181 minecraft:water[level=0]
fill 379 56 -181 380 56 -181 minecraft:kelp_plant
setblock 381 56 -181 minecraft:water[level=0]
setblock 382 56 -181 minecraft:kelp_plant
setblock 383 56 -181 minecraft:water[level=0]
setblock 384 56 -181 minecraft:tall_seagrass[half=lower]
fill 385 56 -181 389 56 -181 minecraft:water[level=0]
setblock 390 56 -181 minecraft:kelp_plant
setblock 391 56 -181 minecraft:water[level=0]
fill 332 56 -182 336 56 -182 minecraft:water[level=0]
setblock 337 56 -182 minecraft:kelp_plant
fill 338 56 -182 352 56 -182 minecraft:water[level=0]
fill 353 56 -182 354 56 -182 minecraft:kelp_plant
setblock 355 56 -182 minecraft:water[level=0]
setblock 356 56 -182 minecraft:kelp_plant
fill 357 56 -182 359 56 -182 minecraft:water[level=0]
fill 360 56 -182 362 56 -182 minecraft:kelp_plant
fill 363 56 -182 365 56 -182 minecraft:water[level=0]
fill 366 56 -182 368 56 -182 minecraft:kelp_plant
setblock 369 56 -182 minecraft:water[level=0]
setblock 370 56 -182 minecraft:kelp_plant
fill 371 56 -182 372 56 -182 minecraft:water[level=0]
setblock 373 56 -182 minecraft:kelp_plant
fill 374 56 -182 376 56 -182 minecraft:water[level=0]
setblock 377 56 -182 minecraft:kelp_plant
fill 378 56 -182 379 56 -182 minecraft:water[level=0]
setblock 380 56 -182 minecraft:kelp_plant
fill 381 56 -182 382 56 -182 minecraft:water[level=0]
setblock 383 56 -182 minecraft:kelp_plant
fill 384 56 -182 386 56 -182 minecraft:water[level=0]
setblock 387 56 -182 minecraft:kelp_plant
fill 388 56 -182 391 56 -182 minecraft:water[level=0]
fill 332 56 -183 346 56 -183 minecraft:water[level=0]
setblock 347 56 -183 minecraft:kelp_plant
fill 348 56 -183 359 56 -183 minecraft:water[level=0]
setblock 360 56 -183 minecraft:kelp_plant
fill 361 56 -183 366 56 -183 minecraft:water[level=0]
setblock 367 56 -183 minecraft:kelp_plant
setblock 368 56 -183 minecraft:tall_seagrass[half=upper]
setblock 369 56 -183 minecraft:kelp_plant
setblock 370 56 -183 minecraft:water[level=0]
setblock 371 56 -183 minecraft:kelp_plant
fill 372 56 -183 377 56 -183 minecraft:water[level=0]
setblock 378 56 -183 minecraft:kelp_plant
fill 379 56 -183 386 56 -183 minecraft:water[level=0]
setblock 387 56 -183 minecraft:kelp_plant
fill 388 56 -183 391 56 -183 minecraft:water[level=0]
fill 332 56 -184 345 56 -184 minecraft:water[level=0]
setblock 346 56 -184 minecraft:kelp_plant
fill 347 56 -184 348 56 -184 minecraft:water[level=0]
setblock 349 56 -184 minecraft:kelp_plant
fill 350 56 -184 359 56 -184 minecraft:water[level=0]
fill 360 56 -184 361 56 -184 minecraft:kelp_plant
fill 362 56 -184 363 56 -184 minecraft:tall_seagrass[half=upper]
fill 364 56 -184 369 56 -184 minecraft:water[level=0]
setblock 370 56 -184 minecraft:kelp_plant
fill 371 56 -184 375 56 -184 minecraft:water[level=0]
setblock 376 56 -184 minecraft:kelp_plant
fill 377 56 -184 379 56 -184 minecraft:water[level=0]
setblock 380 56 -184 minecraft:kelp_plant
setblock 381 56 -184 minecraft:tall_seagrass[half=upper]
setblock 382 56 -184 minecraft:water[level=0]
setblock 383 56 -184 minecraft:tall_seagrass[half=upper]
fill 384 56 -184 386 56 -184 minecraft:water[level=0]
fill 387 56 -184 389 56 -184 minecraft:kelp_plant
fill 390 56 -184 391 56 -184 minecraft:water[level=0]
fill 332 56 -185 356 56 -185 minecraft:water[level=0]
setblock 357 56 -185 minecraft:kelp_plant
fill 358 56 -185 363 56 -185 minecraft:water[level=0]
setblock 364 56 -185 minecraft:kelp_plant
setblock 365 56 -185 minecraft:water[level=0]
setblock 366 56 -185 minecraft:tall_seagrass[half=upper]
setblock 367 56 -185 minecraft:water[level=0]
setblock 368 56 -185 minecraft:tall_seagrass[half=upper]
fill 369 56 -185 370 56 -185 minecraft:water[level=0]
setblock 371 56 -185 minecraft:kelp_plant
fill 372 56 -185 373 56 -185 minecraft:water[level=0]
setblock 374 56 -185 minecraft:kelp_plant
fill 375 56 -185 379 56 -185 minecraft:water[level=0]
setblock 380 56 -185 minecraft:kelp_plant
setblock 381 56 -185 minecraft:water[level=0]
setblock 382 56 -185 minecraft:kelp_plant
setblock 383 56 -185 minecraft:water[level=0]
setblock 384 56 -185 minecraft:kelp_plant
fill 385 56 -185 391 56 -185 minecraft:water[level=0]
fill 332 56 -186 341 56 -186 minecraft:water[level=0]
setblock 342 56 -186 minecraft:kelp_plant
fill 343 56 -186 359 56 -186 minecraft:water[level=0]
setblock 360 56 -186 minecraft:kelp_plant
setblock 361 56 -186 minecraft:water[level=0]
setblock 362 56 -186 minecraft:tall_seagrass[half=upper]
fill 363 56 -186 366 56 -186 minecraft:water[level=0]
setblock 367 56 -186 minecraft:tall_seagrass[half=upper]
setblock 368 56 -186 minecraft:water[level=0]
setblock 369 56 -186 minecraft:kelp_plant
fill 370 56 -186 375 56 -186 minecraft:water[level=0]
setblock 376 56 -186 minecraft:tall_seagrass[half=upper]
fill 377 56 -186 379 56 -186 minecraft:kelp_plant
fill 380 56 -186 390 56 -186 minecraft:water[level=0]
setblock 391 56 -186 minecraft:kelp_plant
fill 332 56 -187 353 56 -187 minecraft:water[level=0]
setblock 354 56 -187 minecraft:kelp_plant
fill 355 56 -187 356 56 -187 minecraft:water[level=0]
fill 357 56 -187 358 56 -187 minecraft:kelp_plant
fill 359 56 -187 362 56 -187 minecraft:water[level=0]
setblock 363 56 -187 minecraft:tall_seagrass[half=upper]
setblock 364 56 -187 minecraft:water[level=0]
fill 365 56 -187 366 56 -187 minecraft:kelp_plant
fill 367 56 -187 368 56 -187 minecraft:water[level=0]
setblock 369 56 -187 minecraft:tall_seagrass[half=upper]
setblock 370 56 -187 minecraft:kelp_plant
fill 371 56 -187 373 56 -187 minecraft:water[level=0]
setblock 374 56 -187 minecraft:kelp_plant
setblock 375 56 -187 minecraft:tall_seagrass[half=upper]
fill 376 56 -187 379 56 -187 minecraft:water[level=0]
fill 380 56 -187 381 56 -187 minecraft:kelp_plant
fill 382 56 -187 387 56 -187 minecraft:water[level=0]
setblock 388 56 -187 minecraft:kelp_plant
fill 389 56 -187 390 56 -187 minecraft:water[level=0]
setblock 391 56 -187 minecraft:kelp_plant
fill 332 56 -188 352 56 -188 minecraft:water[level=0]
setblock 353 56 -188 minecraft:kelp_plant
setblock 354 56 -188 minecraft:water[level=0]
fill 355 56 -188 356 56 -188 minecraft:kelp_plant
fill 357 56 -188 362 56 -188 minecraft:water[level=0]
fill 363 56 -188 365 56 -188 minecraft:kelp_plant
setblock 366 56 -188 minecraft:water[level=0]
setblock 367 56 -188 minecraft:kelp_plant
setblock 368 56 -188 minecraft:water[level=0]
setblock 369 56 -188 minecraft:kelp_plant
setblock 370 56 -188 minecraft:water[level=0]
fill 371 56 -188 374 56 -188 minecraft:kelp_plant
fill 375 56 -188 376 56 -188 minecraft:water[level=0]
fill 377 56 -188 378 56 -188 minecraft:kelp_plant
fill 379 56 -188 380 56 -188 minecraft:water[level=0]
setblock 381 56 -188 minecraft:kelp_plant
setblock 382 56 -188 minecraft:water[level=0]
fill 383 56 -188 384 56 -188 minecraft:kelp_plant
fill 385 56 -188 391 56 -188 minecraft:water[level=0]
fill 332 56 -189 351 56 -189 minecraft:water[level=0]
setblock 352 56 -189 minecraft:kelp_plant
fill 353 56 -189 356 56 -189 minecraft:water[level=0]
setblock 357 56 -189 minecraft:kelp_plant
fill 358 56 -189 363 56 -189 minecraft:water[level=0]
fill 364 56 -189 365 56 -189 minecraft:kelp_plant
fill 366 56 -189 368 56 -189 minecraft:water[level=0]
setblock 369 56 -189 minecraft:kelp_plant
fill 370 56 -189 375 56 -189 minecraft:water[level=0]
setblock 376 56 -189 minecraft:kelp_plant
setblock 377 56 -189 minecraft:water[level=0]
setblock 378 56 -189 minecraft:tall_seagrass[half=upper]
fill 379 56 -189 381 56 -189 minecraft:water[level=0]
fill 382 56 -189 383 56 -189 minecraft:kelp_plant
fill 384 56 -189 391 56 -189 minecraft:water[level=0]
fill 332 56 -190 357 56 -190 minecraft:water[level=0]
setblock 358 56 -190 minecraft:kelp_plant
fill 359 56 -190 361 56 -190 minecraft:water[level=0]
setblock 362 56 -190 minecraft:kelp_plant
fill 363 56 -190 364 56 -190 minecraft:water[level=0]
fill 365 56 -190 370 56 -190 minecraft:kelp_plant
fill 371 56 -190 375 56 -190 minecraft:water[level=0]
setblock 376 56 -190 minecraft:kelp_plant
fill 377 56 -190 380 56 -190 minecraft:water[level=0]
fill 381 56 -190 382 56 -190 minecraft:kelp_plant
fill 383 56 -190 386 56 -190 minecraft:water[level=0]
fill 387 56 -190 388 56 -190 minecraft:kelp_plant
fill 389 56 -190 391 56 -190 minecraft:water[level=0]
fill 328 55 -127 330 55 -127 minecraft:water[level=0]
setblock 331 55 -127 minecraft:tall_seagrass[half=lower]
setblock 333 55 -127 minecraft:seagrass
setblock 334 55 -127 minecraft:tall_seagrass[half=lower]
fill 335 55 -127 337 55 -127 minecraft:seagrass
fill 338 55 -127 340 55 -127 minecraft:water[level=0]
setblock 341 55 -127 minecraft:kelp_plant
setblock 342 55 -127 minecraft:seagrass
setblock 343 55 -127 minecraft:water[level=0]
setblock 344 55 -127 minecraft:tall_seagrass[half=lower]
fill 345 55 -127 346 55 -127 minecraft:water[level=0]
fill 347 55 -127 349 55 -127 minecraft:kelp_plant
fill 350 55 -127 353 55 -127 minecraft:water[level=0]
setblock 354 55 -127 minecraft:kelp_plant
fill 355 55 -127 360 55 -127 minecraft:water[level=0]
setblock 361 55 -127 minecraft:kelp_plant
fill 362 55 -127 368 55 -127 minecraft:water[level=0]
setblock 369 55 -127 minecraft:kelp_plant
fill 370 55 -127 372 55 -127 minecraft:water[level=0]
setblock 373 55 -127 minecraft:kelp_plant
fill 374 55 -127 383 55 -127 minecraft:water[level=0]
fill 384 55 -127 385 55 -127 minecraft:kelp_plant
fill 386 55 -127 390 55 -127 minecraft:water[level=0]
setblock 391 55 -127 minecraft:kelp_plant
fill 328 55 -128 329 55 -128 minecraft:water[level=0]
setblock 330 55 -128 minecraft:seagrass
setblock 337 55 -128 minecraft:water[level=0]
fill 344 55 -128 345 55 -128 minecraft:water[level=0]
setblock 346 55 -128 minecraft:kelp_plant
fill 347 55 -128 354 55 -128 minecraft:water[level=0]
setblock 355 55 -128 minecraft:kelp_plant
setblock 356 55 -128 minecraft:water[level=0]
setblock 357 55 -128 minecraft:kelp_plant
fill 358 55 -128 359 55 -128 minecraft:water[level=0]
setblock 360 55 -128 minecraft:kelp_plant
fill 361 55 -128 366 55 -128 minecraft:water[level=0]
setblock 367 55 -128 minecraft:kelp_plant
fill 368 55 -128 369 55 -128 minecraft:water[level=0]
setblock 370 55 -128 minecraft:kelp_plant
setblock 371 55 -128 minecraft:water[level=0]
fill 372 55 -128 373 55 -128 minecraft:kelp_plant
setblock 374 55 -128 minecraft:water[level=0]
fill 375 55 -128 376 55 -128 minecraft:kelp_plant
setblock 377 55 -128 minecraft:water[level=0]
fill 378 55 -128 380 55 -128 minecraft:kelp_plant
fill 381 55 -128 386 55 -128 minecraft:water[level=0]
setblock 387 55 -128 minecraft:kelp_plant
fill 388 55 -128 391 55 -128 minecraft:water[level=0]
fill 328 55 -129 331 55 -129 minecraft:water[level=0]
fill 332 55 -129 333 55 -129 minecraft:seagrass
setblock 334 55 -129 minecraft:water[level=0]
setblock 335 55 -129 minecraft:tall_seagrass[half=lower]
setblock 336 55 -129 minecraft:water[level=0]
setblock 341 55 -129 minecraft:water[level=0]
setblock 342 55 -129 minecraft:kelp_plant
fill 343 55 -129 348 55 -129 minecraft:water[level=0]
setblock 349 55 -129 minecraft:kelp_plant
fill 350 55 -129 351 55 -129 minecraft:water[level=0]
setblock 352 55 -129 minecraft:tall_seagrass[half=upper]
fill 353 55 -129 358 55 -129 minecraft:water[level=0]
setblock 359 55 -129 minecraft:kelp_plant
fill 360 55 -129 368 55 -129 minecraft:water[level=0]
setblock 369 55 -129 minecraft:kelp_plant
fill 370 55 -129 376 55 -129 minecraft:water[level=0]
setblock 377 55 -129 minecraft:kelp_plant
fill 378 55 -129 384 55 -129 minecraft:water[level=0]
setblock 385 55 -129 minecraft:kelp[age=25]
setblock 386 55 -129 minecraft:water[level=0]
setblock 387 55 -129 minecraft:kelp_plant
fill 388 55 -129 389 55 -129 minecraft:water[level=0]
setblock 390 55 -129 minecraft:kelp_plant
setblock 391 55 -129 minecraft:water[level=0]
fill 328 55 -130 329 55 -130 minecraft:water[level=0]
setblock 330 55 -130 minecraft:tall_seagrass[half=upper]
fill 331 55 -130 333 55 -130 minecraft:water[level=0]
setblock 334 55 -130 minecraft:kelp_plant
fill 335 55 -130 340 55 -130 minecraft:water[level=0]
setblock 341 55 -130 minecraft:seagrass
setblock 342 55 -130 minecraft:water[level=0]
setblock 343 55 -130 minecraft:kelp_plant
fill 344 55 -130 350 55 -130 minecraft:water[level=0]
setblock 351 55 -130 minecraft:kelp_plant
fill 352 55 -130 353 55 -130 minecraft:water[level=0]
setblock 354 55 -130 minecraft:tall_seagrass[half=upper]
fill 355 55 -130 362 55 -130 minecraft:water[level=0]
setblock 363 55 -130 minecraft:kelp_plant
fill 364 55 -130 365 55 -130 minecraft:water[level=0]
setblock 366 55 -130 minecraft:kelp_plant
fill 367 55 -130 368 55 -130 minecraft:water[level=0]
setblock 369 55 -130 minecraft:kelp_plant
fill 370 55 -130 391 55 -130 minecraft:water[level=0]
setblock 328 55 -131 minecraft:kelp_plant
fill 329 55 -131 337 55 -131 minecraft:water[level=0]
setblock 338 55 -131 minecraft:tall_seagrass[half=lower]
setblock 339 55 -131 minecraft:seagrass
fill 340 55 -131 355 55 -131 minecraft:water[level=0]
setblock 356 55 -131 minecraft:tall_seagrass[half=upper]
fill 357 55 -131 367 55 -131 minecraft:water[level=0]
setblock 368 55 -131 minecraft:kelp_plant
fill 369 55 -131 391 55 -131 minecraft:water[level=0]
fill 328 55 -132 362 55 -132 minecraft:water[level=0]
setblock 363 55 -132 minecraft:kelp_plant
fill 364 55 -132 377 55 -132 minecraft:water[level=0]
setblock 378 55 -132 minecraft:kelp_plant
fill 379 55 -132 382 55 -132 minecraft:water[level=0]
setblock 383 55 -132 minecraft:kelp_plant
setblock 384 55 -132 minecraft:water[level=0]
setblock 385 55 -132 minecraft:kelp_plant
setblock 386 55 -132 minecraft:water[level=0]
fill 387 55 -132 388 55 -132 minecraft:kelp_plant
fill 389 55 -132 391 55 -132 minecraft:water[level=0]
fill 328 55 -133 348 55 -133 minecraft:water[level=0]
setblock 349 55 -133 minecraft:kelp_plant
fill 350 55 -133 351 55 -133 minecraft:water[level=0]
setblock 352 55 -133 minecraft:kelp_plant
setblock 353 55 -133 minecraft:tall_seagrass[half=upper]
fill 354 55 -133 356 55 -133 minecraft:water[level=0]
setblock 357 55 -133 minecraft:kelp_plant
setblock 358 55 -133 minecraft:tall_seagrass[half=upper]
fill 359 55 -133 381 55 -133 minecraft:water[level=0]
setblock 382 55 -133 minecraft:kelp_plant
fill 383 55 -133 387 55 -133 minecraft:water[level=0]
setblock 388 55 -133 minecraft:kelp_plant
fill 389 55 -133 391 55 -133 minecraft:water[level=0]
fill 328 55 -134 336 55 -134 minecraft:water[level=0]
setblock 337 55 -134 minecraft:kelp_plant
fill 338 55 -134 340 55 -134 minecraft:water[level=0]
setblock 341 55 -134 minecraft:tall_seagrass[half=upper]
fill 342 55 -134 345 55 -134 minecraft:water[level=0]
setblock 346 55 -134 minecraft:tall_seagrass[half=upper]
fill 347 55 -134 367 55 -134 minecraft:water[level=0]
setblock 368 55 -134 minecraft:kelp[age=25]
setblock 369 55 -134 minecraft:kelp_plant
fill 370 55 -134 371 55 -134 minecraft:water[level=0]
setblock 372 55 -134 minecraft:kelp_plant
fill 373 55 -134 376 55 -134 minecraft:water[level=0]
setblock 377 55 -134 minecraft:kelp[age=25]
fill 378 55 -134 383 55 -134 minecraft:water[level=0]
fill 384 55 -134 385 55 -134 minecraft:kelp_plant
fill 386 55 -134 391 55 -134 minecraft:water[level=0]
fill 328 55 -135 331 55 -135 minecraft:water[level=0]
setblock 332 55 -135 minecraft:kelp_plant
fill 333 55 -135 336 55 -135 minecraft:water[level=0]
setblock 337 55 -135 minecraft:kelp_plant
fill 338 55 -135 347 55 -135 minecraft:water[level=0]
fill 348 55 -135 350 55 -135 minecraft:kelp_plant
setblock 351 55 -135 minecraft:tall_seagrass[half=lower]
fill 352 55 -135 353 55 -135 minecraft:water[level=0]
setblock 354 55 -135 minecraft:seagrass
fill 355 55 -135 376 55 -135 minecraft:water[level=0]
setblock 377 55 -135 minecraft:kelp_plant
fill 378 55 -135 379 55 -135 minecraft:water[level=0]
setblock 380 55 -135 minecraft:kelp_plant
fill 381 55 -135 384 55 -135 minecraft:water[level=0]
setblock 385 55 -135 minecraft:kelp_plant
fill 386 55 -135 391 55 -135 minecraft:water[level=0]
fill 328 55 -136 342 55 -136 minecraft:water[level=0]
setblock 343 55 -136 minecraft:kelp_plant
fill 344 55 -136 345 55 -136 minecraft:water[level=0]
setblock 346 55 -136 minecraft:kelp_plant
fill 347 55 -136 348 55 -136 minecraft:water[level=0]
setblock 349 55 -136 minecraft:kelp_plant
setblock 350 55 -136 minecraft:water[level=0]
setblock 351 55 -136 minecraft:seagrass
fill 352 55 -136 353 55 -136 minecraft:water[level=0]
fill 354 55 -136 355 55 -136 minecraft:seagrass
setblock 356 55 -136 minecraft:water[level=0]
setblock 357 55 -136 minecraft:tall_seagrass[half=upper]
fill 358 55 -136 361 55 -136 minecraft:water[level=0]
setblock 362 55 -136 minecraft:kelp_plant
fill 363 55 -136 364 55 -136 minecraft:water[level=0]
setblock 365 55 -136 minecraft:kelp_plant
fill 366 55 -136 374 55 -136 minecraft:water[level=0]
setblock 375 55 -136 minecraft:kelp_plant
fill 376 55 -136 377 55 -136 minecraft:water[level=0]
setblock 378 55 -136 minecraft:kelp_plant
fill 379 55 -136 381 55 -136 minecraft:water[level=0]
setblock 382 55 -136 minecraft:kelp_plant
fill 383 55 -136 384 55 -136 minecraft:water[level=0]
setblock 385 55 -136 minecraft:kelp_plant
fill 386 55 -136 387 55 -136 minecraft:water[level=0]
fill 388 55 -136 389 55 -136 minecraft:kelp_plant
fill 390 55 -136 391 55 -136 minecraft:water[level=0]
setblock 328 55 -137 minecraft:kelp_plant
fill 329 55 -137 330 55 -137 minecraft:water[level=0]
setblock 331 55 -137 minecraft:kelp_plant
fill 332 55 -137 350 55 -137 minecraft:water[level=0]
setblock 351 55 -137 minecraft:seagrass
setblock 352 55 -137 minecraft:water[level=0]
setblock 353 55 -137 minecraft:seagrass
setblock 354 55 -137 minecraft:water[level=0]
fill 355 55 -137 356 55 -137 minecraft:seagrass
fill 357 55 -137 367 55 -137 minecraft:water[level=0]
setblock 368 55 -137 minecraft:kelp_plant
fill 369 55 -137 381 55 -137 minecraft:water[level=0]
setblock 382 55 -137 minecraft:kelp_plant
fill 383 55 -137 384 55 -137 minecraft:water[level=0]
setblock 385 55 -137 minecraft:kelp_plant
fill 386 55 -137 391 55 -137 minecraft:water[level=0]
fill 328 55 -138 341 55 -138 minecraft:water[level=0]
setblock 342 55 -138 minecraft:tall_seagrass[half=upper]
fill 343 55 -138 351 55 -138 minecraft:water[level=0]
setblock 352 55 -138 minecraft:tall_seagrass[half=lower]
fill 353 55 -138 354 55 -138 minecraft:water[level=0]
setblock 355 55 -138 minecraft:seagrass
fill 356 55 -138 366 55 -138 minecraft:water[level=0]
setblock 367 55 -138 minecraft:kelp_plant
fill 368 55 -138 384 55 -138 minecraft:water[level=0]
setblock 385 55 -138 minecraft:kelp_plant
setblock 386 55 -138 minecraft:kelp[age=25]
fill 387 55 -138 388 55 -138 minecraft:water[level=0]
setblock 389 55 -138 minecraft:kelp_plant
fill 390 55 -138 391 55 -138 minecraft:water[level=0]
fill 328 55 -139 339 55 -139 minecraft:water[level=0]
setblock 340 55 -139 minecraft:tall_seagrass[half=upper]
fill 341 55 -139 344 55 -139 minecraft:water[level=0]
setblock 345 55 -139 minecraft:tall_seagrass[half=upper]
fill 346 55 -139 352 55 -139 minecraft:water[level=0]
setblock 353 55 -139 minecraft:tall_seagrass[half=lower]
fill 354 55 -139 359 55 -139 minecraft:water[level=0]
setblock 360 55 -139 minecraft:kelp_plant
fill 361 55 -139 371 55 -139 minecraft:water[level=0]
setblock 372 55 -139 minecraft:kelp_plant
fill 373 55 -139 383 55 -139 minecraft:water[level=0]
setblock 384 55 -139 minecraft:kelp_plant
fill 385 55 -139 391 55 -139 minecraft:water[level=0]
fill 328 55 -140 333 55 -140 minecraft:water[level=0]
setblock 334 55 -140 minecraft:tall_seagrass[half=upper]
fill 335 55 -140 336 55 -140 minecraft:water[level=0]
setblock 337 55 -140 minecraft:tall_seagrass[half=upper]
fill 338 55 -140 343 55 -140 minecraft:water[level=0]
setblock 344 55 -140 minecraft:kelp_plant
fill 345 55 -140 354 55 -140 minecraft:water[level=0]
setblock 355 55 -140 minecraft:kelp_plant
fill 356 55 -140 368 55 -140 minecraft:water[level=0]
setblock 369 55 -140 minecraft:kelp_plant
setblock 370 55 -140 minecraft:water[level=0]
setblock 371 55 -140 minecraft:kelp_plant
fill 372 55 -140 377 55 -140 minecraft:water[level=0]
setblock 378 55 -140 minecraft:kelp_plant
fill 379 55 -140 380 55 -140 minecraft:water[level=0]
setblock 381 55 -140 minecraft:kelp_plant
fill 382 55 -140 391 55 -140 minecraft:water[level=0]
fill 328 55 -141 355 55 -141 minecraft:water[level=0]
setblock 356 55 -141 minecraft:kelp_plant
fill 357 55 -141 368 55 -141 minecraft:water[level=0]
setblock 369 55 -141 minecraft:kelp_plant
fill 370 55 -141 378 55 -141 minecraft:water[level=0]
setblock 379 55 -141 minecraft:kelp_plant
fill 380 55 -141 382 55 -141 minecraft:water[level=0]
setblock 383 55 -141 minecraft:kelp_plant
fill 384 55 -141 387 55 -141 minecraft:water[level=0]
fill 388 55 -141 389 55 -141 minecraft:kelp_plant
fill 390 55 -141 391 55 -141 minecraft:water[level=0]
fill 328 55 -142 339 55 -142 minecraft:water[level=0]
setblock 340 55 -142 minecraft:tall_seagrass[half=upper]
fill 341 55 -142 352 55 -142 minecraft:water[level=0]
setblock 353 55 -142 minecraft:kelp_plant
fill 354 55 -142 367 55 -142 minecraft:water[level=0]
fill 368 55 -142 369 55 -142 minecraft:kelp_plant
setblock 370 55 -142 minecraft:water[level=0]
fill 371 55 -142 372 55 -142 minecraft:kelp_plant
fill 373 55 -142 391 55 -142 minecraft:water[level=0]
fill 328 55 -143 331 55 -143 minecraft:water[level=0]
setblock 332 55 -143 minecraft:kelp_plant
fill 333 55 -143 337 55 -143 minecraft:water[level=0]
setblock 338 55 -143 minecraft:kelp_plant
fill 339 55 -143 341 55 -143 minecraft:water[level=0]
setblock 342 55 -143 minecraft:kelp_plant
setblock 343 55 -143 minecraft:water[level=0]
setblock 344 55 -143 minecraft:tall_seagrass[half=upper]
fill 345 55 -143 377 55 -143 minecraft:water[level=0]
fill 378 55 -143 379 55 -143 minecraft:kelp_plant
fill 380 55 -143 382 55 -143 minecraft:water[level=0]
setblock 383 55 -143 minecraft:kelp_plant
fill 384 55 -143 385 55 -143 minecraft:water[level=0]
setblock 386 55 -143 minecraft:kelp_plant
fill 387 55 -143 391 55 -143 minecraft:water[level=0]
fill 328 55 -144 344 55 -144 minecraft:water[level=0]
setblock 345 55 -144 minecraft:seagrass
setblock 346 55 -144 minecraft:tall_seagrass[half=lower]
fill 347 55 -144 351 55 -144 minecraft:water[level=0]
setblock 352 55 -144 minecraft:kelp_plant
fill 353 55 -144 354 55 -144 minecraft:water[level=0]
setblock 355 55 -144 minecraft:seagrass
fill 356 55 -144 370 55 -144 minecraft:water[level=0]
setblock 371 55 -144 minecraft:kelp_plant
fill 372 55 -144 391 55 -144 minecraft:water[level=0]
fill 328 55 -145 343 55 -145 minecraft:water[level=0]
setblock 344 55 -145 minecraft:tall_seagrass[half=lower]
fill 345 55 -145 368 55 -145 minecraft:water[level=0]
fill 369 55 -145 370 55 -145 minecraft:kelp_plant
fill 371 55 -145 383 55 -145 minecraft:water[level=0]
setblock 384 55 -145 minecraft:kelp_plant
setblock 385 55 -145 minecraft:water[level=0]
setblock 386 55 -145 minecraft:kelp_plant
fill 387 55 -145 388 55 -145 minecraft:water[level=0]
setblock 389 55 -145 minecraft:kelp_plant
fill 390 55 -145 391 55 -145 minecraft:water[level=0]
fill 328 55 -146 352 55 -146 minecraft:water[level=0]
setblock 353 55 -146 minecraft:seagrass
fill 354 55 -146 360 55 -146 minecraft:water[level=0]
setblock 361 55 -146 minecraft:tall_seagrass[half=upper]
fill 362 55 -146 367 55 -146 minecraft:water[level=0]
setblock 368 55 -146 minecraft:kelp_plant
fill 369 55 -146 371 55 -146 minecraft:water[level=0]
setblock 372 55 -146 minecraft:kelp_plant
fill 373 55 -146 391 55 -146 minecraft:water[level=0]
fill 328 55 -147 340 55 -147 minecraft:water[level=0]
setblock 341 55 -147 minecraft:tall_seagrass[half=upper]
fill 342 55 -147 352 55 -147 minecraft:water[level=0]
setblock 353 55 -147 minecraft:tall_seagrass[half=lower]
fill 354 55 -147 361 55 -147 minecraft:water[level=0]
setblock 362 55 -147 minecraft:tall_seagrass[half=upper]
fill 363 55 -147 368 55 -147 minecraft:water[level=0]
setblock 369 55 -147 minecraft:kelp_plant
fill 370 55 -147 373 55 -147 minecraft:water[level=0]
fill 374 55 -147 375 55 -147 minecraft:kelp_plant
fill 376 55 -147 385 55 -147 minecraft:water[level=0]
setblock 386 55 -147 minecraft:kelp_plant
fill 387 55 -147 391 55 -147 minecraft:water[level=0]
fill 328 55 -148 357 55 -148 minecraft:water[level=0]
setblock 358 55 -148 minecraft:tall_seagrass[half=upper]
fill 359 55 -148 360 55 -148 minecraft:water[level=0]
setblock 361 55 -148 minecraft:tall_seagrass[half=upper]
fill 362 55 -148 374 55 -148 minecraft:water[level=0]
setblock 375 55 -148 minecraft:kelp_plant
fill 376 55 -148 377 55 -148 minecraft:water[level=0]
setblock 378 55 -148 minecraft:kelp_plant
fill 379 55 -148 386 55 -148 minecraft:water[level=0]
setblock 387 55 -148 minecraft:kelp_plant
setblock 388 55 -148 minecraft:water[level=0]
setblock 389 55 -148 minecraft:kelp_plant
fill 390 55 -148 391 55 -148 minecraft:water[level=0]
fill 328 55 -149 344 55 -149 minecraft:water[level=0]
fill 345 55 -149 346 55 -149 minecraft:tall_seagrass[half=upper]
fill 347 55 -149 368 55 -149 minecraft:water[level=0]
fill 369 55 -149 370 55 -149 minecraft:kelp_plant
fill 371 55 -149 377 55 -149 minecraft:water[level=0]
setblock 378 55 -149 minecraft:kelp_plant
fill 379 55 -149 390 55 -149 minecraft:water[level=0]
setblock 391 55 -149 minecraft:kelp_plant
fill 328 55 -150 334 55 -150 minecraft:water[level=0]
setblock 335 55 -150 minecraft:tall_seagrass[half=upper]
fill 336 55 -150 338 55 -150 minecraft:water[level=0]
setblock 339 55 -150 minecraft:tall_seagrass[half=upper]
fill 340 55 -150 346 55 -150 minecraft:water[level=0]
setblock 347 55 -150 minecraft:tall_seagrass[half=lower]
fill 348 55 -150 356 55 -150 minecraft:water[level=0]
setblock 357 55 -150 minecraft:tall_seagrass[half=upper]
fill 358 55 -150 361 55 -150 minecraft:water[level=0]
setblock 362 55 -150 minecraft:tall_seagrass[half=upper]
fill 363 55 -150 369 55 -150 minecraft:water[level=0]
fill 370 55 -150 371 55 -150 minecraft:kelp_plant
fill 372 55 -150 380 55 -150 minecraft:water[level=0]
fill 381 55 -150 382 55 -150 minecraft:tall_seagrass[half=upper]
fill 383 55 -150 391 55 -150 minecraft:water[level=0]
fill 328 55 -151 379 55 -151 minecraft:water[level=0]
setblock 380 55 -151 minecraft:tall_seagrass[half=upper]
setblock 381 55 -151 minecraft:water[level=0]
setblock 382 55 -151 minecraft:kelp_plant
fill 383 55 -151 385 55 -151 minecraft:water[level=0]
setblock 386 55 -151 minecraft:kelp_plant
fill 387 55 -151 391 55 -151 minecraft:water[level=0]
fill 328 55 -152 367 55 -152 minecraft:water[level=0]
fill 368 55 -152 369 55 -152 minecraft:kelp_plant
setblock 370 55 -152 minecraft:water[level=0]
setblock 371 55 -152 minecraft:kelp_plant
fill 372 55 -152 376 55 -152 minecraft:water[level=0]
setblock 377 55 -152 minecraft:kelp_plant
setblock 378 55 -152 minecraft:tall_seagrass[half=upper]
fill 379 55 -152 381 55 -152 minecraft:water[level=0]
setblock 382 55 -152 minecraft:tall_seagrass[half=upper]
fill 383 55 -152 385 55 -152 minecraft:water[level=0]
setblock 386 55 -152 minecraft:kelp_plant
fill 387 55 -152 390 55 -152 minecraft:water[level=0]
setblock 391 55 -152 minecraft:kelp_plant
fill 328 55 -153 340 55 -153 minecraft:water[level=0]
setblock 341 55 -153 minecraft:tall_seagrass[half=upper]
fill 342 55 -153 346 55 -153 minecraft:water[level=0]
setblock 347 55 -153 minecraft:seagrass
fill 348 55 -153 359 55 -153 minecraft:water[level=0]
fill 360 55 -153 361 55 -153 minecraft:tall_seagrass[half=upper]
fill 362 55 -153 363 55 -153 minecraft:water[level=0]
setblock 364 55 -153 minecraft:tall_seagrass[half=upper]
fill 365 55 -153 369 55 -153 minecraft:water[level=0]
setblock 370 55 -153 minecraft:kelp_plant
setblock 371 55 -153 minecraft:water[level=0]
setblock 372 55 -153 minecraft:kelp_plant
fill 373 55 -153 380 55 -153 minecraft:water[level=0]
fill 381 55 -153 382 55 -153 minecraft:kelp_plant
setblock 383 55 -153 minecraft:water[level=0]
fill 384 55 -153 386 55 -153 minecraft:kelp_plant
fill 387 55 -153 389 55 -153 minecraft:water[level=0]
setblock 390 55 -153 minecraft:kelp_plant
setblock 391 55 -153 minecraft:water[level=0]
fill 328 55 -154 362 55 -154 minecraft:water[level=0]
setblock 363 55 -154 minecraft:tall_seagrass[half=upper]
fill 364 55 -154 372 55 -154 minecraft:water[level=0]
setblock 373 55 -154 minecraft:kelp_plant
fill 374 55 -154 375 55 -154 minecraft:water[level=0]
setblock 376 55 -154 minecraft:kelp_plant
fill 377 55 -154 379 55 -154 minecraft:water[level=0]
fill 382 55 -154 391 55 -154 minecraft:water[level=0]
fill 328 55 -155 339 55 -155 minecraft:water[level=0]
setblock 340 55 -155 minecraft:tall_seagrass[half=upper]
fill 341 55 -155 358 55 -155 minecraft:water[level=0]
setblock 359 55 -155 minecraft:tall_seagrass[half=upper]
fill 360 55 -155 376 55 -155 minecraft:water[level=0]
fill 377 55 -155 379 55 -155 minecraft:kelp_plant
setblock 380 55 -155 minecraft:water[level=0]
setblock 381 55 -155 minecraft:kelp_plant
fill 382 55 -155 391 55 -155 minecraft:water[level=0]
fill 328 55 -156 368 55 -156 minecraft:water[level=0]
setblock 369 55 -156 minecraft:kelp_plant
fill 370 55 -156 372 55 -156 minecraft:water[level=0]
setblock 373 55 -156 minecraft:kelp_plant
fill 374 55 -156 378 55 -156 minecraft:water[level=0]
setblock 381 55 -156 minecraft:water[level=0]
fill 382 55 -156 383 55 -156 minecraft:kelp_plant
fill 384 55 -156 391 55 -156 minecraft:water[level=0]
fill 331 55 -157 368 55 -157 minecraft:water[level=0]
setblock 369 55 -157 minecraft:kelp_plant
fill 370 55 -157 376 55 -157 minecraft:water[level=0]
setblock 377 55 -157 minecraft:kelp_plant
fill 378 55 -157 380 55 -157 minecraft:water[level=0]
setblock 381 55 -157 minecraft:kelp_plant
fill 382 55 -157 390 55 -157 minecraft:water[level=0]
setblock 391 55 -157 minecraft:kelp_plant
fill 332 55 -158 356 55 -158 minecraft:water[level=0]
setblock 357 55 -158 minecraft:tall_seagrass[half=upper]
setblock 358 55 -158 minecraft:water[level=0]
setblock 359 55 -158 minecraft:tall_seagrass[half=upper]
fill 360 55 -158 379 55 -158 minecraft:water[level=0]
setblock 380 55 -158 minecraft:kelp_plant
fill 381 55 -158 391 55 -158 minecraft:water[level=0]
fill 332 55 -159 369 55 -159 minecraft:water[level=0]
fill 370 55 -159 371 55 -159 minecraft:kelp_plant
fill 372 55 -159 374 55 -159 minecraft:water[level=0]
setblock 375 55 -159 minecraft:kelp_plant
fill 376 55 -159 386 55 -159 minecraft:water[level=0]
setblock 387 55 -159 minecraft:kelp_plant
fill 388 55 -159 391 55 -159 minecraft:water[level=0]
fill 332 55 -160 369 55 -160 minecraft:water[level=0]
fill 370 55 -160 371 55 -160 minecraft:kelp_plant
fill 372 55 -160 375 55 -160 minecraft:water[level=0]
setblock 376 55 -160 minecraft:kelp_plant
fill 377 55 -160 389 55 -160 minecraft:water[level=0]
setblock 390 55 -160 minecraft:kelp_plant
setblock 391 55 -160 minecraft:water[level=0]
fill 332 55 -161 359 55 -161 minecraft:water[level=0]
setblock 360 55 -161 minecraft:tall_seagrass[half=upper]
fill 361 55 -161 366 55 -161 minecraft:water[level=0]
fill 367 55 -161 368 55 -161 minecraft:kelp_plant
setblock 369 55 -161 minecraft:water[level=0]
fill 370 55 -161 372 55 -161 minecraft:kelp_plant
fill 373 55 -161 376 55 -161 minecraft:water[level=0]
setblock 377 55 -161 minecraft:kelp_plant
fill 378 55 -161 388 55 -161 minecraft:water[level=0]
setblock 389 55 -161 minecraft:kelp_plant
fill 390 55 -161 391 55 -161 minecraft:water[level=0]
fill 332 55 -162 369 55 -162 minecraft:water[level=0]
fill 370 55 -162 371 55 -162 minecraft:kelp_plant
setblock 372 55 -162 minecraft:water[level=0]
setblock 373 55 -162 minecraft:kelp_plant
fill 374 55 -162 377 55 -162 minecraft:water[level=0]
setblock 378 55 -162 minecraft:kelp_plant
setblock 379 55 -162 minecraft:water[level=0]
setblock 380 55 -162 minecraft:kelp_plant
fill 381 55 -162 384 55 -162 minecraft:water[level=0]
setblock 385 55 -162 minecraft:kelp_plant
fill 386 55 -162 391 55 -162 minecraft:water[level=0]
fill 332 55 -163 353 55 -163 minecraft:water[level=0]
setblock 354 55 -163 minecraft:tall_seagrass[half=upper]
fill 355 55 -163 358 55 -163 minecraft:water[level=0]
setblock 359 55 -163 minecraft:tall_seagrass[half=upper]
fill 360 55 -163 370 55 -163 minecraft:water[level=0]
setblock 371 55 -163 minecraft:kelp_plant
fill 372 55 -163 391 55 -163 minecraft:water[level=0]
fill 332 55 -164 368 55 -164 minecraft:water[level=0]
setblock 369 55 -164 minecraft:kelp_plant
fill 370 55 -164 371 55 -164 minecraft:water[level=0]
fill 372 55 -164 373 55 -164 minecraft:kelp_plant
setblock 374 55 -164 minecraft:tall_seagrass[half=upper]
fill 375 55 -164 377 55 -164 minecraft:water[level=0]
setblock 378 55 -164 minecraft:kelp_plant
fill 379 55 -164 380 55 -164 minecraft:water[level=0]
setblock 381 55 -164 minecraft:kelp_plant
fill 382 55 -164 391 55 -164 minecraft:water[level=0]
fill 332 55 -165 363 55 -165 minecraft:water[level=0]
setblock 364 55 -165 minecraft:kelp_plant
fill 365 55 -165 375 55 -165 minecraft:water[level=0]
setblock 376 55 -165 minecraft:kelp_plant
fill 377 55 -165 380 55 -165 minecraft:water[level=0]
setblock 381 55 -165 minecraft:kelp_plant
fill 382 55 -165 391 55 -165 minecraft:water[level=0]
fill 332 55 -166 351 55 -166 minecraft:water[level=0]
setblock 352 55 -166 minecraft:tall_seagrass[half=upper]
fill 353 55 -166 380 55 -166 minecraft:water[level=0]
setblock 381 55 -166 minecraft:kelp_plant
fill 382 55 -166 391 55 -166 minecraft:water[level=0]
fill 332 55 -167 370 55 -167 minecraft:water[level=0]
setblock 371 55 -167 minecraft:tall_seagrass[half=upper]
fill 372 55 -167 374 55 -167 minecraft:water[level=0]
setblock 375 55 -167 minecraft:seagrass
fill 376 55 -167 377 55 -167 minecraft:water[level=0]
setblock 378 55 -167 minecraft:seagrass
setblock 379 55 -167 minecraft:water[level=0]
fill 380 55 -167 381 55 -167 minecraft:kelp_plant
fill 382 55 -167 383 55 -167 minecraft:water[level=0]
setblock 384 55 -167 minecraft:kelp_plant
setblock 385 55 -167 minecraft:water[level=0]
setblock 386 55 -167 minecraft:kelp_plant
fill 387 55 -167 391 55 -167 minecraft:water[level=0]
fill 332 55 -168 367 55 -168 minecraft:water[level=0]
setblock 368 55 -168 minecraft:kelp_plant
setblock 369 55 -168 minecraft:tall_seagrass[half=upper]
fill 370 55 -168 373 55 -168 minecraft:water[level=0]
setblock 374 55 -168 minecraft:tall_seagrass[half=upper]
fill 375 55 -168 376 55 -168 minecraft:water[level=0]
setblock 377 55 -168 minecraft:kelp_plant
setblock 378 55 -168 minecraft:tall_seagrass[half=lower]
setblock 379 55 -168 minecraft:water[level=0]
fill 381 55 -168 383 55 -168 minecraft:kelp_plant
fill 384 55 -168 391 55 -168 minecraft:water[level=0]
fill 332 55 -169 351 55 -169 minecraft:water[level=0]
setblock 352 55 -169 minecraft:kelp_plant
fill 353 55 -169 372 55 -169 minecraft:water[level=0]
setblock 373 55 -169 minecraft:tall_seagrass[half=upper]
fill 374 55 -169 375 55 -169 minecraft:water[level=0]
setblock 376 55 -169 minecraft:kelp_plant
fill 377 55 -169 379 55 -169 minecraft:water[level=0]
setblock 381 55 -169 minecraft:kelp_plant
fill 382 55 -169 391 55 -169 minecraft:water[level=0]
fill 332 55 -170 366 55 -170 minecraft:water[level=0]
setblock 367 55 -170 minecraft:tall_seagrass[half=upper]
setblock 368 55 -170 minecraft:kelp_plant
setblock 369 55 -170 minecraft:water[level=0]
setblock 370 55 -170 minecraft:kelp_plant
fill 371 55 -170 374 55 -170 minecraft:water[level=0]
setblock 375 55 -170 minecraft:kelp_plant
setblock 376 55 -170 minecraft:water[level=0]
fill 377 55 -170 378 55 -170 minecraft:kelp_plant
setblock 379 55 -170 minecraft:water[level=0]
fill 381 55 -170 383 55 -170 minecraft:water[level=0]
setblock 384 55 -170 minecraft:kelp_plant
fill 385 55 -170 390 55 -170 minecraft:water[level=0]
setblock 391 55 -170 minecraft:kelp_plant
fill 331 55 -171 368 55 -171 minecraft:water[level=0]
fill 369 55 -171 370 55 -171 minecraft:kelp_plant
setblock 371 55 -171 minecraft:water[level=0]
setblock 372 55 -171 minecraft:kelp_plant
setblock 373 55 -171 minecraft:water[level=0]
setblock 374 55 -171 minecraft:seagrass
setblock 375 55 -171 minecraft:kelp_plant
fill 376 55 -171 377 55 -171 minecraft:water[level=0]
setblock 378 55 -171 minecraft:tall_seagrass[half=lower]
setblock 379 55 -171 minecraft:water[level=0]
setblock 380 55 -171 minecraft:seagrass
fill 381 55 -171 383 55 -171 minecraft:water[level=0]
setblock 384 55 -171 minecraft:kelp_plant
fill 385 55 -171 391 55 -171 minecraft:water[level=0]
fill 331 55 -172 351 55 -172 minecraft:water[level=0]
setblock 352 55 -172 minecraft:kelp[age=25]
fill 353 55 -172 356 55 -172 minecraft:water[level=0]
setblock 357 55 -172 minecraft:kelp_plant
fill 358 55 -172 365 55 -172 minecraft:water[level=0]
setblock 366 55 -172 minecraft:tall_seagrass[half=upper]
setblock 367 55 -172 minecraft:water[level=0]
setblock 368 55 -172 minecraft:kelp_plant
fill 369 55 -172 370 55 -172 minecraft:water[level=0]
setblock 371 55 -172 minecraft:kelp_plant
setblock 372 55 -172 minecraft:water[level=0]
setblock 373 55 -172 minecraft:tall_seagrass[half=lower]
setblock 374 55 -172 minecraft:seagrass
setblock 375 55 -172 minecraft:kelp_plant
fill 376 55 -172 377 55 -172 minecraft:water[level=0]
setblock 378 55 -172 minecraft:seagrass
setblock 379 55 -172 minecraft:water[level=0]
fill 380 55 -172 382 55 -172 minecraft:kelp_plant
setblock 383 55 -172 minecraft:water[level=0]
setblock 384 55 -172 minecraft:kelp_plant
fill 385 55 -172 386 55 -172 minecraft:water[level=0]
setblock 387 55 -172 minecraft:kelp_plant
fill 388 55 -172 391 55 -172 minecraft:water[level=0]
fill 331 55 -173 367 55 -173 minecraft:water[level=0]
setblock 368 55 -173 minecraft:kelp_plant
fill 369 55 -173 370 55 -173 minecraft:water[level=0]
setblock 371 55 -173 minecraft:kelp_plant
fill 372 55 -173 382 55 -173 minecraft:water[level=0]
setblock 383 55 -173 minecraft:kelp_plant
fill 384 55 -173 385 55 -173 minecraft:water[level=0]
setblock 386 55 -173 minecraft:kelp_plant
fill 387 55 -173 391 55 -173 minecraft:water[level=0]
fill 332 55 -174 358 55 -174 minecraft:water[level=0]
setblock 359 55 -174 minecraft:kelp_plant
fill 360 55 -174 366 55 -174 minecraft:water[level=0]
setblock 367 55 -174 minecraft:kelp_plant
setblock 368 55 -174 minecraft:water[level=0]
setblock 369 55 -174 minecraft:kelp_plant
setblock 370 55 -174 minecraft:water[level=0]
setblock 371 55 -174 minecraft:tall_seagrass[half=lower]
fill 372 55 -174 373 55 -174 minecraft:water[level=0]
fill 374 55 -174 375 55 -174 minecraft:seagrass
setblock 376 55 -174 minecraft:water[level=0]
setblock 377 55 -174 minecraft:kelp_plant
fill 378 55 -174 387 55 -174 minecraft:water[level=0]
fill 388 55 -174 389 55 -174 minecraft:kelp_plant
fill 390 55 -174 391 55 -174 minecraft:water[level=0]
fill 332 55 -175 356 55 -175 minecraft:water[level=0]
setblock 357 55 -175 minecraft:kelp_plant
fill 358 55 -175 366 55 -175 minecraft:water[level=0]
fill 367 55 -175 368 55 -175 minecraft:kelp_plant
fill 369 55 -175 370 55 -175 minecraft:water[level=0]
setblock 371 55 -175 minecraft:seagrass
fill 372 55 -175 374 55 -175 minecraft:water[level=0]
fill 375 55 -175 378 55 -175 minecraft:seagrass
setblock 379 55 -175 minecraft:water[level=0]
setblock 380 55 -175 minecraft:kelp_plant
setblock 381 55 -175 minecraft:water[level=0]
setblock 382 55 -175 minecraft:kelp_plant
fill 383 55 -175 384 55 -175 minecraft:water[level=0]
setblock 385 55 -175 minecraft:kelp_plant
setblock 386 55 -175 minecraft:water[level=0]
setblock 387 55 -175 minecraft:kelp_plant
fill 388 55 -175 391 55 -175 minecraft:water[level=0]
fill 332 55 -176 370 55 -176 minecraft:water[level=0]
fill 371 55 -176 372 55 -176 minecraft:kelp_plant
setblock 373 55 -176 minecraft:seagrass
fill 374 55 -176 376 55 -176 minecraft:water[level=0]
setblock 377 55 -176 minecraft:kelp_plant
setblock 378 55 -176 minecraft:water[level=0]
setblock 379 55 -176 minecraft:seagrass
setblock 380 55 -176 minecraft:water[level=0]
setblock 381 55 -176 minecraft:kelp_plant
fill 382 55 -176 386 55 -176 minecraft:water[level=0]
setblock 387 55 -176 minecraft:kelp_plant
setblock 388 55 -176 minecraft:water[level=0]
setblock 389 55 -176 minecraft:kelp_plant
fill 390 55 -176 391 55 -176 minecraft:water[level=0]
fill 332 55 -177 363 55 -177 minecraft:water[level=0]
fill 364 55 -177 365 55 -177 minecraft:kelp_plant
setblock 366 55 -177 minecraft:water[level=0]
fill 367 55 -177 368 55 -177 minecraft:kelp_plant
setblock 369 55 -177 minecraft:water[level=0]
setblock 370 55 -177 minecraft:seagrass
setblock 371 55 -177 minecraft:water[level=0]
fill 372 55 -177 373 55 -177 minecraft:kelp_plant
setblock 374 55 -177 minecraft:tall_seagrass[half=lower]
fill 375 55 -177 378 55 -177 minecraft:water[level=0]
setblock 379 55 -177 minecraft:seagrass
setblock 380 55 -177 minecraft:kelp_plant
setblock 381 55 -177 minecraft:water[level=0]
fill 382 55 -177 383 55 -177 minecraft:kelp_plant
fill 384 55 -177 388 55 -177 minecraft:water[level=0]
setblock 389 55 -177 minecraft:kelp_plant
fill 390 55 -177 391 55 -177 minecraft:water[level=0]
fill 332 55 -178 356 55 -178 minecraft:water[level=0]
setblock 357 55 -178 minecraft:kelp_plant
fill 358 55 -178 366 55 -178 minecraft:water[level=0]
fill 367 55 -178 368 55 -178 minecraft:kelp_plant
fill 369 55 -178 372 55 -178 minecraft:water[level=0]
setblock 373 55 -178 minecraft:kelp_plant
setblock 374 55 -178 minecraft:water[level=0]
setblock 375 55 -178 minecraft:tall_seagrass[half=lower]
setblock 376 55 -178 minecraft:water[level=0]
fill 377 55 -178 378 55 -178 minecraft:kelp_plant
fill 379 55 -178 381 55 -178 minecraft:water[level=0]
setblock 382 55 -178 minecraft:kelp_plant
fill 383 55 -178 391 55 -178 minecraft:water[level=0]
fill 332 55 -179 351 55 -179 minecraft:water[level=0]
setblock 352 55 -179 minecraft:kelp_plant
setblock 353 55 -179 minecraft:water[level=0]
setblock 354 55 -179 minecraft:kelp_plant
fill 355 55 -179 366 55 -179 minecraft:water[level=0]
setblock 367 55 -179 minecraft:kelp_plant
fill 368 55 -179 369 55 -179 minecraft:water[level=0]
setblock 370 55 -179 minecraft:kelp_plant
fill 371 55 -179 372 55 -179 minecraft:water[level=0]
setblock 373 55 -179 minecraft:kelp_plant
fill 374 55 -179 378 55 -179 minecraft:water[level=0]
setblock 379 55 -179 minecraft:kelp_plant
fill 380 55 -179 381 55 -179 minecraft:water[level=0]
fill 382 55 -179 383 55 -179 minecraft:kelp_plant
fill 385 55 -179 386 55 -179 minecraft:water[level=0]
setblock 387 55 -179 minecraft:kelp_plant
fill 388 55 -179 391 55 -179 minecraft:water[level=0]
fill 332 55 -180 353 55 -180 minecraft:water[level=0]
fill 354 55 -180 355 55 -180 minecraft:kelp_plant
fill 356 55 -180 359 55 -180 minecraft:water[level=0]
setblock 360 55 -180 minecraft:kelp_plant
fill 361 55 -180 362 55 -180 minecraft:water[level=0]
setblock 363 55 -180 minecraft:tall_seagrass[half=upper]
setblock 364 55 -180 minecraft:water[level=0]
fill 365 55 -180 366 55 -180 minecraft:tall_seagrass[half=lower]
setblock 367 55 -180 minecraft:kelp_plant
setblock 368 55 -180 minecraft:water[level=0]
setblock 369 55 -180 minecraft:kelp_plant
setblock 370 55 -180 minecraft:water[level=0]
setblock 371 55 -180 minecraft:kelp_plant
setblock 372 55 -180 minecraft:water[level=0]
setblock 373 55 -180 minecraft:tall_seagrass[half=lower]
setblock 374 55 -180 minecraft:seagrass
fill 375 55 -180 376 55 -180 minecraft:water[level=0]
setblock 377 55 -180 minecraft:kelp_plant
setblock 378 55 -180 minecraft:seagrass
setblock 379 55 -180 minecraft:water[level=0]
setblock 380 55 -180 minecraft:kelp_plant
setblock 381 55 -180 minecraft:seagrass
setblock 382 55 -180 minecraft:water[level=0]
fill 385 55 -180 391 55 -180 minecraft:water[level=0]
fill 332 55 -181 348 55 -181 minecraft:water[level=0]
setblock 349 55 -181 minecraft:kelp_plant
fill 350 55 -181 352 55 -181 minecraft:water[level=0]
setblock 353 55 -181 minecraft:kelp_plant
setblock 354 55 -181 minecraft:water[level=0]
setblock 355 55 -181 minecraft:kelp_plant
setblock 356 55 -181 minecraft:water[level=0]
setblock 357 55 -181 minecraft:kelp_plant
fill 358 55 -181 364 55 -181 minecraft:water[level=0]
setblock 365 55 -181 minecraft:kelp_plant
fill 366 55 -181 367 55 -181 minecraft:water[level=0]
setblock 368 55 -181 minecraft:tall_seagrass[half=lower]
fill 369 55 -181 373 55 -181 minecraft:water[level=0]
setblock 374 55 -181 minecraft:tall_seagrass[half=lower]
setblock 375 55 -181 minecraft:kelp_plant
setblock 376 55 -181 minecraft:water[level=0]
setblock 377 55 -181 minecraft:kelp_plant
setblock 378 55 -181 minecraft:water[level=0]
fill 379 55 -181 380 55 -181 minecraft:kelp_plant
setblock 381 55 -181 minecraft:water[level=0]
setblock 382 55 -181 minecraft:kelp_plant
setblock 383 55 -181 minecraft:water[level=0]
fill 385 55 -181 386 55 -181 minecraft:seagrass
fill 387 55 -181 389 55 -181 minecraft:water[level=0]
setblock 390 55 -181 minecraft:kelp_plant
setblock 391 55 -181 minecraft:water[level=0]
fill 332 55 -182 336 55 -182 minecraft:water[level=0]
setblock 337 55 -182 minecraft:kelp_plant
fill 338 55 -182 352 55 -182 minecraft:water[level=0]
fill 353 55 -182 354 55 -182 minecraft:kelp_plant
setblock 355 55 -182 minecraft:water[level=0]
setblock 356 55 -182 minecraft:kelp_plant
fill 357 55 -182 359 55 -182 minecraft:water[level=0]
fill 360 55 -182 362 55 -182 minecraft:kelp_plant
fill 363 55 -182 365 55 -182 minecraft:water[level=0]
fill 366 55 -182 368 55 -182 minecraft:kelp_plant
setblock 369 55 -182 minecraft:seagrass
setblock 370 55 -182 minecraft:kelp_plant
fill 371 55 -182 372 55 -182 minecraft:water[level=0]
setblock 373 55 -182 minecraft:kelp_plant
fill 374 55 -182 376 55 -182 minecraft:water[level=0]
setblock 377 55 -182 minecraft:kelp_plant
fill 378 55 -182 379 55 -182 minecraft:water[level=0]
setblock 380 55 -182 minecraft:kelp_plant
setblock 381 55 -182 minecraft:water[level=0]
setblock 382 55 -182 minecraft:seagrass
setblock 383 55 -182 minecraft:kelp_plant
fill 384 55 -182 386 55 -182 minecraft:water[level=0]
setblock 387 55 -182 minecraft:kelp_plant
fill 388 55 -182 391 55 -182 minecraft:water[level=0]
fill 332 55 -183 346 55 -183 minecraft:water[level=0]
setblock 347 55 -183 minecraft:kelp_plant
fill 348 55 -183 359 55 -183 minecraft:water[level=0]
setblock 360 55 -183 minecraft:kelp_plant
fill 361 55 -183 363 55 -183 minecraft:water[level=0]
setblock 364 55 -183 minecraft:seagrass
fill 365 55 -183 366 55 -183 minecraft:water[level=0]
setblock 367 55 -183 minecraft:kelp_plant
setblock 368 55 -183 minecraft:tall_seagrass[half=lower]
setblock 369 55 -183 minecraft:kelp_plant
setblock 370 55 -183 minecraft:water[level=0]
setblock 371 55 -183 minecraft:kelp_plant
fill 372 55 -183 377 55 -183 minecraft:water[level=0]
setblock 378 55 -183 minecraft:kelp_plant
fill 379 55 -183 386 55 -183 minecraft:water[level=0]
setblock 387 55 -183 minecraft:kelp_plant
fill 388 55 -183 391 55 -183 minecraft:water[level=0]
fill 332 55 -184 345 55 -184 minecraft:water[level=0]
setblock 346 55 -184 minecraft:kelp_plant
fill 347 55 -184 348 55 -184 minecraft:water[level=0]
setblock 349 55 -184 minecraft:kelp_plant
fill 350 55 -184 359 55 -184 minecraft:water[level=0]
fill 360 55 -184 361 55 -184 minecraft:kelp_plant
fill 362 55 -184 363 55 -184 minecraft:tall_seagrass[half=lower]
setblock 364 55 -184 minecraft:seagrass
fill 365 55 -184 368 55 -184 minecraft:water[level=0]
setblock 369 55 -184 minecraft:seagrass
setblock 370 55 -184 minecraft:kelp_plant
fill 371 55 -184 375 55 -184 minecraft:water[level=0]
setblock 376 55 -184 minecraft:kelp_plant
fill 377 55 -184 379 55 -184 minecraft:water[level=0]
setblock 380 55 -184 minecraft:kelp_plant
setblock 381 55 -184 minecraft:tall_seagrass[half=lower]
setblock 382 55 -184 minecraft:seagrass
setblock 383 55 -184 minecraft:tall_seagrass[half=lower]
fill 384 55 -184 386 55 -184 minecraft:water[level=0]
fill 387 55 -184 389 55 -184 minecraft:kelp_plant
fill 390 55 -184 391 55 -184 minecraft:water[level=0]
fill 332 55 -185 356 55 -185 minecraft:water[level=0]
setblock 357 55 -185 minecraft:kelp_plant
fill 358 55 -185 360 55 -185 minecraft:water[level=0]
setblock 361 55 -185 minecraft:seagrass
fill 362 55 -185 363 55 -185 minecraft:water[level=0]
setblock 364 55 -185 minecraft:kelp_plant
setblock 365 55 -185 minecraft:seagrass
setblock 366 55 -185 minecraft:tall_seagrass[half=lower]
setblock 367 55 -185 minecraft:seagrass
setblock 368 55 -185 minecraft:tall_seagrass[half=lower]
setblock 369 55 -185 minecraft:seagrass
setblock 370 55 -185 minecraft:water[level=0]
setblock 371 55 -185 minecraft:kelp_plant
fill 372 55 -185 373 55 -185 minecraft:water[level=0]
setblock 374 55 -185 minecraft:kelp_plant
setblock 375 55 -185 minecraft:seagrass
setblock 376 55 -185 minecraft:water[level=0]
setblock 377 55 -185 minecraft:seagrass
fill 378 55 -185 379 55 -185 minecraft:water[level=0]
setblock 380 55 -185 minecraft:kelp_plant
setblock 381 55 -185 minecraft:seagrass
setblock 382 55 -185 minecraft:kelp_plant
setblock 383 55 -185 minecraft:water[level=0]
setblock 384 55 -185 minecraft:kelp_plant
fill 385 55 -185 391 55 -185 minecraft:water[level=0]
fill 332 55 -186 341 55 -186 minecraft:water[level=0]
setblock 342 55 -186 minecraft:kelp_plant
fill 343 55 -186 359 55 -186 minecraft:water[level=0]
setblock 360 55 -186 minecraft:kelp_plant
setblock 361 55 -186 minecraft:seagrass
setblock 362 55 -186 minecraft:tall_seagrass[half=lower]
setblock 363 55 -186 minecraft:water[level=0]
setblock 364 55 -186 minecraft:seagrass
fill 365 55 -186 366 55 -186 minecraft:water[level=0]
setblock 367 55 -186 minecraft:tall_seagrass[half=lower]
setblock 368 55 -186 minecraft:water[level=0]
setblock 369 55 -186 minecraft:kelp_plant
fill 370 55 -186 375 55 -186 minecraft:water[level=0]
setblock 376 55 -186 minecraft:tall_seagrass[half=lower]
fill 377 55 -186 379 55 -186 minecraft:kelp_plant
setblock 380 55 -186 minecraft:seagrass
setblock 381 55 -186 minecraft:water[level=0]
setblock 382 55 -186 minecraft:seagrass
setblock 383 55 -186 minecraft:water[level=0]
fill 384 55 -186 385 55 -186 minecraft:seagrass
fill 386 55 -186 390 55 -186 minecraft:water[level=0]
setblock 391 55 -186 minecraft:kelp_plant
fill 332 55 -187 353 55 -187 minecraft:water[level=0]
setblock 354 55 -187 minecraft:kelp_plant
fill 355 55 -187 356 55 -187 minecraft:water[level=0]
fill 357 55 -187 358 55 -187 minecraft:kelp_plant
fill 359 55 -187 362 55 -187 minecraft:water[level=0]
setblock 363 55 -187 minecraft:tall_seagrass[half=lower]
setblock 364 55 -187 minecraft:seagrass
fill 365 55 -187 366 55 -187 minecraft:kelp_plant
setblock 367 55 -187 minecraft:seagrass
setblock 368 55 -187 minecraft:water[level=0]
setblock 369 55 -187 minecraft:tall_seagrass[half=lower]
setblock 370 55 -187 minecraft:kelp_plant
setblock 371 55 -187 minecraft:water[level=0]
setblock 372 55 -187 minecraft:seagrass
setblock 373 55 -187 minecraft:water[level=0]
setblock 374 55 -187 minecraft:kelp_plant
setblock 375 55 -187 minecraft:tall_seagrass[half=lower]
fill 376 55 -187 379 55 -187 minecraft:water[level=0]
fill 380 55 -187 381 55 -187 minecraft:kelp_plant
fill 382 55 -187 384 55 -187 minecraft:seagrass
fill 385 55 -187 387 55 -187 minecraft:water[level=0]
setblock 388 55 -187 minecraft:kelp_plant
fill 389 55 -187 390 55 -187 minecraft:water[level=0]
setblock 391 55 -187 minecraft:kelp_plant
fill 332 55 -188 352 55 -188 minecraft:water[level=0]
setblock 353 55 -188 minecraft:kelp_plant
setblock 354 55 -188 minecraft:water[level=0]
fill 355 55 -188 356 55 -188 minecraft:kelp_plant
fill 357 55 -188 361 55 -188 minecraft:water[level=0]
setblock 362 55 -188 minecraft:seagrass
fill 363 55 -188 365 55 -188 minecraft:kelp_plant
setblock 366 55 -188 minecraft:water[level=0]
setblock 367 55 -188 minecraft:kelp_plant
setblock 368 55 -188 minecraft:water[level=0]
setblock 369 55 -188 minecraft:kelp_plant
setblock 370 55 -188 minecraft:water[level=0]
fill 371 55 -188 374 55 -188 minecraft:kelp_plant
fill 375 55 -188 376 55 -188 minecraft:water[level=0]
fill 377 55 -188 378 55 -188 minecraft:kelp_plant
fill 379 55 -188 380 55 -188 minecraft:water[level=0]
setblock 381 55 -188 minecraft:kelp_plant
setblock 382 55 -188 minecraft:seagrass
fill 383 55 -188 384 55 -188 minecraft:kelp_plant
fill 385 55 -188 391 55 -188 minecraft:water[level=0]
fill 332 55 -189 351 55 -189 minecraft:water[level=0]
setblock 352 55 -189 minecraft:kelp_plant
fill 353 55 -189 356 55 -189 minecraft:water[level=0]
setblock 357 55 -189 minecraft:kelp_plant
fill 358 55 -189 361 55 -189 minecraft:water[level=0]
setblock 362 55 -189 minecraft:seagrass
setblock 363 55 -189 minecraft:water[level=0]
fill 364 55 -189 365 55 -189 minecraft:kelp_plant
fill 366 55 -189 368 55 -189 minecraft:water[level=0]
setblock 369 55 -189 minecraft:kelp_plant
setblock 370 55 -189 minecraft:water[level=0]
setblock 371 55 -189 minecraft:seagrass
fill 372 55 -189 375 55 -189 minecraft:water[level=0]
setblock 376 55 -189 minecraft:kelp_plant
setblock 377 55 -189 minecraft:water[level=0]
setblock 378 55 -189 minecraft:tall_seagrass[half=lower]
setblock 379 55 -189 minecraft:seagrass
fill 380 55 -189 381 55 -189 minecraft:water[level=0]
fill 382 55 -189 383 55 -189 minecraft:kelp_plant
fill 384 55 -189 391 55 -189 minecraft:water[level=0]
fill 332 55 -190 348 55 -190 minecraft:water[level=0]
setblock 349 55 -190 minecraft:tall_seagrass[half=upper]
fill 350 55 -190 357 55 -190 minecraft:water[level=0]
setblock 358 55 -190 minecraft:kelp_plant
fill 359 55 -190 361 55 -190 minecraft:water[level=0]
setblock 362 55 -190 minecraft:kelp_plant
setblock 363 55 -190 minecraft:water[level=0]
setblock 364 55 -190 minecraft:seagrass
fill 365 55 -190 370 55 -190 minecraft:kelp_plant
fill 371 55 -190 375 55 -190 minecraft:water[level=0]
setblock 376 55 -190 minecraft:kelp_plant
fill 377 55 -190 378 55 -190 minecraft:water[level=0]
setblock 379 55 -190 minecraft:seagrass
setblock 380 55 -190 minecraft:water[level=0]
fill 381 55 -190 382 55 -190 minecraft:kelp_plant
fill 385 55 -190 386 55 -190 minecraft:water[level=0]
fill 387 55 -190 388 55 -190 minecraft:kelp_plant
fill 389 55 -190 391 55 -190 minecraft:water[level=0]
fill 338 54 -127 340 54 -127 minecraft:water[level=0]
setblock 341 54 -127 minecraft:kelp_plant
fill 347 54 -127 349 54 -127 minecraft:kelp_plant
fill 350 54 -127 352 54 -127 minecraft:water[level=0]
setblock 353 54 -127 minecraft:tall_seagrass[half=upper]
setblock 354 54 -127 minecraft:kelp_plant
fill 355 54 -127 360 54 -127 minecraft:water[level=0]
setblock 361 54 -127 minecraft:kelp_plant
fill 362 54 -127 368 54 -127 minecraft:water[level=0]
setblock 369 54 -127 minecraft:kelp_plant
fill 370 54 -127 372 54 -127 minecraft:water[level=0]
setblock 373 54 -127 minecraft:kelp_plant
fill 374 54 -127 383 54 -127 minecraft:water[level=0]
fill 384 54 -127 385 54 -127 minecraft:kelp_plant
fill 386 54 -127 390 54 -127 minecraft:water[level=0]
setblock 391 54 -127 minecraft:kelp_plant
fill 347 54 -128 354 54 -128 minecraft:water[level=0]
setblock 355 54 -128 minecraft:kelp_plant
setblock 356 54 -128 minecraft:water[level=0]
setblock 357 54 -128 minecraft:kelp_plant
fill 358 54 -128 359 54 -128 minecraft:water[level=0]
setblock 360 54 -128 minecraft:kelp_plant
fill 361 54 -128 366 54 -128 minecraft:water[level=0]
setblock 367 54 -128 minecraft:kelp_plant
fill 368 54 -128 369 54 -128 minecraft:water[level=0]
setblock 370 54 -128 minecraft:kelp_plant
setblock 371 54 -128 minecraft:water[level=0]
fill 372 54 -128 373 54 -128 minecraft:kelp_plant
setblock 374 54 -128 minecraft:water[level=0]
fill 375 54 -128 376 54 -128 minecraft:kelp_plant
setblock 377 54 -128 minecraft:water[level=0]
fill 378 54 -128 380 54 -128 minecraft:kelp_plant
fill 381 54 -128 386 54 -128 minecraft:water[level=0]
setblock 387 54 -128 minecraft:kelp_plant
fill 388 54 -128 391 54 -128 minecraft:water[level=0]
fill 328 54 -129 329 54 -129 minecraft:seagrass
setblock 330 54 -129 minecraft:water[level=0]
setblock 347 54 -129 minecraft:water[level=0]
setblock 348 54 -129 minecraft:seagrass
setblock 349 54 -129 minecraft:kelp_plant
fill 350 54 -129 351 54 -129 minecraft:water[level=0]
setblock 352 54 -129 minecraft:tall_seagrass[half=lower]
fill 353 54 -129 358 54 -129 minecraft:water[level=0]
setblock 359 54 -129 minecraft:kelp_plant
fill 360 54 -129 368 54 -129 minecraft:water[level=0]
setblock 369 54 -129 minecraft:kelp_plant
fill 370 54 -129 376 54 -129 minecraft:water[level=0]
setblock 377 54 -129 minecraft:kelp_plant
fill 378 54 -129 382 54 -129 minecraft:water[level=0]
setblock 383 54 -129 minecraft:kelp[age=25]
setblock 384 54 -129 minecraft:water[level=0]
setblock 385 54 -129 minecraft:kelp_plant
setblock 386 54 -129 minecraft:water[level=0]
setblock 387 54 -129 minecraft:kelp_plant
fill 388 54 -129 389 54 -129 minecraft:water[level=0]
setblock 390 54 -129 minecraft:kelp_plant
setblock 391 54 -129 minecraft:water[level=0]
setblock 328 54 -130 minecraft:tall_seagrass[half=upper]
setblock 329 54 -130 minecraft:water[level=0]
setblock 330 54 -130 minecraft:tall_seagrass[half=lower]
fill 331 54 -130 333 54 -130 minecraft:seagrass
setblock 334 54 -130 minecraft:kelp_plant
fill 336 54 -130 337 54 -130 minecraft:water[level=0]
fill 348 54 -130 350 54 -130 minecraft:water[level=0]
setblock 351 54 -130 minecraft:kelp_plant
fill 352 54 -130 353 54 -130 minecraft:water[level=0]
setblock 354 54 -130 minecraft:tall_seagrass[half=lower]
fill 355 54 -130 362 54 -130 minecraft:water[level=0]
setblock 363 54 -130 minecraft:kelp_plant
fill 364 54 -130 365 54 -130 minecraft:water[level=0]
setblock 366 54 -130 minecraft:kelp_plant
fill 367 54 -130 368 54 -130 minecraft:water[level=0]
setblock 369 54 -130 minecraft:kelp_plant
fill 370 54 -130 391 54 -130 minecraft:water[level=0]
setblock 328 54 -131 minecraft:kelp_plant
setblock 329 54 -131 minecraft:water[level=0]
setblock 330 54 -131 minecraft:tall_seagrass[half=upper]
fill 331 54 -131 332 54 -131 minecraft:water[level=0]
setblock 333 54 -131 minecraft:seagrass
fill 334 54 -131 337 54 -131 minecraft:water[level=0]
fill 348 54 -131 353 54 -131 minecraft:water[level=0]
fill 354 54 -131 355 54 -131 minecraft:seagrass
setblock 356 54 -131 minecraft:tall_seagrass[half=lower]
fill 357 54 -131 367 54 -131 minecraft:water[level=0]
setblock 368 54 -131 minecraft:kelp_plant
fill 369 54 -131 391 54 -131 minecraft:water[level=0]
fill 328 54 -132 329 54 -132 minecraft:water[level=0]
fill 330 54 -132 331 54 -132 minecraft:tall_seagrass[half=upper]
fill 332 54 -132 333 54 -132 minecraft:water[level=0]
setblock 334 54 -132 minecraft:tall_seagrass[half=upper]
fill 335 54 -132 341 54 -132 minecraft:water[level=0]
fill 349 54 -132 352 54 -132 minecraft:water[level=0]
fill 353 54 -132 355 54 -132 minecraft:seagrass
fill 356 54 -132 362 54 -132 minecraft:water[level=0]
setblock 363 54 -132 minecraft:kelp_plant
fill 364 54 -132 377 54 -132 minecraft:water[level=0]
setblock 378 54 -132 minecraft:kelp_plant
fill 379 54 -132 382 54 -132 minecraft:water[level=0]
setblock 383 54 -132 minecraft:kelp_plant
setblock 384 54 -132 minecraft:water[level=0]
setblock 385 54 -132 minecraft:kelp_plant
setblock 386 54 -132 minecraft:water[level=0]
fill 387 54 -132 388 54 -132 minecraft:kelp_plant
fill 389 54 -132 391 54 -132 minecraft:water[level=0]
fill 328 54 -133 348 54 -133 minecraft:water[level=0]
setblock 349 54 -133 minecraft:kelp_plant
fill 350 54 -133 351 54 -133 minecraft:water[level=0]
setblock 352 54 -133 minecraft:kelp_plant
setblock 353 54 -133 minecraft:tall_seagrass[half=lower]
fill 354 54 -133 355 54 -133 minecraft:seagrass
setblock 356 54 -133 minecraft:water[level=0]
setblock 357 54 -133 minecraft:kelp_plant
setblock 358 54 -133 minecraft:tall_seagrass[half=lower]
fill 359 54 -133 381 54 -133 minecraft:water[level=0]
setblock 382 54 -133 minecraft:kelp_plant
fill 383 54 -133 387 54 -133 minecraft:water[level=0]
setblock 388 54 -133 minecraft:kelp_plant
fill 389 54 -133 391 54 -133 minecraft:water[level=0]
fill 328 54 -134 336 54 -134 minecraft:water[level=0]
setblock 337 54 -134 minecraft:kelp_plant
fill 338 54 -134 340 54 -134 minecraft:water[level=0]
setblock 341 54 -134 minecraft:tall_seagrass[half=lower]
fill 342 54 -134 345 54 -134 minecraft:water[level=0]
setblock 346 54 -134 minecraft:tall_seagrass[half=lower]
fill 347 54 -134 353 54 -134 minecraft:water[level=0]
fill 354 54 -134 355 54 -134 minecraft:seagrass
setblock 356 54 -134 minecraft:water[level=0]
setblock 357 54 -134 minecraft:seagrass
fill 358 54 -134 367 54 -134 minecraft:water[level=0]
fill 368 54 -134 369 54 -134 minecraft:kelp_plant
fill 370 54 -134 371 54 -134 minecraft:water[level=0]
setblock 372 54 -134 minecraft:kelp_plant
fill 373 54 -134 376 54 -134 minecraft:water[level=0]
setblock 377 54 -134 minecraft:kelp_plant
fill 378 54 -134 382 54 -134 minecraft:water[level=0]
setblock 383 54 -134 minecraft:kelp[age=25]
fill 384 54 -134 385 54 -134 minecraft:kelp_plant
fill 386 54 -134 391 54 -134 minecraft:water[level=0]
fill 328 54 -135 331 54 -135 minecraft:water[level=0]
setblock 332 54 -135 minecraft:kelp_plant
fill 333 54 -135 336 54 -135 minecraft:water[level=0]
setblock 337 54 -135 minecraft:kelp_plant
fill 338 54 -135 347 54 -135 minecraft:water[level=0]
fill 348 54 -135 350 54 -135 minecraft:kelp_plant
fill 355 54 -135 358 54 -135 minecraft:water[level=0]
setblock 359 54 -135 minecraft:seagrass
setblock 360 54 -135 minecraft:water[level=0]
setblock 361 54 -135 minecraft:tall_seagrass[half=upper]
fill 362 54 -135 376 54 -135 minecraft:water[level=0]
setblock 377 54 -135 minecraft:kelp_plant
fill 378 54 -135 379 54 -135 minecraft:water[level=0]
setblock 380 54 -135 minecraft:kelp_plant
fill 381 54 -135 384 54 -135 minecraft:water[level=0]
setblock 385 54 -135 minecraft:kelp_plant
fill 386 54 -135 391 54 -135 minecraft:water[level=0]
fill 328 54 -136 342 54 -136 minecraft:water[level=0]
setblock 343 54 -136 minecraft:kelp_plant
fill 344 54 -136 345 54 -136 minecraft:water[level=0]
setblock 346 54 -136 minecraft:kelp_plant
fill 347 54 -136 348 54 -136 minecraft:water[level=0]
setblock 349 54 -136 minecraft:kelp_plant
setblock 350 54 -136 minecraft:water[level=0]
setblock 357 54 -136 minecraft:tall_seagrass[half=lower]
fill 358 54 -136 361 54 -136 minecraft:water[level=0]
setblock 362 54 -136 minecraft:kelp_plant
fill 363 54 -136 364 54 -136 minecraft:water[level=0]
setblock 365 54 -136 minecraft:kelp_plant
fill 366 54 -136 374 54 -136 minecraft:water[level=0]
setblock 375 54 -136 minecraft:kelp_plant
fill 376 54 -136 377 54 -136 minecraft:water[level=0]
setblock 378 54 -136 minecraft:kelp_plant
fill 379 54 -136 381 54 -136 minecraft:water[level=0]
setblock 382 54 -136 minecraft:kelp_plant
fill 383 54 -136 384 54 -136 minecraft:water[level=0]
setblock 385 54 -136 minecraft:kelp_plant
fill 386 54 -136 387 54 -136 minecraft:water[level=0]
fill 388 54 -136 389 54 -136 minecraft:kelp_plant
fill 390 54 -136 391 54 -136 minecraft:water[level=0]
setblock 328 54 -137 minecraft:kelp_plant
fill 329 54 -137 330 54 -137 minecraft:water[level=0]
setblock 331 54 -137 minecraft:kelp_plant
fill 332 54 -137 340 54 -137 minecraft:water[level=0]
setblock 341 54 -137 minecraft:seagrass
fill 342 54 -137 349 54 -137 minecraft:water[level=0]
fill 357 54 -137 367 54 -137 minecraft:water[level=0]
setblock 368 54 -137 minecraft:kelp_plant
fill 369 54 -137 381 54 -137 minecraft:water[level=0]
setblock 382 54 -137 minecraft:kelp_plant
fill 383 54 -137 384 54 -137 minecraft:water[level=0]
setblock 385 54 -137 minecraft:kelp_plant
fill 386 54 -137 391 54 -137 minecraft:water[level=0]
fill 328 54 -138 338 54 -138 minecraft:water[level=0]
fill 339 54 -138 341 54 -138 minecraft:seagrass
setblock 342 54 -138 minecraft:tall_seagrass[half=lower]
fill 343 54 -138 349 54 -138 minecraft:water[level=0]
setblock 357 54 -138 minecraft:seagrass
fill 358 54 -138 366 54 -138 minecraft:water[level=0]
setblock 367 54 -138 minecraft:kelp_plant
fill 368 54 -138 384 54 -138 minecraft:water[level=0]
fill 385 54 -138 386 54 -138 minecraft:kelp_plant
fill 387 54 -138 388 54 -138 minecraft:water[level=0]
setblock 389 54 -138 minecraft:kelp_plant
fill 390 54 -138 391 54 -138 minecraft:water[level=0]
fill 328 54 -139 334 54 -139 minecraft:water[level=0]
setblock 335 54 -139 minecraft:tall_seagrass[half=upper]
fill 336 54 -139 339 54 -139 minecraft:water[level=0]
setblock 340 54 -139 minecraft:tall_seagrass[half=lower]
fill 341 54 -139 344 54 -139 minecraft:water[level=0]
setblock 345 54 -139 minecraft:tall_seagrass[half=lower]
fill 346 54 -139 348 54 -139 minecraft:water[level=0]
fill 357 54 -139 359 54 -139 minecraft:water[level=0]
setblock 360 54 -139 minecraft:kelp_plant
fill 361 54 -139 371 54 -139 minecraft:water[level=0]
setblock 372 54 -139 minecraft:kelp_plant
fill 373 54 -139 383 54 -139 minecraft:water[level=0]
setblock 384 54 -139 minecraft:kelp_plant
fill 385 54 -139 391 54 -139 minecraft:water[level=0]
fill 328 54 -140 330 54 -140 minecraft:water[level=0]
setblock 334 54 -140 minecraft:tall_seagrass[half=lower]
fill 335 54 -140 336 54 -140 minecraft:water[level=0]
setblock 337 54 -140 minecraft:tall_seagrass[half=lower]
fill 338 54 -140 341 54 -140 minecraft:water[level=0]
setblock 342 54 -140 minecraft:seagrass
setblock 343 54 -140 minecraft:water[level=0]
setblock 344 54 -140 minecraft:kelp_plant
fill 345 54 -140 347 54 -140 minecraft:water[level=0]
setblock 357 54 -140 minecraft:seagrass
fill 358 54 -140 368 54 -140 minecraft:water[level=0]
setblock 369 54 -140 minecraft:kelp_plant
setblock 370 54 -140 minecraft:water[level=0]
setblock 371 54 -140 minecraft:kelp_plant
fill 372 54 -140 377 54 -140 minecraft:water[level=0]
setblock 378 54 -140 minecraft:kelp_plant
fill 379 54 -140 380 54 -140 minecraft:water[level=0]
setblock 381 54 -140 minecraft:kelp_plant
fill 382 54 -140 391 54 -140 minecraft:water[level=0]
fill 328 54 -141 330 54 -141 minecraft:water[level=0]
fill 333 54 -141 340 54 -141 minecraft:water[level=0]
setblock 341 54 -141 minecraft:seagrass
fill 342 54 -141 346 54 -141 minecraft:water[level=0]
fill 357 54 -141 368 54 -141 minecraft:water[level=0]
setblock 369 54 -141 minecraft:kelp_plant
fill 370 54 -141 378 54 -141 minecraft:water[level=0]
setblock 379 54 -141 minecraft:kelp_plant
fill 380 54 -141 382 54 -141 minecraft:water[level=0]
setblock 383 54 -141 minecraft:kelp_plant
fill 384 54 -141 387 54 -141 minecraft:water[level=0]
fill 388 54 -141 389 54 -141 minecraft:kelp_plant
fill 390 54 -141 391 54 -141 minecraft:water[level=0]
fill 328 54 -142 331 54 -142 minecraft:water[level=0]
setblock 332 54 -142 minecraft:seagrass
fill 333 54 -142 338 54 -142 minecraft:water[level=0]
setblock 339 54 -142 minecraft:seagrass
setblock 340 54 -142 minecraft:tall_seagrass[half=lower]
fill 341 54 -142 343 54 -142 minecraft:water[level=0]
fill 344 54 -142 345 54 -142 minecraft:seagrass
fill 357 54 -142 367 54 -142 minecraft:water[level=0]
fill 368 54 -142 369 54 -142 minecraft:kelp_plant
setblock 370 54 -142 minecraft:water[level=0]
fill 371 54 -142 372 54 -142 minecraft:kelp_plant
fill 373 54 -142 391 54 -142 minecraft:water[level=0]
fill 328 54 -143 331 54 -143 minecraft:water[level=0]
setblock 332 54 -143 minecraft:kelp_plant
fill 333 54 -143 336 54 -143 minecraft:water[level=0]
setblock 337 54 -143 minecraft:seagrass
setblock 338 54 -143 minecraft:kelp_plant
fill 339 54 -143 340 54 -143 minecraft:water[level=0]
setblock 341 54 -143 minecraft:seagrass
setblock 342 54 -143 minecraft:kelp_plant
setblock 343 54 -143 minecraft:water[level=0]
setblock 344 54 -143 minecraft:tall_seagrass[half=lower]
fill 357 54 -143 359 54 -143 minecraft:water[level=0]
setblock 360 54 -143 minecraft:seagrass
fill 361 54 -143 363 54 -143 minecraft:water[level=0]
setblock 364 54 -143 minecraft:tall_seagrass[half=upper]
fill 365 54 -143 377 54 -143 minecraft:water[level=0]
fill 378 54 -143 379 54 -143 minecraft:kelp_plant
fill 380 54 -143 382 54 -143 minecraft:water[level=0]
setblock 383 54 -143 minecraft:kelp_plant
fill 384 54 -143 385 54 -143 minecraft:water[level=0]
setblock 386 54 -143 minecraft:kelp_plant
fill 387 54 -143 391 54 -143 minecraft:water[level=0]
fill 328 54 -144 334 54 -144 minecraft:water[level=0]
setblock 335 54 -144 minecraft:seagrass
fill 336 54 -144 341 54 -144 minecraft:water[level=0]
setblock 342 54 -144 minecraft:seagrass
setblock 343 54 -144 minecraft:water[level=0]
setblock 357 54 -144 minecraft:water[level=0]
setblock 358 54 -144 minecraft:seagrass
fill 359 54 -144 370 54 -144 minecraft:water[level=0]
setblock 371 54 -144 minecraft:kelp_plant
fill 372 54 -144 391 54 -144 minecraft:water[level=0]
fill 328 54 -145 341 54 -145 minecraft:water[level=0]
setblock 342 54 -145 minecraft:seagrass
setblock 343 54 -145 minecraft:water[level=0]
setblock 357 54 -145 minecraft:seagrass
fill 358 54 -145 359 54 -145 minecraft:water[level=0]
setblock 360 54 -145 minecraft:seagrass
fill 361 54 -145 368 54 -145 minecraft:water[level=0]
fill 369 54 -145 370 54 -145 minecraft:kelp_plant
fill 371 54 -145 383 54 -145 minecraft:water[level=0]
setblock 384 54 -145 minecraft:kelp_plant
setblock 385 54 -145 minecraft:water[level=0]
setblock 386 54 -145 minecraft:kelp_plant
fill 387 54 -145 388 54 -145 minecraft:water[level=0]
setblock 389 54 -145 minecraft:kelp_plant
fill 390 54 -145 391 54 -145 minecraft:water[level=0]
fill 330 54 -146 337 54 -146 minecraft:water[level=0]
setblock 338 54 -146 minecraft:seagrass
fill 339 54 -146 341 54 -146 minecraft:water[level=0]
setblock 342 54 -146 minecraft:seagrass
fill 343 54 -146 346 54 -146 minecraft:water[level=0]
setblock 357 54 -146 minecraft:water[level=0]
setblock 358 54 -146 minecraft:seagrass
setblock 359 54 -146 minecraft:water[level=0]
setblock 360 54 -146 minecraft:seagrass
setblock 361 54 -146 minecraft:tall_seagrass[half=lower]
fill 362 54 -146 367 54 -146 minecraft:water[level=0]
setblock 368 54 -146 minecraft:kelp_plant
fill 369 54 -146 371 54 -146 minecraft:water[level=0]
setblock 372 54 -146 minecraft:kelp_plant
fill 373 54 -146 391 54 -146 minecraft:water[level=0]
fill 331 54 -147 339 54 -147 minecraft:water[level=0]
setblock 340 54 -147 minecraft:seagrass
setblock 341 54 -147 minecraft:tall_seagrass[half=lower]
fill 342 54 -147 348 54 -147 minecraft:water[level=0]
fill 357 54 -147 358 54 -147 minecraft:seagrass
fill 359 54 -147 361 54 -147 minecraft:water[level=0]
setblock 362 54 -147 minecraft:tall_seagrass[half=lower]
fill 363 54 -147 368 54 -147 minecraft:water[level=0]
setblock 369 54 -147 minecraft:kelp_plant
fill 370 54 -147 372 54 -147 minecraft:water[level=0]
setblock 373 54 -147 minecraft:tall_seagrass[half=upper]
fill 374 54 -147 375 54 -147 minecraft:kelp_plant
setblock 376 54 -147 minecraft:tall_seagrass[half=upper]
fill 377 54 -147 379 54 -147 minecraft:water[level=0]
fill 380 54 -147 381 54 -147 minecraft:tall_seagrass[half=upper]
fill 382 54 -147 385 54 -147 minecraft:water[level=0]
setblock 386 54 -147 minecraft:kelp_plant
fill 387 54 -147 391 54 -147 minecraft:water[level=0]
fill 332 54 -148 336 54 -148 minecraft:water[level=0]
fill 337 54 -148 339 54 -148 minecraft:seagrass
setblock 340 54 -148 minecraft:water[level=0]
setblock 341 54 -148 minecraft:seagrass
fill 342 54 -148 346 54 -148 minecraft:water[level=0]
setblock 347 54 -148 minecraft:tall_seagrass[half=upper]
setblock 348 54 -148 minecraft:water[level=0]
setblock 357 54 -148 minecraft:water[level=0]
setblock 358 54 -148 minecraft:tall_seagrass[half=lower]
setblock 359 54 -148 minecraft:seagrass
setblock 360 54 -148 minecraft:water[level=0]
setblock 361 54 -148 minecraft:tall_seagrass[half=lower]
fill 362 54 -148 374 54 -148 minecraft:water[level=0]
setblock 375 54 -148 minecraft:kelp_plant
fill 376 54 -148 377 54 -148 minecraft:water[level=0]
setblock 378 54 -148 minecraft:kelp_plant
fill 379 54 -148 386 54 -148 minecraft:water[level=0]
setblock 387 54 -148 minecraft:kelp_plant
setblock 388 54 -148 minecraft:water[level=0]
setblock 389 54 -148 minecraft:kelp_plant
fill 390 54 -148 391 54 -148 minecraft:water[level=0]
fill 331 54 -149 340 54 -149 minecraft:water[level=0]
fill 341 54 -149 342 54 -149 minecraft:seagrass
fill 343 54 -149 344 54 -149 minecraft:water[level=0]
fill 345 54 -149 346 54 -149 minecraft:tall_seagrass[half=lower]
setblock 347 54 -149 minecraft:water[level=0]
fill 356 54 -149 358 54 -149 minecraft:water[level=0]
fill 359 54 -149 361 54 -149 minecraft:seagrass
fill 362 54 -149 368 54 -149 minecraft:water[level=0]
fill 369 54 -149 370 54 -149 minecraft:kelp_plant
fill 371 54 -149 377 54 -149 minecraft:water[level=0]
setblock 378 54 -149 minecraft:kelp_plant
fill 379 54 -149 380 54 -149 minecraft:water[level=0]
setblock 381 54 -149 minecraft:seagrass
setblock 382 54 -149 minecraft:water[level=0]
fill 383 54 -149 384 54 -149 minecraft:seagrass
fill 385 54 -149 388 54 -149 minecraft:water[level=0]
setblock 389 54 -149 minecraft:tall_seagrass[half=upper]
setblock 390 54 -149 minecraft:water[level=0]
setblock 391 54 -149 minecraft:kelp_plant
fill 330 54 -150 334 54 -150 minecraft:water[level=0]
setblock 335 54 -150 minecraft:tall_seagrass[half=lower]
setblock 336 54 -150 minecraft:water[level=0]
setblock 337 54 -150 minecraft:seagrass
setblock 338 54 -150 minecraft:water[level=0]
setblock 339 54 -150 minecraft:tall_seagrass[half=lower]
setblock 340 54 -150 minecraft:seagrass
setblock 341 54 -150 minecraft:water[level=0]
fill 342 54 -150 343 54 -150 minecraft:seagrass
fill 344 54 -150 346 54 -150 minecraft:water[level=0]
fill 355 54 -150 356 54 -150 minecraft:water[level=0]
setblock 357 54 -150 minecraft:tall_seagrass[half=lower]
setblock 358 54 -150 minecraft:seagrass
setblock 359 54 -150 minecraft:water[level=0]
fill 360 54 -150 361 54 -150 minecraft:seagrass
setblock 362 54 -150 minecraft:tall_seagrass[half=lower]
fill 363 54 -150 369 54 -150 minecraft:water[level=0]
fill 370 54 -150 371 54 -150 minecraft:kelp_plant
fill 372 54 -150 380 54 -150 minecraft:water[level=0]
fill 381 54 -150 382 54 -150 minecraft:tall_seagrass[half=lower]
fill 383 54 -150 388 54 -150 minecraft:water[level=0]
setblock 389 54 -150 minecraft:tall_seagrass[half=upper]
fill 390 54 -150 391 54 -150 minecraft:water[level=0]
fill 330 54 -151 341 54 -151 minecraft:water[level=0]
fill 342 54 -151 344 54 -151 minecraft:seagrass
setblock 354 54 -151 minecraft:seagrass
fill 355 54 -151 359 54 -151 minecraft:water[level=0]
setblock 360 54 -151 minecraft:seagrass
setblock 361 54 -151 minecraft:water[level=0]
setblock 362 54 -151 minecraft:seagrass
fill 363 54 -151 376 54 -151 minecraft:water[level=0]
fill 377 54 -151 379 54 -151 minecraft:seagrass
setblock 380 54 -151 minecraft:tall_seagrass[half=lower]
setblock 382 54 -151 minecraft:kelp_plant
setblock 383 54 -151 minecraft:seagrass
fill 384 54 -151 385 54 -151 minecraft:water[level=0]
setblock 386 54 -151 minecraft:kelp_plant
fill 387 54 -151 391 54 -151 minecraft:water[level=0]
fill 329 54 -152 344 54 -152 minecraft:water[level=0]
fill 353 54 -152 362 54 -152 minecraft:water[level=0]
fill 363 54 -152 364 54 -152 minecraft:seagrass
fill 365 54 -152 367 54 -152 minecraft:water[level=0]
fill 368 54 -152 369 54 -152 minecraft:kelp_plant
setblock 370 54 -152 minecraft:water[level=0]
setblock 371 54 -152 minecraft:kelp_plant
fill 372 54 -152 373 54 -152 minecraft:water[level=0]
setblock 374 54 -152 minecraft:seagrass
fill 375 54 -152 376 54 -152 minecraft:water[level=0]
setblock 377 54 -152 minecraft:kelp_plant
setblock 378 54 -152 minecraft:tall_seagrass[half=lower]
setblock 379 54 -152 minecraft:water[level=0]
setblock 380 54 -152 minecraft:seagrass
setblock 382 54 -152 minecraft:tall_seagrass[half=lower]
fill 383 54 -152 385 54 -152 minecraft:water[level=0]
setblock 386 54 -152 minecraft:kelp_plant
fill 387 54 -152 390 54 -152 minecraft:water[level=0]
setblock 391 54 -152 minecraft:kelp_plant
fill 329 54 -153 339 54 -153 minecraft:water[level=0]
setblock 340 54 -153 minecraft:seagrass
setblock 341 54 -153 minecraft:tall_seagrass[half=lower]
setblock 342 54 -153 minecraft:water[level=0]
setblock 343 54 -153 minecraft:seagrass
fill 344 54 -153 346 54 -153 minecraft:water[level=0]
fill 351 54 -153 358 54 -153 minecraft:water[level=0]
setblock 359 54 -153 minecraft:seagrass
fill 360 54 -153 361 54 -153 minecraft:tall_seagrass[half=lower]
fill 362 54 -153 363 54 -153 minecraft:water[level=0]
setblock 364 54 -153 minecraft:tall_seagrass[half=lower]
fill 365 54 -153 369 54 -153 minecraft:water[level=0]
setblock 370 54 -153 minecraft:kelp_plant
setblock 371 54 -153 minecraft:water[level=0]
setblock 372 54 -153 minecraft:kelp_plant
fill 373 54 -153 380 54 -153 minecraft:water[level=0]
fill 381 54 -153 382 54 -153 minecraft:kelp_plant
setblock 383 54 -153 minecraft:water[level=0]
fill 384 54 -153 386 54 -153 minecraft:kelp_plant
fill 387 54 -153 389 54 -153 minecraft:water[level=0]
setblock 390 54 -153 minecraft:kelp_plant
setblock 391 54 -153 minecraft:water[level=0]
fill 329 54 -154 339 54 -154 minecraft:water[level=0]
setblock 340 54 -154 minecraft:seagrass
fill 341 54 -154 362 54 -154 minecraft:water[level=0]
setblock 363 54 -154 minecraft:tall_seagrass[half=lower]
fill 364 54 -154 372 54 -154 minecraft:water[level=0]
setblock 373 54 -154 minecraft:kelp_plant
fill 374 54 -154 375 54 -154 minecraft:water[level=0]
setblock 376 54 -154 minecraft:kelp_plant
fill 377 54 -154 379 54 -154 minecraft:water[level=0]
setblock 382 54 -154 minecraft:water[level=0]
fill 387 54 -154 391 54 -154 minecraft:water[level=0]
fill 329 54 -155 338 54 -155 minecraft:water[level=0]
setblock 339 54 -155 minecraft:seagrass
setblock 340 54 -155 minecraft:tall_seagrass[half=lower]
fill 341 54 -155 344 54 -155 minecraft:water[level=0]
setblock 345 54 -155 minecraft:seagrass
fill 346 54 -155 358 54 -155 minecraft:water[level=0]
setblock 359 54 -155 minecraft:tall_seagrass[half=lower]
setblock 360 54 -155 minecraft:water[level=0]
setblock 361 54 -155 minecraft:seagrass
fill 362 54 -155 364 54 -155 minecraft:water[level=0]
setblock 365 54 -155 minecraft:tall_seagrass[half=upper]
fill 366 54 -155 376 54 -155 minecraft:water[level=0]
fill 377 54 -155 378 54 -155 minecraft:kelp_plant
setblock 383 54 -155 minecraft:water[level=0]
fill 386 54 -155 391 54 -155 minecraft:water[level=0]
fill 329 54 -156 353 54 -156 minecraft:water[level=0]
setblock 354 54 -156 minecraft:seagrass
fill 355 54 -156 356 54 -156 minecraft:water[level=0]
setblock 357 54 -156 minecraft:seagrass
fill 358 54 -156 359 54 -156 minecraft:water[level=0]
setblock 360 54 -156 minecraft:seagrass
setblock 361 54 -156 minecraft:tall_seagrass[half=upper]
fill 362 54 -156 368 54 -156 minecraft:water[level=0]
setblock 369 54 -156 minecraft:kelp_plant
fill 370 54 -156 372 54 -156 minecraft:water[level=0]
setblock 373 54 -156 minecraft:kelp_plant
fill 374 54 -156 377 54 -156 minecraft:water[level=0]
fill 384 54 -156 391 54 -156 minecraft:water[level=0]
fill 332 54 -157 355 54 -157 minecraft:water[level=0]
setblock 356 54 -157 minecraft:seagrass
fill 357 54 -157 368 54 -157 minecraft:water[level=0]
setblock 369 54 -157 minecraft:kelp_plant
fill 370 54 -157 376 54 -157 minecraft:water[level=0]
setblock 377 54 -157 minecraft:kelp_plant
fill 385 54 -157 390 54 -157 minecraft:water[level=0]
setblock 391 54 -157 minecraft:kelp_plant
fill 332 54 -158 356 54 -158 minecraft:water[level=0]
setblock 357 54 -158 minecraft:tall_seagrass[half=lower]
setblock 358 54 -158 minecraft:water[level=0]
setblock 359 54 -158 minecraft:tall_seagrass[half=lower]
fill 360 54 -158 378 54 -158 minecraft:water[level=0]
setblock 382 54 -158 minecraft:water[level=0]
fill 385 54 -158 391 54 -158 minecraft:water[level=0]
fill 332 54 -159 352 54 -159 minecraft:water[level=0]
setblock 353 54 -159 minecraft:seagrass
fill 354 54 -159 355 54 -159 minecraft:water[level=0]
fill 356 54 -159 357 54 -159 minecraft:seagrass
fill 358 54 -159 369 54 -159 minecraft:water[level=0]
fill 370 54 -159 371 54 -159 minecraft:kelp_plant
fill 372 54 -159 374 54 -159 minecraft:water[level=0]
setblock 375 54 -159 minecraft:kelp_plant
setblock 376 54 -159 minecraft:water[level=0]
setblock 379 54 -159 minecraft:water[level=0]
fill 381 54 -159 386 54 -159 minecraft:water[level=0]
setblock 387 54 -159 minecraft:kelp_plant
fill 388 54 -159 391 54 -159 minecraft:water[level=0]
fill 332 54 -160 355 54 -160 minecraft:water[level=0]
setblock 356 54 -160 minecraft:seagrass
fill 357 54 -160 358 54 -160 minecraft:water[level=0]
setblock 359 54 -160 minecraft:seagrass
fill 360 54 -160 369 54 -160 minecraft:water[level=0]
fill 370 54 -160 371 54 -160 minecraft:kelp_plant
fill 372 54 -160 375 54 -160 minecraft:water[level=0]
setblock 376 54 -160 minecraft:kelp_plant
fill 377 54 -160 389 54 -160 minecraft:water[level=0]
setblock 390 54 -160 minecraft:kelp_plant
setblock 391 54 -160 minecraft:water[level=0]
fill 332 54 -161 352 54 -161 minecraft:water[level=0]
setblock 353 54 -161 minecraft:seagrass
fill 354 54 -161 356 54 -161 minecraft:water[level=0]
setblock 357 54 -161 minecraft:seagrass
fill 358 54 -161 359 54 -161 minecraft:water[level=0]
setblock 360 54 -161 minecraft:tall_seagrass[half=lower]
fill 361 54 -161 366 54 -161 minecraft:water[level=0]
fill 367 54 -161 368 54 -161 minecraft:kelp_plant
setblock 369 54 -161 minecraft:water[level=0]
fill 370 54 -161 372 54 -161 minecraft:kelp_plant
fill 373 54 -161 376 54 -161 minecraft:water[level=0]
setblock 377 54 -161 minecraft:kelp_plant
fill 378 54 -161 388 54 -161 minecraft:water[level=0]
setblock 389 54 -161 minecraft:kelp_plant
fill 390 54 -161 391 54 -161 minecraft:water[level=0]
fill 332 54 -162 352 54 -162 minecraft:water[level=0]
fill 353 54 -162 354 54 -162 minecraft:seagrass
fill 355 54 -162 359 54 -162 minecraft:water[level=0]
setblock 360 54 -162 minecraft:seagrass
fill 361 54 -162 369 54 -162 minecraft:water[level=0]
fill 370 54 -162 371 54 -162 minecraft:kelp_plant
setblock 372 54 -162 minecraft:water[level=0]
setblock 373 54 -162 minecraft:kelp_plant
fill 374 54 -162 377 54 -162 minecraft:water[level=0]
setblock 378 54 -162 minecraft:kelp_plant
fill 381 54 -162 384 54 -162 minecraft:water[level=0]
setblock 385 54 -162 minecraft:kelp_plant
fill 386 54 -162 391 54 -162 minecraft:water[level=0]
fill 332 54 -163 353 54 -163 minecraft:water[level=0]
setblock 354 54 -163 minecraft:tall_seagrass[half=lower]
fill 355 54 -163 357 54 -163 minecraft:water[level=0]
setblock 358 54 -163 minecraft:seagrass
setblock 359 54 -163 minecraft:tall_seagrass[half=lower]
fill 360 54 -163 370 54 -163 minecraft:water[level=0]
setblock 371 54 -163 minecraft:kelp_plant
fill 372 54 -163 376 54 -163 minecraft:water[level=0]
fill 382 54 -163 391 54 -163 minecraft:water[level=0]
fill 332 54 -164 352 54 -164 minecraft:water[level=0]
setblock 353 54 -164 minecraft:seagrass
fill 354 54 -164 355 54 -164 minecraft:water[level=0]
setblock 356 54 -164 minecraft:seagrass
setblock 357 54 -164 minecraft:water[level=0]
setblock 358 54 -164 minecraft:seagrass
fill 359 54 -164 368 54 -164 minecraft:water[level=0]
setblock 369 54 -164 minecraft:kelp_plant
fill 370 54 -164 371 54 -164 minecraft:water[level=0]
fill 372 54 -164 373 54 -164 minecraft:kelp_plant
setblock 374 54 -164 minecraft:tall_seagrass[half=lower]
setblock 375 54 -164 minecraft:water[level=0]
fill 382 54 -164 391 54 -164 minecraft:water[level=0]
fill 332 54 -165 354 54 -165 minecraft:water[level=0]
setblock 355 54 -165 minecraft:seagrass
fill 356 54 -165 358 54 -165 minecraft:water[level=0]
setblock 359 54 -165 minecraft:seagrass
setblock 360 54 -165 minecraft:water[level=0]
setblock 361 54 -165 minecraft:seagrass
setblock 362 54 -165 minecraft:water[level=0]
setblock 363 54 -165 minecraft:tall_seagrass[half=upper]
setblock 364 54 -165 minecraft:kelp_plant
fill 365 54 -165 375 54 -165 minecraft:water[level=0]
fill 383 54 -165 391 54 -165 minecraft:water[level=0]
fill 332 54 -166 351 54 -166 minecraft:water[level=0]
setblock 352 54 -166 minecraft:tall_seagrass[half=lower]
fill 353 54 -166 354 54 -166 minecraft:water[level=0]
setblock 355 54 -166 minecraft:seagrass
fill 356 54 -166 358 54 -166 minecraft:water[level=0]
setblock 359 54 -166 minecraft:seagrass
fill 360 54 -166 368 54 -166 minecraft:water[level=0]
setblock 369 54 -166 minecraft:tall_seagrass[half=upper]
fill 370 54 -166 375 54 -166 minecraft:water[level=0]
fill 384 54 -166 391 54 -166 minecraft:water[level=0]
fill 335 54 -167 349 54 -167 minecraft:water[level=0]
fill 350 54 -167 351 54 -167 minecraft:seagrass
setblock 352 54 -167 minecraft:water[level=0]
setblock 353 54 -167 minecraft:seagrass
setblock 354 54 -167 minecraft:water[level=0]
setblock 355 54 -167 minecraft:seagrass
setblock 356 54 -167 minecraft:water[level=0]
setblock 357 54 -167 minecraft:seagrass
fill 358 54 -167 367 54 -167 minecraft:water[level=0]
setblock 368 54 -167 minecraft:tall_seagrass[half=upper]
fill 369 54 -167 370 54 -167 minecraft:water[level=0]
setblock 371 54 -167 minecraft:tall_seagrass[half=lower]
setblock 372 54 -167 minecraft:seagrass
setblock 373 54 -167 minecraft:water[level=0]
setblock 374 54 -167 minecraft:seagrass
setblock 384 54 -167 minecraft:kelp_plant
setblock 385 54 -167 minecraft:water[level=0]
setblock 386 54 -167 minecraft:kelp_plant
fill 387 54 -167 391 54 -167 minecraft:water[level=0]
fill 337 54 -168 356 54 -168 minecraft:water[level=0]
setblock 357 54 -168 minecraft:seagrass
fill 358 54 -168 367 54 -168 minecraft:water[level=0]
setblock 368 54 -168 minecraft:kelp_plant
setblock 369 54 -168 minecraft:tall_seagrass[half=lower]
fill 370 54 -168 372 54 -168 minecraft:water[level=0]
setblock 373 54 -168 minecraft:seagrass
setblock 374 54 -168 minecraft:tall_seagrass[half=lower]
fill 385 54 -168 391 54 -168 minecraft:water[level=0]
fill 332 54 -169 346 54 -169 minecraft:water[level=0]
setblock 347 54 -169 minecraft:tall_seagrass[half=upper]
fill 348 54 -169 350 54 -169 minecraft:water[level=0]
setblock 351 54 -169 minecraft:seagrass
setblock 352 54 -169 minecraft:kelp_plant
fill 353 54 -169 367 54 -169 minecraft:water[level=0]
setblock 368 54 -169 minecraft:seagrass
fill 369 54 -169 371 54 -169 minecraft:water[level=0]
setblock 372 54 -169 minecraft:seagrass
setblock 373 54 -169 minecraft:tall_seagrass[half=lower]
fill 385 54 -169 391 54 -169 minecraft:water[level=0]
fill 332 54 -170 351 54 -170 minecraft:water[level=0]
setblock 352 54 -170 minecraft:tall_seagrass[half=upper]
fill 353 54 -170 366 54 -170 minecraft:water[level=0]
setblock 367 54 -170 minecraft:tall_seagrass[half=lower]
setblock 368 54 -170 minecraft:kelp_plant
setblock 369 54 -170 minecraft:water[level=0]
setblock 370 54 -170 minecraft:kelp_plant
setblock 371 54 -170 minecraft:seagrass
fill 372 54 -170 373 54 -170 minecraft:water[level=0]
fill 385 54 -170 387 54 -170 minecraft:water[level=0]
setblock 388 54 -170 minecraft:tall_seagrass[half=upper]
fill 389 54 -170 390 54 -170 minecraft:water[level=0]
setblock 391 54 -170 minecraft:kelp_plant
fill 332 54 -171 354 54 -171 minecraft:water[level=0]
setblock 355 54 -171 minecraft:tall_seagrass[half=upper]
fill 356 54 -171 368 54 -171 minecraft:water[level=0]
fill 369 54 -171 370 54 -171 minecraft:kelp_plant
setblock 371 54 -171 minecraft:seagrass
setblock 372 54 -171 minecraft:kelp_plant
fill 385 54 -171 388 54 -171 minecraft:water[level=0]
setblock 389 54 -171 minecraft:tall_seagrass[half=upper]
fill 390 54 -171 391 54 -171 minecraft:water[level=0]
fill 332 54 -172 351 54 -172 minecraft:water[level=0]
setblock 352 54 -172 minecraft:kelp_plant
fill 353 54 -172 356 54 -172 minecraft:water[level=0]
setblock 357 54 -172 minecraft:kelp_plant
fill 358 54 -172 365 54 -172 minecraft:water[level=0]
setblock 366 54 -172 minecraft:tall_seagrass[half=lower]
setblock 367 54 -172 minecraft:water[level=0]
setblock 368 54 -172 minecraft:kelp_plant
fill 369 54 -172 370 54 -172 minecraft:water[level=0]
setblock 371 54 -172 minecraft:kelp_plant
fill 385 54 -172 386 54 -172 minecraft:water[level=0]
setblock 387 54 -172 minecraft:kelp_plant
setblock 388 54 -172 minecraft:water[level=0]
setblock 389 54 -172 minecraft:tall_seagrass[half=upper]
fill 390 54 -172 391 54 -172 minecraft:water[level=0]
fill 332 54 -173 367 54 -173 minecraft:water[level=0]
setblock 368 54 -173 minecraft:kelp_plant
fill 369 54 -173 370 54 -173 minecraft:seagrass
setblock 385 54 -173 minecraft:water[level=0]
setblock 386 54 -173 minecraft:kelp_plant
fill 387 54 -173 391 54 -173 minecraft:water[level=0]
fill 332 54 -174 358 54 -174 minecraft:water[level=0]
setblock 359 54 -174 minecraft:kelp_plant
fill 360 54 -174 366 54 -174 minecraft:water[level=0]
setblock 367 54 -174 minecraft:kelp_plant
setblock 368 54 -174 minecraft:water[level=0]
setblock 369 54 -174 minecraft:kelp_plant
setblock 370 54 -174 minecraft:water[level=0]
setblock 385 54 -174 minecraft:water[level=0]
setblock 386 54 -174 minecraft:seagrass
setblock 387 54 -174 minecraft:water[level=0]
fill 388 54 -174 389 54 -174 minecraft:kelp_plant
fill 390 54 -174 391 54 -174 minecraft:water[level=0]
fill 332 54 -175 356 54 -175 minecraft:water[level=0]
setblock 357 54 -175 minecraft:kelp_plant
fill 358 54 -175 366 54 -175 minecraft:water[level=0]
fill 367 54 -175 368 54 -175 minecraft:kelp_plant
setblock 369 54 -175 minecraft:water[level=0]
setblock 386 54 -175 minecraft:water[level=0]
setblock 387 54 -175 minecraft:kelp_plant
fill 388 54 -175 391 54 -175 minecraft:water[level=0]
fill 332 54 -176 367 54 -176 minecraft:water[level=0]
setblock 368 54 -176 minecraft:seagrass
setblock 386 54 -176 minecraft:water[level=0]
setblock 387 54 -176 minecraft:kelp_plant
setblock 388 54 -176 minecraft:water[level=0]
setblock 389 54 -176 minecraft:kelp_plant
fill 390 54 -176 391 54 -176 minecraft:water[level=0]
fill 332 54 -177 363 54 -177 minecraft:water[level=0]
fill 364 54 -177 365 54 -177 minecraft:kelp_plant
setblock 366 54 -177 minecraft:water[level=0]
fill 367 54 -177 368 54 -177 minecraft:kelp_plant
fill 386 54 -177 388 54 -177 minecraft:water[level=0]
setblock 389 54 -177 minecraft:kelp_plant
fill 390 54 -177 391 54 -177 minecraft:water[level=0]
fill 332 54 -178 356 54 -178 minecraft:water[level=0]
setblock 357 54 -178 minecraft:kelp_plant
fill 358 54 -178 363 54 -178 minecraft:water[level=0]
fill 364 54 -178 365 54 -178 minecraft:seagrass
setblock 366 54 -178 minecraft:water[level=0]
setblock 367 54 -178 minecraft:kelp_plant
fill 386 54 -178 391 54 -178 minecraft:water[level=0]
fill 332 54 -179 351 54 -179 minecraft:water[level=0]
setblock 352 54 -179 minecraft:kelp_plant
setblock 353 54 -179 minecraft:water[level=0]
setblock 354 54 -179 minecraft:kelp_plant
fill 355 54 -179 366 54 -179 minecraft:water[level=0]
setblock 387 54 -179 minecraft:kelp_plant
fill 388 54 -179 391 54 -179 minecraft:water[level=0]
fill 332 54 -180 353 54 -180 minecraft:water[level=0]
fill 354 54 -180 355 54 -180 minecraft:kelp_plant
fill 356 54 -180 359 54 -180 minecraft:water[level=0]
setblock 360 54 -180 minecraft:kelp_plant
setblock 361 54 -180 minecraft:water[level=0]
setblock 362 54 -180 minecraft:seagrass
setblock 363 54 -180 minecraft:tall_seagrass[half=lower]
fill 387 54 -180 391 54 -180 minecraft:water[level=0]
fill 332 54 -181 348 54 -181 minecraft:water[level=0]
setblock 349 54 -181 minecraft:kelp_plant
fill 350 54 -181 352 54 -181 minecraft:water[level=0]
setblock 353 54 -181 minecraft:kelp_plant
setblock 354 54 -181 minecraft:water[level=0]
setblock 355 54 -181 minecraft:kelp_plant
setblock 356 54 -181 minecraft:water[level=0]
setblock 357 54 -181 minecraft:kelp_plant
fill 358 54 -181 361 54 -181 minecraft:water[level=0]
setblock 362 54 -181 minecraft:seagrass
setblock 363 54 -181 minecraft:water[level=0]
setblock 376 54 -181 minecraft:water[level=0]
setblock 377 54 -181 minecraft:kelp_plant
setblock 378 54 -181 minecraft:seagrass
setblock 379 54 -181 minecraft:kelp_plant
fill 387 54 -181 389 54 -181 minecraft:water[level=0]
setblock 390 54 -181 minecraft:kelp_plant
setblock 391 54 -181 minecraft:water[level=0]
fill 332 54 -182 336 54 -182 minecraft:water[level=0]
setblock 337 54 -182 minecraft:kelp_plant
fill 338 54 -182 352 54 -182 minecraft:water[level=0]
fill 353 54 -182 354 54 -182 minecraft:kelp_plant
setblock 355 54 -182 minecraft:water[level=0]
setblock 356 54 -182 minecraft:kelp_plant
fill 357 54 -182 359 54 -182 minecraft:water[level=0]
fill 360 54 -182 362 54 -182 minecraft:kelp_plant
setblock 363 54 -182 minecraft:water[level=0]
fill 374 54 -182 376 54 -182 minecraft:water[level=0]
setblock 377 54 -182 minecraft:kelp_plant
setblock 378 54 -182 minecraft:tall_seagrass[half=upper]
setblock 379 54 -182 minecraft:water[level=0]
setblock 380 54 -182 minecraft:kelp_plant
setblock 386 54 -182 minecraft:water[level=0]
setblock 387 54 -182 minecraft:kelp_plant
fill 388 54 -182 391 54 -182 minecraft:water[level=0]
fill 332 54 -183 346 54 -183 minecraft:water[level=0]
setblock 347 54 -183 minecraft:kelp_plant
fill 348 54 -183 359 54 -183 minecraft:water[level=0]
setblock 360 54 -183 minecraft:kelp_plant
setblock 361 54 -183 minecraft:water[level=0]
fill 362 54 -183 363 54 -183 minecraft:seagrass
fill 375 54 -183 377 54 -183 minecraft:water[level=0]
setblock 378 54 -183 minecraft:kelp_plant
fill 379 54 -183 380 54 -183 minecraft:seagrass
setblock 386 54 -183 minecraft:water[level=0]
setblock 387 54 -183 minecraft:kelp_plant
setblock 388 54 -183 minecraft:seagrass
fill 389 54 -183 391 54 -183 minecraft:water[level=0]
fill 332 54 -184 345 54 -184 minecraft:water[level=0]
setblock 346 54 -184 minecraft:kelp_plant
fill 347 54 -184 348 54 -184 minecraft:water[level=0]
setblock 349 54 -184 minecraft:kelp_plant
fill 350 54 -184 359 54 -184 minecraft:water[level=0]
fill 360 54 -184 361 54 -184 minecraft:kelp_plant
setblock 375 54 -184 minecraft:water[level=0]
setblock 376 54 -184 minecraft:kelp_plant
setblock 377 54 -184 minecraft:tall_seagrass[half=upper]
fill 378 54 -184 379 54 -184 minecraft:water[level=0]
setblock 386 54 -184 minecraft:water[level=0]
fill 387 54 -184 389 54 -184 minecraft:kelp_plant
fill 390 54 -184 391 54 -184 minecraft:water[level=0]
fill 332 54 -185 340 54 -185 minecraft:water[level=0]
setblock 341 54 -185 minecraft:kelp[age=25]
fill 342 54 -185 356 54 -185 minecraft:water[level=0]
setblock 357 54 -185 minecraft:kelp_plant
fill 358 54 -185 359 54 -185 minecraft:water[level=0]
fill 386 54 -185 391 54 -185 minecraft:water[level=0]
fill 332 54 -186 341 54 -186 minecraft:water[level=0]
setblock 342 54 -186 minecraft:kelp_plant
fill 343 54 -186 345 54 -186 minecraft:water[level=0]
setblock 346 54 -186 minecraft:tall_seagrass[half=upper]
fill 347 54 -186 357 54 -186 minecraft:water[level=0]
setblock 386 54 -186 minecraft:water[level=0]
setblock 387 54 -186 minecraft:seagrass
fill 388 54 -186 390 54 -186 minecraft:water[level=0]
setblock 391 54 -186 minecraft:kelp_plant
fill 332 54 -187 353 54 -187 minecraft:water[level=0]
setblock 354 54 -187 minecraft:kelp_plant
setblock 355 54 -187 minecraft:water[level=0]
fill 386 54 -187 387 54 -187 minecraft:water[level=0]
setblock 388 54 -187 minecraft:kelp_plant
fill 389 54 -187 390 54 -187 minecraft:water[level=0]
setblock 391 54 -187 minecraft:kelp_plant
fill 332 54 -188 345 54 -188 minecraft:water[level=0]
setblock 346 54 -188 minecraft:tall_seagrass[half=upper]
fill 347 54 -188 348 54 -188 minecraft:water[level=0]
setblock 349 54 -188 minecraft:tall_seagrass[half=upper]
fill 350 54 -188 352 54 -188 minecraft:water[level=0]
setblock 353 54 -188 minecraft:kelp_plant
setblock 354 54 -188 minecraft:water[level=0]
fill 386 54 -188 391 54 -188 minecraft:water[level=0]
fill 332 54 -189 351 54 -189 minecraft:water[level=0]
setblock 352 54 -189 minecraft:kelp_plant
fill 353 54 -189 355 54 -189 minecraft:water[level=0]
fill 386 54 -189 391 54 -189 minecraft:water[level=0]
fill 333 54 -190 347 54 -190 minecraft:water[level=0]
setblock 348 54 -190 minecraft:tall_seagrass[half=upper]
setblock 349 54 -190 minecraft:tall_seagrass[half=lower]
fill 350 54 -190 355 54 -190 minecraft:water[level=0]
setblock 386 54 -190 minecraft:water[level=0]
fill 387 54 -190 388 54 -190 minecraft:kelp_plant
fill 389 54 -190 391 54 -190 minecraft:water[level=0]
fill 351 53 -127 352 53 -127 minecraft:water[level=0]
setblock 353 53 -127 minecraft:tall_seagrass[half=lower]
setblock 354 53 -127 minecraft:kelp_plant
fill 355 53 -127 357 53 -127 minecraft:water[level=0]
setblock 358 53 -127 minecraft:seagrass
fill 359 53 -127 360 53 -127 minecraft:water[level=0]
setblock 361 53 -127 minecraft:kelp_plant
setblock 362 53 -127 minecraft:water[level=0]
setblock 363 53 -127 minecraft:seagrass
fill 364 53 -127 368 53 -127 minecraft:water[level=0]
setblock 369 53 -127 minecraft:kelp_plant
fill 370 53 -127 372 53 -127 minecraft:water[level=0]
setblock 373 53 -127 minecraft:kelp_plant
fill 374 53 -127 383 53 -127 minecraft:water[level=0]
fill 384 53 -127 385 53 -127 minecraft:kelp_plant
fill 386 53 -127 390 53 -127 minecraft:water[level=0]
setblock 391 53 -127 minecraft:kelp_plant
fill 351 53 -128 352 53 -128 minecraft:water[level=0]
setblock 353 53 -128 minecraft:seagrass
setblock 354 53 -128 minecraft:water[level=0]
setblock 355 53 -128 minecraft:kelp_plant
setblock 356 53 -128 minecraft:water[level=0]
setblock 357 53 -128 minecraft:kelp_plant
setblock 358 53 -128 minecraft:seagrass
setblock 359 53 -128 minecraft:water[level=0]
setblock 360 53 -128 minecraft:kelp_plant
fill 361 53 -128 366 53 -128 minecraft:water[level=0]
setblock 367 53 -128 minecraft:kelp_plant
fill 368 53 -128 369 53 -128 minecraft:water[level=0]
setblock 370 53 -128 minecraft:kelp_plant
setblock 371 53 -128 minecraft:water[level=0]
fill 372 53 -128 373 53 -128 minecraft:kelp_plant
setblock 374 53 -128 minecraft:water[level=0]
fill 375 53 -128 376 53 -128 minecraft:kelp_plant
setblock 377 53 -128 minecraft:water[level=0]
fill 378 53 -128 380 53 -128 minecraft:kelp_plant
fill 381 53 -128 386 53 -128 minecraft:water[level=0]
setblock 387 53 -128 minecraft:kelp_plant
fill 388 53 -128 391 53 -128 minecraft:water[level=0]
fill 353 53 -129 355 53 -129 minecraft:water[level=0]
setblock 356 53 -129 minecraft:seagrass
fill 357 53 -129 358 53 -129 minecraft:water[level=0]
setblock 359 53 -129 minecraft:kelp_plant
fill 360 53 -129 368 53 -129 minecraft:water[level=0]
setblock 369 53 -129 minecraft:kelp_plant
fill 370 53 -129 376 53 -129 minecraft:water[level=0]
setblock 377 53 -129 minecraft:kelp_plant
fill 378 53 -129 382 53 -129 minecraft:water[level=0]
setblock 383 53 -129 minecraft:kelp_plant
setblock 384 53 -129 minecraft:water[level=0]
setblock 385 53 -129 minecraft:kelp_plant
setblock 386 53 -129 minecraft:water[level=0]
setblock 387 53 -129 minecraft:kelp_plant
fill 388 53 -129 389 53 -129 minecraft:water[level=0]
setblock 390 53 -129 minecraft:kelp_plant
setblock 391 53 -129 minecraft:water[level=0]
setblock 328 53 -130 minecraft:tall_seagrass[half=lower]
setblock 329 53 -130 minecraft:water[level=0]
setblock 358 53 -130 minecraft:seagrass
fill 359 53 -130 362 53 -130 minecraft:water[level=0]
setblock 363 53 -130 minecraft:kelp_plant
fill 364 53 -130 365 53 -130 minecraft:water[level=0]
setblock 366 53 -130 minecraft:kelp_plant
fill 367 53 -130 368 53 -130 minecraft:water[level=0]
setblock 369 53 -130 minecraft:kelp_plant
fill 370 53 -130 391 53 -130 minecraft:water[level=0]
setblock 328 53 -131 minecraft:kelp_plant
setblock 329 53 -131 minecraft:water[level=0]
setblock 330 53 -131 minecraft:tall_seagrass[half=lower]
fill 331 53 -131 332 53 -131 minecraft:water[level=0]
setblock 338 53 -131 minecraft:water[level=0]
setblock 359 53 -131 minecraft:seagrass
fill 360 53 -131 367 53 -131 minecraft:water[level=0]
setblock 368 53 -131 minecraft:kelp_plant
setblock 369 53 -131 minecraft:tall_seagrass[half=upper]
fill 370 53 -131 391 53 -131 minecraft:water[level=0]
setblock 328 53 -132 minecraft:water[level=0]
setblock 329 53 -132 minecraft:tall_seagrass[half=upper]
fill 330 53 -132 331 53 -132 minecraft:tall_seagrass[half=lower]
setblock 332 53 -132 minecraft:seagrass
setblock 333 53 -132 minecraft:water[level=0]
setblock 334 53 -132 minecraft:tall_seagrass[half=lower]
fill 335 53 -132 338 53 -132 minecraft:water[level=0]
fill 360 53 -132 362 53 -132 minecraft:water[level=0]
setblock 363 53 -132 minecraft:kelp_plant
fill 364 53 -132 377 53 -132 minecraft:water[level=0]
setblock 378 53 -132 minecraft:kelp_plant
fill 379 53 -132 382 53 -132 minecraft:water[level=0]
setblock 383 53 -132 minecraft:kelp_plant
setblock 384 53 -132 minecraft:water[level=0]
setblock 385 53 -132 minecraft:kelp_plant
setblock 386 53 -132 minecraft:water[level=0]
fill 387 53 -132 388 53 -132 minecraft:kelp_plant
fill 389 53 -132 391 53 -132 minecraft:water[level=0]
fill 328 53 -133 334 53 -133 minecraft:water[level=0]
setblock 335 53 -133 minecraft:seagrass
fill 336 53 -133 339 53 -133 minecraft:water[level=0]
fill 360 53 -133 381 53 -133 minecraft:water[level=0]
setblock 382 53 -133 minecraft:kelp_plant
fill 383 53 -133 387 53 -133 minecraft:water[level=0]
setblock 388 53 -133 minecraft:kelp_plant
fill 389 53 -133 391 53 -133 minecraft:water[level=0]
fill 328 53 -134 336 53 -134 minecraft:water[level=0]
setblock 337 53 -134 minecraft:kelp_plant
fill 338 53 -134 340 53 -134 minecraft:water[level=0]
fill 360 53 -134 367 53 -134 minecraft:water[level=0]
fill 368 53 -134 369 53 -134 minecraft:kelp_plant
fill 370 53 -134 371 53 -134 minecraft:water[level=0]
setblock 372 53 -134 minecraft:kelp_plant
fill 373 53 -134 376 53 -134 minecraft:water[level=0]
setblock 377 53 -134 minecraft:kelp_plant
fill 378 53 -134 382 53 -134 minecraft:water[level=0]
fill 383 53 -134 385 53 -134 minecraft:kelp_plant
fill 386 53 -134 391 53 -134 minecraft:water[level=0]
fill 328 53 -135 331 53 -135 minecraft:water[level=0]
setblock 332 53 -135 minecraft:kelp_plant
fill 333 53 -135 336 53 -135 minecraft:water[level=0]
setblock 337 53 -135 minecraft:kelp_plant
fill 338 53 -135 340 53 -135 minecraft:water[level=0]
setblock 341 53 -135 minecraft:water[level=8]
setblock 360 53 -135 minecraft:water[level=0]
setblock 361 53 -135 minecraft:tall_seagrass[half=lower]
fill 362 53 -135 376 53 -135 minecraft:water[level=0]
setblock 377 53 -135 minecraft:kelp_plant
fill 378 53 -135 379 53 -135 minecraft:water[level=0]
setblock 380 53 -135 minecraft:kelp_plant
fill 381 53 -135 384 53 -135 minecraft:water[level=0]
setblock 385 53 -135 minecraft:kelp_plant
fill 386 53 -135 391 53 -135 minecraft:water[level=0]
fill 328 53 -136 340 53 -136 minecraft:water[level=0]
fill 360 53 -136 361 53 -136 minecraft:water[level=0]
setblock 362 53 -136 minecraft:kelp_plant
fill 363 53 -136 364 53 -136 minecraft:water[level=0]
setblock 365 53 -136 minecraft:kelp_plant
fill 366 53 -136 374 53 -136 minecraft:water[level=0]
setblock 375 53 -136 minecraft:kelp_plant
fill 376 53 -136 377 53 -136 minecraft:water[level=0]
setblock 378 53 -136 minecraft:kelp_plant
fill 379 53 -136 381 53 -136 minecraft:water[level=0]
setblock 382 53 -136 minecraft:kelp_plant
fill 383 53 -136 384 53 -136 minecraft:water[level=0]
setblock 385 53 -136 minecraft:kelp_plant
fill 386 53 -136 387 53 -136 minecraft:water[level=0]
fill 388 53 -136 389 53 -136 minecraft:kelp_plant
fill 390 53 -136 391 53 -136 minecraft:water[level=0]
setblock 328 53 -137 minecraft:kelp_plant
fill 329 53 -137 330 53 -137 minecraft:water[level=0]
setblock 331 53 -137 minecraft:kelp_plant
fill 332 53 -137 339 53 -137 minecraft:water[level=0]
setblock 340 53 -137 minecraft:water[level=8]
fill 360 53 -137 367 53 -137 minecraft:water[level=0]
setblock 368 53 -137 minecraft:kelp_plant
fill 369 53 -137 381 53 -137 minecraft:water[level=0]
setblock 382 53 -137 minecraft:kelp_plant
fill 383 53 -137 384 53 -137 minecraft:water[level=0]
setblock 385 53 -137 minecraft:kelp_plant
fill 386 53 -137 391 53 -137 minecraft:water[level=0]
fill 328 53 -138 338 53 -138 minecraft:water[level=0]
fill 360 53 -138 366 53 -138 minecraft:water[level=0]
setblock 367 53 -138 minecraft:kelp_plant
fill 368 53 -138 384 53 -138 minecraft:water[level=0]
fill 385 53 -138 386 53 -138 minecraft:kelp_plant
fill 387 53 -138 388 53 -138 minecraft:water[level=0]
setblock 389 53 -138 minecraft:kelp_plant
fill 390 53 -138 391 53 -138 minecraft:water[level=0]
fill 328 53 -139 334 53 -139 minecraft:water[level=0]
setblock 335 53 -139 minecraft:tall_seagrass[half=lower]
fill 336 53 -139 337 53 -139 minecraft:seagrass
setblock 360 53 -139 minecraft:kelp_plant
fill 361 53 -139 371 53 -139 minecraft:water[level=0]
setblock 372 53 -139 minecraft:kelp_plant
fill 373 53 -139 383 53 -139 minecraft:water[level=0]
setblock 384 53 -139 minecraft:kelp_plant
fill 385 53 -139 391 53 -139 minecraft:water[level=0]
setblock 328 53 -140 minecraft:water[level=0]
setblock 336 53 -140 minecraft:water[level=0]
fill 360 53 -140 368 53 -140 minecraft:water[level=0]
setblock 369 53 -140 minecraft:kelp_plant
setblock 370 53 -140 minecraft:water[level=0]
setblock 371 53 -140 minecraft:kelp_plant
fill 372 53 -140 377 53 -140 minecraft:water[level=0]
setblock 378 53 -140 minecraft:kelp_plant
fill 379 53 -140 380 53 -140 minecraft:water[level=0]
setblock 381 53 -140 minecraft:kelp_plant
fill 382 53 -140 391 53 -140 minecraft:water[level=0]
setblock 328 53 -141 minecraft:water[level=0]
fill 360 53 -141 368 53 -141 minecraft:water[level=0]
setblock 369 53 -141 minecraft:kelp_plant
fill 370 53 -141 378 53 -141 minecraft:water[level=0]
setblock 379 53 -141 minecraft:kelp_plant
fill 380 53 -141 382 53 -141 minecraft:water[level=0]
setblock 383 53 -141 minecraft:kelp_plant
fill 384 53 -141 387 53 -141 minecraft:water[level=0]
fill 388 53 -141 389 53 -141 minecraft:kelp_plant
fill 390 53 -141 391 53 -141 minecraft:water[level=0]
fill 361 53 -142 367 53 -142 minecraft:water[level=0]
fill 368 53 -142 369 53 -142 minecraft:kelp_plant
setblock 370 53 -142 minecraft:water[level=0]
fill 371 53 -142 372 53 -142 minecraft:kelp_plant
fill 373 53 -142 391 53 -142 minecraft:water[level=0]
fill 361 53 -143 363 53 -143 minecraft:water[level=0]
setblock 364 53 -143 minecraft:tall_seagrass[half=lower]
fill 365 53 -143 377 53 -143 minecraft:water[level=0]
fill 378 53 -143 379 53 -143 minecraft:kelp_plant
fill 380 53 -143 382 53 -143 minecraft:water[level=0]
setblock 383 53 -143 minecraft:kelp_plant
fill 384 53 -143 385 53 -143 minecraft:water[level=0]
setblock 386 53 -143 minecraft:kelp_plant
fill 387 53 -143 391 53 -143 minecraft:water[level=0]
fill 332 53 -144 333 53 -144 minecraft:water[level=0]
setblock 362 53 -144 minecraft:water[level=0]
setblock 363 53 -144 minecraft:seagrass
fill 364 53 -144 370 53 -144 minecraft:water[level=0]
setblock 371 53 -144 minecraft:kelp_plant
fill 372 53 -144 377 53 -144 minecraft:water[level=0]
setblock 378 53 -144 minecraft:tall_seagrass[half=upper]
fill 379 53 -144 391 53 -144 minecraft:water[level=0]
fill 344 53 -145 348 53 -145 minecraft:water[level=0]
fill 362 53 -145 368 53 -145 minecraft:water[level=0]
fill 369 53 -145 370 53 -145 minecraft:kelp_plant
fill 371 53 -145 379 53 -145 minecraft:water[level=0]
setblock 380 53 -145 minecraft:seagrass
fill 381 53 -145 382 53 -145 minecraft:water[level=0]
setblock 383 53 -145 minecraft:seagrass
setblock 384 53 -145 minecraft:kelp_plant
setblock 385 53 -145 minecraft:water[level=0]
setblock 386 53 -145 minecraft:kelp_plant
fill 387 53 -145 388 53 -145 minecraft:water[level=0]
setblock 389 53 -145 minecraft:kelp_plant
fill 390 53 -145 391 53 -145 minecraft:water[level=0]
setblock 343 53 -146 minecraft:water[level=0]
setblock 344 53 -146 minecraft:tall_seagrass[half=upper]
fill 345 53 -146 348 53 -146 minecraft:water[level=0]
fill 363 53 -146 367 53 -146 minecraft:water[level=0]
setblock 368 53 -146 minecraft:kelp_plant
fill 369 53 -146 371 53 -146 minecraft:water[level=0]
setblock 372 53 -146 minecraft:kelp_plant
fill 373 53 -146 375 53 -146 minecraft:water[level=0]
setblock 376 53 -146 minecraft:seagrass
fill 377 53 -146 378 53 -146 minecraft:water[level=0]
fill 379 53 -146 380 53 -146 minecraft:seagrass
setblock 381 53 -146 minecraft:water[level=0]
fill 382 53 -146 384 53 -146 minecraft:seagrass
fill 385 53 -146 386 53 -146 minecraft:water[level=0]
setblock 387 53 -146 minecraft:seagrass
fill 388 53 -146 391 53 -146 minecraft:water[level=0]
fill 343 53 -147 346 53 -147 minecraft:water[level=0]
setblock 347 53 -147 minecraft:seagrass
fill 363 53 -147 365 53 -147 minecraft:water[level=0]
fill 366 53 -147 367 53 -147 minecraft:seagrass
setblock 368 53 -147 minecraft:water[level=0]
setblock 369 53 -147 minecraft:kelp_plant
fill 370 53 -147 372 53 -147 minecraft:water[level=0]
setblock 373 53 -147 minecraft:tall_seagrass[half=lower]
fill 374 53 -147 375 53 -147 minecraft:kelp_plant
setblock 376 53 -147 minecraft:tall_seagrass[half=lower]
setblock 377 53 -147 minecraft:water[level=0]
setblock 378 53 -147 minecraft:seagrass
setblock 379 53 -147 minecraft:water[level=0]
fill 380 53 -147 381 53 -147 minecraft:tall_seagrass[half=lower]
setblock 382 53 -147 minecraft:water[level=0]
fill 383 53 -147 384 53 -147 minecraft:seagrass
setblock 385 53 -147 minecraft:water[level=0]
setblock 386 53 -147 minecraft:kelp_plant
fill 387 53 -147 391 53 -147 minecraft:water[level=0]
setblock 342 53 -148 minecraft:seagrass
fill 343 53 -148 344 53 -148 minecraft:water[level=0]
setblock 345 53 -148 minecraft:seagrass
setblock 346 53 -148 minecraft:water[level=0]
setblock 347 53 -148 minecraft:tall_seagrass[half=lower]
fill 365 53 -148 374 53 -148 minecraft:water[level=0]
setblock 375 53 -148 minecraft:kelp_plant
fill 376 53 -148 377 53 -148 minecraft:water[level=0]
setblock 378 53 -148 minecraft:kelp_plant
setblock 379 53 -148 minecraft:seagrass
fill 380 53 -148 381 53 -148 minecraft:water[level=0]
fill 382 53 -148 384 53 -148 minecraft:seagrass
fill 385 53 -148 386 53 -148 minecraft:water[level=0]
setblock 387 53 -148 minecraft:kelp_plant
setblock 388 53 -148 minecraft:water[level=0]
setblock 389 53 -148 minecraft:kelp_plant
fill 390 53 -148 391 53 -148 minecraft:water[level=0]
fill 365 53 -149 368 53 -149 minecraft:water[level=0]
fill 369 53 -149 370 53 -149 minecraft:kelp_plant
fill 371 53 -149 377 53 -149 minecraft:water[level=0]
setblock 378 53 -149 minecraft:kelp_plant
setblock 379 53 -149 minecraft:seagrass
setblock 380 53 -149 minecraft:water[level=0]
fill 386 53 -149 388 53 -149 minecraft:water[level=0]
setblock 389 53 -149 minecraft:tall_seagrass[half=lower]
setblock 390 53 -149 minecraft:water[level=0]
setblock 391 53 -149 minecraft:kelp_plant
fill 365 53 -150 369 53 -150 minecraft:water[level=0]
fill 370 53 -150 371 53 -150 minecraft:kelp_plant
fill 372 53 -150 378 53 -150 minecraft:water[level=0]
fill 386 53 -150 388 53 -150 minecraft:water[level=0]
setblock 389 53 -150 minecraft:tall_seagrass[half=lower]
fill 390 53 -150 391 53 -150 minecraft:water[level=0]
fill 332 53 -151 334 53 -151 minecraft:water[level=0]
fill 366 53 -151 376 53 -151 minecraft:water[level=0]
fill 387 53 -151 391 53 -151 minecraft:water[level=0]
fill 332 53 -152 337 53 -152 minecraft:water[level=0]
setblock 367 53 -152 minecraft:water[level=0]
fill 368 53 -152 369 53 -152 minecraft:kelp_plant
setblock 370 53 -152 minecraft:water[level=0]
setblock 371 53 -152 minecraft:kelp_plant
setblock 372 53 -152 minecraft:water[level=0]
setblock 373 53 -152 minecraft:seagrass
fill 387 53 -152 388 53 -152 minecraft:seagrass
fill 389 53 -152 390 53 -152 minecraft:water[level=0]
setblock 391 53 -152 minecraft:kelp_plant
fill 332 53 -153 336 53 -153 minecraft:water[level=0]
fill 366 53 -153 369 53 -153 minecraft:water[level=0]
setblock 370 53 -153 minecraft:kelp_plant
setblock 371 53 -153 minecraft:water[level=0]
setblock 372 53 -153 minecraft:kelp_plant
setblock 373 53 -153 minecraft:water[level=0]
setblock 387 53 -153 minecraft:water[level=0]
setblock 388 53 -153 minecraft:seagrass
setblock 389 53 -153 minecraft:water[level=0]
setblock 390 53 -153 minecraft:kelp_plant
setblock 391 53 -153 minecraft:water[level=0]
fill 333 53 -154 336 53 -154 minecraft:water[level=0]
fill 365 53 -154 372 53 -154 minecraft:water[level=0]
fill 387 53 -154 391 53 -154 minecraft:water[level=0]
fill 362 53 -155 363 53 -155 minecraft:water[level=0]
setblock 364 53 -155 minecraft:seagrass
setblock 365 53 -155 minecraft:tall_seagrass[half=lower]
fill 366 53 -155 372 53 -155 minecraft:water[level=0]
fill 386 53 -155 391 53 -155 minecraft:water[level=0]
setblock 361 53 -156 minecraft:tall_seagrass[half=lower]
fill 362 53 -156 368 53 -156 minecraft:water[level=0]
setblock 369 53 -156 minecraft:kelp_plant
fill 370 53 -156 372 53 -156 minecraft:water[level=0]
setblock 386 53 -156 minecraft:water[level=0]
setblock 387 53 -156 minecraft:seagrass
fill 388 53 -156 391 53 -156 minecraft:water[level=0]
setblock 340 53 -157 minecraft:water[level=0]
setblock 360 53 -157 minecraft:water[level=0]
setblock 361 53 -157 minecraft:seagrass
fill 362 53 -157 368 53 -157 minecraft:water[level=0]
setblock 369 53 -157 minecraft:kelp_plant
fill 370 53 -157 372 53 -157 minecraft:water[level=0]
fill 387 53 -157 390 53 -157 minecraft:water[level=0]
setblock 391 53 -157 minecraft:kelp_plant
fill 337 53 -158 342 53 -158 minecraft:water[level=0]
fill 360 53 -158 373 53 -158 minecraft:water[level=0]
setblock 385 53 -158 minecraft:water[level=0]
fill 387 53 -158 391 53 -158 minecraft:water[level=0]
fill 336 53 -159 343 53 -159 minecraft:water[level=0]
fill 360 53 -159 361 53 -159 minecraft:water[level=0]
setblock 362 53 -159 minecraft:seagrass
fill 363 53 -159 369 53 -159 minecraft:water[level=0]
fill 370 53 -159 371 53 -159 minecraft:kelp_plant
fill 372 53 -159 373 53 -159 minecraft:water[level=0]
fill 385 53 -159 386 53 -159 minecraft:water[level=0]
setblock 387 53 -159 minecraft:kelp_plant
fill 388 53 -159 391 53 -159 minecraft:water[level=0]
fill 336 53 -160 346 53 -160 minecraft:water[level=0]
setblock 360 53 -160 minecraft:seagrass
fill 361 53 -160 364 53 -160 minecraft:water[level=0]
setblock 365 53 -160 minecraft:seagrass
fill 366 53 -160 369 53 -160 minecraft:water[level=0]
fill 370 53 -160 371 53 -160 minecraft:kelp_plant
fill 372 53 -160 373 53 -160 minecraft:water[level=0]
fill 384 53 -160 389 53 -160 minecraft:water[level=0]
setblock 390 53 -160 minecraft:kelp_plant
setblock 391 53 -160 minecraft:water[level=0]
fill 335 53 -161 345 53 -161 minecraft:water[level=0]
fill 361 53 -161 362 53 -161 minecraft:water[level=0]
setblock 363 53 -161 minecraft:seagrass
fill 364 53 -161 366 53 -161 minecraft:water[level=0]
fill 367 53 -161 368 53 -161 minecraft:kelp_plant
setblock 369 53 -161 minecraft:water[level=0]
fill 370 53 -161 372 53 -161 minecraft:kelp_plant
setblock 373 53 -161 minecraft:water[level=0]
fill 385 53 -161 388 53 -161 minecraft:water[level=0]
setblock 389 53 -161 minecraft:kelp_plant
fill 390 53 -161 391 53 -161 minecraft:water[level=0]
fill 334 53 -162 344 53 -162 minecraft:water[level=0]
setblock 361 53 -162 minecraft:water[level=0]
setblock 362 53 -162 minecraft:seagrass
fill 363 53 -162 369 53 -162 minecraft:water[level=0]
fill 370 53 -162 371 53 -162 minecraft:kelp_plant
setblock 372 53 -162 minecraft:water[level=0]
setblock 373 53 -162 minecraft:kelp_plant
setblock 385 53 -162 minecraft:kelp_plant
fill 386 53 -162 391 53 -162 minecraft:water[level=0]
fill 332 53 -163 344 53 -163 minecraft:water[level=0]
fill 362 53 -163 370 53 -163 minecraft:water[level=0]
setblock 371 53 -163 minecraft:kelp_plant
fill 372 53 -163 373 53 -163 minecraft:water[level=0]
fill 385 53 -163 391 53 -163 minecraft:water[level=0]
fill 332 53 -164 339 53 -164 minecraft:water[level=0]
fill 343 53 -164 344 53 -164 minecraft:water[level=0]
fill 362 53 -164 363 53 -164 minecraft:water[level=0]
setblock 364 53 -164 minecraft:seagrass
fill 365 53 -164 368 53 -164 minecraft:water[level=0]
setblock 369 53 -164 minecraft:kelp_plant
fill 370 53 -164 371 53 -164 minecraft:water[level=0]
fill 372 53 -164 373 53 -164 minecraft:kelp_plant
fill 385 53 -164 391 53 -164 minecraft:water[level=0]
setblock 362 53 -165 minecraft:water[level=0]
setblock 363 53 -165 minecraft:tall_seagrass[half=lower]
setblock 364 53 -165 minecraft:kelp_plant
fill 365 53 -165 368 53 -165 minecraft:water[level=0]
setblock 369 53 -165 minecraft:seagrass
fill 370 53 -165 372 53 -165 minecraft:water[level=0]
fill 385 53 -165 391 53 -165 minecraft:water[level=0]
fill 362 53 -166 363 53 -166 minecraft:water[level=0]
setblock 364 53 -166 minecraft:seagrass
fill 365 53 -166 368 53 -166 minecraft:water[level=0]
setblock 369 53 -166 minecraft:tall_seagrass[half=lower]
fill 370 53 -166 372 53 -166 minecraft:water[level=0]
fill 385 53 -166 391 53 -166 minecraft:water[level=0]
fill 362 53 -167 367 53 -167 minecraft:water[level=0]
setblock 368 53 -167 minecraft:tall_seagrass[half=lower]
fill 369 53 -167 370 53 -167 minecraft:water[level=0]
setblock 386 53 -167 minecraft:kelp_plant
fill 387 53 -167 389 53 -167 minecraft:water[level=0]
setblock 390 53 -167 minecraft:tall_seagrass[half=upper]
setblock 391 53 -167 minecraft:water[level=0]
fill 362 53 -168 365 53 -168 minecraft:water[level=0]
setblock 366 53 -168 minecraft:seagrass
setblock 367 53 -168 minecraft:water[level=0]
setblock 368 53 -168 minecraft:kelp_plant
fill 386 53 -168 391 53 -168 minecraft:water[level=0]
fill 339 53 -169 343 53 -169 minecraft:water[level=0]
setblock 344 53 -169 minecraft:seagrass
fill 345 53 -169 346 53 -169 minecraft:water[level=0]
setblock 347 53 -169 minecraft:tall_seagrass[half=lower]
setblock 348 53 -169 minecraft:water[level=0]
setblock 349 53 -169 minecraft:seagrass
fill 362 53 -169 367 53 -169 minecraft:water[level=0]
setblock 387 53 -169 minecraft:water[level=0]
setblock 388 53 -169 minecraft:seagrass
fill 389 53 -169 391 53 -169 minecraft:water[level=0]
fill 332 53 -170 344 53 -170 minecraft:water[level=0]
setblock 345 53 -170 minecraft:seagrass
fill 346 53 -170 351 53 -170 minecraft:water[level=0]
setblock 352 53 -170 minecraft:tall_seagrass[half=lower]
setblock 353 53 -170 minecraft:water[level=0]
setblock 354 53 -170 minecraft:seagrass
setblock 355 53 -170 minecraft:water[level=0]
fill 358 53 -170 366 53 -170 minecraft:water[level=0]
setblock 387 53 -170 minecraft:water[level=0]
setblock 388 53 -170 minecraft:tall_seagrass[half=lower]
setblock 389 53 -170 minecraft:water[level=0]
setblock 390 53 -170 minecraft:tall_seagrass[half=upper]
setblock 391 53 -170 minecraft:kelp_plant
fill 332 53 -171 346 53 -171 minecraft:water[level=0]
setblock 347 53 -171 minecraft:tall_seagrass[half=upper]
fill 348 53 -171 354 53 -171 minecraft:water[level=0]
setblock 355 53 -171 minecraft:tall_seagrass[half=lower]
setblock 356 53 -171 minecraft:water[level=0]
setblock 357 53 -171 minecraft:seagrass
fill 358 53 -171 365 53 -171 minecraft:water[level=0]
setblock 388 53 -171 minecraft:water[level=0]
setblock 389 53 -171 minecraft:tall_seagrass[half=lower]
fill 390 53 -171 391 53 -171 minecraft:water[level=0]
fill 332 53 -172 351 53 -172 minecraft:water[level=0]
setblock 352 53 -172 minecraft:kelp_plant
fill 353 53 -172 356 53 -172 minecraft:water[level=0]
setblock 357 53 -172 minecraft:kelp_plant
fill 358 53 -172 364 53 -172 minecraft:water[level=0]
setblock 389 53 -172 minecraft:tall_seagrass[half=lower]
fill 390 53 -172 391 53 -172 minecraft:water[level=0]
fill 332 53 -173 363 53 -173 minecraft:water[level=0]
fill 389 53 -173 391 53 -173 minecraft:water[level=0]
fill 332 53 -174 358 53 -174 minecraft:water[level=0]
setblock 359 53 -174 minecraft:kelp_plant
fill 360 53 -174 362 53 -174 minecraft:water[level=0]
setblock 389 53 -174 minecraft:kelp_plant
fill 390 53 -174 391 53 -174 minecraft:water[level=0]
fill 332 53 -175 356 53 -175 minecraft:water[level=0]
setblock 357 53 -175 minecraft:kelp_plant
fill 358 53 -175 362 53 -175 minecraft:water[level=0]
setblock 389 53 -175 minecraft:seagrass
fill 390 53 -175 391 53 -175 minecraft:water[level=0]
fill 332 53 -176 354 53 -176 minecraft:water[level=0]
fill 355 53 -176 356 53 -176 minecraft:tall_seagrass[half=upper]
fill 357 53 -176 361 53 -176 minecraft:water[level=0]
setblock 389 53 -176 minecraft:kelp_plant
fill 390 53 -176 391 53 -176 minecraft:water[level=0]
fill 332 53 -177 356 53 -177 minecraft:water[level=0]
setblock 357 53 -177 minecraft:seagrass
fill 358 53 -177 362 53 -177 minecraft:water[level=0]
setblock 389 53 -177 minecraft:kelp_plant
fill 390 53 -177 391 53 -177 minecraft:water[level=0]
fill 332 53 -178 356 53 -178 minecraft:water[level=0]
setblock 357 53 -178 minecraft:kelp_plant
fill 358 53 -178 361 53 -178 minecraft:water[level=0]
fill 389 53 -178 391 53 -178 minecraft:water[level=0]
fill 332 53 -179 351 53 -179 minecraft:water[level=0]
setblock 352 53 -179 minecraft:kelp_plant
setblock 353 53 -179 minecraft:water[level=0]
setblock 354 53 -179 minecraft:kelp_plant
fill 355 53 -179 358 53 -179 minecraft:water[level=0]
setblock 361 53 -179 minecraft:water[level=0]
fill 389 53 -179 391 53 -179 minecraft:water[level=0]
fill 332 53 -180 348 53 -180 minecraft:water[level=0]
setblock 349 53 -180 minecraft:tall_seagrass[half=upper]
fill 350 53 -180 353 53 -180 minecraft:water[level=0]
fill 354 53 -180 355 53 -180 minecraft:kelp_plant
fill 356 53 -180 358 53 -180 minecraft:water[level=0]
setblock 361 53 -180 minecraft:water[level=0]
fill 389 53 -180 391 53 -180 minecraft:water[level=0]
fill 332 53 -181 348 53 -181 minecraft:water[level=0]
setblock 349 53 -181 minecraft:kelp_plant
fill 350 53 -181 352 53 -181 minecraft:water[level=0]
setblock 353 53 -181 minecraft:kelp_plant
setblock 354 53 -181 minecraft:water[level=0]
setblock 355 53 -181 minecraft:kelp_plant
setblock 356 53 -181 minecraft:water[level=0]
setblock 357 53 -181 minecraft:kelp_plant
fill 373 53 -181 376 53 -181 minecraft:water[level=0]
setblock 389 53 -181 minecraft:water[level=0]
setblock 390 53 -181 minecraft:kelp_plant
setblock 391 53 -181 minecraft:water[level=0]
fill 332 53 -182 336 53 -182 minecraft:water[level=0]
setblock 337 53 -182 minecraft:kelp_plant
fill 338 53 -182 352 53 -182 minecraft:water[level=0]
fill 353 53 -182 354 53 -182 minecraft:kelp_plant
setblock 355 53 -182 minecraft:water[level=0]
setblock 356 53 -182 minecraft:kelp_plant
fill 373 53 -182 376 53 -182 minecraft:water[level=0]
setblock 377 53 -182 minecraft:kelp_plant
setblock 378 53 -182 minecraft:tall_seagrass[half=lower]
fill 389 53 -182 391 53 -182 minecraft:water[level=0]
fill 332 53 -183 346 53 -183 minecraft:water[level=0]
setblock 347 53 -183 minecraft:kelp_plant
fill 348 53 -183 354 53 -183 minecraft:water[level=0]
fill 373 53 -183 377 53 -183 minecraft:water[level=0]
setblock 378 53 -183 minecraft:kelp_plant
fill 389 53 -183 391 53 -183 minecraft:water[level=0]
fill 332 53 -184 345 53 -184 minecraft:water[level=0]
setblock 346 53 -184 minecraft:kelp_plant
fill 347 53 -184 348 53 -184 minecraft:water[level=0]
setblock 349 53 -184 minecraft:kelp_plant
fill 350 53 -184 352 53 -184 minecraft:water[level=0]
setblock 375 53 -184 minecraft:seagrass
setblock 376 53 -184 minecraft:kelp_plant
setblock 377 53 -184 minecraft:tall_seagrass[half=lower]
setblock 378 53 -184 minecraft:seagrass
setblock 389 53 -184 minecraft:kelp_plant
fill 390 53 -184 391 53 -184 minecraft:water[level=0]
fill 332 53 -185 340 53 -185 minecraft:water[level=0]
setblock 341 53 -185 minecraft:kelp_plant
fill 342 53 -185 345 53 -185 minecraft:water[level=0]
setblock 346 53 -185 minecraft:seagrass
setblock 347 53 -185 minecraft:water[level=0]
setblock 348 53 -185 minecraft:seagrass
fill 349 53 -185 351 53 -185 minecraft:water[level=0]
fill 388 53 -185 389 53 -185 minecraft:water[level=0]
setblock 390 53 -185 minecraft:tall_seagrass[half=upper]
setblock 391 53 -185 minecraft:water[level=0]
fill 332 53 -186 341 53 -186 minecraft:water[level=0]
setblock 342 53 -186 minecraft:kelp_plant
fill 343 53 -186 344 53 -186 minecraft:water[level=0]
setblock 345 53 -186 minecraft:seagrass
setblock 346 53 -186 minecraft:tall_seagrass[half=lower]
fill 347 53 -186 350 53 -186 minecraft:water[level=0]
fill 388 53 -186 390 53 -186 minecraft:water[level=0]
setblock 391 53 -186 minecraft:kelp_plant
fill 332 53 -187 349 53 -187 minecraft:water[level=0]
setblock 388 53 -187 minecraft:kelp_plant
fill 389 53 -187 390 53 -187 minecraft:water[level=0]
setblock 391 53 -187 minecraft:kelp_plant
fill 332 53 -188 344 53 -188 minecraft:water[level=0]
setblock 345 53 -188 minecraft:seagrass
setblock 346 53 -188 minecraft:tall_seagrass[half=lower]
fill 347 53 -188 348 53 -188 minecraft:water[level=0]
setblock 349 53 -188 minecraft:tall_seagrass[half=lower]
setblock 388 53 -188 minecraft:seagrass
fill 389 53 -188 391 53 -188 minecraft:water[level=0]
fill 332 53 -189 344 53 -189 minecraft:water[level=0]
fill 345 53 -189 347 53 -189 minecraft:seagrass
setblock 348 53 -189 minecraft:water[level=0]
fill 387 53 -189 391 53 -189 minecraft:water[level=0]
fill 335 53 -190 343 53 -190 minecraft:water[level=0]
fill 344 53 -190 345 53 -190 minecraft:seagrass
fill 346 53 -190 347 53 -190 minecraft:water[level=0]
setblock 348 53 -190 minecraft:tall_seagrass[half=lower]
fill 387 53 -190 388 53 -190 minecraft:kelp_plant
fill 389 53 -190 391 53 -190 minecraft:water[level=0]
fill 367 52 -127 368 52 -127 minecraft:water[level=0]
setblock 369 52 -127 minecraft:kelp_plant
fill 370 52 -127 372 52 -127 minecraft:water[level=0]
setblock 373 52 -127 minecraft:kelp_plant
setblock 374 52 -127 minecraft:water[level=0]
setblock 375 52 -127 minecraft:tall_seagrass[half=upper]
fill 376 52 -127 383 52 -127 minecraft:water[level=0]
fill 384 52 -127 385 52 -127 minecraft:kelp_plant
fill 386 52 -127 390 52 -127 minecraft:water[level=0]
setblock 391 52 -127 minecraft:kelp_plant
setblock 367 52 -128 minecraft:kelp_plant
fill 368 52 -128 369 52 -128 minecraft:water[level=0]
setblock 370 52 -128 minecraft:kelp_plant
setblock 371 52 -128 minecraft:water[level=0]
fill 372 52 -128 373 52 -128 minecraft:kelp_plant
setblock 374 52 -128 minecraft:water[level=0]
fill 375 52 -128 376 52 -128 minecraft:kelp_plant
setblock 377 52 -128 minecraft:water[level=0]
fill 378 52 -128 380 52 -128 minecraft:kelp_plant
fill 381 52 -128 386 52 -128 minecraft:water[level=0]
setblock 387 52 -128 minecraft:kelp_plant
fill 388 52 -128 391 52 -128 minecraft:water[level=0]
fill 367 52 -129 368 52 -129 minecraft:water[level=0]
setblock 369 52 -129 minecraft:kelp_plant
setblock 370 52 -129 minecraft:seagrass
fill 371 52 -129 373 52 -129 minecraft:water[level=0]
setblock 374 52 -129 minecraft:tall_seagrass[half=upper]
fill 375 52 -129 376 52 -129 minecraft:water[level=0]
setblock 377 52 -129 minecraft:kelp_plant
fill 378 52 -129 382 52 -129 minecraft:water[level=0]
setblock 383 52 -129 minecraft:kelp_plant
setblock 384 52 -129 minecraft:kelp[age=25]
setblock 385 52 -129 minecraft:kelp_plant
setblock 386 52 -129 minecraft:water[level=0]
setblock 387 52 -129 minecraft:kelp_plant
fill 388 52 -129 389 52 -129 minecraft:water[level=0]
setblock 390 52 -129 minecraft:kelp_plant
setblock 391 52 -129 minecraft:water[level=0]
fill 367 52 -130 368 52 -130 minecraft:water[level=0]
setblock 369 52 -130 minecraft:kelp_plant
setblock 370 52 -130 minecraft:seagrass
fill 371 52 -130 391 52 -130 minecraft:water[level=0]
setblock 367 52 -131 minecraft:water[level=0]
setblock 368 52 -131 minecraft:kelp_plant
setblock 369 52 -131 minecraft:tall_seagrass[half=lower]
fill 370 52 -131 373 52 -131 minecraft:water[level=0]
setblock 374 52 -131 minecraft:tall_seagrass[half=upper]
fill 375 52 -131 391 52 -131 minecraft:water[level=0]
setblock 328 52 -132 minecraft:water[level=0]
setblock 329 52 -132 minecraft:tall_seagrass[half=lower]
fill 367 52 -132 377 52 -132 minecraft:water[level=0]
setblock 378 52 -132 minecraft:kelp_plant
fill 379 52 -132 382 52 -132 minecraft:water[level=0]
setblock 383 52 -132 minecraft:kelp_plant
setblock 384 52 -132 minecraft:water[level=0]
setblock 385 52 -132 minecraft:kelp_plant
setblock 386 52 -132 minecraft:water[level=0]
fill 387 52 -132 388 52 -132 minecraft:kelp_plant
fill 389 52 -132 391 52 -132 minecraft:water[level=0]
setblock 328 52 -133 minecraft:seagrass
fill 329 52 -133 330 52 -133 minecraft:water[level=0]
setblock 331 52 -133 minecraft:seagrass
fill 332 52 -133 334 52 -133 minecraft:water[level=0]
fill 336 52 -133 337 52 -133 minecraft:seagrass
setblock 338 52 -133 minecraft:water[level=0]
fill 366 52 -133 381 52 -133 minecraft:water[level=0]
setblock 382 52 -133 minecraft:kelp_plant
fill 383 52 -133 387 52 -133 minecraft:water[level=0]
setblock 388 52 -133 minecraft:kelp_plant
fill 389 52 -133 391 52 -133 minecraft:water[level=0]
setblock 328 52 -134 minecraft:water[level=0]
setblock 329 52 -134 minecraft:seagrass
fill 330 52 -134 333 52 -134 minecraft:water[level=0]
setblock 334 52 -134 minecraft:tall_seagrass[half=upper]
setblock 335 52 -134 minecraft:water[level=0]
setblock 336 52 -134 minecraft:seagrass
setblock 337 52 -134 minecraft:kelp_plant
fill 338 52 -134 339 52 -134 minecraft:water[level=0]
fill 364 52 -134 367 52 -134 minecraft:water[level=0]
fill 368 52 -134 369 52 -134 minecraft:kelp_plant
fill 370 52 -134 371 52 -134 minecraft:water[level=0]
setblock 372 52 -134 minecraft:kelp_plant
setblock 373 52 -134 minecraft:water[level=0]
setblock 374 52 -134 minecraft:tall_seagrass[half=upper]
fill 375 52 -134 376 52 -134 minecraft:water[level=0]
setblock 377 52 -134 minecraft:kelp_plant
fill 378 52 -134 382 52 -134 minecraft:water[level=0]
fill 383 52 -134 385 52 -134 minecraft:kelp_plant
fill 386 52 -134 391 52 -134 minecraft:water[level=0]
fill 328 52 -135 331 52 -135 minecraft:water[level=0]
setblock 332 52 -135 minecraft:kelp_plant
fill 333 52 -135 336 52 -135 minecraft:water[level=0]
setblock 337 52 -135 minecraft:kelp_plant
setblock 338 52 -135 minecraft:water[level=0]
setblock 339 52 -135 minecraft:tall_seagrass[half=upper]
fill 364 52 -135 376 52 -135 minecraft:water[level=0]
setblock 377 52 -135 minecraft:kelp_plant
fill 378 52 -135 379 52 -135 minecraft:water[level=0]
setblock 380 52 -135 minecraft:kelp_plant
fill 381 52 -135 384 52 -135 minecraft:water[level=0]
setblock 385 52 -135 minecraft:kelp_plant
fill 386 52 -135 391 52 -135 minecraft:water[level=0]
fill 328 52 -136 336 52 -136 minecraft:water[level=0]
setblock 337 52 -136 minecraft:tall_seagrass[half=upper]
fill 338 52 -136 339 52 -136 minecraft:water[level=0]
setblock 340 52 -136 minecraft:water[level=8]
fill 363 52 -136 364 52 -136 minecraft:water[level=0]
setblock 365 52 -136 minecraft:kelp_plant
fill 366 52 -136 374 52 -136 minecraft:water[level=0]
setblock 375 52 -136 minecraft:kelp_plant
fill 376 52 -136 377 52 -136 minecraft:water[level=0]
setblock 378 52 -136 minecraft:kelp_plant
fill 379 52 -136 381 52 -136 minecraft:water[level=0]
setblock 382 52 -136 minecraft:kelp_plant
fill 383 52 -136 384 52 -136 minecraft:water[level=0]
setblock 385 52 -136 minecraft:kelp_plant
fill 386 52 -136 387 52 -136 minecraft:water[level=0]
fill 388 52 -136 389 52 -136 minecraft:kelp_plant
fill 390 52 -136 391 52 -136 minecraft:water[level=0]
setblock 328 52 -137 minecraft:kelp_plant
fill 329 52 -137 330 52 -137 minecraft:water[level=0]
setblock 331 52 -137 minecraft:kelp_plant
fill 332 52 -137 339 52 -137 minecraft:water[level=0]
setblock 340 52 -137 minecraft:water[level=8]
fill 363 52 -137 367 52 -137 minecraft:water[level=0]
setblock 368 52 -137 minecraft:kelp_plant
fill 369 52 -137 381 52 -137 minecraft:water[level=0]
setblock 382 52 -137 minecraft:kelp_plant
fill 383 52 -137 384 52 -137 minecraft:water[level=0]
setblock 385 52 -137 minecraft:kelp_plant
fill 386 52 -137 391 52 -137 minecraft:water[level=0]
fill 328 52 -138 339 52 -138 minecraft:water[level=0]
fill 363 52 -138 366 52 -138 minecraft:water[level=0]
setblock 367 52 -138 minecraft:kelp_plant
fill 368 52 -138 384 52 -138 minecraft:water[level=0]
fill 385 52 -138 386 52 -138 minecraft:kelp_plant
fill 387 52 -138 388 52 -138 minecraft:water[level=0]
setblock 389 52 -138 minecraft:kelp_plant
fill 390 52 -138 391 52 -138 minecraft:water[level=0]
fill 328 52 -139 333 52 -139 minecraft:water[level=0]
setblock 334 52 -139 minecraft:seagrass
setblock 340 52 -139 minecraft:water[level=0]
fill 363 52 -139 371 52 -139 minecraft:water[level=0]
setblock 372 52 -139 minecraft:kelp_plant
fill 373 52 -139 383 52 -139 minecraft:water[level=0]
setblock 384 52 -139 minecraft:kelp_plant
fill 385 52 -139 391 52 -139 minecraft:water[level=0]
fill 364 52 -140 368 52 -140 minecraft:water[level=0]
setblock 369 52 -140 minecraft:kelp_plant
setblock 370 52 -140 minecraft:water[level=0]
setblock 371 52 -140 minecraft:kelp_plant
fill 372 52 -140 377 52 -140 minecraft:water[level=0]
setblock 378 52 -140 minecraft:kelp_plant
fill 379 52 -140 380 52 -140 minecraft:water[level=0]
setblock 381 52 -140 minecraft:kelp_plant
fill 382 52 -140 391 52 -140 minecraft:water[level=0]
setblock 342 52 -141 minecraft:water[level=0]
fill 364 52 -141 368 52 -141 minecraft:water[level=0]
setblock 369 52 -141 minecraft:kelp_plant
fill 370 52 -141 378 52 -141 minecraft:water[level=0]
setblock 379 52 -141 minecraft:kelp_plant
fill 380 52 -141 382 52 -141 minecraft:water[level=0]
setblock 383 52 -141 minecraft:kelp_plant
fill 384 52 -141 387 52 -141 minecraft:water[level=0]
fill 388 52 -141 389 52 -141 minecraft:kelp_plant
fill 390 52 -141 391 52 -141 minecraft:water[level=0]
fill 342 52 -142 343 52 -142 minecraft:water[level=0]
fill 365 52 -142 367 52 -142 minecraft:water[level=0]
fill 368 52 -142 369 52 -142 minecraft:kelp_plant
setblock 370 52 -142 minecraft:water[level=0]
fill 371 52 -142 372 52 -142 minecraft:kelp_plant
fill 373 52 -142 390 52 -142 minecraft:water[level=0]
setblock 391 52 -142 minecraft:tall_seagrass[half=upper]
fill 342 52 -143 347 52 -143 minecraft:water[level=0]
fill 365 52 -143 377 52 -143 minecraft:water[level=0]
fill 378 52 -143 379 52 -143 minecraft:kelp_plant
setblock 380 52 -143 minecraft:seagrass
fill 381 52 -143 382 52 -143 minecraft:water[level=0]
setblock 383 52 -143 minecraft:kelp_plant
fill 384 52 -143 385 52 -143 minecraft:water[level=0]
setblock 386 52 -143 minecraft:kelp_plant
fill 387 52 -143 391 52 -143 minecraft:water[level=0]
fill 343 52 -144 348 52 -144 minecraft:water[level=0]
fill 366 52 -144 370 52 -144 minecraft:water[level=0]
setblock 371 52 -144 minecraft:kelp_plant
fill 372 52 -144 376 52 -144 minecraft:water[level=0]
setblock 377 52 -144 minecraft:seagrass
setblock 378 52 -144 minecraft:tall_seagrass[half=lower]
setblock 379 52 -144 minecraft:seagrass
fill 380 52 -144 391 52 -144 minecraft:water[level=0]
fill 342 52 -145 347 52 -145 minecraft:water[level=0]
setblock 368 52 -145 minecraft:water[level=0]
fill 369 52 -145 370 52 -145 minecraft:kelp_plant
fill 371 52 -145 376 52 -145 minecraft:water[level=0]
fill 377 52 -145 378 52 -145 minecraft:seagrass
setblock 379 52 -145 minecraft:water[level=0]
setblock 385 52 -145 minecraft:water[level=0]
setblock 386 52 -145 minecraft:kelp_plant
fill 387 52 -145 388 52 -145 minecraft:water[level=0]
setblock 389 52 -145 minecraft:kelp_plant
fill 390 52 -145 391 52 -145 minecraft:water[level=0]
fill 342 52 -146 343 52 -146 minecraft:water[level=0]
setblock 344 52 -146 minecraft:tall_seagrass[half=lower]
fill 345 52 -146 347 52 -146 minecraft:water[level=0]
fill 370 52 -146 371 52 -146 minecraft:water[level=0]
setblock 372 52 -146 minecraft:kelp_plant
fill 373 52 -146 375 52 -146 minecraft:water[level=0]
fill 389 52 -146 391 52 -146 minecraft:water[level=0]
fill 344 52 -147 346 52 -147 minecraft:water[level=0]
fill 389 52 -147 391 52 -147 minecraft:water[level=0]
fill 390 52 -148 391 52 -148 minecraft:water[level=0]
setblock 390 52 -149 minecraft:water[level=0]
setblock 391 52 -149 minecraft:kelp_plant
fill 390 52 -150 391 52 -150 minecraft:water[level=0]
fill 390 52 -151 391 52 -151 minecraft:water[level=0]
setblock 390 52 -152 minecraft:seagrass
setblock 391 52 -152 minecraft:kelp_plant
setblock 389 52 -153 minecraft:seagrass
setblock 390 52 -153 minecraft:kelp_plant
setblock 391 52 -153 minecraft:tall_seagrass[half=upper]
fill 389 52 -154 391 52 -154 minecraft:water[level=0]
setblock 389 52 -155 minecraft:water[level=0]
setblock 390 52 -155 minecraft:seagrass
setblock 391 52 -155 minecraft:water[level=0]
setblock 389 52 -156 minecraft:water[level=0]
setblock 390 52 -156 minecraft:seagrass
setblock 391 52 -156 minecraft:water[level=0]
fill 388 52 -157 390 52 -157 minecraft:water[level=0]
setblock 391 52 -157 minecraft:kelp_plant
fill 388 52 -158 391 52 -158 minecraft:water[level=0]
setblock 387 52 -159 minecraft:kelp_plant
fill 388 52 -159 391 52 -159 minecraft:water[level=0]
fill 386 52 -160 389 52 -160 minecraft:water[level=0]
setblock 390 52 -160 minecraft:kelp_plant
setblock 391 52 -160 minecraft:water[level=0]
fill 386 52 -161 388 52 -161 minecraft:water[level=0]
setblock 389 52 -161 minecraft:kelp_plant
fill 390 52 -161 391 52 -161 minecraft:water[level=0]
fill 386 52 -162 391 52 -162 minecraft:water[level=0]
fill 386 52 -163 391 52 -163 minecraft:water[level=0]
fill 386 52 -164 391 52 -164 minecraft:water[level=0]
fill 387 52 -165 389 52 -165 minecraft:water[level=0]
setblock 390 52 -165 minecraft:tall_seagrass[half=upper]
setblock 391 52 -165 minecraft:water[level=0]
fill 387 52 -166 391 52 -166 minecraft:water[level=0]
fill 388 52 -167 389 52 -167 minecraft:water[level=0]
setblock 390 52 -167 minecraft:tall_seagrass[half=lower]
setblock 391 52 -167 minecraft:water[level=0]
fill 389 52 -168 391 52 -168 minecraft:water[level=0]
setblock 389 52 -169 minecraft:seagrass
fill 390 52 -169 391 52 -169 minecraft:water[level=0]
setblock 390 52 -170 minecraft:tall_seagrass[half=lower]
setblock 391 52 -170 minecraft:kelp_plant
fill 332 52 -171 333 52 -171 minecraft:water[level=0]
fill 337 52 -171 346 52 -171 minecraft:water[level=0]
setblock 347 52 -171 minecraft:tall_seagrass[half=lower]
setblock 348 52 -171 minecraft:seagrass
setblock 349 52 -171 minecraft:water[level=0]
setblock 350 52 -171 minecraft:seagrass
setblock 351 52 -171 minecraft:water[level=0]
setblock 352 52 -171 minecraft:seagrass
setblock 353 52 -171 minecraft:water[level=0]
fill 390 52 -171 391 52 -171 minecraft:water[level=0]
fill 332 52 -172 351 52 -172 minecraft:water[level=0]
setblock 352 52 -172 minecraft:kelp_plant
fill 353 52 -172 355 52 -172 minecraft:water[level=0]
setblock 391 52 -172 minecraft:water[level=0]
fill 332 52 -173 355 52 -173 minecraft:water[level=0]
setblock 391 52 -173 minecraft:water[level=0]
fill 332 52 -174 345 52 -174 minecraft:water[level=0]
setblock 346 52 -174 minecraft:tall_seagrass[half=upper]
fill 347 52 -174 356 52 -174 minecraft:water[level=0]
setblock 391 52 -174 minecraft:water[level=0]
fill 332 52 -175 353 52 -175 minecraft:water[level=0]
setblock 354 52 -175 minecraft:seagrass
fill 355 52 -175 356 52 -175 minecraft:water[level=0]
setblock 360 52 -175 minecraft:water[level=0]
setblock 391 52 -175 minecraft:water[level=0]
fill 332 52 -176 351 52 -176 minecraft:water[level=0]
fill 352 52 -176 353 52 -176 minecraft:seagrass
setblock 354 52 -176 minecraft:water[level=0]
fill 355 52 -176 356 52 -176 minecraft:tall_seagrass[half=lower]
fill 359 52 -176 361 52 -176 minecraft:water[level=0]
setblock 391 52 -176 minecraft:water[level=0]
fill 332 52 -177 351 52 -177 minecraft:water[level=0]
setblock 352 52 -177 minecraft:seagrass
setblock 353 52 -177 minecraft:water[level=0]
setblock 354 52 -177 minecraft:seagrass
fill 355 52 -177 356 52 -177 minecraft:water[level=0]
fill 359 52 -177 361 52 -177 minecraft:water[level=0]
setblock 391 52 -177 minecraft:water[level=0]
fill 332 52 -178 350 52 -178 minecraft:water[level=0]
fill 351 52 -178 353 52 -178 minecraft:seagrass
fill 354 52 -178 355 52 -178 minecraft:water[level=0]
fill 360 52 -178 361 52 -178 minecraft:water[level=0]
setblock 391 52 -178 minecraft:water[level=0]
fill 332 52 -179 343 52 -179 minecraft:water[level=0]
setblock 344 52 -179 minecraft:tall_seagrass[half=upper]
fill 345 52 -179 347 52 -179 minecraft:water[level=0]
setblock 348 52 -179 minecraft:seagrass
fill 349 52 -179 351 52 -179 minecraft:water[level=0]
setblock 352 52 -179 minecraft:kelp_plant
setblock 353 52 -179 minecraft:water[level=0]
setblock 354 52 -179 minecraft:kelp_plant
setblock 361 52 -179 minecraft:water[level=0]
setblock 391 52 -179 minecraft:water[level=0]
fill 332 52 -180 348 52 -180 minecraft:water[level=0]
setblock 349 52 -180 minecraft:tall_seagrass[half=lower]
fill 350 52 -180 352 52 -180 minecraft:water[level=0]
setblock 361 52 -180 minecraft:water[level=0]
setblock 391 52 -180 minecraft:water[level=0]
fill 332 52 -181 348 52 -181 minecraft:water[level=0]
setblock 349 52 -181 minecraft:kelp_plant
fill 350 52 -181 351 52 -181 minecraft:water[level=0]
fill 373 52 -181 376 52 -181 minecraft:water[level=0]
setblock 390 52 -181 minecraft:kelp_plant
setblock 391 52 -181 minecraft:water[level=0]
fill 332 52 -182 336 52 -182 minecraft:water[level=0]
setblock 337 52 -182 minecraft:kelp_plant
fill 338 52 -182 349 52 -182 minecraft:water[level=0]
fill 373 52 -182 376 52 -182 minecraft:water[level=0]
fill 390 52 -182 391 52 -182 minecraft:water[level=0]
fill 332 52 -183 346 52 -183 minecraft:water[level=0]
setblock 347 52 -183 minecraft:kelp_plant
fill 373 52 -183 376 52 -183 minecraft:water[level=0]
fill 390 52 -183 391 52 -183 minecraft:water[level=0]
fill 332 52 -184 344 52 -184 minecraft:water[level=0]
setblock 345 52 -184 minecraft:seagrass
fill 390 52 -184 391 52 -184 minecraft:water[level=0]
fill 332 52 -185 338 52 -185 minecraft:water[level=0]
setblock 339 52 -185 minecraft:tall_seagrass[half=upper]
setblock 340 52 -185 minecraft:water[level=0]
setblock 341 52 -185 minecraft:kelp_plant
setblock 342 52 -185 minecraft:seagrass
fill 343 52 -185 344 52 -185 minecraft:water[level=0]
setblock 390 52 -185 minecraft:tall_seagrass[half=lower]
setblock 391 52 -185 minecraft:water[level=0]
fill 332 52 -186 341 52 -186 minecraft:water[level=0]
setblock 342 52 -186 minecraft:kelp_plant
fill 343 52 -186 344 52 -186 minecraft:water[level=0]
setblock 390 52 -186 minecraft:water[level=0]
setblock 391 52 -186 minecraft:kelp_plant
fill 332 52 -187 341 52 -187 minecraft:water[level=0]
setblock 342 52 -187 minecraft:seagrass
fill 343 52 -187 344 52 -187 minecraft:water[level=0]
fill 389 52 -187 390 52 -187 minecraft:water[level=0]
setblock 391 52 -187 minecraft:kelp_plant
fill 332 52 -188 339 52 -188 minecraft:water[level=0]
setblock 340 52 -188 minecraft:tall_seagrass[half=upper]
fill 341 52 -188 343 52 -188 minecraft:water[level=0]
setblock 389 52 -188 minecraft:seagrass
fill 390 52 -188 391 52 -188 minecraft:water[level=0]
fill 334 52 -189 339 52 -189 minecraft:water[level=0]
fill 340 52 -189 341 52 -189 minecraft:tall_seagrass[half=upper]
setblock 342 52 -189 minecraft:seagrass
setblock 343 52 -189 minecraft:water[level=0]
fill 389 52 -189 391 52 -189 minecraft:water[level=0]
fill 335 52 -190 343 52 -190 minecraft:water[level=0]
fill 389 52 -190 391 52 -190 minecraft:water[level=0]
fill 371 51 -127 372 51 -127 minecraft:water[level=0]
setblock 373 51 -127 minecraft:kelp_plant
setblock 374 51 -127 minecraft:water[level=0]
setblock 375 51 -127 minecraft:tall_seagrass[half=lower]
fill 376 51 -127 378 51 -127 minecraft:water[level=0]
setblock 379 51 -127 minecraft:tall_seagrass[half=upper]
fill 380 51 -127 383 51 -127 minecraft:water[level=0]
fill 384 51 -127 385 51 -127 minecraft:kelp_plant
fill 386 51 -127 390 51 -127 minecraft:water[level=0]
setblock 391 51 -127 minecraft:kelp_plant
setblock 371 51 -128 minecraft:water[level=0]
fill 372 51 -128 373 51 -128 minecraft:kelp_plant
setblock 374 51 -128 minecraft:water[level=0]
fill 375 51 -128 376 51 -128 minecraft:kelp_plant
setblock 377 51 -128 minecraft:tall_seagrass[half=upper]
fill 378 51 -128 380 51 -128 minecraft:kelp_plant
setblock 381 51 -128 minecraft:tall_seagrass[half=upper]
fill 382 51 -128 386 51 -128 minecraft:water[level=0]
setblock 387 51 -128 minecraft:kelp_plant
fill 388 51 -128 391 51 -128 minecraft:water[level=0]
setblock 371 51 -129 minecraft:water[level=0]
setblock 372 51 -129 minecraft:seagrass
setblock 373 51 -129 minecraft:water[level=0]
setblock 374 51 -129 minecraft:tall_seagrass[half=lower]
fill 375 51 -129 376 51 -129 minecraft:water[level=0]
setblock 377 51 -129 minecraft:kelp_plant
fill 378 51 -129 382 51 -129 minecraft:water[level=0]
fill 383 51 -129 385 51 -129 minecraft:kelp_plant
setblock 386 51 -129 minecraft:water[level=0]
setblock 387 51 -129 minecraft:kelp_plant
fill 388 51 -129 389 51 -129 minecraft:water[level=0]
setblock 390 51 -129 minecraft:kelp_plant
setblock 391 51 -129 minecraft:water[level=0]
setblock 371 51 -130 minecraft:seagrass
fill 372 51 -130 373 51 -130 minecraft:water[level=0]
setblock 374 51 -130 minecraft:seagrass
setblock 375 51 -130 minecraft:water[level=0]
setblock 376 51 -130 minecraft:tall_seagrass[half=upper]
fill 377 51 -130 391 51 -130 minecraft:water[level=0]
fill 371 51 -131 372 51 -131 minecraft:water[level=0]
setblock 373 51 -131 minecraft:seagrass
setblock 374 51 -131 minecraft:tall_seagrass[half=lower]
fill 375 51 -131 391 51 -131 minecraft:water[level=0]
fill 371 51 -132 373 51 -132 minecraft:water[level=0]
setblock 374 51 -132 minecraft:seagrass
fill 375 51 -132 377 51 -132 minecraft:water[level=0]
setblock 378 51 -132 minecraft:kelp_plant
fill 379 51 -132 382 51 -132 minecraft:water[level=0]
setblock 383 51 -132 minecraft:kelp_plant
setblock 384 51 -132 minecraft:water[level=0]
setblock 385 51 -132 minecraft:kelp_plant
setblock 386 51 -132 minecraft:water[level=0]
fill 387 51 -132 388 51 -132 minecraft:kelp_plant
fill 389 51 -132 391 51 -132 minecraft:water[level=0]
setblock 371 51 -133 minecraft:water[level=0]
setblock 372 51 -133 minecraft:seagrass
fill 373 51 -133 378 51 -133 minecraft:water[level=0]
setblock 379 51 -133 minecraft:tall_seagrass[half=upper]
fill 380 51 -133 381 51 -133 minecraft:water[level=0]
setblock 382 51 -133 minecraft:kelp_plant
fill 383 51 -133 387 51 -133 minecraft:water[level=0]
setblock 388 51 -133 minecraft:kelp_plant
fill 389 51 -133 391 51 -133 minecraft:water[level=0]
fill 330 51 -134 332 51 -134 minecraft:water[level=0]
setblock 333 51 -134 minecraft:seagrass
setblock 334 51 -134 minecraft:tall_seagrass[half=lower]
setblock 339 51 -134 minecraft:water[level=0]
setblock 370 51 -134 minecraft:water[level=0]
setblock 371 51 -134 minecraft:seagrass
setblock 372 51 -134 minecraft:kelp_plant
setblock 373 51 -134 minecraft:seagrass
setblock 374 51 -134 minecraft:tall_seagrass[half=lower]
setblock 375 51 -134 minecraft:seagrass
setblock 376 51 -134 minecraft:water[level=0]
setblock 377 51 -134 minecraft:kelp_plant
fill 378 51 -134 382 51 -134 minecraft:water[level=0]
fill 383 51 -134 385 51 -134 minecraft:kelp_plant
fill 386 51 -134 391 51 -134 minecraft:water[level=0]
setblock 329 51 -135 minecraft:seagrass
fill 330 51 -135 331 51 -135 minecraft:water[level=0]
setblock 332 51 -135 minecraft:kelp_plant
fill 333 51 -135 334 51 -135 minecraft:water[level=0]
setblock 335 51 -135 minecraft:seagrass
setblock 336 51 -135 minecraft:water[level=0]
setblock 337 51 -135 minecraft:kelp_plant
setblock 338 51 -135 minecraft:water[level=0]
setblock 339 51 -135 minecraft:tall_seagrass[half=lower]
fill 369 51 -135 372 51 -135 minecraft:water[level=0]
setblock 373 51 -135 minecraft:seagrass
fill 374 51 -135 376 51 -135 minecraft:water[level=0]
setblock 377 51 -135 minecraft:kelp_plant
fill 378 51 -135 379 51 -135 minecraft:water[level=0]
setblock 380 51 -135 minecraft:kelp_plant
fill 381 51 -135 384 51 -135 minecraft:water[level=0]
setblock 385 51 -135 minecraft:kelp_plant
fill 386 51 -135 391 51 -135 minecraft:water[level=0]
fill 328 51 -136 333 51 -136 minecraft:water[level=0]
setblock 334 51 -136 minecraft:tall_seagrass[half=upper]
setblock 335 51 -136 minecraft:water[level=0]
setblock 336 51 -136 minecraft:seagrass
setblock 337 51 -136 minecraft:tall_seagrass[half=lower]
fill 338 51 -136 341 51 -136 minecraft:water[level=0]
fill 368 51 -136 374 51 -136 minecraft:water[level=0]
setblock 375 51 -136 minecraft:kelp_plant
setblock 376 51 -136 minecraft:water[level=0]
setblock 377 51 -136 minecraft:tall_seagrass[half=upper]
setblock 378 51 -136 minecraft:kelp_plant
fill 379 51 -136 381 51 -136 minecraft:water[level=0]
setblock 382 51 -136 minecraft:kelp_plant
fill 383 51 -136 384 51 -136 minecraft:water[level=0]
setblock 385 51 -136 minecraft:kelp_plant
fill 386 51 -136 387 51 -136 minecraft:water[level=0]
fill 388 51 -136 389 51 -136 minecraft:kelp_plant
fill 390 51 -136 391 51 -136 minecraft:water[level=0]
setblock 329 51 -137 minecraft:seagrass
setblock 330 51 -137 minecraft:water[level=0]
setblock 331 51 -137 minecraft:kelp_plant
fill 332 51 -137 333 51 -137 minecraft:water[level=0]
fill 334 51 -137 335 51 -137 minecraft:seagrass
fill 336 51 -137 339 51 -137 minecraft:water[level=0]
setblock 341 51 -137 minecraft:water[level=0]
setblock 368 51 -137 minecraft:kelp_plant
fill 369 51 -137 381 51 -137 minecraft:water[level=0]
setblock 382 51 -137 minecraft:kelp_plant
fill 383 51 -137 384 51 -137 minecraft:water[level=0]
setblock 385 51 -137 minecraft:kelp_plant
fill 386 51 -137 391 51 -137 minecraft:water[level=0]
fill 329 51 -138 332 51 -138 minecraft:water[level=0]
setblock 333 51 -138 minecraft:seagrass
setblock 334 51 -138 minecraft:water[level=0]
setblock 336 51 -138 minecraft:seagrass
fill 337 51 -138 342 51 -138 minecraft:water[level=0]
fill 368 51 -138 384 51 -138 minecraft:water[level=0]
fill 385 51 -138 386 51 -138 minecraft:kelp_plant
fill 387 51 -138 388 51 -138 minecraft:water[level=0]
setblock 389 51 -138 minecraft:kelp_plant
fill 390 51 -138 391 51 -138 minecraft:water[level=0]
fill 336 51 -139 342 51 -139 minecraft:water[level=0]
fill 374 51 -139 383 51 -139 minecraft:water[level=0]
setblock 384 51 -139 minecraft:kelp_plant
fill 385 51 -139 391 51 -139 minecraft:water[level=0]
fill 337 51 -140 343 51 -140 minecraft:water[level=0]
fill 376 51 -140 377 51 -140 minecraft:water[level=0]
setblock 378 51 -140 minecraft:kelp_plant
fill 379 51 -140 380 51 -140 minecraft:water[level=0]
setblock 381 51 -140 minecraft:kelp_plant
fill 382 51 -140 391 51 -140 minecraft:water[level=0]
fill 339 51 -141 346 51 -141 minecraft:water[level=0]
setblock 378 51 -141 minecraft:water[level=0]
setblock 379 51 -141 minecraft:kelp_plant
fill 380 51 -141 381 51 -141 minecraft:water[level=0]
setblock 382 51 -141 minecraft:seagrass
setblock 383 51 -141 minecraft:kelp_plant
fill 384 51 -141 387 51 -141 minecraft:water[level=0]
fill 388 51 -141 389 51 -141 minecraft:kelp_plant
fill 390 51 -141 391 51 -141 minecraft:water[level=0]
fill 340 51 -142 347 51 -142 minecraft:water[level=0]
fill 381 51 -142 390 51 -142 minecraft:water[level=0]
setblock 391 51 -142 minecraft:tall_seagrass[half=lower]
fill 341 51 -143 347 51 -143 minecraft:water[level=0]
fill 390 51 -143 391 51 -143 minecraft:water[level=0]
fill 341 51 -144 347 51 -144 minecraft:water[level=0]
fill 343 51 -145 346 51 -145 minecraft:water[level=0]
setblock 391 51 -153 minecraft:tall_seagrass[half=lower]
setblock 391 51 -154 minecraft:seagrass
setblock 391 51 -155 minecraft:seagrass
setblock 391 51 -156 minecraft:water[level=0]
setblock 390 51 -157 minecraft:water[level=0]
setblock 391 51 -157 minecraft:kelp_plant
setblock 390 51 -158 minecraft:water[level=0]
setblock 391 51 -158 minecraft:seagrass
fill 390 51 -159 391 51 -159 minecraft:water[level=0]
setblock 390 51 -160 minecraft:kelp_plant
setblock 391 51 -160 minecraft:water[level=0]
setblock 389 51 -161 minecraft:kelp_plant
fill 390 51 -161 391 51 -161 minecraft:water[level=0]
fill 389 51 -162 391 51 -162 minecraft:water[level=0]
fill 389 51 -163 391 51 -163 minecraft:water[level=0]
setblock 389 51 -164 minecraft:seagrass
fill 390 51 -164 391 51 -164 minecraft:water[level=0]
setblock 390 51 -165 minecraft:tall_seagrass[half=lower]
setblock 391 51 -165 minecraft:water[level=0]
fill 390 51 -166 391 51 -166 minecraft:water[level=0]
setblock 391 51 -167 minecraft:water[level=0]
setblock 391 51 -168 minecraft:water[level=0]
fill 339 51 -172 343 51 -172 minecraft:water[level=0]
fill 345 51 -172 351 51 -172 minecraft:water[level=0]
setblock 352 51 -172 minecraft:kelp_plant
setblock 332 51 -173 minecraft:water[level=0]
fill 339 51 -173 343 51 -173 minecraft:water[level=0]
setblock 344 51 -173 minecraft:seagrass
fill 345 51 -173 346 51 -173 minecraft:water[level=0]
setblock 347 51 -173 minecraft:seagrass
fill 348 51 -173 349 51 -173 minecraft:water[level=0]
fill 350 51 -173 351 51 -173 minecraft:seagrass
setblock 352 51 -173 minecraft:water[level=0]
fill 332 51 -174 335 51 -174 minecraft:water[level=0]
fill 337 51 -174 345 51 -174 minecraft:water[level=0]
setblock 346 51 -174 minecraft:tall_seagrass[half=lower]
fill 347 51 -174 351 51 -174 minecraft:water[level=0]
setblock 352 51 -174 minecraft:seagrass
setblock 359 51 -174 minecraft:water[level=0]
fill 332 51 -175 346 51 -175 minecraft:water[level=0]
fill 347 51 -175 348 51 -175 minecraft:seagrass
fill 349 51 -175 351 51 -175 minecraft:water[level=0]
setblock 352 51 -175 minecraft:seagrass
fill 359 51 -175 360 51 -175 minecraft:water[level=0]
fill 332 51 -176 347 51 -176 minecraft:water[level=0]
fill 348 51 -176 349 51 -176 minecraft:seagrass
setblock 350 51 -176 minecraft:water[level=0]
setblock 351 51 -176 minecraft:seagrass
fill 359 51 -176 361 51 -176 minecraft:water[level=0]
fill 332 51 -177 344 51 -177 minecraft:water[level=0]
setblock 345 51 -177 minecraft:seagrass
fill 346 51 -177 350 51 -177 minecraft:water[level=0]
fill 359 51 -177 361 51 -177 minecraft:water[level=0]
fill 332 51 -178 349 51 -178 minecraft:water[level=0]
fill 360 51 -178 361 51 -178 minecraft:water[level=0]
fill 332 51 -179 343 51 -179 minecraft:water[level=0]
setblock 344 51 -179 minecraft:tall_seagrass[half=lower]
fill 345 51 -179 347 51 -179 minecraft:water[level=0]
fill 332 51 -180 345 51 -180 minecraft:water[level=0]
fill 332 51 -181 343 51 -181 minecraft:water[level=0]
fill 332 51 -182 336 51 -182 minecraft:water[level=0]
setblock 337 51 -182 minecraft:kelp_plant
fill 338 51 -182 342 51 -182 minecraft:water[level=0]
fill 333 51 -183 341 51 -183 minecraft:water[level=0]
fill 334 51 -184 341 51 -184 minecraft:water[level=0]
setblock 391 51 -184 minecraft:water[level=0]
fill 332 51 -185 338 51 -185 minecraft:water[level=0]
setblock 339 51 -185 minecraft:tall_seagrass[half=lower]
setblock 340 51 -185 minecraft:water[level=0]
setblock 341 51 -185 minecraft:kelp_plant
setblock 391 51 -185 minecraft:water[level=0]
fill 332 51 -186 340 51 -186 minecraft:water[level=0]
setblock 341 51 -186 minecraft:seagrass
setblock 391 51 -186 minecraft:kelp_plant
fill 332 51 -187 339 51 -187 minecraft:water[level=0]
fill 340 51 -187 341 51 -187 minecraft:seagrass
setblock 390 51 -187 minecraft:seagrass
setblock 391 51 -187 minecraft:kelp_plant
fill 332 51 -188 339 51 -188 minecraft:water[level=0]
setblock 340 51 -188 minecraft:tall_seagrass[half=lower]
setblock 341 51 -188 minecraft:water[level=0]
fill 390 51 -188 391 51 -188 minecraft:water[level=0]
fill 335 51 -189 339 51 -189 minecraft:water[level=0]
fill 340 51 -189 341 51 -189 minecraft:tall_seagrass[half=lower]
fill 390 51 -189 391 51 -189 minecraft:water[level=0]
fill 336 51 -190 341 51 -190 minecraft:water[level=0]
fill 390 51 -190 391 51 -190 minecraft:water[level=0]
setblock 376 50 -127 minecraft:seagrass
fill 377 50 -127 378 50 -127 minecraft:water[level=0]
setblock 379 50 -127 minecraft:tall_seagrass[half=lower]
fill 380 50 -127 381 50 -127 minecraft:water[level=0]
setblock 382 50 -127 minecraft:seagrass
setblock 383 50 -127 minecraft:water[level=0]
fill 384 50 -127 385 50 -127 minecraft:kelp_plant
fill 386 50 -127 387 50 -127 minecraft:seagrass
fill 388 50 -127 390 50 -127 minecraft:water[level=0]
setblock 391 50 -127 minecraft:kelp_plant
fill 375 50 -128 376 50 -128 minecraft:kelp_plant
setblock 377 50 -128 minecraft:tall_seagrass[half=lower]
fill 378 50 -128 380 50 -128 minecraft:kelp_plant
setblock 381 50 -128 minecraft:tall_seagrass[half=lower]
setblock 382 50 -128 minecraft:seagrass
fill 383 50 -128 384 50 -128 minecraft:water[level=0]
setblock 385 50 -128 minecraft:seagrass
setblock 386 50 -128 minecraft:water[level=0]
setblock 387 50 -128 minecraft:kelp_plant
fill 388 50 -128 391 50 -128 minecraft:water[level=0]
setblock 375 50 -129 minecraft:seagrass
setblock 376 50 -129 minecraft:water[level=0]
setblock 377 50 -129 minecraft:kelp_plant
setblock 378 50 -129 minecraft:water[level=0]
setblock 379 50 -129 minecraft:seagrass
fill 380 50 -129 382 50 -129 minecraft:water[level=0]
fill 383 50 -129 385 50 -129 minecraft:kelp_plant
setblock 386 50 -129 minecraft:seagrass
setblock 387 50 -129 minecraft:kelp_plant
fill 388 50 -129 389 50 -129 minecraft:water[level=0]
setblock 390 50 -129 minecraft:kelp_plant
setblock 391 50 -129 minecraft:water[level=0]
setblock 375 50 -130 minecraft:seagrass
setblock 376 50 -130 minecraft:tall_seagrass[half=lower]
setblock 377 50 -130 minecraft:water[level=0]
setblock 378 50 -130 minecraft:seagrass
fill 379 50 -130 391 50 -130 minecraft:water[level=0]
fill 375 50 -131 377 50 -131 minecraft:water[level=0]
fill 378 50 -131 379 50 -131 minecraft:seagrass
fill 380 50 -131 391 50 -131 minecraft:water[level=0]
setblock 375 50 -132 minecraft:seagrass
fill 376 50 -132 377 50 -132 minecraft:water[level=0]
setblock 378 50 -132 minecraft:kelp_plant
fill 379 50 -132 382 50 -132 minecraft:water[level=0]
setblock 383 50 -132 minecraft:kelp_plant
setblock 384 50 -132 minecraft:water[level=0]
setblock 385 50 -132 minecraft:kelp_plant
setblock 386 50 -132 minecraft:water[level=0]
fill 387 50 -132 388 50 -132 minecraft:kelp_plant
fill 389 50 -132 390 50 -132 minecraft:water[level=0]
setblock 391 50 -132 minecraft:seagrass
fill 375 50 -133 376 50 -133 minecraft:water[level=0]
fill 377 50 -133 378 50 -133 minecraft:seagrass
setblock 379 50 -133 minecraft:tall_seagrass[half=lower]
fill 380 50 -133 381 50 -133 minecraft:water[level=0]
setblock 382 50 -133 minecraft:kelp_plant
fill 383 50 -133 387 50 -133 minecraft:water[level=0]
setblock 388 50 -133 minecraft:kelp_plant
fill 389 50 -133 391 50 -133 minecraft:water[level=0]
setblock 376 50 -134 minecraft:seagrass
setblock 377 50 -134 minecraft:kelp_plant
fill 378 50 -134 382 50 -134 minecraft:water[level=0]
fill 383 50 -134 385 50 -134 minecraft:kelp_plant
fill 386 50 -134 391 50 -134 minecraft:water[level=0]
fill 330 50 -135 331 50 -135 minecraft:seagrass
setblock 332 50 -135 minecraft:kelp_plant
setblock 333 50 -135 minecraft:water[level=0]
setblock 376 50 -135 minecraft:seagrass
setblock 377 50 -135 minecraft:kelp_plant
fill 378 50 -135 379 50 -135 minecraft:water[level=0]
setblock 380 50 -135 minecraft:kelp_plant
fill 381 50 -135 384 50 -135 minecraft:water[level=0]
setblock 385 50 -135 minecraft:kelp_plant
fill 386 50 -135 391 50 -135 minecraft:water[level=0]
fill 329 50 -136 331 50 -136 minecraft:water[level=0]
setblock 332 50 -136 minecraft:tall_seagrass[half=upper]
setblock 333 50 -136 minecraft:water[level=0]
setblock 334 50 -136 minecraft:tall_seagrass[half=lower]
fill 338 50 -136 339 50 -136 minecraft:water[level=0]
setblock 341 50 -136 minecraft:water[level=0]
setblock 376 50 -136 minecraft:water[level=0]
setblock 377 50 -136 minecraft:tall_seagrass[half=lower]
setblock 378 50 -136 minecraft:kelp_plant
setblock 379 50 -136 minecraft:seagrass
fill 380 50 -136 381 50 -136 minecraft:water[level=0]
setblock 382 50 -136 minecraft:kelp_plant
fill 383 50 -136 384 50 -136 minecraft:water[level=0]
setblock 385 50 -136 minecraft:kelp_plant
fill 386 50 -136 387 50 -136 minecraft:water[level=0]
fill 388 50 -136 389 50 -136 minecraft:kelp_plant
fill 390 50 -136 391 50 -136 minecraft:water[level=0]
setblock 330 50 -137 minecraft:water[level=0]
setblock 331 50 -137 minecraft:kelp_plant
fill 332 50 -137 333 50 -137 minecraft:water[level=0]
setblock 338 50 -137 minecraft:water[level=0]
setblock 339 50 -137 minecraft:seagrass
fill 341 50 -137 343 50 -137 minecraft:water[level=0]
fill 378 50 -137 381 50 -137 minecraft:water[level=0]
setblock 382 50 -137 minecraft:kelp_plant
fill 383 50 -137 384 50 -137 minecraft:water[level=0]
setblock 385 50 -137 minecraft:kelp_plant
fill 386 50 -137 390 50 -137 minecraft:water[level=0]
setblock 332 50 -138 minecraft:water[level=0]
fill 338 50 -138 344 50 -138 minecraft:water[level=0]
fill 379 50 -138 384 50 -138 minecraft:water[level=0]
fill 385 50 -138 386 50 -138 minecraft:kelp_plant
fill 387 50 -138 388 50 -138 minecraft:water[level=0]
setblock 389 50 -138 minecraft:kelp_plant
setblock 390 50 -138 minecraft:water[level=0]
fill 338 50 -139 344 50 -139 minecraft:water[level=0]
fill 380 50 -139 383 50 -139 minecraft:water[level=0]
setblock 384 50 -139 minecraft:kelp_plant
fill 385 50 -139 389 50 -139 minecraft:water[level=0]
fill 339 50 -140 345 50 -140 minecraft:water[level=0]
setblock 381 50 -140 minecraft:kelp_plant
fill 382 50 -140 389 50 -140 minecraft:water[level=0]
fill 340 50 -141 345 50 -141 minecraft:water[level=0]
fill 341 50 -142 345 50 -142 minecraft:water[level=0]
fill 342 50 -143 345 50 -143 minecraft:water[level=0]
setblock 359 50 -174 minecraft:water[level=0]
fill 359 50 -175 360 50 -175 minecraft:water[level=0]
fill 332 50 -176 333 50 -176 minecraft:water[level=0]
fill 359 50 -176 361 50 -176 minecraft:water[level=0]
setblock 332 50 -177 minecraft:water[level=0]
setblock 359 50 -177 minecraft:water[level=0]
setblock 360 50 -177 minecraft:kelp[age=25]
setblock 360 50 -178 minecraft:water[level=0]
setblock 336 50 -185 minecraft:water[level=0]
setblock 336 50 -186 minecraft:water[level=0]
fill 334 50 -187 337 50 -187 minecraft:water[level=0]
fill 332 50 -188 337 50 -188 minecraft:water[level=0]
setblock 391 50 -188 minecraft:seagrass
fill 336 50 -189 337 50 -189 minecraft:water[level=0]
setblock 391 50 -189 minecraft:water[level=0]
fill 336 50 -190 337 50 -190 minecraft:water[level=0]
setblock 338 50 -190 minecraft:seagrass
setblock 391 50 -190 minecraft:seagrass
setblock 384 49 -127 minecraft:kelp_plant
setblock 390 49 -127 minecraft:water[level=0]
setblock 391 49 -127 minecraft:kelp_plant
fill 383 49 -128 384 49 -128 minecraft:water[level=0]
fill 390 49 -128 391 49 -128 minecraft:water[level=0]
setblock 382 49 -129 minecraft:water[level=0]
fill 383 49 -129 385 49 -129 minecraft:kelp_plant
setblock 390 49 -129 minecraft:kelp_plant
setblock 391 49 -129 minecraft:water[level=0]
fill 381 49 -130 385 49 -130 minecraft:water[level=0]
fill 390 49 -130 391 49 -130 minecraft:water[level=0]
fill 380 49 -131 381 49 -131 minecraft:water[level=0]
setblock 382 49 -131 minecraft:seagrass
fill 383 49 -131 386 49 -131 minecraft:water[level=0]
setblock 391 49 -131 minecraft:water[level=0]
fill 380 49 -132 382 49 -132 minecraft:water[level=0]
setblock 383 49 -132 minecraft:kelp_plant
setblock 384 49 -132 minecraft:water[level=0]
setblock 385 49 -132 minecraft:kelp_plant
setblock 386 49 -132 minecraft:water[level=0]
fill 380 49 -133 381 49 -133 minecraft:water[level=0]
setblock 382 49 -133 minecraft:kelp_plant
fill 383 49 -133 386 49 -133 minecraft:water[level=0]
fill 380 49 -134 382 49 -134 minecraft:water[level=0]
fill 383 49 -134 385 49 -134 minecraft:kelp_plant
fill 387 49 -134 388 49 -134 minecraft:water[level=0]
setblock 380 49 -135 minecraft:kelp_plant
setblock 381 49 -135 minecraft:seagrass
fill 382 49 -135 384 49 -135 minecraft:water[level=0]
setblock 385 49 -135 minecraft:kelp_plant
fill 386 49 -135 391 49 -135 minecraft:water[level=0]
fill 330 49 -136 331 49 -136 minecraft:water[level=0]
setblock 332 49 -136 minecraft:tall_seagrass[half=lower]
setblock 333 49 -136 minecraft:water[level=0]
setblock 381 49 -136 minecraft:water[level=0]
setblock 382 49 -136 minecraft:kelp_plant
fill 383 49 -136 384 49 -136 minecraft:water[level=0]
setblock 385 49 -136 minecraft:kelp_plant
setblock 332 49 -137 minecraft:water[level=0]
setblock 384 49 -137 minecraft:water[level=0]
setblock 340 49 -138 minecraft:water[level=0]
fill 341 49 -139 342 49 -139 minecraft:water[level=0]
fill 341 49 -140 343 49 -140 minecraft:water[level=0]
setblock 343 49 -141 minecraft:water[level=0]
setblock 359 49 -174 minecraft:water[level=0]
fill 359 49 -175 360 49 -175 minecraft:water[level=0]
fill 358 49 -176 360 49 -176 minecraft:water[level=0]
setblock 359 49 -177 minecraft:water[level=0]
setblock 360 49 -177 minecraft:kelp_plant
setblock 360 49 -178 minecraft:water[level=0]
setblock 388 48 -134 minecraft:water[level=0]
fill 387 48 -135 391 48 -135 minecraft:water[level=0]
setblock 391 48 -136 minecraft:water[level=0]
fill 358 48 -175 360 48 -175 minecraft:water[level=0]
fill 358 48 -176 360 48 -176 minecraft:water[level=0]
setblock 359 48 -177 minecraft:water[level=0]
setblock 360 48 -177 minecraft:kelp_plant
setblock 387 47 -134 minecraft:water[level=0]
fill 387 47 -135 391 47 -135 minecraft:water[level=0]
fill 389 47 -136 391 47 -136 minecraft:water[level=0]
fill 358 47 -175 359 47 -175 minecraft:water[level=0]
fill 358 47 -176 360 47 -176 minecraft:water[level=0]
setblock 359 47 -177 minecraft:water[level=0]
setblock 360 47 -177 minecraft:kelp_plant
setblock 337 47 -187 minecraft:cave_air
fill 336 47 -188 337 47 -188 minecraft:cave_air
fill 328 47 -190 329 47 -190 minecraft:cave_air
setblock 385 46 -131 minecraft:water[level=0]
fill 382 46 -132 384 46 -132 minecraft:water[level=0]
fill 380 46 -133 384 46 -133 minecraft:water[level=0]
setblock 387 46 -134 minecraft:water[level=0]
fill 387 46 -135 391 46 -135 minecraft:water[level=0]
fill 388 46 -136 391 46 -136 minecraft:water[level=0]
fill 358 46 -175 359 46 -175 minecraft:water[level=0]
fill 358 46 -176 360 46 -176 minecraft:water[level=0]
setblock 359 46 -177 minecraft:water[level=0]
setblock 360 46 -177 minecraft:kelp_plant
fill 336 46 -186 337 46 -186 minecraft:cave_air
fill 328 46 -187 329 46 -187 minecraft:cave_air
fill 336 46 -187 338 46 -187 minecraft:cave_air
fill 328 46 -188 329 46 -188 minecraft:cave_air
fill 336 46 -188 338 46 -188 minecraft:cave_air
fill 328 46 -189 329 46 -189 minecraft:cave_air
fill 334 46 -189 337 46 -189 minecraft:cave_air
fill 328 46 -190 329 46 -190 minecraft:cave_air
fill 332 46 -190 336 46 -190 minecraft:cave_air
fill 385 45 -127 386 45 -127 minecraft:water[level=0]
fill 385 45 -128 386 45 -128 minecraft:water[level=0]
fill 385 45 -129 387 45 -129 minecraft:water[level=0]
fill 384 45 -130 386 45 -130 minecraft:water[level=0]
fill 383 45 -131 386 45 -131 minecraft:water[level=0]
fill 379 45 -132 386 45 -132 minecraft:water[level=0]
fill 379 45 -133 385 45 -133 minecraft:water[level=0]
fill 379 45 -134 384 45 -134 minecraft:water[level=0]
fill 387 45 -135 391 45 -135 minecraft:water[level=0]
fill 387 45 -136 391 45 -136 minecraft:water[level=0]
fill 358 45 -175 359 45 -175 minecraft:water[level=0]
fill 358 45 -176 360 45 -176 minecraft:water[level=0]
fill 358 45 -177 359 45 -177 minecraft:water[level=0]
setblock 360 45 -177 minecraft:kelp_plant
setblock 359 45 -178 minecraft:water[level=0]
setblock 328 45 -186 minecraft:cave_air
fill 336 45 -186 337 45 -186 minecraft:cave_air
fill 328 45 -187 329 45 -187 minecraft:cave_air
fill 336 45 -187 338 45 -187 minecraft:cave_air
fill 328 45 -188 329 45 -188 minecraft:cave_air
fill 336 45 -188 338 45 -188 minecraft:cave_air
fill 328 45 -189 329 45 -189 minecraft:cave_air
fill 332 45 -189 338 45 -189 minecraft:cave_air
fill 328 45 -190 337 45 -190 minecraft:cave_air
forceload remove 328 -190 391 -127
tellraw @a {"text":"Campus zurueck a34 fertig.","color":"green"}
