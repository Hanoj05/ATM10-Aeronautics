# Abschnitt a35: x 392..455, z -190..-127 (28586 Blöcke)
forceload add 392 -190 455 -127
tellraw @a {"text":"Campus zurueck a35: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a35_1 2s
