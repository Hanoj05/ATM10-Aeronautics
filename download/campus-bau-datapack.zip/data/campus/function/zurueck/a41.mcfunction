# Abschnitt a41: x 328..391, z -126..-63 (10265 Blöcke)
forceload add 328 -126 391 -63
tellraw @a {"text":"Campus zurueck a41: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a41_1 2s
