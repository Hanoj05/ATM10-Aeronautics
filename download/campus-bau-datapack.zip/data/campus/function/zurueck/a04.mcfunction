# Abschnitt a04: x 200..263, z -446..-383 (16412 Blöcke)
forceload add 200 -446 263 -383
tellraw @a {"text":"Campus zurueck a04: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a04_1 2s
