setblock 18 90 -256 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 89 -255 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 89 -256 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 89 -256 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 89 -256 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 89 -257 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 88 -255 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 88 -255 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 88 -255 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 88 -256 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 88 -256 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 88 -256 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 88 -257 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 88 -257 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 88 -257 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 88 -270 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 24 88 -270 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 88 -270 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 88 -287 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 88 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 88 -288 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 88 -294 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 88 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 88 -295 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 17 87 -255 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 87 -255 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 87 -255 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 87 -256 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 87 -256 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 87 -256 minecraft:birch_log[axis=y]
setblock 19 87 -256 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 87 -256 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 87 -257 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 87 -257 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 87 -257 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 87 -258 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 87 -264 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 11 87 -265 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 87 -266 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 24 87 -269 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 87 -270 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 87 -270 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 87 -270 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 87 -271 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 87 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 87 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 87 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 87 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 87 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 87 -289 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 87 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 87 -291 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 87 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 87 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 87 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 87 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 87 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 87 -300 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 9 87 -301 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 87 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 87 -302 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 86 -256 minecraft:birch_log[axis=y]
setblock 26 86 -256 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 25 86 -257 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 86 -257 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 86 -258 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 86 -261 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 86 -262 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 86 -262 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 86 -264 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 86 -265 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 86 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 86 -265 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 86 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 86 -267 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 86 -268 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 86 -268 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 86 -269 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 86 -269 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 86 -269 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 86 -270 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 86 -270 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 86 -270 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 86 -271 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 86 -271 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 86 -271 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 86 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 86 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 86 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 86 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 86 -288 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 86 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 86 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 86 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 86 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 86 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 86 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 86 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 86 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 86 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 86 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 86 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 86 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 86 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 86 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 86 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 86 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 86 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 86 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 86 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 86 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 86 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 86 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 86 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 86 -311 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 11 86 -312 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 86 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 85 -256 minecraft:birch_log[axis=y]
setblock 26 85 -256 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 85 -257 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 85 -257 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 85 -257 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 85 -258 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 85 -258 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 85 -259 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 85 -259 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 85 -259 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 85 -260 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 85 -261 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 85 -262 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 85 -262 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 85 -262 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 85 -263 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 85 -264 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 85 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 85 -264 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 85 -264 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 85 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 85 -265 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 85 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 85 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 85 -266 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 85 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 85 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 85 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 85 -267 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 14 85 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 85 -268 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 85 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 85 -268 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 85 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 85 -269 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 85 -269 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 85 -269 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 85 -269 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 85 -270 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 85 -270 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 85 -270 minecraft:birch_log[axis=y]
setblock 25 85 -270 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 85 -270 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 85 -271 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 85 -271 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 85 -271 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 85 -272 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 85 -274 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 85 -274 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 85 -274 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 85 -275 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 21 85 -278 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 85 -279 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 85 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 85 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 85 -287 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 85 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 85 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 85 -288 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 85 -288 minecraft:birch_log[axis=y]
setblock 11 85 -288 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 85 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 85 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 85 -289 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 85 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 85 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 85 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 85 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 85 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 85 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 85 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 85 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 85 -290 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 13 85 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 85 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 85 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 85 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 85 -292 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 13 85 -292 14 85 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 85 -292 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 13 85 -293 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 85 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 85 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 85 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 85 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 85 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 85 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 85 -295 minecraft:birch_log[axis=y]
setblock 16 85 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 85 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 85 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 85 -296 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 85 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 85 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 85 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 85 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 85 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 85 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 85 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 85 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 85 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 85 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 85 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 85 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 85 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 85 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 85 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 85 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 85 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 84 -256 minecraft:birch_log[axis=y]
setblock 25 84 -256 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 84 -256 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 84 -256 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 84 -257 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 84 -257 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 84 -257 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 84 -258 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 84 -258 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 84 -258 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 84 -258 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 84 -259 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 84 -259 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 84 -259 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 84 -260 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 84 -261 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 84 -261 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 84 -261 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 84 -262 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 84 -262 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 84 -262 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 84 -263 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 84 -263 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 84 -263 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 84 -263 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 84 -263 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 84 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 84 -264 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 84 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 84 -264 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 84 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 84 -264 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 84 -265 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 84 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 84 -265 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 84 -265 minecraft:birch_log[axis=y]
setblock 12 84 -265 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 84 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 84 -265 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 84 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 84 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 84 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 84 -266 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 84 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 84 -266 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 84 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 84 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 84 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 84 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 84 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 84 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 84 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 84 -268 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 84 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 84 -269 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 84 -269 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 84 -269 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 84 -270 minecraft:birch_log[axis=y]
setblock 10 84 -272 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 84 -272 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 84 -273 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 84 -274 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 84 -274 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 84 -274 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 84 -275 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 84 -275 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 22 84 -276 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 84 -277 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 84 -277 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 24 84 -277 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 84 -278 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 84 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 84 -278 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 84 -278 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 21 84 -279 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 84 -280 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 84 -280 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 84 -280 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 84 -281 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 29 84 -284 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 84 -288 minecraft:birch_log[axis=y]
setblock 14 84 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 84 -288 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 13 84 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 84 -289 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 84 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 84 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 84 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 84 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 84 -290 minecraft:birch_log[axis=y]
setblock 15 84 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 84 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 84 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 84 -290 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 13 84 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 84 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 84 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 84 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 84 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 84 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 84 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 13 84 -292 14 84 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 84 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 84 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 84 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 84 -294 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 84 -295 minecraft:birch_log[axis=y]
setblock 23 84 -295 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 84 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 84 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 84 -300 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 84 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 84 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 84 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 84 -301 minecraft:birch_log[axis=y]
setblock 11 84 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 84 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 84 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 84 -302 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 84 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 84 -303 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 84 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 84 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 84 -304 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 11 84 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 84 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 84 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 84 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 84 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 84 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 84 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 84 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 84 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 83 -255 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 83 -256 minecraft:birch_log[axis=y]
setblock 25 83 -256 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 83 -256 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 83 -256 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 83 -257 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 83 -257 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 83 -257 minecraft:birch_log[axis=y]
setblock 27 83 -257 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 83 -257 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 83 -258 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 83 -258 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 83 -258 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 83 -258 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 83 -258 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 83 -258 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 83 -259 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 83 -259 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 83 -259 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 83 -259 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 25 83 -259 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 83 -260 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 83 -260 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 83 -260 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 83 -260 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 83 -260 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 83 -261 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 83 -261 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 83 -261 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 83 -262 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 83 -262 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 83 -262 minecraft:birch_log[axis=y]
setblock 21 83 -262 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 83 -262 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 83 -263 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 83 -263 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 83 -263 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 83 -263 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 83 -263 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 83 -263 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 83 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 83 -264 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 83 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 83 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 83 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 83 -265 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 83 -265 minecraft:birch_log[axis=y]
setblock 14 83 -265 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 83 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 83 -265 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 83 -266 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 83 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 83 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 83 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 83 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 83 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 83 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 83 -267 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 83 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 83 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 83 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 83 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 83 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 83 -268 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 83 -268 minecraft:birch_log[axis=y]
setblock 15 83 -268 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 83 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 83 -268 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 83 -269 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 83 -269 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 83 -269 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 83 -270 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 83 -270 minecraft:birch_log[axis=y]
setblock 10 83 -271 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 83 -272 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 83 -272 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 83 -272 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 83 -273 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 83 -273 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 83 -273 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 83 -273 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 83 -274 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 83 -274 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 83 -274 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 83 -275 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 83 -275 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 83 -275 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 83 -275 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 83 -276 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 83 -276 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 23 83 -276 24 83 -276 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 83 -277 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 83 -277 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 83 -277 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 22 83 -277 23 83 -277 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 83 -277 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 83 -277 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 83 -278 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 83 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 83 -278 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 83 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 83 -278 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 83 -279 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 83 -279 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 83 -279 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 83 -279 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 83 -280 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 83 -280 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 83 -280 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 83 -281 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 83 -283 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 31 83 -283 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 29 83 -284 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 83 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 83 -286 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 13 83 -287 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 83 -288 minecraft:birch_log[axis=y]
setblock 60 83 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 59 83 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 83 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 83 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 83 -290 minecraft:birch_log[axis=y]
setblock 25 83 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 83 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 83 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 83 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 83 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 83 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 83 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 83 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 83 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 83 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 83 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 83 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 83 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 83 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 83 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 83 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 83 -293 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 83 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 83 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 83 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 83 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 83 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 83 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 83 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 83 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 83 -295 minecraft:birch_log[axis=y]
setblock 23 83 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 83 -297 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 40 83 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 83 -301 minecraft:birch_log[axis=y]
setblock 8 83 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 83 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 83 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 83 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 83 -308 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 83 -309 9 83 -309 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 8 83 -310 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 83 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 83 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 83 -311 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 83 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 83 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 83 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 83 -312 minecraft:birch_log[axis=y]
setblock 13 83 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 83 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 83 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 83 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 83 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 83 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 83 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 82 -256 minecraft:birch_log[axis=y]
setblock 12 82 -257 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 82 -257 minecraft:birch_log[axis=y]
setblock 11 82 -258 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 82 -258 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 82 -258 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -258 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 82 -259 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -259 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 82 -259 minecraft:birch_log[axis=y]
setblock 13 82 -259 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 82 -259 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 82 -259 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 82 -259 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -260 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 82 -260 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 82 -260 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -260 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 82 -261 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -262 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 82 -262 minecraft:birch_log[axis=y]
setblock 14 82 -263 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -263 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 82 -263 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 82 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 82 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 82 -264 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 82 -264 minecraft:birch_log[axis=y]
setblock 16 82 -264 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 82 -264 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 82 -265 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 82 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -265 minecraft:birch_log[axis=y]
setblock 14 82 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -265 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 82 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 82 -266 minecraft:birch_log[axis=y]
setblock 9 82 -266 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 82 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 82 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 82 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 82 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 82 -267 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 82 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 82 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 82 -267 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 82 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 82 -267 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 82 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 82 -268 minecraft:birch_log[axis=y]
setblock 17 82 -268 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 82 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 82 -268 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 82 -268 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 82 -270 regions_unexplored:birch_branch[facing=west]
setblock 24 82 -270 minecraft:birch_log[axis=y]
setblock 9 82 -271 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 82 -271 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -271 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 82 -272 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 82 -272 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 82 -272 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -272 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 82 -273 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 82 -273 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -273 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 82 -273 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -273 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 82 -273 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 82 -274 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 82 -274 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 82 -274 minecraft:birch_log[axis=y]
setblock 16 82 -274 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 82 -274 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 82 -275 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 82 -275 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 82 -275 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -275 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 82 -275 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 82 -275 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -276 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -276 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 82 -276 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 23 82 -276 24 82 -276 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -276 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 82 -277 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 82 -277 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -277 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 22 82 -277 23 82 -277 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 82 -277 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 82 -277 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 82 -278 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 82 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 82 -278 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 82 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 82 -278 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 82 -278 minecraft:birch_log[axis=y]
setblock 22 82 -278 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 23 82 -278 24 82 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -278 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 82 -279 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 82 -279 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 82 -279 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 82 -279 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -279 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 82 -279 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -280 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 82 -280 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 82 -280 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -280 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -281 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 82 -281 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 82 -281 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 82 -283 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 30 82 -283 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 31 82 -283 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 32 82 -283 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 22 82 -284 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 82 -284 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 82 -284 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 28 82 -284 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 82 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 82 -284 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 82 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 82 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 82 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 82 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 82 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 82 -288 minecraft:birch_log[axis=y]
setblock 59 82 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 82 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 82 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 82 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 82 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 82 -289 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 61 82 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 82 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 82 -290 minecraft:birch_log[axis=y]
setblock 25 82 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 82 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 82 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 82 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 82 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 82 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 82 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 13 82 -291 14 82 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 82 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 82 -291 minecraft:birch_log[axis=y]
setblock 27 82 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 82 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 82 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 82 -292 minecraft:birch_log[axis=y]
setblock 14 82 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 82 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 82 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 82 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 82 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 82 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 82 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 82 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 82 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 82 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 82 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 82 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 82 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 82 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 82 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 82 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 82 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 82 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 82 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 82 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 82 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -295 minecraft:birch_log[axis=y]
setblock 22 82 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 82 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 82 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 82 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 82 -297 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 39 82 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 82 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 82 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 82 -298 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 27 82 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 82 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 82 -299 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 82 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 82 -301 minecraft:birch_log[axis=y]
setblock 8 82 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 82 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 82 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 82 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 82 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 82 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 82 -305 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 82 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 82 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 82 -306 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 82 -307 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 82 -307 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 82 -307 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 82 -308 integrateddynamics:menril_log[axis=y]
setblock 9 82 -308 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 82 -308 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 82 -309 9 82 -309 integrateddynamics:menril_log[axis=y]
setblock 10 82 -309 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 8 82 -310 integrateddynamics:menril_log[axis=y]
setblock 9 82 -310 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 82 -310 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 82 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 82 -311 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 82 -311 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 82 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 82 -312 minecraft:birch_log[axis=y]
setblock 20 82 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 82 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 82 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 82 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 82 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 81 -255 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 81 -256 minecraft:birch_log[axis=y]
setblock 26 81 -257 minecraft:birch_log[axis=y]
setblock 24 81 -258 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 81 -258 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 81 -258 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 81 -259 minecraft:birch_log[axis=y]
setblock 24 81 -259 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 81 -259 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 81 -260 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 81 -260 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 81 -262 minecraft:birch_log[axis=y]
setblock 15 81 -264 minecraft:birch_log[axis=y]
setblock 11 81 -265 minecraft:birch_log[axis=y]
setblock 18 81 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 81 -266 minecraft:birch_log[axis=y]
setblock 17 81 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 81 -266 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 81 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 81 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 81 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 81 -267 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 81 -267 minecraft:birch_log[axis=y]
setblock 19 81 -267 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 81 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 81 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 81 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 81 -267 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 81 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 81 -268 minecraft:birch_log[axis=y]
setblock 17 81 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 81 -268 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 81 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 81 -268 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 81 -269 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -270 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 81 -270 minecraft:birch_log[axis=y]
setblock 9 81 -271 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -271 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 81 -271 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 81 -272 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 81 -272 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 81 -272 minecraft:birch_log[axis=y]
setblock 11 81 -272 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 81 -272 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 81 -273 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -273 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 81 -273 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -274 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 81 -274 minecraft:birch_log[axis=y]
setblock 22 81 -274 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 81 -275 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 81 -275 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 23 81 -275 24 81 -275 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 81 -276 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 81 -276 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 81 -276 minecraft:birch_log[axis=y]
fill 23 81 -276 24 81 -276 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 81 -276 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -277 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 81 -277 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 81 -277 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 21 81 -277 23 81 -277 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 81 -277 minecraft:birch_log[axis=y]
setblock 25 81 -277 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 81 -277 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 81 -278 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 81 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 81 -278 minecraft:birch_log[axis=y]
setblock 22 81 -278 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 81 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 81 -278 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 81 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -279 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 81 -279 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 81 -279 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 81 -279 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 81 -279 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -280 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 81 -280 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 81 -280 minecraft:birch_log[axis=y]
setblock 13 81 -280 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 81 -280 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 81 -281 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 81 -281 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 81 -281 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 81 -282 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 81 -283 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 81 -283 minecraft:birch_log[axis=y]
setblock 31 81 -283 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 22 81 -284 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 81 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 81 -284 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 81 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 81 -284 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 81 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 81 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 81 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 81 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 81 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 81 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 81 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 81 -286 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 81 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 81 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 81 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 81 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 81 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -288 minecraft:birch_log[axis=y]
setblock 59 81 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 81 -288 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 61 81 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 81 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 81 -289 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 60 81 -289 minecraft:birch_log[axis=y]
setblock 61 81 -289 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 62 81 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 81 -290 minecraft:birch_log[axis=y]
fill 24 81 -290 25 81 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 59 81 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 81 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 61 81 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 81 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 81 -291 minecraft:birch_log[axis=y]
setblock 29 81 -291 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 60 81 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 81 -292 minecraft:birch_log[axis=y]
setblock 23 81 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 81 -292 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 29 81 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 81 -292 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 81 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 81 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 81 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 81 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 81 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 81 -293 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 81 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 81 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 81 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 81 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 81 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 81 -294 minecraft:birch_log[axis=y]
setblock 24 81 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 81 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 81 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 81 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 81 -295 minecraft:birch_log[axis=y]
setblock 22 81 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 81 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 81 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 81 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 81 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 81 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 81 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 81 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 81 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 81 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 81 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 81 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 81 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 81 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 81 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 81 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 81 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 81 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 81 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 81 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 81 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 81 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 81 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 81 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 81 -301 minecraft:birch_log[axis=y]
setblock 8 81 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 81 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 81 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 81 -304 minecraft:birch_log[axis=y]
setblock 9 81 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 81 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 81 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 81 -304 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 81 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 81 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 81 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 81 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 81 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 81 -305 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 25 81 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 81 -305 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 49 81 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 81 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 81 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 81 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 81 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 81 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 81 -307 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 81 -307 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 81 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 81 -308 integrateddynamics:menril_log[axis=y]
setblock 9 81 -308 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 81 -308 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 81 -309 9 81 -309 integrateddynamics:menril_log[axis=y]
setblock 10 81 -309 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 8 81 -310 integrateddynamics:menril_log[axis=y]
setblock 9 81 -310 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 81 -310 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 81 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 81 -311 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 81 -311 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 81 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 81 -312 minecraft:birch_log[axis=y]
setblock 16 81 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 81 -312 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 81 -313 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 81 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 81 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 81 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 81 -313 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 32 81 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 81 -313 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 81 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 81 -314 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 81 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 81 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 81 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 81 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 81 -316 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 81 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 81 -317 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 80 -256 minecraft:birch_log[axis=y]
setblock 25 80 -257 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 80 -257 minecraft:birch_log[axis=y]
setblock 24 80 -258 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 25 80 -258 26 80 -258 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 80 -259 minecraft:birch_log[axis=y]
setblock 23 80 -259 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 80 -259 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 80 -259 minecraft:birch_log[axis=y]
setblock 26 80 -259 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 80 -259 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 80 -260 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 80 -260 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 80 -260 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 80 -261 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 80 -262 minecraft:birch_log[axis=y]
setblock 15 80 -264 minecraft:birch_log[axis=y]
setblock 11 80 -265 minecraft:birch_log[axis=y]
setblock 8 80 -266 minecraft:birch_log[axis=y]
setblock 24 80 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 80 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 80 -266 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 80 -267 minecraft:birch_log[axis=y]
setblock 24 80 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 80 -267 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 80 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 80 -268 regions_unexplored:birch_branch[facing=west]
setblock 14 80 -268 minecraft:birch_log[axis=y]
setblock 24 80 -268 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 80 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 80 -268 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 80 -270 minecraft:birch_log[axis=y]
setblock 10 80 -272 minecraft:birch_log[axis=y]
setblock 15 80 -274 minecraft:birch_log[axis=y]
setblock 11 80 -276 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 80 -276 minecraft:birch_log[axis=y]
setblock 10 80 -277 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 80 -277 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 80 -277 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 80 -277 minecraft:birch_log[axis=y]
setblock 9 80 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 80 -278 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 80 -278 minecraft:birch_log[axis=y]
setblock 12 80 -278 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 80 -278 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 80 -278 minecraft:birch_log[axis=y]
setblock 10 80 -279 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 11 80 -279 12 80 -279 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 80 -280 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 80 -280 minecraft:birch_log[axis=y]
setblock 22 80 -283 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 80 -283 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 80 -283 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 80 -283 minecraft:birch_log[axis=y]
setblock 13 80 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 80 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 80 -284 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 80 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 80 -284 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 80 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 80 -285 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 80 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 80 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 80 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 80 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 80 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 80 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 80 -286 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 80 -286 minecraft:birch_log[axis=y]
setblock 14 80 -286 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 80 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 80 -286 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 48 80 -286 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 49 80 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 80 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 80 -287 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 80 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 80 -287 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 10 80 -288 minecraft:birch_log[axis=y]
setblock 13 80 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 80 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 80 -289 minecraft:birch_log[axis=y]
setblock 14 80 -290 minecraft:birch_log[axis=y]
setblock 23 80 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 80 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 80 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 80 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 80 -291 minecraft:birch_log[axis=y]
setblock 29 80 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 80 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 80 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 80 -292 minecraft:birch_log[axis=y]
setblock 28 80 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 80 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 80 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 80 -292 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 80 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 80 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 80 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 80 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 80 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 80 -294 minecraft:birch_log[axis=y]
setblock 10 80 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 80 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 80 -294 minecraft:birch_log[axis=y]
setblock 62 80 -294 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 80 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 80 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 80 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 80 -295 minecraft:birch_log[axis=y]
setblock 40 80 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 80 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 80 -295 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 9 80 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 80 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 80 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 80 -296 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 80 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 80 -296 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 80 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 80 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 28 80 -297 29 80 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 80 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 80 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 80 -297 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 35 80 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 80 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 80 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 80 -297 minecraft:birch_log[axis=y]
setblock 41 80 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 42 80 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 80 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 80 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 80 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 80 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 80 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 80 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 80 -298 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 39 80 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 80 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 80 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 80 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 80 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 80 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 80 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 80 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 80 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 80 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 80 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 80 -301 minecraft:birch_log[axis=y]
setblock 27 80 -301 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 28 80 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 80 -304 minecraft:birch_log[axis=y]
setblock 17 80 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 80 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 80 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 80 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 80 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 80 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 80 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 80 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 80 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 80 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 80 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 80 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 80 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 80 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 80 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 80 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 80 -306 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 80 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 80 -307 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 80 -307 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 80 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 80 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 80 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 80 -308 integrateddynamics:menril_log[axis=y]
setblock 9 80 -308 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 80 -308 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 80 -308 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 46 80 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 8 80 -309 9 80 -309 integrateddynamics:menril_log[axis=y]
setblock 10 80 -309 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 80 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 80 -309 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 80 -310 integrateddynamics:menril_log[axis=y]
fill 9 80 -310 10 80 -310 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 80 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 80 -311 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 80 -311 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 80 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 80 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 80 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 80 -311 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 40 80 -311 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 80 -312 minecraft:birch_log[axis=y]
setblock 15 80 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 80 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 80 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 80 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 80 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 80 -312 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 34 80 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 80 -312 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 40 80 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 80 -312 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 80 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 80 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 80 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 80 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 80 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 80 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 80 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 80 -313 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 80 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 80 -314 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 80 -314 minecraft:birch_log[axis=y]
setblock 21 80 -314 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 80 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 80 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 80 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 80 -315 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 80 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 80 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 80 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 80 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 80 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 80 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 80 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 80 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 80 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -256 minecraft:birch_log[axis=y]
setblock 26 79 -257 minecraft:birch_log[axis=y]
setblock 12 79 -259 minecraft:birch_log[axis=y]
setblock 25 79 -259 minecraft:birch_log[axis=y]
setblock 20 79 -262 minecraft:birch_log[axis=y]
setblock 15 79 -264 minecraft:birch_log[axis=y]
setblock 11 79 -265 minecraft:birch_log[axis=y]
setblock 25 79 -265 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -266 minecraft:birch_log[axis=y]
setblock 24 79 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 79 -266 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 79 -266 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -267 minecraft:birch_log[axis=y]
setblock 23 79 -267 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 79 -267 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 79 -267 minecraft:birch_log[axis=y]
setblock 26 79 -267 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 79 -268 minecraft:birch_log[axis=y]
setblock 24 79 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 79 -268 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 79 -268 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 79 -269 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 79 -270 minecraft:birch_log[axis=y]
setblock 10 79 -272 minecraft:birch_log[axis=y]
setblock 15 79 -274 minecraft:birch_log[axis=y]
setblock 22 79 -276 minecraft:birch_log[axis=y]
setblock 24 79 -277 minecraft:birch_log[axis=y]
setblock 11 79 -278 minecraft:birch_log[axis=y]
setblock 21 79 -278 minecraft:birch_log[axis=y]
setblock 12 79 -280 minecraft:birch_log[axis=y]
setblock 23 79 -282 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 79 -283 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 79 -283 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 79 -283 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 79 -283 minecraft:birch_log[axis=y]
setblock 21 79 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 79 -284 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 79 -284 minecraft:birch_log[axis=y]
setblock 24 79 -284 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 79 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 79 -284 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 79 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 79 -285 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 79 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 79 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 79 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 79 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 79 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 79 -286 minecraft:birch_log[axis=y]
setblock 23 79 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 79 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 79 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 79 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 79 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 79 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 79 -288 minecraft:birch_log[axis=y]
setblock 23 79 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 79 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 79 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 79 -289 minecraft:birch_log[axis=y]
setblock 14 79 -290 minecraft:birch_log[axis=y]
setblock 23 79 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 79 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 79 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 79 -290 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 43 79 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 79 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 79 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 79 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 79 -291 minecraft:birch_log[axis=y]
setblock 28 79 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 79 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 79 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 79 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 79 -291 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 42 79 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 79 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 79 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 79 -292 minecraft:birch_log[axis=y]
setblock 28 79 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 79 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 79 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 79 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 79 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 79 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 79 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 79 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 79 -293 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 52 79 -293 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 9 79 -294 minecraft:birch_log[axis=y]
setblock 23 79 -294 minecraft:birch_log[axis=y]
setblock 46 79 -294 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 47 79 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 79 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 79 -295 minecraft:birch_log[axis=y]
setblock 61 79 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 79 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 79 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 79 -295 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 27 79 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 79 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 79 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 79 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 79 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 79 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 79 -296 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 68 79 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 79 -296 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 79 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 79 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 79 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 28 79 -297 29 79 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 79 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 79 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 79 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 79 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 79 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 79 -297 minecraft:birch_log[axis=y]
setblock 68 79 -297 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 79 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 79 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 79 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 79 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 79 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 79 -298 minecraft:birch_log[axis=y]
setblock 28 79 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 29 79 -298 30 79 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 79 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 79 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 79 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 79 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 79 -299 minecraft:birch_log[axis=y]
setblock 21 79 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 22 79 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 79 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 79 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 79 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 79 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 79 -300 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 79 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 79 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 79 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 79 -301 minecraft:birch_log[axis=y]
setblock 20 79 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 79 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 79 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 79 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 79 -301 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 28 79 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 79 -302 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 41 79 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 79 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -304 minecraft:birch_log[axis=y]
setblock 17 79 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 79 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 79 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 79 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 79 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 79 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 79 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 79 -305 minecraft:birch_log[axis=y]
setblock 19 79 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 79 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 79 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 79 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 79 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 79 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 79 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 79 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -306 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 79 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 79 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 79 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 79 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 79 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 79 -306 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 79 -306 minecraft:birch_log[axis=y]
setblock 50 79 -306 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 79 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -307 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 79 -307 integrateddynamics:menril_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 79 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 79 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 79 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 79 -307 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 79 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -308 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
fill 9 79 -308 10 79 -308 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 79 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 79 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 79 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 79 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -309 integrateddynamics:menril_log[axis=y]
fill 9 79 -309 10 79 -309 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 79 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 79 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 79 -309 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 62 79 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 79 -309 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 8 79 -310 9 79 -310 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 79 -310 minecraft:birch_log[axis=y]
setblock 11 79 -310 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 79 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 79 -310 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 8 79 -311 9 79 -311 integrateddynamics:menril_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 79 -311 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 79 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 79 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 79 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 79 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 79 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 79 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 79 -312 minecraft:birch_log[axis=y]
setblock 15 79 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 79 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 79 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 79 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 79 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 79 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 79 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 79 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 79 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 79 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 79 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 79 -313 regions_unexplored:birch_branch[facing=north]
setblock 15 79 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 79 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 79 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 79 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 79 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 79 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 79 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 79 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 79 -314 minecraft:birch_log[axis=y]
setblock 31 79 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 79 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 79 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 79 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 79 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 79 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 79 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 79 -316 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 25 79 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 79 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 79 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 79 -317 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 47 79 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 79 -317 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 25 79 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 79 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 79 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 79 -318 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 78 -256 minecraft:birch_log[axis=y]
setblock 26 78 -257 minecraft:birch_log[axis=y]
setblock 12 78 -259 minecraft:birch_log[axis=y]
setblock 25 78 -259 minecraft:birch_log[axis=y]
setblock 20 78 -262 minecraft:birch_log[axis=y]
setblock 15 78 -264 minecraft:birch_log[axis=y]
setblock 11 78 -265 minecraft:birch_log[axis=y]
setblock 8 78 -266 minecraft:birch_log[axis=y]
setblock 18 78 -267 minecraft:birch_log[axis=y]
setblock 25 78 -267 minecraft:birch_log[axis=y]
setblock 14 78 -268 minecraft:birch_log[axis=y]
setblock 24 78 -270 minecraft:birch_log[axis=y]
setblock 10 78 -272 minecraft:birch_log[axis=y]
setblock 15 78 -274 minecraft:birch_log[axis=y]
setblock 22 78 -276 minecraft:birch_log[axis=y]
setblock 24 78 -277 minecraft:birch_log[axis=y]
setblock 11 78 -278 minecraft:birch_log[axis=y]
setblock 21 78 -278 minecraft:birch_log[axis=y]
setblock 12 78 -280 minecraft:birch_log[axis=y]
setblock 29 78 -283 minecraft:birch_log[axis=y]
setblock 23 78 -284 minecraft:birch_log[axis=y]
setblock 42 78 -284 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 78 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 78 -284 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 42 78 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 78 -285 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 78 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 78 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 78 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 78 -285 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 78 -286 minecraft:birch_log[axis=y]
setblock 42 78 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 78 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 78 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 78 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 78 -286 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 78 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 78 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 78 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 78 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 78 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -288 minecraft:birch_log[axis=y]
setblock 24 78 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 78 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 78 -289 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 78 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 78 -289 minecraft:birch_log[axis=y]
setblock 14 78 -290 minecraft:birch_log[axis=y]
setblock 22 78 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 78 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 78 -290 minecraft:birch_log[axis=y]
fill 25 78 -290 26 78 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 78 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 78 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 42 78 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 78 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 78 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 78 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 24 78 -291 25 78 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 78 -291 minecraft:birch_log[axis=y]
setblock 28 78 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 78 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 78 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 78 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 78 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 78 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 42 78 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 78 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 78 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 78 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 78 -292 minecraft:birch_log[axis=y]
setblock 24 78 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 78 -292 regions_unexplored:birch_branch[facing=north]
fill 27 78 -292 28 78 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 78 -292 minecraft:birch_log[axis=y]
setblock 30 78 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 78 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 78 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 42 78 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 78 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 78 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 78 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 78 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 78 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 78 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 78 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 78 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 78 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 78 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 78 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 78 -294 minecraft:birch_log[axis=y]
setblock 23 78 -294 minecraft:birch_log[axis=y]
setblock 29 78 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 78 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 78 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 78 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 78 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 78 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 78 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 78 -294 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 78 -295 minecraft:birch_log[axis=y]
setblock 30 78 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 78 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 78 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 78 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 78 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 78 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 78 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 78 -296 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 78 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 78 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 78 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 78 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 78 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 78 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 78 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 78 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 78 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 78 -296 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 78 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 78 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 78 -297 minecraft:birch_log[axis=y]
setblock 31 78 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 78 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 78 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 78 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 78 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 78 -297 minecraft:birch_log[axis=y]
setblock 68 78 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 78 -298 minecraft:birch_log[axis=y]
setblock 29 78 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 78 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 78 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 78 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 78 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 78 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 78 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 78 -298 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 20 78 -299 minecraft:birch_log[axis=y]
setblock 30 78 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 78 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 78 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 78 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -301 minecraft:birch_log[axis=y]
setblock 27 78 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 78 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 78 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 78 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 78 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 78 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 78 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 78 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 78 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 78 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 78 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 78 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 78 -303 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 41 78 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -304 minecraft:birch_log[axis=y]
setblock 24 78 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 78 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 78 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 78 -304 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 39 78 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 78 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 78 -304 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 78 -305 minecraft:birch_log[axis=y]
setblock 23 78 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 78 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 78 -305 minecraft:birch_log[axis=y]
setblock 26 78 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 78 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 78 -305 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 24 78 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 78 -306 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 78 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 78 -306 minecraft:birch_log[axis=y]
setblock 25 78 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 78 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 78 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 78 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 78 -307 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 64 78 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 78 -307 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 78 -308 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 78 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 78 -308 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 78 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 78 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 78 -308 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 78 -309 integrateddynamics:menril_log[axis=y]
setblock 9 78 -309 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 78 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 78 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 78 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 78 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 78 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 78 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -310 integrateddynamics:menril_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 78 -310 minecraft:birch_log[axis=y]
setblock 16 78 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 78 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 78 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 78 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 78 -311 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 78 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 78 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 78 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 78 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 78 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 78 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 78 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 78 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 78 -311 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 64 78 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 78 -312 minecraft:birch_log[axis=y]
setblock 14 78 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 78 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 78 -312 minecraft:birch_log[axis=y]
setblock 17 78 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 78 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 78 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 78 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 78 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 78 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 78 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 78 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 78 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 78 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 63 78 -312 65 78 -312 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 78 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 78 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 78 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 78 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 78 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 78 -313 minecraft:birch_log[axis=y]
setblock 33 78 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 34 78 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 78 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 78 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 78 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 78 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 78 -313 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 78 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 78 -314 minecraft:birch_log[axis=y]
setblock 31 78 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 78 -314 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 78 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 78 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 78 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 78 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 78 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 78 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 78 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 78 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 78 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 78 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 78 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 78 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 78 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 78 -317 minecraft:birch_log[axis=y]
setblock 27 78 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 78 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 78 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 78 -317 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 36 78 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 78 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 78 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 78 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 78 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 78 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 78 -318 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 78 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 78 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 61 78 -318 62 78 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 77 -255 minecraft:short_grass
setblock 11 77 -256 minecraft:short_grass
setblock 12 77 -256 minecraft:grass_block[snowy=false]
setblock 18 77 -256 minecraft:birch_log[axis=y]
setblock 26 77 -257 minecraft:birch_log[axis=y]
setblock 9 77 -258 minecraft:short_grass
setblock 12 77 -259 minecraft:birch_log[axis=y]
fill 13 77 -259 14 77 -259 minecraft:short_grass
setblock 25 77 -259 minecraft:birch_log[axis=y]
setblock 15 77 -261 minecraft:short_grass
setblock 11 77 -262 minecraft:short_grass
setblock 20 77 -262 minecraft:birch_log[axis=y]
setblock 15 77 -264 minecraft:birch_log[axis=y]
setblock 11 77 -265 minecraft:birch_log[axis=y]
setblock 14 77 -265 minecraft:short_grass
setblock 8 77 -266 minecraft:birch_log[axis=y]
setblock 18 77 -267 minecraft:birch_log[axis=y]
setblock 25 77 -267 minecraft:birch_log[axis=y]
setblock 14 77 -268 minecraft:birch_log[axis=y]
setblock 24 77 -270 minecraft:birch_log[axis=y]
setblock 10 77 -272 minecraft:birch_log[axis=y]
setblock 15 77 -274 minecraft:birch_log[axis=y]
setblock 22 77 -276 minecraft:birch_log[axis=y]
setblock 16 77 -277 herbsandharvest:thistle[half=upper]
setblock 24 77 -277 minecraft:birch_log[axis=y]
setblock 11 77 -278 minecraft:birch_log[axis=y]
setblock 21 77 -278 minecraft:birch_log[axis=y]
setblock 12 77 -280 minecraft:birch_log[axis=y]
setblock 29 77 -283 minecraft:birch_log[axis=y]
setblock 43 77 -283 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 77 -284 minecraft:birch_log[axis=y]
setblock 42 77 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 77 -284 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 77 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 77 -284 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 77 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 77 -285 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 43 77 -285 minecraft:birch_log[axis=y]
setblock 44 77 -285 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 77 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 77 -285 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 77 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 77 -286 minecraft:birch_log[axis=y]
setblock 42 77 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 77 -286 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 77 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 77 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -286 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 77 -286 minecraft:birch_log[axis=y]
setblock 50 77 -286 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 77 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 77 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 77 -287 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 43 77 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 77 -287 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 77 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 77 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 77 -288 minecraft:birch_log[axis=y]
setblock 29 77 -288 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 30 77 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 77 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 77 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 77 -289 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 43 77 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 77 -289 minecraft:birch_log[axis=y]
setblock 14 77 -290 minecraft:birch_log[axis=y]
setblock 24 77 -290 minecraft:birch_log[axis=y]
setblock 39 77 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 77 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 77 -290 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 42 77 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 77 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 77 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 77 -291 minecraft:birch_log[axis=y]
setblock 39 77 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 77 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 77 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 43 77 -291 minecraft:birch_log[axis=y]
setblock 44 77 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 77 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 77 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -291 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 77 -292 minecraft:birch_log[axis=y]
setblock 29 77 -292 minecraft:birch_log[axis=y]
setblock 39 77 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 77 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 77 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 42 77 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 43 77 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 77 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 77 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 77 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 77 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 77 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 43 77 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 77 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 77 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 77 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 77 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 77 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 77 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 77 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 77 -294 minecraft:birch_log[axis=y]
setblock 23 77 -294 minecraft:birch_log[axis=y]
setblock 46 77 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 77 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 77 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 77 -294 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 56 77 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 77 -294 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 61 77 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 77 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 77 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 77 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 77 -295 minecraft:birch_log[axis=y]
setblock 35 77 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 77 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 77 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 77 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 77 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 62 77 -295 minecraft:birch_log[axis=y]
setblock 63 77 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 77 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 77 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 77 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 77 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 77 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 77 -296 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 77 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 77 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 77 -296 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 77 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 77 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 77 -296 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 77 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 77 -297 minecraft:birch_log[axis=y]
setblock 33 77 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 77 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 77 -297 minecraft:birch_log[axis=y]
setblock 36 77 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 77 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -297 minecraft:birch_log[axis=y]
setblock 49 77 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 77 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 77 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 77 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 77 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 77 -298 minecraft:birch_log[axis=y]
setblock 34 77 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 77 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 77 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 77 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 77 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 77 -299 minecraft:birch_log[axis=y]
setblock 28 77 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 77 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 77 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 77 -299 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 49 77 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 58 77 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 77 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 77 -300 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 77 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 77 -300 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 56 77 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 77 -301 minecraft:birch_log[axis=y]
setblock 26 77 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 77 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 77 -301 minecraft:birch_log[axis=y]
setblock 29 77 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 77 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 77 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 77 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 77 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 77 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 77 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 58 77 -301 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 59 77 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 77 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 77 -302 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 77 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 77 -302 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 42 77 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 77 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 59 77 -302 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 28 77 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 39 77 -303 40 77 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 77 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 77 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 77 -304 minecraft:birch_log[axis=y]
setblock 38 77 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 77 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 77 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 77 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -305 minecraft:birch_log[axis=y]
setblock 25 77 -305 minecraft:birch_log[axis=y]
setblock 39 77 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 77 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 77 -306 minecraft:birch_log[axis=y]
setblock 64 77 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 77 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 77 -307 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 77 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 77 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 77 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 77 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 77 -308 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 77 -308 minecraft:birch_log[axis=y]
setblock 47 77 -308 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 77 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 77 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 77 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 63 77 -308 64 77 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 77 -309 integrateddynamics:menril_log_filled[axis=y,facing=east]
setblock 45 77 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 77 -309 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 77 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 77 -309 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 61 77 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 77 -309 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 77 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -310 minecraft:birch_log[axis=y]
setblock 34 77 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 77 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 45 77 -310 46 77 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 77 -310 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 51 77 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -310 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 61 77 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 77 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 77 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 77 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 77 -311 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 77 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 77 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -311 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 77 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 77 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 77 -312 minecraft:birch_log[axis=y]
setblock 16 77 -312 minecraft:birch_log[axis=y]
fill 32 77 -312 33 77 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 34 77 -312 minecraft:birch_log[axis=y]
setblock 35 77 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 77 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 77 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 77 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 77 -312 minecraft:birch_log[axis=y]
setblock 41 77 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 42 77 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -312 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 63 77 -312 65 77 -312 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 77 -313 minecraft:birch_log[axis=y]
fill 33 77 -313 34 77 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 77 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 77 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 77 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 77 -313 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 77 -314 minecraft:birch_log[axis=y]
setblock 34 77 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -314 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 53 77 -314 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 30 77 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 77 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 77 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 47 77 -315 48 77 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 77 -315 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 30 77 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 77 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 77 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 77 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 77 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 77 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 77 -316 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 77 -317 minecraft:birch_log[axis=y]
setblock 30 77 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 77 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 77 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 77 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 77 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 77 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 77 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 77 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 77 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 77 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 77 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 77 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 77 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 77 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 77 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 77 -318 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 60 77 -318 62 77 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 76 -255 17 76 -255 minecraft:grass_block[snowy=false]
fill 8 76 -256 11 76 -256 minecraft:grass_block[snowy=false]
setblock 12 76 -256 minecraft:dirt
fill 13 76 -256 17 76 -256 minecraft:grass_block[snowy=false]
setblock 18 76 -256 minecraft:birch_log[axis=y]
fill 8 76 -257 17 76 -257 minecraft:grass_block[snowy=false]
setblock 26 76 -257 minecraft:birch_log[axis=y]
fill 8 76 -258 17 76 -258 minecraft:grass_block[snowy=false]
fill 8 76 -259 11 76 -259 minecraft:grass_block[snowy=false]
setblock 12 76 -259 minecraft:dirt
fill 13 76 -259 17 76 -259 minecraft:grass_block[snowy=false]
setblock 25 76 -259 minecraft:birch_log[axis=y]
fill 8 76 -260 17 76 -260 minecraft:grass_block[snowy=false]
setblock 19 76 -260 naturesaura:aura_bloom
fill 8 76 -261 17 76 -261 minecraft:grass_block[snowy=false]
fill 8 76 -262 17 76 -262 minecraft:grass_block[snowy=false]
setblock 20 76 -262 minecraft:birch_log[axis=y]
fill 9 76 -263 17 76 -263 minecraft:grass_block[snowy=false]
setblock 19 76 -263 naturesaura:aura_bloom
setblock 20 76 -263 minecraft:short_grass
fill 9 76 -264 14 76 -264 minecraft:grass_block[snowy=false]
setblock 15 76 -264 minecraft:dirt
fill 16 76 -264 17 76 -264 minecraft:grass_block[snowy=false]
setblock 18 76 -264 minecraft:short_grass
setblock 11 76 -265 minecraft:dirt
fill 12 76 -265 16 76 -265 minecraft:grass_block[snowy=false]
setblock 8 76 -266 minecraft:birch_log[axis=y]
setblock 18 76 -267 minecraft:birch_log[axis=y]
setblock 25 76 -267 minecraft:birch_log[axis=y]
setblock 14 76 -268 minecraft:birch_log[axis=y]
setblock 24 76 -270 minecraft:birch_log[axis=y]
setblock 16 76 -271 minecraft:grass_block[snowy=false]
setblock 10 76 -272 minecraft:birch_log[axis=y]
fill 15 76 -272 17 76 -272 minecraft:grass_block[snowy=false]
setblock 16 76 -273 minecraft:grass_block[snowy=false]
setblock 14 76 -274 minecraft:short_grass
setblock 15 76 -274 minecraft:birch_log[axis=y]
setblock 16 76 -274 minecraft:grass_block[snowy=false]
setblock 19 76 -274 minecraft:short_grass
setblock 22 76 -276 minecraft:birch_log[axis=y]
setblock 14 76 -277 minecraft:short_grass
setblock 16 76 -277 herbsandharvest:thistle[half=lower]
setblock 17 76 -277 minecraft:short_grass
setblock 24 76 -277 minecraft:birch_log[axis=y]
setblock 11 76 -278 minecraft:birch_log[axis=y]
setblock 21 76 -278 minecraft:birch_log[axis=y]
setblock 12 76 -280 minecraft:birch_log[axis=y]
setblock 29 76 -283 minecraft:birch_log[axis=y]
setblock 23 76 -284 minecraft:birch_log[axis=y]
setblock 43 76 -285 minecraft:birch_log[axis=y]
setblock 13 76 -286 minecraft:birch_log[axis=y]
setblock 49 76 -286 minecraft:birch_log[axis=y]
setblock 51 76 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 76 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 76 -286 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 76 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 76 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -287 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 76 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 76 -288 minecraft:birch_log[axis=y]
setblock 29 76 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 76 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 76 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 76 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 76 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 76 -288 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 76 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 76 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 76 -289 minecraft:birch_log[axis=y]
setblock 14 76 -290 minecraft:birch_log[axis=y]
setblock 24 76 -290 minecraft:birch_log[axis=y]
setblock 39 76 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 76 -290 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 76 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 76 -291 minecraft:birch_log[axis=y]
setblock 38 76 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 76 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 76 -291 minecraft:birch_log[axis=y]
fill 41 76 -291 42 76 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 43 76 -291 minecraft:birch_log[axis=y]
setblock 51 76 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -291 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 76 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 76 -292 minecraft:birch_log[axis=y]
setblock 29 76 -292 minecraft:birch_log[axis=y]
setblock 39 76 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 76 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 76 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 76 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 76 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 76 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 76 -292 minecraft:birch_log[axis=y]
setblock 53 76 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 76 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 76 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 76 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 76 -292 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 76 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 76 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 76 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 76 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 76 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 76 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 76 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 76 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 76 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 76 -294 minecraft:birch_log[axis=y]
setblock 23 76 -294 minecraft:birch_log[axis=y]
setblock 45 76 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 76 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 76 -294 minecraft:birch_log[axis=y]
setblock 48 76 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 76 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 76 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 76 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 76 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 76 -294 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 67 76 -294 68 76 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 76 -295 minecraft:birch_log[axis=y]
setblock 46 76 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 76 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 76 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 76 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 76 -295 minecraft:birch_log[axis=y]
setblock 67 76 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 76 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 76 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 76 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 76 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -296 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 76 -296 minecraft:birch_log[axis=y]
setblock 69 76 -296 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 70 76 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 76 -297 minecraft:birch_log[axis=y]
setblock 35 76 -297 minecraft:birch_log[axis=y]
setblock 40 76 -297 minecraft:birch_log[axis=y]
setblock 48 76 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 76 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 76 -297 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 67 76 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 76 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 76 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 76 -298 minecraft:birch_log[axis=y]
setblock 46 76 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 76 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 76 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 76 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 76 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 76 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 76 -299 minecraft:birch_log[axis=y]
setblock 45 76 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 76 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 47 76 -299 48 76 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 76 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 76 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 76 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 58 76 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 76 -299 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 76 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 76 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 76 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 76 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 57 76 -300 59 76 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 76 -301 minecraft:birch_log[axis=y]
setblock 28 76 -301 minecraft:birch_log[axis=y]
setblock 40 76 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 76 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 42 76 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 76 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 76 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 76 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 76 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 59 76 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 76 -301 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 76 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 76 -302 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 76 -302 minecraft:birch_log[axis=y]
setblock 42 76 -302 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 43 76 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 76 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 76 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 76 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 59 76 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 76 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 39 76 -303 40 76 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 76 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 42 76 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 76 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 76 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 76 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 76 -304 minecraft:birch_log[axis=y]
setblock 38 76 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 76 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 40 76 -304 41 76 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 76 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 76 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 76 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 76 -305 minecraft:birch_log[axis=y]
setblock 25 76 -305 minecraft:birch_log[axis=y]
setblock 38 76 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 76 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 76 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 76 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 76 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 76 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 76 -306 minecraft:birch_log[axis=y]
setblock 63 76 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 76 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 76 -306 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 62 76 -307 63 76 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 76 -307 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 76 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 76 -308 minecraft:birch_log[axis=y]
setblock 55 76 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 76 -308 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 61 76 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 76 -308 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 63 76 -308 64 76 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 76 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 76 -309 integrateddynamics:menril_log[axis=y]
setblock 44 76 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 76 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 76 -309 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 76 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 60 76 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 76 -309 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 62 76 -309 minecraft:birch_log[axis=y]
setblock 63 76 -309 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 76 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 69 76 -309 70 76 -309 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 76 -310 minecraft:birch_log[axis=y]
setblock 44 76 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 76 -310 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 76 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 76 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 76 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -310 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 76 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 76 -310 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 76 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 76 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 76 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 76 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 76 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 76 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 76 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 63 76 -311 65 76 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 76 -312 minecraft:birch_log[axis=y]
setblock 16 76 -312 minecraft:birch_log[axis=y]
setblock 34 76 -312 minecraft:birch_log[axis=y]
setblock 40 76 -312 minecraft:birch_log[axis=y]
setblock 53 76 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 63 76 -312 65 76 -312 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 76 -313 minecraft:birch_log[axis=y]
setblock 52 76 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 76 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 76 -313 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 63 76 -313 65 76 -313 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 76 -314 minecraft:birch_log[axis=y]
setblock 31 76 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 76 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 76 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 76 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 76 -315 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 76 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 47 76 -315 48 76 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 76 -315 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 76 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 76 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 76 -316 minecraft:birch_log[axis=y]
setblock 32 76 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 33 76 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 76 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 76 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 76 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 76 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 76 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 76 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 76 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 76 -317 minecraft:birch_log[axis=y]
setblock 30 76 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 76 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 76 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 76 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 76 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 76 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 76 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 76 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 76 -317 minecraft:birch_log[axis=y]
setblock 48 76 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 76 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 76 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 76 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -317 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 60 76 -317 62 76 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 76 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 76 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 76 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 76 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 76 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 76 -318 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 76 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 76 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 60 76 -318 62 76 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 75 -255 17 75 -255 minecraft:dirt
fill 18 75 -255 19 75 -255 minecraft:grass_block[snowy=false]
fill 8 75 -256 18 75 -256 minecraft:dirt
setblock 19 75 -256 minecraft:grass_block[snowy=false]
fill 8 75 -257 17 75 -257 minecraft:dirt
fill 18 75 -257 19 75 -257 minecraft:grass_block[snowy=false]
setblock 26 75 -257 minecraft:birch_log[axis=y]
fill 8 75 -258 17 75 -258 minecraft:dirt
fill 18 75 -258 19 75 -258 minecraft:grass_block[snowy=false]
fill 8 75 -259 17 75 -259 minecraft:dirt
fill 18 75 -259 20 75 -259 minecraft:grass_block[snowy=false]
setblock 22 75 -259 minecraft:short_grass
setblock 25 75 -259 minecraft:birch_log[axis=y]
fill 8 75 -260 17 75 -260 minecraft:dirt
fill 18 75 -260 20 75 -260 minecraft:grass_block[snowy=false]
setblock 21 75 -260 minecraft:short_grass
fill 8 75 -261 17 75 -261 minecraft:dirt
fill 18 75 -261 20 75 -261 minecraft:grass_block[snowy=false]
setblock 22 75 -261 minecraft:short_grass
fill 8 75 -262 17 75 -262 minecraft:dirt
fill 18 75 -262 19 75 -262 minecraft:grass_block[snowy=false]
setblock 20 75 -262 minecraft:dirt
setblock 22 75 -262 minecraft:short_grass
setblock 8 75 -263 minecraft:grass_block[snowy=false]
fill 9 75 -263 17 75 -263 minecraft:dirt
fill 18 75 -263 20 75 -263 minecraft:grass_block[snowy=false]
setblock 22 75 -263 minecraft:short_grass
setblock 8 75 -264 minecraft:grass_block[snowy=false]
fill 9 75 -264 17 75 -264 minecraft:dirt
fill 18 75 -264 19 75 -264 minecraft:grass_block[snowy=false]
setblock 22 75 -264 minecraft:short_grass
fill 8 75 -265 10 75 -265 minecraft:grass_block[snowy=false]
fill 11 75 -265 16 75 -265 minecraft:dirt
fill 17 75 -265 19 75 -265 minecraft:grass_block[snowy=false]
setblock 8 75 -266 minecraft:dirt
fill 9 75 -266 18 75 -266 minecraft:grass_block[snowy=false]
fill 8 75 -267 17 75 -267 minecraft:grass_block[snowy=false]
setblock 18 75 -267 minecraft:birch_log[axis=y]
setblock 25 75 -267 minecraft:birch_log[axis=y]
fill 8 75 -268 13 75 -268 minecraft:grass_block[snowy=false]
setblock 14 75 -268 minecraft:dirt
fill 15 75 -268 16 75 -268 minecraft:grass_block[snowy=false]
fill 18 75 -268 19 75 -268 naturesaura:aura_bloom
fill 12 75 -269 17 75 -269 minecraft:grass_block[snowy=false]
fill 12 75 -270 18 75 -270 minecraft:grass_block[snowy=false]
setblock 24 75 -270 minecraft:birch_log[axis=y]
fill 13 75 -271 15 75 -271 minecraft:grass_block[snowy=false]
setblock 16 75 -271 minecraft:dirt
fill 17 75 -271 20 75 -271 minecraft:grass_block[snowy=false]
setblock 10 75 -272 minecraft:birch_log[axis=y]
fill 13 75 -272 14 75 -272 minecraft:grass_block[snowy=false]
fill 15 75 -272 17 75 -272 minecraft:dirt
fill 18 75 -272 20 75 -272 minecraft:grass_block[snowy=false]
fill 12 75 -273 15 75 -273 minecraft:grass_block[snowy=false]
setblock 16 75 -273 minecraft:dirt
fill 17 75 -273 20 75 -273 minecraft:grass_block[snowy=false]
fill 12 75 -274 14 75 -274 minecraft:grass_block[snowy=false]
fill 15 75 -274 16 75 -274 minecraft:dirt
fill 17 75 -274 20 75 -274 minecraft:grass_block[snowy=false]
fill 12 75 -275 20 75 -275 minecraft:grass_block[snowy=false]
fill 12 75 -276 20 75 -276 minecraft:grass_block[snowy=false]
setblock 21 75 -276 minecraft:short_grass
setblock 22 75 -276 minecraft:birch_log[axis=y]
fill 12 75 -277 20 75 -277 minecraft:grass_block[snowy=false]
setblock 24 75 -277 minecraft:birch_log[axis=y]
setblock 11 75 -278 minecraft:birch_log[axis=y]
fill 12 75 -278 18 75 -278 minecraft:grass_block[snowy=false]
setblock 20 75 -278 minecraft:short_grass
setblock 21 75 -278 minecraft:birch_log[axis=y]
fill 12 75 -279 17 75 -279 minecraft:grass_block[snowy=false]
setblock 21 75 -279 minecraft:short_grass
setblock 12 75 -280 minecraft:birch_log[axis=y]
fill 15 75 -280 16 75 -280 minecraft:grass_block[snowy=false]
setblock 15 75 -281 minecraft:short_grass
setblock 19 75 -281 regions_unexplored:grass_sprouts
setblock 17 75 -282 regions_unexplored:grass_sprouts
setblock 20 75 -282 minecraft:short_grass
setblock 29 75 -283 minecraft:birch_log[axis=y]
setblock 30 75 -283 regions_unexplored:birch_branch[facing=east]
setblock 23 75 -284 minecraft:birch_log[axis=y]
setblock 43 75 -285 minecraft:birch_log[axis=y]
setblock 52 75 -285 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 75 -286 minecraft:short_grass
setblock 13 75 -286 minecraft:birch_log[axis=y]
setblock 49 75 -286 minecraft:birch_log[axis=y]
setblock 51 75 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -286 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 75 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 75 -287 minecraft:short_grass
setblock 12 75 -287 minecraft:short_grass
setblock 29 75 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 75 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 75 -287 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 75 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -287 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 75 -287 minecraft:birch_log[axis=y]
setblock 53 75 -287 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 75 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 75 -288 minecraft:short_grass
setblock 10 75 -288 minecraft:birch_log[axis=y]
setblock 11 75 -288 minecraft:short_grass
setblock 29 75 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 75 -288 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 75 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -288 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 75 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 75 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 75 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 75 -289 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 75 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 75 -289 minecraft:birch_log[axis=y]
setblock 9 75 -290 regions_unexplored:grass_sprouts
setblock 13 75 -290 regions_unexplored:grass_sprouts
setblock 14 75 -290 minecraft:birch_log[axis=y]
setblock 24 75 -290 minecraft:birch_log[axis=y]
setblock 26 75 -291 minecraft:birch_log[axis=y]
setblock 40 75 -291 minecraft:birch_log[axis=y]
setblock 43 75 -291 minecraft:birch_log[axis=y]
setblock 67 75 -291 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 75 -292 regions_unexplored:grass_sprouts
setblock 13 75 -292 minecraft:birch_log[axis=y]
setblock 29 75 -292 minecraft:birch_log[axis=y]
setblock 52 75 -292 minecraft:birch_log[axis=y]
setblock 66 75 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 75 -292 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 75 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 75 -293 regions_unexplored:grass_sprouts
setblock 55 75 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 75 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 75 -293 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 75 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 75 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 67 75 -293 minecraft:birch_log[axis=y]
setblock 68 75 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 75 -294 minecraft:birch_log[axis=y]
setblock 23 75 -294 minecraft:birch_log[axis=y]
setblock 47 75 -294 minecraft:birch_log[axis=y]
setblock 55 75 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 75 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 75 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 75 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 75 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 75 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 75 -295 minecraft:birch_log[axis=y]
setblock 55 75 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 75 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 75 -295 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 75 -295 minecraft:birch_log[axis=y]
setblock 67 75 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 75 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 75 -296 minecraft:birch_log[axis=y]
setblock 30 75 -297 minecraft:birch_log[axis=y]
setblock 35 75 -297 minecraft:birch_log[axis=y]
setblock 40 75 -297 minecraft:birch_log[axis=y]
setblock 48 75 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 75 -297 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 75 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 75 -298 minecraft:birch_log[axis=y]
setblock 45 75 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 46 75 -298 47 75 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 75 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 75 -298 minecraft:birch_log[axis=y]
setblock 50 75 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 75 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 75 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 58 75 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 75 -298 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 75 -299 minecraft:birch_log[axis=y]
setblock 45 75 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 75 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 47 75 -299 48 75 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 75 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 75 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 56 75 -299 57 75 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 75 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 59 75 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 75 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 46 75 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 75 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 75 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 75 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 75 -300 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 57 75 -300 59 75 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 75 -300 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 75 -301 minecraft:birch_log[axis=y]
setblock 28 75 -301 minecraft:birch_log[axis=y]
setblock 54 75 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 75 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 75 -301 minecraft:birch_log[axis=y]
setblock 57 75 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 75 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 75 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 60 75 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 75 -302 minecraft:birch_log[axis=y]
setblock 55 75 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 75 -302 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 75 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 75 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 59 75 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 75 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 75 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 75 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 75 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 75 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 75 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 75 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 75 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 75 -304 minecraft:birch_log[axis=y]
setblock 37 75 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 75 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 75 -304 minecraft:birch_log[axis=y]
setblock 40 75 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 75 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 75 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 75 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 75 -304 minecraft:birch_log[axis=y]
setblock 65 75 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 66 75 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 75 -305 minecraft:birch_log[axis=y]
setblock 25 75 -305 minecraft:birch_log[axis=y]
setblock 38 75 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 75 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 75 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 75 -305 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 75 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 75 -306 minecraft:birch_log[axis=y]
setblock 63 75 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 75 -306 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 75 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 75 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 75 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 75 -307 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 75 -307 minecraft:birch_log[axis=y]
setblock 65 75 -307 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 66 75 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 75 -308 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 75 -308 minecraft:birch_log[axis=y]
setblock 54 75 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 75 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 75 -308 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 75 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 75 -308 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 75 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 75 -308 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 8 75 -309 integrateddynamics:menril_log[axis=y]
setblock 44 75 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 45 75 -309 46 75 -309 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 75 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 75 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 75 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 75 -309 minecraft:birch_log[axis=y]
setblock 64 75 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 69 75 -309 71 75 -309 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 75 -310 minecraft:birch_log[axis=y]
setblock 43 75 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 75 -310 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 75 -310 minecraft:birch_log[axis=y]
setblock 46 75 -310 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 75 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 75 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -310 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 75 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 75 -310 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 75 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 44 75 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 75 -311 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 75 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 75 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 75 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -311 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 63 75 -311 65 75 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 75 -312 minecraft:birch_log[axis=y]
setblock 16 75 -312 minecraft:birch_log[axis=y]
setblock 34 75 -312 minecraft:birch_log[axis=y]
setblock 40 75 -312 minecraft:birch_log[axis=y]
setblock 45 75 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 75 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 75 -312 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 62 75 -312 63 75 -312 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 75 -312 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 65 75 -312 66 75 -312 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 75 -313 minecraft:birch_log[axis=y]
setblock 52 75 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 75 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 75 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 63 75 -313 65 75 -313 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 75 -314 minecraft:birch_log[axis=y]
setblock 47 75 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 75 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 75 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 75 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 75 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 75 -314 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 75 -314 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 75 -315 regions_unexplored:birch_shrub[half=upper]
setblock 36 75 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 75 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 75 -315 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 75 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 75 -316 minecraft:birch_log[axis=y]
setblock 35 75 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 75 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 75 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 75 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 75 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 49 75 -316 50 75 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 75 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -316 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 75 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 75 -317 minecraft:birch_log[axis=y]
setblock 34 75 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 75 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 75 -317 minecraft:birch_log[axis=y]
setblock 37 75 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 75 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 75 -317 minecraft:birch_log[axis=y]
setblock 50 75 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 75 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 75 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 60 75 -317 62 75 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 75 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 75 -318 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 75 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 75 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 75 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 75 -318 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 59 75 -318 60 75 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 61 75 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 62 75 -318 63 75 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 11 74 -255 19 74 -255 minecraft:dirt
fill 20 74 -255 21 74 -255 minecraft:grass_block[snowy=false]
fill 11 74 -256 19 74 -256 minecraft:dirt
fill 20 74 -256 21 74 -256 minecraft:grass_block[snowy=false]
fill 12 74 -257 19 74 -257 minecraft:dirt
fill 20 74 -257 21 74 -257 minecraft:grass_block[snowy=false]
setblock 26 74 -257 minecraft:birch_log[axis=y]
fill 11 74 -258 19 74 -258 minecraft:dirt
fill 20 74 -258 22 74 -258 minecraft:grass_block[snowy=false]
fill 10 74 -259 20 74 -259 minecraft:dirt
fill 21 74 -259 22 74 -259 minecraft:grass_block[snowy=false]
setblock 24 74 -259 naturesaura:aura_bloom
setblock 25 74 -259 minecraft:birch_log[axis=y]
fill 8 74 -260 20 74 -260 minecraft:dirt
fill 21 74 -260 22 74 -260 minecraft:grass_block[snowy=false]
setblock 23 74 -260 naturesaura:aura_bloom
fill 8 74 -261 20 74 -261 minecraft:dirt
fill 21 74 -261 23 74 -261 minecraft:grass_block[snowy=false]
fill 8 74 -262 20 74 -262 minecraft:dirt
fill 21 74 -262 23 74 -262 minecraft:grass_block[snowy=false]
fill 8 74 -263 20 74 -263 minecraft:dirt
fill 21 74 -263 23 74 -263 minecraft:grass_block[snowy=false]
setblock 24 74 -263 minecraft:short_grass
fill 8 74 -264 19 74 -264 minecraft:dirt
fill 20 74 -264 23 74 -264 minecraft:grass_block[snowy=false]
setblock 25 74 -264 minecraft:short_grass
fill 8 74 -265 19 74 -265 minecraft:dirt
fill 20 74 -265 22 74 -265 minecraft:grass_block[snowy=false]
fill 8 74 -266 18 74 -266 minecraft:dirt
fill 19 74 -266 21 74 -266 minecraft:grass_block[snowy=false]
fill 8 74 -267 18 74 -267 minecraft:dirt
fill 19 74 -267 21 74 -267 minecraft:grass_block[snowy=false]
setblock 25 74 -267 minecraft:birch_log[axis=y]
fill 8 74 -268 16 74 -268 minecraft:dirt
fill 17 74 -268 20 74 -268 minecraft:grass_block[snowy=false]
fill 8 74 -269 11 74 -269 minecraft:grass_block[snowy=false]
fill 12 74 -269 17 74 -269 minecraft:dirt
fill 18 74 -269 21 74 -269 minecraft:grass_block[snowy=false]
fill 8 74 -270 11 74 -270 minecraft:grass_block[snowy=false]
fill 12 74 -270 18 74 -270 minecraft:dirt
fill 19 74 -270 22 74 -270 minecraft:grass_block[snowy=false]
setblock 24 74 -270 minecraft:birch_log[axis=y]
fill 9 74 -271 12 74 -271 minecraft:grass_block[snowy=false]
fill 13 74 -271 20 74 -271 minecraft:dirt
fill 21 74 -271 22 74 -271 minecraft:grass_block[snowy=false]
setblock 10 74 -272 minecraft:dirt
fill 11 74 -272 12 74 -272 minecraft:grass_block[snowy=false]
fill 13 74 -272 20 74 -272 minecraft:dirt
fill 21 74 -272 23 74 -272 minecraft:grass_block[snowy=false]
fill 10 74 -273 11 74 -273 minecraft:grass_block[snowy=false]
fill 12 74 -273 20 74 -273 minecraft:dirt
fill 21 74 -273 23 74 -273 minecraft:grass_block[snowy=false]
fill 10 74 -274 11 74 -274 minecraft:grass_block[snowy=false]
fill 12 74 -274 20 74 -274 minecraft:dirt
fill 21 74 -274 22 74 -274 minecraft:grass_block[snowy=false]
setblock 11 74 -275 minecraft:grass_block[snowy=false]
fill 12 74 -275 20 74 -275 minecraft:dirt
fill 21 74 -275 22 74 -275 minecraft:grass_block[snowy=false]
setblock 11 74 -276 minecraft:grass_block[snowy=false]
fill 12 74 -276 20 74 -276 minecraft:dirt
setblock 21 74 -276 minecraft:grass_block[snowy=false]
setblock 22 74 -276 minecraft:dirt
setblock 11 74 -277 minecraft:grass_block[snowy=false]
fill 12 74 -277 20 74 -277 minecraft:dirt
fill 21 74 -277 22 74 -277 minecraft:grass_block[snowy=false]
setblock 24 74 -277 minecraft:birch_log[axis=y]
fill 11 74 -278 18 74 -278 minecraft:dirt
fill 19 74 -278 20 74 -278 minecraft:grass_block[snowy=false]
setblock 21 74 -278 minecraft:dirt
setblock 23 74 -278 minecraft:short_grass
setblock 11 74 -279 minecraft:grass_block[snowy=false]
fill 12 74 -279 17 74 -279 minecraft:dirt
fill 18 74 -279 21 74 -279 minecraft:grass_block[snowy=false]
setblock 23 74 -279 minecraft:short_grass
setblock 11 74 -280 minecraft:grass_block[snowy=false]
setblock 12 74 -280 minecraft:dirt
fill 13 74 -280 14 74 -280 minecraft:grass_block[snowy=false]
fill 15 74 -280 16 74 -280 minecraft:dirt
fill 17 74 -280 20 74 -280 minecraft:grass_block[snowy=false]
fill 12 74 -281 20 74 -281 minecraft:grass_block[snowy=false]
setblock 12 74 -282 minecraft:short_grass
fill 13 74 -282 20 74 -282 minecraft:grass_block[snowy=false]
setblock 8 74 -283 minecraft:grass_block[snowy=false]
fill 14 74 -283 20 74 -283 minecraft:grass_block[snowy=false]
setblock 22 74 -283 minecraft:short_grass
setblock 26 74 -283 regions_unexplored:birch_shrub[half=upper]
setblock 29 74 -283 minecraft:birch_log[axis=y]
fill 8 74 -284 9 74 -284 minecraft:grass_block[snowy=false]
fill 15 74 -284 19 74 -284 minecraft:grass_block[snowy=false]
setblock 23 74 -284 minecraft:birch_log[axis=y]
fill 8 74 -285 10 74 -285 minecraft:grass_block[snowy=false]
fill 15 74 -285 18 74 -285 minecraft:grass_block[snowy=false]
setblock 43 74 -285 minecraft:birch_log[axis=y]
fill 8 74 -286 11 74 -286 minecraft:grass_block[snowy=false]
setblock 13 74 -286 minecraft:birch_log[axis=y]
fill 15 74 -286 17 74 -286 minecraft:grass_block[snowy=false]
setblock 30 74 -286 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 74 -286 minecraft:birch_log[axis=y]
fill 8 74 -287 15 74 -287 minecraft:grass_block[snowy=false]
setblock 29 74 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 74 -287 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 74 -287 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 74 -287 minecraft:birch_log[axis=y]
fill 8 74 -288 9 74 -288 minecraft:grass_block[snowy=false]
setblock 10 74 -288 minecraft:dirt
fill 11 74 -288 15 74 -288 minecraft:grass_block[snowy=false]
setblock 28 74 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 74 -288 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 74 -288 minecraft:birch_log[axis=y]
setblock 31 74 -288 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 74 -288 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 74 -289 14 74 -289 minecraft:grass_block[snowy=false]
setblock 29 74 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 74 -289 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 74 -289 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 60 74 -289 minecraft:birch_log[axis=y]
fill 8 74 -290 13 74 -290 minecraft:grass_block[snowy=false]
setblock 14 74 -290 minecraft:dirt
setblock 24 74 -290 minecraft:birch_log[axis=y]
setblock 30 74 -290 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 74 -291 13 74 -291 minecraft:grass_block[snowy=false]
setblock 17 74 -291 regions_unexplored:grass_sprouts
setblock 26 74 -291 minecraft:birch_log[axis=y]
setblock 40 74 -291 minecraft:birch_log[axis=y]
setblock 43 74 -291 minecraft:birch_log[axis=y]
fill 8 74 -292 12 74 -292 minecraft:grass_block[snowy=false]
setblock 13 74 -292 minecraft:dirt
setblock 29 74 -292 minecraft:birch_log[axis=y]
setblock 52 74 -292 minecraft:birch_log[axis=y]
setblock 56 74 -292 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 74 -293 12 74 -293 minecraft:grass_block[snowy=false]
setblock 55 74 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -293 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 74 -293 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 74 -293 minecraft:birch_log[axis=y]
setblock 8 74 -294 minecraft:grass_block[snowy=false]
setblock 9 74 -294 minecraft:dirt
setblock 10 74 -294 minecraft:grass_block[snowy=false]
setblock 14 74 -294 minecraft:short_grass
setblock 23 74 -294 minecraft:birch_log[axis=y]
setblock 47 74 -294 minecraft:birch_log[axis=y]
setblock 54 74 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 74 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 74 -294 minecraft:birch_log[axis=y]
setblock 57 74 -294 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 74 -294 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 74 -295 minecraft:grass_block[snowy=false]
setblock 12 74 -295 minecraft:short_grass
setblock 15 74 -295 minecraft:birch_log[axis=y]
setblock 55 74 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -295 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 74 -295 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 74 -295 minecraft:birch_log[axis=y]
setblock 56 74 -296 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 74 -296 minecraft:birch_log[axis=y]
setblock 30 74 -297 minecraft:birch_log[axis=y]
setblock 35 74 -297 minecraft:birch_log[axis=y]
setblock 40 74 -297 minecraft:birch_log[axis=y]
setblock 46 74 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 74 -297 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 74 -298 minecraft:short_grass
setblock 12 74 -298 minecraft:short_grass
setblock 27 74 -298 minecraft:birch_log[axis=y]
setblock 45 74 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 74 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 74 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 74 -298 minecraft:birch_log[axis=y]
setblock 57 74 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 58 74 -298 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 59 74 -298 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 74 -299 minecraft:short_grass
setblock 15 74 -299 regions_unexplored:birch_shrub[half=upper]
setblock 20 74 -299 minecraft:birch_log[axis=y]
setblock 44 74 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 74 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 74 -299 minecraft:birch_log[axis=y]
setblock 47 74 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 74 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 74 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 74 -299 minecraft:birch_log[axis=y]
setblock 59 74 -299 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 60 74 -299 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 74 -300 10 74 -300 regions_unexplored:grass_sprouts
setblock 45 74 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 74 -300 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 74 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 74 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 58 74 -300 59 74 -300 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 60 74 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 74 -301 minecraft:birch_log[axis=y]
setblock 28 74 -301 minecraft:birch_log[axis=y]
setblock 46 74 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -301 minecraft:birch_log[axis=y]
fill 57 74 -301 58 74 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 59 74 -301 minecraft:birch_log[axis=y]
setblock 60 74 -301 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 61 74 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 74 -302 minecraft:birch_log[axis=y]
setblock 58 74 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 59 74 -302 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 60 74 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 74 -302 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 74 -303 minecraft:short_grass
setblock 59 74 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 74 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 74 -304 minecraft:birch_log[axis=y]
setblock 9 74 -304 regions_unexplored:grass_sprouts
setblock 39 74 -304 minecraft:birch_log[axis=y]
setblock 64 74 -304 minecraft:birch_log[axis=y]
setblock 8 74 -305 minecraft:short_grass
setblock 18 74 -305 minecraft:birch_log[axis=y]
setblock 25 74 -305 minecraft:birch_log[axis=y]
setblock 10 74 -306 minecraft:short_grass
setblock 49 74 -306 minecraft:birch_log[axis=y]
setblock 8 74 -307 minecraft:short_grass
setblock 54 74 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 74 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -307 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 74 -307 minecraft:birch_log[axis=y]
setblock 8 74 -308 integrateddynamics:menril_log[axis=y]
setblock 45 74 -308 regions_unexplored:birch_branch[facing=west]
setblock 46 74 -308 minecraft:birch_log[axis=y]
setblock 51 74 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 74 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 74 -308 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 74 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 69 74 -308 71 74 -308 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 74 -309 9 74 -309 integrateddynamics:menril_log[axis=y]
setblock 50 74 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -309 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 74 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 74 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 74 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 74 -309 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 74 -309 minecraft:birch_log[axis=y]
fill 69 74 -309 71 74 -309 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 8 74 -310 integrateddynamics:menril_log[axis=y]
setblock 10 74 -310 minecraft:birch_log[axis=y]
setblock 45 74 -310 minecraft:birch_log[axis=y]
setblock 49 74 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 74 -310 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 74 -310 minecraft:birch_log[axis=y]
setblock 52 74 -310 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 74 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 69 74 -310 71 74 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 74 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -311 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 52 74 -311 53 74 -311 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 74 -312 minecraft:birch_log[axis=y]
setblock 16 74 -312 minecraft:birch_log[axis=y]
setblock 34 74 -312 minecraft:birch_log[axis=y]
setblock 40 74 -312 minecraft:birch_log[axis=y]
fill 51 74 -312 52 74 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 74 -312 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 74 -312 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 74 -312 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 32 74 -313 minecraft:birch_log[axis=y]
setblock 48 74 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 74 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 74 -313 minecraft:birch_log[axis=y]
setblock 54 74 -313 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 74 -313 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 74 -314 minecraft:birch_log[axis=y]
setblock 47 74 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 74 -314 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 74 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 74 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 74 -314 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 74 -314 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 74 -315 regions_unexplored:grass_sprouts
setblock 10 74 -315 regions_unexplored:birch_shrub[half=lower]
setblock 46 74 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 74 -315 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 74 -315 minecraft:birch_log[axis=y]
setblock 49 74 -315 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 50 74 -315 51 74 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 74 -315 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 74 -316 minecraft:birch_log[axis=y]
fill 47 74 -316 48 74 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 49 74 -316 50 74 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -316 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 74 -316 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 74 -317 minecraft:birch_log[axis=y]
setblock 36 74 -317 minecraft:birch_log[axis=y]
setblock 47 74 -317 minecraft:birch_log[axis=y]
setblock 48 74 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 74 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 74 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 74 -317 minecraft:birch_log[axis=y]
setblock 52 74 -317 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 74 -317 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 74 -318 minecraft:short_grass
setblock 50 74 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -318 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 74 -318 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 74 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 12 73 -255 21 73 -255 minecraft:dirt
fill 22 73 -255 23 73 -255 minecraft:grass_block[snowy=false]
setblock 12 73 -256 minecraft:stone
fill 13 73 -256 21 73 -256 minecraft:dirt
fill 22 73 -256 23 73 -256 minecraft:grass_block[snowy=false]
fill 12 73 -257 21 73 -257 minecraft:dirt
fill 22 73 -257 23 73 -257 minecraft:grass_block[snowy=false]
setblock 26 73 -257 minecraft:birch_log[axis=y]
fill 12 73 -258 22 73 -258 minecraft:dirt
fill 23 73 -258 24 73 -258 minecraft:grass_block[snowy=false]
fill 12 73 -259 22 73 -259 minecraft:dirt
fill 23 73 -259 24 73 -259 minecraft:grass_block[snowy=false]
setblock 25 73 -259 minecraft:dirt
fill 11 73 -260 22 73 -260 minecraft:dirt
fill 23 73 -260 25 73 -260 minecraft:grass_block[snowy=false]
fill 8 73 -261 23 73 -261 minecraft:dirt
fill 24 73 -261 25 73 -261 minecraft:grass_block[snowy=false]
fill 8 73 -262 23 73 -262 minecraft:dirt
fill 24 73 -262 25 73 -262 minecraft:grass_block[snowy=false]
fill 8 73 -263 23 73 -263 minecraft:dirt
fill 24 73 -263 25 73 -263 minecraft:grass_block[snowy=false]
fill 8 73 -264 23 73 -264 minecraft:dirt
fill 24 73 -264 25 73 -264 minecraft:grass_block[snowy=false]
fill 8 73 -265 22 73 -265 minecraft:dirt
fill 23 73 -265 25 73 -265 minecraft:grass_block[snowy=false]
fill 8 73 -266 21 73 -266 minecraft:dirt
fill 22 73 -266 24 73 -266 minecraft:grass_block[snowy=false]
fill 8 73 -267 21 73 -267 minecraft:dirt
fill 22 73 -267 24 73 -267 minecraft:grass_block[snowy=false]
setblock 25 73 -267 minecraft:birch_log[axis=y]
fill 8 73 -268 20 73 -268 minecraft:dirt
fill 21 73 -268 24 73 -268 minecraft:grass_block[snowy=false]
fill 8 73 -269 21 73 -269 minecraft:dirt
fill 22 73 -269 24 73 -269 minecraft:grass_block[snowy=false]
fill 8 73 -270 22 73 -270 minecraft:dirt
setblock 23 73 -270 minecraft:grass_block[snowy=false]
setblock 24 73 -270 minecraft:dirt
setblock 8 73 -271 minecraft:grass_block[snowy=false]
fill 9 73 -271 22 73 -271 minecraft:dirt
fill 23 73 -271 25 73 -271 minecraft:grass_block[snowy=false]
fill 8 73 -272 9 73 -272 minecraft:grass_block[snowy=false]
fill 10 73 -272 23 73 -272 minecraft:dirt
fill 24 73 -272 25 73 -272 minecraft:grass_block[snowy=false]
fill 8 73 -273 9 73 -273 minecraft:grass_block[snowy=false]
fill 10 73 -273 23 73 -273 minecraft:dirt
fill 24 73 -273 25 73 -273 minecraft:grass_block[snowy=false]
setblock 9 73 -274 minecraft:grass_block[snowy=false]
fill 10 73 -274 22 73 -274 minecraft:dirt
fill 23 73 -274 25 73 -274 minecraft:grass_block[snowy=false]
fill 9 73 -275 10 73 -275 minecraft:grass_block[snowy=false]
fill 11 73 -275 22 73 -275 minecraft:dirt
fill 23 73 -275 25 73 -275 minecraft:grass_block[snowy=false]
fill 9 73 -276 10 73 -276 minecraft:grass_block[snowy=false]
fill 11 73 -276 22 73 -276 minecraft:dirt
fill 23 73 -276 25 73 -276 minecraft:grass_block[snowy=false]
setblock 10 73 -277 minecraft:grass_block[snowy=false]
fill 11 73 -277 22 73 -277 minecraft:dirt
setblock 23 73 -277 minecraft:grass_block[snowy=false]
setblock 24 73 -277 minecraft:dirt
setblock 10 73 -278 minecraft:grass_block[snowy=false]
fill 11 73 -278 21 73 -278 minecraft:dirt
fill 22 73 -278 24 73 -278 minecraft:grass_block[snowy=false]
setblock 10 73 -279 minecraft:grass_block[snowy=false]
fill 11 73 -279 21 73 -279 minecraft:dirt
fill 22 73 -279 24 73 -279 minecraft:grass_block[snowy=false]
setblock 10 73 -280 minecraft:grass_block[snowy=false]
fill 11 73 -280 20 73 -280 minecraft:dirt
fill 21 73 -280 23 73 -280 minecraft:grass_block[snowy=false]
fill 10 73 -281 11 73 -281 minecraft:grass_block[snowy=false]
fill 12 73 -281 20 73 -281 minecraft:dirt
fill 21 73 -281 23 73 -281 minecraft:grass_block[snowy=false]
fill 8 73 -282 12 73 -282 minecraft:grass_block[snowy=false]
fill 13 73 -282 20 73 -282 minecraft:dirt
fill 21 73 -282 23 73 -282 minecraft:grass_block[snowy=false]
setblock 24 73 -282 minecraft:short_grass
setblock 8 73 -283 minecraft:dirt
fill 9 73 -283 13 73 -283 minecraft:grass_block[snowy=false]
fill 14 73 -283 20 73 -283 minecraft:dirt
fill 21 73 -283 23 73 -283 minecraft:grass_block[snowy=false]
setblock 26 73 -283 regions_unexplored:birch_shrub[half=lower]
setblock 29 73 -283 minecraft:birch_log[axis=y]
fill 8 73 -284 9 73 -284 minecraft:dirt
fill 10 73 -284 11 73 -284 minecraft:grass_block[snowy=false]
fill 13 73 -284 14 73 -284 minecraft:grass_block[snowy=false]
fill 15 73 -284 19 73 -284 minecraft:dirt
fill 20 73 -284 22 73 -284 minecraft:grass_block[snowy=false]
setblock 23 73 -284 minecraft:dirt
fill 8 73 -285 10 73 -285 minecraft:dirt
fill 11 73 -285 14 73 -285 minecraft:grass_block[snowy=false]
fill 15 73 -285 18 73 -285 minecraft:dirt
fill 19 73 -285 23 73 -285 minecraft:grass_block[snowy=false]
setblock 24 73 -285 regions_unexplored:grass_sprouts
setblock 43 73 -285 minecraft:birch_log[axis=y]
fill 8 73 -286 11 73 -286 minecraft:dirt
setblock 12 73 -286 minecraft:grass_block[snowy=false]
setblock 13 73 -286 minecraft:dirt
setblock 14 73 -286 minecraft:grass_block[snowy=false]
fill 15 73 -286 17 73 -286 minecraft:dirt
fill 18 73 -286 23 73 -286 minecraft:grass_block[snowy=false]
setblock 49 73 -286 minecraft:birch_log[axis=y]
fill 8 73 -287 15 73 -287 minecraft:dirt
fill 16 73 -287 23 73 -287 minecraft:grass_block[snowy=false]
setblock 52 73 -287 minecraft:birch_log[axis=y]
fill 8 73 -288 15 73 -288 minecraft:dirt
fill 16 73 -288 22 73 -288 minecraft:grass_block[snowy=false]
setblock 30 73 -288 minecraft:birch_log[axis=y]
fill 8 73 -289 14 73 -289 minecraft:dirt
fill 15 73 -289 21 73 -289 minecraft:grass_block[snowy=false]
setblock 60 73 -289 minecraft:birch_log[axis=y]
fill 8 73 -290 14 73 -290 minecraft:dirt
fill 15 73 -290 20 73 -290 minecraft:grass_block[snowy=false]
setblock 24 73 -290 minecraft:birch_log[axis=y]
fill 8 73 -291 13 73 -291 minecraft:dirt
fill 14 73 -291 19 73 -291 minecraft:grass_block[snowy=false]
setblock 26 73 -291 minecraft:birch_log[axis=y]
setblock 40 73 -291 minecraft:birch_log[axis=y]
setblock 43 73 -291 minecraft:birch_log[axis=y]
fill 8 73 -292 13 73 -292 minecraft:dirt
fill 14 73 -292 19 73 -292 minecraft:grass_block[snowy=false]
setblock 29 73 -292 minecraft:birch_log[axis=y]
setblock 52 73 -292 minecraft:birch_log[axis=y]
fill 8 73 -293 12 73 -293 minecraft:dirt
fill 13 73 -293 18 73 -293 minecraft:grass_block[snowy=false]
setblock 67 73 -293 minecraft:birch_log[axis=y]
fill 8 73 -294 10 73 -294 minecraft:dirt
fill 11 73 -294 17 73 -294 minecraft:grass_block[snowy=false]
setblock 18 73 -294 minecraft:short_grass
setblock 23 73 -294 minecraft:birch_log[axis=y]
setblock 47 73 -294 minecraft:birch_log[axis=y]
setblock 56 73 -294 minecraft:birch_log[axis=y]
setblock 8 73 -295 minecraft:dirt
fill 9 73 -295 14 73 -295 minecraft:grass_block[snowy=false]
setblock 15 73 -295 minecraft:dirt
setblock 16 73 -295 minecraft:grass_block[snowy=false]
setblock 22 73 -295 regions_unexplored:grass_sprouts
setblock 62 73 -295 minecraft:birch_log[axis=y]
fill 8 73 -296 15 73 -296 minecraft:grass_block[snowy=false]
setblock 17 73 -296 minecraft:short_grass
setblock 67 73 -296 regions_unexplored:birch_branch[facing=west]
setblock 68 73 -296 minecraft:birch_log[axis=y]
fill 8 73 -297 14 73 -297 minecraft:grass_block[snowy=false]
setblock 30 73 -297 minecraft:birch_log[axis=y]
setblock 35 73 -297 minecraft:birch_log[axis=y]
setblock 40 73 -297 minecraft:birch_log[axis=y]
fill 8 73 -298 14 73 -298 minecraft:grass_block[snowy=false]
setblock 20 73 -298 regions_unexplored:grass_sprouts
setblock 27 73 -298 minecraft:birch_log[axis=y]
setblock 49 73 -298 minecraft:birch_log[axis=y]
fill 8 73 -299 13 73 -299 minecraft:grass_block[snowy=false]
setblock 15 73 -299 regions_unexplored:birch_shrub[half=lower]
setblock 17 73 -299 minecraft:short_grass
setblock 20 73 -299 minecraft:birch_log[axis=y]
setblock 46 73 -299 minecraft:birch_log[axis=y]
setblock 58 73 -299 minecraft:birch_log[axis=y]
fill 8 73 -300 12 73 -300 minecraft:grass_block[snowy=false]
setblock 20 73 -300 minecraft:short_grass
fill 8 73 -301 9 73 -301 minecraft:grass_block[snowy=false]
setblock 10 73 -301 minecraft:dirt
fill 11 73 -301 12 73 -301 minecraft:grass_block[snowy=false]
setblock 19 73 -301 regions_unexplored:grass_sprouts
setblock 28 73 -301 minecraft:birch_log[axis=y]
setblock 56 73 -301 minecraft:birch_log[axis=y]
setblock 59 73 -301 minecraft:birch_log[axis=y]
fill 8 73 -302 12 73 -302 minecraft:grass_block[snowy=false]
setblock 21 73 -302 regions_unexplored:grass_sprouts
setblock 41 73 -302 minecraft:birch_log[axis=y]
setblock 70 73 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 8 73 -303 12 73 -303 minecraft:grass_block[snowy=false]
setblock 17 73 -303 minecraft:short_grass
setblock 19 73 -303 minecraft:short_grass
setblock 69 73 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 73 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 73 -303 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 73 -304 minecraft:dirt
fill 9 73 -304 12 73 -304 minecraft:grass_block[snowy=false]
setblock 21 73 -304 minecraft:short_grass
setblock 39 73 -304 minecraft:birch_log[axis=y]
setblock 64 73 -304 minecraft:birch_log[axis=y]
setblock 70 73 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 8 73 -305 12 73 -305 minecraft:grass_block[snowy=false]
setblock 18 73 -305 minecraft:birch_log[axis=y]
setblock 25 73 -305 minecraft:birch_log[axis=y]
fill 8 73 -306 12 73 -306 minecraft:grass_block[snowy=false]
setblock 22 73 -306 minecraft:short_grass
setblock 49 73 -306 minecraft:birch_log[axis=y]
setblock 50 73 -306 regions_unexplored:birch_branch[facing=east]
setblock 55 73 -306 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 73 -307 12 73 -307 minecraft:grass_block[snowy=false]
setblock 21 73 -307 regions_unexplored:grass_sprouts
setblock 54 73 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 73 -307 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 73 -307 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 73 -307 minecraft:birch_log[axis=y]
setblock 70 73 -307 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 8 73 -308 minecraft:dirt
fill 9 73 -308 12 73 -308 minecraft:grass_block[snowy=false]
setblock 23 73 -308 minecraft:short_grass
setblock 46 73 -308 minecraft:birch_log[axis=y]
setblock 53 73 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 73 -308 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 73 -308 minecraft:birch_log[axis=y]
setblock 56 73 -308 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 73 -308 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 69 73 -308 71 73 -308 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 73 -309 9 73 -309 minecraft:dirt
fill 10 73 -309 12 73 -309 minecraft:grass_block[snowy=false]
setblock 21 73 -309 minecraft:short_grass
setblock 54 73 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 73 -309 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 73 -309 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 73 -309 minecraft:birch_log[axis=y]
fill 68 73 -309 69 73 -309 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 70 73 -309 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 71 73 -309 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 8 73 -310 minecraft:dirt
setblock 9 73 -310 minecraft:grass_block[snowy=false]
setblock 10 73 -310 minecraft:dirt
fill 11 73 -310 13 73 -310 minecraft:grass_block[snowy=false]
setblock 45 73 -310 minecraft:birch_log[axis=y]
setblock 51 73 -310 minecraft:birch_log[axis=y]
setblock 55 73 -310 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 69 73 -310 71 73 -310 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 73 -311 13 73 -311 minecraft:grass_block[snowy=false]
setblock 70 73 -311 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 73 -312 11 73 -312 minecraft:grass_block[snowy=false]
setblock 12 73 -312 minecraft:dirt
fill 13 73 -312 14 73 -312 minecraft:grass_block[snowy=false]
setblock 16 73 -312 minecraft:birch_log[axis=y]
setblock 34 73 -312 minecraft:birch_log[axis=y]
setblock 40 73 -312 minecraft:birch_log[axis=y]
setblock 64 73 -312 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 73 -313 13 73 -313 minecraft:grass_block[snowy=false]
setblock 18 73 -313 minecraft:short_grass
setblock 32 73 -313 minecraft:birch_log[axis=y]
setblock 53 73 -313 minecraft:birch_log[axis=y]
setblock 64 73 -313 regions_unexplored:silver_birch_log[axis=z,is_base=false]
fill 8 73 -314 13 73 -314 minecraft:grass_block[snowy=false]
setblock 20 73 -314 minecraft:birch_log[axis=y]
fill 8 73 -315 13 73 -315 minecraft:grass_block[snowy=false]
setblock 14 73 -315 regions_unexplored:grass_sprouts
setblock 48 73 -315 minecraft:birch_log[axis=y]
fill 8 73 -316 12 73 -316 minecraft:grass_block[snowy=false]
setblock 16 73 -316 minecraft:short_grass
setblock 19 73 -316 regions_unexplored:grass_sprouts
setblock 31 73 -316 minecraft:birch_log[axis=y]
setblock 64 73 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 73 -317 13 73 -317 minecraft:grass_block[snowy=false]
setblock 26 73 -317 minecraft:birch_log[axis=y]
setblock 36 73 -317 minecraft:birch_log[axis=y]
setblock 47 73 -317 minecraft:birch_log[axis=y]
setblock 51 73 -317 minecraft:birch_log[axis=y]
setblock 61 73 -317 regions_unexplored:silver_birch_log[axis=z,is_base=false]
fill 63 73 -317 65 73 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 71 73 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 73 -318 13 73 -318 minecraft:grass_block[snowy=false]
setblock 61 73 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 64 73 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 11 72 -255 17 72 -255 minecraft:stone
fill 18 72 -255 23 72 -255 minecraft:dirt
fill 24 72 -255 26 72 -255 minecraft:grass_block[snowy=false]
fill 12 72 -256 17 72 -256 minecraft:stone
fill 18 72 -256 23 72 -256 minecraft:dirt
fill 24 72 -256 26 72 -256 minecraft:grass_block[snowy=false]
fill 12 72 -257 17 72 -257 minecraft:stone
fill 18 72 -257 23 72 -257 minecraft:dirt
fill 24 72 -257 25 72 -257 minecraft:grass_block[snowy=false]
setblock 26 72 -257 minecraft:dirt
fill 12 72 -258 17 72 -258 minecraft:stone
fill 18 72 -258 24 72 -258 minecraft:dirt
fill 25 72 -258 26 72 -258 minecraft:grass_block[snowy=false]
fill 12 72 -259 16 72 -259 minecraft:stone
fill 17 72 -259 25 72 -259 minecraft:dirt
setblock 26 72 -259 minecraft:grass_block[snowy=false]
fill 11 72 -260 17 72 -260 minecraft:stone
fill 18 72 -260 25 72 -260 minecraft:dirt
setblock 26 72 -260 minecraft:grass_block[snowy=false]
fill 10 72 -261 14 72 -261 minecraft:stone
fill 15 72 -261 25 72 -261 minecraft:dirt
setblock 26 72 -261 minecraft:grass_block[snowy=false]
fill 8 72 -262 15 72 -262 minecraft:stone
setblock 16 72 -262 minecraft:dirt
setblock 17 72 -262 minecraft:stone
fill 18 72 -262 25 72 -262 minecraft:dirt
setblock 26 72 -262 minecraft:grass_block[snowy=false]
setblock 8 72 -263 minecraft:dirt
fill 9 72 -263 15 72 -263 minecraft:stone
setblock 16 72 -263 minecraft:dirt
setblock 17 72 -263 minecraft:stone
fill 18 72 -263 25 72 -263 minecraft:dirt
setblock 26 72 -263 minecraft:grass_block[snowy=false]
setblock 8 72 -264 minecraft:dirt
fill 9 72 -264 15 72 -264 minecraft:stone
fill 16 72 -264 25 72 -264 minecraft:dirt
setblock 26 72 -264 minecraft:grass_block[snowy=false]
fill 8 72 -265 10 72 -265 minecraft:dirt
fill 11 72 -265 15 72 -265 minecraft:stone
fill 16 72 -265 25 72 -265 minecraft:dirt
setblock 26 72 -265 minecraft:grass_block[snowy=false]
fill 8 72 -266 24 72 -266 minecraft:dirt
fill 25 72 -266 26 72 -266 minecraft:grass_block[snowy=false]
fill 8 72 -267 25 72 -267 minecraft:dirt
setblock 26 72 -267 minecraft:grass_block[snowy=false]
fill 8 72 -268 24 72 -268 minecraft:dirt
fill 25 72 -268 26 72 -268 minecraft:grass_block[snowy=false]
fill 8 72 -269 24 72 -269 minecraft:dirt
fill 25 72 -269 26 72 -269 minecraft:grass_block[snowy=false]
fill 8 72 -270 24 72 -270 minecraft:dirt
fill 25 72 -270 26 72 -270 minecraft:grass_block[snowy=false]
fill 8 72 -271 15 72 -271 minecraft:dirt
setblock 16 72 -271 minecraft:stone
fill 17 72 -271 25 72 -271 minecraft:dirt
setblock 26 72 -271 minecraft:grass_block[snowy=false]
fill 8 72 -272 25 72 -272 minecraft:dirt
setblock 26 72 -272 minecraft:grass_block[snowy=false]
fill 8 72 -273 25 72 -273 minecraft:dirt
setblock 26 72 -273 minecraft:grass_block[snowy=false]
setblock 8 72 -274 minecraft:grass_block[snowy=false]
fill 9 72 -274 25 72 -274 minecraft:dirt
setblock 26 72 -274 minecraft:grass_block[snowy=false]
setblock 8 72 -275 minecraft:grass_block[snowy=false]
fill 9 72 -275 25 72 -275 minecraft:dirt
setblock 26 72 -275 minecraft:grass_block[snowy=false]
setblock 8 72 -276 minecraft:grass_block[snowy=false]
fill 9 72 -276 25 72 -276 minecraft:dirt
setblock 26 72 -276 minecraft:grass_block[snowy=false]
setblock 9 72 -277 minecraft:grass_block[snowy=false]
fill 10 72 -277 24 72 -277 minecraft:dirt
fill 25 72 -277 26 72 -277 minecraft:grass_block[snowy=false]
setblock 9 72 -278 minecraft:grass_block[snowy=false]
fill 10 72 -278 24 72 -278 minecraft:dirt
fill 25 72 -278 26 72 -278 minecraft:grass_block[snowy=false]
setblock 9 72 -279 minecraft:grass_block[snowy=false]
fill 10 72 -279 24 72 -279 minecraft:dirt
fill 25 72 -279 26 72 -279 minecraft:grass_block[snowy=false]
setblock 9 72 -280 minecraft:grass_block[snowy=false]
fill 10 72 -280 23 72 -280 minecraft:dirt
fill 24 72 -280 26 72 -280 minecraft:grass_block[snowy=false]
fill 8 72 -281 9 72 -281 minecraft:grass_block[snowy=false]
fill 10 72 -281 23 72 -281 minecraft:dirt
fill 24 72 -281 26 72 -281 minecraft:grass_block[snowy=false]
fill 8 72 -282 23 72 -282 minecraft:dirt
fill 24 72 -282 26 72 -282 minecraft:grass_block[snowy=false]
fill 8 72 -283 23 72 -283 minecraft:dirt
fill 24 72 -283 27 72 -283 minecraft:grass_block[snowy=false]
setblock 29 72 -283 minecraft:birch_log[axis=y]
fill 8 72 -284 11 72 -284 minecraft:dirt
setblock 12 72 -284 minecraft:grass_block[snowy=false]
fill 13 72 -284 23 72 -284 minecraft:dirt
fill 24 72 -284 27 72 -284 minecraft:grass_block[snowy=false]
fill 8 72 -285 23 72 -285 minecraft:dirt
fill 24 72 -285 26 72 -285 minecraft:grass_block[snowy=false]
setblock 43 72 -285 minecraft:birch_log[axis=y]
fill 8 72 -286 23 72 -286 minecraft:dirt
fill 24 72 -286 25 72 -286 minecraft:grass_block[snowy=false]
setblock 49 72 -286 minecraft:birch_log[axis=y]
fill 8 72 -287 23 72 -287 minecraft:dirt
setblock 24 72 -287 minecraft:grass_block[snowy=false]
setblock 52 72 -287 minecraft:birch_log[axis=y]
fill 8 72 -288 22 72 -288 minecraft:dirt
fill 23 72 -288 24 72 -288 minecraft:grass_block[snowy=false]
setblock 30 72 -288 minecraft:birch_log[axis=y]
fill 8 72 -289 21 72 -289 minecraft:dirt
fill 22 72 -289 24 72 -289 minecraft:grass_block[snowy=false]
setblock 60 72 -289 minecraft:birch_log[axis=y]
fill 8 72 -290 20 72 -290 minecraft:dirt
fill 21 72 -290 23 72 -290 minecraft:grass_block[snowy=false]
setblock 24 72 -290 minecraft:dirt
setblock 25 72 -290 minecraft:grass_block[snowy=false]
fill 8 72 -291 19 72 -291 minecraft:dirt
fill 20 72 -291 25 72 -291 minecraft:grass_block[snowy=false]
setblock 26 72 -291 minecraft:dirt
setblock 40 72 -291 minecraft:birch_log[axis=y]
setblock 43 72 -291 minecraft:birch_log[axis=y]
fill 8 72 -292 19 72 -292 minecraft:dirt
fill 20 72 -292 26 72 -292 minecraft:grass_block[snowy=false]
setblock 29 72 -292 minecraft:birch_log[axis=y]
setblock 52 72 -292 minecraft:birch_log[axis=y]
fill 8 72 -293 18 72 -293 minecraft:dirt
fill 19 72 -293 26 72 -293 minecraft:grass_block[snowy=false]
setblock 67 72 -293 minecraft:birch_log[axis=y]
fill 8 72 -294 17 72 -294 minecraft:dirt
fill 18 72 -294 22 72 -294 minecraft:grass_block[snowy=false]
setblock 23 72 -294 minecraft:dirt
fill 24 72 -294 25 72 -294 minecraft:grass_block[snowy=false]
setblock 47 72 -294 minecraft:birch_log[axis=y]
setblock 56 72 -294 minecraft:birch_log[axis=y]
fill 8 72 -295 16 72 -295 minecraft:dirt
fill 17 72 -295 24 72 -295 minecraft:grass_block[snowy=false]
setblock 62 72 -295 minecraft:birch_log[axis=y]
fill 8 72 -296 15 72 -296 minecraft:dirt
fill 16 72 -296 24 72 -296 minecraft:grass_block[snowy=false]
setblock 68 72 -296 minecraft:birch_log[axis=y]
fill 8 72 -297 14 72 -297 minecraft:dirt
fill 15 72 -297 23 72 -297 minecraft:grass_block[snowy=false]
setblock 30 72 -297 minecraft:birch_log[axis=y]
setblock 35 72 -297 minecraft:birch_log[axis=y]
setblock 40 72 -297 minecraft:birch_log[axis=y]
fill 8 72 -298 14 72 -298 minecraft:dirt
fill 15 72 -298 22 72 -298 minecraft:grass_block[snowy=false]
setblock 23 72 -298 minecraft:short_grass
setblock 27 72 -298 minecraft:birch_log[axis=y]
setblock 49 72 -298 minecraft:birch_log[axis=y]
fill 8 72 -299 13 72 -299 minecraft:dirt
fill 14 72 -299 19 72 -299 minecraft:grass_block[snowy=false]
setblock 20 72 -299 minecraft:dirt
fill 21 72 -299 22 72 -299 minecraft:grass_block[snowy=false]
setblock 46 72 -299 minecraft:birch_log[axis=y]
setblock 58 72 -299 minecraft:birch_log[axis=y]
fill 8 72 -300 12 72 -300 minecraft:dirt
fill 13 72 -300 21 72 -300 minecraft:grass_block[snowy=false]
setblock 33 72 -300 regions_unexplored:birch_shrub[half=upper]
setblock 71 72 -300 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 72 -301 12 72 -301 minecraft:dirt
fill 13 72 -301 21 72 -301 minecraft:grass_block[snowy=false]
setblock 28 72 -301 minecraft:birch_log[axis=y]
setblock 56 72 -301 minecraft:birch_log[axis=y]
setblock 59 72 -301 minecraft:birch_log[axis=y]
fill 8 72 -302 12 72 -302 minecraft:dirt
fill 13 72 -302 21 72 -302 minecraft:grass_block[snowy=false]
setblock 22 72 -302 regions_unexplored:grass_sprouts
setblock 41 72 -302 minecraft:birch_log[axis=y]
setblock 69 72 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 72 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 72 -302 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 8 72 -303 12 72 -303 minecraft:dirt
fill 13 72 -303 21 72 -303 minecraft:grass_block[snowy=false]
setblock 69 72 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 72 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 71 72 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 72 -304 12 72 -304 minecraft:dirt
fill 13 72 -304 21 72 -304 minecraft:grass_block[snowy=false]
setblock 22 72 -304 regions_unexplored:grass_sprouts
setblock 39 72 -304 minecraft:birch_log[axis=y]
setblock 64 72 -304 minecraft:birch_log[axis=y]
setblock 69 72 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 70 72 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 72 -304 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 8 72 -305 12 72 -305 minecraft:dirt
fill 13 72 -305 17 72 -305 minecraft:grass_block[snowy=false]
setblock 18 72 -305 minecraft:dirt
fill 19 72 -305 21 72 -305 minecraft:grass_block[snowy=false]
setblock 25 72 -305 minecraft:birch_log[axis=y]
fill 8 72 -306 12 72 -306 minecraft:dirt
fill 13 72 -306 22 72 -306 minecraft:grass_block[snowy=false]
setblock 25 72 -306 minecraft:short_grass
setblock 49 72 -306 minecraft:birch_log[axis=y]
fill 8 72 -307 12 72 -307 minecraft:dirt
fill 13 72 -307 23 72 -307 minecraft:grass_block[snowy=false]
setblock 26 72 -307 regions_unexplored:grass_sprouts
setblock 64 72 -307 minecraft:birch_log[axis=y]
fill 8 72 -308 12 72 -308 minecraft:dirt
fill 13 72 -308 23 72 -308 minecraft:grass_block[snowy=false]
setblock 46 72 -308 minecraft:birch_log[axis=y]
setblock 55 72 -308 minecraft:birch_log[axis=y]
fill 8 72 -309 12 72 -309 minecraft:dirt
fill 13 72 -309 22 72 -309 minecraft:grass_block[snowy=false]
fill 26 72 -309 27 72 -309 minecraft:short_grass
setblock 28 72 -309 regions_unexplored:grass_sprouts
setblock 31 72 -309 regions_unexplored:birch_shrub[half=upper]
setblock 62 72 -309 minecraft:birch_log[axis=y]
setblock 70 72 -309 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 72 -310 13 72 -310 minecraft:dirt
fill 14 72 -310 21 72 -310 minecraft:grass_block[snowy=false]
setblock 27 72 -310 minecraft:short_grass
setblock 45 72 -310 minecraft:birch_log[axis=y]
setblock 51 72 -310 minecraft:birch_log[axis=y]
fill 8 72 -311 13 72 -311 minecraft:dirt
fill 14 72 -311 21 72 -311 minecraft:grass_block[snowy=false]
fill 8 72 -312 14 72 -312 minecraft:dirt
setblock 15 72 -312 minecraft:grass_block[snowy=false]
setblock 16 72 -312 minecraft:dirt
fill 17 72 -312 19 72 -312 minecraft:grass_block[snowy=false]
setblock 20 72 -312 minecraft:netherrack
setblock 21 72 -312 minecraft:grass_block[snowy=false]
setblock 25 72 -312 regions_unexplored:grass_sprouts
setblock 26 72 -312 minecraft:short_grass
setblock 28 72 -312 minecraft:short_grass
setblock 34 72 -312 minecraft:birch_log[axis=y]
setblock 40 72 -312 minecraft:birch_log[axis=y]
setblock 64 72 -312 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 72 -313 13 72 -313 minecraft:dirt
fill 14 72 -313 19 72 -313 minecraft:grass_block[snowy=false]
setblock 20 72 -313 minecraft:magma_block
setblock 21 72 -313 regions_unexplored:grass_sprouts
setblock 28 72 -313 minecraft:short_grass
setblock 32 72 -313 minecraft:birch_log[axis=y]
setblock 53 72 -313 minecraft:birch_log[axis=y]
fill 8 72 -314 13 72 -314 minecraft:dirt
fill 14 72 -314 19 72 -314 minecraft:grass_block[snowy=false]
setblock 20 72 -314 minecraft:netherrack
fill 8 72 -315 13 72 -315 minecraft:dirt
fill 14 72 -315 18 72 -315 minecraft:grass_block[snowy=false]
setblock 19 72 -315 minecraft:netherrack
setblock 21 72 -315 minecraft:short_grass
setblock 48 72 -315 minecraft:birch_log[axis=y]
fill 8 72 -316 12 72 -316 minecraft:dirt
fill 13 72 -316 15 72 -316 minecraft:grass_block[snowy=false]
fill 16 72 -316 17 72 -316 minecraft:netherrack
fill 18 72 -316 19 72 -316 minecraft:grass_block[snowy=false]
fill 22 72 -316 23 72 -316 minecraft:short_grass
setblock 31 72 -316 minecraft:birch_log[axis=y]
setblock 64 72 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 72 -317 13 72 -317 minecraft:dirt
fill 14 72 -317 15 72 -317 minecraft:grass_block[snowy=false]
setblock 16 72 -317 minecraft:netherrack
setblock 17 72 -317 minecraft:grass_block[snowy=false]
fill 18 72 -317 19 72 -317 minecraft:netherrack
setblock 22 72 -317 regions_unexplored:grass_sprouts
setblock 26 72 -317 minecraft:birch_log[axis=y]
setblock 36 72 -317 minecraft:birch_log[axis=y]
setblock 47 72 -317 minecraft:birch_log[axis=y]
setblock 51 72 -317 minecraft:birch_log[axis=y]
fill 63 72 -317 65 72 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 72 -318 13 72 -318 minecraft:dirt
setblock 14 72 -318 minecraft:grass_block[snowy=false]
fill 15 72 -318 19 72 -318 minecraft:netherrack
setblock 26 72 -318 minecraft:short_grass
setblock 61 72 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 64 72 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 71 -255 19 71 -255 minecraft:stone
fill 20 71 -255 26 71 -255 minecraft:dirt
fill 9 71 -256 19 71 -256 minecraft:stone
fill 20 71 -256 26 71 -256 minecraft:dirt
fill 11 71 -257 19 71 -257 minecraft:stone
fill 20 71 -257 26 71 -257 minecraft:dirt
fill 11 71 -258 18 71 -258 minecraft:stone
fill 19 71 -258 26 71 -258 minecraft:dirt
fill 11 71 -259 18 71 -259 minecraft:stone
setblock 19 71 -259 minecraft:dirt
setblock 20 71 -259 minecraft:stone
fill 21 71 -259 26 71 -259 minecraft:dirt
fill 10 71 -260 17 71 -260 minecraft:stone
fill 18 71 -260 26 71 -260 minecraft:dirt
fill 9 71 -261 18 71 -261 minecraft:stone
fill 19 71 -261 26 71 -261 minecraft:dirt
fill 8 71 -262 17 71 -262 minecraft:stone
fill 18 71 -262 26 71 -262 minecraft:dirt
fill 8 71 -263 17 71 -263 minecraft:stone
fill 18 71 -263 19 71 -263 minecraft:dirt
setblock 20 71 -263 minecraft:stone
fill 21 71 -263 26 71 -263 minecraft:dirt
fill 8 71 -264 17 71 -264 minecraft:stone
fill 18 71 -264 26 71 -264 minecraft:dirt
fill 8 71 -265 16 71 -265 minecraft:stone
setblock 17 71 -265 minecraft:dirt
setblock 18 71 -265 minecraft:stone
fill 19 71 -265 26 71 -265 minecraft:dirt
fill 8 71 -266 17 71 -266 minecraft:stone
fill 18 71 -266 26 71 -266 minecraft:dirt
fill 8 71 -267 16 71 -267 minecraft:stone
fill 17 71 -267 26 71 -267 minecraft:dirt
fill 8 71 -268 16 71 -268 minecraft:stone
fill 17 71 -268 26 71 -268 minecraft:dirt
fill 8 71 -269 11 71 -269 minecraft:dirt
fill 12 71 -269 15 71 -269 minecraft:stone
setblock 16 71 -269 minecraft:dirt
setblock 17 71 -269 minecraft:stone
fill 18 71 -269 26 71 -269 minecraft:dirt
fill 8 71 -270 11 71 -270 minecraft:dirt
fill 12 71 -270 13 71 -270 minecraft:stone
setblock 14 71 -270 minecraft:dirt
setblock 15 71 -270 minecraft:stone
fill 16 71 -270 26 71 -270 minecraft:dirt
fill 8 71 -271 12 71 -271 minecraft:dirt
fill 13 71 -271 16 71 -271 minecraft:stone
fill 17 71 -271 26 71 -271 minecraft:dirt
fill 8 71 -272 12 71 -272 minecraft:dirt
setblock 13 71 -272 minecraft:stone
setblock 14 71 -272 minecraft:dirt
fill 15 71 -272 17 71 -272 minecraft:stone
fill 18 71 -272 26 71 -272 minecraft:dirt
fill 8 71 -273 11 71 -273 minecraft:dirt
setblock 12 71 -273 minecraft:stone
fill 13 71 -273 15 71 -273 minecraft:dirt
setblock 16 71 -273 minecraft:stone
fill 17 71 -273 26 71 -273 minecraft:dirt
fill 8 71 -274 11 71 -274 minecraft:dirt
setblock 12 71 -274 minecraft:stone
fill 13 71 -274 15 71 -274 minecraft:dirt
setblock 16 71 -274 minecraft:stone
fill 17 71 -274 26 71 -274 minecraft:dirt
fill 8 71 -275 11 71 -275 minecraft:dirt
setblock 12 71 -275 minecraft:stone
fill 13 71 -275 26 71 -275 minecraft:dirt
fill 8 71 -276 26 71 -276 minecraft:dirt
setblock 8 71 -277 minecraft:grass_block[snowy=false]
fill 9 71 -277 26 71 -277 minecraft:dirt
setblock 8 71 -278 minecraft:grass_block[snowy=false]
fill 9 71 -278 11 71 -278 minecraft:dirt
setblock 12 71 -278 minecraft:stone
fill 13 71 -278 26 71 -278 minecraft:dirt
setblock 8 71 -279 minecraft:grass_block[snowy=false]
fill 9 71 -279 26 71 -279 minecraft:dirt
setblock 8 71 -280 minecraft:grass_block[snowy=false]
fill 9 71 -280 26 71 -280 minecraft:dirt
fill 8 71 -281 26 71 -281 minecraft:dirt
fill 8 71 -282 26 71 -282 minecraft:dirt
fill 8 71 -283 27 71 -283 minecraft:dirt
setblock 28 71 -283 minecraft:grass_block[snowy=false]
setblock 29 71 -283 minecraft:dirt
setblock 40 71 -283 regions_unexplored:grass_sprouts
setblock 42 71 -283 minecraft:short_grass
fill 8 71 -284 26 71 -284 minecraft:dirt
setblock 51 71 -284 minecraft:short_grass
fill 8 71 -285 24 71 -285 minecraft:dirt
setblock 43 71 -285 minecraft:birch_log[axis=y]
fill 8 71 -286 23 71 -286 minecraft:dirt
setblock 49 71 -286 minecraft:birch_log[axis=y]
fill 8 71 -287 22 71 -287 minecraft:dirt
setblock 52 71 -287 minecraft:birch_log[axis=y]
setblock 53 71 -287 minecraft:lilac[half=upper]
setblock 60 71 -287 minecraft:lilac[half=upper]
fill 8 71 -288 22 71 -288 minecraft:dirt
setblock 30 71 -288 minecraft:birch_log[axis=y]
setblock 56 71 -288 minecraft:lilac[half=upper]
fill 8 71 -289 22 71 -289 minecraft:dirt
setblock 60 71 -289 minecraft:birch_log[axis=y]
fill 8 71 -290 22 71 -290 minecraft:dirt
fill 8 71 -291 24 71 -291 minecraft:dirt
setblock 33 71 -291 minecraft:grass_block[snowy=false]
setblock 40 71 -291 minecraft:birch_log[axis=y]
setblock 43 71 -291 minecraft:birch_log[axis=y]
fill 8 71 -292 26 71 -292 minecraft:dirt
fill 27 71 -292 28 71 -292 minecraft:grass_block[snowy=false]
setblock 29 71 -292 minecraft:dirt
fill 30 71 -292 33 71 -292 minecraft:grass_block[snowy=false]
setblock 52 71 -292 minecraft:birch_log[axis=y]
fill 8 71 -293 26 71 -293 minecraft:dirt
fill 27 71 -293 32 71 -293 minecraft:grass_block[snowy=false]
setblock 67 71 -293 minecraft:birch_log[axis=y]
fill 8 71 -294 25 71 -294 minecraft:dirt
fill 26 71 -294 32 71 -294 minecraft:grass_block[snowy=false]
setblock 47 71 -294 minecraft:birch_log[axis=y]
setblock 56 71 -294 minecraft:birch_log[axis=y]
fill 8 71 -295 24 71 -295 minecraft:dirt
fill 25 71 -295 31 71 -295 minecraft:grass_block[snowy=false]
setblock 62 71 -295 minecraft:birch_log[axis=y]
fill 8 71 -296 24 71 -296 minecraft:dirt
fill 25 71 -296 31 71 -296 minecraft:grass_block[snowy=false]
setblock 68 71 -296 minecraft:birch_log[axis=y]
fill 8 71 -297 23 71 -297 minecraft:dirt
fill 24 71 -297 29 71 -297 minecraft:grass_block[snowy=false]
setblock 30 71 -297 minecraft:dirt
setblock 31 71 -297 minecraft:grass_block[snowy=false]
setblock 35 71 -297 minecraft:birch_log[axis=y]
setblock 40 71 -297 minecraft:birch_log[axis=y]
fill 8 71 -298 22 71 -298 minecraft:dirt
fill 23 71 -298 26 71 -298 minecraft:grass_block[snowy=false]
setblock 27 71 -298 minecraft:dirt
fill 28 71 -298 30 71 -298 minecraft:grass_block[snowy=false]
setblock 33 71 -298 minecraft:short_grass
setblock 35 71 -298 minecraft:short_grass
setblock 49 71 -298 minecraft:birch_log[axis=y]
fill 8 71 -299 22 71 -299 minecraft:dirt
fill 23 71 -299 30 71 -299 minecraft:grass_block[snowy=false]
setblock 46 71 -299 minecraft:birch_log[axis=y]
setblock 58 71 -299 minecraft:birch_log[axis=y]
fill 8 71 -300 21 71 -300 minecraft:dirt
fill 22 71 -300 30 71 -300 minecraft:grass_block[snowy=false]
setblock 33 71 -300 regions_unexplored:birch_shrub[half=lower]
fill 8 71 -301 21 71 -301 minecraft:dirt
fill 22 71 -301 27 71 -301 minecraft:grass_block[snowy=false]
setblock 28 71 -301 minecraft:dirt
fill 29 71 -301 30 71 -301 minecraft:grass_block[snowy=false]
setblock 31 71 -301 minecraft:short_grass
setblock 56 71 -301 minecraft:birch_log[axis=y]
setblock 59 71 -301 minecraft:birch_log[axis=y]
setblock 70 71 -301 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 71 -302 21 71 -302 minecraft:dirt
fill 22 71 -302 30 71 -302 minecraft:grass_block[snowy=false]
setblock 41 71 -302 minecraft:birch_log[axis=y]
setblock 69 71 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 71 -302 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 71 71 -302 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 71 -303 21 71 -303 minecraft:dirt
fill 22 71 -303 29 71 -303 minecraft:grass_block[snowy=false]
setblock 34 71 -303 regions_unexplored:grass_sprouts
setblock 68 71 -303 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 71 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 70 71 -303 minecraft:birch_log[axis=y]
setblock 71 71 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 71 -304 21 71 -304 minecraft:dirt
fill 22 71 -304 29 71 -304 minecraft:grass_block[snowy=false]
setblock 39 71 -304 minecraft:birch_log[axis=y]
setblock 64 71 -304 minecraft:birch_log[axis=y]
setblock 69 71 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 71 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 71 71 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 71 -305 21 71 -305 minecraft:dirt
fill 22 71 -305 24 71 -305 minecraft:grass_block[snowy=false]
setblock 25 71 -305 minecraft:dirt
fill 26 71 -305 29 71 -305 minecraft:grass_block[snowy=false]
setblock 70 71 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 71 -306 22 71 -306 minecraft:dirt
fill 23 71 -306 29 71 -306 minecraft:grass_block[snowy=false]
setblock 49 71 -306 minecraft:birch_log[axis=y]
fill 8 71 -307 23 71 -307 minecraft:dirt
fill 24 71 -307 29 71 -307 minecraft:grass_block[snowy=false]
setblock 30 71 -307 minecraft:short_grass
setblock 64 71 -307 minecraft:birch_log[axis=y]
setblock 65 71 -307 regions_unexplored:birch_branch[facing=east]
fill 8 71 -308 23 71 -308 minecraft:dirt
fill 24 71 -308 29 71 -308 minecraft:grass_block[snowy=false]
setblock 31 71 -308 minecraft:short_grass
setblock 46 71 -308 minecraft:birch_log[axis=y]
setblock 55 71 -308 minecraft:birch_log[axis=y]
fill 8 71 -309 22 71 -309 minecraft:dirt
fill 23 71 -309 28 71 -309 minecraft:grass_block[snowy=false]
setblock 31 71 -309 regions_unexplored:birch_shrub[half=lower]
setblock 62 71 -309 minecraft:birch_log[axis=y]
fill 8 71 -310 21 71 -310 minecraft:dirt
fill 22 71 -310 28 71 -310 minecraft:grass_block[snowy=false]
setblock 45 71 -310 minecraft:birch_log[axis=y]
setblock 51 71 -310 minecraft:birch_log[axis=y]
setblock 70 71 -310 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 71 -311 21 71 -311 minecraft:dirt
fill 22 71 -311 28 71 -311 minecraft:grass_block[snowy=false]
setblock 30 71 -311 minecraft:short_grass
fill 8 71 -312 19 71 -312 minecraft:dirt
setblock 20 71 -312 minecraft:netherrack
setblock 21 71 -312 minecraft:dirt
fill 22 71 -312 28 71 -312 minecraft:grass_block[snowy=false]
setblock 34 71 -312 minecraft:birch_log[axis=y]
setblock 40 71 -312 minecraft:birch_log[axis=y]
setblock 64 71 -312 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 71 -313 19 71 -313 minecraft:dirt
setblock 20 71 -313 minecraft:netherrack
fill 21 71 -313 28 71 -313 minecraft:grass_block[snowy=false]
setblock 32 71 -313 minecraft:birch_log[axis=y]
setblock 53 71 -313 minecraft:birch_log[axis=y]
fill 8 71 -314 19 71 -314 minecraft:dirt
setblock 20 71 -314 minecraft:netherrack
fill 21 71 -314 28 71 -314 minecraft:grass_block[snowy=false]
fill 8 71 -315 18 71 -315 minecraft:dirt
fill 19 71 -315 22 71 -315 minecraft:netherrack
fill 23 71 -315 27 71 -315 minecraft:grass_block[snowy=false]
setblock 28 71 -315 regions_unexplored:grass_sprouts
setblock 48 71 -315 productivebees:birch_wood_nest[axis=y,facing=north]
fill 8 71 -316 15 71 -316 minecraft:dirt
fill 16 71 -316 17 71 -316 minecraft:netherrack
fill 18 71 -316 19 71 -316 minecraft:dirt
setblock 20 71 -316 minecraft:grass_block[snowy=false]
fill 21 71 -316 23 71 -316 minecraft:netherrack
fill 24 71 -316 27 71 -316 minecraft:grass_block[snowy=false]
setblock 31 71 -316 minecraft:birch_log[axis=y]
fill 63 71 -316 65 71 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 71 -317 15 71 -317 minecraft:dirt
setblock 16 71 -317 minecraft:netherrack
setblock 17 71 -317 minecraft:dirt
fill 18 71 -317 19 71 -317 minecraft:netherrack
setblock 20 71 -317 minecraft:grass_block[snowy=false]
setblock 21 71 -317 minecraft:magma_block
setblock 22 71 -317 minecraft:grass_block[snowy=false]
setblock 23 71 -317 minecraft:magma_block
fill 24 71 -317 25 71 -317 minecraft:grass_block[snowy=false]
setblock 26 71 -317 minecraft:dirt
setblock 36 71 -317 minecraft:birch_log[axis=y]
setblock 47 71 -317 minecraft:birch_log[axis=y]
setblock 51 71 -317 minecraft:birch_log[axis=y]
fill 63 71 -317 65 71 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 71 -318 14 71 -318 minecraft:dirt
fill 15 71 -318 21 71 -318 minecraft:netherrack
setblock 22 71 -318 minecraft:grass_block[snowy=false]
fill 23 71 -318 24 71 -318 minecraft:netherrack
fill 25 71 -318 26 71 -318 minecraft:grass_block[snowy=false]
setblock 61 71 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 63 71 -318 65 71 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -255 21 70 -255 minecraft:stone
fill 22 70 -255 26 70 -255 minecraft:dirt
fill 8 70 -256 21 70 -256 minecraft:stone
fill 22 70 -256 26 70 -256 minecraft:dirt
setblock 8 70 -257 minecraft:stone
fill 9 70 -257 10 70 -257 alltheores:ruby_ore
fill 11 70 -257 21 70 -257 minecraft:stone
fill 22 70 -257 26 70 -257 minecraft:dirt
fill 9 70 -258 10 70 -258 alltheores:ruby_ore
fill 11 70 -258 19 70 -258 minecraft:stone
fill 20 70 -258 21 70 -258 minecraft:dirt
setblock 22 70 -258 minecraft:stone
fill 23 70 -258 26 70 -258 minecraft:dirt
fill 9 70 -259 20 70 -259 minecraft:stone
setblock 21 70 -259 minecraft:dirt
setblock 22 70 -259 minecraft:stone
fill 23 70 -259 26 70 -259 minecraft:dirt
fill 9 70 -260 22 70 -260 minecraft:stone
fill 23 70 -260 26 70 -260 minecraft:dirt
fill 8 70 -261 21 70 -261 minecraft:stone
setblock 22 70 -261 minecraft:dirt
setblock 23 70 -261 minecraft:stone
fill 24 70 -261 26 70 -261 minecraft:dirt
fill 8 70 -262 20 70 -262 minecraft:stone
setblock 21 70 -262 minecraft:dirt
setblock 22 70 -262 minecraft:stone
fill 23 70 -262 26 70 -262 minecraft:dirt
fill 8 70 -263 21 70 -263 minecraft:stone
fill 22 70 -263 26 70 -263 minecraft:dirt
fill 8 70 -264 19 70 -264 minecraft:stone
fill 20 70 -264 22 70 -264 minecraft:dirt
setblock 23 70 -264 minecraft:stone
fill 24 70 -264 26 70 -264 minecraft:dirt
fill 8 70 -265 19 70 -265 minecraft:stone
setblock 20 70 -265 minecraft:dirt
setblock 21 70 -265 minecraft:stone
fill 22 70 -265 26 70 -265 minecraft:dirt
fill 8 70 -266 18 70 -266 minecraft:stone
setblock 19 70 -266 minecraft:dirt
setblock 20 70 -266 minecraft:copper_ore
fill 21 70 -266 26 70 -266 minecraft:dirt
fill 8 70 -267 17 70 -267 minecraft:stone
fill 18 70 -267 20 70 -267 minecraft:dirt
setblock 21 70 -267 minecraft:stone
fill 22 70 -267 26 70 -267 minecraft:dirt
fill 8 70 -268 18 70 -268 minecraft:stone
fill 19 70 -268 26 70 -268 minecraft:dirt
fill 8 70 -269 17 70 -269 minecraft:stone
fill 18 70 -269 26 70 -269 minecraft:dirt
fill 8 70 -270 18 70 -270 minecraft:stone
fill 19 70 -270 26 70 -270 minecraft:dirt
setblock 8 70 -271 minecraft:dirt
fill 9 70 -271 20 70 -271 minecraft:stone
fill 21 70 -271 26 70 -271 minecraft:dirt
fill 8 70 -272 9 70 -272 minecraft:dirt
fill 10 70 -272 20 70 -272 minecraft:stone
fill 21 70 -272 26 70 -272 minecraft:dirt
fill 8 70 -273 9 70 -273 minecraft:dirt
fill 10 70 -273 20 70 -273 minecraft:stone
fill 21 70 -273 26 70 -273 minecraft:dirt
fill 8 70 -274 9 70 -274 minecraft:dirt
setblock 10 70 -274 minecraft:stone
setblock 11 70 -274 minecraft:dirt
fill 12 70 -274 20 70 -274 minecraft:stone
fill 21 70 -274 26 70 -274 minecraft:dirt
fill 8 70 -275 10 70 -275 minecraft:dirt
fill 11 70 -275 20 70 -275 minecraft:stone
fill 21 70 -275 26 70 -275 minecraft:dirt
fill 8 70 -276 10 70 -276 minecraft:dirt
fill 11 70 -276 20 70 -276 minecraft:stone
fill 21 70 -276 26 70 -276 minecraft:dirt
fill 8 70 -277 10 70 -277 minecraft:dirt
fill 11 70 -277 20 70 -277 minecraft:stone
fill 21 70 -277 26 70 -277 minecraft:dirt
fill 8 70 -278 10 70 -278 minecraft:dirt
fill 11 70 -278 18 70 -278 minecraft:stone
fill 19 70 -278 26 70 -278 minecraft:dirt
fill 8 70 -279 11 70 -279 minecraft:dirt
fill 12 70 -279 17 70 -279 minecraft:stone
fill 18 70 -279 26 70 -279 minecraft:dirt
fill 8 70 -280 14 70 -280 minecraft:dirt
fill 15 70 -280 16 70 -280 minecraft:stone
fill 17 70 -280 26 70 -280 minecraft:dirt
fill 8 70 -281 26 70 -281 minecraft:dirt
fill 8 70 -282 26 70 -282 minecraft:dirt
setblock 8 70 -283 minecraft:stone
fill 9 70 -283 29 70 -283 minecraft:dirt
fill 30 70 -283 51 70 -283 minecraft:grass_block[snowy=false]
fill 8 70 -284 25 70 -284 minecraft:dirt
fill 35 70 -284 53 70 -284 minecraft:grass_block[snowy=false]
fill 8 70 -285 23 70 -285 minecraft:dirt
fill 35 70 -285 42 70 -285 minecraft:grass_block[snowy=false]
setblock 43 70 -285 minecraft:dirt
fill 44 70 -285 53 70 -285 minecraft:grass_block[snowy=false]
setblock 55 70 -285 minecraft:short_grass
fill 8 70 -286 22 70 -286 minecraft:dirt
fill 36 70 -286 48 70 -286 minecraft:grass_block[snowy=false]
setblock 49 70 -286 minecraft:dirt
fill 50 70 -286 52 70 -286 minecraft:grass_block[snowy=false]
setblock 57 70 -286 regions_unexplored:orange_coneflower[facing=east,flower_amount=3]
fill 8 70 -287 21 70 -287 minecraft:dirt
fill 36 70 -287 50 70 -287 minecraft:grass_block[snowy=false]
setblock 52 70 -287 minecraft:birch_log[axis=y]
setblock 53 70 -287 minecraft:lilac[half=lower]
setblock 60 70 -287 minecraft:lilac[half=lower]
setblock 62 70 -287 minecraft:short_grass
fill 8 70 -288 20 70 -288 minecraft:dirt
setblock 30 70 -288 minecraft:birch_log[axis=y]
fill 35 70 -288 47 70 -288 minecraft:grass_block[snowy=false]
setblock 56 70 -288 minecraft:lilac[half=lower]
fill 8 70 -289 20 70 -289 minecraft:dirt
fill 35 70 -289 43 70 -289 minecraft:grass_block[snowy=false]
setblock 60 70 -289 minecraft:birch_log[axis=y]
fill 8 70 -290 21 70 -290 minecraft:dirt
fill 34 70 -290 41 70 -290 minecraft:grass_block[snowy=false]
setblock 61 70 -290 regions_unexplored:grass_sprouts
fill 8 70 -291 21 70 -291 minecraft:dirt
setblock 32 70 -291 minecraft:grass_block[snowy=false]
setblock 33 70 -291 minecraft:dirt
fill 34 70 -291 39 70 -291 minecraft:grass_block[snowy=false]
setblock 40 70 -291 minecraft:birch_log[axis=y]
setblock 43 70 -291 minecraft:birch_log[axis=y]
setblock 61 70 -291 minecraft:short_grass
fill 8 70 -292 23 70 -292 minecraft:dirt
fill 28 70 -292 33 70 -292 minecraft:dirt
fill 34 70 -292 37 70 -292 minecraft:grass_block[snowy=false]
setblock 49 70 -292 minecraft:short_grass
setblock 52 70 -292 minecraft:birch_log[axis=y]
setblock 53 70 -292 regions_unexplored:grass_sprouts
setblock 62 70 -292 minecraft:short_grass
fill 8 70 -293 32 70 -293 minecraft:dirt
fill 33 70 -293 37 70 -293 minecraft:grass_block[snowy=false]
setblock 67 70 -293 minecraft:birch_log[axis=y]
fill 8 70 -294 32 70 -294 minecraft:dirt
fill 33 70 -294 36 70 -294 minecraft:grass_block[snowy=false]
setblock 47 70 -294 minecraft:birch_log[axis=y]
setblock 56 70 -294 minecraft:birch_log[axis=y]
fill 8 70 -295 31 70 -295 minecraft:dirt
fill 32 70 -295 36 70 -295 minecraft:grass_block[snowy=false]
setblock 62 70 -295 minecraft:birch_log[axis=y]
fill 8 70 -296 31 70 -296 minecraft:dirt
fill 32 70 -296 35 70 -296 minecraft:grass_block[snowy=false]
setblock 68 70 -296 minecraft:birch_log[axis=y]
fill 8 70 -297 31 70 -297 minecraft:dirt
fill 32 70 -297 34 70 -297 minecraft:grass_block[snowy=false]
setblock 35 70 -297 minecraft:dirt
setblock 36 70 -297 regions_unexplored:grass_sprouts
setblock 40 70 -297 minecraft:birch_log[axis=y]
setblock 43 70 -297 regions_unexplored:grass_sprouts
setblock 45 70 -297 minecraft:short_grass
fill 8 70 -298 30 70 -298 minecraft:dirt
fill 31 70 -298 35 70 -298 minecraft:grass_block[snowy=false]
setblock 39 70 -298 minecraft:short_grass
setblock 42 70 -298 regions_unexplored:grass_sprouts
setblock 49 70 -298 minecraft:birch_log[axis=y]
fill 8 70 -299 30 70 -299 minecraft:dirt
fill 31 70 -299 35 70 -299 minecraft:grass_block[snowy=false]
setblock 37 70 -299 minecraft:short_grass
setblock 40 70 -299 minecraft:short_grass
setblock 46 70 -299 minecraft:birch_log[axis=y]
setblock 58 70 -299 minecraft:birch_log[axis=y]
fill 8 70 -300 30 70 -300 minecraft:dirt
fill 31 70 -300 35 70 -300 minecraft:grass_block[snowy=false]
fill 8 70 -301 30 70 -301 minecraft:dirt
fill 31 70 -301 35 70 -301 minecraft:grass_block[snowy=false]
setblock 36 70 -301 regions_unexplored:grass_sprouts
setblock 56 70 -301 minecraft:birch_log[axis=y]
setblock 59 70 -301 minecraft:birch_log[axis=y]
fill 8 70 -302 30 70 -302 minecraft:dirt
fill 31 70 -302 34 70 -302 minecraft:grass_block[snowy=false]
setblock 35 70 -302 regions_unexplored:grass_sprouts
setblock 36 70 -302 minecraft:short_grass
setblock 41 70 -302 minecraft:birch_log[axis=y]
setblock 42 70 -302 minecraft:short_grass
setblock 43 70 -302 regions_unexplored:grass_sprouts
fill 8 70 -303 29 70 -303 minecraft:dirt
fill 30 70 -303 34 70 -303 minecraft:grass_block[snowy=false]
fill 40 70 -303 41 70 -303 regions_unexplored:grass_sprouts
setblock 43 70 -303 regions_unexplored:grass_sprouts
setblock 70 70 -303 minecraft:birch_log[axis=y]
setblock 71 70 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -304 29 70 -304 minecraft:dirt
fill 30 70 -304 33 70 -304 minecraft:grass_block[snowy=false]
setblock 35 70 -304 minecraft:short_grass
setblock 39 70 -304 minecraft:birch_log[axis=y]
setblock 42 70 -304 minecraft:short_grass
setblock 64 70 -304 minecraft:birch_log[axis=y]
setblock 71 70 -304 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 70 -305 29 70 -305 minecraft:dirt
fill 30 70 -305 33 70 -305 minecraft:grass_block[snowy=false]
setblock 34 70 -305 minecraft:short_grass
setblock 35 70 -305 regions_unexplored:grass_sprouts
setblock 37 70 -305 regions_unexplored:grass_sprouts
setblock 38 70 -305 minecraft:short_grass
setblock 40 70 -305 minecraft:short_grass
setblock 71 70 -305 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 8 70 -306 29 70 -306 minecraft:dirt
fill 30 70 -306 33 70 -306 minecraft:grass_block[snowy=false]
setblock 38 70 -306 minecraft:short_grass
setblock 40 70 -306 regions_unexplored:grass_sprouts
setblock 49 70 -306 minecraft:birch_log[axis=y]
fill 8 70 -307 29 70 -307 minecraft:dirt
fill 30 70 -307 33 70 -307 minecraft:grass_block[snowy=false]
setblock 64 70 -307 minecraft:birch_log[axis=y]
fill 8 70 -308 29 70 -308 minecraft:dirt
fill 30 70 -308 33 70 -308 minecraft:grass_block[snowy=false]
setblock 39 70 -308 minecraft:short_grass
setblock 46 70 -308 minecraft:birch_log[axis=y]
setblock 55 70 -308 minecraft:birch_log[axis=y]
fill 8 70 -309 28 70 -309 minecraft:dirt
fill 29 70 -309 32 70 -309 minecraft:grass_block[snowy=false]
setblock 62 70 -309 minecraft:birch_log[axis=y]
fill 8 70 -310 28 70 -310 minecraft:dirt
fill 29 70 -310 32 70 -310 minecraft:grass_block[snowy=false]
setblock 38 70 -310 regions_unexplored:grass_sprouts
setblock 45 70 -310 minecraft:birch_log[axis=y]
setblock 51 70 -310 minecraft:birch_log[axis=y]
setblock 70 70 -310 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 70 -311 28 70 -311 minecraft:dirt
fill 29 70 -311 32 70 -311 minecraft:grass_block[snowy=false]
fill 8 70 -312 19 70 -312 minecraft:dirt
setblock 20 70 -312 minecraft:netherrack
fill 21 70 -312 28 70 -312 minecraft:dirt
fill 29 70 -312 32 70 -312 minecraft:grass_block[snowy=false]
setblock 33 70 -312 minecraft:short_grass
setblock 34 70 -312 minecraft:birch_log[axis=y]
setblock 35 70 -312 minecraft:short_grass
setblock 38 70 -312 regions_unexplored:grass_sprouts
setblock 40 70 -312 minecraft:birch_log[axis=y]
setblock 64 70 -312 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 70 -313 19 70 -313 minecraft:dirt
setblock 20 70 -313 minecraft:netherrack
fill 21 70 -313 28 70 -313 minecraft:dirt
fill 29 70 -313 31 70 -313 minecraft:grass_block[snowy=false]
setblock 32 70 -313 minecraft:dirt
setblock 53 70 -313 minecraft:birch_log[axis=y]
fill 8 70 -314 28 70 -314 minecraft:dirt
fill 29 70 -314 32 70 -314 minecraft:grass_block[snowy=false]
setblock 33 70 -314 regions_unexplored:grass_sprouts
fill 8 70 -315 18 70 -315 minecraft:dirt
fill 19 70 -315 22 70 -315 minecraft:netherrack
fill 23 70 -315 27 70 -315 minecraft:dirt
fill 28 70 -315 32 70 -315 minecraft:grass_block[snowy=false]
setblock 48 70 -315 minecraft:birch_log[axis=y]
setblock 64 70 -315 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -316 15 70 -316 minecraft:dirt
fill 16 70 -316 17 70 -316 minecraft:netherrack
fill 18 70 -316 20 70 -316 minecraft:dirt
setblock 21 70 -316 minecraft:netherrack
setblock 22 70 -316 minecraft:magma_block
setblock 23 70 -316 minecraft:netherrack
fill 24 70 -316 27 70 -316 minecraft:dirt
fill 28 70 -316 30 70 -316 minecraft:grass_block[snowy=false]
setblock 31 70 -316 minecraft:dirt
setblock 32 70 -316 minecraft:grass_block[snowy=false]
fill 63 70 -316 65 70 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -317 17 70 -317 minecraft:dirt
setblock 18 70 -317 minecraft:netherrack
fill 19 70 -317 20 70 -317 minecraft:dirt
setblock 21 70 -317 minecraft:magma_block
setblock 22 70 -317 minecraft:dirt
setblock 23 70 -317 minecraft:netherrack
fill 24 70 -317 26 70 -317 minecraft:dirt
fill 27 70 -317 32 70 -317 minecraft:grass_block[snowy=false]
setblock 36 70 -317 minecraft:birch_log[axis=y]
setblock 47 70 -317 minecraft:birch_log[axis=y]
setblock 51 70 -317 minecraft:birch_log[axis=y]
fill 62 70 -317 63 70 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 70 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 65 70 -317 66 70 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -318 15 70 -318 minecraft:dirt
setblock 16 70 -318 minecraft:netherrack
setblock 17 70 -318 minecraft:dirt
setblock 18 70 -318 minecraft:netherrack
setblock 19 70 -318 minecraft:dirt
fill 20 70 -318 21 70 -318 minecraft:netherrack
setblock 22 70 -318 minecraft:dirt
fill 23 70 -318 24 70 -318 minecraft:netherrack
fill 25 70 -318 26 70 -318 minecraft:dirt
fill 27 70 -318 32 70 -318 minecraft:grass_block[snowy=false]
setblock 61 70 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 63 70 -318 65 70 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 69 -255 20 69 -255 minecraft:stone
fill 21 69 -255 22 69 -255 alltheores:zinc_ore
setblock 23 69 -255 minecraft:stone
fill 24 69 -255 26 69 -255 minecraft:dirt
fill 8 69 -256 23 69 -256 minecraft:stone
fill 24 69 -256 26 69 -256 minecraft:dirt
fill 8 69 -257 23 69 -257 minecraft:stone
fill 24 69 -257 26 69 -257 minecraft:dirt
fill 8 69 -258 24 69 -258 minecraft:stone
fill 25 69 -258 26 69 -258 minecraft:dirt
fill 8 69 -259 25 69 -259 minecraft:stone
setblock 26 69 -259 minecraft:dirt
fill 8 69 -260 25 69 -260 minecraft:stone
setblock 26 69 -260 minecraft:dirt
fill 8 69 -261 23 69 -261 minecraft:stone
setblock 24 69 -261 minecraft:dirt
setblock 25 69 -261 minecraft:stone
setblock 26 69 -261 minecraft:dirt
fill 8 69 -262 25 69 -262 minecraft:stone
setblock 26 69 -262 minecraft:dirt
fill 8 69 -263 20 69 -263 minecraft:stone
setblock 21 69 -263 theurgy:sal_ammoniac_ore
fill 22 69 -263 23 69 -263 minecraft:stone
setblock 24 69 -263 minecraft:dirt
setblock 25 69 -263 minecraft:stone
setblock 26 69 -263 minecraft:dirt
fill 8 69 -264 23 69 -264 minecraft:stone
setblock 24 69 -264 minecraft:dirt
setblock 25 69 -264 minecraft:stone
setblock 26 69 -264 minecraft:dirt
fill 8 69 -265 22 69 -265 minecraft:stone
fill 23 69 -265 24 69 -265 minecraft:dirt
setblock 25 69 -265 minecraft:stone
setblock 26 69 -265 minecraft:dirt
setblock 8 69 -266 minecraft:copper_ore
fill 9 69 -266 18 69 -266 minecraft:stone
setblock 19 69 -266 minecraft:copper_ore
fill 20 69 -266 21 69 -266 minecraft:stone
fill 22 69 -266 23 69 -266 minecraft:dirt
setblock 24 69 -266 minecraft:stone
fill 25 69 -266 26 69 -266 minecraft:dirt
setblock 8 69 -267 minecraft:copper_ore
fill 9 69 -267 21 69 -267 minecraft:stone
fill 22 69 -267 23 69 -267 minecraft:dirt
setblock 24 69 -267 minecraft:stone
fill 25 69 -267 26 69 -267 minecraft:dirt
fill 8 69 -268 20 69 -268 minecraft:stone
fill 21 69 -268 26 69 -268 minecraft:dirt
fill 8 69 -269 21 69 -269 minecraft:stone
fill 22 69 -269 26 69 -269 minecraft:dirt
fill 8 69 -270 22 69 -270 minecraft:stone
fill 23 69 -270 26 69 -270 minecraft:dirt
fill 8 69 -271 22 69 -271 minecraft:stone
fill 23 69 -271 26 69 -271 minecraft:dirt
fill 8 69 -272 23 69 -272 minecraft:stone
fill 24 69 -272 26 69 -272 minecraft:dirt
fill 8 69 -273 23 69 -273 minecraft:stone
fill 24 69 -273 26 69 -273 minecraft:dirt
setblock 8 69 -274 minecraft:dirt
fill 9 69 -274 22 69 -274 minecraft:stone
fill 23 69 -274 26 69 -274 minecraft:dirt
setblock 8 69 -275 minecraft:dirt
fill 9 69 -275 22 69 -275 minecraft:stone
fill 23 69 -275 26 69 -275 minecraft:dirt
setblock 8 69 -276 minecraft:dirt
fill 9 69 -276 22 69 -276 minecraft:stone
fill 23 69 -276 26 69 -276 minecraft:dirt
fill 8 69 -277 9 69 -277 minecraft:dirt
fill 10 69 -277 22 69 -277 minecraft:stone
fill 23 69 -277 26 69 -277 minecraft:dirt
fill 8 69 -278 9 69 -278 minecraft:dirt
fill 10 69 -278 21 69 -278 minecraft:stone
fill 22 69 -278 26 69 -278 minecraft:dirt
fill 8 69 -279 9 69 -279 minecraft:dirt
fill 10 69 -279 21 69 -279 minecraft:stone
fill 22 69 -279 26 69 -279 minecraft:dirt
fill 8 69 -280 10 69 -280 minecraft:dirt
fill 11 69 -280 20 69 -280 minecraft:stone
fill 21 69 -280 26 69 -280 minecraft:dirt
fill 8 69 -281 9 69 -281 minecraft:dirt
setblock 10 69 -281 minecraft:stone
setblock 11 69 -281 minecraft:dirt
fill 12 69 -281 19 69 -281 minecraft:stone
fill 20 69 -281 26 69 -281 minecraft:dirt
fill 8 69 -282 10 69 -282 minecraft:stone
fill 11 69 -282 12 69 -282 minecraft:dirt
setblock 13 69 -282 minecraft:coal_ore
fill 14 69 -282 20 69 -282 minecraft:stone
fill 21 69 -282 26 69 -282 minecraft:dirt
fill 8 69 -283 9 69 -283 minecraft:stone
fill 10 69 -283 13 69 -283 minecraft:dirt
setblock 14 69 -283 minecraft:coal_ore
fill 15 69 -283 18 69 -283 minecraft:stone
fill 19 69 -283 51 69 -283 minecraft:dirt
fill 8 69 -284 10 69 -284 minecraft:stone
fill 11 69 -284 14 69 -284 minecraft:dirt
setblock 15 69 -284 minecraft:coal_ore
fill 16 69 -284 18 69 -284 minecraft:stone
fill 19 69 -284 25 69 -284 minecraft:dirt
fill 30 69 -284 34 69 -284 minecraft:grass_block[snowy=false]
fill 35 69 -284 53 69 -284 minecraft:dirt
setblock 54 69 -284 minecraft:grass_block[snowy=false]
fill 56 69 -284 58 69 -284 minecraft:grass_block[snowy=false]
setblock 60 69 -284 regions_unexplored:orange_coneflower[facing=east,flower_amount=2]
setblock 61 69 -284 regions_unexplored:orange_coneflower[facing=east,flower_amount=4]
setblock 65 69 -284 regions_unexplored:orange_coneflower[facing=south,flower_amount=4]
fill 8 69 -285 10 69 -285 minecraft:stone
fill 11 69 -285 14 69 -285 minecraft:dirt
setblock 15 69 -285 minecraft:coal_ore
fill 16 69 -285 17 69 -285 minecraft:stone
fill 18 69 -285 22 69 -285 minecraft:dirt
fill 33 69 -285 34 69 -285 minecraft:grass_block[snowy=false]
fill 35 69 -285 53 69 -285 minecraft:dirt
fill 54 69 -285 59 69 -285 minecraft:grass_block[snowy=false]
setblock 64 69 -285 minecraft:short_grass
fill 8 69 -286 11 69 -286 minecraft:stone
fill 12 69 -286 14 69 -286 minecraft:dirt
setblock 15 69 -286 minecraft:coal_ore
fill 16 69 -286 17 69 -286 minecraft:stone
fill 18 69 -286 21 69 -286 minecraft:dirt
fill 34 69 -286 35 69 -286 minecraft:grass_block[snowy=false]
fill 36 69 -286 52 69 -286 minecraft:dirt
fill 53 69 -286 61 69 -286 minecraft:grass_block[snowy=false]
setblock 62 69 -286 regions_unexplored:orange_coneflower[facing=north,flower_amount=3]
fill 8 69 -287 15 69 -287 minecraft:stone
fill 16 69 -287 20 69 -287 minecraft:dirt
fill 34 69 -287 35 69 -287 minecraft:grass_block[snowy=false]
fill 36 69 -287 50 69 -287 minecraft:dirt
setblock 51 69 -287 minecraft:grass_block[snowy=false]
setblock 52 69 -287 minecraft:dirt
fill 53 69 -287 62 69 -287 minecraft:grass_block[snowy=false]
fill 8 69 -288 15 69 -288 minecraft:stone
fill 16 69 -288 20 69 -288 minecraft:dirt
setblock 30 69 -288 minecraft:birch_log[axis=y]
setblock 34 69 -288 minecraft:grass_block[snowy=false]
fill 35 69 -288 47 69 -288 minecraft:dirt
fill 48 69 -288 63 69 -288 minecraft:grass_block[snowy=false]
fill 8 69 -289 14 69 -289 minecraft:stone
fill 15 69 -289 19 69 -289 minecraft:dirt
setblock 20 69 -289 minecraft:air
fill 33 69 -289 34 69 -289 minecraft:grass_block[snowy=false]
fill 35 69 -289 43 69 -289 minecraft:dirt
fill 44 69 -289 59 69 -289 minecraft:grass_block[snowy=false]
setblock 60 69 -289 minecraft:dirt
fill 61 69 -289 63 69 -289 minecraft:grass_block[snowy=false]
fill 8 69 -290 13 69 -290 minecraft:stone
fill 14 69 -290 20 69 -290 minecraft:dirt
fill 32 69 -290 33 69 -290 minecraft:grass_block[snowy=false]
fill 34 69 -290 41 69 -290 minecraft:dirt
fill 42 69 -290 62 69 -290 minecraft:grass_block[snowy=false]
setblock 68 69 -290 minecraft:short_grass
fill 8 69 -291 13 69 -291 minecraft:stone
fill 14 69 -291 20 69 -291 minecraft:dirt
setblock 31 69 -291 minecraft:grass_block[snowy=false]
fill 32 69 -291 40 69 -291 minecraft:dirt
fill 41 69 -291 42 69 -291 minecraft:grass_block[snowy=false]
setblock 43 69 -291 minecraft:dirt
fill 44 69 -291 62 69 -291 minecraft:grass_block[snowy=false]
fill 8 69 -292 12 69 -292 minecraft:stone
fill 13 69 -292 21 69 -292 minecraft:dirt
fill 28 69 -292 37 69 -292 minecraft:dirt
fill 38 69 -292 51 69 -292 minecraft:grass_block[snowy=false]
setblock 52 69 -292 minecraft:dirt
fill 53 69 -292 62 69 -292 minecraft:grass_block[snowy=false]
setblock 63 69 -292 regions_unexplored:grass_sprouts
setblock 67 69 -292 regions_unexplored:grass_sprouts
fill 8 69 -293 11 69 -293 minecraft:stone
fill 12 69 -293 37 69 -293 minecraft:dirt
setblock 38 69 -293 minecraft:grass_block[snowy=false]
fill 40 69 -293 60 69 -293 minecraft:grass_block[snowy=false]
setblock 67 69 -293 minecraft:birch_log[axis=y]
fill 8 69 -294 9 69 -294 minecraft:stone
fill 10 69 -294 36 69 -294 minecraft:dirt
setblock 37 69 -294 minecraft:grass_block[snowy=false]
fill 41 69 -294 46 69 -294 minecraft:grass_block[snowy=false]
setblock 47 69 -294 minecraft:dirt
fill 48 69 -294 51 69 -294 minecraft:grass_block[snowy=false]
setblock 53 69 -294 minecraft:short_grass
setblock 56 69 -294 minecraft:birch_log[axis=y]
setblock 58 69 -294 minecraft:short_grass
setblock 60 69 -294 minecraft:short_grass
fill 8 69 -295 36 69 -295 minecraft:dirt
setblock 37 69 -295 minecraft:grass_block[snowy=false]
fill 42 69 -295 48 69 -295 minecraft:grass_block[snowy=false]
setblock 51 69 -295 minecraft:short_grass
setblock 55 69 -295 regions_unexplored:grass_sprouts
setblock 61 69 -295 minecraft:short_grass
setblock 62 69 -295 minecraft:birch_log[axis=y]
fill 8 69 -296 35 69 -296 minecraft:dirt
fill 36 69 -296 37 69 -296 minecraft:grass_block[snowy=false]
fill 41 69 -296 46 69 -296 minecraft:grass_block[snowy=false]
setblock 52 69 -296 regions_unexplored:grass_sprouts
fill 55 69 -296 57 69 -296 minecraft:short_grass
setblock 68 69 -296 minecraft:birch_log[axis=y]
fill 8 69 -297 35 69 -297 minecraft:dirt
fill 36 69 -297 37 69 -297 minecraft:grass_block[snowy=false]
setblock 40 69 -297 minecraft:dirt
fill 41 69 -297 46 69 -297 minecraft:grass_block[snowy=false]
setblock 49 69 -297 regions_unexplored:grass_sprouts
fill 54 69 -297 55 69 -297 regions_unexplored:grass_sprouts
setblock 63 69 -297 minecraft:short_grass
fill 8 69 -298 35 69 -298 minecraft:dirt
fill 36 69 -298 45 69 -298 minecraft:grass_block[snowy=false]
setblock 49 69 -298 minecraft:birch_log[axis=y]
setblock 55 69 -298 minecraft:short_grass
setblock 57 69 -298 regions_unexplored:grass_sprouts
fill 8 69 -299 35 69 -299 minecraft:dirt
fill 36 69 -299 45 69 -299 minecraft:grass_block[snowy=false]
setblock 46 69 -299 minecraft:birch_log[axis=y]
setblock 48 69 -299 regions_unexplored:grass_sprouts
setblock 58 69 -299 minecraft:birch_log[axis=y]
fill 8 69 -300 35 69 -300 minecraft:dirt
fill 36 69 -300 44 69 -300 minecraft:grass_block[snowy=false]
setblock 45 69 -300 regions_unexplored:grass_sprouts
setblock 50 69 -300 minecraft:short_grass
setblock 55 69 -300 regions_unexplored:grass_sprouts
fill 8 69 -301 35 69 -301 minecraft:dirt
fill 36 69 -301 44 69 -301 minecraft:grass_block[snowy=false]
setblock 54 69 -301 minecraft:short_grass
setblock 56 69 -301 minecraft:birch_log[axis=y]
setblock 59 69 -301 minecraft:birch_log[axis=y]
fill 8 69 -302 34 69 -302 minecraft:dirt
fill 35 69 -302 40 69 -302 minecraft:grass_block[snowy=false]
setblock 41 69 -302 minecraft:dirt
fill 42 69 -302 43 69 -302 minecraft:grass_block[snowy=false]
setblock 49 69 -302 minecraft:short_grass
setblock 51 69 -302 minecraft:short_grass
fill 8 69 -303 34 69 -303 minecraft:dirt
fill 35 69 -303 43 69 -303 minecraft:grass_block[snowy=false]
setblock 70 69 -303 minecraft:birch_log[axis=y]
setblock 71 69 -303 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 69 -304 33 69 -304 minecraft:dirt
fill 34 69 -304 38 69 -304 minecraft:grass_block[snowy=false]
setblock 39 69 -304 minecraft:dirt
fill 40 69 -304 43 69 -304 minecraft:grass_block[snowy=false]
fill 48 69 -304 49 69 -304 minecraft:short_grass
setblock 64 69 -304 minecraft:birch_log[axis=y]
setblock 65 69 -304 regions_unexplored:birch_branch[facing=east]
fill 70 69 -304 71 69 -304 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 69 -305 33 69 -305 minecraft:dirt
fill 34 69 -305 41 69 -305 minecraft:grass_block[snowy=false]
setblock 71 69 -305 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 69 -306 33 69 -306 minecraft:dirt
fill 35 69 -306 40 69 -306 minecraft:grass_block[snowy=false]
setblock 49 69 -306 minecraft:birch_log[axis=y]
fill 8 69 -307 33 69 -307 minecraft:dirt
fill 38 69 -307 39 69 -307 minecraft:grass_block[snowy=false]
setblock 44 69 -307 minecraft:short_grass
setblock 46 69 -307 minecraft:short_grass
setblock 64 69 -307 minecraft:birch_log[axis=y]
fill 8 69 -308 33 69 -308 minecraft:dirt
fill 38 69 -308 39 69 -308 minecraft:grass_block[snowy=false]
setblock 45 69 -308 minecraft:short_grass
setblock 46 69 -308 minecraft:birch_log[axis=y]
setblock 55 69 -308 minecraft:birch_log[axis=y]
fill 8 69 -309 32 69 -309 minecraft:dirt
setblock 33 69 -309 minecraft:grass_block[snowy=false]
setblock 37 69 -309 regions_unexplored:grass_sprouts
fill 38 69 -309 39 69 -309 minecraft:grass_block[snowy=false]
setblock 42 69 -309 minecraft:short_grass
setblock 62 69 -309 minecraft:birch_log[axis=y]
setblock 70 69 -309 regions_unexplored:silver_birch_log[axis=z,is_base=false]
fill 8 69 -310 32 69 -310 minecraft:dirt
fill 33 69 -310 38 69 -310 minecraft:grass_block[snowy=false]
setblock 45 69 -310 minecraft:birch_log[axis=y]
setblock 51 69 -310 minecraft:birch_log[axis=y]
setblock 70 69 -310 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 69 -311 32 69 -311 minecraft:dirt
fill 33 69 -311 38 69 -311 minecraft:grass_block[snowy=false]
setblock 43 69 -311 regions_unexplored:grass_sprouts
fill 8 69 -312 32 69 -312 minecraft:dirt
setblock 33 69 -312 minecraft:grass_block[snowy=false]
setblock 34 69 -312 minecraft:dirt
fill 35 69 -312 38 69 -312 minecraft:grass_block[snowy=false]
setblock 40 69 -312 minecraft:birch_log[axis=y]
setblock 64 69 -312 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 69 -313 19 69 -313 minecraft:dirt
setblock 20 69 -313 minecraft:netherrack
fill 21 69 -313 32 69 -313 minecraft:dirt
fill 33 69 -313 38 69 -313 minecraft:grass_block[snowy=false]
setblock 42 69 -313 regions_unexplored:grass_sprouts
setblock 44 69 -313 regions_unexplored:grass_sprouts
setblock 53 69 -313 minecraft:birch_log[axis=y]
fill 8 69 -314 32 69 -314 minecraft:dirt
fill 33 69 -314 38 69 -314 minecraft:grass_block[snowy=false]
fill 8 69 -315 20 69 -315 minecraft:dirt
setblock 21 69 -315 minecraft:netherrack
fill 22 69 -315 32 69 -315 minecraft:dirt
fill 33 69 -315 38 69 -315 minecraft:grass_block[snowy=false]
setblock 43 69 -315 minecraft:short_grass
setblock 48 69 -315 minecraft:birch_log[axis=y]
fill 8 69 -316 15 69 -316 minecraft:dirt
setblock 16 69 -316 minecraft:netherrack
fill 17 69 -316 32 69 -316 minecraft:dirt
fill 33 69 -316 38 69 -316 minecraft:grass_block[snowy=false]
fill 8 69 -317 20 69 -317 minecraft:dirt
setblock 21 69 -317 minecraft:netherrack
setblock 22 69 -317 minecraft:dirt
setblock 23 69 -317 minecraft:netherrack
fill 24 69 -317 32 69 -317 minecraft:dirt
fill 33 69 -317 35 69 -317 minecraft:grass_block[snowy=false]
setblock 36 69 -317 minecraft:dirt
setblock 37 69 -317 minecraft:grass_block[snowy=false]
setblock 39 69 -317 minecraft:short_grass
setblock 47 69 -317 minecraft:birch_log[axis=y]
setblock 51 69 -317 minecraft:birch_log[axis=y]
setblock 64 69 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 65 69 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 69 -318 17 69 -318 minecraft:dirt
setblock 18 69 -318 minecraft:netherrack
setblock 19 69 -318 minecraft:dirt
setblock 20 69 -318 minecraft:magma_block
fill 21 69 -318 23 69 -318 minecraft:dirt
setblock 24 69 -318 minecraft:netherrack
fill 25 69 -318 32 69 -318 minecraft:dirt
fill 33 69 -318 37 69 -318 minecraft:grass_block[snowy=false]
setblock 61 69 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 68 -255 19 68 -255 minecraft:stone
fill 20 68 -255 23 68 -255 alltheores:zinc_ore
fill 24 68 -255 26 68 -255 minecraft:stone
fill 8 68 -256 19 68 -256 minecraft:stone
fill 20 68 -256 21 68 -256 alltheores:zinc_ore
fill 22 68 -256 26 68 -256 minecraft:stone
fill 8 68 -257 25 68 -257 minecraft:stone
setblock 26 68 -257 alltheores:aluminum_ore
fill 8 68 -258 25 68 -258 minecraft:stone
setblock 26 68 -258 alltheores:aluminum_ore
fill 8 68 -259 26 68 -259 minecraft:stone
fill 8 68 -260 26 68 -260 minecraft:stone
fill 8 68 -261 26 68 -261 minecraft:stone
fill 8 68 -262 19 68 -262 minecraft:stone
fill 20 68 -262 21 68 -262 theurgy:sal_ammoniac_ore
fill 22 68 -262 26 68 -262 minecraft:stone
fill 8 68 -263 19 68 -263 minecraft:stone
fill 20 68 -263 21 68 -263 theurgy:sal_ammoniac_ore
fill 22 68 -263 26 68 -263 minecraft:stone
fill 8 68 -264 26 68 -264 minecraft:stone
fill 8 68 -265 26 68 -265 minecraft:stone
fill 8 68 -266 24 68 -266 minecraft:stone
setblock 25 68 -266 minecraft:dirt
setblock 26 68 -266 minecraft:stone
fill 8 68 -267 24 68 -267 minecraft:stone
setblock 25 68 -267 minecraft:dirt
setblock 26 68 -267 minecraft:stone
fill 8 68 -268 24 68 -268 minecraft:stone
fill 25 68 -268 26 68 -268 minecraft:dirt
fill 8 68 -269 24 68 -269 minecraft:stone
fill 25 68 -269 26 68 -269 minecraft:dirt
fill 8 68 -270 24 68 -270 minecraft:stone
fill 25 68 -270 26 68 -270 minecraft:dirt
fill 8 68 -271 25 68 -271 minecraft:stone
setblock 26 68 -271 minecraft:dirt
fill 8 68 -272 25 68 -272 minecraft:stone
setblock 26 68 -272 minecraft:dirt
fill 8 68 -273 25 68 -273 minecraft:stone
setblock 26 68 -273 minecraft:dirt
fill 8 68 -274 25 68 -274 minecraft:stone
setblock 26 68 -274 minecraft:dirt
fill 8 68 -275 25 68 -275 minecraft:stone
setblock 26 68 -275 minecraft:dirt
fill 8 68 -276 25 68 -276 minecraft:stone
setblock 26 68 -276 minecraft:dirt
setblock 8 68 -277 minecraft:dirt
fill 9 68 -277 24 68 -277 minecraft:stone
fill 25 68 -277 26 68 -277 minecraft:dirt
setblock 8 68 -278 minecraft:dirt
fill 9 68 -278 12 68 -278 minecraft:stone
fill 13 68 -278 14 68 -278 alltheores:zinc_ore
fill 15 68 -278 24 68 -278 minecraft:stone
fill 25 68 -278 26 68 -278 minecraft:dirt
setblock 8 68 -279 minecraft:dirt
fill 9 68 -279 12 68 -279 minecraft:stone
fill 13 68 -279 14 68 -279 alltheores:zinc_ore
fill 15 68 -279 23 68 -279 minecraft:stone
fill 24 68 -279 26 68 -279 minecraft:dirt
setblock 8 68 -280 minecraft:dirt
fill 9 68 -280 12 68 -280 minecraft:stone
fill 13 68 -280 14 68 -280 alltheores:zinc_ore
fill 15 68 -280 21 68 -280 minecraft:stone
setblock 22 68 -280 minecraft:dirt
setblock 23 68 -280 minecraft:stone
fill 24 68 -280 26 68 -280 minecraft:dirt
fill 8 68 -281 12 68 -281 minecraft:stone
fill 13 68 -281 14 68 -281 alltheores:zinc_ore
fill 15 68 -281 20 68 -281 minecraft:stone
fill 21 68 -281 26 68 -281 minecraft:dirt
fill 8 68 -282 20 68 -282 minecraft:stone
fill 21 68 -282 26 68 -282 minecraft:dirt
fill 8 68 -283 20 68 -283 minecraft:stone
fill 21 68 -283 43 68 -283 minecraft:dirt
fill 44 68 -283 51 68 -283 railcraft:quarried_stone
fill 8 68 -284 11 68 -284 minecraft:stone
setblock 12 68 -284 minecraft:dirt
fill 13 68 -284 19 68 -284 minecraft:stone
fill 20 68 -284 25 68 -284 minecraft:dirt
fill 26 68 -284 29 68 -284 minecraft:grass_block[snowy=false]
fill 30 68 -284 44 68 -284 minecraft:dirt
fill 45 68 -284 55 68 -284 railcraft:quarried_stone
fill 56 68 -284 58 68 -284 minecraft:dirt
fill 59 68 -284 68 68 -284 minecraft:grass_block[snowy=false]
fill 8 68 -285 9 68 -285 minecraft:coal_ore
fill 10 68 -285 18 68 -285 minecraft:stone
fill 19 68 -285 22 68 -285 minecraft:dirt
fill 30 68 -285 32 68 -285 minecraft:grass_block[snowy=false]
fill 33 68 -285 46 68 -285 minecraft:dirt
fill 47 68 -285 53 68 -285 railcraft:quarried_stone
fill 54 68 -285 59 68 -285 minecraft:dirt
fill 60 68 -285 68 68 -285 minecraft:grass_block[snowy=false]
fill 8 68 -286 9 68 -286 minecraft:coal_ore
fill 10 68 -286 17 68 -286 minecraft:stone
fill 18 68 -286 20 68 -286 minecraft:dirt
fill 31 68 -286 33 68 -286 minecraft:grass_block[snowy=false]
fill 34 68 -286 49 68 -286 minecraft:dirt
setblock 50 68 -286 railcraft:quarried_stone
fill 51 68 -286 61 68 -286 minecraft:dirt
fill 62 68 -286 68 68 -286 minecraft:grass_block[snowy=false]
fill 8 68 -287 10 68 -287 minecraft:coal_ore
fill 11 68 -287 16 68 -287 minecraft:stone
fill 17 68 -287 20 68 -287 minecraft:dirt
fill 31 68 -287 33 68 -287 minecraft:grass_block[snowy=false]
fill 34 68 -287 62 68 -287 minecraft:dirt
fill 63 68 -287 68 68 -287 minecraft:grass_block[snowy=false]
fill 8 68 -288 15 68 -288 minecraft:stone
fill 16 68 -288 19 68 -288 minecraft:dirt
setblock 30 68 -288 minecraft:birch_log[axis=y]
fill 31 68 -288 33 68 -288 minecraft:grass_block[snowy=false]
fill 34 68 -288 63 68 -288 minecraft:dirt
fill 64 68 -288 68 68 -288 minecraft:grass_block[snowy=false]
fill 8 68 -289 15 68 -289 minecraft:stone
fill 16 68 -289 18 68 -289 minecraft:dirt
fill 31 68 -289 32 68 -289 minecraft:grass_block[snowy=false]
fill 33 68 -289 63 68 -289 minecraft:dirt
fill 64 68 -289 68 68 -289 minecraft:grass_block[snowy=false]
fill 8 68 -290 14 68 -290 minecraft:stone
fill 15 68 -290 18 68 -290 minecraft:dirt
fill 30 68 -290 31 68 -290 minecraft:grass_block[snowy=false]
fill 32 68 -290 62 68 -290 minecraft:dirt
fill 63 68 -290 68 68 -290 minecraft:grass_block[snowy=false]
fill 8 68 -291 14 68 -291 minecraft:stone
fill 15 68 -291 19 68 -291 minecraft:dirt
fill 29 68 -291 30 68 -291 minecraft:grass_block[snowy=false]
fill 31 68 -291 62 68 -291 minecraft:dirt
fill 63 68 -291 68 68 -291 minecraft:grass_block[snowy=false]
fill 8 68 -292 13 68 -292 minecraft:stone
fill 14 68 -292 19 68 -292 minecraft:dirt
fill 28 68 -292 62 68 -292 minecraft:dirt
fill 63 68 -292 68 68 -292 minecraft:grass_block[snowy=false]
fill 8 68 -293 12 68 -293 minecraft:stone
fill 13 68 -293 20 68 -293 minecraft:dirt
fill 26 68 -293 38 68 -293 minecraft:dirt
setblock 39 68 -293 minecraft:grass_block[snowy=false]
fill 40 68 -293 60 68 -293 minecraft:dirt
fill 61 68 -293 66 68 -293 minecraft:grass_block[snowy=false]
setblock 67 68 -293 minecraft:dirt
setblock 68 68 -293 minecraft:grass_block[snowy=false]
fill 8 68 -294 11 68 -294 minecraft:stone
fill 12 68 -294 37 68 -294 minecraft:dirt
fill 41 68 -294 51 68 -294 minecraft:dirt
fill 52 68 -294 55 68 -294 minecraft:grass_block[snowy=false]
setblock 56 68 -294 minecraft:dirt
fill 57 68 -294 67 68 -294 minecraft:grass_block[snowy=false]
setblock 8 68 -295 minecraft:stone
fill 9 68 -295 36 68 -295 minecraft:dirt
fill 42 68 -295 48 68 -295 minecraft:dirt
fill 49 68 -295 61 68 -295 minecraft:grass_block[snowy=false]
setblock 62 68 -295 minecraft:dirt
fill 63 68 -295 66 68 -295 minecraft:grass_block[snowy=false]
setblock 8 68 -296 minecraft:stone
fill 9 68 -296 36 68 -296 minecraft:dirt
fill 41 68 -296 46 68 -296 minecraft:dirt
fill 47 68 -296 65 68 -296 minecraft:grass_block[snowy=false]
setblock 68 68 -296 minecraft:birch_log[axis=y]
fill 8 68 -297 36 68 -297 minecraft:dirt
fill 41 68 -297 46 68 -297 minecraft:dirt
fill 47 68 -297 63 68 -297 minecraft:grass_block[snowy=false]
fill 8 68 -298 37 68 -298 minecraft:dirt
fill 40 68 -298 45 68 -298 minecraft:dirt
fill 46 68 -298 48 68 -298 minecraft:grass_block[snowy=false]
setblock 49 68 -298 minecraft:dirt
fill 50 68 -298 60 68 -298 minecraft:grass_block[snowy=false]
fill 8 68 -299 46 68 -299 minecraft:dirt
fill 47 68 -299 57 68 -299 minecraft:grass_block[snowy=false]
setblock 58 68 -299 minecraft:dirt
fill 8 68 -300 44 68 -300 minecraft:dirt
fill 45 68 -300 56 68 -300 minecraft:grass_block[snowy=false]
fill 8 68 -301 44 68 -301 minecraft:dirt
fill 45 68 -301 54 68 -301 minecraft:grass_block[snowy=false]
setblock 56 68 -301 minecraft:birch_log[axis=y]
setblock 59 68 -301 minecraft:birch_log[axis=y]
fill 8 68 -302 43 68 -302 minecraft:dirt
fill 44 68 -302 52 68 -302 minecraft:grass_block[snowy=false]
fill 8 68 -303 43 68 -303 minecraft:dirt
fill 44 68 -303 51 68 -303 minecraft:grass_block[snowy=false]
setblock 70 68 -303 minecraft:birch_log[axis=y]
fill 8 68 -304 43 68 -304 minecraft:dirt
fill 44 68 -304 50 68 -304 minecraft:grass_block[snowy=false]
setblock 64 68 -304 minecraft:birch_log[axis=y]
fill 8 68 -305 41 68 -305 minecraft:dirt
fill 42 68 -305 49 68 -305 minecraft:grass_block[snowy=false]
fill 8 68 -306 33 68 -306 minecraft:dirt
fill 38 68 -306 40 68 -306 minecraft:dirt
fill 41 68 -306 48 68 -306 minecraft:grass_block[snowy=false]
setblock 49 68 -306 minecraft:birch_log[axis=y]
setblock 54 68 -306 regions_unexplored:grass_sprouts
fill 8 68 -307 16 68 -307 minecraft:dirt
fill 18 68 -307 32 68 -307 minecraft:dirt
setblock 37 68 -307 minecraft:grass_block[snowy=false]
fill 38 68 -307 39 68 -307 minecraft:dirt
fill 40 68 -307 47 68 -307 minecraft:grass_block[snowy=false]
setblock 50 68 -307 minecraft:short_grass
setblock 64 68 -307 minecraft:birch_log[axis=y]
fill 8 68 -308 15 68 -308 minecraft:dirt
fill 18 68 -308 32 68 -308 minecraft:dirt
setblock 37 68 -308 minecraft:grass_block[snowy=false]
fill 38 68 -308 39 68 -308 minecraft:dirt
fill 40 68 -308 45 68 -308 minecraft:grass_block[snowy=false]
setblock 46 68 -308 minecraft:dirt
setblock 47 68 -308 minecraft:short_grass
setblock 51 68 -308 regions_unexplored:grass_sprouts
setblock 55 68 -308 minecraft:birch_log[axis=y]
fill 8 68 -309 14 68 -309 minecraft:dirt
setblock 18 68 -309 minecraft:air
fill 19 68 -309 33 68 -309 minecraft:dirt
fill 34 68 -309 35 68 -309 minecraft:grass_block[snowy=false]
setblock 37 68 -309 minecraft:grass_block[snowy=false]
fill 38 68 -309 39 68 -309 minecraft:dirt
fill 40 68 -309 46 68 -309 minecraft:grass_block[snowy=false]
setblock 49 68 -309 minecraft:short_grass
setblock 62 68 -309 minecraft:birch_log[axis=y]
fill 8 68 -310 14 68 -310 minecraft:dirt
fill 19 68 -310 38 68 -310 minecraft:dirt
fill 39 68 -310 44 68 -310 minecraft:grass_block[snowy=false]
setblock 45 68 -310 minecraft:dirt
setblock 50 68 -310 minecraft:short_grass
setblock 51 68 -310 minecraft:birch_log[axis=y]
setblock 70 68 -310 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 68 -311 15 68 -311 minecraft:dirt
fill 20 68 -311 38 68 -311 minecraft:dirt
fill 39 68 -311 45 68 -311 minecraft:grass_block[snowy=false]
setblock 47 68 -311 minecraft:short_grass
setblock 48 68 -311 regions_unexplored:grass_sprouts
fill 8 68 -312 15 68 -312 minecraft:dirt
fill 22 68 -312 38 68 -312 minecraft:dirt
setblock 39 68 -312 minecraft:grass_block[snowy=false]
setblock 40 68 -312 minecraft:dirt
fill 41 68 -312 45 68 -312 minecraft:grass_block[snowy=false]
setblock 64 68 -312 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 68 -313 16 68 -313 minecraft:dirt
fill 23 68 -313 38 68 -313 minecraft:dirt
fill 39 68 -313 45 68 -313 minecraft:grass_block[snowy=false]
setblock 48 68 -313 minecraft:short_grass
setblock 53 68 -313 minecraft:birch_log[axis=y]
fill 8 68 -314 16 68 -314 minecraft:dirt
fill 23 68 -314 38 68 -314 minecraft:dirt
fill 39 68 -314 44 68 -314 minecraft:grass_block[snowy=false]
fill 8 68 -315 10 68 -315 minecraft:stone
fill 11 68 -315 18 68 -315 minecraft:dirt
fill 24 68 -315 38 68 -315 minecraft:dirt
fill 39 68 -315 44 68 -315 minecraft:grass_block[snowy=false]
setblock 48 68 -315 minecraft:birch_log[axis=y]
fill 55 68 -315 56 68 -315 regions_unexplored:meadow_sage[half=upper]
fill 8 68 -316 12 68 -316 minecraft:stone
fill 13 68 -316 20 68 -316 minecraft:dirt
fill 23 68 -316 38 68 -316 minecraft:dirt
fill 39 68 -316 44 68 -316 minecraft:grass_block[snowy=false]
setblock 54 68 -316 regions_unexplored:meadow_sage[half=upper]
setblock 65 68 -316 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 68 -317 13 68 -317 minecraft:stone
fill 14 68 -317 24 68 -317 minecraft:dirt
fill 31 68 -317 37 68 -317 minecraft:dirt
fill 38 68 -317 43 68 -317 minecraft:grass_block[snowy=false]
setblock 47 68 -317 minecraft:birch_log[axis=y]
setblock 51 68 -317 minecraft:birch_log[axis=y]
setblock 55 68 -317 regions_unexplored:meadow_sage[half=upper]
setblock 64 68 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 65 68 -317 regions_unexplored:silver_birch_branch[facing=east]
setblock 66 68 -317 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 68 -318 13 68 -318 minecraft:stone
fill 14 68 -318 17 68 -318 minecraft:dirt
setblock 18 68 -318 minecraft:netherrack
fill 19 68 -318 25 68 -318 minecraft:dirt
fill 31 68 -318 37 68 -318 minecraft:dirt
fill 38 68 -318 43 68 -318 minecraft:grass_block[snowy=false]
setblock 55 68 -318 regions_unexplored:meadow_sage[half=upper]
setblock 61 68 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 65 68 -318 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 67 -255 19 67 -255 minecraft:stone
fill 20 67 -255 22 67 -255 alltheores:zinc_ore
fill 23 67 -255 25 67 -255 minecraft:stone
setblock 26 67 -255 create:limestone
fill 8 67 -256 19 67 -256 minecraft:stone
setblock 20 67 -256 alltheores:zinc_ore
fill 21 67 -256 25 67 -256 minecraft:stone
setblock 26 67 -256 create:limestone
fill 8 67 -257 9 67 -257 minecraft:stone
fill 10 67 -257 11 67 -257 theurgy:sal_ammoniac_ore
fill 12 67 -257 26 67 -257 minecraft:stone
fill 8 67 -258 9 67 -258 minecraft:stone
fill 10 67 -258 12 67 -258 theurgy:sal_ammoniac_ore
fill 13 67 -258 26 67 -258 minecraft:stone
fill 8 67 -259 26 67 -259 minecraft:stone
fill 8 67 -260 26 67 -260 minecraft:stone
fill 8 67 -261 26 67 -261 minecraft:stone
fill 8 67 -262 19 67 -262 minecraft:stone
setblock 20 67 -262 theurgy:sal_ammoniac_ore
fill 21 67 -262 26 67 -262 minecraft:stone
fill 8 67 -263 26 67 -263 minecraft:stone
fill 8 67 -264 26 67 -264 minecraft:stone
fill 8 67 -265 26 67 -265 minecraft:stone
fill 8 67 -266 26 67 -266 minecraft:stone
fill 8 67 -267 26 67 -267 minecraft:stone
fill 8 67 -268 26 67 -268 minecraft:stone
fill 8 67 -269 26 67 -269 minecraft:stone
fill 8 67 -270 18 67 -270 minecraft:stone
fill 19 67 -270 22 67 -270 minecraft:gravel
fill 23 67 -270 25 67 -270 minecraft:stone
setblock 26 67 -270 alltheores:ruby_ore
fill 8 67 -271 18 67 -271 minecraft:stone
fill 19 67 -271 24 67 -271 minecraft:gravel
setblock 25 67 -271 minecraft:stone
setblock 26 67 -271 alltheores:ruby_ore
fill 8 67 -272 18 67 -272 minecraft:stone
fill 19 67 -272 25 67 -272 minecraft:gravel
setblock 26 67 -272 minecraft:stone
fill 8 67 -273 17 67 -273 minecraft:stone
fill 18 67 -273 19 67 -273 minecraft:iron_ore
setblock 20 67 -273 minecraft:stone
fill 21 67 -273 25 67 -273 minecraft:gravel
setblock 26 67 -273 minecraft:stone
fill 8 67 -274 17 67 -274 minecraft:stone
fill 18 67 -274 19 67 -274 minecraft:iron_ore
fill 20 67 -274 26 67 -274 minecraft:stone
fill 8 67 -275 26 67 -275 minecraft:stone
fill 8 67 -276 26 67 -276 minecraft:stone
fill 8 67 -277 26 67 -277 minecraft:stone
fill 8 67 -278 12 67 -278 minecraft:stone
fill 13 67 -278 14 67 -278 alltheores:zinc_ore
fill 15 67 -278 26 67 -278 minecraft:stone
fill 8 67 -279 12 67 -279 minecraft:stone
fill 13 67 -279 14 67 -279 alltheores:zinc_ore
fill 15 67 -279 26 67 -279 minecraft:stone
fill 8 67 -280 12 67 -280 minecraft:stone
fill 13 67 -280 14 67 -280 alltheores:zinc_ore
fill 15 67 -280 24 67 -280 minecraft:stone
fill 25 67 -280 26 67 -280 minecraft:dirt
fill 8 67 -281 9 67 -281 minecraft:coal_ore
fill 10 67 -281 12 67 -281 minecraft:stone
fill 13 67 -281 14 67 -281 alltheores:zinc_ore
fill 15 67 -281 23 67 -281 minecraft:stone
fill 24 67 -281 26 67 -281 minecraft:dirt
fill 8 67 -282 9 67 -282 minecraft:coal_ore
fill 10 67 -282 23 67 -282 minecraft:stone
fill 24 67 -282 26 67 -282 minecraft:dirt
fill 8 67 -283 9 67 -283 minecraft:coal_ore
fill 10 67 -283 23 67 -283 minecraft:stone
fill 24 67 -283 43 67 -283 minecraft:dirt
fill 44 67 -283 51 67 -283 railcraft:quarried_stone
fill 8 67 -284 9 67 -284 minecraft:coal_ore
fill 10 67 -284 23 67 -284 minecraft:stone
fill 24 67 -284 44 67 -284 minecraft:dirt
fill 45 67 -284 55 67 -284 railcraft:quarried_stone
fill 56 67 -284 68 67 -284 minecraft:dirt
setblock 9 67 -285 minecraft:coal_ore
fill 10 67 -285 23 67 -285 minecraft:stone
fill 26 67 -285 29 67 -285 minecraft:grass_block[snowy=false]
fill 30 67 -285 46 67 -285 minecraft:dirt
fill 47 67 -285 53 67 -285 railcraft:quarried_stone
fill 54 67 -285 68 67 -285 minecraft:dirt
setblock 9 67 -286 minecraft:coal_ore
fill 10 67 -286 20 67 -286 minecraft:stone
fill 28 67 -286 30 67 -286 minecraft:grass_block[snowy=false]
fill 31 67 -286 68 67 -286 minecraft:dirt
fill 8 67 -287 10 67 -287 minecraft:coal_ore
fill 11 67 -287 19 67 -287 minecraft:stone
fill 29 67 -287 30 67 -287 minecraft:grass_block[snowy=false]
fill 31 67 -287 68 67 -287 minecraft:dirt
fill 8 67 -288 18 67 -288 minecraft:stone
setblock 29 67 -288 minecraft:grass_block[snowy=false]
fill 30 67 -288 68 67 -288 minecraft:dirt
fill 8 67 -289 18 67 -289 minecraft:stone
fill 29 67 -289 30 67 -289 minecraft:grass_block[snowy=false]
fill 31 67 -289 68 67 -289 minecraft:dirt
fill 8 67 -290 18 67 -290 minecraft:stone
setblock 29 67 -290 minecraft:grass_block[snowy=false]
fill 30 67 -290 68 67 -290 minecraft:dirt
fill 8 67 -291 18 67 -291 minecraft:stone
setblock 28 67 -291 minecraft:grass_block[snowy=false]
fill 29 67 -291 68 67 -291 minecraft:dirt
fill 8 67 -292 18 67 -292 minecraft:stone
setblock 27 67 -292 minecraft:grass_block[snowy=false]
fill 28 67 -292 68 67 -292 minecraft:dirt
fill 8 67 -293 18 67 -293 minecraft:stone
fill 26 67 -293 68 67 -293 minecraft:dirt
fill 8 67 -294 17 67 -294 minecraft:stone
fill 18 67 -294 20 67 -294 minecraft:dirt
fill 24 67 -294 37 67 -294 minecraft:dirt
setblock 40 67 -294 minecraft:grass_block[snowy=false]
fill 41 67 -294 67 67 -294 minecraft:dirt
fill 68 67 -294 71 67 -294 minecraft:grass_block[snowy=false]
fill 8 67 -295 16 67 -295 minecraft:stone
fill 17 67 -295 36 67 -295 minecraft:dirt
setblock 41 67 -295 minecraft:grass_block[snowy=false]
fill 42 67 -295 66 67 -295 minecraft:dirt
fill 67 67 -295 71 67 -295 minecraft:grass_block[snowy=false]
fill 8 67 -296 15 67 -296 minecraft:stone
fill 16 67 -296 36 67 -296 minecraft:dirt
fill 41 67 -296 65 67 -296 minecraft:dirt
fill 66 67 -296 67 67 -296 minecraft:grass_block[snowy=false]
setblock 68 67 -296 minecraft:birch_log[axis=y]
fill 69 67 -296 71 67 -296 minecraft:grass_block[snowy=false]
fill 8 67 -297 14 67 -297 minecraft:stone
fill 15 67 -297 36 67 -297 minecraft:dirt
fill 41 67 -297 63 67 -297 minecraft:dirt
fill 64 67 -297 66 67 -297 minecraft:grass_block[snowy=false]
fill 8 67 -298 14 67 -298 minecraft:stone
fill 15 67 -298 35 67 -298 minecraft:dirt
fill 41 67 -298 60 67 -298 minecraft:dirt
fill 61 67 -298 64 67 -298 minecraft:grass_block[snowy=false]
fill 8 67 -299 13 67 -299 minecraft:stone
fill 14 67 -299 36 67 -299 minecraft:dirt
fill 40 67 -299 58 67 -299 minecraft:dirt
fill 59 67 -299 62 67 -299 minecraft:grass_block[snowy=false]
fill 8 67 -300 12 67 -300 minecraft:stone
fill 13 67 -300 56 67 -300 minecraft:dirt
fill 57 67 -300 61 67 -300 minecraft:grass_block[snowy=false]
fill 8 67 -301 12 67 -301 minecraft:stone
fill 13 67 -301 54 67 -301 minecraft:dirt
setblock 55 67 -301 minecraft:grass_block[snowy=false]
setblock 56 67 -301 minecraft:dirt
fill 57 67 -301 58 67 -301 minecraft:grass_block[snowy=false]
setblock 59 67 -301 minecraft:dirt
setblock 60 67 -301 minecraft:grass_block[snowy=false]
fill 8 67 -302 12 67 -302 minecraft:stone
fill 13 67 -302 52 67 -302 minecraft:dirt
fill 53 67 -302 58 67 -302 minecraft:grass_block[snowy=false]
fill 8 67 -303 12 67 -303 minecraft:stone
fill 13 67 -303 51 67 -303 minecraft:dirt
fill 52 67 -303 57 67 -303 minecraft:grass_block[snowy=false]
setblock 70 67 -303 minecraft:birch_log[axis=y]
fill 8 67 -304 12 67 -304 minecraft:stone
fill 13 67 -304 17 67 -304 minecraft:dirt
fill 22 67 -304 50 67 -304 minecraft:dirt
fill 51 67 -304 56 67 -304 minecraft:grass_block[snowy=false]
setblock 64 67 -304 minecraft:birch_log[axis=y]
fill 8 67 -305 12 67 -305 minecraft:stone
fill 13 67 -305 15 67 -305 minecraft:dirt
fill 22 67 -305 49 67 -305 minecraft:dirt
fill 50 67 -305 56 67 -305 minecraft:grass_block[snowy=false]
fill 8 67 -306 12 67 -306 minecraft:stone
fill 13 67 -306 14 67 -306 minecraft:dirt
fill 22 67 -306 32 67 -306 minecraft:dirt
setblock 37 67 -306 minecraft:grass_block[snowy=false]
fill 38 67 -306 49 67 -306 minecraft:dirt
fill 50 67 -306 55 67 -306 minecraft:grass_block[snowy=false]
fill 8 67 -307 12 67 -307 minecraft:stone
fill 13 67 -307 14 67 -307 minecraft:dirt
fill 20 67 -307 32 67 -307 minecraft:dirt
fill 37 67 -307 47 67 -307 minecraft:dirt
fill 48 67 -307 53 67 -307 minecraft:grass_block[snowy=false]
setblock 64 67 -307 minecraft:birch_log[axis=y]
fill 8 67 -308 12 67 -308 minecraft:stone
fill 13 67 -308 14 67 -308 minecraft:dirt
fill 20 67 -308 32 67 -308 minecraft:dirt
fill 37 67 -308 46 67 -308 minecraft:dirt
fill 47 67 -308 52 67 -308 minecraft:grass_block[snowy=false]
setblock 55 67 -308 minecraft:birch_log[axis=y]
fill 8 67 -309 12 67 -309 minecraft:stone
setblock 13 67 -309 minecraft:dirt
setblock 18 67 -309 minecraft:air
fill 20 67 -309 35 67 -309 minecraft:dirt
setblock 36 67 -309 minecraft:grass_block[snowy=false]
fill 37 67 -309 46 67 -309 minecraft:dirt
fill 47 67 -309 51 67 -309 minecraft:grass_block[snowy=false]
setblock 55 67 -309 regions_unexplored:grass_sprouts
setblock 62 67 -309 minecraft:birch_log[axis=y]
fill 8 67 -310 13 67 -310 minecraft:stone
fill 21 67 -310 45 67 -310 minecraft:dirt
fill 46 67 -310 50 67 -310 minecraft:grass_block[snowy=false]
setblock 51 67 -310 minecraft:dirt
setblock 62 67 -310 regions_unexplored:meadow_sage[half=upper]
setblock 70 67 -310 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 67 -311 13 67 -311 minecraft:stone
setblock 14 67 -311 minecraft:dirt
fill 21 67 -311 45 67 -311 minecraft:dirt
fill 46 67 -311 51 67 -311 minecraft:grass_block[snowy=false]
fill 8 67 -312 14 67 -312 minecraft:stone
fill 23 67 -312 45 67 -312 minecraft:dirt
fill 46 67 -312 51 67 -312 minecraft:grass_block[snowy=false]
setblock 60 67 -312 regions_unexplored:meadow_sage[half=upper]
setblock 64 67 -312 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 67 -313 13 67 -313 minecraft:stone
fill 14 67 -313 15 67 -313 minecraft:dirt
fill 24 67 -313 45 67 -313 minecraft:dirt
fill 46 67 -313 50 67 -313 minecraft:grass_block[snowy=false]
setblock 53 67 -313 minecraft:birch_log[axis=y]
fill 8 67 -314 13 67 -314 minecraft:stone
fill 14 67 -314 15 67 -314 minecraft:dirt
fill 25 67 -314 44 67 -314 minecraft:dirt
fill 45 67 -314 50 67 -314 minecraft:grass_block[snowy=false]
setblock 61 67 -314 regions_unexplored:meadow_sage[half=upper]
fill 8 67 -315 13 67 -315 minecraft:stone
fill 14 67 -315 16 67 -315 minecraft:dirt
fill 27 67 -315 29 67 -315 minecraft:dirt
fill 33 67 -315 44 67 -315 minecraft:dirt
fill 45 67 -315 47 67 -315 minecraft:grass_block[snowy=false]
setblock 48 67 -315 minecraft:dirt
fill 49 67 -315 50 67 -315 minecraft:grass_block[snowy=false]
fill 55 67 -315 56 67 -315 regions_unexplored:meadow_sage[half=lower]
setblock 57 67 -315 regions_unexplored:meadow_sage[half=upper]
fill 8 67 -316 12 67 -316 minecraft:stone
fill 13 67 -316 18 67 -316 minecraft:dirt
fill 34 67 -316 44 67 -316 minecraft:dirt
fill 45 67 -316 50 67 -316 minecraft:grass_block[snowy=false]
setblock 54 67 -316 regions_unexplored:meadow_sage[half=lower]
setblock 61 67 -316 regions_unexplored:meadow_sage[half=upper]
fill 8 67 -317 14 67 -317 minecraft:stone
fill 15 67 -317 19 67 -317 minecraft:dirt
fill 34 67 -317 43 67 -317 minecraft:dirt
fill 44 67 -317 46 67 -317 minecraft:grass_block[snowy=false]
setblock 47 67 -317 minecraft:dirt
fill 48 67 -317 49 67 -317 minecraft:grass_block[snowy=false]
setblock 51 67 -317 minecraft:birch_log[axis=y]
setblock 55 67 -317 regions_unexplored:meadow_sage[half=lower]
setblock 58 67 -317 regions_unexplored:meadow_sage[half=upper]
setblock 64 67 -317 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 8 67 -318 minecraft:coal_ore
fill 9 67 -318 19 67 -318 minecraft:stone
fill 20 67 -318 22 67 -318 minecraft:dirt
fill 33 67 -318 43 67 -318 minecraft:dirt
fill 44 67 -318 49 67 -318 minecraft:grass_block[snowy=false]
setblock 55 67 -318 regions_unexplored:meadow_sage[half=lower]
setblock 57 67 -318 regions_unexplored:meadow_sage[half=upper]
setblock 61 67 -318 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 66 -255 24 66 -255 minecraft:stone
setblock 25 66 -255 minecraft:calcite
setblock 26 66 -255 create:limestone
fill 8 66 -256 25 66 -256 minecraft:stone
setblock 26 66 -256 create:limestone
fill 8 66 -257 25 66 -257 minecraft:stone
setblock 26 66 -257 create:limestone
fill 8 66 -258 12 66 -258 minecraft:coal_ore
fill 13 66 -258 26 66 -258 minecraft:stone
fill 8 66 -259 11 66 -259 minecraft:coal_ore
fill 12 66 -259 26 66 -259 minecraft:stone
fill 8 66 -260 26 66 -260 minecraft:stone
fill 8 66 -261 26 66 -261 minecraft:stone
fill 8 66 -262 26 66 -262 minecraft:stone
fill 8 66 -263 26 66 -263 minecraft:stone
fill 8 66 -264 26 66 -264 minecraft:stone
fill 8 66 -265 26 66 -265 minecraft:stone
fill 8 66 -266 26 66 -266 minecraft:stone
fill 8 66 -267 26 66 -267 minecraft:stone
fill 8 66 -268 26 66 -268 minecraft:stone
fill 8 66 -269 19 66 -269 minecraft:stone
setblock 20 66 -269 minecraft:gravel
fill 21 66 -269 26 66 -269 minecraft:stone
fill 8 66 -270 16 66 -270 minecraft:stone
fill 17 66 -270 24 66 -270 minecraft:gravel
fill 25 66 -270 26 66 -270 minecraft:stone
fill 8 66 -271 17 66 -271 minecraft:stone
fill 18 66 -271 25 66 -271 minecraft:gravel
setblock 26 66 -271 minecraft:stone
fill 8 66 -272 18 66 -272 minecraft:stone
fill 19 66 -272 26 66 -272 minecraft:gravel
fill 8 66 -273 18 66 -273 minecraft:stone
fill 19 66 -273 26 66 -273 minecraft:gravel
fill 8 66 -274 22 66 -274 minecraft:stone
setblock 23 66 -274 minecraft:gravel
setblock 24 66 -274 minecraft:stone
setblock 25 66 -274 minecraft:gravel
setblock 26 66 -274 minecraft:stone
fill 8 66 -275 26 66 -275 minecraft:stone
fill 8 66 -276 26 66 -276 minecraft:stone
fill 8 66 -277 26 66 -277 minecraft:stone
fill 8 66 -278 26 66 -278 minecraft:stone
fill 8 66 -279 26 66 -279 minecraft:stone
fill 8 66 -280 9 66 -280 minecraft:coal_ore
fill 10 66 -280 26 66 -280 minecraft:stone
fill 8 66 -281 9 66 -281 minecraft:coal_ore
fill 10 66 -281 22 66 -281 minecraft:stone
setblock 23 66 -281 alltheores:cinnabar_ore
fill 24 66 -281 26 66 -281 minecraft:stone
fill 8 66 -282 9 66 -282 minecraft:coal_ore
fill 10 66 -282 26 66 -282 minecraft:stone
setblock 9 66 -283 minecraft:coal_ore
fill 10 66 -283 26 66 -283 minecraft:stone
fill 27 66 -283 30 66 -283 minecraft:dirt
setblock 31 66 -283 minecraft:stone
fill 32 66 -283 33 66 -283 minecraft:gravel
fill 34 66 -283 36 66 -283 minecraft:stone
fill 37 66 -283 43 66 -283 minecraft:dirt
setblock 44 66 -283 minecraft:stone
fill 45 66 -283 51 66 -283 railcraft:quarried_stone
setblock 9 66 -284 minecraft:coal_ore
fill 10 66 -284 25 66 -284 minecraft:stone
fill 26 66 -284 33 66 -284 minecraft:dirt
fill 34 66 -284 36 66 -284 minecraft:stone
fill 37 66 -284 42 66 -284 minecraft:dirt
fill 43 66 -284 45 66 -284 minecraft:stone
fill 46 66 -284 54 66 -284 railcraft:quarried_stone
setblock 55 66 -284 minecraft:stone
setblock 56 66 -284 minecraft:dirt
fill 57 66 -284 58 66 -284 minecraft:stone
fill 59 66 -284 66 66 -284 minecraft:dirt
fill 67 66 -284 68 66 -284 minecraft:stone
fill 9 66 -285 25 66 -285 minecraft:stone
fill 26 66 -285 33 66 -285 minecraft:dirt
setblock 34 66 -285 minecraft:stone
fill 35 66 -285 45 66 -285 minecraft:dirt
setblock 46 66 -285 minecraft:stone
fill 47 66 -285 53 66 -285 railcraft:quarried_stone
fill 54 66 -285 56 66 -285 minecraft:dirt
fill 57 66 -285 59 66 -285 minecraft:stone
fill 60 66 -285 67 66 -285 minecraft:dirt
setblock 68 66 -285 minecraft:stone
fill 9 66 -286 21 66 -286 minecraft:stone
fill 25 66 -286 26 66 -286 minecraft:stone
setblock 27 66 -286 minecraft:grass_block[snowy=false]
fill 28 66 -286 34 66 -286 minecraft:dirt
setblock 35 66 -286 minecraft:stone
fill 36 66 -286 44 66 -286 minecraft:dirt
fill 45 66 -286 52 66 -286 minecraft:stone
fill 53 66 -286 56 66 -286 minecraft:dirt
fill 57 66 -286 61 66 -286 minecraft:stone
fill 62 66 -286 68 66 -286 minecraft:dirt
fill 9 66 -287 19 66 -287 minecraft:stone
setblock 27 66 -287 minecraft:stone
setblock 28 66 -287 minecraft:grass_block[snowy=false]
fill 29 66 -287 34 66 -287 minecraft:dirt
setblock 35 66 -287 minecraft:stone
fill 36 66 -287 45 66 -287 minecraft:dirt
fill 46 66 -287 50 66 -287 minecraft:stone
fill 51 66 -287 56 66 -287 minecraft:dirt
fill 57 66 -287 62 66 -287 minecraft:stone
fill 63 66 -287 68 66 -287 minecraft:dirt
fill 8 66 -288 18 66 -288 minecraft:stone
setblock 27 66 -288 minecraft:stone
setblock 28 66 -288 minecraft:grass_block[snowy=false]
fill 29 66 -288 57 66 -288 minecraft:dirt
fill 58 66 -288 63 66 -288 minecraft:stone
fill 64 66 -288 68 66 -288 minecraft:dirt
fill 8 66 -289 17 66 -289 minecraft:stone
setblock 18 66 -289 minecraft:air
setblock 28 66 -289 minecraft:grass_block[snowy=false]
fill 29 66 -289 57 66 -289 minecraft:dirt
setblock 58 66 -289 minecraft:stone
setblock 59 66 -289 minecraft:dirt
fill 60 66 -289 63 66 -289 minecraft:stone
fill 64 66 -289 68 66 -289 minecraft:dirt
fill 8 66 -290 15 66 -290 minecraft:stone
setblock 16 66 -290 evilcraft:dark_ore[glowing=false]
setblock 17 66 -290 minecraft:stone
fill 27 66 -290 28 66 -290 minecraft:grass_block[snowy=false]
fill 29 66 -290 60 66 -290 minecraft:dirt
fill 61 66 -290 62 66 -290 minecraft:stone
fill 63 66 -290 68 66 -290 minecraft:dirt
fill 8 66 -291 17 66 -291 minecraft:stone
setblock 27 66 -291 minecraft:grass_block[snowy=false]
fill 28 66 -291 61 66 -291 minecraft:dirt
setblock 62 66 -291 minecraft:stone
fill 63 66 -291 68 66 -291 minecraft:dirt
fill 8 66 -292 16 66 -292 minecraft:stone
fill 27 66 -292 68 66 -292 minecraft:dirt
fill 8 66 -293 16 66 -293 minecraft:stone
setblock 26 66 -293 minecraft:stone
fill 27 66 -293 68 66 -293 minecraft:dirt
fill 8 66 -294 17 66 -294 minecraft:stone
setblock 25 66 -294 minecraft:stone
fill 26 66 -294 37 66 -294 minecraft:dirt
fill 38 66 -294 39 66 -294 minecraft:grass_block[snowy=false]
fill 40 66 -294 71 66 -294 minecraft:dirt
fill 8 66 -295 20 66 -295 minecraft:stone
fill 22 66 -295 24 66 -295 minecraft:stone
fill 25 66 -295 36 66 -295 minecraft:dirt
setblock 37 66 -295 minecraft:grass_block[snowy=false]
setblock 40 66 -295 minecraft:grass_block[snowy=false]
fill 41 66 -295 71 66 -295 minecraft:dirt
fill 8 66 -296 24 66 -296 minecraft:stone
fill 25 66 -296 36 66 -296 minecraft:dirt
fill 41 66 -296 71 66 -296 minecraft:dirt
fill 8 66 -297 23 66 -297 minecraft:stone
fill 24 66 -297 35 66 -297 minecraft:dirt
fill 41 66 -297 66 66 -297 minecraft:dirt
setblock 67 66 -297 minecraft:grass_block[snowy=false]
fill 69 66 -297 71 66 -297 minecraft:grass_block[snowy=false]
fill 8 66 -298 22 66 -298 minecraft:stone
fill 23 66 -298 34 66 -298 minecraft:dirt
fill 41 66 -298 64 66 -298 minecraft:dirt
fill 65 66 -298 66 66 -298 minecraft:grass_block[snowy=false]
setblock 71 66 -298 minecraft:grass_block[snowy=false]
fill 8 66 -299 22 66 -299 minecraft:stone
fill 23 66 -299 34 66 -299 minecraft:dirt
fill 40 66 -299 62 66 -299 minecraft:dirt
fill 63 66 -299 64 66 -299 minecraft:grass_block[snowy=false]
fill 8 66 -300 21 66 -300 minecraft:stone
fill 22 66 -300 34 66 -300 minecraft:dirt
fill 38 66 -300 61 66 -300 minecraft:dirt
fill 62 66 -300 63 66 -300 minecraft:grass_block[snowy=false]
fill 8 66 -301 21 66 -301 minecraft:stone
fill 22 66 -301 60 66 -301 minecraft:dirt
fill 61 66 -301 62 66 -301 minecraft:grass_block[snowy=false]
fill 8 66 -302 21 66 -302 minecraft:stone
fill 22 66 -302 58 66 -302 minecraft:dirt
fill 59 66 -302 61 66 -302 minecraft:grass_block[snowy=false]
fill 8 66 -303 18 66 -303 minecraft:stone
fill 25 66 -303 57 66 -303 minecraft:dirt
fill 58 66 -303 60 66 -303 minecraft:grass_block[snowy=false]
setblock 70 66 -303 minecraft:birch_log[axis=y]
fill 8 66 -304 15 66 -304 minecraft:stone
fill 26 66 -304 56 66 -304 minecraft:dirt
fill 57 66 -304 59 66 -304 minecraft:grass_block[snowy=false]
setblock 64 66 -304 minecraft:birch_log[axis=y]
fill 8 66 -305 14 66 -305 minecraft:stone
fill 26 66 -305 32 66 -305 minecraft:dirt
fill 36 66 -305 56 66 -305 minecraft:dirt
fill 57 66 -305 59 66 -305 minecraft:grass_block[snowy=false]
fill 8 66 -306 14 66 -306 minecraft:stone
fill 24 66 -306 31 66 -306 minecraft:dirt
fill 37 66 -306 55 66 -306 minecraft:dirt
fill 56 66 -306 60 66 -306 minecraft:grass_block[snowy=false]
fill 8 66 -307 12 66 -307 minecraft:stone
setblock 13 66 -307 minecraft:lava[level=0]
setblock 14 66 -307 minecraft:lava[level=2]
fill 22 66 -307 23 66 -307 minecraft:stone
fill 24 66 -307 31 66 -307 minecraft:dirt
setblock 36 66 -307 minecraft:grass_block[snowy=false]
fill 37 66 -307 53 66 -307 minecraft:dirt
fill 54 66 -307 60 66 -307 minecraft:grass_block[snowy=false]
setblock 64 66 -307 minecraft:birch_log[axis=y]
fill 8 66 -308 13 66 -308 minecraft:stone
fill 20 66 -308 23 66 -308 minecraft:stone
fill 24 66 -308 31 66 -308 minecraft:dirt
setblock 36 66 -308 minecraft:grass_block[snowy=false]
fill 37 66 -308 52 66 -308 minecraft:dirt
fill 53 66 -308 54 66 -308 minecraft:grass_block[snowy=false]
setblock 55 66 -308 minecraft:dirt
fill 56 66 -308 61 66 -308 minecraft:grass_block[snowy=false]
fill 8 66 -309 13 66 -309 minecraft:stone
setblock 18 66 -309 minecraft:air
fill 20 66 -309 22 66 -309 minecraft:stone
fill 23 66 -309 51 66 -309 minecraft:dirt
fill 52 66 -309 60 66 -309 minecraft:grass_block[snowy=false]
setblock 61 66 -309 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 62 66 -309 minecraft:birch_log[axis=y]
fill 8 66 -310 13 66 -310 minecraft:stone
setblock 21 66 -310 minecraft:stone
fill 22 66 -310 51 66 -310 minecraft:dirt
fill 52 66 -310 59 66 -310 minecraft:grass_block[snowy=false]
setblock 61 66 -310 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 62 66 -310 regions_unexplored:meadow_sage[half=lower]
setblock 63 66 -310 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 64 66 -310 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
setblock 67 66 -310 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
setblock 69 66 -310 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 70 66 -310 regions_unexplored:silver_birch_log[axis=y,is_base=true]
fill 8 66 -311 13 66 -311 minecraft:stone
fill 22 66 -311 51 66 -311 minecraft:dirt
fill 52 66 -311 58 66 -311 minecraft:grass_block[snowy=false]
setblock 62 66 -311 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 64 66 -311 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 67 66 -311 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 70 66 -311 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 8 66 -312 14 66 -312 minecraft:stone
fill 24 66 -312 51 66 -312 minecraft:dirt
fill 52 66 -312 57 66 -312 minecraft:grass_block[snowy=false]
setblock 60 66 -312 regions_unexplored:meadow_sage[half=lower]
setblock 64 66 -312 regions_unexplored:silver_birch_log[axis=y,is_base=true]
fill 8 66 -313 14 66 -313 minecraft:stone
fill 25 66 -313 50 66 -313 minecraft:dirt
fill 51 66 -313 52 66 -313 minecraft:grass_block[snowy=false]
setblock 53 66 -313 minecraft:dirt
fill 54 66 -313 57 66 -313 minecraft:grass_block[snowy=false]
setblock 66 66 -313 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 67 66 -313 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 68 66 -313 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 71 66 -313 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 8 66 -314 15 66 -314 minecraft:stone
fill 27 66 -314 30 66 -314 minecraft:dirt
fill 34 66 -314 50 66 -314 minecraft:dirt
fill 51 66 -314 56 66 -314 minecraft:grass_block[snowy=false]
setblock 61 66 -314 regions_unexplored:meadow_sage[half=lower]
setblock 66 66 -314 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
fill 8 66 -315 16 66 -315 minecraft:stone
fill 36 66 -315 50 66 -315 minecraft:dirt
fill 51 66 -315 56 66 -315 minecraft:grass_block[snowy=false]
setblock 57 66 -315 regions_unexplored:meadow_sage[half=lower]
setblock 60 66 -315 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 61 66 -315 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
fill 62 66 -315 63 66 -315 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 65 66 -315 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 66 66 -315 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 8 66 -316 17 66 -316 minecraft:stone
fill 36 66 -316 50 66 -316 minecraft:dirt
fill 51 66 -316 55 66 -316 minecraft:grass_block[snowy=false]
setblock 61 66 -316 regions_unexplored:meadow_sage[half=lower]
setblock 62 66 -316 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 63 66 -316 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 64 66 -316 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 65 66 -316 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
fill 8 66 -317 19 66 -317 minecraft:stone
fill 36 66 -317 49 66 -317 minecraft:dirt
setblock 50 66 -317 minecraft:grass_block[snowy=false]
setblock 51 66 -317 minecraft:dirt
fill 52 66 -317 55 66 -317 minecraft:grass_block[snowy=false]
setblock 58 66 -317 regions_unexplored:meadow_sage[half=lower]
setblock 63 66 -317 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 64 66 -317 regions_unexplored:silver_birch_log[axis=y,is_base=true]
setblock 8 66 -318 minecraft:coal_ore
fill 9 66 -318 20 66 -318 minecraft:stone
fill 35 66 -318 49 66 -318 minecraft:dirt
fill 50 66 -318 55 66 -318 minecraft:grass_block[snowy=false]
setblock 57 66 -318 regions_unexplored:meadow_sage[half=lower]
setblock 58 66 -318 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
setblock 60 66 -318 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 61 66 -318 regions_unexplored:silver_birch_log[axis=y,is_base=true]
setblock 63 66 -318 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
fill 8 65 -255 24 65 -255 minecraft:stone
fill 25 65 -255 26 65 -255 create:limestone
fill 27 65 -255 36 65 -255 minecraft:air
fill 8 65 -256 24 65 -256 minecraft:stone
fill 25 65 -256 26 65 -256 create:limestone
fill 27 65 -256 37 65 -256 minecraft:air
fill 8 65 -257 25 65 -257 minecraft:stone
setblock 26 65 -257 create:limestone
fill 27 65 -257 38 65 -257 minecraft:air
fill 8 65 -258 12 65 -258 minecraft:coal_ore
fill 13 65 -258 26 65 -258 minecraft:stone
fill 27 65 -258 38 65 -258 minecraft:air
fill 8 65 -259 11 65 -259 minecraft:coal_ore
fill 12 65 -259 26 65 -259 minecraft:stone
fill 27 65 -259 39 65 -259 minecraft:air
fill 8 65 -260 26 65 -260 minecraft:stone
fill 27 65 -260 40 65 -260 minecraft:air
fill 8 65 -261 26 65 -261 minecraft:stone
fill 27 65 -261 41 65 -261 minecraft:air
fill 8 65 -262 26 65 -262 minecraft:stone
fill 27 65 -262 42 65 -262 minecraft:air
fill 8 65 -263 26 65 -263 minecraft:stone
fill 27 65 -263 43 65 -263 minecraft:air
fill 8 65 -264 26 65 -264 minecraft:stone
fill 27 65 -264 44 65 -264 minecraft:air
fill 8 65 -265 26 65 -265 minecraft:stone
fill 27 65 -265 45 65 -265 minecraft:air
fill 8 65 -266 26 65 -266 minecraft:stone
fill 27 65 -266 46 65 -266 minecraft:air
fill 8 65 -267 26 65 -267 minecraft:stone
fill 27 65 -267 47 65 -267 minecraft:air
fill 8 65 -268 26 65 -268 minecraft:stone
fill 27 65 -268 48 65 -268 minecraft:air
fill 8 65 -269 19 65 -269 minecraft:stone
setblock 20 65 -269 minecraft:gravel
fill 21 65 -269 26 65 -269 minecraft:stone
fill 27 65 -269 49 65 -269 minecraft:air
fill 8 65 -270 16 65 -270 minecraft:stone
fill 17 65 -270 24 65 -270 minecraft:gravel
fill 25 65 -270 26 65 -270 minecraft:stone
fill 27 65 -270 50 65 -270 minecraft:air
fill 8 65 -271 17 65 -271 minecraft:stone
fill 18 65 -271 25 65 -271 minecraft:gravel
setblock 26 65 -271 minecraft:stone
fill 27 65 -271 52 65 -271 minecraft:air
fill 8 65 -272 18 65 -272 minecraft:stone
fill 19 65 -272 26 65 -272 minecraft:gravel
fill 27 65 -272 53 65 -272 minecraft:air
fill 8 65 -273 18 65 -273 minecraft:stone
fill 19 65 -273 26 65 -273 minecraft:gravel
fill 27 65 -273 55 65 -273 minecraft:air
fill 8 65 -274 22 65 -274 minecraft:stone
setblock 23 65 -274 minecraft:gravel
setblock 24 65 -274 minecraft:stone
setblock 25 65 -274 minecraft:gravel
setblock 26 65 -274 minecraft:stone
fill 27 65 -274 56 65 -274 minecraft:air
fill 8 65 -275 26 65 -275 minecraft:stone
fill 27 65 -275 58 65 -275 minecraft:air
fill 8 65 -276 26 65 -276 minecraft:stone
fill 27 65 -276 60 65 -276 minecraft:air
fill 8 65 -277 26 65 -277 minecraft:stone
fill 27 65 -277 62 65 -277 minecraft:air
fill 8 65 -278 26 65 -278 minecraft:stone
fill 27 65 -278 64 65 -278 minecraft:air
fill 8 65 -279 26 65 -279 minecraft:stone
fill 27 65 -279 67 65 -279 minecraft:air
fill 8 65 -280 9 65 -280 minecraft:coal_ore
fill 10 65 -280 26 65 -280 minecraft:stone
fill 27 65 -280 70 65 -280 minecraft:air
fill 8 65 -281 9 65 -281 minecraft:coal_ore
fill 10 65 -281 22 65 -281 minecraft:stone
setblock 23 65 -281 alltheores:cinnabar_ore
fill 24 65 -281 26 65 -281 minecraft:stone
fill 27 65 -281 71 65 -281 minecraft:air
fill 8 65 -282 9 65 -282 minecraft:coal_ore
fill 10 65 -282 26 65 -282 minecraft:stone
fill 27 65 -282 71 65 -282 minecraft:air
setblock 8 65 -283 pneumaticcraft:oil[level=0]
fill 9 65 -283 26 65 -283 minecraft:stone
fill 27 65 -283 30 65 -283 minecraft:dirt
fill 31 65 -283 34 65 -283 minecraft:gravel
setblock 35 65 -283 minecraft:stone
fill 36 65 -283 37 65 -283 minecraft:gravel
fill 38 65 -283 44 65 -283 minecraft:stone
fill 45 65 -283 51 65 -283 railcraft:quarried_stone
fill 52 65 -283 71 65 -283 minecraft:air
setblock 8 65 -284 pneumaticcraft:oil[level=0]
fill 9 65 -284 27 65 -284 minecraft:stone
fill 28 65 -284 29 65 -284 minecraft:dirt
setblock 30 65 -284 minecraft:stone
fill 31 65 -284 34 65 -284 minecraft:gravel
fill 35 65 -284 45 65 -284 minecraft:stone
fill 46 65 -284 54 65 -284 railcraft:quarried_stone
fill 55 65 -284 69 65 -284 minecraft:stone
setblock 71 65 -284 minecraft:air
setblock 8 65 -285 pneumaticcraft:oil[level=0]
fill 9 65 -285 30 65 -285 minecraft:stone
fill 31 65 -285 34 65 -285 minecraft:gravel
fill 35 65 -285 47 65 -285 minecraft:stone
fill 48 65 -285 52 65 -285 railcraft:quarried_stone
fill 53 65 -285 69 65 -285 minecraft:stone
fill 70 65 -285 71 65 -285 minecraft:air
setblock 8 65 -286 pneumaticcraft:oil[level=0]
fill 9 65 -286 30 65 -286 minecraft:stone
fill 31 65 -286 34 65 -286 minecraft:gravel
fill 35 65 -286 69 65 -286 minecraft:stone
fill 70 65 -286 71 65 -286 minecraft:air
setblock 8 65 -287 pneumaticcraft:oil[level=0]
fill 9 65 -287 19 65 -287 minecraft:stone
fill 20 65 -287 24 65 -287 minecraft:air
fill 25 65 -287 30 65 -287 minecraft:stone
fill 31 65 -287 34 65 -287 minecraft:gravel
fill 35 65 -287 69 65 -287 minecraft:stone
setblock 70 65 -287 minecraft:air
setblock 71 65 -287 minecraft:stone
fill 8 65 -288 18 65 -288 minecraft:stone
fill 19 65 -288 25 65 -288 minecraft:air
fill 26 65 -288 30 65 -288 minecraft:stone
fill 31 65 -288 33 65 -288 minecraft:gravel
fill 34 65 -288 35 65 -288 minecraft:stone
setblock 36 65 -288 minecraft:dirt
fill 37 65 -288 47 65 -288 minecraft:stone
setblock 48 65 -288 minecraft:dirt
fill 49 65 -288 71 65 -288 minecraft:stone
fill 8 65 -289 17 65 -289 minecraft:stone
fill 18 65 -289 26 65 -289 minecraft:air
fill 27 65 -289 34 65 -289 minecraft:stone
setblock 35 65 -289 minecraft:dirt
fill 36 65 -289 43 65 -289 minecraft:stone
fill 44 65 -289 47 65 -289 minecraft:dirt
fill 48 65 -289 70 65 -289 minecraft:stone
fill 8 65 -290 15 65 -290 minecraft:stone
setblock 16 65 -290 evilcraft:dark_ore[glowing=false]
fill 17 65 -290 26 65 -290 minecraft:air
fill 27 65 -290 33 65 -290 minecraft:stone
fill 34 65 -290 36 65 -290 minecraft:dirt
fill 37 65 -290 41 65 -290 minecraft:stone
fill 42 65 -290 48 65 -290 minecraft:dirt
fill 49 65 -290 70 65 -290 minecraft:stone
fill 8 65 -291 14 65 -291 minecraft:stone
setblock 15 65 -291 evilcraft:dark_ore[glowing=false]
fill 16 65 -291 26 65 -291 minecraft:air
fill 27 65 -291 33 65 -291 minecraft:stone
fill 34 65 -291 37 65 -291 minecraft:dirt
fill 38 65 -291 39 65 -291 minecraft:stone
fill 40 65 -291 49 65 -291 minecraft:dirt
fill 50 65 -291 70 65 -291 minecraft:stone
fill 8 65 -292 15 65 -292 minecraft:stone
fill 16 65 -292 25 65 -292 minecraft:air
fill 26 65 -292 33 65 -292 minecraft:stone
fill 34 65 -292 36 65 -292 minecraft:dirt
setblock 37 65 -292 minecraft:stone
fill 38 65 -292 50 65 -292 minecraft:dirt
fill 51 65 -292 70 65 -292 minecraft:stone
fill 8 65 -293 14 65 -293 minecraft:stone
fill 15 65 -293 25 65 -293 minecraft:air
fill 26 65 -293 32 65 -293 minecraft:stone
fill 33 65 -293 50 65 -293 minecraft:dirt
fill 51 65 -293 60 65 -293 minecraft:stone
setblock 61 65 -293 minecraft:dirt
fill 62 65 -293 70 65 -293 minecraft:stone
fill 8 65 -294 14 65 -294 minecraft:stone
fill 15 65 -294 24 65 -294 minecraft:air
fill 25 65 -294 32 65 -294 minecraft:stone
fill 33 65 -294 63 65 -294 minecraft:dirt
setblock 64 65 -294 minecraft:stone
setblock 65 65 -294 minecraft:dirt
fill 66 65 -294 67 65 -294 minecraft:stone
fill 68 65 -294 71 65 -294 minecraft:dirt
fill 8 65 -295 15 65 -295 minecraft:stone
fill 16 65 -295 22 65 -295 minecraft:air
fill 23 65 -295 31 65 -295 minecraft:stone
fill 32 65 -295 37 65 -295 minecraft:dirt
fill 40 65 -295 65 65 -295 minecraft:dirt
setblock 66 65 -295 minecraft:stone
fill 67 65 -295 71 65 -295 minecraft:dirt
fill 8 65 -296 31 65 -296 minecraft:stone
fill 32 65 -296 36 65 -296 minecraft:dirt
fill 37 65 -296 39 65 -296 minecraft:air
fill 41 65 -296 71 65 -296 minecraft:dirt
setblock 8 65 -297 minecraft:dirt
fill 9 65 -297 31 65 -297 minecraft:stone
fill 32 65 -297 35 65 -297 minecraft:dirt
fill 36 65 -297 39 65 -297 minecraft:air
fill 41 65 -297 67 65 -297 minecraft:dirt
fill 69 65 -297 71 65 -297 minecraft:dirt
fill 8 65 -298 9 65 -298 minecraft:dirt
fill 10 65 -298 30 65 -298 minecraft:stone
fill 31 65 -298 34 65 -298 minecraft:dirt
fill 35 65 -298 39 65 -298 minecraft:air
fill 41 65 -298 66 65 -298 minecraft:dirt
setblock 68 65 -298 minecraft:air
setblock 71 65 -298 minecraft:dirt
setblock 8 65 -299 minecraft:dirt
fill 9 65 -299 30 65 -299 minecraft:stone
fill 31 65 -299 33 65 -299 minecraft:dirt
fill 34 65 -299 39 65 -299 minecraft:air
fill 40 65 -299 64 65 -299 minecraft:dirt
fill 67 65 -299 70 65 -299 minecraft:air
setblock 8 65 -300 minecraft:dirt
fill 9 65 -300 30 65 -300 minecraft:stone
fill 31 65 -300 33 65 -300 minecraft:dirt
fill 34 65 -300 38 65 -300 minecraft:air
fill 39 65 -300 63 65 -300 minecraft:dirt
fill 65 65 -300 71 65 -300 minecraft:air
setblock 8 65 -301 minecraft:dirt
fill 9 65 -301 30 65 -301 minecraft:stone
fill 31 65 -301 33 65 -301 minecraft:dirt
fill 34 65 -301 37 65 -301 minecraft:air
fill 38 65 -301 62 65 -301 minecraft:dirt
fill 64 65 -301 71 65 -301 minecraft:air
fill 8 65 -302 19 65 -302 minecraft:stone
fill 20 65 -302 24 65 -302 minecraft:air
fill 25 65 -302 30 65 -302 minecraft:stone
fill 31 65 -302 32 65 -302 minecraft:dirt
fill 33 65 -302 34 65 -302 minecraft:air
fill 35 65 -302 61 65 -302 minecraft:dirt
fill 63 65 -302 71 65 -302 minecraft:air
fill 8 65 -303 16 65 -303 minecraft:stone
setblock 17 65 -303 theurgy:sal_ammoniac_ore
fill 18 65 -303 27 65 -303 minecraft:air
fill 28 65 -303 29 65 -303 minecraft:stone
fill 30 65 -303 31 65 -303 minecraft:dirt
fill 32 65 -303 34 65 -303 minecraft:air
fill 35 65 -303 60 65 -303 minecraft:dirt
fill 63 65 -303 69 65 -303 minecraft:air
setblock 70 65 -303 minecraft:birch_log[axis=y]
setblock 71 65 -303 minecraft:air
fill 8 65 -304 15 65 -304 minecraft:stone
fill 16 65 -304 29 65 -304 minecraft:air
fill 30 65 -304 31 65 -304 minecraft:dirt
fill 32 65 -304 33 65 -304 minecraft:air
fill 34 65 -304 59 65 -304 minecraft:dirt
fill 62 65 -304 63 65 -304 minecraft:air
setblock 64 65 -304 minecraft:birch_log[axis=y]
fill 65 65 -304 71 65 -304 minecraft:air
fill 8 65 -305 14 65 -305 minecraft:stone
fill 15 65 -305 29 65 -305 minecraft:air
fill 30 65 -305 31 65 -305 minecraft:dirt
fill 32 65 -305 36 65 -305 minecraft:air
fill 37 65 -305 59 65 -305 minecraft:dirt
fill 62 65 -305 71 65 -305 minecraft:air
fill 8 65 -306 14 65 -306 minecraft:stone
fill 15 65 -306 27 65 -306 minecraft:air
fill 28 65 -306 29 65 -306 minecraft:stone
fill 30 65 -306 31 65 -306 minecraft:dirt
fill 32 65 -306 35 65 -306 minecraft:air
fill 37 65 -306 60 65 -306 minecraft:dirt
fill 63 65 -306 71 65 -306 minecraft:air
fill 8 65 -307 13 65 -307 minecraft:stone
setblock 14 65 -307 minecraft:lava[level=8]
setblock 15 65 -307 minecraft:lava[level=2]
fill 16 65 -307 23 65 -307 minecraft:air
fill 24 65 -307 29 65 -307 minecraft:stone
setblock 30 65 -307 minecraft:dirt
fill 31 65 -307 35 65 -307 minecraft:air
fill 36 65 -307 60 65 -307 minecraft:dirt
setblock 64 65 -307 minecraft:birch_log[axis=y]
fill 65 65 -307 71 65 -307 minecraft:air
fill 8 65 -308 13 65 -308 minecraft:stone
fill 14 65 -308 20 65 -308 minecraft:air
fill 21 65 -308 29 65 -308 minecraft:stone
fill 30 65 -308 31 65 -308 minecraft:dirt
setblock 34 65 -308 minecraft:air
fill 36 65 -308 61 65 -308 minecraft:dirt
fill 65 65 -308 70 65 -308 minecraft:air
setblock 71 65 -308 regions_unexplored:silt_grass_block[snowy=false]
fill 8 65 -309 13 65 -309 minecraft:stone
fill 14 65 -309 19 65 -309 minecraft:air
fill 20 65 -309 28 65 -309 minecraft:stone
fill 29 65 -309 60 65 -309 minecraft:dirt
setblock 62 65 -309 minecraft:dirt
fill 64 65 -309 65 65 -309 regions_unexplored:silt_grass_block[snowy=false]
fill 66 65 -309 70 65 -309 minecraft:air
setblock 71 65 -309 regions_unexplored:silt_grass_block[snowy=false]
fill 8 65 -310 13 65 -310 minecraft:stone
fill 14 65 -310 20 65 -310 minecraft:air
fill 21 65 -310 28 65 -310 minecraft:stone
fill 29 65 -310 59 65 -310 minecraft:dirt
fill 63 65 -310 67 65 -310 regions_unexplored:silt_grass_block[snowy=false]
setblock 68 65 -310 minecraft:air
setblock 69 65 -310 regions_unexplored:silt_grass_block[snowy=false]
setblock 70 65 -310 regions_unexplored:silt_dirt
setblock 71 65 -310 regions_unexplored:silt_grass_block[snowy=false]
fill 8 65 -311 13 65 -311 minecraft:stone
fill 14 65 -311 21 65 -311 minecraft:air
fill 22 65 -311 28 65 -311 minecraft:stone
fill 29 65 -311 58 65 -311 minecraft:dirt
fill 63 65 -311 71 65 -311 regions_unexplored:silt_grass_block[snowy=false]
fill 8 65 -312 14 65 -312 minecraft:stone
fill 15 65 -312 23 65 -312 minecraft:air
fill 24 65 -312 28 65 -312 minecraft:stone
fill 29 65 -312 57 65 -312 minecraft:dirt
setblock 63 65 -312 regions_unexplored:silt_grass_block[snowy=false]
setblock 64 65 -312 regions_unexplored:silt_dirt
fill 65 65 -312 71 65 -312 regions_unexplored:silt_grass_block[snowy=false]
fill 8 65 -313 14 65 -313 minecraft:stone
fill 15 65 -313 25 65 -313 minecraft:air
fill 26 65 -313 28 65 -313 minecraft:stone
fill 29 65 -313 57 65 -313 minecraft:dirt
fill 62 65 -313 71 65 -313 regions_unexplored:silt_grass_block[snowy=false]
fill 8 65 -314 15 65 -314 minecraft:stone
fill 16 65 -314 26 65 -314 minecraft:air
fill 27 65 -314 28 65 -314 minecraft:stone
setblock 29 65 -314 minecraft:dirt
fill 30 65 -314 35 65 -314 minecraft:air
fill 36 65 -314 56 65 -314 minecraft:dirt
fill 62 65 -314 71 65 -314 regions_unexplored:silt_grass_block[snowy=false]
fill 8 65 -315 16 65 -315 minecraft:stone
fill 17 65 -315 36 65 -315 minecraft:air
fill 37 65 -315 56 65 -315 minecraft:dirt
fill 61 65 -315 70 65 -315 regions_unexplored:silt_grass_block[snowy=false]
setblock 71 65 -315 minecraft:air
fill 8 65 -316 17 65 -316 minecraft:stone
fill 18 65 -316 37 65 -316 minecraft:air
fill 38 65 -316 55 65 -316 minecraft:dirt
fill 61 65 -316 69 65 -316 regions_unexplored:silt_grass_block[snowy=false]
fill 70 65 -316 71 65 -316 minecraft:air
fill 8 65 -317 19 65 -317 minecraft:stone
fill 20 65 -317 36 65 -317 minecraft:air
fill 37 65 -317 55 65 -317 minecraft:dirt
fill 61 65 -317 63 65 -317 regions_unexplored:silt_grass_block[snowy=false]
setblock 64 65 -317 regions_unexplored:silt_dirt
fill 65 65 -317 67 65 -317 minecraft:sand
setblock 68 65 -317 regions_unexplored:silt_grass_block[snowy=false]
fill 69 65 -317 71 65 -317 minecraft:air
fill 8 65 -318 20 65 -318 minecraft:stone
fill 21 65 -318 35 65 -318 minecraft:air
fill 36 65 -318 55 65 -318 minecraft:dirt
setblock 60 65 -318 regions_unexplored:silt_grass_block[snowy=false]
setblock 61 65 -318 regions_unexplored:silt_dirt
fill 62 65 -318 63 65 -318 regions_unexplored:silt_grass_block[snowy=false]
fill 64 65 -318 67 65 -318 minecraft:sand
fill 68 65 -318 71 65 -318 minecraft:air
fill 27 64 -255 44 64 -255 minecraft:air
fill 47 64 -255 71 64 -255 minecraft:air
fill 27 64 -256 45 64 -256 minecraft:air
fill 49 64 -256 52 64 -256 minecraft:air
fill 54 64 -256 57 64 -256 minecraft:air
fill 59 64 -256 62 64 -256 minecraft:air
fill 64 64 -256 67 64 -256 minecraft:air
fill 69 64 -256 71 64 -256 minecraft:air
fill 27 64 -257 46 64 -257 minecraft:air
fill 49 64 -257 65 64 -257 minecraft:air
fill 67 64 -257 71 64 -257 minecraft:air
fill 27 64 -258 47 64 -258 minecraft:air
fill 50 64 -258 71 64 -258 minecraft:air
fill 27 64 -259 48 64 -259 minecraft:air
fill 51 64 -259 71 64 -259 minecraft:air
fill 27 64 -260 49 64 -260 minecraft:air
fill 52 64 -260 56 64 -260 minecraft:air
fill 58 64 -260 71 64 -260 minecraft:air
fill 27 64 -261 50 64 -261 minecraft:air
fill 54 64 -261 57 64 -261 minecraft:air
fill 59 64 -261 62 64 -261 minecraft:air
fill 64 64 -261 67 64 -261 minecraft:air
fill 69 64 -261 71 64 -261 minecraft:air
fill 27 64 -262 51 64 -262 minecraft:air
fill 54 64 -262 71 64 -262 minecraft:air
fill 27 64 -263 52 64 -263 minecraft:air
fill 55 64 -263 71 64 -263 minecraft:air
fill 27 64 -264 53 64 -264 minecraft:air
fill 56 64 -264 71 64 -264 minecraft:air
fill 27 64 -265 54 64 -265 minecraft:air
fill 58 64 -265 71 64 -265 minecraft:air
fill 27 64 -266 56 64 -266 minecraft:air
fill 59 64 -266 62 64 -266 minecraft:air
fill 64 64 -266 67 64 -266 minecraft:air
fill 69 64 -266 71 64 -266 minecraft:air
fill 27 64 -267 57 64 -267 minecraft:air
fill 61 64 -267 68 64 -267 minecraft:air
fill 70 64 -267 71 64 -267 minecraft:air
fill 27 64 -268 59 64 -268 minecraft:air
fill 63 64 -268 71 64 -268 minecraft:air
fill 27 64 -269 61 64 -269 minecraft:air
fill 64 64 -269 71 64 -269 minecraft:air
fill 27 64 -270 63 64 -270 minecraft:air
fill 67 64 -270 71 64 -270 minecraft:air
fill 27 64 -271 65 64 -271 minecraft:air
fill 69 64 -271 71 64 -271 minecraft:air
fill 27 64 -272 67 64 -272 minecraft:air
fill 27 64 -273 70 64 -273 minecraft:air
fill 27 64 -274 71 64 -274 minecraft:air
fill 27 64 -275 71 64 -275 minecraft:air
fill 27 64 -276 71 64 -276 minecraft:air
fill 27 64 -277 71 64 -277 minecraft:air
fill 27 64 -278 71 64 -278 minecraft:air
fill 27 64 -279 71 64 -279 minecraft:air
fill 27 64 -280 71 64 -280 minecraft:air
fill 27 64 -281 71 64 -281 minecraft:air
fill 27 64 -282 71 64 -282 minecraft:air
fill 52 64 -283 71 64 -283 minecraft:air
setblock 8 64 -284 pneumaticcraft:oil[level=0]
setblock 71 64 -284 minecraft:air
setblock 8 64 -285 pneumaticcraft:oil[level=0]
fill 70 64 -285 71 64 -285 minecraft:air
setblock 8 64 -286 pneumaticcraft:oil[level=0]
fill 70 64 -286 71 64 -286 minecraft:air
setblock 8 64 -287 pneumaticcraft:oil[level=0]
fill 70 64 -287 71 64 -287 minecraft:air
fill 19 64 -288 24 64 -288 minecraft:air
setblock 69 64 -288 minecraft:air
fill 17 64 -289 24 64 -289 minecraft:air
fill 16 64 -290 25 64 -290 minecraft:air
fill 14 64 -291 25 64 -291 minecraft:air
fill 13 64 -292 25 64 -292 minecraft:air
fill 13 64 -293 24 64 -293 minecraft:air
fill 13 64 -294 23 64 -294 minecraft:air
fill 14 64 -295 22 64 -295 minecraft:air
fill 15 64 -296 21 64 -296 minecraft:air
fill 36 64 -297 37 64 -297 minecraft:air
fill 35 64 -298 38 64 -298 minecraft:air
fill 34 64 -299 38 64 -299 minecraft:air
fill 68 64 -299 69 64 -299 minecraft:air
fill 34 64 -300 38 64 -300 minecraft:air
fill 66 64 -300 70 64 -300 minecraft:air
fill 32 64 -301 37 64 -301 minecraft:air
fill 66 64 -301 71 64 -301 minecraft:air
fill 20 64 -302 26 64 -302 minecraft:air
fill 31 64 -302 35 64 -302 minecraft:air
fill 65 64 -302 71 64 -302 minecraft:air
fill 18 64 -303 35 64 -303 minecraft:air
fill 64 64 -303 69 64 -303 minecraft:air
setblock 71 64 -303 minecraft:air
fill 16 64 -304 35 64 -304 minecraft:air
setblock 63 64 -304 minecraft:air
fill 65 64 -304 71 64 -304 minecraft:air
setblock 15 64 -305 minecraft:lava[level=4]
setblock 16 64 -305 minecraft:lava[level=6]
fill 17 64 -305 35 64 -305 minecraft:air
fill 64 64 -305 71 64 -305 minecraft:air
setblock 15 64 -306 minecraft:lava[level=2]
setblock 16 64 -306 minecraft:lava[level=4]
setblock 17 64 -306 minecraft:lava[level=6]
fill 18 64 -306 35 64 -306 minecraft:air
fill 65 64 -306 71 64 -306 minecraft:air
setblock 15 64 -307 minecraft:lava[level=8]
setblock 16 64 -307 minecraft:lava[level=2]
setblock 17 64 -307 minecraft:lava[level=4]
setblock 18 64 -307 minecraft:lava[level=6]
fill 19 64 -307 27 64 -307 minecraft:air
fill 30 64 -307 34 64 -307 minecraft:air
fill 66 64 -307 70 64 -307 minecraft:air
setblock 15 64 -308 minecraft:lava[level=2]
setblock 16 64 -308 minecraft:lava[level=4]
setblock 17 64 -308 minecraft:lava[level=6]
fill 18 64 -308 19 64 -308 minecraft:air
fill 67 64 -308 69 64 -308 minecraft:air
setblock 14 64 -309 minecraft:lava[level=6]
setblock 15 64 -309 minecraft:lava[level=4]
setblock 16 64 -309 minecraft:lava[level=6]
fill 17 64 -309 19 64 -309 minecraft:air
setblock 14 64 -310 minecraft:air
setblock 15 64 -310 minecraft:lava[level=6]
fill 16 64 -310 19 64 -310 minecraft:air
fill 15 64 -311 20 64 -311 minecraft:air
fill 15 64 -312 22 64 -312 minecraft:air
setblock 24 64 -312 minecraft:air
fill 16 64 -313 26 64 -313 minecraft:air
fill 33 64 -313 34 64 -313 minecraft:air
fill 17 64 -314 26 64 -314 minecraft:air
fill 31 64 -314 37 64 -314 minecraft:air
fill 18 64 -315 27 64 -315 minecraft:air
fill 29 64 -315 38 64 -315 minecraft:air
fill 19 64 -316 38 64 -316 minecraft:air
fill 20 64 -317 38 64 -317 minecraft:air
fill 21 64 -318 37 64 -318 minecraft:air
fill 27 63 -255 44 63 -255 minecraft:air
fill 27 63 -256 45 63 -256 minecraft:air
fill 27 63 -257 46 63 -257 minecraft:air
fill 27 63 -258 47 63 -258 minecraft:air
fill 27 63 -259 48 63 -259 minecraft:air
fill 27 63 -260 49 63 -260 minecraft:air
fill 27 63 -261 50 63 -261 minecraft:air
fill 27 63 -262 51 63 -262 minecraft:air
fill 27 63 -263 52 63 -263 minecraft:air
fill 27 63 -264 53 63 -264 minecraft:air
fill 27 63 -265 54 63 -265 minecraft:air
fill 27 63 -266 56 63 -266 minecraft:air
fill 27 63 -267 57 63 -267 minecraft:air
fill 27 63 -268 59 63 -268 minecraft:air
fill 27 63 -269 61 63 -269 minecraft:air
fill 27 63 -270 63 63 -270 minecraft:air
fill 27 63 -271 65 63 -271 minecraft:air
fill 27 63 -272 67 63 -272 minecraft:air
fill 27 63 -273 70 63 -273 minecraft:air
fill 27 63 -274 71 63 -274 minecraft:air
fill 27 63 -275 71 63 -275 minecraft:air
fill 27 63 -276 71 63 -276 minecraft:air
fill 27 63 -277 71 63 -277 minecraft:air
fill 27 63 -278 71 63 -278 minecraft:air
fill 27 63 -279 71 63 -279 minecraft:air
fill 27 63 -280 71 63 -280 minecraft:air
fill 27 63 -281 71 63 -281 minecraft:air
fill 27 63 -282 71 63 -282 minecraft:air
fill 52 63 -283 71 63 -283 minecraft:air
fill 70 63 -284 71 63 -284 minecraft:air
fill 70 63 -285 71 63 -285 minecraft:air
fill 70 63 -286 71 63 -286 minecraft:air
fill 69 63 -287 71 63 -287 minecraft:air
setblock 21 63 -288 minecraft:air
fill 69 63 -288 70 63 -288 minecraft:air
fill 17 63 -289 23 63 -289 minecraft:air
fill 13 63 -290 24 63 -290 minecraft:air
fill 12 63 -291 24 63 -291 minecraft:air
fill 11 63 -292 24 63 -292 minecraft:air
fill 11 63 -293 23 63 -293 minecraft:air
fill 11 63 -294 23 63 -294 minecraft:air
fill 12 63 -295 22 63 -295 minecraft:air
fill 13 63 -296 20 63 -296 minecraft:air
fill 15 63 -297 18 63 -297 minecraft:air
fill 35 63 -298 37 63 -298 minecraft:air
fill 35 63 -299 37 63 -299 minecraft:air
setblock 68 63 -299 minecraft:air
fill 33 63 -300 37 63 -300 minecraft:air
fill 67 63 -300 71 63 -300 minecraft:air
fill 32 63 -301 36 63 -301 minecraft:air
fill 67 63 -301 71 63 -301 minecraft:air
fill 22 63 -302 27 63 -302 minecraft:air
fill 30 63 -302 36 63 -302 minecraft:air
fill 66 63 -302 71 63 -302 minecraft:air
fill 20 63 -303 35 63 -303 minecraft:air
fill 65 63 -303 69 63 -303 minecraft:air
setblock 71 63 -303 minecraft:air
fill 19 63 -304 35 63 -304 minecraft:air
fill 65 63 -304 71 63 -304 minecraft:air
fill 19 63 -305 35 63 -305 minecraft:air
fill 66 63 -305 71 63 -305 minecraft:air
fill 19 63 -306 34 63 -306 minecraft:air
fill 67 63 -306 70 63 -306 minecraft:air
fill 20 63 -307 21 63 -307 minecraft:air
fill 24 63 -307 34 63 -307 minecraft:air
setblock 68 63 -307 minecraft:air
fill 23 63 -312 25 63 -312 minecraft:air
fill 22 63 -313 26 63 -313 minecraft:air
setblock 34 63 -313 minecraft:air
fill 21 63 -314 27 63 -314 minecraft:air
fill 32 63 -314 37 63 -314 minecraft:air
fill 21 63 -315 25 63 -315 minecraft:air
setblock 27 63 -315 minecraft:air
fill 31 63 -315 38 63 -315 minecraft:air
fill 21 63 -316 25 63 -316 minecraft:air
fill 30 63 -316 38 63 -316 minecraft:air
fill 21 63 -317 26 63 -317 minecraft:air
fill 30 63 -317 40 63 -317 minecraft:air
fill 22 63 -318 26 63 -318 minecraft:air
fill 31 63 -318 40 63 -318 minecraft:air
fill 27 62 -255 44 62 -255 minecraft:air
fill 27 62 -256 45 62 -256 minecraft:air
fill 27 62 -257 46 62 -257 minecraft:air
fill 27 62 -258 47 62 -258 minecraft:air
fill 27 62 -259 48 62 -259 minecraft:air
fill 27 62 -260 49 62 -260 minecraft:air
fill 27 62 -261 50 62 -261 minecraft:air
fill 27 62 -262 51 62 -262 minecraft:air
fill 27 62 -263 52 62 -263 minecraft:air
fill 27 62 -264 53 62 -264 minecraft:air
fill 27 62 -265 54 62 -265 minecraft:air
fill 27 62 -266 56 62 -266 minecraft:air
fill 27 62 -267 57 62 -267 minecraft:air
fill 27 62 -268 59 62 -268 minecraft:air
fill 27 62 -269 61 62 -269 minecraft:air
fill 27 62 -270 63 62 -270 minecraft:air
fill 27 62 -271 65 62 -271 minecraft:air
fill 27 62 -272 67 62 -272 minecraft:air
fill 27 62 -273 70 62 -273 minecraft:air
fill 27 62 -274 71 62 -274 minecraft:air
fill 27 62 -275 71 62 -275 minecraft:air
fill 27 62 -276 71 62 -276 minecraft:air
fill 27 62 -277 71 62 -277 minecraft:air
fill 27 62 -278 71 62 -278 minecraft:air
fill 27 62 -279 71 62 -279 minecraft:air
fill 27 62 -280 71 62 -280 minecraft:air
fill 27 62 -281 71 62 -281 minecraft:air
fill 27 62 -282 71 62 -282 minecraft:air
fill 52 62 -283 71 62 -283 minecraft:air
fill 70 62 -284 71 62 -284 minecraft:air
fill 70 62 -285 71 62 -285 minecraft:air
fill 69 62 -286 71 62 -286 minecraft:air
fill 69 62 -287 71 62 -287 minecraft:air
fill 69 62 -288 71 62 -288 minecraft:air
fill 18 62 -289 20 62 -289 minecraft:air
setblock 9 62 -290 minecraft:air
setblock 10 62 -290 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=false,west=false]
fill 11 62 -290 22 62 -290 minecraft:air
fill 9 62 -291 22 62 -291 minecraft:air
fill 9 62 -292 22 62 -292 minecraft:air
fill 9 62 -293 22 62 -293 minecraft:air
fill 10 62 -294 22 62 -294 minecraft:air
fill 11 62 -295 21 62 -295 minecraft:air
fill 12 62 -296 20 62 -296 minecraft:air
fill 14 62 -297 18 62 -297 minecraft:air
setblock 68 62 -299 minecraft:air
fill 68 62 -300 71 62 -300 minecraft:air
fill 32 62 -301 35 62 -301 minecraft:air
fill 67 62 -301 71 62 -301 minecraft:air
fill 31 62 -302 35 62 -302 minecraft:air
fill 67 62 -302 71 62 -302 minecraft:air
fill 23 62 -303 35 62 -303 minecraft:air
fill 67 62 -303 69 62 -303 minecraft:air
setblock 71 62 -303 minecraft:air
fill 23 62 -304 35 62 -304 minecraft:air
fill 66 62 -304 71 62 -304 minecraft:air
fill 23 62 -305 34 62 -305 minecraft:air
fill 67 62 -305 70 62 -305 minecraft:air
fill 24 62 -306 34 62 -306 minecraft:air
fill 27 62 -307 33 62 -307 minecraft:air
fill 23 62 -312 24 62 -312 minecraft:water[level=0]
fill 22 62 -313 24 62 -313 minecraft:water[level=0]
fill 21 62 -314 25 62 -314 minecraft:water[level=0]
fill 33 62 -314 37 62 -314 minecraft:air
setblock 58 62 -314 minecraft:air
fill 21 62 -315 25 62 -315 minecraft:water[level=0]
fill 32 62 -315 38 62 -315 minecraft:air
fill 21 62 -316 26 62 -316 minecraft:water[level=0]
fill 32 62 -316 40 62 -316 minecraft:air
fill 21 62 -317 26 62 -317 minecraft:water[level=0]
fill 32 62 -317 41 62 -317 minecraft:air
fill 22 62 -318 25 62 -318 minecraft:water[level=0]
fill 33 62 -318 42 62 -318 minecraft:air
fill 27 61 -255 44 61 -255 minecraft:air
fill 27 61 -256 45 61 -256 minecraft:air
fill 27 61 -257 46 61 -257 minecraft:air
fill 27 61 -258 47 61 -258 minecraft:air
fill 27 61 -259 48 61 -259 minecraft:air
fill 27 61 -260 49 61 -260 minecraft:air
fill 27 61 -261 50 61 -261 minecraft:air
fill 27 61 -262 51 61 -262 minecraft:air
fill 27 61 -263 52 61 -263 minecraft:air
fill 27 61 -264 53 61 -264 minecraft:air
fill 27 61 -265 54 61 -265 minecraft:air
fill 27 61 -266 56 61 -266 minecraft:air
fill 27 61 -267 57 61 -267 minecraft:air
fill 27 61 -268 59 61 -268 minecraft:air
fill 27 61 -269 61 61 -269 minecraft:air
fill 27 61 -270 63 61 -270 minecraft:air
fill 27 61 -271 65 61 -271 minecraft:air
fill 27 61 -272 67 61 -272 minecraft:air
fill 27 61 -273 70 61 -273 minecraft:air
fill 27 61 -274 71 61 -274 minecraft:air
fill 27 61 -275 71 61 -275 minecraft:air
fill 27 61 -276 71 61 -276 minecraft:air
fill 27 61 -277 71 61 -277 minecraft:air
fill 27 61 -278 71 61 -278 minecraft:air
fill 27 61 -279 71 61 -279 minecraft:air
fill 27 61 -280 71 61 -280 minecraft:air
fill 27 61 -281 71 61 -281 minecraft:air
fill 27 61 -282 71 61 -282 minecraft:air
fill 52 61 -283 71 61 -283 minecraft:air
fill 70 61 -284 71 61 -284 minecraft:air
fill 69 61 -285 71 61 -285 minecraft:air
fill 69 61 -286 71 61 -286 minecraft:air
fill 69 61 -287 71 61 -287 minecraft:air
fill 68 61 -288 71 61 -288 minecraft:air
fill 8 61 -289 14 61 -289 minecraft:air
fill 68 61 -289 70 61 -289 minecraft:air
fill 8 61 -290 19 61 -290 minecraft:air
fill 8 61 -291 20 61 -291 minecraft:air
fill 8 61 -292 21 61 -292 minecraft:air
fill 8 61 -293 21 61 -293 minecraft:air
fill 8 61 -294 20 61 -294 minecraft:air
fill 10 61 -295 20 61 -295 minecraft:air
fill 11 61 -296 19 61 -296 minecraft:air
fill 14 61 -297 17 61 -297 minecraft:air
fill 68 61 -300 71 61 -300 minecraft:air
fill 68 61 -301 71 61 -301 minecraft:air
fill 68 61 -302 71 61 -302 minecraft:air
fill 68 61 -303 69 61 -303 minecraft:air
setblock 71 61 -303 minecraft:air
fill 30 61 -304 31 61 -304 minecraft:air
fill 68 61 -304 71 61 -304 minecraft:air
fill 29 61 -305 34 61 -305 minecraft:air
fill 29 61 -306 33 61 -306 minecraft:air
fill 28 61 -307 32 61 -307 minecraft:air
fill 58 61 -308 59 61 -308 minecraft:air
fill 58 61 -309 59 61 -309 minecraft:air
fill 57 61 -310 60 61 -310 minecraft:air
fill 57 61 -311 59 61 -311 minecraft:air
fill 23 61 -312 24 61 -312 minecraft:water[level=0]
fill 57 61 -312 60 61 -312 minecraft:air
fill 21 61 -313 25 61 -313 minecraft:water[level=0]
fill 57 61 -313 59 61 -313 minecraft:air
fill 21 61 -314 25 61 -314 minecraft:water[level=0]
setblock 36 61 -314 minecraft:air
fill 56 61 -314 59 61 -314 minecraft:air
fill 20 61 -315 26 61 -315 minecraft:water[level=0]
fill 34 61 -315 37 61 -315 minecraft:air
setblock 39 61 -315 minecraft:air
fill 56 61 -315 59 61 -315 minecraft:air
fill 20 61 -316 26 61 -316 minecraft:water[level=0]
fill 34 61 -316 41 61 -316 minecraft:air
fill 56 61 -316 58 61 -316 minecraft:air
fill 20 61 -317 26 61 -317 minecraft:water[level=0]
fill 34 61 -317 43 61 -317 minecraft:air
fill 56 61 -317 58 61 -317 minecraft:air
fill 20 61 -318 26 61 -318 minecraft:water[level=0]
fill 35 61 -318 42 61 -318 minecraft:air
fill 55 61 -318 58 61 -318 minecraft:air
fill 27 60 -255 44 60 -255 minecraft:air
fill 27 60 -256 45 60 -256 minecraft:air
fill 27 60 -257 46 60 -257 minecraft:air
fill 27 60 -258 47 60 -258 minecraft:air
fill 27 60 -259 48 60 -259 minecraft:air
fill 27 60 -260 49 60 -260 minecraft:air
fill 27 60 -261 50 60 -261 minecraft:air
fill 27 60 -262 51 60 -262 minecraft:air
fill 27 60 -263 52 60 -263 minecraft:air
fill 27 60 -264 53 60 -264 minecraft:air
fill 27 60 -265 54 60 -265 minecraft:air
fill 27 60 -266 56 60 -266 minecraft:air
fill 27 60 -267 57 60 -267 minecraft:air
fill 27 60 -268 59 60 -268 minecraft:air
fill 27 60 -269 61 60 -269 minecraft:air
fill 27 60 -270 63 60 -270 minecraft:air
fill 27 60 -271 65 60 -271 minecraft:air
fill 27 60 -272 67 60 -272 minecraft:air
fill 27 60 -273 70 60 -273 minecraft:air
fill 27 60 -274 71 60 -274 minecraft:air
fill 27 60 -275 71 60 -275 minecraft:air
fill 27 60 -276 71 60 -276 minecraft:air
fill 27 60 -277 71 60 -277 minecraft:air
fill 27 60 -278 71 60 -278 minecraft:air
fill 27 60 -279 71 60 -279 minecraft:air
fill 27 60 -280 71 60 -280 minecraft:air
fill 27 60 -281 71 60 -281 minecraft:air
fill 27 60 -282 71 60 -282 minecraft:air
fill 52 60 -283 71 60 -283 minecraft:air
fill 69 60 -284 71 60 -284 minecraft:air
fill 69 60 -285 71 60 -285 minecraft:air
fill 69 60 -286 71 60 -286 minecraft:air
fill 68 60 -287 71 60 -287 minecraft:air
fill 8 60 -288 12 60 -288 minecraft:air
fill 68 60 -288 71 60 -288 minecraft:air
fill 8 60 -289 13 60 -289 minecraft:air
fill 68 60 -289 71 60 -289 minecraft:air
fill 8 60 -290 16 60 -290 minecraft:air
setblock 68 60 -290 minecraft:air
fill 8 60 -291 17 60 -291 minecraft:air
fill 8 60 -292 18 60 -292 minecraft:air
fill 8 60 -293 18 60 -293 minecraft:air
fill 8 60 -294 18 60 -294 minecraft:air
fill 8 60 -295 18 60 -295 minecraft:air
fill 12 60 -296 16 60 -296 minecraft:air
fill 70 60 -296 71 60 -296 minecraft:air
fill 70 60 -297 71 60 -297 minecraft:air
fill 70 60 -298 71 60 -298 minecraft:air
fill 70 60 -299 71 60 -299 minecraft:air
setblock 71 60 -300 minecraft:air
fill 8 60 -303 12 60 -303 minecraft:air
fill 57 60 -303 58 60 -303 minecraft:air
fill 8 60 -304 11 60 -304 minecraft:air
fill 29 60 -304 30 60 -304 minecraft:air
fill 57 60 -304 59 60 -304 minecraft:air
fill 8 60 -305 10 60 -305 minecraft:air
setblock 14 60 -305 minecraft:water[level=0]
fill 30 60 -305 33 60 -305 minecraft:air
fill 57 60 -305 59 60 -305 minecraft:air
fill 16 60 -306 17 60 -306 minecraft:water[level=0]
fill 30 60 -306 32 60 -306 minecraft:air
fill 57 60 -306 60 60 -306 minecraft:air
setblock 19 60 -307 minecraft:water[level=0]
fill 29 60 -307 32 60 -307 minecraft:air
fill 57 60 -307 59 60 -307 minecraft:air
fill 57 60 -308 60 60 -308 minecraft:air
fill 57 60 -309 60 60 -309 minecraft:air
fill 57 60 -310 60 60 -310 minecraft:air
fill 57 60 -311 60 60 -311 minecraft:air
fill 57 60 -312 60 60 -312 minecraft:air
fill 21 60 -313 24 60 -313 minecraft:water[level=0]
fill 57 60 -313 60 60 -313 minecraft:air
fill 20 60 -314 25 60 -314 minecraft:water[level=0]
fill 56 60 -314 59 60 -314 minecraft:air
fill 20 60 -315 26 60 -315 minecraft:water[level=0]
fill 56 60 -315 59 60 -315 minecraft:air
fill 19 60 -316 26 60 -316 minecraft:water[level=0]
fill 55 60 -316 59 60 -316 minecraft:air
fill 19 60 -317 26 60 -317 minecraft:water[level=0]
fill 55 60 -317 58 60 -317 minecraft:air
fill 19 60 -318 25 60 -318 minecraft:water[level=0]
fill 55 60 -318 58 60 -318 minecraft:air
fill 27 59 -255 44 59 -255 minecraft:air
fill 27 59 -256 45 59 -256 minecraft:air
fill 27 59 -257 46 59 -257 minecraft:air
fill 27 59 -258 47 59 -258 minecraft:air
fill 27 59 -259 48 59 -259 minecraft:air
fill 27 59 -260 49 59 -260 minecraft:air
fill 27 59 -261 50 59 -261 minecraft:air
fill 27 59 -262 28 59 -262 minecraft:air
fill 30 59 -262 51 59 -262 minecraft:air
fill 27 59 -263 52 59 -263 minecraft:air
fill 27 59 -264 53 59 -264 minecraft:air
fill 27 59 -265 54 59 -265 minecraft:air
fill 27 59 -266 56 59 -266 minecraft:air
fill 27 59 -267 57 59 -267 minecraft:air
fill 27 59 -268 59 59 -268 minecraft:air
fill 27 59 -269 61 59 -269 minecraft:air
fill 27 59 -270 63 59 -270 minecraft:air
fill 27 59 -271 65 59 -271 minecraft:air
fill 27 59 -272 67 59 -272 minecraft:air
fill 27 59 -273 70 59 -273 minecraft:air
fill 27 59 -274 71 59 -274 minecraft:air
fill 27 59 -275 71 59 -275 minecraft:air
fill 27 59 -276 71 59 -276 minecraft:air
fill 27 59 -277 71 59 -277 minecraft:air
fill 27 59 -278 71 59 -278 minecraft:air
fill 27 59 -279 71 59 -279 minecraft:air
fill 27 59 -280 71 59 -280 minecraft:air
fill 27 59 -281 71 59 -281 minecraft:air
fill 27 59 -282 71 59 -282 minecraft:air
fill 70 59 -283 71 59 -283 minecraft:air
fill 70 59 -284 71 59 -284 minecraft:air
fill 69 59 -285 71 59 -285 minecraft:air
fill 68 59 -286 71 59 -286 minecraft:air
fill 68 59 -287 71 59 -287 minecraft:air
fill 8 59 -288 9 59 -288 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=false,west=false]
fill 10 59 -288 11 59 -288 minecraft:air
fill 68 59 -288 71 59 -288 minecraft:air
fill 8 59 -289 13 59 -289 minecraft:air
fill 68 59 -289 71 59 -289 minecraft:air
fill 8 59 -290 14 59 -290 minecraft:air
fill 68 59 -290 69 59 -290 minecraft:air
fill 8 59 -291 15 59 -291 minecraft:air
fill 8 59 -292 16 59 -292 minecraft:air
fill 8 59 -293 16 59 -293 minecraft:air
fill 8 59 -294 16 59 -294 minecraft:air
setblock 71 59 -294 minecraft:air
fill 8 59 -295 15 59 -295 minecraft:air
fill 70 59 -295 71 59 -295 minecraft:air
fill 68 59 -296 71 59 -296 minecraft:air
fill 69 59 -297 71 59 -297 minecraft:air
fill 69 59 -298 71 59 -298 minecraft:air
fill 70 59 -299 71 59 -299 minecraft:air
setblock 71 59 -300 minecraft:air
setblock 12 59 -302 minecraft:air
fill 56 59 -302 58 59 -302 minecraft:air
fill 8 59 -303 12 59 -303 minecraft:air
fill 55 59 -303 59 59 -303 minecraft:air
fill 8 59 -304 11 59 -304 minecraft:air
fill 14 59 -304 15 59 -304 minecraft:water[level=0]
fill 29 59 -304 30 59 -304 minecraft:air
fill 56 59 -304 60 59 -304 minecraft:air
fill 8 59 -305 11 59 -305 minecraft:air
fill 14 59 -305 18 59 -305 minecraft:water[level=0]
fill 30 59 -305 32 59 -305 minecraft:air
fill 56 59 -305 60 59 -305 minecraft:air
fill 15 59 -306 21 59 -306 minecraft:water[level=0]
fill 30 59 -306 32 59 -306 minecraft:air
fill 56 59 -306 60 59 -306 minecraft:air
fill 17 59 -307 21 59 -307 minecraft:water[level=0]
fill 29 59 -307 31 59 -307 minecraft:air
fill 57 59 -307 60 59 -307 minecraft:air
fill 20 59 -308 21 59 -308 minecraft:water[level=0]
setblock 30 59 -308 minecraft:air
fill 57 59 -308 60 59 -308 minecraft:air
fill 57 59 -309 60 59 -309 minecraft:air
setblock 47 59 -310 minecraft:air
fill 57 59 -310 60 59 -310 minecraft:air
fill 46 59 -311 47 59 -311 minecraft:air
fill 57 59 -311 60 59 -311 minecraft:air
setblock 46 59 -312 minecraft:air
fill 57 59 -312 60 59 -312 minecraft:air
fill 22 59 -313 25 59 -313 minecraft:water[level=0]
setblock 46 59 -313 minecraft:air
fill 57 59 -313 59 59 -313 minecraft:air
fill 20 59 -314 26 59 -314 minecraft:water[level=0]
fill 56 59 -314 59 59 -314 minecraft:air
fill 20 59 -315 26 59 -315 minecraft:water[level=0]
fill 56 59 -315 59 59 -315 minecraft:air
fill 19 59 -316 26 59 -316 minecraft:water[level=0]
fill 56 59 -316 58 59 -316 minecraft:air
fill 18 59 -317 26 59 -317 minecraft:water[level=0]
fill 41 59 -317 44 59 -317 minecraft:water[level=0]
fill 55 59 -317 58 59 -317 minecraft:air
fill 18 59 -318 25 59 -318 minecraft:water[level=0]
fill 40 59 -318 45 59 -318 minecraft:water[level=0]
fill 55 59 -318 58 59 -318 minecraft:air
setblock 71 58 -268 minecraft:air
setblock 71 58 -269 minecraft:air
setblock 71 58 -270 minecraft:air
setblock 71 58 -271 minecraft:air
setblock 71 58 -272 minecraft:air
setblock 71 58 -273 minecraft:air
setblock 71 58 -274 minecraft:air
setblock 71 58 -275 minecraft:air
setblock 71 58 -276 minecraft:air
setblock 71 58 -277 minecraft:air
setblock 71 58 -281 minecraft:air
setblock 27 58 -282 minecraft:air
setblock 71 58 -282 minecraft:air
setblock 71 58 -283 minecraft:air
fill 70 58 -284 71 58 -284 minecraft:air
fill 69 58 -285 71 58 -285 minecraft:air
fill 68 58 -286 71 58 -286 minecraft:air
fill 68 58 -287 71 58 -287 minecraft:air
fill 8 58 -288 9 58 -288 minecraft:air
fill 68 58 -288 71 58 -288 minecraft:air
fill 8 58 -289 11 58 -289 minecraft:air
fill 68 58 -289 71 58 -289 minecraft:air
fill 8 58 -290 13 58 -290 minecraft:air
fill 68 58 -290 70 58 -290 minecraft:air
fill 8 58 -291 13 58 -291 minecraft:air
setblock 68 58 -291 minecraft:air
fill 8 58 -292 13 58 -292 minecraft:air
fill 8 58 -293 13 58 -293 minecraft:air
setblock 71 58 -293 minecraft:air
fill 8 58 -294 12 58 -294 minecraft:air
fill 70 58 -294 71 58 -294 minecraft:air
fill 8 58 -295 9 58 -295 minecraft:air
fill 69 58 -295 71 58 -295 minecraft:air
fill 68 58 -296 71 58 -296 minecraft:air
fill 68 58 -297 71 58 -297 minecraft:air
fill 69 58 -298 71 58 -298 minecraft:air
fill 70 58 -299 71 58 -299 minecraft:air
setblock 71 58 -300 minecraft:air
fill 55 58 -301 57 58 -301 minecraft:air
fill 53 58 -302 58 58 -302 minecraft:air
fill 8 58 -303 12 58 -303 minecraft:air
fill 14 58 -303 15 58 -303 minecraft:water[level=0]
fill 51 58 -303 59 58 -303 minecraft:air
fill 8 58 -304 11 58 -304 minecraft:air
fill 14 58 -304 18 58 -304 minecraft:water[level=0]
fill 50 58 -304 60 58 -304 minecraft:air
fill 8 58 -305 11 58 -305 minecraft:air
fill 14 58 -305 21 58 -305 minecraft:water[level=0]
fill 30 58 -305 32 58 -305 minecraft:air
fill 49 58 -305 52 58 -305 minecraft:air
fill 55 58 -305 60 58 -305 minecraft:air
fill 16 58 -306 22 58 -306 minecraft:water[level=0]
setblock 31 58 -306 minecraft:air
fill 48 58 -306 51 58 -306 minecraft:air
fill 56 58 -306 60 58 -306 minecraft:air
fill 18 58 -307 23 58 -307 minecraft:water[level=0]
fill 26 58 -307 27 58 -307 minecraft:water[level=0]
fill 48 58 -307 50 58 -307 minecraft:air
fill 57 58 -307 60 58 -307 minecraft:air
fill 19 58 -308 23 58 -308 minecraft:water[level=0]
fill 47 58 -308 50 58 -308 minecraft:air
fill 57 58 -308 60 58 -308 minecraft:air
fill 20 58 -309 23 58 -309 minecraft:water[level=0]
fill 46 58 -309 50 58 -309 minecraft:air
fill 57 58 -309 60 58 -309 minecraft:air
fill 45 58 -310 49 58 -310 minecraft:air
fill 57 58 -310 60 58 -310 minecraft:air
fill 44 58 -311 45 58 -311 minecraft:air
fill 47 58 -311 49 58 -311 minecraft:air
fill 58 58 -311 59 58 -311 minecraft:air
fill 47 58 -312 48 58 -312 minecraft:air
setblock 23 58 -313 minecraft:water[level=0]
setblock 47 58 -313 minecraft:air
fill 21 58 -314 25 58 -314 minecraft:water[level=0]
fill 43 58 -314 44 58 -314 minecraft:water[level=0]
setblock 47 58 -314 minecraft:air
fill 19 58 -315 25 58 -315 minecraft:water[level=0]
fill 42 58 -315 45 58 -315 minecraft:water[level=0]
fill 19 58 -316 25 58 -316 minecraft:water[level=0]
fill 42 58 -316 45 58 -316 minecraft:water[level=0]
fill 18 58 -317 25 58 -317 minecraft:water[level=0]
fill 42 58 -317 44 58 -317 minecraft:water[level=0]
fill 18 58 -318 25 58 -318 minecraft:water[level=0]
fill 41 58 -318 45 58 -318 minecraft:water[level=0]
fill 56 58 -318 57 58 -318 minecraft:air
setblock 70 57 -265 minecraft:air
setblock 70 57 -266 minecraft:air
setblock 71 57 -267 minecraft:air
setblock 71 57 -268 minecraft:air
setblock 71 57 -269 minecraft:air
setblock 71 57 -270 minecraft:air
setblock 71 57 -271 minecraft:air
setblock 71 57 -272 minecraft:air
setblock 71 57 -273 minecraft:air
setblock 71 57 -274 minecraft:air
setblock 71 57 -275 minecraft:air
setblock 71 57 -283 minecraft:air
setblock 71 57 -284 minecraft:air
fill 70 57 -285 71 57 -285 minecraft:air
fill 69 57 -286 71 57 -286 minecraft:air
fill 68 57 -287 71 57 -287 minecraft:air
fill 67 57 -288 71 57 -288 minecraft:air
fill 8 57 -289 9 57 -289 minecraft:air
fill 67 57 -289 71 57 -289 minecraft:air
fill 8 57 -290 10 57 -290 minecraft:air
fill 67 57 -290 71 57 -290 minecraft:air
fill 8 57 -291 11 57 -291 minecraft:air
fill 67 57 -291 69 57 -291 minecraft:air
fill 8 57 -292 11 57 -292 minecraft:air
setblock 71 57 -292 minecraft:air
fill 8 57 -293 10 57 -293 minecraft:air
fill 70 57 -293 71 57 -293 minecraft:air
fill 8 57 -294 9 57 -294 minecraft:air
fill 69 57 -294 71 57 -294 minecraft:air
fill 68 57 -295 71 57 -295 minecraft:air
fill 67 57 -296 71 57 -296 minecraft:air
fill 68 57 -297 71 57 -297 minecraft:air
fill 69 57 -298 71 57 -298 minecraft:air
fill 70 57 -299 71 57 -299 minecraft:air
setblock 71 57 -300 minecraft:air
fill 54 57 -301 57 57 -301 minecraft:air
fill 51 57 -302 58 57 -302 minecraft:air
fill 50 57 -303 59 57 -303 minecraft:air
fill 49 57 -304 59 57 -304 minecraft:air
fill 18 57 -305 21 57 -305 minecraft:water[level=0]
setblock 31 57 -305 minecraft:air
fill 48 57 -305 59 57 -305 minecraft:air
fill 18 57 -306 22 57 -306 minecraft:water[level=0]
fill 26 57 -306 28 57 -306 minecraft:water[level=0]
fill 47 57 -306 52 57 -306 minecraft:air
fill 57 57 -306 59 57 -306 minecraft:air
fill 19 57 -307 23 57 -307 minecraft:water[level=0]
fill 25 57 -307 29 57 -307 minecraft:water[level=0]
fill 47 57 -307 51 57 -307 minecraft:air
fill 58 57 -307 59 57 -307 minecraft:air
fill 20 57 -308 23 57 -308 minecraft:water[level=0]
setblock 28 57 -308 minecraft:water[level=0]
fill 46 57 -308 51 57 -308 minecraft:air
fill 20 57 -309 24 57 -309 minecraft:water[level=0]
fill 45 57 -309 50 57 -309 minecraft:air
fill 21 57 -310 24 57 -310 minecraft:water[level=0]
fill 45 57 -310 50 57 -310 minecraft:air
fill 22 57 -311 24 57 -311 minecraft:water[level=0]
fill 45 57 -311 49 57 -311 minecraft:air
fill 23 57 -312 24 57 -312 minecraft:water[level=0]
fill 47 57 -312 48 57 -312 minecraft:air
fill 24 57 -313 25 57 -313 minecraft:water[level=0]
setblock 48 57 -313 minecraft:air
setblock 24 57 -314 minecraft:water[level=0]
fill 42 57 -314 45 57 -314 minecraft:water[level=0]
fill 20 57 -315 23 57 -315 minecraft:water[level=0]
fill 42 57 -315 46 57 -315 minecraft:water[level=0]
fill 19 57 -316 24 57 -316 minecraft:water[level=0]
fill 41 57 -316 46 57 -316 minecraft:water[level=0]
fill 18 57 -317 24 57 -317 minecraft:water[level=0]
fill 41 57 -317 45 57 -317 minecraft:water[level=0]
fill 17 57 -318 24 57 -318 minecraft:water[level=0]
fill 41 57 -318 45 57 -318 minecraft:water[level=0]
setblock 69 56 -263 minecraft:air
setblock 69 56 -264 minecraft:air
fill 69 56 -265 70 56 -265 minecraft:air
setblock 70 56 -266 minecraft:air
fill 70 56 -267 71 56 -267 minecraft:air
fill 70 56 -268 71 56 -268 minecraft:air
fill 70 56 -269 71 56 -269 minecraft:air
fill 70 56 -270 71 56 -270 minecraft:air
fill 70 56 -271 71 56 -271 minecraft:air
setblock 71 56 -272 minecraft:air
setblock 71 56 -273 minecraft:air
setblock 71 56 -274 minecraft:air
setblock 71 56 -284 minecraft:air
setblock 71 56 -285 minecraft:air
fill 70 56 -286 71 56 -286 minecraft:air
fill 69 56 -287 71 56 -287 minecraft:air
fill 67 56 -288 71 56 -288 minecraft:air
fill 67 56 -289 71 56 -289 minecraft:air
fill 67 56 -290 71 56 -290 minecraft:air
setblock 8 56 -291 minecraft:air
fill 67 56 -291 71 56 -291 minecraft:air
setblock 8 56 -292 minecraft:air
setblock 67 56 -292 minecraft:air
fill 70 56 -292 71 56 -292 minecraft:air
fill 69 56 -293 71 56 -293 minecraft:air
fill 68 56 -294 71 56 -294 minecraft:air
fill 68 56 -295 71 56 -295 minecraft:air
fill 67 56 -296 71 56 -296 minecraft:air
fill 68 56 -297 71 56 -297 minecraft:air
fill 69 56 -298 71 56 -298 minecraft:air
fill 70 56 -299 71 56 -299 minecraft:air
setblock 71 56 -300 minecraft:air
fill 54 56 -301 56 56 -301 minecraft:air
fill 51 56 -302 57 56 -302 minecraft:air
fill 49 56 -303 58 56 -303 minecraft:air
fill 48 56 -304 58 56 -304 minecraft:air
fill 26 56 -305 28 56 -305 minecraft:water[level=0]
fill 48 56 -305 57 56 -305 minecraft:air
fill 21 56 -306 22 56 -306 minecraft:water[level=0]
fill 25 56 -306 29 56 -306 minecraft:water[level=0]
fill 47 56 -306 53 56 -306 minecraft:air
fill 20 56 -307 23 56 -307 minecraft:water[level=0]
fill 25 56 -307 28 56 -307 minecraft:water[level=0]
fill 47 56 -307 51 56 -307 minecraft:air
fill 20 56 -308 24 56 -308 minecraft:water[level=0]
setblock 28 56 -308 minecraft:water[level=0]
fill 46 56 -308 51 56 -308 minecraft:air
fill 20 56 -309 24 56 -309 minecraft:water[level=0]
fill 45 56 -309 50 56 -309 minecraft:air
fill 21 56 -310 25 56 -310 minecraft:water[level=0]
fill 45 56 -310 50 56 -310 minecraft:air
fill 21 56 -311 25 56 -311 minecraft:water[level=0]
fill 48 56 -311 49 56 -311 minecraft:air
fill 22 56 -312 26 56 -312 minecraft:water[level=0]
setblock 48 56 -312 minecraft:air
fill 23 56 -313 26 56 -313 minecraft:water[level=0]
setblock 43 56 -313 minecraft:water[level=0]
setblock 48 56 -313 minecraft:air
fill 23 56 -314 26 56 -314 minecraft:water[level=0]
fill 42 56 -314 46 56 -314 minecraft:water[level=0]
fill 21 56 -315 26 56 -315 minecraft:water[level=0]
fill 41 56 -315 46 56 -315 minecraft:water[level=0]
fill 19 56 -316 26 56 -316 minecraft:water[level=0]
fill 41 56 -316 46 56 -316 minecraft:water[level=0]
fill 18 56 -317 26 56 -317 minecraft:water[level=0]
fill 41 56 -317 45 56 -317 minecraft:water[level=0]
fill 17 56 -318 26 56 -318 minecraft:water[level=0]
fill 41 56 -318 45 56 -318 minecraft:water[level=0]
setblock 67 55 -260 minecraft:air
setblock 68 55 -261 minecraft:air
setblock 68 55 -262 minecraft:air
fill 68 55 -263 69 55 -263 minecraft:air
fill 68 55 -264 70 55 -264 minecraft:air
fill 68 55 -265 70 55 -265 minecraft:air
fill 69 55 -266 71 55 -266 minecraft:air
fill 69 55 -267 71 55 -267 minecraft:air
fill 69 55 -268 71 55 -268 minecraft:air
fill 70 55 -269 71 55 -269 minecraft:air
fill 70 55 -270 71 55 -270 minecraft:air
setblock 71 55 -271 minecraft:air
setblock 71 55 -272 minecraft:air
setblock 71 55 -273 minecraft:air
fill 70 55 -286 71 55 -286 minecraft:water[level=0]
fill 69 55 -287 71 55 -287 minecraft:water[level=0]
fill 68 55 -288 71 55 -288 minecraft:water[level=0]
fill 67 55 -289 71 55 -289 minecraft:water[level=0]
fill 67 55 -290 71 55 -290 minecraft:water[level=0]
fill 67 55 -291 71 55 -291 minecraft:water[level=0]
fill 67 55 -292 71 55 -292 minecraft:water[level=0]
fill 69 55 -293 71 55 -293 minecraft:water[level=0]
fill 69 55 -294 71 55 -294 minecraft:water[level=0]
fill 68 55 -295 71 55 -295 minecraft:water[level=0]
fill 67 55 -296 71 55 -296 minecraft:water[level=0]
fill 68 55 -297 71 55 -297 minecraft:water[level=0]
fill 69 55 -298 71 55 -298 minecraft:water[level=0]
setblock 70 55 -299 minecraft:water[level=0]
fill 51 55 -302 56 55 -302 minecraft:water[level=0]
fill 50 55 -303 56 55 -303 minecraft:water[level=0]
setblock 27 55 -304 minecraft:water[level=0]
fill 49 55 -304 56 55 -304 minecraft:water[level=0]
fill 26 55 -305 29 55 -305 minecraft:water[level=0]
fill 48 55 -305 54 55 -305 minecraft:water[level=0]
fill 26 55 -306 29 55 -306 minecraft:water[level=0]
fill 48 55 -306 52 55 -306 minecraft:water[level=0]
setblock 22 55 -307 minecraft:water[level=0]
fill 25 55 -307 28 55 -307 minecraft:water[level=0]
fill 47 55 -307 51 55 -307 minecraft:water[level=0]
fill 21 55 -308 23 55 -308 minecraft:water[level=0]
fill 25 55 -308 28 55 -308 minecraft:water[level=0]
fill 47 55 -308 51 55 -308 minecraft:water[level=0]
fill 21 55 -309 24 55 -309 minecraft:water[level=0]
fill 46 55 -309 50 55 -309 minecraft:water[level=0]
fill 21 55 -310 25 55 -310 minecraft:water[level=0]
fill 46 55 -310 49 55 -310 minecraft:water[level=0]
fill 22 55 -311 26 55 -311 minecraft:water[level=0]
fill 22 55 -312 26 55 -312 minecraft:water[level=0]
fill 22 55 -313 26 55 -313 minecraft:water[level=0]
fill 43 55 -313 45 55 -313 minecraft:water[level=0]
fill 22 55 -314 26 55 -314 minecraft:water[level=0]
fill 42 55 -314 46 55 -314 minecraft:water[level=0]
fill 22 55 -315 26 55 -315 minecraft:water[level=0]
fill 42 55 -315 46 55 -315 minecraft:water[level=0]
fill 22 55 -316 26 55 -316 minecraft:water[level=0]
fill 42 55 -316 45 55 -316 minecraft:water[level=0]
fill 18 55 -317 26 55 -317 minecraft:water[level=0]
fill 41 55 -317 45 55 -317 minecraft:water[level=0]
fill 17 55 -318 26 55 -318 minecraft:water[level=0]
fill 41 55 -318 45 55 -318 minecraft:water[level=0]
setblock 65 54 -257 minecraft:air
setblock 66 54 -258 minecraft:air
fill 66 54 -259 67 54 -259 minecraft:air
fill 66 54 -260 67 54 -260 minecraft:air
fill 66 54 -261 68 54 -261 minecraft:air
fill 67 54 -262 69 54 -262 minecraft:air
fill 67 54 -263 69 54 -263 minecraft:air
fill 67 54 -264 70 54 -264 minecraft:air
fill 68 54 -265 70 54 -265 minecraft:air
fill 69 54 -266 71 54 -266 minecraft:air
fill 69 54 -267 71 54 -267 minecraft:air
fill 70 54 -268 71 54 -268 minecraft:air
fill 70 54 -269 71 54 -269 minecraft:air
setblock 71 54 -270 minecraft:air
setblock 71 54 -271 minecraft:air
setblock 71 54 -272 minecraft:air
setblock 71 54 -286 minecraft:water[level=0]
fill 70 54 -287 71 54 -287 minecraft:water[level=0]
fill 69 54 -288 71 54 -288 minecraft:water[level=0]
fill 67 54 -289 71 54 -289 minecraft:water[level=0]
fill 67 54 -290 71 54 -290 minecraft:water[level=0]
fill 67 54 -291 71 54 -291 minecraft:water[level=0]
fill 67 54 -292 71 54 -292 minecraft:water[level=0]
fill 67 54 -293 71 54 -293 minecraft:water[level=0]
fill 69 54 -294 71 54 -294 minecraft:water[level=0]
fill 68 54 -295 71 54 -295 minecraft:water[level=0]
fill 67 54 -296 71 54 -296 minecraft:water[level=0]
fill 69 54 -297 70 54 -297 minecraft:water[level=0]
fill 51 54 -303 52 54 -303 minecraft:water[level=0]
fill 50 54 -304 53 54 -304 minecraft:water[level=0]
fill 26 54 -305 29 54 -305 minecraft:water[level=0]
fill 49 54 -305 52 54 -305 minecraft:water[level=0]
fill 26 54 -306 29 54 -306 minecraft:water[level=0]
fill 49 54 -306 51 54 -306 minecraft:water[level=0]
fill 25 54 -307 28 54 -307 minecraft:water[level=0]
fill 49 54 -307 50 54 -307 minecraft:water[level=0]
fill 24 54 -308 28 54 -308 minecraft:water[level=0]
fill 22 54 -309 23 54 -309 minecraft:water[level=0]
fill 22 54 -310 25 54 -310 minecraft:water[level=0]
fill 22 54 -311 25 54 -311 minecraft:water[level=0]
fill 22 54 -312 26 54 -312 minecraft:water[level=0]
fill 23 54 -313 26 54 -313 minecraft:water[level=0]
fill 23 54 -314 26 54 -314 minecraft:water[level=0]
fill 23 54 -315 26 54 -315 minecraft:water[level=0]
fill 23 54 -316 26 54 -316 minecraft:water[level=0]
fill 22 54 -317 26 54 -317 minecraft:water[level=0]
fill 42 54 -317 43 54 -317 minecraft:water[level=0]
fill 17 54 -318 26 54 -318 minecraft:water[level=0]
fill 42 54 -318 43 54 -318 minecraft:water[level=0]
fill 63 53 -255 64 53 -255 minecraft:air
fill 63 53 -256 65 53 -256 minecraft:air
fill 64 53 -257 65 53 -257 minecraft:air
fill 64 53 -258 66 53 -258 minecraft:air
fill 64 53 -259 67 53 -259 minecraft:air
fill 65 53 -260 68 53 -260 minecraft:air
fill 66 53 -261 68 53 -261 minecraft:air
fill 66 53 -262 69 53 -262 minecraft:air
fill 67 53 -263 70 53 -263 minecraft:air
fill 68 53 -264 70 53 -264 minecraft:air
fill 68 53 -265 71 53 -265 minecraft:air
fill 69 53 -266 71 53 -266 minecraft:air
fill 70 53 -267 71 53 -267 minecraft:air
fill 70 53 -268 71 53 -268 minecraft:air
fill 70 53 -269 71 53 -269 minecraft:air
setblock 71 53 -270 minecraft:air
setblock 71 53 -271 minecraft:air
setblock 71 53 -286 minecraft:water[level=0]
fill 70 53 -287 71 53 -287 minecraft:water[level=0]
fill 70 53 -288 71 53 -288 minecraft:water[level=0]
fill 68 53 -289 71 53 -289 minecraft:water[level=0]
fill 67 53 -290 71 53 -290 minecraft:water[level=0]
fill 67 53 -291 71 53 -291 minecraft:water[level=0]
fill 67 53 -292 71 53 -292 minecraft:water[level=0]
fill 67 53 -293 71 53 -293 minecraft:water[level=0]
fill 69 53 -294 71 53 -294 minecraft:water[level=0]
setblock 68 53 -295 minecraft:water[level=0]
fill 70 53 -295 71 53 -295 minecraft:water[level=0]
fill 68 53 -296 69 53 -296 minecraft:water[level=0]
fill 26 53 -305 29 53 -305 minecraft:water[level=0]
fill 26 53 -306 29 53 -306 minecraft:water[level=0]
fill 25 53 -307 28 53 -307 minecraft:water[level=0]
fill 24 53 -308 28 53 -308 minecraft:water[level=0]
fill 26 53 -309 27 53 -309 minecraft:water[level=0]
fill 24 53 -313 25 53 -313 minecraft:water[level=0]
fill 23 53 -314 25 53 -314 minecraft:water[level=0]
fill 23 53 -315 25 53 -315 minecraft:water[level=0]
fill 23 53 -316 26 53 -316 minecraft:water[level=0]
fill 23 53 -317 26 53 -317 minecraft:water[level=0]
fill 17 53 -318 20 53 -318 minecraft:water[level=0]
fill 23 53 -318 26 53 -318 minecraft:water[level=0]
fill 61 52 -255 64 52 -255 minecraft:air
fill 61 52 -256 65 52 -256 minecraft:air
fill 62 52 -257 66 52 -257 minecraft:air
fill 63 52 -258 66 52 -258 minecraft:air
fill 64 52 -259 67 52 -259 minecraft:air
fill 65 52 -260 67 52 -260 minecraft:air
fill 66 52 -261 68 52 -261 minecraft:air
fill 67 52 -262 68 52 -262 minecraft:air
fill 67 52 -263 69 52 -263 minecraft:air
fill 68 52 -264 69 52 -264 minecraft:air
fill 69 52 -265 70 52 -265 minecraft:air
fill 69 52 -266 70 52 -266 minecraft:air
fill 70 52 -267 71 52 -267 minecraft:air
fill 70 52 -268 71 52 -268 minecraft:air
setblock 71 52 -269 minecraft:air
setblock 71 52 -270 minecraft:air
setblock 71 52 -286 minecraft:water[level=0]
setblock 71 52 -287 minecraft:water[level=0]
fill 70 52 -288 71 52 -288 minecraft:water[level=0]
fill 69 52 -289 71 52 -289 minecraft:water[level=0]
fill 68 52 -290 71 52 -290 minecraft:water[level=0]
fill 67 52 -291 71 52 -291 minecraft:water[level=0]
fill 67 52 -292 71 52 -292 minecraft:water[level=0]
fill 67 52 -293 71 52 -293 minecraft:water[level=0]
fill 67 52 -294 69 52 -294 minecraft:water[level=0]
setblock 71 52 -295 minecraft:water[level=0]
setblock 71 52 -298 minecraft:water[level=0]
fill 26 52 -305 27 52 -305 minecraft:water[level=0]
fill 26 52 -306 30 52 -306 minecraft:water[level=0]
fill 25 52 -307 29 52 -307 minecraft:water[level=0]
fill 24 52 -308 28 52 -308 minecraft:water[level=0]
fill 24 52 -309 27 52 -309 minecraft:water[level=0]
fill 61 51 -255 63 51 -255 minecraft:air
fill 62 51 -256 64 51 -256 minecraft:air
fill 63 51 -257 65 51 -257 minecraft:air
fill 64 51 -258 65 51 -258 minecraft:air
fill 65 51 -259 66 51 -259 minecraft:air
setblock 66 51 -260 minecraft:air
fill 66 51 -261 67 51 -261 minecraft:air
setblock 67 51 -262 minecraft:air
setblock 68 51 -263 minecraft:air
setblock 69 51 -265 minecraft:air
setblock 70 51 -266 minecraft:air
setblock 70 51 -267 minecraft:air
setblock 71 51 -268 minecraft:air
setblock 71 51 -269 minecraft:air
setblock 71 51 -287 minecraft:water[level=0]
setblock 71 51 -288 minecraft:water[level=0]
fill 70 51 -289 71 51 -289 minecraft:water[level=0]
fill 69 51 -290 71 51 -290 minecraft:water[level=0]
fill 67 51 -291 71 51 -291 minecraft:water[level=0]
fill 66 51 -292 71 51 -292 minecraft:water[level=0]
fill 67 51 -293 71 51 -293 minecraft:water[level=0]
fill 67 51 -294 69 51 -294 minecraft:water[level=0]
setblock 71 51 -294 minecraft:water[level=0]
fill 70 51 -295 71 51 -295 minecraft:water[level=0]
fill 70 51 -296 71 51 -296 minecraft:water[level=0]
setblock 71 51 -297 minecraft:water[level=0]
setblock 26 51 -305 minecraft:water[level=0]
fill 26 51 -306 29 51 -306 minecraft:water[level=0]
fill 25 51 -307 29 51 -307 minecraft:water[level=0]
fill 24 51 -308 28 51 -308 minecraft:water[level=0]
fill 24 51 -309 27 51 -309 minecraft:water[level=0]
setblock 26 51 -310 minecraft:water[level=0]
fill 61 50 -255 62 50 -255 minecraft:air
setblock 62 50 -256 minecraft:air
fill 49 50 -257 50 50 -257 minecraft:cave_air
setblock 63 50 -257 minecraft:air
fill 49 50 -258 51 50 -258 minecraft:cave_air
fill 49 50 -259 51 50 -259 minecraft:cave_air
fill 49 50 -260 51 50 -260 minecraft:cave_air
setblock 50 50 -261 minecraft:cave_air
fill 48 50 -262 50 50 -262 minecraft:cave_air
setblock 49 50 -263 minecraft:cave_air
setblock 71 50 -269 minecraft:air
setblock 71 50 -287 minecraft:water[level=0]
setblock 71 50 -288 minecraft:water[level=0]
fill 70 50 -289 71 50 -289 minecraft:water[level=0]
fill 69 50 -290 71 50 -290 minecraft:water[level=0]
fill 68 50 -291 71 50 -291 minecraft:water[level=0]
fill 66 50 -292 71 50 -292 minecraft:water[level=0]
fill 67 50 -293 71 50 -293 minecraft:water[level=0]
fill 67 50 -294 71 50 -294 minecraft:water[level=0]
fill 68 50 -295 69 50 -295 minecraft:water[level=0]
setblock 71 50 -295 minecraft:water[level=0]
setblock 71 50 -296 minecraft:water[level=0]
fill 26 50 -306 28 50 -306 minecraft:water[level=0]
fill 25 50 -307 29 50 -307 minecraft:water[level=0]
fill 24 50 -308 28 50 -308 minecraft:water[level=0]
fill 24 50 -309 27 50 -309 minecraft:water[level=0]
fill 25 50 -310 26 50 -310 minecraft:water[level=0]
setblock 50 49 -255 minecraft:cave_air
fill 49 49 -256 51 49 -256 minecraft:cave_air
fill 49 49 -257 51 49 -257 minecraft:cave_air
fill 48 49 -258 55 49 -258 minecraft:cave_air
fill 48 49 -259 55 49 -259 minecraft:cave_air
fill 48 49 -260 58 49 -260 minecraft:cave_air
fill 48 49 -261 59 49 -261 minecraft:cave_air
fill 47 49 -262 59 49 -262 minecraft:cave_air
fill 48 49 -263 59 49 -263 minecraft:cave_air
fill 50 49 -264 58 49 -264 minecraft:cave_air
fill 51 49 -265 56 49 -265 minecraft:cave_air
fill 52 49 -266 56 49 -266 minecraft:cave_air
setblock 70 49 -288 minecraft:water[level=0]
setblock 71 49 -288 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=true,west=false]
setblock 71 49 -289 minecraft:water[level=0]
fill 70 49 -290 71 49 -290 minecraft:water[level=0]
fill 69 49 -291 71 49 -291 minecraft:water[level=0]
fill 68 49 -292 71 49 -292 minecraft:water[level=0]
fill 67 49 -293 71 49 -293 minecraft:water[level=0]
fill 67 49 -294 71 49 -294 minecraft:water[level=0]
fill 67 49 -295 70 49 -295 minecraft:water[level=0]
fill 67 49 -296 68 49 -296 minecraft:water[level=0]
setblock 26 49 -306 minecraft:water[level=0]
fill 25 49 -307 29 49 -307 minecraft:water[level=0]
fill 24 49 -308 28 49 -308 minecraft:water[level=0]
fill 24 49 -309 27 49 -309 minecraft:water[level=0]
fill 24 49 -310 26 49 -310 minecraft:water[level=0]
fill 57 49 -313 58 49 -313 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 57 49 -314 58 49 -314 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 65 49 -318 66 49 -318 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 49 48 -255 50 48 -255 minecraft:cave_air
fill 49 48 -256 51 48 -256 minecraft:cave_air
fill 48 48 -257 53 48 -257 minecraft:cave_air
fill 48 48 -258 55 48 -258 minecraft:cave_air
fill 48 48 -259 58 48 -259 minecraft:cave_air
fill 48 48 -260 59 48 -260 minecraft:cave_air
fill 47 48 -261 59 48 -261 minecraft:cave_air
fill 47 48 -262 59 48 -262 minecraft:cave_air
fill 47 48 -263 59 48 -263 minecraft:cave_air
fill 47 48 -264 59 48 -264 minecraft:cave_air
fill 48 48 -265 57 48 -265 minecraft:cave_air
fill 49 48 -266 57 48 -266 minecraft:cave_air
fill 52 48 -267 55 48 -267 minecraft:cave_air
setblock 70 48 -286 minecraft:water[level=0]
fill 69 48 -287 70 48 -287 minecraft:water[level=0]
fill 68 48 -288 71 48 -288 minecraft:water[level=0]
fill 68 48 -289 71 48 -289 minecraft:water[level=0]
fill 70 48 -290 71 48 -290 minecraft:water[level=0]
fill 70 48 -291 71 48 -291 minecraft:water[level=0]
fill 69 48 -292 71 48 -292 minecraft:water[level=0]
fill 67 48 -293 71 48 -293 minecraft:water[level=0]
fill 67 48 -294 71 48 -294 minecraft:water[level=0]
fill 67 48 -295 71 48 -295 minecraft:water[level=0]
fill 67 48 -296 70 48 -296 minecraft:water[level=0]
setblock 68 48 -297 minecraft:water[level=0]
setblock 26 48 -306 minecraft:water[level=0]
fill 25 48 -307 28 48 -307 minecraft:water[level=0]
fill 24 48 -308 28 48 -308 minecraft:water[level=0]
fill 24 48 -309 27 48 -309 minecraft:water[level=0]
fill 23 48 -310 26 48 -310 minecraft:water[level=0]
setblock 25 48 -311 minecraft:water[level=0]
fill 65 48 -318 66 48 -318 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 49 47 -256 51 47 -256 minecraft:lava[level=0]
fill 49 47 -257 51 47 -257 minecraft:lava[level=0]
fill 49 47 -258 54 47 -258 minecraft:lava[level=0]
fill 49 47 -259 55 47 -259 minecraft:lava[level=0]
fill 49 47 -260 58 47 -260 minecraft:lava[level=0]
fill 48 47 -261 59 47 -261 minecraft:lava[level=0]
fill 47 47 -262 59 47 -262 minecraft:lava[level=0]
fill 48 47 -263 59 47 -263 minecraft:lava[level=0]
fill 48 47 -264 58 47 -264 minecraft:lava[level=0]
fill 49 47 -265 57 47 -265 minecraft:lava[level=0]
fill 52 47 -266 56 47 -266 minecraft:lava[level=0]
setblock 69 47 -288 minecraft:water[level=0]
setblock 70 47 -292 minecraft:water[level=0]
fill 69 47 -293 71 47 -293 minecraft:water[level=0]
fill 67 47 -294 71 47 -294 minecraft:water[level=0]
fill 67 47 -295 71 47 -295 minecraft:water[level=0]
fill 67 47 -296 71 47 -296 minecraft:water[level=0]
fill 67 47 -297 71 47 -297 minecraft:water[level=0]
fill 68 47 -298 69 47 -298 minecraft:water[level=0]
setblock 26 47 -307 minecraft:water[level=0]
fill 25 47 -308 29 47 -308 minecraft:water[level=0]
fill 24 47 -309 27 47 -309 minecraft:water[level=0]
fill 23 47 -310 26 47 -310 minecraft:water[level=0]
fill 24 47 -311 25 47 -311 minecraft:water[level=0]
setblock 50 46 -258 minecraft:lava[level=0]
setblock 50 46 -259 minecraft:lava[level=0]
fill 48 46 -262 50 46 -262 minecraft:lava[level=0]
setblock 49 46 -263 minecraft:lava[level=0]
fill 29 46 -264 30 46 -264 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 29 46 -265 30 46 -265 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 71 46 -286 minecraft:air
setblock 71 46 -287 minecraft:air
setblock 71 46 -288 minecraft:air
setblock 70 46 -293 minecraft:water[level=0]
fill 69 46 -294 71 46 -294 minecraft:water[level=0]
fill 68 46 -295 71 46 -295 minecraft:water[level=0]
fill 67 46 -296 71 46 -296 minecraft:water[level=0]
fill 67 46 -297 71 46 -297 minecraft:water[level=0]
fill 67 46 -298 71 46 -298 minecraft:water[level=0]
fill 68 46 -299 71 46 -299 minecraft:water[level=0]
fill 68 46 -300 69 46 -300 minecraft:water[level=0]
fill 26 46 -308 27 46 -308 minecraft:water[level=0]
fill 25 46 -309 28 46 -309 minecraft:water[level=0]
fill 24 46 -310 27 46 -310 minecraft:water[level=0]
fill 23 46 -311 26 46 -311 minecraft:water[level=0]
setblock 25 46 -312 minecraft:water[level=0]
setblock 71 45 -287 minecraft:air
setblock 71 45 -288 minecraft:air
setblock 71 45 -294 minecraft:water[level=0]
fill 70 45 -295 71 45 -295 minecraft:water[level=0]
fill 69 45 -296 71 45 -296 minecraft:water[level=0]
fill 67 45 -297 71 45 -297 minecraft:water[level=0]
fill 67 45 -298 71 45 -298 minecraft:water[level=0]
fill 67 45 -299 71 45 -299 minecraft:water[level=0]
fill 68 45 -300 71 45 -300 minecraft:water[level=0]
fill 68 45 -301 71 45 -301 minecraft:water[level=0]
fill 69 45 -302 70 45 -302 minecraft:water[level=0]
fill 26 45 -309 28 45 -309 minecraft:water[level=0]
fill 25 45 -310 28 45 -310 minecraft:water[level=0]
fill 24 45 -311 27 45 -311 minecraft:water[level=0]
fill 24 45 -312 26 45 -312 minecraft:water[level=0]
forceload remove 8 -318 71 -255
tellraw @a {"text":"Campus zurueck a15 fertig.","color":"green"}
