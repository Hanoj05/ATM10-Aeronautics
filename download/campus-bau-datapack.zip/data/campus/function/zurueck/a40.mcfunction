# Abschnitt a40: x 264..327, z -126..-63 (9860 Blöcke)
forceload add 264 -126 327 -63
tellraw @a {"text":"Campus zurueck a40: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a40_1 2s
