# Abschnitt a36: x 8..71, z -126..-63 (1551 Blöcke)
forceload add 8 -126 71 -63
tellraw @a {"text":"Campus zurueck a36: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a36_1 2s
