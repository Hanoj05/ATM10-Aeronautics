setblock 72 81 -145 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 72 81 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 81 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 72 81 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 75 81 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 76 81 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 81 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 115 81 -174 116 81 -174 minecraft:air
fill 113 81 -175 114 81 -175 minecraft:air
setblock 116 81 -175 minecraft:air
fill 111 81 -176 112 81 -176 minecraft:air
setblock 116 81 -176 minecraft:air
fill 109 81 -177 110 81 -177 minecraft:air
setblock 116 81 -177 minecraft:air
fill 107 81 -178 108 81 -178 minecraft:air
setblock 116 81 -178 minecraft:air
fill 105 81 -179 106 81 -179 minecraft:air
setblock 116 81 -179 minecraft:air
fill 102 81 -180 104 81 -180 minecraft:air
setblock 116 81 -180 minecraft:air
fill 100 81 -181 101 81 -181 minecraft:air
setblock 116 81 -181 minecraft:air
fill 98 81 -182 99 81 -182 minecraft:air
setblock 117 81 -182 minecraft:air
fill 96 81 -183 97 81 -183 minecraft:air
setblock 117 81 -183 minecraft:air
fill 94 81 -184 95 81 -184 minecraft:air
setblock 117 81 -184 minecraft:air
fill 72 81 -185 73 81 -185 minecraft:air
fill 92 81 -185 93 81 -185 minecraft:air
setblock 117 81 -185 minecraft:air
fill 74 81 -186 77 81 -186 minecraft:air
fill 90 81 -186 91 81 -186 minecraft:air
setblock 117 81 -186 minecraft:air
fill 78 81 -187 81 81 -187 minecraft:air
fill 88 81 -187 89 81 -187 minecraft:air
setblock 117 81 -187 minecraft:air
fill 82 81 -188 84 81 -188 minecraft:air
fill 86 81 -188 87 81 -188 minecraft:air
setblock 117 81 -188 minecraft:air
setblock 85 81 -189 minecraft:air
setblock 117 81 -189 minecraft:air
setblock 117 81 -190 minecraft:air
setblock 72 80 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 80 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 80 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 80 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 80 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 75 80 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 80 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 80 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 80 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 115 80 -174 116 80 -174 minecraft:white_concrete
fill 113 80 -175 114 80 -175 minecraft:white_concrete
setblock 116 80 -175 minecraft:white_concrete
fill 111 80 -176 112 80 -176 minecraft:white_concrete
setblock 116 80 -176 minecraft:white_concrete
fill 109 80 -177 110 80 -177 minecraft:white_concrete
setblock 116 80 -177 minecraft:white_concrete
fill 107 80 -178 108 80 -178 minecraft:white_concrete
setblock 116 80 -178 minecraft:white_concrete
fill 105 80 -179 106 80 -179 minecraft:white_concrete
setblock 116 80 -179 minecraft:white_concrete
fill 102 80 -180 104 80 -180 minecraft:white_concrete
setblock 116 80 -180 minecraft:white_concrete
fill 100 80 -181 101 80 -181 minecraft:white_concrete
setblock 116 80 -181 minecraft:white_concrete
fill 98 80 -182 99 80 -182 minecraft:white_concrete
setblock 117 80 -182 minecraft:white_concrete
fill 96 80 -183 97 80 -183 minecraft:white_concrete
setblock 117 80 -183 minecraft:white_concrete
fill 94 80 -184 95 80 -184 minecraft:white_concrete
setblock 117 80 -184 minecraft:white_concrete
fill 72 80 -185 73 80 -185 minecraft:white_concrete
fill 92 80 -185 93 80 -185 minecraft:white_concrete
setblock 117 80 -185 minecraft:white_concrete
fill 74 80 -186 77 80 -186 minecraft:white_concrete
fill 90 80 -186 91 80 -186 minecraft:white_concrete
setblock 117 80 -186 minecraft:white_concrete
fill 78 80 -187 81 80 -187 minecraft:white_concrete
fill 88 80 -187 89 80 -187 minecraft:white_concrete
setblock 117 80 -187 minecraft:white_concrete
fill 82 80 -188 84 80 -188 minecraft:white_concrete
fill 86 80 -188 87 80 -188 minecraft:white_concrete
setblock 117 80 -188 minecraft:white_concrete
setblock 85 80 -189 minecraft:white_concrete
setblock 117 80 -189 minecraft:white_concrete
setblock 117 80 -190 minecraft:white_concrete
setblock 72 79 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 79 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 79 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 79 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 75 79 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 79 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 79 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 79 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 79 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 75 79 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 79 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 77 79 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 75 79 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 79 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 79 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 79 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 79 -156 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 97 79 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 96 79 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 97 79 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 78 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 78 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 78 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 78 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 78 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 78 -146 minecraft:birch_log[axis=y]
setblock 73 78 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 74 78 -146 75 78 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 78 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 77 78 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 78 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 73 78 -147 74 78 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 75 78 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 76 78 -147 minecraft:birch_log[axis=y]
setblock 77 78 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 78 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 78 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 75 78 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 78 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 77 78 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 78 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 78 -149 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 116 78 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 117 78 -150 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 95 78 -151 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 77 78 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 78 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 78 -152 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 102 78 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 78 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 78 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 78 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 78 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 78 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 97 78 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 78 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 78 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 97 78 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 78 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 77 -129 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 77 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 77 -130 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 77 -131 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 129 77 -132 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 128 77 -133 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 129 77 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 130 77 -133 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 129 77 -134 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 84 77 -136 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 109 77 -136 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 84 77 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 108 77 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 109 77 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 77 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 96 77 -138 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 112 77 -138 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 95 77 -139 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 96 77 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 112 77 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 77 -140 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 123 77 -140 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 123 77 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 77 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 110 77 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 77 -145 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 72 77 -146 minecraft:birch_log[axis=y]
setblock 79 77 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 76 77 -147 minecraft:birch_log[axis=y]
fill 78 77 -147 79 77 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 80 77 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 104 77 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 77 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 77 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 77 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 77 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 77 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 77 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 102 77 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 77 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 77 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 77 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 77 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 94 77 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 77 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 77 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 101 77 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 102 77 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 77 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 77 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 77 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 102 77 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 77 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 77 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 77 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 77 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 77 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 77 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 77 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 77 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 77 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 77 -156 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 88 77 -157 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 132 77 -157 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 133 77 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 87 77 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 88 77 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 89 77 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 96 77 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 97 77 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 77 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 77 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 77 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 98 77 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 76 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 76 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 76 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 76 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 76 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 76 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 76 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 76 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 76 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 76 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 76 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 76 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 76 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 76 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 76 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 108 76 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 76 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 76 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 76 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 76 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 76 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 112 76 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 76 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 111 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 112 76 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 76 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 112 76 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 76 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 76 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 76 -142 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 123 76 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 76 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 76 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 76 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 76 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 76 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 76 -146 minecraft:birch_log[axis=y]
setblock 79 76 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 76 -147 minecraft:birch_log[axis=y]
setblock 78 76 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 76 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 76 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 76 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 115 76 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 116 76 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 76 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 76 -148 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 92 76 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 104 76 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 76 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 92 76 -149 93 76 -149 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 103 76 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 104 76 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 105 76 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 76 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 76 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 76 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 76 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 104 76 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 76 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 76 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 76 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 76 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 76 -151 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 94 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 76 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 101 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 102 76 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 76 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 76 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 76 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 76 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 76 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 76 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 94 76 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 76 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 76 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 76 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 76 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 103 76 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 76 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 76 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 76 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 76 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 76 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 76 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 76 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 76 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 101 76 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 102 76 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 76 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 76 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 74 76 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 75 76 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 83 76 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 76 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 76 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 76 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 76 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 84 76 -155 minecraft:birch_log[axis=y]
setblock 85 76 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 76 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 76 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 76 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 76 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 76 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 76 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 76 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 97 76 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 76 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 76 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 76 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 87 76 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 76 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 89 76 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 76 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 76 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 98 76 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 76 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 76 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 97 76 -159 minecraft:birch_log[axis=y]
setblock 98 76 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 99 76 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 75 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 75 -128 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 109 75 -128 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 110 75 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 75 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 75 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 75 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 75 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 75 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 75 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 75 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 75 -130 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 92 75 -130 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 93 75 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 75 -130 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 81 75 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 75 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 75 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 75 -131 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 85 75 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 75 -131 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 128 75 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 75 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 75 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 75 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 75 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 130 75 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 75 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 75 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 75 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 75 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 75 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 75 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 108 75 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 75 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 75 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 75 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 75 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 75 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 75 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 75 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 110 75 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 75 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 75 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 75 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 75 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 108 75 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 110 75 -138 111 75 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 112 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 75 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 75 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 80 75 -139 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 95 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 75 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 97 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 112 75 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 113 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 75 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 75 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 96 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 75 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 111 75 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 112 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 75 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 75 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 75 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 75 -141 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 75 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 75 -141 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 90 75 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 75 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 75 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 75 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 75 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 75 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 75 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 75 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 109 75 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 75 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 75 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 75 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 89 75 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 109 75 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 75 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 75 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 75 -145 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 109 75 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 75 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 75 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 75 -146 minecraft:birch_log[axis=y]
setblock 78 75 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 75 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 75 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 75 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 75 -147 minecraft:birch_log[axis=y]
setblock 78 75 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 75 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 75 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 75 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 115 75 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 75 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 75 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 75 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 75 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 75 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 75 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 75 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 75 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 103 75 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 104 75 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 105 75 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 75 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 92 75 -149 93 75 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 103 75 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 104 75 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 105 75 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 75 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 75 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 75 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 75 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 75 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 75 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 75 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 104 75 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 105 75 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 75 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 75 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 75 -150 minecraft:birch_log[axis=y]
setblock 117 75 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 75 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 75 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 75 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 75 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 94 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 75 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 75 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 103 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 75 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 75 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 75 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 75 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 77 75 -152 minecraft:birch_log[axis=y]
setblock 78 75 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 75 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 75 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 75 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 95 75 -152 minecraft:birch_log[axis=y]
setblock 96 75 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 97 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 75 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 102 75 -152 minecraft:birch_log[axis=y]
setblock 103 75 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 104 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 75 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 75 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 75 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 78 75 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 75 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 94 75 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 75 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 75 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 75 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 75 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 103 75 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 75 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 74 75 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 75 75 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 75 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 75 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 75 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 75 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 75 -155 minecraft:birch_log[axis=y]
setblock 132 75 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 75 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 75 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 87 75 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 75 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 89 75 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 132 75 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 75 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 134 75 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 75 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 75 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 89 75 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 75 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 75 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 75 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 97 75 -159 minecraft:birch_log[axis=y]
setblock 95 74 -127 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 110 74 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 111 74 -127 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 117 74 -127 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 74 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 74 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 74 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 74 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 74 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 74 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 74 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 74 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 74 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 74 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 74 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 74 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 74 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 80 74 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 74 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 82 74 -130 minecraft:birch_log[axis=y]
setblock 83 74 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 84 74 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 74 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 74 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 74 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 74 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 74 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 74 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 74 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 74 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 74 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 74 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 74 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 74 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 74 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 74 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 74 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 74 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 74 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 130 74 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 74 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 74 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 129 74 -133 minecraft:birch_log[axis=y]
setblock 130 74 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 131 74 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 74 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 74 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 130 74 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 74 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 74 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 74 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 74 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 74 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 74 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 74 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 74 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 110 74 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 74 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 74 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 84 74 -137 minecraft:birch_log[axis=y]
setblock 85 74 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 74 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 74 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 74 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 74 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 109 74 -137 minecraft:birch_log[axis=y]
setblock 110 74 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 111 74 -137 112 74 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 74 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 74 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 74 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 74 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 74 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 74 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 97 74 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 74 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 74 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 110 74 -138 111 74 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 112 74 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 113 74 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 74 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 74 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 74 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 74 -139 minecraft:birch_log[axis=y]
setblock 97 74 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 98 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 109 74 -139 110 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 74 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 112 74 -139 minecraft:birch_log[axis=y]
setblock 113 74 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 114 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 74 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 74 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 90 74 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 74 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 74 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 97 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 112 74 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 113 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 74 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 74 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 74 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 90 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 74 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 92 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 112 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 74 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 123 74 -141 minecraft:birch_log[axis=y]
setblock 124 74 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 74 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 90 74 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 74 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 74 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 74 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 74 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 74 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 123 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 89 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 108 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 74 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 110 74 -144 minecraft:birch_log[axis=y]
setblock 111 74 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 112 74 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 74 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 119 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 74 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 79 74 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 74 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 74 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 74 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 74 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 74 -146 minecraft:birch_log[axis=y]
setblock 78 74 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 74 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 74 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 74 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 74 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 74 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 74 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 74 -147 minecraft:birch_log[axis=y]
fill 77 74 -147 78 74 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 74 -147 minecraft:birch_log[axis=y]
setblock 80 74 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 81 74 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 74 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 74 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 74 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 104 74 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 74 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 74 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 74 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 74 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 74 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 104 74 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 105 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 74 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 74 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 74 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 74 -148 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 79 74 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 74 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 92 74 -149 93 74 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 74 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 102 74 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 74 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 104 74 -149 minecraft:birch_log[axis=y]
setblock 105 74 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 106 74 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 117 74 -149 118 74 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 74 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 94 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 104 74 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 105 74 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 74 -150 minecraft:birch_log[axis=y]
setblock 82 74 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 74 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 74 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 74 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 104 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 74 -152 minecraft:birch_log[axis=y]
setblock 82 74 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 74 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 84 74 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 74 -152 minecraft:birch_log[axis=y]
setblock 102 74 -152 minecraft:birch_log[axis=y]
setblock 73 74 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 74 74 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 75 74 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 74 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 74 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 74 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 74 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 74 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 75 74 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 74 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 74 74 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 75 74 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 74 -155 minecraft:birch_log[axis=y]
setblock 108 74 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 109 74 -155 110 74 -155 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 133 74 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 74 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 74 -156 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 110 74 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 111 74 -156 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 132 74 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 74 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 134 74 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 74 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 74 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 89 74 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 74 -157 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 98 74 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 74 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 74 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 133 74 -157 minecraft:birch_log[axis=y]
setblock 134 74 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 74 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 74 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 74 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 88 74 -158 minecraft:birch_log[axis=y]
setblock 89 74 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 90 74 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 74 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 74 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 98 74 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 132 74 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 74 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 134 74 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 74 -159 minecraft:birch_log[axis=y]
setblock 133 74 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 73 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 73 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 101 73 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 73 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 73 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 73 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 73 -127 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 117 73 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 73 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 73 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 73 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 73 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 73 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 73 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 73 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 73 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 73 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 73 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 73 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 73 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 101 73 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 73 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 73 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 73 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 73 -129 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 73 -130 minecraft:birch_log[axis=y]
setblock 84 73 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 73 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 73 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 73 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 73 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 94 73 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 73 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 73 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 101 73 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 73 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 73 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 73 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 73 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 73 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 73 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 73 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 73 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 86 73 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 106 73 -132 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 107 73 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 107 73 -133 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 129 73 -133 minecraft:birch_log[axis=y]
setblock 123 73 -135 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 124 73 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 98 73 -136 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 84 73 -137 minecraft:birch_log[axis=y]
setblock 97 73 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 98 73 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 73 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 109 73 -137 minecraft:birch_log[axis=y]
setblock 78 73 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 73 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 73 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 98 73 -138 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 78 73 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 73 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 73 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 73 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 73 -139 minecraft:birch_log[axis=y]
setblock 112 73 -139 minecraft:birch_log[axis=y]
setblock 78 73 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 73 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 80 73 -140 81 73 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 73 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 73 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 90 73 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 73 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 92 73 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 73 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 73 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 73 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 89 73 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 90 73 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 91 73 -141 minecraft:birch_log[axis=y]
setblock 92 73 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 73 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 73 -141 minecraft:birch_log[axis=y]
setblock 81 73 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 73 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 90 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 73 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 92 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 73 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 89 73 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 73 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 119 73 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 87 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 73 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 89 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 73 -144 minecraft:birch_log[axis=y]
fill 112 73 -144 113 73 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 73 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 118 73 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 73 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 87 73 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 73 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 89 73 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 113 73 -145 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 116 73 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 73 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 73 -145 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 72 73 -146 minecraft:birch_log[axis=y]
setblock 92 73 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 73 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 73 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 73 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 73 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 120 73 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 73 -147 minecraft:birch_log[axis=y]
setblock 79 73 -147 minecraft:birch_log[axis=y]
setblock 91 73 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 73 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 73 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 73 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 73 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 73 -147 minecraft:birch_log[axis=y]
setblock 117 73 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 73 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 73 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 90 73 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 73 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 92 73 -148 minecraft:birch_log[axis=y]
setblock 93 73 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 94 73 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 73 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 73 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 73 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 73 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 73 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 73 -148 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 135 73 -148 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 91 73 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 92 73 -149 93 73 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 94 73 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 73 -149 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 104 73 -149 minecraft:birch_log[axis=y]
setblock 116 73 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 117 73 -149 118 73 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 73 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 73 -149 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 134 73 -149 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 135 73 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 83 73 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 73 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 73 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 73 -150 minecraft:birch_log[axis=y]
setblock 94 73 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 95 73 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 73 -150 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 99 73 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 73 -150 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 116 73 -150 minecraft:birch_log[axis=y]
setblock 118 73 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 135 73 -150 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 73 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 84 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 73 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 94 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 73 -151 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 74 73 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 73 -152 minecraft:birch_log[axis=y]
setblock 81 73 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 73 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 73 -152 minecraft:birch_log[axis=y]
setblock 84 73 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 73 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 73 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 73 -152 minecraft:birch_log[axis=y]
setblock 102 73 -152 minecraft:birch_log[axis=y]
setblock 73 73 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 73 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 75 73 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 73 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 73 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 84 73 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 73 -153 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 72 73 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 73 73 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 74 73 -154 minecraft:birch_log[axis=y]
setblock 75 73 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 76 73 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 73 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 73 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 73 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 73 73 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 73 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 75 73 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 73 -155 minecraft:birch_log[axis=y]
setblock 107 73 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 108 73 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 109 73 -155 110 73 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 73 -155 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 74 73 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 73 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 108 73 -156 109 73 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 73 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 73 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 73 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 97 73 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 98 73 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 73 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 73 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 73 -157 minecraft:birch_log[axis=y]
setblock 79 73 -158 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 73 -158 minecraft:birch_log[axis=y]
setblock 90 73 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 73 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 73 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 98 73 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 73 -159 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 73 -159 herbsandharvest:pear_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 97 73 -159 minecraft:birch_log[axis=y]
setblock 94 72 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 95 72 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 72 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 100 72 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 72 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 72 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 72 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 112 72 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 72 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 72 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 117 72 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 72 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 93 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 72 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 101 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 72 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 110 72 -128 minecraft:birch_log[axis=y]
setblock 111 72 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 112 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 72 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 72 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 72 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 72 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 94 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 72 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 100 72 -129 minecraft:birch_log[axis=y]
setblock 101 72 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 102 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 72 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 72 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 72 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 72 -130 minecraft:birch_log[axis=y]
setblock 84 72 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 72 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 72 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 72 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 72 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 72 -130 minecraft:birch_log[axis=y]
setblock 94 72 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 95 72 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 72 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 72 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 101 72 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 72 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 83 72 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 72 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 85 72 -131 minecraft:birch_log[axis=y]
setblock 86 72 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 87 72 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 72 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 72 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 94 72 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 72 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 72 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 84 72 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 72 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 86 72 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 72 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 106 72 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 107 72 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 72 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 72 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 72 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 117 72 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 72 -133 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 129 72 -133 minecraft:birch_log[axis=y]
setblock 124 72 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 72 -135 minecraft:air
setblock 94 72 -135 minecraft:air
setblock 123 72 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 72 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 72 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 98 72 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 72 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 72 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 72 -137 minecraft:birch_log[axis=y]
setblock 97 72 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 98 72 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 72 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 109 72 -137 minecraft:birch_log[axis=y]
setblock 78 72 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 72 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 72 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 72 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 72 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 72 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 72 -139 minecraft:birch_log[axis=y]
setblock 80 72 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 81 72 -139 82 72 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 96 72 -139 minecraft:birch_log[axis=y]
setblock 112 72 -139 minecraft:birch_log[axis=y]
setblock 78 72 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 72 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 80 72 -140 81 72 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 72 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 72 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 79 72 -141 80 72 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 72 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 82 72 -141 minecraft:birch_log[axis=y]
setblock 83 72 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 84 72 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 72 -141 minecraft:birch_log[axis=y]
setblock 123 72 -141 minecraft:birch_log[axis=y]
setblock 81 72 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 72 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 83 72 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 72 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 72 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 89 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 72 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 72 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 72 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 86 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 87 72 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 88 72 -144 minecraft:birch_log[axis=y]
setblock 89 72 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 90 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 72 -144 minecraft:birch_log[axis=y]
setblock 112 72 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 113 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 72 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 72 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 72 -145 minecraft:air
setblock 87 72 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 88 72 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 89 72 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 72 -145 minecraft:air
setblock 113 72 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 72 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 119 72 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 72 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 72 -146 minecraft:birch_log[axis=y]
setblock 88 72 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 72 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 72 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 72 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 72 -146 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 76 72 -147 minecraft:birch_log[axis=y]
setblock 79 72 -147 minecraft:birch_log[axis=y]
setblock 116 72 -147 minecraft:birch_log[axis=y]
setblock 120 72 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 72 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 130 72 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 131 72 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 132 72 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 92 72 -148 minecraft:birch_log[axis=y]
setblock 117 72 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 72 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 72 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 72 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 72 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 72 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 72 -148 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 135 72 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 72 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 104 72 -149 minecraft:birch_log[axis=y]
setblock 117 72 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 72 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 72 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 72 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 72 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 135 72 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 93 72 -150 minecraft:birch_log[axis=y]
setblock 98 72 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 72 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 72 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 72 -150 minecraft:birch_log[axis=y]
setblock 117 72 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 72 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 72 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 135 72 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 72 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 72 -152 minecraft:birch_log[axis=y]
setblock 78 72 -152 regions_unexplored:birch_branch[facing=east]
setblock 83 72 -152 minecraft:birch_log[axis=y]
setblock 95 72 -152 minecraft:birch_log[axis=y]
setblock 102 72 -152 minecraft:birch_log[axis=y]
setblock 129 72 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 74 72 -154 minecraft:birch_log[axis=y]
setblock 107 72 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 108 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 72 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 72 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 72 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 72 -155 minecraft:air
setblock 84 72 -155 minecraft:birch_log[axis=y]
setblock 94 72 -155 minecraft:air
setblock 107 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 72 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 109 72 -155 110 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 72 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 72 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 97 72 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 98 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 72 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 107 72 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 108 72 -156 109 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 72 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 72 -157 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 79 72 -157 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 80 72 -157 herbsandharvest:pear_fruit_leaves[age=2,distance=4,persistent=false,waterlogged=false]
setblock 90 72 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 91 72 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 92 72 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 97 72 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 72 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 99 72 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 72 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 110 72 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 111 72 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 72 -157 minecraft:birch_log[axis=y]
setblock 77 72 -158 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 78 72 -158 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 72 -158 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 72 -158 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 81 72 -158 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 88 72 -158 minecraft:birch_log[axis=y]
setblock 90 72 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 72 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 92 72 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 72 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 98 72 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 72 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 72 -159 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 72 -159 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 72 -159 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 97 72 -159 minecraft:birch_log[axis=y]
fill 72 71 -127 73 71 -127 minecraft:air
setblock 82 71 -127 minecraft:air
setblock 94 71 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 95 71 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 96 71 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 110 71 -127 111 71 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 112 71 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 71 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 71 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 71 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 71 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 71 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 71 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 121 71 -127 123 71 -127 minecraft:air
fill 131 71 -127 133 71 -127 minecraft:air
setblock 72 71 -128 minecraft:air
setblock 95 71 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 71 -128 minecraft:birch_log[axis=y]
setblock 111 71 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 112 71 -128 minecraft:air
setblock 113 71 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 71 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 115 71 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 71 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 71 -128 minecraft:air
setblock 132 71 -128 minecraft:air
setblock 100 71 -129 minecraft:birch_log[axis=y]
setblock 113 71 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 114 71 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 115 71 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 71 -130 minecraft:birch_log[axis=y]
setblock 93 71 -130 minecraft:birch_log[axis=y]
setblock 126 71 -130 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 85 71 -131 minecraft:birch_log[axis=y]
setblock 106 71 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 107 71 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 71 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 71 -131 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 126 71 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 106 71 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 71 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 108 71 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 71 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 71 -132 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 71 -133 minecraft:air
setblock 94 71 -133 minecraft:air
setblock 106 71 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 107 71 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 71 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 116 71 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 117 71 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 71 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 121 71 -133 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 122 71 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 71 -133 minecraft:birch_log[axis=y]
fill 81 71 -134 83 71 -134 minecraft:air
fill 93 71 -134 95 71 -134 minecraft:air
setblock 117 71 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 71 -134 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 123 71 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 71 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 71 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 80 71 -135 84 71 -135 minecraft:air
fill 92 71 -135 96 71 -135 minecraft:air
setblock 123 71 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 71 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 71 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 71 -135 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 134 71 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 81 71 -136 83 71 -136 minecraft:air
fill 93 71 -136 95 71 -136 minecraft:air
setblock 97 71 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 98 71 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 71 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 71 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 71 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 71 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 71 -137 minecraft:air
setblock 84 71 -137 minecraft:birch_log[axis=y]
setblock 94 71 -137 minecraft:air
setblock 97 71 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 71 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 99 71 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 71 -137 minecraft:birch_log[axis=y]
setblock 97 71 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 98 71 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 71 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 71 -139 minecraft:birch_log[axis=y]
setblock 96 71 -139 minecraft:birch_log[axis=y]
setblock 112 71 -139 minecraft:birch_log[axis=y]
setblock 82 71 -141 minecraft:birch_log[axis=y]
setblock 91 71 -141 minecraft:birch_log[axis=y]
setblock 123 71 -141 minecraft:birch_log[axis=y]
setblock 119 71 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 71 -142 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 82 71 -143 minecraft:air
setblock 94 71 -143 minecraft:air
setblock 112 71 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 113 71 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 71 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 71 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 71 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 71 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 71 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 131 71 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 81 71 -144 83 71 -144 minecraft:air
setblock 88 71 -144 minecraft:birch_log[axis=y]
fill 93 71 -144 95 71 -144 minecraft:air
setblock 110 71 -144 minecraft:birch_log[axis=y]
setblock 112 71 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 71 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 114 71 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 71 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 71 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 71 -144 minecraft:birch_log[axis=y]
setblock 120 71 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 121 71 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 71 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 80 71 -145 84 71 -145 minecraft:air
fill 92 71 -145 96 71 -145 minecraft:air
setblock 112 71 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 113 71 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 71 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 71 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 71 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 71 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 71 -145 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 72 71 -146 minecraft:birch_log[axis=y]
fill 81 71 -146 83 71 -146 minecraft:air
fill 93 71 -146 95 71 -146 minecraft:air
setblock 119 71 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 71 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 121 71 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 71 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 71 -147 minecraft:birch_log[axis=y]
setblock 79 71 -147 minecraft:birch_log[axis=y]
setblock 82 71 -147 minecraft:air
setblock 94 71 -147 minecraft:air
setblock 116 71 -147 minecraft:birch_log[axis=y]
setblock 118 71 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 71 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 120 71 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 71 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 71 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 71 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 71 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 130 71 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 71 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 71 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 92 71 -148 minecraft:birch_log[axis=y]
setblock 117 71 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 71 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 71 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 71 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 71 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 71 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 71 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 71 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 135 71 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 71 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 71 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 71 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 104 71 -149 minecraft:birch_log[axis=y]
fill 116 71 -149 117 71 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 71 -149 minecraft:birch_log[axis=y]
setblock 119 71 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 71 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 71 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 71 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 126 71 -149 127 71 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 128 71 -149 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 134 71 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 71 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 71 -150 minecraft:birch_log[axis=y]
setblock 98 71 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 71 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 100 71 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 71 -150 minecraft:birch_log[axis=y]
fill 117 71 -150 118 71 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 71 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 71 -150 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 134 71 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 135 71 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 71 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 99 71 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 100 71 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 118 71 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 71 -152 minecraft:birch_log[axis=y]
setblock 83 71 -152 minecraft:birch_log[axis=y]
setblock 95 71 -152 minecraft:birch_log[axis=y]
setblock 102 71 -152 minecraft:birch_log[axis=y]
setblock 82 71 -153 minecraft:air
setblock 94 71 -153 minecraft:air
setblock 108 71 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 71 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 71 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 71 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 74 71 -154 minecraft:birch_log[axis=y]
fill 81 71 -154 83 71 -154 minecraft:air
fill 93 71 -154 95 71 -154 minecraft:air
setblock 107 71 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 108 71 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 109 71 -154 110 71 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 71 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 71 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 130 71 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 80 71 -155 83 71 -155 minecraft:air
setblock 84 71 -155 minecraft:birch_log[axis=y]
fill 92 71 -155 96 71 -155 minecraft:air
setblock 98 71 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 106 71 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 71 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 108 71 -155 minecraft:birch_log[axis=y]
fill 109 71 -155 110 71 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 71 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 71 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 129 71 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 71 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 81 71 -156 83 71 -156 minecraft:air
setblock 91 71 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 93 71 -156 95 71 -156 minecraft:air
setblock 97 71 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 71 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 99 71 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 71 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 108 71 -156 109 71 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 110 71 -156 minecraft:birch_log[axis=y]
setblock 111 71 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 112 71 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 71 -157 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 71 -157 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 71 -157 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 71 -157 minecraft:air
setblock 90 71 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 71 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 92 71 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 94 71 -157 minecraft:air
setblock 96 71 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 71 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 98 71 -157 minecraft:birch_log[axis=y]
setblock 99 71 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 100 71 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 108 71 -157 109 71 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 71 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 111 71 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 71 -157 minecraft:birch_log[axis=y]
setblock 77 71 -158 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 71 -158 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 71 -158 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 71 -158 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 71 -158 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 71 -158 minecraft:birch_log[axis=y]
setblock 89 71 -158 regions_unexplored:birch_branch[facing=east]
setblock 90 71 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 91 71 -158 minecraft:birch_log[axis=y]
setblock 92 71 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 93 71 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 97 71 -158 98 71 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 99 71 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 110 71 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 71 -159 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 71 -159 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 71 -159 minecraft:oak_log[axis=y]
setblock 97 71 -159 minecraft:birch_log[axis=y]
setblock 98 71 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 72 70 -127 74 70 -127 minecraft:air
fill 81 70 -127 83 70 -127 minecraft:air
fill 93 70 -127 95 70 -127 minecraft:air
fill 110 70 -127 112 70 -127 minecraft:air
setblock 113 70 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 70 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 115 70 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 120 70 -127 124 70 -127 minecraft:air
fill 130 70 -127 134 70 -127 minecraft:air
fill 72 70 -128 73 70 -128 minecraft:air
setblock 110 70 -128 minecraft:birch_log[axis=y]
setblock 111 70 -128 minecraft:air
setblock 112 70 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 70 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 114 70 -128 minecraft:birch_log[axis=y]
setblock 115 70 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 116 70 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 121 70 -128 123 70 -128 minecraft:air
fill 131 70 -128 133 70 -128 minecraft:air
setblock 100 70 -129 minecraft:birch_log[axis=y]
setblock 113 70 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 70 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 115 70 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 70 -130 minecraft:birch_log[axis=y]
setblock 93 70 -130 minecraft:birch_log[axis=y]
setblock 107 70 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 114 70 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 70 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 70 -131 minecraft:birch_log[axis=y]
setblock 106 70 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 70 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 108 70 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 70 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 70 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 70 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 105 70 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 106 70 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 107 70 -132 minecraft:birch_log[axis=y]
setblock 108 70 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 109 70 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 70 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 117 70 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 70 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 70 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 70 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 81 70 -133 83 70 -133 minecraft:air
fill 93 70 -133 95 70 -133 minecraft:air
setblock 106 70 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 70 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 108 70 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 70 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 70 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 70 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 70 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 70 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 70 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 124 70 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 70 -133 regions_unexplored:birch_branch[facing=west]
setblock 129 70 -133 minecraft:birch_log[axis=y]
fill 80 70 -134 84 70 -134 minecraft:air
fill 92 70 -134 96 70 -134 minecraft:air
setblock 107 70 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 70 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 117 70 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 70 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 70 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 123 70 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 70 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 70 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 70 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 80 70 -135 84 70 -135 minecraft:air
fill 92 70 -135 96 70 -135 minecraft:air
setblock 98 70 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 70 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 70 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 70 -135 minecraft:birch_log[axis=y]
setblock 125 70 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 70 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 70 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 70 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 70 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 80 70 -136 84 70 -136 minecraft:air
fill 92 70 -136 96 70 -136 minecraft:air
setblock 97 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 70 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 99 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 70 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 70 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 81 70 -137 83 70 -137 minecraft:air
setblock 84 70 -137 minecraft:birch_log[axis=y]
fill 93 70 -137 95 70 -137 minecraft:air
setblock 96 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 70 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 98 70 -137 minecraft:birch_log[axis=y]
setblock 99 70 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 100 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 109 70 -137 minecraft:birch_log[axis=y]
setblock 124 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 97 70 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 70 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 99 70 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 70 -139 minecraft:birch_log[axis=y]
setblock 96 70 -139 minecraft:birch_log[axis=y]
setblock 98 70 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 112 70 -139 minecraft:birch_log[axis=y]
setblock 123 70 -140 regions_unexplored:birch_branch[facing=south]
setblock 82 70 -141 minecraft:birch_log[axis=y]
setblock 91 70 -141 minecraft:birch_log[axis=y]
setblock 123 70 -141 minecraft:birch_log[axis=y]
setblock 113 70 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 70 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 81 70 -143 83 70 -143 minecraft:air
fill 93 70 -143 95 70 -143 minecraft:air
setblock 112 70 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 70 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 114 70 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 70 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 70 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 70 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 80 70 -144 84 70 -144 minecraft:air
setblock 88 70 -144 minecraft:birch_log[axis=y]
fill 92 70 -144 96 70 -144 minecraft:air
setblock 110 70 -144 minecraft:birch_log[axis=y]
fill 111 70 -144 112 70 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 113 70 -144 minecraft:birch_log[axis=y]
setblock 114 70 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 115 70 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 70 -144 minecraft:birch_log[axis=y]
setblock 120 70 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 131 70 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 80 70 -145 84 70 -145 minecraft:air
fill 92 70 -145 96 70 -145 minecraft:air
setblock 112 70 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 113 70 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 114 70 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 119 70 -145 120 70 -145 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 121 70 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 70 -146 minecraft:birch_log[axis=y]
fill 80 70 -146 84 70 -146 minecraft:air
fill 92 70 -146 96 70 -146 minecraft:air
setblock 113 70 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 118 70 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 119 70 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 120 70 -146 minecraft:birch_log[axis=y]
setblock 121 70 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 122 70 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 70 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 70 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 70 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 70 -146 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 76 70 -147 minecraft:birch_log[axis=y]
setblock 79 70 -147 minecraft:birch_log[axis=y]
fill 81 70 -147 83 70 -147 minecraft:air
fill 93 70 -147 95 70 -147 minecraft:air
setblock 116 70 -147 minecraft:birch_log[axis=y]
setblock 119 70 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 70 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 121 70 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 70 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 70 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 70 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 70 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 70 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 132 70 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 70 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 91 70 -148 regions_unexplored:birch_branch[facing=west]
setblock 92 70 -148 minecraft:birch_log[axis=y]
setblock 99 70 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 120 70 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 70 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 70 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 125 70 -148 minecraft:birch_log[axis=y]
setblock 126 70 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 70 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 70 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 70 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 70 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 70 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 70 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 98 70 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 70 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 100 70 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 103 70 -149 regions_unexplored:birch_branch[facing=west]
setblock 104 70 -149 minecraft:birch_log[axis=y]
setblock 118 70 -149 minecraft:birch_log[axis=y]
setblock 124 70 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 70 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 126 70 -149 127 70 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 70 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 70 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 70 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 70 -149 minecraft:birch_log[axis=y]
setblock 93 70 -150 minecraft:birch_log[axis=y]
setblock 97 70 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 98 70 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 99 70 -150 minecraft:birch_log[axis=y]
setblock 100 70 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 101 70 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 70 -150 minecraft:birch_log[axis=y]
setblock 125 70 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 70 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 70 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 70 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 98 70 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 99 70 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 100 70 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 70 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 70 -152 minecraft:birch_log[axis=y]
setblock 83 70 -152 minecraft:birch_log[axis=y]
setblock 95 70 -152 minecraft:birch_log[axis=y]
setblock 99 70 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 102 70 -152 minecraft:birch_log[axis=y]
setblock 129 70 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 81 70 -153 83 70 -153 minecraft:air
fill 93 70 -153 95 70 -153 minecraft:air
setblock 128 70 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 70 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 130 70 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 70 -154 minecraft:birch_log[axis=y]
fill 80 70 -154 84 70 -154 minecraft:air
fill 92 70 -154 96 70 -154 minecraft:air
setblock 127 70 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 70 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 129 70 -154 minecraft:birch_log[axis=y]
setblock 130 70 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 131 70 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 80 70 -155 83 70 -155 minecraft:air
setblock 84 70 -155 minecraft:birch_log[axis=y]
fill 92 70 -155 96 70 -155 minecraft:air
setblock 108 70 -155 minecraft:birch_log[axis=y]
setblock 128 70 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 70 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 130 70 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 80 70 -156 84 70 -156 minecraft:air
fill 92 70 -156 96 70 -156 minecraft:air
setblock 110 70 -156 minecraft:birch_log[axis=y]
setblock 129 70 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 78 70 -157 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 79 70 -157 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 80 70 -157 herbsandharvest:pear_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
fill 81 70 -157 83 70 -157 minecraft:air
fill 93 70 -157 95 70 -157 minecraft:air
setblock 98 70 -157 minecraft:birch_log[axis=y]
setblock 133 70 -157 minecraft:birch_log[axis=y]
setblock 134 70 -157 regions_unexplored:birch_branch[facing=east]
setblock 77 70 -158 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 78 70 -158 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 70 -158 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 80 70 -158 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 81 70 -158 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 88 70 -158 minecraft:birch_log[axis=y]
setblock 91 70 -158 minecraft:birch_log[axis=y]
setblock 77 70 -159 herbsandharvest:pear_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 78 70 -159 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 70 -159 minecraft:oak_log[axis=y]
setblock 97 70 -159 minecraft:birch_log[axis=y]
fill 72 69 -127 73 69 -127 minecraft:air
setblock 82 69 -127 minecraft:air
setblock 94 69 -127 minecraft:air
fill 111 69 -127 113 69 -127 minecraft:air
fill 121 69 -127 123 69 -127 minecraft:air
fill 131 69 -127 133 69 -127 minecraft:air
setblock 72 69 -128 minecraft:air
setblock 110 69 -128 minecraft:birch_log[axis=y]
setblock 112 69 -128 minecraft:air
setblock 114 69 -128 minecraft:birch_log[axis=y]
setblock 122 69 -128 minecraft:air
setblock 132 69 -128 minecraft:air
setblock 100 69 -129 minecraft:birch_log[axis=y]
setblock 82 69 -130 minecraft:birch_log[axis=y]
setblock 93 69 -130 minecraft:birch_log[axis=y]
setblock 125 69 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 69 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 69 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 85 69 -131 minecraft:birch_log[axis=y]
setblock 117 69 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 69 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 69 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 69 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 69 -132 minecraft:birch_log[axis=y]
setblock 116 69 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 69 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 69 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 69 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 69 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 69 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 125 69 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 126 69 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 69 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 69 -133 minecraft:air
setblock 94 69 -133 minecraft:air
setblock 115 69 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 116 69 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 117 69 -133 minecraft:birch_log[axis=y]
setblock 118 69 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 119 69 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 69 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 69 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 123 69 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 69 -133 minecraft:birch_log[axis=y]
fill 81 69 -134 83 69 -134 minecraft:air
fill 93 69 -134 95 69 -134 minecraft:air
setblock 116 69 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 69 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 118 69 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 69 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 122 69 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 123 69 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 133 69 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 69 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 69 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 80 69 -135 84 69 -135 minecraft:air
fill 92 69 -135 96 69 -135 minecraft:air
setblock 117 69 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 69 -135 minecraft:birch_log[axis=y]
setblock 133 69 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 69 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 69 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 81 69 -136 83 69 -136 minecraft:air
fill 93 69 -136 95 69 -136 minecraft:air
setblock 133 69 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 134 69 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 69 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 69 -137 minecraft:air
setblock 84 69 -137 minecraft:birch_log[axis=y]
setblock 94 69 -137 minecraft:air
setblock 98 69 -137 minecraft:birch_log[axis=y]
setblock 109 69 -137 minecraft:birch_log[axis=y]
setblock 79 69 -139 minecraft:birch_log[axis=y]
setblock 96 69 -139 minecraft:birch_log[axis=y]
setblock 112 69 -139 minecraft:birch_log[axis=y]
setblock 82 69 -141 minecraft:birch_log[axis=y]
setblock 91 69 -141 minecraft:birch_log[axis=y]
setblock 123 69 -141 minecraft:birch_log[axis=y]
setblock 130 69 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 69 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 69 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 82 69 -143 minecraft:air
setblock 94 69 -143 minecraft:air
setblock 130 69 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 69 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 132 69 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 81 69 -144 83 69 -144 minecraft:air
setblock 88 69 -144 minecraft:birch_log[axis=y]
fill 93 69 -144 95 69 -144 minecraft:air
setblock 110 69 -144 minecraft:birch_log[axis=y]
setblock 113 69 -144 minecraft:birch_log[axis=y]
setblock 119 69 -144 minecraft:birch_log[axis=y]
setblock 130 69 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 131 69 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 132 69 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 80 69 -145 84 69 -145 minecraft:air
fill 92 69 -145 96 69 -145 minecraft:air
setblock 131 69 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 69 -146 minecraft:birch_log[axis=y]
fill 81 69 -146 83 69 -146 minecraft:air
fill 93 69 -146 95 69 -146 minecraft:air
setblock 120 69 -146 minecraft:birch_log[axis=y]
setblock 130 69 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 69 -146 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 132 69 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 76 69 -147 minecraft:birch_log[axis=y]
setblock 79 69 -147 minecraft:birch_log[axis=y]
setblock 82 69 -147 minecraft:air
setblock 94 69 -147 minecraft:air
setblock 116 69 -147 minecraft:birch_log[axis=y]
setblock 129 69 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 130 69 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 131 69 -147 minecraft:birch_log[axis=y]
setblock 132 69 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 133 69 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 69 -148 minecraft:short_grass
setblock 92 69 -148 minecraft:birch_log[axis=y]
setblock 125 69 -148 minecraft:birch_log[axis=y]
setblock 126 69 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 69 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 69 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 130 69 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 69 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 132 69 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 104 69 -149 minecraft:birch_log[axis=y]
setblock 118 69 -149 minecraft:birch_log[axis=y]
setblock 126 69 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 69 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 69 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 69 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 135 69 -149 minecraft:birch_log[axis=y]
setblock 93 69 -150 minecraft:birch_log[axis=y]
setblock 99 69 -150 minecraft:birch_log[axis=y]
setblock 116 69 -150 minecraft:birch_log[axis=y]
setblock 126 69 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 127 69 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 128 69 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 77 69 -152 minecraft:birch_log[axis=y]
setblock 83 69 -152 minecraft:birch_log[axis=y]
setblock 95 69 -152 minecraft:birch_log[axis=y]
setblock 102 69 -152 minecraft:birch_log[axis=y]
setblock 82 69 -153 minecraft:air
setblock 94 69 -153 minecraft:air
setblock 74 69 -154 minecraft:birch_log[axis=y]
fill 81 69 -154 83 69 -154 minecraft:air
fill 93 69 -154 95 69 -154 minecraft:air
setblock 129 69 -154 minecraft:birch_log[axis=y]
fill 80 69 -155 83 69 -155 minecraft:air
setblock 84 69 -155 minecraft:birch_log[axis=y]
fill 92 69 -155 96 69 -155 minecraft:air
setblock 108 69 -155 minecraft:birch_log[axis=y]
fill 81 69 -156 83 69 -156 minecraft:air
fill 93 69 -156 95 69 -156 minecraft:air
setblock 110 69 -156 minecraft:birch_log[axis=y]
setblock 79 69 -157 regions_unexplored:birch_shrub[half=upper]
setblock 82 69 -157 minecraft:air
setblock 94 69 -157 minecraft:air
setblock 98 69 -157 minecraft:birch_log[axis=y]
setblock 133 69 -157 minecraft:birch_log[axis=y]
setblock 79 69 -158 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 88 69 -158 minecraft:birch_log[axis=y]
setblock 91 69 -158 minecraft:birch_log[axis=y]
setblock 78 69 -159 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 79 69 -159 minecraft:oak_log[axis=y]
setblock 97 69 -159 minecraft:birch_log[axis=y]
setblock 110 68 -128 minecraft:birch_log[axis=y]
setblock 114 68 -128 minecraft:birch_log[axis=y]
setblock 100 68 -129 minecraft:birch_log[axis=y]
setblock 126 68 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 68 -130 minecraft:birch_log[axis=y]
setblock 93 68 -130 minecraft:birch_log[axis=y]
setblock 125 68 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 68 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 68 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 85 68 -131 minecraft:birch_log[axis=y]
setblock 122 68 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 68 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 68 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 126 68 -131 minecraft:birch_log[axis=y]
setblock 127 68 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 68 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 107 68 -132 minecraft:birch_log[axis=y]
setblock 121 68 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 68 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 123 68 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 125 68 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 68 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 68 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 117 68 -133 minecraft:birch_log[axis=y]
setblock 120 68 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 68 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 122 68 -133 minecraft:birch_log[axis=y]
setblock 123 68 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 124 68 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 126 68 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 129 68 -133 minecraft:birch_log[axis=y]
setblock 134 68 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 121 68 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 122 68 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 123 68 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 68 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 68 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 68 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 82 68 -135 minecraft:air
setblock 94 68 -135 minecraft:air
setblock 122 68 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 124 68 -135 minecraft:birch_log[axis=y]
setblock 132 68 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 133 68 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 134 68 -135 minecraft:birch_log[axis=y]
setblock 135 68 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 133 68 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 134 68 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 135 68 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 84 68 -137 minecraft:birch_log[axis=y]
setblock 98 68 -137 minecraft:birch_log[axis=y]
setblock 109 68 -137 minecraft:birch_log[axis=y]
setblock 134 68 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 79 68 -139 minecraft:birch_log[axis=y]
setblock 96 68 -139 minecraft:birch_log[axis=y]
setblock 112 68 -139 minecraft:birch_log[axis=y]
setblock 73 68 -141 regions_unexplored:grass_sprouts
setblock 82 68 -141 minecraft:birch_log[axis=y]
setblock 91 68 -141 minecraft:birch_log[axis=y]
setblock 123 68 -141 minecraft:birch_log[axis=y]
setblock 131 68 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 68 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 132 68 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 131 68 -143 minecraft:birch_log[axis=y]
setblock 132 68 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 133 68 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 74 68 -144 minecraft:short_grass
setblock 76 68 -144 regions_unexplored:grass_sprouts
setblock 88 68 -144 minecraft:birch_log[axis=y]
setblock 110 68 -144 minecraft:birch_log[axis=y]
setblock 113 68 -144 minecraft:birch_log[axis=y]
setblock 119 68 -144 minecraft:birch_log[axis=y]
setblock 132 68 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 68 -145 minecraft:grass_block[snowy=false]
setblock 73 68 -145 minecraft:short_grass
setblock 76 68 -145 regions_unexplored:grass_sprouts
fill 80 68 -145 81 68 -145 minecraft:short_grass
setblock 82 68 -145 minecraft:air
setblock 94 68 -145 minecraft:air
setblock 72 68 -146 minecraft:dirt
setblock 73 68 -146 regions_unexplored:grass_sprouts
setblock 77 68 -146 minecraft:short_grass
setblock 120 68 -146 minecraft:birch_log[axis=y]
fill 72 68 -147 73 68 -147 minecraft:grass_block[snowy=false]
setblock 76 68 -147 minecraft:birch_log[axis=y]
setblock 79 68 -147 minecraft:birch_log[axis=y]
setblock 80 68 -147 minecraft:short_grass
setblock 116 68 -147 minecraft:birch_log[axis=y]
setblock 127 68 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 72 68 -148 74 68 -148 minecraft:grass_block[snowy=false]
setblock 76 68 -148 minecraft:short_grass
setblock 80 68 -148 regions_unexplored:grass_sprouts
setblock 92 68 -148 minecraft:birch_log[axis=y]
setblock 125 68 -148 minecraft:birch_log[axis=y]
fill 126 68 -148 127 68 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 68 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 104 68 -149 minecraft:birch_log[axis=y]
setblock 118 68 -149 minecraft:birch_log[axis=y]
fill 125 68 -149 126 68 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 127 68 -149 minecraft:birch_log[axis=y]
setblock 128 68 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 73 68 -150 minecraft:short_grass
setblock 93 68 -150 minecraft:birch_log[axis=y]
setblock 99 68 -150 minecraft:birch_log[axis=y]
setblock 116 68 -150 minecraft:birch_log[axis=y]
setblock 126 68 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 127 68 -150 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 128 68 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 77 68 -151 minecraft:short_grass
setblock 127 68 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 72 68 -152 regions_unexplored:grass_sprouts
setblock 77 68 -152 minecraft:birch_log[axis=y]
setblock 78 68 -152 minecraft:short_grass
setblock 83 68 -152 minecraft:birch_log[axis=y]
setblock 95 68 -152 minecraft:birch_log[axis=y]
setblock 102 68 -152 minecraft:birch_log[axis=y]
setblock 102 68 -153 regions_unexplored:birch_branch[facing=north]
setblock 74 68 -154 minecraft:birch_log[axis=y]
setblock 76 68 -154 regions_unexplored:grass_sprouts
setblock 78 68 -154 regions_unexplored:grass_sprouts
setblock 129 68 -154 minecraft:birch_log[axis=y]
setblock 72 68 -155 minecraft:short_grass
setblock 82 68 -155 minecraft:air
setblock 84 68 -155 minecraft:birch_log[axis=y]
setblock 94 68 -155 minecraft:air
setblock 108 68 -155 minecraft:birch_log[axis=y]
setblock 78 68 -156 minecraft:short_grass
setblock 109 68 -156 regions_unexplored:birch_branch[facing=west]
setblock 110 68 -156 minecraft:birch_log[axis=y]
setblock 79 68 -157 regions_unexplored:birch_shrub[half=lower]
setblock 98 68 -157 minecraft:birch_log[axis=y]
setblock 133 68 -157 minecraft:birch_log[axis=y]
setblock 88 68 -158 minecraft:birch_log[axis=y]
setblock 91 68 -158 minecraft:birch_log[axis=y]
setblock 133 68 -158 regions_unexplored:birch_branch[facing=north]
setblock 79 68 -159 minecraft:oak_log[axis=y]
setblock 97 68 -159 minecraft:birch_log[axis=y]
setblock 96 67 -127 minecraft:rose_bush[half=upper]
setblock 110 67 -128 minecraft:birch_log[axis=y]
setblock 133 67 -128 regions_unexplored:grass_sprouts
setblock 100 67 -129 minecraft:birch_log[axis=y]
setblock 82 67 -130 minecraft:birch_log[axis=y]
setblock 93 67 -130 minecraft:birch_log[axis=y]
setblock 85 67 -131 minecraft:birch_log[axis=y]
setblock 126 67 -131 minecraft:birch_log[axis=y]
setblock 107 67 -132 minecraft:birch_log[axis=y]
setblock 129 67 -133 minecraft:birch_log[axis=y]
setblock 82 67 -135 minecraft:air
setblock 94 67 -135 minecraft:air
setblock 134 67 -135 minecraft:birch_log[axis=y]
fill 72 67 -136 73 67 -136 minecraft:grass_block[snowy=false]
fill 72 67 -137 74 67 -137 minecraft:grass_block[snowy=false]
setblock 84 67 -137 minecraft:birch_log[axis=y]
setblock 98 67 -137 minecraft:birch_log[axis=y]
setblock 109 67 -137 minecraft:birch_log[axis=y]
fill 72 67 -138 75 67 -138 minecraft:grass_block[snowy=false]
fill 72 67 -139 76 67 -139 minecraft:grass_block[snowy=false]
setblock 79 67 -139 minecraft:birch_log[axis=y]
setblock 96 67 -139 minecraft:birch_log[axis=y]
setblock 112 67 -139 minecraft:birch_log[axis=y]
fill 72 67 -140 76 67 -140 minecraft:grass_block[snowy=false]
setblock 83 67 -140 regions_unexplored:grass_sprouts
fill 72 67 -141 76 67 -141 minecraft:grass_block[snowy=false]
setblock 82 67 -141 minecraft:birch_log[axis=y]
setblock 85 67 -141 minecraft:short_grass
setblock 91 67 -141 minecraft:birch_log[axis=y]
fill 72 67 -142 76 67 -142 minecraft:grass_block[snowy=false]
setblock 82 67 -142 regions_unexplored:grass_sprouts
setblock 92 67 -142 regions_unexplored:birch_shrub[half=upper]
fill 72 67 -143 77 67 -143 minecraft:grass_block[snowy=false]
fill 72 67 -144 78 67 -144 minecraft:grass_block[snowy=false]
setblock 80 67 -144 minecraft:grass_block[snowy=false]
setblock 88 67 -144 minecraft:birch_log[axis=y]
setblock 110 67 -144 minecraft:birch_log[axis=y]
setblock 113 67 -144 minecraft:birch_log[axis=y]
setblock 119 67 -144 minecraft:birch_log[axis=y]
setblock 72 67 -145 minecraft:dirt
fill 73 67 -145 81 67 -145 minecraft:grass_block[snowy=false]
setblock 82 67 -145 minecraft:air
setblock 85 67 -145 minecraft:short_grass
setblock 88 67 -145 minecraft:short_grass
setblock 94 67 -145 minecraft:air
setblock 72 67 -146 minecraft:dirt
fill 73 67 -146 81 67 -146 minecraft:grass_block[snowy=false]
setblock 120 67 -146 minecraft:birch_log[axis=y]
fill 72 67 -147 73 67 -147 minecraft:dirt
fill 74 67 -147 75 67 -147 minecraft:grass_block[snowy=false]
setblock 76 67 -147 minecraft:dirt
fill 77 67 -147 78 67 -147 minecraft:grass_block[snowy=false]
setblock 79 67 -147 minecraft:dirt
fill 80 67 -147 83 67 -147 minecraft:grass_block[snowy=false]
setblock 86 67 -147 minecraft:short_grass
setblock 116 67 -147 minecraft:birch_log[axis=y]
fill 72 67 -148 74 67 -148 minecraft:dirt
fill 75 67 -148 84 67 -148 minecraft:grass_block[snowy=false]
setblock 92 67 -148 minecraft:birch_log[axis=y]
setblock 125 67 -148 minecraft:birch_log[axis=y]
fill 72 67 -149 84 67 -149 minecraft:grass_block[snowy=false]
setblock 104 67 -149 minecraft:birch_log[axis=y]
setblock 118 67 -149 minecraft:birch_log[axis=y]
setblock 127 67 -149 minecraft:birch_log[axis=y]
fill 72 67 -150 84 67 -150 minecraft:grass_block[snowy=false]
setblock 93 67 -150 minecraft:birch_log[axis=y]
setblock 99 67 -150 minecraft:birch_log[axis=y]
setblock 116 67 -150 minecraft:birch_log[axis=y]
fill 72 67 -151 84 67 -151 minecraft:grass_block[snowy=false]
fill 72 67 -152 76 67 -152 minecraft:grass_block[snowy=false]
setblock 77 67 -152 minecraft:dirt
fill 78 67 -152 82 67 -152 minecraft:grass_block[snowy=false]
setblock 83 67 -152 minecraft:dirt
fill 84 67 -152 85 67 -152 minecraft:grass_block[snowy=false]
setblock 88 67 -152 regions_unexplored:grass_sprouts
setblock 95 67 -152 minecraft:birch_log[axis=y]
setblock 102 67 -152 minecraft:birch_log[axis=y]
fill 72 67 -153 85 67 -153 minecraft:grass_block[snowy=false]
fill 72 67 -154 73 67 -154 minecraft:grass_block[snowy=false]
setblock 74 67 -154 minecraft:dirt
fill 75 67 -154 85 67 -154 minecraft:grass_block[snowy=false]
setblock 129 67 -154 minecraft:birch_log[axis=y]
fill 72 67 -155 75 67 -155 minecraft:grass_block[snowy=false]
fill 77 67 -155 83 67 -155 minecraft:grass_block[snowy=false]
setblock 84 67 -155 minecraft:dirt
setblock 85 67 -155 minecraft:grass_block[snowy=false]
setblock 94 67 -155 minecraft:air
setblock 108 67 -155 minecraft:birch_log[axis=y]
fill 72 67 -156 73 67 -156 minecraft:grass_block[snowy=false]
setblock 75 67 -156 minecraft:short_grass
fill 78 67 -156 84 67 -156 minecraft:grass_block[snowy=false]
setblock 110 67 -156 minecraft:birch_log[axis=y]
setblock 72 67 -157 minecraft:grass_block[snowy=false]
setblock 74 67 -157 minecraft:short_grass
fill 78 67 -157 84 67 -157 minecraft:grass_block[snowy=false]
setblock 86 67 -157 regions_unexplored:grass_sprouts
setblock 98 67 -157 minecraft:birch_log[axis=y]
setblock 132 67 -157 regions_unexplored:birch_branch[facing=west]
setblock 133 67 -157 minecraft:birch_log[axis=y]
setblock 72 67 -158 minecraft:grass_block[snowy=false]
setblock 74 67 -158 regions_unexplored:grass_sprouts
fill 78 67 -158 84 67 -158 minecraft:grass_block[snowy=false]
setblock 88 67 -158 minecraft:birch_log[axis=y]
setblock 91 67 -158 minecraft:birch_log[axis=y]
setblock 78 67 -159 minecraft:grass_block[snowy=false]
setblock 79 67 -159 minecraft:dirt
setblock 97 67 -159 minecraft:birch_log[axis=y]
setblock 88 66 -127 minecraft:rose_bush[half=upper]
setblock 96 66 -127 minecraft:rose_bush[half=lower]
setblock 99 66 -127 minecraft:short_grass
setblock 132 66 -127 minecraft:short_grass
fill 133 66 -127 135 66 -127 minecraft:grass_block[snowy=false]
setblock 72 66 -128 minecraft:grass_block[snowy=false]
setblock 98 66 -128 minecraft:short_grass
fill 132 66 -128 135 66 -128 minecraft:grass_block[snowy=false]
fill 72 66 -129 73 66 -129 minecraft:grass_block[snowy=false]
setblock 82 66 -129 minecraft:short_grass
setblock 84 66 -129 regions_unexplored:grass_sprouts
setblock 97 66 -129 regions_unexplored:grass_sprouts
setblock 100 66 -129 minecraft:birch_log[axis=y]
fill 72 66 -130 74 66 -130 minecraft:grass_block[snowy=false]
setblock 77 66 -130 regions_unexplored:grass_sprouts
setblock 82 66 -130 minecraft:birch_log[axis=y]
setblock 83 66 -130 regions_unexplored:grass_sprouts
setblock 93 66 -130 minecraft:birch_log[axis=y]
fill 72 66 -131 75 66 -131 minecraft:grass_block[snowy=false]
setblock 79 66 -131 regions_unexplored:grass_sprouts
setblock 85 66 -131 minecraft:birch_log[axis=y]
setblock 126 66 -131 minecraft:birch_log[axis=y]
fill 72 66 -132 76 66 -132 minecraft:grass_block[snowy=false]
setblock 79 66 -132 regions_unexplored:grass_sprouts
setblock 88 66 -132 regions_unexplored:grass_sprouts
setblock 100 66 -132 minecraft:short_grass
setblock 107 66 -132 minecraft:birch_log[axis=y]
fill 77 66 -133 78 66 -133 minecraft:grass_block[snowy=false]
setblock 80 66 -133 regions_unexplored:grass_sprouts
setblock 85 66 -133 minecraft:short_grass
setblock 129 66 -133 minecraft:birch_log[axis=y]
fill 78 66 -134 80 66 -134 minecraft:grass_block[snowy=false]
setblock 87 66 -134 minecraft:short_grass
fill 79 66 -135 81 66 -135 minecraft:grass_block[snowy=false]
setblock 82 66 -135 minecraft:air
setblock 94 66 -135 minecraft:air
setblock 134 66 -135 minecraft:birch_log[axis=y]
setblock 72 66 -136 minecraft:dirt
fill 80 66 -136 82 66 -136 minecraft:grass_block[snowy=false]
fill 72 66 -137 74 66 -137 minecraft:dirt
setblock 75 66 -137 minecraft:grass_block[snowy=false]
setblock 78 66 -137 minecraft:short_grass
fill 80 66 -137 83 66 -137 minecraft:grass_block[snowy=false]
setblock 84 66 -137 minecraft:birch_log[axis=y]
setblock 98 66 -137 minecraft:birch_log[axis=y]
setblock 109 66 -137 minecraft:birch_log[axis=y]
fill 72 66 -138 75 66 -138 minecraft:dirt
fill 80 66 -138 84 66 -138 minecraft:grass_block[snowy=false]
fill 72 66 -139 76 66 -139 minecraft:dirt
setblock 79 66 -139 minecraft:birch_log[axis=y]
fill 80 66 -139 85 66 -139 minecraft:grass_block[snowy=false]
setblock 96 66 -139 minecraft:birch_log[axis=y]
setblock 112 66 -139 minecraft:birch_log[axis=y]
fill 72 66 -140 76 66 -140 minecraft:dirt
fill 81 66 -140 85 66 -140 minecraft:grass_block[snowy=false]
fill 72 66 -141 76 66 -141 minecraft:dirt
setblock 81 66 -141 minecraft:grass_block[snowy=false]
setblock 82 66 -141 minecraft:dirt
fill 83 66 -141 86 66 -141 minecraft:grass_block[snowy=false]
setblock 89 66 -141 regions_unexplored:grass_sprouts
setblock 90 66 -141 minecraft:short_grass
setblock 91 66 -141 minecraft:birch_log[axis=y]
fill 72 66 -142 76 66 -142 minecraft:dirt
fill 81 66 -142 87 66 -142 minecraft:grass_block[snowy=false]
setblock 92 66 -142 regions_unexplored:birch_shrub[half=lower]
fill 72 66 -143 77 66 -143 minecraft:dirt
fill 81 66 -143 88 66 -143 minecraft:grass_block[snowy=false]
fill 72 66 -144 77 66 -144 minecraft:dirt
fill 82 66 -144 87 66 -144 minecraft:grass_block[snowy=false]
setblock 88 66 -144 minecraft:dirt
setblock 110 66 -144 minecraft:birch_log[axis=y]
setblock 113 66 -144 minecraft:birch_log[axis=y]
setblock 119 66 -144 minecraft:birch_log[axis=y]
fill 72 66 -145 78 66 -145 minecraft:dirt
fill 82 66 -145 88 66 -145 minecraft:grass_block[snowy=false]
setblock 94 66 -145 minecraft:air
fill 72 66 -146 81 66 -146 minecraft:dirt
fill 82 66 -146 88 66 -146 minecraft:grass_block[snowy=false]
setblock 89 66 -146 regions_unexplored:grass_sprouts
setblock 120 66 -146 minecraft:birch_log[axis=y]
fill 72 66 -147 83 66 -147 minecraft:dirt
fill 84 66 -147 89 66 -147 minecraft:grass_block[snowy=false]
fill 91 66 -147 92 66 -147 regions_unexplored:grass_sprouts
setblock 116 66 -147 minecraft:birch_log[axis=y]
fill 72 66 -148 84 66 -148 minecraft:dirt
fill 85 66 -148 89 66 -148 minecraft:grass_block[snowy=false]
setblock 92 66 -148 minecraft:birch_log[axis=y]
setblock 125 66 -148 minecraft:birch_log[axis=y]
fill 72 66 -149 84 66 -149 minecraft:dirt
fill 85 66 -149 89 66 -149 minecraft:grass_block[snowy=false]
setblock 93 66 -149 regions_unexplored:grass_sprouts
setblock 104 66 -149 minecraft:birch_log[axis=y]
setblock 118 66 -149 minecraft:birch_log[axis=y]
setblock 127 66 -149 minecraft:birch_log[axis=y]
fill 72 66 -150 84 66 -150 minecraft:dirt
fill 85 66 -150 89 66 -150 minecraft:grass_block[snowy=false]
setblock 93 66 -150 minecraft:birch_log[axis=y]
setblock 99 66 -150 minecraft:birch_log[axis=y]
setblock 116 66 -150 minecraft:birch_log[axis=y]
fill 72 66 -151 84 66 -151 minecraft:dirt
fill 85 66 -151 89 66 -151 minecraft:grass_block[snowy=false]
setblock 90 66 -151 minecraft:short_grass
setblock 94 66 -151 regions_unexplored:grass_sprouts
fill 72 66 -152 85 66 -152 minecraft:dirt
fill 86 66 -152 90 66 -152 minecraft:grass_block[snowy=false]
setblock 95 66 -152 minecraft:birch_log[axis=y]
setblock 102 66 -152 minecraft:birch_log[axis=y]
fill 72 66 -153 85 66 -153 minecraft:dirt
fill 86 66 -153 90 66 -153 minecraft:grass_block[snowy=false]
fill 72 66 -154 85 66 -154 minecraft:dirt
fill 86 66 -154 89 66 -154 minecraft:grass_block[snowy=false]
setblock 129 66 -154 minecraft:birch_log[axis=y]
fill 72 66 -155 75 66 -155 minecraft:dirt
setblock 76 66 -155 minecraft:grass_block[snowy=false]
fill 77 66 -155 85 66 -155 minecraft:dirt
fill 86 66 -155 89 66 -155 minecraft:grass_block[snowy=false]
setblock 94 66 -155 minecraft:air
setblock 108 66 -155 minecraft:birch_log[axis=y]
fill 72 66 -156 73 66 -156 minecraft:dirt
fill 74 66 -156 77 66 -156 minecraft:grass_block[snowy=false]
fill 78 66 -156 84 66 -156 minecraft:dirt
fill 85 66 -156 89 66 -156 minecraft:grass_block[snowy=false]
setblock 110 66 -156 minecraft:birch_log[axis=y]
setblock 72 66 -157 minecraft:dirt
fill 73 66 -157 77 66 -157 minecraft:grass_block[snowy=false]
fill 78 66 -157 84 66 -157 minecraft:dirt
fill 85 66 -157 89 66 -157 minecraft:grass_block[snowy=false]
setblock 98 66 -157 minecraft:birch_log[axis=y]
setblock 133 66 -157 minecraft:birch_log[axis=y]
setblock 72 66 -158 minecraft:dirt
fill 73 66 -158 77 66 -158 minecraft:grass_block[snowy=false]
fill 78 66 -158 84 66 -158 minecraft:dirt
fill 85 66 -158 87 66 -158 minecraft:grass_block[snowy=false]
setblock 88 66 -158 minecraft:dirt
setblock 89 66 -158 minecraft:grass_block[snowy=false]
setblock 91 66 -158 minecraft:birch_log[axis=y]
setblock 92 66 -158 regions_unexplored:grass_sprouts
fill 72 66 -159 77 66 -159 minecraft:grass_block[snowy=false]
fill 78 66 -159 79 66 -159 minecraft:dirt
setblock 97 66 -159 minecraft:birch_log[axis=y]
fill 86 65 -127 87 65 -127 minecraft:air
setblock 88 65 -127 minecraft:rose_bush[half=lower]
fill 89 65 -127 95 65 -127 minecraft:air
fill 109 65 -127 130 65 -127 minecraft:air
fill 133 65 -127 135 65 -127 minecraft:dirt
setblock 72 65 -128 minecraft:dirt
fill 86 65 -128 90 65 -128 minecraft:grass_block[snowy=false]
fill 109 65 -128 130 65 -128 minecraft:air
fill 132 65 -128 135 65 -128 minecraft:dirt
fill 72 65 -129 73 65 -129 minecraft:dirt
fill 86 65 -129 90 65 -129 minecraft:grass_block[snowy=false]
fill 94 65 -129 96 65 -129 minecraft:air
setblock 100 65 -129 minecraft:dirt
fill 107 65 -129 132 65 -129 minecraft:air
fill 72 65 -130 74 65 -130 minecraft:dirt
setblock 82 65 -130 minecraft:dirt
fill 86 65 -130 90 65 -130 minecraft:grass_block[snowy=false]
setblock 92 65 -130 minecraft:air
setblock 93 65 -130 minecraft:birch_log[axis=y]
fill 94 65 -130 97 65 -130 minecraft:air
fill 106 65 -130 135 65 -130 minecraft:air
fill 72 65 -131 75 65 -131 minecraft:dirt
setblock 85 65 -131 minecraft:dirt
fill 86 65 -131 90 65 -131 minecraft:grass_block[snowy=false]
fill 91 65 -131 97 65 -131 minecraft:air
fill 106 65 -131 125 65 -131 minecraft:air
setblock 126 65 -131 minecraft:birch_log[axis=y]
fill 127 65 -131 135 65 -131 minecraft:air
fill 72 65 -132 76 65 -132 minecraft:dirt
fill 86 65 -132 90 65 -132 minecraft:grass_block[snowy=false]
fill 91 65 -132 97 65 -132 minecraft:air
fill 105 65 -132 106 65 -132 minecraft:air
setblock 107 65 -132 minecraft:birch_log[axis=y]
fill 108 65 -132 135 65 -132 minecraft:air
fill 72 65 -133 75 65 -133 minecraft:air
fill 77 65 -133 78 65 -133 minecraft:dirt
fill 86 65 -133 90 65 -133 minecraft:grass_block[snowy=false]
fill 91 65 -133 98 65 -133 minecraft:air
fill 105 65 -133 128 65 -133 minecraft:air
setblock 129 65 -133 minecraft:birch_log[axis=y]
fill 130 65 -133 135 65 -133 minecraft:air
fill 72 65 -134 77 65 -134 minecraft:air
fill 78 65 -134 80 65 -134 minecraft:dirt
fill 86 65 -134 89 65 -134 minecraft:grass_block[snowy=false]
fill 90 65 -134 98 65 -134 minecraft:air
fill 103 65 -134 135 65 -134 minecraft:air
fill 72 65 -135 78 65 -135 minecraft:air
fill 79 65 -135 81 65 -135 minecraft:dirt
fill 86 65 -135 89 65 -135 minecraft:grass_block[snowy=false]
fill 90 65 -135 98 65 -135 minecraft:air
fill 103 65 -135 133 65 -135 minecraft:air
setblock 134 65 -135 minecraft:birch_log[axis=y]
setblock 135 65 -135 minecraft:air
fill 72 65 -136 75 65 -136 minecraft:air
setblock 76 65 -136 minecraft:short_grass
setblock 77 65 -136 minecraft:air
fill 80 65 -136 82 65 -136 minecraft:dirt
fill 86 65 -136 89 65 -136 minecraft:grass_block[snowy=false]
fill 90 65 -136 98 65 -136 minecraft:air
fill 102 65 -136 135 65 -136 minecraft:air
fill 72 65 -137 75 65 -137 minecraft:dirt
fill 80 65 -137 84 65 -137 minecraft:dirt
fill 86 65 -137 89 65 -137 minecraft:grass_block[snowy=false]
fill 90 65 -137 97 65 -137 minecraft:air
setblock 98 65 -137 minecraft:birch_log[axis=y]
fill 101 65 -137 108 65 -137 minecraft:air
setblock 109 65 -137 minecraft:birch_log[axis=y]
fill 110 65 -137 135 65 -137 minecraft:air
fill 72 65 -138 75 65 -138 minecraft:dirt
fill 80 65 -138 84 65 -138 minecraft:dirt
fill 86 65 -138 90 65 -138 minecraft:grass_block[snowy=false]
fill 91 65 -138 135 65 -138 minecraft:air
fill 72 65 -139 76 65 -139 minecraft:dirt
fill 79 65 -139 85 65 -139 minecraft:dirt
fill 86 65 -139 90 65 -139 minecraft:grass_block[snowy=false]
fill 91 65 -139 95 65 -139 minecraft:air
setblock 96 65 -139 minecraft:birch_log[axis=y]
fill 97 65 -139 111 65 -139 minecraft:air
setblock 112 65 -139 minecraft:birch_log[axis=y]
fill 113 65 -139 135 65 -139 minecraft:air
fill 72 65 -140 76 65 -140 minecraft:dirt
fill 78 65 -140 79 65 -140 minecraft:air
fill 81 65 -140 85 65 -140 minecraft:dirt
fill 86 65 -140 90 65 -140 minecraft:grass_block[snowy=false]
setblock 92 65 -140 minecraft:short_grass
setblock 93 65 -140 regions_unexplored:grass_sprouts
setblock 94 65 -140 minecraft:air
setblock 95 65 -140 regions_unexplored:grass_sprouts
fill 96 65 -140 135 65 -140 minecraft:air
fill 72 65 -141 76 65 -141 minecraft:dirt
fill 77 65 -141 79 65 -141 minecraft:air
fill 81 65 -141 86 65 -141 minecraft:dirt
fill 87 65 -141 90 65 -141 minecraft:grass_block[snowy=false]
setblock 91 65 -141 minecraft:dirt
fill 92 65 -141 96 65 -141 minecraft:air
setblock 97 65 -141 minecraft:short_grass
fill 98 65 -141 135 65 -141 minecraft:air
fill 72 65 -142 76 65 -142 minecraft:dirt
fill 77 65 -142 80 65 -142 minecraft:air
fill 81 65 -142 87 65 -142 minecraft:dirt
fill 88 65 -142 90 65 -142 minecraft:grass_block[snowy=false]
setblock 93 65 -142 regions_unexplored:grass_sprouts
fill 94 65 -142 135 65 -142 minecraft:air
fill 72 65 -143 77 65 -143 minecraft:dirt
fill 78 65 -143 81 65 -143 minecraft:air
fill 82 65 -143 88 65 -143 minecraft:dirt
fill 89 65 -143 90 65 -143 minecraft:grass_block[snowy=false]
fill 94 65 -143 135 65 -143 minecraft:air
fill 72 65 -144 77 65 -144 minecraft:dirt
fill 78 65 -144 81 65 -144 minecraft:air
fill 82 65 -144 88 65 -144 minecraft:dirt
fill 89 65 -144 90 65 -144 minecraft:grass_block[snowy=false]
fill 95 65 -144 97 65 -144 minecraft:air
setblock 98 65 -144 regions_unexplored:grass_sprouts
fill 99 65 -144 109 65 -144 minecraft:air
setblock 110 65 -144 minecraft:birch_log[axis=y]
fill 111 65 -144 112 65 -144 minecraft:air
setblock 113 65 -144 minecraft:birch_log[axis=y]
fill 114 65 -144 118 65 -144 minecraft:air
setblock 119 65 -144 minecraft:birch_log[axis=y]
fill 120 65 -144 135 65 -144 minecraft:air
fill 72 65 -145 78 65 -145 minecraft:dirt
fill 79 65 -145 82 65 -145 minecraft:air
fill 83 65 -145 88 65 -145 minecraft:dirt
fill 89 65 -145 90 65 -145 minecraft:grass_block[snowy=false]
fill 95 65 -145 96 65 -145 minecraft:air
setblock 97 65 -145 regions_unexplored:grass_sprouts
fill 98 65 -145 135 65 -145 minecraft:air
fill 72 65 -146 79 65 -146 minecraft:dirt
fill 80 65 -146 81 65 -146 minecraft:air
fill 82 65 -146 88 65 -146 minecraft:dirt
fill 89 65 -146 90 65 -146 minecraft:grass_block[snowy=false]
fill 94 65 -146 98 65 -146 minecraft:air
setblock 99 65 -146 regions_unexplored:grass_sprouts
fill 100 65 -146 119 65 -146 minecraft:air
setblock 120 65 -146 minecraft:birch_log[axis=y]
fill 121 65 -146 135 65 -146 minecraft:air
fill 72 65 -147 89 65 -147 minecraft:dirt
setblock 90 65 -147 minecraft:grass_block[snowy=false]
setblock 94 65 -147 minecraft:short_grass
setblock 95 65 -147 regions_unexplored:grass_sprouts
fill 96 65 -147 98 65 -147 minecraft:air
setblock 99 65 -147 regions_unexplored:grass_sprouts
fill 100 65 -147 115 65 -147 minecraft:air
setblock 116 65 -147 minecraft:birch_log[axis=y]
fill 117 65 -147 135 65 -147 minecraft:air
fill 72 65 -148 89 65 -148 minecraft:dirt
setblock 90 65 -148 minecraft:grass_block[snowy=false]
setblock 92 65 -148 minecraft:dirt
fill 94 65 -148 96 65 -148 minecraft:air
setblock 97 65 -148 regions_unexplored:grass_sprouts
fill 98 65 -148 124 65 -148 minecraft:air
setblock 125 65 -148 minecraft:birch_log[axis=y]
fill 126 65 -148 135 65 -148 minecraft:air
fill 72 65 -149 89 65 -149 minecraft:dirt
setblock 90 65 -149 minecraft:grass_block[snowy=false]
fill 95 65 -149 103 65 -149 minecraft:air
setblock 104 65 -149 minecraft:birch_log[axis=y]
fill 105 65 -149 117 65 -149 minecraft:air
setblock 118 65 -149 minecraft:birch_log[axis=y]
fill 119 65 -149 126 65 -149 minecraft:air
setblock 127 65 -149 minecraft:birch_log[axis=y]
fill 128 65 -149 135 65 -149 minecraft:air
fill 72 65 -150 89 65 -150 minecraft:dirt
setblock 90 65 -150 minecraft:grass_block[snowy=false]
setblock 93 65 -150 minecraft:dirt
setblock 95 65 -150 regions_unexplored:grass_sprouts
fill 96 65 -150 97 65 -150 minecraft:air
setblock 98 65 -150 minecraft:short_grass
setblock 99 65 -150 minecraft:birch_log[axis=y]
fill 100 65 -150 115 65 -150 minecraft:air
setblock 116 65 -150 minecraft:birch_log[axis=y]
fill 117 65 -150 135 65 -150 minecraft:air
fill 72 65 -151 89 65 -151 minecraft:dirt
setblock 90 65 -151 minecraft:grass_block[snowy=false]
fill 95 65 -151 135 65 -151 minecraft:air
fill 72 65 -152 90 65 -152 minecraft:dirt
setblock 95 65 -152 minecraft:birch_log[axis=y]
fill 96 65 -152 101 65 -152 minecraft:air
setblock 102 65 -152 minecraft:birch_log[axis=y]
fill 103 65 -152 135 65 -152 minecraft:air
fill 72 65 -153 90 65 -153 minecraft:dirt
fill 95 65 -153 135 65 -153 minecraft:air
fill 72 65 -154 89 65 -154 minecraft:dirt
setblock 90 65 -154 minecraft:grass_block[snowy=false]
fill 95 65 -154 97 65 -154 minecraft:air
setblock 98 65 -154 minecraft:short_grass
fill 99 65 -154 128 65 -154 minecraft:air
setblock 129 65 -154 productivebees:birch_wood_nest[axis=y,facing=north]
fill 130 65 -154 135 65 -154 minecraft:air
fill 72 65 -155 89 65 -155 minecraft:dirt
setblock 90 65 -155 minecraft:grass_block[snowy=false]
fill 94 65 -155 107 65 -155 minecraft:air
setblock 108 65 -155 minecraft:birch_log[axis=y]
fill 109 65 -155 135 65 -155 minecraft:air
fill 72 65 -156 89 65 -156 minecraft:dirt
setblock 90 65 -156 minecraft:grass_block[snowy=false]
fill 94 65 -156 109 65 -156 minecraft:air
setblock 110 65 -156 minecraft:birch_log[axis=y]
fill 111 65 -156 135 65 -156 minecraft:air
fill 72 65 -157 89 65 -157 minecraft:dirt
setblock 90 65 -157 minecraft:grass_block[snowy=false]
fill 94 65 -157 97 65 -157 minecraft:air
setblock 98 65 -157 minecraft:birch_log[axis=y]
fill 99 65 -157 112 65 -157 minecraft:air
fill 113 65 -157 116 65 -157 minecraft:cave_air
fill 117 65 -157 132 65 -157 minecraft:air
setblock 133 65 -157 minecraft:birch_log[axis=y]
fill 134 65 -157 135 65 -157 minecraft:air
fill 72 65 -158 89 65 -158 minecraft:dirt
setblock 90 65 -158 minecraft:grass_block[snowy=false]
setblock 91 65 -158 minecraft:dirt
fill 94 65 -158 110 65 -158 minecraft:air
fill 111 65 -158 118 65 -158 minecraft:cave_air
fill 119 65 -158 135 65 -158 minecraft:air
fill 72 65 -159 79 65 -159 minecraft:dirt
setblock 96 65 -159 minecraft:air
setblock 97 65 -159 productivebees:birch_wood_nest[axis=y,facing=north]
fill 98 65 -159 110 65 -159 minecraft:air
fill 111 65 -159 119 65 -159 minecraft:cave_air
fill 120 65 -159 135 65 -159 minecraft:air
fill 72 65 -160 74 65 -160 minecraft:air
fill 78 65 -160 80 65 -160 minecraft:air
fill 100 65 -160 111 65 -160 minecraft:air
fill 112 65 -160 119 65 -160 minecraft:cave_air
fill 120 65 -160 135 65 -160 minecraft:air
fill 72 65 -161 73 65 -161 minecraft:air
fill 102 65 -161 112 65 -161 minecraft:air
fill 113 65 -161 119 65 -161 minecraft:cave_air
fill 120 65 -161 135 65 -161 minecraft:air
fill 106 65 -162 112 65 -162 minecraft:air
fill 113 65 -162 119 65 -162 minecraft:cave_air
fill 120 65 -162 135 65 -162 minecraft:air
fill 109 65 -163 112 65 -163 minecraft:air
fill 113 65 -163 119 65 -163 minecraft:cave_air
fill 120 65 -163 135 65 -163 minecraft:air
fill 112 65 -164 113 65 -164 minecraft:air
fill 114 65 -164 117 65 -164 minecraft:cave_air
fill 118 65 -164 135 65 -164 minecraft:air
setblock 114 65 -165 minecraft:air
setblock 115 65 -165 minecraft:cave_air
fill 116 65 -165 135 65 -165 minecraft:air
fill 116 65 -166 135 65 -166 minecraft:air
fill 118 65 -167 135 65 -167 minecraft:air
fill 120 65 -168 135 65 -168 minecraft:air
fill 121 65 -169 135 65 -169 minecraft:air
fill 123 65 -170 135 65 -170 minecraft:air
fill 124 65 -171 135 65 -171 minecraft:air
fill 126 65 -172 135 65 -172 minecraft:air
fill 127 65 -173 135 65 -173 minecraft:air
fill 128 65 -174 135 65 -174 minecraft:air
fill 129 65 -175 135 65 -175 minecraft:air
fill 130 65 -176 135 65 -176 minecraft:air
fill 131 65 -177 135 65 -177 minecraft:air
fill 132 65 -178 135 65 -178 minecraft:air
fill 133 65 -179 135 65 -179 minecraft:air
fill 134 65 -180 135 65 -180 minecraft:air
setblock 135 65 -181 minecraft:air
fill 109 64 -127 128 64 -127 minecraft:air
fill 110 64 -128 129 64 -128 minecraft:air
fill 110 64 -129 126 64 -129 minecraft:air
setblock 127 64 -129 regions_unexplored:grass_sprouts
fill 128 64 -129 131 64 -129 minecraft:air
fill 108 64 -130 134 64 -130 minecraft:air
fill 107 64 -131 125 64 -131 minecraft:air
fill 127 64 -131 131 64 -131 minecraft:air
setblock 132 64 -131 regions_unexplored:grass_sprouts
fill 133 64 -131 134 64 -131 minecraft:air
setblock 135 64 -131 minecraft:short_grass
setblock 96 64 -132 minecraft:air
fill 108 64 -132 135 64 -132 minecraft:air
setblock 72 64 -133 minecraft:air
setblock 96 64 -133 minecraft:air
fill 106 64 -133 128 64 -133 minecraft:air
fill 130 64 -133 135 64 -133 minecraft:air
fill 72 64 -134 73 64 -134 minecraft:air
fill 95 64 -134 96 64 -134 minecraft:air
fill 106 64 -134 108 64 -134 minecraft:air
setblock 109 64 -134 regions_unexplored:grass_sprouts
fill 110 64 -134 135 64 -134 minecraft:air
setblock 72 64 -135 minecraft:air
fill 95 64 -135 96 64 -135 minecraft:air
fill 105 64 -135 109 64 -135 minecraft:air
setblock 110 64 -135 minecraft:short_grass
fill 111 64 -135 133 64 -135 minecraft:air
setblock 135 64 -135 minecraft:air
setblock 72 64 -136 minecraft:air
fill 95 64 -136 96 64 -136 minecraft:air
fill 104 64 -136 105 64 -136 minecraft:air
fill 106 64 -136 107 64 -136 regions_unexplored:grass_sprouts
fill 108 64 -136 135 64 -136 minecraft:air
setblock 96 64 -137 minecraft:air
setblock 103 64 -137 regions_unexplored:grass_sprouts
fill 104 64 -137 105 64 -137 minecraft:air
setblock 106 64 -137 regions_unexplored:grass_sprouts
fill 107 64 -137 108 64 -137 minecraft:air
fill 110 64 -137 135 64 -137 minecraft:air
fill 102 64 -138 104 64 -138 minecraft:air
setblock 105 64 -138 minecraft:short_grass
fill 106 64 -138 109 64 -138 minecraft:air
setblock 110 64 -138 minecraft:short_grass
fill 111 64 -138 135 64 -138 minecraft:air
setblock 101 64 -139 minecraft:short_grass
fill 102 64 -139 103 64 -139 regions_unexplored:grass_sprouts
setblock 104 64 -139 minecraft:air
setblock 105 64 -139 minecraft:short_grass
fill 106 64 -139 107 64 -139 minecraft:air
setblock 108 64 -139 minecraft:short_grass
setblock 109 64 -139 regions_unexplored:grass_sprouts
setblock 110 64 -139 minecraft:air
setblock 111 64 -139 minecraft:short_grass
fill 113 64 -139 135 64 -139 minecraft:air
fill 98 64 -140 101 64 -140 minecraft:air
setblock 102 64 -140 regions_unexplored:grass_sprouts
fill 103 64 -140 104 64 -140 minecraft:air
setblock 105 64 -140 minecraft:short_grass
fill 106 64 -140 108 64 -140 minecraft:air
setblock 109 64 -140 regions_unexplored:grass_sprouts
fill 110 64 -140 135 64 -140 minecraft:air
fill 98 64 -141 135 64 -141 minecraft:air
fill 99 64 -142 101 64 -142 minecraft:air
setblock 102 64 -142 regions_unexplored:grass_sprouts
fill 103 64 -142 109 64 -142 minecraft:air
fill 110 64 -142 111 64 -142 regions_unexplored:grass_sprouts
fill 112 64 -142 135 64 -142 minecraft:air
fill 79 64 -143 80 64 -143 minecraft:air
setblock 99 64 -143 minecraft:short_grass
fill 100 64 -143 101 64 -143 minecraft:air
setblock 102 64 -143 minecraft:short_grass
setblock 103 64 -143 minecraft:air
setblock 104 64 -143 regions_unexplored:grass_sprouts
fill 105 64 -143 107 64 -143 minecraft:air
setblock 108 64 -143 minecraft:short_grass
fill 109 64 -143 135 64 -143 minecraft:air
fill 79 64 -144 81 64 -144 minecraft:air
setblock 100 64 -144 minecraft:air
setblock 101 64 -144 minecraft:short_grass
fill 102 64 -144 107 64 -144 minecraft:air
setblock 108 64 -144 minecraft:short_grass
setblock 109 64 -144 minecraft:air
setblock 111 64 -144 regions_unexplored:grass_sprouts
setblock 112 64 -144 minecraft:air
fill 114 64 -144 118 64 -144 minecraft:air
fill 120 64 -144 135 64 -144 minecraft:air
fill 79 64 -145 82 64 -145 minecraft:air
setblock 100 64 -145 minecraft:air
setblock 101 64 -145 minecraft:short_grass
fill 102 64 -145 106 64 -145 minecraft:air
setblock 107 64 -145 minecraft:short_grass
fill 108 64 -145 135 64 -145 minecraft:air
fill 80 64 -146 81 64 -146 minecraft:air
fill 100 64 -146 102 64 -146 minecraft:air
setblock 103 64 -146 minecraft:short_grass
fill 104 64 -146 119 64 -146 minecraft:air
fill 121 64 -146 135 64 -146 minecraft:air
fill 100 64 -147 115 64 -147 minecraft:air
fill 117 64 -147 135 64 -147 minecraft:air
fill 100 64 -148 117 64 -148 minecraft:air
setblock 118 64 -148 regions_unexplored:grass_sprouts
fill 119 64 -148 124 64 -148 minecraft:air
fill 126 64 -148 135 64 -148 minecraft:air
fill 100 64 -149 103 64 -149 minecraft:air
fill 105 64 -149 109 64 -149 minecraft:air
setblock 110 64 -149 minecraft:short_grass
fill 111 64 -149 113 64 -149 minecraft:air
setblock 114 64 -149 minecraft:short_grass
fill 115 64 -149 116 64 -149 minecraft:air
setblock 117 64 -149 minecraft:short_grass
fill 119 64 -149 126 64 -149 minecraft:air
fill 128 64 -149 134 64 -149 minecraft:air
fill 100 64 -150 115 64 -150 minecraft:air
setblock 117 64 -150 minecraft:short_grass
fill 118 64 -150 135 64 -150 minecraft:air
fill 99 64 -151 115 64 -151 minecraft:air
setblock 116 64 -151 regions_unexplored:grass_sprouts
fill 117 64 -151 135 64 -151 minecraft:air
fill 99 64 -152 101 64 -152 minecraft:air
fill 103 64 -152 114 64 -152 minecraft:air
setblock 115 64 -152 minecraft:short_grass
setblock 116 64 -152 minecraft:air
setblock 117 64 -152 minecraft:short_grass
fill 118 64 -152 135 64 -152 minecraft:air
fill 99 64 -153 114 64 -153 minecraft:air
setblock 115 64 -153 regions_unexplored:grass_sprouts
fill 116 64 -153 135 64 -153 minecraft:air
setblock 100 64 -154 minecraft:short_grass
fill 101 64 -154 118 64 -154 minecraft:air
setblock 119 64 -154 regions_unexplored:grass_sprouts
fill 120 64 -154 128 64 -154 minecraft:air
fill 130 64 -154 135 64 -154 minecraft:air
fill 100 64 -155 107 64 -155 minecraft:air
fill 109 64 -155 135 64 -155 minecraft:air
fill 100 64 -156 109 64 -156 minecraft:air
fill 111 64 -156 135 64 -156 minecraft:air
fill 100 64 -157 132 64 -157 minecraft:air
fill 134 64 -157 135 64 -157 minecraft:air
fill 100 64 -158 105 64 -158 minecraft:air
setblock 106 64 -158 minecraft:short_grass
fill 107 64 -158 111 64 -158 minecraft:air
setblock 112 64 -158 minecraft:cave_air
fill 113 64 -158 122 64 -158 minecraft:air
setblock 123 64 -158 minecraft:short_grass
fill 124 64 -158 135 64 -158 minecraft:air
fill 100 64 -159 135 64 -159 minecraft:air
fill 72 64 -160 74 64 -160 minecraft:air
fill 78 64 -160 95 64 -160 minecraft:air
fill 100 64 -160 135 64 -160 minecraft:air
fill 72 64 -161 73 64 -161 minecraft:air
fill 75 64 -161 135 64 -161 minecraft:air
fill 72 64 -162 83 64 -162 minecraft:air
fill 93 64 -162 118 64 -162 minecraft:air
fill 119 64 -162 120 64 -162 minecraft:cave_air
fill 121 64 -162 135 64 -162 minecraft:air
fill 72 64 -163 76 64 -163 minecraft:air
fill 100 64 -163 117 64 -163 minecraft:air
setblock 118 64 -163 minecraft:cave_air
fill 119 64 -163 135 64 -163 minecraft:air
setblock 72 64 -164 minecraft:air
fill 104 64 -164 116 64 -164 minecraft:air
fill 117 64 -164 118 64 -164 minecraft:cave_air
fill 119 64 -164 135 64 -164 minecraft:air
fill 108 64 -165 115 64 -165 minecraft:air
setblock 116 64 -165 minecraft:cave_air
fill 117 64 -165 135 64 -165 minecraft:air
fill 110 64 -166 135 64 -166 minecraft:air
fill 113 64 -167 135 64 -167 minecraft:air
fill 80 64 -168 96 64 -168 minecraft:air
fill 115 64 -168 135 64 -168 minecraft:air
fill 75 64 -169 101 64 -169 minecraft:air
fill 117 64 -169 135 64 -169 minecraft:air
fill 72 64 -170 104 64 -170 minecraft:air
fill 119 64 -170 135 64 -170 minecraft:air
setblock 72 64 -171 minecraft:air
fill 74 64 -171 77 64 -171 minecraft:air
fill 79 64 -171 82 64 -171 minecraft:air
fill 84 64 -171 87 64 -171 minecraft:air
setblock 89 64 -171 minecraft:air
fill 91 64 -171 92 64 -171 minecraft:air
fill 94 64 -171 97 64 -171 minecraft:air
fill 99 64 -171 102 64 -171 minecraft:air
fill 104 64 -171 107 64 -171 minecraft:air
fill 120 64 -171 135 64 -171 minecraft:air
fill 72 64 -172 76 64 -172 minecraft:air
fill 78 64 -172 109 64 -172 minecraft:air
fill 122 64 -172 135 64 -172 minecraft:air
fill 72 64 -173 112 64 -173 minecraft:air
fill 123 64 -173 135 64 -173 minecraft:air
fill 72 64 -174 113 64 -174 minecraft:air
fill 124 64 -174 135 64 -174 minecraft:air
fill 72 64 -175 114 64 -175 minecraft:air
fill 126 64 -175 135 64 -175 minecraft:air
setblock 72 64 -176 minecraft:air
fill 74 64 -176 77 64 -176 minecraft:air
fill 79 64 -176 82 64 -176 minecraft:air
fill 84 64 -176 87 64 -176 minecraft:air
fill 89 64 -176 92 64 -176 minecraft:air
fill 94 64 -176 97 64 -176 minecraft:air
fill 99 64 -176 102 64 -176 minecraft:air
fill 104 64 -176 107 64 -176 minecraft:air
fill 109 64 -176 112 64 -176 minecraft:air
fill 116 64 -176 117 64 -176 minecraft:air
fill 127 64 -176 135 64 -176 minecraft:air
fill 72 64 -177 110 64 -177 minecraft:air
fill 116 64 -177 118 64 -177 minecraft:air
fill 128 64 -177 135 64 -177 minecraft:air
fill 72 64 -178 108 64 -178 minecraft:air
fill 116 64 -178 120 64 -178 minecraft:air
fill 129 64 -178 135 64 -178 minecraft:air
fill 72 64 -179 83 64 -179 minecraft:air
fill 85 64 -179 106 64 -179 minecraft:air
fill 116 64 -179 121 64 -179 minecraft:air
fill 130 64 -179 135 64 -179 minecraft:air
fill 72 64 -180 104 64 -180 minecraft:air
fill 116 64 -180 122 64 -180 minecraft:air
fill 125 64 -180 135 64 -180 minecraft:air
setblock 72 64 -181 minecraft:air
fill 74 64 -181 77 64 -181 minecraft:air
fill 79 64 -181 82 64 -181 minecraft:air
fill 84 64 -181 87 64 -181 minecraft:air
fill 89 64 -181 92 64 -181 minecraft:air
fill 94 64 -181 97 64 -181 minecraft:air
fill 99 64 -181 102 64 -181 minecraft:air
fill 116 64 -181 117 64 -181 minecraft:air
fill 119 64 -181 122 64 -181 minecraft:air
fill 126 64 -181 135 64 -181 minecraft:air
fill 72 64 -182 100 64 -182 minecraft:air
fill 117 64 -182 124 64 -182 minecraft:air
fill 127 64 -182 135 64 -182 minecraft:air
fill 72 64 -183 98 64 -183 minecraft:air
fill 117 64 -183 125 64 -183 minecraft:air
fill 128 64 -183 135 64 -183 minecraft:air
fill 72 64 -184 95 64 -184 minecraft:air
fill 117 64 -184 126 64 -184 minecraft:air
fill 129 64 -184 135 64 -184 minecraft:air
fill 72 64 -185 93 64 -185 minecraft:air
fill 117 64 -185 127 64 -185 minecraft:air
fill 130 64 -185 135 64 -185 minecraft:air
fill 74 64 -186 77 64 -186 minecraft:air
fill 79 64 -186 82 64 -186 minecraft:air
fill 84 64 -186 87 64 -186 minecraft:air
fill 89 64 -186 91 64 -186 minecraft:air
setblock 117 64 -186 minecraft:air
fill 119 64 -186 122 64 -186 minecraft:air
fill 124 64 -186 127 64 -186 minecraft:air
fill 131 64 -186 135 64 -186 minecraft:air
fill 78 64 -187 89 64 -187 minecraft:air
fill 117 64 -187 129 64 -187 minecraft:air
fill 132 64 -187 135 64 -187 minecraft:air
fill 81 64 -188 87 64 -188 minecraft:air
fill 117 64 -188 130 64 -188 minecraft:air
fill 133 64 -188 135 64 -188 minecraft:air
setblock 85 64 -189 minecraft:air
fill 117 64 -189 131 64 -189 minecraft:air
fill 133 64 -189 135 64 -189 minecraft:air
fill 117 64 -190 131 64 -190 minecraft:air
fill 134 64 -190 135 64 -190 minecraft:air
fill 109 63 -127 122 63 -127 minecraft:air
fill 110 63 -128 119 63 -128 minecraft:air
setblock 120 63 -128 regions_unexplored:grass_sprouts
fill 121 63 -128 122 63 -128 minecraft:air
setblock 123 63 -128 minecraft:short_grass
setblock 124 63 -128 minecraft:air
setblock 125 63 -128 minecraft:short_grass
fill 111 63 -129 120 63 -129 minecraft:air
setblock 121 63 -129 regions_unexplored:grass_sprouts
setblock 122 63 -129 minecraft:air
setblock 123 63 -129 regions_unexplored:grass_sprouts
fill 124 63 -129 126 63 -129 minecraft:air
fill 111 63 -130 128 63 -130 minecraft:air
fill 112 63 -131 124 63 -131 minecraft:air
setblock 125 63 -131 regions_unexplored:grass_sprouts
setblock 127 63 -131 minecraft:air
setblock 128 63 -131 minecraft:short_grass
fill 129 63 -131 131 63 -131 minecraft:air
fill 111 63 -132 126 63 -132 minecraft:air
setblock 127 63 -132 regions_unexplored:grass_sprouts
fill 128 63 -132 129 63 -132 minecraft:air
setblock 130 63 -132 regions_unexplored:grass_sprouts
fill 131 63 -132 133 63 -132 minecraft:air
fill 111 63 -133 124 63 -133 minecraft:air
setblock 125 63 -133 regions_unexplored:grass_sprouts
setblock 126 63 -133 minecraft:air
setblock 127 63 -133 regions_unexplored:grass_sprouts
setblock 128 63 -133 minecraft:air
fill 130 63 -133 131 63 -133 minecraft:air
setblock 132 63 -133 regions_unexplored:grass_sprouts
fill 133 63 -133 134 63 -133 minecraft:air
setblock 135 63 -133 minecraft:short_grass
fill 111 63 -134 124 63 -134 minecraft:air
setblock 125 63 -134 regions_unexplored:grass_sprouts
fill 126 63 -134 130 63 -134 minecraft:air
setblock 131 63 -134 regions_unexplored:grass_sprouts
fill 132 63 -134 135 63 -134 minecraft:air
setblock 111 63 -135 minecraft:air
setblock 112 63 -135 regions_unexplored:grass_sprouts
fill 113 63 -135 123 63 -135 minecraft:air
setblock 125 63 -135 minecraft:short_grass
fill 126 63 -135 131 63 -135 minecraft:air
setblock 132 63 -135 regions_unexplored:grass_sprouts
setblock 133 63 -135 minecraft:air
setblock 135 63 -135 minecraft:air
fill 111 63 -136 122 63 -136 minecraft:air
setblock 123 63 -136 minecraft:short_grass
fill 124 63 -136 135 63 -136 minecraft:air
fill 111 63 -137 119 63 -137 minecraft:air
fill 120 63 -137 121 63 -137 minecraft:short_grass
fill 122 63 -137 131 63 -137 minecraft:air
setblock 132 63 -137 minecraft:short_grass
fill 133 63 -137 135 63 -137 minecraft:air
fill 112 63 -138 114 63 -138 minecraft:air
setblock 115 63 -138 minecraft:short_grass
fill 116 63 -138 120 63 -138 minecraft:air
setblock 121 63 -138 regions_unexplored:grass_sprouts
fill 122 63 -138 123 63 -138 minecraft:air
setblock 124 63 -138 regions_unexplored:grass_sprouts
fill 125 63 -138 130 63 -138 minecraft:air
setblock 131 63 -138 regions_unexplored:grass_sprouts
fill 132 63 -138 135 63 -138 minecraft:air
fill 113 63 -139 130 63 -139 minecraft:air
setblock 131 63 -139 regions_unexplored:grass_sprouts
fill 132 63 -139 135 63 -139 minecraft:air
setblock 114 63 -140 minecraft:short_grass
fill 115 63 -140 120 63 -140 minecraft:air
setblock 121 63 -140 minecraft:short_grass
fill 122 63 -140 126 63 -140 minecraft:air
setblock 127 63 -140 minecraft:short_grass
fill 128 63 -140 129 63 -140 minecraft:air
setblock 130 63 -140 regions_unexplored:grass_sprouts
fill 131 63 -140 132 63 -140 minecraft:air
setblock 133 63 -140 minecraft:short_grass
fill 134 63 -140 135 63 -140 minecraft:air
fill 115 63 -141 116 63 -141 minecraft:air
setblock 117 63 -141 minecraft:short_grass
fill 118 63 -141 122 63 -141 minecraft:air
fill 124 63 -141 128 63 -141 minecraft:air
setblock 129 63 -141 regions_unexplored:grass_sprouts
fill 130 63 -141 135 63 -141 minecraft:air
fill 116 63 -142 135 63 -142 minecraft:air
setblock 117 63 -143 minecraft:air
setblock 118 63 -143 minecraft:short_grass
setblock 119 63 -143 regions_unexplored:grass_sprouts
fill 120 63 -143 122 63 -143 minecraft:air
setblock 123 63 -143 minecraft:short_grass
fill 124 63 -143 130 63 -143 minecraft:air
fill 132 63 -143 135 63 -143 minecraft:air
setblock 117 63 -144 minecraft:air
setblock 118 63 -144 regions_unexplored:grass_sprouts
fill 120 63 -144 124 63 -144 minecraft:air
setblock 125 63 -144 regions_unexplored:grass_sprouts
fill 126 63 -144 132 63 -144 minecraft:air
setblock 133 63 -144 regions_unexplored:grass_sprouts
setblock 134 63 -144 minecraft:air
setblock 135 63 -144 regions_unexplored:grass_sprouts
setblock 117 63 -145 minecraft:air
setblock 118 63 -145 regions_unexplored:grass_sprouts
fill 119 63 -145 125 63 -145 minecraft:air
setblock 126 63 -145 minecraft:short_grass
fill 127 63 -145 135 63 -145 minecraft:air
setblock 118 63 -146 regions_unexplored:grass_sprouts
setblock 119 63 -146 minecraft:air
fill 121 63 -146 122 63 -146 minecraft:air
setblock 123 63 -146 regions_unexplored:grass_sprouts
setblock 124 63 -146 minecraft:air
setblock 125 63 -146 regions_unexplored:grass_sprouts
fill 126 63 -146 127 63 -146 minecraft:air
setblock 129 63 -146 minecraft:short_grass
fill 130 63 -146 133 63 -146 minecraft:air
setblock 134 63 -146 minecraft:short_grass
setblock 135 63 -146 minecraft:air
setblock 118 63 -147 regions_unexplored:grass_sprouts
fill 119 63 -147 122 63 -147 minecraft:air
setblock 123 63 -147 regions_unexplored:grass_sprouts
setblock 124 63 -147 minecraft:air
setblock 125 63 -147 regions_unexplored:grass_sprouts
fill 126 63 -147 130 63 -147 minecraft:air
fill 132 63 -147 135 63 -147 minecraft:air
fill 119 63 -148 124 63 -148 minecraft:air
setblock 126 63 -148 regions_unexplored:grass_sprouts
fill 127 63 -148 130 63 -148 minecraft:air
fill 131 63 -148 132 63 -148 regions_unexplored:grass_sprouts
fill 133 63 -148 135 63 -148 minecraft:air
setblock 119 63 -149 minecraft:air
setblock 120 63 -149 minecraft:short_grass
setblock 121 63 -149 regions_unexplored:grass_sprouts
fill 122 63 -149 124 63 -149 minecraft:air
setblock 125 63 -149 minecraft:short_grass
setblock 126 63 -149 minecraft:air
fill 128 63 -149 132 63 -149 minecraft:air
setblock 133 63 -149 regions_unexplored:grass_sprouts
setblock 134 63 -149 minecraft:air
fill 120 63 -150 135 63 -150 minecraft:air
fill 120 63 -151 121 63 -151 minecraft:air
fill 122 63 -151 123 63 -151 regions_unexplored:grass_sprouts
setblock 124 63 -151 minecraft:air
fill 125 63 -151 126 63 -151 minecraft:short_grass
fill 127 63 -151 132 63 -151 minecraft:air
setblock 133 63 -151 regions_unexplored:grass_sprouts
fill 134 63 -151 135 63 -151 minecraft:air
setblock 120 63 -152 regions_unexplored:grass_sprouts
fill 121 63 -152 134 63 -152 minecraft:air
setblock 135 63 -152 regions_unexplored:grass_sprouts
fill 121 63 -153 135 63 -153 minecraft:air
fill 122 63 -154 128 63 -154 minecraft:air
fill 130 63 -154 133 63 -154 minecraft:air
setblock 134 63 -154 minecraft:short_grass
setblock 135 63 -154 minecraft:air
fill 123 63 -155 127 63 -155 minecraft:air
setblock 128 63 -155 regions_unexplored:grass_sprouts
fill 129 63 -155 130 63 -155 minecraft:air
setblock 131 63 -155 minecraft:short_grass
fill 132 63 -155 135 63 -155 minecraft:air
fill 124 63 -156 135 63 -156 minecraft:air
fill 115 63 -157 118 63 -157 minecraft:air
fill 125 63 -157 132 63 -157 minecraft:air
fill 134 63 -157 135 63 -157 minecraft:air
fill 114 63 -158 119 63 -158 minecraft:air
fill 125 63 -158 135 63 -158 minecraft:air
fill 113 63 -159 120 63 -159 minecraft:air
fill 125 63 -159 135 63 -159 minecraft:air
fill 72 63 -160 74 63 -160 minecraft:air
fill 78 63 -160 94 63 -160 minecraft:air
fill 100 63 -160 135 63 -160 minecraft:air
fill 72 63 -161 73 63 -161 minecraft:air
fill 79 63 -161 87 63 -161 minecraft:air
fill 89 63 -161 93 63 -161 minecraft:air
fill 99 63 -161 135 63 -161 minecraft:air
fill 72 63 -162 74 63 -162 minecraft:air
fill 78 63 -162 83 63 -162 minecraft:air
fill 98 63 -162 135 63 -162 minecraft:air
fill 72 63 -163 75 63 -163 minecraft:air
fill 100 63 -163 135 63 -163 minecraft:air
setblock 72 63 -164 minecraft:air
fill 104 63 -164 135 63 -164 minecraft:air
fill 108 63 -165 135 63 -165 minecraft:air
fill 111 63 -166 135 63 -166 minecraft:air
fill 113 63 -167 135 63 -167 minecraft:air
fill 115 63 -168 135 63 -168 minecraft:air
fill 117 63 -169 135 63 -169 minecraft:air
fill 119 63 -170 135 63 -170 minecraft:air
fill 120 63 -171 135 63 -171 minecraft:air
fill 122 63 -172 135 63 -172 minecraft:air
fill 123 63 -173 135 63 -173 minecraft:air
fill 124 63 -174 135 63 -174 minecraft:air
fill 126 63 -175 135 63 -175 minecraft:air
fill 127 63 -176 135 63 -176 minecraft:air
fill 128 63 -177 135 63 -177 minecraft:air
fill 129 63 -178 135 63 -178 minecraft:air
fill 130 63 -179 135 63 -179 minecraft:air
fill 125 63 -180 135 63 -180 minecraft:air
setblock 119 63 -181 minecraft:air
fill 126 63 -181 135 63 -181 minecraft:air
fill 127 63 -182 135 63 -182 minecraft:air
fill 128 63 -183 135 63 -183 minecraft:air
fill 129 63 -184 135 63 -184 minecraft:air
fill 130 63 -185 135 63 -185 minecraft:air
fill 131 63 -186 135 63 -186 minecraft:air
fill 132 63 -187 135 63 -187 minecraft:air
fill 133 63 -188 135 63 -188 minecraft:air
fill 133 63 -189 135 63 -189 minecraft:air
fill 134 63 -190 135 63 -190 minecraft:air
fill 113 62 -127 116 62 -127 minecraft:air
fill 114 62 -128 116 62 -128 minecraft:air
setblock 114 62 -129 minecraft:air
setblock 116 62 -129 minecraft:air
fill 134 62 -134 135 62 -134 minecraft:air
fill 134 62 -135 135 62 -135 minecraft:air
fill 134 62 -136 135 62 -136 minecraft:air
fill 134 62 -137 135 62 -137 minecraft:air
fill 134 62 -138 135 62 -138 minecraft:air
fill 134 62 -139 135 62 -139 minecraft:air
fill 134 62 -140 135 62 -140 minecraft:air
fill 134 62 -141 135 62 -141 minecraft:air
fill 134 62 -142 135 62 -142 minecraft:air
fill 115 62 -158 118 62 -158 minecraft:air
fill 114 62 -159 117 62 -159 minecraft:air
setblock 119 62 -159 minecraft:air
fill 72 62 -160 74 62 -160 minecraft:air
fill 78 62 -160 94 62 -160 minecraft:air
fill 100 62 -160 135 62 -160 minecraft:air
fill 72 62 -161 73 62 -161 minecraft:air
fill 79 62 -161 87 62 -161 minecraft:air
fill 89 62 -161 93 62 -161 minecraft:air
fill 99 62 -161 135 62 -161 minecraft:air
fill 72 62 -162 74 62 -162 minecraft:air
fill 78 62 -162 83 62 -162 minecraft:air
fill 98 62 -162 135 62 -162 minecraft:air
fill 72 62 -163 75 62 -163 minecraft:air
fill 100 62 -163 135 62 -163 minecraft:air
setblock 72 62 -164 minecraft:air
fill 104 62 -164 135 62 -164 minecraft:air
fill 108 62 -165 135 62 -165 minecraft:air
fill 111 62 -166 135 62 -166 minecraft:air
fill 113 62 -167 135 62 -167 minecraft:air
fill 115 62 -168 135 62 -168 minecraft:air
fill 117 62 -169 135 62 -169 minecraft:air
fill 119 62 -170 135 62 -170 minecraft:air
fill 120 62 -171 135 62 -171 minecraft:air
fill 122 62 -172 135 62 -172 minecraft:air
fill 123 62 -173 135 62 -173 minecraft:air
fill 124 62 -174 135 62 -174 minecraft:air
fill 126 62 -175 135 62 -175 minecraft:air
fill 127 62 -176 135 62 -176 minecraft:air
fill 128 62 -177 135 62 -177 minecraft:air
fill 129 62 -178 135 62 -178 minecraft:air
fill 130 62 -179 135 62 -179 minecraft:air
fill 125 62 -180 135 62 -180 minecraft:air
setblock 119 62 -181 minecraft:air
fill 126 62 -181 135 62 -181 minecraft:air
fill 127 62 -182 135 62 -182 minecraft:air
fill 128 62 -183 135 62 -183 minecraft:air
fill 129 62 -184 135 62 -184 minecraft:air
fill 130 62 -185 135 62 -185 minecraft:air
fill 131 62 -186 135 62 -186 minecraft:air
fill 132 62 -187 135 62 -187 minecraft:air
fill 133 62 -188 135 62 -188 minecraft:air
fill 133 62 -189 135 62 -189 minecraft:air
fill 134 62 -190 135 62 -190 minecraft:air
setblock 114 61 -127 minecraft:air
setblock 116 61 -127 minecraft:air
fill 114 61 -128 115 61 -128 minecraft:air
fill 126 61 -134 135 61 -134 minecraft:air
fill 126 61 -135 135 61 -135 minecraft:air
fill 126 61 -136 135 61 -136 minecraft:air
fill 126 61 -137 135 61 -137 minecraft:air
fill 126 61 -138 135 61 -138 minecraft:air
fill 129 61 -139 131 61 -139 minecraft:air
fill 72 61 -160 74 61 -160 minecraft:air
fill 78 61 -160 94 61 -160 minecraft:air
fill 100 61 -160 135 61 -160 minecraft:air
fill 72 61 -161 73 61 -161 minecraft:air
fill 79 61 -161 87 61 -161 minecraft:air
fill 89 61 -161 93 61 -161 minecraft:air
fill 99 61 -161 135 61 -161 minecraft:air
fill 72 61 -162 74 61 -162 minecraft:air
fill 78 61 -162 83 61 -162 minecraft:air
fill 98 61 -162 135 61 -162 minecraft:air
fill 72 61 -163 75 61 -163 minecraft:air
fill 100 61 -163 135 61 -163 minecraft:air
setblock 72 61 -164 minecraft:air
fill 104 61 -164 135 61 -164 minecraft:air
fill 108 61 -165 135 61 -165 minecraft:air
fill 111 61 -166 135 61 -166 minecraft:air
fill 113 61 -167 135 61 -167 minecraft:air
fill 115 61 -168 135 61 -168 minecraft:air
fill 117 61 -169 135 61 -169 minecraft:air
fill 119 61 -170 135 61 -170 minecraft:air
fill 120 61 -171 135 61 -171 minecraft:air
fill 122 61 -172 135 61 -172 minecraft:air
fill 123 61 -173 135 61 -173 minecraft:air
fill 124 61 -174 135 61 -174 minecraft:air
fill 126 61 -175 135 61 -175 minecraft:air
fill 127 61 -176 135 61 -176 minecraft:air
fill 128 61 -177 135 61 -177 minecraft:air
fill 129 61 -178 135 61 -178 minecraft:air
fill 130 61 -179 135 61 -179 minecraft:air
fill 125 61 -180 135 61 -180 minecraft:air
setblock 119 61 -181 minecraft:air
fill 126 61 -181 135 61 -181 minecraft:air
fill 127 61 -182 135 61 -182 minecraft:air
fill 128 61 -183 135 61 -183 minecraft:air
fill 129 61 -184 135 61 -184 minecraft:air
fill 130 61 -185 135 61 -185 minecraft:air
fill 131 61 -186 135 61 -186 minecraft:air
fill 132 61 -187 135 61 -187 minecraft:air
fill 133 61 -188 135 61 -188 minecraft:air
fill 133 61 -189 135 61 -189 minecraft:air
fill 134 61 -190 135 61 -190 minecraft:air
fill 126 60 -134 135 60 -134 minecraft:air
fill 126 60 -135 135 60 -135 minecraft:air
fill 126 60 -136 135 60 -136 minecraft:air
fill 126 60 -137 135 60 -137 minecraft:air
fill 126 60 -138 135 60 -138 minecraft:air
fill 129 60 -139 134 60 -139 minecraft:air
fill 72 60 -160 74 60 -160 minecraft:air
fill 78 60 -160 94 60 -160 minecraft:air
fill 100 60 -160 135 60 -160 minecraft:air
fill 72 60 -161 73 60 -161 minecraft:air
fill 79 60 -161 87 60 -161 minecraft:air
fill 89 60 -161 93 60 -161 minecraft:air
fill 99 60 -161 135 60 -161 minecraft:air
fill 72 60 -162 74 60 -162 minecraft:air
fill 78 60 -162 83 60 -162 minecraft:air
fill 98 60 -162 135 60 -162 minecraft:air
fill 72 60 -163 75 60 -163 minecraft:air
fill 100 60 -163 135 60 -163 minecraft:air
setblock 72 60 -164 minecraft:air
fill 104 60 -164 135 60 -164 minecraft:air
fill 108 60 -165 135 60 -165 minecraft:air
fill 111 60 -166 135 60 -166 minecraft:air
fill 113 60 -167 135 60 -167 minecraft:air
fill 115 60 -168 135 60 -168 minecraft:air
fill 117 60 -169 135 60 -169 minecraft:air
fill 119 60 -170 135 60 -170 minecraft:air
fill 120 60 -171 135 60 -171 minecraft:air
fill 122 60 -172 135 60 -172 minecraft:air
fill 123 60 -173 135 60 -173 minecraft:air
fill 124 60 -174 135 60 -174 minecraft:air
fill 126 60 -175 135 60 -175 minecraft:air
fill 127 60 -176 135 60 -176 minecraft:air
fill 128 60 -177 135 60 -177 minecraft:air
fill 129 60 -178 135 60 -178 minecraft:air
fill 130 60 -179 135 60 -179 minecraft:air
fill 125 60 -180 135 60 -180 minecraft:air
setblock 119 60 -181 minecraft:air
fill 126 60 -181 135 60 -181 minecraft:air
fill 127 60 -182 135 60 -182 minecraft:air
fill 128 60 -183 135 60 -183 minecraft:air
fill 129 60 -184 135 60 -184 minecraft:air
fill 130 60 -185 135 60 -185 minecraft:air
fill 131 60 -186 135 60 -186 minecraft:air
fill 132 60 -187 135 60 -187 minecraft:air
fill 133 60 -188 135 60 -188 minecraft:air
fill 133 60 -189 135 60 -189 minecraft:air
fill 134 60 -190 135 60 -190 minecraft:air
fill 126 59 -134 135 59 -134 minecraft:air
fill 126 59 -135 135 59 -135 minecraft:air
fill 126 59 -136 135 59 -136 minecraft:air
fill 125 59 -137 135 59 -137 minecraft:air
fill 125 59 -138 135 59 -138 minecraft:air
fill 125 59 -139 127 59 -139 minecraft:air
fill 129 59 -139 134 59 -139 minecraft:air
fill 133 59 -160 135 59 -160 minecraft:air
fill 133 59 -161 135 59 -161 minecraft:air
fill 133 59 -162 135 59 -162 minecraft:air
fill 133 59 -163 135 59 -163 minecraft:air
fill 133 59 -164 135 59 -164 minecraft:air
fill 133 59 -165 135 59 -165 minecraft:air
fill 133 59 -166 135 59 -166 minecraft:air
fill 133 59 -167 135 59 -167 minecraft:air
fill 133 59 -168 135 59 -168 minecraft:air
fill 133 59 -169 135 59 -169 minecraft:air
fill 133 59 -170 135 59 -170 minecraft:air
fill 133 59 -171 135 59 -171 minecraft:air
fill 133 59 -172 135 59 -172 minecraft:air
fill 133 59 -173 135 59 -173 minecraft:air
fill 133 59 -174 135 59 -174 minecraft:air
fill 133 59 -175 135 59 -175 minecraft:air
fill 133 59 -176 135 59 -176 minecraft:air
fill 133 59 -177 135 59 -177 minecraft:air
fill 133 59 -178 135 59 -178 minecraft:air
fill 133 59 -179 135 59 -179 minecraft:air
fill 125 59 -180 135 59 -180 minecraft:air
fill 126 59 -181 135 59 -181 minecraft:air
fill 127 59 -182 135 59 -182 minecraft:air
fill 128 59 -183 135 59 -183 minecraft:air
fill 129 59 -184 135 59 -184 minecraft:air
fill 130 59 -185 135 59 -185 minecraft:air
fill 131 59 -186 135 59 -186 minecraft:air
fill 132 59 -187 135 59 -187 minecraft:air
fill 133 59 -188 135 59 -188 minecraft:air
fill 133 59 -189 135 59 -189 minecraft:air
fill 134 59 -190 135 59 -190 minecraft:air
setblock 126 58 -134 minecraft:air
fill 125 58 -135 127 58 -135 minecraft:air
setblock 129 58 -135 minecraft:air
fill 126 58 -136 127 58 -136 minecraft:air
setblock 125 58 -137 minecraft:air
setblock 128 58 -137 minecraft:air
setblock 130 58 -137 minecraft:air
setblock 126 58 -138 minecraft:air
fill 129 58 -138 134 58 -138 minecraft:air
setblock 125 58 -139 minecraft:air
setblock 127 58 -139 minecraft:air
fill 129 58 -139 133 58 -139 minecraft:air
setblock 114 58 -185 minecraft:air
fill 112 58 -186 114 58 -186 minecraft:air
fill 112 58 -187 114 58 -187 minecraft:air
fill 111 58 -188 114 58 -188 minecraft:air
fill 110 58 -189 114 58 -189 minecraft:air
fill 118 58 -189 121 58 -189 minecraft:air
fill 111 58 -190 113 58 -190 minecraft:air
fill 117 58 -190 121 58 -190 minecraft:air
fill 130 57 -138 134 57 -138 minecraft:air
fill 129 57 -139 133 57 -139 minecraft:air
setblock 113 57 -185 minecraft:air
fill 112 57 -186 114 57 -186 minecraft:air
fill 111 57 -187 114 57 -187 minecraft:air
fill 110 57 -188 114 57 -188 minecraft:air
fill 110 57 -189 113 57 -189 minecraft:air
fill 111 57 -190 112 57 -190 minecraft:air
setblock 113 56 -184 minecraft:air
fill 112 56 -185 113 56 -185 minecraft:air
fill 111 56 -186 113 56 -186 minecraft:air
fill 110 56 -187 113 56 -187 minecraft:air
fill 110 56 -188 114 56 -188 minecraft:air
fill 110 56 -189 112 56 -189 minecraft:air
fill 110 56 -190 111 56 -190 minecraft:air
setblock 113 55 -183 minecraft:air
fill 112 55 -184 113 55 -184 minecraft:air
fill 111 55 -185 113 55 -185 minecraft:air
fill 110 55 -186 113 55 -186 minecraft:air
fill 109 55 -187 113 55 -187 minecraft:air
fill 109 55 -188 112 55 -188 minecraft:air
fill 109 55 -189 111 55 -189 minecraft:air
setblock 110 55 -190 minecraft:air
fill 112 54 -182 113 54 -182 minecraft:air
fill 111 54 -183 113 54 -183 minecraft:air
fill 110 54 -184 113 54 -184 minecraft:air
fill 109 54 -185 113 54 -185 minecraft:air
fill 109 54 -186 113 54 -186 minecraft:air
fill 109 54 -187 112 54 -187 minecraft:air
fill 109 54 -188 111 54 -188 minecraft:air
fill 109 54 -189 110 54 -189 minecraft:air
setblock 105 54 -190 minecraft:air
setblock 109 54 -190 minecraft:air
fill 113 53 -180 114 53 -180 minecraft:air
fill 112 53 -181 113 53 -181 minecraft:air
fill 111 53 -182 113 53 -182 minecraft:air
fill 110 53 -183 113 53 -183 minecraft:air
fill 109 53 -184 112 53 -184 minecraft:air
fill 109 53 -185 112 53 -185 minecraft:air
fill 109 53 -186 112 53 -186 minecraft:air
fill 109 53 -187 111 53 -187 minecraft:air
fill 108 53 -188 109 53 -188 minecraft:air
fill 105 53 -189 106 53 -189 minecraft:air
fill 105 53 -190 106 53 -190 minecraft:air
setblock 74 52 -169 minecraft:air
setblock 73 52 -171 minecraft:air
setblock 73 52 -172 minecraft:air
setblock 72 52 -173 minecraft:air
fill 113 52 -179 114 52 -179 minecraft:air
fill 111 52 -180 114 52 -180 minecraft:air
fill 110 52 -181 113 52 -181 minecraft:air
fill 109 52 -182 113 52 -182 minecraft:air
fill 109 52 -183 113 52 -183 minecraft:air
fill 109 52 -184 112 52 -184 minecraft:air
fill 109 52 -185 111 52 -185 minecraft:air
fill 108 52 -186 110 52 -186 minecraft:air
fill 108 52 -187 109 52 -187 minecraft:air
setblock 108 52 -188 minecraft:air
fill 105 52 -189 106 52 -189 minecraft:air
fill 105 52 -190 106 52 -190 minecraft:air
setblock 73 51 -163 minecraft:air
setblock 73 51 -164 minecraft:air
fill 74 51 -166 75 51 -166 minecraft:air
fill 74 51 -167 75 51 -167 minecraft:air
fill 73 51 -168 75 51 -168 minecraft:air
fill 73 51 -169 75 51 -169 minecraft:air
fill 73 51 -170 74 51 -170 minecraft:air
fill 72 51 -171 74 51 -171 minecraft:air
fill 72 51 -172 74 51 -172 minecraft:air
fill 72 51 -173 73 51 -173 minecraft:air
setblock 72 51 -174 minecraft:air
fill 113 51 -178 114 51 -178 minecraft:air
fill 111 51 -179 114 51 -179 minecraft:air
fill 110 51 -180 114 51 -180 minecraft:air
fill 110 51 -181 113 51 -181 minecraft:air
fill 109 51 -182 113 51 -182 minecraft:air
fill 109 51 -183 112 51 -183 minecraft:air
fill 109 51 -184 111 51 -184 minecraft:air
fill 108 51 -185 110 51 -185 minecraft:air
fill 108 51 -186 109 51 -186 minecraft:air
setblock 72 50 -160 minecraft:air
setblock 72 50 -161 minecraft:air
fill 72 50 -162 73 50 -162 minecraft:air
fill 72 50 -163 73 50 -163 minecraft:air
fill 72 50 -164 74 50 -164 minecraft:air
fill 73 50 -165 74 50 -165 minecraft:air
fill 73 50 -166 75 50 -166 minecraft:air
fill 73 50 -167 75 50 -167 minecraft:air
fill 73 50 -168 75 50 -168 minecraft:air
fill 73 50 -169 75 50 -169 minecraft:air
fill 73 50 -170 74 50 -170 minecraft:air
fill 72 50 -171 74 50 -171 minecraft:air
fill 72 50 -172 74 50 -172 minecraft:air
fill 72 50 -173 73 50 -173 minecraft:air
setblock 72 50 -174 minecraft:air
fill 113 50 -177 115 50 -177 minecraft:air
fill 111 50 -178 114 50 -178 minecraft:air
fill 111 50 -179 114 50 -179 minecraft:air
fill 110 50 -180 114 50 -180 minecraft:air
fill 110 50 -181 113 50 -181 minecraft:air
fill 109 50 -182 112 50 -182 minecraft:air
fill 109 50 -183 111 50 -183 minecraft:air
setblock 109 50 -184 minecraft:air
setblock 108 50 -185 minecraft:air
setblock 72 49 -160 minecraft:air
fill 72 49 -161 73 49 -161 minecraft:air
fill 72 49 -162 73 49 -162 minecraft:air
fill 72 49 -163 74 49 -163 minecraft:air
fill 72 49 -164 74 49 -164 minecraft:air
fill 73 49 -165 74 49 -165 minecraft:air
fill 73 49 -166 75 49 -166 minecraft:air
fill 74 49 -167 75 49 -167 minecraft:air
fill 74 49 -168 75 49 -168 minecraft:air
fill 73 49 -169 75 49 -169 minecraft:air
fill 73 49 -170 74 49 -170 minecraft:air
fill 72 49 -171 74 49 -171 minecraft:air
fill 72 49 -172 73 49 -172 minecraft:air
fill 72 49 -173 73 49 -173 minecraft:air
setblock 72 49 -174 minecraft:air
fill 114 49 -176 115 49 -176 minecraft:air
fill 111 49 -177 115 49 -177 minecraft:air
fill 111 49 -178 114 49 -178 minecraft:air
fill 111 49 -179 114 49 -179 minecraft:air
fill 110 49 -180 113 49 -180 minecraft:air
fill 110 49 -181 112 49 -181 minecraft:air
setblock 72 49 -182 minecraft:air
fill 109 49 -182 110 49 -182 minecraft:air
setblock 72 49 -183 minecraft:air
setblock 109 49 -183 minecraft:air
setblock 134 49 -190 oritech:still_oil_block[level=0]
fill 118 48 -147 119 48 -147 minecraft:air
fill 117 48 -148 119 48 -148 minecraft:air
fill 116 48 -149 119 48 -149 minecraft:air
fill 116 48 -150 118 48 -150 minecraft:air
fill 115 48 -151 118 48 -151 minecraft:air
fill 115 48 -152 117 48 -152 minecraft:air
fill 115 48 -153 117 48 -153 minecraft:air
fill 114 48 -154 117 48 -154 minecraft:air
fill 114 48 -155 116 48 -155 minecraft:air
fill 114 48 -156 116 48 -156 minecraft:air
fill 114 48 -157 115 48 -157 minecraft:air
fill 113 48 -158 115 48 -158 minecraft:air
setblock 72 48 -160 minecraft:air
setblock 72 48 -161 minecraft:air
fill 72 48 -162 73 48 -162 minecraft:air
fill 72 48 -163 73 48 -163 minecraft:air
setblock 73 48 -164 minecraft:air
fill 112 48 -176 115 48 -176 minecraft:air
fill 112 48 -177 115 48 -177 minecraft:air
fill 111 48 -178 114 48 -178 minecraft:air
fill 111 48 -179 114 48 -179 minecraft:air
fill 110 48 -180 112 48 -180 minecraft:air
setblock 74 48 -181 minecraft:air
setblock 110 48 -181 minecraft:air
fill 72 48 -182 73 48 -182 minecraft:air
fill 72 48 -183 73 48 -183 minecraft:air
fill 72 48 -184 73 48 -184 minecraft:air
fill 72 48 -185 73 48 -185 minecraft:air
setblock 134 48 -187 oritech:still_oil_block[level=0]
fill 134 48 -188 135 48 -188 oritech:still_oil_block[level=0]
fill 134 48 -189 135 48 -189 oritech:still_oil_block[level=0]
fill 132 48 -190 135 48 -190 oritech:still_oil_block[level=0]
fill 128 47 -135 135 47 -135 minecraft:air
fill 127 47 -136 135 47 -136 minecraft:air
fill 126 47 -137 135 47 -137 minecraft:air
fill 125 47 -138 132 47 -138 minecraft:air
fill 122 47 -142 123 47 -142 minecraft:air
fill 120 47 -143 123 47 -143 minecraft:air
fill 119 47 -144 122 47 -144 minecraft:air
fill 118 47 -145 122 47 -145 minecraft:air
fill 118 47 -146 121 47 -146 minecraft:air
fill 117 47 -147 120 47 -147 minecraft:air
fill 116 47 -148 120 47 -148 minecraft:air
fill 116 47 -149 119 47 -149 minecraft:air
fill 115 47 -150 119 47 -150 minecraft:air
fill 115 47 -151 118 47 -151 minecraft:air
fill 115 47 -152 118 47 -152 minecraft:air
fill 114 47 -153 117 47 -153 minecraft:air
fill 114 47 -154 117 47 -154 minecraft:air
fill 114 47 -155 117 47 -155 minecraft:air
fill 113 47 -156 116 47 -156 minecraft:air
fill 113 47 -157 116 47 -157 minecraft:air
fill 112 47 -158 115 47 -158 minecraft:air
fill 112 47 -159 115 47 -159 minecraft:air
fill 112 47 -160 114 47 -160 minecraft:air
fill 112 47 -161 113 47 -161 minecraft:air
fill 113 47 -175 116 47 -175 minecraft:air
fill 113 47 -176 116 47 -176 minecraft:air
fill 112 47 -177 115 47 -177 minecraft:air
fill 112 47 -178 115 47 -178 minecraft:air
setblock 111 47 -179 minecraft:air
setblock 76 47 -180 minecraft:air
fill 74 47 -181 75 47 -181 minecraft:air
fill 73 47 -182 75 47 -182 minecraft:air
fill 72 47 -183 75 47 -183 minecraft:air
fill 72 47 -184 75 47 -184 minecraft:air
fill 72 47 -185 73 47 -185 minecraft:air
setblock 72 47 -186 minecraft:air
setblock 135 47 -186 oritech:still_oil_block[level=0]
fill 134 47 -187 135 47 -187 oritech:still_oil_block[level=0]
fill 133 47 -188 135 47 -188 oritech:still_oil_block[level=0]
fill 133 47 -189 135 47 -189 oritech:still_oil_block[level=0]
fill 131 47 -190 135 47 -190 oritech:still_oil_block[level=0]
fill 94 46 -127 96 46 -127 minecraft:air
fill 95 46 -128 96 46 -128 minecraft:air
fill 134 46 -134 135 46 -134 minecraft:air
fill 126 46 -135 135 46 -135 minecraft:air
fill 125 46 -136 135 46 -136 minecraft:air
fill 124 46 -137 135 46 -137 minecraft:air
fill 123 46 -138 135 46 -138 minecraft:air
fill 123 46 -139 127 46 -139 minecraft:air
fill 122 46 -140 126 46 -140 minecraft:air
fill 122 46 -141 124 46 -141 minecraft:air
fill 121 46 -142 124 46 -142 minecraft:air
fill 119 46 -143 124 46 -143 minecraft:air
fill 119 46 -144 123 46 -144 minecraft:air
fill 118 46 -145 122 46 -145 minecraft:air
fill 118 46 -146 122 46 -146 minecraft:air
fill 117 46 -147 121 46 -147 minecraft:air
fill 116 46 -148 120 46 -148 minecraft:air
fill 116 46 -149 119 46 -149 minecraft:air
fill 116 46 -150 119 46 -150 minecraft:air
setblock 117 46 -151 minecraft:air
fill 113 46 -157 115 46 -157 minecraft:air
fill 112 46 -158 115 46 -158 minecraft:air
fill 111 46 -159 115 46 -159 minecraft:air
fill 111 46 -160 114 46 -160 minecraft:air
fill 112 46 -161 113 46 -161 minecraft:air
fill 112 46 -162 113 46 -162 minecraft:air
setblock 112 46 -163 minecraft:air
setblock 112 46 -164 minecraft:air
setblock 112 46 -165 minecraft:air
fill 89 46 -172 91 46 -172 minecraft:air
fill 87 46 -173 90 46 -173 minecraft:air
fill 85 46 -174 90 46 -174 minecraft:air
fill 114 46 -174 117 46 -174 minecraft:air
fill 84 46 -175 89 46 -175 minecraft:air
fill 114 46 -175 117 46 -175 minecraft:air
fill 82 46 -176 88 46 -176 minecraft:air
fill 113 46 -176 116 46 -176 minecraft:air
fill 81 46 -177 87 46 -177 minecraft:air
fill 113 46 -177 116 46 -177 minecraft:air
fill 79 46 -178 86 46 -178 minecraft:air
fill 78 46 -179 84 46 -179 minecraft:air
fill 76 46 -180 82 46 -180 minecraft:air
fill 75 46 -181 81 46 -181 minecraft:air
fill 74 46 -182 79 46 -182 minecraft:air
fill 72 46 -183 77 46 -183 minecraft:air
fill 72 46 -184 75 46 -184 minecraft:air
setblock 104 46 -184 minecraft:air
fill 72 46 -185 74 46 -185 minecraft:air
setblock 102 46 -185 minecraft:air
fill 106 46 -185 107 46 -185 minecraft:air
setblock 135 46 -185 oritech:still_oil_block[level=0]
fill 72 46 -186 73 46 -186 minecraft:air
fill 134 46 -186 135 46 -186 oritech:still_oil_block[level=0]
fill 132 46 -187 135 46 -187 oritech:still_oil_block[level=0]
fill 132 46 -188 135 46 -188 oritech:still_oil_block[level=0]
fill 131 46 -189 135 46 -189 oritech:still_oil_block[level=0]
fill 131 46 -190 135 46 -190 oritech:still_oil_block[level=0]
fill 94 45 -127 97 45 -127 minecraft:air
fill 94 45 -128 97 45 -128 minecraft:air
fill 94 45 -129 97 45 -129 minecraft:air
fill 95 45 -130 97 45 -130 minecraft:air
setblock 96 45 -131 minecraft:air
fill 134 45 -134 135 45 -134 minecraft:air
fill 126 45 -135 135 45 -135 minecraft:air
fill 125 45 -136 135 45 -136 minecraft:air
fill 124 45 -137 135 45 -137 minecraft:air
fill 123 45 -138 135 45 -138 minecraft:air
fill 123 45 -139 127 45 -139 minecraft:air
fill 122 45 -140 126 45 -140 minecraft:air
fill 121 45 -141 125 45 -141 minecraft:air
fill 121 45 -142 125 45 -142 minecraft:air
fill 120 45 -143 124 45 -143 minecraft:air
fill 119 45 -144 123 45 -144 minecraft:air
fill 119 45 -145 122 45 -145 minecraft:air
fill 120 45 -146 121 45 -146 minecraft:air
fill 111 45 -160 113 45 -160 minecraft:air
fill 112 45 -161 113 45 -161 minecraft:air
fill 112 45 -162 113 45 -162 minecraft:air
setblock 112 45 -163 minecraft:air
setblock 112 45 -164 minecraft:air
setblock 112 45 -165 minecraft:air
fill 90 45 -169 92 45 -169 minecraft:air
fill 88 45 -170 92 45 -170 minecraft:air
fill 87 45 -171 91 45 -171 minecraft:air
fill 87 45 -172 91 45 -172 minecraft:air
fill 86 45 -173 90 45 -173 minecraft:air
fill 115 45 -173 118 45 -173 minecraft:air
fill 85 45 -174 90 45 -174 minecraft:air
fill 114 45 -174 117 45 -174 minecraft:air
fill 84 45 -175 89 45 -175 minecraft:air
fill 114 45 -175 117 45 -175 minecraft:air
fill 83 45 -176 88 45 -176 minecraft:air
fill 114 45 -176 117 45 -176 minecraft:air
fill 81 45 -177 87 45 -177 minecraft:air
fill 80 45 -178 86 45 -178 minecraft:air
fill 78 45 -179 85 45 -179 minecraft:air
fill 77 45 -180 83 45 -180 minecraft:air
fill 76 45 -181 81 45 -181 minecraft:air
fill 74 45 -182 79 45 -182 minecraft:air
fill 73 45 -183 78 45 -183 minecraft:air
fill 72 45 -184 76 45 -184 minecraft:air
fill 101 45 -184 106 45 -184 minecraft:air
fill 72 45 -185 75 45 -185 minecraft:air
fill 101 45 -185 107 45 -185 minecraft:air
setblock 135 45 -185 oritech:still_oil_block[level=0]
fill 72 45 -186 73 45 -186 minecraft:air
fill 100 45 -186 102 45 -186 minecraft:air
fill 106 45 -186 107 45 -186 minecraft:air
fill 133 45 -186 135 45 -186 oritech:still_oil_block[level=0]
setblock 72 45 -187 minecraft:air
fill 100 45 -187 101 45 -187 minecraft:air
fill 131 45 -187 135 45 -187 oritech:still_oil_block[level=0]
setblock 100 45 -188 minecraft:air
fill 131 45 -188 135 45 -188 oritech:still_oil_block[level=0]
fill 130 45 -189 135 45 -189 oritech:still_oil_block[level=0]
fill 130 45 -190 135 45 -190 oritech:still_oil_block[level=0]
forceload remove 72 -190 135 -127
tellraw @a {"text":"Campus zurueck a30 fertig.","color":"green"}
