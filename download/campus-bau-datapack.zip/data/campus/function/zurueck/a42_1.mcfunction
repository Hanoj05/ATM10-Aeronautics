setblock 392 66 -126 minecraft:air
setblock 394 66 -126 minecraft:air
setblock 396 66 -126 minecraft:air
fill 392 65 -117 394 65 -117 minecraft:air
fill 392 65 -118 397 65 -118 minecraft:air
fill 392 65 -119 400 65 -119 minecraft:air
fill 392 65 -120 402 65 -120 minecraft:air
fill 392 65 -121 404 65 -121 minecraft:air
fill 392 65 -122 405 65 -122 minecraft:air
fill 392 65 -123 407 65 -123 minecraft:air
fill 392 65 -124 408 65 -124 minecraft:air
fill 392 65 -125 409 65 -125 minecraft:air
fill 392 65 -126 410 65 -126 minecraft:air
fill 392 64 -117 394 64 -117 minecraft:air
fill 392 64 -118 397 64 -118 minecraft:air
fill 392 64 -119 400 64 -119 minecraft:air
fill 392 64 -120 402 64 -120 minecraft:air
fill 392 64 -121 404 64 -121 minecraft:air
fill 392 64 -122 405 64 -122 minecraft:air
fill 392 64 -123 407 64 -123 minecraft:air
fill 392 64 -124 408 64 -124 minecraft:air
fill 392 64 -125 409 64 -125 minecraft:air
fill 392 64 -126 410 64 -126 minecraft:air
fill 392 63 -117 394 63 -117 minecraft:air
fill 392 63 -118 397 63 -118 minecraft:air
fill 392 63 -119 400 63 -119 minecraft:air
fill 392 63 -120 402 63 -120 minecraft:air
fill 392 63 -121 404 63 -121 minecraft:air
fill 392 63 -122 405 63 -122 minecraft:air
fill 392 63 -123 407 63 -123 minecraft:air
fill 392 63 -124 408 63 -124 minecraft:air
fill 392 63 -125 409 63 -125 minecraft:air
fill 392 63 -126 410 63 -126 minecraft:air
fill 392 62 -117 394 62 -117 minecraft:water[level=0]
fill 392 62 -118 397 62 -118 minecraft:water[level=0]
fill 392 62 -119 400 62 -119 minecraft:water[level=0]
fill 392 62 -120 402 62 -120 minecraft:water[level=0]
fill 392 62 -121 404 62 -121 minecraft:water[level=0]
fill 392 62 -122 405 62 -122 minecraft:water[level=0]
fill 392 62 -123 407 62 -123 minecraft:water[level=0]
fill 392 62 -124 408 62 -124 minecraft:water[level=0]
fill 392 62 -125 409 62 -125 minecraft:water[level=0]
fill 392 62 -126 410 62 -126 minecraft:water[level=0]
fill 392 61 -117 394 61 -117 minecraft:water[level=0]
fill 392 61 -118 397 61 -118 minecraft:water[level=0]
fill 392 61 -119 400 61 -119 minecraft:water[level=0]
fill 392 61 -120 398 61 -120 minecraft:water[level=0]
setblock 399 61 -120 minecraft:kelp[age=25]
fill 400 61 -120 402 61 -120 minecraft:water[level=0]
fill 392 61 -121 404 61 -121 minecraft:water[level=0]
fill 392 61 -122 405 61 -122 minecraft:water[level=0]
fill 392 61 -123 407 61 -123 minecraft:water[level=0]
fill 392 61 -124 408 61 -124 minecraft:water[level=0]
fill 392 61 -125 409 61 -125 minecraft:water[level=0]
fill 392 61 -126 410 61 -126 minecraft:water[level=0]
fill 392 60 -117 394 60 -117 minecraft:water[level=0]
fill 392 60 -118 397 60 -118 minecraft:water[level=0]
fill 392 60 -119 400 60 -119 minecraft:water[level=0]
fill 392 60 -120 398 60 -120 minecraft:water[level=0]
setblock 399 60 -120 minecraft:kelp_plant
fill 400 60 -120 402 60 -120 minecraft:water[level=0]
fill 392 60 -121 404 60 -121 minecraft:water[level=0]
fill 392 60 -122 405 60 -122 minecraft:water[level=0]
fill 392 60 -123 407 60 -123 minecraft:water[level=0]
fill 392 60 -124 405 60 -124 minecraft:water[level=0]
setblock 406 60 -124 minecraft:kelp[age=25]
fill 407 60 -124 408 60 -124 minecraft:water[level=0]
fill 392 60 -125 409 60 -125 minecraft:water[level=0]
fill 392 60 -126 410 60 -126 minecraft:water[level=0]
fill 392 59 -117 394 59 -117 minecraft:water[level=0]
fill 392 59 -118 397 59 -118 minecraft:water[level=0]
fill 392 59 -119 400 59 -119 minecraft:water[level=0]
fill 392 59 -120 398 59 -120 minecraft:water[level=0]
setblock 399 59 -120 minecraft:kelp_plant
fill 400 59 -120 402 59 -120 minecraft:water[level=0]
fill 392 59 -121 404 59 -121 minecraft:water[level=0]
fill 392 59 -122 405 59 -122 minecraft:water[level=0]
fill 392 59 -123 407 59 -123 minecraft:water[level=0]
fill 392 59 -124 405 59 -124 minecraft:water[level=0]
setblock 406 59 -124 minecraft:kelp_plant
fill 407 59 -124 408 59 -124 minecraft:water[level=0]
fill 392 59 -125 409 59 -125 minecraft:water[level=0]
fill 392 59 -126 410 59 -126 minecraft:water[level=0]
fill 392 58 -117 393 58 -117 minecraft:water[level=0]
setblock 394 58 -117 minecraft:kelp[age=25]
fill 392 58 -118 397 58 -118 minecraft:water[level=0]
fill 392 58 -119 400 58 -119 minecraft:water[level=0]
fill 392 58 -120 398 58 -120 minecraft:water[level=0]
setblock 399 58 -120 minecraft:kelp_plant
fill 400 58 -120 402 58 -120 minecraft:water[level=0]
fill 392 58 -121 404 58 -121 minecraft:water[level=0]
fill 392 58 -122 405 58 -122 minecraft:water[level=0]
fill 392 58 -123 407 58 -123 minecraft:water[level=0]
fill 392 58 -124 405 58 -124 minecraft:water[level=0]
setblock 406 58 -124 minecraft:kelp_plant
fill 407 58 -124 408 58 -124 minecraft:water[level=0]
fill 392 58 -125 409 58 -125 minecraft:water[level=0]
fill 392 58 -126 410 58 -126 minecraft:water[level=0]
fill 392 57 -117 393 57 -117 minecraft:water[level=0]
setblock 394 57 -117 minecraft:kelp_plant
fill 392 57 -118 397 57 -118 minecraft:water[level=0]
fill 392 57 -119 400 57 -119 minecraft:water[level=0]
fill 392 57 -120 398 57 -120 minecraft:water[level=0]
setblock 399 57 -120 minecraft:kelp_plant
fill 400 57 -120 402 57 -120 minecraft:water[level=0]
fill 392 57 -121 396 57 -121 minecraft:water[level=0]
setblock 397 57 -121 minecraft:kelp[age=25]
fill 398 57 -121 404 57 -121 minecraft:water[level=0]
fill 392 57 -122 405 57 -122 minecraft:water[level=0]
fill 392 57 -123 405 57 -123 minecraft:water[level=0]
setblock 406 57 -123 minecraft:kelp[age=25]
setblock 407 57 -123 minecraft:water[level=0]
fill 392 57 -124 405 57 -124 minecraft:water[level=0]
setblock 406 57 -124 minecraft:kelp_plant
fill 407 57 -124 408 57 -124 minecraft:water[level=0]
fill 392 57 -125 409 57 -125 minecraft:water[level=0]
fill 392 57 -126 410 57 -126 minecraft:water[level=0]
fill 392 56 -117 393 56 -117 minecraft:water[level=0]
setblock 394 56 -117 minecraft:kelp_plant
fill 392 56 -118 397 56 -118 minecraft:water[level=0]
fill 392 56 -119 400 56 -119 minecraft:water[level=0]
fill 392 56 -120 398 56 -120 minecraft:water[level=0]
setblock 399 56 -120 minecraft:kelp_plant
fill 400 56 -120 402 56 -120 minecraft:water[level=0]
fill 392 56 -121 393 56 -121 minecraft:water[level=0]
setblock 394 56 -121 minecraft:kelp[age=25]
fill 395 56 -121 396 56 -121 minecraft:water[level=0]
setblock 397 56 -121 minecraft:kelp_plant
setblock 398 56 -121 minecraft:water[level=0]
setblock 399 56 -121 minecraft:kelp[age=25]
fill 400 56 -121 404 56 -121 minecraft:water[level=0]
fill 392 56 -122 405 56 -122 minecraft:water[level=0]
fill 392 56 -123 405 56 -123 minecraft:water[level=0]
setblock 406 56 -123 minecraft:kelp_plant
setblock 407 56 -123 minecraft:water[level=0]
fill 392 56 -124 405 56 -124 minecraft:water[level=0]
setblock 406 56 -124 minecraft:kelp_plant
fill 407 56 -124 408 56 -124 minecraft:water[level=0]
fill 392 56 -125 409 56 -125 minecraft:water[level=0]
fill 392 56 -126 410 56 -126 minecraft:water[level=0]
fill 392 55 -117 393 55 -117 minecraft:water[level=0]
setblock 394 55 -117 minecraft:kelp_plant
fill 392 55 -118 397 55 -118 minecraft:water[level=0]
fill 392 55 -119 398 55 -119 minecraft:water[level=0]
setblock 399 55 -119 minecraft:kelp[age=25]
setblock 400 55 -119 minecraft:water[level=0]
fill 392 55 -120 398 55 -120 minecraft:water[level=0]
setblock 399 55 -120 minecraft:kelp_plant
fill 400 55 -120 402 55 -120 minecraft:water[level=0]
fill 392 55 -121 393 55 -121 minecraft:water[level=0]
setblock 394 55 -121 minecraft:kelp_plant
fill 395 55 -121 396 55 -121 minecraft:water[level=0]
setblock 397 55 -121 minecraft:kelp_plant
setblock 398 55 -121 minecraft:water[level=0]
setblock 399 55 -121 minecraft:kelp_plant
fill 400 55 -121 404 55 -121 minecraft:water[level=0]
fill 392 55 -122 405 55 -122 minecraft:water[level=0]
fill 392 55 -123 405 55 -123 minecraft:water[level=0]
setblock 406 55 -123 minecraft:kelp_plant
setblock 407 55 -123 minecraft:water[level=0]
setblock 392 55 -124 minecraft:kelp[age=25]
fill 393 55 -124 405 55 -124 minecraft:water[level=0]
setblock 406 55 -124 minecraft:kelp_plant
fill 407 55 -124 408 55 -124 minecraft:water[level=0]
fill 392 55 -125 393 55 -125 minecraft:water[level=0]
setblock 394 55 -125 minecraft:kelp[age=24]
fill 395 55 -125 409 55 -125 minecraft:water[level=0]
fill 392 55 -126 410 55 -126 minecraft:water[level=0]
fill 392 54 -117 393 54 -117 minecraft:water[level=0]
setblock 394 54 -117 minecraft:kelp_plant
fill 392 54 -118 397 54 -118 minecraft:water[level=0]
fill 392 54 -119 393 54 -119 minecraft:water[level=0]
setblock 394 54 -119 minecraft:kelp[age=25]
fill 395 54 -119 398 54 -119 minecraft:water[level=0]
setblock 399 54 -119 minecraft:kelp_plant
setblock 400 54 -119 minecraft:water[level=0]
fill 392 54 -120 398 54 -120 minecraft:water[level=0]
setblock 399 54 -120 minecraft:kelp_plant
fill 400 54 -120 402 54 -120 minecraft:water[level=0]
fill 392 54 -121 393 54 -121 minecraft:water[level=0]
setblock 394 54 -121 minecraft:kelp_plant
fill 395 54 -121 396 54 -121 minecraft:water[level=0]
setblock 397 54 -121 minecraft:kelp_plant
setblock 398 54 -121 minecraft:water[level=0]
setblock 399 54 -121 minecraft:kelp_plant
fill 400 54 -121 404 54 -121 minecraft:water[level=0]
fill 392 54 -122 405 54 -122 minecraft:water[level=0]
fill 392 54 -123 405 54 -123 minecraft:water[level=0]
setblock 406 54 -123 minecraft:kelp_plant
setblock 407 54 -123 minecraft:water[level=0]
setblock 392 54 -124 minecraft:kelp_plant
fill 393 54 -124 405 54 -124 minecraft:water[level=0]
setblock 406 54 -124 minecraft:kelp_plant
fill 407 54 -124 408 54 -124 minecraft:water[level=0]
fill 392 54 -125 393 54 -125 minecraft:water[level=0]
setblock 394 54 -125 minecraft:kelp_plant
fill 395 54 -125 409 54 -125 minecraft:water[level=0]
fill 392 54 -126 410 54 -126 minecraft:water[level=0]
fill 392 53 -117 393 53 -117 minecraft:water[level=0]
setblock 394 53 -117 minecraft:kelp_plant
setblock 392 53 -118 minecraft:kelp[age=25]
fill 393 53 -118 397 53 -118 minecraft:water[level=0]
fill 392 53 -119 393 53 -119 minecraft:water[level=0]
setblock 394 53 -119 minecraft:kelp_plant
fill 395 53 -119 398 53 -119 minecraft:water[level=0]
setblock 399 53 -119 minecraft:kelp_plant
setblock 400 53 -119 minecraft:water[level=0]
fill 392 53 -120 398 53 -120 minecraft:water[level=0]
setblock 399 53 -120 minecraft:kelp_plant
fill 400 53 -120 402 53 -120 minecraft:water[level=0]
fill 392 53 -121 393 53 -121 minecraft:water[level=0]
setblock 394 53 -121 minecraft:kelp_plant
fill 395 53 -121 396 53 -121 minecraft:water[level=0]
setblock 397 53 -121 minecraft:kelp_plant
setblock 398 53 -121 minecraft:water[level=0]
setblock 399 53 -121 minecraft:kelp_plant
fill 400 53 -121 404 53 -121 minecraft:water[level=0]
fill 392 53 -122 405 53 -122 minecraft:water[level=0]
fill 392 53 -123 405 53 -123 minecraft:water[level=0]
setblock 406 53 -123 minecraft:kelp_plant
setblock 407 53 -123 minecraft:water[level=0]
setblock 392 53 -124 minecraft:kelp_plant
setblock 393 53 -124 minecraft:water[level=0]
setblock 394 53 -124 minecraft:kelp[age=25]
fill 395 53 -124 405 53 -124 minecraft:water[level=0]
setblock 406 53 -124 minecraft:kelp_plant
fill 407 53 -124 408 53 -124 minecraft:water[level=0]
fill 392 53 -125 393 53 -125 minecraft:water[level=0]
setblock 394 53 -125 minecraft:kelp_plant
fill 395 53 -125 409 53 -125 minecraft:water[level=0]
fill 392 53 -126 410 53 -126 minecraft:water[level=0]
fill 392 52 -117 393 52 -117 minecraft:water[level=0]
setblock 394 52 -117 minecraft:kelp_plant
setblock 392 52 -118 minecraft:kelp_plant
fill 393 52 -118 397 52 -118 minecraft:water[level=0]
fill 392 52 -119 393 52 -119 minecraft:water[level=0]
setblock 394 52 -119 minecraft:kelp_plant
fill 395 52 -119 398 52 -119 minecraft:water[level=0]
setblock 399 52 -119 minecraft:kelp_plant
setblock 400 52 -119 minecraft:water[level=0]
fill 392 52 -120 398 52 -120 minecraft:water[level=0]
setblock 399 52 -120 minecraft:kelp_plant
fill 400 52 -120 402 52 -120 minecraft:water[level=0]
fill 392 52 -121 393 52 -121 minecraft:water[level=0]
setblock 394 52 -121 minecraft:kelp_plant
fill 395 52 -121 396 52 -121 minecraft:water[level=0]
setblock 397 52 -121 minecraft:kelp_plant
setblock 398 52 -121 minecraft:water[level=0]
setblock 399 52 -121 minecraft:kelp_plant
fill 400 52 -121 404 52 -121 minecraft:water[level=0]
fill 392 52 -122 405 52 -122 minecraft:water[level=0]
fill 392 52 -123 405 52 -123 minecraft:water[level=0]
setblock 406 52 -123 minecraft:kelp_plant
setblock 407 52 -123 minecraft:water[level=0]
setblock 392 52 -124 minecraft:kelp_plant
setblock 393 52 -124 minecraft:water[level=0]
setblock 394 52 -124 minecraft:kelp_plant
fill 395 52 -124 405 52 -124 minecraft:water[level=0]
setblock 406 52 -124 minecraft:kelp_plant
fill 407 52 -124 408 52 -124 minecraft:water[level=0]
fill 392 52 -125 393 52 -125 minecraft:water[level=0]
setblock 394 52 -125 minecraft:kelp_plant
fill 395 52 -125 409 52 -125 minecraft:water[level=0]
fill 392 52 -126 410 52 -126 minecraft:water[level=0]
fill 392 51 -117 393 51 -117 minecraft:water[level=0]
setblock 394 51 -117 minecraft:kelp_plant
setblock 392 51 -118 minecraft:kelp_plant
fill 393 51 -118 397 51 -118 minecraft:water[level=0]
fill 392 51 -119 393 51 -119 minecraft:water[level=0]
setblock 394 51 -119 minecraft:kelp_plant
fill 395 51 -119 398 51 -119 minecraft:water[level=0]
setblock 399 51 -119 minecraft:kelp_plant
setblock 400 51 -119 minecraft:water[level=0]
fill 392 51 -120 398 51 -120 minecraft:water[level=0]
setblock 399 51 -120 minecraft:kelp_plant
fill 400 51 -120 402 51 -120 minecraft:water[level=0]
fill 392 51 -121 393 51 -121 minecraft:water[level=0]
setblock 394 51 -121 minecraft:kelp_plant
fill 395 51 -121 396 51 -121 minecraft:water[level=0]
setblock 397 51 -121 minecraft:kelp_plant
setblock 398 51 -121 minecraft:water[level=0]
setblock 399 51 -121 minecraft:kelp_plant
fill 400 51 -121 404 51 -121 minecraft:water[level=0]
fill 392 51 -122 405 51 -122 minecraft:water[level=0]
fill 392 51 -123 405 51 -123 minecraft:water[level=0]
setblock 406 51 -123 minecraft:kelp_plant
setblock 407 51 -123 minecraft:water[level=0]
setblock 392 51 -124 minecraft:kelp_plant
setblock 393 51 -124 minecraft:water[level=0]
setblock 394 51 -124 minecraft:kelp_plant
fill 395 51 -124 405 51 -124 minecraft:water[level=0]
setblock 406 51 -124 minecraft:kelp_plant
fill 407 51 -124 408 51 -124 minecraft:water[level=0]
fill 392 51 -125 393 51 -125 minecraft:water[level=0]
setblock 394 51 -125 minecraft:kelp_plant
fill 395 51 -125 407 51 -125 minecraft:water[level=0]
setblock 408 51 -125 minecraft:tall_seagrass[half=upper]
setblock 409 51 -125 minecraft:water[level=0]
fill 392 51 -126 410 51 -126 minecraft:water[level=0]
fill 392 50 -117 393 50 -117 minecraft:water[level=0]
setblock 394 50 -117 minecraft:kelp_plant
setblock 392 50 -118 minecraft:kelp_plant
fill 393 50 -118 397 50 -118 minecraft:water[level=0]
fill 392 50 -119 393 50 -119 minecraft:water[level=0]
setblock 394 50 -119 minecraft:kelp_plant
fill 395 50 -119 398 50 -119 minecraft:water[level=0]
setblock 399 50 -119 minecraft:kelp_plant
setblock 400 50 -119 minecraft:water[level=0]
fill 392 50 -120 398 50 -120 minecraft:water[level=0]
setblock 399 50 -120 minecraft:kelp_plant
fill 400 50 -120 402 50 -120 minecraft:water[level=0]
fill 392 50 -121 393 50 -121 minecraft:water[level=0]
setblock 394 50 -121 minecraft:kelp_plant
fill 395 50 -121 396 50 -121 minecraft:water[level=0]
setblock 397 50 -121 minecraft:kelp_plant
setblock 398 50 -121 minecraft:water[level=0]
setblock 399 50 -121 minecraft:kelp_plant
fill 400 50 -121 404 50 -121 minecraft:water[level=0]
fill 392 50 -122 405 50 -122 minecraft:water[level=0]
fill 392 50 -123 405 50 -123 minecraft:water[level=0]
setblock 406 50 -123 minecraft:kelp_plant
setblock 407 50 -123 minecraft:tall_seagrass[half=upper]
setblock 392 50 -124 minecraft:kelp_plant
setblock 393 50 -124 minecraft:water[level=0]
setblock 394 50 -124 minecraft:kelp_plant
fill 395 50 -124 405 50 -124 minecraft:water[level=0]
setblock 406 50 -124 minecraft:kelp_plant
fill 407 50 -124 408 50 -124 minecraft:water[level=0]
fill 392 50 -125 393 50 -125 minecraft:water[level=0]
setblock 394 50 -125 minecraft:kelp_plant
fill 395 50 -125 407 50 -125 minecraft:water[level=0]
setblock 408 50 -125 minecraft:tall_seagrass[half=lower]
setblock 409 50 -125 minecraft:water[level=0]
fill 392 50 -126 407 50 -126 minecraft:water[level=0]
setblock 408 50 -126 minecraft:seagrass
fill 409 50 -126 410 50 -126 minecraft:water[level=0]
setblock 392 49 -117 minecraft:water[level=0]
setblock 393 49 -117 minecraft:tall_seagrass[half=upper]
setblock 394 49 -117 minecraft:kelp_plant
setblock 392 49 -118 minecraft:kelp_plant
setblock 393 49 -118 minecraft:water[level=0]
setblock 394 49 -118 minecraft:tall_seagrass[half=upper]
fill 395 49 -118 397 49 -118 minecraft:water[level=0]
fill 392 49 -119 393 49 -119 minecraft:water[level=0]
setblock 394 49 -119 minecraft:kelp_plant
fill 395 49 -119 398 49 -119 minecraft:water[level=0]
setblock 399 49 -119 minecraft:kelp_plant
setblock 400 49 -119 minecraft:water[level=0]
fill 392 49 -120 398 49 -120 minecraft:water[level=0]
setblock 399 49 -120 minecraft:kelp_plant
fill 400 49 -120 402 49 -120 minecraft:water[level=0]
setblock 392 49 -121 minecraft:water[level=0]
setblock 393 49 -121 minecraft:tall_seagrass[half=upper]
setblock 394 49 -121 minecraft:kelp_plant
fill 395 49 -121 396 49 -121 minecraft:water[level=0]
setblock 397 49 -121 minecraft:kelp_plant
setblock 398 49 -121 minecraft:water[level=0]
setblock 399 49 -121 minecraft:kelp_plant
fill 400 49 -121 404 49 -121 minecraft:water[level=0]
fill 392 49 -122 395 49 -122 minecraft:water[level=0]
setblock 396 49 -122 minecraft:tall_seagrass[half=upper]
fill 397 49 -122 404 49 -122 minecraft:water[level=0]
setblock 405 49 -122 minecraft:tall_seagrass[half=upper]
setblock 392 49 -123 minecraft:water[level=0]
setblock 393 49 -123 minecraft:tall_seagrass[half=upper]
setblock 394 49 -123 minecraft:water[level=0]
setblock 395 49 -123 minecraft:tall_seagrass[half=upper]
fill 396 49 -123 405 49 -123 minecraft:water[level=0]
setblock 406 49 -123 minecraft:kelp_plant
setblock 407 49 -123 minecraft:tall_seagrass[half=lower]
setblock 392 49 -124 minecraft:kelp_plant
setblock 393 49 -124 minecraft:water[level=0]
setblock 394 49 -124 minecraft:kelp_plant
fill 395 49 -124 405 49 -124 minecraft:water[level=0]
setblock 406 49 -124 minecraft:kelp_plant
setblock 407 49 -124 minecraft:water[level=0]
fill 392 49 -125 393 49 -125 minecraft:water[level=0]
setblock 394 49 -125 minecraft:kelp_plant
setblock 395 49 -125 minecraft:water[level=0]
setblock 396 49 -125 minecraft:tall_seagrass[half=upper]
fill 397 49 -125 407 49 -125 minecraft:water[level=0]
fill 392 49 -126 407 49 -126 minecraft:water[level=0]
setblock 392 48 -117 minecraft:water[level=0]
setblock 393 48 -117 minecraft:tall_seagrass[half=lower]
setblock 394 48 -117 minecraft:kelp_plant
setblock 392 48 -118 minecraft:kelp_plant
setblock 393 48 -118 minecraft:water[level=0]
setblock 394 48 -118 minecraft:tall_seagrass[half=lower]
fill 395 48 -118 397 48 -118 minecraft:water[level=0]
fill 392 48 -119 393 48 -119 minecraft:water[level=0]
setblock 394 48 -119 minecraft:kelp_plant
setblock 395 48 -119 minecraft:water[level=0]
setblock 396 48 -119 minecraft:seagrass
setblock 397 48 -119 minecraft:tall_seagrass[half=upper]
setblock 398 48 -119 minecraft:water[level=0]
setblock 399 48 -119 minecraft:kelp_plant
setblock 400 48 -119 minecraft:water[level=0]
setblock 392 48 -120 minecraft:seagrass
fill 393 48 -120 398 48 -120 minecraft:water[level=0]
setblock 399 48 -120 minecraft:kelp_plant
fill 400 48 -120 402 48 -120 minecraft:water[level=0]
setblock 392 48 -121 minecraft:water[level=0]
setblock 393 48 -121 minecraft:tall_seagrass[half=lower]
setblock 394 48 -121 minecraft:kelp_plant
fill 395 48 -121 396 48 -121 minecraft:water[level=0]
setblock 397 48 -121 minecraft:kelp_plant
setblock 398 48 -121 minecraft:water[level=0]
setblock 399 48 -121 minecraft:kelp_plant
setblock 400 48 -121 minecraft:water[level=0]
setblock 401 48 -121 minecraft:tall_seagrass[half=upper]
fill 402 48 -121 404 48 -121 minecraft:water[level=0]
setblock 392 48 -122 minecraft:seagrass
fill 393 48 -122 394 48 -122 minecraft:water[level=0]
setblock 395 48 -122 minecraft:seagrass
setblock 396 48 -122 minecraft:tall_seagrass[half=lower]
fill 397 48 -122 400 48 -122 minecraft:water[level=0]
setblock 401 48 -122 minecraft:tall_seagrass[half=upper]
fill 402 48 -122 403 48 -122 minecraft:water[level=0]
setblock 404 48 -122 minecraft:tall_seagrass[half=upper]
setblock 405 48 -122 minecraft:tall_seagrass[half=lower]
setblock 392 48 -123 minecraft:seagrass
setblock 393 48 -123 minecraft:tall_seagrass[half=lower]
setblock 394 48 -123 minecraft:water[level=0]
setblock 395 48 -123 minecraft:tall_seagrass[half=lower]
setblock 396 48 -123 minecraft:seagrass
fill 397 48 -123 405 48 -123 minecraft:water[level=0]
setblock 406 48 -123 minecraft:kelp_plant
setblock 392 48 -124 minecraft:kelp_plant
setblock 393 48 -124 minecraft:water[level=0]
setblock 394 48 -124 minecraft:kelp_plant
fill 395 48 -124 396 48 -124 minecraft:seagrass
fill 397 48 -124 405 48 -124 minecraft:water[level=0]
setblock 406 48 -124 minecraft:kelp_plant
fill 392 48 -125 393 48 -125 minecraft:water[level=0]
setblock 394 48 -125 minecraft:kelp_plant
setblock 395 48 -125 minecraft:water[level=0]
setblock 396 48 -125 minecraft:tall_seagrass[half=lower]
fill 397 48 -125 406 48 -125 minecraft:water[level=0]
setblock 392 48 -126 minecraft:water[level=0]
setblock 393 48 -126 minecraft:seagrass
fill 394 48 -126 406 48 -126 minecraft:water[level=0]
setblock 397 47 -118 minecraft:water[level=0]
setblock 397 47 -119 minecraft:tall_seagrass[half=lower]
setblock 398 47 -119 minecraft:water[level=0]
setblock 399 47 -119 minecraft:kelp_plant
setblock 400 47 -119 minecraft:seagrass
fill 397 47 -120 398 47 -120 minecraft:water[level=0]
setblock 399 47 -120 minecraft:kelp_plant
fill 400 47 -120 401 47 -120 minecraft:seagrass
setblock 402 47 -120 minecraft:water[level=0]
setblock 397 47 -121 minecraft:kelp_plant
setblock 398 47 -121 minecraft:water[level=0]
setblock 399 47 -121 minecraft:kelp_plant
setblock 400 47 -121 minecraft:seagrass
setblock 401 47 -121 minecraft:tall_seagrass[half=lower]
fill 402 47 -121 403 47 -121 minecraft:seagrass
setblock 397 47 -122 minecraft:seagrass
fill 398 47 -122 399 47 -122 minecraft:water[level=0]
setblock 400 47 -122 minecraft:seagrass
setblock 401 47 -122 minecraft:tall_seagrass[half=lower]
fill 402 47 -122 403 47 -122 minecraft:water[level=0]
setblock 404 47 -122 minecraft:tall_seagrass[half=lower]
fill 398 47 -123 399 47 -123 minecraft:water[level=0]
setblock 400 47 -123 minecraft:seagrass
setblock 401 47 -123 minecraft:water[level=0]
fill 402 47 -123 404 47 -123 minecraft:seagrass
setblock 405 47 -123 minecraft:water[level=0]
fill 398 47 -124 405 47 -124 minecraft:water[level=0]
fill 398 47 -125 399 47 -125 minecraft:water[level=0]
setblock 400 47 -125 minecraft:seagrass
fill 401 47 -125 405 47 -125 minecraft:water[level=0]
fill 398 47 -126 404 47 -126 minecraft:water[level=0]
setblock 405 47 -126 minecraft:seagrass
fill 403 46 -124 404 46 -124 minecraft:water[level=0]
setblock 402 46 -125 minecraft:water[level=0]
setblock 403 46 -125 minecraft:seagrass
setblock 404 46 -125 minecraft:water[level=0]
fill 402 46 -126 404 46 -126 minecraft:water[level=0]
forceload remove 392 -126 455 -63
tellraw @a {"text":"Campus zurueck a42 fertig.","color":"green"}
