setblock 209 86 -196 minecraft:white_concrete
setblock 209 86 -197 minecraft:white_concrete
fill 206 86 -204 207 86 -204 minecraft:white_concrete
fill 204 86 -211 205 86 -211 minecraft:white_concrete
setblock 204 86 -219 minecraft:white_concrete
setblock 204 86 -227 minecraft:white_concrete
setblock 205 86 -234 minecraft:white_concrete
fill 207 86 -242 208 86 -242 minecraft:white_concrete
fill 210 86 -249 211 86 -249 minecraft:white_concrete
fill 215 85 -192 216 85 -192 minecraft:white_concrete
setblock 215 85 -193 minecraft:white_concrete
setblock 212 85 -198 minecraft:white_concrete
setblock 212 85 -199 minecraft:white_concrete
setblock 211 85 -200 minecraft:white_concrete
setblock 211 85 -201 minecraft:white_concrete
setblock 211 85 -202 minecraft:white_concrete
setblock 210 85 -203 minecraft:white_concrete
setblock 210 85 -204 minecraft:white_concrete
fill 209 85 -205 210 85 -205 minecraft:white_concrete
setblock 209 85 -206 minecraft:white_concrete
setblock 209 85 -207 minecraft:white_concrete
setblock 209 85 -208 minecraft:white_concrete
setblock 208 85 -214 minecraft:white_concrete
setblock 207 85 -218 minecraft:white_concrete
setblock 207 85 -222 minecraft:white_concrete
setblock 207 85 -224 minecraft:white_concrete
setblock 207 85 -227 minecraft:white_concrete
setblock 208 85 -229 minecraft:white_concrete
setblock 208 85 -231 minecraft:white_concrete
setblock 208 85 -233 minecraft:white_concrete
setblock 209 85 -235 minecraft:white_concrete
fill 209 85 -238 210 85 -238 minecraft:white_concrete
setblock 211 85 -241 minecraft:white_concrete
setblock 211 85 -242 minecraft:white_concrete
setblock 213 85 -246 minecraft:white_concrete
setblock 213 85 -247 minecraft:white_concrete
setblock 214 85 -248 minecraft:white_concrete
setblock 216 85 -251 minecraft:white_concrete
setblock 217 85 -253 minecraft:white_concrete
fill 217 85 -254 218 85 -254 minecraft:white_concrete
setblock 237 68 -200 minecraft:air
setblock 243 68 -205 minecraft:air
setblock 243 68 -251 minecraft:air
setblock 229 67 -201 minecraft:air
setblock 247 67 -239 minecraft:air
setblock 246 67 -242 minecraft:air
setblock 222 66 -199 minecraft:air
setblock 249 66 -210 minecraft:air
setblock 245 66 -222 minecraft:air
setblock 213 66 -226 minecraft:air
setblock 256 66 -235 minecraft:air
setblock 217 66 -237 minecraft:air
setblock 221 66 -248 minecraft:air
fill 259 65 -209 263 65 -209 minecraft:air
fill 257 65 -210 263 65 -210 minecraft:air
fill 255 65 -211 263 65 -211 minecraft:air
fill 254 65 -212 263 65 -212 minecraft:air
fill 253 65 -213 263 65 -213 minecraft:air
fill 253 65 -214 263 65 -214 minecraft:air
fill 252 65 -215 263 65 -215 minecraft:air
fill 252 65 -216 263 65 -216 minecraft:air
fill 251 65 -217 263 65 -217 minecraft:air
fill 251 65 -218 263 65 -218 minecraft:air
fill 251 65 -219 263 65 -219 minecraft:air
fill 251 65 -220 263 65 -220 minecraft:air
fill 251 65 -221 263 65 -221 minecraft:air
fill 251 65 -222 263 65 -222 minecraft:air
fill 251 65 -223 263 65 -223 minecraft:air
fill 251 65 -224 263 65 -224 minecraft:air
fill 251 65 -225 263 65 -225 minecraft:air
fill 252 65 -226 263 65 -226 minecraft:air
fill 252 65 -227 263 65 -227 minecraft:air
fill 253 65 -228 263 65 -228 minecraft:air
fill 253 65 -229 263 65 -229 minecraft:air
fill 254 65 -230 263 65 -230 minecraft:air
fill 255 65 -231 263 65 -231 minecraft:air
fill 257 65 -232 263 65 -232 minecraft:air
fill 259 65 -233 263 65 -233 minecraft:air
fill 243 64 -191 259 64 -191 minecraft:air
setblock 260 64 -191 regions_unexplored:grass_sprouts
setblock 261 64 -191 minecraft:air
setblock 262 64 -191 minecraft:short_grass
setblock 263 64 -191 minecraft:air
fill 244 64 -192 263 64 -192 minecraft:air
fill 244 64 -193 252 64 -193 minecraft:air
setblock 253 64 -193 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
fill 254 64 -193 263 64 -193 minecraft:air
fill 245 64 -194 250 64 -194 minecraft:air
setblock 251 64 -194 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 252 64 -194 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=3]
fill 253 64 -194 263 64 -194 minecraft:air
fill 247 64 -195 252 64 -195 minecraft:air
setblock 253 64 -195 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
fill 254 64 -195 263 64 -195 minecraft:air
fill 248 64 -196 252 64 -196 minecraft:air
setblock 253 64 -196 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=2]
fill 254 64 -196 263 64 -196 minecraft:air
fill 248 64 -197 252 64 -197 minecraft:air
setblock 253 64 -197 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
fill 254 64 -197 261 64 -197 minecraft:air
setblock 262 64 -197 regions_unexplored:grass_sprouts
setblock 263 64 -197 minecraft:air
fill 249 64 -198 263 64 -198 minecraft:air
fill 249 64 -199 250 64 -199 minecraft:air
setblock 251 64 -199 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=3]
setblock 252 64 -199 minecraft:short_grass
fill 253 64 -199 254 64 -199 minecraft:air
setblock 255 64 -199 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
fill 256 64 -199 263 64 -199 minecraft:air
fill 250 64 -200 258 64 -200 minecraft:air
setblock 259 64 -200 minecraft:short_grass
fill 260 64 -200 263 64 -200 minecraft:air
fill 251 64 -201 263 64 -201 minecraft:air
setblock 252 64 -202 minecraft:short_grass
fill 253 64 -202 255 64 -202 minecraft:air
fill 256 64 -202 257 64 -202 regions_unexplored:grass_sprouts
fill 258 64 -202 263 64 -202 minecraft:air
fill 215 64 -203 216 64 -203 minecraft:air
fill 254 64 -203 259 64 -203 minecraft:air
setblock 260 64 -203 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=3]
fill 261 64 -203 263 64 -203 minecraft:air
fill 215 64 -204 216 64 -204 minecraft:air
fill 256 64 -204 257 64 -204 minecraft:air
setblock 258 64 -204 regions_unexplored:grass_sprouts
setblock 259 64 -204 minecraft:air
setblock 260 64 -204 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 261 64 -204 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=4]
setblock 262 64 -204 minecraft:air
setblock 263 64 -204 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
fill 215 64 -205 216 64 -205 minecraft:air
fill 258 64 -205 263 64 -205 minecraft:air
fill 215 64 -206 216 64 -206 minecraft:air
setblock 263 64 -206 minecraft:air
fill 215 64 -207 216 64 -207 minecraft:air
setblock 249 64 -221 minecraft:air
fill 247 64 -222 249 64 -222 minecraft:air
fill 246 64 -223 249 64 -223 minecraft:air
fill 246 64 -224 247 64 -224 minecraft:air
setblock 248 64 -224 minecraft:short_grass
setblock 249 64 -224 minecraft:air
fill 246 64 -225 249 64 -225 minecraft:air
fill 246 64 -226 250 64 -226 minecraft:air
fill 246 64 -227 248 64 -227 minecraft:air
setblock 249 64 -227 regions_unexplored:grass_sprouts
setblock 250 64 -227 minecraft:air
fill 246 64 -228 251 64 -228 minecraft:air
fill 207 64 -229 210 64 -229 minecraft:air
fill 246 64 -229 250 64 -229 minecraft:air
fill 204 64 -230 205 64 -230 minecraft:air
setblock 206 64 -230 minecraft:short_grass
fill 207 64 -230 212 64 -230 minecraft:air
setblock 214 64 -230 minecraft:air
fill 247 64 -230 249 64 -230 minecraft:air
setblock 252 64 -230 minecraft:moss_carpet
fill 202 64 -231 203 64 -231 minecraft:air
fill 206 64 -231 219 64 -231 minecraft:air
fill 247 64 -231 250 64 -231 minecraft:air
fill 252 64 -231 253 64 -231 minecraft:air
setblock 200 64 -232 minecraft:short_grass
setblock 201 64 -232 minecraft:air
fill 203 64 -232 222 64 -232 minecraft:air
fill 247 64 -232 250 64 -232 minecraft:air
setblock 252 64 -232 minecraft:air
setblock 254 64 -232 minecraft:air
fill 201 64 -233 202 64 -233 minecraft:short_grass
fill 203 64 -233 205 64 -233 minecraft:air
fill 207 64 -233 214 64 -233 minecraft:air
setblock 215 64 -233 regions_unexplored:grass_sprouts
fill 216 64 -233 223 64 -233 minecraft:air
fill 246 64 -233 250 64 -233 minecraft:air
fill 252 64 -233 258 64 -233 minecraft:air
fill 200 64 -234 201 64 -234 minecraft:air
setblock 202 64 -234 minecraft:short_grass
setblock 204 64 -234 minecraft:short_grass
fill 205 64 -234 208 64 -234 minecraft:air
setblock 209 64 -234 minecraft:sugar_cane[age=0]
fill 210 64 -234 211 64 -234 minecraft:air
setblock 212 64 -234 minecraft:sugar_cane[age=0]
fill 213 64 -234 219 64 -234 minecraft:air
setblock 220 64 -234 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 221 64 -234 224 64 -234 minecraft:air
setblock 245 64 -234 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
fill 246 64 -234 250 64 -234 minecraft:air
fill 252 64 -234 259 64 -234 minecraft:air
setblock 201 64 -235 minecraft:air
fill 204 64 -235 213 64 -235 minecraft:air
setblock 214 64 -235 minecraft:sugar_cane[age=0]
fill 215 64 -235 217 64 -235 minecraft:air
setblock 218 64 -235 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 219 64 -235 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 220 64 -235 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 221 64 -235 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 222 64 -235 minecraft:air
setblock 223 64 -235 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 224 64 -235 minecraft:air
fill 238 64 -235 239 64 -235 minecraft:air
setblock 240 64 -235 regions_unexplored:grass_sprouts
setblock 241 64 -235 minecraft:air
setblock 242 64 -235 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 243 64 -235 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 244 64 -235 245 64 -235 minecraft:air
fill 247 64 -235 250 64 -235 minecraft:air
fill 252 64 -235 259 64 -235 minecraft:air
fill 261 64 -235 263 64 -235 minecraft:air
setblock 200 64 -236 minecraft:air
setblock 201 64 -236 minecraft:short_grass
fill 202 64 -236 219 64 -236 minecraft:air
setblock 220 64 -236 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 221 64 -236 minecraft:air
setblock 222 64 -236 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
setblock 223 64 -236 minecraft:air
setblock 224 64 -236 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 225 64 -236 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
fill 237 64 -236 238 64 -236 minecraft:air
setblock 240 64 -236 minecraft:air
setblock 241 64 -236 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
fill 242 64 -236 250 64 -236 minecraft:air
fill 252 64 -236 254 64 -236 minecraft:air
fill 256 64 -236 263 64 -236 minecraft:air
fill 200 64 -237 215 64 -237 minecraft:air
setblock 217 64 -237 minecraft:air
fill 219 64 -237 220 64 -237 minecraft:air
setblock 221 64 -237 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 222 64 -237 minecraft:air
setblock 224 64 -237 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
setblock 225 64 -237 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
fill 226 64 -237 233 64 -237 minecraft:air
fill 236 64 -237 238 64 -237 minecraft:air
setblock 239 64 -237 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 240 64 -237 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 241 64 -237 minecraft:air
setblock 242 64 -237 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
fill 243 64 -237 263 64 -237 minecraft:air
fill 200 64 -238 216 64 -238 minecraft:air
setblock 222 64 -238 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 223 64 -238 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 224 64 -238 minecraft:air
setblock 225 64 -238 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
fill 227 64 -238 228 64 -238 minecraft:air
setblock 229 64 -238 minecraft:short_grass
fill 230 64 -238 232 64 -238 minecraft:air
setblock 233 64 -238 regions_unexplored:grass_sprouts
fill 234 64 -238 237 64 -238 minecraft:air
setblock 238 64 -238 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 239 64 -238 251 64 -238 minecraft:air
setblock 252 64 -238 ars_nouveau:light_block[level=14,waterlogged=false]
fill 254 64 -238 263 64 -238 minecraft:air
fill 200 64 -239 222 64 -239 minecraft:air
setblock 223 64 -239 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 224 64 -239 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 225 64 -239 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 226 64 -239 minecraft:short_grass
setblock 227 64 -239 regions_unexplored:grass_sprouts
fill 228 64 -239 238 64 -239 minecraft:air
setblock 239 64 -239 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
setblock 241 64 -239 minecraft:air
setblock 242 64 -239 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
fill 243 64 -239 250 64 -239 minecraft:air
fill 252 64 -239 263 64 -239 minecraft:air
fill 200 64 -240 218 64 -240 minecraft:air
fill 220 64 -240 223 64 -240 minecraft:air
setblock 224 64 -240 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 225 64 -240 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 226 64 -240 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=2]
fill 227 64 -240 228 64 -240 minecraft:air
setblock 229 64 -240 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
fill 230 64 -240 237 64 -240 minecraft:air
setblock 238 64 -240 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
fill 239 64 -240 263 64 -240 minecraft:air
fill 200 64 -241 220 64 -241 minecraft:air
fill 223 64 -241 263 64 -241 minecraft:air
fill 200 64 -242 228 64 -242 minecraft:air
setblock 229 64 -242 regions_unexplored:grass_sprouts
fill 230 64 -242 263 64 -242 minecraft:air
fill 200 64 -243 263 64 -243 minecraft:air
fill 200 64 -244 217 64 -244 minecraft:air
fill 219 64 -244 250 64 -244 minecraft:air
fill 252 64 -244 256 64 -244 minecraft:air
fill 258 64 -244 263 64 -244 minecraft:air
fill 200 64 -245 245 64 -245 minecraft:air
fill 247 64 -245 263 64 -245 minecraft:air
fill 200 64 -246 263 64 -246 minecraft:air
fill 200 64 -247 260 64 -247 minecraft:air
setblock 261 64 -247 regions_unexplored:grass_sprouts
fill 262 64 -247 263 64 -247 minecraft:air
fill 200 64 -248 262 64 -248 minecraft:air
setblock 263 64 -248 minecraft:short_grass
fill 200 64 -249 263 64 -249 minecraft:air
fill 200 64 -250 259 64 -250 minecraft:air
setblock 260 64 -250 regions_unexplored:grass_sprouts
setblock 261 64 -250 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
fill 262 64 -250 263 64 -250 minecraft:air
fill 200 64 -251 261 64 -251 minecraft:air
setblock 262 64 -251 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
setblock 263 64 -251 minecraft:air
fill 200 64 -252 258 64 -252 minecraft:air
setblock 259 64 -252 regions_unexplored:grass_sprouts
setblock 260 64 -252 minecraft:air
setblock 261 64 -252 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 262 64 -252 minecraft:air
setblock 263 64 -252 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 200 64 -253 261 64 -253 minecraft:air
setblock 263 64 -253 minecraft:air
fill 200 64 -254 259 64 -254 minecraft:air
setblock 260 64 -254 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 261 64 -254 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
setblock 262 64 -254 regions_unexplored:grass_sprouts
setblock 263 64 -254 minecraft:air
setblock 263 63 -191 minecraft:air
setblock 200 63 -196 minecraft:air
fill 200 63 -197 201 63 -197 minecraft:air
fill 200 63 -198 201 63 -198 minecraft:air
fill 215 63 -202 216 63 -202 minecraft:air
fill 215 63 -203 216 63 -203 minecraft:air
fill 215 63 -204 216 63 -204 minecraft:air
fill 215 63 -205 216 63 -205 minecraft:air
fill 215 63 -206 216 63 -206 minecraft:air
fill 207 63 -233 211 63 -233 minecraft:air
fill 205 63 -234 208 63 -234 minecraft:air
setblock 209 63 -234 minecraft:sugar_cane[age=0]
fill 210 63 -234 211 63 -234 minecraft:air
setblock 212 63 -234 minecraft:sugar_cane[age=0]
fill 213 63 -234 214 63 -234 minecraft:air
fill 205 63 -235 213 63 -235 minecraft:air
setblock 214 63 -235 minecraft:sugar_cane[age=0]
fill 215 63 -235 216 63 -235 minecraft:air
fill 237 63 -235 239 63 -235 minecraft:air
fill 202 63 -236 217 63 -236 minecraft:air
fill 237 63 -236 238 63 -236 minecraft:air
setblock 202 63 -237 regions_unexplored:grass_sprouts
fill 203 63 -237 215 63 -237 minecraft:air
setblock 217 63 -237 minecraft:air
fill 236 63 -237 237 63 -237 minecraft:air
setblock 238 63 -237 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
fill 200 63 -238 216 63 -238 minecraft:air
fill 236 63 -238 237 63 -238 minecraft:air
setblock 256 63 -238 minecraft:air
fill 200 63 -239 218 63 -239 minecraft:air
setblock 219 63 -239 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 220 63 -239 221 63 -239 minecraft:air
fill 235 63 -239 237 63 -239 minecraft:air
setblock 241 63 -239 minecraft:air
fill 253 63 -239 257 63 -239 minecraft:air
fill 200 63 -240 218 63 -240 minecraft:air
setblock 220 63 -240 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 221 63 -240 regions_unexplored:grass_sprouts
setblock 222 63 -240 minecraft:air
fill 234 63 -240 236 63 -240 minecraft:air
setblock 239 63 -240 minecraft:air
setblock 240 63 -240 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
setblock 241 63 -240 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=2]
fill 242 63 -240 243 63 -240 minecraft:air
fill 249 63 -240 259 63 -240 minecraft:air
fill 200 63 -241 220 63 -241 minecraft:air
fill 223 63 -241 224 63 -241 minecraft:air
fill 234 63 -241 235 63 -241 minecraft:air
setblock 237 63 -241 minecraft:air
setblock 238 63 -241 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
fill 239 63 -241 243 63 -241 minecraft:air
setblock 245 63 -241 minecraft:air
setblock 246 63 -241 minecraft:short_grass
setblock 247 63 -241 minecraft:air
setblock 248 63 -241 minecraft:short_grass
fill 249 63 -241 259 63 -241 minecraft:air
fill 200 63 -242 219 63 -242 minecraft:air
setblock 220 63 -242 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 221 63 -242 minecraft:air
setblock 222 63 -242 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 223 63 -242 minecraft:air
setblock 224 63 -242 regions_unexplored:grass_sprouts
fill 225 63 -242 226 63 -242 minecraft:air
fill 231 63 -242 240 63 -242 minecraft:air
fill 242 63 -242 243 63 -242 minecraft:air
setblock 244 63 -242 minecraft:short_grass
setblock 245 63 -242 minecraft:air
setblock 246 63 -242 minecraft:short_grass
fill 247 63 -242 248 63 -242 minecraft:air
setblock 249 63 -242 minecraft:short_grass
fill 250 63 -242 260 63 -242 minecraft:air
fill 200 63 -243 218 63 -243 minecraft:air
setblock 219 63 -243 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
setblock 220 63 -243 minecraft:air
setblock 221 63 -243 regions_unexplored:grass_sprouts
setblock 222 63 -243 minecraft:air
setblock 223 63 -243 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
setblock 224 63 -243 minecraft:air
setblock 225 63 -243 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 226 63 -243 minecraft:short_grass
setblock 227 63 -243 minecraft:air
fill 229 63 -243 260 63 -243 minecraft:air
fill 200 63 -244 217 63 -244 minecraft:air
fill 219 63 -244 220 63 -244 minecraft:air
setblock 221 63 -244 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
fill 222 63 -244 224 63 -244 minecraft:air
setblock 225 63 -244 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 226 63 -244 minecraft:short_grass
fill 227 63 -244 237 63 -244 minecraft:air
fill 239 63 -244 240 63 -244 minecraft:air
fill 242 63 -244 248 63 -244 minecraft:air
setblock 249 63 -244 regions_unexplored:grass_sprouts
setblock 250 63 -244 minecraft:air
fill 252 63 -244 256 63 -244 minecraft:air
fill 258 63 -244 260 63 -244 minecraft:air
fill 200 63 -245 220 63 -245 minecraft:air
setblock 222 63 -245 minecraft:air
setblock 224 63 -245 minecraft:air
fill 226 63 -245 241 63 -245 minecraft:air
fill 243 63 -245 245 63 -245 minecraft:air
fill 247 63 -245 260 63 -245 minecraft:air
fill 200 63 -246 224 63 -246 minecraft:air
fill 227 63 -246 240 63 -246 minecraft:air
fill 242 63 -246 244 63 -246 minecraft:air
setblock 245 63 -246 minecraft:short_grass
fill 246 63 -246 260 63 -246 minecraft:air
fill 200 63 -247 219 63 -247 minecraft:air
fill 222 63 -247 225 63 -247 minecraft:air
setblock 227 63 -247 minecraft:air
fill 229 63 -247 240 63 -247 minecraft:air
fill 242 63 -247 247 63 -247 minecraft:air
fill 249 63 -247 260 63 -247 minecraft:air
fill 200 63 -248 219 63 -248 minecraft:air
fill 221 63 -248 241 63 -248 minecraft:air
fill 243 63 -248 260 63 -248 minecraft:air
fill 200 63 -249 260 63 -249 minecraft:air
fill 200 63 -250 259 63 -250 minecraft:air
fill 200 63 -251 259 63 -251 minecraft:air
fill 200 63 -252 251 63 -252 minecraft:air
fill 253 63 -252 258 63 -252 minecraft:air
fill 200 63 -253 259 63 -253 minecraft:air
fill 200 63 -254 256 63 -254 minecraft:air
setblock 257 63 -254 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 258 63 -254 minecraft:air
setblock 259 63 -254 minecraft:short_grass
setblock 263 62 -191 minecraft:air
setblock 200 62 -195 minecraft:water[level=0]
fill 200 62 -196 201 62 -196 minecraft:water[level=0]
fill 200 62 -197 202 62 -197 minecraft:water[level=0]
fill 200 62 -198 203 62 -198 minecraft:water[level=0]
fill 200 62 -199 203 62 -199 minecraft:water[level=0]
setblock 203 62 -200 minecraft:water[level=0]
setblock 216 62 -201 minecraft:water[level=0]
fill 215 62 -202 216 62 -202 minecraft:water[level=0]
fill 215 62 -203 216 62 -203 minecraft:water[level=0]
fill 215 62 -204 216 62 -204 minecraft:water[level=0]
fill 215 62 -205 216 62 -205 minecraft:water[level=0]
fill 208 62 -235 209 62 -235 minecraft:water[level=0]
fill 210 62 -235 211 62 -235 minecraft:seagrass
setblock 212 62 -235 minecraft:water[level=0]
fill 237 62 -235 238 62 -235 minecraft:water[level=0]
fill 207 62 -236 212 62 -236 minecraft:water[level=0]
setblock 213 62 -236 minecraft:seagrass
setblock 214 62 -236 minecraft:water[level=0]
fill 236 62 -236 238 62 -236 minecraft:water[level=0]
fill 205 62 -237 210 62 -237 minecraft:water[level=0]
setblock 211 62 -237 minecraft:tall_seagrass[half=upper]
fill 212 62 -237 213 62 -237 minecraft:water[level=0]
setblock 214 62 -237 minecraft:seagrass
setblock 215 62 -237 minecraft:water[level=0]
fill 236 62 -237 237 62 -237 minecraft:water[level=0]
fill 202 62 -238 214 62 -238 minecraft:water[level=0]
setblock 215 62 -238 minecraft:seagrass
setblock 216 62 -238 minecraft:water[level=0]
fill 235 62 -238 237 62 -238 minecraft:water[level=0]
fill 200 62 -239 212 62 -239 minecraft:water[level=0]
setblock 213 62 -239 minecraft:tall_seagrass[half=upper]
fill 214 62 -239 217 62 -239 minecraft:water[level=0]
fill 235 62 -239 236 62 -239 minecraft:water[level=0]
fill 200 62 -240 217 62 -240 minecraft:water[level=0]
setblock 218 62 -240 minecraft:seagrass
fill 234 62 -240 236 62 -240 minecraft:water[level=0]
fill 200 62 -241 218 62 -241 minecraft:water[level=0]
fill 234 62 -241 235 62 -241 minecraft:water[level=0]
fill 200 62 -242 215 62 -242 minecraft:water[level=0]
fill 216 62 -242 217 62 -242 minecraft:seagrass
fill 233 62 -242 235 62 -242 minecraft:water[level=0]
fill 200 62 -243 217 62 -243 minecraft:water[level=0]
fill 233 62 -243 234 62 -243 minecraft:water[level=0]
fill 238 62 -243 241 62 -243 minecraft:water[level=0]
fill 200 62 -244 216 62 -244 minecraft:water[level=0]
fill 232 62 -244 237 62 -244 minecraft:water[level=0]
fill 239 62 -244 240 62 -244 minecraft:water[level=0]
setblock 252 62 -244 minecraft:water[level=0]
fill 200 62 -245 220 62 -245 minecraft:water[level=0]
setblock 222 62 -245 minecraft:water[level=0]
setblock 224 62 -245 minecraft:seagrass
fill 231 62 -245 241 62 -245 minecraft:water[level=0]
fill 248 62 -245 253 62 -245 minecraft:water[level=0]
fill 200 62 -246 223 62 -246 minecraft:water[level=0]
setblock 224 62 -246 minecraft:seagrass
fill 227 62 -246 240 62 -246 minecraft:water[level=0]
fill 242 62 -246 243 62 -246 minecraft:water[level=0]
fill 246 62 -246 248 62 -246 minecraft:water[level=0]
setblock 249 62 -246 minecraft:seagrass
fill 250 62 -246 253 62 -246 minecraft:water[level=0]
setblock 254 62 -246 minecraft:seagrass
fill 200 62 -247 219 62 -247 minecraft:water[level=0]
fill 222 62 -247 225 62 -247 minecraft:water[level=0]
setblock 227 62 -247 minecraft:water[level=0]
fill 229 62 -247 240 62 -247 minecraft:water[level=0]
fill 242 62 -247 247 62 -247 minecraft:water[level=0]
fill 249 62 -247 255 62 -247 minecraft:water[level=0]
fill 200 62 -248 219 62 -248 minecraft:water[level=0]
setblock 221 62 -248 minecraft:water[level=0]
setblock 222 62 -248 minecraft:tall_seagrass[half=upper]
fill 223 62 -248 225 62 -248 minecraft:water[level=0]
setblock 226 62 -248 minecraft:tall_seagrass[half=upper]
fill 227 62 -248 241 62 -248 minecraft:water[level=0]
fill 243 62 -248 247 62 -248 minecraft:water[level=0]
setblock 248 62 -248 minecraft:tall_seagrass[half=upper]
fill 249 62 -248 255 62 -248 minecraft:water[level=0]
fill 200 62 -249 250 62 -249 minecraft:water[level=0]
setblock 251 62 -249 minecraft:tall_seagrass[half=upper]
fill 252 62 -249 255 62 -249 minecraft:water[level=0]
fill 200 62 -250 252 62 -250 minecraft:water[level=0]
setblock 253 62 -250 minecraft:seagrass
fill 254 62 -250 255 62 -250 minecraft:water[level=0]
fill 200 62 -251 255 62 -251 minecraft:water[level=0]
fill 200 62 -252 251 62 -252 minecraft:water[level=0]
setblock 253 62 -252 minecraft:seagrass
setblock 254 62 -252 minecraft:water[level=0]
fill 200 62 -253 250 62 -253 minecraft:water[level=0]
setblock 251 62 -253 minecraft:tall_seagrass[half=upper]
fill 252 62 -253 254 62 -253 minecraft:water[level=0]
fill 200 62 -254 253 62 -254 minecraft:water[level=0]
setblock 254 62 -254 minecraft:seagrass
setblock 255 62 -254 minecraft:water[level=0]
setblock 200 61 -195 minecraft:water[level=0]
fill 200 61 -196 202 61 -196 minecraft:water[level=0]
fill 200 61 -197 203 61 -197 minecraft:water[level=0]
fill 200 61 -198 204 61 -198 minecraft:water[level=0]
fill 200 61 -199 204 61 -199 minecraft:water[level=0]
fill 201 61 -200 204 61 -200 minecraft:water[level=0]
fill 203 61 -201 204 61 -201 minecraft:water[level=0]
fill 214 61 -201 215 61 -201 minecraft:water[level=0]
fill 214 61 -202 215 61 -202 minecraft:water[level=0]
fill 215 61 -203 216 61 -203 minecraft:water[level=0]
fill 215 61 -204 216 61 -204 minecraft:water[level=0]
setblock 202 61 -209 minecraft:water[level=0]
setblock 200 61 -210 minecraft:water[level=0]
setblock 239 61 -234 minecraft:water[level=0]
fill 237 61 -235 238 61 -235 minecraft:water[level=0]
setblock 211 61 -236 minecraft:water[level=0]
setblock 212 61 -236 minecraft:seagrass
fill 236 61 -236 238 61 -236 minecraft:water[level=0]
setblock 208 61 -237 minecraft:water[level=0]
setblock 209 61 -237 minecraft:seagrass
setblock 210 61 -237 minecraft:water[level=0]
setblock 211 61 -237 minecraft:tall_seagrass[half=lower]
setblock 212 61 -237 minecraft:water[level=0]
fill 236 61 -237 237 61 -237 minecraft:water[level=0]
fill 206 61 -238 211 61 -238 minecraft:water[level=0]
setblock 212 61 -238 minecraft:seagrass
setblock 213 61 -238 minecraft:water[level=0]
fill 235 61 -238 237 61 -238 minecraft:water[level=0]
fill 202 61 -239 212 61 -239 minecraft:water[level=0]
setblock 213 61 -239 minecraft:tall_seagrass[half=lower]
setblock 214 61 -239 minecraft:water[level=0]
fill 235 61 -239 236 61 -239 minecraft:water[level=0]
fill 200 61 -240 215 61 -240 minecraft:water[level=0]
fill 234 61 -240 236 61 -240 minecraft:water[level=0]
fill 200 61 -241 214 61 -241 minecraft:water[level=0]
fill 234 61 -241 235 61 -241 minecraft:water[level=0]
fill 200 61 -242 214 61 -242 minecraft:water[level=0]
fill 233 61 -242 235 61 -242 minecraft:water[level=0]
fill 200 61 -243 214 61 -243 minecraft:water[level=0]
fill 233 61 -243 234 61 -243 minecraft:water[level=0]
fill 200 61 -244 213 61 -244 minecraft:water[level=0]
fill 233 61 -244 234 61 -244 minecraft:water[level=0]
fill 200 61 -245 214 61 -245 minecraft:water[level=0]
setblock 233 61 -245 minecraft:water[level=0]
fill 200 61 -246 214 61 -246 minecraft:water[level=0]
setblock 232 61 -246 minecraft:water[level=0]
fill 239 61 -246 240 61 -246 minecraft:water[level=0]
fill 200 61 -247 215 61 -247 minecraft:water[level=0]
setblock 223 61 -247 minecraft:water[level=0]
setblock 224 61 -247 minecraft:seagrass
setblock 225 61 -247 minecraft:water[level=0]
setblock 232 61 -247 minecraft:water[level=0]
fill 236 61 -247 240 61 -247 minecraft:water[level=0]
fill 200 61 -248 219 61 -248 minecraft:water[level=0]
setblock 221 61 -248 minecraft:water[level=0]
setblock 222 61 -248 minecraft:tall_seagrass[half=lower]
fill 223 61 -248 224 61 -248 minecraft:water[level=0]
setblock 225 61 -248 minecraft:seagrass
setblock 226 61 -248 minecraft:tall_seagrass[half=lower]
fill 227 61 -248 241 61 -248 minecraft:water[level=0]
setblock 248 61 -248 minecraft:tall_seagrass[half=lower]
fill 249 61 -248 252 61 -248 minecraft:water[level=0]
fill 200 61 -249 242 61 -249 minecraft:water[level=0]
fill 246 61 -249 250 61 -249 minecraft:water[level=0]
setblock 251 61 -249 minecraft:tall_seagrass[half=lower]
setblock 252 61 -249 minecraft:seagrass
fill 200 61 -250 249 61 -250 minecraft:water[level=0]
setblock 250 61 -250 minecraft:seagrass
setblock 251 61 -250 minecraft:water[level=0]
setblock 252 61 -250 minecraft:seagrass
fill 200 61 -251 252 61 -251 minecraft:water[level=0]
fill 200 61 -252 251 61 -252 minecraft:water[level=0]
fill 200 61 -253 250 61 -253 minecraft:water[level=0]
setblock 251 61 -253 minecraft:tall_seagrass[half=lower]
fill 200 61 -254 252 61 -254 minecraft:water[level=0]
fill 200 60 -195 201 60 -195 minecraft:water[level=0]
fill 200 60 -196 202 60 -196 minecraft:water[level=0]
fill 200 60 -197 203 60 -197 minecraft:water[level=0]
fill 200 60 -198 204 60 -198 minecraft:water[level=0]
fill 200 60 -199 204 60 -199 minecraft:water[level=0]
fill 201 60 -200 205 60 -200 minecraft:water[level=0]
setblock 215 60 -200 minecraft:water[level=0]
fill 202 60 -201 205 60 -201 minecraft:water[level=0]
fill 214 60 -201 215 60 -201 minecraft:water[level=0]
fill 203 60 -202 205 60 -202 minecraft:water[level=0]
fill 214 60 -202 215 60 -202 minecraft:water[level=0]
fill 204 60 -203 205 60 -203 minecraft:water[level=0]
fill 214 60 -203 215 60 -203 minecraft:water[level=0]
fill 204 60 -204 205 60 -204 minecraft:water[level=0]
setblock 214 60 -204 minecraft:water[level=0]
fill 204 60 -205 205 60 -205 minecraft:water[level=0]
fill 204 60 -206 205 60 -206 minecraft:water[level=0]
fill 203 60 -207 204 60 -207 minecraft:water[level=0]
fill 202 60 -208 204 60 -208 minecraft:water[level=0]
fill 200 60 -209 203 60 -209 minecraft:water[level=0]
fill 200 60 -210 203 60 -210 minecraft:water[level=0]
setblock 200 60 -211 minecraft:water[level=0]
fill 238 60 -234 239 60 -234 minecraft:water[level=0]
fill 237 60 -235 238 60 -235 minecraft:water[level=0]
fill 236 60 -236 238 60 -236 minecraft:water[level=0]
fill 236 60 -237 237 60 -237 minecraft:water[level=0]
fill 235 60 -238 237 60 -238 minecraft:water[level=0]
fill 207 60 -239 211 60 -239 minecraft:water[level=0]
setblock 212 60 -239 minecraft:seagrass
fill 235 60 -239 236 60 -239 minecraft:water[level=0]
fill 202 60 -240 213 60 -240 minecraft:water[level=0]
fill 234 60 -240 235 60 -240 minecraft:water[level=0]
fill 201 60 -241 213 60 -241 minecraft:water[level=0]
fill 234 60 -241 235 60 -241 minecraft:water[level=0]
fill 200 60 -242 212 60 -242 minecraft:water[level=0]
fill 234 60 -242 235 60 -242 minecraft:water[level=0]
fill 200 60 -243 212 60 -243 minecraft:water[level=0]
fill 233 60 -243 234 60 -243 minecraft:water[level=0]
fill 200 60 -244 212 60 -244 minecraft:water[level=0]
setblock 233 60 -244 minecraft:water[level=0]
fill 200 60 -245 212 60 -245 minecraft:water[level=0]
setblock 233 60 -245 minecraft:water[level=0]
fill 200 60 -246 212 60 -246 minecraft:water[level=0]
fill 200 60 -247 212 60 -247 minecraft:water[level=0]
fill 200 60 -248 212 60 -248 minecraft:water[level=0]
fill 200 60 -249 215 60 -249 minecraft:water[level=0]
setblock 222 60 -249 minecraft:water[level=0]
setblock 223 60 -249 minecraft:seagrass
setblock 224 60 -249 minecraft:water[level=0]
setblock 225 60 -249 minecraft:seagrass
fill 226 60 -249 229 60 -249 minecraft:water[level=0]
fill 200 60 -250 221 60 -250 minecraft:water[level=0]
setblock 222 60 -250 minecraft:seagrass
fill 223 60 -250 231 60 -250 minecraft:water[level=0]
fill 238 60 -250 240 60 -250 minecraft:water[level=0]
fill 200 60 -251 217 60 -251 minecraft:water[level=0]
setblock 218 60 -251 minecraft:tall_seagrass[half=upper]
fill 219 60 -251 242 60 -251 minecraft:water[level=0]
fill 200 60 -252 243 60 -252 minecraft:water[level=0]
fill 200 60 -253 248 60 -253 minecraft:water[level=0]
fill 200 60 -254 248 60 -254 minecraft:water[level=0]
setblock 200 59 -195 minecraft:water[level=0]
fill 200 59 -196 202 59 -196 minecraft:water[level=0]
fill 200 59 -197 203 59 -197 minecraft:water[level=0]
fill 200 59 -198 204 59 -198 minecraft:water[level=0]
fill 200 59 -199 205 59 -199 minecraft:water[level=0]
fill 201 59 -200 205 59 -200 minecraft:water[level=0]
fill 214 59 -200 215 59 -200 minecraft:water[level=0]
fill 202 59 -201 205 59 -201 minecraft:water[level=0]
fill 214 59 -201 215 59 -201 minecraft:water[level=0]
fill 203 59 -202 206 59 -202 minecraft:water[level=0]
fill 214 59 -202 215 59 -202 minecraft:water[level=0]
fill 203 59 -203 206 59 -203 minecraft:water[level=0]
fill 214 59 -203 215 59 -203 minecraft:water[level=0]
fill 203 59 -204 206 59 -204 minecraft:water[level=0]
fill 203 59 -205 205 59 -205 minecraft:water[level=0]
fill 203 59 -206 205 59 -206 minecraft:water[level=0]
fill 203 59 -207 205 59 -207 minecraft:water[level=0]
fill 201 59 -208 205 59 -208 minecraft:water[level=0]
fill 200 59 -209 204 59 -209 minecraft:water[level=0]
fill 200 59 -210 203 59 -210 minecraft:water[level=0]
fill 200 59 -211 202 59 -211 minecraft:water[level=0]
setblock 239 59 -233 minecraft:water[level=0]
fill 237 59 -234 238 59 -234 minecraft:water[level=0]
fill 237 59 -235 238 59 -235 minecraft:water[level=0]
fill 236 59 -236 237 59 -236 minecraft:water[level=0]
fill 236 59 -237 237 59 -237 minecraft:water[level=0]
fill 235 59 -238 236 59 -238 minecraft:water[level=0]
fill 235 59 -239 236 59 -239 minecraft:water[level=0]
fill 204 59 -240 205 59 -240 minecraft:water[level=0]
fill 234 59 -240 235 59 -240 minecraft:water[level=0]
fill 204 59 -241 205 59 -241 minecraft:water[level=0]
fill 234 59 -241 235 59 -241 minecraft:water[level=0]
fill 203 59 -242 206 59 -242 minecraft:water[level=0]
setblock 234 59 -242 minecraft:water[level=0]
fill 202 59 -243 206 59 -243 minecraft:water[level=0]
setblock 234 59 -243 minecraft:water[level=0]
fill 201 59 -244 206 59 -244 minecraft:water[level=0]
setblock 233 59 -244 minecraft:water[level=0]
fill 201 59 -245 206 59 -245 minecraft:water[level=0]
setblock 233 59 -245 minecraft:water[level=0]
fill 201 59 -246 205 59 -246 minecraft:water[level=0]
fill 201 59 -247 205 59 -247 minecraft:water[level=0]
fill 201 59 -248 205 59 -248 minecraft:water[level=0]
fill 200 59 -249 207 59 -249 minecraft:water[level=0]
fill 200 59 -250 212 59 -250 minecraft:water[level=0]
setblock 223 59 -250 minecraft:seagrass
fill 224 59 -250 226 59 -250 minecraft:water[level=0]
setblock 227 59 -250 minecraft:seagrass
setblock 228 59 -250 minecraft:water[level=0]
fill 200 59 -251 217 59 -251 minecraft:water[level=0]
setblock 218 59 -251 minecraft:tall_seagrass[half=lower]
fill 219 59 -251 230 59 -251 minecraft:water[level=0]
fill 200 59 -252 233 59 -252 minecraft:water[level=0]
fill 239 59 -252 240 59 -252 minecraft:water[level=0]
fill 200 59 -253 209 59 -253 minecraft:water[level=0]
setblock 210 59 -253 minecraft:tall_seagrass[half=upper]
fill 211 59 -253 235 59 -253 minecraft:water[level=0]
fill 237 59 -253 242 59 -253 minecraft:water[level=0]
fill 200 59 -254 243 59 -254 minecraft:water[level=0]
fill 201 58 -197 203 58 -197 minecraft:water[level=0]
fill 201 58 -198 204 58 -198 minecraft:water[level=0]
fill 201 58 -199 205 58 -199 minecraft:water[level=0]
setblock 214 58 -199 minecraft:water[level=0]
fill 201 58 -200 205 58 -200 minecraft:water[level=0]
fill 213 58 -200 215 58 -200 minecraft:water[level=0]
fill 202 58 -201 206 58 -201 minecraft:water[level=0]
fill 213 58 -201 215 58 -201 minecraft:water[level=0]
fill 203 58 -202 206 58 -202 minecraft:water[level=0]
fill 214 58 -202 215 58 -202 minecraft:water[level=0]
fill 203 58 -203 206 58 -203 minecraft:water[level=0]
fill 203 58 -204 206 58 -204 minecraft:water[level=0]
fill 203 58 -205 206 58 -205 minecraft:water[level=0]
fill 203 58 -206 206 58 -206 minecraft:water[level=0]
fill 202 58 -207 205 58 -207 minecraft:water[level=0]
fill 201 58 -208 205 58 -208 minecraft:water[level=0]
fill 200 58 -209 204 58 -209 minecraft:water[level=0]
fill 200 58 -210 203 58 -210 minecraft:water[level=0]
fill 200 58 -211 202 58 -211 minecraft:water[level=0]
fill 238 58 -233 239 58 -233 minecraft:water[level=0]
fill 237 58 -234 238 58 -234 minecraft:water[level=0]
fill 236 58 -235 238 58 -235 minecraft:water[level=0]
fill 236 58 -236 237 58 -236 minecraft:water[level=0]
fill 236 58 -237 237 58 -237 minecraft:water[level=0]
fill 235 58 -238 236 58 -238 minecraft:water[level=0]
fill 235 58 -239 236 58 -239 minecraft:water[level=0]
setblock 235 58 -240 minecraft:water[level=0]
fill 234 58 -241 235 58 -241 minecraft:water[level=0]
setblock 234 58 -242 minecraft:water[level=0]
setblock 234 58 -243 minecraft:water[level=0]
setblock 204 58 -249 minecraft:water[level=0]
fill 200 58 -250 206 58 -250 minecraft:water[level=0]
fill 200 58 -251 207 58 -251 minecraft:water[level=0]
fill 224 58 -251 228 58 -251 minecraft:water[level=0]
fill 200 58 -252 211 58 -252 minecraft:water[level=0]
fill 217 58 -252 230 58 -252 minecraft:water[level=0]
fill 200 58 -253 207 58 -253 minecraft:water[level=0]
setblock 208 58 -253 minecraft:tall_seagrass[half=upper]
setblock 209 58 -253 minecraft:water[level=0]
setblock 210 58 -253 minecraft:tall_seagrass[half=lower]
setblock 211 58 -253 minecraft:water[level=0]
setblock 212 58 -253 minecraft:seagrass
fill 213 58 -253 231 58 -253 minecraft:water[level=0]
fill 200 58 -254 208 58 -254 minecraft:water[level=0]
setblock 209 58 -254 minecraft:tall_seagrass[half=upper]
fill 210 58 -254 212 58 -254 minecraft:water[level=0]
setblock 213 58 -254 minecraft:tall_seagrass[half=upper]
fill 214 58 -254 232 58 -254 minecraft:water[level=0]
setblock 240 58 -254 minecraft:water[level=0]
fill 203 57 -199 204 57 -199 minecraft:water[level=0]
fill 213 57 -199 214 57 -199 minecraft:water[level=0]
fill 202 57 -200 205 57 -200 minecraft:water[level=0]
fill 213 57 -200 214 57 -200 minecraft:water[level=0]
fill 202 57 -201 206 57 -201 minecraft:water[level=0]
fill 213 57 -201 214 57 -201 minecraft:water[level=0]
fill 203 57 -202 206 57 -202 minecraft:water[level=0]
fill 213 57 -202 214 57 -202 minecraft:water[level=0]
fill 203 57 -203 206 57 -203 minecraft:water[level=0]
fill 203 57 -204 206 57 -204 minecraft:water[level=0]
fill 203 57 -205 206 57 -205 minecraft:water[level=0]
fill 203 57 -206 206 57 -206 minecraft:water[level=0]
fill 202 57 -207 205 57 -207 minecraft:water[level=0]
fill 203 57 -208 205 57 -208 minecraft:water[level=0]
setblock 204 57 -209 minecraft:water[level=0]
fill 238 57 -232 239 57 -232 minecraft:water[level=0]
fill 237 57 -233 239 57 -233 minecraft:water[level=0]
fill 237 57 -234 238 57 -234 minecraft:water[level=0]
fill 236 57 -235 238 57 -235 minecraft:water[level=0]
fill 236 57 -236 237 57 -236 minecraft:water[level=0]
fill 235 57 -237 237 57 -237 minecraft:water[level=0]
fill 235 57 -238 236 57 -238 minecraft:water[level=0]
fill 235 57 -239 236 57 -239 minecraft:water[level=0]
setblock 235 57 -240 minecraft:water[level=0]
setblock 235 57 -241 minecraft:water[level=0]
setblock 234 57 -242 minecraft:water[level=0]
setblock 234 57 -243 minecraft:water[level=0]
fill 200 57 -251 204 57 -251 minecraft:water[level=0]
fill 200 57 -252 206 57 -252 minecraft:water[level=0]
fill 224 57 -252 228 57 -252 minecraft:water[level=0]
fill 200 57 -253 207 57 -253 minecraft:water[level=0]
setblock 208 57 -253 minecraft:tall_seagrass[half=lower]
fill 219 57 -253 229 57 -253 minecraft:water[level=0]
fill 201 57 -254 208 57 -254 minecraft:water[level=0]
setblock 209 57 -254 minecraft:tall_seagrass[half=lower]
fill 210 57 -254 212 57 -254 minecraft:water[level=0]
setblock 213 57 -254 minecraft:tall_seagrass[half=lower]
setblock 214 57 -254 minecraft:seagrass
fill 215 57 -254 230 57 -254 minecraft:water[level=0]
setblock 213 56 -198 minecraft:water[level=0]
fill 212 56 -199 214 56 -199 minecraft:water[level=0]
fill 213 56 -200 214 56 -200 minecraft:water[level=0]
fill 213 56 -201 214 56 -201 minecraft:water[level=0]
fill 204 56 -202 205 56 -202 minecraft:water[level=0]
fill 203 56 -203 206 56 -203 minecraft:water[level=0]
fill 203 56 -204 206 56 -204 minecraft:water[level=0]
fill 203 56 -205 206 56 -205 minecraft:water[level=0]
fill 203 56 -206 206 56 -206 minecraft:water[level=0]
fill 204 56 -207 205 56 -207 minecraft:water[level=0]
fill 239 56 -230 240 56 -230 minecraft:water[level=0]
fill 238 56 -231 239 56 -231 minecraft:water[level=0]
fill 238 56 -232 239 56 -232 minecraft:water[level=0]
fill 237 56 -233 238 56 -233 minecraft:water[level=0]
fill 237 56 -234 238 56 -234 minecraft:water[level=0]
fill 236 56 -235 237 56 -235 minecraft:water[level=0]
fill 236 56 -236 237 56 -236 minecraft:water[level=0]
fill 236 56 -237 237 56 -237 minecraft:water[level=0]
fill 235 56 -238 236 56 -238 minecraft:water[level=0]
fill 235 56 -239 236 56 -239 minecraft:water[level=0]
setblock 235 56 -240 minecraft:water[level=0]
setblock 235 56 -241 minecraft:water[level=0]
fill 227 56 -253 228 56 -253 minecraft:water[level=0]
fill 221 56 -254 228 56 -254 minecraft:water[level=0]
setblock 200 55 -191 minecraft:air
setblock 213 55 -198 minecraft:water[level=0]
fill 212 55 -199 213 55 -199 minecraft:water[level=0]
fill 212 55 -200 214 55 -200 minecraft:water[level=0]
fill 212 55 -201 213 55 -201 minecraft:water[level=0]
fill 239 55 -229 240 55 -229 minecraft:water[level=0]
fill 239 55 -230 240 55 -230 minecraft:water[level=0]
fill 238 55 -231 239 55 -231 minecraft:water[level=0]
fill 238 55 -232 239 55 -232 minecraft:water[level=0]
fill 237 55 -233 238 55 -233 minecraft:water[level=0]
fill 237 55 -234 238 55 -234 minecraft:water[level=0]
fill 236 55 -235 237 55 -235 minecraft:water[level=0]
fill 236 55 -236 237 55 -236 minecraft:water[level=0]
fill 236 55 -237 237 55 -237 minecraft:water[level=0]
setblock 236 55 -238 minecraft:water[level=0]
setblock 236 55 -239 minecraft:water[level=0]
fill 200 54 -191 201 54 -191 minecraft:air
setblock 200 54 -192 minecraft:air
setblock 212 54 -198 minecraft:water[level=0]
fill 211 54 -199 213 54 -199 minecraft:water[level=0]
fill 212 54 -200 213 54 -200 minecraft:water[level=0]
fill 212 54 -201 213 54 -201 minecraft:water[level=0]
fill 239 54 -228 240 54 -228 minecraft:water[level=0]
fill 239 54 -229 240 54 -229 minecraft:water[level=0]
fill 238 54 -230 240 54 -230 minecraft:water[level=0]
fill 238 54 -231 239 54 -231 minecraft:water[level=0]
fill 238 54 -232 239 54 -232 minecraft:water[level=0]
fill 237 54 -233 238 54 -233 minecraft:water[level=0]
fill 237 54 -234 238 54 -234 minecraft:water[level=0]
setblock 237 54 -235 minecraft:water[level=0]
setblock 237 54 -236 minecraft:water[level=0]
setblock 237 54 -237 minecraft:water[level=0]
setblock 236 54 -239 minecraft:water[level=0]
fill 200 53 -191 201 53 -191 minecraft:air
setblock 200 53 -192 minecraft:air
setblock 212 53 -198 minecraft:water[level=0]
fill 211 53 -199 212 53 -199 minecraft:water[level=0]
fill 211 53 -200 213 53 -200 minecraft:water[level=0]
fill 211 53 -201 212 53 -201 minecraft:water[level=0]
setblock 240 53 -226 minecraft:water[level=0]
setblock 240 53 -227 minecraft:water[level=0]
fill 239 53 -228 240 53 -228 minecraft:water[level=0]
fill 239 53 -229 240 53 -229 minecraft:water[level=0]
fill 238 53 -230 239 53 -230 minecraft:water[level=0]
fill 238 53 -231 239 53 -231 minecraft:water[level=0]
fill 238 53 -232 239 53 -232 minecraft:water[level=0]
setblock 238 53 -233 minecraft:water[level=0]
setblock 238 53 -234 minecraft:water[level=0]
setblock 237 53 -237 minecraft:water[level=0]
fill 200 52 -191 201 52 -191 minecraft:air
setblock 200 52 -192 minecraft:air
fill 210 52 -199 212 52 -199 minecraft:water[level=0]
fill 211 52 -200 212 52 -200 minecraft:water[level=0]
fill 211 52 -201 212 52 -201 minecraft:water[level=0]
setblock 211 52 -202 minecraft:water[level=0]
fill 240 52 -226 241 52 -226 minecraft:water[level=0]
fill 240 52 -227 241 52 -227 minecraft:water[level=0]
fill 239 52 -228 240 52 -228 minecraft:water[level=0]
fill 239 52 -229 240 52 -229 minecraft:water[level=0]
fill 238 52 -230 239 52 -230 minecraft:water[level=0]
fill 238 52 -231 239 52 -231 minecraft:water[level=0]
setblock 238 52 -232 minecraft:water[level=0]
setblock 238 52 -233 minecraft:water[level=0]
setblock 238 52 -234 minecraft:water[level=0]
setblock 200 51 -191 minecraft:air
fill 209 51 -199 212 51 -199 minecraft:water[level=0]
fill 210 51 -200 212 51 -200 minecraft:water[level=0]
fill 210 51 -201 211 51 -201 minecraft:water[level=0]
setblock 211 51 -202 minecraft:water[level=0]
setblock 241 51 -224 minecraft:water[level=0]
setblock 241 51 -225 minecraft:water[level=0]
fill 240 51 -226 241 51 -226 minecraft:water[level=0]
fill 239 51 -227 241 51 -227 minecraft:water[level=0]
fill 239 51 -228 240 51 -228 minecraft:water[level=0]
fill 239 51 -229 240 51 -229 minecraft:water[level=0]
fill 238 51 -230 239 51 -230 minecraft:water[level=0]
fill 238 51 -231 239 51 -231 minecraft:water[level=0]
setblock 238 51 -232 minecraft:water[level=0]
fill 210 50 -199 211 50 -199 minecraft:water[level=0]
fill 210 50 -200 212 50 -200 minecraft:water[level=0]
fill 210 50 -201 211 50 -201 minecraft:water[level=0]
fill 210 50 -202 211 50 -202 minecraft:water[level=0]
setblock 210 50 -203 minecraft:water[level=0]
setblock 242 50 -223 minecraft:water[level=0]
fill 241 50 -224 242 50 -224 minecraft:water[level=0]
fill 240 50 -225 242 50 -225 minecraft:water[level=0]
fill 240 50 -226 241 50 -226 minecraft:water[level=0]
fill 239 50 -227 241 50 -227 minecraft:water[level=0]
fill 239 50 -228 240 50 -228 minecraft:water[level=0]
fill 238 50 -229 239 50 -229 minecraft:water[level=0]
fill 238 50 -230 239 50 -230 minecraft:water[level=0]
fill 238 50 -231 239 50 -231 minecraft:water[level=0]
setblock 208 49 -199 minecraft:air
setblock 210 49 -199 minecraft:water[level=0]
fill 210 49 -200 211 49 -200 minecraft:water[level=0]
fill 210 49 -201 211 49 -201 minecraft:water[level=0]
setblock 210 49 -202 minecraft:water[level=0]
setblock 210 49 -203 minecraft:water[level=0]
setblock 206 49 -211 minecraft:water[level=0]
fill 204 49 -212 205 49 -212 minecraft:water[level=0]
fill 202 49 -213 204 49 -213 minecraft:water[level=0]
fill 200 49 -214 202 49 -214 minecraft:water[level=0]
setblock 243 49 -221 minecraft:water[level=0]
fill 242 49 -222 243 49 -222 minecraft:water[level=0]
fill 242 49 -223 243 49 -223 minecraft:water[level=0]
fill 241 49 -224 242 49 -224 minecraft:water[level=0]
fill 240 49 -225 242 49 -225 minecraft:water[level=0]
fill 240 49 -226 241 49 -226 minecraft:water[level=0]
fill 239 49 -227 240 49 -227 minecraft:water[level=0]
fill 239 49 -228 240 49 -228 minecraft:water[level=0]
fill 238 49 -229 239 49 -229 minecraft:water[level=0]
fill 238 49 -230 239 49 -230 minecraft:water[level=0]
fill 238 49 -231 239 49 -231 minecraft:water[level=0]
setblock 260 49 -250 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 260 49 -251 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 200 48 -191 minecraft:air
fill 206 48 -191 226 48 -191 minecraft:air
setblock 231 48 -191 minecraft:water[level=0]
fill 207 48 -192 224 48 -192 minecraft:air
fill 228 48 -192 230 48 -192 minecraft:water[level=0]
fill 208 48 -193 222 48 -193 minecraft:air
fill 226 48 -193 229 48 -193 minecraft:water[level=0]
fill 209 48 -194 221 48 -194 minecraft:air
fill 224 48 -194 228 48 -194 minecraft:water[level=0]
fill 209 48 -195 218 48 -195 minecraft:air
fill 223 48 -195 228 48 -195 minecraft:water[level=0]
fill 210 48 -196 214 48 -196 minecraft:air
fill 223 48 -196 227 48 -196 minecraft:water[level=0]
setblock 209 48 -197 minecraft:air
fill 218 48 -197 226 48 -197 minecraft:water[level=0]
setblock 209 48 -198 minecraft:air
fill 214 48 -198 225 48 -198 minecraft:water[level=0]
fill 208 48 -199 209 48 -199 minecraft:air
fill 215 48 -199 224 48 -199 minecraft:water[level=0]
fill 208 48 -200 209 48 -200 minecraft:air
setblock 211 48 -200 minecraft:water[level=0]
setblock 208 48 -201 minecraft:air
setblock 211 48 -201 minecraft:water[level=0]
setblock 208 48 -207 minecraft:air
setblock 208 48 -208 minecraft:air
setblock 207 48 -209 minecraft:air
setblock 207 48 -211 minecraft:water[level=0]
fill 205 48 -212 206 48 -212 minecraft:water[level=0]
fill 203 48 -213 204 48 -213 minecraft:water[level=0]
setblock 202 48 -214 minecraft:water[level=0]
setblock 244 48 -220 minecraft:water[level=0]
fill 243 48 -221 244 48 -221 minecraft:water[level=0]
fill 242 48 -222 244 48 -222 minecraft:water[level=0]
fill 241 48 -223 243 48 -223 minecraft:water[level=0]
fill 241 48 -224 242 48 -224 minecraft:water[level=0]
fill 240 48 -225 241 48 -225 minecraft:water[level=0]
fill 240 48 -226 241 48 -226 minecraft:water[level=0]
fill 239 48 -227 240 48 -227 minecraft:water[level=0]
fill 239 48 -228 240 48 -228 minecraft:water[level=0]
fill 238 48 -229 239 48 -229 minecraft:water[level=0]
fill 238 48 -230 239 48 -230 minecraft:water[level=0]
fill 238 48 -231 239 48 -231 minecraft:water[level=0]
setblock 261 48 -250 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 261 48 -251 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 200 47 -191 201 47 -191 minecraft:air
fill 205 47 -191 225 47 -191 minecraft:air
setblock 230 47 -191 minecraft:water[level=0]
setblock 200 47 -192 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=false,waterlogged=false,west=false]
fill 206 47 -192 223 47 -192 minecraft:air
setblock 227 47 -192 minecraft:water[level=0]
fill 228 47 -192 229 47 -192 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=true,west=false]
fill 207 47 -193 221 47 -193 minecraft:air
fill 225 47 -193 228 47 -193 minecraft:water[level=0]
fill 208 47 -194 221 47 -194 minecraft:air
fill 223 47 -194 228 47 -194 minecraft:water[level=0]
fill 209 47 -195 218 47 -195 minecraft:air
fill 222 47 -195 227 47 -195 minecraft:water[level=0]
fill 210 47 -196 214 47 -196 minecraft:air
fill 222 47 -196 226 47 -196 minecraft:water[level=0]
setblock 208 47 -197 minecraft:air
fill 222 47 -197 225 47 -197 minecraft:water[level=0]
fill 208 47 -198 209 47 -198 minecraft:air
fill 223 47 -198 224 47 -198 minecraft:water[level=0]
fill 208 47 -199 209 47 -199 minecraft:air
fill 208 47 -200 209 47 -200 minecraft:air
fill 208 47 -201 209 47 -201 minecraft:air
fill 208 47 -202 209 47 -202 minecraft:air
setblock 209 47 -203 minecraft:air
setblock 209 47 -204 minecraft:air
setblock 209 47 -205 minecraft:air
fill 208 47 -206 209 47 -206 minecraft:air
fill 208 47 -207 209 47 -207 minecraft:air
fill 208 47 -208 209 47 -208 minecraft:air
fill 206 47 -209 208 47 -209 minecraft:air
fill 205 47 -210 207 47 -210 minecraft:air
fill 204 47 -211 205 47 -211 minecraft:air
fill 202 47 -212 203 47 -212 minecraft:air
fill 200 47 -213 201 47 -213 minecraft:air
fill 256 47 -218 257 47 -218 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 256 47 -219 257 47 -219 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 244 47 -220 minecraft:water[level=0]
fill 243 47 -221 244 47 -221 minecraft:water[level=0]
fill 242 47 -222 243 47 -222 minecraft:water[level=0]
fill 241 47 -223 242 47 -223 minecraft:water[level=0]
fill 240 47 -224 242 47 -224 minecraft:water[level=0]
fill 240 47 -225 241 47 -225 minecraft:water[level=0]
fill 239 47 -226 240 47 -226 minecraft:water[level=0]
fill 239 47 -227 240 47 -227 minecraft:water[level=0]
fill 238 47 -228 239 47 -228 minecraft:water[level=0]
fill 238 47 -229 239 47 -229 minecraft:water[level=0]
fill 238 47 -230 239 47 -230 minecraft:water[level=0]
fill 200 46 -191 224 46 -191 minecraft:air
fill 229 46 -191 230 46 -191 minecraft:water[level=0]
fill 200 46 -192 203 46 -192 minecraft:air
fill 205 46 -192 222 46 -192 minecraft:air
fill 226 46 -192 229 46 -192 minecraft:water[level=0]
fill 206 46 -193 221 46 -193 minecraft:air
fill 224 46 -193 228 46 -193 minecraft:water[level=0]
fill 207 46 -194 220 46 -194 minecraft:air
fill 223 46 -194 227 46 -194 minecraft:water[level=0]
fill 208 46 -195 215 46 -195 minecraft:air
setblock 219 46 -195 minecraft:air
fill 223 46 -195 226 46 -195 minecraft:water[level=0]
fill 209 46 -196 212 46 -196 minecraft:air
fill 219 46 -196 221 46 -196 minecraft:air
fill 223 46 -196 225 46 -196 minecraft:water[level=0]
setblock 208 46 -197 minecraft:air
setblock 211 46 -197 minecraft:air
fill 217 46 -197 221 46 -197 minecraft:air
fill 223 46 -197 224 46 -197 minecraft:water[level=0]
fill 208 46 -198 209 46 -198 minecraft:air
fill 216 46 -198 221 46 -198 minecraft:air
fill 207 46 -199 210 46 -199 minecraft:air
fill 215 46 -199 217 46 -199 minecraft:air
fill 208 46 -200 210 46 -200 minecraft:air
fill 208 46 -201 209 46 -201 minecraft:air
fill 208 46 -202 209 46 -202 minecraft:air
setblock 209 46 -203 minecraft:air
fill 209 46 -204 210 46 -204 minecraft:air
fill 208 46 -205 210 46 -205 minecraft:air
fill 208 46 -206 210 46 -206 minecraft:air
fill 208 46 -207 209 46 -207 minecraft:air
fill 207 46 -208 209 46 -208 minecraft:air
fill 206 46 -209 209 46 -209 minecraft:air
fill 205 46 -210 208 46 -210 minecraft:air
fill 203 46 -211 206 46 -211 minecraft:air
fill 202 46 -212 204 46 -212 minecraft:air
fill 200 46 -213 202 46 -213 minecraft:air
setblock 201 46 -214 minecraft:air
fill 256 46 -218 257 46 -218 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 244 46 -219 minecraft:water[level=0]
fill 256 46 -219 257 46 -219 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 243 46 -220 245 46 -220 minecraft:water[level=0]
fill 242 46 -221 244 46 -221 minecraft:water[level=0]
fill 241 46 -222 243 46 -222 minecraft:water[level=0]
fill 241 46 -223 242 46 -223 minecraft:water[level=0]
fill 240 46 -224 241 46 -224 minecraft:water[level=0]
fill 239 46 -225 241 46 -225 minecraft:water[level=0]
fill 239 46 -226 240 46 -226 minecraft:water[level=0]
fill 239 46 -227 240 46 -227 minecraft:water[level=0]
fill 238 46 -228 239 46 -228 minecraft:water[level=0]
fill 238 46 -229 239 46 -229 minecraft:water[level=0]
setblock 238 46 -230 minecraft:water[level=0]
setblock 200 46 -231 oritech:still_oil_block[level=0]
fill 200 45 -191 223 45 -191 minecraft:air
fill 200 45 -192 222 45 -192 minecraft:air
fill 226 45 -192 228 45 -192 minecraft:water[level=0]
fill 205 45 -193 221 45 -193 minecraft:air
fill 223 45 -193 227 45 -193 minecraft:water[level=0]
fill 206 45 -194 220 45 -194 minecraft:air
fill 223 45 -194 226 45 -194 minecraft:water[level=0]
fill 207 45 -195 221 45 -195 minecraft:air
fill 223 45 -195 225 45 -195 minecraft:water[level=0]
setblock 207 45 -196 minecraft:air
fill 209 45 -196 221 45 -196 minecraft:air
setblock 224 45 -196 minecraft:water[level=0]
fill 207 45 -197 208 45 -197 minecraft:air
fill 210 45 -197 221 45 -197 minecraft:air
setblock 224 45 -197 minecraft:water[level=0]
fill 207 45 -198 209 45 -198 minecraft:air
fill 212 45 -198 219 45 -198 minecraft:air
fill 207 45 -199 209 45 -199 minecraft:air
fill 215 45 -199 216 45 -199 minecraft:air
fill 207 45 -200 210 45 -200 minecraft:air
fill 208 45 -201 210 45 -201 minecraft:air
fill 208 45 -202 210 45 -202 minecraft:air
fill 208 45 -203 210 45 -203 minecraft:air
fill 209 45 -204 210 45 -204 minecraft:air
fill 208 45 -205 210 45 -205 minecraft:air
fill 208 45 -206 210 45 -206 minecraft:air
fill 207 45 -207 210 45 -207 minecraft:air
fill 207 45 -208 210 45 -208 minecraft:air
fill 206 45 -209 209 45 -209 minecraft:air
fill 205 45 -210 208 45 -210 minecraft:air
fill 203 45 -211 207 45 -211 minecraft:air
fill 201 45 -212 205 45 -212 minecraft:air
fill 200 45 -213 203 45 -213 minecraft:air
fill 200 45 -214 201 45 -214 minecraft:air
setblock 245 45 -218 minecraft:water[level=0]
fill 244 45 -219 245 45 -219 minecraft:water[level=0]
fill 243 45 -220 245 45 -220 minecraft:water[level=0]
fill 242 45 -221 244 45 -221 minecraft:water[level=0]
fill 241 45 -222 243 45 -222 minecraft:water[level=0]
fill 240 45 -223 242 45 -223 minecraft:water[level=0]
fill 240 45 -224 241 45 -224 minecraft:water[level=0]
fill 239 45 -225 240 45 -225 minecraft:water[level=0]
fill 239 45 -226 240 45 -226 minecraft:water[level=0]
setblock 200 45 -227 oritech:still_oil_block[level=0]
fill 238 45 -227 239 45 -227 minecraft:water[level=0]
fill 200 45 -228 201 45 -228 oritech:still_oil_block[level=0]
fill 238 45 -228 239 45 -228 minecraft:water[level=0]
setblock 200 45 -229 oritech:still_oil_block[level=0]
setblock 238 45 -229 minecraft:water[level=0]
setblock 200 45 -230 oritech:still_oil_block[level=0]
setblock 200 45 -231 oritech:still_oil_block[level=0]
setblock 200 45 -232 oritech:still_oil_block[level=0]
forceload remove 200 -254 263 -191
tellraw @a {"text":"Campus zurueck a25 fertig.","color":"green"}
