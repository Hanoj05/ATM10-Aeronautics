setblock 321 86 -231 minecraft:white_concrete
setblock 319 86 -238 minecraft:white_concrete
setblock 317 86 -245 minecraft:white_concrete
setblock 313 86 -252 minecraft:white_concrete
setblock 311 85 -195 minecraft:white_concrete
setblock 313 85 -198 minecraft:white_concrete
setblock 315 85 -203 minecraft:white_concrete
setblock 316 85 -206 minecraft:white_concrete
setblock 317 85 -209 minecraft:white_concrete
setblock 317 85 -212 minecraft:white_concrete
setblock 318 85 -215 minecraft:white_concrete
setblock 318 85 -218 minecraft:white_concrete
setblock 318 85 -221 minecraft:white_concrete
setblock 318 85 -222 minecraft:white_concrete
setblock 318 85 -225 minecraft:white_concrete
setblock 318 85 -226 minecraft:white_concrete
setblock 316 85 -235 minecraft:white_concrete
setblock 316 85 -236 minecraft:white_concrete
setblock 315 85 -240 minecraft:white_concrete
setblock 314 85 -242 minecraft:white_concrete
setblock 313 85 -244 minecraft:white_concrete
setblock 312 85 -246 minecraft:white_concrete
setblock 311 85 -249 minecraft:white_concrete
setblock 310 85 -250 minecraft:white_concrete
setblock 284 68 -197 minecraft:air
setblock 300 68 -241 minecraft:air
setblock 309 67 -237 minecraft:air
setblock 308 67 -240 minecraft:air
setblock 292 67 -242 minecraft:air
setblock 306 67 -246 minecraft:air
setblock 266 66 -205 minecraft:air
setblock 278 66 -215 minecraft:air
fill 264 65 -209 267 65 -209 minecraft:air
fill 264 65 -210 269 65 -210 minecraft:air
fill 264 65 -211 271 65 -211 minecraft:air
fill 264 65 -212 272 65 -212 minecraft:air
fill 264 65 -213 273 65 -213 minecraft:air
fill 264 65 -214 273 65 -214 minecraft:air
fill 264 65 -215 274 65 -215 minecraft:air
fill 264 65 -216 274 65 -216 minecraft:air
fill 264 65 -217 275 65 -217 minecraft:air
fill 264 65 -218 275 65 -218 minecraft:air
fill 264 65 -219 275 65 -219 minecraft:air
fill 264 65 -220 275 65 -220 minecraft:air
fill 264 65 -221 275 65 -221 minecraft:air
fill 264 65 -222 275 65 -222 minecraft:air
fill 264 65 -223 275 65 -223 minecraft:air
fill 264 65 -224 275 65 -224 minecraft:air
fill 264 65 -225 275 65 -225 minecraft:air
fill 264 65 -226 274 65 -226 minecraft:air
fill 264 65 -227 274 65 -227 minecraft:air
fill 264 65 -228 273 65 -228 minecraft:air
fill 264 65 -229 273 65 -229 minecraft:air
fill 264 65 -230 272 65 -230 minecraft:air
fill 264 65 -231 271 65 -231 minecraft:air
fill 264 65 -232 269 65 -232 minecraft:air
fill 264 65 -233 267 65 -233 minecraft:air
fill 264 64 -191 267 64 -191 minecraft:air
fill 269 64 -191 271 64 -191 minecraft:air
fill 273 64 -191 277 64 -191 minecraft:air
setblock 278 64 -191 minecraft:dandelion
fill 279 64 -191 281 64 -191 minecraft:air
setblock 282 64 -191 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=2]
setblock 283 64 -191 regions_unexplored:red_maple_leaf_litter[facing=north,flower_amount=3]
setblock 284 64 -191 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=2]
setblock 285 64 -191 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=1]
fill 286 64 -191 287 64 -191 minecraft:air
setblock 288 64 -191 minecraft:dandelion
setblock 289 64 -191 regions_unexplored:grass_sprouts
fill 290 64 -191 301 64 -191 minecraft:air
fill 316 64 -191 320 64 -191 minecraft:air
setblock 321 64 -191 regions_unexplored:grass_sprouts
fill 322 64 -191 327 64 -191 minecraft:air
fill 264 64 -192 277 64 -192 minecraft:air
setblock 278 64 -192 minecraft:short_grass
setblock 279 64 -192 minecraft:air
setblock 280 64 -192 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=3]
setblock 281 64 -192 regions_unexplored:grass_sprouts
fill 282 64 -192 285 64 -192 minecraft:air
setblock 286 64 -192 regions_unexplored:grass_sprouts
setblock 287 64 -192 minecraft:air
setblock 288 64 -192 minecraft:short_grass
fill 289 64 -192 300 64 -192 minecraft:air
fill 316 64 -192 323 64 -192 minecraft:air
setblock 324 64 -192 regions_unexplored:grass_sprouts
fill 325 64 -192 327 64 -192 minecraft:air
fill 264 64 -193 271 64 -193 minecraft:air
setblock 272 64 -193 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 273 64 -193 minecraft:air
setblock 274 64 -193 regions_unexplored:grass_sprouts
fill 275 64 -193 279 64 -193 minecraft:air
setblock 280 64 -193 regions_unexplored:red_maple_leaf_litter[facing=north,flower_amount=3]
setblock 281 64 -193 minecraft:air
setblock 282 64 -193 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=1]
fill 283 64 -193 300 64 -193 minecraft:air
fill 316 64 -193 327 64 -193 minecraft:air
fill 264 64 -194 269 64 -194 minecraft:air
setblock 270 64 -194 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=3]
setblock 271 64 -194 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
setblock 272 64 -194 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
fill 273 64 -194 280 64 -194 minecraft:air
setblock 281 64 -194 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=3]
setblock 282 64 -194 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=3]
setblock 284 64 -194 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=3]
setblock 285 64 -194 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=1]
setblock 286 64 -194 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=2]
fill 287 64 -194 300 64 -194 minecraft:air
fill 316 64 -194 327 64 -194 minecraft:air
fill 264 64 -195 281 64 -195 minecraft:air
setblock 282 64 -195 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=1]
fill 283 64 -195 300 64 -195 minecraft:air
setblock 316 64 -195 minecraft:air
setblock 317 64 -195 regions_unexplored:grass_sprouts
fill 318 64 -195 321 64 -195 minecraft:air
setblock 322 64 -195 minecraft:short_grass
fill 323 64 -195 324 64 -195 minecraft:air
setblock 325 64 -195 minecraft:short_grass
fill 326 64 -195 327 64 -195 minecraft:air
setblock 264 64 -196 minecraft:air
fill 266 64 -196 273 64 -196 minecraft:air
setblock 274 64 -196 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 275 64 -196 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
fill 276 64 -196 284 64 -196 minecraft:air
setblock 285 64 -196 regions_unexplored:grass_sprouts
fill 286 64 -196 299 64 -196 minecraft:air
fill 315 64 -196 327 64 -196 minecraft:air
fill 264 64 -197 273 64 -197 minecraft:air
setblock 274 64 -197 minecraft:dandelion
fill 275 64 -197 276 64 -197 minecraft:air
setblock 277 64 -197 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
fill 278 64 -197 279 64 -197 minecraft:air
setblock 280 64 -197 minecraft:short_grass
fill 281 64 -197 284 64 -197 minecraft:air
setblock 285 64 -197 regions_unexplored:grass_sprouts
fill 286 64 -197 287 64 -197 minecraft:air
setblock 288 64 -197 regions_unexplored:grass_sprouts
fill 289 64 -197 298 64 -197 minecraft:air
fill 316 64 -197 321 64 -197 minecraft:air
setblock 322 64 -197 minecraft:short_grass
fill 323 64 -197 327 64 -197 minecraft:air
fill 264 64 -198 276 64 -198 minecraft:air
setblock 277 64 -198 minecraft:short_grass
setblock 278 64 -198 minecraft:air
setblock 279 64 -198 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
fill 280 64 -198 287 64 -198 minecraft:air
fill 288 64 -198 289 64 -198 minecraft:short_grass
setblock 290 64 -198 regions_unexplored:grass_sprouts
fill 291 64 -198 297 64 -198 minecraft:air
fill 316 64 -198 327 64 -198 minecraft:air
fill 264 64 -199 277 64 -199 minecraft:air
fill 278 64 -199 279 64 -199 minecraft:short_grass
setblock 280 64 -199 regions_unexplored:grass_sprouts
setblock 281 64 -199 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
setblock 282 64 -199 regions_unexplored:grass_sprouts
setblock 283 64 -199 minecraft:air
fill 289 64 -199 290 64 -199 minecraft:air
setblock 291 64 -199 ars_nouveau:light_block[level=14,waterlogged=false]
fill 292 64 -199 293 64 -199 minecraft:air
setblock 319 64 -199 minecraft:air
setblock 320 64 -199 regions_unexplored:grass_sprouts
fill 321 64 -199 327 64 -199 minecraft:air
setblock 264 64 -200 ars_nouveau:light_block[level=14,waterlogged=false]
fill 265 64 -200 278 64 -200 minecraft:air
fill 320 64 -200 326 64 -200 minecraft:air
fill 264 64 -201 275 64 -201 minecraft:air
setblock 276 64 -201 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
setblock 277 64 -201 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 278 64 -201 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=2]
setblock 279 64 -201 minecraft:air
fill 320 64 -201 326 64 -201 minecraft:air
fill 264 64 -202 277 64 -202 minecraft:air
fill 320 64 -202 326 64 -202 minecraft:air
fill 264 64 -203 265 64 -203 minecraft:air
setblock 266 64 -203 regions_unexplored:grass_sprouts
fill 267 64 -203 275 64 -203 minecraft:air
fill 319 64 -203 326 64 -203 minecraft:air
fill 264 64 -204 265 64 -204 minecraft:air
setblock 266 64 -204 regions_unexplored:grass_sprouts
fill 267 64 -204 274 64 -204 minecraft:air
fill 320 64 -204 326 64 -204 minecraft:air
setblock 264 64 -205 minecraft:short_grass
fill 265 64 -205 273 64 -205 minecraft:air
fill 319 64 -205 325 64 -205 minecraft:air
fill 264 64 -206 270 64 -206 minecraft:air
fill 319 64 -206 325 64 -206 minecraft:air
fill 319 64 -207 324 64 -207 minecraft:air
fill 319 64 -208 324 64 -208 minecraft:air
setblock 320 64 -209 minecraft:air
setblock 327 64 -223 minecraft:air
fill 326 64 -224 327 64 -224 minecraft:air
fill 325 64 -225 327 64 -225 minecraft:air
fill 325 64 -226 327 64 -226 minecraft:air
fill 326 64 -227 327 64 -227 minecraft:air
setblock 327 64 -228 minecraft:air
setblock 264 64 -237 minecraft:air
fill 264 64 -238 265 64 -238 minecraft:air
fill 264 64 -239 266 64 -239 minecraft:air
fill 264 64 -240 267 64 -240 minecraft:air
fill 264 64 -241 267 64 -241 minecraft:air
fill 264 64 -242 267 64 -242 minecraft:air
fill 264 64 -243 267 64 -243 minecraft:air
fill 264 64 -244 266 64 -244 minecraft:air
setblock 268 64 -244 minecraft:air
fill 264 64 -245 267 64 -245 minecraft:air
fill 264 64 -246 267 64 -246 minecraft:air
setblock 264 64 -247 minecraft:air
setblock 265 64 -247 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 266 64 -247 minecraft:air
fill 264 64 -248 266 64 -248 minecraft:air
fill 264 64 -249 265 64 -249 minecraft:air
fill 264 64 -250 265 64 -250 minecraft:air
setblock 264 64 -251 minecraft:air
setblock 264 64 -252 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
fill 264 64 -254 265 64 -254 minecraft:air
fill 264 63 -191 267 63 -191 minecraft:air
fill 265 63 -192 266 63 -192 minecraft:air
setblock 267 63 -192 minecraft:lily_of_the_valley
setblock 327 63 -192 minecraft:air
setblock 280 63 -195 minecraft:air
setblock 279 63 -196 minecraft:air
setblock 280 63 -196 minecraft:short_grass
fill 281 63 -196 283 63 -196 minecraft:air
setblock 281 63 -197 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=3]
fill 282 63 -197 284 63 -197 minecraft:air
setblock 324 63 -197 minecraft:air
fill 283 63 -198 284 63 -198 minecraft:air
fill 323 63 -198 325 63 -198 minecraft:air
fill 323 63 -199 324 63 -199 minecraft:air
setblock 269 63 -210 minecraft:air
setblock 268 63 -211 minecraft:air
setblock 327 63 -223 minecraft:air
fill 325 63 -224 327 63 -224 minecraft:air
fill 325 63 -225 327 63 -225 minecraft:air
fill 325 63 -226 327 63 -226 minecraft:air
fill 325 63 -227 327 63 -227 minecraft:air
fill 326 63 -228 327 63 -228 minecraft:air
fill 264 63 -248 265 63 -248 minecraft:air
fill 264 63 -249 265 63 -249 minecraft:air
fill 264 63 -250 265 63 -250 minecraft:air
setblock 264 63 -251 minecraft:air
fill 264 62 -191 265 62 -191 minecraft:air
setblock 282 62 -195 minecraft:air
fill 281 62 -196 284 62 -196 minecraft:air
fill 282 62 -197 285 62 -197 minecraft:air
setblock 324 62 -197 minecraft:water[level=0]
fill 284 62 -198 285 62 -198 minecraft:air
fill 323 62 -198 325 62 -198 minecraft:water[level=0]
fill 323 62 -199 324 62 -199 minecraft:water[level=0]
setblock 327 62 -223 minecraft:water[level=0]
fill 326 62 -224 327 62 -224 minecraft:water[level=0]
fill 325 62 -225 327 62 -225 minecraft:water[level=0]
fill 325 62 -226 327 62 -226 minecraft:water[level=0]
fill 325 62 -227 327 62 -227 minecraft:water[level=0]
fill 326 62 -228 327 62 -228 minecraft:water[level=0]
fill 264 62 -249 265 62 -249 minecraft:water[level=0]
fill 264 62 -250 266 62 -250 minecraft:water[level=0]
fill 264 62 -251 266 62 -251 minecraft:water[level=0]
fill 283 61 -196 286 61 -196 minecraft:air
fill 283 61 -197 286 61 -197 minecraft:air
setblock 324 61 -197 minecraft:water[level=0]
fill 285 61 -198 286 61 -198 minecraft:air
fill 323 61 -198 325 61 -198 minecraft:water[level=0]
fill 323 61 -199 324 61 -199 minecraft:water[level=0]
setblock 327 61 -223 minecraft:water[level=0]
fill 326 61 -224 327 61 -224 minecraft:water[level=0]
fill 325 61 -225 327 61 -225 minecraft:water[level=0]
fill 325 61 -226 327 61 -226 minecraft:water[level=0]
fill 325 61 -227 327 61 -227 minecraft:water[level=0]
fill 326 61 -228 327 61 -228 minecraft:water[level=0]
setblock 266 61 -249 minecraft:water[level=0]
fill 264 61 -250 266 61 -250 minecraft:water[level=0]
fill 265 61 -251 266 61 -251 minecraft:water[level=0]
fill 265 61 -252 266 61 -252 minecraft:water[level=0]
fill 284 60 -196 287 60 -196 minecraft:air
fill 284 60 -197 287 60 -197 minecraft:air
setblock 324 60 -197 minecraft:water[level=0]
setblock 286 60 -198 minecraft:air
fill 323 60 -198 325 60 -198 minecraft:water[level=0]
fill 323 60 -199 324 60 -199 minecraft:water[level=0]
setblock 327 60 -223 minecraft:water[level=0]
fill 326 60 -224 327 60 -224 minecraft:water[level=0]
fill 325 60 -225 327 60 -225 minecraft:water[level=0]
fill 325 60 -226 327 60 -226 minecraft:water[level=0]
fill 325 60 -227 327 60 -227 minecraft:water[level=0]
fill 326 60 -228 327 60 -228 minecraft:water[level=0]
setblock 266 60 -250 minecraft:water[level=0]
fill 265 60 -251 266 60 -251 minecraft:water[level=0]
fill 265 60 -252 267 60 -252 minecraft:water[level=0]
fill 265 60 -253 267 60 -253 minecraft:water[level=0]
setblock 286 59 -195 minecraft:air
fill 285 59 -196 288 59 -196 minecraft:air
fill 285 59 -197 288 59 -197 minecraft:air
fill 324 59 -197 325 59 -197 minecraft:water[level=0]
setblock 287 59 -198 minecraft:air
fill 324 59 -198 325 59 -198 minecraft:water[level=0]
fill 323 59 -199 325 59 -199 minecraft:water[level=0]
setblock 327 59 -223 minecraft:water[level=0]
fill 326 59 -224 327 59 -224 minecraft:water[level=0]
setblock 327 59 -225 minecraft:water[level=0]
setblock 327 59 -226 minecraft:water[level=0]
setblock 327 59 -227 minecraft:water[level=0]
fill 266 59 -251 267 59 -251 minecraft:water[level=0]
fill 265 59 -252 267 59 -252 minecraft:water[level=0]
fill 265 59 -253 267 59 -253 minecraft:water[level=0]
fill 265 59 -254 267 59 -254 minecraft:water[level=0]
fill 287 58 -195 289 58 -195 minecraft:air
fill 286 58 -196 287 58 -196 minecraft:air
setblock 289 58 -196 minecraft:air
fill 286 58 -197 288 58 -197 minecraft:air
fill 324 58 -197 325 58 -197 minecraft:water[level=0]
fill 324 58 -198 325 58 -198 minecraft:water[level=0]
fill 323 58 -199 325 58 -199 minecraft:water[level=0]
fill 266 58 -252 267 58 -252 minecraft:water[level=0]
fill 266 58 -253 267 58 -253 minecraft:water[level=0]
fill 266 58 -254 267 58 -254 minecraft:water[level=0]
fill 287 57 -195 290 57 -195 minecraft:air
setblock 287 57 -196 minecraft:air
fill 289 57 -196 290 57 -196 minecraft:air
setblock 288 57 -197 minecraft:air
fill 324 57 -197 325 57 -197 minecraft:water[level=0]
fill 324 57 -198 325 57 -198 minecraft:water[level=0]
fill 323 57 -199 325 57 -199 minecraft:water[level=0]
setblock 325 57 -224 minecraft:air
setblock 325 57 -225 minecraft:air
setblock 325 57 -226 minecraft:air
fill 326 57 -228 327 57 -228 minecraft:air
fill 266 57 -253 268 57 -253 minecraft:water[level=0]
fill 266 57 -254 268 57 -254 minecraft:water[level=0]
fill 289 56 -194 291 56 -194 minecraft:air
fill 288 56 -195 291 56 -195 minecraft:air
fill 289 56 -196 290 56 -196 minecraft:air
setblock 290 56 -197 minecraft:air
fill 324 56 -197 325 56 -197 minecraft:water[level=0]
fill 324 56 -198 325 56 -198 minecraft:water[level=0]
fill 324 56 -199 325 56 -199 minecraft:water[level=0]
setblock 325 56 -200 minecraft:water[level=0]
fill 326 56 -223 327 56 -223 minecraft:air
fill 325 56 -224 327 56 -224 minecraft:air
fill 325 56 -225 327 56 -225 minecraft:air
fill 325 56 -226 327 56 -226 minecraft:air
fill 325 56 -227 327 56 -227 minecraft:air
fill 326 56 -228 327 56 -228 minecraft:air
fill 319 56 -236 320 56 -236 minecraft:air
fill 318 56 -237 320 56 -237 minecraft:air
fill 318 56 -238 320 56 -238 minecraft:air
fill 266 56 -254 268 56 -254 minecraft:water[level=0]
fill 289 55 -193 290 55 -193 minecraft:air
fill 289 55 -194 291 55 -194 minecraft:air
fill 288 55 -195 291 55 -195 minecraft:air
fill 289 55 -196 290 55 -196 minecraft:air
setblock 324 55 -197 minecraft:water[level=0]
fill 324 55 -198 325 55 -198 minecraft:water[level=0]
fill 324 55 -199 325 55 -199 minecraft:water[level=0]
fill 324 55 -200 325 55 -200 minecraft:water[level=0]
fill 326 55 -222 327 55 -222 minecraft:air
fill 325 55 -223 327 55 -223 minecraft:air
fill 324 55 -224 327 55 -224 minecraft:air
fill 283 55 -225 284 55 -225 minecraft:air
fill 324 55 -225 327 55 -225 minecraft:air
setblock 283 55 -226 minecraft:air
fill 325 55 -226 327 55 -226 minecraft:air
fill 285 55 -227 286 55 -227 minecraft:water[level=0]
fill 325 55 -227 327 55 -227 minecraft:air
fill 284 55 -228 287 55 -228 minecraft:water[level=0]
fill 285 55 -229 287 55 -229 minecraft:water[level=0]
setblock 286 55 -230 minecraft:water[level=0]
setblock 321 55 -233 minecraft:air
fill 320 55 -234 322 55 -234 minecraft:air
setblock 312 55 -235 minecraft:water[level=0]
fill 319 55 -235 322 55 -235 minecraft:air
fill 313 55 -236 314 55 -236 minecraft:water[level=0]
fill 318 55 -236 321 55 -236 minecraft:air
fill 313 55 -237 315 55 -237 minecraft:water[level=0]
fill 318 55 -237 321 55 -237 minecraft:air
fill 313 55 -238 315 55 -238 minecraft:water[level=0]
fill 318 55 -238 321 55 -238 minecraft:air
setblock 315 55 -239 minecraft:water[level=0]
fill 318 55 -239 320 55 -239 minecraft:air
fill 289 54 -193 291 54 -193 minecraft:air
fill 289 54 -194 291 54 -194 minecraft:air
fill 288 54 -195 291 54 -195 minecraft:air
setblock 325 54 -198 minecraft:water[level=0]
fill 325 54 -199 326 54 -199 minecraft:water[level=0]
fill 324 54 -200 325 54 -200 minecraft:water[level=0]
setblock 325 54 -201 minecraft:water[level=0]
fill 283 54 -222 284 54 -222 minecraft:air
fill 325 54 -222 327 54 -222 minecraft:air
fill 283 54 -223 284 54 -223 minecraft:air
fill 324 54 -223 327 54 -223 minecraft:air
fill 282 54 -224 284 54 -224 minecraft:air
fill 324 54 -224 327 54 -224 minecraft:air
fill 282 54 -225 284 54 -225 minecraft:air
fill 324 54 -225 327 54 -225 minecraft:air
setblock 283 54 -226 minecraft:air
fill 324 54 -226 327 54 -226 minecraft:air
fill 285 54 -227 286 54 -227 minecraft:water[level=0]
fill 325 54 -227 327 54 -227 minecraft:air
fill 284 54 -228 287 54 -228 minecraft:water[level=0]
fill 285 54 -229 287 54 -229 minecraft:water[level=0]
fill 285 54 -230 286 54 -230 minecraft:water[level=0]
fill 310 54 -233 312 54 -233 minecraft:water[level=0]
fill 320 54 -233 322 54 -233 minecraft:air
fill 310 54 -234 313 54 -234 minecraft:water[level=0]
fill 320 54 -234 323 54 -234 minecraft:air
fill 310 54 -235 314 54 -235 minecraft:water[level=0]
fill 319 54 -235 323 54 -235 minecraft:air
fill 310 54 -236 315 54 -236 minecraft:water[level=0]
fill 318 54 -236 322 54 -236 minecraft:air
fill 311 54 -237 315 54 -237 minecraft:water[level=0]
fill 318 54 -237 321 54 -237 minecraft:air
fill 312 54 -238 315 54 -238 minecraft:water[level=0]
fill 318 54 -238 319 54 -238 minecraft:air
setblock 320 54 -238 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=false,waterlogged=false,west=false]
setblock 321 54 -238 minecraft:air
fill 313 54 -239 315 54 -239 minecraft:water[level=0]
setblock 318 54 -239 minecraft:air
setblock 319 54 -239 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
setblock 316 54 -240 minecraft:water[level=0]
fill 290 53 -192 291 53 -192 minecraft:air
fill 289 53 -193 291 53 -193 minecraft:air
fill 289 53 -194 291 53 -194 minecraft:air
fill 289 53 -195 291 53 -195 minecraft:air
fill 325 53 -199 326 53 -199 minecraft:water[level=0]
fill 325 53 -200 326 53 -200 minecraft:water[level=0]
fill 325 53 -201 326 53 -201 minecraft:water[level=0]
fill 325 53 -202 326 53 -202 minecraft:water[level=0]
fill 283 53 -221 284 53 -221 minecraft:air
fill 282 53 -222 284 53 -222 minecraft:air
fill 325 53 -222 327 53 -222 minecraft:air
fill 282 53 -223 283 53 -223 minecraft:air
fill 324 53 -223 327 53 -223 minecraft:air
fill 282 53 -224 283 53 -224 minecraft:air
fill 324 53 -224 327 53 -224 minecraft:air
setblock 283 53 -225 minecraft:air
fill 324 53 -225 327 53 -225 minecraft:air
setblock 283 53 -226 minecraft:air
fill 324 53 -226 327 53 -226 minecraft:air
setblock 326 53 -227 minecraft:air
fill 310 53 -230 311 53 -230 minecraft:water[level=0]
fill 309 53 -231 312 53 -231 minecraft:water[level=0]
fill 309 53 -232 312 53 -232 minecraft:water[level=0]
fill 309 53 -233 313 53 -233 minecraft:water[level=0]
fill 321 53 -233 322 53 -233 minecraft:air
fill 309 53 -234 314 53 -234 minecraft:water[level=0]
fill 320 53 -234 323 53 -234 minecraft:air
fill 309 53 -235 314 53 -235 minecraft:water[level=0]
fill 320 53 -235 323 53 -235 minecraft:air
fill 310 53 -236 315 53 -236 minecraft:water[level=0]
fill 321 53 -236 322 53 -236 minecraft:air
fill 311 53 -237 315 53 -237 minecraft:water[level=0]
fill 312 53 -238 315 53 -238 minecraft:water[level=0]
fill 313 53 -239 315 53 -239 minecraft:water[level=0]
fill 290 52 -191 292 52 -191 minecraft:air
fill 290 52 -192 291 52 -192 minecraft:air
fill 289 52 -193 291 52 -193 minecraft:air
fill 289 52 -194 291 52 -194 minecraft:air
setblock 325 52 -199 minecraft:water[level=0]
fill 325 52 -200 326 52 -200 minecraft:water[level=0]
fill 325 52 -201 326 52 -201 minecraft:water[level=0]
fill 325 52 -202 326 52 -202 minecraft:water[level=0]
setblock 326 52 -203 minecraft:water[level=0]
setblock 283 52 -219 minecraft:air
fill 282 52 -220 283 52 -220 minecraft:air
fill 282 52 -221 283 52 -221 minecraft:air
fill 325 52 -221 326 52 -221 minecraft:air
fill 282 52 -222 283 52 -222 minecraft:air
fill 324 52 -222 327 52 -222 minecraft:air
fill 282 52 -223 283 52 -223 minecraft:air
fill 323 52 -223 327 52 -223 minecraft:air
fill 323 52 -224 327 52 -224 minecraft:air
fill 324 52 -225 327 52 -225 minecraft:air
fill 324 52 -226 327 52 -226 minecraft:air
fill 310 52 -229 312 52 -229 minecraft:water[level=0]
fill 309 52 -230 312 52 -230 minecraft:water[level=0]
fill 309 52 -231 313 52 -231 minecraft:water[level=0]
fill 308 52 -232 313 52 -232 minecraft:water[level=0]
fill 309 52 -233 313 52 -233 minecraft:water[level=0]
fill 309 52 -234 313 52 -234 minecraft:water[level=0]
fill 309 52 -235 313 52 -235 minecraft:water[level=0]
fill 310 52 -236 313 52 -236 minecraft:water[level=0]
setblock 312 52 -237 minecraft:water[level=0]
fill 288 52 -251 291 52 -251 minecraft:cave_air
fill 295 52 -251 296 52 -251 minecraft:cave_air
fill 287 52 -252 292 52 -252 minecraft:cave_air
fill 294 52 -252 297 52 -252 minecraft:cave_air
fill 289 52 -253 290 52 -253 minecraft:cave_air
fill 294 52 -253 297 52 -253 minecraft:cave_air
fill 291 52 -254 292 52 -254 minecraft:cave_air
fill 294 52 -254 297 52 -254 minecraft:cave_air
fill 290 51 -191 291 51 -191 minecraft:air
fill 290 51 -192 291 51 -192 minecraft:air
fill 289 51 -193 291 51 -193 minecraft:air
fill 290 51 -194 291 51 -194 minecraft:air
setblock 326 51 -200 minecraft:water[level=0]
fill 326 51 -201 327 51 -201 minecraft:water[level=0]
fill 326 51 -202 327 51 -202 minecraft:water[level=0]
fill 326 51 -203 327 51 -203 minecraft:water[level=0]
fill 326 51 -204 327 51 -204 minecraft:water[level=0]
setblock 327 51 -205 minecraft:water[level=0]
setblock 283 51 -217 minecraft:air
fill 282 51 -218 283 51 -218 minecraft:air
fill 282 51 -219 283 51 -219 minecraft:air
setblock 282 51 -220 minecraft:air
setblock 282 51 -221 minecraft:air
fill 324 51 -221 326 51 -221 minecraft:air
setblock 282 51 -222 minecraft:air
fill 323 51 -222 327 51 -222 minecraft:air
fill 323 51 -223 327 51 -223 minecraft:air
fill 323 51 -224 327 51 -224 minecraft:air
fill 323 51 -225 327 51 -225 minecraft:air
fill 325 51 -226 327 51 -226 minecraft:air
fill 311 51 -227 312 51 -227 minecraft:water[level=0]
fill 310 51 -228 313 51 -228 minecraft:water[level=0]
fill 309 51 -229 313 51 -229 minecraft:water[level=0]
fill 309 51 -230 313 51 -230 minecraft:water[level=0]
fill 309 51 -231 313 51 -231 minecraft:water[level=0]
fill 309 51 -232 313 51 -232 minecraft:water[level=0]
fill 309 51 -233 312 51 -233 minecraft:water[level=0]
fill 310 51 -234 311 51 -234 minecraft:water[level=0]
fill 295 51 -250 296 51 -250 minecraft:cave_air
fill 287 51 -251 292 51 -251 minecraft:cave_air
fill 294 51 -251 297 51 -251 minecraft:cave_air
fill 287 51 -252 292 51 -252 minecraft:cave_air
fill 294 51 -252 298 51 -252 minecraft:cave_air
fill 288 51 -253 298 51 -253 minecraft:cave_air
fill 289 51 -254 298 51 -254 minecraft:cave_air
fill 290 50 -191 291 50 -191 minecraft:air
fill 290 50 -192 291 50 -192 minecraft:air
fill 289 50 -193 291 50 -193 minecraft:air
setblock 326 50 -201 minecraft:water[level=0]
fill 326 50 -202 327 50 -202 minecraft:water[level=0]
fill 326 50 -203 327 50 -203 minecraft:water[level=0]
fill 326 50 -204 327 50 -204 minecraft:water[level=0]
fill 326 50 -205 327 50 -205 minecraft:water[level=0]
setblock 327 50 -206 minecraft:water[level=0]
fill 281 50 -215 283 50 -215 minecraft:air
fill 281 50 -216 283 50 -216 minecraft:air
fill 281 50 -217 282 50 -217 minecraft:air
fill 281 50 -218 282 50 -218 minecraft:air
setblock 282 50 -219 minecraft:air
setblock 282 50 -220 minecraft:air
setblock 285 50 -220 minecraft:water[level=0]
setblock 324 50 -220 minecraft:air
fill 322 50 -221 326 50 -221 minecraft:air
fill 321 50 -222 327 50 -222 minecraft:air
fill 321 50 -223 322 50 -223 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=false,west=false]
fill 323 50 -223 327 50 -223 minecraft:air
fill 322 50 -224 327 50 -224 minecraft:air
fill 323 50 -225 327 50 -225 minecraft:air
fill 311 50 -226 312 50 -226 minecraft:water[level=0]
setblock 325 50 -226 minecraft:air
fill 310 50 -227 312 50 -227 minecraft:water[level=0]
fill 310 50 -228 312 50 -228 minecraft:water[level=0]
fill 309 50 -229 312 50 -229 minecraft:water[level=0]
fill 309 50 -230 312 50 -230 minecraft:water[level=0]
fill 309 50 -231 312 50 -231 minecraft:water[level=0]
fill 309 50 -232 312 50 -232 minecraft:water[level=0]
fill 294 50 -250 297 50 -250 minecraft:cave_air
fill 287 50 -251 292 50 -251 minecraft:cave_air
fill 294 50 -251 297 50 -251 minecraft:cave_air
fill 287 50 -252 298 50 -252 minecraft:cave_air
fill 288 50 -253 298 50 -253 minecraft:cave_air
fill 288 50 -254 298 50 -254 minecraft:cave_air
fill 290 49 -191 291 49 -191 minecraft:air
fill 290 49 -192 291 49 -192 minecraft:air
setblock 327 49 -202 minecraft:water[level=0]
setblock 327 49 -203 minecraft:water[level=0]
setblock 327 49 -204 minecraft:water[level=0]
setblock 327 49 -205 minecraft:water[level=0]
setblock 327 49 -206 minecraft:water[level=0]
setblock 327 49 -207 minecraft:water[level=0]
fill 279 49 -214 282 49 -214 minecraft:air
fill 279 49 -215 282 49 -215 minecraft:air
fill 279 49 -216 282 49 -216 minecraft:air
fill 280 49 -217 282 49 -217 minecraft:air
setblock 281 49 -218 minecraft:air
fill 322 49 -220 325 49 -220 minecraft:air
fill 320 49 -221 326 49 -221 minecraft:air
fill 319 49 -222 327 49 -222 minecraft:air
fill 319 49 -223 327 49 -223 minecraft:air
fill 314 49 -224 315 49 -224 minecraft:air
fill 321 49 -224 327 49 -224 minecraft:air
fill 314 49 -225 315 49 -225 minecraft:air
fill 322 49 -225 326 49 -225 minecraft:air
setblock 311 49 -226 minecraft:water[level=0]
fill 310 49 -227 311 49 -227 minecraft:water[level=0]
fill 310 49 -228 311 49 -228 minecraft:water[level=0]
fill 310 49 -229 311 49 -229 minecraft:water[level=0]
fill 310 49 -230 311 49 -230 minecraft:water[level=0]
setblock 311 49 -231 minecraft:water[level=0]
fill 295 49 -250 296 49 -250 minecraft:lava[level=0]
fill 287 49 -251 291 49 -251 minecraft:lava[level=0]
fill 294 49 -251 297 49 -251 minecraft:lava[level=0]
fill 287 49 -252 292 49 -252 minecraft:lava[level=0]
fill 294 49 -252 298 49 -252 minecraft:lava[level=0]
fill 288 49 -253 298 49 -253 minecraft:lava[level=0]
fill 289 49 -254 298 49 -254 minecraft:lava[level=0]
fill 290 48 -191 291 48 -191 minecraft:air
fill 290 48 -192 291 48 -192 minecraft:air
setblock 327 48 -203 minecraft:water[level=0]
setblock 327 48 -204 minecraft:water[level=0]
setblock 327 48 -205 minecraft:water[level=0]
setblock 327 48 -206 minecraft:water[level=0]
setblock 327 48 -207 minecraft:water[level=0]
fill 280 48 -213 281 48 -213 minecraft:air
fill 279 48 -214 281 48 -214 minecraft:air
fill 278 48 -215 281 48 -215 minecraft:air
fill 279 48 -216 281 48 -216 minecraft:air
fill 279 48 -217 281 48 -217 minecraft:air
setblock 281 48 -218 minecraft:air
fill 319 48 -220 324 48 -220 minecraft:air
fill 317 48 -221 325 48 -221 minecraft:air
fill 314 48 -222 326 48 -222 minecraft:air
fill 313 48 -223 326 48 -223 minecraft:air
setblock 312 48 -224 minecraft:air
fill 314 48 -224 326 48 -224 minecraft:air
fill 315 48 -225 317 48 -225 minecraft:air
setblock 320 48 -225 minecraft:air
fill 322 48 -225 324 48 -225 minecraft:air
setblock 316 48 -226 minecraft:air
setblock 310 48 -227 minecraft:water[level=0]
setblock 310 48 -228 minecraft:water[level=0]
fill 289 48 -251 290 48 -251 minecraft:lava[level=0]
fill 295 48 -251 296 48 -251 minecraft:lava[level=0]
fill 288 48 -252 291 48 -252 minecraft:lava[level=0]
fill 294 48 -252 297 48 -252 minecraft:lava[level=0]
fill 294 48 -253 297 48 -253 minecraft:lava[level=0]
setblock 291 48 -254 minecraft:lava[level=0]
fill 294 48 -254 297 48 -254 minecraft:lava[level=0]
fill 289 47 -191 291 47 -191 minecraft:air
fill 277 47 -213 279 47 -213 minecraft:air
fill 276 47 -214 280 47 -214 minecraft:air
fill 276 47 -215 279 47 -215 minecraft:air
fill 276 47 -216 280 47 -216 minecraft:air
fill 277 47 -217 280 47 -217 minecraft:air
fill 317 47 -220 321 47 -220 minecraft:air
fill 315 47 -221 324 47 -221 minecraft:air
fill 313 47 -222 324 47 -222 minecraft:air
fill 312 47 -223 324 47 -223 minecraft:air
fill 313 47 -224 324 47 -224 minecraft:air
fill 316 47 -225 321 47 -225 minecraft:air
setblock 316 47 -226 minecraft:air
fill 295 47 -253 296 47 -253 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 295 47 -254 296 47 -254 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 289 46 -191 290 46 -191 minecraft:air
setblock 327 46 -191 minecraft:cave_air
setblock 327 46 -192 minecraft:cave_air
setblock 327 46 -194 minecraft:cave_air
setblock 327 46 -195 minecraft:cave_air
fill 276 46 -213 279 46 -213 minecraft:air
fill 275 46 -214 280 46 -214 minecraft:air
fill 275 46 -215 280 46 -215 minecraft:air
fill 275 46 -216 279 46 -216 minecraft:air
fill 276 46 -217 278 46 -217 minecraft:air
fill 318 46 -220 320 46 -220 minecraft:air
fill 315 46 -221 321 46 -221 minecraft:air
fill 314 46 -222 322 46 -222 minecraft:air
fill 313 46 -223 322 46 -223 minecraft:air
fill 312 46 -224 321 46 -224 minecraft:air
fill 315 46 -225 319 46 -225 minecraft:air
setblock 316 46 -226 minecraft:air
setblock 296 46 -253 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 327 45 -191 minecraft:cave_air
setblock 327 45 -192 minecraft:cave_air
setblock 327 45 -193 minecraft:cave_air
setblock 327 45 -194 minecraft:cave_air
setblock 327 45 -195 minecraft:cave_air
setblock 327 45 -196 minecraft:cave_air
fill 275 45 -213 278 45 -213 minecraft:air
fill 274 45 -214 279 45 -214 minecraft:air
fill 274 45 -215 280 45 -215 minecraft:air
fill 274 45 -216 279 45 -216 minecraft:air
fill 275 45 -217 278 45 -217 minecraft:air
fill 317 45 -221 318 45 -221 minecraft:air
fill 315 45 -222 319 45 -222 minecraft:air
fill 315 45 -223 319 45 -223 minecraft:air
fill 315 45 -224 319 45 -224 minecraft:air
setblock 316 45 -225 minecraft:air
forceload remove 264 -254 327 -191
tellraw @a {"text":"Campus zurueck a26 fertig.","color":"green"}
