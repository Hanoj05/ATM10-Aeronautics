setblock 215 86 -255 minecraft:white_concrete
setblock 220 86 -261 minecraft:white_concrete
setblock 219 86 -262 minecraft:white_concrete
setblock 204 86 -263 minecraft:white_concrete
setblock 225 86 -267 minecraft:white_concrete
setblock 210 86 -271 minecraft:white_concrete
setblock 232 86 -271 minecraft:white_concrete
fill 238 86 -275 239 86 -275 minecraft:white_concrete
setblock 217 86 -277 minecraft:white_concrete
setblock 246 86 -277 minecraft:white_concrete
setblock 246 86 -278 minecraft:white_concrete
setblock 253 86 -279 minecraft:white_concrete
setblock 253 86 -280 minecraft:white_concrete
setblock 261 86 -280 minecraft:white_concrete
setblock 224 86 -283 minecraft:white_concrete
setblock 233 86 -287 minecraft:white_concrete
setblock 233 86 -288 minecraft:white_concrete
setblock 242 86 -290 minecraft:white_concrete
setblock 242 86 -291 minecraft:white_concrete
setblock 251 86 -293 minecraft:white_concrete
setblock 261 86 -293 minecraft:white_concrete
setblock 261 86 -294 minecraft:white_concrete
setblock 218 85 -255 minecraft:white_concrete
setblock 221 85 -258 minecraft:white_concrete
setblock 221 85 -259 minecraft:white_concrete
setblock 223 85 -261 minecraft:white_concrete
setblock 225 85 -263 minecraft:white_concrete
setblock 200 85 -264 minecraft:white_concrete
setblock 227 85 -264 minecraft:white_concrete
setblock 200 85 -265 minecraft:white_concrete
setblock 230 85 -267 minecraft:white_concrete
setblock 233 85 -268 minecraft:white_concrete
setblock 234 85 -269 minecraft:white_concrete
setblock 204 85 -270 minecraft:white_concrete
setblock 238 85 -271 minecraft:white_concrete
setblock 240 85 -272 minecraft:white_concrete
setblock 207 85 -273 minecraft:white_concrete
fill 241 85 -273 242 85 -273 minecraft:white_concrete
setblock 207 85 -274 minecraft:white_concrete
setblock 244 85 -274 minecraft:white_concrete
setblock 209 85 -275 minecraft:white_concrete
fill 247 85 -275 249 85 -275 minecraft:white_concrete
setblock 209 85 -276 minecraft:white_concrete
setblock 211 85 -277 minecraft:white_concrete
setblock 259 85 -277 minecraft:white_concrete
setblock 262 85 -277 minecraft:white_concrete
setblock 211 85 -278 minecraft:white_concrete
setblock 213 85 -279 minecraft:white_concrete
setblock 216 85 -282 minecraft:white_concrete
setblock 219 85 -284 minecraft:white_concrete
setblock 220 85 -285 minecraft:white_concrete
setblock 223 85 -287 minecraft:white_concrete
setblock 228 85 -289 minecraft:white_concrete
setblock 229 85 -290 minecraft:white_concrete
setblock 231 85 -291 minecraft:white_concrete
fill 246 85 -296 247 85 -296 minecraft:white_concrete
fill 251 85 -297 252 85 -297 minecraft:white_concrete
fill 257 85 -297 258 85 -297 minecraft:white_concrete
setblock 261 85 -297 minecraft:white_concrete
setblock 203 72 -298 minecraft:air
setblock 221 72 -301 minecraft:air
setblock 203 71 -296 minecraft:air
fill 202 71 -297 204 71 -297 minecraft:air
fill 201 71 -298 205 71 -298 minecraft:air
fill 202 71 -299 204 71 -299 minecraft:air
setblock 221 71 -299 minecraft:air
setblock 203 71 -300 minecraft:air
fill 220 71 -300 222 71 -300 minecraft:air
fill 219 71 -301 223 71 -301 minecraft:air
fill 220 71 -302 222 71 -302 minecraft:air
setblock 221 71 -303 minecraft:air
fill 202 70 -296 204 70 -296 minecraft:air
fill 201 70 -297 205 70 -297 minecraft:air
fill 201 70 -298 205 70 -298 minecraft:air
fill 201 70 -299 205 70 -299 minecraft:air
fill 220 70 -299 222 70 -299 minecraft:air
fill 202 70 -300 204 70 -300 minecraft:air
fill 219 70 -300 223 70 -300 minecraft:air
fill 219 70 -301 223 70 -301 minecraft:air
fill 219 70 -302 223 70 -302 minecraft:air
fill 220 70 -303 222 70 -303 minecraft:air
setblock 203 69 -296 minecraft:air
fill 202 69 -297 204 69 -297 minecraft:air
fill 201 69 -298 205 69 -298 minecraft:air
fill 202 69 -299 204 69 -299 minecraft:air
setblock 221 69 -299 minecraft:air
setblock 203 69 -300 minecraft:air
fill 220 69 -300 222 69 -300 minecraft:air
fill 219 69 -301 223 69 -301 minecraft:air
fill 220 69 -302 222 69 -302 minecraft:air
setblock 221 69 -303 minecraft:air
setblock 203 68 -298 minecraft:air
setblock 221 68 -301 minecraft:air
setblock 245 67 -268 minecraft:air
setblock 252 67 -270 minecraft:air
setblock 203 67 -298 minecraft:air
setblock 221 67 -301 minecraft:air
setblock 210 66 -292 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 203 66 -298 minecraft:air
setblock 216 66 -298 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 238 66 -300 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 221 66 -301 minecraft:air
setblock 228 66 -305 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 254 66 -306 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 210 66 -310 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 237 66 -312 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 222 66 -316 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 200 65 -277 minecraft:air
fill 200 65 -278 201 65 -278 minecraft:air
fill 200 65 -279 202 65 -279 minecraft:air
fill 200 65 -280 203 65 -280 minecraft:air
fill 200 65 -281 204 65 -281 minecraft:air
fill 200 65 -282 205 65 -282 minecraft:air
fill 200 65 -283 206 65 -283 minecraft:air
fill 200 65 -284 207 65 -284 minecraft:air
fill 200 65 -285 208 65 -285 minecraft:air
fill 200 65 -286 209 65 -286 minecraft:air
fill 200 65 -287 211 65 -287 minecraft:air
fill 200 65 -288 212 65 -288 minecraft:air
fill 200 65 -289 213 65 -289 minecraft:air
fill 200 65 -290 215 65 -290 minecraft:air
fill 200 65 -291 216 65 -291 minecraft:air
fill 200 65 -292 218 65 -292 minecraft:air
fill 200 65 -293 219 65 -293 minecraft:air
fill 201 65 -294 221 65 -294 minecraft:air
fill 202 65 -295 223 65 -295 minecraft:air
fill 203 65 -296 225 65 -296 minecraft:air
setblock 200 65 -297 minecraft:stone
fill 205 65 -297 227 65 -297 minecraft:air
fill 200 65 -298 201 65 -298 minecraft:stone
fill 206 65 -298 229 65 -298 minecraft:air
fill 200 65 -299 202 65 -299 minecraft:stone
fill 208 65 -299 231 65 -299 minecraft:air
fill 200 65 -300 204 65 -300 minecraft:stone
fill 207 65 -300 234 65 -300 minecraft:air
fill 200 65 -301 205 65 -301 minecraft:stone
fill 206 65 -301 237 65 -301 minecraft:air
fill 200 65 -302 207 65 -302 minecraft:stone
fill 208 65 -302 210 65 -302 minecraft:air
setblock 211 65 -302 minecraft:grass_block[snowy=false]
fill 212 65 -302 221 65 -302 minecraft:air
fill 223 65 -302 240 65 -302 minecraft:air
fill 200 65 -303 208 65 -303 minecraft:stone
setblock 209 65 -303 minecraft:air
fill 211 65 -303 213 65 -303 minecraft:grass_block[snowy=false]
fill 214 65 -303 220 65 -303 minecraft:air
fill 225 65 -303 244 65 -303 minecraft:air
fill 200 65 -304 208 65 -304 minecraft:stone
fill 209 65 -304 210 65 -304 minecraft:black_concrete
fill 211 65 -304 215 65 -304 minecraft:grass_block[snowy=false]
fill 216 65 -304 221 65 -304 minecraft:air
fill 227 65 -304 250 65 -304 minecraft:air
fill 200 65 -305 208 65 -305 minecraft:stone
fill 209 65 -305 212 65 -305 minecraft:black_concrete
fill 213 65 -305 214 65 -305 minecraft:grass_block[snowy=false]
fill 218 65 -305 223 65 -305 minecraft:air
fill 229 65 -305 250 65 -305 minecraft:air
fill 251 65 -305 261 65 -305 minecraft:black_concrete
fill 200 65 -306 207 65 -306 minecraft:stone
setblock 208 65 -306 minecraft:copper_ore
fill 209 65 -306 214 65 -306 minecraft:black_concrete
fill 215 65 -306 220 65 -306 minecraft:grass_block[snowy=false]
fill 221 65 -306 225 65 -306 minecraft:air
fill 226 65 -306 231 65 -306 minecraft:grass_block[snowy=false]
fill 232 65 -306 250 65 -306 minecraft:air
fill 251 65 -306 261 65 -306 minecraft:black_concrete
fill 262 65 -306 263 65 -306 minecraft:grass_block[snowy=false]
setblock 200 65 -307 minecraft:grass_block[snowy=false]
fill 201 65 -307 207 65 -307 minecraft:stone
fill 208 65 -307 209 65 -307 minecraft:copper_ore
fill 210 65 -307 216 65 -307 minecraft:black_concrete
fill 217 65 -307 222 65 -307 minecraft:grass_block[snowy=false]
fill 223 65 -307 227 65 -307 minecraft:air
fill 228 65 -307 233 65 -307 minecraft:grass_block[snowy=false]
fill 234 65 -307 250 65 -307 minecraft:air
fill 251 65 -307 261 65 -307 minecraft:black_concrete
fill 262 65 -307 263 65 -307 minecraft:grass_block[snowy=false]
fill 202 65 -308 207 65 -308 minecraft:stone
fill 208 65 -308 209 65 -308 minecraft:copper_ore
fill 210 65 -308 218 65 -308 minecraft:black_concrete
fill 219 65 -308 225 65 -308 minecraft:grass_block[snowy=false]
fill 226 65 -308 229 65 -308 minecraft:air
fill 230 65 -308 236 65 -308 minecraft:grass_block[snowy=false]
fill 237 65 -308 250 65 -308 minecraft:air
fill 251 65 -308 261 65 -308 minecraft:black_concrete
fill 262 65 -308 263 65 -308 minecraft:grass_block[snowy=false]
fill 203 65 -309 208 65 -309 minecraft:stone
fill 209 65 -309 220 65 -309 minecraft:black_concrete
fill 221 65 -309 228 65 -309 minecraft:grass_block[snowy=false]
fill 229 65 -309 231 65 -309 minecraft:air
fill 232 65 -309 239 65 -309 minecraft:grass_block[snowy=false]
fill 240 65 -309 250 65 -309 minecraft:air
fill 251 65 -309 261 65 -309 minecraft:black_concrete
fill 205 65 -310 209 65 -310 minecraft:grass_block[snowy=false]
fill 210 65 -310 223 65 -310 minecraft:black_concrete
fill 224 65 -310 231 65 -310 minecraft:grass_block[snowy=false]
fill 232 65 -310 234 65 -310 minecraft:air
fill 235 65 -310 242 65 -310 minecraft:grass_block[snowy=false]
fill 243 65 -310 249 65 -310 minecraft:air
fill 250 65 -310 260 65 -310 minecraft:black_concrete
fill 205 65 -311 209 65 -311 minecraft:grass_block[snowy=false]
fill 210 65 -311 226 65 -311 minecraft:black_concrete
fill 227 65 -311 236 65 -311 minecraft:grass_block[snowy=false]
setblock 237 65 -311 minecraft:air
fill 238 65 -311 247 65 -311 minecraft:grass_block[snowy=false]
fill 248 65 -311 249 65 -311 minecraft:air
fill 250 65 -311 260 65 -311 minecraft:black_concrete
fill 205 65 -312 209 65 -312 minecraft:grass_block[snowy=false]
fill 210 65 -312 229 65 -312 minecraft:black_concrete
fill 230 65 -312 238 65 -312 minecraft:grass_block[snowy=false]
fill 239 65 -312 240 65 -312 minecraft:black_concrete
fill 241 65 -312 249 65 -312 minecraft:grass_block[snowy=false]
fill 250 65 -312 260 65 -312 minecraft:black_concrete
fill 205 65 -313 209 65 -313 minecraft:grass_block[snowy=false]
fill 210 65 -313 233 65 -313 minecraft:black_concrete
fill 234 65 -313 238 65 -313 minecraft:grass_block[snowy=false]
fill 239 65 -313 244 65 -313 minecraft:black_concrete
fill 245 65 -313 249 65 -313 minecraft:grass_block[snowy=false]
fill 250 65 -313 261 65 -313 minecraft:black_concrete
fill 205 65 -314 210 65 -314 minecraft:grass_block[snowy=false]
fill 211 65 -314 262 65 -314 minecraft:black_concrete
setblock 263 65 -314 minecraft:grass_block[snowy=false]
fill 205 65 -315 210 65 -315 minecraft:grass_block[snowy=false]
fill 211 65 -315 262 65 -315 minecraft:black_concrete
fill 205 65 -316 209 65 -316 minecraft:grass_block[snowy=false]
fill 210 65 -316 261 65 -316 minecraft:black_concrete
fill 205 65 -317 211 65 -317 minecraft:grass_block[snowy=false]
fill 212 65 -317 261 65 -317 minecraft:black_concrete
fill 205 65 -318 211 65 -318 minecraft:grass_block[snowy=false]
fill 212 65 -318 261 65 -318 minecraft:black_concrete
fill 200 64 -255 261 64 -255 minecraft:air
setblock 262 64 -255 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
setblock 263 64 -255 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
fill 200 64 -256 259 64 -256 minecraft:air
setblock 260 64 -256 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 261 64 -256 262 64 -256 minecraft:air
setblock 263 64 -256 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
fill 200 64 -257 263 64 -257 minecraft:air
fill 200 64 -258 263 64 -258 minecraft:air
fill 200 64 -259 263 64 -259 minecraft:air
fill 200 64 -260 263 64 -260 minecraft:air
fill 200 64 -261 263 64 -261 minecraft:air
fill 200 64 -262 263 64 -262 minecraft:air
fill 202 64 -263 263 64 -263 minecraft:air
fill 205 64 -264 263 64 -264 minecraft:air
fill 206 64 -265 263 64 -265 minecraft:air
fill 207 64 -266 263 64 -266 minecraft:air
setblock 207 64 -267 minecraft:air
setblock 208 64 -267 regions_unexplored:grass_sprouts
fill 209 64 -267 263 64 -267 minecraft:air
fill 208 64 -268 263 64 -268 minecraft:air
fill 200 64 -269 203 64 -269 minecraft:air
fill 209 64 -269 211 64 -269 minecraft:air
fill 213 64 -269 263 64 -269 minecraft:air
fill 200 64 -270 204 64 -270 minecraft:air
setblock 205 64 -270 regions_unexplored:grass_sprouts
setblock 206 64 -270 minecraft:air
fill 210 64 -270 263 64 -270 minecraft:air
fill 200 64 -271 204 64 -271 minecraft:air
fill 210 64 -271 263 64 -271 minecraft:air
setblock 203 64 -272 minecraft:air
setblock 211 64 -272 regions_unexplored:grass_sprouts
fill 212 64 -272 263 64 -272 minecraft:air
fill 212 64 -273 263 64 -273 minecraft:air
fill 212 64 -274 213 64 -274 minecraft:air
fill 215 64 -274 263 64 -274 minecraft:air
fill 213 64 -275 263 64 -275 minecraft:air
fill 214 64 -276 263 64 -276 minecraft:air
fill 214 64 -277 263 64 -277 minecraft:air
fill 215 64 -278 229 64 -278 minecraft:air
fill 231 64 -278 263 64 -278 minecraft:air
fill 215 64 -279 263 64 -279 minecraft:air
setblock 216 64 -280 regions_unexplored:grass_sprouts
fill 217 64 -280 223 64 -280 minecraft:air
fill 225 64 -280 229 64 -280 minecraft:air
setblock 230 64 -280 regions_unexplored:grass_sprouts
fill 231 64 -280 235 64 -280 minecraft:air
setblock 236 64 -280 regions_unexplored:grass_sprouts
fill 237 64 -280 255 64 -280 minecraft:air
fill 257 64 -280 263 64 -280 minecraft:air
fill 216 64 -281 217 64 -281 minecraft:air
setblock 218 64 -281 minecraft:short_grass
setblock 220 64 -281 minecraft:tall_grass[half=upper]
fill 221 64 -281 226 64 -281 minecraft:air
setblock 227 64 -281 regions_unexplored:grass_sprouts
fill 228 64 -281 229 64 -281 minecraft:air
setblock 231 64 -281 regions_unexplored:grass_sprouts
fill 232 64 -281 233 64 -281 minecraft:air
setblock 234 64 -281 regions_unexplored:grass_sprouts
fill 235 64 -281 236 64 -281 minecraft:air
setblock 237 64 -281 regions_unexplored:grass_sprouts
fill 238 64 -281 263 64 -281 minecraft:air
fill 216 64 -282 218 64 -282 minecraft:air
setblock 219 64 -282 regions_unexplored:grass_sprouts
fill 220 64 -282 227 64 -282 minecraft:air
setblock 229 64 -282 regions_unexplored:grass_sprouts
setblock 230 64 -282 minecraft:air
setblock 231 64 -282 regions_unexplored:grass_sprouts
setblock 232 64 -282 minecraft:air
setblock 233 64 -282 minecraft:short_grass
fill 234 64 -282 243 64 -282 minecraft:air
setblock 244 64 -282 regions_unexplored:grass_sprouts
setblock 245 64 -282 minecraft:air
fill 246 64 -282 247 64 -282 minecraft:short_grass
setblock 248 64 -282 minecraft:air
setblock 249 64 -282 regions_unexplored:grass_sprouts
fill 250 64 -282 252 64 -282 minecraft:air
setblock 253 64 -282 minecraft:short_grass
fill 254 64 -282 263 64 -282 minecraft:air
fill 216 64 -283 218 64 -283 minecraft:air
setblock 219 64 -283 minecraft:short_grass
fill 220 64 -283 222 64 -283 minecraft:air
setblock 223 64 -283 minecraft:short_grass
fill 224 64 -283 228 64 -283 minecraft:air
fill 235 64 -283 237 64 -283 minecraft:air
setblock 238 64 -283 minecraft:short_grass
fill 239 64 -283 249 64 -283 minecraft:air
setblock 250 64 -283 minecraft:short_grass
setblock 251 64 -283 minecraft:air
fill 252 64 -283 253 64 -283 regions_unexplored:grass_sprouts
fill 254 64 -283 262 64 -283 minecraft:air
fill 217 64 -284 220 64 -284 minecraft:air
setblock 221 64 -284 regions_unexplored:grass_sprouts
setblock 222 64 -284 minecraft:air
setblock 223 64 -284 regions_unexplored:grass_sprouts
setblock 224 64 -284 minecraft:air
setblock 225 64 -284 minecraft:short_grass
setblock 226 64 -284 minecraft:air
fill 236 64 -284 237 64 -284 minecraft:air
setblock 238 64 -284 minecraft:short_grass
fill 239 64 -284 240 64 -284 minecraft:air
setblock 241 64 -284 minecraft:short_grass
setblock 242 64 -284 minecraft:air
setblock 243 64 -284 regions_unexplored:grass_sprouts
setblock 247 64 -284 minecraft:short_grass
setblock 248 64 -284 regions_unexplored:grass_sprouts
fill 249 64 -284 251 64 -284 minecraft:air
setblock 252 64 -284 minecraft:short_grass
setblock 253 64 -284 minecraft:air
fill 258 64 -284 259 64 -284 regions_unexplored:grass_sprouts
fill 260 64 -284 262 64 -284 minecraft:air
fill 203 64 -285 207 64 -285 minecraft:air
fill 217 64 -285 220 64 -285 minecraft:air
fill 222 64 -285 226 64 -285 minecraft:air
setblock 236 64 -285 regions_unexplored:grass_sprouts
setblock 237 64 -285 minecraft:short_grass
setblock 238 64 -285 minecraft:air
fill 239 64 -285 240 64 -285 regions_unexplored:grass_sprouts
setblock 241 64 -285 minecraft:air
fill 259 64 -285 263 64 -285 minecraft:air
fill 202 64 -286 208 64 -286 minecraft:air
setblock 218 64 -286 regions_unexplored:grass_sprouts
setblock 219 64 -286 minecraft:air
setblock 220 64 -286 minecraft:short_grass
fill 221 64 -286 226 64 -286 minecraft:air
fill 236 64 -286 240 64 -286 minecraft:air
fill 261 64 -286 262 64 -286 regions_unexplored:grass_sprouts
setblock 263 64 -286 minecraft:air
setblock 209 64 -287 minecraft:air
fill 220 64 -287 225 64 -287 minecraft:air
fill 236 64 -287 240 64 -287 minecraft:air
setblock 262 64 -287 minecraft:short_grass
setblock 263 64 -287 minecraft:air
setblock 210 64 -288 minecraft:air
setblock 236 64 -288 minecraft:air
setblock 237 64 -288 minecraft:short_grass
fill 238 64 -288 239 64 -288 minecraft:air
setblock 263 64 -288 regions_unexplored:grass_sprouts
setblock 263 64 -289 regions_unexplored:grass_sprouts
setblock 252 64 -290 minecraft:short_grass
setblock 263 64 -290 minecraft:air
setblock 251 64 -291 minecraft:air
setblock 252 64 -291 minecraft:short_grass
setblock 253 64 -291 minecraft:air
setblock 263 64 -291 minecraft:air
fill 250 64 -292 254 64 -292 minecraft:air
setblock 250 64 -293 minecraft:air
setblock 251 64 -293 regions_unexplored:grass_sprouts
fill 252 64 -293 254 64 -293 minecraft:air
setblock 263 64 -293 minecraft:air
fill 250 64 -294 251 64 -294 regions_unexplored:grass_sprouts
fill 252 64 -294 255 64 -294 minecraft:air
setblock 263 64 -294 minecraft:air
fill 248 64 -295 249 64 -295 minecraft:air
setblock 250 64 -295 regions_unexplored:grass_sprouts
fill 251 64 -295 252 64 -295 minecraft:air
setblock 253 64 -295 regions_unexplored:grass_sprouts
setblock 254 64 -295 minecraft:air
setblock 255 64 -295 regions_unexplored:grass_sprouts
fill 256 64 -295 257 64 -295 minecraft:air
setblock 258 64 -295 minecraft:short_grass
fill 262 64 -295 263 64 -295 minecraft:air
setblock 247 64 -296 regions_unexplored:grass_sprouts
fill 248 64 -296 249 64 -296 minecraft:air
setblock 250 64 -296 regions_unexplored:grass_sprouts
fill 251 64 -296 259 64 -296 minecraft:air
fill 262 64 -296 263 64 -296 minecraft:air
setblock 247 64 -297 minecraft:air
setblock 248 64 -297 minecraft:short_grass
fill 249 64 -297 250 64 -297 minecraft:air
setblock 251 64 -297 minecraft:short_grass
fill 252 64 -297 262 64 -297 minecraft:air
setblock 263 64 -297 minecraft:short_grass
fill 247 64 -298 259 64 -298 minecraft:air
fill 260 64 -298 261 64 -298 minecraft:short_grass
fill 262 64 -298 263 64 -298 minecraft:air
fill 247 64 -299 250 64 -299 minecraft:air
setblock 251 64 -299 regions_unexplored:grass_sprouts
fill 253 64 -299 254 64 -299 minecraft:air
fill 256 64 -299 263 64 -299 minecraft:air
setblock 249 64 -300 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 250 64 -300 minecraft:short_grass
setblock 251 64 -300 regions_unexplored:grass_sprouts
fill 253 64 -300 255 64 -300 minecraft:air
setblock 256 64 -300 minecraft:tall_grass[half=upper]
fill 257 64 -300 262 64 -300 minecraft:air
setblock 263 64 -300 minecraft:short_grass
fill 249 64 -301 256 64 -301 minecraft:air
fill 258 64 -301 261 64 -301 minecraft:air
setblock 262 64 -301 minecraft:short_grass
setblock 263 64 -301 minecraft:air
setblock 250 64 -302 minecraft:air
setblock 251 64 -302 minecraft:short_grass
fill 252 64 -302 254 64 -302 minecraft:air
setblock 256 64 -302 minecraft:tall_grass[half=upper]
setblock 257 64 -302 minecraft:air
setblock 259 64 -302 minecraft:air
fill 261 64 -302 263 64 -302 minecraft:air
fill 250 64 -303 251 64 -303 minecraft:air
setblock 252 64 -303 regions_unexplored:grass_sprouts
fill 253 64 -303 260 64 -303 minecraft:air
setblock 261 64 -303 minecraft:short_grass
fill 262 64 -303 263 64 -303 regions_unexplored:grass_sprouts
fill 251 64 -304 252 64 -304 minecraft:air
setblock 253 64 -304 minecraft:short_grass
setblock 254 64 -304 regions_unexplored:grass_sprouts
fill 255 64 -304 257 64 -304 minecraft:air
setblock 258 64 -304 regions_unexplored:grass_sprouts
fill 259 64 -304 261 64 -304 minecraft:air
setblock 262 64 -304 minecraft:short_grass
setblock 263 64 -304 minecraft:air
setblock 252 64 -305 minecraft:air
setblock 253 64 -305 minecraft:short_grass
fill 254 64 -305 257 64 -305 minecraft:air
setblock 258 64 -305 minecraft:short_grass
fill 259 64 -305 260 64 -305 minecraft:air
setblock 254 64 -306 minecraft:air
setblock 255 64 -306 minecraft:short_grass
fill 256 64 -306 258 64 -306 minecraft:air
setblock 256 64 -307 minecraft:short_grass
fill 200 63 -255 254 63 -255 minecraft:air
fill 256 63 -255 257 63 -255 minecraft:short_grass
fill 258 63 -255 259 63 -255 minecraft:air
fill 200 63 -256 252 63 -256 minecraft:air
fill 254 63 -256 259 63 -256 minecraft:air
fill 200 63 -257 257 63 -257 minecraft:air
setblock 258 63 -257 regions_unexplored:grass_sprouts
setblock 259 63 -257 minecraft:short_grass
fill 200 63 -258 260 63 -258 minecraft:air
fill 200 63 -259 257 63 -259 minecraft:air
setblock 258 63 -259 regions_unexplored:grass_sprouts
fill 259 63 -259 260 63 -259 minecraft:air
fill 200 63 -260 261 63 -260 minecraft:air
fill 200 63 -261 259 63 -261 minecraft:air
setblock 260 63 -261 minecraft:short_grass
setblock 261 63 -261 minecraft:air
fill 203 63 -262 261 63 -262 minecraft:air
fill 206 63 -263 259 63 -263 minecraft:air
setblock 260 63 -263 minecraft:short_grass
fill 261 63 -263 262 63 -263 minecraft:air
setblock 207 63 -264 minecraft:air
fill 209 63 -264 262 63 -264 minecraft:air
fill 208 63 -265 263 63 -265 minecraft:air
fill 209 63 -266 263 63 -266 minecraft:air
fill 210 63 -267 211 63 -267 minecraft:air
fill 213 63 -267 260 63 -267 minecraft:air
fill 262 63 -267 263 63 -267 minecraft:air
setblock 211 63 -268 minecraft:air
fill 213 63 -268 260 63 -268 minecraft:air
fill 262 63 -268 263 63 -268 minecraft:air
fill 200 63 -269 202 63 -269 minecraft:air
setblock 211 63 -269 minecraft:air
fill 213 63 -269 260 63 -269 minecraft:air
fill 262 63 -269 263 63 -269 minecraft:air
fill 200 63 -270 202 63 -270 minecraft:air
setblock 203 63 -270 regions_unexplored:grass_sprouts
setblock 204 63 -270 minecraft:air
fill 212 63 -270 213 63 -270 minecraft:air
fill 215 63 -270 263 63 -270 minecraft:air
fill 200 63 -271 204 63 -271 minecraft:air
fill 213 63 -271 214 63 -271 minecraft:air
fill 216 63 -271 263 63 -271 minecraft:air
fill 213 63 -272 214 63 -272 minecraft:air
fill 216 63 -272 263 63 -272 minecraft:air
fill 214 63 -273 215 63 -273 minecraft:air
fill 217 63 -273 263 63 -273 minecraft:air
fill 215 63 -274 263 63 -274 minecraft:air
fill 216 63 -275 218 63 -275 minecraft:air
fill 220 63 -275 263 63 -275 minecraft:air
fill 216 63 -276 263 63 -276 minecraft:air
fill 217 63 -277 233 63 -277 minecraft:air
setblock 234 63 -277 regions_unexplored:grass_sprouts
fill 235 63 -277 236 63 -277 minecraft:air
setblock 237 63 -277 minecraft:short_grass
fill 238 63 -277 263 63 -277 minecraft:air
fill 218 63 -278 219 63 -278 minecraft:air
setblock 220 63 -278 minecraft:short_grass
setblock 221 63 -278 minecraft:air
setblock 222 63 -278 minecraft:short_grass
fill 223 63 -278 225 63 -278 minecraft:air
setblock 226 63 -278 minecraft:short_grass
setblock 227 63 -278 minecraft:air
fill 228 63 -278 229 63 -278 regions_unexplored:grass_sprouts
fill 231 63 -278 232 63 -278 minecraft:air
fill 233 63 -278 234 63 -278 minecraft:short_grass
setblock 235 63 -278 regions_unexplored:grass_sprouts
setblock 236 63 -278 minecraft:air
setblock 237 63 -278 regions_unexplored:grass_sprouts
fill 238 63 -278 254 63 -278 minecraft:air
fill 256 63 -278 263 63 -278 minecraft:air
fill 219 63 -279 221 63 -279 minecraft:air
setblock 222 63 -279 minecraft:short_grass
setblock 223 63 -279 regions_unexplored:grass_sprouts
setblock 224 63 -279 minecraft:air
setblock 225 63 -279 regions_unexplored:grass_sprouts
setblock 226 63 -279 minecraft:short_grass
fill 227 63 -279 229 63 -279 minecraft:air
fill 231 63 -279 232 63 -279 minecraft:air
setblock 233 63 -279 regions_unexplored:grass_sprouts
fill 234 63 -279 263 63 -279 minecraft:air
fill 219 63 -280 220 63 -280 minecraft:air
setblock 221 63 -280 minecraft:short_grass
setblock 222 63 -280 minecraft:air
setblock 223 63 -280 minecraft:short_grass
setblock 225 63 -280 regions_unexplored:grass_sprouts
setblock 226 63 -280 minecraft:air
fill 237 63 -280 240 63 -280 minecraft:air
setblock 241 63 -280 minecraft:short_grass
fill 242 63 -280 253 63 -280 minecraft:air
setblock 254 63 -280 regions_unexplored:grass_sprouts
setblock 255 63 -280 minecraft:air
fill 257 63 -280 263 63 -280 minecraft:air
setblock 220 63 -281 minecraft:tall_grass[half=lower]
fill 221 63 -281 223 63 -281 minecraft:air
setblock 224 63 -281 minecraft:short_grass
setblock 239 63 -281 minecraft:short_grass
setblock 240 63 -281 minecraft:air
setblock 241 63 -281 regions_unexplored:grass_sprouts
fill 242 63 -281 243 63 -281 minecraft:short_grass
fill 244 63 -281 245 63 -281 minecraft:air
setblock 246 63 -281 minecraft:short_grass
fill 247 63 -281 254 63 -281 minecraft:air
fill 258 63 -281 263 63 -281 minecraft:air
fill 220 63 -282 221 63 -282 minecraft:air
setblock 222 63 -282 regions_unexplored:grass_sprouts
fill 240 63 -282 241 63 -282 minecraft:air
fill 250 63 -282 252 63 -282 minecraft:air
fill 259 63 -282 263 63 -282 minecraft:air
fill 261 63 -283 262 63 -283 minecraft:air
setblock 262 63 -284 minecraft:air
setblock 263 63 -285 minecraft:air
setblock 252 63 -292 minecraft:air
setblock 252 63 -293 minecraft:air
setblock 252 63 -294 minecraft:short_grass
fill 255 63 -296 256 63 -296 minecraft:air
setblock 257 63 -296 minecraft:short_grass
setblock 254 63 -297 regions_unexplored:grass_sprouts
setblock 255 63 -297 minecraft:air
fill 256 63 -297 257 63 -297 minecraft:short_grass
fill 253 63 -298 254 63 -298 minecraft:short_grass
fill 255 63 -298 258 63 -298 minecraft:air
setblock 253 63 -299 regions_unexplored:grass_sprouts
setblock 254 63 -299 minecraft:air
fill 256 63 -299 258 63 -299 minecraft:air
setblock 259 63 -299 minecraft:short_grass
setblock 260 63 -299 minecraft:air
setblock 261 63 -299 minecraft:short_grass
setblock 253 63 -300 regions_unexplored:grass_sprouts
fill 254 63 -300 255 63 -300 minecraft:air
setblock 256 63 -300 minecraft:tall_grass[half=lower]
fill 257 63 -300 262 63 -300 minecraft:air
setblock 253 63 -301 minecraft:short_grass
setblock 254 63 -301 minecraft:air
setblock 255 63 -301 regions_unexplored:grass_sprouts
setblock 256 63 -301 minecraft:air
setblock 258 63 -301 regions_unexplored:grass_sprouts
fill 259 63 -301 261 63 -301 minecraft:air
setblock 254 63 -302 minecraft:air
setblock 256 63 -302 minecraft:tall_grass[half=lower]
setblock 257 63 -302 regions_unexplored:grass_sprouts
setblock 259 63 -302 minecraft:short_grass
setblock 255 63 -303 minecraft:air
setblock 256 63 -303 minecraft:short_grass
setblock 257 63 -303 regions_unexplored:grass_sprouts
setblock 258 63 -303 minecraft:air
setblock 256 63 -304 regions_unexplored:grass_sprouts
setblock 246 63 -318 minecraft:air
fill 200 62 -255 254 62 -255 minecraft:water[level=0]
fill 200 62 -256 252 62 -256 minecraft:water[level=0]
fill 254 62 -256 255 62 -256 minecraft:water[level=0]
fill 200 62 -257 256 62 -257 minecraft:water[level=0]
fill 200 62 -258 257 62 -258 minecraft:water[level=0]
fill 200 62 -259 257 62 -259 minecraft:water[level=0]
fill 200 62 -260 258 62 -260 minecraft:water[level=0]
fill 203 62 -261 205 62 -261 minecraft:water[level=0]
setblock 206 62 -261 minecraft:tall_seagrass[half=upper]
fill 207 62 -261 258 62 -261 minecraft:water[level=0]
fill 206 62 -262 258 62 -262 minecraft:water[level=0]
setblock 207 62 -263 minecraft:water[level=0]
setblock 208 62 -263 minecraft:seagrass
fill 209 62 -263 258 62 -263 minecraft:water[level=0]
fill 209 62 -264 259 62 -264 minecraft:water[level=0]
fill 210 62 -265 259 62 -265 minecraft:water[level=0]
fill 210 62 -266 259 62 -266 minecraft:water[level=0]
setblock 211 62 -267 minecraft:water[level=0]
fill 213 62 -267 260 62 -267 minecraft:water[level=0]
fill 213 62 -268 260 62 -268 minecraft:water[level=0]
setblock 262 62 -268 minecraft:water[level=0]
setblock 263 62 -268 minecraft:seagrass
fill 200 62 -269 201 62 -269 minecraft:water[level=0]
fill 213 62 -269 260 62 -269 minecraft:water[level=0]
setblock 262 62 -269 minecraft:water[level=0]
setblock 263 62 -269 minecraft:seagrass
fill 200 62 -270 202 62 -270 minecraft:water[level=0]
fill 215 62 -270 263 62 -270 minecraft:water[level=0]
setblock 201 62 -271 minecraft:water[level=0]
setblock 214 62 -271 minecraft:water[level=0]
fill 216 62 -271 260 62 -271 minecraft:water[level=0]
setblock 261 62 -271 minecraft:tall_seagrass[half=upper]
setblock 262 62 -271 minecraft:water[level=0]
setblock 263 62 -271 minecraft:tall_seagrass[half=upper]
fill 216 62 -272 261 62 -272 minecraft:water[level=0]
setblock 262 62 -272 minecraft:tall_seagrass[half=upper]
setblock 263 62 -272 minecraft:water[level=0]
fill 217 62 -273 263 62 -273 minecraft:water[level=0]
fill 217 62 -274 263 62 -274 minecraft:water[level=0]
setblock 218 62 -275 minecraft:water[level=0]
fill 220 62 -275 263 62 -275 minecraft:water[level=0]
fill 219 62 -276 263 62 -276 minecraft:water[level=0]
fill 220 62 -277 232 62 -277 minecraft:water[level=0]
fill 238 62 -277 263 62 -277 minecraft:water[level=0]
fill 223 62 -278 224 62 -278 minecraft:water[level=0]
fill 239 62 -278 254 62 -278 minecraft:water[level=0]
fill 256 62 -278 263 62 -278 minecraft:water[level=0]
fill 240 62 -279 255 62 -279 minecraft:water[level=0]
fill 257 62 -279 263 62 -279 minecraft:water[level=0]
setblock 252 62 -280 minecraft:water[level=0]
fill 262 62 -280 263 62 -280 minecraft:water[level=0]
fill 247 62 -316 249 62 -316 minecraft:water[level=0]
fill 246 62 -317 249 62 -317 minecraft:water[level=0]
fill 246 62 -318 249 62 -318 minecraft:water[level=0]
fill 200 61 -255 252 61 -255 minecraft:water[level=0]
fill 200 61 -256 252 61 -256 minecraft:water[level=0]
setblock 200 61 -257 minecraft:tall_seagrass[half=upper]
fill 201 61 -257 253 61 -257 minecraft:water[level=0]
fill 200 61 -258 254 61 -258 minecraft:water[level=0]
fill 200 61 -259 255 61 -259 minecraft:water[level=0]
fill 203 61 -260 256 61 -260 minecraft:water[level=0]
setblock 206 61 -261 minecraft:tall_seagrass[half=lower]
fill 207 61 -261 256 61 -261 minecraft:water[level=0]
setblock 207 61 -262 minecraft:seagrass
setblock 208 61 -262 minecraft:water[level=0]
setblock 209 61 -262 minecraft:tall_seagrass[half=upper]
fill 210 61 -262 257 61 -262 minecraft:water[level=0]
fill 209 61 -263 257 61 -263 minecraft:water[level=0]
setblock 210 61 -264 minecraft:water[level=0]
setblock 211 61 -264 minecraft:tall_seagrass[half=upper]
fill 212 61 -264 257 61 -264 minecraft:water[level=0]
fill 211 61 -265 257 61 -265 minecraft:water[level=0]
fill 212 61 -266 258 61 -266 minecraft:water[level=0]
fill 213 61 -267 258 61 -267 minecraft:water[level=0]
fill 213 61 -268 258 61 -268 minecraft:water[level=0]
fill 214 61 -269 259 61 -269 minecraft:water[level=0]
fill 215 61 -270 261 61 -270 minecraft:water[level=0]
fill 216 61 -271 260 61 -271 minecraft:water[level=0]
setblock 261 61 -271 minecraft:tall_seagrass[half=lower]
setblock 262 61 -271 minecraft:water[level=0]
setblock 263 61 -271 minecraft:tall_seagrass[half=lower]
fill 216 61 -272 261 61 -272 minecraft:water[level=0]
setblock 262 61 -272 minecraft:tall_seagrass[half=lower]
setblock 263 61 -272 minecraft:water[level=0]
fill 218 61 -273 263 61 -273 minecraft:water[level=0]
fill 219 61 -274 235 61 -274 minecraft:water[level=0]
fill 237 61 -274 263 61 -274 minecraft:water[level=0]
fill 220 61 -275 233 61 -275 minecraft:water[level=0]
fill 239 61 -275 263 61 -275 minecraft:water[level=0]
fill 240 61 -276 263 61 -276 minecraft:water[level=0]
fill 242 61 -277 263 61 -277 minecraft:water[level=0]
fill 251 61 -278 253 61 -278 minecraft:water[level=0]
fill 258 61 -278 263 61 -278 minecraft:water[level=0]
setblock 248 61 -314 minecraft:water[level=0]
fill 247 61 -315 248 61 -315 minecraft:water[level=0]
fill 246 61 -316 249 61 -316 minecraft:water[level=0]
fill 246 61 -317 250 61 -317 minecraft:water[level=0]
fill 245 61 -318 250 61 -318 minecraft:water[level=0]
fill 200 60 -255 249 60 -255 minecraft:water[level=0]
fill 200 60 -256 249 60 -256 minecraft:water[level=0]
setblock 200 60 -257 minecraft:tall_seagrass[half=lower]
fill 201 60 -257 250 60 -257 minecraft:water[level=0]
fill 200 60 -258 252 60 -258 minecraft:water[level=0]
fill 200 60 -259 201 60 -259 minecraft:water[level=0]
fill 203 60 -259 253 60 -259 minecraft:water[level=0]
setblock 200 60 -260 minecraft:water[level=0]
fill 205 60 -260 255 60 -260 minecraft:water[level=0]
fill 207 60 -261 255 60 -261 minecraft:water[level=0]
setblock 209 60 -262 minecraft:tall_seagrass[half=lower]
fill 210 60 -262 255 60 -262 minecraft:water[level=0]
setblock 210 60 -263 minecraft:seagrass
fill 211 60 -263 256 60 -263 minecraft:water[level=0]
setblock 211 60 -264 minecraft:tall_seagrass[half=lower]
fill 212 60 -264 256 60 -264 minecraft:water[level=0]
fill 212 60 -265 256 60 -265 minecraft:water[level=0]
fill 213 60 -266 256 60 -266 minecraft:water[level=0]
fill 214 60 -267 256 60 -267 minecraft:water[level=0]
fill 215 60 -268 256 60 -268 minecraft:water[level=0]
fill 215 60 -269 257 60 -269 minecraft:water[level=0]
fill 216 60 -270 258 60 -270 minecraft:water[level=0]
fill 217 60 -271 258 60 -271 minecraft:water[level=0]
fill 218 60 -272 259 60 -272 minecraft:water[level=0]
fill 220 60 -273 221 60 -273 minecraft:water[level=0]
setblock 222 60 -273 minecraft:seagrass
fill 223 60 -273 234 60 -273 minecraft:water[level=0]
fill 239 60 -273 261 60 -273 minecraft:water[level=0]
fill 222 60 -274 231 60 -274 minecraft:water[level=0]
fill 241 60 -274 263 60 -274 minecraft:water[level=0]
fill 243 60 -275 258 60 -275 minecraft:water[level=0]
setblock 259 60 -275 minecraft:seagrass
fill 260 60 -275 263 60 -275 minecraft:water[level=0]
fill 250 60 -276 255 60 -276 minecraft:water[level=0]
fill 257 60 -276 263 60 -276 minecraft:water[level=0]
fill 259 60 -277 263 60 -277 minecraft:water[level=0]
setblock 249 60 -312 minecraft:water[level=0]
fill 248 60 -313 249 60 -313 minecraft:water[level=0]
fill 247 60 -314 249 60 -314 minecraft:water[level=0]
fill 246 60 -315 248 60 -315 minecraft:water[level=0]
fill 246 60 -316 249 60 -316 minecraft:water[level=0]
fill 246 60 -317 250 60 -317 minecraft:water[level=0]
fill 245 60 -318 249 60 -318 minecraft:water[level=0]
fill 200 59 -255 246 59 -255 minecraft:water[level=0]
fill 200 59 -256 243 59 -256 minecraft:water[level=0]
setblock 244 59 -256 minecraft:tall_seagrass[half=upper]
fill 245 59 -256 247 59 -256 minecraft:water[level=0]
fill 201 59 -257 248 59 -257 minecraft:water[level=0]
fill 201 59 -258 206 59 -258 minecraft:water[level=0]
setblock 207 59 -258 minecraft:tall_seagrass[half=upper]
fill 208 59 -258 246 59 -258 minecraft:water[level=0]
setblock 247 59 -258 minecraft:tall_seagrass[half=upper]
setblock 248 59 -258 minecraft:seagrass
setblock 249 59 -258 minecraft:water[level=0]
fill 200 59 -259 202 59 -259 minecraft:water[level=0]
fill 205 59 -259 207 59 -259 minecraft:water[level=0]
setblock 208 59 -259 minecraft:tall_seagrass[half=upper]
fill 209 59 -259 251 59 -259 minecraft:water[level=0]
fill 200 59 -260 201 59 -260 minecraft:water[level=0]
fill 207 59 -260 253 59 -260 minecraft:water[level=0]
fill 200 59 -261 201 59 -261 minecraft:water[level=0]
setblock 209 59 -261 minecraft:seagrass
fill 210 59 -261 253 59 -261 minecraft:water[level=0]
fill 211 59 -262 253 59 -262 minecraft:water[level=0]
setblock 212 59 -263 minecraft:seagrass
fill 213 59 -263 254 59 -263 minecraft:water[level=0]
fill 213 59 -264 254 59 -264 minecraft:water[level=0]
fill 213 59 -265 254 59 -265 minecraft:water[level=0]
fill 214 59 -266 254 59 -266 minecraft:water[level=0]
fill 215 59 -267 254 59 -267 minecraft:water[level=0]
fill 216 59 -268 254 59 -268 minecraft:water[level=0]
fill 216 59 -269 255 59 -269 minecraft:water[level=0]
fill 217 59 -270 255 59 -270 minecraft:water[level=0]
fill 218 59 -271 219 59 -271 minecraft:water[level=0]
setblock 220 59 -271 minecraft:tall_seagrass[half=upper]
fill 221 59 -271 230 59 -271 minecraft:water[level=0]
setblock 231 59 -271 minecraft:tall_seagrass[half=upper]
fill 232 59 -271 234 59 -271 minecraft:water[level=0]
fill 240 59 -271 256 59 -271 minecraft:water[level=0]
fill 220 59 -272 227 59 -272 minecraft:water[level=0]
setblock 228 59 -272 minecraft:tall_seagrass[half=upper]
fill 229 59 -272 232 59 -272 minecraft:water[level=0]
fill 243 59 -272 256 59 -272 minecraft:water[level=0]
fill 223 59 -273 224 59 -273 minecraft:water[level=0]
setblock 225 59 -273 minecraft:seagrass
fill 226 59 -273 228 59 -273 minecraft:water[level=0]
setblock 229 59 -273 minecraft:seagrass
fill 245 59 -273 256 59 -273 minecraft:water[level=0]
fill 249 59 -274 254 59 -274 minecraft:water[level=0]
setblock 252 59 -275 minecraft:water[level=0]
fill 259 59 -276 262 59 -276 minecraft:water[level=0]
setblock 250 59 -309 minecraft:water[level=0]
setblock 250 59 -310 minecraft:water[level=0]
fill 249 59 -311 250 59 -311 minecraft:water[level=0]
fill 248 59 -312 250 59 -312 minecraft:water[level=0]
fill 247 59 -313 249 59 -313 minecraft:water[level=0]
fill 247 59 -314 249 59 -314 minecraft:water[level=0]
fill 247 59 -315 248 59 -315 minecraft:water[level=0]
setblock 247 59 -316 minecraft:water[level=0]
fill 245 59 -318 247 59 -318 minecraft:water[level=0]
fill 200 58 -255 240 58 -255 minecraft:water[level=0]
setblock 241 58 -255 minecraft:seagrass
setblock 242 58 -255 minecraft:water[level=0]
fill 201 58 -256 240 58 -256 minecraft:water[level=0]
setblock 241 58 -256 minecraft:seagrass
fill 242 58 -256 243 58 -256 minecraft:water[level=0]
setblock 244 58 -256 minecraft:tall_seagrass[half=lower]
setblock 245 58 -256 minecraft:water[level=0]
fill 203 58 -257 246 58 -257 minecraft:water[level=0]
setblock 206 58 -258 minecraft:water[level=0]
setblock 207 58 -258 minecraft:tall_seagrass[half=lower]
fill 208 58 -258 209 58 -258 minecraft:water[level=0]
fill 210 58 -258 211 58 -258 minecraft:tall_seagrass[half=upper]
fill 212 58 -258 238 58 -258 minecraft:water[level=0]
setblock 239 58 -258 minecraft:tall_seagrass[half=upper]
fill 240 58 -258 244 58 -258 minecraft:water[level=0]
setblock 245 58 -258 minecraft:seagrass
setblock 246 58 -258 minecraft:water[level=0]
setblock 247 58 -258 minecraft:tall_seagrass[half=lower]
fill 200 58 -259 202 58 -259 minecraft:water[level=0]
setblock 207 58 -259 minecraft:water[level=0]
setblock 208 58 -259 minecraft:tall_seagrass[half=lower]
setblock 209 58 -259 minecraft:seagrass
fill 210 58 -259 248 58 -259 minecraft:water[level=0]
fill 200 58 -260 201 58 -260 minecraft:water[level=0]
setblock 209 58 -260 minecraft:seagrass
fill 210 58 -260 251 58 -260 minecraft:water[level=0]
fill 200 58 -261 201 58 -261 minecraft:water[level=0]
setblock 211 58 -261 minecraft:seagrass
fill 212 58 -261 251 58 -261 minecraft:water[level=0]
fill 200 58 -262 201 58 -262 minecraft:water[level=0]
fill 212 58 -262 252 58 -262 minecraft:water[level=0]
fill 213 58 -263 247 58 -263 minecraft:water[level=0]
setblock 248 58 -263 minecraft:tall_seagrass[half=upper]
fill 249 58 -263 252 58 -263 minecraft:water[level=0]
fill 214 58 -264 252 58 -264 minecraft:water[level=0]
fill 214 58 -265 252 58 -265 minecraft:water[level=0]
fill 215 58 -266 253 58 -266 minecraft:water[level=0]
fill 216 58 -267 253 58 -267 minecraft:water[level=0]
fill 217 58 -268 253 58 -268 minecraft:water[level=0]
fill 218 58 -269 235 58 -269 minecraft:water[level=0]
fill 242 58 -269 253 58 -269 minecraft:water[level=0]
fill 219 58 -270 233 58 -270 minecraft:water[level=0]
fill 244 58 -270 254 58 -270 minecraft:water[level=0]
setblock 220 58 -271 minecraft:tall_seagrass[half=lower]
fill 221 58 -271 223 58 -271 minecraft:water[level=0]
setblock 224 58 -271 minecraft:tall_seagrass[half=upper]
setblock 225 58 -271 minecraft:water[level=0]
setblock 226 58 -271 minecraft:tall_seagrass[half=upper]
fill 227 58 -271 230 58 -271 minecraft:water[level=0]
setblock 231 58 -271 minecraft:tall_seagrass[half=lower]
fill 246 58 -271 254 58 -271 minecraft:water[level=0]
fill 223 58 -272 227 58 -272 minecraft:water[level=0]
setblock 228 58 -272 minecraft:tall_seagrass[half=lower]
fill 249 58 -272 254 58 -272 minecraft:water[level=0]
fill 250 58 -273 253 58 -273 minecraft:water[level=0]
setblock 251 58 -306 minecraft:water[level=0]
setblock 251 58 -307 minecraft:water[level=0]
fill 250 58 -308 251 58 -308 minecraft:water[level=0]
fill 250 58 -309 251 58 -309 minecraft:water[level=0]
fill 249 58 -310 251 58 -310 minecraft:water[level=0]
fill 249 58 -311 250 58 -311 minecraft:water[level=0]
fill 249 58 -312 250 58 -312 minecraft:water[level=0]
setblock 249 58 -313 minecraft:water[level=0]
fill 203 57 -255 206 57 -255 minecraft:water[level=0]
setblock 207 57 -255 minecraft:seagrass
fill 208 57 -255 211 57 -255 minecraft:water[level=0]
setblock 212 57 -255 minecraft:tall_seagrass[half=upper]
setblock 213 57 -255 minecraft:water[level=0]
setblock 214 57 -255 minecraft:tall_seagrass[half=upper]
fill 215 57 -255 217 57 -255 minecraft:water[level=0]
setblock 218 57 -255 minecraft:tall_seagrass[half=upper]
fill 219 57 -255 231 57 -255 minecraft:water[level=0]
fill 204 57 -256 232 57 -256 minecraft:water[level=0]
setblock 240 57 -256 minecraft:water[level=0]
fill 206 57 -257 208 57 -257 minecraft:water[level=0]
setblock 209 57 -257 minecraft:tall_seagrass[half=upper]
fill 210 57 -257 211 57 -257 minecraft:water[level=0]
fill 212 57 -257 213 57 -257 minecraft:tall_seagrass[half=upper]
fill 214 57 -257 235 57 -257 minecraft:water[level=0]
setblock 236 57 -257 minecraft:seagrass
fill 237 57 -257 244 57 -257 minecraft:water[level=0]
fill 208 57 -258 209 57 -258 minecraft:water[level=0]
fill 210 57 -258 211 57 -258 minecraft:tall_seagrass[half=lower]
fill 212 57 -258 237 57 -258 minecraft:water[level=0]
setblock 238 57 -258 minecraft:seagrass
setblock 239 57 -258 minecraft:tall_seagrass[half=lower]
setblock 240 57 -258 minecraft:seagrass
setblock 241 57 -258 minecraft:water[level=0]
fill 242 57 -258 244 57 -258 minecraft:seagrass
setblock 210 57 -259 minecraft:water[level=0]
setblock 211 57 -259 minecraft:seagrass
fill 212 57 -259 237 57 -259 minecraft:water[level=0]
setblock 238 57 -259 minecraft:tall_seagrass[half=upper]
fill 239 57 -259 242 57 -259 minecraft:water[level=0]
setblock 243 57 -259 minecraft:seagrass
setblock 244 57 -259 minecraft:water[level=0]
setblock 245 57 -259 minecraft:seagrass
setblock 246 57 -259 minecraft:water[level=0]
fill 200 57 -260 202 57 -260 minecraft:water[level=0]
fill 211 57 -260 212 57 -260 minecraft:water[level=0]
setblock 213 57 -260 minecraft:seagrass
fill 214 57 -260 235 57 -260 minecraft:water[level=0]
setblock 236 57 -260 minecraft:tall_seagrass[half=upper]
fill 237 57 -260 245 57 -260 minecraft:water[level=0]
setblock 246 57 -260 minecraft:seagrass
setblock 247 57 -260 minecraft:water[level=0]
fill 200 57 -261 202 57 -261 minecraft:water[level=0]
setblock 213 57 -261 minecraft:water[level=0]
setblock 214 57 -261 minecraft:seagrass
fill 215 57 -261 235 57 -261 minecraft:water[level=0]
setblock 236 57 -261 minecraft:tall_seagrass[half=upper]
fill 237 57 -261 243 57 -261 minecraft:water[level=0]
setblock 244 57 -261 minecraft:tall_seagrass[half=upper]
fill 245 57 -261 248 57 -261 minecraft:water[level=0]
fill 200 57 -262 202 57 -262 minecraft:water[level=0]
fill 214 57 -262 242 57 -262 minecraft:water[level=0]
setblock 243 57 -262 minecraft:tall_seagrass[half=upper]
fill 244 57 -262 247 57 -262 minecraft:water[level=0]
setblock 248 57 -262 minecraft:seagrass
setblock 249 57 -262 minecraft:water[level=0]
fill 200 57 -263 202 57 -263 minecraft:water[level=0]
fill 214 57 -263 237 57 -263 minecraft:water[level=0]
setblock 238 57 -263 minecraft:tall_seagrass[half=upper]
fill 239 57 -263 243 57 -263 minecraft:water[level=0]
setblock 244 57 -263 minecraft:tall_seagrass[half=upper]
fill 245 57 -263 247 57 -263 minecraft:water[level=0]
setblock 248 57 -263 minecraft:tall_seagrass[half=lower]
fill 249 57 -263 250 57 -263 minecraft:water[level=0]
setblock 200 57 -264 minecraft:water[level=0]
fill 214 57 -264 234 57 -264 minecraft:water[level=0]
setblock 235 57 -264 minecraft:tall_seagrass[half=upper]
fill 236 57 -264 250 57 -264 minecraft:water[level=0]
fill 215 57 -265 235 57 -265 minecraft:water[level=0]
setblock 236 57 -265 minecraft:tall_seagrass[half=upper]
fill 237 57 -265 239 57 -265 minecraft:water[level=0]
setblock 240 57 -265 minecraft:tall_seagrass[half=upper]
fill 241 57 -265 245 57 -265 minecraft:water[level=0]
setblock 246 57 -265 minecraft:tall_seagrass[half=upper]
fill 247 57 -265 250 57 -265 minecraft:water[level=0]
fill 216 57 -266 251 57 -266 minecraft:water[level=0]
fill 217 57 -267 222 57 -267 minecraft:water[level=0]
setblock 223 57 -267 minecraft:tall_seagrass[half=upper]
fill 224 57 -267 226 57 -267 minecraft:water[level=0]
setblock 227 57 -267 minecraft:tall_seagrass[half=upper]
fill 228 57 -267 232 57 -267 minecraft:water[level=0]
setblock 233 57 -267 minecraft:tall_seagrass[half=upper]
fill 234 57 -267 235 57 -267 minecraft:water[level=0]
fill 242 57 -267 247 57 -267 minecraft:water[level=0]
setblock 248 57 -267 minecraft:tall_seagrass[half=upper]
fill 249 57 -267 251 57 -267 minecraft:water[level=0]
fill 218 57 -268 226 57 -268 minecraft:water[level=0]
setblock 227 57 -268 minecraft:tall_seagrass[half=upper]
fill 228 57 -268 231 57 -268 minecraft:water[level=0]
setblock 232 57 -268 minecraft:tall_seagrass[half=upper]
fill 233 57 -268 234 57 -268 minecraft:water[level=0]
fill 244 57 -268 251 57 -268 minecraft:water[level=0]
fill 219 57 -269 230 57 -269 minecraft:water[level=0]
setblock 231 57 -269 minecraft:seagrass
setblock 232 57 -269 minecraft:water[level=0]
fill 246 57 -269 252 57 -269 minecraft:water[level=0]
fill 220 57 -270 228 57 -270 minecraft:water[level=0]
setblock 229 57 -270 minecraft:seagrass
fill 230 57 -270 231 57 -270 minecraft:water[level=0]
fill 248 57 -270 252 57 -270 minecraft:water[level=0]
setblock 223 57 -271 minecraft:water[level=0]
setblock 224 57 -271 minecraft:tall_seagrass[half=lower]
setblock 225 57 -271 minecraft:water[level=0]
setblock 226 57 -271 minecraft:tall_seagrass[half=lower]
fill 227 57 -271 228 57 -271 minecraft:water[level=0]
fill 251 57 -271 252 57 -271 minecraft:water[level=0]
fill 251 57 -272 252 57 -272 minecraft:water[level=0]
setblock 200 57 -300 minecraft:water[level=0]
setblock 200 57 -301 minecraft:water[level=0]
fill 200 57 -302 201 57 -302 minecraft:water[level=0]
setblock 253 57 -302 minecraft:water[level=0]
setblock 253 57 -303 minecraft:water[level=0]
setblock 252 57 -304 minecraft:water[level=0]
fill 251 57 -305 252 57 -305 minecraft:water[level=0]
fill 251 57 -306 252 57 -306 minecraft:water[level=0]
fill 250 57 -307 252 57 -307 minecraft:water[level=0]
fill 250 57 -308 252 57 -308 minecraft:water[level=0]
fill 250 57 -309 251 57 -309 minecraft:water[level=0]
setblock 250 57 -310 minecraft:water[level=0]
setblock 250 57 -311 minecraft:water[level=0]
fill 208 56 -255 211 56 -255 minecraft:water[level=0]
setblock 212 56 -255 minecraft:tall_seagrass[half=lower]
setblock 213 56 -255 minecraft:water[level=0]
setblock 214 56 -255 minecraft:tall_seagrass[half=lower]
setblock 217 56 -255 minecraft:water[level=0]
setblock 218 56 -255 minecraft:tall_seagrass[half=lower]
fill 219 56 -255 229 56 -255 minecraft:water[level=0]
fill 206 56 -256 211 56 -256 minecraft:water[level=0]
setblock 212 56 -256 minecraft:seagrass
setblock 213 56 -256 minecraft:water[level=0]
setblock 214 56 -256 minecraft:seagrass
fill 215 56 -256 230 56 -256 minecraft:water[level=0]
setblock 208 56 -257 minecraft:seagrass
setblock 209 56 -257 minecraft:tall_seagrass[half=lower]
setblock 210 56 -257 minecraft:water[level=0]
setblock 211 56 -257 minecraft:seagrass
fill 212 56 -257 213 56 -257 minecraft:tall_seagrass[half=lower]
setblock 214 56 -257 minecraft:water[level=0]
setblock 215 56 -257 minecraft:seagrass
fill 216 56 -257 230 56 -257 minecraft:water[level=0]
setblock 212 56 -258 minecraft:seagrass
fill 213 56 -258 232 56 -258 minecraft:water[level=0]
fill 213 56 -259 237 56 -259 minecraft:water[level=0]
setblock 238 56 -259 minecraft:tall_seagrass[half=lower]
fill 239 56 -259 241 56 -259 minecraft:water[level=0]
setblock 242 56 -259 minecraft:seagrass
setblock 202 56 -260 minecraft:water[level=0]
setblock 214 56 -260 minecraft:seagrass
fill 215 56 -260 234 56 -260 minecraft:water[level=0]
setblock 235 56 -260 minecraft:seagrass
setblock 236 56 -260 minecraft:tall_seagrass[half=lower]
fill 237 56 -260 239 56 -260 minecraft:water[level=0]
fill 240 56 -260 241 56 -260 minecraft:seagrass
fill 242 56 -260 244 56 -260 minecraft:water[level=0]
fill 200 56 -261 202 56 -261 minecraft:water[level=0]
fill 215 56 -261 234 56 -261 minecraft:water[level=0]
setblock 235 56 -261 minecraft:seagrass
setblock 236 56 -261 minecraft:tall_seagrass[half=lower]
setblock 237 56 -261 minecraft:seagrass
fill 238 56 -261 240 56 -261 minecraft:water[level=0]
setblock 241 56 -261 minecraft:seagrass
fill 242 56 -261 243 56 -261 minecraft:water[level=0]
setblock 244 56 -261 minecraft:tall_seagrass[half=lower]
fill 245 56 -261 246 56 -261 minecraft:water[level=0]
fill 200 56 -262 202 56 -262 minecraft:water[level=0]
fill 215 56 -262 239 56 -262 minecraft:water[level=0]
setblock 240 56 -262 minecraft:seagrass
setblock 241 56 -262 minecraft:water[level=0]
setblock 242 56 -262 minecraft:seagrass
setblock 243 56 -262 minecraft:tall_seagrass[half=lower]
fill 244 56 -262 247 56 -262 minecraft:water[level=0]
fill 200 56 -263 202 56 -263 minecraft:water[level=0]
fill 215 56 -263 222 56 -263 minecraft:water[level=0]
setblock 223 56 -263 minecraft:tall_seagrass[half=upper]
fill 224 56 -263 226 56 -263 minecraft:water[level=0]
setblock 227 56 -263 minecraft:tall_seagrass[half=upper]
fill 228 56 -263 236 56 -263 minecraft:water[level=0]
setblock 237 56 -263 minecraft:seagrass
setblock 238 56 -263 minecraft:tall_seagrass[half=lower]
fill 239 56 -263 243 56 -263 minecraft:water[level=0]
setblock 244 56 -263 minecraft:tall_seagrass[half=lower]
fill 245 56 -263 247 56 -263 minecraft:water[level=0]
fill 200 56 -264 202 56 -264 minecraft:water[level=0]
fill 215 56 -264 222 56 -264 minecraft:water[level=0]
setblock 223 56 -264 minecraft:tall_seagrass[half=upper]
fill 224 56 -264 225 56 -264 minecraft:water[level=0]
setblock 226 56 -264 minecraft:tall_seagrass[half=upper]
fill 227 56 -264 234 56 -264 minecraft:water[level=0]
setblock 235 56 -264 minecraft:tall_seagrass[half=lower]
fill 236 56 -264 239 56 -264 minecraft:water[level=0]
setblock 240 56 -264 minecraft:seagrass
fill 241 56 -264 248 56 -264 minecraft:water[level=0]
fill 200 56 -265 201 56 -265 minecraft:water[level=0]
fill 216 56 -265 221 56 -265 minecraft:water[level=0]
setblock 222 56 -265 minecraft:tall_seagrass[half=upper]
fill 223 56 -265 226 56 -265 minecraft:water[level=0]
setblock 227 56 -265 minecraft:tall_seagrass[half=upper]
fill 228 56 -265 235 56 -265 minecraft:water[level=0]
setblock 236 56 -265 minecraft:tall_seagrass[half=lower]
fill 237 56 -265 239 56 -265 minecraft:water[level=0]
setblock 240 56 -265 minecraft:tall_seagrass[half=lower]
fill 241 56 -265 242 56 -265 minecraft:water[level=0]
setblock 243 56 -265 minecraft:seagrass
fill 244 56 -265 245 56 -265 minecraft:water[level=0]
setblock 246 56 -265 minecraft:tall_seagrass[half=lower]
fill 247 56 -265 248 56 -265 minecraft:water[level=0]
setblock 200 56 -266 minecraft:water[level=0]
fill 217 56 -266 234 56 -266 minecraft:water[level=0]
fill 243 56 -266 248 56 -266 minecraft:water[level=0]
setblock 200 56 -267 minecraft:water[level=0]
fill 219 56 -267 222 56 -267 minecraft:water[level=0]
setblock 223 56 -267 minecraft:tall_seagrass[half=lower]
setblock 224 56 -267 minecraft:water[level=0]
fill 225 56 -267 226 56 -267 minecraft:seagrass
setblock 227 56 -267 minecraft:tall_seagrass[half=lower]
fill 228 56 -267 229 56 -267 minecraft:water[level=0]
setblock 230 56 -267 minecraft:seagrass
setblock 231 56 -267 minecraft:water[level=0]
setblock 232 56 -267 minecraft:seagrass
setblock 233 56 -267 minecraft:tall_seagrass[half=lower]
fill 245 56 -267 247 56 -267 minecraft:water[level=0]
setblock 248 56 -267 minecraft:tall_seagrass[half=lower]
setblock 249 56 -267 minecraft:water[level=0]
fill 219 56 -268 222 56 -268 minecraft:water[level=0]
setblock 223 56 -268 minecraft:seagrass
fill 224 56 -268 225 56 -268 minecraft:water[level=0]
setblock 226 56 -268 minecraft:seagrass
setblock 227 56 -268 minecraft:tall_seagrass[half=lower]
fill 228 56 -268 231 56 -268 minecraft:water[level=0]
setblock 232 56 -268 minecraft:tall_seagrass[half=lower]
fill 247 56 -268 249 56 -268 minecraft:water[level=0]
fill 220 56 -269 222 56 -269 minecraft:water[level=0]
setblock 223 56 -269 minecraft:seagrass
fill 224 56 -269 227 56 -269 minecraft:water[level=0]
setblock 228 56 -269 minecraft:seagrass
fill 229 56 -269 230 56 -269 minecraft:water[level=0]
setblock 223 56 -270 minecraft:water[level=0]
setblock 224 56 -270 minecraft:seagrass
setblock 225 56 -270 minecraft:water[level=0]
setblock 226 56 -270 minecraft:seagrass
fill 227 56 -270 228 56 -270 minecraft:water[level=0]
setblock 256 56 -294 minecraft:water[level=0]
setblock 255 56 -296 minecraft:water[level=0]
setblock 255 56 -297 minecraft:water[level=0]
fill 254 56 -298 255 56 -298 minecraft:water[level=0]
setblock 254 56 -299 minecraft:water[level=0]
setblock 200 56 -300 minecraft:water[level=0]
fill 253 56 -300 254 56 -300 minecraft:water[level=0]
fill 200 56 -301 201 56 -301 minecraft:water[level=0]
fill 253 56 -301 254 56 -301 minecraft:water[level=0]
fill 200 56 -302 201 56 -302 minecraft:water[level=0]
fill 252 56 -302 254 56 -302 minecraft:water[level=0]
fill 201 56 -303 202 56 -303 minecraft:water[level=0]
fill 252 56 -303 254 56 -303 minecraft:water[level=0]
fill 252 56 -304 254 56 -304 minecraft:water[level=0]
fill 251 56 -305 253 56 -305 minecraft:water[level=0]
fill 251 56 -306 253 56 -306 minecraft:water[level=0]
fill 251 56 -307 252 56 -307 minecraft:water[level=0]
setblock 251 56 -308 minecraft:water[level=0]
setblock 263 56 -313 minecraft:water[level=0]
fill 262 56 -314 263 56 -314 minecraft:water[level=0]
setblock 263 56 -315 minecraft:water[level=0]
setblock 263 56 -316 minecraft:water[level=0]
setblock 263 56 -317 minecraft:water[level=0]
setblock 263 56 -318 minecraft:water[level=0]
setblock 202 55 -262 minecraft:water[level=0]
fill 226 55 -262 229 55 -262 minecraft:water[level=0]
fill 200 55 -263 202 55 -263 minecraft:water[level=0]
setblock 223 55 -263 minecraft:tall_seagrass[half=lower]
fill 224 55 -263 225 55 -263 minecraft:water[level=0]
setblock 226 55 -263 minecraft:seagrass
setblock 227 55 -263 minecraft:tall_seagrass[half=lower]
fill 228 55 -263 231 55 -263 minecraft:water[level=0]
fill 200 55 -264 202 55 -264 minecraft:water[level=0]
setblock 221 55 -264 minecraft:seagrass
setblock 222 55 -264 minecraft:water[level=0]
setblock 223 55 -264 minecraft:tall_seagrass[half=lower]
fill 224 55 -264 225 55 -264 minecraft:seagrass
setblock 226 55 -264 minecraft:tall_seagrass[half=lower]
fill 227 55 -264 230 55 -264 minecraft:water[level=0]
setblock 231 55 -264 minecraft:seagrass
setblock 232 55 -264 minecraft:water[level=0]
setblock 244 55 -264 minecraft:water[level=0]
fill 200 55 -265 202 55 -265 minecraft:water[level=0]
setblock 222 55 -265 minecraft:tall_seagrass[half=lower]
fill 223 55 -265 225 55 -265 minecraft:water[level=0]
setblock 226 55 -265 minecraft:seagrass
setblock 227 55 -265 minecraft:tall_seagrass[half=lower]
fill 228 55 -265 230 55 -265 minecraft:water[level=0]
fill 200 55 -266 203 55 -266 minecraft:water[level=0]
fill 223 55 -266 224 55 -266 minecraft:seagrass
fill 225 55 -266 226 55 -266 minecraft:water[level=0]
setblock 227 55 -266 minecraft:seagrass
setblock 228 55 -266 minecraft:water[level=0]
fill 200 55 -267 203 55 -267 minecraft:water[level=0]
setblock 224 55 -267 minecraft:seagrass
fill 200 55 -268 202 55 -268 minecraft:water[level=0]
fill 200 55 -269 202 55 -269 minecraft:water[level=0]
fill 200 55 -270 202 55 -270 minecraft:water[level=0]
fill 200 55 -271 202 55 -271 minecraft:water[level=0]
fill 200 55 -272 202 55 -272 minecraft:water[level=0]
setblock 257 55 -293 minecraft:water[level=0]
setblock 256 55 -294 minecraft:water[level=0]
setblock 256 55 -295 minecraft:water[level=0]
fill 255 55 -296 256 55 -296 minecraft:water[level=0]
fill 255 55 -297 256 55 -297 minecraft:water[level=0]
fill 254 55 -298 255 55 -298 minecraft:water[level=0]
setblock 263 55 -298 minecraft:water[level=0]
fill 254 55 -299 255 55 -299 minecraft:water[level=0]
setblock 263 55 -299 minecraft:water[level=0]
fill 253 55 -300 255 55 -300 minecraft:water[level=0]
fill 200 55 -301 202 55 -301 minecraft:water[level=0]
fill 253 55 -301 255 55 -301 minecraft:water[level=0]
fill 201 55 -302 203 55 -302 minecraft:water[level=0]
fill 253 55 -302 255 55 -302 minecraft:water[level=0]
fill 202 55 -303 203 55 -303 minecraft:water[level=0]
fill 253 55 -303 255 55 -303 minecraft:water[level=0]
fill 202 55 -304 204 55 -304 minecraft:water[level=0]
fill 252 55 -304 254 55 -304 minecraft:water[level=0]
fill 203 55 -305 205 55 -305 minecraft:water[level=0]
fill 252 55 -305 253 55 -305 minecraft:water[level=0]
setblock 252 55 -306 minecraft:water[level=0]
setblock 252 55 -307 minecraft:water[level=0]
fill 262 55 -311 263 55 -311 minecraft:water[level=0]
fill 261 55 -312 263 55 -312 minecraft:water[level=0]
fill 261 55 -313 263 55 -313 minecraft:water[level=0]
fill 261 55 -314 263 55 -314 minecraft:water[level=0]
fill 262 55 -315 263 55 -315 minecraft:water[level=0]
fill 262 55 -316 263 55 -316 minecraft:water[level=0]
fill 262 55 -317 263 55 -317 minecraft:water[level=0]
fill 262 55 -318 263 55 -318 minecraft:water[level=0]
fill 201 54 -265 202 54 -265 minecraft:water[level=0]
fill 200 54 -266 202 54 -266 minecraft:water[level=0]
fill 200 54 -267 203 54 -267 minecraft:water[level=0]
fill 200 54 -268 203 54 -268 minecraft:water[level=0]
fill 200 54 -269 206 54 -269 minecraft:water[level=0]
fill 200 54 -270 206 54 -270 minecraft:water[level=0]
fill 200 54 -271 207 54 -271 minecraft:water[level=0]
fill 200 54 -272 207 54 -272 minecraft:water[level=0]
fill 204 54 -273 209 54 -273 minecraft:water[level=0]
setblock 257 54 -293 minecraft:water[level=0]
setblock 263 54 -293 minecraft:water[level=0]
fill 256 54 -294 257 54 -294 minecraft:water[level=0]
setblock 263 54 -294 minecraft:water[level=0]
fill 256 54 -295 257 54 -295 minecraft:water[level=0]
setblock 263 54 -295 minecraft:water[level=0]
fill 255 54 -296 256 54 -296 minecraft:water[level=0]
setblock 263 54 -296 minecraft:water[level=0]
fill 255 54 -297 256 54 -297 minecraft:water[level=0]
fill 254 54 -298 256 54 -298 minecraft:water[level=0]
setblock 263 54 -298 minecraft:water[level=0]
fill 254 54 -299 256 54 -299 minecraft:water[level=0]
setblock 263 54 -299 minecraft:water[level=0]
fill 254 54 -300 256 54 -300 minecraft:water[level=0]
setblock 263 54 -300 minecraft:water[level=0]
fill 254 54 -301 256 54 -301 minecraft:water[level=0]
fill 254 54 -302 255 54 -302 minecraft:water[level=0]
fill 203 54 -303 205 54 -303 minecraft:water[level=0]
setblock 254 54 -303 minecraft:water[level=0]
fill 204 54 -304 205 54 -304 minecraft:water[level=0]
fill 253 54 -304 254 54 -304 minecraft:water[level=0]
fill 204 54 -305 206 54 -305 minecraft:water[level=0]
setblock 253 54 -305 minecraft:water[level=0]
fill 205 54 -306 207 54 -306 minecraft:water[level=0]
fill 206 54 -307 207 54 -307 minecraft:water[level=0]
fill 207 54 -308 208 54 -308 minecraft:water[level=0]
setblock 209 54 -309 minecraft:water[level=0]
fill 260 54 -310 263 54 -310 minecraft:water[level=0]
fill 260 54 -311 263 54 -311 minecraft:water[level=0]
fill 260 54 -312 263 54 -312 minecraft:water[level=0]
fill 260 54 -313 263 54 -313 minecraft:water[level=0]
fill 261 54 -314 263 54 -314 minecraft:water[level=0]
fill 261 54 -315 263 54 -315 minecraft:water[level=0]
fill 262 54 -316 263 54 -316 minecraft:water[level=0]
fill 262 54 -317 263 54 -317 minecraft:water[level=0]
fill 262 54 -318 263 54 -318 minecraft:water[level=0]
fill 202 53 -268 203 53 -268 minecraft:water[level=0]
fill 202 53 -269 204 53 -269 minecraft:water[level=0]
fill 203 53 -270 207 53 -270 minecraft:water[level=0]
fill 203 53 -271 211 53 -271 minecraft:water[level=0]
fill 219 53 -271 224 53 -271 minecraft:water[level=0]
fill 203 53 -272 222 53 -272 minecraft:water[level=0]
fill 204 53 -273 220 53 -273 minecraft:water[level=0]
fill 212 53 -274 216 53 -274 minecraft:water[level=0]
setblock 258 53 -292 minecraft:water[level=0]
fill 257 53 -293 258 53 -293 minecraft:water[level=0]
setblock 263 53 -293 minecraft:water[level=0]
fill 256 53 -294 257 53 -294 minecraft:water[level=0]
fill 262 53 -294 263 53 -294 minecraft:water[level=0]
fill 256 53 -295 257 53 -295 minecraft:water[level=0]
fill 262 53 -295 263 53 -295 minecraft:water[level=0]
fill 255 53 -296 257 53 -296 minecraft:water[level=0]
setblock 263 53 -296 minecraft:water[level=0]
fill 255 53 -297 257 53 -297 minecraft:water[level=0]
fill 255 53 -298 257 53 -298 minecraft:water[level=0]
setblock 263 53 -298 minecraft:water[level=0]
fill 255 53 -299 257 53 -299 minecraft:water[level=0]
setblock 263 53 -299 minecraft:water[level=0]
fill 255 53 -300 256 53 -300 minecraft:water[level=0]
setblock 263 53 -300 minecraft:water[level=0]
fill 255 53 -301 256 53 -301 minecraft:water[level=0]
setblock 255 53 -302 minecraft:water[level=0]
setblock 254 53 -303 minecraft:water[level=0]
fill 261 53 -303 263 53 -303 minecraft:water[level=0]
setblock 254 53 -304 minecraft:water[level=0]
fill 261 53 -304 263 53 -304 minecraft:water[level=0]
fill 206 53 -305 207 53 -305 minecraft:water[level=0]
fill 261 53 -305 263 53 -305 minecraft:water[level=0]
fill 206 53 -306 208 53 -306 minecraft:water[level=0]
fill 207 53 -307 209 53 -307 minecraft:water[level=0]
fill 260 53 -307 262 53 -307 minecraft:water[level=0]
fill 208 53 -308 210 53 -308 minecraft:water[level=0]
fill 260 53 -308 262 53 -308 minecraft:water[level=0]
fill 208 53 -309 211 53 -309 minecraft:water[level=0]
fill 259 53 -309 262 53 -309 minecraft:water[level=0]
fill 209 53 -310 211 53 -310 minecraft:water[level=0]
fill 259 53 -310 263 53 -310 minecraft:water[level=0]
fill 210 53 -311 212 53 -311 minecraft:water[level=0]
fill 259 53 -311 263 53 -311 minecraft:water[level=0]
fill 212 53 -312 213 53 -312 minecraft:water[level=0]
fill 259 53 -312 263 53 -312 minecraft:water[level=0]
setblock 213 53 -313 minecraft:water[level=0]
fill 260 53 -313 263 53 -313 minecraft:water[level=0]
fill 260 53 -314 263 53 -314 minecraft:water[level=0]
fill 261 53 -315 263 53 -315 minecraft:water[level=0]
fill 262 53 -316 263 53 -316 minecraft:water[level=0]
fill 262 53 -317 263 53 -317 minecraft:water[level=0]
fill 262 53 -318 263 53 -318 minecraft:water[level=0]
fill 226 52 -268 228 52 -268 minecraft:water[level=0]
fill 225 52 -269 227 52 -269 minecraft:water[level=0]
fill 223 52 -270 226 52 -270 minecraft:water[level=0]
fill 207 52 -271 209 52 -271 minecraft:water[level=0]
fill 221 52 -271 225 52 -271 minecraft:water[level=0]
fill 208 52 -272 215 52 -272 minecraft:water[level=0]
fill 217 52 -272 224 52 -272 minecraft:water[level=0]
fill 210 52 -273 221 52 -273 minecraft:water[level=0]
setblock 258 52 -292 minecraft:water[level=0]
setblock 263 52 -292 minecraft:water[level=0]
fill 257 52 -293 258 52 -293 minecraft:water[level=0]
setblock 263 52 -293 minecraft:water[level=0]
fill 257 52 -294 258 52 -294 minecraft:water[level=0]
fill 262 52 -294 263 52 -294 minecraft:water[level=0]
fill 256 52 -295 258 52 -295 minecraft:water[level=0]
fill 262 52 -295 263 52 -295 minecraft:water[level=0]
fill 256 52 -296 258 52 -296 minecraft:water[level=0]
setblock 263 52 -296 minecraft:water[level=0]
fill 256 52 -297 257 52 -297 minecraft:water[level=0]
fill 256 52 -298 257 52 -298 minecraft:water[level=0]
fill 256 52 -299 257 52 -299 minecraft:water[level=0]
fill 255 52 -300 256 52 -300 minecraft:water[level=0]
fill 255 52 -301 256 52 -301 minecraft:water[level=0]
setblock 255 52 -302 minecraft:water[level=0]
fill 261 52 -302 263 52 -302 minecraft:water[level=0]
fill 261 52 -303 263 52 -303 minecraft:water[level=0]
fill 260 52 -304 263 52 -304 minecraft:water[level=0]
fill 260 52 -305 263 52 -305 minecraft:water[level=0]
fill 261 52 -306 263 52 -306 minecraft:water[level=0]
fill 260 52 -307 262 52 -307 minecraft:water[level=0]
fill 209 52 -308 210 52 -308 minecraft:water[level=0]
fill 259 52 -308 263 52 -308 minecraft:water[level=0]
fill 210 52 -309 212 52 -309 minecraft:water[level=0]
fill 259 52 -309 263 52 -309 minecraft:water[level=0]
fill 211 52 -310 214 52 -310 minecraft:water[level=0]
fill 259 52 -310 263 52 -310 minecraft:water[level=0]
fill 211 52 -311 214 52 -311 minecraft:water[level=0]
fill 259 52 -311 263 52 -311 minecraft:water[level=0]
fill 212 52 -312 215 52 -312 minecraft:water[level=0]
fill 259 52 -312 263 52 -312 minecraft:water[level=0]
fill 212 52 -313 216 52 -313 minecraft:water[level=0]
fill 260 52 -313 263 52 -313 minecraft:water[level=0]
fill 212 52 -314 216 52 -314 minecraft:water[level=0]
fill 261 52 -314 263 52 -314 minecraft:water[level=0]
fill 214 52 -315 217 52 -315 minecraft:water[level=0]
fill 262 52 -315 263 52 -315 minecraft:water[level=0]
fill 215 52 -316 217 52 -316 minecraft:water[level=0]
setblock 263 52 -316 minecraft:water[level=0]
setblock 217 52 -317 minecraft:water[level=0]
fill 229 51 -266 231 51 -266 minecraft:water[level=0]
fill 228 51 -267 230 51 -267 minecraft:water[level=0]
fill 227 51 -268 229 51 -268 minecraft:water[level=0]
fill 226 51 -269 228 51 -269 minecraft:water[level=0]
fill 224 51 -270 227 51 -270 minecraft:water[level=0]
fill 222 51 -271 226 51 -271 minecraft:water[level=0]
setblock 224 51 -272 minecraft:water[level=0]
setblock 259 51 -291 minecraft:water[level=0]
fill 258 51 -292 259 51 -292 minecraft:water[level=0]
setblock 263 51 -292 minecraft:water[level=0]
fill 257 51 -293 258 51 -293 minecraft:water[level=0]
setblock 263 51 -293 minecraft:water[level=0]
fill 257 51 -294 258 51 -294 minecraft:water[level=0]
fill 257 51 -295 258 51 -295 minecraft:water[level=0]
fill 257 51 -296 258 51 -296 minecraft:water[level=0]
fill 256 51 -297 258 51 -297 minecraft:water[level=0]
fill 256 51 -298 258 51 -298 minecraft:water[level=0]
fill 256 51 -299 257 51 -299 minecraft:water[level=0]
setblock 256 51 -300 minecraft:water[level=0]
fill 261 51 -302 263 51 -302 minecraft:water[level=0]
fill 261 51 -303 263 51 -303 minecraft:water[level=0]
fill 260 51 -304 263 51 -304 minecraft:water[level=0]
fill 260 51 -305 263 51 -305 minecraft:water[level=0]
fill 261 51 -306 263 51 -306 minecraft:water[level=0]
fill 259 51 -307 263 51 -307 minecraft:water[level=0]
fill 259 51 -308 263 51 -308 minecraft:water[level=0]
fill 259 51 -309 263 51 -309 minecraft:water[level=0]
setblock 212 51 -310 minecraft:water[level=0]
fill 259 51 -310 263 51 -310 minecraft:water[level=0]
fill 213 51 -311 214 51 -311 minecraft:water[level=0]
fill 259 51 -311 263 51 -311 minecraft:water[level=0]
fill 214 51 -312 216 51 -312 minecraft:water[level=0]
fill 259 51 -312 263 51 -312 minecraft:water[level=0]
fill 214 51 -313 218 51 -313 minecraft:water[level=0]
fill 260 51 -313 263 51 -313 minecraft:water[level=0]
fill 215 51 -314 219 51 -314 minecraft:water[level=0]
setblock 262 51 -314 minecraft:water[level=0]
fill 215 51 -315 219 51 -315 minecraft:water[level=0]
fill 215 51 -316 217 51 -316 minecraft:water[level=0]
fill 218 51 -316 219 51 -316 minecraft:bubble_column[drag=true]
setblock 220 51 -316 minecraft:water[level=0]
fill 216 51 -317 217 51 -317 minecraft:water[level=0]
setblock 218 51 -317 minecraft:bubble_column[drag=true]
fill 219 51 -317 220 51 -317 minecraft:water[level=0]
setblock 218 51 -318 minecraft:water[level=0]
setblock 219 51 -318 minecraft:bubble_column[drag=true]
setblock 220 51 -318 minecraft:water[level=0]
setblock 231 50 -264 minecraft:water[level=0]
setblock 233 50 -264 minecraft:water[level=0]
fill 230 50 -265 232 50 -265 minecraft:water[level=0]
fill 230 50 -266 232 50 -266 minecraft:water[level=0]
fill 229 50 -267 231 50 -267 minecraft:water[level=0]
fill 228 50 -268 230 50 -268 minecraft:water[level=0]
fill 227 50 -269 229 50 -269 minecraft:water[level=0]
setblock 259 50 -291 minecraft:water[level=0]
fill 258 50 -292 259 50 -292 minecraft:water[level=0]
fill 257 50 -293 259 50 -293 minecraft:water[level=0]
fill 257 50 -294 259 50 -294 minecraft:water[level=0]
fill 257 50 -295 259 50 -295 minecraft:water[level=0]
fill 257 50 -296 258 50 -296 minecraft:water[level=0]
fill 257 50 -297 258 50 -297 minecraft:water[level=0]
fill 257 50 -298 258 50 -298 minecraft:water[level=0]
setblock 257 50 -299 minecraft:water[level=0]
fill 260 50 -307 262 50 -307 minecraft:water[level=0]
fill 260 50 -308 263 50 -308 minecraft:water[level=0]
fill 259 50 -309 262 50 -309 minecraft:water[level=0]
fill 259 50 -310 262 50 -310 minecraft:water[level=0]
fill 260 50 -311 261 50 -311 minecraft:water[level=0]
fill 217 50 -314 218 50 -314 minecraft:water[level=0]
fill 218 50 -315 220 50 -315 minecraft:water[level=0]
fill 218 50 -316 219 50 -316 minecraft:bubble_column[drag=true]
setblock 220 50 -316 minecraft:water[level=0]
setblock 221 50 -316 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=true,waterlogged=true,west=false]
setblock 218 50 -317 minecraft:bubble_column[drag=true]
fill 219 50 -317 222 50 -317 minecraft:water[level=0]
setblock 218 50 -318 minecraft:water[level=0]
setblock 219 50 -318 minecraft:bubble_column[drag=true]
fill 220 50 -318 223 50 -318 minecraft:water[level=0]
fill 233 49 -263 234 49 -263 minecraft:water[level=0]
fill 232 49 -264 234 49 -264 minecraft:water[level=0]
fill 231 49 -265 233 49 -265 minecraft:water[level=0]
fill 230 49 -266 232 49 -266 minecraft:water[level=0]
fill 230 49 -267 232 49 -267 minecraft:water[level=0]
fill 229 49 -268 231 49 -268 minecraft:water[level=0]
setblock 260 49 -290 minecraft:water[level=0]
setblock 259 49 -291 minecraft:water[level=0]
fill 258 49 -292 259 49 -292 minecraft:water[level=0]
fill 258 49 -293 259 49 -293 minecraft:water[level=0]
fill 258 49 -294 259 49 -294 minecraft:water[level=0]
fill 258 49 -295 259 49 -295 minecraft:water[level=0]
fill 258 49 -296 259 49 -296 minecraft:water[level=0]
setblock 258 49 -297 minecraft:water[level=0]
fill 257 49 -298 258 49 -298 minecraft:water[level=0]
setblock 257 49 -299 minecraft:water[level=0]
setblock 221 49 -316 minecraft:water[level=0]
fill 223 49 -317 224 49 -317 minecraft:water[level=0]
fill 222 49 -318 224 49 -318 minecraft:water[level=0]
setblock 234 48 -262 minecraft:water[level=0]
fill 233 48 -263 235 48 -263 minecraft:water[level=0]
fill 233 48 -264 234 48 -264 minecraft:water[level=0]
fill 232 48 -265 234 48 -265 minecraft:water[level=0]
fill 231 48 -266 233 48 -266 minecraft:water[level=0]
setblock 260 48 -290 minecraft:water[level=0]
fill 259 48 -291 260 48 -291 minecraft:water[level=0]
fill 258 48 -292 260 48 -292 minecraft:water[level=0]
fill 258 48 -293 259 48 -293 minecraft:water[level=0]
fill 258 48 -294 259 48 -294 minecraft:water[level=0]
fill 258 48 -295 259 48 -295 minecraft:water[level=0]
fill 258 48 -296 259 48 -296 minecraft:water[level=0]
setblock 258 48 -297 minecraft:water[level=0]
setblock 258 48 -298 minecraft:water[level=0]
fill 225 48 -317 226 48 -317 minecraft:water[level=0]
fill 225 48 -318 226 48 -318 minecraft:water[level=0]
fill 235 47 -261 236 47 -261 minecraft:water[level=0]
fill 234 47 -262 236 47 -262 minecraft:water[level=0]
fill 234 47 -263 235 47 -263 minecraft:water[level=0]
fill 233 47 -264 235 47 -264 minecraft:water[level=0]
setblock 260 47 -291 minecraft:water[level=0]
fill 259 47 -292 260 47 -292 minecraft:water[level=0]
fill 259 47 -293 260 47 -293 minecraft:water[level=0]
fill 258 47 -294 260 47 -294 minecraft:water[level=0]
fill 258 47 -295 260 47 -295 minecraft:water[level=0]
fill 258 47 -296 260 47 -296 minecraft:water[level=0]
fill 258 47 -297 259 47 -297 minecraft:water[level=0]
setblock 258 47 -298 minecraft:water[level=0]
setblock 258 47 -299 minecraft:water[level=0]
setblock 227 47 -318 minecraft:water[level=0]
setblock 236 46 -259 minecraft:water[level=0]
fill 236 46 -260 238 46 -260 minecraft:water[level=0]
fill 235 46 -261 237 46 -261 minecraft:water[level=0]
fill 235 46 -262 237 46 -262 minecraft:water[level=0]
fill 234 46 -263 236 46 -263 minecraft:water[level=0]
setblock 260 46 -292 minecraft:water[level=0]
fill 259 46 -293 260 46 -293 minecraft:water[level=0]
fill 259 46 -294 260 46 -294 minecraft:water[level=0]
fill 259 46 -295 260 46 -295 minecraft:water[level=0]
fill 259 46 -296 260 46 -296 minecraft:water[level=0]
fill 259 46 -297 260 46 -297 minecraft:water[level=0]
setblock 259 46 -298 minecraft:water[level=0]
setblock 259 46 -299 minecraft:water[level=0]
setblock 237 45 -258 minecraft:water[level=0]
fill 237 45 -259 239 45 -259 minecraft:water[level=0]
fill 236 45 -260 238 45 -260 minecraft:water[level=0]
fill 236 45 -261 238 45 -261 minecraft:water[level=0]
fill 236 45 -262 237 45 -262 minecraft:water[level=0]
setblock 260 45 -293 minecraft:water[level=0]
setblock 260 45 -294 minecraft:water[level=0]
fill 259 45 -295 260 45 -295 minecraft:water[level=0]
fill 259 45 -296 260 45 -296 minecraft:water[level=0]
fill 259 45 -297 260 45 -297 minecraft:water[level=0]
fill 259 45 -298 260 45 -298 minecraft:water[level=0]
setblock 259 45 -299 minecraft:water[level=0]
setblock 259 45 -300 minecraft:water[level=0]
forceload remove 200 -318 263 -255
tellraw @a {"text":"Campus zurueck a18 fertig.","color":"green"}
