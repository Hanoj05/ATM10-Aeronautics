setblock 117 81 -191 minecraft:air
setblock 117 81 -192 minecraft:air
setblock 117 81 -193 minecraft:air
setblock 117 81 -194 minecraft:air
setblock 117 81 -195 minecraft:air
setblock 117 81 -196 minecraft:air
setblock 117 81 -197 minecraft:air
setblock 117 81 -198 minecraft:air
setblock 117 81 -199 minecraft:air
setblock 117 81 -200 minecraft:air
setblock 118 81 -201 minecraft:air
setblock 118 81 -202 minecraft:air
setblock 118 81 -203 minecraft:air
setblock 118 81 -204 minecraft:air
setblock 118 81 -205 minecraft:air
setblock 118 81 -206 minecraft:air
setblock 118 81 -207 minecraft:air
setblock 118 81 -208 minecraft:air
setblock 119 81 -209 minecraft:air
setblock 120 81 -210 minecraft:air
setblock 121 81 -211 minecraft:air
setblock 122 81 -212 minecraft:air
setblock 123 81 -213 minecraft:air
setblock 124 81 -214 minecraft:air
setblock 125 81 -215 minecraft:air
setblock 125 81 -216 minecraft:air
setblock 126 81 -217 minecraft:air
setblock 127 81 -218 minecraft:air
setblock 128 81 -219 minecraft:air
setblock 129 81 -220 minecraft:air
setblock 130 81 -221 minecraft:air
setblock 131 81 -222 minecraft:air
setblock 132 81 -223 minecraft:air
setblock 133 81 -224 minecraft:air
setblock 134 81 -225 minecraft:air
setblock 135 81 -226 minecraft:air
fill 133 81 -236 135 81 -236 minecraft:air
fill 131 81 -237 132 81 -237 minecraft:air
fill 128 81 -238 130 81 -238 minecraft:air
fill 126 81 -239 127 81 -239 minecraft:air
fill 123 81 -240 125 81 -240 minecraft:air
fill 120 81 -241 122 81 -241 minecraft:air
fill 118 81 -242 119 81 -242 minecraft:air
fill 115 81 -243 117 81 -243 minecraft:air
fill 113 81 -244 114 81 -244 minecraft:air
fill 110 81 -245 112 81 -245 minecraft:air
setblock 109 81 -246 minecraft:air
setblock 109 81 -247 minecraft:air
setblock 108 81 -248 minecraft:air
setblock 108 81 -249 minecraft:air
setblock 72 81 -250 minecraft:air
setblock 107 81 -250 minecraft:air
setblock 73 81 -251 minecraft:air
setblock 106 81 -251 minecraft:air
setblock 74 81 -252 minecraft:air
setblock 106 81 -252 minecraft:air
setblock 74 81 -253 minecraft:air
setblock 105 81 -253 minecraft:air
setblock 75 81 -254 minecraft:air
setblock 105 81 -254 minecraft:air
setblock 117 80 -191 minecraft:white_concrete
setblock 117 80 -192 minecraft:white_concrete
setblock 117 80 -193 minecraft:white_concrete
setblock 117 80 -194 minecraft:white_concrete
setblock 117 80 -195 minecraft:white_concrete
setblock 117 80 -196 minecraft:white_concrete
setblock 117 80 -197 minecraft:white_concrete
setblock 117 80 -198 minecraft:white_concrete
setblock 117 80 -199 minecraft:white_concrete
setblock 117 80 -200 minecraft:white_concrete
setblock 118 80 -201 minecraft:white_concrete
setblock 118 80 -202 minecraft:white_concrete
setblock 118 80 -203 minecraft:white_concrete
setblock 118 80 -204 minecraft:white_concrete
setblock 118 80 -205 minecraft:white_concrete
setblock 118 80 -206 minecraft:white_concrete
setblock 118 80 -207 minecraft:white_concrete
setblock 118 80 -208 minecraft:white_concrete
setblock 119 80 -209 minecraft:white_concrete
setblock 120 80 -210 minecraft:white_concrete
setblock 121 80 -211 minecraft:white_concrete
setblock 122 80 -212 minecraft:white_concrete
setblock 123 80 -213 minecraft:white_concrete
setblock 124 80 -214 minecraft:white_concrete
setblock 125 80 -215 minecraft:white_concrete
setblock 125 80 -216 minecraft:white_concrete
setblock 126 80 -217 minecraft:white_concrete
setblock 127 80 -218 minecraft:white_concrete
setblock 128 80 -219 minecraft:white_concrete
setblock 129 80 -220 minecraft:white_concrete
setblock 130 80 -221 minecraft:white_concrete
setblock 131 80 -222 minecraft:white_concrete
setblock 132 80 -223 minecraft:white_concrete
setblock 133 80 -224 minecraft:white_concrete
setblock 134 80 -225 minecraft:white_concrete
setblock 135 80 -226 minecraft:white_concrete
fill 133 80 -236 135 80 -236 minecraft:white_concrete
fill 131 80 -237 132 80 -237 minecraft:white_concrete
fill 128 80 -238 130 80 -238 minecraft:white_concrete
fill 126 80 -239 127 80 -239 minecraft:white_concrete
fill 123 80 -240 125 80 -240 minecraft:white_concrete
fill 120 80 -241 122 80 -241 minecraft:white_concrete
fill 118 80 -242 119 80 -242 minecraft:white_concrete
fill 115 80 -243 117 80 -243 minecraft:white_concrete
fill 113 80 -244 114 80 -244 minecraft:white_concrete
fill 110 80 -245 112 80 -245 minecraft:white_concrete
setblock 109 80 -246 minecraft:white_concrete
setblock 109 80 -247 minecraft:white_concrete
setblock 108 80 -248 minecraft:white_concrete
setblock 108 80 -249 minecraft:white_concrete
setblock 72 80 -250 minecraft:white_concrete
setblock 107 80 -250 minecraft:white_concrete
setblock 73 80 -251 minecraft:white_concrete
setblock 106 80 -251 minecraft:white_concrete
setblock 74 80 -252 minecraft:white_concrete
setblock 106 80 -252 minecraft:white_concrete
setblock 74 80 -253 minecraft:white_concrete
setblock 105 80 -253 minecraft:white_concrete
setblock 75 80 -254 minecraft:white_concrete
setblock 105 80 -254 minecraft:white_concrete
setblock 117 64 -191 minecraft:air
fill 119 64 -191 122 64 -191 minecraft:air
fill 124 64 -191 127 64 -191 minecraft:air
fill 129 64 -191 132 64 -191 minecraft:air
setblock 135 64 -191 minecraft:air
fill 117 64 -192 133 64 -192 minecraft:air
setblock 135 64 -192 minecraft:air
fill 117 64 -193 133 64 -193 minecraft:air
fill 117 64 -194 134 64 -194 minecraft:air
fill 117 64 -195 134 64 -195 minecraft:air
setblock 117 64 -196 minecraft:air
fill 119 64 -196 122 64 -196 minecraft:air
fill 124 64 -196 127 64 -196 minecraft:air
fill 129 64 -196 132 64 -196 minecraft:air
fill 134 64 -196 135 64 -196 minecraft:air
fill 117 64 -197 135 64 -197 minecraft:air
fill 117 64 -198 133 64 -198 minecraft:air
fill 117 64 -199 130 64 -199 minecraft:air
fill 117 64 -200 128 64 -200 minecraft:air
setblock 133 64 -200 minecraft:air
fill 119 64 -201 122 64 -201 minecraft:air
fill 124 64 -201 125 64 -201 minecraft:air
setblock 131 64 -201 minecraft:air
fill 118 64 -202 123 64 -202 minecraft:air
setblock 126 64 -202 minecraft:air
fill 118 64 -203 121 64 -203 minecraft:air
setblock 131 64 -203 minecraft:air
setblock 134 64 -203 minecraft:air
fill 117 64 -204 119 64 -204 minecraft:air
setblock 129 64 -204 minecraft:air
setblock 116 64 -205 minecraft:air
setblock 122 64 -205 minecraft:air
setblock 124 64 -205 minecraft:air
fill 134 64 -205 135 64 -205 minecraft:air
setblock 119 64 -206 minecraft:air
setblock 132 64 -206 minecraft:air
fill 134 64 -206 135 64 -206 minecraft:air
setblock 127 64 -207 minecraft:air
fill 130 64 -207 135 64 -207 minecraft:air
setblock 120 64 -208 minecraft:air
setblock 122 64 -208 minecraft:air
fill 128 64 -208 135 64 -208 minecraft:air
fill 125 64 -209 135 64 -209 minecraft:air
fill 123 64 -210 135 64 -210 minecraft:air
fill 121 64 -211 122 64 -211 minecraft:air
fill 124 64 -211 127 64 -211 minecraft:air
fill 129 64 -211 132 64 -211 minecraft:air
fill 134 64 -211 135 64 -211 minecraft:air
fill 119 64 -212 135 64 -212 minecraft:air
fill 122 64 -213 135 64 -213 minecraft:air
fill 123 64 -214 135 64 -214 minecraft:air
fill 124 64 -215 135 64 -215 minecraft:air
fill 125 64 -216 127 64 -216 minecraft:air
fill 129 64 -216 132 64 -216 minecraft:air
fill 134 64 -216 135 64 -216 minecraft:air
fill 126 64 -217 135 64 -217 minecraft:air
fill 127 64 -218 135 64 -218 minecraft:air
fill 128 64 -219 135 64 -219 minecraft:air
fill 129 64 -220 135 64 -220 minecraft:air
fill 130 64 -221 135 64 -221 minecraft:air
fill 131 64 -222 135 64 -222 minecraft:air
fill 132 64 -223 135 64 -223 minecraft:air
fill 133 64 -224 135 64 -224 minecraft:air
fill 134 64 -225 135 64 -225 minecraft:air
setblock 135 64 -226 minecraft:air
fill 133 64 -236 135 64 -236 minecraft:air
fill 131 64 -237 135 64 -237 minecraft:air
fill 128 64 -238 135 64 -238 minecraft:air
fill 125 64 -239 135 64 -239 minecraft:air
fill 123 64 -240 135 64 -240 minecraft:air
fill 120 64 -241 135 64 -241 minecraft:air
fill 118 64 -242 135 64 -242 minecraft:air
fill 115 64 -243 135 64 -243 minecraft:air
fill 112 64 -244 135 64 -244 minecraft:air
fill 110 64 -245 135 64 -245 minecraft:air
fill 109 64 -246 112 64 -246 minecraft:air
fill 114 64 -246 117 64 -246 minecraft:air
fill 119 64 -246 122 64 -246 minecraft:air
fill 124 64 -246 127 64 -246 minecraft:air
fill 129 64 -246 132 64 -246 minecraft:air
fill 134 64 -246 135 64 -246 minecraft:air
fill 109 64 -247 134 64 -247 minecraft:air
fill 108 64 -248 134 64 -248 minecraft:air
setblock 72 64 -249 minecraft:air
fill 107 64 -249 133 64 -249 minecraft:air
setblock 72 64 -250 minecraft:air
fill 107 64 -250 133 64 -250 minecraft:air
setblock 135 64 -250 minecraft:air
setblock 72 64 -251 minecraft:air
fill 106 64 -251 107 64 -251 minecraft:air
fill 109 64 -251 112 64 -251 minecraft:air
fill 114 64 -251 117 64 -251 minecraft:air
fill 119 64 -251 122 64 -251 minecraft:air
fill 124 64 -251 127 64 -251 minecraft:air
fill 129 64 -251 132 64 -251 minecraft:air
setblock 135 64 -251 minecraft:air
fill 72 64 -252 74 64 -252 minecraft:air
fill 106 64 -252 131 64 -252 minecraft:air
fill 134 64 -252 135 64 -252 minecraft:air
fill 72 64 -253 75 64 -253 minecraft:air
fill 105 64 -253 115 64 -253 minecraft:air
fill 117 64 -253 131 64 -253 minecraft:air
fill 133 64 -253 135 64 -253 minecraft:air
fill 72 64 -254 76 64 -254 minecraft:air
fill 105 64 -254 125 64 -254 minecraft:air
fill 127 64 -254 130 64 -254 minecraft:air
fill 133 64 -254 135 64 -254 minecraft:air
setblock 135 63 -191 minecraft:air
setblock 135 63 -192 minecraft:air
setblock 135 63 -250 minecraft:air
setblock 135 63 -251 minecraft:air
fill 134 63 -252 135 63 -252 minecraft:air
fill 133 63 -253 135 63 -253 minecraft:air
fill 133 63 -254 135 63 -254 minecraft:air
setblock 135 62 -191 minecraft:air
setblock 135 62 -192 minecraft:air
setblock 135 62 -250 minecraft:air
setblock 135 62 -251 minecraft:air
fill 134 62 -252 135 62 -252 minecraft:air
fill 133 62 -253 135 62 -253 minecraft:air
fill 133 62 -254 135 62 -254 minecraft:air
setblock 135 61 -191 minecraft:air
setblock 135 61 -192 minecraft:air
setblock 135 61 -250 minecraft:air
setblock 135 61 -251 minecraft:air
fill 134 61 -252 135 61 -252 minecraft:air
fill 133 61 -253 135 61 -253 minecraft:air
fill 133 61 -254 135 61 -254 minecraft:air
setblock 135 60 -191 minecraft:air
setblock 135 60 -192 minecraft:air
setblock 135 60 -250 minecraft:air
setblock 135 60 -251 minecraft:air
fill 134 60 -252 135 60 -252 minecraft:air
fill 133 60 -253 135 60 -253 minecraft:air
fill 133 60 -254 135 60 -254 minecraft:air
setblock 135 59 -191 minecraft:air
setblock 135 59 -192 minecraft:air
setblock 135 59 -250 minecraft:air
setblock 135 59 -251 minecraft:air
fill 134 59 -252 135 59 -252 minecraft:air
fill 133 59 -253 135 59 -253 minecraft:air
fill 133 59 -254 135 59 -254 minecraft:air
setblock 111 58 -191 minecraft:air
fill 117 58 -191 121 58 -191 minecraft:air
fill 117 58 -192 121 58 -192 minecraft:air
fill 117 58 -193 121 58 -193 minecraft:air
fill 117 58 -194 121 58 -194 minecraft:air
fill 116 58 -195 121 58 -195 minecraft:air
fill 116 58 -196 121 58 -196 minecraft:air
fill 116 58 -197 121 58 -197 minecraft:air
fill 129 58 -197 130 58 -197 minecraft:air
fill 117 58 -198 130 58 -198 minecraft:air
fill 116 58 -199 128 58 -199 minecraft:air
fill 116 58 -200 128 58 -200 minecraft:air
fill 117 58 -201 128 58 -201 minecraft:air
fill 133 58 -201 134 58 -201 minecraft:water[level=0]
fill 117 58 -202 124 58 -202 minecraft:air
fill 126 58 -202 128 58 -202 minecraft:air
fill 133 58 -202 134 58 -202 minecraft:water[level=0]
fill 117 58 -203 120 58 -203 minecraft:air
fill 132 58 -203 135 58 -203 minecraft:water[level=0]
setblock 77 58 -204 minecraft:air
fill 117 58 -204 120 58 -204 minecraft:air
fill 132 58 -204 135 58 -204 minecraft:water[level=0]
fill 95 58 -205 99 58 -205 minecraft:air
fill 117 58 -205 120 58 -205 minecraft:air
fill 132 58 -205 135 58 -205 minecraft:water[level=0]
fill 94 58 -206 100 58 -206 minecraft:air
fill 117 58 -206 120 58 -206 minecraft:air
fill 133 58 -206 135 58 -206 minecraft:water[level=0]
fill 95 58 -207 101 58 -207 minecraft:air
fill 117 58 -207 120 58 -207 minecraft:air
fill 133 58 -207 135 58 -207 minecraft:water[level=0]
fill 95 58 -208 102 58 -208 minecraft:air
fill 117 58 -208 120 58 -208 minecraft:air
fill 133 58 -208 135 58 -208 minecraft:water[level=0]
fill 96 58 -209 102 58 -209 minecraft:air
fill 133 58 -209 135 58 -209 minecraft:water[level=0]
fill 97 58 -210 102 58 -210 minecraft:air
fill 133 58 -210 135 58 -210 minecraft:water[level=0]
fill 95 58 -211 96 58 -211 minecraft:air
fill 98 58 -211 102 58 -211 minecraft:air
setblock 116 58 -211 minecraft:air
setblock 133 58 -211 minecraft:water[level=0]
fill 93 58 -212 95 58 -212 minecraft:air
fill 97 58 -212 102 58 -212 minecraft:air
fill 116 58 -212 117 58 -212 minecraft:air
setblock 133 58 -212 minecraft:water[level=0]
fill 93 58 -213 94 58 -213 minecraft:air
fill 97 58 -213 102 58 -213 minecraft:air
setblock 116 58 -213 minecraft:air
fill 118 58 -213 119 58 -213 minecraft:air
setblock 126 58 -213 minecraft:air
fill 132 58 -213 133 58 -213 minecraft:water[level=0]
fill 92 58 -214 101 58 -214 minecraft:air
setblock 118 58 -214 minecraft:air
setblock 120 58 -214 minecraft:air
fill 125 58 -214 126 58 -214 minecraft:air
fill 132 58 -214 133 58 -214 minecraft:water[level=0]
fill 93 58 -215 101 58 -215 minecraft:air
fill 118 58 -215 126 58 -215 minecraft:air
fill 132 58 -215 133 58 -215 minecraft:water[level=0]
fill 93 58 -216 100 58 -216 minecraft:air
fill 118 58 -216 123 58 -216 minecraft:air
fill 131 58 -216 133 58 -216 minecraft:water[level=0]
fill 94 58 -217 99 58 -217 minecraft:air
fill 131 58 -217 133 58 -217 minecraft:water[level=0]
fill 131 58 -218 132 58 -218 minecraft:water[level=0]
fill 130 58 -219 132 58 -219 minecraft:water[level=0]
fill 130 58 -220 131 58 -220 minecraft:water[level=0]
fill 129 58 -221 131 58 -221 minecraft:water[level=0]
fill 80 58 -222 82 58 -222 minecraft:air
fill 128 58 -222 130 58 -222 minecraft:water[level=0]
fill 78 58 -223 82 58 -223 minecraft:air
fill 128 58 -223 129 58 -223 minecraft:water[level=0]
fill 79 58 -224 82 58 -224 minecraft:air
fill 127 58 -224 129 58 -224 minecraft:water[level=0]
fill 126 58 -225 128 58 -225 minecraft:water[level=0]
fill 124 58 -226 127 58 -226 minecraft:water[level=0]
fill 122 58 -227 126 58 -227 minecraft:water[level=0]
fill 120 58 -228 124 58 -228 minecraft:water[level=0]
fill 119 58 -229 122 58 -229 minecraft:water[level=0]
setblock 111 57 -191 minecraft:air
fill 116 57 -195 118 57 -195 minecraft:air
fill 116 57 -196 121 57 -196 minecraft:air
fill 116 57 -197 121 57 -197 minecraft:air
setblock 125 57 -197 minecraft:air
fill 116 57 -198 128 57 -198 minecraft:air
fill 116 57 -199 128 57 -199 minecraft:air
fill 116 57 -200 128 57 -200 minecraft:air
fill 117 57 -201 128 57 -201 minecraft:air
fill 106 57 -202 107 57 -202 minecraft:air
fill 117 57 -202 129 57 -202 minecraft:air
setblock 134 57 -202 minecraft:water[level=0]
fill 117 57 -203 120 57 -203 minecraft:air
fill 134 57 -203 135 57 -203 minecraft:water[level=0]
fill 105 57 -204 106 57 -204 minecraft:air
fill 117 57 -204 120 57 -204 minecraft:air
fill 133 57 -204 134 57 -204 minecraft:water[level=0]
setblock 97 57 -205 minecraft:air
fill 104 57 -205 106 57 -205 minecraft:air
fill 117 57 -205 120 57 -205 minecraft:air
setblock 133 57 -205 minecraft:water[level=0]
fill 96 57 -206 100 57 -206 minecraft:air
fill 102 57 -206 106 57 -206 minecraft:air
fill 117 57 -206 120 57 -206 minecraft:air
setblock 133 57 -206 minecraft:water[level=0]
fill 96 57 -207 105 57 -207 minecraft:air
fill 116 57 -207 120 57 -207 minecraft:air
fill 133 57 -207 135 57 -207 minecraft:water[level=0]
fill 96 57 -208 103 57 -208 minecraft:air
fill 115 57 -208 120 57 -208 minecraft:air
fill 133 57 -208 135 57 -208 minecraft:water[level=0]
fill 97 57 -209 102 57 -209 minecraft:air
fill 115 57 -209 117 57 -209 minecraft:air
fill 133 57 -209 135 57 -209 minecraft:water[level=0]
fill 94 57 -210 102 57 -210 minecraft:air
fill 115 57 -210 117 57 -210 minecraft:air
fill 133 57 -210 135 57 -210 minecraft:water[level=0]
fill 93 57 -211 102 57 -211 minecraft:air
fill 115 57 -211 117 57 -211 minecraft:air
fill 133 57 -211 134 57 -211 minecraft:water[level=0]
fill 92 57 -212 102 57 -212 minecraft:air
fill 133 57 -212 134 57 -212 minecraft:water[level=0]
fill 92 57 -213 102 57 -213 minecraft:air
fill 133 57 -213 134 57 -213 minecraft:water[level=0]
fill 92 57 -214 101 57 -214 minecraft:air
fill 132 57 -214 134 57 -214 minecraft:water[level=0]
fill 92 57 -215 101 57 -215 minecraft:air
fill 132 57 -215 134 57 -215 minecraft:water[level=0]
fill 92 57 -216 100 57 -216 minecraft:air
fill 132 57 -216 133 57 -216 minecraft:water[level=0]
fill 93 57 -217 99 57 -217 minecraft:air
fill 131 57 -217 133 57 -217 minecraft:water[level=0]
fill 94 57 -218 98 57 -218 minecraft:air
fill 131 57 -218 133 57 -218 minecraft:water[level=0]
fill 131 57 -219 132 57 -219 minecraft:water[level=0]
fill 130 57 -220 132 57 -220 minecraft:water[level=0]
setblock 131 57 -221 minecraft:water[level=0]
fill 79 57 -222 82 57 -222 minecraft:air
fill 130 57 -222 131 57 -222 minecraft:water[level=0]
fill 78 57 -223 82 57 -223 minecraft:air
fill 129 57 -223 130 57 -223 minecraft:water[level=0]
fill 78 57 -224 80 57 -224 minecraft:air
fill 128 57 -224 130 57 -224 minecraft:water[level=0]
fill 127 57 -225 129 57 -225 minecraft:water[level=0]
fill 125 57 -226 128 57 -226 minecraft:water[level=0]
fill 124 57 -227 127 57 -227 minecraft:water[level=0]
fill 121 57 -228 126 57 -228 minecraft:water[level=0]
setblock 114 57 -229 minecraft:water[level=0]
fill 119 57 -229 124 57 -229 minecraft:water[level=0]
fill 114 57 -230 121 57 -230 minecraft:water[level=0]
fill 124 56 -196 125 56 -196 minecraft:air
fill 124 56 -197 125 56 -197 minecraft:air
setblock 116 56 -198 minecraft:air
fill 121 56 -198 129 56 -198 minecraft:air
fill 106 56 -199 107 56 -199 minecraft:air
setblock 116 56 -199 minecraft:air
fill 118 56 -199 129 56 -199 minecraft:air
fill 106 56 -200 107 56 -200 minecraft:air
fill 116 56 -200 129 56 -200 minecraft:air
fill 106 56 -201 107 56 -201 minecraft:air
fill 118 56 -201 129 56 -201 minecraft:air
fill 106 56 -202 108 56 -202 minecraft:air
fill 117 56 -202 129 56 -202 minecraft:air
fill 105 56 -203 107 56 -203 minecraft:air
fill 117 56 -203 120 56 -203 minecraft:air
setblock 135 56 -203 minecraft:water[level=0]
fill 104 56 -204 107 56 -204 minecraft:air
fill 117 56 -204 120 56 -204 minecraft:air
setblock 134 56 -204 minecraft:water[level=0]
fill 102 56 -205 107 56 -205 minecraft:air
fill 117 56 -205 120 56 -205 minecraft:air
setblock 98 56 -206 minecraft:air
fill 101 56 -206 106 56 -206 minecraft:air
fill 117 56 -206 120 56 -206 minecraft:air
fill 97 56 -207 105 56 -207 minecraft:air
fill 115 56 -207 120 56 -207 minecraft:air
fill 97 56 -208 104 56 -208 minecraft:air
fill 115 56 -208 120 56 -208 minecraft:air
setblock 133 56 -208 minecraft:water[level=0]
fill 96 56 -209 103 56 -209 minecraft:air
fill 115 56 -209 118 56 -209 minecraft:air
fill 133 56 -209 135 56 -209 minecraft:water[level=0]
fill 94 56 -210 102 56 -210 minecraft:air
fill 115 56 -210 118 56 -210 minecraft:air
fill 133 56 -210 135 56 -210 minecraft:water[level=0]
fill 93 56 -211 102 56 -211 minecraft:air
fill 115 56 -211 117 56 -211 minecraft:air
fill 133 56 -211 135 56 -211 minecraft:water[level=0]
fill 92 56 -212 102 56 -212 minecraft:air
setblock 113 56 -212 minecraft:air
fill 133 56 -212 135 56 -212 minecraft:water[level=0]
fill 92 56 -213 102 56 -213 minecraft:air
setblock 113 56 -213 minecraft:air
fill 133 56 -213 135 56 -213 minecraft:water[level=0]
fill 91 56 -214 101 56 -214 minecraft:air
fill 112 56 -214 114 56 -214 minecraft:air
fill 133 56 -214 134 56 -214 minecraft:water[level=0]
fill 91 56 -215 101 56 -215 minecraft:air
fill 112 56 -215 114 56 -215 minecraft:air
fill 132 56 -215 134 56 -215 minecraft:water[level=0]
fill 92 56 -216 100 56 -216 minecraft:air
fill 112 56 -216 115 56 -216 minecraft:air
fill 132 56 -216 134 56 -216 minecraft:water[level=0]
fill 92 56 -217 99 56 -217 minecraft:air
fill 112 56 -217 115 56 -217 minecraft:air
fill 132 56 -217 133 56 -217 minecraft:water[level=0]
fill 94 56 -218 98 56 -218 minecraft:air
fill 132 56 -218 133 56 -218 minecraft:water[level=0]
fill 131 56 -219 133 56 -219 minecraft:water[level=0]
setblock 132 56 -220 minecraft:water[level=0]
setblock 132 56 -221 minecraft:water[level=0]
fill 77 56 -222 82 56 -222 minecraft:air
fill 130 56 -222 131 56 -222 minecraft:water[level=0]
fill 77 56 -223 82 56 -223 minecraft:air
fill 129 56 -223 131 56 -223 minecraft:water[level=0]
fill 78 56 -224 79 56 -224 minecraft:air
fill 129 56 -224 130 56 -224 minecraft:water[level=0]
fill 128 56 -225 130 56 -225 minecraft:water[level=0]
fill 126 56 -226 127 56 -226 minecraft:water[level=0]
fill 125 56 -227 126 56 -227 minecraft:water[level=0]
fill 124 56 -228 125 56 -228 minecraft:water[level=0]
setblock 114 56 -229 minecraft:water[level=0]
fill 119 56 -229 124 56 -229 minecraft:water[level=0]
fill 114 56 -230 123 56 -230 minecraft:water[level=0]
fill 115 56 -231 121 56 -231 minecraft:water[level=0]
setblock 124 55 -196 minecraft:air
fill 106 55 -197 107 55 -197 minecraft:air
fill 106 55 -198 107 55 -198 minecraft:air
fill 121 55 -198 129 55 -198 minecraft:air
fill 106 55 -199 107 55 -199 minecraft:air
fill 121 55 -199 129 55 -199 minecraft:air
fill 105 55 -200 108 55 -200 minecraft:air
fill 121 55 -200 130 55 -200 minecraft:air
fill 105 55 -201 108 55 -201 minecraft:air
fill 121 55 -201 130 55 -201 minecraft:air
fill 105 55 -202 108 55 -202 minecraft:air
fill 117 55 -202 129 55 -202 minecraft:air
fill 105 55 -203 108 55 -203 minecraft:air
fill 117 55 -203 120 55 -203 minecraft:air
fill 104 55 -204 107 55 -204 minecraft:air
fill 117 55 -204 121 55 -204 minecraft:air
fill 102 55 -205 107 55 -205 minecraft:air
fill 117 55 -205 121 55 -205 minecraft:air
fill 100 55 -206 106 55 -206 minecraft:air
fill 117 55 -206 120 55 -206 minecraft:air
fill 98 55 -207 106 55 -207 minecraft:air
fill 115 55 -207 120 55 -207 minecraft:air
fill 97 55 -208 104 55 -208 minecraft:air
fill 116 55 -208 120 55 -208 minecraft:air
fill 95 55 -209 103 55 -209 minecraft:air
fill 116 55 -209 118 55 -209 minecraft:air
setblock 133 55 -209 minecraft:water[level=0]
setblock 135 55 -209 minecraft:water[level=0]
fill 93 55 -210 102 55 -210 minecraft:air
fill 113 55 -210 118 55 -210 minecraft:air
fill 134 55 -210 135 55 -210 minecraft:water[level=0]
fill 92 55 -211 102 55 -211 minecraft:air
fill 113 55 -211 117 55 -211 minecraft:air
fill 133 55 -211 135 55 -211 minecraft:water[level=0]
fill 92 55 -212 102 55 -212 minecraft:air
fill 113 55 -212 116 55 -212 minecraft:air
fill 133 55 -212 135 55 -212 minecraft:water[level=0]
fill 91 55 -213 102 55 -213 minecraft:air
fill 113 55 -213 116 55 -213 minecraft:air
fill 133 55 -213 135 55 -213 minecraft:water[level=0]
fill 91 55 -214 101 55 -214 minecraft:air
fill 112 55 -214 115 55 -214 minecraft:air
fill 133 55 -214 135 55 -214 minecraft:water[level=0]
fill 91 55 -215 101 55 -215 minecraft:air
fill 112 55 -215 115 55 -215 minecraft:air
fill 133 55 -215 134 55 -215 minecraft:water[level=0]
fill 92 55 -216 100 55 -216 minecraft:air
fill 112 55 -216 115 55 -216 minecraft:air
fill 132 55 -216 134 55 -216 minecraft:water[level=0]
fill 92 55 -217 99 55 -217 minecraft:air
fill 112 55 -217 116 55 -217 minecraft:air
fill 132 55 -217 134 55 -217 minecraft:water[level=0]
fill 94 55 -218 98 55 -218 minecraft:air
fill 114 55 -218 116 55 -218 minecraft:air
fill 132 55 -218 133 55 -218 minecraft:water[level=0]
setblock 116 55 -219 minecraft:air
fill 132 55 -219 133 55 -219 minecraft:water[level=0]
fill 132 55 -220 133 55 -220 minecraft:water[level=0]
fill 79 55 -221 80 55 -221 minecraft:air
setblock 132 55 -221 minecraft:water[level=0]
fill 75 55 -222 81 55 -222 minecraft:air
fill 130 55 -222 132 55 -222 minecraft:water[level=0]
fill 75 55 -223 81 55 -223 minecraft:air
fill 130 55 -223 131 55 -223 minecraft:water[level=0]
setblock 76 55 -224 minecraft:air
fill 129 55 -224 131 55 -224 minecraft:water[level=0]
fill 128 55 -225 129 55 -225 minecraft:water[level=0]
setblock 127 55 -226 minecraft:water[level=0]
fill 122 55 -229 123 55 -229 minecraft:water[level=0]
fill 114 55 -230 122 55 -230 minecraft:water[level=0]
fill 115 55 -231 122 55 -231 minecraft:water[level=0]
setblock 105 54 -191 minecraft:air
setblock 105 54 -192 minecraft:air
fill 105 54 -193 106 54 -193 minecraft:air
fill 105 54 -194 106 54 -194 minecraft:air
fill 105 54 -195 106 54 -195 minecraft:air
setblock 106 54 -196 minecraft:air
fill 105 54 -197 107 54 -197 minecraft:air
fill 105 54 -198 107 54 -198 minecraft:air
setblock 124 54 -198 minecraft:air
fill 126 54 -198 129 54 -198 minecraft:air
fill 105 54 -199 108 54 -199 minecraft:air
fill 123 54 -199 129 54 -199 minecraft:air
fill 105 54 -200 108 54 -200 minecraft:air
fill 123 54 -200 130 54 -200 minecraft:air
fill 105 54 -201 108 54 -201 minecraft:air
fill 124 54 -201 130 54 -201 minecraft:air
fill 105 54 -202 108 54 -202 minecraft:air
setblock 124 54 -202 minecraft:air
fill 106 54 -203 108 54 -203 minecraft:air
fill 104 54 -204 107 54 -204 minecraft:air
fill 102 54 -205 107 54 -205 minecraft:air
fill 117 54 -205 120 54 -205 minecraft:air
fill 100 54 -206 106 54 -206 minecraft:air
fill 117 54 -206 120 54 -206 minecraft:air
fill 98 54 -207 105 54 -207 minecraft:air
fill 115 54 -207 120 54 -207 minecraft:air
fill 97 54 -208 104 54 -208 minecraft:air
fill 117 54 -208 119 54 -208 minecraft:air
setblock 121 54 -208 minecraft:air
fill 95 54 -209 103 54 -209 minecraft:air
fill 116 54 -209 118 54 -209 minecraft:air
fill 93 54 -210 101 54 -210 minecraft:air
fill 113 54 -210 118 54 -210 minecraft:air
setblock 135 54 -210 minecraft:water[level=0]
fill 92 54 -211 101 54 -211 minecraft:air
fill 113 54 -211 117 54 -211 minecraft:air
fill 133 54 -211 135 54 -211 minecraft:water[level=0]
fill 92 54 -212 101 54 -212 minecraft:air
fill 113 54 -212 116 54 -212 minecraft:air
fill 133 54 -212 135 54 -212 minecraft:water[level=0]
fill 91 54 -213 101 54 -213 minecraft:air
fill 113 54 -213 116 54 -213 minecraft:air
fill 133 54 -213 135 54 -213 minecraft:water[level=0]
fill 91 54 -214 101 54 -214 minecraft:air
fill 112 54 -214 115 54 -214 minecraft:air
fill 117 54 -214 119 54 -214 minecraft:air
fill 133 54 -214 135 54 -214 minecraft:water[level=0]
fill 91 54 -215 100 54 -215 minecraft:air
fill 112 54 -215 115 54 -215 minecraft:air
fill 117 54 -215 119 54 -215 minecraft:air
fill 133 54 -215 135 54 -215 minecraft:water[level=0]
fill 92 54 -216 100 54 -216 minecraft:air
fill 112 54 -216 119 54 -216 minecraft:air
fill 133 54 -216 134 54 -216 minecraft:water[level=0]
fill 92 54 -217 99 54 -217 minecraft:air
fill 112 54 -217 118 54 -217 minecraft:air
fill 133 54 -217 134 54 -217 minecraft:water[level=0]
fill 94 54 -218 97 54 -218 minecraft:air
fill 114 54 -218 118 54 -218 minecraft:air
fill 133 54 -218 134 54 -218 minecraft:water[level=0]
fill 114 54 -219 119 54 -219 minecraft:air
setblock 133 54 -219 minecraft:water[level=0]
fill 116 54 -220 119 54 -220 minecraft:air
fill 132 54 -220 133 54 -220 minecraft:water[level=0]
fill 76 54 -221 80 54 -221 minecraft:air
fill 116 54 -221 119 54 -221 minecraft:air
fill 132 54 -221 133 54 -221 minecraft:water[level=0]
fill 73 54 -222 80 54 -222 minecraft:air
fill 131 54 -222 132 54 -222 minecraft:water[level=0]
fill 73 54 -223 78 54 -223 minecraft:air
fill 130 54 -223 132 54 -223 minecraft:water[level=0]
setblock 74 54 -224 minecraft:air
setblock 130 54 -224 minecraft:water[level=0]
setblock 115 54 -230 minecraft:water[level=0]
fill 121 54 -230 122 54 -230 minecraft:water[level=0]
fill 115 54 -231 121 54 -231 minecraft:water[level=0]
fill 116 54 -232 120 54 -232 minecraft:water[level=0]
fill 105 53 -191 106 53 -191 minecraft:air
fill 105 53 -192 106 53 -192 minecraft:air
fill 105 53 -193 106 53 -193 minecraft:air
fill 105 53 -194 106 53 -194 minecraft:air
fill 105 53 -195 106 53 -195 minecraft:air
setblock 106 53 -196 minecraft:air
fill 105 53 -197 107 53 -197 minecraft:air
fill 105 53 -198 107 53 -198 minecraft:air
fill 105 53 -199 108 53 -199 minecraft:air
fill 106 53 -200 108 53 -200 minecraft:air
fill 106 53 -201 108 53 -201 minecraft:air
fill 106 53 -202 108 53 -202 minecraft:air
fill 106 53 -203 107 53 -203 minecraft:air
fill 105 53 -204 106 53 -204 minecraft:air
fill 104 53 -205 106 53 -205 minecraft:air
fill 101 53 -206 106 53 -206 minecraft:air
fill 99 53 -207 104 53 -207 minecraft:air
fill 97 53 -208 104 53 -208 minecraft:air
fill 115 53 -208 117 53 -208 minecraft:air
fill 96 53 -209 102 53 -209 minecraft:air
fill 115 53 -209 117 53 -209 minecraft:air
fill 94 53 -210 100 53 -210 minecraft:air
fill 113 53 -210 117 53 -210 minecraft:air
setblock 135 53 -210 minecraft:water[level=0]
fill 93 53 -211 99 53 -211 minecraft:air
fill 113 53 -211 117 53 -211 minecraft:air
fill 134 53 -211 135 53 -211 minecraft:water[level=0]
fill 92 53 -212 98 53 -212 minecraft:air
fill 113 53 -212 116 53 -212 minecraft:air
fill 133 53 -212 135 53 -212 minecraft:water[level=0]
fill 92 53 -213 97 53 -213 minecraft:air
fill 113 53 -213 116 53 -213 minecraft:air
fill 133 53 -213 135 53 -213 minecraft:water[level=0]
fill 92 53 -214 99 53 -214 minecraft:air
fill 112 53 -214 115 53 -214 minecraft:air
fill 117 53 -214 119 53 -214 minecraft:air
fill 133 53 -214 135 53 -214 minecraft:water[level=0]
fill 92 53 -215 99 53 -215 minecraft:air
fill 112 53 -215 119 53 -215 minecraft:air
fill 133 53 -215 135 53 -215 minecraft:water[level=0]
fill 92 53 -216 99 53 -216 minecraft:air
fill 112 53 -216 119 53 -216 minecraft:air
fill 133 53 -216 135 53 -216 minecraft:water[level=0]
fill 93 53 -217 98 53 -217 minecraft:air
fill 112 53 -217 118 53 -217 minecraft:air
fill 133 53 -217 134 53 -217 minecraft:water[level=0]
fill 95 53 -218 96 53 -218 minecraft:air
fill 114 53 -218 118 53 -218 minecraft:air
fill 133 53 -218 134 53 -218 minecraft:water[level=0]
fill 114 53 -219 119 53 -219 minecraft:air
fill 133 53 -219 134 53 -219 minecraft:water[level=0]
fill 78 53 -220 79 53 -220 minecraft:air
fill 116 53 -220 119 53 -220 minecraft:air
fill 132 53 -220 134 53 -220 minecraft:water[level=0]
fill 74 53 -221 79 53 -221 minecraft:air
fill 116 53 -221 119 53 -221 minecraft:air
fill 132 53 -221 133 53 -221 minecraft:water[level=0]
fill 72 53 -222 79 53 -222 minecraft:air
fill 117 53 -222 120 53 -222 minecraft:air
fill 131 53 -222 133 53 -222 minecraft:water[level=0]
fill 72 53 -223 75 53 -223 minecraft:air
fill 117 53 -223 120 53 -223 minecraft:air
setblock 131 53 -223 minecraft:water[level=0]
setblock 72 53 -224 minecraft:air
fill 117 53 -224 120 53 -224 minecraft:air
fill 117 53 -225 120 53 -225 minecraft:air
fill 117 53 -226 120 53 -226 minecraft:air
setblock 119 53 -227 minecraft:air
fill 116 53 -231 120 53 -231 minecraft:water[level=0]
fill 116 53 -232 118 53 -232 minecraft:water[level=0]
fill 105 52 -191 106 52 -191 minecraft:air
fill 105 52 -192 106 52 -192 minecraft:air
fill 105 52 -193 106 52 -193 minecraft:air
fill 105 52 -194 106 52 -194 minecraft:air
fill 105 52 -195 106 52 -195 minecraft:air
fill 105 52 -197 107 52 -197 minecraft:air
fill 106 52 -198 107 52 -198 minecraft:air
fill 106 52 -199 107 52 -199 minecraft:air
fill 106 52 -200 107 52 -200 minecraft:air
fill 98 52 -208 100 52 -208 minecraft:air
fill 97 52 -209 100 52 -209 minecraft:air
fill 95 52 -210 99 52 -210 minecraft:air
fill 113 52 -210 115 52 -210 minecraft:air
fill 94 52 -211 98 52 -211 minecraft:air
fill 113 52 -211 115 52 -211 minecraft:air
setblock 135 52 -211 minecraft:water[level=0]
fill 93 52 -212 97 52 -212 minecraft:air
fill 113 52 -212 115 52 -212 minecraft:air
fill 134 52 -212 135 52 -212 minecraft:water[level=0]
fill 92 52 -213 95 52 -213 minecraft:air
fill 113 52 -213 115 52 -213 minecraft:air
fill 133 52 -213 135 52 -213 minecraft:water[level=0]
fill 92 52 -214 95 52 -214 minecraft:air
fill 112 52 -214 119 52 -214 minecraft:air
fill 133 52 -214 135 52 -214 minecraft:water[level=0]
fill 92 52 -215 95 52 -215 minecraft:air
fill 112 52 -215 119 52 -215 minecraft:air
fill 133 52 -215 135 52 -215 minecraft:water[level=0]
fill 93 52 -216 96 52 -216 minecraft:air
fill 112 52 -216 119 52 -216 minecraft:air
fill 133 52 -216 135 52 -216 minecraft:water[level=0]
fill 94 52 -217 95 52 -217 minecraft:air
fill 112 52 -217 119 52 -217 minecraft:air
fill 133 52 -217 135 52 -217 minecraft:water[level=0]
fill 114 52 -218 119 52 -218 minecraft:air
fill 133 52 -218 134 52 -218 minecraft:water[level=0]
fill 114 52 -219 120 52 -219 minecraft:air
fill 133 52 -219 134 52 -219 minecraft:water[level=0]
fill 75 52 -220 78 52 -220 minecraft:air
fill 116 52 -220 120 52 -220 minecraft:air
fill 132 52 -220 134 52 -220 minecraft:water[level=0]
fill 72 52 -221 78 52 -221 minecraft:air
fill 116 52 -221 120 52 -221 minecraft:air
fill 132 52 -221 134 52 -221 minecraft:water[level=0]
fill 72 52 -222 77 52 -222 minecraft:air
fill 117 52 -222 120 52 -222 minecraft:air
setblock 132 52 -222 minecraft:water[level=0]
fill 72 52 -223 73 52 -223 minecraft:air
fill 117 52 -223 120 52 -223 minecraft:air
fill 117 52 -224 120 52 -224 minecraft:air
fill 117 52 -225 120 52 -225 minecraft:air
fill 117 52 -226 120 52 -226 minecraft:air
fill 118 52 -227 120 52 -227 minecraft:air
setblock 135 51 -211 minecraft:water[level=0]
setblock 135 51 -212 minecraft:water[level=0]
fill 134 51 -213 135 51 -213 minecraft:water[level=0]
fill 116 51 -214 119 51 -214 minecraft:air
fill 133 51 -214 135 51 -214 minecraft:water[level=0]
fill 115 51 -215 119 51 -215 minecraft:air
fill 133 51 -215 135 51 -215 minecraft:water[level=0]
fill 115 51 -216 119 51 -216 minecraft:air
fill 133 51 -216 135 51 -216 minecraft:water[level=0]
fill 114 51 -217 119 51 -217 minecraft:air
fill 133 51 -217 135 51 -217 minecraft:water[level=0]
fill 114 51 -218 119 51 -218 minecraft:air
fill 133 51 -218 135 51 -218 minecraft:water[level=0]
fill 76 51 -219 77 51 -219 minecraft:air
fill 116 51 -219 120 51 -219 minecraft:air
fill 133 51 -219 135 51 -219 minecraft:water[level=0]
fill 73 51 -220 77 51 -220 minecraft:air
fill 116 51 -220 120 51 -220 minecraft:air
fill 133 51 -220 134 51 -220 minecraft:water[level=0]
fill 72 51 -221 77 51 -221 minecraft:air
fill 116 51 -221 120 51 -221 minecraft:air
fill 132 51 -221 133 51 -221 minecraft:water[level=0]
fill 72 51 -222 74 51 -222 minecraft:air
fill 117 51 -222 120 51 -222 minecraft:air
fill 117 51 -223 120 51 -223 minecraft:air
fill 117 51 -224 120 51 -224 minecraft:air
fill 117 51 -225 120 51 -225 minecraft:air
fill 117 51 -226 120 51 -226 minecraft:air
fill 117 51 -227 121 51 -227 minecraft:air
setblock 134 50 -193 oritech:still_oil_block[level=0]
setblock 135 50 -212 minecraft:water[level=0]
fill 134 50 -213 135 50 -213 minecraft:water[level=0]
fill 116 50 -214 119 50 -214 minecraft:air
fill 133 50 -214 135 50 -214 minecraft:water[level=0]
fill 116 50 -215 119 50 -215 minecraft:air
fill 133 50 -215 135 50 -215 minecraft:water[level=0]
fill 116 50 -216 119 50 -216 minecraft:air
fill 133 50 -216 135 50 -216 minecraft:water[level=0]
fill 117 50 -217 120 50 -217 minecraft:air
fill 133 50 -217 135 50 -217 minecraft:water[level=0]
fill 116 50 -218 120 50 -218 minecraft:air
fill 133 50 -218 135 50 -218 minecraft:water[level=0]
fill 73 50 -219 77 50 -219 minecraft:air
fill 116 50 -219 120 50 -219 minecraft:air
fill 133 50 -219 135 50 -219 minecraft:water[level=0]
fill 72 50 -220 76 50 -220 minecraft:air
fill 116 50 -220 120 50 -220 minecraft:air
fill 133 50 -220 134 50 -220 minecraft:water[level=0]
fill 72 50 -221 75 50 -221 minecraft:air
fill 116 50 -221 120 50 -221 minecraft:air
setblock 133 50 -221 minecraft:water[level=0]
setblock 72 50 -222 minecraft:air
fill 117 50 -222 120 50 -222 minecraft:air
fill 117 50 -223 120 50 -223 minecraft:air
fill 117 50 -224 120 50 -224 minecraft:air
fill 117 50 -225 121 50 -225 minecraft:air
fill 117 50 -226 121 50 -226 minecraft:air
fill 117 50 -227 121 50 -227 minecraft:air
setblock 135 49 -191 oritech:still_oil_block[level=0]
setblock 135 49 -192 oritech:still_oil_block[level=0]
fill 134 49 -193 135 49 -193 oritech:still_oil_block[level=0]
fill 134 49 -194 135 49 -194 oritech:still_oil_block[level=0]
setblock 135 49 -195 oritech:still_oil_block[level=0]
setblock 135 49 -213 minecraft:water[level=0]
fill 134 49 -214 135 49 -214 minecraft:water[level=0]
fill 134 49 -215 135 49 -215 minecraft:water[level=0]
fill 134 49 -216 135 49 -216 minecraft:water[level=0]
fill 112 49 -217 113 49 -217 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 134 49 -217 135 49 -217 minecraft:water[level=0]
fill 74 49 -218 76 49 -218 minecraft:air
setblock 112 49 -218 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 134 49 -218 135 49 -218 minecraft:water[level=0]
fill 72 49 -219 76 49 -219 minecraft:air
fill 134 49 -219 135 49 -219 minecraft:water[level=0]
fill 72 49 -220 75 49 -220 minecraft:air
setblock 134 49 -220 minecraft:water[level=0]
fill 72 49 -221 73 49 -221 minecraft:air
fill 117 49 -221 120 49 -221 minecraft:air
fill 117 49 -222 120 49 -222 minecraft:air
fill 117 49 -223 120 49 -223 minecraft:air
fill 117 49 -224 120 49 -224 minecraft:air
fill 117 49 -225 121 49 -225 minecraft:air
fill 118 49 -226 120 49 -226 minecraft:air
fill 119 49 -227 120 49 -227 minecraft:air
fill 132 48 -191 135 48 -191 oritech:still_oil_block[level=0]
fill 132 48 -192 135 48 -192 oritech:still_oil_block[level=0]
fill 132 48 -193 135 48 -193 oritech:still_oil_block[level=0]
fill 132 48 -194 135 48 -194 oritech:still_oil_block[level=0]
fill 132 48 -195 135 48 -195 oritech:still_oil_block[level=0]
fill 133 48 -196 135 48 -196 oritech:still_oil_block[level=0]
fill 134 48 -197 135 48 -197 oritech:still_oil_block[level=0]
setblock 135 48 -198 oritech:still_oil_block[level=0]
setblock 135 48 -213 minecraft:water[level=0]
fill 134 48 -214 135 48 -214 minecraft:water[level=0]
fill 134 48 -215 135 48 -215 minecraft:water[level=0]
fill 134 48 -216 135 48 -216 minecraft:water[level=0]
fill 76 48 -217 77 48 -217 minecraft:air
fill 112 48 -217 113 48 -217 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 134 48 -217 135 48 -217 minecraft:water[level=0]
fill 72 48 -218 76 48 -218 minecraft:air
setblock 112 48 -218 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 134 48 -218 135 48 -218 minecraft:water[level=0]
fill 72 48 -219 75 48 -219 minecraft:air
fill 134 48 -219 135 48 -219 minecraft:water[level=0]
fill 72 48 -220 74 48 -220 minecraft:air
fill 131 47 -191 135 47 -191 oritech:still_oil_block[level=0]
fill 131 47 -192 135 47 -192 oritech:still_oil_block[level=0]
fill 131 47 -193 135 47 -193 oritech:still_oil_block[level=0]
fill 132 47 -194 135 47 -194 oritech:still_oil_block[level=0]
fill 131 47 -195 135 47 -195 oritech:still_oil_block[level=0]
fill 132 47 -196 135 47 -196 oritech:still_oil_block[level=0]
fill 132 47 -197 135 47 -197 oritech:still_oil_block[level=0]
fill 72 47 -198 73 47 -198 minecraft:air
fill 133 47 -198 135 47 -198 oritech:still_oil_block[level=0]
setblock 73 47 -199 minecraft:air
fill 133 47 -199 135 47 -199 oritech:still_oil_block[level=0]
setblock 135 47 -214 minecraft:water[level=0]
fill 134 47 -215 135 47 -215 minecraft:water[level=0]
fill 134 47 -216 135 47 -216 minecraft:water[level=0]
fill 74 47 -217 77 47 -217 minecraft:air
fill 134 47 -217 135 47 -217 minecraft:water[level=0]
fill 72 47 -218 76 47 -218 minecraft:air
fill 134 47 -218 135 47 -218 minecraft:water[level=0]
fill 72 47 -219 74 47 -219 minecraft:air
fill 134 47 -219 135 47 -219 minecraft:water[level=0]
fill 72 47 -220 73 47 -220 minecraft:air
setblock 134 47 -220 minecraft:water[level=0]
fill 130 46 -191 135 46 -191 oritech:still_oil_block[level=0]
fill 130 46 -192 135 46 -192 oritech:still_oil_block[level=0]
fill 130 46 -193 135 46 -193 oritech:still_oil_block[level=0]
fill 130 46 -194 135 46 -194 oritech:still_oil_block[level=0]
fill 130 46 -195 135 46 -195 oritech:still_oil_block[level=0]
fill 131 46 -196 135 46 -196 oritech:still_oil_block[level=0]
fill 72 46 -197 73 46 -197 minecraft:air
fill 80 46 -197 82 46 -197 minecraft:air
fill 131 46 -197 135 46 -197 oritech:still_oil_block[level=0]
fill 72 46 -198 76 46 -198 minecraft:air
fill 78 46 -198 82 46 -198 minecraft:air
fill 131 46 -198 135 46 -198 oritech:still_oil_block[level=0]
fill 72 46 -199 80 46 -199 minecraft:air
fill 133 46 -199 135 46 -199 oritech:still_oil_block[level=0]
fill 75 46 -200 78 46 -200 minecraft:air
fill 134 46 -200 135 46 -200 oritech:still_oil_block[level=0]
setblock 135 46 -201 oritech:still_oil_block[level=0]
setblock 134 46 -215 minecraft:water[level=0]
fill 77 46 -216 78 46 -216 minecraft:air
setblock 134 46 -216 minecraft:water[level=0]
fill 73 46 -217 77 46 -217 minecraft:air
setblock 134 46 -217 minecraft:water[level=0]
fill 72 46 -218 76 46 -218 minecraft:air
setblock 134 46 -218 minecraft:water[level=0]
fill 72 46 -219 74 46 -219 minecraft:air
setblock 134 46 -219 minecraft:water[level=0]
setblock 72 46 -220 minecraft:air
setblock 134 46 -220 minecraft:water[level=0]
fill 130 45 -191 135 45 -191 oritech:still_oil_block[level=0]
fill 130 45 -192 135 45 -192 oritech:still_oil_block[level=0]
fill 130 45 -193 135 45 -193 oritech:still_oil_block[level=0]
setblock 91 45 -194 minecraft:air
fill 130 45 -194 135 45 -194 oritech:still_oil_block[level=0]
fill 89 45 -195 90 45 -195 minecraft:air
fill 130 45 -195 135 45 -195 oritech:still_oil_block[level=0]
fill 81 45 -196 90 45 -196 minecraft:air
fill 130 45 -196 135 45 -196 oritech:still_oil_block[level=0]
fill 72 45 -197 74 45 -197 minecraft:air
fill 79 45 -197 88 45 -197 minecraft:air
fill 130 45 -197 135 45 -197 oritech:still_oil_block[level=0]
fill 72 45 -198 83 45 -198 minecraft:air
setblock 85 45 -198 minecraft:air
fill 131 45 -198 135 45 -198 oritech:still_oil_block[level=0]
fill 72 45 -199 81 45 -199 minecraft:air
setblock 130 45 -199 oritech:still_oil_block[level=0]
fill 132 45 -199 135 45 -199 oritech:still_oil_block[level=0]
fill 73 45 -200 79 45 -200 minecraft:air
fill 132 45 -200 135 45 -200 oritech:still_oil_block[level=0]
setblock 135 45 -201 oritech:still_oil_block[level=0]
fill 75 45 -216 79 45 -216 minecraft:air
fill 72 45 -217 77 45 -217 minecraft:air
fill 72 45 -218 75 45 -218 minecraft:air
fill 72 45 -219 73 45 -219 minecraft:air
forceload remove 72 -254 135 -191
tellraw @a {"text":"Campus zurueck a23 fertig.","color":"green"}
