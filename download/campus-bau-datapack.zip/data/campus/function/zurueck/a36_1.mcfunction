setblock 41 80 -117 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 45 80 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 80 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 54 80 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 80 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 45 79 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 79 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 79 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 79 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 79 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 79 -117 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 45 79 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 79 -118 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 69 79 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 79 -118 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 71 79 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 79 -121 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 36 79 -122 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 79 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 79 -123 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 54 79 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 79 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 53 79 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 79 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 79 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 78 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 78 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 78 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 78 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 78 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 42 78 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 78 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 78 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 78 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 78 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 44 78 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 78 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 46 78 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 68 78 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 78 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 70 78 -118 71 78 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 69 78 -119 70 78 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 78 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 78 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 78 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 78 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 78 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 78 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 78 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 78 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 78 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 78 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 78 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 78 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 78 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 78 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 77 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 77 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 77 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 77 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 77 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 42 77 -117 43 77 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 77 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 45 77 -117 minecraft:birch_log[axis=y]
setblock 46 77 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 47 77 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 77 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 77 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 70 77 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 77 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 44 77 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 77 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 46 77 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 77 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 77 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 70 77 -118 71 77 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 77 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 77 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 69 77 -119 70 77 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 77 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 70 77 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 77 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 77 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 77 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 77 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 77 -121 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 36 77 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 77 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 77 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 77 -122 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 66 77 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 77 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 77 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 77 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 77 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 77 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 55 77 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 77 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 77 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 77 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 77 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 77 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 77 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 77 -126 minecraft:birch_log[axis=y]
setblock 55 77 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 77 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 76 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 76 -117 minecraft:birch_log[axis=y]
setblock 68 76 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 76 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 70 76 -117 71 76 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 68 76 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 69 76 -118 minecraft:birch_log[axis=y]
fill 70 76 -118 71 76 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 76 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 69 76 -119 70 76 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 71 76 -119 minecraft:birch_log[axis=y]
setblock 37 76 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 69 76 -120 70 76 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 76 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 76 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 76 -121 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 76 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 76 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 76 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 76 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 76 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 76 -122 minecraft:birch_log[axis=y]
setblock 38 76 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 76 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 76 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 76 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 76 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 76 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 76 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 76 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 76 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 76 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 76 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 76 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 76 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 76 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 76 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 76 -126 minecraft:birch_log[axis=y]
setblock 56 76 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 75 -116 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 55 75 -116 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 56 75 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 57 75 -116 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 45 75 -117 minecraft:birch_log[axis=y]
setblock 56 75 -117 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 69 75 -118 minecraft:birch_log[axis=y]
setblock 35 75 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 75 -119 minecraft:birch_log[axis=y]
setblock 35 75 -120 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 50 75 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 75 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 75 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 75 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 75 -122 minecraft:birch_log[axis=y]
setblock 50 75 -122 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 65 75 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 75 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 67 75 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 75 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 75 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 67 75 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 75 -124 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 63 75 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 75 -125 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 63 75 -125 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 32 75 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 75 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 34 75 -126 35 75 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 75 -126 minecraft:birch_log[axis=y]
setblock 55 75 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 75 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 75 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 74 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 74 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 74 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 74 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 45 74 -117 minecraft:birch_log[axis=y]
setblock 56 74 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 74 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 74 -118 minecraft:birch_log[axis=y]
setblock 30 74 -119 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 34 74 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 74 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 74 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 74 -119 minecraft:birch_log[axis=y]
setblock 35 74 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 74 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 74 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 74 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 74 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -121 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 74 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 74 -121 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 67 74 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 74 -122 minecraft:birch_log[axis=y]
setblock 50 74 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 64 74 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 65 74 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 66 74 -122 minecraft:birch_log[axis=y]
setblock 67 74 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 68 74 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 74 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 65 74 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 74 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 67 74 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 74 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 74 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 74 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 74 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 74 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 74 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 32 74 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 74 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 34 74 -126 35 74 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 74 -126 minecraft:birch_log[axis=y]
fill 55 74 -126 56 74 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 74 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 73 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 51 73 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 73 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 55 73 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 73 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 73 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 73 -117 minecraft:birch_log[axis=y]
setblock 55 73 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 73 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 57 73 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 73 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 69 73 -118 minecraft:birch_log[axis=y]
setblock 30 73 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 73 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 73 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 73 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 73 -119 minecraft:birch_log[axis=y]
setblock 34 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 73 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 73 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 73 -120 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 73 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 73 -121 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 73 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 73 -122 regions_unexplored:birch_branch[facing=west]
setblock 37 73 -122 minecraft:birch_log[axis=y]
setblock 49 73 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 50 73 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 73 -122 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 66 73 -122 minecraft:birch_log[axis=y]
setblock 62 73 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 73 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 73 -123 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 73 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 73 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 73 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 73 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 73 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 73 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 62 73 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 73 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 64 73 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 71 73 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 73 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 73 -126 minecraft:birch_log[axis=y]
setblock 50 72 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 72 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 72 -116 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 72 -116 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 54 72 -116 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 72 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 72 -116 minecraft:birch_log[axis=y]
setblock 57 72 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 58 72 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 45 72 -117 minecraft:birch_log[axis=y]
setblock 51 72 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 55 72 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 72 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 57 72 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 72 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 56 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 69 72 -118 minecraft:birch_log[axis=y]
setblock 30 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 72 -119 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 72 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 72 -119 minecraft:birch_log[axis=y]
setblock 36 72 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 71 72 -119 minecraft:birch_log[axis=y]
setblock 34 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 72 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 72 -120 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 72 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 72 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 72 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 72 -121 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 72 -121 minecraft:birch_log[axis=y]
setblock 51 72 -121 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 72 -121 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 72 -122 minecraft:birch_log[axis=y]
setblock 49 72 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 72 -122 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 72 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 72 -122 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 66 72 -122 minecraft:birch_log[axis=y]
setblock 50 72 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 72 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 72 -123 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 72 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 72 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 72 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 72 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 63 72 -124 minecraft:birch_log[axis=y]
setblock 64 72 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 65 72 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 72 -125 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 27 72 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 72 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 72 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 72 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 62 72 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 63 72 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 64 72 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 33 72 -126 34 72 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 72 -126 minecraft:birch_log[axis=y]
setblock 36 72 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 72 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 72 -126 minecraft:air
setblock 54 72 -126 minecraft:birch_log[axis=y]
setblock 62 72 -126 minecraft:air
setblock 63 72 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 52 71 -116 53 71 -116 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 71 -116 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 71 -116 minecraft:birch_log[axis=y]
setblock 45 71 -117 minecraft:birch_log[axis=y]
setblock 69 71 -118 minecraft:birch_log[axis=y]
setblock 30 71 -119 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 71 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 71 -119 minecraft:birch_log[axis=y]
setblock 71 71 -119 minecraft:birch_log[axis=y]
setblock 30 71 -120 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 50 71 -121 minecraft:birch_log[axis=y]
setblock 37 71 -122 minecraft:birch_log[axis=y]
setblock 66 71 -122 minecraft:birch_log[axis=y]
setblock 27 71 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 71 -124 minecraft:air
setblock 62 71 -124 minecraft:air
setblock 63 71 -124 minecraft:birch_log[axis=y]
setblock 23 71 -125 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 71 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 71 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 71 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 51 71 -125 53 71 -125 minecraft:air
fill 61 71 -125 63 71 -125 minecraft:air
setblock 71 71 -125 minecraft:air
setblock 22 71 -126 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 71 -126 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 71 -126 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 71 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 71 -126 minecraft:birch_log[axis=y]
setblock 36 71 -126 minecraft:air
fill 50 71 -126 53 71 -126 minecraft:air
setblock 54 71 -126 minecraft:birch_log[axis=y]
fill 60 71 -126 64 71 -126 minecraft:air
fill 70 71 -126 71 71 -126 minecraft:air
fill 52 70 -116 53 70 -116 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 54 70 -116 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 56 70 -116 minecraft:birch_log[axis=y]
setblock 45 70 -117 minecraft:birch_log[axis=y]
setblock 69 70 -118 minecraft:birch_log[axis=y]
setblock 35 70 -119 minecraft:birch_log[axis=y]
setblock 71 70 -119 minecraft:birch_log[axis=y]
setblock 50 70 -121 minecraft:birch_log[axis=y]
setblock 37 70 -122 minecraft:birch_log[axis=y]
setblock 66 70 -122 minecraft:birch_log[axis=y]
setblock 22 70 -124 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 70 -124 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 70 -124 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 70 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 70 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 51 70 -124 53 70 -124 minecraft:air
fill 61 70 -124 62 70 -124 minecraft:air
setblock 63 70 -124 minecraft:birch_log[axis=y]
setblock 71 70 -124 minecraft:air
fill 21 70 -125 22 70 -125 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 70 -125 herbsandharvest:avocado_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
fill 24 70 -125 25 70 -125 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 70 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 70 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 70 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 50 70 -125 54 70 -125 minecraft:air
fill 60 70 -125 64 70 -125 minecraft:air
fill 70 70 -125 71 70 -125 minecraft:air
setblock 20 70 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 21 70 -126 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 70 -126 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 70 -126 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 70 -126 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 70 -126 herbsandharvest:avocado_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 26 70 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 70 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 70 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 70 -126 minecraft:birch_log[axis=y]
fill 36 70 -126 37 70 -126 minecraft:air
fill 50 70 -126 53 70 -126 minecraft:air
setblock 54 70 -126 minecraft:birch_log[axis=y]
fill 60 70 -126 64 70 -126 minecraft:air
fill 70 70 -126 71 70 -126 minecraft:air
setblock 56 69 -116 minecraft:birch_log[axis=y]
setblock 45 69 -117 minecraft:birch_log[axis=y]
setblock 69 69 -118 minecraft:birch_log[axis=y]
setblock 35 69 -119 minecraft:birch_log[axis=y]
setblock 71 69 -119 minecraft:birch_log[axis=y]
setblock 50 69 -121 minecraft:birch_log[axis=y]
setblock 37 69 -122 minecraft:birch_log[axis=y]
setblock 66 69 -122 minecraft:birch_log[axis=y]
setblock 27 69 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 69 -124 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 69 -124 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 69 -124 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 69 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 69 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 69 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 69 -124 minecraft:air
setblock 62 69 -124 minecraft:air
setblock 63 69 -124 minecraft:birch_log[axis=y]
setblock 21 69 -125 herbsandharvest:avocado_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 22 69 -125 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 69 -125 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
fill 24 69 -125 25 69 -125 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 69 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 69 -125 minecraft:birch_log[axis=y]
setblock 28 69 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 69 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 51 69 -125 53 69 -125 minecraft:air
fill 61 69 -125 63 69 -125 minecraft:air
setblock 71 69 -125 minecraft:air
setblock 20 69 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 21 69 -126 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 22 69 -126 herbsandharvest:avocado_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 23 69 -126 minecraft:oak_log[axis=y]
setblock 24 69 -126 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 69 -126 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 69 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 69 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 69 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 69 -126 minecraft:birch_log[axis=y]
setblock 36 69 -126 minecraft:air
fill 50 69 -126 53 69 -126 minecraft:air
setblock 54 69 -126 minecraft:birch_log[axis=y]
fill 60 69 -126 64 69 -126 minecraft:air
fill 70 69 -126 71 69 -126 minecraft:air
setblock 56 68 -116 minecraft:birch_log[axis=y]
setblock 45 68 -117 minecraft:birch_log[axis=y]
setblock 69 68 -118 minecraft:birch_log[axis=y]
setblock 35 68 -119 minecraft:birch_log[axis=y]
setblock 71 68 -119 minecraft:birch_log[axis=y]
setblock 50 68 -121 minecraft:birch_log[axis=y]
setblock 37 68 -122 minecraft:birch_log[axis=y]
setblock 66 68 -122 minecraft:birch_log[axis=y]
setblock 22 68 -124 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 68 -124 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 68 -124 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 63 68 -124 minecraft:birch_log[axis=y]
setblock 21 68 -125 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 68 -125 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 68 -125 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 68 -125 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 68 -125 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 68 -125 minecraft:birch_log[axis=y]
setblock 21 68 -126 herbsandharvest:avocado_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 22 68 -126 herbsandharvest:avocado_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 23 68 -126 minecraft:oak_log[axis=y]
setblock 24 68 -126 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 68 -126 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 68 -126 minecraft:birch_log[axis=y]
setblock 52 68 -126 minecraft:air
setblock 54 68 -126 minecraft:birch_log[axis=y]
setblock 62 68 -126 minecraft:air
setblock 56 67 -116 minecraft:birch_log[axis=y]
setblock 45 67 -117 minecraft:birch_log[axis=y]
setblock 50 67 -117 minecraft:short_grass
setblock 69 67 -118 minecraft:birch_log[axis=y]
setblock 35 67 -119 minecraft:birch_log[axis=y]
setblock 71 67 -119 minecraft:birch_log[axis=y]
setblock 50 67 -121 minecraft:birch_log[axis=y]
setblock 37 67 -122 minecraft:birch_log[axis=y]
setblock 66 67 -122 minecraft:birch_log[axis=y]
setblock 63 67 -124 minecraft:birch_log[axis=y]
setblock 23 67 -125 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 67 -125 minecraft:birch_log[axis=y]
setblock 56 67 -125 regions_unexplored:grass_sprouts
setblock 22 67 -126 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 23 67 -126 minecraft:oak_log[axis=y]
setblock 24 67 -126 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 67 -126 minecraft:birch_log[axis=y]
setblock 52 67 -126 minecraft:air
setblock 54 67 -126 minecraft:birch_log[axis=y]
setblock 62 67 -126 minecraft:air
fill 45 66 -116 55 66 -116 minecraft:grass_block[snowy=false]
setblock 56 66 -116 minecraft:dirt
setblock 63 66 -116 regions_unexplored:birch_shrub[half=upper]
setblock 36 66 -117 minecraft:short_grass
setblock 45 66 -117 minecraft:birch_log[axis=y]
fill 50 66 -117 55 66 -117 minecraft:grass_block[snowy=false]
fill 48 66 -118 49 66 -118 minecraft:short_grass
setblock 52 66 -118 minecraft:short_grass
setblock 54 66 -118 regions_unexplored:grass_sprouts
setblock 69 66 -118 minecraft:birch_log[axis=y]
setblock 35 66 -119 minecraft:birch_log[axis=y]
fill 41 66 -119 42 66 -119 regions_unexplored:grass_sprouts
setblock 43 66 -119 minecraft:short_grass
fill 44 66 -119 45 66 -119 regions_unexplored:grass_sprouts
setblock 49 66 -119 regions_unexplored:grass_sprouts
setblock 71 66 -119 minecraft:birch_log[axis=y]
setblock 36 66 -120 regions_unexplored:grass_sprouts
setblock 44 66 -120 minecraft:short_grass
setblock 54 66 -120 minecraft:short_grass
setblock 40 66 -121 regions_unexplored:grass_sprouts
setblock 47 66 -121 minecraft:short_grass
setblock 48 66 -121 regions_unexplored:grass_sprouts
setblock 50 66 -121 minecraft:birch_log[axis=y]
setblock 59 66 -121 regions_unexplored:grass_sprouts
setblock 37 66 -122 minecraft:birch_log[axis=y]
setblock 38 66 -122 minecraft:short_grass
setblock 42 66 -122 minecraft:short_grass
setblock 44 66 -122 minecraft:short_grass
setblock 45 66 -122 regions_unexplored:grass_sprouts
setblock 50 66 -122 regions_unexplored:grass_sprouts
setblock 54 66 -122 regions_unexplored:grass_sprouts
setblock 66 66 -122 minecraft:birch_log[axis=y]
setblock 37 66 -123 minecraft:short_grass
setblock 40 66 -123 minecraft:short_grass
setblock 43 66 -123 regions_unexplored:grass_sprouts
setblock 52 66 -123 regions_unexplored:grass_sprouts
setblock 55 66 -123 minecraft:short_grass
setblock 41 66 -124 minecraft:short_grass
setblock 63 66 -124 minecraft:birch_log[axis=y]
setblock 27 66 -125 minecraft:birch_log[axis=y]
fill 55 66 -125 58 66 -125 minecraft:grass_block[snowy=false]
setblock 60 66 -125 regions_unexplored:grass_sprouts
fill 63 66 -125 68 66 -125 minecraft:grass_block[snowy=false]
setblock 23 66 -126 minecraft:oak_log[axis=y]
setblock 35 66 -126 minecraft:birch_log[axis=y]
setblock 40 66 -126 regions_unexplored:grass_sprouts
setblock 42 66 -126 minecraft:short_grass
fill 51 66 -126 53 66 -126 minecraft:grass_block[snowy=false]
setblock 54 66 -126 minecraft:dirt
fill 55 66 -126 69 66 -126 minecraft:grass_block[snowy=false]
setblock 44 65 -116 minecraft:grass_block[snowy=false]
fill 45 65 -116 56 65 -116 minecraft:dirt
fill 57 65 -116 58 65 -116 minecraft:grass_block[snowy=false]
fill 59 65 -116 61 65 -116 minecraft:air
setblock 62 65 -116 regions_unexplored:grass_sprouts
setblock 63 65 -116 regions_unexplored:birch_shrub[half=lower]
fill 64 65 -116 70 65 -116 minecraft:air
setblock 71 65 -116 regions_unexplored:grass_sprouts
fill 36 65 -117 44 65 -117 minecraft:grass_block[snowy=false]
setblock 45 65 -117 minecraft:dirt
fill 46 65 -117 49 65 -117 minecraft:grass_block[snowy=false]
fill 50 65 -117 55 65 -117 minecraft:dirt
fill 56 65 -117 59 65 -117 minecraft:grass_block[snowy=false]
fill 60 65 -117 64 65 -117 minecraft:air
setblock 65 65 -117 regions_unexplored:grass_sprouts
fill 66 65 -117 71 65 -117 minecraft:air
setblock 33 65 -118 minecraft:air
fill 34 65 -118 59 65 -118 minecraft:grass_block[snowy=false]
fill 60 65 -118 66 65 -118 minecraft:air
setblock 67 65 -118 regions_unexplored:grass_sprouts
setblock 68 65 -118 minecraft:air
setblock 69 65 -118 minecraft:birch_log[axis=y]
fill 70 65 -118 71 65 -118 minecraft:air
setblock 30 65 -119 minecraft:air
setblock 31 65 -119 minecraft:short_grass
fill 32 65 -119 34 65 -119 minecraft:air
setblock 35 65 -119 minecraft:dirt
fill 36 65 -119 70 65 -119 minecraft:grass_block[snowy=false]
setblock 71 65 -119 minecraft:birch_log[axis=y]
setblock 28 65 -120 minecraft:short_grass
setblock 29 65 -120 minecraft:air
setblock 30 65 -120 regions_unexplored:grass_sprouts
fill 31 65 -120 35 65 -120 minecraft:air
fill 36 65 -120 71 65 -120 minecraft:grass_block[snowy=false]
fill 26 65 -121 36 65 -121 minecraft:air
fill 37 65 -121 49 65 -121 minecraft:grass_block[snowy=false]
setblock 50 65 -121 minecraft:dirt
fill 51 65 -121 71 65 -121 minecraft:grass_block[snowy=false]
fill 25 65 -122 36 65 -122 minecraft:air
setblock 37 65 -122 minecraft:dirt
fill 38 65 -122 43 65 -122 minecraft:grass_block[snowy=false]
setblock 66 65 -122 minecraft:dirt
fill 23 65 -123 36 65 -123 minecraft:air
fill 22 65 -124 36 65 -124 minecraft:air
fill 45 65 -124 49 65 -124 minecraft:air
setblock 63 65 -124 minecraft:dirt
fill 21 65 -125 26 65 -125 minecraft:air
setblock 27 65 -125 minecraft:birch_log[axis=y]
fill 28 65 -125 37 65 -125 minecraft:air
fill 44 65 -125 51 65 -125 minecraft:air
fill 55 65 -125 58 65 -125 minecraft:dirt
fill 63 65 -125 68 65 -125 minecraft:dirt
fill 20 65 -126 22 65 -126 minecraft:air
setblock 23 65 -126 minecraft:oak_log[axis=y]
fill 24 65 -126 34 65 -126 minecraft:air
setblock 35 65 -126 minecraft:birch_log[axis=y]
setblock 36 65 -126 regions_unexplored:grass_sprouts
fill 37 65 -126 38 65 -126 minecraft:air
fill 44 65 -126 51 65 -126 minecraft:air
fill 52 65 -126 69 65 -126 minecraft:dirt
setblock 26 64 -121 minecraft:short_grass
fill 25 64 -122 29 64 -122 minecraft:air
fill 23 64 -123 31 64 -123 minecraft:air
fill 44 64 -123 49 64 -123 minecraft:air
fill 22 64 -124 32 64 -124 minecraft:air
fill 43 64 -124 50 64 -124 minecraft:air
fill 21 64 -125 26 64 -125 minecraft:air
fill 28 64 -125 32 64 -125 minecraft:air
fill 42 64 -125 51 64 -125 minecraft:air
fill 20 64 -126 21 64 -126 minecraft:air
setblock 22 64 -126 minecraft:short_grass
fill 24 64 -126 33 64 -126 minecraft:air
fill 42 64 -126 52 64 -126 minecraft:air
fill 44 63 -122 48 63 -122 minecraft:air
setblock 30 63 -123 minecraft:air
fill 42 63 -123 50 63 -123 minecraft:air
fill 29 63 -124 30 63 -124 minecraft:air
fill 41 63 -124 51 63 -124 minecraft:air
fill 28 63 -125 29 63 -125 minecraft:air
fill 40 63 -125 51 63 -125 minecraft:air
setblock 26 63 -126 minecraft:short_grass
fill 27 63 -126 29 63 -126 minecraft:air
fill 39 63 -126 52 63 -126 minecraft:air
fill 43 62 -122 48 62 -122 minecraft:air
fill 41 62 -123 50 62 -123 minecraft:air
setblock 30 62 -124 regions_unexplored:grass_sprouts
fill 40 62 -124 51 62 -124 minecraft:air
fill 29 62 -125 30 62 -125 minecraft:air
fill 38 62 -125 52 62 -125 minecraft:air
fill 28 62 -126 29 62 -126 minecraft:air
fill 37 62 -126 52 62 -126 minecraft:air
fill 42 61 -122 49 61 -122 minecraft:air
fill 40 61 -123 50 61 -123 minecraft:air
fill 39 61 -124 51 61 -124 minecraft:air
setblock 30 61 -125 minecraft:air
fill 37 61 -125 51 61 -125 minecraft:air
fill 29 61 -126 30 61 -126 minecraft:air
fill 36 61 -126 52 61 -126 minecraft:air
fill 42 60 -122 48 60 -122 minecraft:air
fill 40 60 -123 50 60 -123 minecraft:air
fill 38 60 -124 51 60 -124 minecraft:air
setblock 31 60 -125 minecraft:air
fill 37 60 -125 51 60 -125 minecraft:air
setblock 30 60 -126 minecraft:air
fill 36 60 -126 52 60 -126 minecraft:air
fill 42 59 -122 48 59 -122 minecraft:air
fill 40 59 -123 49 59 -123 minecraft:air
fill 38 59 -124 50 59 -124 minecraft:air
fill 37 59 -125 51 59 -125 minecraft:air
setblock 31 59 -126 minecraft:air
fill 36 59 -126 51 59 -126 minecraft:air
fill 43 58 -122 46 58 -122 minecraft:air
fill 40 58 -123 48 58 -123 minecraft:air
fill 38 58 -124 49 58 -124 minecraft:air
fill 37 58 -125 49 58 -125 minecraft:air
fill 36 58 -126 49 58 -126 minecraft:air
fill 41 57 -123 44 57 -123 minecraft:air
fill 39 57 -124 45 57 -124 minecraft:air
fill 37 57 -125 46 57 -125 minecraft:air
fill 36 57 -126 46 57 -126 minecraft:air
fill 38 56 -125 40 56 -125 minecraft:air
fill 37 56 -126 41 56 -126 minecraft:air
setblock 40 49 -126 minecraft:air
setblock 42 47 -125 minecraft:air
setblock 43 46 -125 minecraft:air
fill 42 46 -126 43 46 -126 minecraft:air
setblock 44 45 -124 minecraft:air
fill 43 45 -125 44 45 -125 minecraft:air
fill 43 45 -126 44 45 -126 minecraft:air
forceload remove 8 -126 71 -63
tellraw @a {"text":"Campus zurueck a36 fertig.","color":"green"}
