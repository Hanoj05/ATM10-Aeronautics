fill 264 65 -116 327 65 -116 minecraft:air
fill 264 65 -117 327 65 -117 minecraft:air
fill 264 65 -118 327 65 -118 minecraft:air
fill 264 65 -119 327 65 -119 minecraft:air
fill 264 65 -120 327 65 -120 minecraft:air
fill 264 65 -121 327 65 -121 minecraft:air
fill 264 65 -122 327 65 -122 minecraft:air
fill 264 65 -123 327 65 -123 minecraft:air
fill 264 65 -124 327 65 -124 minecraft:air
fill 264 65 -125 327 65 -125 minecraft:air
fill 314 65 -126 327 65 -126 minecraft:air
fill 264 64 -116 327 64 -116 minecraft:air
fill 264 64 -117 327 64 -117 minecraft:air
fill 264 64 -118 327 64 -118 minecraft:air
fill 264 64 -119 327 64 -119 minecraft:air
fill 264 64 -120 327 64 -120 minecraft:air
fill 264 64 -121 327 64 -121 minecraft:air
fill 264 64 -122 327 64 -122 minecraft:air
fill 264 64 -123 327 64 -123 minecraft:air
fill 264 64 -124 327 64 -124 minecraft:air
fill 264 64 -125 327 64 -125 minecraft:air
fill 264 64 -126 327 64 -126 minecraft:air
fill 264 63 -116 327 63 -116 minecraft:air
fill 264 63 -117 327 63 -117 minecraft:air
fill 264 63 -118 266 63 -118 minecraft:air
fill 268 63 -118 327 63 -118 minecraft:air
fill 264 63 -119 267 63 -119 minecraft:air
fill 269 63 -119 327 63 -119 minecraft:air
fill 264 63 -120 266 63 -120 minecraft:air
fill 270 63 -120 327 63 -120 minecraft:air
fill 264 63 -121 267 63 -121 minecraft:air
fill 269 63 -121 327 63 -121 minecraft:air
fill 264 63 -122 327 63 -122 minecraft:air
fill 264 63 -123 327 63 -123 minecraft:air
fill 264 63 -124 327 63 -124 minecraft:air
fill 264 63 -125 327 63 -125 minecraft:air
fill 264 63 -126 281 63 -126 minecraft:air
setblock 285 63 -126 regions_unexplored:grass_sprouts
fill 286 63 -126 327 63 -126 minecraft:air
fill 269 62 -116 320 62 -116 minecraft:water[level=0]
setblock 321 62 -116 minecraft:kelp[age=25]
fill 322 62 -116 326 62 -116 minecraft:water[level=0]
setblock 327 62 -116 minecraft:kelp[age=25]
fill 269 62 -117 325 62 -117 minecraft:water[level=0]
setblock 326 62 -117 minecraft:kelp[age=25]
setblock 327 62 -117 minecraft:water[level=0]
fill 269 62 -118 326 62 -118 minecraft:water[level=0]
setblock 327 62 -118 minecraft:kelp[age=23]
fill 271 62 -119 293 62 -119 minecraft:water[level=0]
setblock 294 62 -119 minecraft:kelp[age=24]
fill 295 62 -119 317 62 -119 minecraft:water[level=0]
setblock 318 62 -119 minecraft:kelp[age=24]
fill 319 62 -119 327 62 -119 minecraft:water[level=0]
setblock 271 62 -120 minecraft:water[level=0]
fill 273 62 -120 323 62 -120 minecraft:water[level=0]
setblock 324 62 -120 minecraft:kelp[age=22]
setblock 325 62 -120 minecraft:kelp[age=21]
fill 326 62 -120 327 62 -120 minecraft:water[level=0]
fill 273 62 -121 315 62 -121 minecraft:water[level=0]
setblock 316 62 -121 minecraft:kelp[age=22]
fill 317 62 -121 327 62 -121 minecraft:water[level=0]
setblock 270 62 -122 minecraft:water[level=0]
fill 272 62 -122 276 62 -122 minecraft:water[level=0]
fill 281 62 -122 319 62 -122 minecraft:water[level=0]
setblock 320 62 -122 minecraft:kelp[age=25]
setblock 321 62 -122 minecraft:kelp[age=22]
fill 322 62 -122 323 62 -122 minecraft:water[level=0]
setblock 324 62 -122 minecraft:kelp[age=25]
fill 325 62 -122 327 62 -122 minecraft:water[level=0]
setblock 270 62 -123 minecraft:water[level=0]
fill 272 62 -123 274 62 -123 minecraft:water[level=0]
fill 285 62 -123 312 62 -123 minecraft:water[level=0]
setblock 313 62 -123 minecraft:kelp[age=24]
fill 314 62 -123 327 62 -123 minecraft:water[level=0]
fill 270 62 -124 274 62 -124 minecraft:water[level=0]
fill 285 62 -124 327 62 -124 minecraft:water[level=0]
setblock 272 62 -125 minecraft:water[level=0]
fill 286 62 -125 313 62 -125 minecraft:water[level=0]
setblock 314 62 -125 minecraft:kelp[age=24]
fill 315 62 -125 325 62 -125 minecraft:water[level=0]
setblock 326 62 -125 minecraft:kelp[age=24]
setblock 327 62 -125 minecraft:water[level=0]
fill 286 62 -126 324 62 -126 minecraft:water[level=0]
setblock 325 62 -126 minecraft:kelp[age=22]
setblock 326 62 -126 minecraft:water[level=0]
setblock 327 62 -126 minecraft:kelp[age=23]
fill 270 61 -116 320 61 -116 minecraft:water[level=0]
setblock 321 61 -116 minecraft:kelp_plant
fill 322 61 -116 326 61 -116 minecraft:water[level=0]
setblock 327 61 -116 minecraft:kelp_plant
fill 270 61 -117 325 61 -117 minecraft:water[level=0]
setblock 326 61 -117 minecraft:kelp_plant
setblock 327 61 -117 minecraft:water[level=0]
fill 271 61 -118 326 61 -118 minecraft:water[level=0]
setblock 327 61 -118 minecraft:kelp_plant
fill 271 61 -119 293 61 -119 minecraft:water[level=0]
setblock 294 61 -119 minecraft:kelp_plant
fill 295 61 -119 317 61 -119 minecraft:water[level=0]
setblock 318 61 -119 minecraft:kelp_plant
fill 319 61 -119 327 61 -119 minecraft:water[level=0]
fill 274 61 -120 277 61 -120 minecraft:water[level=0]
fill 280 61 -120 323 61 -120 minecraft:water[level=0]
fill 324 61 -120 325 61 -120 minecraft:kelp_plant
fill 326 61 -120 327 61 -120 minecraft:water[level=0]
fill 281 61 -121 315 61 -121 minecraft:water[level=0]
setblock 316 61 -121 minecraft:kelp_plant
fill 317 61 -121 327 61 -121 minecraft:water[level=0]
fill 284 61 -122 319 61 -122 minecraft:water[level=0]
fill 320 61 -122 321 61 -122 minecraft:kelp_plant
fill 322 61 -122 323 61 -122 minecraft:water[level=0]
setblock 324 61 -122 minecraft:kelp_plant
fill 325 61 -122 327 61 -122 minecraft:water[level=0]
setblock 272 61 -123 minecraft:water[level=0]
fill 285 61 -123 312 61 -123 minecraft:water[level=0]
setblock 313 61 -123 minecraft:kelp_plant
fill 314 61 -123 327 61 -123 minecraft:water[level=0]
setblock 272 61 -124 minecraft:water[level=0]
fill 286 61 -124 327 61 -124 minecraft:water[level=0]
fill 286 61 -125 313 61 -125 minecraft:water[level=0]
setblock 314 61 -125 minecraft:kelp_plant
fill 315 61 -125 325 61 -125 minecraft:water[level=0]
setblock 326 61 -125 minecraft:kelp_plant
setblock 327 61 -125 minecraft:water[level=0]
fill 287 61 -126 323 61 -126 minecraft:water[level=0]
setblock 324 61 -126 minecraft:kelp[age=25]
setblock 325 61 -126 minecraft:kelp_plant
setblock 326 61 -126 minecraft:water[level=0]
setblock 327 61 -126 minecraft:kelp_plant
fill 271 60 -116 320 60 -116 minecraft:water[level=0]
setblock 321 60 -116 minecraft:kelp_plant
fill 322 60 -116 326 60 -116 minecraft:water[level=0]
setblock 327 60 -116 minecraft:kelp_plant
fill 272 60 -117 325 60 -117 minecraft:water[level=0]
setblock 326 60 -117 minecraft:kelp_plant
setblock 327 60 -117 minecraft:water[level=0]
fill 271 60 -118 305 60 -118 minecraft:water[level=0]
setblock 306 60 -118 minecraft:kelp[age=25]
fill 307 60 -118 326 60 -118 minecraft:water[level=0]
setblock 327 60 -118 minecraft:kelp_plant
fill 272 60 -119 277 60 -119 minecraft:water[level=0]
fill 279 60 -119 293 60 -119 minecraft:water[level=0]
setblock 294 60 -119 minecraft:kelp_plant
fill 295 60 -119 317 60 -119 minecraft:water[level=0]
setblock 318 60 -119 minecraft:kelp_plant
fill 319 60 -119 327 60 -119 minecraft:water[level=0]
fill 281 60 -120 323 60 -120 minecraft:water[level=0]
fill 324 60 -120 325 60 -120 minecraft:kelp_plant
fill 326 60 -120 327 60 -120 minecraft:water[level=0]
fill 283 60 -121 315 60 -121 minecraft:water[level=0]
setblock 316 60 -121 minecraft:kelp_plant
fill 317 60 -121 327 60 -121 minecraft:water[level=0]
fill 285 60 -122 319 60 -122 minecraft:water[level=0]
fill 320 60 -122 321 60 -122 minecraft:kelp_plant
fill 322 60 -122 323 60 -122 minecraft:water[level=0]
setblock 324 60 -122 minecraft:kelp_plant
fill 325 60 -122 327 60 -122 minecraft:water[level=0]
fill 286 60 -123 312 60 -123 minecraft:water[level=0]
setblock 313 60 -123 minecraft:kelp_plant
fill 314 60 -123 327 60 -123 minecraft:water[level=0]
fill 286 60 -124 327 60 -124 minecraft:water[level=0]
fill 287 60 -125 313 60 -125 minecraft:water[level=0]
setblock 314 60 -125 minecraft:kelp_plant
fill 315 60 -125 325 60 -125 minecraft:water[level=0]
setblock 326 60 -125 minecraft:kelp_plant
setblock 327 60 -125 minecraft:water[level=0]
fill 288 60 -126 318 60 -126 minecraft:water[level=0]
setblock 319 60 -126 minecraft:kelp[age=25]
fill 320 60 -126 323 60 -126 minecraft:water[level=0]
fill 324 60 -126 325 60 -126 minecraft:kelp_plant
setblock 326 60 -126 minecraft:water[level=0]
setblock 327 60 -126 minecraft:kelp_plant
fill 271 59 -116 310 59 -116 minecraft:water[level=0]
setblock 311 59 -116 minecraft:kelp[age=25]
fill 312 59 -116 320 59 -116 minecraft:water[level=0]
setblock 321 59 -116 minecraft:kelp_plant
fill 322 59 -116 324 59 -116 minecraft:water[level=0]
fill 325 59 -116 326 59 -116 minecraft:kelp[age=25]
setblock 327 59 -116 minecraft:kelp_plant
fill 271 59 -117 325 59 -117 minecraft:water[level=0]
setblock 326 59 -117 minecraft:kelp_plant
setblock 327 59 -117 minecraft:water[level=0]
fill 272 59 -118 277 59 -118 minecraft:water[level=0]
fill 279 59 -118 305 59 -118 minecraft:water[level=0]
setblock 306 59 -118 minecraft:kelp_plant
fill 307 59 -118 326 59 -118 minecraft:water[level=0]
setblock 327 59 -118 minecraft:kelp_plant
setblock 279 59 -119 minecraft:water[level=0]
fill 281 59 -119 293 59 -119 minecraft:water[level=0]
setblock 294 59 -119 minecraft:kelp_plant
fill 295 59 -119 317 59 -119 minecraft:water[level=0]
setblock 318 59 -119 minecraft:kelp_plant
fill 319 59 -119 327 59 -119 minecraft:water[level=0]
fill 283 59 -120 323 59 -120 minecraft:water[level=0]
fill 324 59 -120 325 59 -120 minecraft:kelp_plant
fill 326 59 -120 327 59 -120 minecraft:water[level=0]
fill 284 59 -121 315 59 -121 minecraft:water[level=0]
setblock 316 59 -121 minecraft:kelp_plant
fill 317 59 -121 325 59 -121 minecraft:water[level=0]
setblock 326 59 -121 minecraft:kelp[age=25]
setblock 327 59 -121 minecraft:water[level=0]
fill 285 59 -122 319 59 -122 minecraft:water[level=0]
fill 320 59 -122 321 59 -122 minecraft:kelp_plant
fill 322 59 -122 323 59 -122 minecraft:water[level=0]
setblock 324 59 -122 minecraft:kelp_plant
fill 325 59 -122 327 59 -122 minecraft:water[level=0]
fill 286 59 -123 312 59 -123 minecraft:water[level=0]
setblock 313 59 -123 minecraft:kelp_plant
fill 314 59 -123 327 59 -123 minecraft:water[level=0]
fill 287 59 -124 327 59 -124 minecraft:water[level=0]
fill 288 59 -125 313 59 -125 minecraft:water[level=0]
setblock 314 59 -125 minecraft:kelp_plant
fill 315 59 -125 325 59 -125 minecraft:water[level=0]
setblock 326 59 -125 minecraft:kelp_plant
setblock 327 59 -125 minecraft:water[level=0]
fill 290 59 -126 318 59 -126 minecraft:water[level=0]
setblock 319 59 -126 minecraft:kelp_plant
setblock 320 59 -126 minecraft:kelp[age=25]
fill 321 59 -126 323 59 -126 minecraft:water[level=0]
fill 324 59 -126 325 59 -126 minecraft:kelp_plant
setblock 326 59 -126 minecraft:water[level=0]
setblock 327 59 -126 minecraft:kelp_plant
fill 271 58 -116 310 58 -116 minecraft:water[level=0]
setblock 311 58 -116 minecraft:kelp_plant
fill 312 58 -116 320 58 -116 minecraft:water[level=0]
setblock 321 58 -116 minecraft:kelp_plant
fill 322 58 -116 324 58 -116 minecraft:water[level=0]
fill 325 58 -116 327 58 -116 minecraft:kelp_plant
fill 271 58 -117 310 58 -117 minecraft:water[level=0]
setblock 311 58 -117 minecraft:kelp[age=25]
fill 312 58 -117 322 58 -117 minecraft:water[level=0]
setblock 323 58 -117 minecraft:kelp[age=25]
fill 324 58 -117 325 58 -117 minecraft:water[level=0]
setblock 326 58 -117 minecraft:kelp_plant
setblock 327 58 -117 minecraft:water[level=0]
fill 272 58 -118 305 58 -118 minecraft:water[level=0]
setblock 306 58 -118 minecraft:kelp_plant
fill 307 58 -118 326 58 -118 minecraft:water[level=0]
setblock 327 58 -118 minecraft:kelp_plant
fill 281 58 -119 293 58 -119 minecraft:water[level=0]
setblock 294 58 -119 minecraft:kelp_plant
fill 295 58 -119 317 58 -119 minecraft:water[level=0]
setblock 318 58 -119 minecraft:kelp_plant
fill 319 58 -119 327 58 -119 minecraft:water[level=0]
fill 283 58 -120 323 58 -120 minecraft:water[level=0]
fill 324 58 -120 325 58 -120 minecraft:kelp_plant
fill 326 58 -120 327 58 -120 minecraft:water[level=0]
fill 283 58 -121 315 58 -121 minecraft:water[level=0]
setblock 316 58 -121 minecraft:kelp_plant
fill 317 58 -121 325 58 -121 minecraft:water[level=0]
setblock 326 58 -121 minecraft:kelp_plant
setblock 327 58 -121 minecraft:water[level=0]
fill 285 58 -122 319 58 -122 minecraft:water[level=0]
fill 320 58 -122 321 58 -122 minecraft:kelp_plant
fill 322 58 -122 323 58 -122 minecraft:water[level=0]
setblock 324 58 -122 minecraft:kelp_plant
fill 325 58 -122 327 58 -122 minecraft:water[level=0]
fill 286 58 -123 312 58 -123 minecraft:water[level=0]
setblock 313 58 -123 minecraft:kelp_plant
fill 314 58 -123 327 58 -123 minecraft:water[level=0]
fill 287 58 -124 327 58 -124 minecraft:water[level=0]
fill 288 58 -125 313 58 -125 minecraft:water[level=0]
setblock 314 58 -125 minecraft:kelp_plant
fill 315 58 -125 325 58 -125 minecraft:water[level=0]
setblock 326 58 -125 minecraft:kelp_plant
setblock 327 58 -125 minecraft:water[level=0]
fill 291 58 -126 318 58 -126 minecraft:water[level=0]
fill 319 58 -126 320 58 -126 minecraft:kelp_plant
fill 321 58 -126 323 58 -126 minecraft:water[level=0]
fill 324 58 -126 325 58 -126 minecraft:kelp_plant
setblock 326 58 -126 minecraft:water[level=0]
setblock 327 58 -126 minecraft:kelp_plant
fill 271 57 -116 310 57 -116 minecraft:water[level=0]
setblock 311 57 -116 minecraft:kelp_plant
fill 312 57 -116 320 57 -116 minecraft:water[level=0]
setblock 321 57 -116 minecraft:kelp_plant
fill 322 57 -116 324 57 -116 minecraft:water[level=0]
fill 325 57 -116 327 57 -116 minecraft:kelp_plant
fill 272 57 -117 310 57 -117 minecraft:water[level=0]
setblock 311 57 -117 minecraft:kelp_plant
fill 312 57 -117 322 57 -117 minecraft:water[level=0]
setblock 323 57 -117 minecraft:kelp_plant
fill 324 57 -117 325 57 -117 minecraft:water[level=0]
setblock 326 57 -117 minecraft:kelp_plant
setblock 327 57 -117 minecraft:water[level=0]
fill 273 57 -118 305 57 -118 minecraft:water[level=0]
setblock 306 57 -118 minecraft:kelp_plant
fill 307 57 -118 308 57 -118 minecraft:water[level=0]
setblock 309 57 -118 minecraft:kelp[age=25]
fill 310 57 -118 326 57 -118 minecraft:water[level=0]
setblock 327 57 -118 minecraft:kelp_plant
fill 281 57 -119 293 57 -119 minecraft:water[level=0]
setblock 294 57 -119 minecraft:kelp_plant
fill 295 57 -119 317 57 -119 minecraft:water[level=0]
setblock 318 57 -119 minecraft:kelp_plant
fill 319 57 -119 327 57 -119 minecraft:water[level=0]
fill 282 57 -120 323 57 -120 minecraft:water[level=0]
fill 324 57 -120 325 57 -120 minecraft:kelp_plant
fill 326 57 -120 327 57 -120 minecraft:water[level=0]
fill 284 57 -121 315 57 -121 minecraft:water[level=0]
setblock 316 57 -121 minecraft:kelp_plant
fill 317 57 -121 325 57 -121 minecraft:water[level=0]
setblock 326 57 -121 minecraft:kelp_plant
setblock 327 57 -121 minecraft:water[level=0]
fill 286 57 -122 319 57 -122 minecraft:water[level=0]
fill 320 57 -122 321 57 -122 minecraft:kelp_plant
fill 322 57 -122 323 57 -122 minecraft:water[level=0]
setblock 324 57 -122 minecraft:kelp_plant
fill 325 57 -122 327 57 -122 minecraft:water[level=0]
fill 287 57 -123 312 57 -123 minecraft:water[level=0]
setblock 313 57 -123 minecraft:kelp_plant
fill 314 57 -123 321 57 -123 minecraft:water[level=0]
setblock 322 57 -123 minecraft:kelp[age=25]
fill 323 57 -123 327 57 -123 minecraft:water[level=0]
fill 287 57 -124 327 57 -124 minecraft:water[level=0]
fill 288 57 -125 313 57 -125 minecraft:water[level=0]
setblock 314 57 -125 minecraft:kelp_plant
fill 315 57 -125 325 57 -125 minecraft:water[level=0]
setblock 326 57 -125 minecraft:kelp_plant
setblock 327 57 -125 minecraft:water[level=0]
fill 292 57 -126 318 57 -126 minecraft:water[level=0]
fill 319 57 -126 320 57 -126 minecraft:kelp_plant
fill 321 57 -126 323 57 -126 minecraft:water[level=0]
fill 324 57 -126 325 57 -126 minecraft:kelp_plant
setblock 326 57 -126 minecraft:water[level=0]
setblock 327 57 -126 minecraft:kelp_plant
fill 271 56 -116 310 56 -116 minecraft:water[level=0]
setblock 311 56 -116 minecraft:kelp_plant
fill 312 56 -116 320 56 -116 minecraft:water[level=0]
setblock 321 56 -116 minecraft:kelp_plant
fill 322 56 -116 324 56 -116 minecraft:water[level=0]
fill 325 56 -116 327 56 -116 minecraft:kelp_plant
fill 272 56 -117 298 56 -117 minecraft:water[level=0]
setblock 299 56 -117 minecraft:kelp[age=25]
fill 300 56 -117 310 56 -117 minecraft:water[level=0]
setblock 311 56 -117 minecraft:kelp_plant
fill 312 56 -117 322 56 -117 minecraft:water[level=0]
setblock 323 56 -117 minecraft:kelp_plant
fill 324 56 -117 325 56 -117 minecraft:water[level=0]
setblock 326 56 -117 minecraft:kelp_plant
setblock 327 56 -117 minecraft:water[level=0]
fill 281 56 -118 305 56 -118 minecraft:water[level=0]
setblock 306 56 -118 minecraft:kelp_plant
fill 307 56 -118 308 56 -118 minecraft:water[level=0]
setblock 309 56 -118 minecraft:kelp_plant
fill 310 56 -118 326 56 -118 minecraft:water[level=0]
setblock 327 56 -118 minecraft:kelp_plant
fill 282 56 -119 293 56 -119 minecraft:water[level=0]
setblock 294 56 -119 minecraft:kelp_plant
fill 295 56 -119 317 56 -119 minecraft:water[level=0]
setblock 318 56 -119 minecraft:kelp_plant
fill 319 56 -119 320 56 -119 minecraft:water[level=0]
setblock 321 56 -119 minecraft:kelp[age=25]
fill 322 56 -119 326 56 -119 minecraft:water[level=0]
setblock 327 56 -119 minecraft:kelp[age=25]
fill 283 56 -120 323 56 -120 minecraft:water[level=0]
fill 324 56 -120 325 56 -120 minecraft:kelp_plant
fill 326 56 -120 327 56 -120 minecraft:water[level=0]
fill 284 56 -121 315 56 -121 minecraft:water[level=0]
setblock 316 56 -121 minecraft:kelp_plant
fill 317 56 -121 324 56 -121 minecraft:water[level=0]
setblock 325 56 -121 minecraft:kelp[age=25]
setblock 326 56 -121 minecraft:kelp_plant
setblock 327 56 -121 minecraft:water[level=0]
fill 286 56 -122 319 56 -122 minecraft:water[level=0]
fill 320 56 -122 321 56 -122 minecraft:kelp_plant
fill 322 56 -122 323 56 -122 minecraft:water[level=0]
setblock 324 56 -122 minecraft:kelp_plant
fill 325 56 -122 327 56 -122 minecraft:water[level=0]
fill 287 56 -123 312 56 -123 minecraft:water[level=0]
setblock 313 56 -123 minecraft:kelp_plant
fill 314 56 -123 321 56 -123 minecraft:water[level=0]
setblock 322 56 -123 minecraft:kelp_plant
fill 323 56 -123 327 56 -123 minecraft:water[level=0]
fill 287 56 -124 327 56 -124 minecraft:water[level=0]
fill 289 56 -125 313 56 -125 minecraft:water[level=0]
setblock 314 56 -125 minecraft:kelp_plant
fill 315 56 -125 325 56 -125 minecraft:water[level=0]
setblock 326 56 -125 minecraft:kelp_plant
setblock 327 56 -125 minecraft:water[level=0]
fill 292 56 -126 318 56 -126 minecraft:water[level=0]
fill 319 56 -126 320 56 -126 minecraft:kelp_plant
setblock 321 56 -126 minecraft:kelp[age=25]
fill 322 56 -126 323 56 -126 minecraft:water[level=0]
fill 324 56 -126 325 56 -126 minecraft:kelp_plant
setblock 326 56 -126 minecraft:water[level=0]
setblock 327 56 -126 minecraft:kelp_plant
fill 271 55 -116 310 55 -116 minecraft:water[level=0]
setblock 311 55 -116 minecraft:kelp_plant
fill 312 55 -116 320 55 -116 minecraft:water[level=0]
setblock 321 55 -116 minecraft:kelp_plant
fill 322 55 -116 324 55 -116 minecraft:water[level=0]
fill 325 55 -116 327 55 -116 minecraft:kelp_plant
fill 272 55 -117 298 55 -117 minecraft:water[level=0]
setblock 299 55 -117 minecraft:kelp_plant
fill 300 55 -117 310 55 -117 minecraft:water[level=0]
setblock 311 55 -117 minecraft:kelp_plant
fill 312 55 -117 322 55 -117 minecraft:water[level=0]
setblock 323 55 -117 minecraft:kelp_plant
fill 324 55 -117 325 55 -117 minecraft:water[level=0]
setblock 326 55 -117 minecraft:kelp_plant
setblock 327 55 -117 minecraft:water[level=0]
fill 281 55 -118 305 55 -118 minecraft:water[level=0]
setblock 306 55 -118 minecraft:kelp_plant
fill 307 55 -118 308 55 -118 minecraft:water[level=0]
setblock 309 55 -118 minecraft:kelp_plant
fill 310 55 -118 326 55 -118 minecraft:water[level=0]
setblock 327 55 -118 minecraft:kelp_plant
fill 282 55 -119 293 55 -119 minecraft:water[level=0]
setblock 294 55 -119 minecraft:kelp_plant
fill 295 55 -119 317 55 -119 minecraft:water[level=0]
setblock 318 55 -119 minecraft:kelp_plant
fill 319 55 -119 320 55 -119 minecraft:water[level=0]
setblock 321 55 -119 minecraft:kelp_plant
fill 322 55 -119 326 55 -119 minecraft:water[level=0]
setblock 327 55 -119 minecraft:kelp_plant
fill 283 55 -120 323 55 -120 minecraft:water[level=0]
fill 324 55 -120 325 55 -120 minecraft:kelp_plant
fill 326 55 -120 327 55 -120 minecraft:water[level=0]
fill 284 55 -121 315 55 -121 minecraft:water[level=0]
setblock 316 55 -121 minecraft:kelp_plant
fill 317 55 -121 324 55 -121 minecraft:water[level=0]
fill 325 55 -121 326 55 -121 minecraft:kelp_plant
setblock 327 55 -121 minecraft:water[level=0]
fill 286 55 -122 319 55 -122 minecraft:water[level=0]
fill 320 55 -122 321 55 -122 minecraft:kelp_plant
fill 322 55 -122 323 55 -122 minecraft:water[level=0]
setblock 324 55 -122 minecraft:kelp_plant
fill 325 55 -122 327 55 -122 minecraft:water[level=0]
fill 287 55 -123 312 55 -123 minecraft:water[level=0]
setblock 313 55 -123 minecraft:kelp_plant
fill 314 55 -123 321 55 -123 minecraft:water[level=0]
setblock 322 55 -123 minecraft:kelp_plant
fill 323 55 -123 327 55 -123 minecraft:water[level=0]
fill 287 55 -124 323 55 -124 minecraft:water[level=0]
setblock 324 55 -124 minecraft:tall_seagrass[half=upper]
fill 325 55 -124 327 55 -124 minecraft:water[level=0]
fill 288 55 -125 313 55 -125 minecraft:water[level=0]
setblock 314 55 -125 minecraft:kelp_plant
fill 315 55 -125 325 55 -125 minecraft:water[level=0]
setblock 326 55 -125 minecraft:kelp_plant
setblock 327 55 -125 minecraft:water[level=0]
fill 292 55 -126 318 55 -126 minecraft:water[level=0]
fill 319 55 -126 321 55 -126 minecraft:kelp_plant
fill 322 55 -126 323 55 -126 minecraft:water[level=0]
fill 324 55 -126 325 55 -126 minecraft:kelp_plant
setblock 326 55 -126 minecraft:tall_seagrass[half=upper]
setblock 327 55 -126 minecraft:kelp_plant
fill 271 54 -116 288 54 -116 minecraft:water[level=0]
setblock 289 54 -116 minecraft:kelp[age=25]
fill 290 54 -116 310 54 -116 minecraft:water[level=0]
setblock 311 54 -116 minecraft:kelp_plant
fill 312 54 -116 320 54 -116 minecraft:water[level=0]
setblock 321 54 -116 minecraft:kelp_plant
fill 322 54 -116 324 54 -116 minecraft:water[level=0]
fill 325 54 -116 327 54 -116 minecraft:kelp_plant
fill 272 54 -117 298 54 -117 minecraft:water[level=0]
setblock 299 54 -117 minecraft:kelp_plant
fill 300 54 -117 310 54 -117 minecraft:water[level=0]
setblock 311 54 -117 minecraft:kelp_plant
fill 312 54 -117 322 54 -117 minecraft:water[level=0]
setblock 323 54 -117 minecraft:kelp_plant
fill 324 54 -117 325 54 -117 minecraft:water[level=0]
setblock 326 54 -117 minecraft:kelp_plant
setblock 327 54 -117 minecraft:water[level=0]
fill 281 54 -118 305 54 -118 minecraft:water[level=0]
setblock 306 54 -118 minecraft:kelp_plant
fill 307 54 -118 308 54 -118 minecraft:water[level=0]
setblock 309 54 -118 minecraft:kelp_plant
fill 310 54 -118 326 54 -118 minecraft:water[level=0]
setblock 327 54 -118 minecraft:kelp_plant
fill 282 54 -119 293 54 -119 minecraft:water[level=0]
setblock 294 54 -119 minecraft:kelp_plant
fill 295 54 -119 317 54 -119 minecraft:water[level=0]
setblock 318 54 -119 minecraft:kelp_plant
fill 319 54 -119 320 54 -119 minecraft:water[level=0]
setblock 321 54 -119 minecraft:kelp_plant
fill 322 54 -119 326 54 -119 minecraft:water[level=0]
setblock 327 54 -119 minecraft:kelp_plant
fill 283 54 -120 323 54 -120 minecraft:water[level=0]
fill 324 54 -120 325 54 -120 minecraft:kelp_plant
fill 326 54 -120 327 54 -120 minecraft:water[level=0]
fill 284 54 -121 315 54 -121 minecraft:water[level=0]
setblock 316 54 -121 minecraft:kelp_plant
fill 317 54 -121 324 54 -121 minecraft:water[level=0]
fill 325 54 -121 326 54 -121 minecraft:kelp_plant
setblock 327 54 -121 minecraft:water[level=0]
fill 286 54 -122 319 54 -122 minecraft:water[level=0]
fill 320 54 -122 321 54 -122 minecraft:kelp_plant
fill 322 54 -122 323 54 -122 minecraft:water[level=0]
setblock 324 54 -122 minecraft:kelp_plant
fill 325 54 -122 327 54 -122 minecraft:water[level=0]
fill 287 54 -123 312 54 -123 minecraft:water[level=0]
setblock 313 54 -123 minecraft:kelp_plant
fill 314 54 -123 321 54 -123 minecraft:water[level=0]
setblock 322 54 -123 minecraft:kelp_plant
fill 323 54 -123 327 54 -123 minecraft:water[level=0]
fill 287 54 -124 323 54 -124 minecraft:water[level=0]
setblock 324 54 -124 minecraft:tall_seagrass[half=lower]
fill 325 54 -124 326 54 -124 minecraft:water[level=0]
fill 288 54 -125 313 54 -125 minecraft:water[level=0]
setblock 314 54 -125 minecraft:kelp_plant
fill 315 54 -125 325 54 -125 minecraft:water[level=0]
setblock 326 54 -125 minecraft:kelp_plant
fill 293 54 -126 318 54 -126 minecraft:water[level=0]
fill 319 54 -126 321 54 -126 minecraft:kelp_plant
fill 322 54 -126 323 54 -126 minecraft:water[level=0]
fill 324 54 -126 325 54 -126 minecraft:kelp_plant
setblock 326 54 -126 minecraft:tall_seagrass[half=lower]
fill 271 53 -116 288 53 -116 minecraft:water[level=0]
setblock 289 53 -116 minecraft:kelp_plant
fill 290 53 -116 310 53 -116 minecraft:water[level=0]
setblock 311 53 -116 minecraft:kelp_plant
fill 312 53 -116 320 53 -116 minecraft:water[level=0]
setblock 321 53 -116 minecraft:kelp_plant
fill 322 53 -116 324 53 -116 minecraft:water[level=0]
fill 325 53 -116 327 53 -116 minecraft:kelp_plant
fill 272 53 -117 298 53 -117 minecraft:water[level=0]
setblock 299 53 -117 minecraft:kelp_plant
fill 300 53 -117 310 53 -117 minecraft:water[level=0]
setblock 311 53 -117 minecraft:kelp_plant
fill 312 53 -117 322 53 -117 minecraft:water[level=0]
setblock 323 53 -117 minecraft:kelp_plant
fill 324 53 -117 325 53 -117 minecraft:water[level=0]
setblock 326 53 -117 minecraft:kelp_plant
setblock 327 53 -117 minecraft:water[level=0]
fill 281 53 -118 305 53 -118 minecraft:water[level=0]
setblock 306 53 -118 minecraft:kelp_plant
fill 307 53 -118 308 53 -118 minecraft:water[level=0]
setblock 309 53 -118 minecraft:kelp_plant
fill 310 53 -118 326 53 -118 minecraft:water[level=0]
setblock 327 53 -118 minecraft:kelp_plant
fill 282 53 -119 293 53 -119 minecraft:water[level=0]
setblock 294 53 -119 minecraft:kelp_plant
fill 295 53 -119 317 53 -119 minecraft:water[level=0]
setblock 318 53 -119 minecraft:kelp_plant
fill 319 53 -119 320 53 -119 minecraft:water[level=0]
setblock 321 53 -119 minecraft:kelp_plant
fill 322 53 -119 326 53 -119 minecraft:water[level=0]
setblock 327 53 -119 minecraft:kelp_plant
fill 283 53 -120 323 53 -120 minecraft:water[level=0]
fill 324 53 -120 325 53 -120 minecraft:kelp_plant
fill 326 53 -120 327 53 -120 minecraft:water[level=0]
fill 284 53 -121 315 53 -121 minecraft:water[level=0]
setblock 316 53 -121 minecraft:kelp_plant
fill 317 53 -121 324 53 -121 minecraft:water[level=0]
fill 325 53 -121 326 53 -121 minecraft:kelp_plant
setblock 327 53 -121 minecraft:water[level=0]
fill 286 53 -122 319 53 -122 minecraft:water[level=0]
fill 320 53 -122 321 53 -122 minecraft:kelp_plant
fill 322 53 -122 323 53 -122 minecraft:water[level=0]
setblock 324 53 -122 minecraft:kelp_plant
fill 325 53 -122 327 53 -122 minecraft:water[level=0]
fill 287 53 -123 312 53 -123 minecraft:water[level=0]
setblock 313 53 -123 minecraft:kelp_plant
fill 314 53 -123 321 53 -123 minecraft:water[level=0]
setblock 322 53 -123 minecraft:kelp_plant
fill 323 53 -123 326 53 -123 minecraft:water[level=0]
fill 287 53 -124 323 53 -124 minecraft:water[level=0]
fill 288 53 -125 313 53 -125 minecraft:water[level=0]
setblock 314 53 -125 minecraft:kelp_plant
fill 315 53 -125 323 53 -125 minecraft:water[level=0]
fill 293 53 -126 318 53 -126 minecraft:water[level=0]
fill 319 53 -126 321 53 -126 minecraft:kelp_plant
fill 322 53 -126 323 53 -126 minecraft:water[level=0]
fill 271 52 -116 288 52 -116 minecraft:water[level=0]
setblock 289 52 -116 minecraft:kelp_plant
fill 290 52 -116 310 52 -116 minecraft:water[level=0]
setblock 311 52 -116 minecraft:kelp_plant
fill 312 52 -116 320 52 -116 minecraft:water[level=0]
setblock 321 52 -116 minecraft:kelp_plant
fill 322 52 -116 324 52 -116 minecraft:water[level=0]
fill 325 52 -116 327 52 -116 minecraft:kelp_plant
fill 272 52 -117 298 52 -117 minecraft:water[level=0]
setblock 299 52 -117 minecraft:kelp_plant
fill 300 52 -117 310 52 -117 minecraft:water[level=0]
setblock 311 52 -117 minecraft:kelp_plant
fill 312 52 -117 322 52 -117 minecraft:water[level=0]
setblock 323 52 -117 minecraft:kelp_plant
fill 324 52 -117 325 52 -117 minecraft:water[level=0]
setblock 326 52 -117 minecraft:kelp_plant
setblock 327 52 -117 minecraft:water[level=0]
fill 273 52 -118 277 52 -118 minecraft:water[level=0]
fill 281 52 -118 305 52 -118 minecraft:water[level=0]
setblock 306 52 -118 minecraft:kelp_plant
fill 307 52 -118 308 52 -118 minecraft:water[level=0]
setblock 309 52 -118 minecraft:kelp_plant
fill 310 52 -118 326 52 -118 minecraft:water[level=0]
setblock 327 52 -118 minecraft:kelp_plant
fill 272 52 -119 277 52 -119 minecraft:water[level=0]
fill 282 52 -119 293 52 -119 minecraft:water[level=0]
setblock 294 52 -119 minecraft:kelp_plant
fill 295 52 -119 317 52 -119 minecraft:water[level=0]
setblock 318 52 -119 minecraft:kelp_plant
fill 319 52 -119 320 52 -119 minecraft:water[level=0]
setblock 321 52 -119 minecraft:kelp_plant
fill 322 52 -119 326 52 -119 minecraft:water[level=0]
setblock 327 52 -119 minecraft:kelp_plant
fill 272 52 -120 276 52 -120 minecraft:water[level=0]
fill 283 52 -120 323 52 -120 minecraft:water[level=0]
fill 324 52 -120 325 52 -120 minecraft:kelp_plant
fill 326 52 -120 327 52 -120 minecraft:water[level=0]
fill 272 52 -121 275 52 -121 minecraft:water[level=0]
fill 284 52 -121 315 52 -121 minecraft:water[level=0]
setblock 316 52 -121 minecraft:kelp_plant
fill 317 52 -121 324 52 -121 minecraft:water[level=0]
fill 325 52 -121 326 52 -121 minecraft:kelp_plant
setblock 327 52 -121 minecraft:water[level=0]
fill 271 52 -122 274 52 -122 minecraft:water[level=0]
fill 286 52 -122 319 52 -122 minecraft:water[level=0]
fill 320 52 -122 321 52 -122 minecraft:kelp_plant
fill 322 52 -122 323 52 -122 minecraft:water[level=0]
fill 271 52 -123 274 52 -123 minecraft:water[level=0]
fill 287 52 -123 312 52 -123 minecraft:water[level=0]
setblock 313 52 -123 minecraft:kelp_plant
fill 314 52 -123 319 52 -123 minecraft:water[level=0]
setblock 321 52 -123 minecraft:water[level=0]
setblock 322 52 -123 minecraft:kelp_plant
fill 271 52 -124 274 52 -124 minecraft:water[level=0]
fill 287 52 -124 319 52 -124 minecraft:water[level=0]
fill 271 52 -125 274 52 -125 minecraft:water[level=0]
fill 288 52 -125 313 52 -125 minecraft:water[level=0]
setblock 314 52 -125 minecraft:kelp_plant
fill 315 52 -125 321 52 -125 minecraft:water[level=0]
fill 271 52 -126 274 52 -126 minecraft:water[level=0]
fill 293 52 -126 318 52 -126 minecraft:water[level=0]
fill 319 52 -126 321 52 -126 minecraft:kelp_plant
setblock 322 52 -126 minecraft:water[level=0]
fill 271 51 -116 288 51 -116 minecraft:water[level=0]
setblock 289 51 -116 minecraft:kelp_plant
fill 290 51 -116 310 51 -116 minecraft:water[level=0]
setblock 311 51 -116 minecraft:kelp_plant
fill 312 51 -116 320 51 -116 minecraft:water[level=0]
setblock 321 51 -116 minecraft:kelp_plant
fill 322 51 -116 324 51 -116 minecraft:water[level=0]
fill 325 51 -116 327 51 -116 minecraft:kelp_plant
fill 272 51 -117 298 51 -117 minecraft:water[level=0]
setblock 299 51 -117 minecraft:kelp_plant
fill 300 51 -117 310 51 -117 minecraft:water[level=0]
setblock 311 51 -117 minecraft:kelp_plant
fill 312 51 -117 322 51 -117 minecraft:water[level=0]
setblock 323 51 -117 minecraft:kelp_plant
fill 324 51 -117 325 51 -117 minecraft:water[level=0]
setblock 326 51 -117 minecraft:kelp_plant
setblock 327 51 -117 minecraft:water[level=0]
fill 272 51 -118 278 51 -118 minecraft:water[level=0]
fill 281 51 -118 305 51 -118 minecraft:water[level=0]
setblock 306 51 -118 minecraft:kelp_plant
fill 307 51 -118 308 51 -118 minecraft:water[level=0]
setblock 309 51 -118 minecraft:kelp_plant
fill 310 51 -118 326 51 -118 minecraft:water[level=0]
setblock 327 51 -118 minecraft:kelp_plant
fill 272 51 -119 277 51 -119 minecraft:water[level=0]
fill 282 51 -119 293 51 -119 minecraft:water[level=0]
setblock 294 51 -119 minecraft:kelp_plant
fill 295 51 -119 317 51 -119 minecraft:water[level=0]
setblock 318 51 -119 minecraft:kelp_plant
fill 319 51 -119 320 51 -119 minecraft:water[level=0]
setblock 321 51 -119 minecraft:kelp_plant
fill 322 51 -119 323 51 -119 minecraft:water[level=0]
fill 325 51 -119 326 51 -119 minecraft:water[level=0]
setblock 327 51 -119 minecraft:kelp_plant
fill 271 51 -120 276 51 -120 minecraft:water[level=0]
fill 283 51 -120 320 51 -120 minecraft:water[level=0]
fill 271 51 -121 275 51 -121 minecraft:water[level=0]
fill 284 51 -121 315 51 -121 minecraft:water[level=0]
setblock 316 51 -121 minecraft:kelp_plant
fill 317 51 -121 321 51 -121 minecraft:water[level=0]
fill 270 51 -122 275 51 -122 minecraft:water[level=0]
fill 286 51 -122 316 51 -122 minecraft:water[level=0]
fill 318 51 -122 319 51 -122 minecraft:water[level=0]
setblock 320 51 -122 minecraft:kelp_plant
fill 270 51 -123 275 51 -123 minecraft:water[level=0]
fill 287 51 -123 312 51 -123 minecraft:water[level=0]
setblock 313 51 -123 minecraft:kelp_plant
fill 314 51 -123 317 51 -123 minecraft:water[level=0]
fill 270 51 -124 274 51 -124 minecraft:water[level=0]
fill 287 51 -124 315 51 -124 minecraft:water[level=0]
fill 270 51 -125 275 51 -125 minecraft:water[level=0]
fill 288 51 -125 313 51 -125 minecraft:water[level=0]
setblock 314 51 -125 minecraft:kelp_plant
setblock 315 51 -125 minecraft:water[level=0]
fill 317 51 -125 318 51 -125 minecraft:water[level=0]
fill 270 51 -126 274 51 -126 minecraft:water[level=0]
fill 294 51 -126 318 51 -126 minecraft:water[level=0]
setblock 319 51 -126 minecraft:kelp_plant
fill 270 50 -116 288 50 -116 minecraft:water[level=0]
setblock 289 50 -116 minecraft:kelp_plant
fill 290 50 -116 310 50 -116 minecraft:water[level=0]
setblock 311 50 -116 minecraft:kelp_plant
fill 312 50 -116 320 50 -116 minecraft:water[level=0]
setblock 321 50 -116 minecraft:kelp_plant
fill 322 50 -116 324 50 -116 minecraft:water[level=0]
fill 325 50 -116 327 50 -116 minecraft:kelp_plant
fill 271 50 -117 298 50 -117 minecraft:water[level=0]
setblock 299 50 -117 minecraft:kelp_plant
fill 300 50 -117 310 50 -117 minecraft:water[level=0]
setblock 311 50 -117 minecraft:kelp_plant
fill 312 50 -117 320 50 -117 minecraft:water[level=0]
setblock 322 50 -117 minecraft:water[level=0]
setblock 323 50 -117 minecraft:kelp_plant
fill 272 50 -118 277 50 -118 minecraft:water[level=0]
fill 282 50 -118 305 50 -118 minecraft:water[level=0]
setblock 306 50 -118 minecraft:kelp_plant
fill 307 50 -118 308 50 -118 minecraft:water[level=0]
setblock 309 50 -118 minecraft:kelp_plant
fill 310 50 -118 320 50 -118 minecraft:water[level=0]
fill 272 50 -119 277 50 -119 minecraft:water[level=0]
fill 283 50 -119 293 50 -119 minecraft:water[level=0]
setblock 294 50 -119 minecraft:kelp_plant
fill 295 50 -119 317 50 -119 minecraft:water[level=0]
setblock 318 50 -119 minecraft:kelp_plant
setblock 320 50 -119 minecraft:water[level=0]
fill 271 50 -120 276 50 -120 minecraft:water[level=0]
fill 283 50 -120 317 50 -120 minecraft:water[level=0]
fill 271 50 -121 275 50 -121 minecraft:water[level=0]
fill 284 50 -121 315 50 -121 minecraft:water[level=0]
setblock 316 50 -121 minecraft:kelp_plant
setblock 318 50 -121 minecraft:water[level=0]
fill 270 50 -122 275 50 -122 minecraft:water[level=0]
fill 286 50 -122 315 50 -122 minecraft:water[level=0]
fill 270 50 -123 275 50 -123 minecraft:water[level=0]
fill 286 50 -123 309 50 -123 minecraft:water[level=0]
setblock 310 50 -123 minecraft:seagrass
fill 311 50 -123 312 50 -123 minecraft:water[level=0]
fill 270 50 -124 275 50 -124 minecraft:water[level=0]
fill 287 50 -124 306 50 -124 minecraft:water[level=0]
fill 270 50 -125 275 50 -125 minecraft:water[level=0]
fill 288 50 -125 306 50 -125 minecraft:water[level=0]
fill 270 50 -126 274 50 -126 minecraft:water[level=0]
fill 294 50 -126 306 50 -126 minecraft:water[level=0]
fill 269 49 -116 288 49 -116 minecraft:water[level=0]
setblock 289 49 -116 minecraft:kelp_plant
fill 290 49 -116 309 49 -116 minecraft:water[level=0]
setblock 310 49 -116 minecraft:tall_seagrass[half=upper]
setblock 311 49 -116 minecraft:kelp_plant
fill 312 49 -116 316 49 -116 minecraft:water[level=0]
fill 318 49 -116 320 49 -116 minecraft:water[level=0]
setblock 321 49 -116 minecraft:kelp_plant
fill 270 49 -117 298 49 -117 minecraft:water[level=0]
setblock 299 49 -117 minecraft:kelp_plant
fill 300 49 -117 304 49 -117 minecraft:water[level=0]
setblock 305 49 -117 minecraft:tall_seagrass[half=upper]
fill 306 49 -117 310 49 -117 minecraft:water[level=0]
setblock 311 49 -117 minecraft:kelp_plant
fill 312 49 -117 316 49 -117 minecraft:water[level=0]
fill 318 49 -117 319 49 -117 minecraft:water[level=0]
fill 272 49 -118 277 49 -118 minecraft:water[level=0]
fill 282 49 -118 303 49 -118 minecraft:water[level=0]
setblock 304 49 -118 minecraft:tall_seagrass[half=upper]
setblock 305 49 -118 minecraft:water[level=0]
setblock 306 49 -118 minecraft:kelp_plant
setblock 307 49 -118 minecraft:tall_seagrass[half=upper]
setblock 308 49 -118 minecraft:water[level=0]
setblock 309 49 -118 minecraft:kelp_plant
fill 310 49 -118 316 49 -118 minecraft:water[level=0]
fill 273 49 -119 275 49 -119 minecraft:water[level=0]
fill 283 49 -119 293 49 -119 minecraft:water[level=0]
setblock 294 49 -119 minecraft:kelp_plant
fill 295 49 -119 301 49 -119 minecraft:water[level=0]
setblock 302 49 -119 minecraft:tall_seagrass[half=upper]
fill 303 49 -119 317 49 -119 minecraft:water[level=0]
fill 272 49 -120 275 49 -120 minecraft:water[level=0]
fill 283 49 -120 298 49 -120 minecraft:water[level=0]
setblock 299 49 -120 minecraft:tall_seagrass[half=upper]
fill 300 49 -120 303 49 -120 minecraft:water[level=0]
setblock 304 49 -120 minecraft:seagrass
fill 305 49 -120 306 49 -120 minecraft:water[level=0]
setblock 307 49 -120 minecraft:seagrass
fill 308 49 -120 315 49 -120 minecraft:water[level=0]
fill 271 49 -121 274 49 -121 minecraft:water[level=0]
fill 284 49 -121 302 49 -121 minecraft:water[level=0]
fill 303 49 -121 304 49 -121 minecraft:seagrass
fill 305 49 -121 315 49 -121 minecraft:water[level=0]
fill 271 49 -122 274 49 -122 minecraft:water[level=0]
fill 285 49 -122 303 49 -122 minecraft:water[level=0]
setblock 305 49 -122 minecraft:water[level=0]
fill 271 49 -123 274 49 -123 minecraft:water[level=0]
fill 285 49 -123 306 49 -123 minecraft:water[level=0]
fill 271 49 -124 274 49 -124 minecraft:water[level=0]
fill 286 49 -124 306 49 -124 minecraft:water[level=0]
fill 271 49 -125 274 49 -125 minecraft:water[level=0]
fill 287 49 -125 306 49 -125 minecraft:water[level=0]
fill 271 49 -126 274 49 -126 minecraft:water[level=0]
setblock 288 49 -126 minecraft:water[level=0]
fill 295 49 -126 306 49 -126 minecraft:water[level=0]
fill 264 48 -116 288 48 -116 minecraft:water[level=0]
setblock 289 48 -116 minecraft:kelp_plant
fill 290 48 -116 300 48 -116 minecraft:water[level=0]
setblock 301 48 -116 minecraft:seagrass
fill 302 48 -116 303 48 -116 minecraft:water[level=0]
fill 304 48 -116 305 48 -116 minecraft:seagrass
setblock 306 48 -116 minecraft:water[level=0]
setblock 307 48 -116 minecraft:seagrass
fill 308 48 -116 309 48 -116 minecraft:water[level=0]
setblock 310 48 -116 minecraft:tall_seagrass[half=lower]
setblock 311 48 -116 minecraft:kelp_plant
fill 312 48 -116 316 48 -116 minecraft:water[level=0]
fill 264 48 -117 279 48 -117 minecraft:water[level=0]
fill 282 48 -117 298 48 -117 minecraft:water[level=0]
setblock 299 48 -117 minecraft:kelp_plant
fill 300 48 -117 304 48 -117 minecraft:water[level=0]
setblock 305 48 -117 minecraft:tall_seagrass[half=lower]
setblock 306 48 -117 minecraft:water[level=0]
setblock 307 48 -117 minecraft:seagrass
fill 308 48 -117 309 48 -117 minecraft:water[level=0]
setblock 310 48 -117 minecraft:seagrass
setblock 311 48 -117 minecraft:kelp_plant
fill 312 48 -117 316 48 -117 minecraft:water[level=0]
fill 264 48 -118 277 48 -118 minecraft:water[level=0]
fill 284 48 -118 303 48 -118 minecraft:water[level=0]
setblock 304 48 -118 minecraft:tall_seagrass[half=lower]
setblock 305 48 -118 minecraft:water[level=0]
setblock 306 48 -118 minecraft:kelp_plant
setblock 307 48 -118 minecraft:tall_seagrass[half=lower]
setblock 308 48 -118 minecraft:water[level=0]
setblock 309 48 -118 minecraft:kelp_plant
fill 310 48 -118 315 48 -118 minecraft:water[level=0]
fill 264 48 -119 270 48 -119 minecraft:water[level=0]
fill 284 48 -119 293 48 -119 minecraft:water[level=0]
setblock 294 48 -119 minecraft:kelp_plant
fill 295 48 -119 301 48 -119 minecraft:water[level=0]
setblock 302 48 -119 minecraft:tall_seagrass[half=lower]
setblock 303 48 -119 minecraft:seagrass
fill 305 48 -119 307 48 -119 minecraft:water[level=0]
fill 308 48 -119 309 48 -119 minecraft:seagrass
fill 310 48 -119 315 48 -119 minecraft:water[level=0]
fill 264 48 -120 269 48 -120 minecraft:water[level=0]
fill 284 48 -120 288 48 -120 minecraft:water[level=0]
fill 294 48 -120 298 48 -120 minecraft:water[level=0]
setblock 299 48 -120 minecraft:tall_seagrass[half=lower]
fill 300 48 -120 302 48 -120 minecraft:water[level=0]
setblock 308 48 -120 minecraft:water[level=0]
fill 309 48 -120 310 48 -120 minecraft:seagrass
fill 311 48 -120 315 48 -120 minecraft:water[level=0]
fill 264 48 -121 270 48 -121 minecraft:water[level=0]
fill 284 48 -121 302 48 -121 minecraft:water[level=0]
fill 264 48 -122 270 48 -122 minecraft:water[level=0]
fill 282 48 -122 301 48 -122 minecraft:water[level=0]
fill 304 48 -122 306 48 -122 minecraft:water[level=0]
fill 264 48 -123 270 48 -123 minecraft:water[level=0]
fill 274 48 -123 301 48 -123 minecraft:water[level=0]
fill 303 48 -123 306 48 -123 minecraft:water[level=0]
fill 264 48 -124 271 48 -124 minecraft:water[level=0]
fill 273 48 -124 301 48 -124 minecraft:water[level=0]
fill 303 48 -124 307 48 -124 minecraft:water[level=0]
fill 264 48 -125 291 48 -125 minecraft:water[level=0]
fill 293 48 -125 302 48 -125 minecraft:water[level=0]
fill 304 48 -125 306 48 -125 minecraft:water[level=0]
fill 264 48 -126 289 48 -126 minecraft:water[level=0]
fill 296 48 -126 303 48 -126 minecraft:water[level=0]
fill 264 47 -116 271 47 -116 minecraft:water[level=0]
fill 273 47 -116 278 47 -116 minecraft:water[level=0]
fill 264 47 -117 271 47 -117 minecraft:water[level=0]
fill 274 47 -117 277 47 -117 minecraft:water[level=0]
fill 264 47 -118 270 47 -118 minecraft:water[level=0]
fill 264 47 -119 270 47 -119 minecraft:water[level=0]
fill 264 47 -120 270 47 -120 minecraft:water[level=0]
fill 264 47 -121 270 47 -121 minecraft:water[level=0]
fill 305 47 -121 306 47 -121 minecraft:water[level=0]
fill 264 47 -122 270 47 -122 minecraft:water[level=0]
fill 294 47 -122 298 47 -122 minecraft:water[level=0]
fill 304 47 -122 307 47 -122 minecraft:water[level=0]
fill 264 47 -123 270 47 -123 minecraft:water[level=0]
fill 274 47 -123 284 47 -123 minecraft:water[level=0]
fill 294 47 -123 298 47 -123 minecraft:water[level=0]
fill 304 47 -123 307 47 -123 minecraft:water[level=0]
fill 264 47 -124 271 47 -124 minecraft:water[level=0]
fill 273 47 -124 286 47 -124 minecraft:water[level=0]
fill 304 47 -124 307 47 -124 minecraft:water[level=0]
fill 264 47 -125 286 47 -125 minecraft:water[level=0]
fill 305 47 -125 306 47 -125 minecraft:water[level=0]
fill 264 47 -126 287 47 -126 minecraft:water[level=0]
fill 264 46 -116 269 46 -116 minecraft:water[level=0]
fill 264 46 -117 269 46 -117 minecraft:water[level=0]
fill 264 46 -118 269 46 -118 minecraft:water[level=0]
fill 264 46 -119 270 46 -119 minecraft:water[level=0]
fill 264 46 -120 270 46 -120 minecraft:water[level=0]
setblock 306 46 -120 minecraft:water[level=0]
fill 264 46 -121 270 46 -121 minecraft:water[level=0]
fill 293 46 -121 297 46 -121 minecraft:water[level=0]
fill 304 46 -121 307 46 -121 minecraft:water[level=0]
fill 264 46 -122 270 46 -122 minecraft:water[level=0]
fill 293 46 -122 297 46 -122 minecraft:water[level=0]
fill 304 46 -122 307 46 -122 minecraft:water[level=0]
fill 264 46 -123 270 46 -123 minecraft:water[level=0]
fill 274 46 -123 281 46 -123 minecraft:water[level=0]
fill 304 46 -123 307 46 -123 minecraft:water[level=0]
fill 264 46 -124 271 46 -124 minecraft:water[level=0]
fill 273 46 -124 284 46 -124 minecraft:water[level=0]
fill 305 46 -124 306 46 -124 minecraft:water[level=0]
fill 264 46 -125 284 46 -125 minecraft:water[level=0]
fill 264 46 -126 285 46 -126 minecraft:water[level=0]
fill 264 45 -116 269 45 -116 minecraft:water[level=0]
fill 264 45 -117 269 45 -117 minecraft:water[level=0]
fill 264 45 -118 269 45 -118 minecraft:water[level=0]
fill 264 45 -119 269 45 -119 minecraft:water[level=0]
fill 306 45 -119 307 45 -119 minecraft:water[level=0]
fill 264 45 -120 270 45 -120 minecraft:water[level=0]
fill 292 45 -120 297 45 -120 minecraft:water[level=0]
fill 305 45 -120 308 45 -120 minecraft:water[level=0]
fill 264 45 -121 270 45 -121 minecraft:water[level=0]
fill 292 45 -121 297 45 -121 minecraft:water[level=0]
fill 305 45 -121 308 45 -121 minecraft:water[level=0]
fill 264 45 -122 270 45 -122 minecraft:water[level=0]
fill 305 45 -122 308 45 -122 minecraft:water[level=0]
fill 264 45 -123 271 45 -123 minecraft:water[level=0]
fill 274 45 -123 280 45 -123 minecraft:water[level=0]
fill 305 45 -123 307 45 -123 minecraft:water[level=0]
fill 264 45 -124 271 45 -124 minecraft:water[level=0]
fill 273 45 -124 284 45 -124 minecraft:water[level=0]
fill 264 45 -125 284 45 -125 minecraft:water[level=0]
fill 264 45 -126 284 45 -126 minecraft:water[level=0]
forceload remove 264 -126 327 -63
tellraw @a {"text":"Campus zurueck a40 fertig.","color":"green"}
