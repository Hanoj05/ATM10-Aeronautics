# Abschnitt a25: x 200..263, z -254..-191 (6448 Blöcke)
forceload add 200 -254 263 -191
tellraw @a {"text":"Campus zurueck a25: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a25_1 2s
