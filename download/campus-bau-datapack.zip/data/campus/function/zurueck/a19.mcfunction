# Abschnitt a19: x 264..327, z -318..-255 (7595 Blöcke)
forceload add 264 -318 327 -255
tellraw @a {"text":"Campus zurueck a19: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a19_1 2s
