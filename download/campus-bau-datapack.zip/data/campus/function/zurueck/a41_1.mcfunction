setblock 332 72 -126 minecraft:air
setblock 342 72 -126 minecraft:air
setblock 332 71 -124 minecraft:air
setblock 342 71 -124 minecraft:air
fill 331 71 -125 333 71 -125 minecraft:air
fill 341 71 -125 343 71 -125 minecraft:air
fill 330 71 -126 334 71 -126 minecraft:air
fill 340 71 -126 344 71 -126 minecraft:air
fill 331 70 -124 333 70 -124 minecraft:air
fill 341 70 -124 343 70 -124 minecraft:air
fill 330 70 -125 334 70 -125 minecraft:air
fill 340 70 -125 344 70 -125 minecraft:air
fill 330 70 -126 334 70 -126 minecraft:air
fill 340 70 -126 344 70 -126 minecraft:air
setblock 332 69 -124 minecraft:air
setblock 342 69 -124 minecraft:air
fill 331 69 -125 333 69 -125 minecraft:air
fill 341 69 -125 343 69 -125 minecraft:air
fill 330 69 -126 334 69 -126 minecraft:air
fill 340 69 -126 344 69 -126 minecraft:air
setblock 332 68 -126 minecraft:air
setblock 342 68 -126 minecraft:air
setblock 332 67 -126 minecraft:air
setblock 342 67 -126 minecraft:air
setblock 332 66 -126 minecraft:air
setblock 342 66 -126 minecraft:air
setblock 349 66 -126 minecraft:air
fill 356 66 -126 359 66 -126 minecraft:air
fill 362 66 -126 363 66 -126 minecraft:air
setblock 366 66 -126 minecraft:air
fill 368 66 -126 370 66 -126 minecraft:air
fill 372 66 -126 375 66 -126 minecraft:air
setblock 385 66 -126 minecraft:air
setblock 388 66 -126 minecraft:air
setblock 390 66 -126 minecraft:air
fill 328 65 -116 386 65 -116 minecraft:air
fill 328 65 -117 391 65 -117 minecraft:air
fill 328 65 -118 391 65 -118 minecraft:air
fill 328 65 -119 391 65 -119 minecraft:air
fill 328 65 -120 391 65 -120 minecraft:air
fill 328 65 -121 391 65 -121 minecraft:air
fill 328 65 -122 391 65 -122 minecraft:air
fill 328 65 -123 391 65 -123 minecraft:air
fill 328 65 -124 391 65 -124 minecraft:air
fill 328 65 -125 391 65 -125 minecraft:air
fill 328 65 -126 391 65 -126 minecraft:air
fill 328 64 -116 386 64 -116 minecraft:air
fill 328 64 -117 391 64 -117 minecraft:air
fill 328 64 -118 391 64 -118 minecraft:air
fill 328 64 -119 391 64 -119 minecraft:air
fill 328 64 -120 391 64 -120 minecraft:air
fill 328 64 -121 391 64 -121 minecraft:air
fill 328 64 -122 391 64 -122 minecraft:air
fill 328 64 -123 391 64 -123 minecraft:air
fill 328 64 -124 391 64 -124 minecraft:air
fill 328 64 -125 391 64 -125 minecraft:air
fill 328 64 -126 391 64 -126 minecraft:air
fill 328 63 -116 386 63 -116 minecraft:air
fill 328 63 -117 391 63 -117 minecraft:air
fill 328 63 -118 391 63 -118 minecraft:air
fill 328 63 -119 391 63 -119 minecraft:air
fill 328 63 -120 391 63 -120 minecraft:air
fill 328 63 -121 391 63 -121 minecraft:air
fill 328 63 -122 391 63 -122 minecraft:air
fill 328 63 -123 391 63 -123 minecraft:air
fill 328 63 -124 391 63 -124 minecraft:air
fill 328 63 -125 391 63 -125 minecraft:air
fill 328 63 -126 391 63 -126 minecraft:air
fill 328 62 -116 341 62 -116 minecraft:water[level=0]
setblock 342 62 -116 minecraft:kelp[age=25]
fill 343 62 -116 359 62 -116 minecraft:water[level=0]
setblock 360 62 -116 minecraft:kelp[age=23]
fill 361 62 -116 363 62 -116 minecraft:water[level=0]
setblock 364 62 -116 minecraft:kelp[age=21]
setblock 365 62 -116 minecraft:water[level=0]
setblock 366 62 -116 minecraft:kelp[age=24]
fill 367 62 -116 368 62 -116 minecraft:water[level=0]
setblock 369 62 -116 minecraft:kelp[age=24]
fill 370 62 -116 371 62 -116 minecraft:water[level=0]
setblock 372 62 -116 minecraft:kelp[age=25]
fill 373 62 -116 386 62 -116 minecraft:water[level=0]
fill 328 62 -117 391 62 -117 minecraft:water[level=0]
fill 328 62 -118 331 62 -118 minecraft:water[level=0]
setblock 332 62 -118 minecraft:kelp[age=25]
setblock 333 62 -118 minecraft:kelp[age=24]
fill 334 62 -118 345 62 -118 minecraft:water[level=0]
setblock 346 62 -118 minecraft:kelp[age=23]
fill 347 62 -118 349 62 -118 minecraft:water[level=0]
setblock 350 62 -118 minecraft:kelp[age=25]
fill 351 62 -118 358 62 -118 minecraft:water[level=0]
setblock 359 62 -118 minecraft:kelp[age=24]
fill 360 62 -118 364 62 -118 minecraft:water[level=0]
setblock 365 62 -118 minecraft:kelp[age=24]
fill 366 62 -118 371 62 -118 minecraft:water[level=0]
setblock 372 62 -118 minecraft:kelp[age=22]
fill 373 62 -118 385 62 -118 minecraft:water[level=0]
setblock 386 62 -118 minecraft:kelp[age=24]
fill 387 62 -118 391 62 -118 minecraft:water[level=0]
fill 328 62 -119 379 62 -119 minecraft:water[level=0]
setblock 380 62 -119 minecraft:kelp[age=24]
fill 381 62 -119 391 62 -119 minecraft:water[level=0]
fill 328 62 -120 329 62 -120 minecraft:water[level=0]
setblock 330 62 -120 minecraft:kelp[age=21]
fill 331 62 -120 342 62 -120 minecraft:water[level=0]
setblock 343 62 -120 minecraft:kelp[age=22]
fill 344 62 -120 345 62 -120 minecraft:water[level=0]
setblock 346 62 -120 minecraft:kelp[age=25]
fill 347 62 -120 361 62 -120 minecraft:water[level=0]
setblock 362 62 -120 minecraft:kelp[age=23]
setblock 363 62 -120 minecraft:kelp[age=24]
fill 364 62 -120 371 62 -120 minecraft:water[level=0]
setblock 372 62 -120 minecraft:kelp[age=25]
fill 373 62 -120 391 62 -120 minecraft:water[level=0]
fill 328 62 -121 333 62 -121 minecraft:water[level=0]
setblock 334 62 -121 minecraft:kelp[age=23]
fill 335 62 -121 347 62 -121 minecraft:water[level=0]
setblock 348 62 -121 minecraft:kelp[age=22]
fill 349 62 -121 350 62 -121 minecraft:water[level=0]
setblock 351 62 -121 minecraft:kelp[age=22]
fill 352 62 -121 391 62 -121 minecraft:water[level=0]
setblock 328 62 -122 minecraft:kelp[age=23]
fill 329 62 -122 331 62 -122 minecraft:water[level=0]
setblock 332 62 -122 minecraft:kelp[age=22]
fill 333 62 -122 341 62 -122 minecraft:water[level=0]
setblock 342 62 -122 minecraft:kelp[age=21]
fill 343 62 -122 345 62 -122 minecraft:water[level=0]
setblock 346 62 -122 minecraft:kelp[age=21]
fill 347 62 -122 362 62 -122 minecraft:water[level=0]
setblock 363 62 -122 minecraft:kelp[age=24]
fill 364 62 -122 370 62 -122 minecraft:water[level=0]
setblock 371 62 -122 minecraft:kelp[age=21]
setblock 372 62 -122 minecraft:kelp[age=23]
fill 373 62 -122 384 62 -122 minecraft:water[level=0]
setblock 385 62 -122 minecraft:kelp[age=25]
fill 386 62 -122 391 62 -122 minecraft:water[level=0]
setblock 328 62 -123 minecraft:water[level=0]
setblock 329 62 -123 minecraft:kelp[age=25]
fill 330 62 -123 344 62 -123 minecraft:water[level=0]
fill 345 62 -123 346 62 -123 minecraft:kelp[age=24]
fill 347 62 -123 390 62 -123 minecraft:water[level=0]
setblock 391 62 -123 minecraft:kelp[age=25]
fill 328 62 -124 337 62 -124 minecraft:water[level=0]
setblock 338 62 -124 minecraft:kelp[age=24]
fill 339 62 -124 363 62 -124 minecraft:water[level=0]
setblock 364 62 -124 minecraft:kelp[age=22]
fill 365 62 -124 391 62 -124 minecraft:water[level=0]
fill 328 62 -125 342 62 -125 minecraft:water[level=0]
setblock 343 62 -125 minecraft:kelp[age=21]
fill 344 62 -125 346 62 -125 minecraft:water[level=0]
setblock 347 62 -125 minecraft:kelp[age=22]
fill 348 62 -125 364 62 -125 minecraft:water[level=0]
setblock 365 62 -125 minecraft:kelp[age=21]
fill 366 62 -125 391 62 -125 minecraft:water[level=0]
fill 328 62 -126 336 62 -126 minecraft:water[level=0]
setblock 337 62 -126 minecraft:kelp[age=24]
fill 338 62 -126 341 62 -126 minecraft:water[level=0]
setblock 342 62 -126 minecraft:kelp[age=21]
setblock 343 62 -126 minecraft:water[level=0]
setblock 344 62 -126 minecraft:kelp[age=21]
setblock 345 62 -126 minecraft:water[level=0]
setblock 346 62 -126 minecraft:kelp[age=23]
fill 347 62 -126 348 62 -126 minecraft:water[level=0]
setblock 349 62 -126 minecraft:kelp[age=25]
fill 350 62 -126 352 62 -126 minecraft:water[level=0]
setblock 353 62 -126 minecraft:kelp[age=24]
fill 354 62 -126 366 62 -126 minecraft:water[level=0]
setblock 367 62 -126 minecraft:kelp[age=23]
fill 368 62 -126 374 62 -126 minecraft:water[level=0]
setblock 375 62 -126 minecraft:kelp[age=24]
setblock 376 62 -126 minecraft:water[level=0]
setblock 377 62 -126 minecraft:kelp[age=23]
fill 378 62 -126 391 62 -126 minecraft:water[level=0]
fill 328 61 -116 341 61 -116 minecraft:water[level=0]
setblock 342 61 -116 minecraft:kelp_plant
fill 343 61 -116 345 61 -116 minecraft:water[level=0]
setblock 346 61 -116 minecraft:kelp[age=25]
fill 347 61 -116 354 61 -116 minecraft:water[level=0]
setblock 355 61 -116 minecraft:kelp[age=25]
fill 356 61 -116 359 61 -116 minecraft:water[level=0]
setblock 360 61 -116 minecraft:kelp_plant
fill 361 61 -116 363 61 -116 minecraft:water[level=0]
setblock 364 61 -116 minecraft:kelp_plant
setblock 365 61 -116 minecraft:water[level=0]
setblock 366 61 -116 minecraft:kelp_plant
fill 367 61 -116 368 61 -116 minecraft:water[level=0]
setblock 369 61 -116 minecraft:kelp_plant
fill 370 61 -116 371 61 -116 minecraft:water[level=0]
setblock 372 61 -116 minecraft:kelp_plant
fill 373 61 -116 386 61 -116 minecraft:water[level=0]
fill 328 61 -117 336 61 -117 minecraft:water[level=0]
setblock 337 61 -117 minecraft:kelp[age=25]
fill 338 61 -117 391 61 -117 minecraft:water[level=0]
fill 328 61 -118 331 61 -118 minecraft:water[level=0]
fill 332 61 -118 333 61 -118 minecraft:kelp_plant
fill 334 61 -118 335 61 -118 minecraft:water[level=0]
setblock 336 61 -118 minecraft:kelp[age=25]
fill 337 61 -118 341 61 -118 minecraft:water[level=0]
setblock 342 61 -118 minecraft:kelp[age=25]
fill 343 61 -118 345 61 -118 minecraft:water[level=0]
setblock 346 61 -118 minecraft:kelp_plant
fill 347 61 -118 349 61 -118 minecraft:water[level=0]
setblock 350 61 -118 minecraft:kelp_plant
fill 351 61 -118 354 61 -118 minecraft:water[level=0]
setblock 355 61 -118 minecraft:kelp[age=25]
fill 356 61 -118 358 61 -118 minecraft:water[level=0]
setblock 359 61 -118 minecraft:kelp_plant
fill 360 61 -118 363 61 -118 minecraft:water[level=0]
setblock 364 61 -118 minecraft:kelp[age=25]
setblock 365 61 -118 minecraft:kelp_plant
fill 366 61 -118 371 61 -118 minecraft:water[level=0]
setblock 372 61 -118 minecraft:kelp_plant
fill 373 61 -118 385 61 -118 minecraft:water[level=0]
setblock 386 61 -118 minecraft:kelp_plant
fill 387 61 -118 391 61 -118 minecraft:water[level=0]
fill 328 61 -119 355 61 -119 minecraft:water[level=0]
setblock 356 61 -119 minecraft:kelp[age=25]
fill 357 61 -119 361 61 -119 minecraft:water[level=0]
setblock 362 61 -119 minecraft:kelp[age=25]
fill 363 61 -119 379 61 -119 minecraft:water[level=0]
setblock 380 61 -119 minecraft:kelp_plant
fill 381 61 -119 391 61 -119 minecraft:water[level=0]
fill 328 61 -120 329 61 -120 minecraft:water[level=0]
setblock 330 61 -120 minecraft:kelp_plant
fill 331 61 -120 342 61 -120 minecraft:water[level=0]
setblock 343 61 -120 minecraft:kelp_plant
fill 344 61 -120 345 61 -120 minecraft:water[level=0]
setblock 346 61 -120 minecraft:kelp_plant
fill 347 61 -120 361 61 -120 minecraft:water[level=0]
fill 362 61 -120 363 61 -120 minecraft:kelp_plant
fill 364 61 -120 371 61 -120 minecraft:water[level=0]
setblock 372 61 -120 minecraft:kelp_plant
fill 373 61 -120 391 61 -120 minecraft:water[level=0]
fill 328 61 -121 333 61 -121 minecraft:water[level=0]
setblock 334 61 -121 minecraft:kelp_plant
fill 335 61 -121 347 61 -121 minecraft:water[level=0]
setblock 348 61 -121 minecraft:kelp_plant
fill 349 61 -121 350 61 -121 minecraft:water[level=0]
setblock 351 61 -121 minecraft:kelp_plant
fill 352 61 -121 391 61 -121 minecraft:water[level=0]
setblock 328 61 -122 minecraft:kelp_plant
fill 329 61 -122 331 61 -122 minecraft:water[level=0]
setblock 332 61 -122 minecraft:kelp_plant
fill 333 61 -122 341 61 -122 minecraft:water[level=0]
setblock 342 61 -122 minecraft:kelp_plant
fill 343 61 -122 345 61 -122 minecraft:water[level=0]
setblock 346 61 -122 minecraft:kelp_plant
fill 347 61 -122 362 61 -122 minecraft:water[level=0]
setblock 363 61 -122 minecraft:kelp_plant
fill 364 61 -122 370 61 -122 minecraft:water[level=0]
fill 371 61 -122 372 61 -122 minecraft:kelp_plant
fill 373 61 -122 384 61 -122 minecraft:water[level=0]
setblock 385 61 -122 minecraft:kelp_plant
fill 386 61 -122 391 61 -122 minecraft:water[level=0]
setblock 328 61 -123 minecraft:water[level=0]
setblock 329 61 -123 minecraft:kelp_plant
fill 330 61 -123 344 61 -123 minecraft:water[level=0]
fill 345 61 -123 346 61 -123 minecraft:kelp_plant
fill 347 61 -123 389 61 -123 minecraft:water[level=0]
setblock 390 61 -123 minecraft:kelp[age=25]
setblock 391 61 -123 minecraft:kelp_plant
setblock 328 61 -124 minecraft:kelp[age=25]
fill 329 61 -124 337 61 -124 minecraft:water[level=0]
setblock 338 61 -124 minecraft:kelp_plant
fill 339 61 -124 363 61 -124 minecraft:water[level=0]
setblock 364 61 -124 minecraft:kelp_plant
fill 365 61 -124 391 61 -124 minecraft:water[level=0]
fill 328 61 -125 342 61 -125 minecraft:water[level=0]
setblock 343 61 -125 minecraft:kelp_plant
fill 344 61 -125 346 61 -125 minecraft:water[level=0]
setblock 347 61 -125 minecraft:kelp_plant
fill 348 61 -125 364 61 -125 minecraft:water[level=0]
setblock 365 61 -125 minecraft:kelp_plant
fill 366 61 -125 391 61 -125 minecraft:water[level=0]
fill 328 61 -126 336 61 -126 minecraft:water[level=0]
setblock 337 61 -126 minecraft:kelp_plant
setblock 338 61 -126 minecraft:water[level=0]
setblock 339 61 -126 minecraft:kelp[age=25]
fill 340 61 -126 341 61 -126 minecraft:water[level=0]
setblock 342 61 -126 minecraft:kelp_plant
setblock 343 61 -126 minecraft:water[level=0]
setblock 344 61 -126 minecraft:kelp_plant
setblock 345 61 -126 minecraft:kelp[age=25]
setblock 346 61 -126 minecraft:kelp_plant
fill 347 61 -126 348 61 -126 minecraft:water[level=0]
setblock 349 61 -126 minecraft:kelp_plant
fill 350 61 -126 352 61 -126 minecraft:water[level=0]
setblock 353 61 -126 minecraft:kelp_plant
fill 354 61 -126 366 61 -126 minecraft:water[level=0]
setblock 367 61 -126 minecraft:kelp_plant
fill 368 61 -126 374 61 -126 minecraft:water[level=0]
setblock 375 61 -126 minecraft:kelp_plant
setblock 376 61 -126 minecraft:water[level=0]
setblock 377 61 -126 minecraft:kelp_plant
fill 378 61 -126 391 61 -126 minecraft:water[level=0]
fill 328 60 -116 341 60 -116 minecraft:water[level=0]
setblock 342 60 -116 minecraft:kelp_plant
fill 343 60 -116 345 60 -116 minecraft:water[level=0]
setblock 346 60 -116 minecraft:kelp_plant
fill 347 60 -116 354 60 -116 minecraft:water[level=0]
setblock 355 60 -116 minecraft:kelp_plant
fill 356 60 -116 359 60 -116 minecraft:water[level=0]
setblock 360 60 -116 minecraft:kelp_plant
fill 361 60 -116 363 60 -116 minecraft:water[level=0]
setblock 364 60 -116 minecraft:kelp_plant
setblock 365 60 -116 minecraft:water[level=0]
setblock 366 60 -116 minecraft:kelp_plant
fill 367 60 -116 368 60 -116 minecraft:water[level=0]
setblock 369 60 -116 minecraft:kelp_plant
fill 370 60 -116 371 60 -116 minecraft:water[level=0]
setblock 372 60 -116 minecraft:kelp_plant
fill 373 60 -116 386 60 -116 minecraft:water[level=0]
fill 328 60 -117 336 60 -117 minecraft:water[level=0]
setblock 337 60 -117 minecraft:kelp_plant
fill 338 60 -117 343 60 -117 minecraft:water[level=0]
setblock 344 60 -117 minecraft:kelp[age=25]
fill 345 60 -117 391 60 -117 minecraft:water[level=0]
fill 328 60 -118 331 60 -118 minecraft:water[level=0]
fill 332 60 -118 333 60 -118 minecraft:kelp_plant
fill 334 60 -118 335 60 -118 minecraft:water[level=0]
setblock 336 60 -118 minecraft:kelp_plant
fill 337 60 -118 341 60 -118 minecraft:water[level=0]
setblock 342 60 -118 minecraft:kelp_plant
fill 343 60 -118 345 60 -118 minecraft:water[level=0]
setblock 346 60 -118 minecraft:kelp_plant
fill 347 60 -118 349 60 -118 minecraft:water[level=0]
setblock 350 60 -118 minecraft:kelp_plant
fill 351 60 -118 354 60 -118 minecraft:water[level=0]
setblock 355 60 -118 minecraft:kelp_plant
fill 356 60 -118 358 60 -118 minecraft:water[level=0]
setblock 359 60 -118 minecraft:kelp_plant
fill 360 60 -118 363 60 -118 minecraft:water[level=0]
fill 364 60 -118 365 60 -118 minecraft:kelp_plant
fill 366 60 -118 371 60 -118 minecraft:water[level=0]
setblock 372 60 -118 minecraft:kelp_plant
fill 373 60 -118 385 60 -118 minecraft:water[level=0]
setblock 386 60 -118 minecraft:kelp_plant
fill 387 60 -118 391 60 -118 minecraft:water[level=0]
fill 328 60 -119 355 60 -119 minecraft:water[level=0]
setblock 356 60 -119 minecraft:kelp_plant
fill 357 60 -119 361 60 -119 minecraft:water[level=0]
setblock 362 60 -119 minecraft:kelp_plant
fill 363 60 -119 379 60 -119 minecraft:water[level=0]
setblock 380 60 -119 minecraft:kelp_plant
fill 381 60 -119 391 60 -119 minecraft:water[level=0]
fill 328 60 -120 329 60 -120 minecraft:water[level=0]
setblock 330 60 -120 minecraft:kelp_plant
fill 331 60 -120 342 60 -120 minecraft:water[level=0]
setblock 343 60 -120 minecraft:kelp_plant
fill 344 60 -120 345 60 -120 minecraft:water[level=0]
setblock 346 60 -120 minecraft:kelp_plant
fill 347 60 -120 360 60 -120 minecraft:water[level=0]
setblock 361 60 -120 minecraft:kelp[age=25]
fill 362 60 -120 363 60 -120 minecraft:kelp_plant
fill 364 60 -120 371 60 -120 minecraft:water[level=0]
setblock 372 60 -120 minecraft:kelp_plant
fill 373 60 -120 391 60 -120 minecraft:water[level=0]
fill 328 60 -121 333 60 -121 minecraft:water[level=0]
setblock 334 60 -121 minecraft:kelp_plant
fill 335 60 -121 347 60 -121 minecraft:water[level=0]
setblock 348 60 -121 minecraft:kelp_plant
setblock 349 60 -121 minecraft:kelp[age=25]
setblock 350 60 -121 minecraft:water[level=0]
setblock 351 60 -121 minecraft:kelp_plant
fill 352 60 -121 354 60 -121 minecraft:water[level=0]
setblock 355 60 -121 minecraft:kelp[age=25]
fill 356 60 -121 391 60 -121 minecraft:water[level=0]
setblock 328 60 -122 minecraft:kelp_plant
fill 329 60 -122 331 60 -122 minecraft:water[level=0]
setblock 332 60 -122 minecraft:kelp_plant
fill 333 60 -122 341 60 -122 minecraft:water[level=0]
setblock 342 60 -122 minecraft:kelp_plant
fill 343 60 -122 345 60 -122 minecraft:water[level=0]
setblock 346 60 -122 minecraft:kelp_plant
fill 347 60 -122 362 60 -122 minecraft:water[level=0]
setblock 363 60 -122 minecraft:kelp_plant
fill 364 60 -122 366 60 -122 minecraft:water[level=0]
setblock 367 60 -122 minecraft:kelp[age=25]
fill 368 60 -122 370 60 -122 minecraft:water[level=0]
fill 371 60 -122 372 60 -122 minecraft:kelp_plant
fill 373 60 -122 384 60 -122 minecraft:water[level=0]
setblock 385 60 -122 minecraft:kelp_plant
fill 386 60 -122 391 60 -122 minecraft:water[level=0]
setblock 328 60 -123 minecraft:water[level=0]
setblock 329 60 -123 minecraft:kelp_plant
setblock 330 60 -123 minecraft:kelp[age=25]
fill 331 60 -123 336 60 -123 minecraft:water[level=0]
setblock 337 60 -123 minecraft:kelp[age=25]
fill 338 60 -123 344 60 -123 minecraft:water[level=0]
fill 345 60 -123 346 60 -123 minecraft:kelp_plant
fill 347 60 -123 348 60 -123 minecraft:water[level=0]
setblock 349 60 -123 minecraft:kelp[age=25]
fill 350 60 -123 354 60 -123 minecraft:water[level=0]
setblock 355 60 -123 minecraft:kelp[age=25]
fill 356 60 -123 382 60 -123 minecraft:water[level=0]
setblock 383 60 -123 minecraft:kelp[age=25]
fill 384 60 -123 389 60 -123 minecraft:water[level=0]
fill 390 60 -123 391 60 -123 minecraft:kelp_plant
setblock 328 60 -124 minecraft:kelp_plant
fill 329 60 -124 337 60 -124 minecraft:water[level=0]
setblock 338 60 -124 minecraft:kelp_plant
fill 339 60 -124 363 60 -124 minecraft:water[level=0]
setblock 364 60 -124 minecraft:kelp_plant
fill 365 60 -124 371 60 -124 minecraft:water[level=0]
setblock 372 60 -124 minecraft:kelp[age=25]
fill 373 60 -124 375 60 -124 minecraft:water[level=0]
setblock 376 60 -124 minecraft:kelp[age=25]
fill 377 60 -124 391 60 -124 minecraft:water[level=0]
fill 328 60 -125 342 60 -125 minecraft:water[level=0]
setblock 343 60 -125 minecraft:kelp_plant
fill 344 60 -125 346 60 -125 minecraft:water[level=0]
setblock 347 60 -125 minecraft:kelp_plant
fill 348 60 -125 364 60 -125 minecraft:water[level=0]
setblock 365 60 -125 minecraft:kelp_plant
fill 366 60 -125 391 60 -125 minecraft:water[level=0]
fill 328 60 -126 336 60 -126 minecraft:water[level=0]
setblock 337 60 -126 minecraft:kelp_plant
setblock 338 60 -126 minecraft:water[level=0]
setblock 339 60 -126 minecraft:kelp_plant
fill 340 60 -126 341 60 -126 minecraft:water[level=0]
setblock 342 60 -126 minecraft:kelp_plant
setblock 343 60 -126 minecraft:water[level=0]
fill 344 60 -126 346 60 -126 minecraft:kelp_plant
setblock 347 60 -126 minecraft:kelp[age=25]
setblock 348 60 -126 minecraft:water[level=0]
setblock 349 60 -126 minecraft:kelp_plant
setblock 350 60 -126 minecraft:water[level=0]
fill 351 60 -126 352 60 -126 minecraft:kelp[age=25]
setblock 353 60 -126 minecraft:kelp_plant
setblock 354 60 -126 minecraft:water[level=0]
setblock 355 60 -126 minecraft:kelp[age=25]
fill 356 60 -126 366 60 -126 minecraft:water[level=0]
setblock 367 60 -126 minecraft:kelp_plant
fill 368 60 -126 374 60 -126 minecraft:water[level=0]
setblock 375 60 -126 minecraft:kelp_plant
setblock 376 60 -126 minecraft:water[level=0]
setblock 377 60 -126 minecraft:kelp_plant
fill 378 60 -126 391 60 -126 minecraft:water[level=0]
fill 328 59 -116 341 59 -116 minecraft:water[level=0]
setblock 342 59 -116 minecraft:kelp_plant
fill 343 59 -116 345 59 -116 minecraft:water[level=0]
setblock 346 59 -116 minecraft:kelp_plant
fill 347 59 -116 354 59 -116 minecraft:water[level=0]
setblock 355 59 -116 minecraft:kelp_plant
fill 356 59 -116 359 59 -116 minecraft:water[level=0]
setblock 360 59 -116 minecraft:kelp_plant
fill 361 59 -116 363 59 -116 minecraft:water[level=0]
setblock 364 59 -116 minecraft:kelp_plant
setblock 365 59 -116 minecraft:water[level=0]
setblock 366 59 -116 minecraft:kelp_plant
fill 367 59 -116 368 59 -116 minecraft:water[level=0]
setblock 369 59 -116 minecraft:kelp_plant
fill 370 59 -116 371 59 -116 minecraft:water[level=0]
setblock 372 59 -116 minecraft:kelp_plant
fill 373 59 -116 379 59 -116 minecraft:water[level=0]
setblock 380 59 -116 minecraft:kelp[age=25]
fill 381 59 -116 386 59 -116 minecraft:water[level=0]
fill 328 59 -117 336 59 -117 minecraft:water[level=0]
setblock 337 59 -117 minecraft:kelp_plant
fill 338 59 -117 343 59 -117 minecraft:water[level=0]
setblock 344 59 -117 minecraft:kelp_plant
fill 345 59 -117 391 59 -117 minecraft:water[level=0]
fill 328 59 -118 331 59 -118 minecraft:water[level=0]
fill 332 59 -118 333 59 -118 minecraft:kelp_plant
fill 334 59 -118 335 59 -118 minecraft:water[level=0]
setblock 336 59 -118 minecraft:kelp_plant
fill 337 59 -118 341 59 -118 minecraft:water[level=0]
setblock 342 59 -118 minecraft:kelp_plant
fill 343 59 -118 345 59 -118 minecraft:water[level=0]
setblock 346 59 -118 minecraft:kelp_plant
fill 347 59 -118 349 59 -118 minecraft:water[level=0]
setblock 350 59 -118 minecraft:kelp_plant
fill 351 59 -118 354 59 -118 minecraft:water[level=0]
setblock 355 59 -118 minecraft:kelp_plant
fill 356 59 -118 358 59 -118 minecraft:water[level=0]
setblock 359 59 -118 minecraft:kelp_plant
fill 360 59 -118 363 59 -118 minecraft:water[level=0]
fill 364 59 -118 365 59 -118 minecraft:kelp_plant
fill 366 59 -118 371 59 -118 minecraft:water[level=0]
setblock 372 59 -118 minecraft:kelp_plant
setblock 373 59 -118 minecraft:water[level=0]
setblock 374 59 -118 minecraft:kelp[age=25]
fill 375 59 -118 385 59 -118 minecraft:water[level=0]
setblock 386 59 -118 minecraft:kelp_plant
fill 387 59 -118 391 59 -118 minecraft:water[level=0]
fill 328 59 -119 355 59 -119 minecraft:water[level=0]
setblock 356 59 -119 minecraft:kelp_plant
fill 357 59 -119 361 59 -119 minecraft:water[level=0]
setblock 362 59 -119 minecraft:kelp_plant
fill 363 59 -119 379 59 -119 minecraft:water[level=0]
setblock 380 59 -119 minecraft:kelp_plant
fill 381 59 -119 391 59 -119 minecraft:water[level=0]
fill 328 59 -120 329 59 -120 minecraft:water[level=0]
setblock 330 59 -120 minecraft:kelp_plant
fill 331 59 -120 342 59 -120 minecraft:water[level=0]
setblock 343 59 -120 minecraft:kelp_plant
fill 344 59 -120 345 59 -120 minecraft:water[level=0]
setblock 346 59 -120 minecraft:kelp_plant
fill 347 59 -120 360 59 -120 minecraft:water[level=0]
fill 361 59 -120 363 59 -120 minecraft:kelp_plant
fill 364 59 -120 371 59 -120 minecraft:water[level=0]
setblock 372 59 -120 minecraft:kelp_plant
fill 373 59 -120 384 59 -120 minecraft:water[level=0]
setblock 385 59 -120 minecraft:kelp[age=25]
fill 386 59 -120 391 59 -120 minecraft:water[level=0]
fill 328 59 -121 333 59 -121 minecraft:water[level=0]
setblock 334 59 -121 minecraft:kelp_plant
fill 335 59 -121 339 59 -121 minecraft:water[level=0]
setblock 340 59 -121 minecraft:kelp[age=25]
fill 341 59 -121 347 59 -121 minecraft:water[level=0]
fill 348 59 -121 349 59 -121 minecraft:kelp_plant
setblock 350 59 -121 minecraft:water[level=0]
setblock 351 59 -121 minecraft:kelp_plant
fill 352 59 -121 354 59 -121 minecraft:water[level=0]
setblock 355 59 -121 minecraft:kelp_plant
fill 356 59 -121 384 59 -121 minecraft:water[level=0]
setblock 385 59 -121 minecraft:kelp[age=25]
fill 386 59 -121 391 59 -121 minecraft:water[level=0]
setblock 328 59 -122 minecraft:kelp_plant
fill 329 59 -122 331 59 -122 minecraft:water[level=0]
setblock 332 59 -122 minecraft:kelp_plant
fill 333 59 -122 341 59 -122 minecraft:water[level=0]
setblock 342 59 -122 minecraft:kelp_plant
fill 343 59 -122 345 59 -122 minecraft:water[level=0]
setblock 346 59 -122 minecraft:kelp_plant
fill 347 59 -122 362 59 -122 minecraft:water[level=0]
setblock 363 59 -122 minecraft:kelp_plant
fill 364 59 -122 366 59 -122 minecraft:water[level=0]
setblock 367 59 -122 minecraft:kelp_plant
fill 368 59 -122 370 59 -122 minecraft:water[level=0]
fill 371 59 -122 372 59 -122 minecraft:kelp_plant
setblock 373 59 -122 minecraft:kelp[age=25]
fill 374 59 -122 384 59 -122 minecraft:water[level=0]
setblock 385 59 -122 minecraft:kelp_plant
fill 386 59 -122 391 59 -122 minecraft:water[level=0]
setblock 328 59 -123 minecraft:water[level=0]
fill 329 59 -123 330 59 -123 minecraft:kelp_plant
fill 331 59 -123 336 59 -123 minecraft:water[level=0]
setblock 337 59 -123 minecraft:kelp_plant
fill 338 59 -123 344 59 -123 minecraft:water[level=0]
fill 345 59 -123 346 59 -123 minecraft:kelp_plant
fill 347 59 -123 348 59 -123 minecraft:water[level=0]
setblock 349 59 -123 minecraft:kelp_plant
fill 350 59 -123 354 59 -123 minecraft:water[level=0]
setblock 355 59 -123 minecraft:kelp_plant
fill 356 59 -123 382 59 -123 minecraft:water[level=0]
setblock 383 59 -123 minecraft:kelp_plant
fill 384 59 -123 389 59 -123 minecraft:water[level=0]
fill 390 59 -123 391 59 -123 minecraft:kelp_plant
setblock 328 59 -124 minecraft:kelp_plant
fill 329 59 -124 337 59 -124 minecraft:water[level=0]
setblock 338 59 -124 minecraft:kelp_plant
fill 339 59 -124 363 59 -124 minecraft:water[level=0]
setblock 364 59 -124 minecraft:kelp_plant
fill 365 59 -124 367 59 -124 minecraft:water[level=0]
setblock 368 59 -124 minecraft:kelp[age=25]
fill 369 59 -124 371 59 -124 minecraft:water[level=0]
setblock 372 59 -124 minecraft:kelp_plant
fill 373 59 -124 375 59 -124 minecraft:water[level=0]
setblock 376 59 -124 minecraft:kelp_plant
fill 377 59 -124 391 59 -124 minecraft:water[level=0]
fill 328 59 -125 342 59 -125 minecraft:water[level=0]
setblock 343 59 -125 minecraft:kelp_plant
fill 344 59 -125 346 59 -125 minecraft:water[level=0]
setblock 347 59 -125 minecraft:kelp_plant
fill 348 59 -125 364 59 -125 minecraft:water[level=0]
setblock 365 59 -125 minecraft:kelp_plant
fill 366 59 -125 391 59 -125 minecraft:water[level=0]
fill 328 59 -126 336 59 -126 minecraft:water[level=0]
setblock 337 59 -126 minecraft:kelp_plant
setblock 338 59 -126 minecraft:water[level=0]
setblock 339 59 -126 minecraft:kelp_plant
fill 340 59 -126 341 59 -126 minecraft:water[level=0]
setblock 342 59 -126 minecraft:kelp_plant
setblock 343 59 -126 minecraft:water[level=0]
fill 344 59 -126 347 59 -126 minecraft:kelp_plant
setblock 348 59 -126 minecraft:water[level=0]
setblock 349 59 -126 minecraft:kelp_plant
setblock 350 59 -126 minecraft:water[level=0]
fill 351 59 -126 353 59 -126 minecraft:kelp_plant
setblock 354 59 -126 minecraft:water[level=0]
setblock 355 59 -126 minecraft:kelp_plant
fill 356 59 -126 366 59 -126 minecraft:water[level=0]
setblock 367 59 -126 minecraft:kelp_plant
fill 368 59 -126 374 59 -126 minecraft:water[level=0]
setblock 375 59 -126 minecraft:kelp_plant
setblock 376 59 -126 minecraft:water[level=0]
setblock 377 59 -126 minecraft:kelp_plant
fill 378 59 -126 391 59 -126 minecraft:water[level=0]
fill 328 58 -116 341 58 -116 minecraft:water[level=0]
setblock 342 58 -116 minecraft:kelp_plant
fill 343 58 -116 345 58 -116 minecraft:water[level=0]
setblock 346 58 -116 minecraft:kelp_plant
fill 347 58 -116 354 58 -116 minecraft:water[level=0]
setblock 355 58 -116 minecraft:kelp_plant
fill 356 58 -116 359 58 -116 minecraft:water[level=0]
setblock 360 58 -116 minecraft:kelp_plant
fill 361 58 -116 363 58 -116 minecraft:water[level=0]
setblock 364 58 -116 minecraft:kelp_plant
setblock 365 58 -116 minecraft:water[level=0]
setblock 366 58 -116 minecraft:kelp_plant
fill 367 58 -116 368 58 -116 minecraft:water[level=0]
setblock 369 58 -116 minecraft:kelp_plant
fill 370 58 -116 371 58 -116 minecraft:water[level=0]
setblock 372 58 -116 minecraft:kelp_plant
fill 373 58 -116 379 58 -116 minecraft:water[level=0]
setblock 380 58 -116 minecraft:kelp_plant
fill 381 58 -116 386 58 -116 minecraft:water[level=0]
fill 328 58 -117 336 58 -117 minecraft:water[level=0]
setblock 337 58 -117 minecraft:kelp_plant
fill 338 58 -117 343 58 -117 minecraft:water[level=0]
setblock 344 58 -117 minecraft:kelp_plant
fill 345 58 -117 391 58 -117 minecraft:water[level=0]
fill 328 58 -118 331 58 -118 minecraft:water[level=0]
fill 332 58 -118 333 58 -118 minecraft:kelp_plant
setblock 334 58 -118 minecraft:kelp[age=25]
setblock 335 58 -118 minecraft:water[level=0]
setblock 336 58 -118 minecraft:kelp_plant
setblock 337 58 -118 minecraft:water[level=0]
setblock 338 58 -118 minecraft:kelp[age=25]
fill 339 58 -118 341 58 -118 minecraft:water[level=0]
setblock 342 58 -118 minecraft:kelp_plant
fill 343 58 -118 345 58 -118 minecraft:water[level=0]
setblock 346 58 -118 minecraft:kelp_plant
fill 347 58 -118 349 58 -118 minecraft:water[level=0]
setblock 350 58 -118 minecraft:kelp_plant
fill 351 58 -118 354 58 -118 minecraft:water[level=0]
setblock 355 58 -118 minecraft:kelp_plant
fill 356 58 -118 358 58 -118 minecraft:water[level=0]
setblock 359 58 -118 minecraft:kelp_plant
fill 360 58 -118 361 58 -118 minecraft:water[level=0]
setblock 362 58 -118 minecraft:kelp[age=25]
setblock 363 58 -118 minecraft:water[level=0]
fill 364 58 -118 365 58 -118 minecraft:kelp_plant
fill 366 58 -118 367 58 -118 minecraft:water[level=0]
setblock 368 58 -118 minecraft:kelp[age=25]
fill 369 58 -118 371 58 -118 minecraft:water[level=0]
setblock 372 58 -118 minecraft:kelp_plant
setblock 373 58 -118 minecraft:water[level=0]
setblock 374 58 -118 minecraft:kelp_plant
fill 375 58 -118 385 58 -118 minecraft:water[level=0]
setblock 386 58 -118 minecraft:kelp_plant
fill 387 58 -118 391 58 -118 minecraft:water[level=0]
fill 328 58 -119 334 58 -119 minecraft:water[level=0]
setblock 335 58 -119 minecraft:kelp[age=25]
fill 336 58 -119 355 58 -119 minecraft:water[level=0]
setblock 356 58 -119 minecraft:kelp_plant
fill 357 58 -119 361 58 -119 minecraft:water[level=0]
setblock 362 58 -119 minecraft:kelp_plant
fill 363 58 -119 370 58 -119 minecraft:water[level=0]
setblock 371 58 -119 minecraft:kelp[age=25]
fill 372 58 -119 379 58 -119 minecraft:water[level=0]
setblock 380 58 -119 minecraft:kelp_plant
fill 381 58 -119 391 58 -119 minecraft:water[level=0]
fill 328 58 -120 329 58 -120 minecraft:water[level=0]
setblock 330 58 -120 minecraft:kelp_plant
fill 331 58 -120 337 58 -120 minecraft:water[level=0]
setblock 338 58 -120 minecraft:kelp[age=25]
fill 339 58 -120 342 58 -120 minecraft:water[level=0]
setblock 343 58 -120 minecraft:kelp_plant
fill 344 58 -120 345 58 -120 minecraft:water[level=0]
setblock 346 58 -120 minecraft:kelp_plant
fill 347 58 -120 360 58 -120 minecraft:water[level=0]
fill 361 58 -120 363 58 -120 minecraft:kelp_plant
fill 364 58 -120 371 58 -120 minecraft:water[level=0]
setblock 372 58 -120 minecraft:kelp_plant
fill 373 58 -120 384 58 -120 minecraft:water[level=0]
setblock 385 58 -120 minecraft:kelp_plant
fill 386 58 -120 391 58 -120 minecraft:water[level=0]
fill 328 58 -121 333 58 -121 minecraft:water[level=0]
setblock 334 58 -121 minecraft:kelp_plant
fill 335 58 -121 339 58 -121 minecraft:water[level=0]
setblock 340 58 -121 minecraft:kelp_plant
fill 341 58 -121 347 58 -121 minecraft:water[level=0]
fill 348 58 -121 349 58 -121 minecraft:kelp_plant
setblock 350 58 -121 minecraft:water[level=0]
setblock 351 58 -121 minecraft:kelp_plant
fill 352 58 -121 354 58 -121 minecraft:water[level=0]
setblock 355 58 -121 minecraft:kelp_plant
fill 356 58 -121 378 58 -121 minecraft:water[level=0]
setblock 379 58 -121 minecraft:kelp[age=25]
fill 380 58 -121 384 58 -121 minecraft:water[level=0]
setblock 385 58 -121 minecraft:kelp_plant
fill 386 58 -121 391 58 -121 minecraft:water[level=0]
setblock 328 58 -122 minecraft:kelp_plant
fill 329 58 -122 331 58 -122 minecraft:water[level=0]
setblock 332 58 -122 minecraft:kelp_plant
fill 333 58 -122 341 58 -122 minecraft:water[level=0]
setblock 342 58 -122 minecraft:kelp_plant
fill 343 58 -122 345 58 -122 minecraft:water[level=0]
setblock 346 58 -122 minecraft:kelp_plant
fill 347 58 -122 362 58 -122 minecraft:water[level=0]
setblock 363 58 -122 minecraft:kelp_plant
fill 364 58 -122 366 58 -122 minecraft:water[level=0]
setblock 367 58 -122 minecraft:kelp_plant
fill 368 58 -122 370 58 -122 minecraft:water[level=0]
fill 371 58 -122 373 58 -122 minecraft:kelp_plant
fill 374 58 -122 384 58 -122 minecraft:water[level=0]
setblock 385 58 -122 minecraft:kelp_plant
fill 386 58 -122 391 58 -122 minecraft:water[level=0]
setblock 328 58 -123 minecraft:water[level=0]
fill 329 58 -123 330 58 -123 minecraft:kelp_plant
fill 331 58 -123 336 58 -123 minecraft:water[level=0]
setblock 337 58 -123 minecraft:kelp_plant
fill 338 58 -123 344 58 -123 minecraft:water[level=0]
fill 345 58 -123 346 58 -123 minecraft:kelp_plant
fill 347 58 -123 348 58 -123 minecraft:water[level=0]
setblock 349 58 -123 minecraft:kelp_plant
fill 350 58 -123 354 58 -123 minecraft:water[level=0]
setblock 355 58 -123 minecraft:kelp_plant
fill 356 58 -123 374 58 -123 minecraft:water[level=0]
setblock 375 58 -123 minecraft:kelp[age=25]
fill 376 58 -123 382 58 -123 minecraft:water[level=0]
setblock 383 58 -123 minecraft:kelp_plant
fill 384 58 -123 389 58 -123 minecraft:water[level=0]
fill 390 58 -123 391 58 -123 minecraft:kelp_plant
setblock 328 58 -124 minecraft:kelp_plant
fill 329 58 -124 337 58 -124 minecraft:water[level=0]
setblock 338 58 -124 minecraft:kelp_plant
fill 339 58 -124 363 58 -124 minecraft:water[level=0]
setblock 364 58 -124 minecraft:kelp_plant
fill 365 58 -124 367 58 -124 minecraft:water[level=0]
setblock 368 58 -124 minecraft:kelp_plant
fill 369 58 -124 371 58 -124 minecraft:water[level=0]
setblock 372 58 -124 minecraft:kelp_plant
fill 373 58 -124 375 58 -124 minecraft:water[level=0]
setblock 376 58 -124 minecraft:kelp_plant
setblock 377 58 -124 minecraft:kelp[age=25]
fill 378 58 -124 391 58 -124 minecraft:water[level=0]
fill 328 58 -125 342 58 -125 minecraft:water[level=0]
setblock 343 58 -125 minecraft:kelp_plant
fill 344 58 -125 346 58 -125 minecraft:water[level=0]
setblock 347 58 -125 minecraft:kelp_plant
fill 348 58 -125 364 58 -125 minecraft:water[level=0]
setblock 365 58 -125 minecraft:kelp_plant
fill 366 58 -125 391 58 -125 minecraft:water[level=0]
fill 328 58 -126 336 58 -126 minecraft:water[level=0]
setblock 337 58 -126 minecraft:kelp_plant
setblock 338 58 -126 minecraft:water[level=0]
setblock 339 58 -126 minecraft:kelp_plant
setblock 340 58 -126 minecraft:kelp[age=25]
setblock 341 58 -126 minecraft:water[level=0]
setblock 342 58 -126 minecraft:kelp_plant
setblock 343 58 -126 minecraft:water[level=0]
fill 344 58 -126 347 58 -126 minecraft:kelp_plant
setblock 348 58 -126 minecraft:water[level=0]
setblock 349 58 -126 minecraft:kelp_plant
setblock 350 58 -126 minecraft:water[level=0]
fill 351 58 -126 353 58 -126 minecraft:kelp_plant
setblock 354 58 -126 minecraft:water[level=0]
setblock 355 58 -126 minecraft:kelp_plant
fill 356 58 -126 366 58 -126 minecraft:water[level=0]
setblock 367 58 -126 minecraft:kelp_plant
fill 368 58 -126 371 58 -126 minecraft:water[level=0]
setblock 372 58 -126 minecraft:kelp[age=25]
fill 373 58 -126 374 58 -126 minecraft:water[level=0]
setblock 375 58 -126 minecraft:kelp_plant
setblock 376 58 -126 minecraft:water[level=0]
setblock 377 58 -126 minecraft:kelp_plant
fill 378 58 -126 391 58 -126 minecraft:water[level=0]
fill 328 57 -116 329 57 -116 minecraft:water[level=0]
setblock 330 57 -116 minecraft:kelp[age=25]
fill 331 57 -116 341 57 -116 minecraft:water[level=0]
setblock 342 57 -116 minecraft:kelp_plant
fill 343 57 -116 345 57 -116 minecraft:water[level=0]
setblock 346 57 -116 minecraft:kelp_plant
fill 347 57 -116 354 57 -116 minecraft:water[level=0]
setblock 355 57 -116 minecraft:kelp_plant
fill 356 57 -116 359 57 -116 minecraft:water[level=0]
setblock 360 57 -116 minecraft:kelp_plant
fill 361 57 -116 363 57 -116 minecraft:water[level=0]
setblock 364 57 -116 minecraft:kelp_plant
setblock 365 57 -116 minecraft:water[level=0]
setblock 366 57 -116 minecraft:kelp_plant
fill 367 57 -116 368 57 -116 minecraft:water[level=0]
setblock 369 57 -116 minecraft:kelp_plant
fill 370 57 -116 371 57 -116 minecraft:water[level=0]
setblock 372 57 -116 minecraft:kelp_plant
fill 373 57 -116 379 57 -116 minecraft:water[level=0]
setblock 380 57 -116 minecraft:kelp_plant
fill 381 57 -116 386 57 -116 minecraft:water[level=0]
fill 328 57 -117 330 57 -117 minecraft:water[level=0]
setblock 331 57 -117 minecraft:kelp[age=25]
fill 332 57 -117 336 57 -117 minecraft:water[level=0]
setblock 337 57 -117 minecraft:kelp_plant
fill 338 57 -117 343 57 -117 minecraft:water[level=0]
setblock 344 57 -117 minecraft:kelp_plant
fill 345 57 -117 375 57 -117 minecraft:water[level=0]
setblock 376 57 -117 minecraft:kelp[age=25]
fill 377 57 -117 391 57 -117 minecraft:water[level=0]
fill 328 57 -118 331 57 -118 minecraft:water[level=0]
fill 332 57 -118 334 57 -118 minecraft:kelp_plant
setblock 335 57 -118 minecraft:water[level=0]
setblock 336 57 -118 minecraft:kelp_plant
setblock 337 57 -118 minecraft:water[level=0]
setblock 338 57 -118 minecraft:kelp_plant
fill 339 57 -118 341 57 -118 minecraft:water[level=0]
setblock 342 57 -118 minecraft:kelp_plant
fill 343 57 -118 345 57 -118 minecraft:water[level=0]
setblock 346 57 -118 minecraft:kelp_plant
fill 347 57 -118 349 57 -118 minecraft:water[level=0]
setblock 350 57 -118 minecraft:kelp_plant
fill 351 57 -118 354 57 -118 minecraft:water[level=0]
setblock 355 57 -118 minecraft:kelp_plant
fill 356 57 -118 358 57 -118 minecraft:water[level=0]
setblock 359 57 -118 minecraft:kelp_plant
fill 360 57 -118 361 57 -118 minecraft:water[level=0]
setblock 362 57 -118 minecraft:kelp_plant
setblock 363 57 -118 minecraft:water[level=0]
fill 364 57 -118 365 57 -118 minecraft:kelp_plant
fill 366 57 -118 367 57 -118 minecraft:water[level=0]
setblock 368 57 -118 minecraft:kelp_plant
fill 369 57 -118 371 57 -118 minecraft:water[level=0]
setblock 372 57 -118 minecraft:kelp_plant
setblock 373 57 -118 minecraft:water[level=0]
setblock 374 57 -118 minecraft:kelp_plant
fill 375 57 -118 385 57 -118 minecraft:water[level=0]
setblock 386 57 -118 minecraft:kelp_plant
fill 387 57 -118 389 57 -118 minecraft:water[level=0]
setblock 390 57 -118 minecraft:kelp[age=25]
setblock 391 57 -118 minecraft:water[level=0]
fill 328 57 -119 334 57 -119 minecraft:water[level=0]
setblock 335 57 -119 minecraft:kelp_plant
fill 336 57 -119 350 57 -119 minecraft:water[level=0]
setblock 351 57 -119 minecraft:kelp[age=25]
fill 352 57 -119 355 57 -119 minecraft:water[level=0]
setblock 356 57 -119 minecraft:kelp_plant
fill 357 57 -119 361 57 -119 minecraft:water[level=0]
setblock 362 57 -119 minecraft:kelp_plant
fill 363 57 -119 370 57 -119 minecraft:water[level=0]
setblock 371 57 -119 minecraft:kelp_plant
fill 372 57 -119 379 57 -119 minecraft:water[level=0]
setblock 380 57 -119 minecraft:kelp_plant
fill 381 57 -119 391 57 -119 minecraft:water[level=0]
fill 328 57 -120 329 57 -120 minecraft:water[level=0]
setblock 330 57 -120 minecraft:kelp_plant
fill 331 57 -120 337 57 -120 minecraft:water[level=0]
setblock 338 57 -120 minecraft:kelp_plant
fill 339 57 -120 342 57 -120 minecraft:water[level=0]
setblock 343 57 -120 minecraft:kelp_plant
fill 344 57 -120 345 57 -120 minecraft:water[level=0]
setblock 346 57 -120 minecraft:kelp_plant
fill 347 57 -120 360 57 -120 minecraft:water[level=0]
fill 361 57 -120 363 57 -120 minecraft:kelp_plant
fill 364 57 -120 371 57 -120 minecraft:water[level=0]
setblock 372 57 -120 minecraft:kelp_plant
fill 373 57 -120 384 57 -120 minecraft:water[level=0]
setblock 385 57 -120 minecraft:kelp_plant
fill 386 57 -120 391 57 -120 minecraft:water[level=0]
fill 328 57 -121 333 57 -121 minecraft:water[level=0]
setblock 334 57 -121 minecraft:kelp_plant
fill 335 57 -121 339 57 -121 minecraft:water[level=0]
setblock 340 57 -121 minecraft:kelp_plant
fill 341 57 -121 346 57 -121 minecraft:water[level=0]
setblock 347 57 -121 minecraft:kelp[age=25]
fill 348 57 -121 349 57 -121 minecraft:kelp_plant
setblock 350 57 -121 minecraft:water[level=0]
setblock 351 57 -121 minecraft:kelp_plant
fill 352 57 -121 354 57 -121 minecraft:water[level=0]
setblock 355 57 -121 minecraft:kelp_plant
fill 356 57 -121 378 57 -121 minecraft:water[level=0]
setblock 379 57 -121 minecraft:kelp_plant
fill 380 57 -121 384 57 -121 minecraft:water[level=0]
setblock 385 57 -121 minecraft:kelp_plant
fill 386 57 -121 391 57 -121 minecraft:water[level=0]
setblock 328 57 -122 minecraft:kelp_plant
fill 329 57 -122 331 57 -122 minecraft:water[level=0]
setblock 332 57 -122 minecraft:kelp_plant
fill 333 57 -122 341 57 -122 minecraft:water[level=0]
setblock 342 57 -122 minecraft:kelp_plant
fill 343 57 -122 345 57 -122 minecraft:water[level=0]
setblock 346 57 -122 minecraft:kelp_plant
fill 347 57 -122 352 57 -122 minecraft:water[level=0]
setblock 353 57 -122 minecraft:kelp[age=25]
fill 354 57 -122 362 57 -122 minecraft:water[level=0]
setblock 363 57 -122 minecraft:kelp_plant
fill 364 57 -122 366 57 -122 minecraft:water[level=0]
setblock 367 57 -122 minecraft:kelp_plant
fill 368 57 -122 370 57 -122 minecraft:water[level=0]
fill 371 57 -122 373 57 -122 minecraft:kelp_plant
fill 374 57 -122 384 57 -122 minecraft:water[level=0]
setblock 385 57 -122 minecraft:kelp_plant
fill 386 57 -122 391 57 -122 minecraft:water[level=0]
setblock 328 57 -123 minecraft:water[level=0]
fill 329 57 -123 330 57 -123 minecraft:kelp_plant
fill 331 57 -123 336 57 -123 minecraft:water[level=0]
setblock 337 57 -123 minecraft:kelp_plant
fill 338 57 -123 344 57 -123 minecraft:water[level=0]
fill 345 57 -123 346 57 -123 minecraft:kelp_plant
fill 347 57 -123 348 57 -123 minecraft:water[level=0]
setblock 349 57 -123 minecraft:kelp_plant
fill 350 57 -123 354 57 -123 minecraft:water[level=0]
setblock 355 57 -123 minecraft:kelp_plant
fill 356 57 -123 374 57 -123 minecraft:water[level=0]
setblock 375 57 -123 minecraft:kelp_plant
fill 376 57 -123 382 57 -123 minecraft:water[level=0]
setblock 383 57 -123 minecraft:kelp_plant
fill 384 57 -123 389 57 -123 minecraft:water[level=0]
fill 390 57 -123 391 57 -123 minecraft:kelp_plant
setblock 328 57 -124 minecraft:kelp_plant
fill 329 57 -124 337 57 -124 minecraft:water[level=0]
setblock 338 57 -124 minecraft:kelp_plant
fill 339 57 -124 358 57 -124 minecraft:water[level=0]
setblock 359 57 -124 minecraft:kelp[age=25]
fill 360 57 -124 363 57 -124 minecraft:water[level=0]
setblock 364 57 -124 minecraft:kelp_plant
fill 365 57 -124 367 57 -124 minecraft:water[level=0]
setblock 368 57 -124 minecraft:kelp_plant
fill 369 57 -124 371 57 -124 minecraft:water[level=0]
setblock 372 57 -124 minecraft:kelp_plant
fill 373 57 -124 375 57 -124 minecraft:water[level=0]
fill 376 57 -124 377 57 -124 minecraft:kelp_plant
fill 378 57 -124 391 57 -124 minecraft:water[level=0]
fill 328 57 -125 342 57 -125 minecraft:water[level=0]
setblock 343 57 -125 minecraft:kelp_plant
fill 344 57 -125 346 57 -125 minecraft:water[level=0]
setblock 347 57 -125 minecraft:kelp_plant
fill 348 57 -125 364 57 -125 minecraft:water[level=0]
setblock 365 57 -125 minecraft:kelp_plant
fill 366 57 -125 391 57 -125 minecraft:water[level=0]
fill 328 57 -126 336 57 -126 minecraft:water[level=0]
setblock 337 57 -126 minecraft:kelp_plant
setblock 338 57 -126 minecraft:water[level=0]
fill 339 57 -126 340 57 -126 minecraft:kelp_plant
setblock 341 57 -126 minecraft:water[level=0]
setblock 342 57 -126 minecraft:kelp_plant
setblock 343 57 -126 minecraft:water[level=0]
fill 344 57 -126 347 57 -126 minecraft:kelp_plant
setblock 348 57 -126 minecraft:water[level=0]
setblock 349 57 -126 minecraft:kelp_plant
setblock 350 57 -126 minecraft:water[level=0]
fill 351 57 -126 353 57 -126 minecraft:kelp_plant
setblock 354 57 -126 minecraft:water[level=0]
setblock 355 57 -126 minecraft:kelp_plant
fill 356 57 -126 366 57 -126 minecraft:water[level=0]
setblock 367 57 -126 minecraft:kelp_plant
fill 368 57 -126 371 57 -126 minecraft:water[level=0]
setblock 372 57 -126 minecraft:kelp_plant
fill 373 57 -126 374 57 -126 minecraft:water[level=0]
setblock 375 57 -126 minecraft:kelp_plant
setblock 376 57 -126 minecraft:water[level=0]
setblock 377 57 -126 minecraft:kelp_plant
fill 378 57 -126 391 57 -126 minecraft:water[level=0]
fill 328 56 -116 329 56 -116 minecraft:water[level=0]
setblock 330 56 -116 minecraft:kelp_plant
fill 331 56 -116 341 56 -116 minecraft:water[level=0]
setblock 342 56 -116 minecraft:kelp_plant
fill 343 56 -116 345 56 -116 minecraft:water[level=0]
setblock 346 56 -116 minecraft:kelp_plant
fill 347 56 -116 348 56 -116 minecraft:water[level=0]
setblock 349 56 -116 minecraft:kelp[age=25]
fill 350 56 -116 352 56 -116 minecraft:water[level=0]
setblock 353 56 -116 minecraft:kelp[age=25]
setblock 354 56 -116 minecraft:water[level=0]
setblock 355 56 -116 minecraft:kelp_plant
fill 356 56 -116 359 56 -116 minecraft:water[level=0]
setblock 360 56 -116 minecraft:kelp_plant
fill 361 56 -116 363 56 -116 minecraft:water[level=0]
setblock 364 56 -116 minecraft:kelp_plant
setblock 365 56 -116 minecraft:water[level=0]
setblock 366 56 -116 minecraft:kelp_plant
fill 367 56 -116 368 56 -116 minecraft:water[level=0]
setblock 369 56 -116 minecraft:kelp_plant
fill 370 56 -116 371 56 -116 minecraft:water[level=0]
setblock 372 56 -116 minecraft:kelp_plant
fill 373 56 -116 379 56 -116 minecraft:water[level=0]
setblock 380 56 -116 minecraft:kelp_plant
fill 381 56 -116 386 56 -116 minecraft:water[level=0]
fill 328 56 -117 330 56 -117 minecraft:water[level=0]
setblock 331 56 -117 minecraft:kelp_plant
fill 332 56 -117 336 56 -117 minecraft:water[level=0]
setblock 337 56 -117 minecraft:kelp_plant
fill 338 56 -117 343 56 -117 minecraft:water[level=0]
setblock 344 56 -117 minecraft:kelp_plant
fill 345 56 -117 375 56 -117 minecraft:water[level=0]
setblock 376 56 -117 minecraft:kelp_plant
fill 377 56 -117 391 56 -117 minecraft:water[level=0]
fill 328 56 -118 331 56 -118 minecraft:water[level=0]
fill 332 56 -118 334 56 -118 minecraft:kelp_plant
setblock 335 56 -118 minecraft:water[level=0]
setblock 336 56 -118 minecraft:kelp_plant
setblock 337 56 -118 minecraft:water[level=0]
setblock 338 56 -118 minecraft:kelp_plant
fill 339 56 -118 341 56 -118 minecraft:water[level=0]
setblock 342 56 -118 minecraft:kelp_plant
fill 343 56 -118 345 56 -118 minecraft:water[level=0]
setblock 346 56 -118 minecraft:kelp_plant
fill 347 56 -118 349 56 -118 minecraft:water[level=0]
setblock 350 56 -118 minecraft:kelp_plant
fill 351 56 -118 354 56 -118 minecraft:water[level=0]
setblock 355 56 -118 minecraft:kelp_plant
fill 356 56 -118 358 56 -118 minecraft:water[level=0]
setblock 359 56 -118 minecraft:kelp_plant
fill 360 56 -118 361 56 -118 minecraft:water[level=0]
setblock 362 56 -118 minecraft:kelp_plant
setblock 363 56 -118 minecraft:water[level=0]
fill 364 56 -118 365 56 -118 minecraft:kelp_plant
fill 366 56 -118 367 56 -118 minecraft:water[level=0]
setblock 368 56 -118 minecraft:kelp_plant
fill 369 56 -118 371 56 -118 minecraft:water[level=0]
setblock 372 56 -118 minecraft:kelp_plant
setblock 373 56 -118 minecraft:water[level=0]
setblock 374 56 -118 minecraft:kelp_plant
setblock 375 56 -118 minecraft:kelp[age=25]
fill 376 56 -118 385 56 -118 minecraft:water[level=0]
setblock 386 56 -118 minecraft:kelp_plant
fill 387 56 -118 389 56 -118 minecraft:water[level=0]
setblock 390 56 -118 minecraft:kelp_plant
setblock 391 56 -118 minecraft:water[level=0]
fill 328 56 -119 334 56 -119 minecraft:water[level=0]
setblock 335 56 -119 minecraft:kelp_plant
fill 336 56 -119 340 56 -119 minecraft:water[level=0]
setblock 341 56 -119 minecraft:kelp[age=25]
fill 342 56 -119 350 56 -119 minecraft:water[level=0]
setblock 351 56 -119 minecraft:kelp_plant
fill 352 56 -119 355 56 -119 minecraft:water[level=0]
setblock 356 56 -119 minecraft:kelp_plant
fill 357 56 -119 361 56 -119 minecraft:water[level=0]
setblock 362 56 -119 minecraft:kelp_plant
fill 363 56 -119 366 56 -119 minecraft:water[level=0]
setblock 367 56 -119 minecraft:kelp[age=25]
fill 368 56 -119 370 56 -119 minecraft:water[level=0]
setblock 371 56 -119 minecraft:kelp_plant
fill 372 56 -119 375 56 -119 minecraft:water[level=0]
setblock 376 56 -119 minecraft:kelp[age=25]
fill 377 56 -119 379 56 -119 minecraft:water[level=0]
setblock 380 56 -119 minecraft:kelp_plant
fill 381 56 -119 391 56 -119 minecraft:water[level=0]
fill 328 56 -120 329 56 -120 minecraft:water[level=0]
setblock 330 56 -120 minecraft:kelp_plant
fill 331 56 -120 337 56 -120 minecraft:water[level=0]
setblock 338 56 -120 minecraft:kelp_plant
fill 339 56 -120 342 56 -120 minecraft:water[level=0]
setblock 343 56 -120 minecraft:kelp_plant
fill 344 56 -120 345 56 -120 minecraft:water[level=0]
setblock 346 56 -120 minecraft:kelp_plant
fill 347 56 -120 360 56 -120 minecraft:water[level=0]
fill 361 56 -120 363 56 -120 minecraft:kelp_plant
fill 364 56 -120 371 56 -120 minecraft:water[level=0]
setblock 372 56 -120 minecraft:kelp_plant
fill 373 56 -120 384 56 -120 minecraft:water[level=0]
setblock 385 56 -120 minecraft:kelp_plant
fill 386 56 -120 391 56 -120 minecraft:water[level=0]
fill 328 56 -121 333 56 -121 minecraft:water[level=0]
setblock 334 56 -121 minecraft:kelp_plant
fill 335 56 -121 339 56 -121 minecraft:water[level=0]
setblock 340 56 -121 minecraft:kelp_plant
fill 341 56 -121 346 56 -121 minecraft:water[level=0]
fill 347 56 -121 349 56 -121 minecraft:kelp_plant
setblock 350 56 -121 minecraft:water[level=0]
setblock 351 56 -121 minecraft:kelp_plant
fill 352 56 -121 354 56 -121 minecraft:water[level=0]
setblock 355 56 -121 minecraft:kelp_plant
fill 356 56 -121 372 56 -121 minecraft:water[level=0]
setblock 373 56 -121 minecraft:kelp[age=25]
fill 374 56 -121 378 56 -121 minecraft:water[level=0]
setblock 379 56 -121 minecraft:kelp_plant
fill 380 56 -121 384 56 -121 minecraft:water[level=0]
setblock 385 56 -121 minecraft:kelp_plant
fill 386 56 -121 391 56 -121 minecraft:water[level=0]
setblock 328 56 -122 minecraft:kelp_plant
fill 329 56 -122 331 56 -122 minecraft:water[level=0]
setblock 332 56 -122 minecraft:kelp_plant
fill 333 56 -122 341 56 -122 minecraft:water[level=0]
setblock 342 56 -122 minecraft:kelp_plant
fill 343 56 -122 345 56 -122 minecraft:water[level=0]
setblock 346 56 -122 minecraft:kelp_plant
fill 347 56 -122 352 56 -122 minecraft:water[level=0]
setblock 353 56 -122 minecraft:kelp_plant
fill 354 56 -122 362 56 -122 minecraft:water[level=0]
setblock 363 56 -122 minecraft:kelp_plant
fill 364 56 -122 366 56 -122 minecraft:water[level=0]
setblock 367 56 -122 minecraft:kelp_plant
fill 368 56 -122 370 56 -122 minecraft:water[level=0]
fill 371 56 -122 373 56 -122 minecraft:kelp_plant
fill 374 56 -122 384 56 -122 minecraft:water[level=0]
setblock 385 56 -122 minecraft:kelp_plant
fill 386 56 -122 391 56 -122 minecraft:water[level=0]
setblock 328 56 -123 minecraft:water[level=0]
fill 329 56 -123 330 56 -123 minecraft:kelp_plant
fill 331 56 -123 336 56 -123 minecraft:water[level=0]
setblock 337 56 -123 minecraft:kelp_plant
fill 338 56 -123 344 56 -123 minecraft:water[level=0]
fill 345 56 -123 346 56 -123 minecraft:kelp_plant
fill 347 56 -123 348 56 -123 minecraft:water[level=0]
setblock 349 56 -123 minecraft:kelp_plant
fill 350 56 -123 354 56 -123 minecraft:water[level=0]
setblock 355 56 -123 minecraft:kelp_plant
fill 356 56 -123 374 56 -123 minecraft:water[level=0]
setblock 375 56 -123 minecraft:kelp_plant
fill 376 56 -123 382 56 -123 minecraft:water[level=0]
setblock 383 56 -123 minecraft:kelp_plant
fill 384 56 -123 389 56 -123 minecraft:water[level=0]
fill 390 56 -123 391 56 -123 minecraft:kelp_plant
setblock 328 56 -124 minecraft:kelp_plant
fill 329 56 -124 331 56 -124 minecraft:water[level=0]
setblock 332 56 -124 minecraft:tall_seagrass[half=upper]
fill 333 56 -124 337 56 -124 minecraft:water[level=0]
setblock 338 56 -124 minecraft:kelp_plant
fill 339 56 -124 358 56 -124 minecraft:water[level=0]
setblock 359 56 -124 minecraft:kelp_plant
fill 360 56 -124 363 56 -124 minecraft:water[level=0]
setblock 364 56 -124 minecraft:kelp_plant
fill 365 56 -124 367 56 -124 minecraft:water[level=0]
setblock 368 56 -124 minecraft:kelp_plant
fill 369 56 -124 371 56 -124 minecraft:water[level=0]
setblock 372 56 -124 minecraft:kelp_plant
fill 373 56 -124 375 56 -124 minecraft:water[level=0]
fill 376 56 -124 377 56 -124 minecraft:kelp_plant
fill 378 56 -124 383 56 -124 minecraft:water[level=0]
setblock 384 56 -124 minecraft:kelp[age=25]
fill 385 56 -124 391 56 -124 minecraft:water[level=0]
fill 328 56 -125 342 56 -125 minecraft:water[level=0]
setblock 343 56 -125 minecraft:kelp_plant
fill 344 56 -125 346 56 -125 minecraft:water[level=0]
setblock 347 56 -125 minecraft:kelp_plant
fill 348 56 -125 364 56 -125 minecraft:water[level=0]
setblock 365 56 -125 minecraft:kelp_plant
fill 366 56 -125 391 56 -125 minecraft:water[level=0]
fill 328 56 -126 331 56 -126 minecraft:water[level=0]
setblock 332 56 -126 minecraft:tall_seagrass[half=upper]
fill 333 56 -126 336 56 -126 minecraft:water[level=0]
setblock 337 56 -126 minecraft:kelp_plant
setblock 338 56 -126 minecraft:water[level=0]
fill 339 56 -126 340 56 -126 minecraft:kelp_plant
setblock 341 56 -126 minecraft:water[level=0]
setblock 342 56 -126 minecraft:kelp_plant
setblock 343 56 -126 minecraft:water[level=0]
fill 344 56 -126 347 56 -126 minecraft:kelp_plant
setblock 348 56 -126 minecraft:water[level=0]
setblock 349 56 -126 minecraft:kelp_plant
setblock 350 56 -126 minecraft:water[level=0]
fill 351 56 -126 353 56 -126 minecraft:kelp_plant
setblock 354 56 -126 minecraft:water[level=0]
setblock 355 56 -126 minecraft:kelp_plant
fill 356 56 -126 366 56 -126 minecraft:water[level=0]
setblock 367 56 -126 minecraft:kelp_plant
fill 368 56 -126 371 56 -126 minecraft:water[level=0]
setblock 372 56 -126 minecraft:kelp_plant
fill 373 56 -126 374 56 -126 minecraft:water[level=0]
setblock 375 56 -126 minecraft:kelp_plant
setblock 376 56 -126 minecraft:water[level=0]
setblock 377 56 -126 minecraft:kelp_plant
fill 378 56 -126 391 56 -126 minecraft:water[level=0]
fill 328 55 -116 329 55 -116 minecraft:water[level=0]
setblock 330 55 -116 minecraft:kelp_plant
fill 331 55 -116 341 55 -116 minecraft:water[level=0]
setblock 342 55 -116 minecraft:kelp_plant
fill 343 55 -116 345 55 -116 minecraft:water[level=0]
setblock 346 55 -116 minecraft:kelp_plant
fill 347 55 -116 348 55 -116 minecraft:water[level=0]
setblock 349 55 -116 minecraft:kelp_plant
fill 350 55 -116 352 55 -116 minecraft:water[level=0]
setblock 353 55 -116 minecraft:kelp_plant
setblock 354 55 -116 minecraft:water[level=0]
setblock 355 55 -116 minecraft:kelp_plant
fill 356 55 -116 359 55 -116 minecraft:water[level=0]
setblock 360 55 -116 minecraft:kelp_plant
fill 361 55 -116 363 55 -116 minecraft:water[level=0]
setblock 364 55 -116 minecraft:kelp_plant
setblock 365 55 -116 minecraft:water[level=0]
setblock 366 55 -116 minecraft:kelp_plant
fill 367 55 -116 368 55 -116 minecraft:water[level=0]
setblock 369 55 -116 minecraft:kelp_plant
fill 370 55 -116 371 55 -116 minecraft:water[level=0]
setblock 372 55 -116 minecraft:kelp_plant
fill 373 55 -116 379 55 -116 minecraft:water[level=0]
setblock 380 55 -116 minecraft:kelp_plant
fill 381 55 -116 386 55 -116 minecraft:water[level=0]
fill 328 55 -117 330 55 -117 minecraft:water[level=0]
setblock 331 55 -117 minecraft:kelp_plant
fill 332 55 -117 336 55 -117 minecraft:water[level=0]
setblock 337 55 -117 minecraft:kelp_plant
fill 338 55 -117 340 55 -117 minecraft:water[level=0]
setblock 341 55 -117 minecraft:kelp[age=25]
fill 342 55 -117 343 55 -117 minecraft:water[level=0]
setblock 344 55 -117 minecraft:kelp_plant
fill 345 55 -117 375 55 -117 minecraft:water[level=0]
setblock 376 55 -117 minecraft:kelp_plant
fill 377 55 -117 382 55 -117 minecraft:water[level=0]
setblock 383 55 -117 minecraft:kelp[age=24]
fill 384 55 -117 391 55 -117 minecraft:water[level=0]
fill 328 55 -118 331 55 -118 minecraft:water[level=0]
fill 332 55 -118 334 55 -118 minecraft:kelp_plant
setblock 335 55 -118 minecraft:water[level=0]
setblock 336 55 -118 minecraft:kelp_plant
setblock 337 55 -118 minecraft:water[level=0]
setblock 338 55 -118 minecraft:kelp_plant
fill 339 55 -118 341 55 -118 minecraft:water[level=0]
setblock 342 55 -118 minecraft:kelp_plant
fill 343 55 -118 345 55 -118 minecraft:water[level=0]
setblock 346 55 -118 minecraft:kelp_plant
fill 347 55 -118 349 55 -118 minecraft:water[level=0]
setblock 350 55 -118 minecraft:kelp_plant
fill 351 55 -118 354 55 -118 minecraft:water[level=0]
setblock 355 55 -118 minecraft:kelp_plant
fill 356 55 -118 358 55 -118 minecraft:water[level=0]
setblock 359 55 -118 minecraft:kelp_plant
fill 360 55 -118 361 55 -118 minecraft:water[level=0]
setblock 362 55 -118 minecraft:kelp_plant
setblock 363 55 -118 minecraft:water[level=0]
fill 364 55 -118 365 55 -118 minecraft:kelp_plant
fill 366 55 -118 367 55 -118 minecraft:water[level=0]
setblock 368 55 -118 minecraft:kelp_plant
fill 369 55 -118 371 55 -118 minecraft:water[level=0]
setblock 372 55 -118 minecraft:kelp_plant
setblock 373 55 -118 minecraft:water[level=0]
fill 374 55 -118 375 55 -118 minecraft:kelp_plant
fill 376 55 -118 385 55 -118 minecraft:water[level=0]
setblock 386 55 -118 minecraft:kelp_plant
fill 387 55 -118 389 55 -118 minecraft:water[level=0]
setblock 390 55 -118 minecraft:kelp_plant
setblock 391 55 -118 minecraft:water[level=0]
fill 328 55 -119 334 55 -119 minecraft:water[level=0]
setblock 335 55 -119 minecraft:kelp_plant
fill 336 55 -119 340 55 -119 minecraft:water[level=0]
setblock 341 55 -119 minecraft:kelp_plant
fill 342 55 -119 343 55 -119 minecraft:water[level=0]
fill 344 55 -119 345 55 -119 minecraft:kelp[age=25]
fill 346 55 -119 350 55 -119 minecraft:water[level=0]
setblock 351 55 -119 minecraft:kelp_plant
fill 352 55 -119 355 55 -119 minecraft:water[level=0]
setblock 356 55 -119 minecraft:kelp_plant
fill 357 55 -119 361 55 -119 minecraft:water[level=0]
setblock 362 55 -119 minecraft:kelp_plant
fill 363 55 -119 366 55 -119 minecraft:water[level=0]
setblock 367 55 -119 minecraft:kelp_plant
fill 368 55 -119 370 55 -119 minecraft:water[level=0]
setblock 371 55 -119 minecraft:kelp_plant
fill 372 55 -119 375 55 -119 minecraft:water[level=0]
setblock 376 55 -119 minecraft:kelp_plant
fill 377 55 -119 379 55 -119 minecraft:water[level=0]
setblock 380 55 -119 minecraft:kelp_plant
fill 381 55 -119 391 55 -119 minecraft:water[level=0]
fill 328 55 -120 329 55 -120 minecraft:water[level=0]
setblock 330 55 -120 minecraft:kelp_plant
fill 331 55 -120 337 55 -120 minecraft:water[level=0]
setblock 338 55 -120 minecraft:kelp_plant
fill 339 55 -120 342 55 -120 minecraft:water[level=0]
setblock 343 55 -120 minecraft:kelp_plant
fill 344 55 -120 345 55 -120 minecraft:water[level=0]
setblock 346 55 -120 minecraft:kelp_plant
fill 347 55 -120 360 55 -120 minecraft:water[level=0]
fill 361 55 -120 363 55 -120 minecraft:kelp_plant
fill 364 55 -120 371 55 -120 minecraft:water[level=0]
setblock 372 55 -120 minecraft:kelp_plant
fill 373 55 -120 384 55 -120 minecraft:water[level=0]
setblock 385 55 -120 minecraft:kelp_plant
fill 386 55 -120 391 55 -120 minecraft:water[level=0]
fill 328 55 -121 333 55 -121 minecraft:water[level=0]
setblock 334 55 -121 minecraft:kelp_plant
fill 335 55 -121 339 55 -121 minecraft:water[level=0]
setblock 340 55 -121 minecraft:kelp_plant
fill 341 55 -121 346 55 -121 minecraft:water[level=0]
fill 347 55 -121 349 55 -121 minecraft:kelp_plant
setblock 350 55 -121 minecraft:water[level=0]
setblock 351 55 -121 minecraft:kelp_plant
fill 352 55 -121 354 55 -121 minecraft:water[level=0]
setblock 355 55 -121 minecraft:kelp_plant
fill 356 55 -121 372 55 -121 minecraft:water[level=0]
setblock 373 55 -121 minecraft:kelp_plant
fill 374 55 -121 378 55 -121 minecraft:water[level=0]
setblock 379 55 -121 minecraft:kelp_plant
setblock 380 55 -121 minecraft:kelp[age=25]
fill 381 55 -121 384 55 -121 minecraft:water[level=0]
setblock 385 55 -121 minecraft:kelp_plant
fill 386 55 -121 391 55 -121 minecraft:water[level=0]
setblock 328 55 -122 minecraft:kelp_plant
fill 329 55 -122 331 55 -122 minecraft:water[level=0]
setblock 332 55 -122 minecraft:kelp_plant
fill 333 55 -122 341 55 -122 minecraft:water[level=0]
setblock 342 55 -122 minecraft:kelp_plant
fill 343 55 -122 345 55 -122 minecraft:water[level=0]
setblock 346 55 -122 minecraft:kelp_plant
fill 347 55 -122 352 55 -122 minecraft:water[level=0]
setblock 353 55 -122 minecraft:kelp_plant
fill 354 55 -122 362 55 -122 minecraft:water[level=0]
setblock 363 55 -122 minecraft:kelp_plant
fill 364 55 -122 366 55 -122 minecraft:water[level=0]
setblock 367 55 -122 minecraft:kelp_plant
fill 368 55 -122 370 55 -122 minecraft:water[level=0]
fill 371 55 -122 373 55 -122 minecraft:kelp_plant
fill 374 55 -122 381 55 -122 minecraft:water[level=0]
setblock 382 55 -122 minecraft:kelp[age=25]
fill 383 55 -122 384 55 -122 minecraft:water[level=0]
setblock 385 55 -122 minecraft:kelp_plant
fill 386 55 -122 391 55 -122 minecraft:water[level=0]
setblock 328 55 -123 minecraft:water[level=0]
fill 329 55 -123 330 55 -123 minecraft:kelp_plant
fill 331 55 -123 336 55 -123 minecraft:water[level=0]
setblock 337 55 -123 minecraft:kelp_plant
fill 338 55 -123 344 55 -123 minecraft:water[level=0]
fill 345 55 -123 346 55 -123 minecraft:kelp_plant
fill 347 55 -123 348 55 -123 minecraft:water[level=0]
setblock 349 55 -123 minecraft:kelp_plant
fill 350 55 -123 354 55 -123 minecraft:water[level=0]
setblock 355 55 -123 minecraft:kelp_plant
fill 356 55 -123 374 55 -123 minecraft:water[level=0]
setblock 375 55 -123 minecraft:kelp_plant
fill 376 55 -123 382 55 -123 minecraft:water[level=0]
setblock 383 55 -123 minecraft:kelp_plant
fill 384 55 -123 389 55 -123 minecraft:water[level=0]
fill 390 55 -123 391 55 -123 minecraft:kelp_plant
setblock 328 55 -124 minecraft:kelp_plant
fill 329 55 -124 331 55 -124 minecraft:water[level=0]
setblock 332 55 -124 minecraft:tall_seagrass[half=lower]
fill 333 55 -124 337 55 -124 minecraft:water[level=0]
setblock 338 55 -124 minecraft:kelp_plant
fill 339 55 -124 343 55 -124 minecraft:water[level=0]
setblock 344 55 -124 minecraft:seagrass
fill 345 55 -124 358 55 -124 minecraft:water[level=0]
setblock 359 55 -124 minecraft:kelp_plant
fill 360 55 -124 363 55 -124 minecraft:water[level=0]
setblock 364 55 -124 minecraft:kelp_plant
fill 365 55 -124 367 55 -124 minecraft:water[level=0]
setblock 368 55 -124 minecraft:kelp_plant
fill 369 55 -124 371 55 -124 minecraft:water[level=0]
setblock 372 55 -124 minecraft:kelp_plant
fill 373 55 -124 375 55 -124 minecraft:water[level=0]
fill 376 55 -124 377 55 -124 minecraft:kelp_plant
fill 378 55 -124 383 55 -124 minecraft:water[level=0]
setblock 384 55 -124 minecraft:kelp_plant
fill 385 55 -124 391 55 -124 minecraft:water[level=0]
fill 328 55 -125 332 55 -125 minecraft:water[level=0]
setblock 333 55 -125 minecraft:seagrass
fill 334 55 -125 342 55 -125 minecraft:water[level=0]
setblock 343 55 -125 minecraft:kelp_plant
fill 344 55 -125 346 55 -125 minecraft:water[level=0]
setblock 347 55 -125 minecraft:kelp_plant
fill 348 55 -125 364 55 -125 minecraft:water[level=0]
setblock 365 55 -125 minecraft:kelp_plant
fill 366 55 -125 381 55 -125 minecraft:water[level=0]
setblock 382 55 -125 minecraft:kelp[age=25]
fill 383 55 -125 391 55 -125 minecraft:water[level=0]
fill 328 55 -126 330 55 -126 minecraft:water[level=0]
setblock 331 55 -126 minecraft:seagrass
setblock 332 55 -126 minecraft:tall_seagrass[half=lower]
fill 333 55 -126 334 55 -126 minecraft:seagrass
fill 335 55 -126 336 55 -126 minecraft:water[level=0]
setblock 337 55 -126 minecraft:kelp_plant
setblock 338 55 -126 minecraft:water[level=0]
fill 339 55 -126 340 55 -126 minecraft:kelp_plant
setblock 341 55 -126 minecraft:water[level=0]
setblock 342 55 -126 minecraft:kelp_plant
setblock 343 55 -126 minecraft:seagrass
fill 344 55 -126 347 55 -126 minecraft:kelp_plant
setblock 348 55 -126 minecraft:water[level=0]
setblock 349 55 -126 minecraft:kelp_plant
setblock 350 55 -126 minecraft:water[level=0]
fill 351 55 -126 353 55 -126 minecraft:kelp_plant
setblock 354 55 -126 minecraft:water[level=0]
setblock 355 55 -126 minecraft:kelp_plant
fill 356 55 -126 366 55 -126 minecraft:water[level=0]
setblock 367 55 -126 minecraft:kelp_plant
fill 368 55 -126 371 55 -126 minecraft:water[level=0]
setblock 372 55 -126 minecraft:kelp_plant
fill 373 55 -126 374 55 -126 minecraft:water[level=0]
setblock 375 55 -126 minecraft:kelp_plant
setblock 376 55 -126 minecraft:water[level=0]
setblock 377 55 -126 minecraft:kelp_plant
fill 378 55 -126 391 55 -126 minecraft:water[level=0]
fill 328 54 -116 329 54 -116 minecraft:water[level=0]
setblock 330 54 -116 minecraft:kelp_plant
fill 331 54 -116 341 54 -116 minecraft:water[level=0]
setblock 342 54 -116 minecraft:kelp_plant
fill 343 54 -116 345 54 -116 minecraft:water[level=0]
setblock 346 54 -116 minecraft:kelp_plant
fill 347 54 -116 348 54 -116 minecraft:water[level=0]
setblock 349 54 -116 minecraft:kelp_plant
fill 350 54 -116 352 54 -116 minecraft:water[level=0]
setblock 353 54 -116 minecraft:kelp_plant
setblock 354 54 -116 minecraft:water[level=0]
setblock 355 54 -116 minecraft:kelp_plant
fill 356 54 -116 359 54 -116 minecraft:water[level=0]
setblock 360 54 -116 minecraft:kelp_plant
fill 361 54 -116 363 54 -116 minecraft:water[level=0]
setblock 364 54 -116 minecraft:kelp_plant
setblock 365 54 -116 minecraft:water[level=0]
setblock 366 54 -116 minecraft:kelp_plant
fill 367 54 -116 368 54 -116 minecraft:water[level=0]
setblock 369 54 -116 minecraft:kelp_plant
fill 370 54 -116 371 54 -116 minecraft:water[level=0]
setblock 372 54 -116 minecraft:kelp_plant
fill 373 54 -116 379 54 -116 minecraft:water[level=0]
setblock 380 54 -116 minecraft:kelp_plant
fill 381 54 -116 386 54 -116 minecraft:water[level=0]
fill 328 54 -117 330 54 -117 minecraft:water[level=0]
setblock 331 54 -117 minecraft:kelp_plant
fill 332 54 -117 336 54 -117 minecraft:water[level=0]
setblock 337 54 -117 minecraft:kelp_plant
fill 338 54 -117 340 54 -117 minecraft:water[level=0]
setblock 341 54 -117 minecraft:kelp_plant
fill 342 54 -117 343 54 -117 minecraft:water[level=0]
setblock 344 54 -117 minecraft:kelp_plant
fill 345 54 -117 375 54 -117 minecraft:water[level=0]
setblock 376 54 -117 minecraft:kelp_plant
fill 377 54 -117 382 54 -117 minecraft:water[level=0]
setblock 383 54 -117 minecraft:kelp_plant
fill 384 54 -117 391 54 -117 minecraft:water[level=0]
fill 328 54 -118 331 54 -118 minecraft:water[level=0]
fill 332 54 -118 334 54 -118 minecraft:kelp_plant
setblock 335 54 -118 minecraft:water[level=0]
setblock 336 54 -118 minecraft:kelp_plant
setblock 337 54 -118 minecraft:water[level=0]
setblock 338 54 -118 minecraft:kelp_plant
fill 339 54 -118 341 54 -118 minecraft:water[level=0]
setblock 342 54 -118 minecraft:kelp_plant
fill 343 54 -118 345 54 -118 minecraft:water[level=0]
setblock 346 54 -118 minecraft:kelp_plant
fill 347 54 -118 349 54 -118 minecraft:water[level=0]
setblock 350 54 -118 minecraft:kelp_plant
fill 351 54 -118 354 54 -118 minecraft:water[level=0]
setblock 355 54 -118 minecraft:kelp_plant
fill 356 54 -118 358 54 -118 minecraft:water[level=0]
setblock 359 54 -118 minecraft:kelp_plant
fill 360 54 -118 361 54 -118 minecraft:water[level=0]
setblock 362 54 -118 minecraft:kelp_plant
setblock 363 54 -118 minecraft:water[level=0]
fill 364 54 -118 365 54 -118 minecraft:kelp_plant
fill 366 54 -118 367 54 -118 minecraft:water[level=0]
setblock 368 54 -118 minecraft:kelp_plant
fill 369 54 -118 371 54 -118 minecraft:water[level=0]
setblock 372 54 -118 minecraft:kelp_plant
setblock 373 54 -118 minecraft:water[level=0]
fill 374 54 -118 375 54 -118 minecraft:kelp_plant
fill 376 54 -118 385 54 -118 minecraft:water[level=0]
setblock 386 54 -118 minecraft:kelp_plant
fill 387 54 -118 389 54 -118 minecraft:water[level=0]
setblock 390 54 -118 minecraft:kelp_plant
setblock 391 54 -118 minecraft:water[level=0]
fill 328 54 -119 334 54 -119 minecraft:water[level=0]
setblock 335 54 -119 minecraft:kelp_plant
fill 336 54 -119 340 54 -119 minecraft:water[level=0]
setblock 341 54 -119 minecraft:kelp_plant
fill 342 54 -119 343 54 -119 minecraft:water[level=0]
fill 344 54 -119 345 54 -119 minecraft:kelp_plant
fill 346 54 -119 350 54 -119 minecraft:water[level=0]
setblock 351 54 -119 minecraft:kelp_plant
fill 352 54 -119 355 54 -119 minecraft:water[level=0]
setblock 356 54 -119 minecraft:kelp_plant
fill 357 54 -119 361 54 -119 minecraft:water[level=0]
setblock 362 54 -119 minecraft:kelp_plant
fill 363 54 -119 366 54 -119 minecraft:water[level=0]
setblock 367 54 -119 minecraft:kelp_plant
fill 368 54 -119 370 54 -119 minecraft:water[level=0]
setblock 371 54 -119 minecraft:kelp_plant
fill 372 54 -119 375 54 -119 minecraft:water[level=0]
setblock 376 54 -119 minecraft:kelp_plant
fill 377 54 -119 379 54 -119 minecraft:water[level=0]
setblock 380 54 -119 minecraft:kelp_plant
fill 381 54 -119 391 54 -119 minecraft:water[level=0]
fill 328 54 -120 329 54 -120 minecraft:water[level=0]
setblock 330 54 -120 minecraft:kelp_plant
fill 331 54 -120 337 54 -120 minecraft:water[level=0]
setblock 338 54 -120 minecraft:kelp_plant
fill 339 54 -120 342 54 -120 minecraft:water[level=0]
setblock 343 54 -120 minecraft:kelp_plant
fill 344 54 -120 345 54 -120 minecraft:water[level=0]
setblock 346 54 -120 minecraft:kelp_plant
fill 347 54 -120 360 54 -120 minecraft:water[level=0]
fill 361 54 -120 363 54 -120 minecraft:kelp_plant
fill 364 54 -120 371 54 -120 minecraft:water[level=0]
setblock 372 54 -120 minecraft:kelp_plant
fill 373 54 -120 384 54 -120 minecraft:water[level=0]
setblock 385 54 -120 minecraft:kelp_plant
fill 386 54 -120 391 54 -120 minecraft:water[level=0]
fill 328 54 -121 333 54 -121 minecraft:water[level=0]
setblock 334 54 -121 minecraft:kelp_plant
fill 335 54 -121 339 54 -121 minecraft:water[level=0]
setblock 340 54 -121 minecraft:kelp_plant
fill 341 54 -121 345 54 -121 minecraft:water[level=0]
setblock 346 54 -121 minecraft:tall_seagrass[half=upper]
fill 347 54 -121 349 54 -121 minecraft:kelp_plant
setblock 350 54 -121 minecraft:water[level=0]
setblock 351 54 -121 minecraft:kelp_plant
fill 352 54 -121 354 54 -121 minecraft:water[level=0]
setblock 355 54 -121 minecraft:kelp_plant
setblock 356 54 -121 minecraft:water[level=0]
setblock 357 54 -121 minecraft:tall_seagrass[half=upper]
fill 358 54 -121 372 54 -121 minecraft:water[level=0]
setblock 373 54 -121 minecraft:kelp_plant
fill 374 54 -121 378 54 -121 minecraft:water[level=0]
fill 379 54 -121 380 54 -121 minecraft:kelp_plant
fill 381 54 -121 384 54 -121 minecraft:water[level=0]
setblock 385 54 -121 minecraft:kelp_plant
fill 386 54 -121 391 54 -121 minecraft:water[level=0]
setblock 328 54 -122 minecraft:kelp_plant
fill 329 54 -122 331 54 -122 minecraft:water[level=0]
setblock 332 54 -122 minecraft:kelp_plant
fill 333 54 -122 341 54 -122 minecraft:water[level=0]
setblock 342 54 -122 minecraft:kelp_plant
fill 343 54 -122 345 54 -122 minecraft:water[level=0]
setblock 346 54 -122 minecraft:kelp_plant
fill 347 54 -122 352 54 -122 minecraft:water[level=0]
setblock 353 54 -122 minecraft:kelp_plant
fill 354 54 -122 362 54 -122 minecraft:water[level=0]
setblock 363 54 -122 minecraft:kelp_plant
fill 364 54 -122 366 54 -122 minecraft:water[level=0]
setblock 367 54 -122 minecraft:kelp_plant
fill 368 54 -122 370 54 -122 minecraft:water[level=0]
fill 371 54 -122 373 54 -122 minecraft:kelp_plant
fill 374 54 -122 381 54 -122 minecraft:water[level=0]
setblock 382 54 -122 minecraft:kelp_plant
fill 383 54 -122 384 54 -122 minecraft:water[level=0]
setblock 385 54 -122 minecraft:kelp_plant
fill 386 54 -122 391 54 -122 minecraft:water[level=0]
setblock 328 54 -123 minecraft:water[level=0]
fill 329 54 -123 330 54 -123 minecraft:kelp_plant
fill 331 54 -123 336 54 -123 minecraft:water[level=0]
setblock 337 54 -123 minecraft:kelp_plant
fill 338 54 -123 344 54 -123 minecraft:water[level=0]
fill 345 54 -123 346 54 -123 minecraft:kelp_plant
fill 347 54 -123 348 54 -123 minecraft:water[level=0]
setblock 349 54 -123 minecraft:kelp_plant
fill 350 54 -123 354 54 -123 minecraft:water[level=0]
setblock 355 54 -123 minecraft:kelp_plant
setblock 356 54 -123 minecraft:tall_seagrass[half=upper]
fill 357 54 -123 374 54 -123 minecraft:water[level=0]
setblock 375 54 -123 minecraft:kelp_plant
fill 376 54 -123 382 54 -123 minecraft:water[level=0]
setblock 383 54 -123 minecraft:kelp_plant
fill 384 54 -123 389 54 -123 minecraft:water[level=0]
fill 390 54 -123 391 54 -123 minecraft:kelp_plant
setblock 333 54 -124 minecraft:seagrass
fill 334 54 -124 337 54 -124 minecraft:water[level=0]
setblock 338 54 -124 minecraft:kelp_plant
fill 339 54 -124 343 54 -124 minecraft:water[level=0]
setblock 345 54 -124 minecraft:seagrass
fill 346 54 -124 358 54 -124 minecraft:water[level=0]
setblock 359 54 -124 minecraft:kelp_plant
fill 360 54 -124 362 54 -124 minecraft:water[level=0]
setblock 363 54 -124 minecraft:tall_seagrass[half=upper]
setblock 364 54 -124 minecraft:kelp_plant
fill 365 54 -124 367 54 -124 minecraft:water[level=0]
setblock 368 54 -124 minecraft:kelp_plant
fill 369 54 -124 371 54 -124 minecraft:water[level=0]
setblock 372 54 -124 minecraft:kelp_plant
fill 373 54 -124 375 54 -124 minecraft:water[level=0]
fill 376 54 -124 377 54 -124 minecraft:kelp_plant
fill 378 54 -124 383 54 -124 minecraft:water[level=0]
setblock 384 54 -124 minecraft:kelp_plant
fill 385 54 -124 391 54 -124 minecraft:water[level=0]
setblock 334 54 -125 minecraft:water[level=0]
setblock 335 54 -125 minecraft:seagrass
fill 336 54 -125 342 54 -125 minecraft:water[level=0]
setblock 343 54 -125 minecraft:kelp_plant
setblock 346 54 -125 minecraft:water[level=0]
setblock 347 54 -125 minecraft:kelp_plant
fill 348 54 -125 360 54 -125 minecraft:water[level=0]
fill 361 54 -125 362 54 -125 minecraft:tall_seagrass[half=upper]
fill 363 54 -125 364 54 -125 minecraft:water[level=0]
setblock 365 54 -125 minecraft:kelp_plant
fill 366 54 -125 381 54 -125 minecraft:water[level=0]
setblock 382 54 -125 minecraft:kelp_plant
fill 383 54 -125 391 54 -125 minecraft:water[level=0]
setblock 335 54 -126 minecraft:seagrass
setblock 336 54 -126 minecraft:water[level=0]
setblock 337 54 -126 minecraft:kelp_plant
setblock 338 54 -126 minecraft:water[level=0]
fill 339 54 -126 340 54 -126 minecraft:kelp_plant
setblock 341 54 -126 minecraft:tall_seagrass[half=upper]
setblock 342 54 -126 minecraft:kelp_plant
fill 346 54 -126 347 54 -126 minecraft:kelp_plant
setblock 348 54 -126 minecraft:water[level=0]
setblock 349 54 -126 minecraft:kelp_plant
setblock 350 54 -126 minecraft:water[level=0]
fill 351 54 -126 353 54 -126 minecraft:kelp_plant
setblock 354 54 -126 minecraft:water[level=0]
setblock 355 54 -126 minecraft:kelp_plant
fill 356 54 -126 366 54 -126 minecraft:water[level=0]
setblock 367 54 -126 minecraft:kelp_plant
fill 368 54 -126 371 54 -126 minecraft:water[level=0]
setblock 372 54 -126 minecraft:kelp_plant
fill 373 54 -126 374 54 -126 minecraft:water[level=0]
setblock 375 54 -126 minecraft:kelp_plant
setblock 376 54 -126 minecraft:water[level=0]
setblock 377 54 -126 minecraft:kelp_plant
fill 378 54 -126 391 54 -126 minecraft:water[level=0]
fill 328 53 -116 329 53 -116 minecraft:water[level=0]
setblock 330 53 -116 minecraft:kelp_plant
fill 331 53 -116 341 53 -116 minecraft:water[level=0]
setblock 342 53 -116 minecraft:kelp_plant
fill 343 53 -116 345 53 -116 minecraft:water[level=0]
setblock 346 53 -116 minecraft:kelp_plant
fill 347 53 -116 348 53 -116 minecraft:water[level=0]
setblock 349 53 -116 minecraft:kelp_plant
fill 350 53 -116 352 53 -116 minecraft:water[level=0]
setblock 353 53 -116 minecraft:kelp_plant
setblock 354 53 -116 minecraft:water[level=0]
setblock 355 53 -116 minecraft:kelp_plant
fill 356 53 -116 359 53 -116 minecraft:water[level=0]
setblock 360 53 -116 minecraft:kelp_plant
setblock 361 53 -116 minecraft:water[level=0]
setblock 362 53 -116 minecraft:tall_seagrass[half=upper]
setblock 363 53 -116 minecraft:water[level=0]
setblock 364 53 -116 minecraft:kelp_plant
setblock 365 53 -116 minecraft:water[level=0]
setblock 366 53 -116 minecraft:kelp_plant
fill 367 53 -116 368 53 -116 minecraft:water[level=0]
setblock 369 53 -116 minecraft:kelp_plant
fill 370 53 -116 371 53 -116 minecraft:water[level=0]
setblock 372 53 -116 minecraft:kelp_plant
fill 373 53 -116 379 53 -116 minecraft:water[level=0]
setblock 380 53 -116 minecraft:kelp_plant
fill 381 53 -116 386 53 -116 minecraft:water[level=0]
fill 328 53 -117 330 53 -117 minecraft:water[level=0]
setblock 331 53 -117 minecraft:kelp_plant
fill 332 53 -117 336 53 -117 minecraft:water[level=0]
setblock 337 53 -117 minecraft:kelp_plant
fill 338 53 -117 340 53 -117 minecraft:water[level=0]
setblock 341 53 -117 minecraft:kelp_plant
fill 342 53 -117 343 53 -117 minecraft:water[level=0]
setblock 344 53 -117 minecraft:kelp_plant
fill 345 53 -117 362 53 -117 minecraft:water[level=0]
setblock 363 53 -117 minecraft:tall_seagrass[half=upper]
fill 364 53 -117 375 53 -117 minecraft:water[level=0]
setblock 376 53 -117 minecraft:kelp_plant
fill 377 53 -117 382 53 -117 minecraft:water[level=0]
setblock 383 53 -117 minecraft:kelp_plant
fill 384 53 -117 391 53 -117 minecraft:water[level=0]
fill 328 53 -118 331 53 -118 minecraft:water[level=0]
fill 332 53 -118 334 53 -118 minecraft:kelp_plant
setblock 335 53 -118 minecraft:water[level=0]
setblock 336 53 -118 minecraft:kelp_plant
setblock 337 53 -118 minecraft:water[level=0]
setblock 338 53 -118 minecraft:kelp_plant
fill 339 53 -118 341 53 -118 minecraft:water[level=0]
setblock 342 53 -118 minecraft:kelp_plant
fill 343 53 -118 345 53 -118 minecraft:water[level=0]
setblock 346 53 -118 minecraft:kelp_plant
fill 347 53 -118 349 53 -118 minecraft:water[level=0]
setblock 350 53 -118 minecraft:kelp_plant
fill 351 53 -118 354 53 -118 minecraft:water[level=0]
setblock 355 53 -118 minecraft:kelp_plant
fill 356 53 -118 358 53 -118 minecraft:water[level=0]
setblock 359 53 -118 minecraft:kelp_plant
fill 360 53 -118 361 53 -118 minecraft:water[level=0]
setblock 362 53 -118 minecraft:kelp_plant
setblock 363 53 -118 minecraft:water[level=0]
fill 364 53 -118 365 53 -118 minecraft:kelp_plant
fill 366 53 -118 367 53 -118 minecraft:water[level=0]
setblock 368 53 -118 minecraft:kelp_plant
fill 369 53 -118 371 53 -118 minecraft:water[level=0]
setblock 372 53 -118 minecraft:kelp_plant
setblock 373 53 -118 minecraft:water[level=0]
fill 374 53 -118 375 53 -118 minecraft:kelp_plant
fill 376 53 -118 385 53 -118 minecraft:water[level=0]
setblock 386 53 -118 minecraft:kelp_plant
fill 387 53 -118 389 53 -118 minecraft:water[level=0]
setblock 390 53 -118 minecraft:kelp_plant
setblock 391 53 -118 minecraft:water[level=0]
fill 328 53 -119 334 53 -119 minecraft:water[level=0]
setblock 335 53 -119 minecraft:kelp_plant
fill 336 53 -119 340 53 -119 minecraft:water[level=0]
setblock 341 53 -119 minecraft:kelp_plant
fill 342 53 -119 343 53 -119 minecraft:water[level=0]
fill 344 53 -119 345 53 -119 minecraft:kelp_plant
fill 346 53 -119 350 53 -119 minecraft:water[level=0]
setblock 351 53 -119 minecraft:kelp_plant
fill 352 53 -119 355 53 -119 minecraft:water[level=0]
setblock 356 53 -119 minecraft:kelp_plant
fill 357 53 -119 358 53 -119 minecraft:water[level=0]
setblock 359 53 -119 minecraft:tall_seagrass[half=upper]
fill 360 53 -119 361 53 -119 minecraft:water[level=0]
setblock 362 53 -119 minecraft:kelp_plant
fill 363 53 -119 366 53 -119 minecraft:water[level=0]
setblock 367 53 -119 minecraft:kelp_plant
fill 368 53 -119 370 53 -119 minecraft:water[level=0]
setblock 371 53 -119 minecraft:kelp_plant
fill 372 53 -119 375 53 -119 minecraft:water[level=0]
setblock 376 53 -119 minecraft:kelp_plant
setblock 377 53 -119 minecraft:kelp[age=25]
fill 378 53 -119 379 53 -119 minecraft:water[level=0]
setblock 380 53 -119 minecraft:kelp_plant
fill 381 53 -119 388 53 -119 minecraft:water[level=0]
setblock 389 53 -119 minecraft:kelp[age=25]
fill 390 53 -119 391 53 -119 minecraft:water[level=0]
fill 328 53 -120 329 53 -120 minecraft:water[level=0]
setblock 330 53 -120 minecraft:kelp_plant
fill 331 53 -120 337 53 -120 minecraft:water[level=0]
setblock 338 53 -120 minecraft:kelp_plant
fill 339 53 -120 342 53 -120 minecraft:water[level=0]
setblock 343 53 -120 minecraft:kelp_plant
fill 344 53 -120 345 53 -120 minecraft:water[level=0]
setblock 346 53 -120 minecraft:kelp_plant
fill 347 53 -120 355 53 -120 minecraft:water[level=0]
setblock 356 53 -120 minecraft:tall_seagrass[half=upper]
fill 357 53 -120 360 53 -120 minecraft:water[level=0]
fill 361 53 -120 363 53 -120 minecraft:kelp_plant
fill 364 53 -120 371 53 -120 minecraft:water[level=0]
setblock 372 53 -120 minecraft:kelp_plant
fill 373 53 -120 384 53 -120 minecraft:water[level=0]
setblock 385 53 -120 minecraft:kelp_plant
fill 386 53 -120 391 53 -120 minecraft:water[level=0]
fill 328 53 -121 333 53 -121 minecraft:water[level=0]
setblock 334 53 -121 minecraft:kelp_plant
setblock 335 53 -121 minecraft:tall_seagrass[half=upper]
fill 336 53 -121 339 53 -121 minecraft:water[level=0]
setblock 340 53 -121 minecraft:kelp_plant
fill 341 53 -121 343 53 -121 minecraft:water[level=0]
setblock 344 53 -121 minecraft:tall_seagrass[half=upper]
setblock 345 53 -121 minecraft:water[level=0]
setblock 346 53 -121 minecraft:tall_seagrass[half=lower]
fill 347 53 -121 349 53 -121 minecraft:kelp_plant
setblock 350 53 -121 minecraft:water[level=0]
setblock 351 53 -121 minecraft:kelp_plant
fill 352 53 -121 354 53 -121 minecraft:water[level=0]
setblock 355 53 -121 minecraft:kelp_plant
setblock 356 53 -121 minecraft:water[level=0]
setblock 357 53 -121 minecraft:tall_seagrass[half=lower]
fill 358 53 -121 360 53 -121 minecraft:water[level=0]
setblock 361 53 -121 minecraft:seagrass
setblock 362 53 -121 minecraft:water[level=0]
fill 363 53 -121 364 53 -121 minecraft:seagrass
fill 365 53 -121 372 53 -121 minecraft:water[level=0]
setblock 373 53 -121 minecraft:kelp_plant
fill 374 53 -121 378 53 -121 minecraft:water[level=0]
fill 379 53 -121 380 53 -121 minecraft:kelp_plant
fill 381 53 -121 384 53 -121 minecraft:water[level=0]
setblock 385 53 -121 minecraft:kelp_plant
fill 386 53 -121 391 53 -121 minecraft:water[level=0]
setblock 328 53 -122 minecraft:kelp_plant
fill 329 53 -122 331 53 -122 minecraft:water[level=0]
setblock 332 53 -122 minecraft:kelp_plant
setblock 333 53 -122 minecraft:water[level=0]
setblock 334 53 -122 minecraft:seagrass
fill 335 53 -122 341 53 -122 minecraft:water[level=0]
setblock 342 53 -122 minecraft:kelp_plant
setblock 343 53 -122 minecraft:tall_seagrass[half=upper]
setblock 344 53 -122 minecraft:seagrass
setblock 345 53 -122 minecraft:water[level=0]
setblock 346 53 -122 minecraft:kelp_plant
fill 347 53 -122 352 53 -122 minecraft:water[level=0]
setblock 353 53 -122 minecraft:kelp_plant
fill 354 53 -122 357 53 -122 minecraft:water[level=0]
setblock 358 53 -122 minecraft:seagrass
fill 359 53 -122 360 53 -122 minecraft:water[level=0]
fill 361 53 -122 362 53 -122 minecraft:seagrass
setblock 363 53 -122 minecraft:kelp_plant
setblock 364 53 -122 minecraft:water[level=0]
setblock 365 53 -122 minecraft:tall_seagrass[half=upper]
setblock 366 53 -122 minecraft:water[level=0]
setblock 367 53 -122 minecraft:kelp_plant
fill 368 53 -122 370 53 -122 minecraft:water[level=0]
fill 371 53 -122 373 53 -122 minecraft:kelp_plant
fill 374 53 -122 381 53 -122 minecraft:water[level=0]
setblock 382 53 -122 minecraft:kelp_plant
fill 383 53 -122 384 53 -122 minecraft:water[level=0]
setblock 385 53 -122 minecraft:kelp_plant
fill 386 53 -122 391 53 -122 minecraft:water[level=0]
fill 334 53 -123 335 53 -123 minecraft:seagrass
setblock 336 53 -123 minecraft:water[level=0]
setblock 337 53 -123 minecraft:kelp_plant
fill 338 53 -123 343 53 -123 minecraft:water[level=0]
setblock 348 53 -123 minecraft:water[level=0]
setblock 349 53 -123 minecraft:kelp_plant
fill 350 53 -123 352 53 -123 minecraft:water[level=0]
setblock 353 53 -123 minecraft:seagrass
setblock 354 53 -123 minecraft:water[level=0]
setblock 355 53 -123 minecraft:kelp_plant
setblock 356 53 -123 minecraft:tall_seagrass[half=lower]
setblock 357 53 -123 minecraft:seagrass
setblock 358 53 -123 minecraft:water[level=0]
setblock 359 53 -123 minecraft:seagrass
setblock 360 53 -123 minecraft:water[level=0]
setblock 361 53 -123 minecraft:seagrass
setblock 362 53 -123 minecraft:water[level=0]
fill 363 53 -123 364 53 -123 minecraft:seagrass
fill 365 53 -123 374 53 -123 minecraft:water[level=0]
setblock 375 53 -123 minecraft:kelp_plant
fill 376 53 -123 382 53 -123 minecraft:water[level=0]
setblock 383 53 -123 minecraft:kelp_plant
fill 384 53 -123 389 53 -123 minecraft:water[level=0]
fill 390 53 -123 391 53 -123 minecraft:kelp_plant
setblock 335 53 -124 minecraft:water[level=0]
setblock 336 53 -124 minecraft:seagrass
setblock 337 53 -124 minecraft:tall_seagrass[half=upper]
setblock 338 53 -124 minecraft:kelp_plant
fill 339 53 -124 341 53 -124 minecraft:water[level=0]
setblock 342 53 -124 minecraft:seagrass
fill 349 53 -124 356 53 -124 minecraft:water[level=0]
setblock 357 53 -124 minecraft:seagrass
setblock 358 53 -124 minecraft:water[level=0]
setblock 359 53 -124 minecraft:kelp_plant
setblock 360 53 -124 minecraft:water[level=0]
setblock 361 53 -124 minecraft:seagrass
setblock 362 53 -124 minecraft:water[level=0]
setblock 363 53 -124 minecraft:tall_seagrass[half=lower]
setblock 364 53 -124 minecraft:kelp_plant
setblock 365 53 -124 minecraft:seagrass
fill 366 53 -124 367 53 -124 minecraft:water[level=0]
setblock 368 53 -124 minecraft:kelp_plant
fill 369 53 -124 371 53 -124 minecraft:water[level=0]
setblock 372 53 -124 minecraft:kelp_plant
fill 373 53 -124 375 53 -124 minecraft:water[level=0]
fill 376 53 -124 377 53 -124 minecraft:kelp_plant
fill 378 53 -124 383 53 -124 minecraft:water[level=0]
setblock 384 53 -124 minecraft:kelp_plant
fill 385 53 -124 391 53 -124 minecraft:water[level=0]
fill 336 53 -125 342 53 -125 minecraft:water[level=0]
fill 350 53 -125 358 53 -125 minecraft:water[level=0]
fill 359 53 -125 360 53 -125 minecraft:seagrass
fill 361 53 -125 362 53 -125 minecraft:tall_seagrass[half=lower]
fill 363 53 -125 364 53 -125 minecraft:water[level=0]
setblock 365 53 -125 minecraft:kelp_plant
fill 366 53 -125 381 53 -125 minecraft:water[level=0]
setblock 382 53 -125 minecraft:kelp_plant
fill 383 53 -125 391 53 -125 minecraft:water[level=0]
setblock 338 53 -126 minecraft:seagrass
fill 339 53 -126 340 53 -126 minecraft:kelp_plant
setblock 341 53 -126 minecraft:tall_seagrass[half=lower]
setblock 350 53 -126 minecraft:water[level=0]
fill 351 53 -126 353 53 -126 minecraft:kelp_plant
setblock 354 53 -126 minecraft:water[level=0]
setblock 355 53 -126 minecraft:kelp_plant
fill 356 53 -126 357 53 -126 minecraft:water[level=0]
setblock 358 53 -126 minecraft:seagrass
fill 359 53 -126 360 53 -126 minecraft:water[level=0]
setblock 361 53 -126 minecraft:seagrass
fill 362 53 -126 366 53 -126 minecraft:water[level=0]
setblock 367 53 -126 minecraft:kelp_plant
fill 368 53 -126 371 53 -126 minecraft:water[level=0]
setblock 372 53 -126 minecraft:kelp_plant
fill 373 53 -126 374 53 -126 minecraft:water[level=0]
setblock 375 53 -126 minecraft:kelp_plant
setblock 376 53 -126 minecraft:water[level=0]
setblock 377 53 -126 minecraft:kelp_plant
fill 378 53 -126 391 53 -126 minecraft:water[level=0]
fill 328 52 -116 329 52 -116 minecraft:water[level=0]
setblock 330 52 -116 minecraft:kelp_plant
fill 331 52 -116 341 52 -116 minecraft:water[level=0]
setblock 342 52 -116 minecraft:kelp_plant
fill 343 52 -116 345 52 -116 minecraft:water[level=0]
setblock 346 52 -116 minecraft:kelp_plant
fill 347 52 -116 348 52 -116 minecraft:water[level=0]
setblock 349 52 -116 minecraft:kelp_plant
fill 350 52 -116 352 52 -116 minecraft:water[level=0]
setblock 353 52 -116 minecraft:kelp_plant
setblock 354 52 -116 minecraft:water[level=0]
setblock 355 52 -116 minecraft:kelp_plant
fill 356 52 -116 359 52 -116 minecraft:water[level=0]
setblock 360 52 -116 minecraft:kelp_plant
setblock 361 52 -116 minecraft:water[level=0]
setblock 362 52 -116 minecraft:tall_seagrass[half=lower]
setblock 363 52 -116 minecraft:water[level=0]
setblock 364 52 -116 minecraft:kelp_plant
setblock 365 52 -116 minecraft:water[level=0]
setblock 366 52 -116 minecraft:kelp_plant
fill 367 52 -116 368 52 -116 minecraft:water[level=0]
setblock 369 52 -116 minecraft:kelp_plant
fill 370 52 -116 371 52 -116 minecraft:water[level=0]
setblock 372 52 -116 minecraft:kelp_plant
fill 373 52 -116 379 52 -116 minecraft:water[level=0]
setblock 380 52 -116 minecraft:kelp_plant
fill 381 52 -116 386 52 -116 minecraft:water[level=0]
fill 328 52 -117 330 52 -117 minecraft:water[level=0]
setblock 331 52 -117 minecraft:kelp_plant
fill 332 52 -117 336 52 -117 minecraft:water[level=0]
setblock 337 52 -117 minecraft:kelp_plant
fill 338 52 -117 340 52 -117 minecraft:water[level=0]
setblock 341 52 -117 minecraft:kelp_plant
fill 342 52 -117 343 52 -117 minecraft:water[level=0]
setblock 344 52 -117 minecraft:kelp_plant
fill 345 52 -117 353 52 -117 minecraft:water[level=0]
setblock 354 52 -117 minecraft:seagrass
fill 355 52 -117 357 52 -117 minecraft:water[level=0]
setblock 358 52 -117 minecraft:seagrass
fill 359 52 -117 362 52 -117 minecraft:water[level=0]
setblock 363 52 -117 minecraft:tall_seagrass[half=lower]
fill 364 52 -117 375 52 -117 minecraft:water[level=0]
setblock 376 52 -117 minecraft:kelp_plant
fill 377 52 -117 382 52 -117 minecraft:water[level=0]
setblock 383 52 -117 minecraft:kelp_plant
fill 384 52 -117 391 52 -117 minecraft:water[level=0]
fill 328 52 -118 331 52 -118 minecraft:water[level=0]
fill 332 52 -118 334 52 -118 minecraft:kelp_plant
setblock 335 52 -118 minecraft:water[level=0]
setblock 336 52 -118 minecraft:kelp_plant
setblock 337 52 -118 minecraft:water[level=0]
setblock 338 52 -118 minecraft:kelp_plant
fill 339 52 -118 341 52 -118 minecraft:water[level=0]
setblock 342 52 -118 minecraft:kelp_plant
fill 343 52 -118 345 52 -118 minecraft:water[level=0]
setblock 346 52 -118 minecraft:kelp_plant
setblock 347 52 -118 minecraft:water[level=0]
setblock 349 52 -118 minecraft:water[level=0]
setblock 350 52 -118 minecraft:kelp_plant
fill 351 52 -118 354 52 -118 minecraft:water[level=0]
setblock 355 52 -118 minecraft:kelp_plant
fill 356 52 -118 358 52 -118 minecraft:water[level=0]
setblock 359 52 -118 minecraft:kelp_plant
setblock 360 52 -118 minecraft:seagrass
setblock 361 52 -118 minecraft:water[level=0]
setblock 362 52 -118 minecraft:kelp_plant
setblock 363 52 -118 minecraft:water[level=0]
fill 364 52 -118 365 52 -118 minecraft:kelp_plant
fill 366 52 -118 367 52 -118 minecraft:water[level=0]
setblock 368 52 -118 minecraft:kelp_plant
fill 369 52 -118 371 52 -118 minecraft:water[level=0]
setblock 372 52 -118 minecraft:kelp_plant
setblock 373 52 -118 minecraft:water[level=0]
fill 374 52 -118 375 52 -118 minecraft:kelp_plant
setblock 376 52 -118 minecraft:water[level=0]
setblock 377 52 -118 minecraft:tall_seagrass[half=upper]
fill 378 52 -118 379 52 -118 minecraft:water[level=0]
setblock 380 52 -118 minecraft:tall_seagrass[half=upper]
fill 381 52 -118 385 52 -118 minecraft:water[level=0]
setblock 386 52 -118 minecraft:kelp_plant
fill 387 52 -118 389 52 -118 minecraft:water[level=0]
setblock 390 52 -118 minecraft:kelp_plant
setblock 391 52 -118 minecraft:water[level=0]
fill 328 52 -119 334 52 -119 minecraft:water[level=0]
setblock 335 52 -119 minecraft:kelp_plant
fill 336 52 -119 340 52 -119 minecraft:water[level=0]
setblock 341 52 -119 minecraft:kelp_plant
fill 342 52 -119 343 52 -119 minecraft:water[level=0]
fill 344 52 -119 345 52 -119 minecraft:kelp_plant
fill 346 52 -119 347 52 -119 minecraft:water[level=0]
setblock 351 52 -119 minecraft:kelp_plant
fill 352 52 -119 355 52 -119 minecraft:water[level=0]
setblock 356 52 -119 minecraft:kelp_plant
fill 357 52 -119 358 52 -119 minecraft:water[level=0]
setblock 359 52 -119 minecraft:tall_seagrass[half=lower]
fill 360 52 -119 361 52 -119 minecraft:water[level=0]
setblock 362 52 -119 minecraft:kelp_plant
fill 363 52 -119 366 52 -119 minecraft:water[level=0]
setblock 367 52 -119 minecraft:kelp_plant
fill 368 52 -119 370 52 -119 minecraft:water[level=0]
setblock 371 52 -119 minecraft:kelp_plant
fill 372 52 -119 375 52 -119 minecraft:water[level=0]
fill 376 52 -119 377 52 -119 minecraft:kelp_plant
fill 378 52 -119 379 52 -119 minecraft:water[level=0]
setblock 380 52 -119 minecraft:kelp_plant
setblock 381 52 -119 minecraft:water[level=0]
setblock 382 52 -119 minecraft:tall_seagrass[half=upper]
fill 383 52 -119 388 52 -119 minecraft:water[level=0]
setblock 389 52 -119 minecraft:kelp_plant
fill 390 52 -119 391 52 -119 minecraft:water[level=0]
fill 328 52 -120 329 52 -120 minecraft:water[level=0]
setblock 330 52 -120 minecraft:kelp_plant
fill 331 52 -120 337 52 -120 minecraft:water[level=0]
setblock 338 52 -120 minecraft:kelp_plant
fill 339 52 -120 342 52 -120 minecraft:water[level=0]
setblock 343 52 -120 minecraft:kelp_plant
fill 344 52 -120 345 52 -120 minecraft:water[level=0]
setblock 346 52 -120 minecraft:kelp_plant
fill 352 52 -120 355 52 -120 minecraft:water[level=0]
setblock 356 52 -120 minecraft:tall_seagrass[half=lower]
setblock 357 52 -120 minecraft:seagrass
setblock 358 52 -120 minecraft:water[level=0]
fill 359 52 -120 360 52 -120 minecraft:seagrass
fill 361 52 -120 363 52 -120 minecraft:kelp_plant
setblock 364 52 -120 minecraft:water[level=0]
setblock 365 52 -120 minecraft:seagrass
fill 366 52 -120 371 52 -120 minecraft:water[level=0]
setblock 372 52 -120 minecraft:kelp_plant
fill 373 52 -120 384 52 -120 minecraft:water[level=0]
setblock 385 52 -120 minecraft:kelp_plant
fill 386 52 -120 391 52 -120 minecraft:water[level=0]
fill 328 52 -121 331 52 -121 minecraft:water[level=0]
setblock 333 52 -121 minecraft:water[level=0]
setblock 334 52 -121 minecraft:kelp_plant
setblock 335 52 -121 minecraft:tall_seagrass[half=lower]
fill 336 52 -121 339 52 -121 minecraft:water[level=0]
setblock 340 52 -121 minecraft:kelp_plant
fill 341 52 -121 343 52 -121 minecraft:water[level=0]
setblock 344 52 -121 minecraft:tall_seagrass[half=lower]
setblock 345 52 -121 minecraft:water[level=0]
setblock 365 52 -121 minecraft:water[level=0]
fill 366 52 -121 367 52 -121 minecraft:seagrass
fill 368 52 -121 372 52 -121 minecraft:water[level=0]
setblock 373 52 -121 minecraft:kelp_plant
fill 374 52 -121 378 52 -121 minecraft:water[level=0]
fill 379 52 -121 380 52 -121 minecraft:kelp_plant
fill 381 52 -121 384 52 -121 minecraft:water[level=0]
setblock 385 52 -121 minecraft:kelp_plant
fill 386 52 -121 391 52 -121 minecraft:water[level=0]
setblock 335 52 -122 minecraft:seagrass
setblock 336 52 -122 minecraft:water[level=0]
setblock 337 52 -122 minecraft:seagrass
fill 338 52 -122 341 52 -122 minecraft:water[level=0]
setblock 342 52 -122 minecraft:kelp_plant
setblock 343 52 -122 minecraft:tall_seagrass[half=lower]
setblock 365 52 -122 minecraft:tall_seagrass[half=lower]
setblock 366 52 -122 minecraft:seagrass
setblock 367 52 -122 minecraft:kelp_plant
fill 368 52 -122 370 52 -122 minecraft:water[level=0]
fill 371 52 -122 373 52 -122 minecraft:kelp_plant
fill 374 52 -122 381 52 -122 minecraft:water[level=0]
setblock 382 52 -122 minecraft:kelp_plant
fill 383 52 -122 384 52 -122 minecraft:water[level=0]
setblock 385 52 -122 minecraft:kelp_plant
fill 386 52 -122 391 52 -122 minecraft:water[level=0]
setblock 336 52 -123 minecraft:seagrass
setblock 337 52 -123 minecraft:kelp_plant
fill 338 52 -123 342 52 -123 minecraft:water[level=0]
fill 365 52 -123 374 52 -123 minecraft:water[level=0]
setblock 375 52 -123 minecraft:kelp_plant
fill 376 52 -123 382 52 -123 minecraft:water[level=0]
setblock 383 52 -123 minecraft:kelp_plant
fill 384 52 -123 389 52 -123 minecraft:water[level=0]
fill 390 52 -123 391 52 -123 minecraft:kelp_plant
setblock 337 52 -124 minecraft:tall_seagrass[half=lower]
setblock 338 52 -124 minecraft:kelp_plant
fill 339 52 -124 341 52 -124 minecraft:water[level=0]
fill 366 52 -124 367 52 -124 minecraft:water[level=0]
setblock 368 52 -124 minecraft:kelp_plant
fill 369 52 -124 370 52 -124 minecraft:water[level=0]
setblock 371 52 -124 minecraft:tall_seagrass[half=upper]
setblock 372 52 -124 minecraft:kelp_plant
fill 373 52 -124 375 52 -124 minecraft:water[level=0]
fill 376 52 -124 377 52 -124 minecraft:kelp_plant
fill 378 52 -124 383 52 -124 minecraft:water[level=0]
setblock 384 52 -124 minecraft:kelp_plant
fill 385 52 -124 391 52 -124 minecraft:water[level=0]
setblock 338 52 -125 minecraft:seagrass
fill 339 52 -125 340 52 -125 minecraft:water[level=0]
setblock 341 52 -125 minecraft:seagrass
fill 366 52 -125 381 52 -125 minecraft:water[level=0]
setblock 382 52 -125 minecraft:kelp_plant
fill 383 52 -125 391 52 -125 minecraft:water[level=0]
setblock 340 52 -126 minecraft:kelp_plant
setblock 366 52 -126 minecraft:water[level=0]
setblock 367 52 -126 minecraft:kelp_plant
fill 368 52 -126 371 52 -126 minecraft:water[level=0]
setblock 372 52 -126 minecraft:kelp_plant
fill 373 52 -126 374 52 -126 minecraft:water[level=0]
setblock 375 52 -126 minecraft:kelp_plant
setblock 376 52 -126 minecraft:water[level=0]
setblock 377 52 -126 minecraft:kelp_plant
fill 378 52 -126 391 52 -126 minecraft:water[level=0]
fill 328 51 -116 329 51 -116 minecraft:water[level=0]
setblock 330 51 -116 minecraft:kelp_plant
fill 331 51 -116 341 51 -116 minecraft:water[level=0]
setblock 342 51 -116 minecraft:kelp_plant
fill 343 51 -116 345 51 -116 minecraft:water[level=0]
setblock 346 51 -116 minecraft:kelp_plant
fill 376 51 -116 379 51 -116 minecraft:water[level=0]
setblock 380 51 -116 minecraft:kelp_plant
setblock 381 51 -116 minecraft:seagrass
fill 382 51 -116 386 51 -116 minecraft:water[level=0]
fill 328 51 -117 330 51 -117 minecraft:water[level=0]
setblock 331 51 -117 minecraft:kelp_plant
fill 332 51 -117 336 51 -117 minecraft:water[level=0]
setblock 337 51 -117 minecraft:kelp_plant
fill 338 51 -117 340 51 -117 minecraft:tall_seagrass[half=upper]
setblock 341 51 -117 minecraft:kelp_plant
setblock 342 51 -117 minecraft:tall_seagrass[half=upper]
setblock 343 51 -117 minecraft:water[level=0]
setblock 344 51 -117 minecraft:kelp_plant
setblock 345 51 -117 minecraft:water[level=0]
setblock 346 51 -117 minecraft:seagrass
setblock 375 51 -117 minecraft:seagrass
setblock 376 51 -117 minecraft:kelp_plant
fill 377 51 -117 380 51 -117 minecraft:water[level=0]
fill 381 51 -117 382 51 -117 minecraft:seagrass
setblock 383 51 -117 minecraft:kelp_plant
fill 384 51 -117 391 51 -117 minecraft:water[level=0]
fill 328 51 -118 331 51 -118 minecraft:water[level=0]
fill 332 51 -118 334 51 -118 minecraft:kelp_plant
setblock 335 51 -118 minecraft:water[level=0]
setblock 336 51 -118 minecraft:kelp_plant
setblock 337 51 -118 minecraft:water[level=0]
setblock 338 51 -118 minecraft:kelp_plant
fill 339 51 -118 340 51 -118 minecraft:water[level=0]
setblock 341 51 -118 minecraft:tall_seagrass[half=upper]
setblock 342 51 -118 minecraft:kelp_plant
setblock 343 51 -118 minecraft:tall_seagrass[half=upper]
fill 344 51 -118 345 51 -118 minecraft:water[level=0]
setblock 375 51 -118 minecraft:kelp_plant
setblock 376 51 -118 minecraft:water[level=0]
setblock 377 51 -118 minecraft:tall_seagrass[half=lower]
fill 378 51 -118 379 51 -118 minecraft:water[level=0]
setblock 380 51 -118 minecraft:tall_seagrass[half=lower]
setblock 381 51 -118 minecraft:water[level=0]
setblock 382 51 -118 minecraft:seagrass
setblock 383 51 -118 minecraft:water[level=0]
setblock 384 51 -118 minecraft:seagrass
setblock 385 51 -118 minecraft:water[level=0]
setblock 386 51 -118 minecraft:kelp_plant
fill 387 51 -118 389 51 -118 minecraft:water[level=0]
setblock 390 51 -118 minecraft:kelp_plant
setblock 391 51 -118 minecraft:water[level=0]
fill 328 51 -119 329 51 -119 minecraft:water[level=0]
setblock 334 51 -119 minecraft:water[level=0]
setblock 335 51 -119 minecraft:kelp_plant
setblock 336 51 -119 minecraft:water[level=0]
setblock 337 51 -119 minecraft:seagrass
fill 338 51 -119 339 51 -119 minecraft:water[level=0]
setblock 340 51 -119 minecraft:tall_seagrass[half=upper]
setblock 341 51 -119 minecraft:kelp_plant
fill 342 51 -119 343 51 -119 minecraft:water[level=0]
fill 344 51 -119 345 51 -119 minecraft:kelp_plant
setblock 375 51 -119 minecraft:water[level=0]
fill 376 51 -119 377 51 -119 minecraft:kelp_plant
fill 378 51 -119 379 51 -119 minecraft:water[level=0]
setblock 380 51 -119 minecraft:kelp_plant
setblock 381 51 -119 minecraft:water[level=0]
setblock 382 51 -119 minecraft:tall_seagrass[half=lower]
fill 383 51 -119 388 51 -119 minecraft:water[level=0]
setblock 389 51 -119 minecraft:kelp_plant
fill 390 51 -119 391 51 -119 minecraft:water[level=0]
setblock 335 51 -120 minecraft:water[level=0]
setblock 336 51 -120 minecraft:seagrass
setblock 337 51 -120 minecraft:water[level=0]
setblock 338 51 -120 minecraft:kelp_plant
setblock 339 51 -120 minecraft:tall_seagrass[half=upper]
fill 340 51 -120 342 51 -120 minecraft:water[level=0]
setblock 343 51 -120 minecraft:kelp_plant
fill 344 51 -120 345 51 -120 minecraft:water[level=0]
fill 374 51 -120 380 51 -120 minecraft:water[level=0]
setblock 381 51 -120 minecraft:seagrass
fill 382 51 -120 384 51 -120 minecraft:water[level=0]
setblock 385 51 -120 minecraft:kelp_plant
fill 386 51 -120 391 51 -120 minecraft:water[level=0]
fill 336 51 -121 339 51 -121 minecraft:water[level=0]
setblock 340 51 -121 minecraft:kelp_plant
fill 341 51 -121 342 51 -121 minecraft:water[level=0]
setblock 343 51 -121 minecraft:seagrass
fill 374 51 -121 378 51 -121 minecraft:water[level=0]
fill 379 51 -121 380 51 -121 minecraft:kelp_plant
setblock 381 51 -121 minecraft:water[level=0]
setblock 382 51 -121 minecraft:seagrass
fill 383 51 -121 384 51 -121 minecraft:water[level=0]
setblock 385 51 -121 minecraft:kelp_plant
setblock 386 51 -121 minecraft:water[level=0]
setblock 387 51 -121 minecraft:tall_seagrass[half=upper]
fill 388 51 -121 391 51 -121 minecraft:water[level=0]
fill 338 51 -122 340 51 -122 minecraft:water[level=0]
setblock 341 51 -122 minecraft:tall_seagrass[half=upper]
setblock 342 51 -122 minecraft:kelp_plant
setblock 373 51 -122 minecraft:kelp_plant
fill 374 51 -122 381 51 -122 minecraft:water[level=0]
setblock 382 51 -122 minecraft:kelp_plant
setblock 383 51 -122 minecraft:tall_seagrass[half=upper]
setblock 384 51 -122 minecraft:water[level=0]
setblock 385 51 -122 minecraft:kelp_plant
fill 386 51 -122 391 51 -122 minecraft:water[level=0]
fill 338 51 -123 341 51 -123 minecraft:water[level=0]
fill 372 51 -123 374 51 -123 minecraft:water[level=0]
setblock 375 51 -123 minecraft:kelp_plant
fill 376 51 -123 382 51 -123 minecraft:water[level=0]
setblock 383 51 -123 minecraft:kelp_plant
fill 384 51 -123 389 51 -123 minecraft:water[level=0]
fill 390 51 -123 391 51 -123 minecraft:kelp_plant
setblock 339 51 -124 minecraft:seagrass
setblock 340 51 -124 minecraft:tall_seagrass[half=upper]
setblock 341 51 -124 minecraft:water[level=0]
setblock 371 51 -124 minecraft:tall_seagrass[half=lower]
setblock 372 51 -124 minecraft:kelp_plant
fill 373 51 -124 374 51 -124 minecraft:water[level=0]
setblock 375 51 -124 minecraft:seagrass
fill 376 51 -124 377 51 -124 minecraft:kelp_plant
fill 378 51 -124 383 51 -124 minecraft:water[level=0]
setblock 384 51 -124 minecraft:kelp_plant
setblock 385 51 -124 minecraft:tall_seagrass[half=upper]
fill 386 51 -124 391 51 -124 minecraft:water[level=0]
setblock 340 51 -125 minecraft:seagrass
setblock 371 51 -125 minecraft:seagrass
fill 372 51 -125 375 51 -125 minecraft:water[level=0]
fill 376 51 -125 377 51 -125 minecraft:seagrass
fill 378 51 -125 381 51 -125 minecraft:water[level=0]
setblock 382 51 -125 minecraft:kelp_plant
fill 383 51 -125 387 51 -125 minecraft:water[level=0]
setblock 388 51 -125 minecraft:tall_seagrass[half=upper]
fill 389 51 -125 391 51 -125 minecraft:water[level=0]
setblock 371 51 -126 minecraft:water[level=0]
setblock 372 51 -126 minecraft:kelp_plant
setblock 373 51 -126 minecraft:seagrass
setblock 374 51 -126 minecraft:water[level=0]
setblock 375 51 -126 minecraft:kelp_plant
setblock 376 51 -126 minecraft:water[level=0]
setblock 377 51 -126 minecraft:kelp_plant
fill 378 51 -126 383 51 -126 minecraft:water[level=0]
setblock 384 51 -126 minecraft:tall_seagrass[half=upper]
fill 385 51 -126 391 51 -126 minecraft:water[level=0]
fill 328 50 -116 329 50 -116 minecraft:water[level=0]
setblock 330 50 -116 minecraft:kelp_plant
fill 331 50 -116 335 50 -116 minecraft:water[level=0]
fill 338 50 -116 340 50 -116 minecraft:water[level=0]
setblock 341 50 -116 minecraft:seagrass
setblock 342 50 -116 minecraft:kelp_plant
setblock 343 50 -116 minecraft:water[level=0]
setblock 344 50 -116 minecraft:seagrass
fill 372 50 -116 374 50 -116 minecraft:water[level=0]
setblock 385 50 -116 minecraft:seagrass
setblock 386 50 -116 minecraft:water[level=0]
fill 338 50 -117 340 50 -117 minecraft:tall_seagrass[half=lower]
setblock 341 50 -117 minecraft:kelp_plant
setblock 342 50 -117 minecraft:tall_seagrass[half=lower]
setblock 343 50 -117 minecraft:water[level=0]
setblock 344 50 -117 minecraft:kelp_plant
fill 372 50 -117 374 50 -117 minecraft:water[level=0]
setblock 385 50 -117 minecraft:seagrass
setblock 386 50 -117 minecraft:water[level=0]
setblock 387 50 -117 minecraft:tall_seagrass[half=upper]
fill 388 50 -117 391 50 -117 minecraft:water[level=0]
setblock 338 50 -118 minecraft:kelp_plant
fill 339 50 -118 340 50 -118 minecraft:water[level=0]
setblock 341 50 -118 minecraft:tall_seagrass[half=lower]
setblock 342 50 -118 minecraft:kelp_plant
setblock 343 50 -118 minecraft:tall_seagrass[half=lower]
setblock 344 50 -118 minecraft:water[level=0]
fill 373 50 -118 374 50 -118 minecraft:water[level=0]
setblock 375 50 -118 minecraft:kelp_plant
setblock 376 50 -118 minecraft:water[level=0]
setblock 385 50 -118 minecraft:water[level=0]
setblock 386 50 -118 minecraft:kelp_plant
fill 387 50 -118 389 50 -118 minecraft:water[level=0]
setblock 390 50 -118 minecraft:kelp_plant
setblock 391 50 -118 minecraft:water[level=0]
setblock 338 50 -119 minecraft:water[level=0]
setblock 339 50 -119 minecraft:seagrass
setblock 340 50 -119 minecraft:tall_seagrass[half=lower]
setblock 341 50 -119 minecraft:kelp_plant
fill 342 50 -119 343 50 -119 minecraft:water[level=0]
setblock 344 50 -119 minecraft:kelp_plant
fill 373 50 -119 375 50 -119 minecraft:water[level=0]
fill 376 50 -119 377 50 -119 minecraft:kelp_plant
setblock 378 50 -119 minecraft:water[level=0]
setblock 384 50 -119 minecraft:seagrass
fill 385 50 -119 388 50 -119 minecraft:water[level=0]
setblock 389 50 -119 minecraft:kelp_plant
setblock 390 50 -119 minecraft:tall_seagrass[half=upper]
setblock 391 50 -119 minecraft:water[level=0]
setblock 338 50 -120 minecraft:kelp_plant
setblock 339 50 -120 minecraft:tall_seagrass[half=lower]
setblock 340 50 -120 minecraft:water[level=0]
fill 341 50 -120 342 50 -120 minecraft:seagrass
setblock 343 50 -120 minecraft:kelp_plant
fill 374 50 -120 378 50 -120 minecraft:water[level=0]
setblock 379 50 -120 minecraft:tall_seagrass[half=upper]
setblock 384 50 -120 minecraft:water[level=0]
setblock 385 50 -120 minecraft:kelp_plant
fill 386 50 -120 387 50 -120 minecraft:seagrass
setblock 388 50 -120 minecraft:water[level=0]
setblock 389 50 -120 minecraft:tall_seagrass[half=upper]
fill 390 50 -120 391 50 -120 minecraft:water[level=0]
setblock 339 50 -121 minecraft:seagrass
setblock 340 50 -121 minecraft:kelp_plant
setblock 341 50 -121 minecraft:water[level=0]
setblock 342 50 -121 minecraft:seagrass
fill 374 50 -121 378 50 -121 minecraft:water[level=0]
fill 379 50 -121 380 50 -121 minecraft:kelp_plant
setblock 381 50 -121 minecraft:water[level=0]
fill 383 50 -121 384 50 -121 minecraft:seagrass
setblock 385 50 -121 minecraft:kelp_plant
setblock 386 50 -121 minecraft:seagrass
setblock 387 50 -121 minecraft:tall_seagrass[half=lower]
setblock 388 50 -121 minecraft:seagrass
setblock 389 50 -121 minecraft:tall_seagrass[half=upper]
fill 390 50 -121 391 50 -121 minecraft:water[level=0]
setblock 339 50 -122 minecraft:water[level=0]
setblock 340 50 -122 minecraft:seagrass
setblock 341 50 -122 minecraft:tall_seagrass[half=lower]
fill 375 50 -122 379 50 -122 minecraft:water[level=0]
setblock 380 50 -122 minecraft:tall_seagrass[half=upper]
setblock 381 50 -122 minecraft:water[level=0]
setblock 382 50 -122 minecraft:kelp_plant
setblock 383 50 -122 minecraft:tall_seagrass[half=lower]
setblock 384 50 -122 minecraft:water[level=0]
setblock 385 50 -122 minecraft:kelp_plant
setblock 386 50 -122 minecraft:water[level=0]
fill 387 50 -122 388 50 -122 minecraft:seagrass
fill 389 50 -122 391 50 -122 minecraft:water[level=0]
setblock 340 50 -123 minecraft:seagrass
fill 376 50 -123 377 50 -123 minecraft:water[level=0]
setblock 378 50 -123 minecraft:tall_seagrass[half=upper]
fill 379 50 -123 382 50 -123 minecraft:water[level=0]
setblock 383 50 -123 minecraft:kelp_plant
fill 384 50 -123 389 50 -123 minecraft:water[level=0]
fill 390 50 -123 391 50 -123 minecraft:kelp_plant
setblock 340 50 -124 minecraft:tall_seagrass[half=lower]
fill 378 50 -124 383 50 -124 minecraft:water[level=0]
setblock 384 50 -124 minecraft:kelp_plant
setblock 385 50 -124 minecraft:tall_seagrass[half=lower]
fill 386 50 -124 391 50 -124 minecraft:water[level=0]
setblock 378 50 -125 minecraft:seagrass
fill 379 50 -125 381 50 -125 minecraft:water[level=0]
setblock 382 50 -125 minecraft:kelp_plant
fill 383 50 -125 387 50 -125 minecraft:water[level=0]
setblock 388 50 -125 minecraft:tall_seagrass[half=lower]
fill 389 50 -125 391 50 -125 minecraft:water[level=0]
setblock 377 50 -126 minecraft:kelp_plant
fill 378 50 -126 382 50 -126 minecraft:water[level=0]
setblock 383 50 -126 minecraft:seagrass
setblock 384 50 -126 minecraft:tall_seagrass[half=lower]
setblock 385 50 -126 minecraft:water[level=0]
setblock 386 50 -126 minecraft:seagrass
fill 387 50 -126 389 50 -126 minecraft:water[level=0]
setblock 390 50 -126 minecraft:tall_seagrass[half=upper]
setblock 391 50 -126 minecraft:water[level=0]
fill 371 49 -116 375 49 -116 minecraft:water[level=0]
fill 372 49 -117 375 49 -117 minecraft:water[level=0]
setblock 387 49 -117 minecraft:tall_seagrass[half=lower]
fill 388 49 -117 391 49 -117 minecraft:water[level=0]
fill 372 49 -118 374 49 -118 minecraft:water[level=0]
setblock 375 49 -118 minecraft:kelp_plant
setblock 376 49 -118 minecraft:water[level=0]
fill 387 49 -118 389 49 -118 minecraft:water[level=0]
setblock 390 49 -118 minecraft:kelp_plant
setblock 391 49 -118 minecraft:water[level=0]
fill 372 49 -119 375 49 -119 minecraft:water[level=0]
fill 376 49 -119 377 49 -119 minecraft:kelp_plant
setblock 378 49 -119 minecraft:water[level=0]
setblock 388 49 -119 minecraft:seagrass
setblock 389 49 -119 minecraft:kelp_plant
setblock 390 49 -119 minecraft:tall_seagrass[half=lower]
setblock 391 49 -119 minecraft:water[level=0]
setblock 340 49 -120 minecraft:seagrass
fill 373 49 -120 378 49 -120 minecraft:water[level=0]
setblock 379 49 -120 minecraft:tall_seagrass[half=lower]
setblock 389 49 -120 minecraft:tall_seagrass[half=lower]
setblock 390 49 -120 minecraft:seagrass
setblock 391 49 -120 minecraft:water[level=0]
setblock 340 49 -121 minecraft:kelp_plant
fill 374 49 -121 378 49 -121 minecraft:water[level=0]
setblock 379 49 -121 minecraft:kelp_plant
setblock 389 49 -121 minecraft:tall_seagrass[half=lower]
setblock 390 49 -121 minecraft:seagrass
setblock 391 49 -121 minecraft:water[level=0]
fill 375 49 -122 379 49 -122 minecraft:water[level=0]
setblock 380 49 -122 minecraft:tall_seagrass[half=lower]
setblock 381 49 -122 minecraft:water[level=0]
fill 389 49 -122 391 49 -122 minecraft:water[level=0]
fill 376 49 -123 377 49 -123 minecraft:water[level=0]
setblock 378 49 -123 minecraft:tall_seagrass[half=lower]
fill 379 49 -123 380 49 -123 minecraft:water[level=0]
setblock 381 49 -123 minecraft:seagrass
setblock 382 49 -123 minecraft:water[level=0]
setblock 389 49 -123 minecraft:water[level=0]
fill 390 49 -123 391 49 -123 minecraft:kelp_plant
fill 379 49 -124 380 49 -124 minecraft:water[level=0]
setblock 381 49 -124 minecraft:seagrass
setblock 382 49 -124 minecraft:water[level=0]
setblock 389 49 -124 minecraft:seagrass
fill 390 49 -124 391 49 -124 minecraft:water[level=0]
fill 379 49 -125 380 49 -125 minecraft:water[level=0]
setblock 381 49 -125 minecraft:seagrass
setblock 382 49 -125 minecraft:kelp_plant
fill 389 49 -125 391 49 -125 minecraft:water[level=0]
setblock 389 49 -126 minecraft:water[level=0]
setblock 390 49 -126 minecraft:tall_seagrass[half=lower]
setblock 391 49 -126 minecraft:seagrass
fill 371 48 -116 375 48 -116 minecraft:water[level=0]
fill 372 48 -117 375 48 -117 minecraft:water[level=0]
setblock 389 48 -117 minecraft:seagrass
setblock 390 48 -117 minecraft:water[level=0]
setblock 391 48 -117 minecraft:seagrass
fill 372 48 -118 374 48 -118 minecraft:water[level=0]
setblock 375 48 -118 minecraft:kelp_plant
setblock 376 48 -118 minecraft:water[level=0]
setblock 390 48 -118 minecraft:kelp_plant
setblock 391 48 -118 minecraft:water[level=0]
fill 372 48 -119 375 48 -119 minecraft:water[level=0]
fill 376 48 -119 377 48 -119 minecraft:kelp_plant
setblock 391 48 -119 minecraft:seagrass
fill 373 48 -120 377 48 -120 minecraft:water[level=0]
setblock 378 48 -120 minecraft:seagrass
setblock 391 48 -120 minecraft:water[level=0]
fill 374 48 -121 375 48 -121 minecraft:water[level=0]
setblock 376 48 -121 minecraft:seagrass
fill 377 48 -121 378 48 -121 minecraft:water[level=0]
setblock 391 48 -121 minecraft:water[level=0]
setblock 375 48 -122 minecraft:seagrass
fill 376 48 -122 378 48 -122 minecraft:water[level=0]
setblock 391 48 -122 minecraft:seagrass
setblock 391 48 -123 minecraft:kelp_plant
setblock 391 48 -124 minecraft:seagrass
fill 372 47 -116 375 47 -116 minecraft:water[level=0]
fill 372 47 -117 375 47 -117 minecraft:water[level=0]
fill 373 47 -118 374 47 -118 minecraft:water[level=0]
setblock 375 47 -118 minecraft:kelp_plant
fill 373 47 -119 375 47 -119 minecraft:water[level=0]
fill 373 47 -120 375 47 -120 minecraft:water[level=0]
setblock 383 45 -122 minecraft:water[level=0]
fill 383 45 -123 384 45 -123 minecraft:water[level=0]
fill 383 45 -124 384 45 -124 minecraft:water[level=0]
setblock 386 45 -126 minecraft:water[level=0]
forceload remove 328 -126 391 -63
tellraw @a {"text":"Campus zurueck a41 fertig.","color":"green"}
