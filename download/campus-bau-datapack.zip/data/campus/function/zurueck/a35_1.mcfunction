setblock 393 66 -127 minecraft:air
fill 395 66 -127 396 66 -127 minecraft:air
fill 398 66 -127 400 66 -127 minecraft:air
setblock 393 66 -128 minecraft:air
fill 395 66 -128 399 66 -128 minecraft:air
setblock 402 66 -128 minecraft:air
setblock 392 66 -129 minecraft:air
setblock 395 66 -129 minecraft:air
setblock 400 66 -129 minecraft:air
fill 392 66 -130 396 66 -130 minecraft:air
setblock 398 66 -130 minecraft:air
setblock 400 66 -130 minecraft:air
setblock 404 66 -130 minecraft:air
setblock 392 66 -131 minecraft:air
fill 394 66 -131 395 66 -131 minecraft:air
setblock 397 66 -131 minecraft:air
fill 399 66 -131 403 66 -131 minecraft:air
fill 405 66 -131 406 66 -131 minecraft:air
fill 392 66 -132 396 66 -132 minecraft:air
fill 399 66 -132 400 66 -132 minecraft:air
setblock 402 66 -132 minecraft:air
setblock 404 66 -132 minecraft:air
setblock 407 66 -132 minecraft:air
setblock 393 66 -133 minecraft:air
setblock 395 66 -133 minecraft:air
fill 397 66 -133 402 66 -133 minecraft:air
fill 405 66 -133 407 66 -133 minecraft:air
fill 393 66 -134 394 66 -134 minecraft:air
fill 397 66 -134 398 66 -134 minecraft:air
fill 400 66 -134 401 66 -134 minecraft:air
setblock 403 66 -134 minecraft:air
setblock 393 66 -135 minecraft:air
setblock 395 66 -135 minecraft:air
fill 398 66 -135 400 66 -135 minecraft:air
fill 406 66 -135 407 66 -135 minecraft:air
setblock 409 66 -135 minecraft:air
fill 392 66 -136 394 66 -136 minecraft:air
fill 397 66 -136 398 66 -136 minecraft:air
fill 401 66 -136 404 66 -136 minecraft:air
setblock 407 66 -136 minecraft:air
fill 409 66 -136 410 66 -136 minecraft:air
setblock 392 66 -137 minecraft:air
fill 394 66 -137 397 66 -137 minecraft:air
setblock 399 66 -137 minecraft:air
setblock 402 66 -137 minecraft:air
setblock 406 66 -137 minecraft:air
setblock 408 66 -137 minecraft:air
setblock 394 66 -138 minecraft:air
fill 396 66 -138 397 66 -138 minecraft:air
setblock 400 66 -138 minecraft:air
fill 402 66 -138 404 66 -138 minecraft:air
fill 406 66 -138 408 66 -138 minecraft:air
fill 410 66 -138 411 66 -138 minecraft:air
setblock 393 66 -139 minecraft:air
fill 395 66 -139 396 66 -139 minecraft:air
setblock 399 66 -139 minecraft:air
setblock 403 66 -139 minecraft:air
fill 405 66 -139 407 66 -139 minecraft:air
fill 409 66 -139 410 66 -139 minecraft:air
setblock 392 66 -140 minecraft:air
setblock 395 66 -140 minecraft:air
fill 398 66 -140 400 66 -140 minecraft:air
fill 402 66 -140 407 66 -140 minecraft:air
fill 409 66 -140 411 66 -140 minecraft:air
setblock 395 66 -141 minecraft:air
fill 400 66 -141 401 66 -141 minecraft:air
fill 404 66 -141 405 66 -141 minecraft:air
setblock 410 66 -141 minecraft:air
fill 393 66 -142 397 66 -142 minecraft:air
fill 399 66 -142 403 66 -142 minecraft:air
setblock 407 66 -142 minecraft:air
setblock 410 66 -142 minecraft:air
setblock 412 66 -142 minecraft:air
fill 395 66 -143 402 66 -143 minecraft:air
setblock 405 66 -143 minecraft:air
setblock 407 66 -143 minecraft:air
setblock 413 66 -143 minecraft:air
setblock 394 66 -144 minecraft:air
fill 396 66 -144 400 66 -144 minecraft:air
setblock 402 66 -144 minecraft:air
setblock 405 66 -144 minecraft:air
fill 407 66 -144 408 66 -144 minecraft:air
setblock 410 66 -144 minecraft:air
setblock 412 66 -144 minecraft:air
setblock 393 66 -145 minecraft:air
setblock 395 66 -145 minecraft:air
setblock 399 66 -145 minecraft:air
setblock 401 66 -145 minecraft:air
setblock 405 66 -145 minecraft:air
setblock 407 66 -145 minecraft:air
fill 409 66 -145 410 66 -145 minecraft:air
fill 412 66 -145 414 66 -145 minecraft:air
fill 392 66 -146 394 66 -146 minecraft:air
fill 396 66 -146 398 66 -146 minecraft:air
setblock 400 66 -146 minecraft:air
setblock 402 66 -146 minecraft:air
fill 405 66 -146 406 66 -146 minecraft:air
setblock 409 66 -146 minecraft:air
fill 412 66 -146 413 66 -146 minecraft:air
fill 392 66 -147 396 66 -147 minecraft:air
setblock 401 66 -147 minecraft:air
fill 403 66 -147 405 66 -147 minecraft:air
setblock 408 66 -147 minecraft:air
setblock 410 66 -147 minecraft:air
fill 412 66 -147 414 66 -147 minecraft:air
setblock 392 66 -148 minecraft:air
setblock 396 66 -148 minecraft:air
setblock 399 66 -148 minecraft:air
setblock 401 66 -148 minecraft:air
setblock 403 66 -148 minecraft:air
fill 405 66 -148 406 66 -148 minecraft:air
fill 408 66 -148 409 66 -148 minecraft:air
fill 411 66 -148 414 66 -148 minecraft:air
setblock 393 66 -149 minecraft:air
setblock 395 66 -149 minecraft:air
setblock 397 66 -149 minecraft:air
setblock 401 66 -149 minecraft:air
setblock 403 66 -149 minecraft:air
setblock 405 66 -149 minecraft:air
setblock 408 66 -149 minecraft:air
fill 396 66 -150 398 66 -150 minecraft:air
setblock 405 66 -150 minecraft:air
setblock 408 66 -150 minecraft:air
fill 412 66 -150 413 66 -150 minecraft:air
setblock 395 66 -151 minecraft:air
fill 397 66 -151 398 66 -151 minecraft:air
setblock 400 66 -151 minecraft:air
setblock 402 66 -151 minecraft:air
setblock 406 66 -151 minecraft:air
fill 409 66 -151 411 66 -151 minecraft:air
setblock 413 66 -151 minecraft:air
setblock 392 66 -152 minecraft:air
fill 395 66 -152 396 66 -152 minecraft:air
setblock 399 66 -152 minecraft:air
fill 406 66 -152 407 66 -152 minecraft:air
fill 409 66 -152 411 66 -152 minecraft:air
setblock 413 66 -152 minecraft:air
setblock 415 66 -152 minecraft:air
setblock 392 66 -153 minecraft:air
fill 395 66 -153 397 66 -153 minecraft:air
setblock 399 66 -153 minecraft:air
fill 401 66 -153 405 66 -153 minecraft:air
setblock 407 66 -153 minecraft:air
fill 412 66 -153 414 66 -153 minecraft:air
setblock 392 66 -154 minecraft:air
setblock 394 66 -154 minecraft:air
setblock 396 66 -154 minecraft:air
setblock 400 66 -154 minecraft:air
fill 403 66 -154 412 66 -154 minecraft:air
fill 414 66 -154 415 66 -154 minecraft:air
fill 392 66 -155 393 66 -155 minecraft:air
setblock 399 66 -155 minecraft:air
setblock 402 66 -155 minecraft:air
setblock 405 66 -155 minecraft:air
fill 410 66 -155 412 66 -155 minecraft:air
setblock 414 66 -155 minecraft:air
setblock 392 66 -156 minecraft:air
setblock 394 66 -156 minecraft:air
fill 396 66 -156 397 66 -156 minecraft:air
fill 400 66 -156 401 66 -156 minecraft:air
setblock 405 66 -156 minecraft:air
setblock 408 66 -156 minecraft:air
fill 410 66 -156 414 66 -156 minecraft:air
fill 392 66 -157 396 66 -157 minecraft:air
setblock 399 66 -157 minecraft:air
fill 403 66 -157 405 66 -157 minecraft:air
setblock 407 66 -157 minecraft:air
fill 414 66 -157 415 66 -157 minecraft:air
setblock 392 66 -158 minecraft:air
setblock 394 66 -158 minecraft:air
setblock 396 66 -158 minecraft:air
setblock 402 66 -158 minecraft:air
fill 404 66 -158 405 66 -158 minecraft:air
fill 409 66 -158 411 66 -158 minecraft:air
setblock 413 66 -158 minecraft:air
setblock 415 66 -158 minecraft:air
fill 396 66 -159 397 66 -159 minecraft:air
setblock 400 66 -159 minecraft:air
setblock 402 66 -159 minecraft:air
fill 404 66 -159 406 66 -159 minecraft:air
fill 410 66 -159 415 66 -159 minecraft:air
fill 394 66 -160 397 66 -160 minecraft:air
fill 402 66 -160 405 66 -160 minecraft:air
fill 411 66 -160 412 66 -160 minecraft:air
fill 414 66 -160 415 66 -160 minecraft:air
setblock 392 66 -161 minecraft:air
fill 395 66 -161 397 66 -161 minecraft:air
fill 402 66 -161 403 66 -161 minecraft:air
setblock 406 66 -161 minecraft:air
fill 408 66 -161 411 66 -161 minecraft:air
setblock 415 66 -161 minecraft:air
fill 392 66 -162 395 66 -162 minecraft:air
fill 400 66 -162 404 66 -162 minecraft:air
setblock 406 66 -162 minecraft:air
fill 409 66 -162 410 66 -162 minecraft:air
fill 412 66 -162 415 66 -162 minecraft:air
fill 392 66 -163 393 66 -163 minecraft:air
setblock 395 66 -163 minecraft:air
setblock 398 66 -163 minecraft:air
setblock 401 66 -163 minecraft:air
fill 403 66 -163 406 66 -163 minecraft:air
fill 408 66 -163 409 66 -163 minecraft:air
setblock 411 66 -163 minecraft:air
fill 413 66 -163 415 66 -163 minecraft:air
fill 393 66 -164 394 66 -164 minecraft:air
setblock 396 66 -164 minecraft:air
fill 398 66 -164 400 66 -164 minecraft:air
setblock 402 66 -164 minecraft:air
fill 404 66 -164 406 66 -164 minecraft:air
fill 408 66 -164 410 66 -164 minecraft:air
fill 412 66 -164 413 66 -164 minecraft:air
setblock 415 66 -164 minecraft:air
fill 394 66 -165 395 66 -165 minecraft:air
fill 397 66 -165 398 66 -165 minecraft:air
fill 400 66 -165 401 66 -165 minecraft:air
setblock 403 66 -165 minecraft:air
fill 405 66 -165 406 66 -165 minecraft:air
fill 408 66 -165 411 66 -165 minecraft:air
setblock 413 66 -165 minecraft:air
setblock 415 66 -165 minecraft:air
setblock 392 66 -166 minecraft:air
fill 395 66 -166 396 66 -166 minecraft:air
fill 401 66 -166 407 66 -166 minecraft:air
fill 409 66 -166 410 66 -166 minecraft:air
fill 412 66 -166 413 66 -166 minecraft:air
fill 395 66 -167 398 66 -167 minecraft:air
fill 400 66 -167 402 66 -167 minecraft:air
setblock 408 66 -167 minecraft:air
setblock 410 66 -167 minecraft:air
fill 412 66 -167 415 66 -167 minecraft:air
setblock 392 66 -168 minecraft:air
fill 395 66 -168 398 66 -168 minecraft:air
fill 401 66 -168 405 66 -168 minecraft:air
fill 409 66 -168 413 66 -168 minecraft:air
setblock 415 66 -168 minecraft:air
fill 394 66 -169 402 66 -169 minecraft:air
setblock 404 66 -169 minecraft:air
fill 406 66 -169 407 66 -169 minecraft:air
fill 410 66 -169 412 66 -169 minecraft:air
fill 414 66 -169 415 66 -169 minecraft:air
setblock 392 66 -170 minecraft:air
setblock 394 66 -170 minecraft:air
setblock 397 66 -170 minecraft:air
fill 400 66 -170 402 66 -170 minecraft:air
fill 404 66 -170 407 66 -170 minecraft:air
setblock 409 66 -170 minecraft:air
fill 414 66 -170 415 66 -170 minecraft:air
setblock 395 66 -171 minecraft:air
fill 398 66 -171 399 66 -171 minecraft:air
fill 401 66 -171 402 66 -171 minecraft:air
setblock 407 66 -171 minecraft:air
fill 411 66 -171 415 66 -171 minecraft:air
fill 392 66 -172 393 66 -172 minecraft:air
fill 395 66 -172 399 66 -172 minecraft:air
fill 401 66 -172 402 66 -172 minecraft:air
setblock 404 66 -172 minecraft:air
fill 408 66 -172 409 66 -172 minecraft:air
fill 411 66 -172 412 66 -172 minecraft:air
fill 392 66 -173 396 66 -173 minecraft:air
fill 398 66 -173 399 66 -173 minecraft:air
fill 401 66 -173 402 66 -173 minecraft:air
fill 404 66 -173 408 66 -173 minecraft:air
fill 414 66 -173 415 66 -173 minecraft:air
fill 393 66 -174 394 66 -174 minecraft:air
setblock 396 66 -174 minecraft:air
setblock 398 66 -174 minecraft:air
setblock 401 66 -174 minecraft:air
setblock 403 66 -174 minecraft:air
setblock 406 66 -174 minecraft:air
fill 408 66 -174 412 66 -174 minecraft:air
fill 414 66 -174 415 66 -174 minecraft:air
setblock 392 66 -175 minecraft:air
setblock 394 66 -175 minecraft:air
fill 396 66 -175 397 66 -175 minecraft:air
fill 399 66 -175 400 66 -175 minecraft:air
fill 405 66 -175 406 66 -175 minecraft:air
setblock 408 66 -175 minecraft:air
fill 411 66 -175 412 66 -175 minecraft:air
setblock 394 66 -176 minecraft:air
fill 396 66 -176 400 66 -176 minecraft:air
setblock 407 66 -176 minecraft:air
fill 412 66 -176 413 66 -176 minecraft:air
fill 392 66 -177 393 66 -177 minecraft:air
fill 397 66 -177 398 66 -177 minecraft:air
setblock 402 66 -177 minecraft:air
setblock 407 66 -177 minecraft:air
fill 412 66 -177 413 66 -177 minecraft:air
setblock 415 66 -177 minecraft:air
setblock 394 66 -178 minecraft:air
fill 396 66 -178 398 66 -178 minecraft:air
fill 403 66 -178 406 66 -178 minecraft:air
setblock 408 66 -178 minecraft:air
fill 410 66 -178 414 66 -178 minecraft:air
fill 392 66 -179 393 66 -179 minecraft:air
fill 395 66 -179 396 66 -179 minecraft:air
fill 399 66 -179 400 66 -179 minecraft:air
setblock 405 66 -179 minecraft:air
fill 410 66 -179 411 66 -179 minecraft:air
fill 413 66 -179 414 66 -179 minecraft:air
fill 393 66 -180 396 66 -180 minecraft:air
fill 398 66 -180 399 66 -180 minecraft:air
setblock 401 66 -180 minecraft:air
fill 404 66 -180 406 66 -180 minecraft:air
setblock 410 66 -180 minecraft:air
setblock 412 66 -180 minecraft:air
fill 414 66 -180 415 66 -180 minecraft:air
setblock 392 66 -181 minecraft:air
fill 394 66 -181 397 66 -181 minecraft:air
fill 401 66 -181 405 66 -181 minecraft:air
fill 408 66 -181 411 66 -181 minecraft:air
fill 414 66 -181 415 66 -181 minecraft:air
fill 393 66 -182 394 66 -182 minecraft:air
setblock 396 66 -182 minecraft:air
setblock 398 66 -182 minecraft:air
setblock 400 66 -182 minecraft:air
fill 404 66 -182 410 66 -182 minecraft:air
setblock 415 66 -182 minecraft:air
setblock 392 66 -183 minecraft:air
fill 395 66 -183 396 66 -183 minecraft:air
fill 398 66 -183 399 66 -183 minecraft:air
fill 403 66 -183 404 66 -183 minecraft:air
fill 408 66 -183 411 66 -183 minecraft:air
setblock 413 66 -183 minecraft:air
setblock 415 66 -183 minecraft:air
setblock 392 66 -184 minecraft:air
setblock 397 66 -184 minecraft:air
fill 401 66 -184 402 66 -184 minecraft:air
setblock 404 66 -184 minecraft:air
setblock 408 66 -184 minecraft:air
setblock 410 66 -184 minecraft:air
fill 412 66 -184 415 66 -184 minecraft:air
setblock 392 66 -185 minecraft:air
fill 394 66 -185 395 66 -185 minecraft:air
fill 399 66 -185 402 66 -185 minecraft:air
fill 404 66 -185 405 66 -185 minecraft:air
fill 408 66 -185 409 66 -185 minecraft:air
setblock 412 66 -185 minecraft:air
setblock 414 66 -185 minecraft:air
setblock 392 66 -186 minecraft:air
fill 395 66 -186 397 66 -186 minecraft:air
fill 399 66 -186 400 66 -186 minecraft:air
fill 402 66 -186 403 66 -186 minecraft:air
setblock 405 66 -186 minecraft:air
fill 407 66 -186 408 66 -186 minecraft:air
setblock 411 66 -186 minecraft:air
setblock 413 66 -186 minecraft:air
setblock 415 66 -186 minecraft:air
fill 393 66 -187 396 66 -187 minecraft:air
fill 398 66 -187 399 66 -187 minecraft:air
setblock 403 66 -187 minecraft:air
fill 406 66 -187 407 66 -187 minecraft:air
setblock 409 66 -187 minecraft:air
fill 412 66 -187 413 66 -187 minecraft:air
setblock 415 66 -187 minecraft:air
setblock 392 66 -188 minecraft:air
fill 395 66 -188 396 66 -188 minecraft:air
setblock 400 66 -188 minecraft:air
setblock 403 66 -188 minecraft:air
fill 406 66 -188 407 66 -188 minecraft:air
fill 411 66 -188 414 66 -188 minecraft:air
setblock 393 66 -189 minecraft:air
setblock 396 66 -189 minecraft:air
fill 398 66 -189 400 66 -189 minecraft:air
setblock 404 66 -189 minecraft:air
setblock 408 66 -189 minecraft:air
fill 411 66 -189 414 66 -189 minecraft:air
setblock 392 66 -190 minecraft:air
setblock 394 66 -190 minecraft:air
setblock 396 66 -190 minecraft:air
fill 402 66 -190 404 66 -190 minecraft:air
setblock 407 66 -190 minecraft:air
setblock 410 66 -190 minecraft:air
setblock 413 66 -190 minecraft:air
fill 392 65 -127 411 65 -127 minecraft:air
fill 392 65 -128 412 65 -128 minecraft:air
fill 392 65 -129 413 65 -129 minecraft:air
fill 392 65 -130 414 65 -130 minecraft:air
fill 392 65 -131 415 65 -131 minecraft:air
fill 392 65 -132 415 65 -132 minecraft:air
fill 392 65 -133 416 65 -133 minecraft:air
fill 392 65 -134 417 65 -134 minecraft:air
fill 392 65 -135 417 65 -135 minecraft:air
fill 392 65 -136 418 65 -136 minecraft:air
fill 392 65 -137 418 65 -137 minecraft:air
fill 392 65 -138 419 65 -138 minecraft:air
fill 392 65 -139 419 65 -139 minecraft:air
fill 392 65 -140 419 65 -140 minecraft:air
fill 392 65 -141 420 65 -141 minecraft:air
fill 392 65 -142 420 65 -142 minecraft:air
fill 392 65 -143 420 65 -143 minecraft:air
fill 392 65 -144 421 65 -144 minecraft:air
fill 392 65 -145 421 65 -145 minecraft:air
fill 392 65 -146 421 65 -146 minecraft:air
fill 392 65 -147 421 65 -147 minecraft:air
fill 392 65 -148 421 65 -148 minecraft:air
fill 392 65 -149 421 65 -149 minecraft:air
fill 392 65 -150 421 65 -150 minecraft:air
fill 392 65 -151 421 65 -151 minecraft:air
fill 392 65 -152 422 65 -152 minecraft:air
fill 392 65 -153 422 65 -153 minecraft:air
fill 392 65 -154 422 65 -154 minecraft:air
fill 392 65 -155 422 65 -155 minecraft:air
fill 392 65 -156 422 65 -156 minecraft:air
fill 392 65 -157 422 65 -157 minecraft:air
fill 392 65 -158 422 65 -158 minecraft:air
fill 392 65 -159 422 65 -159 minecraft:air
fill 392 65 -160 422 65 -160 minecraft:air
fill 392 65 -161 422 65 -161 minecraft:air
fill 392 65 -162 422 65 -162 minecraft:air
fill 392 65 -163 422 65 -163 minecraft:air
fill 392 65 -164 422 65 -164 minecraft:air
fill 392 65 -165 422 65 -165 minecraft:air
fill 392 65 -166 422 65 -166 minecraft:air
fill 392 65 -167 422 65 -167 minecraft:air
fill 392 65 -168 422 65 -168 minecraft:air
fill 392 65 -169 422 65 -169 minecraft:air
fill 392 65 -170 412 65 -170 minecraft:air
fill 414 65 -170 422 65 -170 minecraft:air
fill 392 65 -171 422 65 -171 minecraft:air
fill 392 65 -172 422 65 -172 minecraft:air
fill 392 65 -173 422 65 -173 minecraft:air
fill 392 65 -174 401 65 -174 minecraft:air
fill 403 65 -174 422 65 -174 minecraft:air
fill 392 65 -175 422 65 -175 minecraft:air
fill 392 65 -176 422 65 -176 minecraft:air
fill 392 65 -177 422 65 -177 minecraft:air
fill 392 65 -178 422 65 -178 minecraft:air
fill 392 65 -179 422 65 -179 minecraft:air
fill 392 65 -180 422 65 -180 minecraft:air
fill 392 65 -181 422 65 -181 minecraft:air
fill 392 65 -182 422 65 -182 minecraft:air
fill 392 65 -183 422 65 -183 minecraft:air
fill 392 65 -184 422 65 -184 minecraft:air
fill 392 65 -185 422 65 -185 minecraft:air
fill 392 65 -186 422 65 -186 minecraft:air
fill 392 65 -187 422 65 -187 minecraft:air
fill 392 65 -188 404 65 -188 minecraft:air
fill 406 65 -188 422 65 -188 minecraft:air
fill 392 65 -189 422 65 -189 minecraft:air
fill 392 65 -190 422 65 -190 minecraft:air
fill 392 64 -127 411 64 -127 minecraft:air
fill 392 64 -128 412 64 -128 minecraft:air
fill 392 64 -129 413 64 -129 minecraft:air
fill 392 64 -130 414 64 -130 minecraft:air
fill 392 64 -131 415 64 -131 minecraft:air
fill 392 64 -132 415 64 -132 minecraft:air
fill 392 64 -133 416 64 -133 minecraft:air
fill 392 64 -134 417 64 -134 minecraft:air
fill 392 64 -135 417 64 -135 minecraft:air
fill 392 64 -136 418 64 -136 minecraft:air
fill 392 64 -137 418 64 -137 minecraft:air
fill 392 64 -138 419 64 -138 minecraft:air
fill 392 64 -139 419 64 -139 minecraft:air
fill 392 64 -140 419 64 -140 minecraft:air
fill 392 64 -141 420 64 -141 minecraft:air
fill 392 64 -142 420 64 -142 minecraft:air
fill 392 64 -143 420 64 -143 minecraft:air
fill 392 64 -144 421 64 -144 minecraft:air
fill 392 64 -145 421 64 -145 minecraft:air
fill 392 64 -146 421 64 -146 minecraft:air
fill 392 64 -147 421 64 -147 minecraft:air
fill 392 64 -148 421 64 -148 minecraft:air
fill 392 64 -149 421 64 -149 minecraft:air
fill 392 64 -150 421 64 -150 minecraft:air
fill 392 64 -151 421 64 -151 minecraft:air
fill 392 64 -152 422 64 -152 minecraft:air
fill 392 64 -153 422 64 -153 minecraft:air
fill 392 64 -154 422 64 -154 minecraft:air
fill 392 64 -155 422 64 -155 minecraft:air
fill 392 64 -156 422 64 -156 minecraft:air
fill 392 64 -157 422 64 -157 minecraft:air
fill 392 64 -158 422 64 -158 minecraft:air
fill 392 64 -159 422 64 -159 minecraft:air
fill 392 64 -160 422 64 -160 minecraft:air
fill 392 64 -161 422 64 -161 minecraft:air
fill 392 64 -162 422 64 -162 minecraft:air
fill 392 64 -163 422 64 -163 minecraft:air
fill 392 64 -164 422 64 -164 minecraft:air
fill 392 64 -165 422 64 -165 minecraft:air
fill 392 64 -166 422 64 -166 minecraft:air
fill 392 64 -167 422 64 -167 minecraft:air
fill 392 64 -168 422 64 -168 minecraft:air
fill 392 64 -169 422 64 -169 minecraft:air
fill 392 64 -170 412 64 -170 minecraft:air
fill 414 64 -170 422 64 -170 minecraft:air
fill 392 64 -171 422 64 -171 minecraft:air
fill 392 64 -172 422 64 -172 minecraft:air
fill 392 64 -173 422 64 -173 minecraft:air
fill 392 64 -174 401 64 -174 minecraft:air
fill 403 64 -174 422 64 -174 minecraft:air
fill 392 64 -175 422 64 -175 minecraft:air
fill 392 64 -176 422 64 -176 minecraft:air
fill 392 64 -177 422 64 -177 minecraft:air
fill 392 64 -178 422 64 -178 minecraft:air
fill 392 64 -179 422 64 -179 minecraft:air
fill 392 64 -180 422 64 -180 minecraft:air
fill 392 64 -181 422 64 -181 minecraft:air
fill 392 64 -182 422 64 -182 minecraft:air
fill 392 64 -183 422 64 -183 minecraft:air
fill 392 64 -184 422 64 -184 minecraft:air
fill 392 64 -185 422 64 -185 minecraft:air
fill 392 64 -186 422 64 -186 minecraft:air
fill 392 64 -187 422 64 -187 minecraft:air
fill 392 64 -188 404 64 -188 minecraft:air
fill 406 64 -188 422 64 -188 minecraft:air
fill 392 64 -189 422 64 -189 minecraft:air
fill 392 64 -190 422 64 -190 minecraft:air
fill 392 63 -127 411 63 -127 minecraft:air
fill 392 63 -128 412 63 -128 minecraft:air
fill 392 63 -129 413 63 -129 minecraft:air
fill 392 63 -130 414 63 -130 minecraft:air
fill 392 63 -131 415 63 -131 minecraft:air
fill 392 63 -132 415 63 -132 minecraft:air
fill 392 63 -133 416 63 -133 minecraft:air
fill 392 63 -134 417 63 -134 minecraft:air
fill 392 63 -135 417 63 -135 minecraft:air
fill 392 63 -136 418 63 -136 minecraft:air
fill 392 63 -137 418 63 -137 minecraft:air
fill 392 63 -138 419 63 -138 minecraft:air
fill 392 63 -139 419 63 -139 minecraft:air
fill 392 63 -140 419 63 -140 minecraft:air
fill 392 63 -141 420 63 -141 minecraft:air
fill 392 63 -142 420 63 -142 minecraft:air
fill 392 63 -143 420 63 -143 minecraft:air
fill 392 63 -144 421 63 -144 minecraft:air
fill 392 63 -145 421 63 -145 minecraft:air
fill 392 63 -146 421 63 -146 minecraft:air
fill 392 63 -147 421 63 -147 minecraft:air
fill 392 63 -148 421 63 -148 minecraft:air
fill 392 63 -149 421 63 -149 minecraft:air
fill 392 63 -150 421 63 -150 minecraft:air
fill 392 63 -151 421 63 -151 minecraft:air
fill 392 63 -152 422 63 -152 minecraft:air
fill 392 63 -153 422 63 -153 minecraft:air
fill 392 63 -154 422 63 -154 minecraft:air
fill 392 63 -155 422 63 -155 minecraft:air
fill 392 63 -156 422 63 -156 minecraft:air
fill 392 63 -157 422 63 -157 minecraft:air
fill 392 63 -158 422 63 -158 minecraft:air
fill 392 63 -159 422 63 -159 minecraft:air
fill 392 63 -160 422 63 -160 minecraft:air
fill 392 63 -161 422 63 -161 minecraft:air
fill 392 63 -162 422 63 -162 minecraft:air
fill 392 63 -163 422 63 -163 minecraft:air
fill 392 63 -164 422 63 -164 minecraft:air
fill 392 63 -165 422 63 -165 minecraft:air
fill 392 63 -166 422 63 -166 minecraft:air
fill 392 63 -167 422 63 -167 minecraft:air
fill 392 63 -168 422 63 -168 minecraft:air
fill 392 63 -169 422 63 -169 minecraft:air
fill 392 63 -170 412 63 -170 minecraft:air
fill 414 63 -170 422 63 -170 minecraft:air
fill 392 63 -171 422 63 -171 minecraft:air
fill 392 63 -172 422 63 -172 minecraft:air
fill 392 63 -173 422 63 -173 minecraft:air
fill 392 63 -174 401 63 -174 minecraft:air
fill 403 63 -174 422 63 -174 minecraft:air
fill 392 63 -175 422 63 -175 minecraft:air
fill 392 63 -176 422 63 -176 minecraft:air
fill 392 63 -177 422 63 -177 minecraft:air
fill 392 63 -178 422 63 -178 minecraft:air
fill 392 63 -179 422 63 -179 minecraft:air
fill 392 63 -180 422 63 -180 minecraft:air
fill 392 63 -181 422 63 -181 minecraft:air
fill 392 63 -182 422 63 -182 minecraft:air
fill 392 63 -183 422 63 -183 minecraft:air
fill 392 63 -184 422 63 -184 minecraft:air
fill 392 63 -185 422 63 -185 minecraft:air
fill 392 63 -186 422 63 -186 minecraft:air
fill 392 63 -187 422 63 -187 minecraft:air
fill 392 63 -188 404 63 -188 minecraft:air
fill 406 63 -188 422 63 -188 minecraft:air
fill 392 63 -189 422 63 -189 minecraft:air
fill 392 63 -190 422 63 -190 minecraft:air
fill 392 62 -127 411 62 -127 minecraft:water[level=0]
fill 392 62 -128 398 62 -128 minecraft:water[level=0]
setblock 399 62 -128 minecraft:kelp[age=25]
fill 400 62 -128 412 62 -128 minecraft:water[level=0]
fill 392 62 -129 413 62 -129 minecraft:water[level=0]
fill 392 62 -130 396 62 -130 minecraft:water[level=0]
setblock 397 62 -130 minecraft:kelp[age=24]
fill 398 62 -130 414 62 -130 minecraft:water[level=0]
fill 392 62 -131 415 62 -131 minecraft:water[level=0]
setblock 392 62 -132 minecraft:kelp[age=23]
fill 393 62 -132 415 62 -132 minecraft:water[level=0]
setblock 392 62 -133 minecraft:water[level=0]
setblock 393 62 -133 minecraft:kelp[age=22]
fill 394 62 -133 416 62 -133 minecraft:water[level=0]
fill 392 62 -134 417 62 -134 minecraft:water[level=0]
fill 392 62 -135 417 62 -135 minecraft:water[level=0]
fill 392 62 -136 418 62 -136 minecraft:water[level=0]
fill 392 62 -137 418 62 -137 minecraft:water[level=0]
fill 392 62 -138 419 62 -138 minecraft:water[level=0]
fill 392 62 -139 419 62 -139 minecraft:water[level=0]
fill 392 62 -140 419 62 -140 minecraft:water[level=0]
fill 392 62 -141 420 62 -141 minecraft:water[level=0]
fill 392 62 -142 420 62 -142 minecraft:water[level=0]
fill 392 62 -143 420 62 -143 minecraft:water[level=0]
fill 392 62 -144 421 62 -144 minecraft:water[level=0]
fill 392 62 -145 398 62 -145 minecraft:water[level=0]
setblock 399 62 -145 minecraft:kelp[age=25]
fill 400 62 -145 421 62 -145 minecraft:water[level=0]
fill 392 62 -146 394 62 -146 minecraft:water[level=0]
setblock 395 62 -146 minecraft:kelp[age=24]
fill 396 62 -146 421 62 -146 minecraft:water[level=0]
fill 392 62 -147 421 62 -147 minecraft:water[level=0]
fill 392 62 -148 421 62 -148 minecraft:water[level=0]
fill 392 62 -149 393 62 -149 minecraft:water[level=0]
setblock 394 62 -149 minecraft:kelp[age=25]
fill 395 62 -149 421 62 -149 minecraft:water[level=0]
fill 392 62 -150 421 62 -150 minecraft:water[level=0]
fill 392 62 -151 421 62 -151 minecraft:water[level=0]
fill 392 62 -152 422 62 -152 minecraft:water[level=0]
fill 392 62 -153 422 62 -153 minecraft:water[level=0]
fill 392 62 -154 422 62 -154 minecraft:water[level=0]
fill 392 62 -155 422 62 -155 minecraft:water[level=0]
fill 392 62 -156 422 62 -156 minecraft:water[level=0]
fill 392 62 -157 422 62 -157 minecraft:water[level=0]
fill 392 62 -158 422 62 -158 minecraft:water[level=0]
fill 392 62 -159 422 62 -159 minecraft:water[level=0]
fill 392 62 -160 422 62 -160 minecraft:water[level=0]
setblock 392 62 -161 minecraft:kelp[age=24]
fill 393 62 -161 398 62 -161 minecraft:water[level=0]
setblock 399 62 -161 minecraft:kelp[age=25]
fill 400 62 -161 422 62 -161 minecraft:water[level=0]
fill 392 62 -162 422 62 -162 minecraft:water[level=0]
setblock 392 62 -163 minecraft:kelp[age=23]
fill 393 62 -163 411 62 -163 minecraft:water[level=0]
setblock 412 62 -163 minecraft:bubble_column[drag=true]
fill 413 62 -163 422 62 -163 minecraft:water[level=0]
fill 392 62 -164 422 62 -164 minecraft:water[level=0]
fill 392 62 -165 422 62 -165 minecraft:water[level=0]
fill 392 62 -166 422 62 -166 minecraft:water[level=0]
fill 392 62 -167 406 62 -167 minecraft:water[level=0]
setblock 407 62 -167 minecraft:tall_seagrass[half=upper]
fill 408 62 -167 422 62 -167 minecraft:water[level=0]
fill 392 62 -168 395 62 -168 minecraft:water[level=0]
setblock 396 62 -168 minecraft:kelp[age=25]
fill 397 62 -168 422 62 -168 minecraft:water[level=0]
fill 392 62 -169 422 62 -169 minecraft:water[level=0]
fill 392 62 -170 398 62 -170 minecraft:water[level=0]
setblock 399 62 -170 minecraft:kelp[age=23]
fill 400 62 -170 412 62 -170 minecraft:water[level=0]
fill 414 62 -170 422 62 -170 minecraft:water[level=0]
fill 392 62 -171 397 62 -171 minecraft:water[level=0]
setblock 398 62 -171 minecraft:kelp[age=24]
fill 399 62 -171 422 62 -171 minecraft:water[level=0]
fill 392 62 -172 402 62 -172 minecraft:water[level=0]
setblock 403 62 -172 minecraft:bubble_column[drag=true]
fill 404 62 -172 422 62 -172 minecraft:water[level=0]
fill 392 62 -173 422 62 -173 minecraft:water[level=0]
fill 392 62 -174 401 62 -174 minecraft:water[level=0]
fill 403 62 -174 422 62 -174 minecraft:water[level=0]
fill 392 62 -175 398 62 -175 minecraft:water[level=0]
setblock 399 62 -175 minecraft:kelp[age=23]
fill 400 62 -175 422 62 -175 minecraft:water[level=0]
fill 392 62 -176 422 62 -176 minecraft:water[level=0]
fill 392 62 -177 397 62 -177 minecraft:water[level=0]
setblock 398 62 -177 minecraft:kelp[age=23]
fill 399 62 -177 422 62 -177 minecraft:water[level=0]
setblock 392 62 -178 minecraft:kelp[age=23]
fill 393 62 -178 422 62 -178 minecraft:water[level=0]
fill 392 62 -179 422 62 -179 minecraft:water[level=0]
fill 392 62 -180 397 62 -180 minecraft:water[level=0]
setblock 398 62 -180 minecraft:kelp[age=25]
fill 399 62 -180 422 62 -180 minecraft:water[level=0]
fill 392 62 -181 422 62 -181 minecraft:water[level=0]
fill 392 62 -182 422 62 -182 minecraft:water[level=0]
fill 392 62 -183 422 62 -183 minecraft:water[level=0]
fill 392 62 -184 393 62 -184 minecraft:water[level=0]
fill 394 62 -184 395 62 -184 minecraft:kelp[age=25]
fill 396 62 -184 422 62 -184 minecraft:water[level=0]
fill 392 62 -185 394 62 -185 minecraft:water[level=0]
setblock 395 62 -185 minecraft:kelp[age=24]
setblock 396 62 -185 minecraft:kelp[age=25]
setblock 397 62 -185 minecraft:water[level=0]
setblock 398 62 -185 minecraft:kelp[age=24]
fill 399 62 -185 422 62 -185 minecraft:water[level=0]
fill 392 62 -186 422 62 -186 minecraft:water[level=0]
fill 392 62 -187 397 62 -187 minecraft:water[level=0]
setblock 398 62 -187 minecraft:kelp[age=24]
fill 399 62 -187 422 62 -187 minecraft:water[level=0]
fill 392 62 -188 404 62 -188 minecraft:water[level=0]
fill 406 62 -188 419 62 -188 minecraft:water[level=0]
setblock 420 62 -188 minecraft:kelp[age=25]
setblock 421 62 -188 minecraft:bubble_column[drag=true]
setblock 422 62 -188 minecraft:water[level=0]
fill 392 62 -189 422 62 -189 minecraft:water[level=0]
fill 392 62 -190 422 62 -190 minecraft:water[level=0]
fill 392 61 -127 402 61 -127 minecraft:water[level=0]
setblock 403 61 -127 minecraft:kelp[age=25]
fill 404 61 -127 411 61 -127 minecraft:water[level=0]
fill 392 61 -128 398 61 -128 minecraft:water[level=0]
setblock 399 61 -128 minecraft:kelp_plant
fill 400 61 -128 412 61 -128 minecraft:water[level=0]
fill 392 61 -129 413 61 -129 minecraft:water[level=0]
fill 392 61 -130 396 61 -130 minecraft:water[level=0]
setblock 397 61 -130 minecraft:kelp_plant
fill 398 61 -130 414 61 -130 minecraft:water[level=0]
fill 392 61 -131 415 61 -131 minecraft:water[level=0]
setblock 392 61 -132 minecraft:kelp_plant
fill 393 61 -132 415 61 -132 minecraft:water[level=0]
setblock 392 61 -133 minecraft:water[level=0]
setblock 393 61 -133 minecraft:kelp_plant
fill 394 61 -133 416 61 -133 minecraft:water[level=0]
fill 392 61 -134 397 61 -134 minecraft:water[level=0]
setblock 398 61 -134 minecraft:kelp[age=25]
fill 399 61 -134 417 61 -134 minecraft:water[level=0]
fill 392 61 -135 417 61 -135 minecraft:water[level=0]
fill 392 61 -136 418 61 -136 minecraft:water[level=0]
fill 392 61 -137 394 61 -137 minecraft:water[level=0]
setblock 395 61 -137 minecraft:kelp[age=25]
fill 396 61 -137 418 61 -137 minecraft:water[level=0]
fill 392 61 -138 419 61 -138 minecraft:water[level=0]
fill 392 61 -139 419 61 -139 minecraft:water[level=0]
fill 392 61 -140 419 61 -140 minecraft:water[level=0]
fill 392 61 -141 420 61 -141 minecraft:water[level=0]
fill 392 61 -142 420 61 -142 minecraft:water[level=0]
fill 392 61 -143 420 61 -143 minecraft:water[level=0]
fill 392 61 -144 421 61 -144 minecraft:water[level=0]
fill 392 61 -145 398 61 -145 minecraft:water[level=0]
setblock 399 61 -145 minecraft:kelp_plant
fill 400 61 -145 421 61 -145 minecraft:water[level=0]
fill 392 61 -146 394 61 -146 minecraft:water[level=0]
setblock 395 61 -146 minecraft:kelp_plant
fill 396 61 -146 421 61 -146 minecraft:water[level=0]
setblock 392 61 -147 minecraft:water[level=0]
setblock 393 61 -147 minecraft:kelp[age=25]
fill 394 61 -147 421 61 -147 minecraft:water[level=0]
fill 392 61 -148 421 61 -148 minecraft:water[level=0]
fill 392 61 -149 393 61 -149 minecraft:water[level=0]
setblock 394 61 -149 minecraft:kelp_plant
fill 395 61 -149 421 61 -149 minecraft:water[level=0]
fill 392 61 -150 421 61 -150 minecraft:water[level=0]
fill 392 61 -151 421 61 -151 minecraft:water[level=0]
fill 392 61 -152 422 61 -152 minecraft:water[level=0]
fill 392 61 -153 422 61 -153 minecraft:water[level=0]
fill 392 61 -154 422 61 -154 minecraft:water[level=0]
fill 392 61 -155 422 61 -155 minecraft:water[level=0]
fill 392 61 -156 397 61 -156 minecraft:water[level=0]
setblock 398 61 -156 minecraft:kelp[age=25]
fill 399 61 -156 422 61 -156 minecraft:water[level=0]
fill 392 61 -157 422 61 -157 minecraft:water[level=0]
fill 392 61 -158 422 61 -158 minecraft:water[level=0]
fill 392 61 -159 422 61 -159 minecraft:water[level=0]
fill 392 61 -160 422 61 -160 minecraft:water[level=0]
setblock 392 61 -161 minecraft:kelp_plant
fill 393 61 -161 398 61 -161 minecraft:water[level=0]
setblock 399 61 -161 minecraft:kelp_plant
fill 400 61 -161 422 61 -161 minecraft:water[level=0]
fill 392 61 -162 396 61 -162 minecraft:water[level=0]
setblock 397 61 -162 minecraft:kelp[age=25]
fill 398 61 -162 422 61 -162 minecraft:water[level=0]
setblock 392 61 -163 minecraft:kelp_plant
fill 393 61 -163 411 61 -163 minecraft:water[level=0]
setblock 412 61 -163 minecraft:bubble_column[drag=true]
fill 413 61 -163 422 61 -163 minecraft:water[level=0]
fill 392 61 -164 422 61 -164 minecraft:water[level=0]
fill 392 61 -165 422 61 -165 minecraft:water[level=0]
fill 392 61 -166 394 61 -166 minecraft:water[level=0]
setblock 395 61 -166 minecraft:kelp[age=25]
fill 396 61 -166 422 61 -166 minecraft:water[level=0]
fill 392 61 -167 398 61 -167 minecraft:water[level=0]
setblock 399 61 -167 minecraft:kelp[age=25]
fill 400 61 -167 406 61 -167 minecraft:water[level=0]
setblock 407 61 -167 minecraft:tall_seagrass[half=lower]
fill 408 61 -167 422 61 -167 minecraft:water[level=0]
fill 392 61 -168 395 61 -168 minecraft:water[level=0]
setblock 396 61 -168 minecraft:kelp_plant
fill 397 61 -168 422 61 -168 minecraft:water[level=0]
fill 392 61 -169 408 61 -169 minecraft:water[level=0]
fill 410 61 -169 422 61 -169 minecraft:water[level=0]
fill 392 61 -170 398 61 -170 minecraft:water[level=0]
setblock 399 61 -170 minecraft:kelp_plant
fill 400 61 -170 406 61 -170 minecraft:water[level=0]
fill 408 61 -170 412 61 -170 minecraft:water[level=0]
fill 414 61 -170 422 61 -170 minecraft:water[level=0]
fill 392 61 -171 397 61 -171 minecraft:water[level=0]
setblock 398 61 -171 minecraft:kelp_plant
fill 399 61 -171 422 61 -171 minecraft:water[level=0]
fill 392 61 -172 402 61 -172 minecraft:water[level=0]
setblock 403 61 -172 minecraft:bubble_column[drag=true]
fill 404 61 -172 422 61 -172 minecraft:water[level=0]
setblock 392 61 -173 minecraft:kelp[age=25]
fill 393 61 -173 422 61 -173 minecraft:water[level=0]
fill 392 61 -174 397 61 -174 minecraft:water[level=0]
setblock 398 61 -174 minecraft:kelp[age=25]
fill 399 61 -174 401 61 -174 minecraft:water[level=0]
fill 403 61 -174 422 61 -174 minecraft:water[level=0]
fill 392 61 -175 398 61 -175 minecraft:water[level=0]
setblock 399 61 -175 minecraft:kelp_plant
fill 400 61 -175 422 61 -175 minecraft:water[level=0]
fill 392 61 -176 422 61 -176 minecraft:water[level=0]
fill 392 61 -177 397 61 -177 minecraft:water[level=0]
setblock 398 61 -177 minecraft:kelp_plant
fill 399 61 -177 422 61 -177 minecraft:water[level=0]
setblock 392 61 -178 minecraft:kelp_plant
fill 393 61 -178 422 61 -178 minecraft:water[level=0]
fill 392 61 -179 422 61 -179 minecraft:water[level=0]
fill 392 61 -180 397 61 -180 minecraft:water[level=0]
setblock 398 61 -180 minecraft:kelp_plant
fill 399 61 -180 422 61 -180 minecraft:water[level=0]
fill 392 61 -181 422 61 -181 minecraft:water[level=0]
fill 392 61 -182 422 61 -182 minecraft:water[level=0]
fill 392 61 -183 422 61 -183 minecraft:water[level=0]
fill 392 61 -184 393 61 -184 minecraft:water[level=0]
fill 394 61 -184 395 61 -184 minecraft:kelp_plant
fill 396 61 -184 422 61 -184 minecraft:water[level=0]
fill 392 61 -185 394 61 -185 minecraft:water[level=0]
fill 395 61 -185 396 61 -185 minecraft:kelp_plant
setblock 397 61 -185 minecraft:water[level=0]
setblock 398 61 -185 minecraft:kelp_plant
setblock 399 61 -185 minecraft:kelp[age=25]
fill 400 61 -185 422 61 -185 minecraft:water[level=0]
fill 392 61 -186 416 61 -186 minecraft:water[level=0]
setblock 417 61 -186 minecraft:kelp[age=25]
fill 418 61 -186 422 61 -186 minecraft:water[level=0]
fill 392 61 -187 397 61 -187 minecraft:water[level=0]
setblock 398 61 -187 minecraft:kelp_plant
fill 399 61 -187 422 61 -187 minecraft:water[level=0]
fill 392 61 -188 404 61 -188 minecraft:water[level=0]
fill 406 61 -188 419 61 -188 minecraft:water[level=0]
setblock 420 61 -188 minecraft:kelp_plant
setblock 421 61 -188 minecraft:bubble_column[drag=true]
setblock 422 61 -188 minecraft:water[level=0]
fill 392 61 -189 422 61 -189 minecraft:water[level=0]
fill 392 61 -190 396 61 -190 minecraft:water[level=0]
setblock 397 61 -190 minecraft:kelp[age=25]
fill 398 61 -190 410 61 -190 minecraft:water[level=0]
setblock 411 61 -190 minecraft:kelp[age=25]
fill 412 61 -190 422 61 -190 minecraft:water[level=0]
fill 392 60 -127 402 60 -127 minecraft:water[level=0]
setblock 403 60 -127 minecraft:kelp_plant
fill 404 60 -127 411 60 -127 minecraft:water[level=0]
fill 392 60 -128 398 60 -128 minecraft:water[level=0]
setblock 399 60 -128 minecraft:kelp_plant
fill 400 60 -128 412 60 -128 minecraft:water[level=0]
fill 392 60 -129 413 60 -129 minecraft:water[level=0]
fill 392 60 -130 396 60 -130 minecraft:water[level=0]
setblock 397 60 -130 minecraft:kelp_plant
fill 398 60 -130 414 60 -130 minecraft:water[level=0]
fill 392 60 -131 415 60 -131 minecraft:water[level=0]
setblock 392 60 -132 minecraft:kelp_plant
fill 393 60 -132 415 60 -132 minecraft:water[level=0]
setblock 392 60 -133 minecraft:water[level=0]
setblock 393 60 -133 minecraft:kelp_plant
fill 394 60 -133 416 60 -133 minecraft:water[level=0]
fill 392 60 -134 397 60 -134 minecraft:water[level=0]
setblock 398 60 -134 minecraft:kelp_plant
fill 399 60 -134 417 60 -134 minecraft:water[level=0]
fill 392 60 -135 417 60 -135 minecraft:water[level=0]
fill 392 60 -136 418 60 -136 minecraft:water[level=0]
fill 392 60 -137 394 60 -137 minecraft:water[level=0]
setblock 395 60 -137 minecraft:kelp_plant
fill 396 60 -137 418 60 -137 minecraft:water[level=0]
fill 392 60 -138 419 60 -138 minecraft:water[level=0]
fill 392 60 -139 398 60 -139 minecraft:water[level=0]
setblock 399 60 -139 minecraft:kelp[age=25]
fill 400 60 -139 419 60 -139 minecraft:water[level=0]
fill 392 60 -140 419 60 -140 minecraft:water[level=0]
fill 392 60 -141 396 60 -141 minecraft:water[level=0]
setblock 397 60 -141 minecraft:kelp[age=25]
fill 398 60 -141 420 60 -141 minecraft:water[level=0]
fill 392 60 -142 420 60 -142 minecraft:water[level=0]
setblock 392 60 -143 minecraft:water[level=0]
setblock 393 60 -143 minecraft:kelp[age=25]
fill 394 60 -143 420 60 -143 minecraft:water[level=0]
fill 392 60 -144 421 60 -144 minecraft:water[level=0]
fill 392 60 -145 398 60 -145 minecraft:water[level=0]
setblock 399 60 -145 minecraft:kelp_plant
fill 400 60 -145 421 60 -145 minecraft:water[level=0]
fill 392 60 -146 394 60 -146 minecraft:water[level=0]
setblock 395 60 -146 minecraft:kelp_plant
fill 396 60 -146 397 60 -146 minecraft:water[level=0]
fill 398 60 -146 399 60 -146 minecraft:kelp[age=25]
fill 400 60 -146 421 60 -146 minecraft:water[level=0]
setblock 392 60 -147 minecraft:water[level=0]
setblock 393 60 -147 minecraft:kelp_plant
fill 394 60 -147 421 60 -147 minecraft:water[level=0]
fill 392 60 -148 421 60 -148 minecraft:water[level=0]
fill 392 60 -149 393 60 -149 minecraft:water[level=0]
setblock 394 60 -149 minecraft:kelp_plant
fill 395 60 -149 421 60 -149 minecraft:water[level=0]
fill 392 60 -150 421 60 -150 minecraft:water[level=0]
fill 392 60 -151 421 60 -151 minecraft:water[level=0]
fill 392 60 -152 422 60 -152 minecraft:water[level=0]
fill 392 60 -153 422 60 -153 minecraft:water[level=0]
fill 392 60 -154 422 60 -154 minecraft:water[level=0]
fill 392 60 -155 395 60 -155 minecraft:water[level=0]
setblock 396 60 -155 minecraft:kelp[age=25]
fill 397 60 -155 422 60 -155 minecraft:water[level=0]
setblock 392 60 -156 minecraft:kelp[age=25]
fill 393 60 -156 396 60 -156 minecraft:water[level=0]
setblock 397 60 -156 minecraft:kelp[age=25]
setblock 398 60 -156 minecraft:kelp_plant
fill 399 60 -156 422 60 -156 minecraft:water[level=0]
fill 392 60 -157 397 60 -157 minecraft:water[level=0]
setblock 398 60 -157 minecraft:kelp[age=25]
fill 399 60 -157 422 60 -157 minecraft:water[level=0]
fill 392 60 -158 422 60 -158 minecraft:water[level=0]
fill 392 60 -159 422 60 -159 minecraft:water[level=0]
fill 392 60 -160 396 60 -160 minecraft:water[level=0]
setblock 397 60 -160 minecraft:kelp[age=25]
fill 398 60 -160 422 60 -160 minecraft:water[level=0]
setblock 392 60 -161 minecraft:kelp_plant
fill 393 60 -161 398 60 -161 minecraft:water[level=0]
setblock 399 60 -161 minecraft:kelp_plant
fill 400 60 -161 422 60 -161 minecraft:water[level=0]
fill 392 60 -162 396 60 -162 minecraft:water[level=0]
setblock 397 60 -162 minecraft:kelp_plant
fill 398 60 -162 422 60 -162 minecraft:water[level=0]
setblock 392 60 -163 minecraft:kelp_plant
setblock 393 60 -163 minecraft:kelp[age=25]
fill 394 60 -163 411 60 -163 minecraft:water[level=0]
setblock 412 60 -163 minecraft:bubble_column[drag=true]
fill 413 60 -163 422 60 -163 minecraft:water[level=0]
fill 392 60 -164 422 60 -164 minecraft:water[level=0]
fill 392 60 -165 422 60 -165 minecraft:water[level=0]
fill 392 60 -166 394 60 -166 minecraft:water[level=0]
setblock 395 60 -166 minecraft:kelp_plant
fill 396 60 -166 422 60 -166 minecraft:water[level=0]
setblock 392 60 -167 minecraft:kelp[age=25]
fill 393 60 -167 398 60 -167 minecraft:water[level=0]
setblock 399 60 -167 minecraft:kelp_plant
fill 400 60 -167 406 60 -167 minecraft:water[level=0]
fill 409 60 -167 422 60 -167 minecraft:water[level=0]
fill 392 60 -168 395 60 -168 minecraft:water[level=0]
setblock 396 60 -168 minecraft:kelp_plant
fill 397 60 -168 405 60 -168 minecraft:water[level=0]
setblock 407 60 -168 minecraft:water[level=0]
fill 410 60 -168 422 60 -168 minecraft:water[level=0]
fill 392 60 -169 405 60 -169 minecraft:water[level=0]
setblock 407 60 -169 minecraft:water[level=0]
fill 411 60 -169 422 60 -169 minecraft:water[level=0]
fill 392 60 -170 398 60 -170 minecraft:water[level=0]
setblock 399 60 -170 minecraft:kelp_plant
fill 400 60 -170 405 60 -170 minecraft:water[level=0]
fill 410 60 -170 412 60 -170 minecraft:water[level=0]
fill 414 60 -170 422 60 -170 minecraft:water[level=0]
fill 392 60 -171 395 60 -171 minecraft:water[level=0]
setblock 396 60 -171 minecraft:kelp[age=25]
setblock 397 60 -171 minecraft:water[level=0]
setblock 398 60 -171 minecraft:kelp_plant
fill 399 60 -171 406 60 -171 minecraft:water[level=0]
fill 408 60 -171 422 60 -171 minecraft:water[level=0]
fill 392 60 -172 402 60 -172 minecraft:water[level=0]
setblock 403 60 -172 minecraft:bubble_column[drag=true]
fill 404 60 -172 422 60 -172 minecraft:water[level=0]
setblock 392 60 -173 minecraft:kelp_plant
fill 393 60 -173 422 60 -173 minecraft:water[level=0]
fill 392 60 -174 397 60 -174 minecraft:water[level=0]
setblock 398 60 -174 minecraft:kelp_plant
fill 399 60 -174 401 60 -174 minecraft:water[level=0]
fill 403 60 -174 422 60 -174 minecraft:water[level=0]
fill 392 60 -175 398 60 -175 minecraft:water[level=0]
setblock 399 60 -175 minecraft:kelp_plant
fill 400 60 -175 422 60 -175 minecraft:water[level=0]
fill 392 60 -176 398 60 -176 minecraft:water[level=0]
setblock 399 60 -176 minecraft:kelp[age=25]
fill 400 60 -176 422 60 -176 minecraft:water[level=0]
setblock 392 60 -177 minecraft:water[level=0]
setblock 393 60 -177 minecraft:kelp[age=25]
fill 394 60 -177 397 60 -177 minecraft:water[level=0]
setblock 398 60 -177 minecraft:kelp_plant
fill 399 60 -177 422 60 -177 minecraft:water[level=0]
setblock 392 60 -178 minecraft:kelp_plant
fill 393 60 -178 422 60 -178 minecraft:water[level=0]
fill 392 60 -179 422 60 -179 minecraft:water[level=0]
fill 392 60 -180 397 60 -180 minecraft:water[level=0]
setblock 398 60 -180 minecraft:kelp_plant
fill 399 60 -180 422 60 -180 minecraft:water[level=0]
fill 392 60 -181 398 60 -181 minecraft:water[level=0]
setblock 399 60 -181 minecraft:kelp[age=25]
fill 400 60 -181 422 60 -181 minecraft:water[level=0]
fill 392 60 -182 422 60 -182 minecraft:water[level=0]
fill 392 60 -183 422 60 -183 minecraft:water[level=0]
fill 392 60 -184 393 60 -184 minecraft:water[level=0]
fill 394 60 -184 395 60 -184 minecraft:kelp_plant
fill 396 60 -184 422 60 -184 minecraft:water[level=0]
fill 392 60 -185 394 60 -185 minecraft:water[level=0]
fill 395 60 -185 396 60 -185 minecraft:kelp_plant
setblock 397 60 -185 minecraft:water[level=0]
fill 398 60 -185 399 60 -185 minecraft:kelp_plant
fill 400 60 -185 422 60 -185 minecraft:water[level=0]
fill 392 60 -186 416 60 -186 minecraft:water[level=0]
setblock 417 60 -186 minecraft:kelp_plant
fill 418 60 -186 422 60 -186 minecraft:water[level=0]
fill 392 60 -187 397 60 -187 minecraft:water[level=0]
setblock 398 60 -187 minecraft:kelp_plant
fill 399 60 -187 400 60 -187 minecraft:water[level=0]
setblock 401 60 -187 minecraft:kelp[age=25]
fill 402 60 -187 422 60 -187 minecraft:water[level=0]
fill 392 60 -188 404 60 -188 minecraft:water[level=0]
fill 406 60 -188 411 60 -188 minecraft:water[level=0]
setblock 412 60 -188 minecraft:kelp[age=25]
fill 413 60 -188 419 60 -188 minecraft:water[level=0]
setblock 420 60 -188 minecraft:kelp_plant
setblock 421 60 -188 minecraft:bubble_column[drag=true]
setblock 422 60 -188 minecraft:water[level=0]
fill 392 60 -189 422 60 -189 minecraft:water[level=0]
fill 392 60 -190 396 60 -190 minecraft:water[level=0]
setblock 397 60 -190 minecraft:kelp_plant
fill 398 60 -190 410 60 -190 minecraft:water[level=0]
setblock 411 60 -190 minecraft:kelp_plant
fill 412 60 -190 422 60 -190 minecraft:water[level=0]
fill 392 59 -127 402 59 -127 minecraft:water[level=0]
setblock 403 59 -127 minecraft:kelp_plant
fill 404 59 -127 411 59 -127 minecraft:water[level=0]
fill 392 59 -128 398 59 -128 minecraft:water[level=0]
setblock 399 59 -128 minecraft:kelp_plant
fill 400 59 -128 412 59 -128 minecraft:water[level=0]
fill 392 59 -129 413 59 -129 minecraft:water[level=0]
fill 392 59 -130 396 59 -130 minecraft:water[level=0]
setblock 397 59 -130 minecraft:kelp_plant
fill 398 59 -130 414 59 -130 minecraft:water[level=0]
fill 392 59 -131 415 59 -131 minecraft:water[level=0]
setblock 392 59 -132 minecraft:kelp_plant
fill 393 59 -132 415 59 -132 minecraft:water[level=0]
setblock 392 59 -133 minecraft:water[level=0]
setblock 393 59 -133 minecraft:kelp_plant
fill 394 59 -133 416 59 -133 minecraft:water[level=0]
fill 392 59 -134 397 59 -134 minecraft:water[level=0]
setblock 398 59 -134 minecraft:kelp_plant
fill 399 59 -134 417 59 -134 minecraft:water[level=0]
fill 392 59 -135 417 59 -135 minecraft:water[level=0]
fill 392 59 -136 418 59 -136 minecraft:water[level=0]
fill 392 59 -137 394 59 -137 minecraft:water[level=0]
setblock 395 59 -137 minecraft:kelp_plant
fill 396 59 -137 418 59 -137 minecraft:water[level=0]
fill 392 59 -138 419 59 -138 minecraft:water[level=0]
fill 392 59 -139 398 59 -139 minecraft:water[level=0]
setblock 399 59 -139 minecraft:kelp_plant
fill 400 59 -139 419 59 -139 minecraft:water[level=0]
fill 392 59 -140 419 59 -140 minecraft:water[level=0]
fill 392 59 -141 396 59 -141 minecraft:water[level=0]
setblock 397 59 -141 minecraft:kelp_plant
fill 398 59 -141 420 59 -141 minecraft:water[level=0]
fill 392 59 -142 420 59 -142 minecraft:water[level=0]
setblock 392 59 -143 minecraft:water[level=0]
setblock 393 59 -143 minecraft:kelp_plant
fill 394 59 -143 420 59 -143 minecraft:water[level=0]
fill 392 59 -144 421 59 -144 minecraft:water[level=0]
fill 392 59 -145 398 59 -145 minecraft:water[level=0]
setblock 399 59 -145 minecraft:kelp_plant
fill 400 59 -145 421 59 -145 minecraft:water[level=0]
fill 392 59 -146 394 59 -146 minecraft:water[level=0]
setblock 395 59 -146 minecraft:kelp_plant
fill 396 59 -146 397 59 -146 minecraft:water[level=0]
fill 398 59 -146 399 59 -146 minecraft:kelp_plant
fill 400 59 -146 421 59 -146 minecraft:water[level=0]
setblock 392 59 -147 minecraft:water[level=0]
setblock 393 59 -147 minecraft:kelp_plant
fill 394 59 -147 421 59 -147 minecraft:water[level=0]
setblock 392 59 -148 minecraft:water[level=0]
setblock 393 59 -148 minecraft:kelp[age=25]
fill 394 59 -148 421 59 -148 minecraft:water[level=0]
fill 392 59 -149 393 59 -149 minecraft:water[level=0]
setblock 394 59 -149 minecraft:kelp_plant
fill 395 59 -149 397 59 -149 minecraft:water[level=0]
setblock 398 59 -149 minecraft:kelp[age=25]
fill 399 59 -149 421 59 -149 minecraft:water[level=0]
fill 392 59 -150 393 59 -150 minecraft:water[level=0]
setblock 394 59 -150 minecraft:kelp[age=25]
fill 395 59 -150 421 59 -150 minecraft:water[level=0]
fill 392 59 -151 421 59 -151 minecraft:water[level=0]
fill 392 59 -152 398 59 -152 minecraft:water[level=0]
setblock 399 59 -152 minecraft:kelp[age=25]
fill 400 59 -152 422 59 -152 minecraft:water[level=0]
fill 392 59 -153 422 59 -153 minecraft:water[level=0]
fill 392 59 -154 422 59 -154 minecraft:water[level=0]
fill 392 59 -155 395 59 -155 minecraft:water[level=0]
setblock 396 59 -155 minecraft:kelp_plant
fill 397 59 -155 422 59 -155 minecraft:water[level=0]
setblock 392 59 -156 minecraft:kelp_plant
fill 393 59 -156 396 59 -156 minecraft:water[level=0]
fill 397 59 -156 398 59 -156 minecraft:kelp_plant
setblock 399 59 -156 minecraft:kelp[age=25]
fill 400 59 -156 422 59 -156 minecraft:water[level=0]
fill 392 59 -157 397 59 -157 minecraft:water[level=0]
setblock 398 59 -157 minecraft:kelp_plant
fill 399 59 -157 422 59 -157 minecraft:water[level=0]
fill 392 59 -158 422 59 -158 minecraft:water[level=0]
fill 392 59 -159 422 59 -159 minecraft:water[level=0]
fill 392 59 -160 396 59 -160 minecraft:water[level=0]
setblock 397 59 -160 minecraft:kelp_plant
fill 398 59 -160 422 59 -160 minecraft:water[level=0]
setblock 392 59 -161 minecraft:kelp_plant
fill 393 59 -161 396 59 -161 minecraft:water[level=0]
setblock 397 59 -161 minecraft:kelp[age=25]
setblock 398 59 -161 minecraft:water[level=0]
setblock 399 59 -161 minecraft:kelp_plant
fill 400 59 -161 422 59 -161 minecraft:water[level=0]
fill 392 59 -162 396 59 -162 minecraft:water[level=0]
setblock 397 59 -162 minecraft:kelp_plant
fill 398 59 -162 422 59 -162 minecraft:water[level=0]
fill 392 59 -163 393 59 -163 minecraft:kelp_plant
fill 394 59 -163 411 59 -163 minecraft:water[level=0]
setblock 412 59 -163 minecraft:bubble_column[drag=true]
fill 413 59 -163 422 59 -163 minecraft:water[level=0]
fill 392 59 -164 422 59 -164 minecraft:water[level=0]
fill 392 59 -165 403 59 -165 minecraft:water[level=0]
setblock 404 59 -165 minecraft:tall_seagrass[half=upper]
fill 405 59 -165 422 59 -165 minecraft:water[level=0]
fill 392 59 -166 394 59 -166 minecraft:water[level=0]
setblock 395 59 -166 minecraft:kelp_plant
fill 396 59 -166 422 59 -166 minecraft:water[level=0]
setblock 392 59 -167 minecraft:kelp_plant
setblock 393 59 -167 minecraft:water[level=0]
setblock 394 59 -167 minecraft:kelp[age=25]
fill 395 59 -167 398 59 -167 minecraft:water[level=0]
setblock 399 59 -167 minecraft:kelp_plant
fill 400 59 -167 405 59 -167 minecraft:water[level=0]
fill 407 59 -167 408 59 -167 minecraft:water[level=0]
fill 410 59 -167 422 59 -167 minecraft:water[level=0]
fill 392 59 -168 395 59 -168 minecraft:water[level=0]
setblock 396 59 -168 minecraft:kelp_plant
setblock 397 59 -168 minecraft:water[level=0]
setblock 398 59 -168 minecraft:kelp[age=25]
fill 399 59 -168 407 59 -168 minecraft:water[level=0]
setblock 408 59 -168 minecraft:bubble_column[drag=true]
fill 409 59 -168 422 59 -168 minecraft:water[level=0]
fill 392 59 -169 422 59 -169 minecraft:water[level=0]
fill 392 59 -170 398 59 -170 minecraft:water[level=0]
setblock 399 59 -170 minecraft:kelp_plant
fill 400 59 -170 405 59 -170 minecraft:water[level=0]
fill 407 59 -170 408 59 -170 minecraft:water[level=0]
fill 411 59 -170 412 59 -170 minecraft:water[level=0]
fill 414 59 -170 422 59 -170 minecraft:water[level=0]
fill 392 59 -171 395 59 -171 minecraft:water[level=0]
setblock 396 59 -171 minecraft:kelp_plant
setblock 397 59 -171 minecraft:water[level=0]
setblock 398 59 -171 minecraft:kelp_plant
fill 399 59 -171 408 59 -171 minecraft:water[level=0]
fill 410 59 -171 422 59 -171 minecraft:water[level=0]
fill 392 59 -172 402 59 -172 minecraft:water[level=0]
setblock 403 59 -172 minecraft:bubble_column[drag=true]
fill 404 59 -172 422 59 -172 minecraft:water[level=0]
setblock 392 59 -173 minecraft:kelp_plant
fill 393 59 -173 422 59 -173 minecraft:water[level=0]
fill 392 59 -174 397 59 -174 minecraft:water[level=0]
setblock 398 59 -174 minecraft:kelp_plant
fill 399 59 -174 401 59 -174 minecraft:water[level=0]
fill 403 59 -174 422 59 -174 minecraft:water[level=0]
fill 392 59 -175 398 59 -175 minecraft:water[level=0]
setblock 399 59 -175 minecraft:kelp_plant
fill 400 59 -175 422 59 -175 minecraft:water[level=0]
fill 392 59 -176 398 59 -176 minecraft:water[level=0]
setblock 399 59 -176 minecraft:kelp_plant
fill 400 59 -176 422 59 -176 minecraft:water[level=0]
setblock 392 59 -177 minecraft:water[level=0]
setblock 393 59 -177 minecraft:kelp_plant
fill 394 59 -177 397 59 -177 minecraft:water[level=0]
setblock 398 59 -177 minecraft:kelp_plant
fill 399 59 -177 422 59 -177 minecraft:water[level=0]
setblock 392 59 -178 minecraft:kelp_plant
fill 393 59 -178 422 59 -178 minecraft:water[level=0]
fill 392 59 -179 422 59 -179 minecraft:water[level=0]
fill 392 59 -180 397 59 -180 minecraft:water[level=0]
setblock 398 59 -180 minecraft:kelp_plant
fill 399 59 -180 422 59 -180 minecraft:water[level=0]
fill 392 59 -181 398 59 -181 minecraft:water[level=0]
setblock 399 59 -181 minecraft:kelp_plant
fill 400 59 -181 422 59 -181 minecraft:water[level=0]
fill 392 59 -182 422 59 -182 minecraft:water[level=0]
fill 392 59 -183 422 59 -183 minecraft:water[level=0]
fill 392 59 -184 393 59 -184 minecraft:water[level=0]
fill 394 59 -184 395 59 -184 minecraft:kelp_plant
fill 396 59 -184 422 59 -184 minecraft:water[level=0]
fill 392 59 -185 394 59 -185 minecraft:water[level=0]
fill 395 59 -185 396 59 -185 minecraft:kelp_plant
setblock 397 59 -185 minecraft:water[level=0]
fill 398 59 -185 399 59 -185 minecraft:kelp_plant
fill 400 59 -185 422 59 -185 minecraft:water[level=0]
fill 392 59 -186 398 59 -186 minecraft:water[level=0]
setblock 399 59 -186 minecraft:kelp[age=25]
fill 400 59 -186 416 59 -186 minecraft:water[level=0]
setblock 417 59 -186 minecraft:kelp_plant
fill 418 59 -186 422 59 -186 minecraft:water[level=0]
fill 392 59 -187 397 59 -187 minecraft:water[level=0]
setblock 398 59 -187 minecraft:kelp_plant
fill 399 59 -187 400 59 -187 minecraft:water[level=0]
setblock 401 59 -187 minecraft:kelp_plant
fill 402 59 -187 422 59 -187 minecraft:water[level=0]
fill 392 59 -188 404 59 -188 minecraft:water[level=0]
fill 406 59 -188 411 59 -188 minecraft:water[level=0]
setblock 412 59 -188 minecraft:kelp_plant
fill 413 59 -188 419 59 -188 minecraft:water[level=0]
setblock 420 59 -188 minecraft:kelp_plant
setblock 421 59 -188 minecraft:bubble_column[drag=true]
setblock 422 59 -188 minecraft:water[level=0]
fill 392 59 -189 422 59 -189 minecraft:water[level=0]
fill 392 59 -190 396 59 -190 minecraft:water[level=0]
setblock 397 59 -190 minecraft:kelp_plant
fill 398 59 -190 410 59 -190 minecraft:water[level=0]
setblock 411 59 -190 minecraft:kelp_plant
fill 412 59 -190 422 59 -190 minecraft:water[level=0]
fill 392 58 -127 395 58 -127 minecraft:water[level=0]
setblock 396 58 -127 minecraft:kelp[age=25]
fill 397 58 -127 402 58 -127 minecraft:water[level=0]
setblock 403 58 -127 minecraft:kelp_plant
fill 404 58 -127 411 58 -127 minecraft:water[level=0]
fill 392 58 -128 398 58 -128 minecraft:water[level=0]
setblock 399 58 -128 minecraft:kelp_plant
fill 400 58 -128 412 58 -128 minecraft:water[level=0]
fill 392 58 -129 393 58 -129 minecraft:water[level=0]
setblock 394 58 -129 minecraft:kelp[age=25]
fill 395 58 -129 413 58 -129 minecraft:water[level=0]
fill 392 58 -130 396 58 -130 minecraft:water[level=0]
setblock 397 58 -130 minecraft:kelp_plant
fill 398 58 -130 414 58 -130 minecraft:water[level=0]
setblock 392 58 -131 minecraft:water[level=0]
setblock 393 58 -131 minecraft:kelp[age=25]
fill 394 58 -131 415 58 -131 minecraft:water[level=0]
setblock 392 58 -132 minecraft:kelp_plant
fill 393 58 -132 415 58 -132 minecraft:water[level=0]
setblock 392 58 -133 minecraft:water[level=0]
setblock 393 58 -133 minecraft:kelp_plant
fill 394 58 -133 416 58 -133 minecraft:water[level=0]
fill 392 58 -134 397 58 -134 minecraft:water[level=0]
setblock 398 58 -134 minecraft:kelp_plant
fill 399 58 -134 417 58 -134 minecraft:water[level=0]
fill 392 58 -135 417 58 -135 minecraft:water[level=0]
fill 392 58 -136 418 58 -136 minecraft:water[level=0]
fill 392 58 -137 394 58 -137 minecraft:water[level=0]
setblock 395 58 -137 minecraft:kelp_plant
fill 396 58 -137 418 58 -137 minecraft:water[level=0]
fill 392 58 -138 419 58 -138 minecraft:water[level=0]
fill 392 58 -139 398 58 -139 minecraft:water[level=0]
setblock 399 58 -139 minecraft:kelp_plant
fill 400 58 -139 419 58 -139 minecraft:water[level=0]
setblock 392 58 -140 minecraft:kelp[age=25]
fill 393 58 -140 419 58 -140 minecraft:water[level=0]
fill 392 58 -141 396 58 -141 minecraft:water[level=0]
setblock 397 58 -141 minecraft:kelp_plant
fill 398 58 -141 420 58 -141 minecraft:water[level=0]
fill 392 58 -142 397 58 -142 minecraft:water[level=0]
setblock 398 58 -142 minecraft:kelp[age=25]
fill 399 58 -142 420 58 -142 minecraft:water[level=0]
setblock 392 58 -143 minecraft:water[level=0]
setblock 393 58 -143 minecraft:kelp_plant
fill 394 58 -143 420 58 -143 minecraft:water[level=0]
fill 392 58 -144 421 58 -144 minecraft:water[level=0]
fill 392 58 -145 398 58 -145 minecraft:water[level=0]
setblock 399 58 -145 minecraft:kelp_plant
fill 400 58 -145 421 58 -145 minecraft:water[level=0]
fill 392 58 -146 394 58 -146 minecraft:water[level=0]
setblock 395 58 -146 minecraft:kelp_plant
fill 396 58 -146 397 58 -146 minecraft:water[level=0]
fill 398 58 -146 399 58 -146 minecraft:kelp_plant
fill 400 58 -146 421 58 -146 minecraft:water[level=0]
setblock 392 58 -147 minecraft:water[level=0]
setblock 393 58 -147 minecraft:kelp_plant
fill 394 58 -147 421 58 -147 minecraft:water[level=0]
setblock 392 58 -148 minecraft:water[level=0]
setblock 393 58 -148 minecraft:kelp_plant
fill 394 58 -148 421 58 -148 minecraft:water[level=0]
fill 392 58 -149 393 58 -149 minecraft:water[level=0]
setblock 394 58 -149 minecraft:kelp_plant
fill 395 58 -149 397 58 -149 minecraft:water[level=0]
setblock 398 58 -149 minecraft:kelp_plant
fill 399 58 -149 421 58 -149 minecraft:water[level=0]
setblock 392 58 -150 minecraft:kelp[age=25]
setblock 393 58 -150 minecraft:water[level=0]
setblock 394 58 -150 minecraft:kelp_plant
fill 395 58 -150 421 58 -150 minecraft:water[level=0]
fill 392 58 -151 421 58 -151 minecraft:water[level=0]
fill 392 58 -152 398 58 -152 minecraft:water[level=0]
setblock 399 58 -152 minecraft:kelp_plant
fill 400 58 -152 422 58 -152 minecraft:water[level=0]
fill 392 58 -153 422 58 -153 minecraft:water[level=0]
fill 392 58 -154 398 58 -154 minecraft:water[level=0]
setblock 399 58 -154 minecraft:kelp[age=25]
fill 400 58 -154 422 58 -154 minecraft:water[level=0]
fill 392 58 -155 395 58 -155 minecraft:water[level=0]
setblock 396 58 -155 minecraft:kelp_plant
fill 397 58 -155 422 58 -155 minecraft:water[level=0]
setblock 392 58 -156 minecraft:kelp_plant
fill 393 58 -156 396 58 -156 minecraft:water[level=0]
fill 397 58 -156 399 58 -156 minecraft:kelp_plant
fill 400 58 -156 422 58 -156 minecraft:water[level=0]
fill 392 58 -157 394 58 -157 minecraft:water[level=0]
setblock 395 58 -157 minecraft:kelp[age=25]
fill 396 58 -157 397 58 -157 minecraft:water[level=0]
setblock 398 58 -157 minecraft:kelp_plant
fill 399 58 -157 422 58 -157 minecraft:water[level=0]
fill 392 58 -158 422 58 -158 minecraft:water[level=0]
fill 392 58 -159 422 58 -159 minecraft:water[level=0]
fill 392 58 -160 396 58 -160 minecraft:water[level=0]
setblock 397 58 -160 minecraft:kelp_plant
fill 398 58 -160 422 58 -160 minecraft:water[level=0]
setblock 392 58 -161 minecraft:kelp_plant
fill 393 58 -161 396 58 -161 minecraft:water[level=0]
setblock 397 58 -161 minecraft:kelp_plant
setblock 398 58 -161 minecraft:water[level=0]
setblock 399 58 -161 minecraft:kelp_plant
fill 400 58 -161 422 58 -161 minecraft:water[level=0]
fill 392 58 -162 396 58 -162 minecraft:water[level=0]
setblock 397 58 -162 minecraft:kelp_plant
fill 398 58 -162 422 58 -162 minecraft:water[level=0]
fill 392 58 -163 393 58 -163 minecraft:kelp_plant
fill 394 58 -163 408 58 -163 minecraft:water[level=0]
setblock 409 58 -163 minecraft:seagrass
fill 410 58 -163 411 58 -163 minecraft:water[level=0]
setblock 412 58 -163 minecraft:bubble_column[drag=true]
fill 413 58 -163 422 58 -163 minecraft:water[level=0]
fill 392 58 -164 422 58 -164 minecraft:water[level=0]
fill 392 58 -165 403 58 -165 minecraft:water[level=0]
setblock 404 58 -165 minecraft:tall_seagrass[half=lower]
fill 405 58 -165 422 58 -165 minecraft:water[level=0]
fill 392 58 -166 394 58 -166 minecraft:water[level=0]
setblock 395 58 -166 minecraft:kelp_plant
fill 396 58 -166 404 58 -166 minecraft:water[level=0]
fill 406 58 -166 409 58 -166 minecraft:water[level=0]
fill 411 58 -166 422 58 -166 minecraft:water[level=0]
setblock 392 58 -167 minecraft:kelp_plant
setblock 393 58 -167 minecraft:water[level=0]
setblock 394 58 -167 minecraft:kelp_plant
fill 395 58 -167 398 58 -167 minecraft:water[level=0]
setblock 399 58 -167 minecraft:kelp_plant
fill 400 58 -167 405 58 -167 minecraft:water[level=0]
fill 407 58 -167 408 58 -167 minecraft:water[level=0]
fill 410 58 -167 412 58 -167 minecraft:water[level=0]
fill 414 58 -167 422 58 -167 minecraft:water[level=0]
fill 392 58 -168 395 58 -168 minecraft:water[level=0]
setblock 396 58 -168 minecraft:kelp_plant
setblock 397 58 -168 minecraft:water[level=0]
setblock 398 58 -168 minecraft:kelp_plant
fill 399 58 -168 407 58 -168 minecraft:water[level=0]
setblock 408 58 -168 minecraft:bubble_column[drag=true]
fill 409 58 -168 422 58 -168 minecraft:water[level=0]
setblock 392 58 -169 minecraft:water[level=0]
setblock 393 58 -169 minecraft:kelp[age=25]
fill 394 58 -169 408 58 -169 minecraft:water[level=0]
fill 410 58 -169 422 58 -169 minecraft:water[level=0]
fill 392 58 -170 398 58 -170 minecraft:water[level=0]
setblock 399 58 -170 minecraft:kelp_plant
fill 400 58 -170 401 58 -170 minecraft:water[level=0]
setblock 402 58 -170 minecraft:seagrass
fill 403 58 -170 405 58 -170 minecraft:water[level=0]
setblock 407 58 -170 minecraft:water[level=0]
fill 411 58 -170 412 58 -170 minecraft:water[level=0]
fill 414 58 -170 422 58 -170 minecraft:water[level=0]
fill 392 58 -171 395 58 -171 minecraft:water[level=0]
setblock 396 58 -171 minecraft:kelp_plant
setblock 397 58 -171 minecraft:water[level=0]
setblock 398 58 -171 minecraft:kelp_plant
fill 399 58 -171 404 58 -171 minecraft:water[level=0]
fill 406 58 -171 408 58 -171 minecraft:water[level=0]
fill 410 58 -171 422 58 -171 minecraft:water[level=0]
setblock 392 58 -172 minecraft:kelp[age=25]
fill 393 58 -172 402 58 -172 minecraft:water[level=0]
setblock 403 58 -172 minecraft:bubble_column[drag=true]
fill 404 58 -172 410 58 -172 minecraft:water[level=0]
fill 412 58 -172 422 58 -172 minecraft:water[level=0]
setblock 392 58 -173 minecraft:kelp_plant
fill 393 58 -173 422 58 -173 minecraft:water[level=0]
fill 392 58 -174 396 58 -174 minecraft:water[level=0]
setblock 397 58 -174 minecraft:kelp[age=25]
setblock 398 58 -174 minecraft:kelp_plant
fill 399 58 -174 401 58 -174 minecraft:water[level=0]
fill 403 58 -174 412 58 -174 minecraft:water[level=0]
fill 414 58 -174 422 58 -174 minecraft:water[level=0]
fill 392 58 -175 398 58 -175 minecraft:water[level=0]
setblock 399 58 -175 minecraft:kelp_plant
fill 400 58 -175 422 58 -175 minecraft:water[level=0]
fill 392 58 -176 398 58 -176 minecraft:water[level=0]
setblock 399 58 -176 minecraft:kelp_plant
fill 400 58 -176 422 58 -176 minecraft:water[level=0]
setblock 392 58 -177 minecraft:water[level=0]
setblock 393 58 -177 minecraft:kelp_plant
fill 394 58 -177 397 58 -177 minecraft:water[level=0]
setblock 398 58 -177 minecraft:kelp_plant
fill 399 58 -177 422 58 -177 minecraft:water[level=0]
setblock 392 58 -178 minecraft:kelp_plant
fill 393 58 -178 422 58 -178 minecraft:water[level=0]
fill 392 58 -179 422 58 -179 minecraft:water[level=0]
fill 392 58 -180 397 58 -180 minecraft:water[level=0]
setblock 398 58 -180 minecraft:kelp_plant
fill 399 58 -180 422 58 -180 minecraft:water[level=0]
fill 392 58 -181 396 58 -181 minecraft:water[level=0]
setblock 397 58 -181 minecraft:kelp[age=25]
setblock 398 58 -181 minecraft:water[level=0]
setblock 399 58 -181 minecraft:kelp_plant
fill 400 58 -181 422 58 -181 minecraft:water[level=0]
fill 392 58 -182 422 58 -182 minecraft:water[level=0]
fill 392 58 -183 422 58 -183 minecraft:water[level=0]
fill 392 58 -184 393 58 -184 minecraft:water[level=0]
fill 394 58 -184 395 58 -184 minecraft:kelp_plant
fill 396 58 -184 412 58 -184 minecraft:water[level=0]
setblock 413 58 -184 minecraft:kelp[age=25]
fill 414 58 -184 422 58 -184 minecraft:water[level=0]
fill 392 58 -185 394 58 -185 minecraft:water[level=0]
fill 395 58 -185 396 58 -185 minecraft:kelp_plant
setblock 397 58 -185 minecraft:water[level=0]
fill 398 58 -185 399 58 -185 minecraft:kelp_plant
fill 400 58 -185 422 58 -185 minecraft:water[level=0]
fill 392 58 -186 398 58 -186 minecraft:water[level=0]
setblock 399 58 -186 minecraft:kelp_plant
fill 400 58 -186 416 58 -186 minecraft:water[level=0]
setblock 417 58 -186 minecraft:kelp_plant
setblock 418 58 -186 minecraft:water[level=0]
setblock 419 58 -186 minecraft:stone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=true]
fill 420 58 -186 422 58 -186 minecraft:water[level=0]
fill 392 58 -187 397 58 -187 minecraft:water[level=0]
setblock 398 58 -187 minecraft:kelp_plant
fill 399 58 -187 400 58 -187 minecraft:water[level=0]
setblock 401 58 -187 minecraft:kelp_plant
fill 402 58 -187 422 58 -187 minecraft:water[level=0]
fill 392 58 -188 404 58 -188 minecraft:water[level=0]
fill 406 58 -188 411 58 -188 minecraft:water[level=0]
setblock 412 58 -188 minecraft:kelp_plant
fill 413 58 -188 418 58 -188 minecraft:water[level=0]
setblock 420 58 -188 minecraft:kelp_plant
setblock 421 58 -188 minecraft:bubble_column[drag=true]
setblock 422 58 -188 minecraft:water[level=0]
fill 392 58 -189 404 58 -189 minecraft:water[level=0]
fill 406 58 -189 418 58 -189 minecraft:water[level=0]
setblock 419 58 -189 minecraft:stone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=true]
fill 420 58 -189 422 58 -189 minecraft:water[level=0]
fill 392 58 -190 396 58 -190 minecraft:water[level=0]
setblock 397 58 -190 minecraft:kelp_plant
fill 398 58 -190 410 58 -190 minecraft:water[level=0]
setblock 411 58 -190 minecraft:kelp_plant
fill 412 58 -190 422 58 -190 minecraft:water[level=0]
fill 392 57 -127 395 57 -127 minecraft:water[level=0]
setblock 396 57 -127 minecraft:kelp_plant
fill 397 57 -127 402 57 -127 minecraft:water[level=0]
setblock 403 57 -127 minecraft:kelp_plant
fill 404 57 -127 411 57 -127 minecraft:water[level=0]
fill 392 57 -128 398 57 -128 minecraft:water[level=0]
setblock 399 57 -128 minecraft:kelp_plant
fill 400 57 -128 412 57 -128 minecraft:water[level=0]
fill 392 57 -129 393 57 -129 minecraft:water[level=0]
setblock 394 57 -129 minecraft:kelp_plant
fill 395 57 -129 413 57 -129 minecraft:water[level=0]
fill 392 57 -130 396 57 -130 minecraft:water[level=0]
setblock 397 57 -130 minecraft:kelp_plant
fill 398 57 -130 414 57 -130 minecraft:water[level=0]
setblock 392 57 -131 minecraft:water[level=0]
setblock 393 57 -131 minecraft:kelp_plant
fill 394 57 -131 415 57 -131 minecraft:water[level=0]
setblock 392 57 -132 minecraft:kelp_plant
fill 393 57 -132 415 57 -132 minecraft:water[level=0]
setblock 392 57 -133 minecraft:water[level=0]
setblock 393 57 -133 minecraft:kelp_plant
fill 394 57 -133 416 57 -133 minecraft:water[level=0]
fill 392 57 -134 397 57 -134 minecraft:water[level=0]
setblock 398 57 -134 minecraft:kelp_plant
setblock 399 57 -134 minecraft:kelp[age=25]
fill 400 57 -134 417 57 -134 minecraft:water[level=0]
fill 392 57 -135 417 57 -135 minecraft:water[level=0]
fill 392 57 -136 418 57 -136 minecraft:water[level=0]
fill 392 57 -137 394 57 -137 minecraft:water[level=0]
setblock 395 57 -137 minecraft:kelp_plant
fill 396 57 -137 418 57 -137 minecraft:water[level=0]
fill 392 57 -138 419 57 -138 minecraft:water[level=0]
fill 392 57 -139 398 57 -139 minecraft:water[level=0]
setblock 399 57 -139 minecraft:kelp_plant
fill 400 57 -139 419 57 -139 minecraft:water[level=0]
setblock 392 57 -140 minecraft:kelp_plant
fill 393 57 -140 419 57 -140 minecraft:water[level=0]
fill 392 57 -141 396 57 -141 minecraft:water[level=0]
setblock 397 57 -141 minecraft:kelp_plant
fill 398 57 -141 420 57 -141 minecraft:water[level=0]
fill 392 57 -142 397 57 -142 minecraft:water[level=0]
setblock 398 57 -142 minecraft:kelp_plant
fill 399 57 -142 420 57 -142 minecraft:water[level=0]
setblock 392 57 -143 minecraft:water[level=0]
setblock 393 57 -143 minecraft:kelp_plant
fill 394 57 -143 420 57 -143 minecraft:water[level=0]
fill 392 57 -144 421 57 -144 minecraft:water[level=0]
fill 392 57 -145 398 57 -145 minecraft:water[level=0]
setblock 399 57 -145 minecraft:kelp_plant
fill 400 57 -145 421 57 -145 minecraft:water[level=0]
fill 392 57 -146 394 57 -146 minecraft:water[level=0]
setblock 395 57 -146 minecraft:kelp_plant
fill 396 57 -146 397 57 -146 minecraft:water[level=0]
fill 398 57 -146 399 57 -146 minecraft:kelp_plant
fill 400 57 -146 421 57 -146 minecraft:water[level=0]
setblock 392 57 -147 minecraft:water[level=0]
setblock 393 57 -147 minecraft:kelp_plant
fill 394 57 -147 396 57 -147 minecraft:water[level=0]
setblock 397 57 -147 minecraft:kelp[age=25]
fill 398 57 -147 421 57 -147 minecraft:water[level=0]
setblock 392 57 -148 minecraft:water[level=0]
setblock 393 57 -148 minecraft:kelp_plant
fill 394 57 -148 421 57 -148 minecraft:water[level=0]
fill 392 57 -149 393 57 -149 minecraft:water[level=0]
setblock 394 57 -149 minecraft:kelp_plant
fill 395 57 -149 397 57 -149 minecraft:water[level=0]
setblock 398 57 -149 minecraft:kelp_plant
fill 399 57 -149 421 57 -149 minecraft:water[level=0]
setblock 392 57 -150 minecraft:kelp_plant
setblock 393 57 -150 minecraft:water[level=0]
setblock 394 57 -150 minecraft:kelp_plant
fill 395 57 -150 421 57 -150 minecraft:water[level=0]
fill 392 57 -151 398 57 -151 minecraft:water[level=0]
setblock 399 57 -151 minecraft:kelp[age=25]
fill 400 57 -151 421 57 -151 minecraft:water[level=0]
fill 392 57 -152 398 57 -152 minecraft:water[level=0]
setblock 399 57 -152 minecraft:kelp_plant
fill 400 57 -152 422 57 -152 minecraft:water[level=0]
fill 392 57 -153 422 57 -153 minecraft:water[level=0]
fill 392 57 -154 398 57 -154 minecraft:water[level=0]
setblock 399 57 -154 minecraft:kelp_plant
fill 400 57 -154 422 57 -154 minecraft:water[level=0]
fill 392 57 -155 395 57 -155 minecraft:water[level=0]
setblock 396 57 -155 minecraft:kelp_plant
fill 397 57 -155 422 57 -155 minecraft:water[level=0]
setblock 392 57 -156 minecraft:kelp_plant
fill 393 57 -156 396 57 -156 minecraft:water[level=0]
fill 397 57 -156 399 57 -156 minecraft:kelp_plant
fill 400 57 -156 422 57 -156 minecraft:water[level=0]
fill 392 57 -157 394 57 -157 minecraft:water[level=0]
setblock 395 57 -157 minecraft:kelp_plant
fill 396 57 -157 397 57 -157 minecraft:water[level=0]
setblock 398 57 -157 minecraft:kelp_plant
fill 399 57 -157 422 57 -157 minecraft:water[level=0]
fill 392 57 -158 393 57 -158 minecraft:water[level=0]
setblock 394 57 -158 minecraft:kelp[age=25]
fill 395 57 -158 422 57 -158 minecraft:water[level=0]
fill 392 57 -159 422 57 -159 minecraft:water[level=0]
fill 392 57 -160 396 57 -160 minecraft:water[level=0]
setblock 397 57 -160 minecraft:kelp_plant
fill 398 57 -160 422 57 -160 minecraft:water[level=0]
setblock 392 57 -161 minecraft:kelp_plant
fill 393 57 -161 396 57 -161 minecraft:water[level=0]
setblock 397 57 -161 minecraft:kelp_plant
setblock 398 57 -161 minecraft:water[level=0]
setblock 399 57 -161 minecraft:kelp_plant
fill 400 57 -161 422 57 -161 minecraft:water[level=0]
fill 392 57 -162 396 57 -162 minecraft:water[level=0]
setblock 397 57 -162 minecraft:kelp_plant
fill 398 57 -162 408 57 -162 minecraft:water[level=0]
setblock 409 57 -162 minecraft:tall_seagrass[half=upper]
fill 410 57 -162 422 57 -162 minecraft:water[level=0]
fill 392 57 -163 393 57 -163 minecraft:kelp_plant
fill 394 57 -163 401 57 -163 minecraft:water[level=0]
fill 403 57 -163 405 57 -163 minecraft:water[level=0]
fill 407 57 -163 408 57 -163 minecraft:water[level=0]
setblock 410 57 -163 minecraft:water[level=0]
setblock 411 57 -163 minecraft:seagrass
setblock 412 57 -163 minecraft:bubble_column[drag=true]
fill 414 57 -163 422 57 -163 minecraft:water[level=0]
fill 392 57 -164 422 57 -164 minecraft:water[level=0]
fill 392 57 -165 403 57 -165 minecraft:water[level=0]
setblock 405 57 -165 minecraft:tall_seagrass[half=upper]
fill 406 57 -165 410 57 -165 minecraft:water[level=0]
fill 412 57 -165 422 57 -165 minecraft:water[level=0]
fill 392 57 -166 394 57 -166 minecraft:water[level=0]
setblock 395 57 -166 minecraft:kelp_plant
fill 396 57 -166 422 57 -166 minecraft:water[level=0]
setblock 392 57 -167 minecraft:kelp_plant
setblock 393 57 -167 minecraft:water[level=0]
setblock 394 57 -167 minecraft:kelp_plant
fill 395 57 -167 398 57 -167 minecraft:water[level=0]
setblock 399 57 -167 minecraft:kelp_plant
fill 400 57 -167 401 57 -167 minecraft:water[level=0]
fill 403 57 -167 412 57 -167 minecraft:water[level=0]
fill 414 57 -167 422 57 -167 minecraft:water[level=0]
fill 392 57 -168 395 57 -168 minecraft:water[level=0]
setblock 396 57 -168 minecraft:kelp_plant
setblock 397 57 -168 minecraft:water[level=0]
setblock 398 57 -168 minecraft:kelp_plant
fill 399 57 -168 406 57 -168 minecraft:water[level=0]
setblock 407 57 -168 minecraft:tall_seagrass[half=upper]
setblock 408 57 -168 minecraft:bubble_column[drag=true]
fill 409 57 -168 412 57 -168 minecraft:water[level=0]
fill 414 57 -168 422 57 -168 minecraft:water[level=0]
setblock 392 57 -169 minecraft:kelp[age=25]
setblock 393 57 -169 minecraft:kelp_plant
fill 394 57 -169 422 57 -169 minecraft:water[level=0]
fill 392 57 -170 398 57 -170 minecraft:water[level=0]
setblock 399 57 -170 minecraft:kelp_plant
fill 400 57 -170 401 57 -170 minecraft:water[level=0]
fill 403 57 -170 411 57 -170 minecraft:water[level=0]
fill 414 57 -170 418 57 -170 minecraft:water[level=0]
setblock 419 57 -170 minecraft:stone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=true]
setblock 420 57 -170 minecraft:stone_brick_stairs[facing=west,half=bottom,shape=straight,waterlogged=true]
fill 421 57 -170 422 57 -170 minecraft:water[level=0]
fill 392 57 -171 395 57 -171 minecraft:water[level=0]
setblock 396 57 -171 minecraft:kelp_plant
setblock 397 57 -171 minecraft:water[level=0]
setblock 398 57 -171 minecraft:kelp_plant
fill 399 57 -171 422 57 -171 minecraft:water[level=0]
setblock 392 57 -172 minecraft:kelp_plant
fill 393 57 -172 402 57 -172 minecraft:water[level=0]
setblock 403 57 -172 minecraft:bubble_column[drag=true]
fill 404 57 -172 409 57 -172 minecraft:water[level=0]
fill 413 57 -172 416 57 -172 minecraft:water[level=0]
setblock 417 57 -172 minecraft:stone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=true]
fill 418 57 -172 421 57 -172 minecraft:water[level=0]
setblock 422 57 -172 minecraft:stone_brick_stairs[facing=north,half=bottom,shape=straight,waterlogged=true]
setblock 392 57 -173 minecraft:kelp_plant
fill 393 57 -173 410 57 -173 minecraft:water[level=0]
fill 412 57 -173 416 57 -173 minecraft:water[level=0]
setblock 417 57 -173 minecraft:stone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=true]
fill 418 57 -173 421 57 -173 minecraft:water[level=0]
setblock 422 57 -173 minecraft:stone_brick_stairs[facing=south,half=bottom,shape=straight,waterlogged=true]
fill 392 57 -174 393 57 -174 minecraft:water[level=0]
setblock 394 57 -174 minecraft:kelp[age=25]
fill 395 57 -174 396 57 -174 minecraft:water[level=0]
fill 397 57 -174 398 57 -174 minecraft:kelp_plant
fill 399 57 -174 401 57 -174 minecraft:water[level=0]
fill 403 57 -174 405 57 -174 minecraft:water[level=0]
fill 407 57 -174 408 57 -174 minecraft:water[level=0]
fill 410 57 -174 411 57 -174 minecraft:water[level=0]
fill 415 57 -174 422 57 -174 minecraft:water[level=0]
fill 392 57 -175 398 57 -175 minecraft:water[level=0]
setblock 399 57 -175 minecraft:kelp_plant
fill 400 57 -175 412 57 -175 minecraft:water[level=0]
fill 414 57 -175 418 57 -175 minecraft:water[level=0]
setblock 419 57 -175 minecraft:stone_brick_stairs[facing=east,half=bottom,shape=straight,waterlogged=true]
fill 420 57 -175 422 57 -175 minecraft:water[level=0]
fill 392 57 -176 398 57 -176 minecraft:water[level=0]
setblock 399 57 -176 minecraft:kelp_plant
fill 400 57 -176 422 57 -176 minecraft:water[level=0]
setblock 392 57 -177 minecraft:water[level=0]
setblock 393 57 -177 minecraft:kelp_plant
fill 394 57 -177 397 57 -177 minecraft:water[level=0]
setblock 398 57 -177 minecraft:kelp_plant
fill 399 57 -177 422 57 -177 minecraft:water[level=0]
setblock 392 57 -178 minecraft:kelp_plant
fill 393 57 -178 422 57 -178 minecraft:water[level=0]
fill 392 57 -179 393 57 -179 minecraft:water[level=0]
setblock 394 57 -179 minecraft:kelp[age=25]
fill 395 57 -179 422 57 -179 minecraft:water[level=0]
fill 392 57 -180 397 57 -180 minecraft:water[level=0]
setblock 398 57 -180 minecraft:kelp_plant
fill 399 57 -180 422 57 -180 minecraft:water[level=0]
fill 392 57 -181 396 57 -181 minecraft:water[level=0]
setblock 397 57 -181 minecraft:kelp_plant
setblock 398 57 -181 minecraft:water[level=0]
setblock 399 57 -181 minecraft:kelp_plant
fill 400 57 -181 422 57 -181 minecraft:water[level=0]
fill 392 57 -182 422 57 -182 minecraft:water[level=0]
fill 392 57 -183 422 57 -183 minecraft:water[level=0]
fill 392 57 -184 393 57 -184 minecraft:water[level=0]
fill 394 57 -184 395 57 -184 minecraft:kelp_plant
fill 396 57 -184 412 57 -184 minecraft:water[level=0]
setblock 413 57 -184 minecraft:kelp_plant
fill 414 57 -184 422 57 -184 minecraft:water[level=0]
fill 392 57 -185 394 57 -185 minecraft:water[level=0]
fill 395 57 -185 396 57 -185 minecraft:kelp_plant
setblock 397 57 -185 minecraft:water[level=0]
fill 398 57 -185 399 57 -185 minecraft:kelp_plant
fill 400 57 -185 418 57 -185 minecraft:water[level=0]
fill 420 57 -185 422 57 -185 minecraft:water[level=0]
fill 392 57 -186 398 57 -186 minecraft:water[level=0]
setblock 399 57 -186 minecraft:kelp_plant
fill 400 57 -186 416 57 -186 minecraft:water[level=0]
setblock 417 57 -186 minecraft:kelp_plant
setblock 418 57 -186 minecraft:water[level=0]
fill 420 57 -186 422 57 -186 minecraft:water[level=0]
fill 392 57 -187 397 57 -187 minecraft:water[level=0]
setblock 398 57 -187 minecraft:kelp_plant
fill 399 57 -187 400 57 -187 minecraft:water[level=0]
setblock 401 57 -187 minecraft:kelp_plant
fill 402 57 -187 405 57 -187 minecraft:water[level=0]
fill 407 57 -187 418 57 -187 minecraft:water[level=0]
fill 420 57 -187 422 57 -187 minecraft:water[level=0]
fill 392 57 -188 404 57 -188 minecraft:water[level=0]
fill 407 57 -188 411 57 -188 minecraft:water[level=0]
setblock 412 57 -188 minecraft:kelp_plant
fill 413 57 -188 418 57 -188 minecraft:water[level=0]
setblock 420 57 -188 minecraft:kelp_plant
setblock 421 57 -188 minecraft:bubble_column[drag=true]
setblock 422 57 -188 minecraft:water[level=0]
fill 392 57 -189 403 57 -189 minecraft:water[level=0]
fill 406 57 -189 422 57 -189 minecraft:water[level=0]
fill 392 57 -190 396 57 -190 minecraft:water[level=0]
setblock 397 57 -190 minecraft:kelp_plant
fill 398 57 -190 410 57 -190 minecraft:water[level=0]
setblock 411 57 -190 minecraft:kelp_plant
fill 412 57 -190 418 57 -190 minecraft:water[level=0]
fill 420 57 -190 422 57 -190 minecraft:water[level=0]
fill 392 56 -127 395 56 -127 minecraft:water[level=0]
setblock 396 56 -127 minecraft:kelp_plant
fill 397 56 -127 402 56 -127 minecraft:water[level=0]
setblock 403 56 -127 minecraft:kelp_plant
fill 404 56 -127 411 56 -127 minecraft:water[level=0]
fill 392 56 -128 393 56 -128 minecraft:water[level=0]
setblock 394 56 -128 minecraft:kelp[age=25]
fill 395 56 -128 398 56 -128 minecraft:water[level=0]
setblock 399 56 -128 minecraft:kelp_plant
fill 400 56 -128 402 56 -128 minecraft:water[level=0]
setblock 403 56 -128 minecraft:kelp[age=25]
fill 404 56 -128 412 56 -128 minecraft:water[level=0]
fill 392 56 -129 393 56 -129 minecraft:water[level=0]
setblock 394 56 -129 minecraft:kelp_plant
fill 395 56 -129 413 56 -129 minecraft:water[level=0]
fill 392 56 -130 396 56 -130 minecraft:water[level=0]
setblock 397 56 -130 minecraft:kelp_plant
fill 398 56 -130 414 56 -130 minecraft:water[level=0]
setblock 392 56 -131 minecraft:water[level=0]
setblock 393 56 -131 minecraft:kelp_plant
fill 394 56 -131 415 56 -131 minecraft:water[level=0]
setblock 392 56 -132 minecraft:kelp_plant
fill 393 56 -132 415 56 -132 minecraft:water[level=0]
setblock 392 56 -133 minecraft:water[level=0]
setblock 393 56 -133 minecraft:kelp_plant
fill 394 56 -133 416 56 -133 minecraft:water[level=0]
fill 392 56 -134 393 56 -134 minecraft:water[level=0]
setblock 394 56 -134 minecraft:kelp[age=25]
fill 395 56 -134 397 56 -134 minecraft:water[level=0]
fill 398 56 -134 399 56 -134 minecraft:kelp_plant
fill 400 56 -134 417 56 -134 minecraft:water[level=0]
fill 392 56 -135 417 56 -135 minecraft:water[level=0]
fill 392 56 -136 418 56 -136 minecraft:water[level=0]
fill 392 56 -137 394 56 -137 minecraft:water[level=0]
setblock 395 56 -137 minecraft:kelp_plant
fill 396 56 -137 418 56 -137 minecraft:water[level=0]
fill 392 56 -138 419 56 -138 minecraft:water[level=0]
fill 392 56 -139 398 56 -139 minecraft:water[level=0]
setblock 399 56 -139 minecraft:kelp_plant
fill 400 56 -139 419 56 -139 minecraft:water[level=0]
setblock 392 56 -140 minecraft:kelp_plant
fill 393 56 -140 419 56 -140 minecraft:water[level=0]
fill 392 56 -141 396 56 -141 minecraft:water[level=0]
setblock 397 56 -141 minecraft:kelp_plant
fill 398 56 -141 420 56 -141 minecraft:water[level=0]
fill 392 56 -142 397 56 -142 minecraft:water[level=0]
setblock 398 56 -142 minecraft:kelp_plant
fill 399 56 -142 420 56 -142 minecraft:water[level=0]
setblock 392 56 -143 minecraft:water[level=0]
setblock 393 56 -143 minecraft:kelp_plant
fill 394 56 -143 420 56 -143 minecraft:water[level=0]
fill 392 56 -144 421 56 -144 minecraft:water[level=0]
fill 392 56 -145 398 56 -145 minecraft:water[level=0]
setblock 399 56 -145 minecraft:kelp_plant
fill 400 56 -145 421 56 -145 minecraft:water[level=0]
fill 392 56 -146 394 56 -146 minecraft:water[level=0]
setblock 395 56 -146 minecraft:kelp_plant
fill 396 56 -146 397 56 -146 minecraft:water[level=0]
fill 398 56 -146 399 56 -146 minecraft:kelp_plant
fill 400 56 -146 421 56 -146 minecraft:water[level=0]
setblock 392 56 -147 minecraft:water[level=0]
setblock 393 56 -147 minecraft:kelp_plant
fill 394 56 -147 396 56 -147 minecraft:water[level=0]
setblock 397 56 -147 minecraft:kelp_plant
fill 398 56 -147 421 56 -147 minecraft:water[level=0]
setblock 392 56 -148 minecraft:water[level=0]
setblock 393 56 -148 minecraft:kelp_plant
fill 394 56 -148 395 56 -148 minecraft:water[level=0]
setblock 396 56 -148 minecraft:kelp[age=25]
fill 397 56 -148 421 56 -148 minecraft:water[level=0]
fill 392 56 -149 393 56 -149 minecraft:water[level=0]
setblock 394 56 -149 minecraft:kelp_plant
fill 395 56 -149 397 56 -149 minecraft:water[level=0]
setblock 398 56 -149 minecraft:kelp_plant
fill 399 56 -149 421 56 -149 minecraft:water[level=0]
setblock 392 56 -150 minecraft:kelp_plant
setblock 393 56 -150 minecraft:water[level=0]
setblock 394 56 -150 minecraft:kelp_plant
fill 395 56 -150 421 56 -150 minecraft:water[level=0]
fill 392 56 -151 398 56 -151 minecraft:water[level=0]
setblock 399 56 -151 minecraft:kelp_plant
fill 400 56 -151 421 56 -151 minecraft:water[level=0]
fill 392 56 -152 396 56 -152 minecraft:water[level=0]
setblock 397 56 -152 minecraft:kelp[age=25]
setblock 398 56 -152 minecraft:water[level=0]
setblock 399 56 -152 minecraft:kelp_plant
fill 400 56 -152 422 56 -152 minecraft:water[level=0]
fill 392 56 -153 422 56 -153 minecraft:water[level=0]
fill 392 56 -154 395 56 -154 minecraft:water[level=0]
setblock 396 56 -154 minecraft:kelp[age=25]
fill 397 56 -154 398 56 -154 minecraft:water[level=0]
setblock 399 56 -154 minecraft:kelp_plant
fill 400 56 -154 422 56 -154 minecraft:water[level=0]
fill 392 56 -155 395 56 -155 minecraft:water[level=0]
setblock 396 56 -155 minecraft:kelp_plant
fill 397 56 -155 422 56 -155 minecraft:water[level=0]
setblock 392 56 -156 minecraft:kelp_plant
fill 393 56 -156 396 56 -156 minecraft:water[level=0]
fill 397 56 -156 399 56 -156 minecraft:kelp_plant
fill 400 56 -156 422 56 -156 minecraft:water[level=0]
fill 392 56 -157 394 56 -157 minecraft:water[level=0]
setblock 395 56 -157 minecraft:kelp_plant
fill 396 56 -157 397 56 -157 minecraft:water[level=0]
setblock 398 56 -157 minecraft:kelp_plant
fill 399 56 -157 422 56 -157 minecraft:water[level=0]
fill 392 56 -158 393 56 -158 minecraft:water[level=0]
setblock 394 56 -158 minecraft:kelp_plant
fill 395 56 -158 422 56 -158 minecraft:water[level=0]
fill 392 56 -159 422 56 -159 minecraft:water[level=0]
fill 392 56 -160 396 56 -160 minecraft:water[level=0]
setblock 397 56 -160 minecraft:kelp_plant
fill 398 56 -160 422 56 -160 minecraft:water[level=0]
setblock 392 56 -161 minecraft:kelp_plant
fill 393 56 -161 396 56 -161 minecraft:water[level=0]
setblock 397 56 -161 minecraft:kelp_plant
setblock 398 56 -161 minecraft:water[level=0]
setblock 399 56 -161 minecraft:kelp_plant
fill 400 56 -161 422 56 -161 minecraft:water[level=0]
setblock 392 56 -162 minecraft:water[level=0]
setblock 393 56 -162 minecraft:kelp[age=25]
fill 394 56 -162 396 56 -162 minecraft:water[level=0]
setblock 397 56 -162 minecraft:kelp_plant
fill 398 56 -162 405 56 -162 minecraft:water[level=0]
setblock 406 56 -162 minecraft:seagrass
fill 407 56 -162 408 56 -162 minecraft:water[level=0]
setblock 409 56 -162 minecraft:tall_seagrass[half=lower]
fill 410 56 -162 422 56 -162 minecraft:water[level=0]
fill 392 56 -163 393 56 -163 minecraft:kelp_plant
fill 394 56 -163 401 56 -163 minecraft:water[level=0]
setblock 403 56 -163 minecraft:water[level=0]
setblock 404 56 -163 minecraft:tall_seagrass[half=upper]
setblock 405 56 -163 minecraft:water[level=0]
setblock 407 56 -163 minecraft:tall_seagrass[half=upper]
setblock 408 56 -163 minecraft:water[level=0]
setblock 410 56 -163 minecraft:water[level=0]
setblock 412 56 -163 minecraft:bubble_column[drag=true]
fill 414 56 -163 422 56 -163 minecraft:water[level=0]
fill 392 56 -164 405 56 -164 minecraft:water[level=0]
setblock 406 56 -164 minecraft:seagrass
fill 407 56 -164 422 56 -164 minecraft:water[level=0]
fill 392 56 -165 403 56 -165 minecraft:water[level=0]
setblock 405 56 -165 minecraft:tall_seagrass[half=lower]
fill 406 56 -165 408 56 -165 minecraft:water[level=0]
setblock 409 56 -165 minecraft:seagrass
setblock 410 56 -165 minecraft:water[level=0]
fill 412 56 -165 422 56 -165 minecraft:water[level=0]
fill 392 56 -166 394 56 -166 minecraft:water[level=0]
setblock 395 56 -166 minecraft:kelp_plant
fill 396 56 -166 402 56 -166 minecraft:water[level=0]
setblock 403 56 -166 minecraft:tall_seagrass[half=upper]
fill 405 56 -166 406 56 -166 minecraft:water[level=0]
setblock 407 56 -166 minecraft:tall_seagrass[half=upper]
fill 408 56 -166 422 56 -166 minecraft:water[level=0]
setblock 392 56 -167 minecraft:kelp_plant
setblock 393 56 -167 minecraft:water[level=0]
setblock 394 56 -167 minecraft:kelp_plant
fill 395 56 -167 398 56 -167 minecraft:water[level=0]
setblock 399 56 -167 minecraft:kelp_plant
fill 400 56 -167 412 56 -167 minecraft:water[level=0]
fill 414 56 -167 422 56 -167 minecraft:water[level=0]
fill 392 56 -168 395 56 -168 minecraft:water[level=0]
setblock 396 56 -168 minecraft:kelp_plant
setblock 397 56 -168 minecraft:water[level=0]
setblock 398 56 -168 minecraft:kelp_plant
fill 399 56 -168 406 56 -168 minecraft:water[level=0]
setblock 407 56 -168 minecraft:tall_seagrass[half=lower]
setblock 408 56 -168 minecraft:bubble_column[drag=true]
fill 409 56 -168 422 56 -168 minecraft:water[level=0]
fill 392 56 -169 393 56 -169 minecraft:kelp_plant
fill 394 56 -169 422 56 -169 minecraft:water[level=0]
fill 392 56 -170 398 56 -170 minecraft:water[level=0]
setblock 399 56 -170 minecraft:kelp_plant
fill 400 56 -170 412 56 -170 minecraft:water[level=0]
fill 414 56 -170 417 56 -170 minecraft:water[level=0]
fill 418 56 -170 421 56 -170 minecraft:stone_brick_stairs[facing=north,half=top,shape=straight,waterlogged=true]
setblock 422 56 -170 minecraft:water[level=0]
fill 392 56 -171 395 56 -171 minecraft:water[level=0]
setblock 396 56 -171 minecraft:kelp_plant
setblock 397 56 -171 minecraft:water[level=0]
setblock 398 56 -171 minecraft:kelp_plant
fill 399 56 -171 402 56 -171 minecraft:water[level=0]
fill 404 56 -171 417 56 -171 minecraft:water[level=0]
setblock 422 56 -171 minecraft:stone_brick_stairs[facing=west,half=top,shape=straight,waterlogged=true]
setblock 392 56 -172 minecraft:kelp_plant
fill 393 56 -172 401 56 -172 minecraft:water[level=0]
setblock 403 56 -172 minecraft:bubble_column[drag=true]
fill 405 56 -172 417 56 -172 minecraft:water[level=0]
setblock 419 56 -172 minecraft:water[level=0]
setblock 422 56 -172 minecraft:stone_brick_stairs[facing=west,half=top,shape=straight,waterlogged=true]
setblock 392 56 -173 minecraft:kelp_plant
fill 393 56 -173 416 56 -173 minecraft:water[level=0]
setblock 417 56 -173 minecraft:stone_brick_stairs[facing=east,half=top,shape=straight,waterlogged=true]
setblock 422 56 -173 minecraft:stone_brick_stairs[facing=west,half=top,shape=straight,waterlogged=true]
fill 392 56 -174 393 56 -174 minecraft:water[level=0]
setblock 394 56 -174 minecraft:kelp_plant
fill 395 56 -174 396 56 -174 minecraft:water[level=0]
fill 397 56 -174 398 56 -174 minecraft:kelp_plant
fill 399 56 -174 401 56 -174 minecraft:water[level=0]
fill 403 56 -174 405 56 -174 minecraft:water[level=0]
fill 407 56 -174 408 56 -174 minecraft:water[level=0]
fill 410 56 -174 412 56 -174 minecraft:water[level=0]
fill 414 56 -174 416 56 -174 minecraft:water[level=0]
setblock 417 56 -174 minecraft:stone_brick_stairs[facing=east,half=top,shape=straight,waterlogged=true]
setblock 422 56 -174 minecraft:stone_brick_stairs[facing=west,half=top,shape=straight,waterlogged=true]
fill 392 56 -175 394 56 -175 minecraft:water[level=0]
setblock 395 56 -175 minecraft:kelp[age=25]
fill 396 56 -175 398 56 -175 minecraft:water[level=0]
setblock 399 56 -175 minecraft:kelp_plant
fill 400 56 -175 411 56 -175 minecraft:water[level=0]
fill 413 56 -175 417 56 -175 minecraft:water[level=0]
fill 418 56 -175 421 56 -175 minecraft:stone_brick_stairs[facing=south,half=top,shape=straight,waterlogged=true]
setblock 422 56 -175 minecraft:water[level=0]
fill 392 56 -176 398 56 -176 minecraft:water[level=0]
setblock 399 56 -176 minecraft:kelp_plant
fill 400 56 -176 422 56 -176 minecraft:water[level=0]
setblock 392 56 -177 minecraft:water[level=0]
setblock 393 56 -177 minecraft:kelp_plant
fill 394 56 -177 397 56 -177 minecraft:water[level=0]
setblock 398 56 -177 minecraft:kelp_plant
fill 399 56 -177 422 56 -177 minecraft:water[level=0]
setblock 392 56 -178 minecraft:kelp_plant
fill 393 56 -178 422 56 -178 minecraft:water[level=0]
fill 392 56 -179 393 56 -179 minecraft:water[level=0]
setblock 394 56 -179 minecraft:kelp_plant
fill 395 56 -179 422 56 -179 minecraft:water[level=0]
fill 392 56 -180 397 56 -180 minecraft:water[level=0]
setblock 398 56 -180 minecraft:kelp_plant
fill 399 56 -180 422 56 -180 minecraft:water[level=0]
fill 392 56 -181 396 56 -181 minecraft:water[level=0]
setblock 397 56 -181 minecraft:kelp_plant
setblock 398 56 -181 minecraft:water[level=0]
setblock 399 56 -181 minecraft:kelp_plant
fill 400 56 -181 422 56 -181 minecraft:water[level=0]
fill 392 56 -182 422 56 -182 minecraft:water[level=0]
fill 392 56 -183 422 56 -183 minecraft:water[level=0]
fill 392 56 -184 393 56 -184 minecraft:water[level=0]
fill 394 56 -184 395 56 -184 minecraft:kelp_plant
fill 396 56 -184 412 56 -184 minecraft:water[level=0]
setblock 413 56 -184 minecraft:kelp_plant
fill 414 56 -184 422 56 -184 minecraft:water[level=0]
fill 392 56 -185 394 56 -185 minecraft:water[level=0]
fill 395 56 -185 396 56 -185 minecraft:kelp_plant
setblock 397 56 -185 minecraft:water[level=0]
fill 398 56 -185 399 56 -185 minecraft:kelp_plant
fill 400 56 -185 413 56 -185 minecraft:water[level=0]
setblock 414 56 -185 minecraft:kelp[age=25]
fill 415 56 -185 422 56 -185 minecraft:water[level=0]
fill 392 56 -186 398 56 -186 minecraft:water[level=0]
setblock 399 56 -186 minecraft:kelp_plant
fill 400 56 -186 416 56 -186 minecraft:water[level=0]
setblock 417 56 -186 minecraft:kelp_plant
setblock 418 56 -186 minecraft:water[level=0]
fill 420 56 -186 422 56 -186 minecraft:water[level=0]
fill 392 56 -187 397 56 -187 minecraft:water[level=0]
setblock 398 56 -187 minecraft:kelp_plant
fill 399 56 -187 400 56 -187 minecraft:water[level=0]
setblock 401 56 -187 minecraft:kelp_plant
fill 402 56 -187 404 56 -187 minecraft:water[level=0]
fill 409 56 -187 422 56 -187 minecraft:water[level=0]
fill 392 56 -188 404 56 -188 minecraft:water[level=0]
fill 406 56 -188 409 56 -188 minecraft:water[level=0]
setblock 411 56 -188 minecraft:water[level=0]
setblock 412 56 -188 minecraft:kelp_plant
fill 413 56 -188 419 56 -188 minecraft:water[level=0]
setblock 420 56 -188 minecraft:kelp_plant
setblock 421 56 -188 minecraft:bubble_column[drag=true]
setblock 422 56 -188 minecraft:water[level=0]
fill 392 56 -189 403 56 -189 minecraft:water[level=0]
fill 405 56 -189 418 56 -189 minecraft:water[level=0]
fill 420 56 -189 422 56 -189 minecraft:water[level=0]
fill 392 56 -190 396 56 -190 minecraft:water[level=0]
setblock 397 56 -190 minecraft:kelp_plant
fill 398 56 -190 403 56 -190 minecraft:water[level=0]
fill 405 56 -190 409 56 -190 minecraft:water[level=0]
setblock 411 56 -190 minecraft:kelp_plant
fill 412 56 -190 422 56 -190 minecraft:water[level=0]
fill 392 55 -127 395 55 -127 minecraft:water[level=0]
setblock 396 55 -127 minecraft:kelp_plant
fill 397 55 -127 402 55 -127 minecraft:water[level=0]
setblock 403 55 -127 minecraft:kelp_plant
fill 404 55 -127 411 55 -127 minecraft:water[level=0]
fill 392 55 -128 393 55 -128 minecraft:water[level=0]
setblock 394 55 -128 minecraft:kelp_plant
fill 395 55 -128 398 55 -128 minecraft:water[level=0]
setblock 399 55 -128 minecraft:kelp_plant
fill 400 55 -128 402 55 -128 minecraft:water[level=0]
setblock 403 55 -128 minecraft:kelp_plant
fill 404 55 -128 412 55 -128 minecraft:water[level=0]
fill 392 55 -129 393 55 -129 minecraft:water[level=0]
setblock 394 55 -129 minecraft:kelp_plant
fill 395 55 -129 413 55 -129 minecraft:water[level=0]
fill 392 55 -130 396 55 -130 minecraft:water[level=0]
setblock 397 55 -130 minecraft:kelp_plant
fill 398 55 -130 414 55 -130 minecraft:water[level=0]
setblock 392 55 -131 minecraft:water[level=0]
setblock 393 55 -131 minecraft:kelp_plant
fill 394 55 -131 415 55 -131 minecraft:water[level=0]
setblock 392 55 -132 minecraft:kelp_plant
fill 393 55 -132 415 55 -132 minecraft:water[level=0]
setblock 392 55 -133 minecraft:water[level=0]
setblock 393 55 -133 minecraft:kelp_plant
fill 394 55 -133 416 55 -133 minecraft:water[level=0]
fill 392 55 -134 393 55 -134 minecraft:water[level=0]
setblock 394 55 -134 minecraft:kelp_plant
fill 395 55 -134 397 55 -134 minecraft:water[level=0]
fill 398 55 -134 399 55 -134 minecraft:kelp_plant
fill 400 55 -134 417 55 -134 minecraft:water[level=0]
fill 392 55 -135 417 55 -135 minecraft:water[level=0]
fill 392 55 -136 418 55 -136 minecraft:water[level=0]
fill 392 55 -137 394 55 -137 minecraft:water[level=0]
setblock 395 55 -137 minecraft:kelp_plant
fill 396 55 -137 418 55 -137 minecraft:water[level=0]
fill 392 55 -138 419 55 -138 minecraft:water[level=0]
fill 392 55 -139 398 55 -139 minecraft:water[level=0]
setblock 399 55 -139 minecraft:kelp_plant
fill 400 55 -139 419 55 -139 minecraft:water[level=0]
setblock 392 55 -140 minecraft:kelp_plant
fill 393 55 -140 419 55 -140 minecraft:water[level=0]
fill 392 55 -141 396 55 -141 minecraft:water[level=0]
setblock 397 55 -141 minecraft:kelp_plant
fill 398 55 -141 420 55 -141 minecraft:water[level=0]
fill 392 55 -142 397 55 -142 minecraft:water[level=0]
setblock 398 55 -142 minecraft:kelp_plant
fill 399 55 -142 420 55 -142 minecraft:water[level=0]
setblock 392 55 -143 minecraft:water[level=0]
setblock 393 55 -143 minecraft:kelp_plant
fill 394 55 -143 420 55 -143 minecraft:water[level=0]
setblock 392 55 -144 minecraft:water[level=0]
setblock 393 55 -144 minecraft:kelp[age=25]
fill 394 55 -144 421 55 -144 minecraft:water[level=0]
fill 392 55 -145 398 55 -145 minecraft:water[level=0]
setblock 399 55 -145 minecraft:kelp_plant
fill 400 55 -145 421 55 -145 minecraft:water[level=0]
fill 392 55 -146 394 55 -146 minecraft:water[level=0]
setblock 395 55 -146 minecraft:kelp_plant
fill 396 55 -146 397 55 -146 minecraft:water[level=0]
fill 398 55 -146 399 55 -146 minecraft:kelp_plant
fill 400 55 -146 421 55 -146 minecraft:water[level=0]
setblock 392 55 -147 minecraft:water[level=0]
setblock 393 55 -147 minecraft:kelp_plant
fill 394 55 -147 396 55 -147 minecraft:water[level=0]
setblock 397 55 -147 minecraft:kelp_plant
fill 398 55 -147 421 55 -147 minecraft:water[level=0]
setblock 392 55 -148 minecraft:kelp[age=25]
setblock 393 55 -148 minecraft:kelp_plant
fill 394 55 -148 395 55 -148 minecraft:water[level=0]
setblock 396 55 -148 minecraft:kelp_plant
fill 397 55 -148 421 55 -148 minecraft:water[level=0]
fill 392 55 -149 393 55 -149 minecraft:water[level=0]
setblock 394 55 -149 minecraft:kelp_plant
fill 395 55 -149 397 55 -149 minecraft:water[level=0]
setblock 398 55 -149 minecraft:kelp_plant
fill 399 55 -149 421 55 -149 minecraft:water[level=0]
setblock 392 55 -150 minecraft:kelp_plant
setblock 393 55 -150 minecraft:water[level=0]
setblock 394 55 -150 minecraft:kelp_plant
fill 395 55 -150 421 55 -150 minecraft:water[level=0]
fill 392 55 -151 398 55 -151 minecraft:water[level=0]
setblock 399 55 -151 minecraft:kelp_plant
fill 400 55 -151 421 55 -151 minecraft:water[level=0]
fill 392 55 -152 396 55 -152 minecraft:water[level=0]
setblock 397 55 -152 minecraft:kelp_plant
setblock 398 55 -152 minecraft:water[level=0]
setblock 399 55 -152 minecraft:kelp_plant
fill 400 55 -152 422 55 -152 minecraft:water[level=0]
fill 392 55 -153 422 55 -153 minecraft:water[level=0]
fill 392 55 -154 395 55 -154 minecraft:water[level=0]
setblock 396 55 -154 minecraft:kelp_plant
fill 397 55 -154 398 55 -154 minecraft:water[level=0]
setblock 399 55 -154 minecraft:kelp_plant
fill 400 55 -154 422 55 -154 minecraft:water[level=0]
fill 392 55 -155 395 55 -155 minecraft:water[level=0]
setblock 396 55 -155 minecraft:kelp_plant
fill 397 55 -155 422 55 -155 minecraft:water[level=0]
setblock 392 55 -156 minecraft:kelp_plant
fill 393 55 -156 396 55 -156 minecraft:water[level=0]
fill 397 55 -156 399 55 -156 minecraft:kelp_plant
fill 400 55 -156 422 55 -156 minecraft:water[level=0]
fill 392 55 -157 394 55 -157 minecraft:water[level=0]
setblock 395 55 -157 minecraft:kelp_plant
fill 396 55 -157 397 55 -157 minecraft:water[level=0]
setblock 398 55 -157 minecraft:kelp_plant
fill 399 55 -157 422 55 -157 minecraft:water[level=0]
fill 392 55 -158 393 55 -158 minecraft:water[level=0]
setblock 394 55 -158 minecraft:kelp_plant
fill 395 55 -158 422 55 -158 minecraft:water[level=0]
fill 392 55 -159 396 55 -159 minecraft:water[level=0]
setblock 397 55 -159 minecraft:kelp[age=25]
fill 398 55 -159 422 55 -159 minecraft:water[level=0]
fill 392 55 -160 396 55 -160 minecraft:water[level=0]
setblock 397 55 -160 minecraft:kelp_plant
fill 398 55 -160 422 55 -160 minecraft:water[level=0]
setblock 392 55 -161 minecraft:kelp_plant
fill 393 55 -161 396 55 -161 minecraft:water[level=0]
setblock 397 55 -161 minecraft:kelp_plant
setblock 398 55 -161 minecraft:water[level=0]
setblock 399 55 -161 minecraft:kelp_plant
fill 400 55 -161 407 55 -161 minecraft:water[level=0]
setblock 408 55 -161 minecraft:seagrass
fill 409 55 -161 422 55 -161 minecraft:water[level=0]
setblock 392 55 -162 minecraft:water[level=0]
setblock 393 55 -162 minecraft:kelp_plant
fill 394 55 -162 396 55 -162 minecraft:water[level=0]
setblock 397 55 -162 minecraft:kelp_plant
fill 398 55 -162 401 55 -162 minecraft:water[level=0]
setblock 403 55 -162 minecraft:water[level=0]
setblock 405 55 -162 minecraft:water[level=0]
setblock 407 55 -162 minecraft:seagrass
setblock 408 55 -162 minecraft:water[level=0]
fill 411 55 -162 412 55 -162 minecraft:water[level=0]
fill 414 55 -162 422 55 -162 minecraft:water[level=0]
fill 392 55 -163 393 55 -163 minecraft:kelp_plant
fill 394 55 -163 400 55 -163 minecraft:water[level=0]
setblock 403 55 -163 minecraft:water[level=0]
setblock 404 55 -163 minecraft:tall_seagrass[half=lower]
setblock 407 55 -163 minecraft:tall_seagrass[half=lower]
setblock 408 55 -163 minecraft:seagrass
setblock 412 55 -163 minecraft:bubble_column[drag=true]
fill 415 55 -163 422 55 -163 minecraft:water[level=0]
fill 392 55 -164 401 55 -164 minecraft:water[level=0]
fill 402 55 -164 405 55 -164 minecraft:seagrass
fill 407 55 -164 410 55 -164 minecraft:water[level=0]
setblock 411 55 -164 minecraft:seagrass
fill 413 55 -164 422 55 -164 minecraft:water[level=0]
setblock 392 55 -165 minecraft:kelp[age=25]
fill 393 55 -165 403 55 -165 minecraft:water[level=0]
setblock 406 55 -165 minecraft:water[level=0]
fill 407 55 -165 408 55 -165 minecraft:seagrass
setblock 410 55 -165 minecraft:water[level=0]
fill 412 55 -165 422 55 -165 minecraft:water[level=0]
fill 392 55 -166 394 55 -166 minecraft:water[level=0]
setblock 395 55 -166 minecraft:kelp_plant
fill 396 55 -166 402 55 -166 minecraft:water[level=0]
setblock 403 55 -166 minecraft:tall_seagrass[half=lower]
fill 405 55 -166 406 55 -166 minecraft:water[level=0]
setblock 407 55 -166 minecraft:tall_seagrass[half=lower]
setblock 408 55 -166 minecraft:seagrass
fill 409 55 -166 422 55 -166 minecraft:water[level=0]
setblock 392 55 -167 minecraft:kelp_plant
setblock 393 55 -167 minecraft:water[level=0]
setblock 394 55 -167 minecraft:kelp_plant
fill 395 55 -167 398 55 -167 minecraft:water[level=0]
setblock 399 55 -167 minecraft:kelp_plant
setblock 400 55 -167 minecraft:water[level=0]
fill 403 55 -167 407 55 -167 minecraft:water[level=0]
fill 409 55 -167 410 55 -167 minecraft:water[level=0]
setblock 411 55 -167 minecraft:seagrass
setblock 412 55 -167 minecraft:water[level=0]
fill 415 55 -167 422 55 -167 minecraft:water[level=0]
setblock 392 55 -168 minecraft:water[level=0]
setblock 393 55 -168 minecraft:kelp[age=25]
fill 394 55 -168 395 55 -168 minecraft:water[level=0]
setblock 396 55 -168 minecraft:kelp_plant
setblock 397 55 -168 minecraft:water[level=0]
setblock 398 55 -168 minecraft:kelp_plant
fill 399 55 -168 406 55 -168 minecraft:water[level=0]
setblock 408 55 -168 minecraft:bubble_column[drag=true]
fill 411 55 -168 422 55 -168 minecraft:water[level=0]
fill 392 55 -169 393 55 -169 minecraft:kelp_plant
fill 394 55 -169 408 55 -169 minecraft:water[level=0]
fill 411 55 -169 422 55 -169 minecraft:water[level=0]
fill 392 55 -170 398 55 -170 minecraft:water[level=0]
setblock 399 55 -170 minecraft:kelp_plant
setblock 400 55 -170 minecraft:water[level=0]
setblock 403 55 -170 minecraft:water[level=0]
fill 405 55 -170 410 55 -170 minecraft:water[level=0]
fill 415 55 -170 422 55 -170 minecraft:water[level=0]
fill 392 55 -171 395 55 -171 minecraft:water[level=0]
setblock 396 55 -171 minecraft:kelp_plant
setblock 397 55 -171 minecraft:water[level=0]
setblock 398 55 -171 minecraft:kelp_plant
fill 399 55 -171 402 55 -171 minecraft:water[level=0]
setblock 405 55 -171 minecraft:water[level=0]
setblock 407 55 -171 minecraft:water[level=0]
fill 409 55 -171 417 55 -171 minecraft:water[level=0]
setblock 422 55 -171 minecraft:water[level=0]
setblock 392 55 -172 minecraft:kelp_plant
fill 393 55 -172 400 55 -172 minecraft:water[level=0]
setblock 403 55 -172 minecraft:bubble_column[drag=true]
setblock 406 55 -172 minecraft:water[level=0]
fill 408 55 -172 409 55 -172 minecraft:water[level=0]
fill 411 55 -172 417 55 -172 minecraft:water[level=0]
fill 419 55 -172 420 55 -172 minecraft:water[level=0]
setblock 422 55 -172 minecraft:water[level=0]
setblock 392 55 -173 minecraft:kelp_plant
fill 393 55 -173 400 55 -173 minecraft:water[level=0]
setblock 402 55 -173 minecraft:water[level=8]
setblock 403 55 -173 minecraft:water[level=0]
fill 406 55 -173 417 55 -173 minecraft:water[level=0]
fill 419 55 -173 420 55 -173 minecraft:water[level=0]
setblock 422 55 -173 minecraft:water[level=0]
fill 392 55 -174 393 55 -174 minecraft:water[level=0]
setblock 394 55 -174 minecraft:kelp_plant
fill 395 55 -174 396 55 -174 minecraft:water[level=0]
fill 397 55 -174 398 55 -174 minecraft:kelp_plant
fill 399 55 -174 401 55 -174 minecraft:water[level=0]
fill 407 55 -174 412 55 -174 minecraft:water[level=0]
fill 415 55 -174 417 55 -174 minecraft:water[level=0]
fill 421 55 -174 422 55 -174 minecraft:water[level=0]
fill 392 55 -175 394 55 -175 minecraft:water[level=0]
setblock 395 55 -175 minecraft:kelp_plant
fill 396 55 -175 398 55 -175 minecraft:water[level=0]
setblock 399 55 -175 minecraft:kelp_plant
fill 400 55 -175 401 55 -175 minecraft:water[level=0]
setblock 403 55 -175 minecraft:water[level=0]
setblock 405 55 -175 minecraft:water[level=0]
setblock 407 55 -175 minecraft:water[level=0]
fill 410 55 -175 411 55 -175 minecraft:water[level=0]
fill 414 55 -175 422 55 -175 minecraft:water[level=0]
fill 392 55 -176 398 55 -176 minecraft:water[level=0]
setblock 399 55 -176 minecraft:kelp_plant
fill 400 55 -176 410 55 -176 minecraft:water[level=0]
fill 412 55 -176 422 55 -176 minecraft:water[level=0]
setblock 392 55 -177 minecraft:water[level=0]
setblock 393 55 -177 minecraft:kelp_plant
fill 394 55 -177 397 55 -177 minecraft:water[level=0]
setblock 398 55 -177 minecraft:kelp_plant
fill 399 55 -177 422 55 -177 minecraft:water[level=0]
setblock 392 55 -178 minecraft:kelp_plant
fill 393 55 -178 422 55 -178 minecraft:water[level=0]
fill 392 55 -179 393 55 -179 minecraft:water[level=0]
setblock 394 55 -179 minecraft:kelp_plant
fill 395 55 -179 422 55 -179 minecraft:water[level=0]
fill 392 55 -180 397 55 -180 minecraft:water[level=0]
setblock 398 55 -180 minecraft:kelp_plant
fill 399 55 -180 422 55 -180 minecraft:water[level=0]
fill 392 55 -181 396 55 -181 minecraft:water[level=0]
setblock 397 55 -181 minecraft:kelp_plant
setblock 398 55 -181 minecraft:water[level=0]
setblock 399 55 -181 minecraft:kelp_plant
fill 400 55 -181 422 55 -181 minecraft:water[level=0]
fill 392 55 -182 422 55 -182 minecraft:water[level=0]
fill 392 55 -183 422 55 -183 minecraft:water[level=0]
fill 392 55 -184 393 55 -184 minecraft:water[level=0]
fill 394 55 -184 395 55 -184 minecraft:kelp_plant
fill 396 55 -184 412 55 -184 minecraft:water[level=0]
setblock 413 55 -184 minecraft:kelp_plant
fill 414 55 -184 422 55 -184 minecraft:water[level=0]
fill 392 55 -185 394 55 -185 minecraft:water[level=0]
fill 395 55 -185 396 55 -185 minecraft:kelp_plant
setblock 397 55 -185 minecraft:water[level=0]
fill 398 55 -185 399 55 -185 minecraft:kelp_plant
fill 400 55 -185 413 55 -185 minecraft:water[level=0]
setblock 414 55 -185 minecraft:kelp_plant
fill 415 55 -185 422 55 -185 minecraft:water[level=0]
fill 392 55 -186 398 55 -186 minecraft:water[level=0]
setblock 399 55 -186 minecraft:kelp_plant
fill 400 55 -186 416 55 -186 minecraft:water[level=0]
setblock 417 55 -186 minecraft:kelp_plant
setblock 418 55 -186 minecraft:water[level=0]
fill 420 55 -186 422 55 -186 minecraft:water[level=0]
fill 392 55 -187 397 55 -187 minecraft:water[level=0]
setblock 398 55 -187 minecraft:kelp_plant
fill 399 55 -187 400 55 -187 minecraft:water[level=0]
setblock 401 55 -187 minecraft:kelp_plant
fill 402 55 -187 406 55 -187 minecraft:water[level=0]
fill 408 55 -187 418 55 -187 minecraft:water[level=0]
setblock 420 55 -187 minecraft:water[level=0]
setblock 421 55 -187 minecraft:seagrass
setblock 422 55 -187 minecraft:water[level=0]
fill 392 55 -188 403 55 -188 minecraft:water[level=0]
fill 406 55 -188 409 55 -188 minecraft:water[level=0]
setblock 411 55 -188 minecraft:water[level=0]
setblock 412 55 -188 minecraft:kelp_plant
fill 413 55 -188 419 55 -188 minecraft:water[level=0]
setblock 420 55 -188 minecraft:kelp_plant
setblock 421 55 -188 minecraft:bubble_column[drag=true]
setblock 422 55 -188 minecraft:water[level=0]
fill 392 55 -189 403 55 -189 minecraft:water[level=0]
fill 405 55 -189 418 55 -189 minecraft:water[level=0]
fill 420 55 -189 422 55 -189 minecraft:water[level=0]
fill 392 55 -190 396 55 -190 minecraft:water[level=0]
setblock 397 55 -190 minecraft:kelp_plant
fill 398 55 -190 409 55 -190 minecraft:water[level=0]
setblock 411 55 -190 minecraft:kelp_plant
fill 412 55 -190 422 55 -190 minecraft:water[level=0]
setblock 392 54 -127 minecraft:kelp[age=25]
fill 393 54 -127 395 54 -127 minecraft:water[level=0]
setblock 396 54 -127 minecraft:kelp_plant
fill 397 54 -127 402 54 -127 minecraft:water[level=0]
setblock 403 54 -127 minecraft:kelp_plant
fill 404 54 -127 411 54 -127 minecraft:water[level=0]
fill 392 54 -128 393 54 -128 minecraft:water[level=0]
setblock 394 54 -128 minecraft:kelp_plant
fill 395 54 -128 398 54 -128 minecraft:water[level=0]
setblock 399 54 -128 minecraft:kelp_plant
fill 400 54 -128 402 54 -128 minecraft:water[level=0]
setblock 403 54 -128 minecraft:kelp_plant
fill 404 54 -128 412 54 -128 minecraft:water[level=0]
fill 392 54 -129 393 54 -129 minecraft:water[level=0]
setblock 394 54 -129 minecraft:kelp_plant
fill 395 54 -129 413 54 -129 minecraft:water[level=0]
fill 392 54 -130 396 54 -130 minecraft:water[level=0]
setblock 397 54 -130 minecraft:kelp_plant
fill 398 54 -130 414 54 -130 minecraft:water[level=0]
setblock 392 54 -131 minecraft:water[level=0]
setblock 393 54 -131 minecraft:kelp_plant
fill 394 54 -131 415 54 -131 minecraft:water[level=0]
setblock 392 54 -132 minecraft:kelp_plant
fill 393 54 -132 415 54 -132 minecraft:water[level=0]
setblock 392 54 -133 minecraft:water[level=0]
setblock 393 54 -133 minecraft:kelp_plant
fill 394 54 -133 416 54 -133 minecraft:water[level=0]
fill 392 54 -134 393 54 -134 minecraft:water[level=0]
setblock 394 54 -134 minecraft:kelp_plant
fill 395 54 -134 397 54 -134 minecraft:water[level=0]
fill 398 54 -134 399 54 -134 minecraft:kelp_plant
fill 400 54 -134 417 54 -134 minecraft:water[level=0]
fill 392 54 -135 417 54 -135 minecraft:water[level=0]
fill 392 54 -136 418 54 -136 minecraft:water[level=0]
fill 392 54 -137 394 54 -137 minecraft:water[level=0]
setblock 395 54 -137 minecraft:kelp_plant
fill 396 54 -137 418 54 -137 minecraft:water[level=0]
fill 392 54 -138 419 54 -138 minecraft:water[level=0]
fill 392 54 -139 398 54 -139 minecraft:water[level=0]
setblock 399 54 -139 minecraft:kelp_plant
fill 400 54 -139 419 54 -139 minecraft:water[level=0]
setblock 392 54 -140 minecraft:kelp_plant
fill 393 54 -140 419 54 -140 minecraft:water[level=0]
fill 392 54 -141 396 54 -141 minecraft:water[level=0]
setblock 397 54 -141 minecraft:kelp_plant
fill 398 54 -141 420 54 -141 minecraft:water[level=0]
fill 392 54 -142 396 54 -142 minecraft:water[level=0]
setblock 397 54 -142 minecraft:kelp[age=25]
setblock 398 54 -142 minecraft:kelp_plant
fill 399 54 -142 420 54 -142 minecraft:water[level=0]
setblock 392 54 -143 minecraft:water[level=0]
setblock 393 54 -143 minecraft:kelp_plant
fill 394 54 -143 420 54 -143 minecraft:water[level=0]
setblock 392 54 -144 minecraft:water[level=0]
setblock 393 54 -144 minecraft:kelp_plant
fill 394 54 -144 421 54 -144 minecraft:water[level=0]
fill 392 54 -145 398 54 -145 minecraft:water[level=0]
setblock 399 54 -145 minecraft:kelp_plant
fill 400 54 -145 421 54 -145 minecraft:water[level=0]
fill 392 54 -146 394 54 -146 minecraft:water[level=0]
setblock 395 54 -146 minecraft:kelp_plant
fill 396 54 -146 397 54 -146 minecraft:water[level=0]
fill 398 54 -146 399 54 -146 minecraft:kelp_plant
fill 400 54 -146 421 54 -146 minecraft:water[level=0]
setblock 392 54 -147 minecraft:water[level=0]
setblock 393 54 -147 minecraft:kelp_plant
fill 394 54 -147 396 54 -147 minecraft:water[level=0]
setblock 397 54 -147 minecraft:kelp_plant
fill 398 54 -147 421 54 -147 minecraft:water[level=0]
fill 392 54 -148 393 54 -148 minecraft:kelp_plant
fill 394 54 -148 395 54 -148 minecraft:water[level=0]
setblock 396 54 -148 minecraft:kelp_plant
fill 397 54 -148 421 54 -148 minecraft:water[level=0]
fill 392 54 -149 393 54 -149 minecraft:water[level=0]
setblock 394 54 -149 minecraft:kelp_plant
fill 395 54 -149 397 54 -149 minecraft:water[level=0]
setblock 398 54 -149 minecraft:kelp_plant
fill 399 54 -149 421 54 -149 minecraft:water[level=0]
setblock 392 54 -150 minecraft:kelp_plant
setblock 393 54 -150 minecraft:water[level=0]
setblock 394 54 -150 minecraft:kelp_plant
fill 395 54 -150 421 54 -150 minecraft:water[level=0]
fill 392 54 -151 398 54 -151 minecraft:water[level=0]
setblock 399 54 -151 minecraft:kelp_plant
fill 400 54 -151 421 54 -151 minecraft:water[level=0]
fill 392 54 -152 396 54 -152 minecraft:water[level=0]
setblock 397 54 -152 minecraft:kelp_plant
setblock 398 54 -152 minecraft:water[level=0]
setblock 399 54 -152 minecraft:kelp_plant
fill 400 54 -152 422 54 -152 minecraft:water[level=0]
fill 392 54 -153 422 54 -153 minecraft:water[level=0]
fill 392 54 -154 395 54 -154 minecraft:water[level=0]
setblock 396 54 -154 minecraft:kelp_plant
fill 397 54 -154 398 54 -154 minecraft:water[level=0]
setblock 399 54 -154 minecraft:kelp_plant
fill 400 54 -154 422 54 -154 minecraft:water[level=0]
fill 392 54 -155 395 54 -155 minecraft:water[level=0]
setblock 396 54 -155 minecraft:kelp_plant
fill 397 54 -155 422 54 -155 minecraft:water[level=0]
setblock 392 54 -156 minecraft:kelp_plant
fill 393 54 -156 396 54 -156 minecraft:water[level=0]
fill 397 54 -156 399 54 -156 minecraft:kelp_plant
fill 400 54 -156 422 54 -156 minecraft:water[level=0]
fill 392 54 -157 394 54 -157 minecraft:water[level=0]
setblock 395 54 -157 minecraft:kelp_plant
fill 396 54 -157 397 54 -157 minecraft:water[level=0]
setblock 398 54 -157 minecraft:kelp_plant
fill 399 54 -157 422 54 -157 minecraft:water[level=0]
fill 392 54 -158 393 54 -158 minecraft:water[level=0]
setblock 394 54 -158 minecraft:kelp_plant
fill 395 54 -158 406 54 -158 minecraft:water[level=0]
fill 407 54 -158 408 54 -158 minecraft:tall_seagrass[half=upper]
fill 409 54 -158 422 54 -158 minecraft:water[level=0]
fill 392 54 -159 396 54 -159 minecraft:water[level=0]
setblock 397 54 -159 minecraft:kelp_plant
fill 398 54 -159 407 54 -159 minecraft:water[level=0]
fill 408 54 -159 409 54 -159 minecraft:tall_seagrass[half=upper]
setblock 410 54 -159 minecraft:water[level=0]
setblock 411 54 -159 minecraft:tall_seagrass[half=upper]
fill 412 54 -159 422 54 -159 minecraft:water[level=0]
fill 392 54 -160 396 54 -160 minecraft:water[level=0]
setblock 397 54 -160 minecraft:kelp_plant
fill 398 54 -160 422 54 -160 minecraft:water[level=0]
setblock 392 54 -161 minecraft:kelp_plant
fill 393 54 -161 396 54 -161 minecraft:water[level=0]
setblock 397 54 -161 minecraft:kelp_plant
setblock 398 54 -161 minecraft:water[level=0]
setblock 399 54 -161 minecraft:kelp_plant
fill 400 54 -161 406 54 -161 minecraft:water[level=0]
setblock 407 54 -161 minecraft:tall_seagrass[half=upper]
fill 409 54 -161 411 54 -161 minecraft:water[level=0]
fill 413 54 -161 422 54 -161 minecraft:water[level=0]
setblock 392 54 -162 minecraft:water[level=0]
setblock 393 54 -162 minecraft:kelp_plant
fill 394 54 -162 396 54 -162 minecraft:water[level=0]
setblock 397 54 -162 minecraft:kelp_plant
fill 398 54 -162 402 54 -162 minecraft:water[level=0]
setblock 405 54 -162 minecraft:water[level=0]
setblock 408 54 -162 minecraft:water[level=0]
fill 411 54 -162 412 54 -162 minecraft:water[level=8]
fill 414 54 -162 422 54 -162 minecraft:water[level=0]
fill 392 54 -163 393 54 -163 minecraft:kelp_plant
fill 394 54 -163 403 54 -163 minecraft:water[level=0]
fill 414 54 -163 422 54 -163 minecraft:water[level=0]
fill 392 54 -164 400 54 -164 minecraft:water[level=0]
setblock 401 54 -164 minecraft:tall_seagrass[half=upper]
fill 414 54 -164 422 54 -164 minecraft:water[level=0]
setblock 392 54 -165 minecraft:kelp_plant
fill 393 54 -165 400 54 -165 minecraft:water[level=0]
setblock 413 54 -165 minecraft:water[level=0]
fill 415 54 -165 422 54 -165 minecraft:water[level=0]
fill 392 54 -166 394 54 -166 minecraft:water[level=0]
setblock 395 54 -166 minecraft:kelp_plant
fill 396 54 -166 399 54 -166 minecraft:water[level=0]
setblock 400 54 -166 minecraft:seagrass
fill 414 54 -166 422 54 -166 minecraft:water[level=0]
setblock 392 54 -167 minecraft:kelp_plant
setblock 393 54 -167 minecraft:water[level=0]
setblock 394 54 -167 minecraft:kelp_plant
fill 395 54 -167 398 54 -167 minecraft:water[level=0]
setblock 399 54 -167 minecraft:kelp_plant
setblock 409 54 -167 minecraft:water[level=0]
fill 414 54 -167 422 54 -167 minecraft:water[level=0]
setblock 392 54 -168 minecraft:water[level=0]
setblock 393 54 -168 minecraft:kelp_plant
fill 394 54 -168 395 54 -168 minecraft:water[level=0]
setblock 396 54 -168 minecraft:kelp_plant
setblock 397 54 -168 minecraft:water[level=0]
setblock 398 54 -168 minecraft:kelp_plant
setblock 399 54 -168 minecraft:water[level=0]
setblock 412 54 -168 minecraft:water[level=0]
fill 414 54 -168 422 54 -168 minecraft:water[level=0]
fill 392 54 -169 393 54 -169 minecraft:kelp_plant
fill 394 54 -169 400 54 -169 minecraft:water[level=0]
setblock 402 54 -169 minecraft:water[level=0]
fill 414 54 -169 422 54 -169 minecraft:water[level=0]
fill 392 54 -170 398 54 -170 minecraft:water[level=0]
setblock 399 54 -170 minecraft:kelp_plant
setblock 400 54 -170 minecraft:water[level=0]
setblock 405 54 -170 minecraft:water[level=0]
setblock 408 54 -170 minecraft:water[level=0]
fill 415 54 -170 422 54 -170 minecraft:water[level=0]
fill 392 54 -171 395 54 -171 minecraft:water[level=0]
setblock 396 54 -171 minecraft:kelp_plant
setblock 397 54 -171 minecraft:water[level=0]
setblock 398 54 -171 minecraft:kelp_plant
setblock 399 54 -171 minecraft:water[level=0]
setblock 412 54 -171 minecraft:water[level=0]
fill 414 54 -171 417 54 -171 minecraft:water[level=0]
setblock 422 54 -171 minecraft:water[level=0]
setblock 392 54 -172 minecraft:kelp_plant
fill 393 54 -172 399 54 -172 minecraft:water[level=0]
setblock 413 54 -172 minecraft:water[level=8]
fill 415 54 -172 417 54 -172 minecraft:water[level=0]
setblock 419 54 -172 minecraft:water[level=8]
setblock 422 54 -172 minecraft:water[level=0]
setblock 392 54 -173 minecraft:kelp_plant
fill 393 54 -173 399 54 -173 minecraft:water[level=0]
setblock 413 54 -173 minecraft:water[level=8]
fill 414 54 -173 417 54 -173 minecraft:water[level=0]
fill 419 54 -173 420 54 -173 minecraft:water[level=0]
setblock 422 54 -173 minecraft:water[level=0]
fill 392 54 -174 393 54 -174 minecraft:water[level=0]
setblock 394 54 -174 minecraft:kelp_plant
fill 395 54 -174 396 54 -174 minecraft:water[level=0]
fill 397 54 -174 398 54 -174 minecraft:kelp_plant
setblock 399 54 -174 minecraft:water[level=0]
setblock 401 54 -174 minecraft:water[level=0]
setblock 411 54 -174 minecraft:water[level=0]
fill 415 54 -174 417 54 -174 minecraft:water[level=0]
setblock 422 54 -174 minecraft:water[level=0]
fill 392 54 -175 394 54 -175 minecraft:water[level=0]
setblock 395 54 -175 minecraft:kelp_plant
fill 396 54 -175 398 54 -175 minecraft:water[level=0]
setblock 399 54 -175 minecraft:kelp_plant
setblock 400 54 -175 minecraft:water[level=0]
setblock 402 54 -175 minecraft:water[level=0]
fill 414 54 -175 422 54 -175 minecraft:water[level=0]
fill 392 54 -176 398 54 -176 minecraft:water[level=0]
setblock 399 54 -176 minecraft:kelp_plant
fill 400 54 -176 409 54 -176 minecraft:water[level=0]
fill 413 54 -176 422 54 -176 minecraft:water[level=0]
setblock 392 54 -177 minecraft:water[level=0]
setblock 393 54 -177 minecraft:kelp_plant
fill 394 54 -177 397 54 -177 minecraft:water[level=0]
setblock 398 54 -177 minecraft:kelp_plant
fill 399 54 -177 412 54 -177 minecraft:water[level=0]
setblock 413 54 -177 minecraft:tall_seagrass[half=upper]
fill 414 54 -177 422 54 -177 minecraft:water[level=0]
setblock 392 54 -178 minecraft:kelp_plant
fill 393 54 -178 410 54 -178 minecraft:water[level=0]
setblock 411 54 -178 minecraft:tall_seagrass[half=upper]
fill 412 54 -178 422 54 -178 minecraft:water[level=0]
fill 392 54 -179 393 54 -179 minecraft:water[level=0]
setblock 394 54 -179 minecraft:kelp_plant
fill 395 54 -179 422 54 -179 minecraft:water[level=0]
fill 392 54 -180 397 54 -180 minecraft:water[level=0]
setblock 398 54 -180 minecraft:kelp_plant
fill 399 54 -180 422 54 -180 minecraft:water[level=0]
fill 392 54 -181 396 54 -181 minecraft:water[level=0]
setblock 397 54 -181 minecraft:kelp_plant
setblock 398 54 -181 minecraft:water[level=0]
setblock 399 54 -181 minecraft:kelp_plant
fill 400 54 -181 411 54 -181 minecraft:water[level=0]
setblock 412 54 -181 minecraft:tall_seagrass[half=upper]
fill 413 54 -181 422 54 -181 minecraft:water[level=0]
fill 392 54 -182 415 54 -182 minecraft:water[level=0]
setblock 416 54 -182 minecraft:tall_seagrass[half=upper]
fill 417 54 -182 422 54 -182 minecraft:water[level=0]
fill 392 54 -183 414 54 -183 minecraft:water[level=0]
setblock 415 54 -183 minecraft:tall_seagrass[half=upper]
fill 416 54 -183 422 54 -183 minecraft:water[level=0]
fill 392 54 -184 393 54 -184 minecraft:water[level=0]
fill 394 54 -184 395 54 -184 minecraft:kelp_plant
fill 396 54 -184 412 54 -184 minecraft:water[level=0]
setblock 413 54 -184 minecraft:kelp_plant
fill 414 54 -184 419 54 -184 minecraft:water[level=0]
setblock 420 54 -184 minecraft:tall_seagrass[half=upper]
fill 421 54 -184 422 54 -184 minecraft:water[level=0]
fill 392 54 -185 394 54 -185 minecraft:water[level=0]
fill 395 54 -185 396 54 -185 minecraft:kelp_plant
setblock 397 54 -185 minecraft:water[level=0]
fill 398 54 -185 399 54 -185 minecraft:kelp_plant
fill 400 54 -185 412 54 -185 minecraft:water[level=0]
setblock 413 54 -185 minecraft:tall_seagrass[half=upper]
setblock 414 54 -185 minecraft:kelp_plant
fill 415 54 -185 416 54 -185 minecraft:water[level=0]
setblock 417 54 -185 minecraft:seagrass
fill 418 54 -185 422 54 -185 minecraft:water[level=0]
fill 392 54 -186 398 54 -186 minecraft:water[level=0]
setblock 399 54 -186 minecraft:kelp_plant
fill 400 54 -186 416 54 -186 minecraft:water[level=0]
setblock 417 54 -186 minecraft:kelp_plant
setblock 418 54 -186 minecraft:water[level=0]
fill 420 54 -186 422 54 -186 minecraft:water[level=0]
fill 392 54 -187 397 54 -187 minecraft:water[level=0]
setblock 398 54 -187 minecraft:kelp_plant
fill 399 54 -187 400 54 -187 minecraft:water[level=0]
setblock 401 54 -187 minecraft:kelp_plant
fill 402 54 -187 405 54 -187 minecraft:water[level=0]
fill 410 54 -187 416 54 -187 minecraft:water[level=0]
setblock 417 54 -187 minecraft:seagrass
setblock 420 54 -187 minecraft:seagrass
setblock 422 54 -187 minecraft:water[level=0]
fill 392 54 -188 400 54 -188 minecraft:water[level=0]
setblock 401 54 -188 minecraft:tall_seagrass[half=upper]
fill 402 54 -188 403 54 -188 minecraft:water[level=0]
fill 406 54 -188 409 54 -188 minecraft:water[level=0]
setblock 411 54 -188 minecraft:water[level=0]
setblock 412 54 -188 minecraft:kelp_plant
fill 413 54 -188 416 54 -188 minecraft:water[level=0]
fill 418 54 -188 419 54 -188 minecraft:water[level=0]
setblock 421 54 -188 minecraft:bubble_column[drag=true]
setblock 422 54 -188 minecraft:water[level=0]
fill 392 54 -189 402 54 -189 minecraft:water[level=0]
fill 405 54 -189 408 54 -189 minecraft:water[level=0]
fill 410 54 -189 418 54 -189 minecraft:water[level=0]
fill 420 54 -189 421 54 -189 minecraft:water[level=0]
fill 392 54 -190 396 54 -190 minecraft:water[level=0]
setblock 397 54 -190 minecraft:kelp_plant
fill 398 54 -190 400 54 -190 minecraft:water[level=0]
setblock 401 54 -190 minecraft:tall_seagrass[half=upper]
fill 402 54 -190 404 54 -190 minecraft:water[level=0]
fill 407 54 -190 408 54 -190 minecraft:water[level=0]
setblock 411 54 -190 minecraft:kelp_plant
fill 412 54 -190 422 54 -190 minecraft:water[level=0]
setblock 392 53 -127 minecraft:kelp_plant
fill 393 53 -127 395 53 -127 minecraft:water[level=0]
setblock 396 53 -127 minecraft:kelp_plant
fill 397 53 -127 402 53 -127 minecraft:water[level=0]
setblock 403 53 -127 minecraft:kelp_plant
fill 404 53 -127 411 53 -127 minecraft:water[level=0]
fill 392 53 -128 393 53 -128 minecraft:water[level=0]
setblock 394 53 -128 minecraft:kelp_plant
fill 395 53 -128 398 53 -128 minecraft:water[level=0]
setblock 399 53 -128 minecraft:kelp_plant
fill 400 53 -128 402 53 -128 minecraft:water[level=0]
setblock 403 53 -128 minecraft:kelp_plant
fill 404 53 -128 412 53 -128 minecraft:water[level=0]
fill 392 53 -129 393 53 -129 minecraft:water[level=0]
setblock 394 53 -129 minecraft:kelp_plant
fill 395 53 -129 413 53 -129 minecraft:water[level=0]
fill 392 53 -130 396 53 -130 minecraft:water[level=0]
setblock 397 53 -130 minecraft:kelp_plant
fill 398 53 -130 414 53 -130 minecraft:water[level=0]
setblock 392 53 -131 minecraft:water[level=0]
setblock 393 53 -131 minecraft:kelp_plant
fill 394 53 -131 415 53 -131 minecraft:water[level=0]
setblock 392 53 -132 minecraft:kelp_plant
fill 393 53 -132 415 53 -132 minecraft:water[level=0]
setblock 392 53 -133 minecraft:water[level=0]
setblock 393 53 -133 minecraft:kelp_plant
fill 394 53 -133 416 53 -133 minecraft:water[level=0]
fill 392 53 -134 393 53 -134 minecraft:water[level=0]
setblock 394 53 -134 minecraft:kelp_plant
fill 395 53 -134 397 53 -134 minecraft:water[level=0]
fill 398 53 -134 399 53 -134 minecraft:kelp_plant
fill 400 53 -134 417 53 -134 minecraft:water[level=0]
fill 392 53 -135 417 53 -135 minecraft:water[level=0]
fill 392 53 -136 418 53 -136 minecraft:water[level=0]
fill 392 53 -137 394 53 -137 minecraft:water[level=0]
setblock 395 53 -137 minecraft:kelp_plant
fill 396 53 -137 418 53 -137 minecraft:water[level=0]
fill 392 53 -138 419 53 -138 minecraft:water[level=0]
fill 392 53 -139 398 53 -139 minecraft:water[level=0]
setblock 399 53 -139 minecraft:kelp_plant
fill 400 53 -139 419 53 -139 minecraft:water[level=0]
setblock 392 53 -140 minecraft:kelp_plant
fill 393 53 -140 419 53 -140 minecraft:water[level=0]
fill 392 53 -141 396 53 -141 minecraft:water[level=0]
setblock 397 53 -141 minecraft:kelp_plant
fill 398 53 -141 420 53 -141 minecraft:water[level=0]
fill 392 53 -142 396 53 -142 minecraft:water[level=0]
fill 397 53 -142 398 53 -142 minecraft:kelp_plant
fill 399 53 -142 420 53 -142 minecraft:water[level=0]
setblock 392 53 -143 minecraft:water[level=0]
setblock 393 53 -143 minecraft:kelp_plant
fill 394 53 -143 420 53 -143 minecraft:water[level=0]
setblock 392 53 -144 minecraft:water[level=0]
setblock 393 53 -144 minecraft:kelp_plant
fill 394 53 -144 421 53 -144 minecraft:water[level=0]
fill 392 53 -145 398 53 -145 minecraft:water[level=0]
setblock 399 53 -145 minecraft:kelp_plant
fill 400 53 -145 421 53 -145 minecraft:water[level=0]
fill 392 53 -146 394 53 -146 minecraft:water[level=0]
setblock 395 53 -146 minecraft:kelp_plant
fill 396 53 -146 397 53 -146 minecraft:water[level=0]
fill 398 53 -146 399 53 -146 minecraft:kelp_plant
fill 400 53 -146 421 53 -146 minecraft:water[level=0]
setblock 392 53 -147 minecraft:water[level=0]
setblock 393 53 -147 minecraft:kelp_plant
fill 394 53 -147 396 53 -147 minecraft:water[level=0]
setblock 397 53 -147 minecraft:kelp_plant
fill 398 53 -147 421 53 -147 minecraft:water[level=0]
fill 392 53 -148 393 53 -148 minecraft:kelp_plant
fill 394 53 -148 395 53 -148 minecraft:water[level=0]
setblock 396 53 -148 minecraft:kelp_plant
fill 397 53 -148 421 53 -148 minecraft:water[level=0]
fill 392 53 -149 393 53 -149 minecraft:water[level=0]
setblock 394 53 -149 minecraft:kelp_plant
fill 395 53 -149 397 53 -149 minecraft:water[level=0]
setblock 398 53 -149 minecraft:kelp_plant
fill 399 53 -149 421 53 -149 minecraft:water[level=0]
setblock 392 53 -150 minecraft:kelp_plant
setblock 393 53 -150 minecraft:water[level=0]
setblock 394 53 -150 minecraft:kelp_plant
fill 395 53 -150 421 53 -150 minecraft:water[level=0]
fill 392 53 -151 398 53 -151 minecraft:water[level=0]
setblock 399 53 -151 minecraft:kelp_plant
fill 400 53 -151 421 53 -151 minecraft:water[level=0]
fill 392 53 -152 396 53 -152 minecraft:water[level=0]
setblock 397 53 -152 minecraft:kelp_plant
setblock 398 53 -152 minecraft:water[level=0]
setblock 399 53 -152 minecraft:kelp_plant
fill 400 53 -152 422 53 -152 minecraft:water[level=0]
fill 392 53 -153 422 53 -153 minecraft:water[level=0]
fill 392 53 -154 395 53 -154 minecraft:water[level=0]
setblock 396 53 -154 minecraft:kelp_plant
fill 397 53 -154 398 53 -154 minecraft:water[level=0]
setblock 399 53 -154 minecraft:kelp_plant
fill 400 53 -154 422 53 -154 minecraft:water[level=0]
fill 392 53 -155 395 53 -155 minecraft:water[level=0]
setblock 396 53 -155 minecraft:kelp_plant
fill 397 53 -155 422 53 -155 minecraft:water[level=0]
setblock 392 53 -156 minecraft:kelp_plant
fill 393 53 -156 396 53 -156 minecraft:water[level=0]
fill 397 53 -156 399 53 -156 minecraft:kelp_plant
fill 400 53 -156 408 53 -156 minecraft:water[level=0]
setblock 409 53 -156 minecraft:tall_seagrass[half=upper]
fill 410 53 -156 422 53 -156 minecraft:water[level=0]
fill 392 53 -157 394 53 -157 minecraft:water[level=0]
setblock 395 53 -157 minecraft:kelp_plant
fill 396 53 -157 397 53 -157 minecraft:water[level=0]
setblock 398 53 -157 minecraft:kelp_plant
fill 399 53 -157 405 53 -157 minecraft:water[level=0]
setblock 406 53 -157 minecraft:tall_seagrass[half=upper]
fill 407 53 -157 422 53 -157 minecraft:water[level=0]
fill 392 53 -158 393 53 -158 minecraft:water[level=0]
setblock 394 53 -158 minecraft:kelp_plant
fill 395 53 -158 406 53 -158 minecraft:water[level=0]
fill 407 53 -158 408 53 -158 minecraft:tall_seagrass[half=lower]
setblock 409 53 -158 minecraft:water[level=0]
setblock 410 53 -158 minecraft:tall_seagrass[half=upper]
fill 411 53 -158 422 53 -158 minecraft:water[level=0]
fill 392 53 -159 396 53 -159 minecraft:water[level=0]
setblock 397 53 -159 minecraft:kelp_plant
fill 398 53 -159 405 53 -159 minecraft:water[level=0]
fill 406 53 -159 407 53 -159 minecraft:seagrass
fill 408 53 -159 409 53 -159 minecraft:tall_seagrass[half=lower]
setblock 410 53 -159 minecraft:water[level=0]
setblock 411 53 -159 minecraft:tall_seagrass[half=lower]
setblock 412 53 -159 minecraft:tall_seagrass[half=upper]
fill 413 53 -159 422 53 -159 minecraft:water[level=0]
fill 392 53 -160 396 53 -160 minecraft:water[level=0]
setblock 397 53 -160 minecraft:kelp_plant
fill 398 53 -160 403 53 -160 minecraft:water[level=0]
setblock 404 53 -160 minecraft:seagrass
setblock 405 53 -160 minecraft:water[level=0]
fill 406 53 -160 407 53 -160 minecraft:seagrass
setblock 408 53 -160 minecraft:water[level=0]
fill 409 53 -160 410 53 -160 minecraft:seagrass
setblock 411 53 -160 minecraft:water[level=0]
setblock 412 53 -160 minecraft:seagrass
fill 413 53 -160 422 53 -160 minecraft:water[level=0]
setblock 392 53 -161 minecraft:kelp_plant
fill 393 53 -161 396 53 -161 minecraft:water[level=0]
setblock 397 53 -161 minecraft:kelp_plant
setblock 398 53 -161 minecraft:water[level=0]
setblock 399 53 -161 minecraft:kelp_plant
fill 400 53 -161 402 53 -161 minecraft:water[level=0]
setblock 406 53 -161 minecraft:seagrass
setblock 407 53 -161 minecraft:tall_seagrass[half=lower]
fill 414 53 -161 422 53 -161 minecraft:water[level=0]
setblock 392 53 -162 minecraft:water[level=0]
setblock 393 53 -162 minecraft:kelp_plant
fill 394 53 -162 396 53 -162 minecraft:water[level=0]
setblock 397 53 -162 minecraft:kelp_plant
fill 398 53 -162 400 53 -162 minecraft:water[level=0]
fill 413 53 -162 422 53 -162 minecraft:water[level=0]
fill 392 53 -163 393 53 -163 minecraft:kelp_plant
fill 394 53 -163 400 53 -163 minecraft:water[level=0]
fill 412 53 -163 422 53 -163 minecraft:water[level=0]
fill 392 53 -164 399 53 -164 minecraft:water[level=0]
setblock 401 53 -164 minecraft:tall_seagrass[half=lower]
setblock 414 53 -164 minecraft:water[level=0]
fill 416 53 -164 422 53 -164 minecraft:water[level=0]
setblock 392 53 -165 minecraft:kelp_plant
fill 393 53 -165 400 53 -165 minecraft:water[level=0]
fill 416 53 -165 422 53 -165 minecraft:water[level=0]
fill 392 53 -166 394 53 -166 minecraft:water[level=0]
setblock 395 53 -166 minecraft:kelp_plant
fill 396 53 -166 399 53 -166 minecraft:water[level=0]
fill 416 53 -166 422 53 -166 minecraft:water[level=0]
setblock 392 53 -167 minecraft:kelp_plant
setblock 393 53 -167 minecraft:water[level=0]
setblock 394 53 -167 minecraft:kelp_plant
fill 395 53 -167 398 53 -167 minecraft:water[level=0]
setblock 399 53 -167 minecraft:kelp_plant
fill 414 53 -167 422 53 -167 minecraft:water[level=0]
setblock 392 53 -168 minecraft:water[level=0]
setblock 393 53 -168 minecraft:kelp_plant
fill 394 53 -168 395 53 -168 minecraft:water[level=0]
setblock 396 53 -168 minecraft:kelp_plant
setblock 397 53 -168 minecraft:water[level=0]
setblock 398 53 -168 minecraft:kelp_plant
setblock 399 53 -168 minecraft:water[level=0]
fill 415 53 -168 422 53 -168 minecraft:water[level=0]
fill 392 53 -169 393 53 -169 minecraft:kelp_plant
fill 394 53 -169 397 53 -169 minecraft:water[level=0]
setblock 398 53 -169 minecraft:seagrass
setblock 399 53 -169 minecraft:water[level=0]
fill 416 53 -169 422 53 -169 minecraft:water[level=0]
fill 392 53 -170 398 53 -170 minecraft:water[level=0]
setblock 414 53 -170 minecraft:water[level=0]
fill 416 53 -170 422 53 -170 minecraft:water[level=0]
setblock 392 53 -171 minecraft:tall_seagrass[half=upper]
fill 393 53 -171 395 53 -171 minecraft:water[level=0]
setblock 396 53 -171 minecraft:kelp_plant
setblock 397 53 -171 minecraft:water[level=0]
setblock 398 53 -171 minecraft:kelp_plant
setblock 414 53 -171 minecraft:water[level=0]
fill 416 53 -171 418 53 -171 minecraft:water[level=0]
fill 421 53 -171 422 53 -171 minecraft:water[level=0]
setblock 392 53 -172 minecraft:kelp_plant
fill 393 53 -172 397 53 -172 minecraft:water[level=0]
setblock 398 53 -172 minecraft:seagrass
fill 416 53 -172 417 53 -172 minecraft:water[level=0]
setblock 422 53 -172 minecraft:water[level=0]
setblock 392 53 -173 minecraft:kelp_plant
setblock 393 53 -173 minecraft:water[level=0]
setblock 394 53 -173 minecraft:tall_seagrass[half=upper]
fill 395 53 -173 398 53 -173 minecraft:water[level=0]
fill 416 53 -173 420 53 -173 minecraft:water[level=0]
setblock 422 53 -173 minecraft:water[level=0]
fill 392 53 -174 393 53 -174 minecraft:water[level=0]
setblock 394 53 -174 minecraft:kelp_plant
fill 395 53 -174 396 53 -174 minecraft:water[level=0]
fill 397 53 -174 398 53 -174 minecraft:kelp_plant
fill 413 53 -174 414 53 -174 minecraft:water[level=0]
fill 416 53 -174 417 53 -174 minecraft:water[level=0]
setblock 419 53 -174 minecraft:water[level=0]
setblock 422 53 -174 minecraft:water[level=0]
fill 392 53 -175 394 53 -175 minecraft:water[level=0]
setblock 395 53 -175 minecraft:kelp_plant
setblock 396 53 -175 minecraft:tall_seagrass[half=upper]
fill 397 53 -175 398 53 -175 minecraft:water[level=0]
setblock 413 53 -175 minecraft:water[level=0]
fill 415 53 -175 422 53 -175 minecraft:water[level=0]
fill 392 53 -176 398 53 -176 minecraft:water[level=0]
setblock 399 53 -176 minecraft:kelp_plant
setblock 405 53 -176 minecraft:water[level=0]
setblock 407 53 -176 minecraft:water[level=0]
setblock 409 53 -176 minecraft:water[level=0]
fill 414 53 -176 422 53 -176 minecraft:water[level=0]
setblock 392 53 -177 minecraft:water[level=0]
setblock 393 53 -177 minecraft:kelp_plant
fill 394 53 -177 397 53 -177 minecraft:water[level=0]
setblock 398 53 -177 minecraft:kelp_plant
setblock 399 53 -177 minecraft:water[level=0]
fill 402 53 -177 410 53 -177 minecraft:water[level=0]
setblock 411 53 -177 minecraft:seagrass
setblock 412 53 -177 minecraft:water[level=0]
setblock 413 53 -177 minecraft:tall_seagrass[half=lower]
fill 414 53 -177 422 53 -177 minecraft:water[level=0]
setblock 392 53 -178 minecraft:kelp_plant
fill 393 53 -178 410 53 -178 minecraft:water[level=0]
setblock 411 53 -178 minecraft:tall_seagrass[half=lower]
fill 412 53 -178 414 53 -178 minecraft:water[level=0]
fill 415 53 -178 416 53 -178 minecraft:tall_seagrass[half=upper]
fill 417 53 -178 422 53 -178 minecraft:water[level=0]
fill 392 53 -179 393 53 -179 minecraft:water[level=0]
setblock 394 53 -179 minecraft:kelp_plant
fill 395 53 -179 407 53 -179 minecraft:water[level=0]
setblock 408 53 -179 minecraft:seagrass
fill 409 53 -179 411 53 -179 minecraft:water[level=0]
setblock 412 53 -179 minecraft:seagrass
fill 413 53 -179 422 53 -179 minecraft:water[level=0]
fill 392 53 -180 397 53 -180 minecraft:water[level=0]
setblock 398 53 -180 minecraft:kelp_plant
fill 399 53 -180 411 53 -180 minecraft:water[level=0]
setblock 412 53 -180 minecraft:seagrass
setblock 413 53 -180 minecraft:water[level=0]
setblock 414 53 -180 minecraft:tall_seagrass[half=upper]
fill 415 53 -180 416 53 -180 minecraft:water[level=0]
setblock 417 53 -180 minecraft:tall_seagrass[half=upper]
fill 418 53 -180 422 53 -180 minecraft:water[level=0]
fill 392 53 -181 396 53 -181 minecraft:water[level=0]
setblock 397 53 -181 minecraft:kelp_plant
setblock 398 53 -181 minecraft:seagrass
setblock 399 53 -181 minecraft:kelp_plant
fill 400 53 -181 411 53 -181 minecraft:water[level=0]
setblock 412 53 -181 minecraft:tall_seagrass[half=lower]
fill 413 53 -181 420 53 -181 minecraft:water[level=0]
setblock 421 53 -181 minecraft:tall_seagrass[half=upper]
setblock 422 53 -181 minecraft:water[level=0]
fill 392 53 -182 399 53 -182 minecraft:water[level=0]
setblock 400 53 -182 minecraft:seagrass
fill 401 53 -182 414 53 -182 minecraft:water[level=0]
setblock 415 53 -182 minecraft:seagrass
setblock 416 53 -182 minecraft:tall_seagrass[half=lower]
fill 417 53 -182 418 53 -182 minecraft:tall_seagrass[half=upper]
setblock 419 53 -182 minecraft:water[level=0]
setblock 420 53 -182 minecraft:tall_seagrass[half=upper]
fill 421 53 -182 422 53 -182 minecraft:water[level=0]
fill 392 53 -183 412 53 -183 minecraft:water[level=0]
setblock 413 53 -183 minecraft:seagrass
setblock 414 53 -183 minecraft:water[level=0]
setblock 415 53 -183 minecraft:tall_seagrass[half=lower]
setblock 416 53 -183 minecraft:water[level=0]
fill 417 53 -183 418 53 -183 minecraft:seagrass
setblock 419 53 -183 minecraft:water[level=0]
setblock 420 53 -183 minecraft:tall_seagrass[half=upper]
fill 421 53 -183 422 53 -183 minecraft:water[level=0]
fill 392 53 -184 393 53 -184 minecraft:water[level=0]
fill 394 53 -184 395 53 -184 minecraft:kelp_plant
setblock 396 53 -184 minecraft:water[level=0]
fill 397 53 -184 398 53 -184 minecraft:tall_seagrass[half=upper]
setblock 399 53 -184 minecraft:water[level=0]
fill 402 53 -184 412 53 -184 minecraft:water[level=0]
setblock 413 53 -184 minecraft:kelp_plant
fill 414 53 -184 415 53 -184 minecraft:water[level=0]
setblock 416 53 -184 minecraft:seagrass
fill 417 53 -184 419 53 -184 minecraft:water[level=0]
setblock 420 53 -184 minecraft:tall_seagrass[half=lower]
setblock 421 53 -184 minecraft:water[level=0]
setblock 422 53 -184 minecraft:seagrass
fill 392 53 -185 394 53 -185 minecraft:water[level=0]
fill 395 53 -185 396 53 -185 minecraft:kelp_plant
setblock 397 53 -185 minecraft:tall_seagrass[half=upper]
fill 398 53 -185 399 53 -185 minecraft:kelp_plant
fill 400 53 -185 402 53 -185 minecraft:water[level=0]
setblock 403 53 -185 minecraft:seagrass
fill 404 53 -185 411 53 -185 minecraft:water[level=0]
setblock 412 53 -185 minecraft:seagrass
setblock 413 53 -185 minecraft:tall_seagrass[half=lower]
setblock 414 53 -185 minecraft:kelp_plant
setblock 415 53 -185 minecraft:water[level=0]
setblock 416 53 -185 minecraft:seagrass
setblock 419 53 -185 minecraft:seagrass
setblock 422 53 -185 minecraft:water[level=0]
fill 392 53 -186 398 53 -186 minecraft:water[level=0]
setblock 399 53 -186 minecraft:kelp_plant
fill 400 53 -186 416 53 -186 minecraft:water[level=0]
setblock 420 53 -186 minecraft:seagrass
fill 392 53 -187 397 53 -187 minecraft:water[level=0]
setblock 398 53 -187 minecraft:kelp_plant
fill 399 53 -187 400 53 -187 minecraft:seagrass
setblock 401 53 -187 minecraft:kelp_plant
setblock 402 53 -187 minecraft:water[level=0]
setblock 407 53 -187 minecraft:water[level=0]
fill 411 53 -187 415 53 -187 minecraft:water[level=0]
setblock 416 53 -187 minecraft:seagrass
fill 421 53 -187 422 53 -187 minecraft:water[level=0]
setblock 392 53 -188 minecraft:water[level=0]
setblock 393 53 -188 minecraft:kelp[age=25]
fill 394 53 -188 399 53 -188 minecraft:water[level=0]
setblock 401 53 -188 minecraft:tall_seagrass[half=lower]
fill 402 53 -188 403 53 -188 minecraft:seagrass
setblock 411 53 -188 minecraft:water[level=0]
setblock 412 53 -188 minecraft:kelp_plant
fill 413 53 -188 416 53 -188 minecraft:water[level=0]
setblock 418 53 -188 minecraft:water[level=0]
setblock 422 53 -188 minecraft:water[level=0]
fill 392 53 -189 399 53 -189 minecraft:water[level=0]
fill 401 53 -189 403 53 -189 minecraft:water[level=0]
setblock 407 53 -189 minecraft:water[level=0]
fill 409 53 -189 414 53 -189 minecraft:water[level=0]
fill 420 53 -189 422 53 -189 minecraft:water[level=0]
fill 392 53 -190 396 53 -190 minecraft:water[level=0]
setblock 397 53 -190 minecraft:kelp_plant
fill 398 53 -190 399 53 -190 minecraft:water[level=0]
setblock 401 53 -190 minecraft:tall_seagrass[half=lower]
setblock 402 53 -190 minecraft:water[level=0]
fill 408 53 -190 409 53 -190 minecraft:water[level=0]
setblock 411 53 -190 minecraft:kelp_plant
fill 412 53 -190 418 53 -190 minecraft:water[level=0]
setblock 420 53 -190 minecraft:water[level=0]
setblock 422 53 -190 minecraft:water[level=0]
setblock 392 52 -127 minecraft:kelp_plant
fill 393 52 -127 395 52 -127 minecraft:water[level=0]
setblock 396 52 -127 minecraft:kelp_plant
fill 397 52 -127 402 52 -127 minecraft:water[level=0]
setblock 403 52 -127 minecraft:kelp_plant
fill 404 52 -127 411 52 -127 minecraft:water[level=0]
fill 392 52 -128 393 52 -128 minecraft:water[level=0]
setblock 394 52 -128 minecraft:kelp_plant
fill 395 52 -128 398 52 -128 minecraft:water[level=0]
setblock 399 52 -128 minecraft:kelp_plant
fill 400 52 -128 402 52 -128 minecraft:water[level=0]
setblock 403 52 -128 minecraft:kelp_plant
fill 404 52 -128 412 52 -128 minecraft:water[level=0]
fill 392 52 -129 393 52 -129 minecraft:water[level=0]
setblock 394 52 -129 minecraft:kelp_plant
fill 395 52 -129 413 52 -129 minecraft:water[level=0]
fill 392 52 -130 396 52 -130 minecraft:water[level=0]
setblock 397 52 -130 minecraft:kelp_plant
fill 398 52 -130 414 52 -130 minecraft:water[level=0]
setblock 392 52 -131 minecraft:water[level=0]
setblock 393 52 -131 minecraft:kelp_plant
fill 394 52 -131 415 52 -131 minecraft:water[level=0]
setblock 392 52 -132 minecraft:kelp_plant
fill 393 52 -132 415 52 -132 minecraft:water[level=0]
setblock 392 52 -133 minecraft:water[level=0]
setblock 393 52 -133 minecraft:kelp_plant
fill 394 52 -133 416 52 -133 minecraft:water[level=0]
fill 392 52 -134 393 52 -134 minecraft:water[level=0]
setblock 394 52 -134 minecraft:kelp_plant
fill 395 52 -134 397 52 -134 minecraft:water[level=0]
fill 398 52 -134 399 52 -134 minecraft:kelp_plant
fill 400 52 -134 417 52 -134 minecraft:water[level=0]
fill 392 52 -135 417 52 -135 minecraft:water[level=0]
fill 392 52 -136 418 52 -136 minecraft:water[level=0]
fill 392 52 -137 394 52 -137 minecraft:water[level=0]
setblock 395 52 -137 minecraft:kelp_plant
fill 396 52 -137 418 52 -137 minecraft:water[level=0]
fill 392 52 -138 419 52 -138 minecraft:water[level=0]
fill 392 52 -139 398 52 -139 minecraft:water[level=0]
setblock 399 52 -139 minecraft:kelp_plant
fill 400 52 -139 419 52 -139 minecraft:water[level=0]
setblock 392 52 -140 minecraft:kelp_plant
fill 393 52 -140 419 52 -140 minecraft:water[level=0]
fill 392 52 -141 396 52 -141 minecraft:water[level=0]
setblock 397 52 -141 minecraft:kelp_plant
fill 398 52 -141 420 52 -141 minecraft:water[level=0]
fill 392 52 -142 396 52 -142 minecraft:water[level=0]
fill 397 52 -142 398 52 -142 minecraft:kelp_plant
fill 399 52 -142 420 52 -142 minecraft:water[level=0]
setblock 392 52 -143 minecraft:water[level=0]
setblock 393 52 -143 minecraft:kelp_plant
fill 394 52 -143 420 52 -143 minecraft:water[level=0]
setblock 392 52 -144 minecraft:water[level=0]
setblock 393 52 -144 minecraft:kelp_plant
fill 394 52 -144 421 52 -144 minecraft:water[level=0]
fill 392 52 -145 398 52 -145 minecraft:water[level=0]
setblock 399 52 -145 minecraft:kelp_plant
fill 400 52 -145 421 52 -145 minecraft:water[level=0]
fill 392 52 -146 394 52 -146 minecraft:water[level=0]
setblock 395 52 -146 minecraft:kelp_plant
fill 396 52 -146 397 52 -146 minecraft:water[level=0]
fill 398 52 -146 399 52 -146 minecraft:kelp_plant
fill 400 52 -146 421 52 -146 minecraft:water[level=0]
setblock 392 52 -147 minecraft:water[level=0]
setblock 393 52 -147 minecraft:kelp_plant
fill 394 52 -147 396 52 -147 minecraft:water[level=0]
setblock 397 52 -147 minecraft:kelp_plant
fill 398 52 -147 421 52 -147 minecraft:water[level=0]
fill 392 52 -148 393 52 -148 minecraft:kelp_plant
fill 394 52 -148 395 52 -148 minecraft:water[level=0]
setblock 396 52 -148 minecraft:kelp_plant
fill 397 52 -148 421 52 -148 minecraft:water[level=0]
fill 392 52 -149 393 52 -149 minecraft:water[level=0]
setblock 394 52 -149 minecraft:kelp_plant
fill 395 52 -149 397 52 -149 minecraft:water[level=0]
setblock 398 52 -149 minecraft:kelp_plant
fill 399 52 -149 421 52 -149 minecraft:water[level=0]
setblock 392 52 -150 minecraft:kelp_plant
setblock 393 52 -150 minecraft:water[level=0]
setblock 394 52 -150 minecraft:kelp_plant
fill 395 52 -150 421 52 -150 minecraft:water[level=0]
fill 392 52 -151 398 52 -151 minecraft:water[level=0]
setblock 399 52 -151 minecraft:kelp_plant
fill 400 52 -151 421 52 -151 minecraft:water[level=0]
fill 392 52 -152 396 52 -152 minecraft:water[level=0]
setblock 397 52 -152 minecraft:kelp_plant
setblock 398 52 -152 minecraft:water[level=0]
setblock 399 52 -152 minecraft:kelp_plant
fill 400 52 -152 422 52 -152 minecraft:water[level=0]
setblock 392 52 -153 minecraft:tall_seagrass[half=upper]
fill 393 52 -153 422 52 -153 minecraft:water[level=0]
fill 392 52 -154 395 52 -154 minecraft:water[level=0]
setblock 396 52 -154 minecraft:kelp_plant
fill 397 52 -154 398 52 -154 minecraft:water[level=0]
setblock 399 52 -154 minecraft:kelp_plant
fill 400 52 -154 403 52 -154 minecraft:water[level=0]
setblock 404 52 -154 minecraft:tall_seagrass[half=upper]
fill 405 52 -154 406 52 -154 minecraft:water[level=0]
setblock 407 52 -154 minecraft:tall_seagrass[half=upper]
fill 408 52 -154 422 52 -154 minecraft:water[level=0]
fill 392 52 -155 395 52 -155 minecraft:water[level=0]
setblock 396 52 -155 minecraft:kelp_plant
fill 397 52 -155 402 52 -155 minecraft:water[level=0]
setblock 403 52 -155 minecraft:tall_seagrass[half=upper]
fill 404 52 -155 422 52 -155 minecraft:water[level=0]
setblock 392 52 -156 minecraft:kelp_plant
fill 393 52 -156 396 52 -156 minecraft:water[level=0]
fill 397 52 -156 399 52 -156 minecraft:kelp_plant
fill 400 52 -156 404 52 -156 minecraft:water[level=0]
fill 405 52 -156 406 52 -156 minecraft:seagrass
fill 407 52 -156 408 52 -156 minecraft:water[level=0]
setblock 409 52 -156 minecraft:tall_seagrass[half=lower]
fill 410 52 -156 411 52 -156 minecraft:seagrass
fill 412 52 -156 422 52 -156 minecraft:water[level=0]
fill 392 52 -157 394 52 -157 minecraft:water[level=0]
setblock 395 52 -157 minecraft:kelp_plant
fill 396 52 -157 397 52 -157 minecraft:water[level=0]
setblock 398 52 -157 minecraft:kelp_plant
fill 399 52 -157 404 52 -157 minecraft:water[level=0]
setblock 405 52 -157 minecraft:seagrass
setblock 406 52 -157 minecraft:tall_seagrass[half=lower]
setblock 407 52 -157 minecraft:water[level=0]
fill 408 52 -157 409 52 -157 minecraft:seagrass
fill 410 52 -157 422 52 -157 minecraft:water[level=0]
fill 392 52 -158 393 52 -158 minecraft:water[level=0]
setblock 394 52 -158 minecraft:kelp_plant
fill 395 52 -158 403 52 -158 minecraft:water[level=0]
setblock 404 52 -158 minecraft:seagrass
fill 405 52 -158 406 52 -158 minecraft:water[level=0]
setblock 410 52 -158 minecraft:tall_seagrass[half=lower]
setblock 411 52 -158 minecraft:water[level=0]
setblock 412 52 -158 minecraft:seagrass
fill 413 52 -158 422 52 -158 minecraft:water[level=0]
fill 392 52 -159 396 52 -159 minecraft:water[level=0]
setblock 397 52 -159 minecraft:kelp_plant
fill 398 52 -159 403 52 -159 minecraft:water[level=0]
fill 404 52 -159 405 52 -159 minecraft:seagrass
setblock 412 52 -159 minecraft:tall_seagrass[half=lower]
setblock 413 52 -159 minecraft:seagrass
fill 414 52 -159 422 52 -159 minecraft:water[level=0]
fill 392 52 -160 396 52 -160 minecraft:water[level=0]
setblock 397 52 -160 minecraft:kelp_plant
fill 398 52 -160 403 52 -160 minecraft:water[level=0]
fill 413 52 -160 422 52 -160 minecraft:water[level=0]
setblock 392 52 -161 minecraft:kelp_plant
fill 393 52 -161 396 52 -161 minecraft:water[level=0]
setblock 397 52 -161 minecraft:kelp_plant
setblock 398 52 -161 minecraft:water[level=0]
setblock 399 52 -161 minecraft:kelp_plant
setblock 400 52 -161 minecraft:water[level=0]
setblock 401 52 -161 minecraft:seagrass
fill 414 52 -161 422 52 -161 minecraft:water[level=0]
setblock 392 52 -162 minecraft:water[level=0]
setblock 393 52 -162 minecraft:kelp_plant
fill 394 52 -162 396 52 -162 minecraft:water[level=0]
setblock 397 52 -162 minecraft:kelp_plant
fill 398 52 -162 400 52 -162 minecraft:water[level=0]
fill 415 52 -162 422 52 -162 minecraft:water[level=0]
fill 392 52 -163 393 52 -163 minecraft:kelp_plant
fill 394 52 -163 399 52 -163 minecraft:water[level=0]
fill 416 52 -163 422 52 -163 minecraft:water[level=0]
fill 392 52 -164 399 52 -164 minecraft:water[level=0]
fill 416 52 -164 422 52 -164 minecraft:water[level=0]
setblock 392 52 -165 minecraft:kelp_plant
fill 393 52 -165 399 52 -165 minecraft:water[level=0]
fill 416 52 -165 422 52 -165 minecraft:water[level=0]
fill 392 52 -166 394 52 -166 minecraft:water[level=0]
setblock 395 52 -166 minecraft:kelp_plant
fill 396 52 -166 398 52 -166 minecraft:water[level=0]
fill 418 52 -166 422 52 -166 minecraft:water[level=0]
setblock 392 52 -167 minecraft:kelp_plant
setblock 393 52 -167 minecraft:water[level=0]
setblock 394 52 -167 minecraft:kelp_plant
fill 395 52 -167 398 52 -167 minecraft:water[level=0]
setblock 416 52 -167 minecraft:water[level=0]
fill 418 52 -167 422 52 -167 minecraft:water[level=0]
setblock 392 52 -168 minecraft:water[level=0]
setblock 393 52 -168 minecraft:kelp_plant
fill 394 52 -168 395 52 -168 minecraft:water[level=0]
setblock 396 52 -168 minecraft:kelp_plant
setblock 397 52 -168 minecraft:tall_seagrass[half=upper]
setblock 398 52 -168 minecraft:kelp_plant
fill 416 52 -168 422 52 -168 minecraft:water[level=0]
fill 392 52 -169 393 52 -169 minecraft:kelp_plant
setblock 394 52 -169 minecraft:tall_seagrass[half=upper]
setblock 395 52 -169 minecraft:water[level=0]
setblock 396 52 -169 minecraft:tall_seagrass[half=upper]
setblock 397 52 -169 minecraft:water[level=0]
fill 416 52 -169 418 52 -169 minecraft:water[level=0]
fill 420 52 -169 422 52 -169 minecraft:water[level=0]
setblock 392 52 -170 minecraft:tall_seagrass[half=upper]
fill 393 52 -170 394 52 -170 minecraft:water[level=0]
setblock 395 52 -170 minecraft:tall_seagrass[half=upper]
fill 396 52 -170 397 52 -170 minecraft:water[level=0]
setblock 417 52 -170 minecraft:water[level=0]
fill 420 52 -170 422 52 -170 minecraft:water[level=0]
setblock 392 52 -171 minecraft:tall_seagrass[half=lower]
fill 393 52 -171 395 52 -171 minecraft:water[level=0]
setblock 396 52 -171 minecraft:kelp_plant
setblock 397 52 -171 minecraft:seagrass
setblock 417 52 -171 minecraft:water[level=0]
setblock 419 52 -171 minecraft:water[level=0]
setblock 422 52 -171 minecraft:water[level=0]
setblock 392 52 -172 minecraft:kelp_plant
setblock 393 52 -172 minecraft:seagrass
fill 394 52 -172 397 52 -172 minecraft:water[level=0]
setblock 422 52 -172 minecraft:water[level=0]
setblock 392 52 -173 minecraft:kelp_plant
setblock 393 52 -173 minecraft:seagrass
setblock 394 52 -173 minecraft:tall_seagrass[half=lower]
setblock 395 52 -173 minecraft:water[level=0]
setblock 396 52 -173 minecraft:seagrass
setblock 416 52 -173 minecraft:water[level=0]
fill 419 52 -173 421 52 -173 minecraft:water[level=0]
fill 392 52 -174 393 52 -174 minecraft:water[level=0]
setblock 394 52 -174 minecraft:kelp_plant
setblock 395 52 -174 minecraft:water[level=0]
setblock 396 52 -174 minecraft:seagrass
setblock 416 52 -174 minecraft:water[level=0]
fill 418 52 -174 419 52 -174 minecraft:water[level=0]
fill 392 52 -175 394 52 -175 minecraft:water[level=0]
setblock 395 52 -175 minecraft:kelp_plant
setblock 396 52 -175 minecraft:tall_seagrass[half=lower]
fill 415 52 -175 416 52 -175 minecraft:seagrass
fill 417 52 -175 422 52 -175 minecraft:water[level=0]
fill 392 52 -176 396 52 -176 minecraft:water[level=0]
fill 415 52 -176 418 52 -176 minecraft:water[level=0]
setblock 419 52 -176 minecraft:seagrass
fill 420 52 -176 422 52 -176 minecraft:water[level=0]
setblock 392 52 -177 minecraft:water[level=0]
setblock 393 52 -177 minecraft:kelp_plant
fill 394 52 -177 396 52 -177 minecraft:water[level=0]
fill 415 52 -177 422 52 -177 minecraft:water[level=0]
setblock 392 52 -178 minecraft:kelp_plant
fill 393 52 -178 396 52 -178 minecraft:water[level=0]
fill 415 52 -178 416 52 -178 minecraft:tall_seagrass[half=lower]
setblock 417 52 -178 minecraft:seagrass
setblock 418 52 -178 minecraft:water[level=0]
setblock 419 52 -178 minecraft:tall_seagrass[half=upper]
fill 420 52 -178 422 52 -178 minecraft:water[level=0]
fill 392 52 -179 393 52 -179 minecraft:water[level=0]
setblock 394 52 -179 minecraft:kelp_plant
fill 395 52 -179 396 52 -179 minecraft:water[level=0]
fill 414 52 -179 417 52 -179 minecraft:water[level=0]
setblock 418 52 -179 minecraft:tall_seagrass[half=upper]
fill 419 52 -179 422 52 -179 minecraft:water[level=0]
fill 392 52 -180 397 52 -180 minecraft:water[level=0]
setblock 413 52 -180 minecraft:water[level=0]
setblock 414 52 -180 minecraft:tall_seagrass[half=lower]
fill 415 52 -180 416 52 -180 minecraft:water[level=0]
setblock 417 52 -180 minecraft:tall_seagrass[half=lower]
fill 418 52 -180 422 52 -180 minecraft:water[level=0]
fill 392 52 -181 396 52 -181 minecraft:water[level=0]
setblock 397 52 -181 minecraft:kelp_plant
fill 414 52 -181 420 52 -181 minecraft:water[level=0]
setblock 421 52 -181 minecraft:tall_seagrass[half=lower]
setblock 422 52 -181 minecraft:water[level=0]
fill 392 52 -182 397 52 -182 minecraft:water[level=0]
fill 417 52 -182 418 52 -182 minecraft:tall_seagrass[half=lower]
setblock 419 52 -182 minecraft:water[level=0]
setblock 420 52 -182 minecraft:tall_seagrass[half=lower]
setblock 421 52 -182 minecraft:water[level=0]
setblock 422 52 -182 minecraft:seagrass
fill 392 52 -183 398 52 -183 minecraft:water[level=0]
setblock 420 52 -183 minecraft:tall_seagrass[half=lower]
setblock 421 52 -183 minecraft:seagrass
setblock 422 52 -183 minecraft:water[level=0]
fill 392 52 -184 393 52 -184 minecraft:water[level=0]
fill 394 52 -184 395 52 -184 minecraft:kelp_plant
setblock 396 52 -184 minecraft:water[level=0]
fill 397 52 -184 398 52 -184 minecraft:tall_seagrass[half=lower]
fill 392 52 -185 394 52 -185 minecraft:water[level=0]
fill 395 52 -185 396 52 -185 minecraft:kelp_plant
setblock 397 52 -185 minecraft:tall_seagrass[half=lower]
setblock 398 52 -185 minecraft:kelp_plant
setblock 422 52 -185 minecraft:seagrass
fill 392 52 -186 398 52 -186 minecraft:water[level=0]
setblock 422 52 -186 minecraft:seagrass
fill 392 52 -187 396 52 -187 minecraft:water[level=0]
setblock 397 52 -187 minecraft:tall_seagrass[half=upper]
setblock 398 52 -187 minecraft:kelp_plant
setblock 421 52 -187 minecraft:water[level=0]
setblock 392 52 -188 minecraft:water[level=0]
setblock 393 52 -188 minecraft:kelp_plant
fill 394 52 -188 397 52 -188 minecraft:water[level=0]
setblock 398 52 -188 minecraft:seagrass
fill 421 52 -188 422 52 -188 minecraft:water[level=0]
fill 392 52 -189 399 52 -189 minecraft:water[level=0]
setblock 422 52 -189 minecraft:water[level=0]
fill 392 52 -190 396 52 -190 minecraft:water[level=0]
setblock 397 52 -190 minecraft:kelp_plant
setblock 398 52 -190 minecraft:tall_seagrass[half=upper]
setblock 399 52 -190 minecraft:water[level=0]
setblock 420 52 -190 minecraft:seagrass
setblock 422 52 -190 minecraft:water[level=0]
setblock 392 51 -127 minecraft:kelp_plant
fill 393 51 -127 395 51 -127 minecraft:water[level=0]
setblock 396 51 -127 minecraft:kelp_plant
fill 397 51 -127 402 51 -127 minecraft:water[level=0]
setblock 403 51 -127 minecraft:kelp_plant
fill 404 51 -127 411 51 -127 minecraft:water[level=0]
fill 392 51 -128 393 51 -128 minecraft:water[level=0]
setblock 394 51 -128 minecraft:kelp_plant
fill 395 51 -128 398 51 -128 minecraft:water[level=0]
setblock 399 51 -128 minecraft:kelp_plant
fill 400 51 -128 402 51 -128 minecraft:water[level=0]
setblock 403 51 -128 minecraft:kelp_plant
fill 404 51 -128 412 51 -128 minecraft:water[level=0]
fill 392 51 -129 393 51 -129 minecraft:water[level=0]
setblock 394 51 -129 minecraft:kelp_plant
fill 395 51 -129 413 51 -129 minecraft:water[level=0]
fill 392 51 -130 396 51 -130 minecraft:water[level=0]
setblock 397 51 -130 minecraft:kelp_plant
fill 398 51 -130 414 51 -130 minecraft:water[level=0]
setblock 392 51 -131 minecraft:water[level=0]
setblock 393 51 -131 minecraft:kelp_plant
fill 394 51 -131 413 51 -131 minecraft:water[level=0]
setblock 414 51 -131 minecraft:tall_seagrass[half=upper]
setblock 415 51 -131 minecraft:water[level=0]
setblock 392 51 -132 minecraft:kelp_plant
fill 393 51 -132 415 51 -132 minecraft:water[level=0]
setblock 392 51 -133 minecraft:water[level=0]
setblock 393 51 -133 minecraft:kelp_plant
fill 394 51 -133 416 51 -133 minecraft:water[level=0]
fill 392 51 -134 393 51 -134 minecraft:water[level=0]
setblock 394 51 -134 minecraft:kelp_plant
fill 395 51 -134 397 51 -134 minecraft:water[level=0]
fill 398 51 -134 399 51 -134 minecraft:kelp_plant
fill 400 51 -134 417 51 -134 minecraft:water[level=0]
fill 392 51 -135 417 51 -135 minecraft:water[level=0]
setblock 392 51 -136 minecraft:seagrass
fill 393 51 -136 418 51 -136 minecraft:water[level=0]
fill 392 51 -137 394 51 -137 minecraft:water[level=0]
setblock 395 51 -137 minecraft:kelp_plant
fill 396 51 -137 418 51 -137 minecraft:water[level=0]
fill 392 51 -138 419 51 -138 minecraft:water[level=0]
setblock 392 51 -139 minecraft:water[level=0]
setblock 393 51 -139 minecraft:seagrass
fill 394 51 -139 398 51 -139 minecraft:water[level=0]
setblock 399 51 -139 minecraft:kelp_plant
fill 400 51 -139 419 51 -139 minecraft:water[level=0]
setblock 392 51 -140 minecraft:kelp_plant
fill 393 51 -140 394 51 -140 minecraft:water[level=0]
setblock 395 51 -140 minecraft:tall_seagrass[half=upper]
fill 396 51 -140 419 51 -140 minecraft:water[level=0]
fill 392 51 -141 396 51 -141 minecraft:water[level=0]
setblock 397 51 -141 minecraft:kelp_plant
fill 398 51 -141 420 51 -141 minecraft:water[level=0]
fill 392 51 -142 396 51 -142 minecraft:water[level=0]
fill 397 51 -142 398 51 -142 minecraft:kelp_plant
fill 399 51 -142 420 51 -142 minecraft:water[level=0]
setblock 392 51 -143 minecraft:water[level=0]
setblock 393 51 -143 minecraft:kelp_plant
fill 394 51 -143 420 51 -143 minecraft:water[level=0]
setblock 393 51 -144 minecraft:kelp_plant
fill 394 51 -144 421 51 -144 minecraft:water[level=0]
fill 392 51 -145 398 51 -145 minecraft:water[level=0]
setblock 399 51 -145 minecraft:kelp_plant
fill 400 51 -145 409 51 -145 minecraft:water[level=0]
setblock 410 51 -145 minecraft:tall_seagrass[half=upper]
fill 411 51 -145 421 51 -145 minecraft:water[level=0]
fill 392 51 -146 394 51 -146 minecraft:water[level=0]
setblock 395 51 -146 minecraft:kelp_plant
fill 396 51 -146 397 51 -146 minecraft:water[level=0]
fill 398 51 -146 399 51 -146 minecraft:kelp_plant
fill 400 51 -146 410 51 -146 minecraft:water[level=0]
setblock 411 51 -146 minecraft:tall_seagrass[half=upper]
fill 412 51 -146 421 51 -146 minecraft:water[level=0]
setblock 392 51 -147 minecraft:water[level=0]
setblock 393 51 -147 minecraft:kelp_plant
fill 394 51 -147 396 51 -147 minecraft:water[level=0]
setblock 397 51 -147 minecraft:kelp_plant
fill 398 51 -147 403 51 -147 minecraft:water[level=0]
setblock 404 51 -147 minecraft:tall_seagrass[half=upper]
fill 405 51 -147 421 51 -147 minecraft:water[level=0]
fill 392 51 -148 393 51 -148 minecraft:kelp_plant
fill 394 51 -148 395 51 -148 minecraft:water[level=0]
setblock 396 51 -148 minecraft:kelp_plant
fill 397 51 -148 401 51 -148 minecraft:water[level=0]
setblock 402 51 -148 minecraft:tall_seagrass[half=upper]
fill 403 51 -148 421 51 -148 minecraft:water[level=0]
fill 392 51 -149 393 51 -149 minecraft:water[level=0]
setblock 394 51 -149 minecraft:kelp_plant
fill 395 51 -149 397 51 -149 minecraft:water[level=0]
setblock 398 51 -149 minecraft:kelp_plant
fill 399 51 -149 401 51 -149 minecraft:water[level=0]
setblock 402 51 -149 minecraft:tall_seagrass[half=upper]
fill 403 51 -149 421 51 -149 minecraft:water[level=0]
setblock 392 51 -150 minecraft:kelp_plant
setblock 393 51 -150 minecraft:water[level=0]
setblock 394 51 -150 minecraft:kelp_plant
fill 395 51 -150 421 51 -150 minecraft:water[level=0]
setblock 392 51 -151 minecraft:seagrass
fill 393 51 -151 398 51 -151 minecraft:water[level=0]
setblock 399 51 -151 minecraft:kelp_plant
fill 400 51 -151 421 51 -151 minecraft:water[level=0]
fill 392 51 -152 393 51 -152 minecraft:water[level=0]
setblock 394 51 -152 minecraft:tall_seagrass[half=upper]
fill 395 51 -152 396 51 -152 minecraft:water[level=0]
setblock 397 51 -152 minecraft:kelp_plant
setblock 398 51 -152 minecraft:water[level=0]
setblock 399 51 -152 minecraft:kelp_plant
fill 400 51 -152 422 51 -152 minecraft:water[level=0]
setblock 392 51 -153 minecraft:tall_seagrass[half=lower]
fill 393 51 -153 422 51 -153 minecraft:water[level=0]
fill 392 51 -154 393 51 -154 minecraft:seagrass
fill 394 51 -154 395 51 -154 minecraft:water[level=0]
setblock 396 51 -154 minecraft:kelp_plant
fill 397 51 -154 398 51 -154 minecraft:water[level=0]
setblock 399 51 -154 minecraft:kelp_plant
fill 400 51 -154 401 51 -154 minecraft:water[level=0]
setblock 402 51 -154 minecraft:seagrass
setblock 403 51 -154 minecraft:water[level=0]
setblock 404 51 -154 minecraft:tall_seagrass[half=lower]
fill 405 51 -154 406 51 -154 minecraft:water[level=0]
setblock 407 51 -154 minecraft:tall_seagrass[half=lower]
setblock 408 51 -154 minecraft:water[level=0]
setblock 409 51 -154 minecraft:seagrass
fill 410 51 -154 412 51 -154 minecraft:water[level=0]
setblock 413 51 -154 minecraft:seagrass
fill 414 51 -154 422 51 -154 minecraft:water[level=0]
fill 392 51 -155 395 51 -155 minecraft:water[level=0]
setblock 396 51 -155 minecraft:kelp_plant
fill 397 51 -155 400 51 -155 minecraft:water[level=0]
setblock 401 51 -155 minecraft:seagrass
setblock 402 51 -155 minecraft:water[level=0]
setblock 403 51 -155 minecraft:tall_seagrass[half=lower]
fill 404 51 -155 405 51 -155 minecraft:water[level=0]
fill 411 51 -155 422 51 -155 minecraft:water[level=0]
setblock 392 51 -156 minecraft:kelp_plant
setblock 393 51 -156 minecraft:tall_seagrass[half=upper]
fill 394 51 -156 396 51 -156 minecraft:water[level=0]
fill 397 51 -156 399 51 -156 minecraft:kelp_plant
fill 400 51 -156 404 51 -156 minecraft:water[level=0]
setblock 413 51 -156 minecraft:seagrass
fill 414 51 -156 422 51 -156 minecraft:water[level=0]
setblock 392 51 -157 minecraft:seagrass
setblock 393 51 -157 minecraft:tall_seagrass[half=upper]
setblock 394 51 -157 minecraft:water[level=0]
setblock 395 51 -157 minecraft:kelp_plant
fill 396 51 -157 397 51 -157 minecraft:water[level=0]
setblock 398 51 -157 minecraft:kelp_plant
setblock 399 51 -157 minecraft:water[level=0]
setblock 400 51 -157 minecraft:seagrass
fill 401 51 -157 403 51 -157 minecraft:water[level=0]
fill 414 51 -157 422 51 -157 minecraft:water[level=0]
fill 392 51 -158 393 51 -158 minecraft:water[level=0]
setblock 394 51 -158 minecraft:kelp_plant
fill 395 51 -158 401 51 -158 minecraft:water[level=0]
fill 414 51 -158 422 51 -158 minecraft:water[level=0]
setblock 392 51 -159 minecraft:seagrass
fill 393 51 -159 396 51 -159 minecraft:water[level=0]
setblock 397 51 -159 minecraft:kelp_plant
fill 398 51 -159 400 51 -159 minecraft:water[level=0]
fill 415 51 -159 422 51 -159 minecraft:water[level=0]
fill 392 51 -160 396 51 -160 minecraft:water[level=0]
setblock 397 51 -160 minecraft:kelp_plant
fill 398 51 -160 400 51 -160 minecraft:water[level=0]
fill 416 51 -160 422 51 -160 minecraft:water[level=0]
setblock 392 51 -161 minecraft:kelp_plant
fill 393 51 -161 396 51 -161 minecraft:water[level=0]
setblock 397 51 -161 minecraft:kelp_plant
setblock 398 51 -161 minecraft:tall_seagrass[half=upper]
setblock 399 51 -161 minecraft:kelp_plant
fill 416 51 -161 422 51 -161 minecraft:water[level=0]
setblock 392 51 -162 minecraft:water[level=0]
setblock 393 51 -162 minecraft:kelp_plant
fill 394 51 -162 396 51 -162 minecraft:water[level=0]
setblock 397 51 -162 minecraft:kelp_plant
fill 398 51 -162 399 51 -162 minecraft:water[level=0]
fill 417 51 -162 422 51 -162 minecraft:water[level=0]
fill 392 51 -163 393 51 -163 minecraft:kelp_plant
setblock 394 51 -163 minecraft:water[level=0]
setblock 395 51 -163 minecraft:tall_seagrass[half=upper]
fill 396 51 -163 398 51 -163 minecraft:water[level=0]
fill 417 51 -163 422 51 -163 minecraft:water[level=0]
setblock 392 51 -164 minecraft:water[level=0]
setblock 393 51 -164 minecraft:seagrass
setblock 394 51 -164 minecraft:water[level=0]
setblock 395 51 -164 minecraft:tall_seagrass[half=upper]
fill 396 51 -164 398 51 -164 minecraft:water[level=0]
fill 417 51 -164 422 51 -164 minecraft:water[level=0]
setblock 392 51 -165 minecraft:kelp_plant
setblock 393 51 -165 minecraft:seagrass
fill 394 51 -165 398 51 -165 minecraft:water[level=0]
setblock 418 51 -165 minecraft:water[level=0]
fill 420 51 -165 422 51 -165 minecraft:water[level=0]
setblock 392 51 -166 minecraft:water[level=0]
setblock 393 51 -166 minecraft:seagrass
setblock 394 51 -166 minecraft:water[level=0]
setblock 395 51 -166 minecraft:kelp_plant
fill 396 51 -166 397 51 -166 minecraft:water[level=0]
setblock 418 51 -166 minecraft:water[level=0]
fill 420 51 -166 422 51 -166 minecraft:water[level=0]
setblock 392 51 -167 minecraft:kelp_plant
setblock 393 51 -167 minecraft:water[level=0]
setblock 394 51 -167 minecraft:kelp_plant
fill 395 51 -167 397 51 -167 minecraft:water[level=0]
fill 420 51 -167 422 51 -167 minecraft:water[level=0]
setblock 392 51 -168 minecraft:water[level=0]
setblock 393 51 -168 minecraft:kelp_plant
setblock 394 51 -168 minecraft:seagrass
setblock 395 51 -168 minecraft:water[level=0]
setblock 396 51 -168 minecraft:kelp_plant
setblock 397 51 -168 minecraft:tall_seagrass[half=lower]
fill 420 51 -168 422 51 -168 minecraft:water[level=0]
fill 392 51 -169 393 51 -169 minecraft:kelp_plant
setblock 394 51 -169 minecraft:tall_seagrass[half=lower]
setblock 395 51 -169 minecraft:seagrass
setblock 396 51 -169 minecraft:tall_seagrass[half=lower]
setblock 418 51 -169 minecraft:water[level=0]
fill 421 51 -169 422 51 -169 minecraft:water[level=0]
setblock 392 51 -170 minecraft:tall_seagrass[half=lower]
fill 393 51 -170 394 51 -170 minecraft:water[level=0]
setblock 395 51 -170 minecraft:tall_seagrass[half=lower]
setblock 396 51 -170 minecraft:water[level=0]
fill 421 51 -170 422 51 -170 minecraft:water[level=0]
setblock 394 51 -171 minecraft:seagrass
setblock 395 51 -171 minecraft:water[level=0]
setblock 396 51 -171 minecraft:kelp_plant
setblock 422 51 -171 minecraft:water[level=0]
setblock 422 51 -172 minecraft:water[level=0]
fill 419 51 -173 420 51 -173 minecraft:water[level=0]
setblock 419 51 -174 minecraft:water[level=0]
setblock 418 51 -175 minecraft:seagrass
fill 420 51 -175 422 51 -175 minecraft:water[level=0]
setblock 418 51 -176 minecraft:water[level=0]
fill 420 51 -176 422 51 -176 minecraft:water[level=0]
setblock 418 51 -177 minecraft:water[level=0]
fill 419 51 -177 420 51 -177 minecraft:seagrass
fill 421 51 -177 422 51 -177 minecraft:water[level=0]
setblock 418 51 -178 minecraft:seagrass
setblock 419 51 -178 minecraft:tall_seagrass[half=lower]
fill 420 51 -178 421 51 -178 minecraft:water[level=0]
setblock 422 51 -178 minecraft:seagrass
setblock 418 51 -179 minecraft:tall_seagrass[half=lower]
setblock 419 51 -179 minecraft:seagrass
fill 420 51 -179 422 51 -179 minecraft:water[level=0]
setblock 392 51 -180 minecraft:water[level=0]
setblock 418 51 -180 minecraft:water[level=0]
setblock 419 51 -180 minecraft:seagrass
fill 420 51 -180 421 51 -180 minecraft:water[level=0]
fill 392 51 -181 394 51 -181 minecraft:water[level=0]
fill 392 51 -182 395 51 -182 minecraft:water[level=0]
fill 392 51 -183 396 51 -183 minecraft:water[level=0]
fill 392 51 -184 393 51 -184 minecraft:water[level=0]
fill 394 51 -184 395 51 -184 minecraft:kelp_plant
setblock 396 51 -184 minecraft:water[level=0]
fill 392 51 -185 394 51 -185 minecraft:water[level=0]
fill 395 51 -185 396 51 -185 minecraft:kelp_plant
fill 392 51 -186 397 51 -186 minecraft:water[level=0]
setblock 392 51 -187 minecraft:water[level=0]
setblock 393 51 -187 minecraft:tall_seagrass[half=upper]
fill 394 51 -187 396 51 -187 minecraft:water[level=0]
setblock 397 51 -187 minecraft:tall_seagrass[half=lower]
setblock 392 51 -188 minecraft:water[level=0]
setblock 393 51 -188 minecraft:kelp_plant
fill 394 51 -188 396 51 -188 minecraft:water[level=0]
setblock 397 51 -188 minecraft:seagrass
fill 392 51 -189 398 51 -189 minecraft:water[level=0]
fill 392 51 -190 396 51 -190 minecraft:water[level=0]
setblock 397 51 -190 minecraft:kelp_plant
setblock 398 51 -190 minecraft:tall_seagrass[half=lower]
setblock 392 50 -127 minecraft:kelp_plant
fill 393 50 -127 395 50 -127 minecraft:water[level=0]
setblock 396 50 -127 minecraft:kelp_plant
fill 397 50 -127 402 50 -127 minecraft:water[level=0]
setblock 403 50 -127 minecraft:kelp_plant
fill 404 50 -127 411 50 -127 minecraft:water[level=0]
fill 392 50 -128 393 50 -128 minecraft:water[level=0]
setblock 394 50 -128 minecraft:kelp_plant
fill 395 50 -128 398 50 -128 minecraft:water[level=0]
setblock 399 50 -128 minecraft:kelp_plant
fill 400 50 -128 402 50 -128 minecraft:water[level=0]
setblock 403 50 -128 minecraft:kelp_plant
fill 404 50 -128 412 50 -128 minecraft:water[level=0]
fill 392 50 -129 393 50 -129 minecraft:water[level=0]
setblock 394 50 -129 minecraft:kelp_plant
fill 395 50 -129 411 50 -129 minecraft:water[level=0]
setblock 412 50 -129 minecraft:seagrass
setblock 413 50 -129 minecraft:water[level=0]
fill 392 50 -130 396 50 -130 minecraft:water[level=0]
setblock 397 50 -130 minecraft:kelp_plant
fill 398 50 -130 413 50 -130 minecraft:water[level=0]
setblock 414 50 -130 minecraft:seagrass
setblock 392 50 -131 minecraft:water[level=0]
setblock 393 50 -131 minecraft:kelp_plant
fill 394 50 -131 413 50 -131 minecraft:water[level=0]
setblock 414 50 -131 minecraft:tall_seagrass[half=lower]
setblock 415 50 -131 minecraft:water[level=0]
setblock 392 50 -132 minecraft:kelp_plant
fill 393 50 -132 415 50 -132 minecraft:water[level=0]
setblock 392 50 -133 minecraft:water[level=0]
setblock 393 50 -133 minecraft:kelp_plant
fill 394 50 -133 395 50 -133 minecraft:water[level=0]
setblock 396 50 -133 minecraft:tall_seagrass[half=upper]
fill 397 50 -133 416 50 -133 minecraft:water[level=0]
fill 392 50 -134 393 50 -134 minecraft:water[level=0]
setblock 394 50 -134 minecraft:kelp_plant
fill 395 50 -134 397 50 -134 minecraft:water[level=0]
fill 398 50 -134 399 50 -134 minecraft:kelp_plant
fill 400 50 -134 417 50 -134 minecraft:water[level=0]
fill 392 50 -135 417 50 -135 minecraft:water[level=0]
fill 393 50 -136 418 50 -136 minecraft:water[level=0]
fill 393 50 -137 394 50 -137 minecraft:seagrass
setblock 395 50 -137 minecraft:kelp_plant
fill 396 50 -137 418 50 -137 minecraft:water[level=0]
fill 393 50 -138 397 50 -138 minecraft:water[level=0]
setblock 398 50 -138 minecraft:tall_seagrass[half=upper]
fill 399 50 -138 419 50 -138 minecraft:water[level=0]
setblock 394 50 -139 minecraft:water[level=0]
setblock 395 50 -139 minecraft:seagrass
setblock 396 50 -139 minecraft:water[level=0]
setblock 397 50 -139 minecraft:tall_seagrass[half=upper]
setblock 398 50 -139 minecraft:water[level=0]
setblock 399 50 -139 minecraft:kelp_plant
setblock 400 50 -139 minecraft:tall_seagrass[half=upper]
fill 401 50 -139 408 50 -139 minecraft:water[level=0]
setblock 409 50 -139 minecraft:tall_seagrass[half=upper]
fill 410 50 -139 419 50 -139 minecraft:water[level=0]
setblock 394 50 -140 minecraft:water[level=0]
setblock 395 50 -140 minecraft:tall_seagrass[half=lower]
fill 396 50 -140 419 50 -140 minecraft:water[level=0]
fill 394 50 -141 395 50 -141 minecraft:water[level=0]
setblock 396 50 -141 minecraft:tall_seagrass[half=upper]
setblock 397 50 -141 minecraft:kelp_plant
fill 398 50 -141 420 50 -141 minecraft:water[level=0]
setblock 394 50 -142 minecraft:water[level=0]
setblock 395 50 -142 minecraft:seagrass
setblock 396 50 -142 minecraft:water[level=0]
fill 397 50 -142 398 50 -142 minecraft:kelp_plant
fill 399 50 -142 420 50 -142 minecraft:water[level=0]
fill 395 50 -143 410 50 -143 minecraft:water[level=0]
setblock 411 50 -143 minecraft:seagrass
fill 412 50 -143 420 50 -143 minecraft:water[level=0]
fill 395 50 -144 401 50 -144 minecraft:water[level=0]
setblock 402 50 -144 minecraft:tall_seagrass[half=upper]
fill 403 50 -144 405 50 -144 minecraft:water[level=0]
setblock 406 50 -144 minecraft:tall_seagrass[half=upper]
fill 407 50 -144 421 50 -144 minecraft:water[level=0]
fill 395 50 -145 398 50 -145 minecraft:water[level=0]
setblock 399 50 -145 minecraft:kelp_plant
fill 400 50 -145 409 50 -145 minecraft:water[level=0]
setblock 410 50 -145 minecraft:tall_seagrass[half=lower]
fill 411 50 -145 421 50 -145 minecraft:water[level=0]
setblock 394 50 -146 minecraft:water[level=0]
setblock 395 50 -146 minecraft:kelp_plant
fill 396 50 -146 397 50 -146 minecraft:water[level=0]
fill 398 50 -146 399 50 -146 minecraft:kelp_plant
fill 400 50 -146 402 50 -146 minecraft:water[level=0]
setblock 403 50 -146 minecraft:tall_seagrass[half=upper]
fill 404 50 -146 410 50 -146 minecraft:water[level=0]
setblock 411 50 -146 minecraft:tall_seagrass[half=lower]
fill 412 50 -146 421 50 -146 minecraft:water[level=0]
fill 394 50 -147 396 50 -147 minecraft:water[level=0]
setblock 397 50 -147 minecraft:kelp_plant
fill 398 50 -147 403 50 -147 minecraft:water[level=0]
setblock 404 50 -147 minecraft:tall_seagrass[half=lower]
fill 405 50 -147 406 50 -147 minecraft:water[level=0]
setblock 407 50 -147 minecraft:seagrass
fill 408 50 -147 421 50 -147 minecraft:water[level=0]
fill 394 50 -148 395 50 -148 minecraft:water[level=0]
setblock 396 50 -148 minecraft:kelp_plant
fill 397 50 -148 401 50 -148 minecraft:water[level=0]
setblock 402 50 -148 minecraft:tall_seagrass[half=lower]
setblock 403 50 -148 minecraft:seagrass
fill 404 50 -148 421 50 -148 minecraft:water[level=0]
setblock 394 50 -149 minecraft:kelp_plant
setblock 395 50 -149 minecraft:seagrass
fill 396 50 -149 397 50 -149 minecraft:water[level=0]
setblock 398 50 -149 minecraft:kelp_plant
fill 399 50 -149 400 50 -149 minecraft:water[level=0]
setblock 402 50 -149 minecraft:tall_seagrass[half=lower]
fill 403 50 -149 404 50 -149 minecraft:water[level=0]
setblock 405 50 -149 minecraft:seagrass
fill 406 50 -149 408 50 -149 minecraft:water[level=0]
setblock 409 50 -149 minecraft:seagrass
fill 410 50 -149 421 50 -149 minecraft:water[level=0]
setblock 394 50 -150 minecraft:kelp_plant
fill 395 50 -150 400 50 -150 minecraft:water[level=0]
fill 402 50 -150 421 50 -150 minecraft:water[level=0]
fill 394 50 -151 398 50 -151 minecraft:water[level=0]
setblock 399 50 -151 minecraft:kelp_plant
fill 400 50 -151 404 50 -151 minecraft:water[level=0]
fill 410 50 -151 421 50 -151 minecraft:water[level=0]
setblock 394 50 -152 minecraft:tall_seagrass[half=lower]
fill 395 50 -152 396 50 -152 minecraft:water[level=0]
setblock 397 50 -152 minecraft:kelp_plant
setblock 398 50 -152 minecraft:water[level=0]
setblock 399 50 -152 minecraft:kelp_plant
fill 400 50 -152 403 50 -152 minecraft:water[level=0]
fill 411 50 -152 422 50 -152 minecraft:water[level=0]
setblock 394 50 -153 minecraft:seagrass
fill 395 50 -153 400 50 -153 minecraft:water[level=0]
setblock 401 50 -153 minecraft:seagrass
setblock 402 50 -153 minecraft:water[level=0]
fill 413 50 -153 421 50 -153 minecraft:water[level=0]
setblock 394 50 -154 minecraft:seagrass
setblock 395 50 -154 minecraft:water[level=0]
setblock 396 50 -154 minecraft:kelp_plant
setblock 397 50 -154 minecraft:water[level=0]
setblock 398 50 -154 minecraft:tall_seagrass[half=upper]
setblock 399 50 -154 minecraft:kelp_plant
fill 400 50 -154 401 50 -154 minecraft:water[level=0]
fill 414 50 -154 422 50 -154 minecraft:water[level=0]
fill 393 50 -155 395 50 -155 minecraft:water[level=0]
setblock 396 50 -155 minecraft:kelp_plant
fill 397 50 -155 400 50 -155 minecraft:water[level=0]
fill 415 50 -155 421 50 -155 minecraft:water[level=0]
setblock 393 50 -156 minecraft:tall_seagrass[half=lower]
fill 394 50 -156 396 50 -156 minecraft:water[level=0]
fill 397 50 -156 399 50 -156 minecraft:kelp_plant
setblock 400 50 -156 minecraft:water[level=0]
fill 416 50 -156 422 50 -156 minecraft:water[level=0]
setblock 393 50 -157 minecraft:tall_seagrass[half=lower]
setblock 394 50 -157 minecraft:water[level=0]
setblock 395 50 -157 minecraft:kelp_plant
fill 396 50 -157 397 50 -157 minecraft:water[level=0]
setblock 398 50 -157 minecraft:kelp_plant
setblock 399 50 -157 minecraft:water[level=0]
fill 416 50 -157 422 50 -157 minecraft:water[level=0]
setblock 393 50 -158 minecraft:water[level=0]
setblock 394 50 -158 minecraft:kelp_plant
fill 395 50 -158 399 50 -158 minecraft:water[level=0]
fill 417 50 -158 422 50 -158 minecraft:water[level=0]
fill 393 50 -159 394 50 -159 minecraft:water[level=0]
setblock 395 50 -159 minecraft:tall_seagrass[half=upper]
setblock 396 50 -159 minecraft:water[level=0]
setblock 397 50 -159 minecraft:kelp_plant
fill 398 50 -159 399 50 -159 minecraft:water[level=0]
fill 417 50 -159 422 50 -159 minecraft:water[level=0]
fill 393 50 -160 394 50 -160 minecraft:water[level=0]
setblock 395 50 -160 minecraft:tall_seagrass[half=upper]
setblock 396 50 -160 minecraft:water[level=0]
setblock 397 50 -160 minecraft:kelp_plant
setblock 398 50 -160 minecraft:water[level=0]
fill 418 50 -160 422 50 -160 minecraft:water[level=0]
fill 393 50 -161 396 50 -161 minecraft:water[level=0]
setblock 397 50 -161 minecraft:kelp_plant
setblock 398 50 -161 minecraft:tall_seagrass[half=lower]
fill 418 50 -161 422 50 -161 minecraft:water[level=0]
setblock 393 50 -162 minecraft:kelp_plant
fill 394 50 -162 396 50 -162 minecraft:water[level=0]
setblock 397 50 -162 minecraft:kelp_plant
setblock 398 50 -162 minecraft:water[level=0]
fill 419 50 -162 422 50 -162 minecraft:water[level=0]
setblock 394 50 -163 minecraft:seagrass
setblock 395 50 -163 minecraft:tall_seagrass[half=lower]
fill 396 50 -163 397 50 -163 minecraft:water[level=0]
fill 419 50 -163 422 50 -163 minecraft:water[level=0]
setblock 394 50 -164 minecraft:seagrass
setblock 395 50 -164 minecraft:tall_seagrass[half=lower]
fill 396 50 -164 397 50 -164 minecraft:water[level=0]
fill 419 50 -164 422 50 -164 minecraft:water[level=0]
setblock 394 50 -165 minecraft:seagrass
fill 395 50 -165 396 50 -165 minecraft:water[level=0]
setblock 397 50 -165 minecraft:seagrass
fill 421 50 -165 422 50 -165 minecraft:water[level=0]
setblock 395 50 -166 minecraft:kelp_plant
setblock 396 50 -166 minecraft:water[level=0]
setblock 396 50 -167 minecraft:seagrass
setblock 421 50 -167 minecraft:water[level=0]
setblock 421 50 -168 minecraft:water[level=0]
fill 421 50 -169 422 50 -169 minecraft:water[level=0]
setblock 420 50 -176 minecraft:water[level=0]
fill 421 50 -177 422 50 -177 minecraft:water[level=0]
setblock 392 50 -185 minecraft:seagrass
fill 393 50 -185 394 50 -185 minecraft:water[level=0]
setblock 395 50 -185 minecraft:kelp_plant
fill 392 50 -186 394 50 -186 minecraft:water[level=0]
fill 395 50 -186 396 50 -186 minecraft:seagrass
setblock 392 50 -187 minecraft:water[level=0]
setblock 393 50 -187 minecraft:tall_seagrass[half=lower]
fill 394 50 -187 396 50 -187 minecraft:water[level=0]
setblock 392 50 -188 minecraft:water[level=0]
setblock 393 50 -188 minecraft:kelp_plant
fill 394 50 -188 396 50 -188 minecraft:water[level=0]
fill 392 50 -189 397 50 -189 minecraft:water[level=0]
fill 392 50 -190 396 50 -190 minecraft:water[level=0]
setblock 397 50 -190 minecraft:kelp_plant
setblock 392 49 -127 minecraft:kelp_plant
fill 393 49 -127 395 49 -127 minecraft:water[level=0]
setblock 396 49 -127 minecraft:kelp_plant
fill 397 49 -127 402 49 -127 minecraft:water[level=0]
setblock 403 49 -127 minecraft:kelp_plant
fill 404 49 -127 407 49 -127 minecraft:water[level=0]
fill 392 49 -128 393 49 -128 minecraft:water[level=0]
setblock 394 49 -128 minecraft:kelp_plant
fill 395 49 -128 398 49 -128 minecraft:water[level=0]
setblock 399 49 -128 minecraft:kelp_plant
fill 400 49 -128 402 49 -128 minecraft:water[level=0]
setblock 403 49 -128 minecraft:kelp_plant
fill 404 49 -128 407 49 -128 minecraft:water[level=0]
fill 392 49 -129 393 49 -129 minecraft:water[level=0]
setblock 394 49 -129 minecraft:kelp_plant
fill 395 49 -129 407 49 -129 minecraft:water[level=0]
fill 392 49 -130 396 49 -130 minecraft:water[level=0]
setblock 397 49 -130 minecraft:kelp_plant
fill 398 49 -130 407 49 -130 minecraft:water[level=0]
setblock 392 49 -131 minecraft:water[level=0]
setblock 393 49 -131 minecraft:kelp_plant
fill 394 49 -131 407 49 -131 minecraft:water[level=0]
setblock 392 49 -132 minecraft:kelp_plant
setblock 393 49 -132 minecraft:water[level=0]
setblock 394 49 -132 minecraft:seagrass
fill 395 49 -132 407 49 -132 minecraft:water[level=0]
setblock 394 49 -133 minecraft:water[level=0]
setblock 395 49 -133 minecraft:seagrass
setblock 396 49 -133 minecraft:tall_seagrass[half=lower]
setblock 397 49 -133 minecraft:seagrass
fill 398 49 -133 407 49 -133 minecraft:water[level=0]
setblock 395 49 -134 minecraft:seagrass
setblock 396 49 -134 minecraft:water[level=0]
setblock 397 49 -134 minecraft:seagrass
fill 398 49 -134 399 49 -134 minecraft:kelp_plant
fill 400 49 -134 407 49 -134 minecraft:water[level=0]
fill 392 49 -135 407 49 -135 minecraft:water[level=0]
fill 393 49 -136 407 49 -136 minecraft:water[level=0]
fill 396 49 -137 408 49 -137 minecraft:water[level=0]
fill 396 49 -138 397 49 -138 minecraft:seagrass
setblock 398 49 -138 minecraft:tall_seagrass[half=lower]
setblock 399 49 -138 minecraft:water[level=0]
setblock 400 49 -138 minecraft:seagrass
fill 401 49 -138 409 49 -138 minecraft:water[level=0]
fill 417 49 -138 419 49 -138 minecraft:water[level=0]
setblock 396 49 -139 minecraft:seagrass
setblock 397 49 -139 minecraft:tall_seagrass[half=lower]
setblock 398 49 -139 minecraft:water[level=0]
setblock 399 49 -139 minecraft:kelp_plant
setblock 400 49 -139 minecraft:tall_seagrass[half=lower]
fill 401 49 -139 407 49 -139 minecraft:water[level=0]
setblock 408 49 -139 minecraft:seagrass
setblock 409 49 -139 minecraft:tall_seagrass[half=lower]
fill 416 49 -139 419 49 -139 minecraft:water[level=0]
setblock 396 49 -140 minecraft:water[level=0]
setblock 397 49 -140 minecraft:seagrass
fill 398 49 -140 399 49 -140 minecraft:water[level=0]
setblock 400 49 -140 minecraft:seagrass
fill 401 49 -140 410 49 -140 minecraft:water[level=0]
fill 415 49 -140 419 49 -140 minecraft:water[level=0]
setblock 396 49 -141 minecraft:tall_seagrass[half=lower]
setblock 397 49 -141 minecraft:kelp_plant
fill 400 49 -141 401 49 -141 minecraft:seagrass
setblock 404 49 -141 minecraft:water[level=0]
fill 407 49 -141 410 49 -141 minecraft:water[level=0]
fill 415 49 -141 420 49 -141 minecraft:water[level=0]
setblock 396 49 -142 minecraft:water[level=0]
fill 397 49 -142 398 49 -142 minecraft:kelp_plant
setblock 399 49 -142 minecraft:water[level=0]
setblock 401 49 -142 minecraft:seagrass
fill 402 49 -142 403 49 -142 minecraft:water[level=0]
setblock 404 49 -142 minecraft:seagrass
fill 406 49 -142 410 49 -142 minecraft:water[level=0]
fill 415 49 -142 420 49 -142 minecraft:water[level=0]
setblock 396 49 -143 minecraft:seagrass
fill 397 49 -143 399 49 -143 minecraft:water[level=0]
fill 401 49 -143 402 49 -143 minecraft:water[level=0]
setblock 404 49 -143 minecraft:water[level=0]
fill 406 49 -143 409 49 -143 minecraft:water[level=0]
setblock 410 49 -143 minecraft:seagrass
fill 415 49 -143 418 49 -143 minecraft:water[level=0]
setblock 396 49 -144 minecraft:seagrass
setblock 397 49 -144 minecraft:water[level=0]
fill 400 49 -144 401 49 -144 minecraft:water[level=0]
setblock 402 49 -144 minecraft:tall_seagrass[half=lower]
setblock 406 49 -144 minecraft:tall_seagrass[half=lower]
setblock 407 49 -144 minecraft:seagrass
fill 408 49 -144 410 49 -144 minecraft:water[level=0]
fill 415 49 -144 421 49 -144 minecraft:water[level=0]
fill 396 49 -145 398 49 -145 minecraft:water[level=0]
setblock 399 49 -145 minecraft:kelp_plant
setblock 401 49 -145 minecraft:seagrass
fill 407 49 -145 409 49 -145 minecraft:seagrass
fill 414 49 -145 421 49 -145 minecraft:water[level=0]
fill 396 49 -146 397 49 -146 minecraft:water[level=0]
fill 398 49 -146 399 49 -146 minecraft:kelp_plant
fill 401 49 -146 402 49 -146 minecraft:water[level=0]
setblock 403 49 -146 minecraft:tall_seagrass[half=lower]
fill 414 49 -146 421 49 -146 minecraft:water[level=0]
setblock 396 49 -147 minecraft:water[level=0]
setblock 397 49 -147 minecraft:kelp_plant
fill 398 49 -147 399 49 -147 minecraft:water[level=0]
setblock 401 49 -147 minecraft:water[level=0]
fill 414 49 -147 421 49 -147 minecraft:water[level=0]
setblock 396 49 -148 minecraft:kelp_plant
fill 397 49 -148 399 49 -148 minecraft:water[level=0]
fill 414 49 -148 421 49 -148 minecraft:water[level=0]
setblock 396 49 -149 minecraft:seagrass
setblock 397 49 -149 minecraft:water[level=0]
setblock 398 49 -149 minecraft:kelp_plant
setblock 399 49 -149 minecraft:water[level=0]
fill 415 49 -149 421 49 -149 minecraft:water[level=0]
setblock 395 49 -150 minecraft:seagrass
fill 396 49 -150 399 49 -150 minecraft:water[level=0]
fill 415 49 -150 421 49 -150 minecraft:water[level=0]
fill 395 49 -151 398 49 -151 minecraft:water[level=0]
setblock 399 49 -151 minecraft:kelp_plant
fill 416 49 -151 421 49 -151 minecraft:water[level=0]
setblock 395 49 -152 minecraft:seagrass
setblock 396 49 -152 minecraft:water[level=0]
setblock 397 49 -152 minecraft:kelp_plant
setblock 398 49 -152 minecraft:water[level=0]
setblock 399 49 -152 minecraft:kelp_plant
fill 416 49 -152 421 49 -152 minecraft:water[level=0]
fill 395 49 -153 399 49 -153 minecraft:water[level=0]
fill 417 49 -153 422 49 -153 minecraft:water[level=0]
setblock 395 49 -154 minecraft:water[level=0]
setblock 396 49 -154 minecraft:kelp_plant
setblock 397 49 -154 minecraft:water[level=0]
setblock 398 49 -154 minecraft:tall_seagrass[half=lower]
fill 418 49 -154 422 49 -154 minecraft:water[level=0]
setblock 395 49 -155 minecraft:seagrass
setblock 396 49 -155 minecraft:kelp_plant
setblock 397 49 -155 minecraft:seagrass
setblock 398 49 -155 minecraft:water[level=0]
fill 418 49 -155 421 49 -155 minecraft:water[level=0]
setblock 395 49 -156 minecraft:seagrass
setblock 396 49 -156 minecraft:water[level=0]
fill 397 49 -156 398 49 -156 minecraft:kelp_plant
fill 419 49 -156 422 49 -156 minecraft:water[level=0]
setblock 395 49 -157 minecraft:kelp_plant
fill 396 49 -157 397 49 -157 minecraft:water[level=0]
setblock 398 49 -157 minecraft:kelp_plant
fill 419 49 -157 422 49 -157 minecraft:water[level=0]
fill 395 49 -158 396 49 -158 minecraft:water[level=0]
setblock 397 49 -158 minecraft:seagrass
fill 419 49 -158 422 49 -158 minecraft:water[level=0]
setblock 395 49 -159 minecraft:tall_seagrass[half=lower]
setblock 396 49 -159 minecraft:water[level=0]
setblock 397 49 -159 minecraft:kelp_plant
fill 419 49 -159 422 49 -159 minecraft:water[level=0]
setblock 395 49 -160 minecraft:tall_seagrass[half=lower]
setblock 396 49 -160 minecraft:water[level=0]
setblock 397 49 -160 minecraft:kelp_plant
fill 420 49 -160 422 49 -160 minecraft:water[level=0]
setblock 396 49 -161 minecraft:water[level=0]
setblock 397 49 -161 minecraft:kelp_plant
setblock 422 49 -161 minecraft:water[level=0]
setblock 396 49 -162 minecraft:water[level=0]
fill 420 49 -162 422 49 -162 minecraft:water[level=0]
setblock 396 49 -163 minecraft:water[level=0]
fill 421 49 -163 422 49 -163 minecraft:water[level=0]
setblock 396 49 -164 minecraft:water[level=0]
setblock 422 49 -164 minecraft:water[level=0]
setblock 392 49 -188 minecraft:seagrass
setblock 393 49 -188 minecraft:kelp_plant
setblock 394 49 -188 minecraft:seagrass
fill 395 49 -188 396 49 -188 minecraft:water[level=0]
setblock 392 49 -189 minecraft:seagrass
setblock 393 49 -189 minecraft:water[level=0]
setblock 394 49 -189 minecraft:seagrass
fill 395 49 -189 396 49 -189 minecraft:water[level=0]
fill 392 49 -190 396 49 -190 minecraft:water[level=0]
setblock 392 48 -127 minecraft:kelp_plant
setblock 393 48 -127 minecraft:water[level=0]
setblock 394 48 -127 minecraft:seagrass
setblock 395 48 -127 minecraft:water[level=0]
setblock 396 48 -127 minecraft:kelp_plant
fill 397 48 -127 402 48 -127 minecraft:water[level=0]
setblock 403 48 -127 minecraft:kelp_plant
fill 404 48 -127 406 48 -127 minecraft:water[level=0]
setblock 393 48 -128 minecraft:seagrass
setblock 394 48 -128 minecraft:kelp_plant
fill 395 48 -128 398 48 -128 minecraft:water[level=0]
setblock 399 48 -128 minecraft:kelp_plant
fill 400 48 -128 402 48 -128 minecraft:water[level=0]
setblock 403 48 -128 minecraft:kelp_plant
fill 404 48 -128 406 48 -128 minecraft:water[level=0]
fill 395 48 -129 406 48 -129 minecraft:water[level=0]
setblock 396 48 -130 minecraft:water[level=0]
setblock 397 48 -130 minecraft:kelp_plant
fill 398 48 -130 406 48 -130 minecraft:water[level=0]
fill 397 48 -131 406 48 -131 minecraft:water[level=0]
fill 397 48 -132 400 48 -132 minecraft:water[level=0]
setblock 401 48 -132 minecraft:seagrass
fill 402 48 -132 406 48 -132 minecraft:water[level=0]
setblock 398 48 -133 minecraft:seagrass
fill 399 48 -133 406 48 -133 minecraft:water[level=0]
fill 398 48 -134 399 48 -134 minecraft:kelp_plant
fill 400 48 -134 406 48 -134 minecraft:water[level=0]
fill 392 48 -135 397 48 -135 minecraft:water[level=0]
fill 398 48 -135 399 48 -135 minecraft:seagrass
setblock 400 48 -135 minecraft:water[level=0]
setblock 401 48 -135 minecraft:seagrass
setblock 402 48 -135 minecraft:water[level=0]
setblock 403 48 -135 minecraft:seagrass
fill 404 48 -135 406 48 -135 minecraft:water[level=0]
fill 392 48 -136 406 48 -136 minecraft:water[level=0]
fill 398 48 -137 406 48 -137 minecraft:water[level=0]
fill 401 48 -138 405 48 -138 minecraft:water[level=0]
fill 402 48 -139 405 48 -139 minecraft:water[level=0]
fill 403 48 -140 405 48 -140 minecraft:water[level=0]
setblock 404 48 -141 minecraft:water[level=0]
setblock 421 48 -147 minecraft:water[level=0]
setblock 421 48 -149 minecraft:water[level=0]
setblock 421 48 -150 minecraft:water[level=0]
setblock 396 48 -151 minecraft:water[level=0]
setblock 420 48 -151 minecraft:water[level=0]
setblock 396 48 -152 minecraft:water[level=0]
fill 420 48 -152 422 48 -152 minecraft:water[level=0]
setblock 396 48 -153 minecraft:water[level=0]
setblock 396 48 -154 minecraft:kelp_plant
setblock 396 48 -155 minecraft:kelp_plant
setblock 396 48 -156 minecraft:seagrass
setblock 421 48 -156 minecraft:water[level=0]
setblock 396 48 -157 minecraft:water[level=0]
setblock 422 48 -157 minecraft:water[level=0]
setblock 396 48 -158 minecraft:water[level=0]
setblock 422 48 -158 minecraft:water[level=0]
setblock 422 48 -159 minecraft:water[level=0]
setblock 422 48 -160 minecraft:water[level=0]
fill 395 48 -189 396 48 -189 minecraft:seagrass
fill 392 48 -190 394 48 -190 minecraft:water[level=0]
fill 395 48 -190 396 48 -190 minecraft:seagrass
setblock 399 47 -127 minecraft:water[level=0]
setblock 400 47 -127 minecraft:seagrass
fill 401 47 -127 402 47 -127 minecraft:water[level=0]
setblock 403 47 -127 minecraft:kelp_plant
fill 404 47 -127 406 47 -127 minecraft:water[level=0]
setblock 399 47 -128 minecraft:kelp_plant
fill 400 47 -128 402 47 -128 minecraft:water[level=0]
setblock 403 47 -128 minecraft:kelp_plant
fill 404 47 -128 406 47 -128 minecraft:water[level=0]
fill 400 47 -129 406 47 -129 minecraft:water[level=0]
fill 400 47 -130 405 47 -130 minecraft:water[level=0]
fill 401 47 -131 405 47 -131 minecraft:water[level=0]
fill 402 47 -132 405 47 -132 minecraft:water[level=0]
fill 402 47 -133 405 47 -133 minecraft:water[level=0]
setblock 403 47 -134 minecraft:seagrass
setblock 404 47 -134 minecraft:water[level=0]
fill 392 47 -135 393 47 -135 minecraft:water[level=0]
setblock 394 47 -135 minecraft:tall_seagrass[half=upper]
setblock 395 47 -135 minecraft:water[level=0]
setblock 396 47 -135 minecraft:seagrass
setblock 397 47 -135 minecraft:water[level=0]
setblock 404 47 -135 minecraft:water[level=0]
fill 392 47 -136 398 47 -136 minecraft:water[level=0]
setblock 399 47 -136 minecraft:tall_seagrass[half=upper]
fill 400 47 -136 402 47 -136 minecraft:water[level=0]
fill 398 47 -137 403 47 -137 minecraft:water[level=0]
fill 400 47 -138 404 47 -138 minecraft:water[level=0]
fill 403 47 -139 404 47 -139 minecraft:water[level=0]
setblock 402 46 -127 minecraft:water[level=0]
setblock 403 46 -127 minecraft:kelp_plant
fill 404 46 -127 405 46 -127 minecraft:water[level=0]
setblock 402 46 -128 minecraft:water[level=0]
setblock 403 46 -128 minecraft:kelp_plant
setblock 404 46 -128 minecraft:seagrass
setblock 405 46 -128 minecraft:water[level=0]
fill 403 46 -129 404 46 -129 minecraft:water[level=0]
fill 403 46 -130 404 46 -130 minecraft:water[level=0]
setblock 404 46 -131 minecraft:water[level=0]
fill 392 46 -135 393 46 -135 minecraft:water[level=0]
setblock 394 46 -135 minecraft:tall_seagrass[half=lower]
setblock 392 46 -136 minecraft:water[level=0]
setblock 398 46 -136 minecraft:water[level=0]
setblock 399 46 -136 minecraft:tall_seagrass[half=lower]
setblock 400 46 -136 minecraft:water[level=0]
fill 400 46 -137 401 46 -137 minecraft:seagrass
setblock 402 46 -137 minecraft:water[level=0]
setblock 403 46 -137 minecraft:seagrass
setblock 404 46 -137 minecraft:water[level=0]
fill 401 46 -138 406 46 -138 minecraft:water[level=0]
fill 402 46 -139 406 46 -139 minecraft:water[level=0]
fill 404 46 -140 407 46 -140 minecraft:water[level=0]
fill 406 46 -141 407 46 -141 minecraft:water[level=0]
setblock 408 46 -142 minecraft:water[level=0]
setblock 392 45 -135 minecraft:water[level=0]
setblock 402 45 -137 minecraft:water[level=0]
fill 403 45 -138 405 45 -138 minecraft:water[level=0]
setblock 403 45 -139 minecraft:water[level=0]
setblock 404 45 -139 minecraft:seagrass
fill 405 45 -139 408 45 -139 minecraft:water[level=0]
fill 404 45 -140 408 45 -140 minecraft:water[level=0]
fill 405 45 -141 410 45 -141 minecraft:water[level=0]
fill 406 45 -142 411 45 -142 minecraft:water[level=0]
fill 408 45 -143 412 45 -143 minecraft:water[level=0]
fill 410 45 -144 414 45 -144 minecraft:water[level=0]
fill 412 45 -145 417 45 -145 minecraft:water[level=0]
fill 414 45 -146 417 45 -146 minecraft:water[level=0]
setblock 394 45 -185 minecraft:water[level=0]
fill 393 45 -186 395 45 -186 minecraft:water[level=0]
fill 393 45 -187 395 45 -187 minecraft:water[level=0]
forceload remove 392 -190 455 -127
tellraw @a {"text":"Campus zurueck a35 fertig.","color":"green"}
