fill 196 86 -191 197 86 -191 minecraft:white_concrete
fill 193 86 -200 194 86 -200 minecraft:white_concrete
fill 191 86 -209 192 86 -209 minecraft:white_concrete
fill 190 86 -219 191 86 -219 minecraft:white_concrete
fill 190 86 -228 191 86 -228 minecraft:white_concrete
setblock 192 86 -237 minecraft:white_concrete
setblock 195 86 -246 minecraft:white_concrete
setblock 195 86 -247 minecraft:white_concrete
setblock 193 85 -191 minecraft:white_concrete
setblock 189 85 -202 minecraft:white_concrete
setblock 189 85 -203 minecraft:white_concrete
setblock 189 85 -204 minecraft:white_concrete
setblock 187 85 -210 minecraft:white_concrete
setblock 187 85 -211 minecraft:white_concrete
setblock 187 85 -215 minecraft:white_concrete
setblock 187 85 -219 minecraft:white_concrete
setblock 187 85 -222 minecraft:white_concrete
setblock 187 85 -225 minecraft:white_concrete
setblock 187 85 -227 minecraft:white_concrete
setblock 188 85 -234 minecraft:white_concrete
setblock 189 85 -239 minecraft:white_concrete
setblock 189 85 -241 minecraft:white_concrete
setblock 190 85 -244 minecraft:white_concrete
setblock 191 85 -247 minecraft:white_concrete
fill 192 85 -251 193 85 -251 minecraft:white_concrete
setblock 136 81 -227 minecraft:air
setblock 137 81 -228 minecraft:air
setblock 138 81 -229 minecraft:air
setblock 139 81 -230 minecraft:air
setblock 140 81 -231 minecraft:air
setblock 141 81 -232 minecraft:air
setblock 141 81 -233 minecraft:air
fill 139 81 -234 140 81 -234 minecraft:air
fill 136 81 -235 138 81 -235 minecraft:air
setblock 136 80 -227 minecraft:white_concrete
setblock 137 80 -228 minecraft:white_concrete
setblock 138 80 -229 minecraft:white_concrete
setblock 139 80 -230 minecraft:white_concrete
setblock 140 80 -231 minecraft:white_concrete
setblock 141 80 -232 minecraft:white_concrete
setblock 141 80 -233 minecraft:white_concrete
fill 139 80 -234 140 80 -234 minecraft:white_concrete
fill 136 80 -235 138 80 -235 minecraft:white_concrete
setblock 156 76 -192 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 76 -193 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 76 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 76 -193 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 76 -194 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 76 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -195 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 75 -191 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 75 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 75 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 75 -192 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 75 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 75 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 75 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 75 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 75 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 75 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 75 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 75 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 75 -195 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 74 -191 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 74 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 74 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 74 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 74 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 74 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 74 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 74 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 74 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 74 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 74 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 74 -193 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 74 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 74 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 74 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 74 -194 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 74 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 74 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 74 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 74 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 74 -195 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 74 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 74 -195 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 73 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 73 -191 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 73 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 73 -191 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 73 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 73 -192 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 73 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 73 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 73 -192 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 73 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 73 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 73 -193 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 73 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 73 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -193 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 73 -193 minecraft:birch_log[axis=y]
setblock 157 73 -193 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 73 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 73 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 73 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 73 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 73 -194 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 73 -194 minecraft:birch_log[axis=y]
setblock 151 73 -194 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 73 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 73 -194 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 73 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 73 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 73 -195 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 73 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 73 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 73 -196 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 72 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 72 -191 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 72 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 72 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 72 -192 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 72 -192 minecraft:birch_log[axis=y]
setblock 166 72 -192 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 72 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 72 -193 minecraft:birch_log[axis=y]
setblock 164 72 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 72 -193 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 72 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 72 -194 minecraft:birch_log[axis=y]
setblock 165 72 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 72 -194 minecraft:air
setblock 152 71 -191 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 153 71 -191 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 71 -192 minecraft:birch_log[axis=y]
setblock 171 71 -192 minecraft:air
setblock 156 71 -193 minecraft:birch_log[axis=y]
setblock 160 71 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 170 71 -193 172 71 -193 minecraft:air
setblock 150 71 -194 minecraft:birch_log[axis=y]
setblock 160 71 -194 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 169 71 -194 173 71 -194 minecraft:air
fill 170 71 -195 172 71 -195 minecraft:air
setblock 171 71 -196 minecraft:air
setblock 152 70 -191 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 70 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 70 -191 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 70 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 70 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 70 -192 minecraft:birch_log[axis=y]
fill 170 70 -192 172 70 -192 minecraft:air
setblock 156 70 -193 minecraft:birch_log[axis=y]
setblock 159 70 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 70 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 70 -193 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 169 70 -193 173 70 -193 minecraft:air
setblock 150 70 -194 minecraft:birch_log[axis=y]
setblock 156 70 -194 regions_unexplored:birch_branch[facing=north]
setblock 160 70 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 169 70 -194 173 70 -194 minecraft:air
fill 169 70 -195 173 70 -195 minecraft:air
fill 170 70 -196 172 70 -196 minecraft:air
setblock 152 69 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 69 -191 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 69 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 69 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 69 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 69 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 69 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 69 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 69 -192 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 69 -192 minecraft:birch_log[axis=y]
setblock 171 69 -192 minecraft:air
setblock 156 69 -193 minecraft:birch_log[axis=y]
setblock 157 69 -193 regions_unexplored:birch_branch[facing=east]
setblock 159 69 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 69 -193 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 69 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 170 69 -193 172 69 -193 minecraft:air
setblock 150 69 -194 minecraft:birch_log[axis=y]
setblock 159 69 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 69 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 69 -194 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 169 69 -194 173 69 -194 minecraft:air
fill 170 69 -195 172 69 -195 minecraft:air
setblock 171 69 -196 minecraft:air
setblock 151 68 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 68 -191 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 68 -191 minecraft:birch_log[axis=y]
setblock 154 68 -191 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 68 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 68 -191 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 68 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 68 -192 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 68 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 68 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 68 -192 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 68 -192 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 68 -192 minecraft:birch_log[axis=y]
setblock 153 68 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 68 -193 minecraft:birch_log[axis=y]
setblock 158 68 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 68 -193 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 68 -193 minecraft:birch_log[axis=y]
setblock 161 68 -193 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 68 -193 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 68 -194 minecraft:birch_log[axis=y]
setblock 159 68 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 68 -194 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 68 -194 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 68 -194 minecraft:air
setblock 160 68 -195 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 67 -191 minecraft:birch_log[axis=y]
setblock 165 67 -192 minecraft:birch_log[axis=y]
setblock 156 67 -193 minecraft:birch_log[axis=y]
setblock 160 67 -193 minecraft:birch_log[axis=y]
setblock 150 67 -194 minecraft:birch_log[axis=y]
setblock 171 67 -194 minecraft:air
setblock 172 67 -195 minecraft:birch_log[axis=y]
setblock 153 66 -191 minecraft:birch_log[axis=y]
setblock 165 66 -192 minecraft:birch_log[axis=y]
setblock 156 66 -193 minecraft:birch_log[axis=y]
setblock 160 66 -193 minecraft:birch_log[axis=y]
setblock 150 66 -194 minecraft:birch_log[axis=y]
setblock 171 66 -194 minecraft:air
setblock 172 66 -195 minecraft:birch_log[axis=y]
fill 142 65 -191 152 65 -191 minecraft:air
setblock 153 65 -191 minecraft:birch_log[axis=y]
fill 154 65 -191 176 65 -191 minecraft:air
setblock 177 65 -191 minecraft:birch_log[axis=y]
fill 178 65 -191 180 65 -191 minecraft:air
fill 143 65 -192 164 65 -192 minecraft:air
setblock 165 65 -192 minecraft:birch_log[axis=y]
fill 166 65 -192 178 65 -192 minecraft:air
setblock 179 65 -192 minecraft:birch_log[axis=y]
setblock 180 65 -192 minecraft:air
fill 143 65 -193 155 65 -193 minecraft:air
setblock 156 65 -193 minecraft:birch_log[axis=y]
fill 157 65 -193 159 65 -193 minecraft:air
setblock 160 65 -193 minecraft:birch_log[axis=y]
fill 161 65 -193 175 65 -193 minecraft:air
setblock 176 65 -193 minecraft:birch_log[axis=y]
fill 177 65 -193 183 65 -193 minecraft:air
fill 144 65 -194 149 65 -194 minecraft:air
setblock 150 65 -194 minecraft:birch_log[axis=y]
fill 151 65 -194 183 65 -194 minecraft:air
fill 144 65 -195 171 65 -195 minecraft:air
setblock 172 65 -195 minecraft:birch_log[axis=y]
setblock 173 65 -195 regions_unexplored:birch_branch[facing=east]
fill 174 65 -195 183 65 -195 minecraft:air
fill 145 65 -196 182 65 -196 minecraft:air
fill 145 65 -197 182 65 -197 minecraft:air
fill 146 65 -198 182 65 -198 minecraft:air
fill 146 65 -199 181 65 -199 minecraft:air
fill 146 65 -200 181 65 -200 minecraft:air
fill 147 65 -201 181 65 -201 minecraft:air
fill 147 65 -202 181 65 -202 minecraft:air
fill 147 65 -203 180 65 -203 minecraft:air
fill 148 65 -204 180 65 -204 minecraft:air
fill 148 65 -205 180 65 -205 minecraft:air
fill 148 65 -206 180 65 -206 minecraft:air
fill 148 65 -207 180 65 -207 minecraft:air
fill 149 65 -208 180 65 -208 minecraft:air
fill 149 65 -209 179 65 -209 minecraft:air
fill 149 65 -210 179 65 -210 minecraft:air
fill 149 65 -211 179 65 -211 minecraft:air
fill 149 65 -212 179 65 -212 minecraft:air
fill 149 65 -213 179 65 -213 minecraft:air
fill 151 65 -214 179 65 -214 minecraft:air
fill 151 65 -215 179 65 -215 minecraft:air
fill 151 65 -216 179 65 -216 minecraft:air
fill 151 65 -217 179 65 -217 minecraft:air
fill 151 65 -218 179 65 -218 minecraft:air
fill 151 65 -219 179 65 -219 minecraft:air
fill 151 65 -220 179 65 -220 minecraft:air
fill 151 65 -221 178 65 -221 minecraft:air
fill 151 65 -222 179 65 -222 minecraft:air
fill 151 65 -223 175 65 -223 minecraft:air
setblock 176 65 -223 minecraft:birch_log[axis=y]
fill 177 65 -223 178 65 -223 minecraft:air
fill 151 65 -224 177 65 -224 minecraft:air
fill 151 65 -225 178 65 -225 minecraft:air
fill 151 65 -226 179 65 -226 minecraft:air
fill 151 65 -227 179 65 -227 minecraft:air
fill 151 65 -228 179 65 -228 minecraft:air
setblock 149 65 -229 minecraft:air
fill 151 65 -229 179 65 -229 minecraft:air
fill 149 65 -230 179 65 -230 minecraft:air
fill 149 65 -231 179 65 -231 minecraft:air
fill 149 65 -232 179 65 -232 minecraft:air
fill 149 65 -233 179 65 -233 minecraft:air
fill 149 65 -234 180 65 -234 minecraft:air
fill 148 65 -235 180 65 -235 minecraft:air
fill 148 65 -236 180 65 -236 minecraft:air
fill 148 65 -237 180 65 -237 minecraft:air
fill 148 65 -238 180 65 -238 minecraft:air
fill 147 65 -239 180 65 -239 minecraft:air
fill 147 65 -240 181 65 -240 minecraft:air
fill 147 65 -241 181 65 -241 minecraft:air
fill 146 65 -242 181 65 -242 minecraft:air
fill 146 65 -243 181 65 -243 minecraft:air
fill 146 65 -244 182 65 -244 minecraft:air
fill 145 65 -245 182 65 -245 minecraft:air
fill 145 65 -246 182 65 -246 minecraft:air
fill 144 65 -247 183 65 -247 minecraft:air
fill 144 65 -248 183 65 -248 minecraft:air
fill 143 65 -249 183 65 -249 minecraft:air
fill 143 65 -250 184 65 -250 minecraft:air
fill 142 65 -251 184 65 -251 minecraft:air
fill 142 65 -252 184 65 -252 minecraft:air
fill 141 65 -253 185 65 -253 minecraft:air
fill 140 65 -254 185 65 -254 minecraft:air
fill 136 64 -191 152 64 -191 minecraft:air
fill 154 64 -191 176 64 -191 minecraft:air
fill 178 64 -191 180 64 -191 minecraft:air
setblock 181 64 -191 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 64 -191 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 64 -191 herbsandharvest:plum_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 185 64 -191 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
fill 186 64 -191 195 64 -191 minecraft:air
fill 136 64 -192 164 64 -192 minecraft:air
fill 166 64 -192 178 64 -192 minecraft:air
setblock 180 64 -192 minecraft:air
setblock 181 64 -192 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 182 64 -192 herbsandharvest:plum_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 183 64 -192 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 64 -192 herbsandharvest:plum_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 185 64 -192 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
fill 186 64 -192 193 64 -192 minecraft:air
setblock 194 64 -192 regions_unexplored:grass_sprouts
fill 136 64 -193 155 64 -193 minecraft:air
fill 157 64 -193 159 64 -193 minecraft:air
fill 161 64 -193 175 64 -193 minecraft:air
fill 177 64 -193 181 64 -193 minecraft:air
setblock 182 64 -193 herbsandharvest:plum_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 183 64 -193 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 64 -193 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
fill 185 64 -193 194 64 -193 minecraft:air
fill 136 64 -194 149 64 -194 minecraft:air
fill 151 64 -194 192 64 -194 minecraft:air
setblock 193 64 -194 regions_unexplored:grass_sprouts
setblock 194 64 -194 minecraft:air
fill 137 64 -195 171 64 -195 minecraft:air
fill 173 64 -195 194 64 -195 minecraft:air
fill 137 64 -196 190 64 -196 minecraft:air
setblock 192 64 -196 minecraft:air
setblock 193 64 -196 regions_unexplored:grass_sprouts
fill 138 64 -197 194 64 -197 minecraft:air
fill 138 64 -198 194 64 -198 minecraft:air
fill 139 64 -199 161 64 -199 minecraft:air
fill 164 64 -199 194 64 -199 minecraft:air
setblock 136 64 -200 minecraft:air
fill 139 64 -200 194 64 -200 minecraft:air
fill 140 64 -201 194 64 -201 minecraft:air
setblock 136 64 -202 minecraft:air
fill 140 64 -202 192 64 -202 minecraft:air
setblock 194 64 -202 minecraft:short_grass
fill 140 64 -203 193 64 -203 minecraft:air
setblock 194 64 -203 minecraft:short_grass
fill 137 64 -204 138 64 -204 minecraft:air
fill 141 64 -204 193 64 -204 minecraft:air
fill 136 64 -205 139 64 -205 minecraft:air
fill 141 64 -205 193 64 -205 minecraft:air
fill 136 64 -206 137 64 -206 minecraft:air
setblock 139 64 -206 minecraft:air
fill 141 64 -206 193 64 -206 minecraft:air
fill 136 64 -207 139 64 -207 minecraft:air
fill 142 64 -207 193 64 -207 minecraft:air
fill 136 64 -208 140 64 -208 minecraft:air
fill 142 64 -208 193 64 -208 minecraft:air
fill 136 64 -209 140 64 -209 minecraft:air
fill 142 64 -209 194 64 -209 minecraft:air
fill 136 64 -210 140 64 -210 minecraft:air
fill 142 64 -210 195 64 -210 minecraft:air
fill 136 64 -211 137 64 -211 minecraft:air
fill 139 64 -211 140 64 -211 minecraft:air
fill 143 64 -211 196 64 -211 minecraft:air
fill 136 64 -212 140 64 -212 minecraft:air
fill 143 64 -212 197 64 -212 minecraft:air
fill 136 64 -213 141 64 -213 minecraft:air
fill 143 64 -213 196 64 -213 minecraft:air
fill 136 64 -214 141 64 -214 minecraft:air
fill 143 64 -214 149 64 -214 minecraft:air
fill 151 64 -214 188 64 -214 minecraft:air
fill 190 64 -214 194 64 -214 minecraft:air
fill 136 64 -215 141 64 -215 minecraft:air
fill 143 64 -215 149 64 -215 minecraft:air
fill 151 64 -215 191 64 -215 minecraft:air
fill 136 64 -216 137 64 -216 minecraft:air
fill 139 64 -216 141 64 -216 minecraft:air
fill 143 64 -216 149 64 -216 minecraft:air
fill 151 64 -216 188 64 -216 minecraft:air
fill 136 64 -217 141 64 -217 minecraft:air
fill 143 64 -217 149 64 -217 minecraft:air
fill 151 64 -217 188 64 -217 minecraft:air
fill 136 64 -218 141 64 -218 minecraft:air
fill 143 64 -218 149 64 -218 minecraft:air
fill 151 64 -218 188 64 -218 minecraft:air
fill 136 64 -219 141 64 -219 minecraft:air
fill 143 64 -219 149 64 -219 minecraft:air
fill 151 64 -219 186 64 -219 minecraft:air
setblock 188 64 -219 minecraft:air
fill 136 64 -220 141 64 -220 minecraft:air
fill 143 64 -220 149 64 -220 minecraft:air
fill 151 64 -220 179 64 -220 minecraft:air
fill 181 64 -220 188 64 -220 minecraft:air
fill 136 64 -221 141 64 -221 minecraft:air
fill 144 64 -221 149 64 -221 minecraft:air
fill 151 64 -221 179 64 -221 minecraft:air
fill 181 64 -221 187 64 -221 minecraft:air
fill 136 64 -222 141 64 -222 minecraft:air
fill 143 64 -222 149 64 -222 minecraft:air
fill 151 64 -222 178 64 -222 minecraft:air
fill 181 64 -222 187 64 -222 minecraft:air
fill 136 64 -223 141 64 -223 minecraft:air
fill 143 64 -223 149 64 -223 minecraft:air
fill 151 64 -223 175 64 -223 minecraft:air
fill 177 64 -223 178 64 -223 minecraft:air
fill 182 64 -223 186 64 -223 minecraft:air
fill 136 64 -224 141 64 -224 minecraft:air
fill 143 64 -224 149 64 -224 minecraft:air
fill 151 64 -224 177 64 -224 minecraft:air
fill 183 64 -224 185 64 -224 minecraft:air
fill 136 64 -225 141 64 -225 minecraft:air
fill 143 64 -225 149 64 -225 minecraft:air
fill 151 64 -225 178 64 -225 minecraft:air
setblock 184 64 -225 minecraft:air
fill 136 64 -226 141 64 -226 minecraft:air
fill 143 64 -226 149 64 -226 minecraft:air
fill 151 64 -226 179 64 -226 minecraft:air
fill 136 64 -227 141 64 -227 minecraft:air
fill 143 64 -227 149 64 -227 minecraft:air
fill 151 64 -227 179 64 -227 minecraft:air
fill 136 64 -228 141 64 -228 minecraft:air
fill 143 64 -228 149 64 -228 minecraft:air
fill 151 64 -228 179 64 -228 minecraft:air
fill 137 64 -229 141 64 -229 minecraft:air
fill 143 64 -229 149 64 -229 minecraft:air
fill 151 64 -229 179 64 -229 minecraft:air
fill 138 64 -230 140 64 -230 minecraft:air
fill 143 64 -230 179 64 -230 minecraft:air
fill 139 64 -231 140 64 -231 minecraft:air
fill 143 64 -231 179 64 -231 minecraft:air
setblock 140 64 -232 minecraft:air
fill 142 64 -232 179 64 -232 minecraft:air
setblock 184 64 -232 minecraft:air
fill 196 64 -232 199 64 -232 minecraft:air
fill 142 64 -233 187 64 -233 minecraft:air
fill 195 64 -233 197 64 -233 minecraft:air
setblock 199 64 -233 minecraft:air
fill 138 64 -234 140 64 -234 minecraft:air
fill 142 64 -234 187 64 -234 minecraft:air
setblock 191 64 -234 minecraft:air
setblock 192 64 -234 regions_unexplored:grass_sprouts
fill 193 64 -234 194 64 -234 minecraft:air
setblock 195 64 -234 minecraft:short_grass
fill 196 64 -234 197 64 -234 minecraft:air
setblock 198 64 -234 minecraft:short_grass
setblock 199 64 -234 minecraft:air
fill 136 64 -235 139 64 -235 minecraft:air
fill 142 64 -235 199 64 -235 minecraft:air
fill 136 64 -236 137 64 -236 minecraft:air
setblock 139 64 -236 minecraft:air
fill 141 64 -236 196 64 -236 minecraft:air
setblock 197 64 -236 minecraft:short_grass
fill 198 64 -236 199 64 -236 minecraft:air
fill 136 64 -237 139 64 -237 minecraft:air
fill 141 64 -237 199 64 -237 minecraft:air
fill 136 64 -238 138 64 -238 minecraft:air
fill 141 64 -238 199 64 -238 minecraft:air
fill 136 64 -239 138 64 -239 minecraft:air
fill 140 64 -239 199 64 -239 minecraft:air
fill 136 64 -240 138 64 -240 minecraft:air
fill 140 64 -240 199 64 -240 minecraft:air
fill 136 64 -241 137 64 -241 minecraft:air
fill 140 64 -241 199 64 -241 minecraft:air
fill 136 64 -242 137 64 -242 minecraft:air
fill 139 64 -242 199 64 -242 minecraft:air
setblock 136 64 -243 minecraft:air
fill 139 64 -243 199 64 -243 minecraft:air
setblock 136 64 -244 minecraft:air
fill 138 64 -244 199 64 -244 minecraft:air
setblock 136 64 -245 minecraft:air
fill 138 64 -245 199 64 -245 minecraft:air
fill 137 64 -246 199 64 -246 minecraft:air
fill 137 64 -247 199 64 -247 minecraft:air
fill 136 64 -248 199 64 -248 minecraft:air
fill 136 64 -249 199 64 -249 minecraft:air
fill 136 64 -250 199 64 -250 minecraft:air
fill 136 64 -251 199 64 -251 minecraft:air
fill 136 64 -252 179 64 -252 minecraft:air
fill 181 64 -252 199 64 -252 minecraft:air
fill 136 64 -253 180 64 -253 minecraft:air
setblock 181 64 -253 minecraft:short_grass
fill 182 64 -253 184 64 -253 minecraft:air
setblock 185 64 -253 regions_unexplored:grass_sprouts
setblock 186 64 -253 minecraft:short_grass
fill 187 64 -253 199 64 -253 minecraft:air
fill 136 64 -254 179 64 -254 minecraft:air
fill 187 64 -254 188 64 -254 minecraft:air
setblock 189 64 -254 regions_unexplored:grass_sprouts
fill 190 64 -254 191 64 -254 minecraft:air
fill 193 64 -254 199 64 -254 minecraft:air
fill 136 63 -191 152 63 -191 minecraft:air
fill 154 63 -191 176 63 -191 minecraft:air
fill 178 63 -191 181 63 -191 minecraft:air
setblock 182 63 -191 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 63 -191 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
fill 185 63 -191 193 63 -191 minecraft:air
fill 136 63 -192 164 63 -192 minecraft:air
fill 166 63 -192 178 63 -192 minecraft:air
fill 180 63 -192 182 63 -192 minecraft:air
setblock 183 63 -192 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
fill 184 63 -192 190 63 -192 minecraft:air
setblock 191 63 -192 minecraft:short_grass
setblock 193 63 -192 minecraft:air
fill 136 63 -193 155 63 -193 minecraft:air
fill 157 63 -193 159 63 -193 minecraft:air
fill 161 63 -193 175 63 -193 minecraft:air
fill 177 63 -193 195 63 -193 minecraft:air
fill 136 63 -194 149 63 -194 minecraft:air
fill 151 63 -194 192 63 -194 minecraft:air
fill 194 63 -194 198 63 -194 minecraft:air
fill 137 63 -195 171 63 -195 minecraft:air
fill 173 63 -195 188 63 -195 minecraft:air
setblock 189 63 -195 regions_unexplored:grass_sprouts
fill 190 63 -195 192 63 -195 minecraft:air
fill 194 63 -195 199 63 -195 minecraft:air
fill 137 63 -196 190 63 -196 minecraft:air
fill 196 63 -196 199 63 -196 minecraft:air
fill 138 63 -197 174 63 -197 minecraft:air
setblock 175 63 -197 regions_unexplored:grass_sprouts
fill 176 63 -197 192 63 -197 minecraft:air
fill 198 63 -197 199 63 -197 minecraft:air
fill 138 63 -198 161 63 -198 minecraft:air
setblock 166 63 -198 regions_unexplored:grass_sprouts
fill 167 63 -198 171 63 -198 minecraft:air
setblock 172 63 -198 regions_unexplored:grass_sprouts
fill 173 63 -198 177 63 -198 minecraft:air
setblock 187 63 -198 minecraft:short_grass
fill 188 63 -198 190 63 -198 minecraft:air
setblock 191 63 -198 regions_unexplored:grass_sprouts
setblock 192 63 -198 minecraft:short_grass
setblock 193 63 -198 minecraft:air
fill 139 63 -199 152 63 -199 minecraft:air
fill 166 63 -199 193 63 -199 minecraft:air
fill 139 63 -200 157 63 -200 minecraft:air
fill 161 63 -200 193 63 -200 minecraft:air
fill 140 63 -201 193 63 -201 minecraft:air
fill 140 63 -202 192 63 -202 minecraft:air
fill 140 63 -203 192 63 -203 minecraft:air
fill 141 63 -204 191 63 -204 minecraft:air
fill 141 63 -205 191 63 -205 minecraft:air
fill 141 63 -206 191 63 -206 minecraft:air
fill 142 63 -207 191 63 -207 minecraft:air
fill 142 63 -208 191 63 -208 minecraft:air
fill 142 63 -209 192 63 -209 minecraft:air
fill 142 63 -210 193 63 -210 minecraft:air
fill 143 63 -211 194 63 -211 minecraft:air
fill 143 63 -212 194 63 -212 minecraft:air
fill 143 63 -213 194 63 -213 minecraft:air
fill 143 63 -214 149 63 -214 minecraft:air
fill 151 63 -214 187 63 -214 minecraft:air
setblock 188 63 -214 regions_unexplored:grass_sprouts
fill 190 63 -214 192 63 -214 minecraft:air
fill 143 63 -215 149 63 -215 minecraft:air
fill 151 63 -215 188 63 -215 minecraft:air
fill 143 63 -216 149 63 -216 minecraft:air
fill 151 63 -216 187 63 -216 minecraft:air
fill 143 63 -217 149 63 -217 minecraft:air
fill 151 63 -217 187 63 -217 minecraft:air
fill 143 63 -218 149 63 -218 minecraft:air
fill 151 63 -218 178 63 -218 minecraft:air
setblock 179 63 -218 minecraft:short_grass
fill 181 63 -218 187 63 -218 minecraft:air
fill 143 63 -219 149 63 -219 minecraft:air
fill 151 63 -219 179 63 -219 minecraft:air
fill 181 63 -219 186 63 -219 minecraft:air
fill 143 63 -220 149 63 -220 minecraft:air
fill 151 63 -220 178 63 -220 minecraft:air
fill 182 63 -220 187 63 -220 minecraft:air
fill 144 63 -221 149 63 -221 minecraft:air
fill 151 63 -221 178 63 -221 minecraft:air
fill 182 63 -221 186 63 -221 minecraft:air
fill 143 63 -222 149 63 -222 minecraft:air
fill 151 63 -222 175 63 -222 minecraft:air
setblock 176 63 -222 minecraft:short_grass
setblock 177 63 -222 minecraft:air
fill 183 63 -222 185 63 -222 minecraft:air
fill 143 63 -223 149 63 -223 minecraft:air
fill 151 63 -223 175 63 -223 minecraft:air
setblock 184 63 -223 minecraft:air
fill 143 63 -224 149 63 -224 minecraft:air
fill 151 63 -224 175 63 -224 minecraft:air
fill 143 63 -225 149 63 -225 minecraft:air
fill 151 63 -225 177 63 -225 minecraft:air
fill 143 63 -226 149 63 -226 minecraft:air
fill 151 63 -226 178 63 -226 minecraft:air
fill 143 63 -227 149 63 -227 minecraft:air
fill 151 63 -227 178 63 -227 minecraft:air
fill 143 63 -228 149 63 -228 minecraft:air
fill 151 63 -228 178 63 -228 minecraft:air
fill 143 63 -229 149 63 -229 minecraft:air
fill 151 63 -229 179 63 -229 minecraft:air
fill 143 63 -230 179 63 -230 minecraft:air
fill 143 63 -231 179 63 -231 minecraft:air
fill 142 63 -232 179 63 -232 minecraft:air
fill 142 63 -233 185 63 -233 minecraft:air
fill 142 63 -234 187 63 -234 minecraft:air
fill 142 63 -235 187 63 -235 minecraft:air
setblock 192 63 -235 minecraft:air
fill 141 63 -236 196 63 -236 minecraft:air
fill 141 63 -237 199 63 -237 minecraft:air
fill 141 63 -238 196 63 -238 minecraft:air
setblock 197 63 -238 regions_unexplored:grass_sprouts
setblock 198 63 -238 minecraft:short_grass
setblock 199 63 -238 minecraft:air
fill 140 63 -239 199 63 -239 minecraft:air
fill 140 63 -240 199 63 -240 minecraft:air
fill 140 63 -241 199 63 -241 minecraft:air
fill 139 63 -242 199 63 -242 minecraft:air
fill 139 63 -243 199 63 -243 minecraft:air
fill 138 63 -244 199 63 -244 minecraft:air
fill 138 63 -245 199 63 -245 minecraft:air
fill 137 63 -246 199 63 -246 minecraft:air
fill 137 63 -247 199 63 -247 minecraft:air
fill 136 63 -248 199 63 -248 minecraft:air
fill 136 63 -249 183 63 -249 minecraft:air
fill 185 63 -249 199 63 -249 minecraft:air
fill 136 63 -250 199 63 -250 minecraft:air
fill 136 63 -251 199 63 -251 minecraft:air
fill 136 63 -252 179 63 -252 minecraft:air
fill 181 63 -252 182 63 -252 minecraft:air
fill 185 63 -252 187 63 -252 minecraft:air
setblock 188 63 -252 regions_unexplored:grass_sprouts
fill 189 63 -252 199 63 -252 minecraft:air
fill 136 63 -253 179 63 -253 minecraft:air
fill 189 63 -253 199 63 -253 minecraft:air
fill 136 63 -254 178 63 -254 minecraft:air
setblock 193 63 -254 regions_unexplored:grass_sprouts
fill 194 63 -254 199 63 -254 minecraft:air
fill 136 62 -191 152 62 -191 minecraft:air
fill 154 62 -191 172 62 -191 minecraft:air
setblock 173 62 -191 minecraft:short_grass
fill 174 62 -191 175 62 -191 minecraft:air
setblock 176 62 -191 minecraft:short_grass
fill 178 62 -191 179 62 -191 minecraft:air
setblock 180 62 -191 minecraft:short_grass
fill 181 62 -191 182 62 -191 minecraft:air
fill 184 62 -191 190 62 -191 minecraft:air
fill 136 62 -192 156 62 -192 minecraft:air
setblock 157 62 -192 minecraft:short_grass
fill 158 62 -192 164 62 -192 minecraft:air
fill 166 62 -192 173 62 -192 minecraft:air
setblock 174 62 -192 regions_unexplored:grass_sprouts
fill 175 62 -192 178 62 -192 minecraft:air
setblock 180 62 -192 regions_unexplored:grass_sprouts
fill 181 62 -192 182 62 -192 minecraft:air
setblock 183 62 -192 minecraft:short_grass
fill 184 62 -192 190 62 -192 minecraft:air
fill 194 62 -192 195 62 -192 minecraft:water[level=0]
fill 136 62 -193 155 62 -193 minecraft:air
fill 157 62 -193 159 62 -193 minecraft:air
fill 161 62 -193 175 62 -193 minecraft:air
fill 177 62 -193 178 62 -193 minecraft:air
setblock 179 62 -193 minecraft:short_grass
setblock 180 62 -193 minecraft:air
setblock 181 62 -193 minecraft:short_grass
fill 182 62 -193 184 62 -193 minecraft:air
setblock 185 62 -193 minecraft:short_grass
setblock 186 62 -193 regions_unexplored:grass_sprouts
fill 187 62 -193 190 62 -193 minecraft:air
fill 192 62 -193 196 62 -193 minecraft:water[level=0]
fill 136 62 -194 149 62 -194 minecraft:air
fill 151 62 -194 178 62 -194 minecraft:air
setblock 179 62 -194 regions_unexplored:grass_sprouts
fill 180 62 -194 188 62 -194 minecraft:air
fill 192 62 -194 199 62 -194 minecraft:water[level=0]
fill 137 62 -195 171 62 -195 minecraft:air
fill 173 62 -195 182 62 -195 minecraft:air
setblock 183 62 -195 minecraft:short_grass
fill 184 62 -195 186 62 -195 minecraft:air
setblock 187 62 -195 minecraft:short_grass
setblock 188 62 -195 minecraft:air
fill 192 62 -195 199 62 -195 minecraft:water[level=0]
fill 137 62 -196 168 62 -196 minecraft:air
fill 169 62 -196 170 62 -196 minecraft:water[level=2]
fill 171 62 -196 174 62 -196 minecraft:air
fill 177 62 -196 187 62 -196 minecraft:air
fill 196 62 -196 199 62 -196 minecraft:water[level=0]
fill 138 62 -197 167 62 -197 minecraft:air
fill 168 62 -197 170 62 -197 minecraft:water[level=1]
setblock 171 62 -197 minecraft:air
fill 178 62 -197 186 62 -197 minecraft:air
fill 196 62 -197 199 62 -197 minecraft:water[level=0]
fill 138 62 -198 156 62 -198 minecraft:air
setblock 157 62 -198 regions_unexplored:grass_sprouts
fill 158 62 -198 161 62 -198 minecraft:air
setblock 167 62 -198 minecraft:air
fill 168 62 -198 170 62 -198 minecraft:water[level=0]
fill 174 62 -198 176 62 -198 minecraft:water[level=0]
fill 188 62 -198 190 62 -198 minecraft:water[level=0]
fill 198 62 -198 199 62 -198 minecraft:water[level=0]
fill 139 62 -199 149 62 -199 minecraft:air
fill 168 62 -199 185 62 -199 minecraft:water[level=0]
fill 187 62 -199 192 62 -199 minecraft:water[level=0]
fill 139 62 -200 149 62 -200 minecraft:air
fill 153 62 -200 157 62 -200 minecraft:water[level=0]
fill 163 62 -200 192 62 -200 minecraft:water[level=0]
fill 140 62 -201 149 62 -201 minecraft:air
fill 151 62 -201 191 62 -201 minecraft:water[level=0]
fill 140 62 -202 149 62 -202 minecraft:air
fill 151 62 -202 190 62 -202 minecraft:water[level=0]
fill 140 62 -203 149 62 -203 minecraft:air
fill 151 62 -203 189 62 -203 minecraft:water[level=0]
fill 141 62 -204 149 62 -204 minecraft:air
fill 151 62 -204 189 62 -204 minecraft:water[level=0]
fill 141 62 -205 149 62 -205 minecraft:air
fill 151 62 -205 189 62 -205 minecraft:water[level=0]
fill 141 62 -206 149 62 -206 minecraft:air
fill 151 62 -206 189 62 -206 minecraft:water[level=0]
fill 142 62 -207 149 62 -207 minecraft:air
fill 151 62 -207 189 62 -207 minecraft:water[level=0]
fill 142 62 -208 149 62 -208 minecraft:air
fill 151 62 -208 189 62 -208 minecraft:water[level=0]
fill 142 62 -209 149 62 -209 minecraft:air
fill 151 62 -209 190 62 -209 minecraft:water[level=0]
fill 142 62 -210 149 62 -210 minecraft:air
fill 151 62 -210 191 62 -210 minecraft:water[level=0]
fill 143 62 -211 149 62 -211 minecraft:air
fill 151 62 -211 192 62 -211 minecraft:water[level=0]
fill 143 62 -212 149 62 -212 minecraft:air
fill 151 62 -212 193 62 -212 minecraft:water[level=0]
fill 143 62 -213 149 62 -213 minecraft:air
fill 151 62 -213 191 62 -213 minecraft:water[level=0]
fill 143 62 -214 149 62 -214 minecraft:air
fill 151 62 -214 187 62 -214 minecraft:water[level=0]
fill 143 62 -215 149 62 -215 minecraft:air
fill 151 62 -215 179 62 -215 minecraft:water[level=0]
fill 181 62 -215 186 62 -215 minecraft:water[level=0]
fill 143 62 -216 149 62 -216 minecraft:air
fill 151 62 -216 178 62 -216 minecraft:water[level=0]
fill 182 62 -216 185 62 -216 minecraft:water[level=0]
fill 143 62 -217 149 62 -217 minecraft:air
fill 151 62 -217 178 62 -217 minecraft:water[level=0]
fill 182 62 -217 185 62 -217 minecraft:water[level=0]
fill 143 62 -218 149 62 -218 minecraft:air
fill 151 62 -218 177 62 -218 minecraft:water[level=0]
fill 182 62 -218 185 62 -218 minecraft:water[level=0]
fill 143 62 -219 149 62 -219 minecraft:air
fill 151 62 -219 177 62 -219 minecraft:water[level=0]
fill 183 62 -219 185 62 -219 minecraft:water[level=0]
fill 143 62 -220 149 62 -220 minecraft:air
fill 151 62 -220 177 62 -220 minecraft:water[level=0]
fill 183 62 -220 185 62 -220 minecraft:water[level=0]
fill 144 62 -221 149 62 -221 minecraft:air
fill 151 62 -221 176 62 -221 minecraft:water[level=0]
fill 183 62 -221 184 62 -221 minecraft:water[level=0]
fill 143 62 -222 149 62 -222 minecraft:air
fill 151 62 -222 175 62 -222 minecraft:water[level=0]
setblock 184 62 -222 minecraft:water[level=0]
fill 143 62 -223 149 62 -223 minecraft:air
fill 151 62 -223 174 62 -223 minecraft:water[level=0]
fill 143 62 -224 149 62 -224 minecraft:air
fill 151 62 -224 174 62 -224 minecraft:water[level=0]
fill 143 62 -225 149 62 -225 minecraft:air
fill 151 62 -225 175 62 -225 minecraft:water[level=0]
fill 143 62 -226 149 62 -226 minecraft:air
fill 151 62 -226 176 62 -226 minecraft:water[level=0]
fill 143 62 -227 149 62 -227 minecraft:air
fill 151 62 -227 177 62 -227 minecraft:water[level=0]
fill 143 62 -228 149 62 -228 minecraft:air
fill 151 62 -228 178 62 -228 minecraft:water[level=0]
fill 143 62 -229 149 62 -229 minecraft:air
fill 151 62 -229 178 62 -229 minecraft:water[level=0]
fill 143 62 -230 149 62 -230 minecraft:air
fill 151 62 -230 178 62 -230 minecraft:water[level=0]
fill 143 62 -231 149 62 -231 minecraft:air
fill 151 62 -231 178 62 -231 minecraft:water[level=0]
fill 142 62 -232 149 62 -232 minecraft:air
fill 151 62 -232 178 62 -232 minecraft:water[level=0]
fill 142 62 -233 149 62 -233 minecraft:air
fill 151 62 -233 179 62 -233 minecraft:water[level=0]
setblock 184 62 -233 minecraft:water[level=0]
fill 142 62 -234 149 62 -234 minecraft:air
fill 151 62 -234 186 62 -234 minecraft:water[level=0]
fill 142 62 -235 149 62 -235 minecraft:air
fill 151 62 -235 187 62 -235 minecraft:water[level=0]
setblock 192 62 -235 oritech:still_oil_block[level=0]
fill 141 62 -236 149 62 -236 minecraft:air
fill 151 62 -236 187 62 -236 minecraft:water[level=0]
fill 141 62 -237 149 62 -237 minecraft:air
fill 151 62 -237 187 62 -237 minecraft:water[level=0]
fill 141 62 -238 149 62 -238 minecraft:air
fill 151 62 -238 194 62 -238 minecraft:water[level=0]
fill 140 62 -239 149 62 -239 minecraft:air
fill 151 62 -239 199 62 -239 minecraft:water[level=0]
fill 140 62 -240 149 62 -240 minecraft:air
fill 151 62 -240 199 62 -240 minecraft:water[level=0]
fill 140 62 -241 149 62 -241 minecraft:air
fill 151 62 -241 199 62 -241 minecraft:water[level=0]
fill 139 62 -242 149 62 -242 minecraft:air
fill 151 62 -242 199 62 -242 minecraft:water[level=0]
fill 139 62 -243 149 62 -243 minecraft:air
fill 151 62 -243 199 62 -243 minecraft:water[level=0]
fill 138 62 -244 149 62 -244 minecraft:air
fill 151 62 -244 199 62 -244 minecraft:water[level=0]
fill 138 62 -245 149 62 -245 minecraft:air
fill 151 62 -245 199 62 -245 minecraft:water[level=0]
fill 137 62 -246 149 62 -246 minecraft:air
fill 151 62 -246 199 62 -246 minecraft:water[level=0]
fill 137 62 -247 149 62 -247 minecraft:air
fill 151 62 -247 199 62 -247 minecraft:water[level=0]
fill 136 62 -248 149 62 -248 minecraft:air
fill 151 62 -248 199 62 -248 minecraft:water[level=0]
fill 136 62 -249 149 62 -249 minecraft:air
fill 151 62 -249 183 62 -249 minecraft:water[level=0]
setblock 185 62 -249 minecraft:water[level=0]
setblock 186 62 -249 minecraft:tall_seagrass[half=upper]
fill 187 62 -249 199 62 -249 minecraft:water[level=0]
fill 136 62 -250 149 62 -250 minecraft:air
fill 151 62 -250 199 62 -250 minecraft:water[level=0]
fill 136 62 -251 149 62 -251 minecraft:air
fill 151 62 -251 183 62 -251 minecraft:water[level=0]
setblock 186 62 -251 minecraft:seagrass
fill 187 62 -251 199 62 -251 minecraft:water[level=0]
fill 136 62 -252 149 62 -252 minecraft:air
fill 151 62 -252 179 62 -252 minecraft:water[level=0]
fill 189 62 -252 190 62 -252 minecraft:water[level=0]
fill 191 62 -252 192 62 -252 minecraft:seagrass
fill 193 62 -252 199 62 -252 minecraft:water[level=0]
fill 136 62 -253 149 62 -253 minecraft:air
fill 151 62 -253 179 62 -253 minecraft:water[level=0]
fill 193 62 -253 199 62 -253 minecraft:water[level=0]
fill 136 62 -254 149 62 -254 minecraft:air
fill 151 62 -254 178 62 -254 minecraft:water[level=0]
fill 194 62 -254 199 62 -254 minecraft:water[level=0]
fill 136 61 -191 149 61 -191 minecraft:air
fill 163 61 -191 166 61 -191 minecraft:air
setblock 167 61 -191 minecraft:water[level=7]
setblock 168 61 -191 minecraft:water[level=6]
fill 169 61 -191 170 61 -191 minecraft:water[level=5]
setblock 171 61 -191 minecraft:water[level=6]
setblock 172 61 -191 minecraft:water[level=7]
fill 185 61 -191 191 61 -191 minecraft:air
fill 136 61 -192 149 61 -192 minecraft:air
fill 162 61 -192 164 61 -192 minecraft:air
setblock 166 61 -192 minecraft:water[level=7]
setblock 167 61 -192 minecraft:water[level=6]
setblock 168 61 -192 minecraft:water[level=5]
fill 169 61 -192 170 61 -192 minecraft:water[level=4]
setblock 171 61 -192 minecraft:water[level=5]
setblock 172 61 -192 minecraft:water[level=6]
setblock 173 61 -192 minecraft:water[level=7]
fill 186 61 -192 190 61 -192 minecraft:air
fill 193 61 -192 195 61 -192 minecraft:water[level=0]
fill 136 61 -193 149 61 -193 minecraft:air
fill 161 61 -193 164 61 -193 minecraft:air
setblock 165 61 -193 minecraft:water[level=7]
setblock 166 61 -193 minecraft:water[level=6]
setblock 167 61 -193 minecraft:water[level=5]
setblock 168 61 -193 minecraft:water[level=4]
fill 169 61 -193 170 61 -193 minecraft:water[level=3]
setblock 171 61 -193 minecraft:water[level=4]
setblock 172 61 -193 minecraft:water[level=5]
setblock 173 61 -193 minecraft:water[level=6]
fill 187 61 -193 189 61 -193 minecraft:air
fill 192 61 -193 197 61 -193 minecraft:water[level=0]
fill 136 61 -194 149 61 -194 minecraft:air
fill 160 61 -194 163 61 -194 minecraft:air
setblock 164 61 -194 minecraft:water[level=7]
setblock 165 61 -194 minecraft:water[level=6]
setblock 166 61 -194 minecraft:water[level=5]
setblock 167 61 -194 minecraft:water[level=4]
setblock 168 61 -194 minecraft:water[level=3]
fill 169 61 -194 170 61 -194 minecraft:water[level=2]
setblock 171 61 -194 minecraft:water[level=3]
setblock 172 61 -194 minecraft:water[level=4]
setblock 173 61 -194 minecraft:water[level=5]
fill 191 61 -194 199 61 -194 minecraft:water[level=0]
fill 137 61 -195 149 61 -195 minecraft:air
fill 160 61 -195 162 61 -195 minecraft:air
setblock 163 61 -195 minecraft:water[level=7]
setblock 164 61 -195 minecraft:water[level=6]
setblock 165 61 -195 minecraft:water[level=5]
setblock 166 61 -195 minecraft:water[level=4]
setblock 167 61 -195 minecraft:water[level=3]
setblock 168 61 -195 minecraft:water[level=2]
fill 169 61 -195 170 61 -195 minecraft:water[level=1]
setblock 171 61 -195 minecraft:water[level=2]
setblock 173 61 -195 minecraft:water[level=4]
fill 191 61 -195 199 61 -195 minecraft:water[level=0]
fill 137 61 -196 149 61 -196 minecraft:air
fill 159 61 -196 161 61 -196 minecraft:air
setblock 162 61 -196 minecraft:water[level=7]
setblock 163 61 -196 minecraft:water[level=6]
setblock 164 61 -196 minecraft:water[level=5]
setblock 165 61 -196 minecraft:water[level=4]
setblock 166 61 -196 minecraft:water[level=3]
setblock 167 61 -196 minecraft:water[level=2]
setblock 168 61 -196 minecraft:water[level=1]
fill 169 61 -196 170 61 -196 minecraft:water[level=8]
setblock 171 61 -196 minecraft:water[level=1]
setblock 172 61 -196 minecraft:water[level=2]
setblock 173 61 -196 minecraft:water[level=3]
fill 194 61 -196 199 61 -196 minecraft:water[level=0]
fill 138 61 -197 149 61 -197 minecraft:air
setblock 160 61 -197 minecraft:air
setblock 161 61 -197 minecraft:water[level=7]
setblock 162 61 -197 minecraft:water[level=6]
setblock 163 61 -197 minecraft:water[level=5]
setblock 164 61 -197 minecraft:water[level=4]
setblock 165 61 -197 minecraft:water[level=3]
setblock 166 61 -197 minecraft:water[level=2]
setblock 167 61 -197 minecraft:water[level=1]
setblock 168 61 -197 minecraft:water[level=8]
fill 196 61 -197 199 61 -197 minecraft:water[level=0]
fill 138 61 -198 149 61 -198 minecraft:air
fill 160 61 -198 161 61 -198 minecraft:air
setblock 162 61 -198 minecraft:water[level=7]
fill 198 61 -198 199 61 -198 minecraft:water[level=0]
fill 139 61 -199 149 61 -199 minecraft:air
fill 170 61 -199 175 61 -199 minecraft:water[level=0]
fill 139 61 -200 149 61 -200 minecraft:air
fill 164 61 -200 176 61 -200 minecraft:water[level=0]
fill 183 61 -200 185 61 -200 minecraft:water[level=0]
fill 140 61 -201 149 61 -201 minecraft:air
fill 164 61 -201 176 61 -201 minecraft:water[level=0]
fill 183 61 -201 185 61 -201 minecraft:water[level=0]
fill 140 61 -202 149 61 -202 minecraft:air
fill 164 61 -202 177 61 -202 minecraft:water[level=0]
fill 184 61 -202 185 61 -202 minecraft:water[level=0]
fill 140 61 -203 149 61 -203 minecraft:air
fill 164 61 -203 178 61 -203 minecraft:water[level=0]
fill 183 61 -203 185 61 -203 minecraft:water[level=0]
fill 141 61 -204 149 61 -204 minecraft:air
fill 164 61 -204 178 61 -204 minecraft:water[level=0]
fill 184 61 -204 185 61 -204 minecraft:water[level=0]
fill 141 61 -205 149 61 -205 minecraft:air
fill 164 61 -205 178 61 -205 minecraft:water[level=0]
fill 141 61 -206 149 61 -206 minecraft:air
fill 163 61 -206 178 61 -206 minecraft:water[level=0]
fill 142 61 -207 149 61 -207 minecraft:air
fill 162 61 -207 178 61 -207 minecraft:water[level=0]
setblock 184 61 -207 minecraft:water[level=0]
fill 142 61 -208 149 61 -208 minecraft:air
fill 161 61 -208 177 61 -208 minecraft:water[level=0]
fill 182 61 -208 187 61 -208 minecraft:water[level=0]
fill 142 61 -209 149 61 -209 minecraft:air
fill 156 61 -209 157 61 -209 minecraft:water[level=0]
fill 161 61 -209 175 61 -209 minecraft:water[level=0]
fill 183 61 -209 188 61 -209 minecraft:water[level=0]
fill 142 61 -210 149 61 -210 minecraft:air
fill 154 61 -210 174 61 -210 minecraft:water[level=0]
fill 183 61 -210 188 61 -210 minecraft:water[level=0]
fill 143 61 -211 149 61 -211 minecraft:air
fill 152 61 -211 173 61 -211 minecraft:water[level=0]
fill 183 61 -211 188 61 -211 minecraft:water[level=0]
fill 143 61 -212 149 61 -212 minecraft:air
fill 151 61 -212 172 61 -212 minecraft:water[level=0]
fill 183 61 -212 189 61 -212 minecraft:water[level=0]
fill 143 61 -213 149 61 -213 minecraft:air
fill 151 61 -213 172 61 -213 minecraft:water[level=0]
setblock 184 61 -213 minecraft:water[level=0]
fill 143 61 -214 149 61 -214 minecraft:air
fill 151 61 -214 171 61 -214 minecraft:water[level=0]
setblock 184 61 -214 minecraft:water[level=0]
fill 143 61 -215 149 61 -215 minecraft:air
fill 151 61 -215 167 61 -215 minecraft:water[level=0]
setblock 184 61 -215 minecraft:water[level=0]
fill 143 61 -216 149 61 -216 minecraft:air
fill 151 61 -216 167 61 -216 minecraft:water[level=0]
setblock 184 61 -216 minecraft:water[level=0]
fill 143 61 -217 149 61 -217 minecraft:air
fill 151 61 -217 166 61 -217 minecraft:water[level=0]
setblock 184 61 -217 minecraft:water[level=0]
fill 143 61 -218 149 61 -218 minecraft:air
fill 151 61 -218 165 61 -218 minecraft:water[level=0]
setblock 184 61 -218 minecraft:water[level=0]
fill 143 61 -219 149 61 -219 minecraft:air
fill 151 61 -219 165 61 -219 minecraft:water[level=0]
fill 143 61 -220 149 61 -220 minecraft:air
fill 151 61 -220 165 61 -220 minecraft:water[level=0]
setblock 167 61 -220 minecraft:water[level=8]
fill 144 61 -221 149 61 -221 minecraft:air
fill 151 61 -221 165 61 -221 minecraft:water[level=0]
fill 166 61 -221 169 61 -221 minecraft:water[level=8]
fill 143 61 -222 149 61 -222 minecraft:air
fill 151 61 -222 166 61 -222 minecraft:water[level=0]
fill 167 61 -222 169 61 -222 minecraft:water[level=8]
fill 143 61 -223 149 61 -223 minecraft:air
fill 151 61 -223 167 61 -223 minecraft:water[level=0]
setblock 168 61 -223 minecraft:water[level=8]
fill 169 61 -223 172 61 -223 minecraft:water[level=0]
fill 143 61 -224 149 61 -224 minecraft:air
fill 151 61 -224 172 61 -224 minecraft:water[level=0]
fill 143 61 -225 149 61 -225 minecraft:air
fill 151 61 -225 173 61 -225 minecraft:water[level=0]
fill 143 61 -226 149 61 -226 minecraft:air
fill 151 61 -226 174 61 -226 minecraft:water[level=0]
fill 143 61 -227 149 61 -227 minecraft:air
fill 151 61 -227 176 61 -227 minecraft:water[level=0]
fill 143 61 -228 149 61 -228 minecraft:air
fill 151 61 -228 177 61 -228 minecraft:water[level=0]
fill 143 61 -229 149 61 -229 minecraft:air
fill 151 61 -229 177 61 -229 minecraft:water[level=0]
fill 143 61 -230 149 61 -230 minecraft:air
fill 151 61 -230 177 61 -230 minecraft:water[level=0]
fill 143 61 -231 149 61 -231 minecraft:air
fill 151 61 -231 177 61 -231 minecraft:water[level=0]
fill 142 61 -232 149 61 -232 minecraft:air
fill 151 61 -232 177 61 -232 minecraft:water[level=0]
fill 142 61 -233 149 61 -233 minecraft:air
fill 151 61 -233 178 61 -233 minecraft:water[level=0]
fill 142 61 -234 149 61 -234 minecraft:air
fill 151 61 -234 185 61 -234 minecraft:water[level=0]
fill 142 61 -235 149 61 -235 minecraft:air
fill 151 61 -235 186 61 -235 minecraft:water[level=0]
setblock 192 61 -235 oritech:still_oil_block[level=0]
fill 141 61 -236 149 61 -236 minecraft:air
fill 151 61 -236 187 61 -236 minecraft:water[level=0]
fill 141 61 -237 149 61 -237 minecraft:air
fill 151 61 -237 187 61 -237 minecraft:water[level=0]
fill 141 61 -238 149 61 -238 minecraft:air
fill 151 61 -238 187 61 -238 minecraft:water[level=0]
fill 140 61 -239 149 61 -239 minecraft:air
fill 151 61 -239 192 61 -239 minecraft:water[level=0]
fill 140 61 -240 149 61 -240 minecraft:air
fill 151 61 -240 194 61 -240 minecraft:water[level=0]
fill 198 61 -240 199 61 -240 minecraft:water[level=0]
fill 140 61 -241 149 61 -241 minecraft:air
fill 151 61 -241 199 61 -241 minecraft:water[level=0]
fill 139 61 -242 149 61 -242 minecraft:air
fill 151 61 -242 199 61 -242 minecraft:water[level=0]
fill 139 61 -243 149 61 -243 minecraft:air
fill 151 61 -243 199 61 -243 minecraft:water[level=0]
fill 138 61 -244 149 61 -244 minecraft:air
fill 151 61 -244 199 61 -244 minecraft:water[level=0]
fill 138 61 -245 149 61 -245 minecraft:air
fill 151 61 -245 199 61 -245 minecraft:water[level=0]
fill 137 61 -246 149 61 -246 minecraft:air
fill 151 61 -246 199 61 -246 minecraft:water[level=0]
fill 137 61 -247 149 61 -247 minecraft:air
fill 151 61 -247 199 61 -247 minecraft:water[level=0]
fill 136 61 -248 149 61 -248 minecraft:air
fill 151 61 -248 187 61 -248 minecraft:water[level=0]
setblock 188 61 -248 minecraft:tall_seagrass[half=upper]
fill 189 61 -248 199 61 -248 minecraft:water[level=0]
fill 136 61 -249 149 61 -249 minecraft:air
fill 151 61 -249 183 61 -249 minecraft:water[level=0]
setblock 185 61 -249 minecraft:water[level=0]
setblock 186 61 -249 minecraft:tall_seagrass[half=lower]
fill 187 61 -249 199 61 -249 minecraft:water[level=0]
fill 136 61 -250 149 61 -250 minecraft:air
fill 151 61 -250 183 61 -250 minecraft:water[level=0]
fill 188 61 -250 199 61 -250 minecraft:water[level=0]
fill 136 61 -251 149 61 -251 minecraft:air
fill 151 61 -251 180 61 -251 minecraft:water[level=0]
setblock 181 61 -251 minecraft:seagrass
fill 190 61 -251 199 61 -251 minecraft:water[level=0]
fill 136 61 -252 149 61 -252 minecraft:air
fill 151 61 -252 179 61 -252 minecraft:water[level=0]
setblock 193 61 -252 minecraft:water[level=0]
setblock 194 61 -252 minecraft:seagrass
fill 195 61 -252 199 61 -252 minecraft:water[level=0]
fill 136 61 -253 149 61 -253 minecraft:air
fill 151 61 -253 178 61 -253 minecraft:water[level=0]
fill 194 61 -253 199 61 -253 minecraft:water[level=0]
fill 136 61 -254 149 61 -254 minecraft:air
fill 151 61 -254 177 61 -254 minecraft:water[level=0]
setblock 195 61 -254 minecraft:seagrass
fill 196 61 -254 199 61 -254 minecraft:water[level=0]
fill 136 60 -191 149 60 -191 minecraft:air
fill 184 60 -191 190 60 -191 minecraft:air
fill 136 60 -192 149 60 -192 minecraft:air
fill 185 60 -192 190 60 -192 minecraft:air
fill 136 60 -193 149 60 -193 minecraft:air
fill 187 60 -193 189 60 -193 minecraft:air
setblock 192 60 -193 minecraft:water[level=0]
fill 195 60 -193 197 60 -193 minecraft:water[level=0]
fill 136 60 -194 149 60 -194 minecraft:air
setblock 188 60 -194 minecraft:air
fill 191 60 -194 199 60 -194 minecraft:water[level=0]
fill 137 60 -195 149 60 -195 minecraft:air
fill 191 60 -195 199 60 -195 minecraft:water[level=0]
fill 137 60 -196 149 60 -196 minecraft:air
fill 194 60 -196 199 60 -196 minecraft:water[level=0]
fill 138 60 -197 149 60 -197 minecraft:air
setblock 183 60 -197 minecraft:air
fill 196 60 -197 199 60 -197 minecraft:water[level=0]
fill 138 60 -198 149 60 -198 minecraft:air
fill 198 60 -198 199 60 -198 minecraft:water[level=0]
fill 139 60 -199 149 60 -199 minecraft:air
setblock 199 60 -199 minecraft:water[level=0]
fill 139 60 -200 149 60 -200 minecraft:air
fill 183 60 -200 185 60 -200 minecraft:water[level=0]
fill 140 60 -201 149 60 -201 minecraft:air
fill 183 60 -201 185 60 -201 minecraft:water[level=0]
fill 140 60 -202 149 60 -202 minecraft:air
fill 184 60 -202 185 60 -202 minecraft:water[level=0]
fill 140 60 -203 149 60 -203 minecraft:air
fill 141 60 -204 149 60 -204 minecraft:air
fill 141 60 -205 149 60 -205 minecraft:air
fill 141 60 -206 149 60 -206 minecraft:air
fill 142 60 -207 149 60 -207 minecraft:air
fill 142 60 -208 149 60 -208 minecraft:air
fill 142 60 -209 149 60 -209 minecraft:air
fill 196 60 -209 199 60 -209 minecraft:water[level=0]
fill 142 60 -210 149 60 -210 minecraft:air
fill 196 60 -210 199 60 -210 minecraft:water[level=0]
fill 143 60 -211 149 60 -211 minecraft:air
setblock 199 60 -211 minecraft:water[level=0]
fill 143 60 -212 149 60 -212 minecraft:air
fill 143 60 -213 149 60 -213 minecraft:air
fill 143 60 -214 149 60 -214 minecraft:air
fill 143 60 -215 149 60 -215 minecraft:air
fill 143 60 -216 149 60 -216 minecraft:air
fill 143 60 -217 149 60 -217 minecraft:air
fill 143 60 -218 149 60 -218 minecraft:air
fill 143 60 -219 149 60 -219 minecraft:air
fill 143 60 -220 149 60 -220 minecraft:air
setblock 167 60 -220 minecraft:water[level=8]
fill 144 60 -221 149 60 -221 minecraft:air
fill 165 60 -221 169 60 -221 minecraft:water[level=8]
fill 143 60 -222 149 60 -222 minecraft:air
fill 156 60 -222 158 60 -222 minecraft:water[level=0]
fill 165 60 -222 169 60 -222 minecraft:water[level=8]
fill 143 60 -223 149 60 -223 minecraft:air
fill 155 60 -223 159 60 -223 minecraft:water[level=0]
fill 165 60 -223 170 60 -223 minecraft:water[level=8]
fill 143 60 -224 149 60 -224 minecraft:air
fill 155 60 -224 160 60 -224 minecraft:water[level=0]
fill 165 60 -224 169 60 -224 minecraft:water[level=8]
fill 143 60 -225 149 60 -225 minecraft:air
fill 154 60 -225 160 60 -225 minecraft:water[level=0]
fill 165 60 -225 169 60 -225 minecraft:water[level=8]
fill 143 60 -226 149 60 -226 minecraft:air
fill 154 60 -226 161 60 -226 minecraft:water[level=0]
setblock 167 60 -226 minecraft:water[level=8]
fill 143 60 -227 149 60 -227 minecraft:air
fill 153 60 -227 161 60 -227 minecraft:water[level=0]
fill 143 60 -228 149 60 -228 minecraft:air
fill 153 60 -228 162 60 -228 minecraft:water[level=0]
fill 172 60 -228 176 60 -228 minecraft:water[level=0]
fill 143 60 -229 149 60 -229 minecraft:air
fill 152 60 -229 162 60 -229 minecraft:water[level=0]
fill 171 60 -229 176 60 -229 minecraft:water[level=0]
fill 143 60 -230 149 60 -230 minecraft:air
fill 152 60 -230 163 60 -230 minecraft:water[level=0]
fill 169 60 -230 176 60 -230 minecraft:water[level=0]
fill 143 60 -231 149 60 -231 minecraft:air
fill 152 60 -231 177 60 -231 minecraft:water[level=0]
fill 142 60 -232 149 60 -232 minecraft:air
fill 152 60 -232 177 60 -232 minecraft:water[level=0]
fill 142 60 -233 149 60 -233 minecraft:air
fill 152 60 -233 178 60 -233 minecraft:water[level=0]
fill 142 60 -234 149 60 -234 minecraft:air
fill 153 60 -234 179 60 -234 minecraft:water[level=0]
fill 142 60 -235 149 60 -235 minecraft:air
fill 153 60 -235 185 60 -235 minecraft:water[level=0]
setblock 192 60 -235 oritech:still_oil_block[level=0]
fill 141 60 -236 149 60 -236 minecraft:air
fill 153 60 -236 186 60 -236 minecraft:water[level=0]
fill 141 60 -237 149 60 -237 minecraft:air
fill 153 60 -237 187 60 -237 minecraft:water[level=0]
fill 141 60 -238 149 60 -238 minecraft:air
fill 153 60 -238 187 60 -238 minecraft:water[level=0]
fill 140 60 -239 149 60 -239 minecraft:air
fill 153 60 -239 187 60 -239 minecraft:water[level=0]
fill 140 60 -240 149 60 -240 minecraft:air
fill 153 60 -240 187 60 -240 minecraft:water[level=0]
fill 140 60 -241 149 60 -241 minecraft:air
fill 153 60 -241 187 60 -241 minecraft:water[level=0]
fill 191 60 -241 192 60 -241 minecraft:water[level=0]
fill 139 60 -242 149 60 -242 minecraft:air
fill 153 60 -242 187 60 -242 minecraft:water[level=0]
fill 189 60 -242 195 60 -242 minecraft:water[level=0]
setblock 199 60 -242 minecraft:water[level=0]
fill 139 60 -243 149 60 -243 minecraft:air
fill 152 60 -243 199 60 -243 minecraft:water[level=0]
fill 138 60 -244 149 60 -244 minecraft:air
fill 152 60 -244 199 60 -244 minecraft:water[level=0]
fill 138 60 -245 149 60 -245 minecraft:air
fill 152 60 -245 199 60 -245 minecraft:water[level=0]
fill 137 60 -246 149 60 -246 minecraft:air
fill 151 60 -246 199 60 -246 minecraft:water[level=0]
fill 137 60 -247 149 60 -247 minecraft:air
fill 151 60 -247 188 60 -247 minecraft:water[level=0]
setblock 189 60 -247 minecraft:seagrass
fill 190 60 -247 199 60 -247 minecraft:water[level=0]
fill 136 60 -248 149 60 -248 minecraft:air
fill 151 60 -248 183 60 -248 minecraft:water[level=0]
fill 186 60 -248 187 60 -248 minecraft:water[level=0]
setblock 188 60 -248 minecraft:tall_seagrass[half=lower]
fill 189 60 -248 199 60 -248 minecraft:water[level=0]
fill 136 60 -249 149 60 -249 minecraft:air
fill 151 60 -249 183 60 -249 minecraft:water[level=0]
fill 189 60 -249 199 60 -249 minecraft:water[level=0]
fill 136 60 -250 149 60 -250 minecraft:air
fill 151 60 -250 181 60 -250 minecraft:water[level=0]
setblock 182 60 -250 minecraft:seagrass
fill 191 60 -250 199 60 -250 minecraft:water[level=0]
fill 136 60 -251 149 60 -251 minecraft:air
fill 151 60 -251 178 60 -251 minecraft:water[level=0]
setblock 179 60 -251 minecraft:tall_seagrass[half=upper]
setblock 193 60 -251 minecraft:seagrass
fill 194 60 -251 199 60 -251 minecraft:water[level=0]
fill 136 60 -252 149 60 -252 minecraft:air
fill 151 60 -252 178 60 -252 minecraft:water[level=0]
fill 195 60 -252 199 60 -252 minecraft:water[level=0]
fill 136 60 -253 149 60 -253 minecraft:air
fill 151 60 -253 178 60 -253 minecraft:water[level=0]
fill 196 60 -253 199 60 -253 minecraft:water[level=0]
fill 136 60 -254 149 60 -254 minecraft:air
fill 151 60 -254 176 60 -254 minecraft:water[level=0]
setblock 196 60 -254 minecraft:seagrass
fill 197 60 -254 199 60 -254 minecraft:water[level=0]
fill 136 59 -191 149 59 -191 minecraft:air
fill 183 59 -191 190 59 -191 minecraft:air
setblock 192 59 -191 minecraft:air
fill 136 59 -192 149 59 -192 minecraft:air
fill 183 59 -192 189 59 -192 minecraft:air
fill 136 59 -193 149 59 -193 minecraft:air
fill 182 59 -193 183 59 -193 minecraft:air
fill 186 59 -193 188 59 -193 minecraft:air
setblock 191 59 -193 minecraft:water[level=0]
setblock 196 59 -193 minecraft:water[level=0]
fill 136 59 -194 149 59 -194 minecraft:air
fill 182 59 -194 183 59 -194 minecraft:air
fill 190 59 -194 199 59 -194 minecraft:water[level=0]
fill 137 59 -195 149 59 -195 minecraft:air
fill 182 59 -195 183 59 -195 minecraft:air
fill 191 59 -195 199 59 -195 minecraft:water[level=0]
fill 137 59 -196 149 59 -196 minecraft:air
fill 194 59 -196 199 59 -196 minecraft:water[level=0]
fill 138 59 -197 149 59 -197 minecraft:air
fill 197 59 -197 199 59 -197 minecraft:water[level=0]
fill 138 59 -198 149 59 -198 minecraft:air
fill 198 59 -198 199 59 -198 minecraft:water[level=0]
fill 139 59 -199 149 59 -199 minecraft:air
fill 184 59 -199 185 59 -199 minecraft:water[level=0]
fill 139 59 -200 149 59 -200 minecraft:air
fill 183 59 -200 185 59 -200 minecraft:water[level=0]
fill 140 59 -201 149 59 -201 minecraft:air
setblock 184 59 -201 minecraft:water[level=0]
fill 140 59 -202 149 59 -202 minecraft:air
fill 140 59 -203 149 59 -203 minecraft:air
fill 141 59 -204 149 59 -204 minecraft:air
fill 141 59 -205 149 59 -205 minecraft:air
fill 141 59 -206 149 59 -206 minecraft:air
fill 142 59 -207 149 59 -207 minecraft:air
fill 142 59 -208 149 59 -208 minecraft:air
fill 142 59 -209 149 59 -209 minecraft:air
fill 194 59 -209 199 59 -209 minecraft:water[level=0]
fill 142 59 -210 149 59 -210 minecraft:air
fill 194 59 -210 199 59 -210 minecraft:water[level=0]
fill 143 59 -211 149 59 -211 minecraft:air
fill 196 59 -211 199 59 -211 minecraft:water[level=0]
fill 143 59 -212 149 59 -212 minecraft:air
fill 143 59 -213 149 59 -213 minecraft:air
fill 143 59 -214 149 59 -214 minecraft:air
fill 143 59 -215 149 59 -215 minecraft:air
fill 143 59 -216 149 59 -216 minecraft:air
fill 143 59 -217 149 59 -217 minecraft:air
fill 143 59 -218 149 59 -218 minecraft:air
fill 143 59 -219 149 59 -219 minecraft:air
fill 143 59 -220 149 59 -220 minecraft:air
fill 144 59 -221 149 59 -221 minecraft:air
fill 143 59 -222 149 59 -222 minecraft:air
fill 143 59 -223 149 59 -223 minecraft:air
fill 143 59 -224 149 59 -224 minecraft:air
fill 143 59 -225 149 59 -225 minecraft:air
setblock 156 59 -225 minecraft:water[level=8]
fill 158 59 -225 160 59 -225 minecraft:water[level=8]
fill 143 59 -226 149 59 -226 minecraft:air
fill 157 59 -226 159 59 -226 minecraft:water[level=8]
fill 143 59 -227 149 59 -227 minecraft:air
setblock 158 59 -227 minecraft:water[level=8]
fill 143 59 -228 149 59 -228 minecraft:air
fill 143 59 -229 149 59 -229 minecraft:air
fill 143 59 -230 149 59 -230 minecraft:air
fill 143 59 -231 149 59 -231 minecraft:air
setblock 176 59 -231 minecraft:water[level=0]
fill 142 59 -232 149 59 -232 minecraft:air
fill 174 59 -232 176 59 -232 minecraft:water[level=0]
fill 142 59 -233 149 59 -233 minecraft:air
fill 158 59 -233 162 59 -233 minecraft:water[level=0]
fill 171 59 -233 177 59 -233 minecraft:water[level=0]
fill 142 59 -234 149 59 -234 minecraft:air
fill 157 59 -234 178 59 -234 minecraft:water[level=0]
fill 142 59 -235 149 59 -235 minecraft:air
fill 156 59 -235 184 59 -235 minecraft:water[level=0]
setblock 192 59 -235 oritech:still_oil_block[level=0]
fill 141 59 -236 149 59 -236 minecraft:air
fill 156 59 -236 186 59 -236 minecraft:water[level=0]
fill 141 59 -237 149 59 -237 minecraft:air
fill 156 59 -237 186 59 -237 minecraft:water[level=0]
fill 141 59 -238 149 59 -238 minecraft:air
setblock 155 59 -238 minecraft:seagrass
fill 156 59 -238 186 59 -238 minecraft:water[level=0]
fill 140 59 -239 149 59 -239 minecraft:air
fill 155 59 -239 187 59 -239 minecraft:water[level=0]
fill 140 59 -240 149 59 -240 minecraft:air
fill 155 59 -240 187 59 -240 minecraft:water[level=0]
fill 140 59 -241 149 59 -241 minecraft:air
fill 155 59 -241 187 59 -241 minecraft:water[level=0]
fill 139 59 -242 149 59 -242 minecraft:air
fill 154 59 -242 187 59 -242 minecraft:water[level=0]
fill 139 59 -243 149 59 -243 minecraft:air
fill 154 59 -243 187 59 -243 minecraft:water[level=0]
fill 138 59 -244 149 59 -244 minecraft:air
setblock 154 59 -244 minecraft:water[level=0]
setblock 155 59 -244 minecraft:tall_seagrass[half=upper]
fill 156 59 -244 187 59 -244 minecraft:water[level=0]
fill 191 59 -244 195 59 -244 minecraft:water[level=0]
fill 138 59 -245 149 59 -245 minecraft:air
setblock 153 59 -245 minecraft:water[level=0]
setblock 154 59 -245 minecraft:seagrass
fill 155 59 -245 187 59 -245 minecraft:water[level=0]
fill 191 59 -245 199 59 -245 minecraft:water[level=0]
fill 137 59 -246 149 59 -246 minecraft:air
setblock 153 59 -246 minecraft:water[level=0]
setblock 154 59 -246 minecraft:tall_seagrass[half=upper]
fill 155 59 -246 187 59 -246 minecraft:water[level=0]
fill 190 59 -246 199 59 -246 minecraft:water[level=0]
fill 137 59 -247 149 59 -247 minecraft:air
fill 153 59 -247 186 59 -247 minecraft:water[level=0]
fill 190 59 -247 199 59 -247 minecraft:water[level=0]
fill 136 59 -248 149 59 -248 minecraft:air
setblock 153 59 -248 minecraft:seagrass
setblock 154 59 -248 minecraft:tall_seagrass[half=upper]
fill 155 59 -248 183 59 -248 minecraft:water[level=0]
fill 190 59 -248 199 59 -248 minecraft:water[level=0]
fill 136 59 -249 149 59 -249 minecraft:air
fill 152 59 -249 182 59 -249 minecraft:water[level=0]
fill 192 59 -249 199 59 -249 minecraft:water[level=0]
fill 136 59 -250 149 59 -250 minecraft:air
fill 151 59 -250 181 59 -250 minecraft:water[level=0]
fill 194 59 -250 199 59 -250 minecraft:water[level=0]
fill 136 59 -251 149 59 -251 minecraft:air
fill 151 59 -251 178 59 -251 minecraft:water[level=0]
setblock 179 59 -251 minecraft:tall_seagrass[half=lower]
fill 195 59 -251 199 59 -251 minecraft:water[level=0]
fill 136 59 -252 149 59 -252 minecraft:air
fill 151 59 -252 178 59 -252 minecraft:water[level=0]
fill 196 59 -252 199 59 -252 minecraft:water[level=0]
fill 136 59 -253 149 59 -253 minecraft:air
fill 151 59 -253 177 59 -253 minecraft:water[level=0]
fill 197 59 -253 199 59 -253 minecraft:water[level=0]
fill 136 59 -254 149 59 -254 minecraft:air
fill 151 59 -254 176 59 -254 minecraft:water[level=0]
setblock 198 59 -254 minecraft:water[level=0]
setblock 199 59 -254 minecraft:tall_seagrass[half=upper]
fill 182 58 -191 189 58 -191 minecraft:air
fill 192 58 -191 194 58 -191 minecraft:air
fill 182 58 -192 189 58 -192 minecraft:air
fill 183 58 -193 184 58 -193 minecraft:air
fill 186 58 -193 188 58 -193 minecraft:air
setblock 191 58 -193 minecraft:water[level=0]
fill 190 58 -194 191 58 -194 minecraft:water[level=0]
setblock 137 58 -197 oritech:still_oil_block[level=0]
setblock 184 58 -199 minecraft:water[level=0]
fill 191 58 -209 199 58 -209 minecraft:water[level=0]
fill 192 58 -210 199 58 -210 minecraft:water[level=0]
fill 195 58 -211 199 58 -211 minecraft:water[level=0]
fill 175 58 -233 176 58 -233 minecraft:water[level=0]
fill 173 58 -234 177 58 -234 minecraft:water[level=0]
fill 160 58 -235 162 58 -235 minecraft:water[level=0]
fill 168 58 -235 179 58 -235 minecraft:water[level=0]
setblock 192 58 -235 oritech:still_oil_block[level=0]
fill 158 58 -236 185 58 -236 minecraft:water[level=0]
fill 158 58 -237 161 58 -237 minecraft:water[level=0]
setblock 162 58 -237 minecraft:tall_seagrass[half=upper]
fill 163 58 -237 185 58 -237 minecraft:water[level=0]
fill 157 58 -238 186 58 -238 minecraft:water[level=0]
fill 157 58 -239 186 58 -239 minecraft:water[level=0]
fill 156 58 -240 187 58 -240 minecraft:water[level=0]
fill 156 58 -241 187 58 -241 minecraft:water[level=0]
fill 155 58 -242 187 58 -242 minecraft:water[level=0]
fill 155 58 -243 187 58 -243 minecraft:water[level=0]
setblock 155 58 -244 minecraft:tall_seagrass[half=lower]
fill 156 58 -244 187 58 -244 minecraft:water[level=0]
fill 155 58 -245 187 58 -245 minecraft:water[level=0]
setblock 154 58 -246 minecraft:tall_seagrass[half=lower]
fill 155 58 -246 186 58 -246 minecraft:water[level=0]
setblock 196 58 -246 minecraft:water[level=0]
fill 154 58 -247 184 58 -247 minecraft:water[level=0]
fill 194 58 -247 197 58 -247 minecraft:water[level=0]
setblock 154 58 -248 minecraft:tall_seagrass[half=lower]
setblock 155 58 -248 minecraft:tall_seagrass[half=upper]
fill 156 58 -248 182 58 -248 minecraft:water[level=0]
fill 193 58 -248 198 58 -248 minecraft:water[level=0]
fill 153 58 -249 181 58 -249 minecraft:water[level=0]
setblock 182 58 -249 minecraft:seagrass
fill 195 58 -249 198 58 -249 minecraft:water[level=0]
setblock 152 58 -250 minecraft:seagrass
fill 153 58 -250 180 58 -250 minecraft:water[level=0]
fill 196 58 -250 199 58 -250 minecraft:water[level=0]
setblock 150 58 -251 minecraft:water[level=0]
setblock 151 58 -251 minecraft:seagrass
setblock 152 58 -251 minecraft:tall_seagrass[half=upper]
fill 153 58 -251 178 58 -251 minecraft:water[level=0]
setblock 197 58 -251 minecraft:seagrass
fill 198 58 -251 199 58 -251 minecraft:water[level=0]
fill 151 58 -252 178 58 -252 minecraft:water[level=0]
fill 198 58 -252 199 58 -252 minecraft:water[level=0]
fill 136 58 -253 143 58 -253 minecraft:water[level=0]
fill 151 58 -253 177 58 -253 minecraft:water[level=0]
fill 198 58 -253 199 58 -253 minecraft:seagrass
fill 151 58 -254 175 58 -254 minecraft:water[level=0]
setblock 199 58 -254 minecraft:tall_seagrass[half=lower]
fill 184 57 -191 189 57 -191 minecraft:air
fill 192 57 -191 194 57 -191 minecraft:air
fill 186 57 -192 188 57 -192 minecraft:air
fill 195 57 -192 196 57 -192 minecraft:air
setblock 137 57 -197 oritech:still_oil_block[level=0]
setblock 136 57 -207 minecraft:water[level=0]
setblock 136 57 -208 minecraft:water[level=0]
fill 185 57 -208 189 57 -208 minecraft:water[level=0]
fill 191 57 -208 193 57 -208 minecraft:water[level=0]
fill 187 57 -209 198 57 -209 minecraft:water[level=0]
fill 191 57 -210 198 57 -210 minecraft:water[level=0]
fill 195 57 -211 197 57 -211 minecraft:water[level=0]
setblock 176 57 -234 minecraft:water[level=0]
fill 173 57 -235 178 57 -235 minecraft:water[level=0]
setblock 192 57 -235 oritech:still_oil_block[level=0]
setblock 160 57 -236 minecraft:water[level=0]
fill 170 57 -236 182 57 -236 minecraft:water[level=0]
fill 159 57 -237 161 57 -237 minecraft:water[level=0]
setblock 162 57 -237 minecraft:tall_seagrass[half=lower]
fill 163 57 -237 184 57 -237 minecraft:water[level=0]
fill 159 57 -238 185 57 -238 minecraft:water[level=0]
fill 158 57 -239 186 57 -239 minecraft:water[level=0]
fill 157 57 -240 186 57 -240 minecraft:water[level=0]
fill 157 57 -241 186 57 -241 minecraft:water[level=0]
fill 156 57 -242 186 57 -242 minecraft:water[level=0]
fill 156 57 -243 186 57 -243 minecraft:water[level=0]
fill 156 57 -244 186 57 -244 minecraft:water[level=0]
fill 155 57 -245 186 57 -245 minecraft:water[level=0]
setblock 155 57 -246 minecraft:seagrass
setblock 156 57 -246 minecraft:tall_seagrass[half=upper]
fill 157 57 -246 183 57 -246 minecraft:water[level=0]
setblock 184 57 -246 minecraft:tall_seagrass[half=upper]
setblock 185 57 -246 minecraft:water[level=0]
setblock 155 57 -247 minecraft:water[level=0]
setblock 156 57 -247 minecraft:tall_seagrass[half=upper]
fill 157 57 -247 183 57 -247 minecraft:water[level=0]
setblock 155 57 -248 minecraft:tall_seagrass[half=lower]
fill 156 57 -248 182 57 -248 minecraft:water[level=0]
setblock 196 57 -248 minecraft:water[level=0]
fill 154 57 -249 181 57 -249 minecraft:water[level=0]
fill 153 57 -250 179 57 -250 minecraft:water[level=0]
setblock 152 57 -251 minecraft:tall_seagrass[half=lower]
setblock 153 57 -251 minecraft:tall_seagrass[half=upper]
fill 154 57 -251 178 57 -251 minecraft:water[level=0]
fill 150 57 -252 177 57 -252 minecraft:water[level=0]
setblock 199 57 -252 minecraft:water[level=0]
fill 151 57 -253 176 57 -253 minecraft:water[level=0]
fill 136 57 -254 138 57 -254 minecraft:water[level=0]
fill 151 57 -254 175 57 -254 minecraft:water[level=0]
fill 192 56 -191 195 56 -191 minecraft:air
fill 194 56 -192 198 56 -192 minecraft:air
setblock 137 56 -197 oritech:still_oil_block[level=0]
setblock 136 56 -206 minecraft:water[level=0]
setblock 136 56 -207 minecraft:water[level=0]
fill 185 56 -207 186 56 -207 minecraft:water[level=0]
setblock 136 56 -208 minecraft:water[level=0]
fill 185 56 -208 192 56 -208 minecraft:water[level=0]
setblock 136 56 -209 minecraft:water[level=0]
fill 186 56 -209 194 56 -209 minecraft:water[level=0]
fill 189 56 -210 194 56 -210 minecraft:water[level=0]
fill 175 56 -235 176 56 -235 minecraft:water[level=0]
setblock 192 56 -235 oritech:still_oil_block[level=0]
fill 173 56 -236 179 56 -236 minecraft:water[level=0]
fill 168 56 -237 183 56 -237 minecraft:water[level=0]
fill 160 56 -238 161 56 -238 minecraft:water[level=0]
setblock 162 56 -238 minecraft:seagrass
fill 163 56 -238 164 56 -238 minecraft:water[level=0]
setblock 165 56 -238 minecraft:seagrass
fill 166 56 -238 184 56 -238 minecraft:water[level=0]
fill 159 56 -239 185 56 -239 minecraft:water[level=0]
setblock 158 56 -240 minecraft:water[level=0]
setblock 159 56 -240 minecraft:seagrass
fill 160 56 -240 186 56 -240 minecraft:water[level=0]
fill 158 56 -241 186 56 -241 minecraft:water[level=0]
fill 157 56 -242 186 56 -242 minecraft:water[level=0]
fill 157 56 -243 186 56 -243 minecraft:water[level=0]
setblock 156 56 -244 minecraft:water[level=0]
setblock 157 56 -244 minecraft:seagrass
fill 158 56 -244 186 56 -244 minecraft:water[level=0]
fill 156 56 -245 157 56 -245 minecraft:water[level=0]
fill 158 56 -245 159 56 -245 minecraft:tall_seagrass[half=upper]
fill 160 56 -245 185 56 -245 minecraft:water[level=0]
setblock 156 56 -246 minecraft:tall_seagrass[half=lower]
fill 157 56 -246 183 56 -246 minecraft:water[level=0]
setblock 184 56 -246 minecraft:tall_seagrass[half=lower]
setblock 156 56 -247 minecraft:tall_seagrass[half=lower]
setblock 157 56 -247 minecraft:tall_seagrass[half=upper]
fill 158 56 -247 181 56 -247 minecraft:water[level=0]
setblock 182 56 -247 minecraft:tall_seagrass[half=upper]
setblock 183 56 -247 minecraft:water[level=0]
setblock 156 56 -248 minecraft:seagrass
setblock 157 56 -248 minecraft:tall_seagrass[half=upper]
fill 158 56 -248 180 56 -248 minecraft:water[level=0]
setblock 181 56 -248 minecraft:tall_seagrass[half=upper]
setblock 182 56 -248 minecraft:water[level=0]
setblock 155 56 -249 minecraft:seagrass
fill 156 56 -249 181 56 -249 minecraft:water[level=0]
fill 154 56 -250 179 56 -250 minecraft:water[level=0]
setblock 153 56 -251 minecraft:tall_seagrass[half=lower]
fill 154 56 -251 178 56 -251 minecraft:water[level=0]
fill 151 56 -252 177 56 -252 minecraft:water[level=0]
fill 150 56 -253 176 56 -253 minecraft:water[level=0]
fill 138 56 -254 142 56 -254 minecraft:water[level=0]
fill 151 56 -254 174 56 -254 minecraft:water[level=0]
fill 193 55 -191 194 55 -191 minecraft:air
fill 198 55 -191 199 55 -191 minecraft:air
fill 194 55 -192 199 55 -192 minecraft:air
fill 197 55 -193 199 55 -193 minecraft:air
setblock 137 55 -197 oritech:still_oil_block[level=0]
setblock 136 55 -207 minecraft:water[level=0]
fill 185 55 -207 186 55 -207 minecraft:water[level=0]
setblock 136 55 -208 minecraft:water[level=0]
fill 185 55 -208 190 55 -208 minecraft:water[level=0]
setblock 136 55 -209 minecraft:water[level=0]
fill 186 55 -209 190 55 -209 minecraft:water[level=0]
setblock 189 55 -210 minecraft:water[level=0]
setblock 192 55 -235 oritech:still_oil_block[level=0]
fill 175 55 -236 177 55 -236 minecraft:water[level=0]
fill 174 55 -237 179 55 -237 minecraft:water[level=0]
fill 168 55 -238 184 55 -238 minecraft:water[level=0]
setblock 162 55 -239 minecraft:seagrass
fill 163 55 -239 185 55 -239 minecraft:water[level=0]
setblock 160 55 -240 minecraft:water[level=0]
setblock 161 55 -240 minecraft:seagrass
fill 162 55 -240 185 55 -240 minecraft:water[level=0]
fill 160 55 -241 185 55 -241 minecraft:water[level=0]
fill 159 55 -242 160 55 -242 minecraft:water[level=0]
setblock 161 55 -242 minecraft:seagrass
fill 162 55 -242 185 55 -242 minecraft:water[level=0]
setblock 158 55 -243 minecraft:seagrass
setblock 159 55 -243 minecraft:water[level=0]
setblock 160 55 -243 minecraft:seagrass
fill 161 55 -243 185 55 -243 minecraft:water[level=0]
setblock 158 55 -244 minecraft:water[level=0]
setblock 159 55 -244 minecraft:seagrass
fill 160 55 -244 185 55 -244 minecraft:water[level=0]
setblock 157 55 -245 minecraft:water[level=0]
fill 158 55 -245 159 55 -245 minecraft:tall_seagrass[half=lower]
setblock 160 55 -245 minecraft:water[level=0]
fill 161 55 -245 162 55 -245 minecraft:tall_seagrass[half=upper]
fill 163 55 -245 185 55 -245 minecraft:water[level=0]
fill 157 55 -246 158 55 -246 minecraft:seagrass
fill 159 55 -246 183 55 -246 minecraft:water[level=0]
setblock 157 55 -247 minecraft:tall_seagrass[half=lower]
fill 158 55 -247 181 55 -247 minecraft:water[level=0]
setblock 182 55 -247 minecraft:tall_seagrass[half=lower]
setblock 157 55 -248 minecraft:tall_seagrass[half=lower]
fill 158 55 -248 180 55 -248 minecraft:water[level=0]
setblock 181 55 -248 minecraft:tall_seagrass[half=lower]
setblock 156 55 -249 minecraft:water[level=0]
setblock 157 55 -249 minecraft:seagrass
setblock 158 55 -249 minecraft:tall_seagrass[half=upper]
fill 159 55 -249 179 55 -249 minecraft:water[level=0]
setblock 180 55 -249 minecraft:seagrass
setblock 155 55 -250 minecraft:water[level=0]
setblock 156 55 -250 minecraft:seagrass
fill 157 55 -250 178 55 -250 minecraft:water[level=0]
setblock 154 55 -251 minecraft:water[level=0]
setblock 155 55 -251 minecraft:seagrass
fill 156 55 -251 177 55 -251 minecraft:water[level=0]
fill 152 55 -252 176 55 -252 minecraft:water[level=0]
fill 151 55 -253 162 55 -253 minecraft:water[level=0]
setblock 163 55 -253 minecraft:tall_seagrass[half=upper]
fill 164 55 -253 175 55 -253 minecraft:water[level=0]
fill 151 55 -254 173 55 -254 minecraft:water[level=0]
fill 197 54 -191 199 54 -191 minecraft:air
fill 195 54 -192 199 54 -192 minecraft:air
fill 197 54 -193 199 54 -193 minecraft:air
setblock 137 54 -197 oritech:still_oil_block[level=0]
setblock 136 54 -208 minecraft:water[level=0]
setblock 136 54 -209 minecraft:water[level=0]
setblock 192 54 -235 oritech:still_oil_block[level=0]
setblock 176 54 -238 minecraft:water[level=0]
fill 174 54 -239 184 54 -239 minecraft:water[level=0]
setblock 164 54 -240 minecraft:water[level=0]
setblock 165 54 -240 minecraft:seagrass
fill 166 54 -240 185 54 -240 minecraft:water[level=0]
fill 163 54 -241 165 54 -241 minecraft:water[level=0]
setblock 166 54 -241 minecraft:seagrass
fill 167 54 -241 185 54 -241 minecraft:water[level=0]
setblock 162 54 -242 minecraft:seagrass
fill 163 54 -242 185 54 -242 minecraft:water[level=0]
setblock 161 54 -243 minecraft:water[level=0]
setblock 162 54 -243 minecraft:seagrass
fill 163 54 -243 165 54 -243 minecraft:water[level=0]
setblock 166 54 -243 minecraft:seagrass
fill 167 54 -243 185 54 -243 minecraft:water[level=0]
fill 160 54 -244 163 54 -244 minecraft:seagrass
fill 164 54 -244 185 54 -244 minecraft:water[level=0]
setblock 160 54 -245 minecraft:seagrass
fill 161 54 -245 162 54 -245 minecraft:tall_seagrass[half=lower]
fill 163 54 -245 164 54 -245 minecraft:water[level=0]
setblock 165 54 -245 minecraft:tall_seagrass[half=upper]
fill 166 54 -245 182 54 -245 minecraft:water[level=0]
setblock 183 54 -245 minecraft:seagrass
setblock 184 54 -245 minecraft:water[level=0]
fill 159 54 -246 161 54 -246 minecraft:seagrass
setblock 162 54 -246 minecraft:water[level=0]
setblock 163 54 -246 minecraft:tall_seagrass[half=upper]
fill 164 54 -246 166 54 -246 minecraft:water[level=0]
setblock 167 54 -246 minecraft:tall_seagrass[half=upper]
fill 168 54 -246 182 54 -246 minecraft:water[level=0]
fill 159 54 -247 161 54 -247 minecraft:seagrass
fill 162 54 -247 181 54 -247 minecraft:water[level=0]
setblock 159 54 -248 minecraft:water[level=0]
setblock 160 54 -248 minecraft:seagrass
fill 161 54 -248 176 54 -248 minecraft:water[level=0]
setblock 177 54 -248 minecraft:tall_seagrass[half=upper]
fill 178 54 -248 180 54 -248 minecraft:water[level=0]
setblock 158 54 -249 minecraft:tall_seagrass[half=lower]
fill 159 54 -249 176 54 -249 minecraft:water[level=0]
setblock 177 54 -249 minecraft:tall_seagrass[half=upper]
setblock 178 54 -249 minecraft:seagrass
setblock 179 54 -249 minecraft:water[level=0]
fill 157 54 -250 177 54 -250 minecraft:water[level=0]
setblock 156 54 -251 minecraft:seagrass
fill 157 54 -251 175 54 -251 minecraft:water[level=0]
setblock 176 54 -251 minecraft:seagrass
fill 154 54 -252 157 54 -252 minecraft:water[level=0]
setblock 158 54 -252 minecraft:tall_seagrass[half=upper]
fill 159 54 -252 175 54 -252 minecraft:water[level=0]
setblock 176 54 -252 minecraft:seagrass
fill 152 54 -253 162 54 -253 minecraft:water[level=0]
setblock 163 54 -253 minecraft:tall_seagrass[half=lower]
fill 164 54 -253 172 54 -253 minecraft:water[level=0]
fill 151 54 -254 167 54 -254 minecraft:water[level=0]
fill 197 53 -191 199 53 -191 minecraft:air
fill 197 53 -192 199 53 -192 minecraft:air
fill 197 53 -193 199 53 -193 minecraft:air
setblock 137 53 -197 oritech:still_oil_block[level=0]
setblock 136 53 -208 minecraft:water[level=0]
setblock 136 53 -209 minecraft:water[level=0]
setblock 175 53 -226 minecraft:water[level=0]
setblock 173 53 -227 minecraft:water[level=0]
fill 169 53 -228 172 53 -228 minecraft:water[level=0]
fill 167 53 -229 170 53 -229 minecraft:water[level=0]
fill 166 53 -230 169 53 -230 minecraft:water[level=0]
fill 164 53 -231 167 53 -231 minecraft:water[level=0]
fill 163 53 -232 165 53 -232 minecraft:water[level=0]
fill 161 53 -233 164 53 -233 minecraft:water[level=0]
fill 160 53 -234 162 53 -234 minecraft:water[level=0]
fill 159 53 -235 161 53 -235 minecraft:water[level=0]
setblock 192 53 -235 oritech:still_oil_block[level=0]
fill 159 53 -236 160 53 -236 minecraft:water[level=0]
fill 179 53 -240 184 53 -240 minecraft:water[level=0]
fill 178 53 -241 184 53 -241 minecraft:water[level=0]
fill 176 53 -242 184 53 -242 minecraft:water[level=0]
fill 173 53 -243 184 53 -243 minecraft:water[level=0]
fill 168 53 -244 178 53 -244 minecraft:water[level=0]
setblock 179 53 -244 minecraft:seagrass
fill 180 53 -244 184 53 -244 minecraft:water[level=0]
setblock 164 53 -245 minecraft:water[level=0]
setblock 165 53 -245 minecraft:tall_seagrass[half=lower]
fill 166 53 -245 179 53 -245 minecraft:water[level=0]
setblock 180 53 -245 minecraft:seagrass
setblock 181 53 -245 minecraft:water[level=0]
setblock 163 53 -246 minecraft:tall_seagrass[half=lower]
setblock 164 53 -246 minecraft:seagrass
fill 165 53 -246 166 53 -246 minecraft:water[level=0]
setblock 167 53 -246 minecraft:tall_seagrass[half=lower]
fill 168 53 -246 180 53 -246 minecraft:water[level=0]
setblock 162 53 -247 minecraft:water[level=0]
setblock 163 53 -247 minecraft:seagrass
setblock 164 53 -247 minecraft:water[level=0]
setblock 165 53 -247 minecraft:seagrass
fill 166 53 -247 175 53 -247 minecraft:water[level=0]
setblock 176 53 -247 minecraft:seagrass
fill 177 53 -247 179 53 -247 minecraft:water[level=0]
fill 161 53 -248 176 53 -248 minecraft:water[level=0]
setblock 177 53 -248 minecraft:tall_seagrass[half=lower]
fill 178 53 -248 179 53 -248 minecraft:water[level=0]
setblock 161 53 -249 minecraft:water[level=0]
setblock 162 53 -249 minecraft:seagrass
fill 163 53 -249 176 53 -249 minecraft:water[level=0]
setblock 177 53 -249 minecraft:tall_seagrass[half=lower]
fill 160 53 -250 162 53 -250 minecraft:seagrass
fill 163 53 -250 170 53 -250 minecraft:water[level=0]
fill 174 53 -250 176 53 -250 minecraft:water[level=0]
fill 159 53 -251 167 53 -251 minecraft:water[level=0]
setblock 158 53 -252 minecraft:tall_seagrass[half=lower]
setblock 159 53 -252 minecraft:seagrass
fill 160 53 -252 164 53 -252 minecraft:water[level=0]
setblock 157 53 -253 minecraft:seagrass
fill 158 53 -253 162 53 -253 minecraft:water[level=0]
fill 152 53 -254 154 53 -254 minecraft:water[level=0]
setblock 155 53 -254 minecraft:seagrass
fill 156 53 -254 160 53 -254 minecraft:water[level=0]
fill 198 52 -191 199 52 -191 minecraft:air
setblock 199 52 -192 minecraft:air
setblock 137 52 -197 oritech:still_oil_block[level=0]
setblock 136 52 -211 minecraft:water[level=0]
setblock 136 52 -212 minecraft:water[level=0]
setblock 181 52 -221 minecraft:water[level=0]
fill 179 52 -222 180 52 -222 minecraft:water[level=0]
fill 177 52 -223 179 52 -223 minecraft:water[level=0]
fill 175 52 -224 178 52 -224 minecraft:water[level=0]
fill 174 52 -225 176 52 -225 minecraft:water[level=0]
fill 172 52 -226 175 52 -226 minecraft:water[level=0]
fill 171 52 -227 174 52 -227 minecraft:water[level=0]
fill 169 52 -228 172 52 -228 minecraft:water[level=0]
fill 167 52 -229 171 52 -229 minecraft:water[level=0]
fill 165 52 -230 169 52 -230 minecraft:water[level=0]
fill 164 52 -231 167 52 -231 minecraft:water[level=0]
fill 162 52 -232 165 52 -232 minecraft:water[level=0]
fill 161 52 -233 164 52 -233 minecraft:water[level=0]
fill 160 52 -234 162 52 -234 minecraft:water[level=0]
fill 159 52 -235 161 52 -235 minecraft:water[level=0]
setblock 192 52 -235 oritech:still_oil_block[level=0]
fill 158 52 -236 160 52 -236 minecraft:water[level=0]
fill 157 52 -237 158 52 -237 minecraft:water[level=0]
setblock 157 52 -238 minecraft:water[level=0]
setblock 164 52 -247 minecraft:water[level=0]
setblock 163 52 -248 minecraft:water[level=0]
setblock 164 52 -248 minecraft:seagrass
setblock 165 52 -248 minecraft:water[level=0]
setblock 166 52 -248 minecraft:seagrass
fill 164 52 -249 165 52 -249 minecraft:water[level=0]
setblock 137 51 -197 oritech:still_oil_block[level=0]
setblock 136 51 -210 minecraft:water[level=0]
setblock 136 51 -211 minecraft:water[level=0]
setblock 136 51 -212 minecraft:water[level=0]
setblock 136 51 -213 minecraft:water[level=0]
fill 183 51 -219 184 51 -219 minecraft:water[level=0]
fill 181 51 -220 183 51 -220 minecraft:water[level=0]
fill 179 51 -221 182 51 -221 minecraft:water[level=0]
fill 177 51 -222 180 51 -222 minecraft:water[level=0]
fill 176 51 -223 179 51 -223 minecraft:water[level=0]
fill 175 51 -224 178 51 -224 minecraft:water[level=0]
fill 174 51 -225 177 51 -225 minecraft:water[level=0]
fill 173 51 -226 176 51 -226 minecraft:water[level=0]
fill 171 51 -227 174 51 -227 minecraft:water[level=0]
fill 169 51 -228 173 51 -228 minecraft:water[level=0]
fill 167 51 -229 171 51 -229 minecraft:water[level=0]
fill 165 51 -230 169 51 -230 minecraft:water[level=0]
fill 164 51 -231 168 51 -231 minecraft:water[level=0]
fill 162 51 -232 166 51 -232 minecraft:water[level=0]
fill 161 51 -233 164 51 -233 minecraft:water[level=0]
fill 159 51 -234 162 51 -234 minecraft:water[level=0]
fill 158 51 -235 161 51 -235 minecraft:water[level=0]
setblock 192 51 -235 oritech:still_oil_block[level=0]
fill 157 51 -236 159 51 -236 minecraft:water[level=0]
fill 156 51 -237 158 51 -237 minecraft:water[level=0]
fill 155 51 -238 157 51 -238 minecraft:water[level=0]
fill 155 51 -239 156 51 -239 minecraft:water[level=0]
fill 154 51 -240 155 51 -240 minecraft:water[level=0]
setblock 136 50 -191 oritech:still_oil_block[level=0]
setblock 138 50 -191 oritech:still_oil_block[level=0]
fill 171 50 -191 174 50 -191 minecraft:water[level=0]
fill 170 50 -192 173 50 -192 minecraft:water[level=0]
setblock 140 50 -193 oritech:still_oil_block[level=0]
setblock 172 50 -193 minecraft:water[level=0]
fill 136 50 -194 138 50 -194 oritech:still_oil_block[level=0]
setblock 137 50 -197 oritech:still_oil_block[level=0]
setblock 136 50 -211 minecraft:water[level=0]
setblock 136 50 -212 minecraft:water[level=0]
setblock 136 50 -213 minecraft:water[level=0]
setblock 136 50 -214 minecraft:water[level=0]
setblock 136 50 -215 minecraft:water[level=0]
setblock 187 50 -217 minecraft:water[level=0]
fill 184 50 -218 186 50 -218 minecraft:water[level=0]
fill 182 50 -219 184 50 -219 minecraft:water[level=0]
fill 180 50 -220 183 50 -220 minecraft:water[level=0]
fill 179 50 -221 182 50 -221 minecraft:water[level=0]
fill 178 50 -222 181 50 -222 minecraft:water[level=0]
fill 177 50 -223 179 50 -223 minecraft:water[level=0]
fill 176 50 -224 177 50 -224 minecraft:water[level=0]
fill 174 50 -225 176 50 -225 minecraft:water[level=0]
fill 173 50 -226 174 50 -226 minecraft:water[level=0]
fill 171 50 -227 172 50 -227 minecraft:water[level=0]
setblock 192 50 -235 oritech:still_oil_block[level=0]
fill 157 50 -236 158 50 -236 minecraft:water[level=0]
fill 156 50 -237 158 50 -237 minecraft:water[level=0]
fill 155 50 -238 157 50 -238 minecraft:water[level=0]
fill 154 50 -239 156 50 -239 minecraft:water[level=0]
fill 153 50 -240 155 50 -240 minecraft:water[level=0]
fill 153 50 -241 154 50 -241 minecraft:water[level=0]
fill 136 49 -191 143 49 -191 oritech:still_oil_block[level=0]
fill 166 49 -191 168 49 -191 minecraft:air
fill 170 49 -191 178 49 -191 minecraft:water[level=0]
fill 136 49 -192 142 49 -192 oritech:still_oil_block[level=0]
fill 167 49 -192 168 49 -192 minecraft:air
fill 170 49 -192 178 49 -192 minecraft:water[level=0]
fill 136 49 -193 142 49 -193 oritech:still_oil_block[level=0]
fill 170 49 -193 178 49 -193 minecraft:water[level=0]
fill 136 49 -194 142 49 -194 oritech:still_oil_block[level=0]
fill 171 49 -194 177 49 -194 minecraft:water[level=0]
fill 136 49 -195 141 49 -195 oritech:still_oil_block[level=0]
fill 174 49 -195 176 49 -195 minecraft:water[level=0]
fill 136 49 -196 141 49 -196 oritech:still_oil_block[level=0]
fill 136 49 -197 141 49 -197 oritech:still_oil_block[level=0]
setblock 139 49 -198 oritech:still_oil_block[level=0]
setblock 136 49 -213 minecraft:water[level=0]
setblock 136 49 -214 minecraft:water[level=0]
fill 197 49 -214 199 49 -214 minecraft:water[level=0]
setblock 136 49 -215 minecraft:water[level=0]
fill 193 49 -215 196 49 -215 minecraft:water[level=0]
setblock 136 49 -216 minecraft:water[level=0]
fill 189 49 -216 191 49 -216 minecraft:water[level=0]
setblock 136 49 -217 minecraft:bubble_column[drag=true]
fill 185 49 -217 189 49 -217 minecraft:water[level=0]
setblock 136 49 -218 minecraft:water[level=0]
fill 182 49 -218 187 49 -218 minecraft:water[level=0]
fill 181 49 -219 185 49 -219 minecraft:water[level=0]
fill 180 49 -220 183 49 -220 minecraft:water[level=0]
fill 179 49 -221 181 49 -221 minecraft:water[level=0]
fill 178 49 -222 179 49 -222 minecraft:water[level=0]
setblock 177 49 -223 minecraft:water[level=0]
setblock 193 49 -229 oritech:still_oil_block[level=0]
setblock 190 49 -230 oritech:still_oil_block[level=0]
setblock 194 49 -230 oritech:still_oil_block[level=0]
setblock 191 49 -231 oritech:still_oil_block[level=0]
setblock 193 49 -232 oritech:still_oil_block[level=0]
setblock 192 49 -235 oritech:still_oil_block[level=0]
fill 154 49 -238 156 49 -238 minecraft:water[level=0]
fill 154 49 -239 156 49 -239 minecraft:water[level=0]
fill 153 49 -240 155 49 -240 minecraft:water[level=0]
fill 152 49 -241 154 49 -241 minecraft:water[level=0]
fill 151 49 -242 153 49 -242 minecraft:water[level=0]
fill 151 49 -243 152 49 -243 minecraft:water[level=0]
setblock 150 49 -244 minecraft:water[level=0]
fill 136 48 -191 144 48 -191 oritech:still_oil_block[level=0]
fill 175 48 -191 181 48 -191 minecraft:water[level=0]
fill 195 48 -191 199 48 -191 minecraft:air
fill 136 48 -192 144 48 -192 oritech:still_oil_block[level=0]
fill 174 48 -192 181 48 -192 minecraft:water[level=0]
fill 195 48 -192 199 48 -192 minecraft:air
fill 136 48 -193 143 48 -193 oritech:still_oil_block[level=0]
fill 171 48 -193 181 48 -193 minecraft:water[level=0]
fill 136 48 -194 143 48 -194 oritech:still_oil_block[level=0]
fill 173 48 -194 180 48 -194 minecraft:water[level=0]
fill 136 48 -195 143 48 -195 oritech:still_oil_block[level=0]
fill 177 48 -195 180 48 -195 minecraft:water[level=0]
fill 136 48 -196 143 48 -196 oritech:still_oil_block[level=0]
fill 136 48 -197 142 48 -197 oritech:still_oil_block[level=0]
fill 136 48 -198 141 48 -198 oritech:still_oil_block[level=0]
setblock 137 48 -199 oritech:still_oil_block[level=0]
setblock 141 48 -199 oritech:still_oil_block[level=0]
setblock 136 48 -214 minecraft:water[level=0]
fill 195 48 -214 199 48 -214 minecraft:water[level=0]
setblock 136 48 -215 minecraft:water[level=0]
fill 191 48 -215 199 48 -215 minecraft:water[level=0]
setblock 136 48 -216 minecraft:water[level=0]
fill 187 48 -216 195 48 -216 minecraft:water[level=0]
setblock 136 48 -217 minecraft:bubble_column[drag=true]
fill 183 48 -217 190 48 -217 minecraft:water[level=0]
setblock 136 48 -218 minecraft:water[level=0]
fill 182 48 -218 187 48 -218 minecraft:water[level=0]
fill 181 48 -219 184 48 -219 minecraft:water[level=0]
fill 181 48 -220 182 48 -220 minecraft:water[level=0]
setblock 180 48 -221 minecraft:water[level=0]
fill 192 48 -225 193 48 -225 oritech:still_oil_block[level=0]
setblock 190 48 -226 oritech:still_oil_block[level=0]
fill 192 48 -226 194 48 -226 oritech:still_oil_block[level=0]
fill 188 48 -227 196 48 -227 oritech:still_oil_block[level=0]
setblock 189 48 -228 oritech:still_oil_block[level=0]
fill 191 48 -228 195 48 -228 oritech:still_oil_block[level=0]
fill 190 48 -229 195 48 -229 oritech:still_oil_block[level=0]
setblock 188 48 -230 oritech:still_oil_block[level=0]
fill 190 48 -230 195 48 -230 oritech:still_oil_block[level=0]
setblock 187 48 -231 oritech:still_oil_block[level=0]
fill 189 48 -231 196 48 -231 oritech:still_oil_block[level=0]
setblock 187 48 -232 oritech:still_oil_block[level=0]
fill 189 48 -232 196 48 -232 oritech:still_oil_block[level=0]
fill 189 48 -233 196 48 -233 oritech:still_oil_block[level=0]
fill 191 48 -234 193 48 -234 oritech:still_oil_block[level=0]
setblock 192 48 -235 oritech:still_oil_block[level=0]
setblock 195 48 -235 oritech:still_oil_block[level=0]
fill 152 48 -240 154 48 -240 minecraft:water[level=0]
fill 151 48 -241 154 48 -241 minecraft:water[level=0]
fill 151 48 -242 153 48 -242 minecraft:water[level=0]
fill 150 48 -243 152 48 -243 minecraft:water[level=0]
fill 150 48 -244 151 48 -244 minecraft:water[level=0]
fill 149 48 -245 151 48 -245 minecraft:water[level=0]
fill 136 47 -191 144 47 -191 oritech:still_oil_block[level=0]
fill 179 47 -191 183 47 -191 minecraft:water[level=0]
fill 195 47 -191 199 47 -191 minecraft:air
fill 136 47 -192 144 47 -192 oritech:still_oil_block[level=0]
fill 178 47 -192 183 47 -192 minecraft:water[level=0]
fill 195 47 -192 198 47 -192 minecraft:air
setblock 199 47 -192 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=false,waterlogged=false,west=false]
fill 136 47 -193 146 47 -193 oritech:still_oil_block[level=0]
fill 177 47 -193 183 47 -193 minecraft:water[level=0]
fill 136 47 -194 145 47 -194 oritech:still_oil_block[level=0]
fill 177 47 -194 182 47 -194 minecraft:water[level=0]
fill 136 47 -195 145 47 -195 oritech:still_oil_block[level=0]
fill 136 47 -196 145 47 -196 oritech:still_oil_block[level=0]
fill 136 47 -197 144 47 -197 oritech:still_oil_block[level=0]
fill 136 47 -198 144 47 -198 oritech:still_oil_block[level=0]
fill 136 47 -199 141 47 -199 oritech:still_oil_block[level=0]
fill 136 47 -200 138 47 -200 oritech:still_oil_block[level=0]
setblock 141 47 -200 oritech:still_oil_block[level=0]
setblock 136 47 -214 minecraft:water[level=0]
fill 194 47 -214 198 47 -214 minecraft:water[level=0]
setblock 136 47 -215 minecraft:water[level=0]
fill 190 47 -215 198 47 -215 minecraft:water[level=0]
setblock 136 47 -216 minecraft:water[level=0]
fill 186 47 -216 194 47 -216 minecraft:water[level=0]
setblock 136 47 -217 minecraft:bubble_column[drag=true]
fill 183 47 -217 189 47 -217 minecraft:water[level=0]
setblock 136 47 -218 minecraft:water[level=0]
fill 182 47 -218 186 47 -218 minecraft:water[level=0]
fill 181 47 -219 183 47 -219 minecraft:water[level=0]
setblock 193 47 -223 oritech:still_oil_block[level=0]
setblock 190 47 -224 oritech:still_oil_block[level=0]
setblock 193 47 -224 oritech:still_oil_block[level=0]
fill 187 47 -225 196 47 -225 oritech:still_oil_block[level=0]
fill 187 47 -226 196 47 -226 oritech:still_oil_block[level=0]
setblock 198 47 -226 oritech:still_oil_block[level=0]
fill 187 47 -227 197 47 -227 oritech:still_oil_block[level=0]
setblock 186 47 -228 oritech:still_oil_block[level=0]
fill 188 47 -228 197 47 -228 oritech:still_oil_block[level=0]
fill 187 47 -229 198 47 -229 oritech:still_oil_block[level=0]
fill 185 47 -230 198 47 -230 oritech:still_oil_block[level=0]
fill 186 47 -231 198 47 -231 oritech:still_oil_block[level=0]
fill 187 47 -232 198 47 -232 oritech:still_oil_block[level=0]
fill 186 47 -233 198 47 -233 oritech:still_oil_block[level=0]
fill 188 47 -234 197 47 -234 oritech:still_oil_block[level=0]
fill 189 47 -235 194 47 -235 oritech:still_oil_block[level=0]
setblock 196 47 -235 oritech:still_oil_block[level=0]
fill 190 47 -236 192 47 -236 oritech:still_oil_block[level=0]
fill 150 47 -242 153 47 -242 minecraft:water[level=0]
fill 150 47 -243 152 47 -243 minecraft:water[level=0]
fill 149 47 -244 151 47 -244 minecraft:water[level=0]
fill 148 47 -245 150 47 -245 minecraft:water[level=0]
fill 148 47 -246 150 47 -246 minecraft:water[level=0]
setblock 147 47 -247 minecraft:water[level=0]
fill 136 46 -191 145 46 -191 oritech:still_oil_block[level=0]
fill 181 46 -191 185 46 -191 minecraft:water[level=0]
fill 195 46 -191 199 46 -191 minecraft:air
fill 136 46 -192 146 46 -192 oritech:still_oil_block[level=0]
fill 181 46 -192 185 46 -192 minecraft:water[level=0]
fill 195 46 -192 199 46 -192 minecraft:air
fill 136 46 -193 146 46 -193 oritech:still_oil_block[level=0]
fill 180 46 -193 185 46 -193 minecraft:water[level=0]
fill 136 46 -194 146 46 -194 oritech:still_oil_block[level=0]
fill 136 46 -195 145 46 -195 oritech:still_oil_block[level=0]
fill 136 46 -196 146 46 -196 oritech:still_oil_block[level=0]
fill 136 46 -197 145 46 -197 oritech:still_oil_block[level=0]
fill 136 46 -198 144 46 -198 oritech:still_oil_block[level=0]
fill 136 46 -199 145 46 -199 oritech:still_oil_block[level=0]
fill 136 46 -200 143 46 -200 oritech:still_oil_block[level=0]
fill 136 46 -201 138 46 -201 oritech:still_oil_block[level=0]
setblock 140 46 -201 oritech:still_oil_block[level=0]
setblock 138 46 -202 oritech:still_oil_block[level=0]
setblock 199 46 -213 minecraft:air
fill 193 46 -214 197 46 -214 minecraft:water[level=0]
fill 188 46 -215 197 46 -215 minecraft:water[level=0]
fill 184 46 -216 193 46 -216 minecraft:water[level=0]
fill 183 46 -217 188 46 -217 minecraft:water[level=0]
fill 182 46 -218 185 46 -218 minecraft:water[level=0]
setblock 192 46 -222 oritech:still_oil_block[level=0]
fill 190 46 -223 194 46 -223 oritech:still_oil_block[level=0]
fill 188 46 -224 197 46 -224 oritech:still_oil_block[level=0]
fill 187 46 -225 197 46 -225 oritech:still_oil_block[level=0]
fill 185 46 -226 198 46 -226 oritech:still_oil_block[level=0]
fill 186 46 -227 198 46 -227 oritech:still_oil_block[level=0]
fill 185 46 -228 199 46 -228 oritech:still_oil_block[level=0]
setblock 184 46 -229 oritech:still_oil_block[level=0]
fill 186 46 -229 198 46 -229 oritech:still_oil_block[level=0]
fill 184 46 -230 198 46 -230 oritech:still_oil_block[level=0]
fill 184 46 -231 199 46 -231 oritech:still_oil_block[level=0]
fill 185 46 -232 199 46 -232 oritech:still_oil_block[level=0]
fill 186 46 -233 199 46 -233 oritech:still_oil_block[level=0]
fill 186 46 -234 197 46 -234 oritech:still_oil_block[level=0]
fill 186 46 -235 197 46 -235 oritech:still_oil_block[level=0]
fill 188 46 -236 196 46 -236 oritech:still_oil_block[level=0]
setblock 188 46 -237 oritech:still_oil_block[level=0]
setblock 191 46 -237 oritech:still_oil_block[level=0]
fill 193 46 -237 195 46 -237 oritech:still_oil_block[level=0]
fill 149 46 -243 152 46 -243 minecraft:water[level=0]
fill 149 46 -244 151 46 -244 minecraft:water[level=0]
fill 148 46 -245 150 46 -245 minecraft:water[level=0]
fill 147 46 -246 150 46 -246 minecraft:water[level=0]
fill 147 46 -247 149 46 -247 minecraft:water[level=0]
fill 146 46 -248 147 46 -248 minecraft:water[level=0]
setblock 145 46 -249 minecraft:water[level=0]
fill 136 45 -191 146 45 -191 oritech:still_oil_block[level=0]
fill 183 45 -191 184 45 -191 minecraft:water[level=0]
fill 194 45 -191 199 45 -191 minecraft:air
fill 136 45 -192 147 45 -192 oritech:still_oil_block[level=0]
fill 183 45 -192 187 45 -192 minecraft:water[level=0]
fill 195 45 -192 199 45 -192 minecraft:air
fill 136 45 -193 147 45 -193 oritech:still_oil_block[level=0]
fill 182 45 -193 187 45 -193 minecraft:water[level=0]
fill 136 45 -194 147 45 -194 oritech:still_oil_block[level=0]
fill 136 45 -195 147 45 -195 oritech:still_oil_block[level=0]
fill 136 45 -196 146 45 -196 oritech:still_oil_block[level=0]
fill 136 45 -197 145 45 -197 oritech:still_oil_block[level=0]
fill 136 45 -198 145 45 -198 oritech:still_oil_block[level=0]
fill 136 45 -199 144 45 -199 oritech:still_oil_block[level=0]
fill 136 45 -200 143 45 -200 oritech:still_oil_block[level=0]
fill 136 45 -201 143 45 -201 oritech:still_oil_block[level=0]
fill 139 45 -202 141 45 -202 oritech:still_oil_block[level=0]
fill 198 45 -213 199 45 -213 minecraft:air
fill 192 45 -214 196 45 -214 minecraft:water[level=0]
fill 187 45 -215 197 45 -215 minecraft:water[level=0]
fill 184 45 -216 192 45 -216 minecraft:water[level=0]
fill 183 45 -217 187 45 -217 minecraft:water[level=0]
setblock 137 45 -218 minecraft:air
fill 182 45 -218 183 45 -218 minecraft:water[level=0]
fill 189 45 -222 191 45 -222 oritech:still_oil_block[level=0]
fill 193 45 -222 194 45 -222 oritech:still_oil_block[level=0]
fill 188 45 -223 196 45 -223 oritech:still_oil_block[level=0]
fill 187 45 -224 197 45 -224 oritech:still_oil_block[level=0]
fill 186 45 -225 199 45 -225 oritech:still_oil_block[level=0]
fill 185 45 -226 199 45 -226 oritech:still_oil_block[level=0]
fill 185 45 -227 199 45 -227 oritech:still_oil_block[level=0]
fill 184 45 -228 199 45 -228 oritech:still_oil_block[level=0]
fill 184 45 -229 199 45 -229 oritech:still_oil_block[level=0]
fill 184 45 -230 199 45 -230 oritech:still_oil_block[level=0]
fill 184 45 -231 199 45 -231 oritech:still_oil_block[level=0]
fill 184 45 -232 199 45 -232 oritech:still_oil_block[level=0]
fill 185 45 -233 199 45 -233 oritech:still_oil_block[level=0]
fill 184 45 -234 199 45 -234 oritech:still_oil_block[level=0]
fill 185 45 -235 199 45 -235 oritech:still_oil_block[level=0]
fill 186 45 -236 198 45 -236 oritech:still_oil_block[level=0]
fill 188 45 -237 196 45 -237 oritech:still_oil_block[level=0]
setblock 198 45 -237 oritech:still_oil_block[level=0]
setblock 189 45 -238 oritech:still_oil_block[level=0]
fill 191 45 -238 193 45 -238 oritech:still_oil_block[level=0]
fill 150 45 -244 151 45 -244 minecraft:water[level=0]
fill 147 45 -245 150 45 -245 minecraft:water[level=0]
fill 146 45 -246 149 45 -246 minecraft:water[level=0]
fill 146 45 -247 149 45 -247 minecraft:water[level=0]
fill 145 45 -248 148 45 -248 minecraft:water[level=0]
fill 145 45 -249 147 45 -249 minecraft:water[level=0]
fill 144 45 -250 145 45 -250 minecraft:water[level=0]
forceload remove 136 -254 199 -191
tellraw @a {"text":"Campus zurueck a24 fertig.","color":"green"}
