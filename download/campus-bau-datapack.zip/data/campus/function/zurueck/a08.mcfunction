# Abschnitt a08: x 8..71, z -382..-319 (45889 Blöcke)
forceload add 8 -382 71 -319
tellraw @a {"text":"Campus zurueck a08: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a08_1 2s
