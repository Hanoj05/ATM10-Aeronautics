setblock 324 86 -259 minecraft:white_concrete
setblock 325 86 -260 minecraft:white_concrete
setblock 303 86 -264 minecraft:white_concrete
setblock 319 86 -267 minecraft:white_concrete
setblock 297 86 -269 minecraft:white_concrete
setblock 291 86 -273 minecraft:white_concrete
fill 312 86 -274 313 86 -274 minecraft:white_concrete
setblock 284 86 -276 minecraft:white_concrete
setblock 276 86 -279 minecraft:white_concrete
setblock 305 86 -279 minecraft:white_concrete
setblock 269 86 -280 minecraft:white_concrete
setblock 305 86 -280 minecraft:white_concrete
setblock 297 86 -285 minecraft:white_concrete
fill 288 86 -289 289 86 -289 minecraft:white_concrete
setblock 279 86 -292 minecraft:white_concrete
setblock 270 86 -293 minecraft:white_concrete
setblock 270 86 -294 minecraft:white_concrete
setblock 305 85 -257 minecraft:white_concrete
setblock 302 85 -260 minecraft:white_concrete
setblock 327 85 -262 minecraft:white_concrete
setblock 299 85 -263 minecraft:white_concrete
setblock 326 85 -263 minecraft:white_concrete
fill 325 85 -264 326 85 -264 minecraft:white_concrete
setblock 325 85 -265 minecraft:white_concrete
setblock 295 85 -266 minecraft:white_concrete
setblock 324 85 -266 minecraft:white_concrete
setblock 294 85 -267 minecraft:white_concrete
setblock 323 85 -267 minecraft:white_concrete
setblock 293 85 -268 minecraft:white_concrete
setblock 323 85 -268 minecraft:white_concrete
setblock 292 85 -269 minecraft:white_concrete
fill 289 85 -270 290 85 -270 minecraft:white_concrete
fill 287 85 -271 288 85 -271 minecraft:white_concrete
setblock 319 85 -272 minecraft:white_concrete
fill 282 85 -273 284 85 -273 minecraft:white_concrete
setblock 319 85 -273 minecraft:white_concrete
setblock 279 85 -274 minecraft:white_concrete
setblock 317 85 -274 minecraft:white_concrete
setblock 276 85 -275 minecraft:white_concrete
setblock 317 85 -275 minecraft:white_concrete
setblock 272 85 -276 minecraft:white_concrete
setblock 275 85 -276 minecraft:white_concrete
setblock 315 85 -276 minecraft:white_concrete
setblock 265 85 -277 minecraft:white_concrete
setblock 315 85 -277 minecraft:white_concrete
setblock 312 85 -279 minecraft:white_concrete
setblock 309 85 -281 minecraft:white_concrete
setblock 308 85 -282 minecraft:white_concrete
setblock 307 85 -283 minecraft:white_concrete
setblock 306 85 -284 minecraft:white_concrete
setblock 305 85 -285 minecraft:white_concrete
fill 297 85 -289 298 85 -289 minecraft:white_concrete
setblock 295 85 -290 minecraft:white_concrete
fill 290 85 -292 292 85 -292 minecraft:white_concrete
setblock 287 85 -293 minecraft:white_concrete
setblock 284 85 -294 minecraft:white_concrete
fill 281 85 -295 282 85 -295 minecraft:white_concrete
setblock 277 85 -296 minecraft:white_concrete
setblock 264 85 -297 minecraft:white_concrete
setblock 267 85 -297 minecraft:white_concrete
setblock 269 85 -297 minecraft:white_concrete
setblock 271 85 -297 minecraft:white_concrete
setblock 273 85 -297 minecraft:white_concrete
fill 277 71 -318 278 71 -318 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 277 70 -318 278 70 -318 minecraft:oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 294 67 -259 minecraft:air
setblock 284 66 -266 minecraft:air
setblock 267 66 -271 minecraft:air
setblock 294 66 -299 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 280 66 -303 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 309 66 -308 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 267 66 -311 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 290 66 -314 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 322 66 -315 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 292 65 -300 minecraft:black_concrete
fill 289 65 -301 292 65 -301 minecraft:black_concrete
fill 286 65 -302 292 65 -302 minecraft:black_concrete
fill 282 65 -303 292 65 -303 minecraft:black_concrete
fill 280 65 -304 292 65 -304 minecraft:black_concrete
setblock 267 65 -305 minecraft:black_concrete
setblock 273 65 -305 minecraft:black_concrete
fill 280 65 -305 292 65 -305 minecraft:black_concrete
fill 321 65 -305 325 65 -305 minecraft:black_concrete
fill 264 65 -306 265 65 -306 minecraft:grass_block[snowy=false]
setblock 267 65 -306 minecraft:black_concrete
setblock 273 65 -306 minecraft:black_concrete
setblock 275 65 -306 minecraft:grass_block[snowy=false]
fill 279 65 -306 292 65 -306 minecraft:black_concrete
fill 293 65 -306 320 65 -306 minecraft:grass_block[snowy=false]
fill 321 65 -306 325 65 -306 minecraft:black_concrete
setblock 326 65 -306 minecraft:grass_block[snowy=false]
fill 264 65 -307 265 65 -307 minecraft:grass_block[snowy=false]
setblock 267 65 -307 minecraft:black_concrete
setblock 273 65 -307 minecraft:black_concrete
fill 275 65 -307 277 65 -307 minecraft:grass_block[snowy=false]
fill 278 65 -307 292 65 -307 minecraft:black_concrete
fill 293 65 -307 320 65 -307 minecraft:grass_block[snowy=false]
fill 321 65 -307 325 65 -307 minecraft:black_concrete
setblock 326 65 -307 minecraft:grass_block[snowy=false]
fill 264 65 -308 265 65 -308 minecraft:grass_block[snowy=false]
setblock 267 65 -308 minecraft:black_concrete
setblock 273 65 -308 minecraft:black_concrete
setblock 275 65 -308 minecraft:grass_block[snowy=false]
fill 279 65 -308 292 65 -308 minecraft:black_concrete
fill 293 65 -308 320 65 -308 minecraft:grass_block[snowy=false]
fill 321 65 -308 325 65 -308 minecraft:black_concrete
setblock 326 65 -308 minecraft:grass_block[snowy=false]
setblock 265 65 -309 minecraft:grass_block[snowy=false]
setblock 267 65 -309 minecraft:black_concrete
setblock 273 65 -309 minecraft:black_concrete
fill 280 65 -309 292 65 -309 minecraft:black_concrete
fill 293 65 -309 320 65 -309 minecraft:grass_block[snowy=false]
fill 321 65 -309 325 65 -309 minecraft:black_concrete
setblock 326 65 -309 minecraft:grass_block[snowy=false]
setblock 267 65 -310 minecraft:black_concrete
setblock 273 65 -310 minecraft:black_concrete
fill 280 65 -310 292 65 -310 minecraft:black_concrete
fill 293 65 -310 307 65 -310 minecraft:grass_block[snowy=false]
fill 308 65 -310 325 65 -310 minecraft:black_concrete
setblock 326 65 -310 minecraft:grass_block[snowy=false]
setblock 267 65 -311 minecraft:black_concrete
setblock 273 65 -311 minecraft:black_concrete
fill 280 65 -311 292 65 -311 minecraft:black_concrete
fill 293 65 -311 307 65 -311 minecraft:grass_block[snowy=false]
fill 308 65 -311 325 65 -311 minecraft:black_concrete
setblock 326 65 -311 minecraft:grass_block[snowy=false]
setblock 267 65 -312 minecraft:black_concrete
setblock 273 65 -312 minecraft:black_concrete
setblock 275 65 -312 minecraft:grass_block[snowy=false]
fill 279 65 -312 325 65 -312 minecraft:black_concrete
setblock 326 65 -312 minecraft:grass_block[snowy=false]
setblock 265 65 -313 minecraft:grass_block[snowy=false]
setblock 267 65 -313 minecraft:black_concrete
setblock 273 65 -313 minecraft:black_concrete
fill 275 65 -313 278 65 -313 minecraft:grass_block[snowy=false]
fill 279 65 -313 325 65 -313 minecraft:black_concrete
setblock 326 65 -313 minecraft:grass_block[snowy=false]
fill 264 65 -314 265 65 -314 minecraft:grass_block[snowy=false]
setblock 267 65 -314 minecraft:black_concrete
setblock 273 65 -314 minecraft:black_concrete
fill 275 65 -314 276 65 -314 minecraft:grass_block[snowy=false]
fill 280 65 -314 325 65 -314 minecraft:black_concrete
setblock 326 65 -314 minecraft:grass_block[snowy=false]
fill 281 65 -315 325 65 -315 minecraft:black_concrete
setblock 326 65 -315 minecraft:grass_block[snowy=false]
fill 281 65 -316 327 65 -316 minecraft:black_concrete
fill 281 65 -317 327 65 -317 minecraft:black_concrete
fill 276 65 -318 278 65 -318 minecraft:grass_block[snowy=false]
fill 280 65 -318 327 65 -318 minecraft:black_concrete
setblock 264 64 -255 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
setblock 265 64 -255 minecraft:air
fill 264 64 -256 265 64 -256 minecraft:air
fill 264 64 -257 265 64 -257 minecraft:air
fill 264 64 -258 266 64 -258 minecraft:air
fill 264 64 -259 266 64 -259 minecraft:air
fill 264 64 -260 266 64 -260 minecraft:air
fill 264 64 -261 267 64 -261 minecraft:air
fill 264 64 -262 268 64 -262 minecraft:air
setblock 264 64 -263 regions_unexplored:grass_sprouts
fill 265 64 -263 269 64 -263 minecraft:air
fill 264 64 -264 270 64 -264 minecraft:air
fill 264 64 -265 270 64 -265 minecraft:air
fill 264 64 -266 269 64 -266 minecraft:air
setblock 270 64 -266 regions_unexplored:grass_sprouts
setblock 271 64 -266 minecraft:air
fill 264 64 -267 269 64 -267 minecraft:air
setblock 270 64 -267 minecraft:short_grass
setblock 271 64 -267 minecraft:air
fill 264 64 -268 265 64 -268 minecraft:air
setblock 266 64 -268 minecraft:tall_grass[half=upper]
fill 267 64 -268 270 64 -268 minecraft:air
setblock 271 64 -268 minecraft:short_grass
setblock 272 64 -268 minecraft:air
fill 264 64 -269 272 64 -269 minecraft:air
fill 264 64 -270 271 64 -270 minecraft:air
fill 272 64 -270 273 64 -270 minecraft:short_grass
fill 264 64 -271 271 64 -271 minecraft:air
setblock 272 64 -271 regions_unexplored:grass_sprouts
setblock 273 64 -271 minecraft:air
fill 264 64 -272 274 64 -272 minecraft:air
fill 264 64 -273 273 64 -273 minecraft:air
setblock 274 64 -273 minecraft:short_grass
setblock 275 64 -273 minecraft:air
fill 264 64 -274 276 64 -274 minecraft:air
fill 264 64 -275 277 64 -275 minecraft:air
fill 264 64 -276 273 64 -276 minecraft:air
fill 275 64 -276 276 64 -276 minecraft:air
setblock 277 64 -276 minecraft:short_grass
setblock 304 64 -276 minecraft:air
fill 264 64 -277 277 64 -277 minecraft:air
setblock 304 64 -277 minecraft:air
fill 264 64 -278 278 64 -278 minecraft:air
setblock 304 64 -278 minecraft:air
fill 264 64 -279 278 64 -279 minecraft:air
setblock 304 64 -279 minecraft:air
fill 264 64 -280 279 64 -280 minecraft:air
setblock 304 64 -280 regions_unexplored:orange_coneflower[facing=west,flower_amount=4]
fill 264 64 -281 276 64 -281 minecraft:air
fill 278 64 -281 279 64 -281 minecraft:air
fill 264 64 -282 277 64 -282 minecraft:air
fill 279 64 -282 280 64 -282 minecraft:air
fill 264 64 -283 277 64 -283 minecraft:air
setblock 278 64 -283 minecraft:tall_grass[half=upper]
fill 279 64 -283 280 64 -283 minecraft:air
setblock 306 64 -283 minecraft:air
setblock 308 64 -283 minecraft:air
fill 264 64 -284 278 64 -284 minecraft:air
setblock 279 64 -284 minecraft:tall_grass[half=upper]
fill 280 64 -284 281 64 -284 minecraft:air
setblock 300 64 -284 minecraft:air
setblock 306 64 -284 minecraft:air
setblock 307 64 -284 regions_unexplored:orange_coneflower[facing=south,flower_amount=3]
fill 308 64 -284 309 64 -284 minecraft:air
fill 264 64 -285 281 64 -285 minecraft:air
setblock 300 64 -285 minecraft:air
fill 305 64 -285 308 64 -285 minecraft:air
fill 264 64 -286 281 64 -286 minecraft:air
setblock 300 64 -286 regions_unexplored:orange_coneflower[facing=west,flower_amount=2]
setblock 306 64 -286 minecraft:air
setblock 308 64 -286 minecraft:air
fill 264 64 -287 279 64 -287 minecraft:air
setblock 280 64 -287 minecraft:tall_grass[half=upper]
setblock 281 64 -287 minecraft:short_grass
setblock 300 64 -287 minecraft:short_grass
fill 301 64 -287 302 64 -287 minecraft:air
fill 264 64 -288 280 64 -288 minecraft:air
setblock 281 64 -288 minecraft:short_grass
setblock 282 64 -288 minecraft:air
fill 300 64 -288 306 64 -288 minecraft:air
fill 264 64 -289 270 64 -289 minecraft:air
fill 272 64 -289 278 64 -289 minecraft:air
setblock 280 64 -289 minecraft:air
setblock 281 64 -289 regions_unexplored:grass_sprouts
fill 301 64 -289 303 64 -289 minecraft:air
setblock 304 64 -289 regions_unexplored:grass_sprouts
setblock 305 64 -289 minecraft:air
fill 264 64 -290 271 64 -290 minecraft:air
fill 273 64 -290 281 64 -290 minecraft:air
setblock 299 64 -290 minecraft:air
setblock 300 64 -290 regions_unexplored:orange_coneflower[facing=north,flower_amount=2]
setblock 301 64 -290 minecraft:air
setblock 302 64 -290 regions_unexplored:orange_coneflower[facing=west,flower_amount=3]
fill 303 64 -290 304 64 -290 minecraft:air
fill 264 64 -291 265 64 -291 regions_unexplored:grass_sprouts
fill 266 64 -291 280 64 -291 minecraft:air
setblock 281 64 -291 regions_unexplored:grass_sprouts
fill 292 64 -291 293 64 -291 minecraft:air
fill 298 64 -291 299 64 -291 minecraft:air
setblock 300 64 -291 regions_unexplored:orange_coneflower[facing=west,flower_amount=2]
setblock 301 64 -291 regions_unexplored:orange_coneflower[facing=east,flower_amount=3]
setblock 302 64 -291 minecraft:air
setblock 303 64 -291 regions_unexplored:orange_coneflower[facing=east,flower_amount=1]
setblock 304 64 -291 minecraft:air
setblock 264 64 -292 minecraft:air
setblock 265 64 -292 minecraft:short_grass
setblock 266 64 -292 regions_unexplored:grass_sprouts
fill 267 64 -292 281 64 -292 minecraft:air
fill 291 64 -292 298 64 -292 minecraft:air
setblock 299 64 -292 regions_unexplored:orange_coneflower[facing=west,flower_amount=3]
setblock 300 64 -292 regions_unexplored:orange_coneflower[facing=south,flower_amount=2]
fill 301 64 -292 302 64 -292 minecraft:short_grass
setblock 303 64 -292 minecraft:air
fill 264 64 -293 266 64 -293 minecraft:air
setblock 267 64 -293 minecraft:short_grass
fill 268 64 -293 280 64 -293 minecraft:air
setblock 281 64 -293 regions_unexplored:grass_sprouts
fill 291 64 -293 295 64 -293 minecraft:air
setblock 299 64 -293 minecraft:short_grass
fill 300 64 -293 302 64 -293 minecraft:air
fill 264 64 -294 265 64 -294 regions_unexplored:grass_sprouts
setblock 266 64 -294 minecraft:short_grass
setblock 267 64 -294 minecraft:air
setblock 268 64 -294 minecraft:short_grass
fill 269 64 -294 281 64 -294 minecraft:air
fill 291 64 -294 294 64 -294 minecraft:air
setblock 264 64 -295 minecraft:air
fill 265 64 -295 266 64 -295 regions_unexplored:grass_sprouts
setblock 267 64 -295 minecraft:air
setblock 268 64 -295 regions_unexplored:grass_sprouts
fill 269 64 -295 280 64 -295 minecraft:air
setblock 281 64 -295 regions_unexplored:grass_sprouts
setblock 292 64 -295 minecraft:short_grass
setblock 293 64 -295 minecraft:air
setblock 264 64 -296 minecraft:air
setblock 265 64 -296 minecraft:short_grass
fill 266 64 -296 267 64 -296 minecraft:air
setblock 268 64 -296 regions_unexplored:grass_sprouts
setblock 269 64 -296 minecraft:short_grass
fill 270 64 -296 281 64 -296 minecraft:air
setblock 292 64 -296 minecraft:air
setblock 264 64 -297 minecraft:air
setblock 265 64 -297 minecraft:short_grass
fill 266 64 -297 282 64 -297 minecraft:air
setblock 264 64 -298 regions_unexplored:grass_sprouts
fill 265 64 -298 267 64 -298 minecraft:air
setblock 268 64 -298 minecraft:short_grass
fill 269 64 -298 283 64 -298 minecraft:air
setblock 264 64 -299 minecraft:air
fill 265 64 -299 266 64 -299 regions_unexplored:grass_sprouts
setblock 267 64 -299 minecraft:air
setblock 268 64 -299 minecraft:short_grass
fill 269 64 -299 286 64 -299 minecraft:air
setblock 287 64 -299 regions_unexplored:grass_sprouts
setblock 288 64 -299 minecraft:air
fill 264 64 -300 266 64 -300 minecraft:air
setblock 267 64 -300 regions_unexplored:grass_sprouts
fill 269 64 -300 270 64 -300 minecraft:air
setblock 271 64 -300 minecraft:short_grass
fill 272 64 -300 288 64 -300 minecraft:air
setblock 264 64 -301 minecraft:air
setblock 265 64 -301 minecraft:short_grass
fill 266 64 -301 268 64 -301 minecraft:air
fill 269 64 -301 270 64 -301 minecraft:short_grass
setblock 271 64 -301 minecraft:air
setblock 272 64 -301 regions_unexplored:grass_sprouts
fill 273 64 -301 284 64 -301 minecraft:air
setblock 285 64 -301 minecraft:tall_grass[half=upper]
fill 286 64 -301 288 64 -301 minecraft:air
setblock 289 64 -301 minecraft:short_grass
setblock 304 64 -301 minecraft:air
setblock 264 64 -302 minecraft:air
setblock 265 64 -302 minecraft:short_grass
fill 266 64 -302 290 64 -302 minecraft:air
fill 304 64 -302 305 64 -302 minecraft:air
setblock 312 64 -302 minecraft:air
setblock 264 64 -303 minecraft:short_grass
setblock 265 64 -303 regions_unexplored:grass_sprouts
setblock 266 64 -303 minecraft:air
setblock 267 64 -303 regions_unexplored:grass_sprouts
fill 268 64 -303 289 64 -303 minecraft:air
setblock 290 64 -303 regions_unexplored:grass_sprouts
fill 291 64 -303 292 64 -303 minecraft:air
setblock 293 64 -303 regions_unexplored:grass_sprouts
fill 294 64 -303 297 64 -303 minecraft:air
fill 303 64 -303 304 64 -303 minecraft:air
setblock 305 64 -303 minecraft:short_grass
setblock 306 64 -303 regions_unexplored:grass_sprouts
setblock 307 64 -303 minecraft:short_grass
setblock 308 64 -303 minecraft:air
fill 311 64 -303 316 64 -303 minecraft:air
fill 265 64 -304 302 64 -304 minecraft:air
setblock 303 64 -304 minecraft:short_grass
setblock 304 64 -304 regions_unexplored:grass_sprouts
setblock 305 64 -304 minecraft:air
setblock 306 64 -304 regions_unexplored:grass_sprouts
fill 307 64 -304 316 64 -304 minecraft:air
setblock 266 64 -305 regions_unexplored:grass_sprouts
setblock 267 64 -305 minecraft:air
setblock 268 64 -305 regions_unexplored:grass_sprouts
setblock 269 64 -305 minecraft:short_grass
fill 270 64 -305 299 64 -305 minecraft:air
setblock 300 64 -305 minecraft:short_grass
fill 301 64 -305 302 64 -305 minecraft:air
setblock 303 64 -305 regions_unexplored:grass_sprouts
fill 304 64 -305 316 64 -305 minecraft:air
setblock 267 64 -306 minecraft:short_grass
setblock 268 64 -306 regions_unexplored:grass_sprouts
setblock 269 64 -306 minecraft:short_grass
fill 270 64 -306 316 64 -306 minecraft:air
fill 268 64 -307 316 64 -307 minecraft:air
fill 273 64 -308 315 64 -308 minecraft:air
setblock 316 64 -308 minecraft:short_grass
fill 274 64 -309 308 64 -309 minecraft:air
setblock 309 64 -309 minecraft:tall_grass[half=upper]
fill 310 64 -309 314 64 -309 minecraft:air
fill 276 64 -310 313 64 -310 minecraft:air
fill 278 64 -311 313 64 -311 minecraft:air
fill 280 64 -312 312 64 -312 minecraft:air
setblock 313 64 -312 regions_unexplored:grass_sprouts
fill 281 64 -313 287 64 -313 minecraft:air
fill 289 64 -313 310 64 -313 minecraft:air
setblock 311 64 -313 regions_unexplored:grass_sprouts
fill 312 64 -313 313 64 -313 minecraft:air
fill 283 64 -314 308 64 -314 minecraft:air
fill 310 64 -314 312 64 -314 minecraft:air
setblock 313 64 -314 regions_unexplored:grass_sprouts
fill 284 64 -315 313 64 -315 minecraft:air
fill 285 64 -316 313 64 -316 minecraft:air
fill 286 64 -317 311 64 -317 minecraft:air
setblock 312 64 -317 regions_unexplored:grass_sprouts
fill 288 64 -318 308 64 -318 minecraft:air
setblock 310 64 -318 minecraft:air
fill 264 63 -265 265 63 -265 minecraft:air
setblock 266 63 -265 regions_unexplored:grass_sprouts
fill 264 63 -266 268 63 -266 minecraft:air
fill 264 63 -267 267 63 -267 minecraft:air
setblock 268 63 -267 regions_unexplored:grass_sprouts
setblock 269 63 -267 minecraft:air
setblock 264 63 -268 regions_unexplored:grass_sprouts
setblock 265 63 -268 minecraft:short_grass
setblock 266 63 -268 minecraft:tall_grass[half=lower]
fill 267 63 -268 269 63 -268 minecraft:air
fill 264 63 -269 268 63 -269 minecraft:air
setblock 269 63 -269 minecraft:short_grass
setblock 270 63 -269 minecraft:air
fill 264 63 -270 270 63 -270 minecraft:air
fill 264 63 -271 268 63 -271 minecraft:air
setblock 269 63 -271 regions_unexplored:grass_sprouts
setblock 270 63 -271 minecraft:air
setblock 271 63 -271 regions_unexplored:grass_sprouts
fill 264 63 -272 269 63 -272 minecraft:air
setblock 270 63 -272 regions_unexplored:grass_sprouts
setblock 271 63 -272 minecraft:air
fill 264 63 -273 270 63 -273 minecraft:air
fill 271 63 -273 272 63 -273 minecraft:short_grass
fill 264 63 -274 273 63 -274 minecraft:air
fill 264 63 -275 269 63 -275 minecraft:air
fill 271 63 -275 275 63 -275 minecraft:air
fill 264 63 -276 273 63 -276 minecraft:air
fill 275 63 -276 276 63 -276 minecraft:air
fill 264 63 -277 273 63 -277 minecraft:air
fill 275 63 -277 276 63 -277 minecraft:air
fill 264 63 -278 276 63 -278 minecraft:air
fill 264 63 -279 277 63 -279 minecraft:air
fill 264 63 -280 277 63 -280 minecraft:air
fill 264 63 -281 276 63 -281 minecraft:air
setblock 278 63 -281 minecraft:air
fill 264 63 -282 277 63 -282 minecraft:air
fill 264 63 -283 277 63 -283 minecraft:air
setblock 278 63 -283 minecraft:tall_grass[half=lower]
setblock 279 63 -283 regions_unexplored:grass_sprouts
fill 305 63 -283 306 63 -283 minecraft:air
fill 264 63 -284 278 63 -284 minecraft:air
setblock 279 63 -284 minecraft:tall_grass[half=lower]
fill 305 63 -284 306 63 -284 minecraft:air
fill 264 63 -285 274 63 -285 minecraft:air
fill 276 63 -285 279 63 -285 minecraft:air
fill 305 63 -285 306 63 -285 minecraft:air
fill 264 63 -286 271 63 -286 minecraft:air
fill 273 63 -286 278 63 -286 minecraft:air
setblock 279 63 -286 regions_unexplored:grass_sprouts
setblock 280 63 -286 minecraft:air
fill 305 63 -286 306 63 -286 minecraft:air
fill 265 63 -287 270 63 -287 minecraft:air
fill 272 63 -287 275 63 -287 minecraft:air
fill 277 63 -287 278 63 -287 minecraft:air
setblock 279 63 -287 minecraft:short_grass
setblock 280 63 -287 minecraft:tall_grass[half=lower]
setblock 306 63 -287 minecraft:air
setblock 265 63 -288 regions_unexplored:grass_sprouts
fill 266 63 -288 267 63 -288 minecraft:air
fill 269 63 -288 280 63 -288 minecraft:air
fill 265 63 -289 270 63 -289 minecraft:air
fill 272 63 -289 278 63 -289 minecraft:air
setblock 280 63 -289 minecraft:air
fill 266 63 -290 271 63 -290 minecraft:air
fill 273 63 -290 274 63 -290 minecraft:air
setblock 276 63 -290 minecraft:air
fill 278 63 -290 280 63 -290 minecraft:air
setblock 266 63 -291 minecraft:air
setblock 267 63 -291 minecraft:short_grass
fill 268 63 -291 276 63 -291 minecraft:air
fill 278 63 -291 280 63 -291 minecraft:air
fill 267 63 -292 273 63 -292 minecraft:air
fill 276 63 -292 279 63 -292 minecraft:air
fill 268 63 -293 273 63 -293 minecraft:air
fill 275 63 -293 280 63 -293 minecraft:air
fill 269 63 -294 273 63 -294 minecraft:air
fill 275 63 -294 280 63 -294 minecraft:air
fill 270 63 -295 271 63 -295 regions_unexplored:grass_sprouts
fill 272 63 -295 273 63 -295 minecraft:air
fill 275 63 -295 277 63 -295 minecraft:air
setblock 278 63 -295 regions_unexplored:grass_sprouts
fill 279 63 -295 280 63 -295 minecraft:air
setblock 271 63 -296 minecraft:short_grass
fill 272 63 -296 273 63 -296 minecraft:air
fill 275 63 -296 276 63 -296 minecraft:air
fill 278 63 -296 280 63 -296 minecraft:air
fill 272 63 -297 274 63 -297 minecraft:air
setblock 276 63 -297 minecraft:air
setblock 278 63 -297 minecraft:air
fill 280 63 -297 281 63 -297 minecraft:air
fill 272 63 -298 277 63 -298 minecraft:air
fill 279 63 -298 282 63 -298 minecraft:air
fill 273 63 -299 283 63 -299 minecraft:air
fill 273 63 -300 282 63 -300 minecraft:air
fill 284 63 -300 286 63 -300 minecraft:air
fill 273 63 -301 284 63 -301 minecraft:air
setblock 285 63 -301 minecraft:tall_grass[half=lower]
fill 286 63 -301 287 63 -301 minecraft:air
fill 272 63 -302 282 63 -302 minecraft:air
fill 285 63 -302 287 63 -302 minecraft:air
fill 312 63 -302 313 63 -302 minecraft:air
fill 271 63 -303 283 63 -303 minecraft:air
fill 285 63 -303 288 63 -303 minecraft:air
fill 310 63 -303 314 63 -303 minecraft:air
setblock 271 63 -304 regions_unexplored:grass_sprouts
fill 272 63 -304 289 63 -304 minecraft:air
setblock 290 63 -304 minecraft:short_grass
fill 309 63 -304 314 63 -304 minecraft:air
fill 273 63 -305 288 63 -305 minecraft:air
setblock 289 63 -305 regions_unexplored:grass_sprouts
fill 290 63 -305 296 63 -305 minecraft:air
fill 308 63 -305 315 63 -305 minecraft:air
fill 274 63 -306 290 63 -306 minecraft:air
setblock 292 63 -306 minecraft:air
setblock 293 63 -306 minecraft:short_grass
fill 294 63 -306 298 63 -306 minecraft:air
setblock 299 63 -306 minecraft:short_grass
setblock 300 63 -306 minecraft:air
fill 308 63 -306 312 63 -306 minecraft:air
fill 276 63 -307 299 63 -307 minecraft:air
setblock 300 63 -307 minecraft:short_grass
setblock 301 63 -307 regions_unexplored:grass_sprouts
fill 302 63 -307 305 63 -307 minecraft:air
fill 308 63 -307 309 63 -307 regions_unexplored:grass_sprouts
fill 279 63 -308 302 63 -308 minecraft:air
setblock 303 63 -308 regions_unexplored:grass_sprouts
fill 304 63 -308 306 63 -308 minecraft:air
setblock 307 63 -308 minecraft:short_grass
setblock 308 63 -308 minecraft:air
fill 281 63 -309 308 63 -309 minecraft:air
setblock 309 63 -309 minecraft:tall_grass[half=lower]
fill 282 63 -310 308 63 -310 minecraft:air
setblock 309 63 -310 minecraft:short_grass
fill 283 63 -311 305 63 -311 minecraft:air
fill 307 63 -311 310 63 -311 minecraft:air
fill 284 63 -312 310 63 -312 minecraft:air
fill 285 63 -313 287 63 -313 minecraft:air
fill 289 63 -313 304 63 -313 minecraft:air
fill 306 63 -313 310 63 -313 minecraft:air
fill 287 63 -314 306 63 -314 minecraft:air
setblock 308 63 -314 minecraft:air
setblock 310 63 -314 minecraft:air
setblock 311 63 -314 regions_unexplored:grass_sprouts
fill 288 63 -315 305 63 -315 minecraft:air
fill 307 63 -315 311 63 -315 minecraft:air
fill 289 63 -316 303 63 -316 minecraft:air
setblock 306 63 -316 minecraft:air
fill 309 63 -316 312 63 -316 minecraft:air
fill 290 63 -317 307 63 -317 minecraft:air
setblock 309 63 -317 regions_unexplored:grass_sprouts
setblock 310 63 -317 minecraft:air
fill 291 63 -318 292 63 -318 minecraft:air
fill 294 63 -318 306 63 -318 minecraft:air
setblock 308 63 -318 minecraft:air
fill 264 62 -269 265 62 -269 minecraft:seagrass
setblock 266 62 -269 minecraft:water[level=0]
setblock 267 62 -269 minecraft:seagrass
setblock 268 62 -269 minecraft:water[level=0]
setblock 264 62 -270 minecraft:seagrass
setblock 265 62 -270 minecraft:water[level=0]
fill 266 62 -270 267 62 -270 minecraft:seagrass
setblock 268 62 -270 minecraft:water[level=0]
fill 264 62 -271 268 62 -271 minecraft:water[level=0]
fill 264 62 -272 267 62 -272 minecraft:water[level=0]
fill 268 62 -272 269 62 -272 minecraft:seagrass
fill 264 62 -273 270 62 -273 minecraft:water[level=0]
setblock 264 62 -274 minecraft:water[level=0]
setblock 265 62 -274 minecraft:tall_seagrass[half=upper]
fill 266 62 -274 270 62 -274 minecraft:water[level=0]
setblock 271 62 -274 minecraft:seagrass
fill 264 62 -275 269 62 -275 minecraft:water[level=0]
fill 271 62 -275 272 62 -275 minecraft:water[level=0]
fill 264 62 -276 273 62 -276 minecraft:water[level=0]
fill 264 62 -277 270 62 -277 minecraft:water[level=0]
setblock 271 62 -277 minecraft:tall_seagrass[half=upper]
fill 272 62 -277 273 62 -277 minecraft:water[level=0]
fill 264 62 -278 273 62 -278 minecraft:water[level=0]
setblock 274 62 -278 minecraft:seagrass
fill 264 62 -279 275 62 -279 minecraft:water[level=0]
setblock 264 62 -280 minecraft:seagrass
fill 265 62 -280 276 62 -280 minecraft:water[level=0]
fill 264 62 -281 266 62 -281 minecraft:water[level=0]
setblock 267 62 -281 minecraft:tall_seagrass[half=upper]
fill 268 62 -281 276 62 -281 minecraft:water[level=0]
setblock 265 62 -282 minecraft:water[level=0]
setblock 266 62 -282 minecraft:seagrass
setblock 267 62 -282 minecraft:water[level=0]
setblock 268 62 -282 minecraft:tall_seagrass[half=upper]
fill 269 62 -282 276 62 -282 minecraft:water[level=0]
fill 266 62 -283 269 62 -283 minecraft:water[level=0]
setblock 270 62 -283 minecraft:seagrass
fill 271 62 -283 277 62 -283 minecraft:water[level=0]
setblock 305 62 -283 minecraft:water[level=0]
fill 269 62 -284 278 62 -284 minecraft:water[level=0]
fill 305 62 -284 306 62 -284 minecraft:water[level=0]
fill 269 62 -285 274 62 -285 minecraft:water[level=0]
fill 276 62 -285 278 62 -285 minecraft:water[level=0]
fill 305 62 -285 306 62 -285 minecraft:water[level=0]
fill 269 62 -286 271 62 -286 minecraft:water[level=0]
fill 273 62 -286 278 62 -286 minecraft:water[level=0]
fill 305 62 -286 306 62 -286 minecraft:water[level=0]
fill 268 62 -287 270 62 -287 minecraft:water[level=0]
fill 272 62 -287 275 62 -287 minecraft:water[level=0]
fill 277 62 -287 278 62 -287 minecraft:water[level=0]
fill 305 62 -287 306 62 -287 minecraft:water[level=0]
fill 272 62 -288 278 62 -288 minecraft:water[level=0]
setblock 306 62 -288 minecraft:water[level=0]
fill 272 62 -289 278 62 -289 minecraft:water[level=0]
fill 273 62 -290 274 62 -290 minecraft:water[level=0]
setblock 276 62 -290 minecraft:water[level=0]
setblock 278 62 -290 minecraft:water[level=0]
fill 273 62 -291 276 62 -291 minecraft:water[level=0]
fill 272 62 -292 273 62 -292 minecraft:water[level=0]
fill 276 62 -292 277 62 -292 minecraft:water[level=0]
setblock 273 62 -293 minecraft:water[level=0]
fill 275 62 -293 277 62 -293 minecraft:water[level=0]
fill 275 62 -294 277 62 -294 minecraft:water[level=0]
fill 275 62 -295 277 62 -295 minecraft:water[level=0]
fill 275 62 -296 276 62 -296 minecraft:water[level=0]
setblock 274 62 -297 minecraft:water[level=0]
setblock 276 62 -297 minecraft:water[level=0]
setblock 278 62 -297 minecraft:water[level=0]
fill 274 62 -298 277 62 -298 minecraft:water[level=0]
fill 279 62 -298 280 62 -298 minecraft:water[level=0]
fill 274 62 -299 279 62 -299 minecraft:water[level=0]
setblock 280 62 -299 minecraft:tall_seagrass[half=upper]
setblock 281 62 -299 minecraft:water[level=0]
fill 274 62 -300 277 62 -300 minecraft:water[level=0]
setblock 278 62 -300 minecraft:tall_seagrass[half=upper]
fill 279 62 -300 281 62 -300 minecraft:water[level=0]
setblock 282 62 -300 minecraft:seagrass
fill 274 62 -301 277 62 -301 minecraft:water[level=0]
fill 278 62 -301 279 62 -301 minecraft:tall_seagrass[half=upper]
setblock 280 62 -301 minecraft:water[level=0]
setblock 281 62 -301 minecraft:tall_seagrass[half=upper]
setblock 282 62 -301 minecraft:water[level=0]
setblock 283 62 -301 minecraft:seagrass
setblock 284 62 -301 minecraft:water[level=0]
fill 312 62 -301 313 62 -301 minecraft:water[level=0]
fill 274 62 -302 277 62 -302 minecraft:water[level=0]
fill 278 62 -302 279 62 -302 minecraft:tall_seagrass[half=upper]
fill 280 62 -302 282 62 -302 minecraft:water[level=0]
setblock 285 62 -302 minecraft:water[level=0]
fill 311 62 -302 313 62 -302 minecraft:water[level=0]
fill 274 62 -303 278 62 -303 minecraft:water[level=0]
setblock 279 62 -303 minecraft:tall_seagrass[half=upper]
fill 280 62 -303 283 62 -303 minecraft:water[level=0]
setblock 285 62 -303 minecraft:seagrass
setblock 286 62 -303 minecraft:water[level=0]
fill 310 62 -303 314 62 -303 minecraft:water[level=0]
fill 275 62 -304 280 62 -304 minecraft:water[level=0]
fill 281 62 -304 282 62 -304 minecraft:tall_seagrass[half=upper]
fill 283 62 -304 284 62 -304 minecraft:water[level=0]
setblock 285 62 -304 minecraft:seagrass
setblock 286 62 -304 minecraft:water[level=0]
fill 294 62 -304 297 62 -304 minecraft:water[level=0]
fill 309 62 -304 315 62 -304 minecraft:water[level=0]
fill 276 62 -305 281 62 -305 minecraft:water[level=0]
setblock 282 62 -305 minecraft:tall_seagrass[half=upper]
fill 283 62 -305 288 62 -305 minecraft:water[level=0]
fill 294 62 -305 297 62 -305 minecraft:water[level=0]
fill 309 62 -305 315 62 -305 minecraft:water[level=0]
fill 278 62 -306 287 62 -306 minecraft:water[level=0]
setblock 288 62 -306 minecraft:seagrass
fill 289 62 -306 290 62 -306 minecraft:water[level=0]
setblock 292 62 -306 minecraft:water[level=0]
fill 294 62 -306 298 62 -306 minecraft:water[level=0]
fill 309 62 -306 312 62 -306 minecraft:water[level=0]
setblock 281 62 -307 minecraft:seagrass
fill 282 62 -307 285 62 -307 minecraft:water[level=0]
setblock 286 62 -307 minecraft:tall_seagrass[half=upper]
fill 287 62 -307 298 62 -307 minecraft:water[level=0]
fill 283 62 -308 301 62 -308 minecraft:water[level=0]
setblock 284 62 -309 minecraft:seagrass
fill 285 62 -309 287 62 -309 minecraft:water[level=0]
setblock 288 62 -309 minecraft:tall_seagrass[half=upper]
setblock 289 62 -309 minecraft:water[level=0]
setblock 290 62 -309 minecraft:tall_seagrass[half=upper]
fill 291 62 -309 300 62 -309 minecraft:water[level=0]
setblock 301 62 -309 minecraft:seagrass
setblock 302 62 -309 minecraft:water[level=0]
setblock 303 62 -309 minecraft:seagrass
fill 285 62 -310 303 62 -310 minecraft:water[level=0]
setblock 304 62 -310 minecraft:seagrass
setblock 305 62 -310 minecraft:water[level=0]
setblock 286 62 -311 minecraft:water[level=0]
fill 287 62 -311 288 62 -311 minecraft:seagrass
fill 289 62 -311 302 62 -311 minecraft:water[level=0]
setblock 303 62 -311 minecraft:seagrass
fill 304 62 -311 305 62 -311 minecraft:water[level=0]
setblock 288 62 -312 minecraft:water[level=0]
setblock 289 62 -312 minecraft:seagrass
fill 290 62 -312 301 62 -312 minecraft:water[level=0]
fill 302 62 -312 303 62 -312 minecraft:tall_seagrass[half=upper]
fill 304 62 -312 305 62 -312 minecraft:seagrass
setblock 306 62 -312 minecraft:water[level=0]
setblock 307 62 -312 minecraft:seagrass
fill 289 62 -313 303 62 -313 minecraft:water[level=0]
setblock 304 62 -313 minecraft:seagrass
setblock 306 62 -313 minecraft:seagrass
setblock 307 62 -313 minecraft:water[level=0]
fill 289 62 -314 306 62 -314 minecraft:water[level=0]
setblock 308 62 -314 minecraft:water[level=0]
fill 288 62 -315 305 62 -315 minecraft:water[level=0]
fill 307 62 -315 308 62 -315 minecraft:water[level=0]
fill 287 62 -316 303 62 -316 minecraft:water[level=0]
setblock 306 62 -316 minecraft:seagrass
fill 288 62 -317 307 62 -317 minecraft:water[level=0]
fill 294 62 -318 306 62 -318 minecraft:water[level=0]
setblock 308 62 -318 minecraft:water[level=0]
setblock 264 61 -271 minecraft:water[level=0]
setblock 264 61 -272 minecraft:water[level=0]
setblock 265 61 -272 minecraft:seagrass
setblock 266 61 -272 minecraft:water[level=0]
fill 264 61 -273 268 61 -273 minecraft:water[level=0]
setblock 264 61 -274 minecraft:water[level=0]
setblock 265 61 -274 minecraft:tall_seagrass[half=lower]
fill 266 61 -274 268 61 -274 minecraft:water[level=0]
fill 264 61 -275 269 61 -275 minecraft:water[level=0]
fill 264 61 -276 271 61 -276 minecraft:water[level=0]
fill 264 61 -277 270 61 -277 minecraft:water[level=0]
setblock 271 61 -277 minecraft:tall_seagrass[half=lower]
fill 264 61 -278 271 61 -278 minecraft:water[level=0]
fill 265 61 -279 272 61 -279 minecraft:water[level=0]
fill 266 61 -280 272 61 -280 minecraft:water[level=0]
setblock 267 61 -281 minecraft:tall_seagrass[half=lower]
fill 268 61 -281 272 61 -281 minecraft:water[level=0]
setblock 268 61 -282 minecraft:tall_seagrass[half=lower]
setblock 305 61 -283 minecraft:water[level=0]
fill 275 61 -284 276 61 -284 minecraft:water[level=0]
fill 304 61 -284 305 61 -284 minecraft:water[level=0]
setblock 276 61 -285 minecraft:water[level=0]
fill 304 61 -285 306 61 -285 minecraft:water[level=0]
setblock 276 61 -286 minecraft:water[level=0]
fill 304 61 -286 306 61 -286 minecraft:water[level=0]
fill 272 61 -287 274 61 -287 minecraft:water[level=0]
setblock 292 61 -287 minecraft:water[level=0]
fill 305 61 -287 306 61 -287 minecraft:water[level=0]
fill 272 61 -288 274 61 -288 minecraft:water[level=0]
fill 291 61 -288 293 61 -288 minecraft:water[level=0]
setblock 306 61 -288 minecraft:water[level=0]
fill 272 61 -289 274 61 -289 minecraft:water[level=0]
fill 291 61 -289 293 61 -289 minecraft:water[level=0]
setblock 276 61 -297 minecraft:water[level=0]
fill 276 61 -298 277 61 -298 minecraft:water[level=0]
fill 276 61 -299 278 61 -299 minecraft:water[level=0]
setblock 279 61 -299 minecraft:seagrass
setblock 280 61 -299 minecraft:tall_seagrass[half=lower]
fill 276 61 -300 277 61 -300 minecraft:water[level=0]
setblock 278 61 -300 minecraft:tall_seagrass[half=lower]
fill 279 61 -300 281 61 -300 minecraft:water[level=0]
setblock 295 61 -300 minecraft:water[level=0]
setblock 296 61 -300 minecraft:bubble_column[drag=true]
fill 276 61 -301 277 61 -301 minecraft:water[level=0]
fill 278 61 -301 279 61 -301 minecraft:tall_seagrass[half=lower]
setblock 280 61 -301 minecraft:water[level=0]
setblock 281 61 -301 minecraft:tall_seagrass[half=lower]
setblock 295 61 -301 minecraft:bubble_column[drag=true]
fill 296 61 -301 297 61 -301 minecraft:water[level=0]
fill 312 61 -301 313 61 -301 minecraft:water[level=0]
fill 276 61 -302 277 61 -302 minecraft:water[level=0]
fill 278 61 -302 279 61 -302 minecraft:tall_seagrass[half=lower]
setblock 280 61 -302 minecraft:seagrass
setblock 281 61 -302 minecraft:water[level=0]
setblock 282 61 -302 minecraft:seagrass
fill 294 61 -302 297 61 -302 minecraft:water[level=0]
fill 311 61 -302 314 61 -302 minecraft:water[level=0]
fill 277 61 -303 278 61 -303 minecraft:water[level=0]
setblock 279 61 -303 minecraft:tall_seagrass[half=lower]
fill 280 61 -303 283 61 -303 minecraft:water[level=0]
fill 295 61 -303 297 61 -303 minecraft:water[level=0]
fill 310 61 -303 314 61 -303 minecraft:water[level=0]
fill 278 61 -304 280 61 -304 minecraft:water[level=0]
fill 281 61 -304 282 61 -304 minecraft:tall_seagrass[half=lower]
setblock 283 61 -304 minecraft:seagrass
setblock 284 61 -304 minecraft:water[level=0]
fill 294 61 -304 297 61 -304 minecraft:water[level=0]
fill 310 61 -304 315 61 -304 minecraft:water[level=0]
fill 280 61 -305 281 61 -305 minecraft:water[level=0]
setblock 282 61 -305 minecraft:tall_seagrass[half=lower]
fill 283 61 -305 284 61 -305 minecraft:water[level=0]
fill 293 61 -305 298 61 -305 minecraft:water[level=0]
fill 310 61 -305 315 61 -305 minecraft:water[level=0]
setblock 284 61 -306 minecraft:water[level=0]
fill 293 61 -306 298 61 -306 minecraft:water[level=0]
fill 310 61 -306 312 61 -306 minecraft:water[level=0]
setblock 285 61 -307 minecraft:water[level=0]
setblock 286 61 -307 minecraft:tall_seagrass[half=lower]
fill 287 61 -307 290 61 -307 minecraft:water[level=0]
fill 293 61 -307 298 61 -307 minecraft:water[level=0]
setblock 285 61 -308 minecraft:seagrass
setblock 286 61 -308 minecraft:water[level=0]
setblock 287 61 -308 minecraft:seagrass
fill 288 61 -308 297 61 -308 minecraft:water[level=0]
setblock 298 61 -308 minecraft:seagrass
setblock 286 61 -309 minecraft:seagrass
setblock 287 61 -309 minecraft:water[level=0]
setblock 288 61 -309 minecraft:tall_seagrass[half=lower]
setblock 289 61 -309 minecraft:water[level=0]
setblock 290 61 -309 minecraft:tall_seagrass[half=lower]
fill 291 61 -309 297 61 -309 minecraft:water[level=0]
setblock 288 61 -310 minecraft:seagrass
setblock 289 61 -310 minecraft:water[level=0]
setblock 290 61 -310 minecraft:seagrass
fill 291 61 -310 298 61 -310 minecraft:water[level=0]
setblock 299 61 -310 minecraft:seagrass
setblock 289 61 -311 minecraft:water[level=0]
setblock 290 61 -311 minecraft:seagrass
fill 291 61 -311 292 61 -311 minecraft:tall_seagrass[half=upper]
fill 293 61 -311 300 61 -311 minecraft:water[level=0]
setblock 301 61 -311 minecraft:seagrass
setblock 290 61 -312 minecraft:seagrass
fill 291 61 -312 299 61 -312 minecraft:water[level=0]
setblock 300 61 -312 minecraft:seagrass
setblock 301 61 -312 minecraft:water[level=0]
fill 302 61 -312 303 61 -312 minecraft:tall_seagrass[half=lower]
fill 289 61 -313 303 61 -313 minecraft:water[level=0]
fill 287 61 -314 303 61 -314 minecraft:water[level=0]
fill 286 61 -315 303 61 -315 minecraft:water[level=0]
fill 285 61 -316 303 61 -316 minecraft:water[level=0]
fill 284 61 -317 304 61 -317 minecraft:water[level=0]
fill 285 61 -318 291 61 -318 minecraft:water[level=0]
fill 295 61 -318 305 61 -318 minecraft:water[level=0]
setblock 264 60 -274 minecraft:water[level=0]
fill 264 60 -275 266 60 -275 minecraft:water[level=0]
setblock 264 60 -276 minecraft:water[level=0]
setblock 265 60 -276 minecraft:seagrass
fill 266 60 -276 267 60 -276 minecraft:water[level=0]
fill 264 60 -277 267 60 -277 minecraft:water[level=0]
setblock 268 60 -279 minecraft:water[level=0]
setblock 268 60 -280 minecraft:water[level=0]
setblock 304 60 -283 minecraft:water[level=0]
fill 304 60 -284 305 60 -284 minecraft:water[level=0]
fill 304 60 -285 305 60 -285 minecraft:water[level=0]
fill 304 60 -286 305 60 -286 minecraft:water[level=0]
setblock 273 60 -287 minecraft:water[level=0]
fill 291 60 -287 293 60 -287 minecraft:water[level=0]
fill 304 60 -287 305 60 -287 minecraft:water[level=0]
fill 272 60 -288 275 60 -288 minecraft:water[level=0]
fill 290 60 -288 294 60 -288 minecraft:water[level=0]
setblock 305 60 -288 minecraft:water[level=0]
fill 273 60 -289 275 60 -289 minecraft:water[level=0]
fill 290 60 -289 294 60 -289 minecraft:water[level=0]
setblock 306 60 -289 minecraft:water[level=0]
setblock 274 60 -290 minecraft:water[level=0]
fill 290 60 -290 293 60 -290 minecraft:water[level=0]
fill 290 60 -291 292 60 -291 minecraft:water[level=0]
fill 290 60 -292 291 60 -292 minecraft:water[level=0]
setblock 291 60 -293 minecraft:water[level=0]
setblock 291 60 -294 minecraft:water[level=0]
fill 294 60 -298 295 60 -298 minecraft:water[level=0]
setblock 293 60 -299 minecraft:water[level=0]
setblock 294 60 -299 minecraft:bubble_column[drag=true]
setblock 295 60 -299 minecraft:water[level=0]
setblock 296 60 -299 minecraft:bubble_column[drag=true]
setblock 312 60 -299 minecraft:water[level=0]
fill 293 60 -300 295 60 -300 minecraft:water[level=0]
setblock 296 60 -300 minecraft:bubble_column[drag=true]
setblock 297 60 -300 minecraft:water[level=0]
fill 312 60 -300 313 60 -300 minecraft:water[level=0]
setblock 294 60 -301 minecraft:water[level=0]
setblock 295 60 -301 minecraft:bubble_column[drag=true]
fill 296 60 -301 297 60 -301 minecraft:water[level=0]
fill 312 60 -301 313 60 -301 minecraft:water[level=0]
fill 294 60 -302 298 60 -302 minecraft:water[level=0]
fill 311 60 -302 314 60 -302 minecraft:water[level=0]
fill 294 60 -303 297 60 -303 minecraft:water[level=0]
fill 310 60 -303 315 60 -303 minecraft:water[level=0]
fill 294 60 -304 297 60 -304 minecraft:water[level=0]
fill 311 60 -304 316 60 -304 minecraft:water[level=0]
fill 294 60 -305 298 60 -305 minecraft:water[level=0]
fill 311 60 -305 315 60 -305 minecraft:water[level=0]
fill 293 60 -306 298 60 -306 minecraft:water[level=0]
fill 311 60 -306 312 60 -306 minecraft:water[level=0]
fill 293 60 -307 298 60 -307 minecraft:water[level=0]
fill 288 60 -308 289 60 -308 minecraft:seagrass
fill 293 60 -308 297 60 -308 minecraft:water[level=0]
fill 292 60 -309 297 60 -309 minecraft:water[level=0]
fill 292 60 -310 297 60 -310 minecraft:water[level=0]
fill 291 60 -311 292 60 -311 minecraft:tall_seagrass[half=lower]
setblock 293 60 -311 minecraft:water[level=0]
setblock 294 60 -311 minecraft:seagrass
fill 295 60 -311 298 60 -311 minecraft:water[level=0]
fill 291 60 -312 299 60 -312 minecraft:water[level=0]
fill 289 60 -313 292 60 -313 minecraft:water[level=0]
setblock 293 60 -313 minecraft:seagrass
fill 294 60 -313 299 60 -313 minecraft:water[level=0]
fill 286 60 -314 297 60 -314 minecraft:water[level=0]
setblock 298 60 -314 minecraft:seagrass
fill 299 60 -314 301 60 -314 minecraft:water[level=0]
fill 284 60 -315 291 60 -315 minecraft:water[level=0]
fill 292 60 -315 293 60 -315 minecraft:tall_seagrass[half=upper]
fill 294 60 -315 301 60 -315 minecraft:water[level=0]
fill 282 60 -316 293 60 -316 minecraft:water[level=0]
fill 295 60 -316 302 60 -316 minecraft:water[level=0]
fill 279 60 -317 293 60 -317 minecraft:water[level=0]
fill 296 60 -317 302 60 -317 minecraft:water[level=0]
fill 319 60 -317 320 60 -317 minecraft:cave_air
fill 279 60 -318 291 60 -318 minecraft:water[level=0]
fill 296 60 -318 303 60 -318 minecraft:water[level=0]
setblock 304 59 -284 minecraft:water[level=0]
fill 304 59 -285 305 59 -285 minecraft:water[level=0]
fill 304 59 -286 305 59 -286 minecraft:water[level=0]
fill 291 59 -287 293 59 -287 minecraft:water[level=0]
fill 304 59 -287 305 59 -287 minecraft:water[level=0]
fill 273 59 -288 275 59 -288 minecraft:water[level=0]
fill 290 59 -288 294 59 -288 minecraft:water[level=0]
fill 304 59 -288 305 59 -288 minecraft:water[level=0]
fill 273 59 -289 275 59 -289 minecraft:water[level=0]
fill 290 59 -289 293 59 -289 minecraft:water[level=0]
setblock 305 59 -289 minecraft:water[level=0]
setblock 274 59 -290 minecraft:water[level=0]
fill 290 59 -290 293 59 -290 minecraft:water[level=0]
setblock 306 59 -290 minecraft:water[level=0]
fill 289 59 -291 292 59 -291 minecraft:water[level=0]
fill 289 59 -292 292 59 -292 minecraft:water[level=0]
fill 290 59 -293 292 59 -293 minecraft:water[level=0]
fill 290 59 -294 293 59 -294 minecraft:water[level=0]
fill 290 59 -295 294 59 -295 minecraft:water[level=0]
fill 291 59 -296 294 59 -296 minecraft:water[level=0]
fill 292 59 -297 295 59 -297 minecraft:water[level=0]
fill 292 59 -298 296 59 -298 minecraft:water[level=0]
setblock 311 59 -298 minecraft:water[level=0]
setblock 293 59 -299 minecraft:water[level=0]
setblock 294 59 -299 minecraft:bubble_column[drag=true]
setblock 295 59 -299 minecraft:water[level=0]
setblock 296 59 -299 minecraft:bubble_column[drag=true]
setblock 297 59 -299 minecraft:water[level=0]
setblock 312 59 -299 minecraft:water[level=0]
fill 293 59 -300 295 59 -300 minecraft:water[level=0]
setblock 296 59 -300 minecraft:bubble_column[drag=true]
setblock 297 59 -300 minecraft:water[level=0]
fill 312 59 -300 313 59 -300 minecraft:water[level=0]
fill 293 59 -301 294 59 -301 minecraft:water[level=0]
setblock 295 59 -301 minecraft:bubble_column[drag=true]
fill 296 59 -301 298 59 -301 minecraft:water[level=0]
fill 311 59 -301 314 59 -301 minecraft:water[level=0]
fill 293 59 -302 298 59 -302 minecraft:water[level=0]
fill 310 59 -302 314 59 -302 minecraft:water[level=0]
fill 294 59 -303 298 59 -303 minecraft:water[level=0]
fill 311 59 -303 315 59 -303 minecraft:water[level=0]
fill 294 59 -304 297 59 -304 minecraft:water[level=0]
fill 311 59 -304 316 59 -304 minecraft:water[level=0]
fill 312 59 -305 315 59 -305 minecraft:water[level=0]
setblock 312 59 -306 minecraft:water[level=0]
fill 293 59 -312 297 59 -312 minecraft:water[level=0]
fill 289 59 -313 290 59 -313 minecraft:water[level=0]
setblock 291 59 -313 minecraft:seagrass
setblock 292 59 -313 minecraft:water[level=0]
fill 295 59 -313 297 59 -313 minecraft:water[level=0]
fill 284 59 -314 293 59 -314 minecraft:water[level=0]
fill 296 59 -314 297 59 -314 minecraft:water[level=0]
fill 282 59 -315 289 59 -315 minecraft:water[level=0]
setblock 290 59 -315 minecraft:tall_seagrass[half=upper]
setblock 291 59 -315 minecraft:water[level=0]
fill 292 59 -315 293 59 -315 minecraft:tall_seagrass[half=lower]
fill 296 59 -315 297 59 -315 minecraft:water[level=0]
fill 278 59 -316 291 59 -316 minecraft:water[level=0]
setblock 292 59 -316 minecraft:seagrass
setblock 293 59 -316 minecraft:water[level=0]
fill 297 59 -316 300 59 -316 minecraft:water[level=0]
fill 316 59 -316 320 59 -316 minecraft:cave_air
fill 276 59 -317 292 59 -317 minecraft:water[level=0]
fill 298 59 -317 300 59 -317 minecraft:water[level=0]
fill 315 59 -317 321 59 -317 minecraft:cave_air
fill 275 59 -318 291 59 -318 minecraft:water[level=0]
fill 299 59 -318 301 59 -318 minecraft:water[level=0]
fill 315 59 -318 320 59 -318 minecraft:cave_air
setblock 267 58 -255 minecraft:water[level=0]
setblock 303 58 -283 minecraft:water[level=0]
fill 303 58 -284 304 58 -284 minecraft:water[level=0]
fill 303 58 -285 304 58 -285 minecraft:water[level=0]
fill 303 58 -286 305 58 -286 minecraft:water[level=0]
fill 303 58 -287 305 58 -287 minecraft:water[level=0]
fill 274 58 -288 276 58 -288 minecraft:water[level=0]
setblock 291 58 -288 minecraft:water[level=0]
fill 303 58 -288 305 58 -288 minecraft:water[level=0]
fill 273 58 -289 276 58 -289 minecraft:water[level=0]
fill 290 58 -289 292 58 -289 minecraft:water[level=0]
fill 304 58 -289 305 58 -289 minecraft:water[level=0]
setblock 275 58 -290 minecraft:water[level=0]
fill 290 58 -290 293 58 -290 minecraft:water[level=0]
fill 305 58 -290 306 58 -290 minecraft:water[level=0]
fill 289 58 -291 292 58 -291 minecraft:water[level=0]
setblock 306 58 -291 minecraft:water[level=0]
fill 289 58 -292 292 58 -292 minecraft:water[level=0]
setblock 307 58 -292 minecraft:water[level=0]
fill 289 58 -293 293 58 -293 minecraft:water[level=0]
fill 289 58 -294 294 58 -294 minecraft:water[level=0]
fill 290 58 -295 294 58 -295 minecraft:water[level=0]
fill 290 58 -296 295 58 -296 minecraft:water[level=0]
fill 291 58 -297 295 58 -297 minecraft:water[level=0]
fill 292 58 -298 296 58 -298 minecraft:water[level=0]
setblock 311 58 -298 minecraft:water[level=0]
setblock 293 58 -299 minecraft:water[level=0]
setblock 294 58 -299 minecraft:bubble_column[drag=true]
setblock 295 58 -299 minecraft:water[level=0]
setblock 296 58 -299 minecraft:bubble_column[drag=true]
setblock 297 58 -299 minecraft:water[level=0]
fill 311 58 -299 312 58 -299 minecraft:water[level=0]
fill 293 58 -300 295 58 -300 minecraft:water[level=0]
setblock 296 58 -300 minecraft:bubble_column[drag=true]
setblock 297 58 -300 minecraft:water[level=0]
fill 312 58 -300 313 58 -300 minecraft:water[level=0]
fill 293 58 -301 294 58 -301 minecraft:water[level=0]
setblock 295 58 -301 minecraft:bubble_column[drag=true]
fill 296 58 -301 297 58 -301 minecraft:water[level=0]
fill 311 58 -301 314 58 -301 minecraft:water[level=0]
fill 294 58 -302 297 58 -302 minecraft:water[level=0]
fill 310 58 -302 315 58 -302 minecraft:water[level=0]
fill 294 58 -303 297 58 -303 minecraft:water[level=0]
fill 311 58 -303 315 58 -303 minecraft:water[level=0]
fill 295 58 -304 296 58 -304 minecraft:water[level=0]
fill 312 58 -304 316 58 -304 minecraft:water[level=0]
fill 312 58 -305 315 58 -305 minecraft:water[level=0]
fill 284 58 -314 290 58 -314 minecraft:water[level=0]
fill 279 58 -315 287 58 -315 minecraft:water[level=0]
setblock 288 58 -315 minecraft:tall_seagrass[half=upper]
setblock 289 58 -315 minecraft:water[level=0]
setblock 290 58 -315 minecraft:tall_seagrass[half=lower]
setblock 291 58 -315 minecraft:seagrass
fill 276 58 -316 288 58 -316 minecraft:water[level=0]
setblock 289 58 -316 minecraft:seagrass
fill 290 58 -316 291 58 -316 minecraft:water[level=0]
fill 315 58 -316 320 58 -316 minecraft:cave_air
fill 274 58 -317 289 58 -317 minecraft:water[level=0]
setblock 290 58 -317 minecraft:seagrass
setblock 291 58 -317 minecraft:water[level=0]
fill 314 58 -317 321 58 -317 minecraft:cave_air
fill 273 58 -318 290 58 -318 minecraft:water[level=0]
fill 314 58 -318 321 58 -318 minecraft:cave_air
fill 266 57 -255 267 57 -255 minecraft:water[level=0]
setblock 303 57 -284 minecraft:water[level=0]
fill 303 57 -285 304 57 -285 minecraft:water[level=0]
fill 303 57 -286 304 57 -286 minecraft:water[level=0]
fill 303 57 -287 305 57 -287 minecraft:water[level=0]
fill 275 57 -288 277 57 -288 minecraft:water[level=0]
fill 303 57 -288 305 57 -288 minecraft:water[level=0]
fill 274 57 -289 277 57 -289 minecraft:water[level=0]
fill 303 57 -289 305 57 -289 minecraft:water[level=0]
fill 275 57 -290 276 57 -290 minecraft:water[level=0]
fill 305 57 -290 306 57 -290 minecraft:water[level=0]
setblock 306 57 -291 minecraft:water[level=0]
fill 290 57 -292 292 57 -292 minecraft:water[level=0]
setblock 307 57 -292 minecraft:water[level=0]
fill 289 57 -293 293 57 -293 minecraft:water[level=0]
setblock 307 57 -293 minecraft:water[level=0]
fill 289 57 -294 294 57 -294 minecraft:water[level=0]
setblock 308 57 -294 minecraft:water[level=0]
fill 290 57 -295 294 57 -295 minecraft:water[level=0]
setblock 309 57 -295 minecraft:water[level=0]
fill 291 57 -296 295 57 -296 minecraft:water[level=0]
setblock 310 57 -296 minecraft:water[level=0]
fill 291 57 -297 295 57 -297 minecraft:water[level=0]
fill 310 57 -297 311 57 -297 minecraft:water[level=0]
fill 292 57 -298 296 57 -298 minecraft:water[level=0]
fill 310 57 -298 312 57 -298 minecraft:water[level=0]
setblock 293 57 -299 minecraft:water[level=0]
setblock 294 57 -299 minecraft:bubble_column[drag=true]
setblock 295 57 -299 minecraft:water[level=0]
setblock 296 57 -299 minecraft:bubble_column[drag=true]
fill 311 57 -299 313 57 -299 minecraft:water[level=0]
fill 293 57 -300 295 57 -300 minecraft:water[level=0]
setblock 296 57 -300 minecraft:bubble_column[drag=true]
setblock 297 57 -300 minecraft:water[level=0]
fill 311 57 -300 314 57 -300 minecraft:water[level=0]
fill 293 57 -301 294 57 -301 minecraft:water[level=0]
setblock 295 57 -301 minecraft:bubble_column[drag=true]
setblock 296 57 -301 minecraft:water[level=0]
fill 310 57 -301 314 57 -301 minecraft:water[level=0]
fill 294 57 -302 296 57 -302 minecraft:water[level=0]
fill 311 57 -302 315 57 -302 minecraft:water[level=0]
fill 312 57 -303 316 57 -303 minecraft:water[level=0]
fill 313 57 -304 316 57 -304 minecraft:water[level=0]
fill 313 57 -305 315 57 -305 minecraft:water[level=0]
fill 285 57 -314 287 57 -314 minecraft:water[level=0]
fill 279 57 -315 287 57 -315 minecraft:water[level=0]
setblock 288 57 -315 minecraft:tall_seagrass[half=lower]
fill 264 57 -316 265 57 -316 minecraft:water[level=0]
fill 275 57 -316 288 57 -316 minecraft:water[level=0]
fill 316 57 -316 320 57 -316 minecraft:lava[level=0]
fill 264 57 -317 266 57 -317 minecraft:water[level=0]
fill 274 57 -317 288 57 -317 minecraft:water[level=0]
fill 314 57 -317 321 57 -317 minecraft:lava[level=0]
fill 264 57 -318 266 57 -318 minecraft:water[level=0]
fill 272 57 -318 288 57 -318 minecraft:water[level=0]
fill 314 57 -318 321 57 -318 minecraft:lava[level=0]
fill 266 56 -255 268 56 -255 minecraft:water[level=0]
fill 266 56 -256 268 56 -256 minecraft:water[level=0]
setblock 302 56 -284 minecraft:water[level=0]
fill 302 56 -285 303 56 -285 minecraft:water[level=0]
fill 303 56 -286 304 56 -286 minecraft:water[level=0]
fill 303 56 -287 304 56 -287 minecraft:water[level=0]
fill 275 56 -288 277 56 -288 minecraft:water[level=0]
fill 303 56 -288 305 56 -288 minecraft:water[level=0]
fill 275 56 -289 278 56 -289 minecraft:water[level=0]
fill 303 56 -289 305 56 -289 minecraft:water[level=0]
fill 275 56 -290 277 56 -290 minecraft:water[level=0]
fill 304 56 -290 306 56 -290 minecraft:water[level=0]
fill 305 56 -291 306 56 -291 minecraft:water[level=0]
fill 306 56 -292 307 56 -292 minecraft:water[level=0]
setblock 307 56 -293 minecraft:water[level=0]
setblock 308 56 -294 minecraft:water[level=0]
setblock 309 56 -295 minecraft:water[level=0]
fill 309 56 -296 310 56 -296 minecraft:water[level=0]
fill 310 56 -297 311 56 -297 minecraft:water[level=0]
fill 310 56 -298 312 56 -298 minecraft:water[level=0]
fill 310 56 -299 313 56 -299 minecraft:water[level=0]
fill 311 56 -300 314 56 -300 minecraft:water[level=0]
fill 311 56 -301 315 56 -301 minecraft:water[level=0]
fill 312 56 -302 315 56 -302 minecraft:water[level=0]
fill 271 56 -303 274 56 -303 minecraft:water[level=0]
fill 312 56 -303 316 56 -303 minecraft:water[level=0]
fill 271 56 -304 274 56 -304 minecraft:water[level=0]
fill 313 56 -304 316 56 -304 minecraft:water[level=0]
fill 271 56 -305 274 56 -305 minecraft:water[level=0]
fill 313 56 -305 314 56 -305 minecraft:water[level=0]
fill 271 56 -306 274 56 -306 minecraft:water[level=0]
fill 264 56 -313 265 56 -313 minecraft:water[level=0]
fill 264 56 -314 266 56 -314 minecraft:water[level=0]
fill 264 56 -315 266 56 -315 minecraft:water[level=0]
fill 279 56 -315 283 56 -315 minecraft:water[level=0]
fill 264 56 -316 267 56 -316 minecraft:water[level=0]
fill 275 56 -316 284 56 -316 minecraft:water[level=0]
fill 264 56 -317 267 56 -317 minecraft:water[level=0]
fill 274 56 -317 285 56 -317 minecraft:water[level=0]
fill 264 56 -318 267 56 -318 minecraft:water[level=0]
fill 272 56 -318 285 56 -318 minecraft:water[level=0]
fill 266 55 -255 268 55 -255 minecraft:water[level=0]
fill 266 55 -256 268 55 -256 minecraft:water[level=0]
fill 266 55 -257 268 55 -257 minecraft:water[level=0]
setblock 302 55 -284 minecraft:water[level=0]
fill 302 55 -285 303 55 -285 minecraft:water[level=0]
fill 303 55 -286 304 55 -286 minecraft:water[level=0]
fill 303 55 -287 305 55 -287 minecraft:water[level=0]
fill 276 55 -288 279 55 -288 minecraft:water[level=0]
fill 303 55 -288 305 55 -288 minecraft:water[level=0]
fill 275 55 -289 279 55 -289 minecraft:water[level=0]
fill 304 55 -289 305 55 -289 minecraft:water[level=0]
fill 276 55 -290 278 55 -290 minecraft:water[level=0]
fill 304 55 -290 306 55 -290 minecraft:water[level=0]
fill 305 55 -291 307 55 -291 minecraft:water[level=0]
fill 306 55 -292 307 55 -292 minecraft:water[level=0]
fill 307 55 -293 308 55 -293 minecraft:water[level=0]
fill 308 55 -294 309 55 -294 minecraft:water[level=0]
setblock 264 55 -295 minecraft:water[level=0]
fill 309 55 -295 310 55 -295 minecraft:water[level=0]
fill 309 55 -296 311 55 -296 minecraft:water[level=0]
fill 310 55 -297 312 55 -297 minecraft:water[level=0]
setblock 264 55 -298 minecraft:water[level=0]
fill 310 55 -298 313 55 -298 minecraft:water[level=0]
fill 264 55 -299 265 55 -299 minecraft:water[level=0]
fill 272 55 -299 273 55 -299 minecraft:water[level=0]
fill 311 55 -299 314 55 -299 minecraft:water[level=0]
fill 264 55 -300 265 55 -300 minecraft:water[level=0]
fill 270 55 -300 275 55 -300 minecraft:water[level=0]
fill 312 55 -300 315 55 -300 minecraft:water[level=0]
fill 264 55 -301 266 55 -301 minecraft:water[level=0]
fill 269 55 -301 276 55 -301 minecraft:water[level=0]
fill 312 55 -301 316 55 -301 minecraft:water[level=0]
fill 265 55 -302 277 55 -302 minecraft:water[level=0]
fill 313 55 -302 316 55 -302 minecraft:water[level=0]
fill 267 55 -303 277 55 -303 minecraft:water[level=0]
fill 313 55 -303 317 55 -303 minecraft:water[level=0]
fill 267 55 -304 278 55 -304 minecraft:water[level=0]
fill 314 55 -304 317 55 -304 minecraft:water[level=0]
fill 267 55 -305 278 55 -305 minecraft:water[level=0]
fill 314 55 -305 315 55 -305 minecraft:water[level=0]
fill 268 55 -306 277 55 -306 minecraft:water[level=0]
fill 268 55 -307 277 55 -307 minecraft:water[level=0]
fill 269 55 -308 276 55 -308 minecraft:water[level=0]
fill 270 55 -309 275 55 -309 minecraft:water[level=0]
fill 272 55 -310 273 55 -310 minecraft:water[level=0]
fill 264 55 -312 265 55 -312 minecraft:water[level=0]
fill 264 55 -313 266 55 -313 minecraft:water[level=0]
fill 264 55 -314 266 55 -314 minecraft:water[level=0]
fill 264 55 -315 267 55 -315 minecraft:water[level=0]
fill 264 55 -316 267 55 -316 minecraft:water[level=0]
fill 264 55 -317 267 55 -317 minecraft:water[level=0]
fill 275 55 -317 278 55 -317 minecraft:water[level=0]
fill 264 55 -318 267 55 -318 minecraft:water[level=0]
fill 273 55 -318 279 55 -318 minecraft:water[level=0]
fill 267 54 -256 269 54 -256 minecraft:water[level=0]
fill 266 54 -257 269 54 -257 minecraft:water[level=0]
fill 267 54 -258 268 54 -258 minecraft:water[level=0]
setblock 302 54 -284 minecraft:water[level=0]
fill 302 54 -285 303 54 -285 minecraft:water[level=0]
fill 303 54 -286 304 54 -286 minecraft:water[level=0]
fill 303 54 -287 305 54 -287 minecraft:water[level=0]
fill 277 54 -288 280 54 -288 minecraft:water[level=0]
fill 303 54 -288 305 54 -288 minecraft:water[level=0]
fill 276 54 -289 281 54 -289 minecraft:water[level=0]
fill 304 54 -289 306 54 -289 minecraft:water[level=0]
fill 277 54 -290 280 54 -290 minecraft:water[level=0]
fill 304 54 -290 307 54 -290 minecraft:water[level=0]
fill 305 54 -291 307 54 -291 minecraft:water[level=0]
setblock 265 54 -292 minecraft:water[level=0]
fill 306 54 -292 308 54 -292 minecraft:water[level=0]
fill 264 54 -293 265 54 -293 minecraft:water[level=0]
fill 307 54 -293 309 54 -293 minecraft:water[level=0]
fill 264 54 -294 265 54 -294 minecraft:water[level=0]
fill 308 54 -294 310 54 -294 minecraft:water[level=0]
fill 264 54 -295 265 54 -295 minecraft:water[level=0]
fill 309 54 -295 311 54 -295 minecraft:water[level=0]
setblock 264 54 -296 minecraft:water[level=0]
setblock 291 54 -296 minecraft:water[level=0]
fill 309 54 -296 313 54 -296 minecraft:water[level=0]
fill 310 54 -297 313 54 -297 minecraft:water[level=0]
fill 264 54 -298 265 54 -298 minecraft:water[level=0]
fill 272 54 -298 273 54 -298 minecraft:water[level=0]
fill 311 54 -298 314 54 -298 minecraft:water[level=0]
fill 264 54 -299 265 54 -299 minecraft:water[level=0]
fill 269 54 -299 276 54 -299 minecraft:water[level=0]
fill 312 54 -299 315 54 -299 minecraft:water[level=0]
fill 264 54 -300 266 54 -300 minecraft:water[level=0]
fill 268 54 -300 277 54 -300 minecraft:water[level=0]
fill 313 54 -300 316 54 -300 minecraft:water[level=0]
fill 264 54 -301 278 54 -301 minecraft:water[level=0]
fill 313 54 -301 317 54 -301 minecraft:water[level=0]
fill 265 54 -302 278 54 -302 minecraft:water[level=0]
fill 314 54 -302 317 54 -302 minecraft:water[level=0]
fill 266 54 -303 278 54 -303 minecraft:water[level=0]
fill 315 54 -303 317 54 -303 minecraft:water[level=0]
fill 266 54 -304 279 54 -304 minecraft:water[level=0]
fill 315 54 -304 318 54 -304 minecraft:water[level=0]
fill 266 54 -305 279 54 -305 minecraft:water[level=0]
fill 315 54 -305 318 54 -305 minecraft:water[level=0]
fill 267 54 -306 278 54 -306 minecraft:water[level=0]
setblock 315 54 -306 minecraft:water[level=0]
fill 267 54 -307 278 54 -307 minecraft:water[level=0]
fill 267 54 -308 278 54 -308 minecraft:water[level=0]
fill 268 54 -309 277 54 -309 minecraft:water[level=0]
fill 269 54 -310 276 54 -310 minecraft:water[level=0]
setblock 264 54 -311 minecraft:water[level=0]
fill 272 54 -311 273 54 -311 minecraft:water[level=0]
fill 264 54 -312 265 54 -312 minecraft:water[level=0]
fill 264 54 -313 266 54 -313 minecraft:water[level=0]
fill 264 54 -314 267 54 -314 minecraft:water[level=0]
fill 264 54 -315 267 54 -315 minecraft:water[level=0]
fill 264 54 -316 267 54 -316 minecraft:water[level=0]
fill 264 54 -317 268 54 -317 minecraft:water[level=0]
fill 264 54 -318 268 54 -318 minecraft:water[level=0]
fill 267 53 -256 268 53 -256 minecraft:water[level=0]
fill 267 53 -257 269 53 -257 minecraft:water[level=0]
fill 267 53 -258 269 53 -258 minecraft:water[level=0]
setblock 302 53 -283 minecraft:water[level=0]
setblock 302 53 -284 minecraft:water[level=0]
fill 302 53 -285 304 53 -285 minecraft:water[level=0]
fill 303 53 -286 304 53 -286 minecraft:water[level=0]
fill 303 53 -287 305 53 -287 minecraft:water[level=0]
fill 278 53 -288 281 53 -288 minecraft:water[level=0]
fill 304 53 -288 306 53 -288 minecraft:water[level=0]
fill 277 53 -289 282 53 -289 minecraft:water[level=0]
fill 304 53 -289 306 53 -289 minecraft:water[level=0]
fill 278 53 -290 283 53 -290 minecraft:water[level=0]
fill 305 53 -290 307 53 -290 minecraft:water[level=0]
fill 264 53 -291 266 53 -291 minecraft:water[level=0]
fill 306 53 -291 308 53 -291 minecraft:water[level=0]
fill 264 53 -292 266 53 -292 minecraft:water[level=0]
fill 306 53 -292 309 53 -292 minecraft:water[level=0]
fill 264 53 -293 266 53 -293 minecraft:water[level=0]
fill 307 53 -293 310 53 -293 minecraft:water[level=0]
fill 264 53 -294 265 53 -294 minecraft:water[level=0]
fill 287 53 -294 289 53 -294 minecraft:water[level=0]
fill 308 53 -294 311 53 -294 minecraft:water[level=0]
fill 264 53 -295 265 53 -295 minecraft:water[level=0]
fill 288 53 -295 291 53 -295 minecraft:water[level=0]
fill 309 53 -295 313 53 -295 minecraft:water[level=0]
setblock 264 53 -296 minecraft:water[level=0]
fill 289 53 -296 292 53 -296 minecraft:water[level=0]
fill 310 53 -296 314 53 -296 minecraft:water[level=0]
fill 291 53 -297 292 53 -297 minecraft:water[level=0]
fill 311 53 -297 315 53 -297 minecraft:water[level=0]
fill 264 53 -298 265 53 -298 minecraft:water[level=0]
fill 272 53 -298 273 53 -298 minecraft:water[level=0]
fill 312 53 -298 315 53 -298 minecraft:water[level=0]
fill 264 53 -299 265 53 -299 minecraft:water[level=0]
fill 269 53 -299 276 53 -299 minecraft:water[level=0]
fill 313 53 -299 316 53 -299 minecraft:water[level=0]
fill 264 53 -300 266 53 -300 minecraft:water[level=0]
fill 268 53 -300 277 53 -300 minecraft:water[level=0]
fill 314 53 -300 317 53 -300 minecraft:water[level=0]
fill 264 53 -301 278 53 -301 minecraft:water[level=0]
fill 315 53 -301 317 53 -301 minecraft:water[level=0]
fill 265 53 -302 278 53 -302 minecraft:water[level=0]
fill 315 53 -302 318 53 -302 minecraft:water[level=0]
fill 266 53 -303 278 53 -303 minecraft:water[level=0]
fill 316 53 -303 318 53 -303 minecraft:water[level=0]
fill 266 53 -304 279 53 -304 minecraft:water[level=0]
fill 316 53 -304 319 53 -304 minecraft:water[level=0]
fill 266 53 -305 279 53 -305 minecraft:water[level=0]
fill 316 53 -305 319 53 -305 minecraft:water[level=0]
fill 267 53 -306 278 53 -306 minecraft:water[level=0]
fill 316 53 -306 317 53 -306 minecraft:water[level=0]
fill 267 53 -307 278 53 -307 minecraft:water[level=0]
fill 267 53 -308 278 53 -308 minecraft:water[level=0]
fill 268 53 -309 277 53 -309 minecraft:water[level=0]
fill 269 53 -310 276 53 -310 minecraft:water[level=0]
setblock 264 53 -311 minecraft:water[level=0]
fill 272 53 -311 273 53 -311 minecraft:water[level=0]
fill 264 53 -312 265 53 -312 minecraft:water[level=0]
fill 264 53 -313 266 53 -313 minecraft:water[level=0]
fill 264 53 -314 266 53 -314 minecraft:water[level=0]
fill 264 53 -315 267 53 -315 minecraft:water[level=0]
fill 264 53 -316 267 53 -316 minecraft:water[level=0]
fill 264 53 -317 267 53 -317 minecraft:water[level=0]
fill 264 53 -318 267 53 -318 minecraft:water[level=0]
setblock 289 52 -255 minecraft:cave_air
fill 291 52 -255 292 52 -255 minecraft:cave_air
fill 294 52 -255 297 52 -255 minecraft:cave_air
fill 288 52 -256 289 52 -256 minecraft:cave_air
fill 267 52 -257 269 52 -257 minecraft:water[level=0]
fill 288 52 -257 289 52 -257 minecraft:cave_air
fill 267 52 -258 270 52 -258 minecraft:water[level=0]
fill 288 52 -258 289 52 -258 minecraft:cave_air
fill 267 52 -259 269 52 -259 minecraft:water[level=0]
setblock 289 52 -259 minecraft:cave_air
setblock 301 52 -282 minecraft:water[level=0]
setblock 302 52 -283 minecraft:water[level=0]
fill 302 52 -284 303 52 -284 minecraft:water[level=0]
fill 302 52 -285 304 52 -285 minecraft:water[level=0]
fill 303 52 -286 304 52 -286 minecraft:water[level=0]
fill 303 52 -287 305 52 -287 minecraft:water[level=0]
setblock 281 52 -288 minecraft:water[level=0]
fill 304 52 -288 306 52 -288 minecraft:water[level=0]
fill 279 52 -289 283 52 -289 minecraft:water[level=0]
fill 305 52 -289 307 52 -289 minecraft:water[level=0]
fill 265 52 -290 267 52 -290 minecraft:water[level=0]
fill 280 52 -290 284 52 -290 minecraft:water[level=0]
fill 305 52 -290 308 52 -290 minecraft:water[level=0]
fill 264 52 -291 267 52 -291 minecraft:water[level=0]
fill 282 52 -291 285 52 -291 minecraft:water[level=0]
fill 306 52 -291 309 52 -291 minecraft:water[level=0]
fill 264 52 -292 267 52 -292 minecraft:water[level=0]
setblock 284 52 -292 minecraft:water[level=0]
fill 286 52 -292 287 52 -292 minecraft:water[level=0]
fill 307 52 -292 310 52 -292 minecraft:water[level=0]
fill 264 52 -293 266 52 -293 minecraft:water[level=0]
fill 286 52 -293 288 52 -293 minecraft:water[level=0]
fill 308 52 -293 311 52 -293 minecraft:water[level=0]
fill 264 52 -294 265 52 -294 minecraft:water[level=0]
fill 286 52 -294 290 52 -294 minecraft:water[level=0]
fill 309 52 -294 312 52 -294 minecraft:water[level=0]
fill 264 52 -295 265 52 -295 minecraft:water[level=0]
fill 287 52 -295 291 52 -295 minecraft:water[level=0]
fill 310 52 -295 313 52 -295 minecraft:water[level=0]
setblock 264 52 -296 minecraft:water[level=0]
fill 289 52 -296 292 52 -296 minecraft:water[level=0]
fill 311 52 -296 314 52 -296 minecraft:water[level=0]
setblock 291 52 -297 minecraft:water[level=0]
fill 312 52 -297 314 52 -297 minecraft:water[level=0]
fill 313 52 -298 315 52 -298 minecraft:water[level=0]
fill 314 52 -299 317 52 -299 minecraft:water[level=0]
fill 315 52 -300 318 52 -300 minecraft:water[level=0]
fill 316 52 -301 318 52 -301 minecraft:water[level=0]
fill 316 52 -302 319 52 -302 minecraft:water[level=0]
setblock 264 52 -303 minecraft:water[level=0]
fill 317 52 -303 319 52 -303 minecraft:water[level=0]
setblock 264 52 -304 minecraft:water[level=0]
fill 317 52 -304 320 52 -304 minecraft:water[level=0]
fill 317 52 -305 320 52 -305 minecraft:water[level=0]
fill 317 52 -306 320 52 -306 minecraft:water[level=0]
setblock 317 52 -307 minecraft:water[level=0]
setblock 264 52 -311 minecraft:water[level=0]
setblock 264 52 -312 minecraft:water[level=0]
fill 264 52 -313 265 52 -313 minecraft:water[level=0]
fill 264 52 -314 265 52 -314 minecraft:water[level=0]
fill 264 52 -315 265 52 -315 minecraft:water[level=0]
setblock 264 52 -316 minecraft:water[level=0]
fill 264 52 -318 265 52 -318 minecraft:water[level=0]
fill 288 51 -255 297 51 -255 minecraft:cave_air
fill 288 51 -256 292 51 -256 minecraft:cave_air
fill 294 51 -256 297 51 -256 minecraft:cave_air
fill 288 51 -257 291 51 -257 minecraft:cave_air
fill 268 51 -258 270 51 -258 minecraft:water[level=0]
fill 288 51 -258 295 51 -258 minecraft:cave_air
fill 267 51 -259 270 51 -259 minecraft:water[level=0]
fill 288 51 -259 296 51 -259 minecraft:cave_air
fill 268 51 -260 270 51 -260 minecraft:water[level=0]
fill 289 51 -260 296 51 -260 minecraft:cave_air
fill 291 51 -261 295 51 -261 minecraft:cave_air
setblock 299 51 -275 minecraft:water[level=0]
setblock 299 51 -276 minecraft:water[level=0]
setblock 300 51 -278 minecraft:water[level=0]
setblock 300 51 -279 minecraft:water[level=0]
setblock 300 51 -280 minecraft:water[level=0]
setblock 301 51 -281 minecraft:water[level=0]
setblock 301 51 -282 minecraft:water[level=0]
fill 301 51 -283 302 51 -283 minecraft:water[level=0]
fill 302 51 -284 303 51 -284 minecraft:water[level=0]
fill 302 51 -285 304 51 -285 minecraft:water[level=0]
fill 303 51 -286 304 51 -286 minecraft:water[level=0]
fill 304 51 -287 305 51 -287 minecraft:water[level=0]
fill 304 51 -288 306 51 -288 minecraft:water[level=0]
setblock 267 51 -289 minecraft:water[level=0]
fill 281 51 -289 283 51 -289 minecraft:water[level=0]
fill 305 51 -289 307 51 -289 minecraft:water[level=0]
fill 265 51 -290 269 51 -290 minecraft:water[level=0]
fill 282 51 -290 285 51 -290 minecraft:water[level=0]
fill 306 51 -290 308 51 -290 minecraft:water[level=0]
fill 264 51 -291 269 51 -291 minecraft:water[level=0]
fill 282 51 -291 285 51 -291 minecraft:water[level=0]
fill 307 51 -291 309 51 -291 minecraft:water[level=0]
fill 264 51 -292 268 51 -292 minecraft:water[level=0]
fill 284 51 -292 287 51 -292 minecraft:water[level=0]
fill 308 51 -292 310 51 -292 minecraft:water[level=0]
fill 264 51 -293 266 51 -293 minecraft:water[level=0]
fill 285 51 -293 288 51 -293 minecraft:water[level=0]
fill 309 51 -293 311 51 -293 minecraft:water[level=0]
fill 264 51 -294 265 51 -294 minecraft:water[level=0]
fill 286 51 -294 289 51 -294 minecraft:water[level=0]
fill 310 51 -294 311 51 -294 minecraft:water[level=0]
fill 288 51 -295 290 51 -295 minecraft:water[level=0]
fill 311 51 -295 312 51 -295 minecraft:water[level=0]
fill 313 51 -296 314 51 -296 minecraft:water[level=0]
setblock 314 51 -297 minecraft:water[level=0]
fill 314 51 -298 315 51 -298 minecraft:water[level=0]
fill 315 51 -299 316 51 -299 minecraft:water[level=0]
fill 316 51 -300 318 51 -300 minecraft:water[level=0]
fill 317 51 -301 319 51 -301 minecraft:water[level=0]
fill 317 51 -302 320 51 -302 minecraft:water[level=0]
setblock 264 51 -303 minecraft:water[level=0]
fill 317 51 -303 320 51 -303 minecraft:water[level=0]
setblock 264 51 -304 minecraft:water[level=0]
fill 318 51 -304 320 51 -304 minecraft:water[level=0]
fill 318 51 -305 320 51 -305 minecraft:water[level=0]
fill 318 51 -306 320 51 -306 minecraft:water[level=0]
fill 318 51 -307 320 51 -307 minecraft:water[level=0]
setblock 318 51 -308 minecraft:water[level=0]
setblock 264 51 -312 minecraft:water[level=0]
fill 288 50 -255 298 50 -255 minecraft:cave_air
fill 288 50 -256 297 50 -256 minecraft:cave_air
fill 288 50 -257 291 50 -257 minecraft:cave_air
setblock 293 50 -257 minecraft:cave_air
setblock 268 50 -258 minecraft:water[level=0]
fill 288 50 -258 296 50 -258 minecraft:cave_air
fill 268 50 -259 271 50 -259 minecraft:water[level=0]
fill 288 50 -259 296 50 -259 minecraft:cave_air
fill 268 50 -260 271 50 -260 minecraft:water[level=0]
fill 289 50 -260 296 50 -260 minecraft:cave_air
fill 269 50 -261 270 50 -261 minecraft:water[level=0]
fill 290 50 -261 296 50 -261 minecraft:cave_air
fill 292 50 -262 294 50 -262 minecraft:cave_air
setblock 298 50 -269 minecraft:water[level=0]
setblock 298 50 -270 minecraft:water[level=0]
fill 298 50 -271 299 50 -271 minecraft:water[level=0]
fill 298 50 -272 299 50 -272 minecraft:water[level=0]
fill 298 50 -273 299 50 -273 minecraft:water[level=0]
fill 298 50 -274 300 50 -274 minecraft:water[level=0]
fill 298 50 -275 300 50 -275 minecraft:water[level=0]
fill 299 50 -276 300 50 -276 minecraft:water[level=0]
fill 299 50 -277 300 50 -277 minecraft:water[level=0]
fill 299 50 -278 300 50 -278 minecraft:water[level=0]
fill 300 50 -279 301 50 -279 minecraft:water[level=0]
fill 300 50 -280 301 50 -280 minecraft:water[level=0]
fill 300 50 -281 301 50 -281 minecraft:water[level=0]
fill 301 50 -282 302 50 -282 minecraft:water[level=0]
fill 301 50 -283 302 50 -283 minecraft:water[level=0]
fill 302 50 -284 303 50 -284 minecraft:water[level=0]
fill 302 50 -285 304 50 -285 minecraft:water[level=0]
fill 303 50 -286 305 50 -286 minecraft:water[level=0]
fill 304 50 -287 305 50 -287 minecraft:water[level=0]
fill 304 50 -288 306 50 -288 minecraft:water[level=0]
fill 266 50 -289 269 50 -289 minecraft:water[level=0]
fill 305 50 -289 307 50 -289 minecraft:water[level=0]
fill 265 50 -290 270 50 -290 minecraft:water[level=0]
fill 283 50 -290 284 50 -290 minecraft:water[level=0]
fill 307 50 -290 308 50 -290 minecraft:water[level=0]
fill 264 50 -291 270 50 -291 minecraft:water[level=0]
fill 283 50 -291 285 50 -291 minecraft:water[level=0]
fill 308 50 -291 309 50 -291 minecraft:water[level=0]
fill 264 50 -292 269 50 -292 minecraft:water[level=0]
fill 309 50 -292 310 50 -292 minecraft:water[level=0]
fill 264 50 -293 266 50 -293 minecraft:water[level=0]
setblock 286 50 -293 minecraft:water[level=0]
setblock 310 50 -293 minecraft:water[level=0]
setblock 311 50 -294 minecraft:water[level=0]
fill 317 50 -300 318 50 -300 minecraft:water[level=0]
fill 318 50 -301 319 50 -301 minecraft:water[level=0]
fill 318 50 -302 320 50 -302 minecraft:water[level=0]
fill 318 50 -303 321 50 -303 minecraft:water[level=0]
fill 319 50 -304 321 50 -304 minecraft:water[level=0]
fill 319 50 -305 321 50 -305 minecraft:water[level=0]
fill 319 50 -306 321 50 -306 minecraft:water[level=0]
fill 319 50 -307 321 50 -307 minecraft:water[level=0]
fill 318 50 -308 321 50 -308 minecraft:water[level=0]
fill 288 49 -255 297 49 -255 minecraft:lava[level=0]
fill 288 49 -256 292 49 -256 minecraft:lava[level=0]
fill 294 49 -256 297 49 -256 minecraft:lava[level=0]
fill 288 49 -257 291 49 -257 minecraft:lava[level=0]
fill 288 49 -258 295 49 -258 minecraft:lava[level=0]
fill 269 49 -259 270 49 -259 minecraft:water[level=0]
fill 288 49 -259 296 49 -259 minecraft:lava[level=0]
fill 268 49 -260 272 49 -260 minecraft:water[level=0]
fill 290 49 -260 296 49 -260 minecraft:lava[level=0]
fill 268 49 -261 271 49 -261 minecraft:water[level=0]
fill 291 49 -261 295 49 -261 minecraft:lava[level=0]
setblock 270 49 -262 minecraft:water[level=0]
fill 296 49 -265 297 49 -265 minecraft:water[level=0]
fill 296 49 -266 298 49 -266 minecraft:water[level=0]
fill 296 49 -267 298 49 -267 minecraft:water[level=0]
fill 296 49 -268 298 49 -268 minecraft:water[level=0]
fill 297 49 -269 298 49 -269 minecraft:water[level=0]
fill 297 49 -270 298 49 -270 minecraft:water[level=0]
fill 297 49 -271 298 49 -271 minecraft:water[level=0]
fill 297 49 -272 298 49 -272 minecraft:water[level=0]
fill 297 49 -273 299 49 -273 minecraft:water[level=0]
fill 297 49 -274 299 49 -274 minecraft:water[level=0]
fill 298 49 -275 299 49 -275 minecraft:water[level=0]
fill 298 49 -276 299 49 -276 minecraft:water[level=0]
fill 298 49 -277 300 49 -277 minecraft:water[level=0]
fill 299 49 -278 300 49 -278 minecraft:water[level=0]
fill 299 49 -279 301 49 -279 minecraft:water[level=0]
fill 299 49 -280 301 49 -280 minecraft:water[level=0]
fill 300 49 -281 302 49 -281 minecraft:water[level=0]
fill 300 49 -282 302 49 -282 minecraft:water[level=0]
fill 301 49 -283 303 49 -283 minecraft:water[level=0]
fill 302 49 -284 303 49 -284 minecraft:water[level=0]
fill 302 49 -285 304 49 -285 minecraft:water[level=0]
fill 303 49 -286 305 49 -286 minecraft:water[level=0]
fill 304 49 -287 305 49 -287 minecraft:water[level=0]
fill 305 49 -288 306 49 -288 minecraft:water[level=0]
fill 266 49 -289 270 49 -289 minecraft:water[level=0]
fill 306 49 -289 307 49 -289 minecraft:water[level=0]
fill 265 49 -290 271 49 -290 minecraft:water[level=0]
fill 307 49 -290 308 49 -290 minecraft:water[level=0]
fill 265 49 -291 272 49 -291 minecraft:water[level=0]
fill 308 49 -291 309 49 -291 minecraft:water[level=0]
fill 265 49 -292 271 49 -292 minecraft:water[level=0]
fill 275 49 -294 276 49 -294 minecraft:water[level=0]
fill 275 49 -295 276 49 -295 minecraft:water[level=0]
setblock 277 49 -298 minecraft:water[level=0]
fill 279 49 -299 280 49 -299 minecraft:water[level=0]
setblock 318 49 -300 minecraft:water[level=0]
setblock 319 49 -301 minecraft:water[level=0]
setblock 319 49 -302 minecraft:water[level=0]
fill 319 49 -303 322 49 -303 minecraft:water[level=0]
fill 319 49 -304 322 49 -304 minecraft:water[level=0]
fill 319 49 -305 322 49 -305 minecraft:water[level=0]
fill 319 49 -306 322 49 -306 minecraft:water[level=0]
fill 319 49 -307 322 49 -307 minecraft:water[level=0]
fill 319 49 -308 322 49 -308 minecraft:water[level=0]
fill 319 49 -309 321 49 -309 minecraft:water[level=0]
fill 291 48 -255 292 48 -255 minecraft:lava[level=0]
fill 295 48 -255 297 48 -255 minecraft:lava[level=0]
setblock 289 48 -257 minecraft:lava[level=0]
fill 269 48 -260 270 48 -260 minecraft:water[level=0]
setblock 271 48 -260 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=true,west=false]
fill 269 48 -261 272 48 -261 minecraft:water[level=0]
fill 268 48 -262 272 48 -262 minecraft:water[level=0]
setblock 271 48 -263 minecraft:water[level=0]
fill 294 48 -263 296 48 -263 minecraft:water[level=0]
fill 295 48 -264 297 48 -264 minecraft:water[level=0]
fill 295 48 -265 297 48 -265 minecraft:water[level=0]
fill 295 48 -266 297 48 -266 minecraft:water[level=0]
fill 295 48 -267 297 48 -267 minecraft:water[level=0]
fill 295 48 -268 297 48 -268 minecraft:water[level=0]
fill 295 48 -269 297 48 -269 minecraft:water[level=0]
fill 295 48 -270 297 48 -270 minecraft:water[level=0]
fill 295 48 -271 297 48 -271 minecraft:water[level=0]
fill 296 48 -272 297 48 -272 minecraft:water[level=0]
fill 296 48 -273 298 48 -273 minecraft:water[level=0]
fill 296 48 -274 298 48 -274 minecraft:water[level=0]
fill 297 48 -275 298 48 -275 minecraft:water[level=0]
fill 297 48 -276 299 48 -276 minecraft:water[level=0]
fill 297 48 -277 299 48 -277 minecraft:water[level=0]
fill 298 48 -278 300 48 -278 minecraft:water[level=0]
fill 298 48 -279 300 48 -279 minecraft:water[level=0]
fill 299 48 -280 301 48 -280 minecraft:water[level=0]
fill 299 48 -281 301 48 -281 minecraft:water[level=0]
fill 300 48 -282 302 48 -282 minecraft:water[level=0]
fill 301 48 -283 303 48 -283 minecraft:water[level=0]
fill 301 48 -284 304 48 -284 minecraft:water[level=0]
fill 302 48 -285 304 48 -285 minecraft:water[level=0]
fill 303 48 -286 305 48 -286 minecraft:water[level=0]
fill 304 48 -287 305 48 -287 minecraft:water[level=0]
fill 305 48 -288 306 48 -288 minecraft:water[level=0]
fill 267 48 -289 271 48 -289 minecraft:water[level=0]
setblock 307 48 -289 minecraft:water[level=0]
fill 266 48 -290 272 48 -290 minecraft:water[level=0]
setblock 308 48 -290 minecraft:water[level=0]
fill 266 48 -291 274 48 -291 minecraft:water[level=0]
setblock 309 48 -291 minecraft:water[level=0]
fill 266 48 -292 275 48 -292 minecraft:water[level=0]
fill 273 48 -293 277 48 -293 minecraft:water[level=0]
setblock 270 48 -294 minecraft:water[level=0]
fill 274 48 -294 277 48 -294 minecraft:water[level=0]
fill 270 48 -295 277 48 -295 minecraft:water[level=0]
fill 271 48 -296 277 48 -296 minecraft:water[level=0]
fill 272 48 -297 278 48 -297 minecraft:water[level=0]
fill 275 48 -298 280 48 -298 minecraft:water[level=0]
fill 277 48 -299 281 48 -299 minecraft:water[level=0]
fill 279 48 -300 283 48 -300 minecraft:water[level=0]
fill 280 48 -301 284 48 -301 minecraft:water[level=0]
fill 282 48 -302 283 48 -302 minecraft:water[level=0]
fill 320 48 -303 321 48 -303 minecraft:water[level=0]
fill 320 48 -304 323 48 -304 minecraft:water[level=0]
fill 320 48 -305 323 48 -305 minecraft:water[level=0]
fill 320 48 -306 323 48 -306 minecraft:water[level=0]
fill 320 48 -307 322 48 -307 minecraft:water[level=0]
fill 320 48 -308 322 48 -308 minecraft:water[level=0]
fill 319 48 -309 322 48 -309 minecraft:water[level=0]
fill 319 48 -310 321 48 -310 minecraft:water[level=0]
setblock 318 48 -311 minecraft:water[level=0]
setblock 270 47 -260 minecraft:water[level=0]
setblock 296 47 -260 minecraft:water[level=0]
fill 269 47 -261 273 47 -261 minecraft:water[level=0]
fill 293 47 -261 296 47 -261 minecraft:water[level=0]
fill 268 47 -262 273 47 -262 minecraft:water[level=0]
fill 293 47 -262 296 47 -262 minecraft:water[level=0]
fill 270 47 -263 272 47 -263 minecraft:water[level=0]
fill 293 47 -263 296 47 -263 minecraft:water[level=0]
fill 293 47 -264 296 47 -264 minecraft:water[level=0]
setblock 264 47 -265 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 294 47 -265 296 47 -265 minecraft:water[level=0]
fill 294 47 -266 296 47 -266 minecraft:water[level=0]
fill 300 47 -266 301 47 -266 minecraft:water[level=0]
fill 294 47 -267 296 47 -267 minecraft:water[level=0]
fill 298 47 -267 300 47 -267 minecraft:water[level=0]
fill 294 47 -268 296 47 -268 minecraft:water[level=0]
setblock 298 47 -268 minecraft:water[level=0]
setblock 296 47 -269 minecraft:water[level=0]
setblock 297 47 -271 minecraft:water[level=0]
setblock 298 47 -274 minecraft:water[level=0]
setblock 298 47 -275 minecraft:water[level=0]
setblock 298 47 -276 minecraft:water[level=0]
fill 298 47 -277 299 47 -277 minecraft:water[level=0]
fill 297 47 -278 299 47 -278 minecraft:water[level=0]
fill 298 47 -279 300 47 -279 minecraft:water[level=0]
fill 298 47 -280 301 47 -280 minecraft:water[level=0]
fill 299 47 -281 301 47 -281 minecraft:water[level=0]
fill 300 47 -282 302 47 -282 minecraft:water[level=0]
fill 301 47 -283 303 47 -283 minecraft:water[level=0]
fill 302 47 -284 304 47 -284 minecraft:water[level=0]
fill 303 47 -285 305 47 -285 minecraft:water[level=0]
fill 304 47 -286 306 47 -286 minecraft:water[level=0]
fill 305 47 -287 306 47 -287 minecraft:water[level=0]
fill 306 47 -288 307 47 -288 minecraft:water[level=0]
fill 268 47 -289 272 47 -289 minecraft:water[level=0]
setblock 308 47 -289 minecraft:water[level=0]
fill 267 47 -290 273 47 -290 minecraft:water[level=0]
fill 267 47 -291 275 47 -291 minecraft:water[level=0]
fill 268 47 -292 276 47 -292 minecraft:water[level=0]
fill 268 47 -293 277 47 -293 minecraft:water[level=0]
fill 268 47 -294 278 47 -294 minecraft:water[level=0]
fill 269 47 -295 278 47 -295 minecraft:water[level=0]
fill 270 47 -296 277 47 -296 minecraft:water[level=0]
fill 271 47 -297 279 47 -297 minecraft:water[level=0]
fill 273 47 -298 281 47 -298 minecraft:water[level=0]
fill 276 47 -299 282 47 -299 minecraft:water[level=0]
fill 278 47 -300 284 47 -300 minecraft:water[level=0]
fill 280 47 -301 285 47 -301 minecraft:water[level=0]
fill 281 47 -302 285 47 -302 minecraft:water[level=0]
fill 321 47 -303 322 47 -303 minecraft:water[level=0]
fill 321 47 -304 324 47 -304 minecraft:water[level=0]
fill 321 47 -305 323 47 -305 minecraft:water[level=0]
fill 321 47 -306 323 47 -306 minecraft:water[level=0]
fill 321 47 -307 323 47 -307 minecraft:water[level=0]
fill 320 47 -308 323 47 -308 minecraft:water[level=0]
fill 320 47 -309 323 47 -309 minecraft:water[level=0]
fill 319 47 -310 322 47 -310 minecraft:water[level=0]
fill 319 47 -311 322 47 -311 minecraft:water[level=0]
fill 319 47 -312 321 47 -312 minecraft:water[level=0]
fill 318 47 -313 319 47 -313 minecraft:water[level=0]
fill 292 46 -259 295 46 -259 minecraft:water[level=0]
fill 291 46 -260 295 46 -260 minecraft:water[level=0]
fill 270 46 -261 274 46 -261 minecraft:water[level=0]
fill 291 46 -261 295 46 -261 minecraft:water[level=0]
fill 269 46 -262 274 46 -262 minecraft:water[level=0]
fill 292 46 -262 295 46 -262 minecraft:water[level=0]
fill 270 46 -263 273 46 -263 minecraft:water[level=0]
fill 292 46 -263 295 46 -263 minecraft:water[level=0]
fill 292 46 -264 295 46 -264 minecraft:water[level=0]
fill 264 46 -265 265 46 -265 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 300 46 -265 302 46 -265 minecraft:water[level=0]
fill 299 46 -266 302 46 -266 minecraft:water[level=0]
fill 298 46 -267 301 46 -267 minecraft:water[level=0]
fill 297 46 -268 299 46 -268 minecraft:water[level=0]
fill 296 46 -269 298 46 -269 minecraft:water[level=0]
fill 296 46 -270 297 46 -270 minecraft:water[level=0]
setblock 296 46 -271 minecraft:water[level=0]
setblock 301 46 -280 minecraft:water[level=0]
fill 301 46 -281 302 46 -281 minecraft:water[level=0]
fill 301 46 -282 303 46 -282 minecraft:water[level=0]
fill 301 46 -283 304 46 -283 minecraft:water[level=0]
fill 302 46 -284 305 46 -284 minecraft:water[level=0]
fill 303 46 -285 306 46 -285 minecraft:water[level=0]
fill 304 46 -286 307 46 -286 minecraft:water[level=0]
fill 306 46 -287 307 46 -287 minecraft:water[level=0]
fill 307 46 -288 308 46 -288 minecraft:water[level=0]
fill 269 46 -289 272 46 -289 minecraft:water[level=0]
fill 267 46 -290 273 46 -290 minecraft:water[level=0]
fill 267 46 -291 275 46 -291 minecraft:water[level=0]
fill 267 46 -292 276 46 -292 minecraft:water[level=0]
fill 267 46 -293 277 46 -293 minecraft:water[level=0]
fill 268 46 -294 278 46 -294 minecraft:water[level=0]
fill 269 46 -295 278 46 -295 minecraft:water[level=0]
setblock 269 46 -296 minecraft:water[level=0]
setblock 270 46 -296 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=false,waterlogged=true,west=false]
fill 271 46 -296 277 46 -296 minecraft:water[level=0]
fill 271 46 -297 279 46 -297 minecraft:water[level=0]
fill 273 46 -298 281 46 -298 minecraft:water[level=0]
fill 276 46 -299 282 46 -299 minecraft:water[level=0]
fill 278 46 -300 286 46 -300 minecraft:water[level=0]
fill 280 46 -301 287 46 -301 minecraft:water[level=0]
fill 281 46 -302 286 46 -302 minecraft:water[level=0]
fill 283 46 -303 284 46 -303 minecraft:water[level=0]
setblock 322 46 -303 minecraft:water[level=0]
fill 322 46 -304 323 46 -304 minecraft:water[level=0]
setblock 324 46 -304 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=true,west=false]
fill 322 46 -305 325 46 -305 minecraft:water[level=0]
fill 321 46 -306 324 46 -306 minecraft:water[level=0]
fill 321 46 -307 324 46 -307 minecraft:water[level=0]
fill 321 46 -308 324 46 -308 minecraft:water[level=0]
fill 321 46 -309 323 46 -309 minecraft:water[level=0]
fill 320 46 -310 323 46 -310 minecraft:water[level=0]
fill 320 46 -311 322 46 -311 minecraft:water[level=0]
fill 319 46 -312 322 46 -312 minecraft:water[level=0]
fill 318 46 -313 321 46 -313 minecraft:water[level=0]
fill 317 46 -314 320 46 -314 minecraft:water[level=0]
fill 317 46 -315 320 46 -315 minecraft:water[level=0]
fill 316 46 -316 318 46 -316 minecraft:water[level=0]
fill 314 46 -317 316 46 -317 minecraft:water[level=0]
fill 313 46 -318 315 46 -318 minecraft:water[level=0]
fill 292 45 -258 293 45 -258 minecraft:water[level=0]
setblock 288 45 -259 minecraft:water[level=0]
fill 291 45 -259 293 45 -259 minecraft:water[level=0]
fill 289 45 -260 293 45 -260 minecraft:water[level=0]
fill 270 45 -261 274 45 -261 minecraft:water[level=0]
fill 289 45 -261 293 45 -261 minecraft:water[level=0]
fill 270 45 -262 275 45 -262 minecraft:water[level=0]
fill 290 45 -262 294 45 -262 minecraft:water[level=0]
fill 269 45 -263 274 45 -263 minecraft:water[level=0]
setblock 290 45 -263 minecraft:water[level=0]
setblock 273 45 -264 minecraft:water[level=0]
fill 300 45 -265 302 45 -265 minecraft:water[level=0]
setblock 265 45 -266 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 298 45 -266 304 45 -266 minecraft:water[level=0]
fill 297 45 -267 305 45 -267 minecraft:water[level=0]
fill 296 45 -268 300 45 -268 minecraft:water[level=0]
fill 304 45 -268 305 45 -268 minecraft:water[level=0]
fill 296 45 -269 298 45 -269 minecraft:water[level=0]
fill 295 45 -270 298 45 -270 minecraft:water[level=0]
fill 295 45 -271 297 45 -271 minecraft:water[level=0]
fill 294 45 -272 296 45 -272 minecraft:water[level=0]
setblock 303 45 -282 minecraft:water[level=0]
fill 303 45 -283 304 45 -283 minecraft:water[level=0]
fill 303 45 -284 306 45 -284 minecraft:water[level=0]
fill 303 45 -285 307 45 -285 minecraft:water[level=0]
fill 305 45 -286 307 45 -286 minecraft:water[level=0]
setblock 268 45 -287 minecraft:water[level=0]
fill 307 45 -287 308 45 -287 minecraft:water[level=0]
fill 267 45 -288 269 45 -288 minecraft:water[level=0]
setblock 308 45 -288 minecraft:water[level=0]
setblock 268 45 -289 minecraft:water[level=0]
fill 271 45 -289 272 45 -289 minecraft:water[level=0]
fill 266 45 -290 268 45 -290 minecraft:water[level=0]
fill 270 45 -290 273 45 -290 minecraft:water[level=0]
fill 266 45 -291 275 45 -291 minecraft:water[level=0]
fill 266 45 -292 276 45 -292 minecraft:water[level=0]
fill 267 45 -293 277 45 -293 minecraft:water[level=0]
fill 268 45 -294 271 45 -294 minecraft:water[level=0]
fill 273 45 -294 278 45 -294 minecraft:water[level=0]
fill 269 45 -295 271 45 -295 minecraft:water[level=0]
fill 274 45 -295 278 45 -295 minecraft:water[level=0]
setblock 270 45 -296 minecraft:water[level=0]
fill 274 45 -296 277 45 -296 minecraft:water[level=0]
fill 281 45 -300 288 45 -300 minecraft:water[level=0]
fill 281 45 -301 288 45 -301 minecraft:water[level=0]
fill 282 45 -302 287 45 -302 minecraft:water[level=0]
fill 284 45 -303 285 45 -303 minecraft:water[level=0]
fill 323 45 -304 324 45 -304 minecraft:water[level=0]
fill 322 45 -305 325 45 -305 minecraft:water[level=0]
fill 322 45 -306 325 45 -306 minecraft:water[level=0]
fill 322 45 -307 325 45 -307 minecraft:water[level=0]
fill 322 45 -308 325 45 -308 minecraft:water[level=0]
fill 321 45 -309 324 45 -309 minecraft:water[level=0]
fill 321 45 -310 323 45 -310 minecraft:water[level=0]
fill 320 45 -311 323 45 -311 minecraft:water[level=0]
fill 320 45 -312 322 45 -312 minecraft:water[level=0]
fill 319 45 -313 322 45 -313 minecraft:water[level=0]
fill 318 45 -314 321 45 -314 minecraft:water[level=0]
fill 317 45 -315 320 45 -315 minecraft:water[level=0]
fill 316 45 -316 319 45 -316 minecraft:water[level=0]
fill 315 45 -317 318 45 -317 minecraft:water[level=0]
fill 313 45 -318 317 45 -318 minecraft:water[level=0]
forceload remove 264 -318 327 -255
tellraw @a {"text":"Campus zurueck a19 fertig.","color":"green"}
