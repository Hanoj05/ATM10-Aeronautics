# Abschnitt a42: x 392..455, z -126..-63 (2321 Blöcke)
forceload add 392 -126 455 -63
tellraw @a {"text":"Campus zurueck a42: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a42_1 2s
