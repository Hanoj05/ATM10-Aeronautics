setblock 11 87 -325 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 11 87 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 86 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 9 86 -323 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 86 -324 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 11 86 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 86 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 86 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 86 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 86 -327 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 85 -322 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 85 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 85 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 85 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 85 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 85 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 85 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 85 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 85 -326 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 85 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 85 -327 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 85 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 85 -327 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 84 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 84 -322 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 84 -323 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 84 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 84 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 84 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 84 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 84 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 84 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 84 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 9 84 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 84 -326 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 84 -326 minecraft:birch_log[axis=y]
setblock 12 84 -326 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 84 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 84 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 84 -327 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 84 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 84 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 83 -319 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 29 83 -320 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 30 83 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 83 -320 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 83 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 83 -322 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 83 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 83 -323 minecraft:birch_log[axis=y]
setblock 9 83 -323 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 83 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 83 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 9 83 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 83 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 83 -326 minecraft:birch_log[axis=y]
setblock 11 83 -329 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 83 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 83 -329 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 83 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 82 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 82 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 82 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 82 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 82 -321 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 82 -323 minecraft:birch_log[axis=y]
setblock 34 82 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 82 -326 minecraft:birch_log[axis=y]
setblock 12 82 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 82 -328 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 82 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 82 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 82 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 82 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 82 -329 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 15 82 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 82 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 82 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 82 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 82 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 82 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 82 -333 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 82 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 82 -334 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 16 82 -335 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 29 81 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 81 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 81 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 81 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 81 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 81 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 81 -321 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 81 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 81 -321 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 81 -323 minecraft:birch_log[axis=y]
setblock 34 81 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 81 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 81 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 81 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 81 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 81 -326 minecraft:birch_log[axis=y]
setblock 11 81 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 81 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 81 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 81 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 81 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 81 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 81 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 81 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 81 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 81 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 81 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 81 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 81 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 81 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 81 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 81 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 81 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 81 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 81 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 81 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 81 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 81 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 81 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 81 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 81 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 81 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 81 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 81 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 29 80 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 80 -319 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 80 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 80 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 80 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 80 -320 minecraft:birch_log[axis=y]
setblock 31 80 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 80 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 80 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 80 -321 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 80 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 80 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 80 -323 minecraft:birch_log[axis=y]
setblock 33 80 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 80 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 80 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 33 80 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 80 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 80 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 80 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 80 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 80 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 80 -326 minecraft:birch_log[axis=y]
setblock 12 80 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 80 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 80 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 80 -328 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 80 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 80 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 80 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 80 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 80 -328 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 80 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 80 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 80 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 80 -329 minecraft:birch_log[axis=y]
setblock 13 80 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 14 80 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 80 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 80 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 80 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 80 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 80 -329 minecraft:birch_log[axis=y]
setblock 38 80 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 80 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 80 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 80 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 80 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 80 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 80 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 80 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 80 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 80 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 80 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 80 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 80 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 80 -333 10 80 -333 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 80 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 80 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 80 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 9 80 -334 10 80 -334 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 80 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 80 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 80 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 80 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 80 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 17 80 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 80 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 20 80 -335 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 19 80 -336 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 30 79 -320 minecraft:birch_log[axis=y]
setblock 34 79 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -323 minecraft:birch_log[axis=y]
setblock 33 79 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 79 -323 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 79 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 32 79 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 79 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 34 79 -324 minecraft:birch_log[axis=y]
setblock 35 79 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 79 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 33 79 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 79 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 79 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 79 -326 minecraft:birch_log[axis=y]
setblock 34 79 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 79 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 14 79 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 79 -328 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 79 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 79 -329 minecraft:birch_log[axis=y]
fill 13 79 -329 14 79 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 15 79 -329 minecraft:birch_log[axis=y]
setblock 16 79 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 79 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 79 -329 minecraft:birch_log[axis=y]
setblock 14 79 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 79 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 79 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 79 -331 10 79 -331 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 79 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -332 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
fill 9 79 -332 10 79 -332 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 79 -332 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 79 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 79 -333 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 79 -333 10 79 -333 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 79 -333 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 79 -333 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 79 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 79 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 79 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 79 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 79 -333 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 79 -334 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 79 -334 10 79 -334 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 79 -334 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 79 -334 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 14 79 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 15 79 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 16 79 -334 minecraft:birch_log[axis=y]
setblock 17 79 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 18 79 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 79 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 79 -335 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
fill 9 79 -335 10 79 -335 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 79 -335 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 15 79 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 79 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 17 79 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 79 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 79 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 79 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 9 79 -336 10 79 -336 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 79 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 79 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 78 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 78 -319 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 61 78 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 78 -320 minecraft:birch_log[axis=y]
setblock 34 78 -320 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 35 78 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 78 -321 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 78 -323 minecraft:birch_log[axis=y]
setblock 34 78 -324 minecraft:birch_log[axis=y]
setblock 11 78 -326 minecraft:birch_log[axis=y]
setblock 40 78 -326 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 40 78 -327 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 41 78 -327 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 40 78 -328 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 78 -329 minecraft:birch_log[axis=y]
setblock 15 78 -329 minecraft:birch_log[axis=y]
setblock 27 78 -329 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 78 -329 minecraft:birch_log[axis=y]
setblock 8 78 -330 minecraft:dark_oak_leaves[distance=4,persistent=false,waterlogged=false]
fill 9 78 -330 10 78 -330 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 78 -330 minecraft:dark_oak_leaves[distance=4,persistent=false,waterlogged=false]
setblock 27 78 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 28 78 -330 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 36 78 -330 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 78 -331 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
fill 9 78 -331 10 78 -331 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 78 -331 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 78 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 36 78 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -332 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 78 -332 10 78 -332 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 78 -332 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 78 -332 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 78 -332 minecraft:dark_oak_leaves[distance=4,persistent=false,waterlogged=false]
setblock 36 78 -332 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 38 78 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -333 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
fill 9 78 -333 10 78 -333 minecraft:dark_oak_log[axis=y]
setblock 11 78 -333 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 78 -333 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 78 -333 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 78 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 78 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 78 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -334 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
fill 9 78 -334 10 78 -334 minecraft:dark_oak_log[axis=y]
setblock 11 78 -334 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 78 -334 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 78 -334 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 78 -334 minecraft:birch_log[axis=y]
setblock 18 78 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 78 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 78 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 78 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -335 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 78 -335 10 78 -335 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 78 -335 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 78 -335 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 78 -335 minecraft:dark_oak_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 78 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 78 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 78 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 78 -336 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
fill 9 78 -336 11 78 -336 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 78 -336 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 13 78 -336 minecraft:dark_oak_leaves[distance=4,persistent=false,waterlogged=false]
setblock 18 78 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 78 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 20 78 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 78 -337 minecraft:dark_oak_leaves[distance=4,persistent=false,waterlogged=false]
setblock 9 78 -337 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 10 78 -337 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 78 -337 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 77 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 61 77 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 77 -320 minecraft:birch_log[axis=y]
setblock 34 77 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 77 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 77 -320 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 77 -321 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 77 -323 minecraft:birch_log[axis=y]
setblock 34 77 -324 minecraft:birch_log[axis=y]
fill 19 77 -325 20 77 -325 minecraft:stone_brick_slab[type=bottom,waterlogged=false]
setblock 11 77 -326 minecraft:birch_log[axis=y]
setblock 40 77 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 77 -327 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 77 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 77 -327 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 77 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 77 -329 minecraft:birch_log[axis=y]
setblock 15 77 -329 minecraft:birch_log[axis=y]
setblock 27 77 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 77 -329 minecraft:birch_log[axis=y]
fill 8 77 -330 9 77 -330 minecraft:dark_oak_leaves[distance=4,persistent=false,waterlogged=false]
setblock 26 77 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 77 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 77 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 77 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 77 -330 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 8 77 -331 10 77 -331 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 77 -331 minecraft:dark_oak_leaves[distance=4,persistent=false,waterlogged=false]
setblock 12 77 -331 minecraft:dark_oak_leaves[distance=5,persistent=false,waterlogged=false]
setblock 27 77 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 77 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 77 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 77 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 77 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 77 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 8 77 -332 10 77 -332 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 77 -332 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 77 -332 minecraft:dark_oak_leaves[distance=4,persistent=false,waterlogged=false]
fill 36 77 -332 37 77 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 77 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 77 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 8 77 -333 10 77 -333 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 77 -333 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 77 -333 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 19 77 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 77 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 25 77 -333 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 77 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 77 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 77 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 77 -334 10 77 -334 minecraft:dark_oak_log[axis=y]
setblock 11 77 -334 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 77 -334 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 77 -334 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 77 -334 minecraft:birch_log[axis=y]
setblock 18 77 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 77 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 77 -334 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 37 77 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 77 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 77 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 77 -335 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
fill 9 77 -335 10 77 -335 minecraft:dark_oak_log[axis=y]
setblock 11 77 -335 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 77 -335 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 77 -335 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 17 77 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 77 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 77 -335 minecraft:birch_log[axis=y]
setblock 20 77 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 21 77 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 77 -336 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 77 -336 11 77 -336 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 12 77 -336 minecraft:dark_oak_leaves[distance=2,persistent=false,waterlogged=false]
setblock 13 77 -336 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 18 77 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 19 77 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 20 77 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 10 77 -337 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 77 -337 minecraft:dark_oak_log[axis=y]
setblock 12 77 -337 minecraft:dark_oak_leaves[distance=1,persistent=false,waterlogged=false]
setblock 19 77 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 76 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 76 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 76 -319 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 47 76 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 60 76 -319 62 76 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 76 -320 minecraft:birch_log[axis=y]
setblock 34 76 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 76 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 76 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 76 -321 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 76 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 76 -321 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 76 -323 minecraft:birch_log[axis=y]
setblock 34 76 -324 minecraft:birch_log[axis=y]
setblock 18 76 -325 minecraft:stone_slab[type=bottom,waterlogged=false]
setblock 11 76 -326 minecraft:birch_log[axis=y]
setblock 39 76 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 76 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 76 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 76 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 76 -327 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 76 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 76 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 76 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 41 76 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 12 76 -329 minecraft:birch_log[axis=y]
setblock 15 76 -329 minecraft:birch_log[axis=y]
setblock 26 76 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 76 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 76 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 76 -329 minecraft:birch_log[axis=y]
setblock 26 76 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 76 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 76 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 76 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 76 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 76 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 76 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 76 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 76 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 76 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 76 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 31 76 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 35 76 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 76 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 37 76 -331 39 76 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 76 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 76 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 76 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 36 76 -332 37 76 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 76 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 76 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -332 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 23 76 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 76 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 76 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 36 76 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 76 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 76 -333 minecraft:birch_log[axis=y]
setblock 39 76 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 76 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 76 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 53 76 -333 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 8 76 -334 minecraft:dark_oak_log[axis=y]
setblock 16 76 -334 minecraft:birch_log[axis=y]
setblock 24 76 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 37 76 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 76 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 76 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 76 -335 10 76 -335 minecraft:dark_oak_log[axis=y]
setblock 19 76 -335 minecraft:birch_log[axis=y]
setblock 38 76 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 76 -336 10 76 -336 minecraft:dark_oak_log[axis=y]
setblock 11 76 -337 minecraft:dark_oak_log[axis=y]
setblock 39 76 -338 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 38 76 -339 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 39 76 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 40 76 -339 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 34 75 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 75 -319 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 75 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 60 75 -319 62 75 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 75 -320 minecraft:birch_log[axis=y]
setblock 33 75 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 34 75 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 35 75 -320 minecraft:birch_log[axis=y]
setblock 36 75 -320 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 75 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 61 75 -320 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 34 75 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 75 -321 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 75 -321 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 75 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 8 75 -323 minecraft:birch_log[axis=y]
setblock 34 75 -324 minecraft:birch_log[axis=y]
fill 18 75 -325 19 75 -325 minecraft:obsidian
setblock 20 75 -325 minecraft:crying_obsidian
setblock 40 75 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 11 75 -326 minecraft:birch_log[axis=y]
setblock 39 75 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 75 -326 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 75 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 75 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -327 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 75 -327 minecraft:birch_log[axis=y]
setblock 41 75 -327 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 42 75 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 75 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 75 -328 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 75 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 12 75 -329 minecraft:birch_log[axis=y]
setblock 15 75 -329 minecraft:birch_log[axis=y]
setblock 26 75 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 75 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 75 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 75 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 75 -329 minecraft:birch_log[axis=y]
setblock 40 75 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 75 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 26 75 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 27 75 -330 minecraft:birch_log[axis=y]
setblock 28 75 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 75 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 75 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 75 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 36 75 -330 37 75 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 38 75 -330 39 75 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 75 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 26 75 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 75 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 28 75 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 75 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 75 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 75 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 34 75 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 35 75 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 36 75 -331 minecraft:birch_log[axis=y]
setblock 37 75 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 38 75 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 75 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 75 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 75 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 75 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 75 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 27 75 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 75 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 35 75 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 75 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 37 75 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 75 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 75 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 75 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 75 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 23 75 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 75 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 75 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 75 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 75 -333 minecraft:birch_log[axis=y]
setblock 51 75 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 75 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 75 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 16 75 -334 minecraft:birch_log[axis=y]
setblock 23 75 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 24 75 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 25 75 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 75 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 9 75 -335 10 75 -335 minecraft:dark_oak_log[axis=y]
setblock 16 75 -335 regions_unexplored:birch_branch[facing=north]
setblock 19 75 -335 minecraft:birch_log[axis=y]
fill 9 75 -336 10 75 -336 minecraft:dark_oak_log[axis=y]
setblock 47 75 -336 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 48 75 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 49 75 -336 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 11 75 -337 minecraft:dark_oak_log[axis=y]
setblock 39 75 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 75 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 75 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 75 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 75 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 8 74 -319 minecraft:short_grass
setblock 10 74 -319 regions_unexplored:grass_sprouts
setblock 51 74 -319 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 74 -320 minecraft:birch_log[axis=y]
setblock 35 74 -320 minecraft:birch_log[axis=y]
setblock 9 74 -321 minecraft:short_grass
setblock 12 74 -321 minecraft:short_grass
setblock 12 74 -322 regions_unexplored:grass_sprouts
setblock 8 74 -323 minecraft:birch_log[axis=y]
setblock 11 74 -324 regions_unexplored:grass_sprouts
setblock 34 74 -324 minecraft:birch_log[axis=y]
setblock 10 74 -325 regions_unexplored:grass_sprouts
setblock 18 74 -325 minecraft:obsidian
setblock 11 74 -326 minecraft:birch_log[axis=y]
setblock 40 74 -327 minecraft:birch_log[axis=y]
setblock 12 74 -329 minecraft:birch_log[axis=y]
setblock 15 74 -329 minecraft:birch_log[axis=y]
setblock 37 74 -329 minecraft:birch_log[axis=y]
setblock 39 74 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 27 74 -330 minecraft:birch_log[axis=y]
setblock 29 74 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 74 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 74 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 74 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 74 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 74 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 74 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 74 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 74 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 74 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 74 -331 minecraft:birch_log[axis=y]
fill 37 74 -331 38 74 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 74 -331 minecraft:birch_log[axis=y]
setblock 40 74 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 74 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 74 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 74 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 74 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 74 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 30 74 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 31 74 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 38 74 -332 39 74 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 74 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 74 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 74 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 22 74 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 23 74 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 24 74 -333 minecraft:birch_log[axis=y]
setblock 25 74 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 26 74 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 74 -333 minecraft:birch_log[axis=y]
setblock 39 74 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 51 74 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 74 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 74 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 74 -334 minecraft:birch_log[axis=y]
setblock 23 74 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 74 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 25 74 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 74 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 74 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 53 74 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 9 74 -335 10 74 -335 minecraft:dark_oak_log[axis=y]
setblock 19 74 -335 minecraft:birch_log[axis=y]
setblock 24 74 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 74 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 9 74 -336 10 74 -336 minecraft:dark_oak_log[axis=y]
setblock 47 74 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 74 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 74 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 11 74 -337 minecraft:dark_oak_log[axis=y]
setblock 48 74 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 74 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 74 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 74 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 74 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 74 -339 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 74 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 74 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 39 74 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 40 74 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 8 73 -319 12 73 -319 minecraft:grass_block[snowy=false]
setblock 13 73 -319 minecraft:netherrack
fill 8 73 -320 14 73 -320 minecraft:grass_block[snowy=false]
setblock 15 73 -320 regions_unexplored:grass_sprouts
setblock 30 73 -320 minecraft:birch_log[axis=y]
setblock 35 73 -320 minecraft:birch_log[axis=y]
fill 8 73 -321 13 73 -321 minecraft:grass_block[snowy=false]
fill 8 73 -322 11 73 -322 minecraft:grass_block[snowy=false]
fill 12 73 -322 13 73 -322 minecraft:netherrack
setblock 14 73 -322 regions_unexplored:grass_sprouts
setblock 8 73 -323 minecraft:dirt
fill 9 73 -323 10 73 -323 minecraft:grass_block[snowy=false]
fill 11 73 -323 13 73 -323 minecraft:netherrack
setblock 14 73 -323 regions_unexplored:grass_sprouts
setblock 18 73 -323 minecraft:netherrack
setblock 23 73 -323 minecraft:stone_brick_slab[type=bottom,waterlogged=false]
setblock 8 73 -324 minecraft:grass_block[snowy=false]
setblock 9 73 -324 minecraft:magma_block
fill 10 73 -324 11 73 -324 minecraft:netherrack
setblock 12 73 -324 minecraft:magma_block
setblock 34 73 -324 minecraft:birch_log[axis=y]
fill 8 73 -325 9 73 -325 minecraft:grass_block[snowy=false]
setblock 10 73 -325 minecraft:netherrack
fill 11 73 -325 12 73 -325 minecraft:grass_block[snowy=false]
setblock 18 73 -325 minecraft:crying_obsidian
setblock 21 73 -325 minecraft:crying_obsidian
setblock 11 73 -326 minecraft:birch_log[axis=y]
setblock 40 73 -327 minecraft:birch_log[axis=y]
setblock 12 73 -329 minecraft:birch_log[axis=y]
setblock 15 73 -329 minecraft:birch_log[axis=y]
setblock 30 73 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 73 -329 minecraft:birch_log[axis=y]
setblock 27 73 -330 minecraft:birch_log[axis=y]
setblock 29 73 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 73 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 73 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 28 73 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 29 73 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 30 73 -331 minecraft:birch_log[axis=y]
setblock 31 73 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 32 73 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 36 73 -331 minecraft:birch_log[axis=y]
setblock 39 73 -331 minecraft:birch_log[axis=y]
setblock 52 73 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 55 73 -331 56 73 -331 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 29 73 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 30 73 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 31 73 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 73 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 73 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 73 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 24 73 -333 minecraft:birch_log[axis=y]
setblock 30 73 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 73 -333 minecraft:birch_log[axis=y]
setblock 50 73 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 51 73 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 52 73 -333 minecraft:birch_log[axis=y]
setblock 53 73 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 54 73 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 16 73 -334 productivebees:birch_wood_nest[axis=y,facing=north]
setblock 51 73 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 52 73 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 53 73 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 73 -335 10 73 -335 minecraft:dark_oak_log[axis=y]
setblock 19 73 -335 minecraft:birch_log[axis=y]
setblock 47 73 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 73 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 73 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 52 73 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 73 -336 10 73 -336 minecraft:dark_oak_log[axis=y]
setblock 47 73 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 73 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 73 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 73 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 73 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 48 73 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 49 73 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 38 73 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 73 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 73 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 37 73 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 73 -339 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 39 73 -339 minecraft:birch_log[axis=y]
setblock 40 73 -339 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 41 73 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 38 73 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 73 -340 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 40 73 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 39 73 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 8 72 -319 12 72 -319 minecraft:dirt
fill 13 72 -319 19 72 -319 minecraft:netherrack
fill 8 72 -320 14 72 -320 minecraft:dirt
fill 15 72 -320 20 72 -320 minecraft:netherrack
setblock 30 72 -320 minecraft:birch_log[axis=y]
setblock 35 72 -320 minecraft:birch_log[axis=y]
fill 8 72 -321 13 72 -321 minecraft:dirt
setblock 14 72 -321 minecraft:netherrack
setblock 15 72 -321 minecraft:grass_block[snowy=false]
fill 16 72 -321 18 72 -321 minecraft:netherrack
fill 19 72 -321 20 72 -321 minecraft:lava[level=0]
fill 21 72 -321 22 72 -321 minecraft:netherrack
fill 8 72 -322 11 72 -322 minecraft:dirt
fill 12 72 -322 19 72 -322 minecraft:netherrack
setblock 20 72 -322 minecraft:lava[level=0]
setblock 21 72 -322 minecraft:magma_block
setblock 22 72 -322 minecraft:stone_bricks
setblock 23 72 -322 minecraft:netherrack
fill 8 72 -323 10 72 -323 minecraft:dirt
setblock 11 72 -323 minecraft:netherrack
setblock 12 72 -323 minecraft:magma_block
fill 13 72 -323 19 72 -323 minecraft:netherrack
fill 20 72 -323 21 72 -323 minecraft:lava[level=0]
setblock 22 72 -323 minecraft:obsidian
setblock 23 72 -323 minecraft:netherrack
setblock 8 72 -324 minecraft:dirt
setblock 9 72 -324 minecraft:magma_block
fill 10 72 -324 16 72 -324 minecraft:netherrack
fill 17 72 -324 22 72 -324 minecraft:lava[level=0]
setblock 23 72 -324 minecraft:netherrack
setblock 34 72 -324 minecraft:birch_log[axis=y]
fill 8 72 -325 9 72 -325 minecraft:dirt
setblock 10 72 -325 minecraft:netherrack
fill 11 72 -325 12 72 -325 minecraft:dirt
fill 13 72 -325 17 72 -325 minecraft:netherrack
setblock 18 72 -325 minecraft:obsidian
fill 19 72 -325 20 72 -325 minecraft:lava[level=0]
setblock 21 72 -325 minecraft:obsidian
setblock 22 72 -325 minecraft:lava[level=0]
setblock 23 72 -325 minecraft:netherrack
fill 8 72 -326 10 72 -326 minecraft:grass_block[snowy=false]
setblock 11 72 -326 minecraft:dirt
setblock 12 72 -326 minecraft:grass_block[snowy=false]
setblock 13 72 -326 minecraft:netherrack
setblock 14 72 -326 minecraft:grass_block[snowy=false]
fill 15 72 -326 17 72 -326 minecraft:netherrack
fill 18 72 -326 21 72 -326 minecraft:lava[level=0]
fill 22 72 -326 23 72 -326 minecraft:netherrack
fill 8 72 -327 11 72 -327 minecraft:grass_block[snowy=false]
setblock 12 72 -327 minecraft:netherrack
setblock 13 72 -327 minecraft:grass_block[snowy=false]
fill 14 72 -327 18 72 -327 minecraft:netherrack
setblock 19 72 -327 minecraft:magma_block
fill 20 72 -327 22 72 -327 minecraft:netherrack
setblock 40 72 -327 minecraft:birch_log[axis=y]
fill 8 72 -328 12 72 -328 minecraft:grass_block[snowy=false]
setblock 13 72 -328 minecraft:netherrack
fill 14 72 -328 15 72 -328 minecraft:grass_block[snowy=false]
setblock 16 72 -328 minecraft:magma_block
setblock 18 72 -328 lootr:lootr_chest[facing=north,type=single,waterlogged=false]
fill 8 72 -329 11 72 -329 minecraft:grass_block[snowy=false]
setblock 12 72 -329 minecraft:dirt
setblock 13 72 -329 minecraft:grass_block[snowy=false]
setblock 14 72 -329 minecraft:netherrack
setblock 15 72 -329 minecraft:dirt
setblock 18 72 -329 minecraft:air
setblock 37 72 -329 minecraft:birch_log[axis=y]
setblock 9 72 -330 minecraft:short_grass
setblock 11 72 -330 regions_unexplored:grass_sprouts
setblock 27 72 -330 minecraft:birch_log[axis=y]
setblock 56 72 -330 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 13 72 -331 minecraft:short_grass
setblock 30 72 -331 minecraft:birch_log[axis=y]
setblock 36 72 -331 minecraft:birch_log[axis=y]
setblock 39 72 -331 minecraft:birch_log[axis=y]
fill 55 72 -331 57 72 -331 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 10 72 -332 regions_unexplored:grass_sprouts
setblock 56 72 -332 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 11 72 -333 regions_unexplored:grass_sprouts
setblock 24 72 -333 minecraft:birch_log[axis=y]
setblock 38 72 -333 minecraft:birch_log[axis=y]
setblock 52 72 -333 minecraft:birch_log[axis=y]
setblock 16 72 -334 minecraft:birch_log[axis=y]
setblock 48 72 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 72 -335 10 72 -335 minecraft:dark_oak_log[axis=y]
setblock 19 72 -335 minecraft:birch_log[axis=y]
setblock 47 72 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 72 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 72 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 9 72 -336 10 72 -336 minecraft:dark_oak_log[axis=y]
setblock 13 72 -336 regions_unexplored:birch_shrub[half=upper]
setblock 46 72 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 72 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 48 72 -336 minecraft:birch_log[axis=y]
setblock 49 72 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 50 72 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 47 72 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 72 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 49 72 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 48 72 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 18 72 -339 minecraft:air
setblock 39 72 -339 minecraft:birch_log[axis=y]
setblock 18 72 -349 minecraft:air
setblock 18 72 -359 minecraft:air
setblock 18 72 -369 minecraft:air
setblock 18 72 -379 minecraft:air
fill 8 71 -319 13 71 -319 minecraft:dirt
fill 14 71 -319 22 71 -319 minecraft:netherrack
fill 23 71 -319 24 71 -319 minecraft:grass_block[snowy=false]
setblock 25 71 -319 minecraft:netherrack
setblock 26 71 -319 minecraft:grass_block[snowy=false]
fill 8 71 -320 14 71 -320 minecraft:dirt
fill 15 71 -320 20 71 -320 minecraft:netherrack
setblock 21 71 -320 minecraft:magma_block
fill 22 71 -320 24 71 -320 minecraft:netherrack
setblock 25 71 -320 minecraft:grass_block[snowy=false]
setblock 30 71 -320 minecraft:birch_log[axis=y]
setblock 35 71 -320 minecraft:birch_log[axis=y]
fill 8 71 -321 13 71 -321 minecraft:dirt
setblock 14 71 -321 minecraft:netherrack
setblock 15 71 -321 minecraft:dirt
fill 16 71 -321 25 71 -321 minecraft:netherrack
fill 8 71 -322 11 71 -322 minecraft:dirt
setblock 12 71 -322 minecraft:netherrack
setblock 13 71 -322 minecraft:dirt
fill 14 71 -322 15 71 -322 minecraft:netherrack
setblock 16 71 -322 minecraft:magma_block
fill 17 71 -322 24 71 -322 minecraft:netherrack
fill 8 71 -323 10 71 -323 minecraft:dirt
setblock 11 71 -323 minecraft:magma_block
setblock 12 71 -323 minecraft:dirt
setblock 13 71 -323 minecraft:magma_block
fill 14 71 -323 17 71 -323 minecraft:netherrack
setblock 18 71 -323 minecraft:magma_block
fill 19 71 -323 24 71 -323 minecraft:netherrack
fill 8 71 -324 10 71 -324 minecraft:dirt
setblock 11 71 -324 minecraft:netherrack
setblock 12 71 -324 minecraft:dirt
fill 13 71 -324 14 71 -324 minecraft:netherrack
setblock 15 71 -324 minecraft:magma_block
fill 16 71 -324 17 71 -324 minecraft:netherrack
fill 18 71 -324 19 71 -324 minecraft:magma_block
fill 20 71 -324 24 71 -324 minecraft:netherrack
setblock 34 71 -324 minecraft:birch_log[axis=y]
fill 8 71 -325 9 71 -325 minecraft:dirt
setblock 10 71 -325 minecraft:netherrack
fill 11 71 -325 12 71 -325 minecraft:dirt
fill 13 71 -325 14 71 -325 minecraft:netherrack
setblock 15 71 -325 minecraft:magma_block
fill 16 71 -325 17 71 -325 minecraft:netherrack
setblock 18 71 -325 minecraft:crying_obsidian
fill 19 71 -325 20 71 -325 minecraft:obsidian
fill 21 71 -325 24 71 -325 minecraft:netherrack
fill 8 71 -326 12 71 -326 minecraft:dirt
setblock 13 71 -326 minecraft:netherrack
setblock 14 71 -326 minecraft:dirt
setblock 15 71 -326 minecraft:magma_block
fill 16 71 -326 24 71 -326 minecraft:netherrack
fill 8 71 -327 11 71 -327 minecraft:dirt
setblock 12 71 -327 minecraft:magma_block
setblock 13 71 -327 minecraft:dirt
fill 14 71 -327 23 71 -327 minecraft:netherrack
setblock 40 71 -327 minecraft:birch_log[axis=y]
fill 8 71 -328 12 71 -328 minecraft:dirt
setblock 13 71 -328 minecraft:netherrack
fill 14 71 -328 15 71 -328 minecraft:dirt
fill 16 71 -328 18 71 -328 minecraft:netherrack
setblock 19 71 -328 minecraft:magma_block
fill 20 71 -328 23 71 -328 minecraft:netherrack
fill 8 71 -329 13 71 -329 minecraft:dirt
setblock 14 71 -329 minecraft:netherrack
setblock 15 71 -329 minecraft:dirt
fill 16 71 -329 18 71 -329 minecraft:netherrack
setblock 19 71 -329 minecraft:grass_block[snowy=false]
setblock 20 71 -329 minecraft:magma_block
setblock 37 71 -329 minecraft:birch_log[axis=y]
fill 8 71 -330 15 71 -330 minecraft:grass_block[snowy=false]
fill 16 71 -330 19 71 -330 minecraft:netherrack
setblock 20 71 -330 regions_unexplored:grass_sprouts
setblock 27 71 -330 minecraft:birch_log[axis=y]
fill 55 71 -330 57 71 -330 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 71 -331 16 71 -331 minecraft:grass_block[snowy=false]
fill 17 71 -331 18 71 -331 minecraft:netherrack
setblock 30 71 -331 minecraft:birch_log[axis=y]
setblock 36 71 -331 minecraft:birch_log[axis=y]
setblock 39 71 -331 minecraft:birch_log[axis=y]
fill 55 71 -331 57 71 -331 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 71 -332 17 71 -332 minecraft:grass_block[snowy=false]
fill 55 71 -332 57 71 -332 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 10 71 -333 15 71 -333 minecraft:grass_block[snowy=false]
setblock 24 71 -333 minecraft:birch_log[axis=y]
setblock 38 71 -333 minecraft:birch_log[axis=y]
setblock 52 71 -333 minecraft:birch_log[axis=y]
setblock 10 71 -334 regions_unexplored:grass_sprouts
setblock 16 71 -334 minecraft:birch_log[axis=y]
fill 9 71 -335 10 71 -335 minecraft:dark_oak_log[axis=y]
setblock 11 71 -335 minecraft:short_grass
setblock 19 71 -335 minecraft:birch_log[axis=y]
fill 9 71 -336 10 71 -336 minecraft:dark_oak_log[axis=y]
setblock 11 71 -336 regions_unexplored:grass_sprouts
setblock 12 71 -336 minecraft:short_grass
setblock 13 71 -336 regions_unexplored:birch_shrub[half=lower]
setblock 48 71 -336 minecraft:birch_log[axis=y]
setblock 18 71 -337 minecraft:air
fill 17 71 -338 19 71 -338 minecraft:air
fill 16 71 -339 20 71 -339 minecraft:air
setblock 39 71 -339 minecraft:birch_log[axis=y]
fill 17 71 -340 19 71 -340 minecraft:air
setblock 18 71 -341 minecraft:air
setblock 18 71 -347 minecraft:air
fill 17 71 -348 19 71 -348 minecraft:air
fill 16 71 -349 20 71 -349 minecraft:air
fill 17 71 -350 19 71 -350 minecraft:air
setblock 18 71 -351 minecraft:air
setblock 18 71 -357 minecraft:air
fill 17 71 -358 19 71 -358 minecraft:air
fill 16 71 -359 20 71 -359 minecraft:air
fill 17 71 -360 19 71 -360 minecraft:air
setblock 18 71 -361 minecraft:air
setblock 18 71 -367 minecraft:air
fill 17 71 -368 19 71 -368 minecraft:air
fill 16 71 -369 20 71 -369 minecraft:air
fill 17 71 -370 19 71 -370 minecraft:air
setblock 18 71 -371 minecraft:air
setblock 18 71 -377 minecraft:air
fill 17 71 -378 19 71 -378 minecraft:air
fill 16 71 -379 20 71 -379 minecraft:air
fill 17 71 -380 19 71 -380 minecraft:air
setblock 18 71 -381 minecraft:air
fill 8 70 -319 13 70 -319 minecraft:dirt
setblock 14 70 -319 minecraft:netherrack
fill 15 70 -319 18 70 -319 minecraft:dirt
fill 19 70 -319 22 70 -319 minecraft:netherrack
fill 23 70 -319 24 70 -319 minecraft:dirt
setblock 25 70 -319 minecraft:netherrack
setblock 26 70 -319 minecraft:dirt
setblock 27 70 -319 minecraft:magma_block
fill 28 70 -319 32 70 -319 minecraft:grass_block[snowy=false]
setblock 64 70 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 71 70 -319 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -320 14 70 -320 minecraft:dirt
setblock 15 70 -320 minecraft:netherrack
fill 16 70 -320 18 70 -320 minecraft:dirt
fill 19 70 -320 23 70 -320 minecraft:netherrack
setblock 24 70 -320 minecraft:magma_block
setblock 25 70 -320 minecraft:dirt
setblock 26 70 -320 minecraft:netherrack
fill 27 70 -320 29 70 -320 minecraft:grass_block[snowy=false]
setblock 30 70 -320 minecraft:dirt
fill 31 70 -320 32 70 -320 minecraft:grass_block[snowy=false]
setblock 35 70 -320 minecraft:birch_log[axis=y]
fill 8 70 -321 16 70 -321 minecraft:dirt
fill 17 70 -321 18 70 -321 minecraft:netherrack
setblock 19 70 -321 minecraft:magma_block
fill 20 70 -321 26 70 -321 minecraft:netherrack
fill 27 70 -321 32 70 -321 minecraft:grass_block[snowy=false]
fill 8 70 -322 13 70 -322 minecraft:dirt
setblock 14 70 -322 minecraft:magma_block
fill 15 70 -322 16 70 -322 minecraft:netherrack
setblock 17 70 -322 minecraft:magma_block
setblock 18 70 -322 minecraft:netherrack
setblock 19 70 -322 minecraft:magma_block
fill 20 70 -322 25 70 -322 minecraft:netherrack
setblock 26 70 -322 minecraft:magma_block
setblock 27 70 -322 minecraft:grass_block[snowy=false]
setblock 28 70 -322 minecraft:netherrack
setblock 29 70 -322 minecraft:grass_block[snowy=false]
setblock 30 70 -322 minecraft:netherrack
fill 31 70 -322 32 70 -322 minecraft:grass_block[snowy=false]
fill 8 70 -323 10 70 -323 minecraft:dirt
setblock 11 70 -323 minecraft:netherrack
setblock 12 70 -323 minecraft:dirt
fill 13 70 -323 25 70 -323 minecraft:netherrack
fill 26 70 -323 27 70 -323 minecraft:grass_block[snowy=false]
fill 28 70 -323 30 70 -323 minecraft:netherrack
fill 31 70 -323 32 70 -323 minecraft:grass_block[snowy=false]
fill 8 70 -324 12 70 -324 minecraft:dirt
setblock 13 70 -324 minecraft:netherrack
fill 14 70 -324 16 70 -324 minecraft:dirt
setblock 17 70 -324 minecraft:netherrack
fill 18 70 -324 19 70 -324 minecraft:dirt
fill 20 70 -324 27 70 -324 minecraft:netherrack
setblock 29 70 -324 minecraft:netherrack
fill 30 70 -324 33 70 -324 minecraft:grass_block[snowy=false]
setblock 34 70 -324 minecraft:birch_log[axis=y]
fill 8 70 -325 13 70 -325 minecraft:dirt
fill 14 70 -325 17 70 -325 minecraft:netherrack
fill 18 70 -325 20 70 -325 minecraft:dirt
fill 21 70 -325 26 70 -325 minecraft:netherrack
fill 8 70 -326 12 70 -326 minecraft:dirt
setblock 13 70 -326 minecraft:netherrack
fill 14 70 -326 15 70 -326 minecraft:dirt
fill 16 70 -326 21 70 -326 minecraft:netherrack
setblock 22 70 -326 minecraft:magma_block
fill 23 70 -326 25 70 -326 minecraft:netherrack
fill 8 70 -327 13 70 -327 minecraft:dirt
fill 14 70 -327 15 70 -327 minecraft:netherrack
setblock 16 70 -327 minecraft:dirt
fill 17 70 -327 24 70 -327 minecraft:netherrack
setblock 40 70 -327 minecraft:birch_log[axis=y]
fill 8 70 -328 12 70 -328 minecraft:dirt
setblock 13 70 -328 minecraft:netherrack
fill 14 70 -328 16 70 -328 minecraft:dirt
setblock 17 70 -328 minecraft:magma_block
fill 18 70 -328 23 70 -328 minecraft:netherrack
fill 8 70 -329 13 70 -329 minecraft:dirt
setblock 14 70 -329 minecraft:netherrack
setblock 15 70 -329 minecraft:dirt
fill 16 70 -329 18 70 -329 minecraft:netherrack
setblock 19 70 -329 minecraft:dirt
fill 20 70 -329 23 70 -329 minecraft:netherrack
setblock 37 70 -329 minecraft:birch_log[axis=y]
setblock 56 70 -329 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -330 15 70 -330 minecraft:dirt
setblock 16 70 -330 minecraft:netherrack
setblock 17 70 -330 minecraft:magma_block
fill 18 70 -330 21 70 -330 minecraft:netherrack
setblock 22 70 -330 minecraft:grass_block[snowy=false]
setblock 27 70 -330 minecraft:birch_log[axis=y]
fill 55 70 -330 57 70 -330 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -331 16 70 -331 minecraft:dirt
fill 17 70 -331 21 70 -331 minecraft:netherrack
setblock 30 70 -331 minecraft:birch_log[axis=y]
setblock 36 70 -331 minecraft:birch_log[axis=y]
setblock 39 70 -331 minecraft:birch_log[axis=y]
fill 54 70 -331 55 70 -331 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 56 70 -331 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 57 70 -331 58 70 -331 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -332 17 70 -332 minecraft:dirt
setblock 18 70 -332 minecraft:netherrack
fill 19 70 -332 20 70 -332 minecraft:grass_block[snowy=false]
setblock 52 70 -332 regions_unexplored:birch_branch[facing=south]
fill 55 70 -332 57 70 -332 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -333 9 70 -333 minecraft:grass_block[snowy=false]
fill 10 70 -333 15 70 -333 minecraft:dirt
fill 16 70 -333 17 70 -333 minecraft:grass_block[snowy=false]
fill 18 70 -333 19 70 -333 minecraft:netherrack
setblock 23 70 -333 regions_unexplored:grass_sprouts
setblock 24 70 -333 minecraft:birch_log[axis=y]
setblock 38 70 -333 minecraft:birch_log[axis=y]
setblock 52 70 -333 minecraft:birch_log[axis=y]
setblock 56 70 -333 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 8 70 -334 15 70 -334 minecraft:grass_block[snowy=false]
setblock 16 70 -334 minecraft:dirt
fill 17 70 -334 18 70 -334 minecraft:grass_block[snowy=false]
setblock 21 70 -334 regions_unexplored:grass_sprouts
setblock 8 70 -335 minecraft:grass_block[snowy=false]
fill 9 70 -335 10 70 -335 minecraft:dirt
fill 11 70 -335 17 70 -335 minecraft:grass_block[snowy=false]
setblock 19 70 -335 minecraft:birch_log[axis=y]
setblock 8 70 -336 minecraft:grass_block[snowy=false]
fill 9 70 -336 10 70 -336 minecraft:dirt
fill 11 70 -336 14 70 -336 minecraft:grass_block[snowy=false]
setblock 48 70 -336 minecraft:birch_log[axis=y]
setblock 11 70 -337 minecraft:short_grass
setblock 14 70 -337 regions_unexplored:grass_sprouts
fill 17 70 -337 19 70 -337 minecraft:air
fill 16 70 -338 20 70 -338 minecraft:air
setblock 16 70 -339 minecraft:air
setblock 17 70 -339 regions_unexplored:grass_sprouts
fill 18 70 -339 20 70 -339 minecraft:air
setblock 39 70 -339 minecraft:birch_log[axis=y]
fill 16 70 -340 20 70 -340 minecraft:air
fill 17 70 -341 19 70 -341 minecraft:air
fill 17 70 -347 19 70 -347 minecraft:air
fill 16 70 -348 20 70 -348 minecraft:air
fill 16 70 -349 20 70 -349 minecraft:air
fill 16 70 -350 20 70 -350 minecraft:air
fill 17 70 -351 19 70 -351 minecraft:air
fill 17 70 -357 19 70 -357 minecraft:air
fill 16 70 -358 20 70 -358 minecraft:air
fill 16 70 -359 20 70 -359 minecraft:air
fill 16 70 -360 20 70 -360 minecraft:air
fill 17 70 -361 19 70 -361 minecraft:air
fill 17 70 -367 19 70 -367 minecraft:air
fill 16 70 -368 20 70 -368 minecraft:air
fill 16 70 -369 20 70 -369 minecraft:air
fill 16 70 -370 20 70 -370 minecraft:air
fill 17 70 -371 19 70 -371 minecraft:air
fill 17 70 -377 19 70 -377 minecraft:air
fill 16 70 -378 20 70 -378 minecraft:air
fill 16 70 -379 20 70 -379 minecraft:air
fill 16 70 -380 20 70 -380 minecraft:air
fill 17 70 -381 19 70 -381 minecraft:air
fill 8 69 -319 20 69 -319 minecraft:dirt
fill 21 69 -319 22 69 -319 minecraft:netherrack
fill 23 69 -319 24 69 -319 minecraft:dirt
setblock 25 69 -319 minecraft:netherrack
setblock 26 69 -319 minecraft:dirt
setblock 27 69 -319 minecraft:netherrack
fill 28 69 -319 32 69 -319 minecraft:dirt
fill 33 69 -319 37 69 -319 minecraft:grass_block[snowy=false]
fill 8 69 -320 19 69 -320 minecraft:dirt
fill 20 69 -320 21 69 -320 minecraft:netherrack
fill 22 69 -320 23 69 -320 minecraft:dirt
setblock 24 69 -320 minecraft:netherrack
setblock 25 69 -320 minecraft:dirt
setblock 26 69 -320 minecraft:netherrack
fill 27 69 -320 32 69 -320 minecraft:dirt
fill 33 69 -320 34 69 -320 minecraft:grass_block[snowy=false]
setblock 35 69 -320 minecraft:dirt
setblock 36 69 -320 minecraft:grass_block[snowy=false]
fill 8 69 -321 16 69 -321 minecraft:dirt
setblock 17 69 -321 minecraft:netherrack
setblock 18 69 -321 minecraft:magma_block
fill 19 69 -321 24 69 -321 minecraft:netherrack
setblock 25 69 -321 minecraft:dirt
setblock 26 69 -321 minecraft:netherrack
fill 27 69 -321 32 69 -321 minecraft:dirt
fill 33 69 -321 36 69 -321 minecraft:grass_block[snowy=false]
setblock 37 69 -321 regions_unexplored:grass_sprouts
fill 8 69 -322 13 69 -322 minecraft:dirt
fill 14 69 -322 17 69 -322 minecraft:netherrack
setblock 18 69 -322 minecraft:dirt
fill 19 69 -322 22 69 -322 minecraft:netherrack
setblock 23 69 -322 minecraft:dirt
fill 24 69 -322 26 69 -322 minecraft:netherrack
setblock 27 69 -322 minecraft:dirt
setblock 28 69 -322 minecraft:netherrack
setblock 29 69 -322 minecraft:dirt
setblock 30 69 -322 minecraft:netherrack
fill 31 69 -322 32 69 -322 minecraft:dirt
fill 33 69 -322 36 69 -322 minecraft:grass_block[snowy=false]
fill 8 69 -323 12 69 -323 minecraft:dirt
fill 13 69 -323 14 69 -323 minecraft:netherrack
setblock 15 69 -323 minecraft:dirt
setblock 16 69 -323 minecraft:netherrack
fill 17 69 -323 19 69 -323 minecraft:dirt
fill 20 69 -323 21 69 -323 minecraft:netherrack
setblock 22 69 -323 minecraft:dirt
fill 23 69 -323 25 69 -323 minecraft:netherrack
fill 26 69 -323 27 69 -323 minecraft:dirt
fill 28 69 -323 30 69 -323 minecraft:netherrack
fill 31 69 -323 32 69 -323 minecraft:dirt
fill 33 69 -323 36 69 -323 minecraft:grass_block[snowy=false]
setblock 40 69 -323 minecraft:short_grass
fill 8 69 -324 19 69 -324 minecraft:dirt
setblock 20 69 -324 minecraft:netherrack
fill 21 69 -324 22 69 -324 minecraft:dirt
fill 23 69 -324 29 69 -324 minecraft:netherrack
fill 30 69 -324 34 69 -324 minecraft:dirt
fill 35 69 -324 36 69 -324 minecraft:grass_block[snowy=false]
fill 8 69 -325 14 69 -325 minecraft:dirt
setblock 15 69 -325 minecraft:netherrack
setblock 16 69 -325 minecraft:dirt
setblock 17 69 -325 minecraft:netherrack
fill 18 69 -325 20 69 -325 minecraft:dirt
fill 21 69 -325 26 69 -325 minecraft:netherrack
setblock 27 69 -325 minecraft:magma_block
setblock 28 69 -325 minecraft:netherrack
setblock 29 69 -325 minecraft:grass_block[snowy=false]
setblock 30 69 -325 minecraft:netherrack
fill 31 69 -325 36 69 -325 minecraft:grass_block[snowy=false]
setblock 38 69 -325 regions_unexplored:grass_sprouts
fill 8 69 -326 12 69 -326 minecraft:dirt
setblock 13 69 -326 minecraft:netherrack
fill 14 69 -326 15 69 -326 minecraft:dirt
setblock 16 69 -326 minecraft:netherrack
setblock 17 69 -326 minecraft:dirt
setblock 18 69 -326 minecraft:netherrack
setblock 19 69 -326 minecraft:dirt
fill 20 69 -326 26 69 -326 minecraft:netherrack
setblock 27 69 -326 minecraft:grass_block[snowy=false]
fill 28 69 -326 29 69 -326 minecraft:netherrack
fill 30 69 -326 36 69 -326 minecraft:grass_block[snowy=false]
setblock 37 69 -326 regions_unexplored:grass_sprouts
fill 8 69 -327 14 69 -327 minecraft:dirt
setblock 15 69 -327 minecraft:netherrack
setblock 16 69 -327 minecraft:dirt
fill 17 69 -327 27 69 -327 minecraft:netherrack
fill 28 69 -327 36 69 -327 minecraft:grass_block[snowy=false]
setblock 40 69 -327 minecraft:birch_log[axis=y]
fill 8 69 -328 16 69 -328 minecraft:dirt
fill 17 69 -328 19 69 -328 minecraft:netherrack
setblock 20 69 -328 minecraft:dirt
fill 21 69 -328 24 69 -328 minecraft:netherrack
setblock 25 69 -328 minecraft:grass_block[snowy=false]
setblock 26 69 -328 minecraft:netherrack
setblock 27 69 -328 minecraft:magma_block
fill 8 69 -329 13 69 -329 minecraft:dirt
setblock 14 69 -329 minecraft:magma_block
setblock 15 69 -329 minecraft:dirt
setblock 16 69 -329 minecraft:magma_block
fill 17 69 -329 20 69 -329 minecraft:dirt
fill 21 69 -329 25 69 -329 minecraft:netherrack
setblock 26 69 -329 minecraft:grass_block[snowy=false]
setblock 35 69 -329 minecraft:short_grass
setblock 37 69 -329 minecraft:birch_log[axis=y]
fill 8 69 -330 19 69 -330 minecraft:dirt
fill 20 69 -330 21 69 -330 minecraft:netherrack
setblock 22 69 -330 minecraft:dirt
setblock 23 69 -330 minecraft:grass_block[snowy=false]
fill 24 69 -330 25 69 -330 minecraft:netherrack
setblock 26 69 -330 minecraft:grass_block[snowy=false]
setblock 27 69 -330 minecraft:birch_log[axis=y]
fill 8 69 -331 16 69 -331 minecraft:dirt
setblock 17 69 -331 minecraft:netherrack
setblock 18 69 -331 minecraft:dirt
fill 19 69 -331 22 69 -331 minecraft:netherrack
fill 23 69 -331 25 69 -331 minecraft:grass_block[snowy=false]
setblock 30 69 -331 minecraft:birch_log[axis=y]
setblock 36 69 -331 minecraft:birch_log[axis=y]
setblock 39 69 -331 minecraft:birch_log[axis=y]
setblock 56 69 -331 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 69 -332 17 69 -332 minecraft:dirt
setblock 18 69 -332 minecraft:netherrack
fill 19 69 -332 20 69 -332 minecraft:dirt
fill 21 69 -332 23 69 -332 minecraft:grass_block[snowy=false]
setblock 24 69 -332 minecraft:netherrack
setblock 27 69 -332 minecraft:dandelion
fill 8 69 -333 17 69 -333 minecraft:dirt
fill 18 69 -333 20 69 -333 minecraft:netherrack
setblock 21 69 -333 minecraft:grass_block[snowy=false]
fill 22 69 -333 23 69 -333 minecraft:netherrack
setblock 24 69 -333 minecraft:birch_log[axis=y]
setblock 38 69 -333 minecraft:birch_log[axis=y]
setblock 52 69 -333 minecraft:birch_log[axis=y]
setblock 53 69 -333 regions_unexplored:birch_branch[facing=east]
fill 8 69 -334 18 69 -334 minecraft:dirt
setblock 19 69 -334 minecraft:grass_block[snowy=false]
fill 20 69 -334 21 69 -334 minecraft:netherrack
setblock 22 69 -334 minecraft:grass_block[snowy=false]
fill 8 69 -335 17 69 -335 minecraft:dirt
setblock 18 69 -335 minecraft:grass_block[snowy=false]
setblock 19 69 -335 minecraft:dirt
fill 20 69 -335 21 69 -335 minecraft:grass_block[snowy=false]
fill 8 69 -336 14 69 -336 minecraft:dirt
fill 15 69 -336 20 69 -336 minecraft:grass_block[snowy=false]
setblock 48 69 -336 minecraft:birch_log[axis=y]
setblock 9 69 -337 regions_unexplored:grass_sprouts
fill 10 69 -337 19 69 -337 minecraft:grass_block[snowy=false]
setblock 48 69 -337 regions_unexplored:birch_branch[facing=north]
fill 12 69 -338 18 69 -338 minecraft:grass_block[snowy=false]
setblock 19 69 -338 minecraft:air
setblock 20 69 -338 minecraft:short_grass
setblock 21 69 -338 regions_unexplored:grass_sprouts
setblock 13 69 -339 regions_unexplored:grass_sprouts
fill 15 69 -339 17 69 -339 minecraft:grass_block[snowy=false]
setblock 18 69 -339 minecraft:air
setblock 19 69 -339 regions_unexplored:grass_sprouts
setblock 20 69 -339 minecraft:air
setblock 39 69 -339 minecraft:birch_log[axis=y]
setblock 16 69 -340 minecraft:grass_block[snowy=false]
setblock 17 69 -340 regions_unexplored:grass_sprouts
fill 18 69 -340 19 69 -340 minecraft:air
setblock 18 69 -341 minecraft:air
setblock 18 69 -347 minecraft:air
fill 17 69 -348 19 69 -348 minecraft:air
fill 16 69 -349 20 69 -349 minecraft:air
fill 17 69 -350 19 69 -350 minecraft:air
setblock 18 69 -351 minecraft:air
setblock 18 69 -357 minecraft:air
fill 17 69 -358 19 69 -358 minecraft:air
fill 16 69 -359 20 69 -359 minecraft:air
fill 17 69 -360 19 69 -360 minecraft:air
setblock 18 69 -361 minecraft:air
setblock 18 69 -367 minecraft:air
fill 17 69 -368 19 69 -368 minecraft:air
fill 16 69 -369 20 69 -369 minecraft:air
fill 17 69 -370 19 69 -370 minecraft:air
setblock 18 69 -371 minecraft:air
setblock 18 69 -377 minecraft:air
fill 17 69 -378 19 69 -378 minecraft:air
fill 16 69 -379 20 69 -379 minecraft:air
fill 17 69 -380 19 69 -380 minecraft:air
setblock 18 69 -381 minecraft:air
fill 8 68 -319 13 68 -319 minecraft:stone
fill 14 68 -319 21 68 -319 minecraft:dirt
setblock 22 68 -319 minecraft:magma_block
fill 23 68 -319 26 68 -319 minecraft:dirt
setblock 27 68 -319 minecraft:netherrack
fill 29 68 -319 37 68 -319 minecraft:dirt
fill 38 68 -319 42 68 -319 minecraft:grass_block[snowy=false]
setblock 45 68 -319 regions_unexplored:grass_sprouts
fill 8 68 -320 14 68 -320 minecraft:stone
fill 15 68 -320 19 68 -320 minecraft:dirt
setblock 20 68 -320 minecraft:netherrack
fill 21 68 -320 23 68 -320 minecraft:dirt
setblock 24 68 -320 minecraft:netherrack
setblock 25 68 -320 minecraft:dirt
setblock 26 68 -320 minecraft:netherrack
fill 27 68 -320 36 68 -320 minecraft:dirt
fill 37 68 -320 42 68 -320 minecraft:grass_block[snowy=false]
setblock 8 68 -321 minecraft:iron_ore
fill 9 68 -321 13 68 -321 minecraft:stone
fill 14 68 -321 17 68 -321 minecraft:dirt
setblock 18 68 -321 minecraft:magma_block
fill 19 68 -321 20 68 -321 minecraft:dirt
fill 21 68 -321 23 68 -321 minecraft:netherrack
fill 24 68 -321 36 68 -321 minecraft:dirt
fill 37 68 -321 41 68 -321 minecraft:grass_block[snowy=false]
fill 8 68 -322 13 68 -322 minecraft:stone
fill 14 68 -322 24 68 -322 minecraft:dirt
setblock 25 68 -322 minecraft:netherrack
fill 26 68 -322 27 68 -322 minecraft:dirt
setblock 28 68 -322 minecraft:netherrack
setblock 29 68 -322 minecraft:dirt
setblock 30 68 -322 minecraft:netherrack
fill 31 68 -322 36 68 -322 minecraft:dirt
fill 37 68 -322 40 68 -322 minecraft:grass_block[snowy=false]
fill 8 68 -323 13 68 -323 minecraft:stone
setblock 14 68 -323 minecraft:netherrack
setblock 15 68 -323 minecraft:dirt
setblock 16 68 -323 minecraft:netherrack
fill 17 68 -323 19 68 -323 minecraft:dirt
setblock 20 68 -323 minecraft:magma_block
fill 21 68 -323 23 68 -323 minecraft:dirt
setblock 24 68 -323 minecraft:netherrack
fill 25 68 -323 27 68 -323 minecraft:dirt
fill 28 68 -323 30 68 -323 minecraft:netherrack
fill 31 68 -323 36 68 -323 minecraft:dirt
fill 37 68 -323 40 68 -323 minecraft:grass_block[snowy=false]
fill 8 68 -324 12 68 -324 minecraft:stone
fill 13 68 -324 19 68 -324 minecraft:dirt
setblock 20 68 -324 minecraft:netherrack
fill 21 68 -324 23 68 -324 minecraft:dirt
fill 24 68 -324 25 68 -324 minecraft:netherrack
fill 26 68 -324 27 68 -324 minecraft:dirt
setblock 28 68 -324 minecraft:netherrack
setblock 29 68 -324 minecraft:magma_block
fill 30 68 -324 36 68 -324 minecraft:dirt
fill 37 68 -324 39 68 -324 minecraft:grass_block[snowy=false]
setblock 40 68 -324 minecraft:short_grass
setblock 41 68 -324 regions_unexplored:grass_sprouts
fill 8 68 -325 12 68 -325 minecraft:stone
fill 13 68 -325 20 68 -325 minecraft:dirt
fill 21 68 -325 24 68 -325 minecraft:netherrack
fill 25 68 -325 26 68 -325 minecraft:dirt
fill 27 68 -325 28 68 -325 minecraft:netherrack
setblock 29 68 -325 minecraft:dirt
setblock 30 68 -325 minecraft:netherrack
fill 31 68 -325 36 68 -325 minecraft:dirt
fill 37 68 -325 39 68 -325 minecraft:grass_block[snowy=false]
fill 8 68 -326 15 68 -326 minecraft:dirt
setblock 16 68 -326 minecraft:netherrack
fill 17 68 -326 21 68 -326 minecraft:dirt
fill 22 68 -326 26 68 -326 minecraft:netherrack
setblock 27 68 -326 minecraft:dirt
fill 28 68 -326 29 68 -326 minecraft:netherrack
fill 30 68 -326 36 68 -326 minecraft:dirt
fill 37 68 -326 39 68 -326 minecraft:grass_block[snowy=false]
setblock 41 68 -326 regions_unexplored:grass_sprouts
fill 8 68 -327 16 68 -327 minecraft:dirt
fill 17 68 -327 19 68 -327 minecraft:netherrack
setblock 20 68 -327 minecraft:dirt
fill 21 68 -327 22 68 -327 minecraft:netherrack
fill 23 68 -327 24 68 -327 minecraft:dirt
fill 25 68 -327 27 68 -327 minecraft:netherrack
fill 28 68 -327 36 68 -327 minecraft:dirt
fill 37 68 -327 38 68 -327 minecraft:grass_block[snowy=false]
setblock 40 68 -327 minecraft:birch_log[axis=y]
fill 8 68 -328 16 68 -328 minecraft:dirt
setblock 17 68 -328 minecraft:netherrack
setblock 18 68 -328 minecraft:dirt
setblock 19 68 -328 minecraft:netherrack
setblock 20 68 -328 minecraft:dirt
fill 21 68 -328 22 68 -328 minecraft:netherrack
setblock 23 68 -328 minecraft:dirt
setblock 24 68 -328 minecraft:netherrack
setblock 25 68 -328 minecraft:dirt
fill 26 68 -328 27 68 -328 minecraft:netherrack
fill 28 68 -328 38 68 -328 minecraft:grass_block[snowy=false]
fill 8 68 -329 20 68 -329 minecraft:dirt
setblock 21 68 -329 minecraft:netherrack
setblock 22 68 -329 minecraft:dirt
setblock 23 68 -329 minecraft:magma_block
fill 24 68 -329 25 68 -329 minecraft:netherrack
setblock 26 68 -329 minecraft:dirt
fill 27 68 -329 36 68 -329 minecraft:grass_block[snowy=false]
setblock 37 68 -329 minecraft:dirt
fill 8 68 -330 20 68 -330 minecraft:dirt
setblock 21 68 -330 minecraft:netherrack
fill 22 68 -330 23 68 -330 minecraft:dirt
setblock 24 68 -330 minecraft:magma_block
setblock 25 68 -330 minecraft:netherrack
fill 26 68 -330 27 68 -330 minecraft:dirt
fill 28 68 -330 31 68 -330 minecraft:grass_block[snowy=false]
fill 35 68 -330 36 68 -330 minecraft:grass_block[snowy=false]
setblock 56 68 -330 regions_unexplored:silver_birch_log[axis=z,is_base=false]
fill 8 68 -331 16 68 -331 minecraft:dirt
setblock 17 68 -331 minecraft:netherrack
setblock 18 68 -331 minecraft:dirt
setblock 19 68 -331 minecraft:netherrack
setblock 20 68 -331 minecraft:dirt
fill 21 68 -331 22 68 -331 minecraft:netherrack
fill 23 68 -331 25 68 -331 minecraft:dirt
fill 26 68 -331 29 68 -331 minecraft:grass_block[snowy=false]
setblock 30 68 -331 minecraft:birch_log[axis=y]
setblock 36 68 -331 minecraft:birch_log[axis=y]
setblock 39 68 -331 minecraft:birch_log[axis=y]
setblock 56 68 -331 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 68 -332 17 68 -332 minecraft:dirt
setblock 18 68 -332 minecraft:netherrack
fill 19 68 -332 23 68 -332 minecraft:dirt
setblock 24 68 -332 minecraft:netherrack
fill 25 68 -332 28 68 -332 minecraft:grass_block[snowy=false]
fill 8 68 -333 17 68 -333 minecraft:dirt
fill 18 68 -333 19 68 -333 minecraft:netherrack
setblock 20 68 -333 alltheores:nether_fluorite_ore
setblock 21 68 -333 minecraft:dirt
fill 22 68 -333 23 68 -333 minecraft:netherrack
setblock 24 68 -333 minecraft:dirt
fill 25 68 -333 26 68 -333 minecraft:grass_block[snowy=false]
setblock 38 68 -333 minecraft:birch_log[axis=y]
setblock 52 68 -333 minecraft:birch_log[axis=y]
fill 8 68 -334 19 68 -334 minecraft:dirt
fill 20 68 -334 21 68 -334 alltheores:nether_fluorite_ore
setblock 22 68 -334 minecraft:dirt
fill 23 68 -334 25 68 -334 minecraft:grass_block[snowy=false]
fill 8 68 -335 21 68 -335 minecraft:dirt
fill 22 68 -335 23 68 -335 minecraft:grass_block[snowy=false]
fill 8 68 -336 20 68 -336 minecraft:dirt
fill 21 68 -336 22 68 -336 minecraft:grass_block[snowy=false]
setblock 32 68 -336 minecraft:peony[half=upper]
setblock 48 68 -336 minecraft:birch_log[axis=y]
fill 8 68 -337 9 68 -337 minecraft:grass_block[snowy=false]
fill 10 68 -337 19 68 -337 minecraft:dirt
fill 20 68 -337 22 68 -337 minecraft:grass_block[snowy=false]
setblock 23 68 -337 regions_unexplored:grass_sprouts
setblock 11 68 -338 minecraft:grass_block[snowy=false]
fill 12 68 -338 18 68 -338 minecraft:dirt
fill 19 68 -338 22 68 -338 minecraft:grass_block[snowy=false]
fill 12 68 -339 14 68 -339 minecraft:grass_block[snowy=false]
fill 15 68 -339 17 68 -339 minecraft:dirt
fill 18 68 -339 21 68 -339 minecraft:grass_block[snowy=false]
setblock 39 68 -339 minecraft:birch_log[axis=y]
fill 14 68 -340 15 68 -340 minecraft:grass_block[snowy=false]
setblock 16 68 -340 minecraft:dirt
fill 17 68 -340 21 68 -340 minecraft:grass_block[snowy=false]
setblock 18 68 -349 minecraft:air
setblock 18 68 -359 minecraft:air
setblock 18 68 -369 minecraft:air
setblock 18 68 -379 minecraft:air
setblock 8 67 -319 minecraft:coal_ore
fill 9 67 -319 19 67 -319 minecraft:stone
fill 20 67 -319 21 67 -319 minecraft:dirt
setblock 22 67 -319 minecraft:netherrack
setblock 23 67 -319 minecraft:dirt
setblock 27 67 -319 minecraft:magma_block
fill 32 67 -319 42 67 -319 minecraft:dirt
fill 43 67 -319 48 67 -319 minecraft:grass_block[snowy=false]
setblock 58 67 -319 regions_unexplored:meadow_sage[half=upper]
fill 8 67 -320 19 67 -320 minecraft:stone
setblock 20 67 -320 minecraft:netherrack
fill 21 67 -320 25 67 -320 minecraft:dirt
setblock 26 67 -320 minecraft:magma_block
fill 30 67 -320 42 67 -320 minecraft:dirt
fill 43 67 -320 46 67 -320 minecraft:grass_block[snowy=false]
fill 47 67 -320 48 67 -320 minecraft:sand
setblock 58 67 -320 regions_unexplored:meadow_sage[half=upper]
fill 8 67 -321 19 67 -321 minecraft:stone
fill 20 67 -321 22 67 -321 minecraft:dirt
setblock 23 67 -321 minecraft:netherrack
fill 24 67 -321 41 67 -321 minecraft:dirt
fill 42 67 -321 46 67 -321 minecraft:grass_block[snowy=false]
fill 8 67 -322 19 67 -322 minecraft:stone
fill 20 67 -322 24 67 -322 minecraft:dirt
setblock 25 67 -322 minecraft:netherrack
fill 26 67 -322 40 67 -322 minecraft:dirt
fill 41 67 -322 44 67 -322 minecraft:grass_block[snowy=false]
fill 8 67 -323 13 67 -323 minecraft:stone
setblock 14 67 -323 minecraft:netherrack
setblock 15 67 -323 minecraft:stone
setblock 16 67 -323 minecraft:netherrack
fill 17 67 -323 19 67 -323 minecraft:stone
fill 20 67 -323 23 67 -323 minecraft:dirt
setblock 24 67 -323 minecraft:netherrack
fill 25 67 -323 27 67 -323 minecraft:dirt
fill 28 67 -323 29 67 -323 minecraft:netherrack
fill 30 67 -323 40 67 -323 minecraft:dirt
fill 41 67 -323 43 67 -323 minecraft:grass_block[snowy=false]
setblock 47 67 -323 regions_unexplored:grass_sprouts
fill 8 67 -324 19 67 -324 minecraft:stone
setblock 20 67 -324 minecraft:netherrack
setblock 21 67 -324 minecraft:dirt
setblock 22 67 -324 minecraft:stone
fill 23 67 -324 24 67 -324 minecraft:dirt
setblock 25 67 -324 minecraft:netherrack
fill 26 67 -324 27 67 -324 minecraft:dirt
setblock 28 67 -324 minecraft:netherrack
fill 29 67 -324 39 67 -324 minecraft:dirt
fill 40 67 -324 42 67 -324 minecraft:grass_block[snowy=false]
setblock 43 67 -324 minecraft:short_grass
fill 8 67 -325 13 67 -325 minecraft:stone
fill 14 67 -325 15 67 -325 minecraft:dirt
fill 16 67 -325 18 67 -325 minecraft:stone
fill 19 67 -325 20 67 -325 minecraft:dirt
setblock 21 67 -325 minecraft:netherrack
setblock 22 67 -325 minecraft:stone
fill 23 67 -325 24 67 -325 minecraft:netherrack
fill 25 67 -325 39 67 -325 minecraft:dirt
fill 40 67 -325 41 67 -325 minecraft:grass_block[snowy=false]
fill 8 67 -326 13 67 -326 minecraft:stone
fill 14 67 -326 15 67 -326 minecraft:dirt
setblock 16 67 -326 minecraft:netherrack
setblock 17 67 -326 minecraft:stone
setblock 18 67 -326 minecraft:dirt
fill 19 67 -326 21 67 -326 minecraft:stone
setblock 22 67 -326 minecraft:netherrack
setblock 23 67 -326 minecraft:magma_block
setblock 24 67 -326 minecraft:netherrack
fill 25 67 -326 27 67 -326 minecraft:dirt
fill 28 67 -326 29 67 -326 minecraft:netherrack
fill 30 67 -326 39 67 -326 minecraft:dirt
fill 40 67 -326 41 67 -326 minecraft:grass_block[snowy=false]
fill 8 67 -327 12 67 -327 minecraft:stone
fill 13 67 -327 16 67 -327 minecraft:dirt
setblock 17 67 -327 minecraft:netherrack
setblock 18 67 -327 minecraft:magma_block
setblock 19 67 -327 minecraft:netherrack
setblock 20 67 -327 minecraft:dirt
setblock 21 67 -327 minecraft:netherrack
fill 22 67 -327 25 67 -327 minecraft:dirt
setblock 26 67 -327 minecraft:netherrack
fill 27 67 -327 38 67 -327 minecraft:dirt
setblock 39 67 -327 minecraft:grass_block[snowy=false]
setblock 40 67 -327 minecraft:dirt
fill 8 67 -328 12 67 -328 minecraft:stone
fill 13 67 -328 18 67 -328 minecraft:dirt
setblock 19 67 -328 minecraft:netherrack
setblock 20 67 -328 minecraft:stone
setblock 21 67 -328 minecraft:netherrack
fill 22 67 -328 23 67 -328 minecraft:dirt
setblock 24 67 -328 minecraft:netherrack
fill 25 67 -328 38 67 -328 minecraft:dirt
fill 39 67 -328 40 67 -328 minecraft:grass_block[snowy=false]
setblock 42 67 -328 regions_unexplored:grass_sprouts
fill 8 67 -329 12 67 -329 minecraft:stone
fill 13 67 -329 18 67 -329 minecraft:dirt
fill 19 67 -329 20 67 -329 minecraft:stone
setblock 21 67 -329 minecraft:netherrack
fill 22 67 -329 24 67 -329 minecraft:dirt
setblock 25 67 -329 minecraft:netherrack
fill 26 67 -329 37 67 -329 minecraft:dirt
fill 38 67 -329 40 67 -329 minecraft:grass_block[snowy=false]
fill 8 67 -330 17 67 -330 minecraft:dirt
fill 18 67 -330 19 67 -330 minecraft:stone
fill 20 67 -330 24 67 -330 minecraft:dirt
setblock 25 67 -330 minecraft:netherrack
fill 26 67 -330 31 67 -330 minecraft:dirt
fill 32 67 -330 34 67 -330 minecraft:grass_block[snowy=false]
fill 35 67 -330 36 67 -330 minecraft:dirt
fill 37 67 -330 39 67 -330 minecraft:grass_block[snowy=false]
fill 8 67 -331 17 67 -331 minecraft:dirt
setblock 18 67 -331 minecraft:stone
fill 19 67 -331 21 67 -331 minecraft:dirt
setblock 22 67 -331 minecraft:netherrack
fill 23 67 -331 30 67 -331 minecraft:dirt
fill 31 67 -331 35 67 -331 minecraft:grass_block[snowy=false]
setblock 36 67 -331 minecraft:dirt
setblock 37 67 -331 minecraft:grass_block[snowy=false]
setblock 39 67 -331 minecraft:birch_log[axis=y]
setblock 56 67 -331 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 67 -332 16 67 -332 minecraft:dirt
setblock 17 67 -332 minecraft:stone
setblock 18 67 -332 minecraft:netherrack
fill 19 67 -332 23 67 -332 minecraft:dirt
setblock 24 67 -332 minecraft:netherrack
fill 25 67 -332 28 67 -332 minecraft:dirt
fill 29 67 -332 31 67 -332 minecraft:grass_block[snowy=false]
setblock 36 67 -332 minecraft:grass_block[snowy=false]
fill 8 67 -333 17 67 -333 minecraft:dirt
setblock 18 67 -333 minecraft:netherrack
fill 19 67 -333 26 67 -333 minecraft:dirt
fill 27 67 -333 30 67 -333 minecraft:grass_block[snowy=false]
setblock 38 67 -333 minecraft:birch_log[axis=y]
setblock 52 67 -333 minecraft:birch_log[axis=y]
fill 8 67 -334 19 67 -334 minecraft:dirt
setblock 20 67 -334 alltheores:nether_fluorite_ore
fill 21 67 -334 25 67 -334 minecraft:dirt
fill 26 67 -334 29 67 -334 minecraft:grass_block[snowy=false]
fill 8 67 -335 23 67 -335 minecraft:dirt
fill 24 67 -335 27 67 -335 minecraft:grass_block[snowy=false]
fill 8 67 -336 22 67 -336 minecraft:dirt
fill 23 67 -336 25 67 -336 minecraft:grass_block[snowy=false]
setblock 32 67 -336 minecraft:peony[half=lower]
setblock 48 67 -336 minecraft:birch_log[axis=y]
fill 8 67 -337 22 67 -337 minecraft:dirt
fill 23 67 -337 24 67 -337 minecraft:grass_block[snowy=false]
fill 9 67 -338 10 67 -338 minecraft:grass_block[snowy=false]
fill 11 67 -338 22 67 -338 minecraft:dirt
fill 23 67 -338 24 67 -338 minecraft:grass_block[snowy=false]
setblock 11 67 -339 minecraft:grass_block[snowy=false]
fill 12 67 -339 21 67 -339 minecraft:dirt
fill 22 67 -339 24 67 -339 minecraft:grass_block[snowy=false]
setblock 25 67 -339 minecraft:peony[half=upper]
setblock 39 67 -339 minecraft:birch_log[axis=y]
setblock 13 67 -340 minecraft:grass_block[snowy=false]
fill 14 67 -340 21 67 -340 minecraft:dirt
fill 22 67 -340 24 67 -340 minecraft:grass_block[snowy=false]
setblock 18 67 -349 minecraft:air
setblock 18 67 -359 minecraft:air
setblock 18 67 -369 minecraft:air
setblock 18 67 -379 minecraft:air
setblock 8 66 -319 minecraft:coal_ore
fill 9 66 -319 22 66 -319 minecraft:stone
setblock 27 66 -319 minecraft:netherrack
fill 33 66 -319 48 66 -319 minecraft:dirt
fill 49 66 -319 54 66 -319 minecraft:grass_block[snowy=false]
setblock 58 66 -319 regions_unexplored:meadow_sage[half=lower]
setblock 61 66 -319 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 62 66 -319 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
fill 8 66 -320 24 66 -320 minecraft:stone
setblock 26 66 -320 minecraft:netherrack
fill 32 66 -320 46 66 -320 minecraft:dirt
fill 47 66 -320 50 66 -320 minecraft:sand
fill 51 66 -320 54 66 -320 minecraft:grass_block[snowy=false]
setblock 58 66 -320 regions_unexplored:meadow_sage[half=lower]
fill 8 66 -321 22 66 -321 minecraft:stone
setblock 23 66 -321 minecraft:netherrack
fill 24 66 -321 25 66 -321 minecraft:stone
fill 26 66 -321 46 66 -321 minecraft:dirt
fill 47 66 -321 51 66 -321 minecraft:sand
setblock 52 66 -321 minecraft:grass_block[snowy=false]
setblock 53 66 -321 minecraft:sand
fill 8 66 -322 16 66 -322 minecraft:stone
setblock 17 66 -322 minecraft:copper_ore
fill 18 66 -322 24 66 -322 minecraft:stone
fill 25 66 -322 44 66 -322 minecraft:dirt
fill 45 66 -322 46 66 -322 minecraft:grass_block[snowy=false]
fill 47 66 -322 52 66 -322 minecraft:sand
fill 8 66 -323 15 66 -323 minecraft:stone
setblock 16 66 -323 minecraft:netherrack
fill 17 66 -323 23 66 -323 minecraft:stone
fill 24 66 -323 43 66 -323 minecraft:dirt
fill 44 66 -323 47 66 -323 minecraft:grass_block[snowy=false]
setblock 48 66 -323 minecraft:sand
fill 8 66 -324 13 66 -324 minecraft:stone
fill 14 66 -324 16 66 -324 minecraft:dirt
fill 17 66 -324 22 66 -324 minecraft:stone
fill 23 66 -324 24 66 -324 minecraft:dirt
fill 25 66 -324 26 66 -324 minecraft:stone
setblock 27 66 -324 minecraft:dirt
setblock 28 66 -324 minecraft:netherrack
fill 29 66 -324 42 66 -324 minecraft:dirt
fill 43 66 -324 46 66 -324 minecraft:grass_block[snowy=false]
fill 8 66 -325 13 66 -325 minecraft:stone
fill 14 66 -325 16 66 -325 minecraft:dirt
fill 17 66 -325 20 66 -325 minecraft:stone
setblock 21 66 -325 minecraft:netherrack
setblock 22 66 -325 minecraft:stone
fill 23 66 -325 24 66 -325 minecraft:netherrack
fill 25 66 -325 26 66 -325 minecraft:stone
fill 27 66 -325 41 66 -325 minecraft:dirt
fill 42 66 -325 44 66 -325 minecraft:grass_block[snowy=false]
setblock 45 66 -325 regions_unexplored:grass_sprouts
setblock 47 66 -325 minecraft:short_grass
setblock 48 66 -325 regions_unexplored:grass_sprouts
fill 8 66 -326 12 66 -326 minecraft:stone
fill 13 66 -326 15 66 -326 minecraft:dirt
setblock 16 66 -326 minecraft:magma_block
fill 17 66 -326 22 66 -326 minecraft:stone
setblock 23 66 -326 minecraft:netherrack
fill 24 66 -326 25 66 -326 minecraft:stone
fill 26 66 -326 28 66 -326 minecraft:dirt
setblock 29 66 -326 minecraft:netherrack
fill 30 66 -326 41 66 -326 minecraft:dirt
fill 42 66 -326 43 66 -326 minecraft:grass_block[snowy=false]
fill 8 66 -327 12 66 -327 minecraft:stone
fill 13 66 -327 16 66 -327 minecraft:dirt
setblock 17 66 -327 minecraft:stone
setblock 18 66 -327 minecraft:netherrack
fill 19 66 -327 20 66 -327 minecraft:stone
setblock 21 66 -327 minecraft:netherrack
fill 22 66 -327 24 66 -327 minecraft:stone
fill 25 66 -327 40 66 -327 minecraft:dirt
fill 41 66 -327 42 66 -327 minecraft:grass_block[snowy=false]
fill 8 66 -328 12 66 -328 minecraft:stone
fill 13 66 -328 16 66 -328 minecraft:dirt
fill 17 66 -328 18 66 -328 minecraft:stone
setblock 19 66 -328 minecraft:netherrack
setblock 20 66 -328 minecraft:stone
setblock 21 66 -328 minecraft:netherrack
fill 22 66 -328 23 66 -328 minecraft:stone
setblock 24 66 -328 minecraft:netherrack
fill 25 66 -328 40 66 -328 minecraft:dirt
fill 41 66 -328 42 66 -328 minecraft:grass_block[snowy=false]
fill 8 66 -329 12 66 -329 minecraft:stone
fill 13 66 -329 16 66 -329 minecraft:dirt
fill 17 66 -329 23 66 -329 minecraft:stone
setblock 24 66 -329 minecraft:dirt
setblock 25 66 -329 minecraft:netherrack
fill 26 66 -329 40 66 -329 minecraft:dirt
setblock 41 66 -329 minecraft:grass_block[snowy=false]
setblock 43 66 -329 minecraft:short_grass
fill 8 66 -330 12 66 -330 minecraft:stone
fill 13 66 -330 16 66 -330 minecraft:dirt
fill 17 66 -330 22 66 -330 minecraft:stone
fill 23 66 -330 39 66 -330 minecraft:dirt
fill 40 66 -330 41 66 -330 minecraft:grass_block[snowy=false]
fill 8 66 -331 12 66 -331 minecraft:stone
fill 13 66 -331 15 66 -331 minecraft:dirt
fill 16 66 -331 19 66 -331 minecraft:stone
fill 20 66 -331 21 66 -331 alltheores:fluorite_ore
fill 22 66 -331 37 66 -331 minecraft:dirt
setblock 38 66 -331 minecraft:grass_block[snowy=false]
setblock 39 66 -331 minecraft:dirt
setblock 40 66 -331 minecraft:grass_block[snowy=false]
setblock 56 66 -331 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 8 66 -332 12 66 -332 minecraft:stone
fill 13 66 -332 15 66 -332 minecraft:dirt
fill 16 66 -332 17 66 -332 minecraft:stone
setblock 18 66 -332 minecraft:netherrack
fill 19 66 -332 20 66 -332 alltheores:fluorite_ore
fill 21 66 -332 31 66 -332 minecraft:dirt
fill 32 66 -332 35 66 -332 minecraft:grass_block[snowy=false]
setblock 36 66 -332 minecraft:dirt
fill 37 66 -332 39 66 -332 minecraft:grass_block[snowy=false]
fill 8 66 -333 9 66 -333 minecraft:dirt
fill 10 66 -333 12 66 -333 minecraft:stone
fill 13 66 -333 15 66 -333 minecraft:dirt
fill 16 66 -333 18 66 -333 minecraft:stone
setblock 19 66 -333 alltheores:fluorite_ore
fill 20 66 -333 30 66 -333 minecraft:dirt
fill 31 66 -333 37 66 -333 minecraft:grass_block[snowy=false]
setblock 38 66 -333 minecraft:dirt
setblock 52 66 -333 minecraft:birch_log[axis=y]
fill 8 66 -334 13 66 -334 minecraft:dirt
fill 14 66 -334 18 66 -334 minecraft:stone
setblock 19 66 -334 minecraft:dirt
setblock 20 66 -334 alltheores:nether_fluorite_ore
fill 21 66 -334 29 66 -334 minecraft:dirt
fill 30 66 -334 36 66 -334 minecraft:grass_block[snowy=false]
fill 8 66 -335 10 66 -335 minecraft:dirt
setblock 11 66 -335 minecraft:stone
setblock 12 66 -335 minecraft:dirt
fill 13 66 -335 17 66 -335 minecraft:stone
fill 18 66 -335 27 66 -335 minecraft:dirt
fill 28 66 -335 33 66 -335 minecraft:grass_block[snowy=false]
setblock 34 66 -335 regions_unexplored:grass_sprouts
setblock 36 66 -335 minecraft:dandelion
setblock 8 66 -336 minecraft:stone
setblock 9 66 -336 minecraft:dirt
fill 10 66 -336 14 66 -336 minecraft:stone
fill 15 66 -336 25 66 -336 minecraft:dirt
fill 26 66 -336 32 66 -336 minecraft:grass_block[snowy=false]
setblock 48 66 -336 minecraft:birch_log[axis=y]
fill 8 66 -337 24 66 -337 minecraft:dirt
setblock 25 66 -337 minecraft:grass_block[snowy=false]
setblock 35 66 -337 minecraft:peony[half=upper]
setblock 8 66 -338 minecraft:grass_block[snowy=false]
fill 9 66 -338 24 66 -338 minecraft:dirt
setblock 25 66 -338 minecraft:short_grass
fill 11 66 -339 24 66 -339 minecraft:dirt
setblock 25 66 -339 minecraft:peony[half=lower]
setblock 39 66 -339 minecraft:birch_log[axis=y]
setblock 12 66 -340 minecraft:grass_block[snowy=false]
fill 13 66 -340 24 66 -340 minecraft:dirt
setblock 25 66 -340 minecraft:peony[half=upper]
fill 16 66 -341 22 66 -341 minecraft:grass_block[snowy=false]
setblock 18 66 -349 minecraft:air
setblock 18 66 -359 minecraft:air
setblock 18 66 -369 minecraft:air
setblock 18 66 -379 minecraft:air
fill 8 65 -319 22 65 -319 minecraft:stone
fill 23 65 -319 26 65 -319 minecraft:air
setblock 27 65 -319 minecraft:magma_block
fill 28 65 -319 33 65 -319 minecraft:air
fill 34 65 -319 54 65 -319 minecraft:dirt
fill 60 65 -319 62 65 -319 regions_unexplored:silt_grass_block[snowy=false]
fill 63 65 -319 65 65 -319 minecraft:sand
fill 66 65 -319 69 65 -319 minecraft:air
setblock 70 65 -319 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 71 65 -319 minecraft:deepslate[axis=y]
fill 8 65 -320 24 65 -320 minecraft:stone
fill 25 65 -320 31 65 -320 minecraft:air
setblock 32 65 -320 minecraft:stone
fill 33 65 -320 46 65 -320 minecraft:dirt
fill 47 65 -320 50 65 -320 minecraft:sand
fill 51 65 -320 52 65 -320 minecraft:dirt
fill 53 65 -320 54 65 -320 minecraft:sand
setblock 55 65 -320 minecraft:air
fill 59 65 -320 64 65 -320 minecraft:sand
fill 65 65 -320 70 65 -320 minecraft:air
setblock 71 65 -320 minecraft:deepslate[axis=y]
fill 8 65 -321 16 65 -321 minecraft:stone
setblock 17 65 -321 minecraft:copper_ore
fill 18 65 -321 32 65 -321 minecraft:stone
fill 33 65 -321 47 65 -321 minecraft:dirt
fill 48 65 -321 52 65 -321 minecraft:sand
fill 53 65 -321 58 65 -321 minecraft:air
fill 59 65 -321 60 65 -321 minecraft:sand
fill 61 65 -321 71 65 -321 minecraft:air
fill 8 65 -322 16 65 -322 minecraft:stone
fill 17 65 -322 18 65 -322 minecraft:copper_ore
fill 19 65 -322 27 65 -322 minecraft:stone
setblock 28 65 -322 minecraft:copper_ore
fill 29 65 -322 32 65 -322 minecraft:stone
fill 33 65 -322 47 65 -322 minecraft:dirt
fill 48 65 -322 51 65 -322 minecraft:sand
fill 52 65 -322 71 65 -322 minecraft:air
fill 8 65 -323 15 65 -323 minecraft:stone
setblock 16 65 -323 minecraft:netherrack
fill 17 65 -323 18 65 -323 minecraft:copper_ore
fill 19 65 -323 32 65 -323 minecraft:stone
fill 33 65 -323 47 65 -323 minecraft:dirt
fill 48 65 -323 52 65 -323 minecraft:sand
fill 53 65 -323 71 65 -323 minecraft:air
fill 8 65 -324 13 65 -324 minecraft:stone
fill 14 65 -324 15 65 -324 minecraft:dirt
fill 16 65 -324 17 65 -324 minecraft:stone
setblock 18 65 -324 minecraft:copper_ore
fill 19 65 -324 26 65 -324 minecraft:stone
setblock 27 65 -324 theurgy:sal_ammoniac_ore
setblock 28 65 -324 minecraft:dirt
fill 29 65 -324 33 65 -324 minecraft:stone
fill 34 65 -324 46 65 -324 minecraft:dirt
fill 48 65 -324 52 65 -324 minecraft:sand
fill 53 65 -324 71 65 -324 minecraft:air
fill 8 65 -325 13 65 -325 minecraft:stone
fill 14 65 -325 16 65 -325 minecraft:dirt
fill 17 65 -325 22 65 -325 minecraft:stone
fill 23 65 -325 24 65 -325 minecraft:netherrack
fill 25 65 -325 28 65 -325 minecraft:stone
setblock 29 65 -325 minecraft:dirt
setblock 30 65 -325 minecraft:stone
setblock 31 65 -325 minecraft:dirt
setblock 32 65 -325 minecraft:stone
fill 33 65 -325 44 65 -325 minecraft:dirt
fill 53 65 -325 71 65 -325 minecraft:air
fill 8 65 -326 12 65 -326 minecraft:stone
fill 13 65 -326 15 65 -326 minecraft:dirt
setblock 16 65 -326 minecraft:netherrack
fill 17 65 -326 22 65 -326 minecraft:stone
setblock 23 65 -326 minecraft:netherrack
fill 24 65 -326 28 65 -326 minecraft:stone
setblock 29 65 -326 minecraft:netherrack
fill 30 65 -326 32 65 -326 minecraft:stone
setblock 33 65 -326 minecraft:dirt
fill 34 65 -326 36 65 -326 minecraft:stone
fill 37 65 -326 43 65 -326 minecraft:dirt
setblock 47 65 -326 minecraft:short_grass
fill 48 65 -326 71 65 -326 minecraft:air
fill 8 65 -327 12 65 -327 minecraft:stone
fill 13 65 -327 16 65 -327 minecraft:dirt
fill 17 65 -327 20 65 -327 minecraft:stone
setblock 21 65 -327 minecraft:netherrack
fill 22 65 -327 34 65 -327 minecraft:stone
fill 35 65 -327 42 65 -327 minecraft:dirt
fill 45 65 -327 71 65 -327 minecraft:air
fill 8 65 -328 12 65 -328 minecraft:stone
fill 13 65 -328 16 65 -328 minecraft:dirt
fill 17 65 -328 18 65 -328 minecraft:stone
setblock 19 65 -328 minecraft:netherrack
fill 20 65 -328 23 65 -328 minecraft:stone
setblock 24 65 -328 minecraft:netherrack
setblock 25 65 -328 minecraft:stone
setblock 26 65 -328 minecraft:coal_ore
setblock 27 65 -328 minecraft:stone
fill 28 65 -328 42 65 -328 minecraft:dirt
fill 44 65 -328 71 65 -328 minecraft:air
fill 8 65 -329 12 65 -329 minecraft:stone
fill 13 65 -329 16 65 -329 minecraft:dirt
fill 17 65 -329 25 65 -329 minecraft:stone
setblock 26 65 -329 minecraft:coal_ore
fill 27 65 -329 41 65 -329 minecraft:dirt
setblock 44 65 -329 minecraft:short_grass
setblock 45 65 -329 regions_unexplored:grass_sprouts
fill 46 65 -329 71 65 -329 minecraft:air
fill 8 65 -330 12 65 -330 minecraft:stone
fill 13 65 -330 16 65 -330 minecraft:dirt
fill 17 65 -330 24 65 -330 minecraft:stone
fill 25 65 -330 26 65 -330 minecraft:coal_ore
fill 27 65 -330 41 65 -330 minecraft:dirt
fill 43 65 -330 71 65 -330 minecraft:air
fill 8 65 -331 13 65 -331 minecraft:stone
fill 14 65 -331 15 65 -331 minecraft:dirt
fill 16 65 -331 24 65 -331 minecraft:stone
setblock 25 65 -331 minecraft:coal_ore
fill 26 65 -331 40 65 -331 minecraft:dirt
fill 43 65 -331 55 65 -331 minecraft:air
setblock 56 65 -331 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 57 65 -331 71 65 -331 minecraft:air
fill 8 65 -332 13 65 -332 minecraft:stone
fill 14 65 -332 15 65 -332 minecraft:dirt
fill 16 65 -332 17 65 -332 minecraft:stone
setblock 18 65 -332 minecraft:netherrack
fill 19 65 -332 24 65 -332 minecraft:stone
fill 25 65 -332 39 65 -332 minecraft:dirt
fill 42 65 -332 71 65 -332 minecraft:air
fill 8 65 -333 13 65 -333 minecraft:stone
setblock 14 65 -333 minecraft:dirt
fill 15 65 -333 19 65 -333 minecraft:stone
fill 20 65 -333 21 65 -333 alltheores:fluorite_ore
fill 22 65 -333 23 65 -333 minecraft:stone
fill 24 65 -333 38 65 -333 minecraft:dirt
fill 42 65 -333 51 65 -333 minecraft:air
setblock 52 65 -333 minecraft:birch_log[axis=y]
fill 53 65 -333 71 65 -333 minecraft:air
fill 8 65 -334 19 65 -334 minecraft:stone
setblock 20 65 -334 alltheores:nether_fluorite_ore
setblock 21 65 -334 alltheores:fluorite_ore
setblock 22 65 -334 minecraft:stone
fill 23 65 -334 36 65 -334 minecraft:dirt
fill 41 65 -334 71 65 -334 minecraft:air
fill 8 65 -335 19 65 -335 minecraft:stone
fill 20 65 -335 21 65 -335 alltheores:fluorite_ore
fill 22 65 -335 33 65 -335 minecraft:dirt
fill 39 65 -335 71 65 -335 minecraft:air
fill 8 65 -336 19 65 -336 minecraft:stone
setblock 20 65 -336 alltheores:fluorite_ore
fill 21 65 -336 32 65 -336 minecraft:dirt
fill 37 65 -336 39 65 -336 minecraft:air
setblock 40 65 -336 regions_unexplored:grass_sprouts
fill 41 65 -336 47 65 -336 minecraft:air
setblock 48 65 -336 minecraft:birch_log[axis=y]
fill 49 65 -336 71 65 -336 minecraft:air
fill 8 65 -337 9 65 -337 minecraft:dirt
fill 10 65 -337 19 65 -337 minecraft:stone
fill 20 65 -337 25 65 -337 minecraft:dirt
fill 27 65 -337 29 65 -337 minecraft:air
setblock 30 65 -337 minecraft:peony[half=upper]
fill 31 65 -337 34 65 -337 minecraft:air
setblock 35 65 -337 minecraft:peony[half=lower]
fill 36 65 -337 71 65 -337 minecraft:air
fill 8 65 -338 11 65 -338 minecraft:dirt
fill 12 65 -338 18 65 -338 minecraft:stone
fill 19 65 -338 20 65 -338 minecraft:dirt
fill 21 65 -338 22 65 -338 minecraft:stone
fill 23 65 -338 24 65 -338 minecraft:dirt
fill 26 65 -338 71 65 -338 minecraft:air
fill 8 65 -339 9 65 -339 minecraft:air
setblock 10 65 -339 minecraft:grass_block[snowy=false]
fill 11 65 -339 14 65 -339 minecraft:dirt
fill 15 65 -339 17 65 -339 minecraft:stone
setblock 18 65 -339 minecraft:dirt
fill 19 65 -339 20 65 -339 minecraft:stone
fill 21 65 -339 24 65 -339 minecraft:dirt
fill 26 65 -339 38 65 -339 minecraft:air
setblock 39 65 -339 minecraft:birch_log[axis=y]
fill 40 65 -339 71 65 -339 minecraft:air
fill 8 65 -340 10 65 -340 minecraft:air
setblock 11 65 -340 minecraft:grass_block[snowy=false]
fill 12 65 -340 15 65 -340 minecraft:dirt
setblock 16 65 -340 minecraft:stone
fill 17 65 -340 18 65 -340 minecraft:dirt
setblock 19 65 -340 minecraft:stone
setblock 20 65 -340 minecraft:dirt
setblock 21 65 -340 minecraft:stone
fill 22 65 -340 24 65 -340 minecraft:dirt
setblock 25 65 -340 minecraft:peony[half=lower]
fill 26 65 -340 71 65 -340 minecraft:air
fill 8 65 -341 13 65 -341 minecraft:air
fill 16 65 -341 22 65 -341 minecraft:dirt
fill 25 65 -341 71 65 -341 minecraft:air
fill 8 65 -342 71 65 -342 minecraft:air
fill 8 65 -343 71 65 -343 minecraft:air
fill 8 65 -344 71 65 -344 minecraft:air
fill 8 65 -345 71 65 -345 minecraft:air
fill 8 65 -346 71 65 -346 minecraft:air
fill 8 65 -347 71 65 -347 minecraft:air
fill 8 65 -348 71 65 -348 minecraft:air
fill 8 65 -349 71 65 -349 minecraft:air
fill 8 65 -350 71 65 -350 minecraft:air
fill 8 65 -351 71 65 -351 minecraft:air
fill 8 65 -352 71 65 -352 minecraft:air
fill 8 65 -353 71 65 -353 minecraft:air
fill 8 65 -354 71 65 -354 minecraft:air
fill 8 65 -355 71 65 -355 minecraft:air
fill 8 65 -356 71 65 -356 minecraft:air
fill 8 65 -357 71 65 -357 minecraft:air
fill 8 65 -358 71 65 -358 minecraft:air
fill 8 65 -359 71 65 -359 minecraft:air
fill 8 65 -360 71 65 -360 minecraft:air
fill 8 65 -361 71 65 -361 minecraft:air
fill 8 65 -362 71 65 -362 minecraft:air
fill 8 65 -363 71 65 -363 minecraft:air
fill 8 65 -364 71 65 -364 minecraft:air
fill 8 65 -365 71 65 -365 minecraft:air
fill 8 65 -366 71 65 -366 minecraft:air
fill 8 65 -367 71 65 -367 minecraft:air
fill 8 65 -368 71 65 -368 minecraft:air
fill 8 65 -369 71 65 -369 minecraft:air
fill 8 65 -370 71 65 -370 minecraft:air
fill 8 65 -371 71 65 -371 minecraft:air
fill 8 65 -372 71 65 -372 minecraft:air
fill 8 65 -373 71 65 -373 minecraft:air
fill 8 65 -374 71 65 -374 minecraft:air
fill 8 65 -375 71 65 -375 minecraft:air
fill 8 65 -376 71 65 -376 minecraft:air
fill 8 65 -377 71 65 -377 minecraft:air
fill 8 65 -378 71 65 -378 minecraft:air
fill 8 65 -379 71 65 -379 minecraft:air
fill 8 65 -380 71 65 -380 minecraft:air
fill 8 65 -381 71 65 -381 minecraft:air
fill 8 65 -382 71 65 -382 minecraft:air
fill 23 64 -319 26 64 -319 minecraft:air
fill 28 64 -319 33 64 -319 minecraft:air
fill 26 64 -320 30 64 -320 minecraft:air
fill 52 64 -320 56 64 -320 minecraft:air
setblock 70 64 -320 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
fill 51 64 -321 58 64 -321 minecraft:air
fill 68 64 -321 71 64 -321 minecraft:air
fill 51 64 -322 59 64 -322 minecraft:air
fill 66 64 -322 69 64 -322 minecraft:air
fill 51 64 -323 59 64 -323 minecraft:air
fill 65 64 -323 70 64 -323 minecraft:air
fill 52 64 -324 59 64 -324 minecraft:air
fill 63 64 -324 71 64 -324 minecraft:air
fill 54 64 -325 58 64 -325 minecraft:air
fill 60 64 -325 71 64 -325 minecraft:air
fill 55 64 -326 71 64 -326 minecraft:air
fill 48 64 -327 51 64 -327 minecraft:air
setblock 52 64 -327 minecraft:short_grass
fill 53 64 -327 71 64 -327 minecraft:air
fill 46 64 -328 49 64 -328 minecraft:air
setblock 50 64 -328 minecraft:short_grass
setblock 51 64 -328 minecraft:air
fill 52 64 -328 53 64 -328 regions_unexplored:grass_sprouts
setblock 54 64 -328 regions_unexplored:orange_coneflower[facing=south,flower_amount=1]
setblock 55 64 -328 minecraft:air
setblock 56 64 -328 regions_unexplored:orange_coneflower[facing=west,flower_amount=4]
fill 57 64 -328 71 64 -328 minecraft:air
fill 46 64 -329 55 64 -329 minecraft:air
setblock 56 64 -329 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 57 64 -329 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 58 64 -329 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 59 64 -329 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 60 64 -329 71 64 -329 minecraft:air
fill 45 64 -330 52 64 -330 minecraft:air
setblock 53 64 -330 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
fill 54 64 -330 71 64 -330 minecraft:air
fill 44 64 -331 55 64 -331 minecraft:air
fill 57 64 -331 58 64 -331 minecraft:air
setblock 59 64 -331 minecraft:short_grass
fill 60 64 -331 71 64 -331 minecraft:air
fill 44 64 -332 50 64 -332 minecraft:air
setblock 51 64 -332 minecraft:short_grass
fill 52 64 -332 54 64 -332 minecraft:air
setblock 55 64 -332 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
fill 56 64 -332 57 64 -332 minecraft:air
setblock 58 64 -332 regions_unexplored:orange_coneflower[facing=south,flower_amount=3]
fill 59 64 -332 71 64 -332 minecraft:air
fill 44 64 -333 51 64 -333 minecraft:air
fill 53 64 -333 71 64 -333 minecraft:air
fill 44 64 -334 53 64 -334 minecraft:air
setblock 54 64 -334 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
fill 55 64 -334 71 64 -334 minecraft:air
fill 43 64 -335 71 64 -335 minecraft:air
fill 41 64 -336 47 64 -336 minecraft:air
fill 49 64 -336 71 64 -336 minecraft:air
fill 28 64 -337 29 64 -337 minecraft:air
fill 31 64 -337 34 64 -337 minecraft:air
setblock 41 64 -337 minecraft:air
setblock 42 64 -337 regions_unexplored:grass_sprouts
fill 43 64 -337 71 64 -337 minecraft:air
fill 27 64 -338 33 64 -338 minecraft:air
fill 34 64 -338 35 64 -338 minecraft:short_grass
fill 41 64 -338 71 64 -338 minecraft:air
setblock 8 64 -339 minecraft:air
fill 26 64 -339 37 64 -339 minecraft:air
setblock 38 64 -339 minecraft:short_grass
fill 41 64 -339 71 64 -339 minecraft:air
fill 8 64 -340 10 64 -340 minecraft:air
fill 26 64 -340 37 64 -340 minecraft:air
setblock 38 64 -340 minecraft:short_grass
setblock 39 64 -340 minecraft:air
fill 41 64 -340 71 64 -340 minecraft:air
fill 8 64 -341 11 64 -341 minecraft:air
fill 25 64 -341 71 64 -341 minecraft:air
fill 8 64 -342 18 64 -342 minecraft:air
fill 24 64 -342 71 64 -342 minecraft:air
fill 8 64 -343 71 64 -343 minecraft:air
fill 8 64 -344 71 64 -344 minecraft:air
fill 8 64 -345 71 64 -345 minecraft:air
fill 8 64 -346 71 64 -346 minecraft:air
fill 8 64 -347 71 64 -347 minecraft:air
fill 8 64 -348 71 64 -348 minecraft:air
fill 8 64 -349 71 64 -349 minecraft:air
fill 8 64 -350 71 64 -350 minecraft:air
fill 8 64 -351 71 64 -351 minecraft:air
fill 8 64 -352 71 64 -352 minecraft:air
fill 8 64 -353 71 64 -353 minecraft:air
fill 8 64 -354 71 64 -354 minecraft:air
fill 8 64 -355 71 64 -355 minecraft:air
fill 8 64 -356 71 64 -356 minecraft:air
fill 8 64 -357 71 64 -357 minecraft:air
fill 8 64 -358 71 64 -358 minecraft:air
fill 8 64 -359 71 64 -359 minecraft:air
fill 8 64 -360 71 64 -360 minecraft:air
fill 8 64 -361 71 64 -361 minecraft:air
fill 8 64 -362 71 64 -362 minecraft:air
fill 8 64 -363 71 64 -363 minecraft:air
fill 8 64 -364 71 64 -364 minecraft:air
fill 8 64 -365 71 64 -365 minecraft:air
fill 8 64 -366 71 64 -366 minecraft:air
fill 8 64 -367 71 64 -367 minecraft:air
fill 8 64 -368 71 64 -368 minecraft:air
fill 8 64 -369 71 64 -369 minecraft:air
fill 8 64 -370 71 64 -370 minecraft:air
fill 8 64 -371 71 64 -371 minecraft:air
fill 8 64 -372 71 64 -372 minecraft:air
fill 8 64 -373 71 64 -373 minecraft:air
fill 8 64 -374 71 64 -374 minecraft:air
fill 8 64 -375 71 64 -375 minecraft:air
fill 8 64 -376 71 64 -376 minecraft:air
fill 8 64 -377 71 64 -377 minecraft:air
fill 8 64 -378 71 64 -378 minecraft:air
fill 8 64 -379 71 64 -379 minecraft:air
fill 8 64 -380 71 64 -380 minecraft:air
fill 8 64 -381 71 64 -381 minecraft:air
fill 8 64 -382 71 64 -382 minecraft:air
setblock 36 63 -319 minecraft:air
fill 38 63 -319 40 63 -319 minecraft:air
fill 51 63 -320 56 63 -320 minecraft:air
fill 49 63 -321 57 63 -321 minecraft:air
fill 49 63 -322 58 63 -322 minecraft:air
fill 49 63 -323 58 63 -323 minecraft:air
fill 51 63 -324 58 63 -324 minecraft:air
fill 54 63 -325 56 63 -325 minecraft:air
fill 66 63 -325 71 63 -325 minecraft:air
fill 65 63 -326 71 63 -326 minecraft:air
fill 64 63 -327 71 63 -327 minecraft:air
fill 63 63 -328 71 63 -328 minecraft:air
fill 62 63 -329 68 63 -329 minecraft:air
fill 70 63 -329 71 63 -329 minecraft:air
fill 62 63 -330 66 63 -330 minecraft:air
setblock 71 63 -330 minecraft:air
fill 61 63 -331 65 63 -331 minecraft:air
fill 61 63 -332 71 63 -332 minecraft:air
fill 60 63 -333 71 63 -333 minecraft:air
fill 60 63 -334 71 63 -334 minecraft:air
fill 61 63 -335 71 63 -335 minecraft:air
fill 61 63 -336 71 63 -336 minecraft:air
fill 31 63 -337 32 63 -337 minecraft:air
fill 47 63 -337 59 63 -337 minecraft:air
fill 61 63 -337 64 63 -337 minecraft:air
fill 27 63 -338 33 63 -338 minecraft:air
fill 46 63 -338 59 63 -338 minecraft:air
fill 61 63 -338 64 63 -338 minecraft:air
fill 26 63 -339 34 63 -339 minecraft:air
fill 45 63 -339 57 63 -339 minecraft:air
setblock 59 63 -339 minecraft:air
fill 62 63 -339 63 63 -339 minecraft:air
fill 8 63 -340 9 63 -340 minecraft:air
fill 26 63 -340 35 63 -340 minecraft:air
fill 45 63 -340 60 63 -340 minecraft:air
fill 62 63 -340 63 63 -340 minecraft:air
fill 67 63 -340 69 63 -340 minecraft:air
fill 8 63 -341 10 63 -341 minecraft:air
fill 25 63 -341 39 63 -341 minecraft:air
fill 41 63 -341 43 63 -341 minecraft:air
setblock 44 63 -341 minecraft:short_grass
fill 45 63 -341 63 63 -341 minecraft:air
fill 66 63 -341 69 63 -341 minecraft:air
fill 8 63 -342 17 63 -342 minecraft:air
fill 25 63 -342 62 63 -342 minecraft:air
fill 66 63 -342 69 63 -342 minecraft:air
setblock 71 63 -342 minecraft:air
fill 8 63 -343 63 63 -343 minecraft:air
fill 66 63 -343 71 63 -343 minecraft:air
fill 8 63 -344 63 63 -344 minecraft:air
fill 65 63 -344 68 63 -344 minecraft:air
fill 70 63 -344 71 63 -344 minecraft:air
fill 8 63 -345 63 63 -345 minecraft:air
fill 65 63 -345 68 63 -345 minecraft:air
fill 70 63 -345 71 63 -345 minecraft:air
fill 8 63 -346 62 63 -346 minecraft:air
setblock 63 63 -346 regions_unexplored:grass_sprouts
fill 64 63 -346 68 63 -346 minecraft:air
fill 70 63 -346 71 63 -346 minecraft:air
fill 8 63 -347 71 63 -347 minecraft:air
fill 8 63 -348 68 63 -348 minecraft:air
fill 70 63 -348 71 63 -348 minecraft:air
fill 8 63 -349 71 63 -349 minecraft:air
fill 8 63 -350 67 63 -350 minecraft:air
fill 69 63 -350 71 63 -350 minecraft:air
fill 8 63 -351 71 63 -351 minecraft:air
fill 8 63 -352 71 63 -352 minecraft:air
fill 8 63 -353 71 63 -353 minecraft:air
fill 8 63 -354 71 63 -354 minecraft:air
fill 8 63 -355 71 63 -355 minecraft:air
fill 8 63 -356 71 63 -356 minecraft:air
fill 8 63 -357 71 63 -357 minecraft:air
fill 8 63 -358 71 63 -358 minecraft:air
fill 8 63 -359 71 63 -359 minecraft:air
fill 8 63 -360 71 63 -360 minecraft:air
fill 8 63 -361 71 63 -361 minecraft:air
fill 8 63 -362 71 63 -362 minecraft:air
fill 8 63 -363 71 63 -363 minecraft:air
fill 8 63 -364 71 63 -364 minecraft:air
fill 8 63 -365 71 63 -365 minecraft:air
fill 8 63 -366 71 63 -366 minecraft:air
fill 8 63 -367 71 63 -367 minecraft:air
fill 8 63 -368 71 63 -368 minecraft:air
fill 8 63 -369 71 63 -369 minecraft:air
fill 8 63 -370 71 63 -370 minecraft:air
fill 8 63 -371 71 63 -371 minecraft:air
fill 8 63 -372 71 63 -372 minecraft:air
fill 8 63 -373 71 63 -373 minecraft:air
fill 8 63 -374 71 63 -374 minecraft:air
fill 8 63 -375 71 63 -375 minecraft:air
fill 8 63 -376 71 63 -376 minecraft:air
fill 8 63 -377 71 63 -377 minecraft:air
fill 8 63 -378 71 63 -378 minecraft:air
fill 8 63 -379 71 63 -379 minecraft:air
fill 8 63 -380 71 63 -380 minecraft:air
fill 8 63 -381 71 63 -381 minecraft:air
fill 8 63 -382 71 63 -382 minecraft:air
setblock 37 62 -319 minecraft:air
setblock 42 62 -319 minecraft:air
setblock 51 62 -319 minecraft:air
setblock 38 62 -320 minecraft:water[level=0]
setblock 48 62 -320 minecraft:water[level=0]
fill 47 62 -321 53 62 -321 minecraft:water[level=0]
fill 47 62 -322 55 62 -322 minecraft:water[level=0]
fill 48 62 -323 57 62 -323 minecraft:water[level=0]
fill 49 62 -324 56 62 -324 minecraft:water[level=0]
fill 68 62 -325 70 62 -325 minecraft:water[level=0]
fill 66 62 -326 71 62 -326 minecraft:water[level=0]
fill 65 62 -327 71 62 -327 minecraft:water[level=0]
fill 64 62 -328 71 62 -328 minecraft:water[level=0]
fill 63 62 -329 67 62 -329 minecraft:water[level=0]
setblock 71 62 -329 minecraft:water[level=0]
fill 63 62 -330 66 62 -330 minecraft:water[level=0]
fill 62 62 -331 65 62 -331 minecraft:water[level=0]
fill 62 62 -332 64 62 -332 minecraft:water[level=0]
fill 66 62 -332 71 62 -332 minecraft:water[level=0]
fill 62 62 -333 71 62 -333 minecraft:water[level=0]
fill 62 62 -334 63 62 -334 minecraft:water[level=0]
fill 65 62 -334 71 62 -334 minecraft:water[level=0]
fill 62 62 -335 63 62 -335 minecraft:water[level=0]
fill 65 62 -335 71 62 -335 minecraft:water[level=0]
fill 67 62 -336 68 62 -336 minecraft:water[level=0]
fill 70 62 -336 71 62 -336 minecraft:water[level=0]
fill 27 62 -338 33 62 -338 minecraft:water[level=0]
fill 47 62 -338 57 62 -338 minecraft:water[level=0]
fill 27 62 -339 33 62 -339 minecraft:water[level=0]
fill 46 62 -339 56 62 -339 minecraft:water[level=0]
setblock 57 62 -339 minecraft:kelp[age=23]
setblock 8 62 -340 minecraft:water[level=0]
fill 26 62 -340 34 62 -340 minecraft:water[level=0]
fill 46 62 -340 52 62 -340 minecraft:water[level=0]
setblock 53 62 -340 minecraft:kelp[age=25]
fill 54 62 -340 57 62 -340 minecraft:water[level=0]
setblock 58 62 -340 minecraft:kelp[age=21]
setblock 59 62 -340 minecraft:kelp[age=23]
setblock 8 62 -341 minecraft:water[level=0]
setblock 9 62 -341 minecraft:seagrass
fill 26 62 -341 35 62 -341 minecraft:water[level=0]
fill 45 62 -341 58 62 -341 minecraft:water[level=0]
setblock 59 62 -341 minecraft:kelp[age=22]
fill 8 62 -342 10 62 -342 minecraft:water[level=0]
setblock 16 62 -342 minecraft:water[level=0]
fill 25 62 -342 35 62 -342 minecraft:water[level=0]
setblock 36 62 -342 minecraft:tall_seagrass[half=upper]
fill 37 62 -342 38 62 -342 minecraft:water[level=0]
fill 39 62 -342 40 62 -342 minecraft:seagrass
setblock 41 62 -342 minecraft:water[level=0]
fill 42 62 -342 43 62 -342 minecraft:seagrass
fill 44 62 -342 46 62 -342 minecraft:water[level=0]
fill 49 62 -342 57 62 -342 minecraft:water[level=0]
setblock 58 62 -342 minecraft:kelp[age=21]
setblock 59 62 -342 minecraft:water[level=0]
setblock 60 62 -342 minecraft:tall_seagrass[half=upper]
setblock 61 62 -342 minecraft:seagrass
fill 8 62 -343 21 62 -343 minecraft:water[level=0]
setblock 22 62 -343 minecraft:seagrass
fill 25 62 -343 61 62 -343 minecraft:water[level=0]
fill 8 62 -344 22 62 -344 minecraft:water[level=0]
setblock 23 62 -344 minecraft:tall_seagrass[half=upper]
fill 24 62 -344 62 62 -344 minecraft:water[level=0]
fill 66 62 -344 68 62 -344 minecraft:water[level=0]
fill 8 62 -345 57 62 -345 minecraft:water[level=0]
setblock 58 62 -345 minecraft:kelp[age=25]
fill 59 62 -345 60 62 -345 minecraft:water[level=0]
setblock 61 62 -345 minecraft:kelp[age=24]
setblock 62 62 -345 minecraft:water[level=0]
setblock 65 62 -345 minecraft:kelp[age=21]
fill 66 62 -345 68 62 -345 minecraft:water[level=0]
fill 8 62 -346 38 62 -346 minecraft:water[level=0]
setblock 39 62 -346 minecraft:kelp[age=24]
fill 40 62 -346 47 62 -346 minecraft:water[level=0]
setblock 48 62 -346 minecraft:kelp[age=23]
fill 49 62 -346 59 62 -346 minecraft:water[level=0]
setblock 60 62 -346 minecraft:kelp[age=25]
setblock 61 62 -346 minecraft:water[level=0]
setblock 62 62 -346 minecraft:kelp[age=22]
setblock 65 62 -346 minecraft:kelp[age=23]
fill 66 62 -346 68 62 -346 minecraft:water[level=0]
fill 8 62 -347 57 62 -347 minecraft:water[level=0]
setblock 58 62 -347 minecraft:kelp[age=25]
fill 59 62 -347 62 62 -347 minecraft:water[level=0]
setblock 65 62 -347 minecraft:seagrass
fill 66 62 -347 68 62 -347 minecraft:water[level=0]
fill 8 62 -348 50 62 -348 minecraft:water[level=0]
setblock 51 62 -348 minecraft:kelp[age=25]
fill 52 62 -348 62 62 -348 minecraft:water[level=0]
fill 65 62 -348 68 62 -348 minecraft:water[level=0]
setblock 71 62 -348 minecraft:water[level=0]
fill 8 62 -349 43 62 -349 minecraft:water[level=0]
setblock 44 62 -349 minecraft:kelp[age=23]
fill 45 62 -349 48 62 -349 minecraft:water[level=0]
setblock 49 62 -349 minecraft:kelp[age=24]
fill 50 62 -349 63 62 -349 minecraft:water[level=0]
fill 66 62 -349 67 62 -349 minecraft:water[level=0]
setblock 68 62 -349 minecraft:seagrass
fill 70 62 -349 71 62 -349 minecraft:water[level=0]
fill 8 62 -350 63 62 -350 minecraft:water[level=0]
setblock 64 62 -350 minecraft:tall_seagrass[half=upper]
setblock 65 62 -350 minecraft:seagrass
setblock 66 62 -350 minecraft:water[level=0]
fill 70 62 -350 71 62 -350 minecraft:water[level=0]
fill 8 62 -351 50 62 -351 minecraft:water[level=0]
setblock 51 62 -351 minecraft:kelp[age=24]
fill 52 62 -351 67 62 -351 minecraft:water[level=0]
fill 69 62 -351 71 62 -351 minecraft:water[level=0]
fill 8 62 -352 32 62 -352 minecraft:water[level=0]
setblock 33 62 -352 minecraft:kelp[age=24]
fill 34 62 -352 67 62 -352 minecraft:water[level=0]
fill 69 62 -352 71 62 -352 minecraft:water[level=0]
fill 8 62 -353 48 62 -353 minecraft:water[level=0]
setblock 49 62 -353 minecraft:kelp[age=23]
fill 50 62 -353 66 62 -353 minecraft:water[level=0]
setblock 67 62 -353 minecraft:kelp[age=24]
setblock 68 62 -353 minecraft:water[level=0]
setblock 69 62 -353 minecraft:kelp[age=22]
fill 70 62 -353 71 62 -353 minecraft:water[level=0]
fill 8 62 -354 67 62 -354 minecraft:water[level=0]
setblock 68 62 -354 minecraft:kelp[age=22]
fill 69 62 -354 71 62 -354 minecraft:water[level=0]
fill 8 62 -355 71 62 -355 minecraft:water[level=0]
fill 8 62 -356 71 62 -356 minecraft:water[level=0]
fill 8 62 -357 71 62 -357 minecraft:water[level=0]
fill 8 62 -358 71 62 -358 minecraft:water[level=0]
fill 8 62 -359 71 62 -359 minecraft:water[level=0]
fill 8 62 -360 71 62 -360 minecraft:water[level=0]
fill 8 62 -361 71 62 -361 minecraft:water[level=0]
fill 8 62 -362 71 62 -362 minecraft:water[level=0]
fill 8 62 -363 47 62 -363 minecraft:water[level=0]
setblock 48 62 -363 minecraft:kelp[age=25]
setblock 49 62 -363 minecraft:water[level=0]
setblock 50 62 -363 minecraft:kelp[age=24]
fill 51 62 -363 71 62 -363 minecraft:water[level=0]
fill 8 62 -364 71 62 -364 minecraft:water[level=0]
fill 8 62 -365 54 62 -365 minecraft:water[level=0]
setblock 55 62 -365 minecraft:kelp[age=23]
fill 56 62 -365 71 62 -365 minecraft:water[level=0]
fill 8 62 -366 71 62 -366 minecraft:water[level=0]
fill 8 62 -367 71 62 -367 minecraft:water[level=0]
fill 8 62 -368 71 62 -368 minecraft:water[level=0]
fill 8 62 -369 71 62 -369 minecraft:water[level=0]
fill 8 62 -370 71 62 -370 minecraft:water[level=0]
fill 8 62 -371 71 62 -371 minecraft:water[level=0]
fill 8 62 -372 71 62 -372 minecraft:water[level=0]
fill 8 62 -373 71 62 -373 minecraft:water[level=0]
fill 8 62 -374 71 62 -374 minecraft:water[level=0]
fill 8 62 -375 71 62 -375 minecraft:water[level=0]
fill 8 62 -376 71 62 -376 minecraft:water[level=0]
fill 8 62 -377 71 62 -377 minecraft:water[level=0]
fill 8 62 -378 71 62 -378 minecraft:water[level=0]
fill 8 62 -379 71 62 -379 minecraft:water[level=0]
fill 8 62 -380 71 62 -380 minecraft:water[level=0]
fill 8 62 -381 71 62 -381 minecraft:water[level=0]
fill 8 62 -382 71 62 -382 minecraft:water[level=0]
fill 21 61 -319 24 61 -319 minecraft:water[level=0]
fill 55 61 -319 57 61 -319 minecraft:air
fill 38 61 -320 44 61 -320 minecraft:water[level=0]
fill 46 61 -320 48 61 -320 minecraft:water[level=0]
fill 46 61 -321 51 61 -321 minecraft:water[level=0]
fill 46 61 -322 53 61 -322 minecraft:water[level=0]
fill 47 61 -323 54 61 -323 minecraft:water[level=0]
fill 48 61 -324 54 61 -324 minecraft:water[level=0]
fill 69 61 -333 71 61 -333 minecraft:water[level=0]
fill 69 61 -334 71 61 -334 minecraft:water[level=0]
fill 70 61 -335 71 61 -335 minecraft:water[level=0]
fill 28 61 -338 32 61 -338 minecraft:water[level=0]
fill 48 61 -338 56 61 -338 minecraft:water[level=0]
fill 27 61 -339 33 61 -339 minecraft:water[level=0]
fill 48 61 -339 56 61 -339 minecraft:water[level=0]
setblock 57 61 -339 minecraft:kelp_plant
setblock 8 61 -340 minecraft:water[level=0]
fill 26 61 -340 34 61 -340 minecraft:water[level=0]
fill 50 61 -340 51 61 -340 minecraft:water[level=0]
setblock 52 61 -340 minecraft:kelp[age=25]
setblock 53 61 -340 minecraft:kelp_plant
fill 54 61 -340 57 61 -340 minecraft:water[level=0]
setblock 58 61 -340 minecraft:kelp_plant
setblock 8 61 -341 minecraft:water[level=0]
fill 26 61 -341 34 61 -341 minecraft:water[level=0]
fill 50 61 -341 58 61 -341 minecraft:water[level=0]
setblock 59 61 -341 minecraft:kelp_plant
fill 8 61 -342 9 61 -342 minecraft:water[level=0]
fill 26 61 -342 35 61 -342 minecraft:water[level=0]
setblock 36 61 -342 minecraft:tall_seagrass[half=lower]
setblock 37 61 -342 minecraft:water[level=0]
fill 44 61 -342 45 61 -342 minecraft:water[level=0]
fill 50 61 -342 57 61 -342 minecraft:water[level=0]
setblock 58 61 -342 minecraft:kelp_plant
setblock 59 61 -342 minecraft:water[level=0]
setblock 60 61 -342 minecraft:tall_seagrass[half=lower]
fill 8 61 -343 19 61 -343 minecraft:water[level=0]
fill 25 61 -343 46 61 -343 minecraft:water[level=0]
fill 48 61 -343 61 61 -343 minecraft:water[level=0]
fill 8 61 -344 20 61 -344 minecraft:water[level=0]
fill 21 61 -344 22 61 -344 minecraft:seagrass
setblock 23 61 -344 minecraft:tall_seagrass[half=lower]
fill 25 61 -344 61 61 -344 minecraft:water[level=0]
fill 8 61 -345 57 61 -345 minecraft:water[level=0]
setblock 58 61 -345 minecraft:kelp_plant
fill 59 61 -345 60 61 -345 minecraft:water[level=0]
setblock 61 61 -345 minecraft:kelp_plant
fill 8 61 -346 38 61 -346 minecraft:water[level=0]
setblock 39 61 -346 minecraft:kelp_plant
fill 40 61 -346 44 61 -346 minecraft:water[level=0]
setblock 45 61 -346 minecraft:kelp[age=25]
fill 46 61 -346 47 61 -346 minecraft:water[level=0]
setblock 48 61 -346 minecraft:kelp_plant
fill 49 61 -346 59 61 -346 minecraft:water[level=0]
setblock 60 61 -346 minecraft:kelp_plant
setblock 61 61 -346 minecraft:water[level=0]
fill 8 61 -347 57 61 -347 minecraft:water[level=0]
setblock 58 61 -347 minecraft:kelp_plant
fill 59 61 -347 61 61 -347 minecraft:water[level=0]
fill 8 61 -348 50 61 -348 minecraft:water[level=0]
setblock 51 61 -348 minecraft:kelp_plant
fill 52 61 -348 62 61 -348 minecraft:water[level=0]
fill 8 61 -349 43 61 -349 minecraft:water[level=0]
setblock 44 61 -349 minecraft:kelp_plant
fill 45 61 -349 48 61 -349 minecraft:water[level=0]
setblock 49 61 -349 minecraft:kelp_plant
fill 50 61 -349 62 61 -349 minecraft:water[level=0]
fill 8 61 -350 37 61 -350 minecraft:water[level=0]
setblock 38 61 -350 minecraft:kelp[age=25]
fill 39 61 -350 56 61 -350 minecraft:water[level=0]
setblock 57 61 -350 minecraft:kelp[age=25]
fill 58 61 -350 63 61 -350 minecraft:water[level=0]
setblock 64 61 -350 minecraft:tall_seagrass[half=lower]
setblock 71 61 -350 minecraft:water[level=0]
fill 8 61 -351 50 61 -351 minecraft:water[level=0]
setblock 51 61 -351 minecraft:kelp_plant
fill 52 61 -351 65 61 -351 minecraft:water[level=0]
setblock 66 61 -351 minecraft:seagrass
setblock 71 61 -351 minecraft:water[level=0]
fill 8 61 -352 32 61 -352 minecraft:water[level=0]
setblock 33 61 -352 minecraft:kelp_plant
fill 34 61 -352 67 61 -352 minecraft:water[level=0]
fill 70 61 -352 71 61 -352 minecraft:water[level=0]
fill 8 61 -353 48 61 -353 minecraft:water[level=0]
setblock 49 61 -353 minecraft:kelp_plant
fill 50 61 -353 66 61 -353 minecraft:water[level=0]
setblock 67 61 -353 minecraft:kelp_plant
setblock 68 61 -353 minecraft:water[level=0]
setblock 69 61 -353 minecraft:kelp_plant
fill 70 61 -353 71 61 -353 minecraft:water[level=0]
fill 8 61 -354 67 61 -354 minecraft:water[level=0]
setblock 68 61 -354 minecraft:kelp_plant
fill 69 61 -354 71 61 -354 minecraft:water[level=0]
fill 8 61 -355 63 61 -355 minecraft:water[level=0]
setblock 64 61 -355 minecraft:kelp[age=25]
fill 65 61 -355 71 61 -355 minecraft:water[level=0]
fill 8 61 -356 71 61 -356 minecraft:water[level=0]
fill 8 61 -357 62 61 -357 minecraft:water[level=0]
setblock 63 61 -357 minecraft:kelp[age=25]
fill 64 61 -357 71 61 -357 minecraft:water[level=0]
fill 8 61 -358 53 61 -358 minecraft:water[level=0]
setblock 54 61 -358 minecraft:kelp[age=24]
fill 55 61 -358 71 61 -358 minecraft:water[level=0]
fill 8 61 -359 71 61 -359 minecraft:water[level=0]
fill 8 61 -360 71 61 -360 minecraft:water[level=0]
fill 8 61 -361 71 61 -361 minecraft:water[level=0]
fill 8 61 -362 69 61 -362 minecraft:water[level=0]
setblock 70 61 -362 minecraft:kelp[age=25]
setblock 71 61 -362 minecraft:water[level=0]
fill 8 61 -363 47 61 -363 minecraft:water[level=0]
setblock 48 61 -363 minecraft:kelp_plant
setblock 49 61 -363 minecraft:water[level=0]
setblock 50 61 -363 minecraft:kelp_plant
fill 51 61 -363 71 61 -363 minecraft:water[level=0]
fill 8 61 -364 71 61 -364 minecraft:water[level=0]
fill 8 61 -365 54 61 -365 minecraft:water[level=0]
setblock 55 61 -365 minecraft:kelp_plant
fill 56 61 -365 71 61 -365 minecraft:water[level=0]
fill 8 61 -366 71 61 -366 minecraft:water[level=0]
fill 8 61 -367 71 61 -367 minecraft:water[level=0]
fill 8 61 -368 63 61 -368 minecraft:water[level=0]
setblock 64 61 -368 minecraft:kelp[age=25]
fill 65 61 -368 71 61 -368 minecraft:water[level=0]
fill 8 61 -369 71 61 -369 minecraft:water[level=0]
fill 8 61 -370 71 61 -370 minecraft:water[level=0]
fill 8 61 -371 71 61 -371 minecraft:water[level=0]
fill 8 61 -372 71 61 -372 minecraft:water[level=0]
fill 8 61 -373 71 61 -373 minecraft:water[level=0]
fill 8 61 -374 71 61 -374 minecraft:water[level=0]
fill 8 61 -375 71 61 -375 minecraft:water[level=0]
fill 8 61 -376 71 61 -376 minecraft:water[level=0]
fill 8 61 -377 71 61 -377 minecraft:water[level=0]
fill 8 61 -378 71 61 -378 minecraft:water[level=0]
fill 8 61 -379 71 61 -379 minecraft:water[level=0]
fill 8 61 -380 71 61 -380 minecraft:water[level=0]
fill 8 61 -381 71 61 -381 minecraft:water[level=0]
fill 8 61 -382 71 61 -382 minecraft:water[level=0]
fill 19 60 -319 24 60 -319 minecraft:water[level=0]
fill 44 60 -319 45 60 -319 minecraft:water[level=0]
setblock 51 60 -319 minecraft:air
fill 55 60 -319 58 60 -319 minecraft:air
fill 20 60 -320 23 60 -320 minecraft:water[level=0]
fill 38 60 -320 47 60 -320 minecraft:water[level=0]
fill 56 60 -320 57 60 -320 minecraft:air
fill 42 60 -321 49 60 -321 minecraft:water[level=0]
fill 54 60 -321 57 60 -321 minecraft:air
fill 44 60 -322 50 60 -322 minecraft:water[level=0]
fill 56 60 -322 57 60 -322 minecraft:air
fill 45 60 -323 52 60 -323 minecraft:water[level=0]
fill 46 60 -324 52 60 -324 minecraft:water[level=0]
fill 46 60 -325 48 60 -325 minecraft:water[level=0]
setblock 56 60 -325 minecraft:water[level=0]
fill 46 60 -326 49 60 -326 minecraft:water[level=0]
setblock 56 60 -326 minecraft:water[level=0]
fill 46 60 -327 49 60 -327 minecraft:water[level=0]
fill 55 60 -327 57 60 -327 minecraft:water[level=0]
fill 46 60 -328 50 60 -328 minecraft:water[level=0]
fill 55 60 -328 57 60 -328 minecraft:water[level=0]
fill 47 60 -329 50 60 -329 minecraft:water[level=0]
fill 54 60 -329 56 60 -329 minecraft:water[level=0]
fill 47 60 -330 51 60 -330 minecraft:water[level=0]
fill 54 60 -330 56 60 -330 minecraft:water[level=0]
fill 48 60 -331 56 60 -331 minecraft:water[level=0]
fill 49 60 -332 52 60 -332 minecraft:water[level=0]
fill 54 60 -332 55 60 -332 minecraft:water[level=0]
fill 28 60 -338 32 60 -338 minecraft:water[level=0]
fill 27 60 -339 33 60 -339 minecraft:water[level=0]
fill 50 60 -339 56 60 -339 minecraft:water[level=0]
setblock 57 60 -339 minecraft:kelp_plant
fill 26 60 -340 33 60 -340 minecraft:water[level=0]
setblock 51 60 -340 minecraft:water[level=0]
fill 52 60 -340 53 60 -340 minecraft:kelp_plant
fill 54 60 -340 57 60 -340 minecraft:water[level=0]
setblock 8 60 -341 minecraft:water[level=0]
fill 26 60 -341 34 60 -341 minecraft:water[level=0]
fill 50 60 -341 57 60 -341 minecraft:water[level=0]
setblock 58 60 -341 minecraft:tall_seagrass[half=upper]
setblock 8 60 -342 minecraft:water[level=0]
fill 26 60 -342 34 60 -342 minecraft:water[level=0]
setblock 35 60 -342 minecraft:seagrass
fill 50 60 -342 57 60 -342 minecraft:water[level=0]
setblock 58 60 -342 minecraft:kelp_plant
setblock 59 60 -342 minecraft:water[level=0]
fill 8 60 -343 11 60 -343 minecraft:water[level=0]
fill 13 60 -343 18 60 -343 minecraft:water[level=0]
fill 26 60 -343 44 60 -343 minecraft:water[level=0]
fill 50 60 -343 52 60 -343 minecraft:water[level=0]
setblock 53 60 -343 minecraft:kelp[age=25]
fill 54 60 -343 60 60 -343 minecraft:water[level=0]
fill 8 60 -344 20 60 -344 minecraft:water[level=0]
fill 25 60 -344 48 60 -344 minecraft:water[level=0]
fill 50 60 -344 61 60 -344 minecraft:water[level=0]
fill 8 60 -345 22 60 -345 minecraft:water[level=0]
fill 23 60 -345 24 60 -345 minecraft:seagrass
fill 25 60 -345 57 60 -345 minecraft:water[level=0]
setblock 58 60 -345 minecraft:kelp_plant
fill 59 60 -345 60 60 -345 minecraft:water[level=0]
setblock 61 60 -345 minecraft:kelp_plant
fill 8 60 -346 38 60 -346 minecraft:water[level=0]
setblock 39 60 -346 minecraft:kelp_plant
fill 40 60 -346 44 60 -346 minecraft:water[level=0]
setblock 45 60 -346 minecraft:kelp_plant
fill 46 60 -346 47 60 -346 minecraft:water[level=0]
setblock 48 60 -346 minecraft:kelp_plant
fill 49 60 -346 57 60 -346 minecraft:water[level=0]
setblock 58 60 -346 minecraft:kelp[age=25]
setblock 59 60 -346 minecraft:water[level=0]
setblock 60 60 -346 minecraft:kelp_plant
setblock 61 60 -346 minecraft:water[level=0]
fill 8 60 -347 31 60 -347 minecraft:water[level=0]
setblock 32 60 -347 minecraft:kelp[age=24]
fill 33 60 -347 57 60 -347 minecraft:water[level=0]
setblock 58 60 -347 minecraft:kelp_plant
fill 59 60 -347 61 60 -347 minecraft:water[level=0]
fill 8 60 -348 50 60 -348 minecraft:water[level=0]
setblock 51 60 -348 minecraft:kelp_plant
fill 52 60 -348 57 60 -348 minecraft:water[level=0]
setblock 58 60 -348 minecraft:kelp[age=25]
fill 59 60 -348 61 60 -348 minecraft:water[level=0]
fill 8 60 -349 43 60 -349 minecraft:water[level=0]
setblock 44 60 -349 minecraft:kelp_plant
fill 45 60 -349 48 60 -349 minecraft:water[level=0]
setblock 49 60 -349 minecraft:kelp_plant
fill 50 60 -349 62 60 -349 minecraft:water[level=0]
fill 8 60 -350 37 60 -350 minecraft:water[level=0]
setblock 38 60 -350 minecraft:kelp_plant
fill 39 60 -350 51 60 -350 minecraft:water[level=0]
setblock 52 60 -350 minecraft:kelp[age=23]
fill 53 60 -350 54 60 -350 minecraft:water[level=0]
setblock 55 60 -350 minecraft:kelp[age=25]
setblock 56 60 -350 minecraft:water[level=0]
setblock 57 60 -350 minecraft:kelp_plant
fill 58 60 -350 63 60 -350 minecraft:water[level=0]
fill 8 60 -351 50 60 -351 minecraft:water[level=0]
setblock 51 60 -351 minecraft:kelp_plant
fill 52 60 -351 65 60 -351 minecraft:water[level=0]
fill 8 60 -352 32 60 -352 minecraft:water[level=0]
setblock 33 60 -352 minecraft:kelp_plant
fill 34 60 -352 42 60 -352 minecraft:water[level=0]
setblock 43 60 -352 minecraft:kelp[age=25]
fill 44 60 -352 66 60 -352 minecraft:water[level=0]
setblock 71 60 -352 minecraft:water[level=0]
fill 8 60 -353 48 60 -353 minecraft:water[level=0]
setblock 49 60 -353 minecraft:kelp_plant
fill 50 60 -353 66 60 -353 minecraft:water[level=0]
setblock 67 60 -353 minecraft:kelp_plant
setblock 69 60 -353 minecraft:kelp_plant
fill 70 60 -353 71 60 -353 minecraft:water[level=0]
fill 8 60 -354 67 60 -354 minecraft:water[level=0]
setblock 68 60 -354 minecraft:kelp_plant
fill 69 60 -354 71 60 -354 minecraft:water[level=0]
fill 8 60 -355 63 60 -355 minecraft:water[level=0]
setblock 64 60 -355 minecraft:kelp_plant
fill 65 60 -355 71 60 -355 minecraft:water[level=0]
fill 8 60 -356 71 60 -356 minecraft:water[level=0]
fill 8 60 -357 62 60 -357 minecraft:water[level=0]
setblock 63 60 -357 minecraft:kelp_plant
fill 64 60 -357 71 60 -357 minecraft:water[level=0]
fill 8 60 -358 53 60 -358 minecraft:water[level=0]
setblock 54 60 -358 minecraft:kelp_plant
fill 55 60 -358 71 60 -358 minecraft:water[level=0]
fill 8 60 -359 71 60 -359 minecraft:water[level=0]
fill 8 60 -360 71 60 -360 minecraft:water[level=0]
fill 8 60 -361 71 60 -361 minecraft:water[level=0]
fill 8 60 -362 69 60 -362 minecraft:water[level=0]
setblock 70 60 -362 minecraft:kelp_plant
setblock 71 60 -362 minecraft:water[level=0]
fill 8 60 -363 47 60 -363 minecraft:water[level=0]
setblock 48 60 -363 minecraft:kelp_plant
setblock 49 60 -363 minecraft:water[level=0]
setblock 50 60 -363 minecraft:kelp_plant
fill 51 60 -363 71 60 -363 minecraft:water[level=0]
fill 8 60 -364 71 60 -364 minecraft:water[level=0]
fill 8 60 -365 54 60 -365 minecraft:water[level=0]
setblock 55 60 -365 minecraft:kelp_plant
fill 56 60 -365 71 60 -365 minecraft:water[level=0]
fill 8 60 -366 71 60 -366 minecraft:water[level=0]
fill 8 60 -367 56 60 -367 minecraft:water[level=0]
setblock 57 60 -367 minecraft:kelp[age=25]
fill 58 60 -367 71 60 -367 minecraft:water[level=0]
fill 8 60 -368 63 60 -368 minecraft:water[level=0]
setblock 64 60 -368 minecraft:kelp_plant
fill 65 60 -368 71 60 -368 minecraft:water[level=0]
fill 8 60 -369 71 60 -369 minecraft:water[level=0]
fill 8 60 -370 71 60 -370 minecraft:water[level=0]
fill 8 60 -371 71 60 -371 minecraft:water[level=0]
fill 8 60 -372 71 60 -372 minecraft:water[level=0]
fill 8 60 -373 71 60 -373 minecraft:water[level=0]
fill 8 60 -374 71 60 -374 minecraft:water[level=0]
fill 8 60 -375 71 60 -375 minecraft:water[level=0]
fill 8 60 -376 71 60 -376 minecraft:water[level=0]
fill 8 60 -377 71 60 -377 minecraft:water[level=0]
fill 8 60 -378 71 60 -378 minecraft:water[level=0]
fill 8 60 -379 71 60 -379 minecraft:water[level=0]
fill 8 60 -380 71 60 -380 minecraft:water[level=0]
fill 8 60 -381 71 60 -381 minecraft:water[level=0]
fill 8 60 -382 71 60 -382 minecraft:water[level=0]
fill 18 59 -319 24 59 -319 minecraft:water[level=0]
fill 42 59 -319 44 59 -319 minecraft:water[level=0]
fill 55 59 -319 58 59 -319 minecraft:air
fill 18 59 -320 24 59 -320 minecraft:water[level=0]
fill 39 59 -320 45 59 -320 minecraft:water[level=0]
fill 50 59 -320 51 59 -320 minecraft:air
fill 55 59 -320 57 59 -320 minecraft:air
fill 18 59 -321 22 59 -321 minecraft:water[level=0]
fill 42 59 -321 46 59 -321 minecraft:water[level=0]
setblock 52 59 -321 minecraft:air
fill 55 59 -321 58 59 -321 minecraft:air
setblock 20 59 -322 minecraft:water[level=0]
fill 43 59 -322 48 59 -322 minecraft:water[level=0]
fill 55 59 -322 58 59 -322 minecraft:air
fill 44 59 -323 50 59 -323 minecraft:water[level=0]
fill 56 59 -323 57 59 -323 minecraft:air
fill 44 59 -324 50 59 -324 minecraft:water[level=0]
fill 45 59 -325 49 59 -325 minecraft:water[level=0]
fill 45 59 -326 49 59 -326 minecraft:water[level=0]
setblock 55 59 -326 minecraft:water[level=0]
fill 45 59 -327 50 59 -327 minecraft:water[level=0]
fill 55 59 -327 57 59 -327 minecraft:water[level=0]
fill 46 59 -328 50 59 -328 minecraft:water[level=0]
fill 55 59 -328 57 59 -328 minecraft:water[level=0]
fill 46 59 -329 51 59 -329 minecraft:water[level=0]
fill 54 59 -329 56 59 -329 minecraft:water[level=0]
fill 47 59 -330 56 59 -330 minecraft:water[level=0]
fill 48 59 -331 56 59 -331 minecraft:water[level=0]
fill 48 59 -332 55 59 -332 minecraft:water[level=0]
fill 50 59 -333 54 59 -333 minecraft:water[level=0]
fill 52 59 -334 55 59 -334 minecraft:water[level=0]
setblock 54 59 -335 minecraft:water[level=0]
fill 30 59 -338 32 59 -338 minecraft:water[level=0]
fill 27 59 -339 32 59 -339 minecraft:water[level=0]
fill 50 59 -339 56 59 -339 minecraft:water[level=0]
fill 27 59 -340 33 59 -340 minecraft:water[level=0]
setblock 51 59 -340 minecraft:water[level=0]
fill 52 59 -340 53 59 -340 minecraft:kelp_plant
fill 54 59 -340 57 59 -340 minecraft:water[level=0]
fill 26 59 -341 33 59 -341 minecraft:water[level=0]
fill 50 59 -341 57 59 -341 minecraft:water[level=0]
setblock 58 59 -341 minecraft:tall_seagrass[half=lower]
setblock 8 59 -342 minecraft:water[level=0]
fill 26 59 -342 34 59 -342 minecraft:water[level=0]
fill 50 59 -342 57 59 -342 minecraft:water[level=0]
setblock 58 59 -342 minecraft:kelp_plant
fill 8 59 -343 9 59 -343 minecraft:water[level=0]
fill 15 59 -343 17 59 -343 minecraft:water[level=0]
fill 26 59 -343 35 59 -343 minecraft:water[level=0]
setblock 36 59 -343 minecraft:tall_seagrass[half=upper]
fill 37 59 -343 44 59 -343 minecraft:water[level=0]
fill 50 59 -343 52 59 -343 minecraft:water[level=0]
setblock 53 59 -343 minecraft:kelp_plant
fill 54 59 -343 60 59 -343 minecraft:water[level=0]
fill 8 59 -344 18 59 -344 minecraft:water[level=0]
setblock 19 59 -344 minecraft:seagrass
fill 26 59 -344 45 59 -344 minecraft:water[level=0]
setblock 48 59 -344 minecraft:water[level=0]
fill 50 59 -344 61 59 -344 minecraft:water[level=0]
fill 8 59 -345 22 59 -345 minecraft:water[level=0]
fill 25 59 -345 57 59 -345 minecraft:water[level=0]
setblock 58 59 -345 minecraft:kelp_plant
fill 59 59 -345 60 59 -345 minecraft:water[level=0]
setblock 61 59 -345 minecraft:kelp_plant
fill 8 59 -346 38 59 -346 minecraft:water[level=0]
setblock 39 59 -346 minecraft:kelp_plant
fill 40 59 -346 44 59 -346 minecraft:water[level=0]
setblock 45 59 -346 minecraft:kelp_plant
fill 46 59 -346 47 59 -346 minecraft:water[level=0]
setblock 48 59 -346 minecraft:kelp_plant
setblock 49 59 -346 minecraft:kelp[age=25]
fill 50 59 -346 51 59 -346 minecraft:water[level=0]
setblock 52 59 -346 minecraft:kelp[age=25]
fill 53 59 -346 57 59 -346 minecraft:water[level=0]
setblock 58 59 -346 minecraft:kelp_plant
setblock 59 59 -346 minecraft:water[level=0]
setblock 60 59 -346 minecraft:kelp_plant
setblock 61 59 -346 minecraft:seagrass
fill 8 59 -347 31 59 -347 minecraft:water[level=0]
setblock 32 59 -347 minecraft:kelp_plant
fill 33 59 -347 47 59 -347 minecraft:water[level=0]
setblock 48 59 -347 minecraft:kelp[age=25]
fill 49 59 -347 57 59 -347 minecraft:water[level=0]
setblock 58 59 -347 minecraft:kelp_plant
fill 59 59 -347 61 59 -347 minecraft:water[level=0]
fill 8 59 -348 50 59 -348 minecraft:water[level=0]
setblock 51 59 -348 minecraft:kelp_plant
fill 52 59 -348 57 59 -348 minecraft:water[level=0]
setblock 58 59 -348 minecraft:kelp_plant
fill 59 59 -348 61 59 -348 minecraft:water[level=0]
fill 8 59 -349 43 59 -349 minecraft:water[level=0]
setblock 44 59 -349 minecraft:kelp_plant
fill 45 59 -349 48 59 -349 minecraft:water[level=0]
setblock 49 59 -349 minecraft:kelp_plant
fill 50 59 -349 55 59 -349 minecraft:water[level=0]
setblock 56 59 -349 minecraft:kelp[age=25]
fill 57 59 -349 61 59 -349 minecraft:water[level=0]
fill 8 59 -350 37 59 -350 minecraft:water[level=0]
setblock 38 59 -350 minecraft:kelp_plant
fill 39 59 -350 51 59 -350 minecraft:water[level=0]
setblock 52 59 -350 minecraft:kelp_plant
fill 53 59 -350 54 59 -350 minecraft:water[level=0]
setblock 55 59 -350 minecraft:kelp_plant
setblock 56 59 -350 minecraft:water[level=0]
setblock 57 59 -350 minecraft:kelp_plant
fill 58 59 -350 62 59 -350 minecraft:water[level=0]
fill 8 59 -351 50 59 -351 minecraft:water[level=0]
setblock 51 59 -351 minecraft:kelp_plant
fill 52 59 -351 64 59 -351 minecraft:water[level=0]
fill 8 59 -352 32 59 -352 minecraft:water[level=0]
setblock 33 59 -352 minecraft:kelp_plant
fill 34 59 -352 42 59 -352 minecraft:water[level=0]
setblock 43 59 -352 minecraft:kelp_plant
fill 44 59 -352 47 59 -352 minecraft:water[level=0]
setblock 48 59 -352 minecraft:kelp[age=25]
fill 49 59 -352 61 59 -352 minecraft:water[level=0]
setblock 62 59 -352 minecraft:kelp[age=25]
fill 63 59 -352 66 59 -352 minecraft:water[level=0]
fill 8 59 -353 48 59 -353 minecraft:water[level=0]
setblock 49 59 -353 minecraft:kelp_plant
fill 50 59 -353 66 59 -353 minecraft:water[level=0]
setblock 71 59 -353 minecraft:water[level=0]
fill 8 59 -354 67 59 -354 minecraft:water[level=0]
setblock 68 59 -354 minecraft:kelp_plant
fill 69 59 -354 71 59 -354 minecraft:water[level=0]
fill 8 59 -355 63 59 -355 minecraft:water[level=0]
setblock 64 59 -355 minecraft:kelp_plant
fill 65 59 -355 71 59 -355 minecraft:water[level=0]
fill 8 59 -356 71 59 -356 minecraft:water[level=0]
fill 8 59 -357 62 59 -357 minecraft:water[level=0]
setblock 63 59 -357 minecraft:kelp_plant
fill 64 59 -357 71 59 -357 minecraft:water[level=0]
fill 8 59 -358 53 59 -358 minecraft:water[level=0]
setblock 54 59 -358 minecraft:kelp_plant
fill 55 59 -358 71 59 -358 minecraft:water[level=0]
fill 8 59 -359 71 59 -359 minecraft:water[level=0]
fill 8 59 -360 71 59 -360 minecraft:water[level=0]
fill 8 59 -361 49 59 -361 minecraft:water[level=0]
setblock 50 59 -361 minecraft:kelp[age=25]
fill 51 59 -361 52 59 -361 minecraft:water[level=0]
setblock 53 59 -361 minecraft:kelp[age=25]
fill 54 59 -361 71 59 -361 minecraft:water[level=0]
fill 8 59 -362 69 59 -362 minecraft:water[level=0]
setblock 70 59 -362 minecraft:kelp_plant
setblock 71 59 -362 minecraft:water[level=0]
fill 8 59 -363 47 59 -363 minecraft:water[level=0]
setblock 48 59 -363 minecraft:kelp_plant
setblock 49 59 -363 minecraft:water[level=0]
setblock 50 59 -363 minecraft:kelp_plant
fill 51 59 -363 71 59 -363 minecraft:water[level=0]
fill 8 59 -364 71 59 -364 minecraft:water[level=0]
fill 8 59 -365 54 59 -365 minecraft:water[level=0]
setblock 55 59 -365 minecraft:kelp_plant
fill 56 59 -365 71 59 -365 minecraft:water[level=0]
fill 8 59 -366 71 59 -366 minecraft:water[level=0]
fill 8 59 -367 56 59 -367 minecraft:water[level=0]
setblock 57 59 -367 minecraft:kelp_plant
fill 58 59 -367 71 59 -367 minecraft:water[level=0]
fill 8 59 -368 63 59 -368 minecraft:water[level=0]
setblock 64 59 -368 minecraft:kelp_plant
fill 65 59 -368 71 59 -368 minecraft:water[level=0]
fill 8 59 -369 71 59 -369 minecraft:water[level=0]
fill 8 59 -370 71 59 -370 minecraft:water[level=0]
fill 8 59 -371 71 59 -371 minecraft:water[level=0]
fill 8 59 -372 71 59 -372 minecraft:water[level=0]
fill 8 59 -373 71 59 -373 minecraft:water[level=0]
fill 8 59 -374 71 59 -374 minecraft:water[level=0]
fill 8 59 -375 71 59 -375 minecraft:water[level=0]
fill 8 59 -376 71 59 -376 minecraft:water[level=0]
fill 8 59 -377 71 59 -377 minecraft:water[level=0]
fill 8 59 -378 71 59 -378 minecraft:water[level=0]
fill 8 59 -379 71 59 -379 minecraft:water[level=0]
fill 8 59 -380 71 59 -380 minecraft:water[level=0]
fill 8 59 -381 71 59 -381 minecraft:water[level=0]
fill 8 59 -382 71 59 -382 minecraft:water[level=0]
fill 17 58 -319 24 58 -319 minecraft:water[level=0]
fill 41 58 -319 44 58 -319 minecraft:water[level=0]
fill 47 58 -319 49 58 -319 minecraft:air
fill 56 58 -319 57 58 -319 minecraft:air
fill 17 58 -320 24 58 -320 minecraft:water[level=0]
fill 41 58 -320 45 58 -320 minecraft:water[level=0]
fill 48 58 -320 50 58 -320 minecraft:air
fill 17 58 -321 23 58 -321 minecraft:water[level=0]
fill 41 58 -321 45 58 -321 minecraft:water[level=0]
fill 50 58 -321 51 58 -321 minecraft:air
fill 55 58 -321 57 58 -321 minecraft:air
fill 18 58 -322 22 58 -322 minecraft:water[level=0]
fill 40 58 -322 45 58 -322 minecraft:water[level=0]
fill 55 58 -322 57 58 -322 minecraft:air
fill 40 58 -323 47 58 -323 minecraft:water[level=0]
fill 55 58 -323 57 58 -323 minecraft:air
fill 39 58 -324 42 58 -324 minecraft:water[level=0]
fill 44 58 -324 48 58 -324 minecraft:water[level=0]
fill 55 58 -324 57 58 -324 minecraft:air
fill 38 58 -325 41 58 -325 minecraft:water[level=0]
fill 44 58 -325 49 58 -325 minecraft:water[level=0]
fill 37 58 -326 39 58 -326 minecraft:water[level=0]
fill 45 58 -326 49 58 -326 minecraft:water[level=0]
fill 45 58 -327 49 58 -327 minecraft:water[level=0]
fill 46 58 -328 50 58 -328 minecraft:water[level=0]
fill 47 58 -329 51 58 -329 minecraft:water[level=0]
fill 55 58 -329 56 58 -329 minecraft:water[level=0]
fill 47 58 -330 52 58 -330 minecraft:water[level=0]
fill 54 58 -330 56 58 -330 minecraft:water[level=0]
fill 48 58 -331 55 58 -331 minecraft:water[level=0]
fill 49 58 -332 54 58 -332 minecraft:water[level=0]
fill 50 58 -333 55 58 -333 minecraft:water[level=0]
fill 51 58 -334 55 58 -334 minecraft:water[level=0]
fill 52 58 -335 55 58 -335 minecraft:water[level=0]
setblock 54 58 -336 minecraft:water[level=0]
setblock 32 58 -338 minecraft:water[level=0]
fill 28 58 -339 32 58 -339 minecraft:water[level=0]
fill 50 58 -339 56 58 -339 minecraft:water[level=0]
fill 27 58 -340 33 58 -340 minecraft:water[level=0]
fill 50 58 -340 51 58 -340 minecraft:water[level=0]
fill 52 58 -340 53 58 -340 minecraft:kelp_plant
fill 54 58 -340 57 58 -340 minecraft:water[level=0]
fill 27 58 -341 33 58 -341 minecraft:water[level=0]
fill 50 58 -341 57 58 -341 minecraft:water[level=0]
setblock 8 58 -342 minecraft:water[level=0]
fill 27 58 -342 33 58 -342 minecraft:water[level=0]
setblock 34 58 -342 minecraft:seagrass
fill 50 58 -342 57 58 -342 minecraft:water[level=0]
setblock 58 58 -342 minecraft:kelp_plant
fill 8 58 -343 9 58 -343 minecraft:water[level=0]
fill 16 58 -343 17 58 -343 minecraft:water[level=0]
fill 26 58 -343 35 58 -343 minecraft:water[level=0]
setblock 36 58 -343 minecraft:tall_seagrass[half=lower]
setblock 37 58 -343 minecraft:seagrass
fill 38 58 -343 39 58 -343 minecraft:water[level=0]
fill 41 58 -343 42 58 -343 minecraft:seagrass
fill 43 58 -343 45 58 -343 minecraft:water[level=0]
fill 49 58 -343 52 58 -343 minecraft:water[level=0]
setblock 53 58 -343 minecraft:kelp_plant
fill 54 58 -343 59 58 -343 minecraft:water[level=0]
setblock 60 58 -343 minecraft:seagrass
fill 8 58 -344 18 58 -344 minecraft:water[level=0]
fill 26 58 -344 45 58 -344 minecraft:water[level=0]
fill 47 58 -344 60 58 -344 minecraft:water[level=0]
fill 8 58 -345 20 58 -345 minecraft:water[level=0]
fill 26 58 -345 57 58 -345 minecraft:water[level=0]
setblock 58 58 -345 minecraft:kelp_plant
fill 59 58 -345 60 58 -345 minecraft:water[level=0]
fill 8 58 -346 38 58 -346 minecraft:water[level=0]
setblock 39 58 -346 minecraft:kelp_plant
fill 40 58 -346 44 58 -346 minecraft:water[level=0]
setblock 45 58 -346 minecraft:kelp_plant
fill 46 58 -346 47 58 -346 minecraft:water[level=0]
fill 48 58 -346 49 58 -346 minecraft:kelp_plant
fill 50 58 -346 51 58 -346 minecraft:water[level=0]
setblock 52 58 -346 minecraft:kelp_plant
fill 53 58 -346 57 58 -346 minecraft:water[level=0]
setblock 58 58 -346 minecraft:kelp_plant
setblock 59 58 -346 minecraft:water[level=0]
setblock 60 58 -346 minecraft:kelp_plant
fill 8 58 -347 31 58 -347 minecraft:water[level=0]
setblock 32 58 -347 minecraft:kelp_plant
fill 33 58 -347 47 58 -347 minecraft:water[level=0]
setblock 48 58 -347 minecraft:kelp_plant
fill 49 58 -347 54 58 -347 minecraft:water[level=0]
setblock 55 58 -347 minecraft:kelp[age=25]
fill 56 58 -347 57 58 -347 minecraft:water[level=0]
setblock 58 58 -347 minecraft:kelp_plant
fill 59 58 -347 61 58 -347 minecraft:water[level=0]
fill 8 58 -348 50 58 -348 minecraft:water[level=0]
setblock 51 58 -348 minecraft:kelp_plant
fill 52 58 -348 57 58 -348 minecraft:water[level=0]
setblock 58 58 -348 minecraft:kelp_plant
fill 59 58 -348 60 58 -348 minecraft:water[level=0]
setblock 61 58 -348 minecraft:seagrass
fill 8 58 -349 43 58 -349 minecraft:water[level=0]
setblock 44 58 -349 minecraft:kelp_plant
fill 45 58 -349 48 58 -349 minecraft:water[level=0]
setblock 49 58 -349 minecraft:kelp_plant
fill 50 58 -349 55 58 -349 minecraft:water[level=0]
setblock 56 58 -349 minecraft:kelp_plant
fill 57 58 -349 61 58 -349 minecraft:water[level=0]
fill 8 58 -350 37 58 -350 minecraft:water[level=0]
setblock 38 58 -350 minecraft:kelp_plant
fill 39 58 -350 51 58 -350 minecraft:water[level=0]
setblock 52 58 -350 minecraft:kelp_plant
fill 53 58 -350 54 58 -350 minecraft:water[level=0]
setblock 55 58 -350 minecraft:kelp_plant
setblock 56 58 -350 minecraft:water[level=0]
setblock 57 58 -350 minecraft:kelp_plant
fill 58 58 -350 62 58 -350 minecraft:water[level=0]
fill 8 58 -351 50 58 -351 minecraft:water[level=0]
setblock 51 58 -351 minecraft:kelp_plant
fill 52 58 -351 55 58 -351 minecraft:water[level=0]
setblock 56 58 -351 minecraft:kelp[age=25]
fill 57 58 -351 64 58 -351 minecraft:water[level=0]
fill 8 58 -352 32 58 -352 minecraft:water[level=0]
setblock 33 58 -352 minecraft:kelp_plant
fill 34 58 -352 42 58 -352 minecraft:water[level=0]
setblock 43 58 -352 minecraft:kelp_plant
fill 44 58 -352 47 58 -352 minecraft:water[level=0]
setblock 48 58 -352 minecraft:kelp_plant
fill 49 58 -352 61 58 -352 minecraft:water[level=0]
setblock 62 58 -352 minecraft:kelp_plant
fill 63 58 -352 65 58 -352 minecraft:water[level=0]
fill 8 58 -353 48 58 -353 minecraft:water[level=0]
setblock 49 58 -353 minecraft:kelp_plant
fill 50 58 -353 65 58 -353 minecraft:water[level=0]
setblock 66 58 -353 minecraft:tall_seagrass[half=upper]
fill 8 58 -354 67 58 -354 minecraft:water[level=0]
fill 69 58 -354 71 58 -354 minecraft:water[level=0]
fill 8 58 -355 63 58 -355 minecraft:water[level=0]
setblock 64 58 -355 minecraft:kelp_plant
fill 65 58 -355 71 58 -355 minecraft:water[level=0]
fill 8 58 -356 71 58 -356 minecraft:water[level=0]
fill 8 58 -357 62 58 -357 minecraft:water[level=0]
setblock 63 58 -357 minecraft:kelp_plant
fill 64 58 -357 66 58 -357 minecraft:water[level=0]
setblock 67 58 -357 minecraft:kelp[age=24]
fill 68 58 -357 71 58 -357 minecraft:water[level=0]
fill 8 58 -358 53 58 -358 minecraft:water[level=0]
setblock 54 58 -358 minecraft:kelp_plant
fill 55 58 -358 71 58 -358 minecraft:water[level=0]
fill 8 58 -359 71 58 -359 minecraft:water[level=0]
fill 8 58 -360 71 58 -360 minecraft:water[level=0]
fill 8 58 -361 49 58 -361 minecraft:water[level=0]
setblock 50 58 -361 minecraft:kelp_plant
fill 51 58 -361 52 58 -361 minecraft:water[level=0]
setblock 53 58 -361 minecraft:kelp_plant
fill 54 58 -361 64 58 -361 minecraft:water[level=0]
setblock 65 58 -361 minecraft:kelp[age=25]
fill 66 58 -361 71 58 -361 minecraft:water[level=0]
fill 8 58 -362 68 58 -362 minecraft:water[level=0]
setblock 69 58 -362 minecraft:kelp[age=25]
setblock 70 58 -362 minecraft:kelp_plant
setblock 71 58 -362 minecraft:water[level=0]
fill 8 58 -363 47 58 -363 minecraft:water[level=0]
setblock 48 58 -363 minecraft:kelp_plant
setblock 49 58 -363 minecraft:water[level=0]
setblock 50 58 -363 minecraft:kelp_plant
fill 51 58 -363 71 58 -363 minecraft:water[level=0]
fill 8 58 -364 71 58 -364 minecraft:water[level=0]
fill 8 58 -365 54 58 -365 minecraft:water[level=0]
setblock 55 58 -365 minecraft:kelp_plant
fill 56 58 -365 71 58 -365 minecraft:water[level=0]
fill 8 58 -366 56 58 -366 minecraft:water[level=0]
setblock 57 58 -366 minecraft:kelp[age=25]
fill 58 58 -366 71 58 -366 minecraft:water[level=0]
fill 8 58 -367 56 58 -367 minecraft:water[level=0]
setblock 57 58 -367 minecraft:kelp_plant
fill 58 58 -367 71 58 -367 minecraft:water[level=0]
fill 8 58 -368 63 58 -368 minecraft:water[level=0]
setblock 64 58 -368 minecraft:kelp_plant
fill 65 58 -368 71 58 -368 minecraft:water[level=0]
fill 8 58 -369 71 58 -369 minecraft:water[level=0]
fill 8 58 -370 71 58 -370 minecraft:water[level=0]
fill 8 58 -371 71 58 -371 minecraft:water[level=0]
fill 8 58 -372 71 58 -372 minecraft:water[level=0]
fill 8 58 -373 71 58 -373 minecraft:water[level=0]
fill 8 58 -374 71 58 -374 minecraft:water[level=0]
fill 8 58 -375 71 58 -375 minecraft:water[level=0]
fill 8 58 -376 71 58 -376 minecraft:water[level=0]
fill 8 58 -377 71 58 -377 minecraft:water[level=0]
fill 8 58 -378 71 58 -378 minecraft:water[level=0]
fill 8 58 -379 71 58 -379 minecraft:water[level=0]
fill 8 58 -380 71 58 -380 minecraft:water[level=0]
fill 8 58 -381 71 58 -381 minecraft:water[level=0]
fill 8 58 -382 71 58 -382 minecraft:water[level=0]
fill 17 57 -319 24 57 -319 minecraft:water[level=0]
fill 41 57 -319 45 57 -319 minecraft:water[level=0]
fill 47 57 -319 48 57 -319 minecraft:air
fill 16 57 -320 24 57 -320 minecraft:water[level=0]
fill 40 57 -320 44 57 -320 minecraft:water[level=0]
fill 46 57 -320 49 57 -320 minecraft:air
fill 16 57 -321 23 57 -321 minecraft:water[level=0]
fill 40 57 -321 44 57 -321 minecraft:water[level=0]
fill 48 57 -321 49 57 -321 minecraft:air
fill 17 57 -322 22 57 -322 minecraft:water[level=0]
fill 39 57 -322 45 57 -322 minecraft:water[level=0]
fill 18 57 -323 21 57 -323 minecraft:water[level=0]
fill 38 57 -323 46 57 -323 minecraft:water[level=0]
fill 28 57 -324 31 57 -324 minecraft:water[level=0]
fill 37 57 -324 47 57 -324 minecraft:water[level=0]
fill 29 57 -325 42 57 -325 minecraft:water[level=0]
fill 45 57 -325 48 57 -325 minecraft:water[level=0]
fill 29 57 -326 41 57 -326 minecraft:water[level=0]
fill 45 57 -326 48 57 -326 minecraft:water[level=0]
fill 30 57 -327 40 57 -327 minecraft:water[level=0]
fill 46 57 -327 47 57 -327 minecraft:water[level=0]
fill 32 57 -328 38 57 -328 minecraft:water[level=0]
fill 51 57 -331 53 57 -331 minecraft:water[level=0]
fill 51 57 -332 54 57 -332 minecraft:water[level=0]
fill 51 57 -333 55 57 -333 minecraft:water[level=0]
fill 52 57 -334 55 57 -334 minecraft:water[level=0]
fill 52 57 -335 55 57 -335 minecraft:water[level=0]
setblock 54 57 -336 minecraft:water[level=0]
fill 28 57 -339 32 57 -339 minecraft:water[level=0]
fill 27 57 -340 32 57 -340 minecraft:water[level=0]
fill 50 57 -340 51 57 -340 minecraft:water[level=0]
fill 52 57 -340 53 57 -340 minecraft:kelp_plant
fill 54 57 -340 57 57 -340 minecraft:water[level=0]
fill 27 57 -341 33 57 -341 minecraft:water[level=0]
fill 50 57 -341 52 57 -341 minecraft:water[level=0]
setblock 53 57 -341 minecraft:kelp[age=24]
setblock 54 57 -341 minecraft:water[level=0]
setblock 55 57 -341 minecraft:kelp[age=25]
fill 56 57 -341 57 57 -341 minecraft:water[level=0]
fill 27 57 -342 33 57 -342 minecraft:water[level=0]
fill 49 57 -342 57 57 -342 minecraft:water[level=0]
setblock 8 57 -343 minecraft:water[level=0]
setblock 16 57 -343 minecraft:water[level=0]
fill 27 57 -343 35 57 -343 minecraft:water[level=0]
setblock 45 57 -343 minecraft:water[level=0]
fill 48 57 -343 52 57 -343 minecraft:water[level=0]
setblock 53 57 -343 minecraft:kelp_plant
fill 54 57 -343 59 57 -343 minecraft:water[level=0]
fill 8 57 -344 18 57 -344 minecraft:water[level=0]
fill 27 57 -344 52 57 -344 minecraft:water[level=0]
setblock 53 57 -344 minecraft:kelp[age=25]
fill 54 57 -344 59 57 -344 minecraft:water[level=0]
setblock 60 57 -344 minecraft:kelp[age=25]
fill 8 57 -345 19 57 -345 minecraft:water[level=0]
fill 26 57 -345 57 57 -345 minecraft:water[level=0]
setblock 58 57 -345 minecraft:kelp_plant
fill 59 57 -345 60 57 -345 minecraft:water[level=0]
fill 8 57 -346 20 57 -346 minecraft:water[level=0]
setblock 21 57 -346 minecraft:seagrass
setblock 22 57 -346 minecraft:water[level=0]
setblock 25 57 -346 minecraft:seagrass
fill 26 57 -346 38 57 -346 minecraft:water[level=0]
setblock 39 57 -346 minecraft:kelp_plant
fill 40 57 -346 44 57 -346 minecraft:water[level=0]
setblock 45 57 -346 minecraft:kelp_plant
fill 46 57 -346 47 57 -346 minecraft:water[level=0]
fill 48 57 -346 49 57 -346 minecraft:kelp_plant
fill 50 57 -346 51 57 -346 minecraft:water[level=0]
setblock 52 57 -346 minecraft:kelp_plant
fill 53 57 -346 57 57 -346 minecraft:water[level=0]
setblock 58 57 -346 minecraft:kelp_plant
setblock 59 57 -346 minecraft:water[level=0]
setblock 60 57 -346 minecraft:kelp_plant
fill 8 57 -347 31 57 -347 minecraft:water[level=0]
setblock 32 57 -347 minecraft:kelp_plant
fill 33 57 -347 47 57 -347 minecraft:water[level=0]
setblock 48 57 -347 minecraft:kelp_plant
fill 49 57 -347 54 57 -347 minecraft:water[level=0]
setblock 55 57 -347 minecraft:kelp_plant
fill 56 57 -347 57 57 -347 minecraft:water[level=0]
setblock 58 57 -347 minecraft:kelp_plant
fill 59 57 -347 60 57 -347 minecraft:water[level=0]
fill 8 57 -348 50 57 -348 minecraft:water[level=0]
setblock 51 57 -348 minecraft:kelp_plant
fill 52 57 -348 57 57 -348 minecraft:water[level=0]
setblock 58 57 -348 minecraft:kelp_plant
fill 59 57 -348 60 57 -348 minecraft:water[level=0]
fill 8 57 -349 38 57 -349 minecraft:water[level=0]
setblock 39 57 -349 minecraft:kelp[age=25]
fill 40 57 -349 43 57 -349 minecraft:water[level=0]
setblock 44 57 -349 minecraft:kelp_plant
fill 45 57 -349 48 57 -349 minecraft:water[level=0]
setblock 49 57 -349 minecraft:kelp_plant
fill 50 57 -349 55 57 -349 minecraft:water[level=0]
setblock 56 57 -349 minecraft:kelp_plant
fill 57 57 -349 59 57 -349 minecraft:water[level=0]
setblock 60 57 -349 minecraft:kelp[age=25]
setblock 61 57 -349 minecraft:seagrass
fill 8 57 -350 33 57 -350 minecraft:water[level=0]
setblock 34 57 -350 minecraft:kelp[age=25]
fill 35 57 -350 37 57 -350 minecraft:water[level=0]
setblock 38 57 -350 minecraft:kelp_plant
fill 39 57 -350 46 57 -350 minecraft:water[level=0]
setblock 47 57 -350 minecraft:kelp[age=25]
fill 48 57 -350 51 57 -350 minecraft:water[level=0]
setblock 52 57 -350 minecraft:kelp_plant
fill 53 57 -350 54 57 -350 minecraft:water[level=0]
setblock 55 57 -350 minecraft:kelp_plant
setblock 56 57 -350 minecraft:water[level=0]
setblock 57 57 -350 minecraft:kelp_plant
setblock 58 57 -350 minecraft:kelp[age=25]
fill 59 57 -350 61 57 -350 minecraft:water[level=0]
fill 8 57 -351 50 57 -351 minecraft:water[level=0]
setblock 51 57 -351 minecraft:kelp_plant
fill 52 57 -351 55 57 -351 minecraft:water[level=0]
setblock 56 57 -351 minecraft:kelp_plant
fill 57 57 -351 63 57 -351 minecraft:water[level=0]
fill 8 57 -352 32 57 -352 minecraft:water[level=0]
setblock 33 57 -352 minecraft:kelp_plant
fill 34 57 -352 42 57 -352 minecraft:water[level=0]
setblock 43 57 -352 minecraft:kelp_plant
fill 44 57 -352 47 57 -352 minecraft:water[level=0]
setblock 48 57 -352 minecraft:kelp_plant
fill 49 57 -352 61 57 -352 minecraft:water[level=0]
setblock 62 57 -352 minecraft:kelp_plant
fill 63 57 -352 65 57 -352 minecraft:water[level=0]
fill 8 57 -353 48 57 -353 minecraft:water[level=0]
setblock 49 57 -353 minecraft:kelp_plant
fill 50 57 -353 65 57 -353 minecraft:water[level=0]
setblock 66 57 -353 minecraft:tall_seagrass[half=lower]
fill 8 57 -354 67 57 -354 minecraft:water[level=0]
fill 70 57 -354 71 57 -354 minecraft:water[level=0]
fill 8 57 -355 60 57 -355 minecraft:water[level=0]
setblock 61 57 -355 minecraft:kelp[age=23]
fill 62 57 -355 63 57 -355 minecraft:water[level=0]
setblock 64 57 -355 minecraft:kelp_plant
fill 65 57 -355 71 57 -355 minecraft:water[level=0]
fill 8 57 -356 71 57 -356 minecraft:water[level=0]
fill 8 57 -357 62 57 -357 minecraft:water[level=0]
setblock 63 57 -357 minecraft:kelp_plant
fill 64 57 -357 66 57 -357 minecraft:water[level=0]
setblock 67 57 -357 minecraft:kelp_plant
fill 68 57 -357 71 57 -357 minecraft:water[level=0]
fill 8 57 -358 51 57 -358 minecraft:water[level=0]
setblock 52 57 -358 minecraft:kelp[age=25]
setblock 53 57 -358 minecraft:water[level=0]
setblock 54 57 -358 minecraft:kelp_plant
fill 55 57 -358 71 57 -358 minecraft:water[level=0]
fill 8 57 -359 71 57 -359 minecraft:water[level=0]
fill 8 57 -360 71 57 -360 minecraft:water[level=0]
fill 8 57 -361 49 57 -361 minecraft:water[level=0]
setblock 50 57 -361 minecraft:kelp_plant
fill 51 57 -361 52 57 -361 minecraft:water[level=0]
setblock 53 57 -361 minecraft:kelp_plant
fill 54 57 -361 64 57 -361 minecraft:water[level=0]
setblock 65 57 -361 minecraft:kelp_plant
fill 66 57 -361 71 57 -361 minecraft:water[level=0]
fill 8 57 -362 68 57 -362 minecraft:water[level=0]
fill 69 57 -362 70 57 -362 minecraft:kelp_plant
setblock 71 57 -362 minecraft:water[level=0]
fill 8 57 -363 47 57 -363 minecraft:water[level=0]
setblock 48 57 -363 minecraft:kelp_plant
setblock 49 57 -363 minecraft:water[level=0]
setblock 50 57 -363 minecraft:kelp_plant
fill 51 57 -363 71 57 -363 minecraft:water[level=0]
fill 8 57 -364 68 57 -364 minecraft:water[level=0]
setblock 69 57 -364 minecraft:kelp[age=25]
fill 70 57 -364 71 57 -364 minecraft:water[level=0]
fill 8 57 -365 54 57 -365 minecraft:water[level=0]
setblock 55 57 -365 minecraft:kelp_plant
fill 56 57 -365 65 57 -365 minecraft:water[level=0]
setblock 66 57 -365 minecraft:kelp[age=25]
fill 67 57 -365 71 57 -365 minecraft:water[level=0]
fill 8 57 -366 56 57 -366 minecraft:water[level=0]
setblock 57 57 -366 minecraft:kelp_plant
fill 58 57 -366 71 57 -366 minecraft:water[level=0]
fill 8 57 -367 56 57 -367 minecraft:water[level=0]
setblock 57 57 -367 minecraft:kelp_plant
fill 58 57 -367 70 57 -367 minecraft:water[level=0]
setblock 71 57 -367 minecraft:kelp[age=25]
fill 8 57 -368 63 57 -368 minecraft:water[level=0]
setblock 64 57 -368 minecraft:kelp_plant
fill 65 57 -368 71 57 -368 minecraft:water[level=0]
fill 8 57 -369 71 57 -369 minecraft:water[level=0]
fill 8 57 -370 71 57 -370 minecraft:water[level=0]
fill 8 57 -371 71 57 -371 minecraft:water[level=0]
fill 8 57 -372 71 57 -372 minecraft:water[level=0]
fill 8 57 -373 71 57 -373 minecraft:water[level=0]
fill 8 57 -374 71 57 -374 minecraft:water[level=0]
fill 8 57 -375 71 57 -375 minecraft:water[level=0]
fill 8 57 -376 71 57 -376 minecraft:water[level=0]
fill 8 57 -377 71 57 -377 minecraft:water[level=0]
fill 8 57 -378 71 57 -378 minecraft:water[level=0]
fill 8 57 -379 71 57 -379 minecraft:water[level=0]
fill 8 57 -380 71 57 -380 minecraft:water[level=0]
fill 8 57 -381 71 57 -381 minecraft:water[level=0]
fill 8 57 -382 71 57 -382 minecraft:water[level=0]
fill 16 56 -319 26 56 -319 minecraft:water[level=0]
fill 40 56 -319 45 56 -319 minecraft:water[level=0]
fill 16 56 -320 26 56 -320 minecraft:water[level=0]
fill 40 56 -320 44 56 -320 minecraft:water[level=0]
fill 46 56 -320 47 56 -320 minecraft:air
fill 16 56 -321 28 56 -321 minecraft:water[level=0]
fill 40 56 -321 44 56 -321 minecraft:water[level=0]
setblock 48 56 -321 minecraft:air
fill 16 56 -322 22 56 -322 minecraft:water[level=0]
fill 25 56 -322 28 56 -322 minecraft:water[level=0]
fill 39 56 -322 44 56 -322 minecraft:water[level=0]
fill 16 56 -323 21 56 -323 minecraft:water[level=0]
fill 25 56 -323 30 56 -323 minecraft:water[level=0]
fill 38 56 -323 46 56 -323 minecraft:water[level=0]
fill 18 56 -324 20 56 -324 minecraft:water[level=0]
fill 27 56 -324 33 56 -324 minecraft:water[level=0]
fill 36 56 -324 43 56 -324 minecraft:water[level=0]
fill 27 56 -325 42 56 -325 minecraft:water[level=0]
fill 28 56 -326 41 56 -326 minecraft:water[level=0]
fill 29 56 -327 40 56 -327 minecraft:water[level=0]
fill 31 56 -328 39 56 -328 minecraft:water[level=0]
fill 33 56 -329 35 56 -329 minecraft:water[level=0]
fill 29 56 -339 32 56 -339 minecraft:water[level=0]
fill 28 56 -340 32 56 -340 minecraft:water[level=0]
fill 49 56 -340 51 56 -340 minecraft:water[level=0]
fill 52 56 -340 53 56 -340 minecraft:kelp_plant
fill 54 56 -340 56 56 -340 minecraft:water[level=0]
fill 27 56 -341 32 56 -341 minecraft:water[level=0]
fill 49 56 -341 52 56 -341 minecraft:water[level=0]
setblock 53 56 -341 minecraft:kelp_plant
setblock 54 56 -341 minecraft:water[level=0]
setblock 55 56 -341 minecraft:kelp_plant
fill 56 56 -341 57 56 -341 minecraft:water[level=0]
fill 27 56 -342 33 56 -342 minecraft:water[level=0]
fill 47 56 -342 57 56 -342 minecraft:water[level=0]
fill 27 56 -343 34 56 -343 minecraft:water[level=0]
fill 45 56 -343 52 56 -343 minecraft:water[level=0]
setblock 53 56 -343 minecraft:kelp_plant
fill 54 56 -343 57 56 -343 minecraft:water[level=0]
setblock 58 56 -343 minecraft:tall_seagrass[half=upper]
fill 8 56 -344 17 56 -344 minecraft:water[level=0]
fill 27 56 -344 52 56 -344 minecraft:water[level=0]
setblock 53 56 -344 minecraft:kelp_plant
fill 54 56 -344 59 56 -344 minecraft:water[level=0]
setblock 60 56 -344 minecraft:kelp_plant
fill 8 56 -345 18 56 -345 minecraft:water[level=0]
fill 27 56 -345 47 56 -345 minecraft:water[level=0]
setblock 48 56 -345 minecraft:kelp[age=25]
fill 49 56 -345 52 56 -345 minecraft:water[level=0]
setblock 53 56 -345 minecraft:kelp[age=25]
fill 54 56 -345 57 56 -345 minecraft:water[level=0]
setblock 58 56 -345 minecraft:kelp_plant
fill 59 56 -345 60 56 -345 minecraft:water[level=0]
fill 8 56 -346 18 56 -346 minecraft:water[level=0]
setblock 19 56 -346 minecraft:seagrass
setblock 20 56 -346 minecraft:water[level=0]
fill 26 56 -346 38 56 -346 minecraft:water[level=0]
setblock 39 56 -346 minecraft:kelp_plant
fill 40 56 -346 44 56 -346 minecraft:water[level=0]
setblock 45 56 -346 minecraft:kelp_plant
fill 46 56 -346 47 56 -346 minecraft:water[level=0]
fill 48 56 -346 49 56 -346 minecraft:kelp_plant
fill 50 56 -346 51 56 -346 minecraft:water[level=0]
setblock 52 56 -346 minecraft:kelp_plant
fill 53 56 -346 57 56 -346 minecraft:water[level=0]
setblock 58 56 -346 minecraft:kelp_plant
setblock 59 56 -346 minecraft:water[level=0]
setblock 60 56 -346 minecraft:kelp_plant
fill 8 56 -347 22 56 -347 minecraft:water[level=0]
setblock 23 56 -347 minecraft:tall_seagrass[half=upper]
fill 24 56 -347 31 56 -347 minecraft:water[level=0]
setblock 32 56 -347 minecraft:kelp_plant
fill 33 56 -347 47 56 -347 minecraft:water[level=0]
setblock 48 56 -347 minecraft:kelp_plant
fill 49 56 -347 51 56 -347 minecraft:water[level=0]
setblock 52 56 -347 minecraft:kelp[age=25]
fill 53 56 -347 54 56 -347 minecraft:water[level=0]
setblock 55 56 -347 minecraft:kelp_plant
fill 56 56 -347 57 56 -347 minecraft:water[level=0]
setblock 58 56 -347 minecraft:kelp_plant
fill 59 56 -347 60 56 -347 minecraft:water[level=0]
fill 8 56 -348 50 56 -348 minecraft:water[level=0]
setblock 51 56 -348 minecraft:kelp_plant
fill 52 56 -348 57 56 -348 minecraft:water[level=0]
setblock 58 56 -348 minecraft:kelp_plant
fill 59 56 -348 60 56 -348 minecraft:water[level=0]
fill 8 56 -349 38 56 -349 minecraft:water[level=0]
setblock 39 56 -349 minecraft:kelp_plant
fill 40 56 -349 43 56 -349 minecraft:water[level=0]
setblock 44 56 -349 minecraft:kelp_plant
fill 45 56 -349 47 56 -349 minecraft:water[level=0]
setblock 48 56 -349 minecraft:kelp[age=25]
setblock 49 56 -349 minecraft:kelp_plant
fill 50 56 -349 55 56 -349 minecraft:water[level=0]
setblock 56 56 -349 minecraft:kelp_plant
fill 57 56 -349 59 56 -349 minecraft:water[level=0]
setblock 60 56 -349 minecraft:kelp_plant
fill 8 56 -350 33 56 -350 minecraft:water[level=0]
setblock 34 56 -350 minecraft:kelp_plant
fill 35 56 -350 37 56 -350 minecraft:water[level=0]
setblock 38 56 -350 minecraft:kelp_plant
fill 39 56 -350 46 56 -350 minecraft:water[level=0]
setblock 47 56 -350 minecraft:kelp_plant
fill 48 56 -350 51 56 -350 minecraft:water[level=0]
setblock 52 56 -350 minecraft:kelp_plant
fill 53 56 -350 54 56 -350 minecraft:water[level=0]
setblock 55 56 -350 minecraft:kelp_plant
setblock 56 56 -350 minecraft:water[level=0]
fill 57 56 -350 58 56 -350 minecraft:kelp_plant
fill 59 56 -350 61 56 -350 minecraft:water[level=0]
fill 8 56 -351 50 56 -351 minecraft:water[level=0]
setblock 51 56 -351 minecraft:kelp_plant
fill 52 56 -351 55 56 -351 minecraft:water[level=0]
setblock 56 56 -351 minecraft:kelp_plant
fill 57 56 -351 63 56 -351 minecraft:water[level=0]
fill 8 56 -352 32 56 -352 minecraft:water[level=0]
setblock 33 56 -352 minecraft:kelp_plant
fill 34 56 -352 42 56 -352 minecraft:water[level=0]
setblock 43 56 -352 minecraft:kelp_plant
fill 44 56 -352 47 56 -352 minecraft:water[level=0]
setblock 48 56 -352 minecraft:kelp_plant
fill 49 56 -352 61 56 -352 minecraft:water[level=0]
setblock 62 56 -352 minecraft:kelp_plant
fill 63 56 -352 65 56 -352 minecraft:water[level=0]
fill 8 56 -353 48 56 -353 minecraft:water[level=0]
setblock 49 56 -353 minecraft:kelp_plant
fill 50 56 -353 65 56 -353 minecraft:water[level=0]
fill 8 56 -354 66 56 -354 minecraft:water[level=0]
setblock 71 56 -354 minecraft:water[level=0]
fill 8 56 -355 60 56 -355 minecraft:water[level=0]
setblock 61 56 -355 minecraft:kelp_plant
fill 62 56 -355 63 56 -355 minecraft:water[level=0]
setblock 64 56 -355 minecraft:kelp_plant
fill 65 56 -355 71 56 -355 minecraft:water[level=0]
fill 8 56 -356 71 56 -356 minecraft:water[level=0]
fill 8 56 -357 62 56 -357 minecraft:water[level=0]
setblock 63 56 -357 minecraft:kelp_plant
fill 64 56 -357 66 56 -357 minecraft:water[level=0]
setblock 67 56 -357 minecraft:kelp_plant
fill 68 56 -357 71 56 -357 minecraft:water[level=0]
fill 8 56 -358 51 56 -358 minecraft:water[level=0]
setblock 52 56 -358 minecraft:kelp_plant
setblock 53 56 -358 minecraft:water[level=0]
setblock 54 56 -358 minecraft:kelp_plant
fill 55 56 -358 71 56 -358 minecraft:water[level=0]
fill 8 56 -359 71 56 -359 minecraft:water[level=0]
fill 8 56 -360 68 56 -360 minecraft:water[level=0]
setblock 69 56 -360 minecraft:kelp[age=25]
fill 70 56 -360 71 56 -360 minecraft:water[level=0]
fill 8 56 -361 49 56 -361 minecraft:water[level=0]
setblock 50 56 -361 minecraft:kelp_plant
fill 51 56 -361 52 56 -361 minecraft:water[level=0]
setblock 53 56 -361 minecraft:kelp_plant
fill 54 56 -361 64 56 -361 minecraft:water[level=0]
setblock 65 56 -361 minecraft:kelp_plant
fill 66 56 -361 71 56 -361 minecraft:water[level=0]
fill 8 56 -362 68 56 -362 minecraft:water[level=0]
fill 69 56 -362 70 56 -362 minecraft:kelp_plant
setblock 71 56 -362 minecraft:water[level=0]
fill 8 56 -363 47 56 -363 minecraft:water[level=0]
setblock 48 56 -363 minecraft:kelp_plant
setblock 49 56 -363 minecraft:water[level=0]
setblock 50 56 -363 minecraft:kelp_plant
fill 51 56 -363 71 56 -363 minecraft:water[level=0]
fill 8 56 -364 68 56 -364 minecraft:water[level=0]
setblock 69 56 -364 minecraft:kelp_plant
fill 70 56 -364 71 56 -364 minecraft:water[level=0]
fill 8 56 -365 54 56 -365 minecraft:water[level=0]
setblock 55 56 -365 minecraft:kelp_plant
fill 56 56 -365 60 56 -365 minecraft:water[level=0]
setblock 61 56 -365 minecraft:kelp[age=25]
fill 62 56 -365 65 56 -365 minecraft:water[level=0]
setblock 66 56 -365 minecraft:kelp_plant
fill 67 56 -365 71 56 -365 minecraft:water[level=0]
fill 8 56 -366 56 56 -366 minecraft:water[level=0]
setblock 57 56 -366 minecraft:kelp_plant
fill 58 56 -366 71 56 -366 minecraft:water[level=0]
fill 8 56 -367 56 56 -367 minecraft:water[level=0]
setblock 57 56 -367 minecraft:kelp_plant
fill 58 56 -367 70 56 -367 minecraft:water[level=0]
setblock 71 56 -367 minecraft:kelp_plant
fill 8 56 -368 63 56 -368 minecraft:water[level=0]
setblock 64 56 -368 minecraft:kelp_plant
fill 65 56 -368 71 56 -368 minecraft:water[level=0]
fill 8 56 -369 71 56 -369 minecraft:water[level=0]
fill 8 56 -370 71 56 -370 minecraft:water[level=0]
fill 8 56 -371 71 56 -371 minecraft:water[level=0]
fill 8 56 -372 71 56 -372 minecraft:water[level=0]
fill 8 56 -373 71 56 -373 minecraft:water[level=0]
fill 8 56 -374 71 56 -374 minecraft:water[level=0]
fill 8 56 -375 71 56 -375 minecraft:water[level=0]
fill 8 56 -376 47 56 -376 minecraft:water[level=0]
setblock 48 56 -376 minecraft:seagrass
fill 49 56 -376 71 56 -376 minecraft:water[level=0]
fill 8 56 -377 71 56 -377 minecraft:water[level=0]
fill 8 56 -378 38 56 -378 minecraft:water[level=0]
setblock 39 56 -378 minecraft:tall_seagrass[half=upper]
fill 40 56 -378 71 56 -378 minecraft:water[level=0]
fill 8 56 -379 71 56 -379 minecraft:water[level=0]
fill 8 56 -380 36 56 -380 minecraft:water[level=0]
setblock 37 56 -380 minecraft:tall_seagrass[half=upper]
fill 38 56 -380 40 56 -380 minecraft:water[level=0]
setblock 41 56 -380 minecraft:tall_seagrass[half=upper]
fill 42 56 -380 71 56 -380 minecraft:water[level=0]
fill 8 56 -381 36 56 -381 minecraft:water[level=0]
setblock 37 56 -381 minecraft:tall_seagrass[half=upper]
fill 38 56 -381 40 56 -381 minecraft:water[level=0]
setblock 41 56 -381 minecraft:tall_seagrass[half=upper]
fill 42 56 -381 44 56 -381 minecraft:water[level=0]
setblock 45 56 -381 minecraft:seagrass
fill 46 56 -381 71 56 -381 minecraft:water[level=0]
fill 8 56 -382 35 56 -382 minecraft:water[level=0]
setblock 36 56 -382 minecraft:tall_seagrass[half=upper]
fill 37 56 -382 38 56 -382 minecraft:water[level=0]
setblock 39 56 -382 minecraft:tall_seagrass[half=upper]
fill 40 56 -382 71 56 -382 minecraft:water[level=0]
fill 16 55 -319 27 55 -319 minecraft:water[level=0]
fill 41 55 -319 45 55 -319 minecraft:water[level=0]
fill 15 55 -320 27 55 -320 minecraft:water[level=0]
fill 40 55 -320 44 55 -320 minecraft:water[level=0]
fill 15 55 -321 28 55 -321 minecraft:water[level=0]
fill 40 55 -321 44 55 -321 minecraft:water[level=0]
fill 15 55 -322 22 55 -322 minecraft:water[level=0]
fill 24 55 -322 29 55 -322 minecraft:water[level=0]
fill 39 55 -322 45 55 -322 minecraft:water[level=0]
fill 16 55 -323 21 55 -323 minecraft:water[level=0]
fill 25 55 -323 31 55 -323 minecraft:water[level=0]
fill 38 55 -323 43 55 -323 minecraft:water[level=0]
fill 17 55 -324 20 55 -324 minecraft:water[level=0]
fill 26 55 -324 33 55 -324 minecraft:water[level=0]
fill 36 55 -324 43 55 -324 minecraft:water[level=0]
fill 26 55 -325 42 55 -325 minecraft:water[level=0]
fill 27 55 -326 41 55 -326 minecraft:water[level=0]
fill 29 55 -327 40 55 -327 minecraft:water[level=0]
fill 30 55 -328 39 55 -328 minecraft:water[level=0]
fill 33 55 -329 35 55 -329 minecraft:water[level=0]
fill 31 55 -339 32 55 -339 minecraft:water[level=0]
fill 29 55 -340 32 55 -340 minecraft:water[level=0]
fill 48 55 -340 51 55 -340 minecraft:water[level=0]
fill 52 55 -340 53 55 -340 minecraft:kelp_plant
fill 54 55 -340 56 55 -340 minecraft:water[level=0]
fill 28 55 -341 32 55 -341 minecraft:water[level=0]
fill 47 55 -341 52 55 -341 minecraft:water[level=0]
setblock 53 55 -341 minecraft:kelp_plant
setblock 54 55 -341 minecraft:water[level=0]
setblock 55 55 -341 minecraft:kelp_plant
fill 56 55 -341 57 55 -341 minecraft:water[level=0]
fill 28 55 -342 33 55 -342 minecraft:water[level=0]
fill 47 55 -342 57 55 -342 minecraft:water[level=0]
fill 28 55 -343 34 55 -343 minecraft:water[level=0]
fill 46 55 -343 52 55 -343 minecraft:water[level=0]
setblock 53 55 -343 minecraft:kelp_plant
fill 54 55 -343 57 55 -343 minecraft:water[level=0]
setblock 58 55 -343 minecraft:tall_seagrass[half=lower]
fill 9 55 -344 16 55 -344 minecraft:water[level=0]
fill 27 55 -344 50 55 -344 minecraft:water[level=0]
setblock 51 55 -344 minecraft:kelp[age=25]
setblock 52 55 -344 minecraft:water[level=0]
setblock 53 55 -344 minecraft:kelp_plant
fill 54 55 -344 58 55 -344 minecraft:water[level=0]
setblock 59 55 -344 minecraft:tall_seagrass[half=upper]
setblock 60 55 -344 minecraft:kelp_plant
fill 8 55 -345 16 55 -345 minecraft:water[level=0]
fill 27 55 -345 47 55 -345 minecraft:water[level=0]
setblock 48 55 -345 minecraft:kelp_plant
fill 49 55 -345 52 55 -345 minecraft:water[level=0]
setblock 53 55 -345 minecraft:kelp_plant
fill 54 55 -345 57 55 -345 minecraft:water[level=0]
setblock 58 55 -345 minecraft:kelp_plant
fill 59 55 -345 60 55 -345 minecraft:water[level=0]
fill 8 55 -346 16 55 -346 minecraft:water[level=0]
setblock 17 55 -346 minecraft:seagrass
fill 26 55 -346 38 55 -346 minecraft:water[level=0]
setblock 39 55 -346 minecraft:kelp_plant
fill 40 55 -346 44 55 -346 minecraft:water[level=0]
setblock 45 55 -346 minecraft:kelp_plant
setblock 46 55 -346 minecraft:kelp[age=25]
setblock 47 55 -346 minecraft:water[level=0]
fill 48 55 -346 49 55 -346 minecraft:kelp_plant
fill 50 55 -346 51 55 -346 minecraft:water[level=0]
setblock 52 55 -346 minecraft:kelp_plant
fill 53 55 -346 57 55 -346 minecraft:water[level=0]
setblock 58 55 -346 minecraft:kelp_plant
setblock 59 55 -346 minecraft:water[level=0]
setblock 60 55 -346 minecraft:kelp_plant
fill 8 55 -347 14 55 -347 minecraft:water[level=0]
setblock 15 55 -347 minecraft:tall_seagrass[half=upper]
fill 16 55 -347 18 55 -347 minecraft:water[level=0]
fill 19 55 -347 21 55 -347 minecraft:seagrass
setblock 22 55 -347 minecraft:water[level=0]
setblock 23 55 -347 minecraft:tall_seagrass[half=lower]
fill 24 55 -347 31 55 -347 minecraft:water[level=0]
setblock 32 55 -347 minecraft:kelp_plant
fill 33 55 -347 47 55 -347 minecraft:water[level=0]
setblock 48 55 -347 minecraft:kelp_plant
fill 49 55 -347 51 55 -347 minecraft:water[level=0]
setblock 52 55 -347 minecraft:kelp_plant
setblock 53 55 -347 minecraft:kelp[age=25]
setblock 54 55 -347 minecraft:water[level=0]
setblock 55 55 -347 minecraft:kelp_plant
fill 56 55 -347 57 55 -347 minecraft:water[level=0]
setblock 58 55 -347 minecraft:kelp_plant
fill 59 55 -347 60 55 -347 minecraft:water[level=0]
fill 8 55 -348 50 55 -348 minecraft:water[level=0]
setblock 51 55 -348 minecraft:kelp_plant
fill 52 55 -348 57 55 -348 minecraft:water[level=0]
setblock 58 55 -348 minecraft:kelp_plant
fill 59 55 -348 60 55 -348 minecraft:water[level=0]
fill 8 55 -349 38 55 -349 minecraft:water[level=0]
setblock 39 55 -349 minecraft:kelp_plant
fill 40 55 -349 43 55 -349 minecraft:water[level=0]
setblock 44 55 -349 minecraft:kelp_plant
fill 45 55 -349 47 55 -349 minecraft:water[level=0]
fill 48 55 -349 49 55 -349 minecraft:kelp_plant
fill 50 55 -349 55 55 -349 minecraft:water[level=0]
setblock 56 55 -349 minecraft:kelp_plant
fill 57 55 -349 59 55 -349 minecraft:water[level=0]
setblock 60 55 -349 minecraft:kelp_plant
fill 8 55 -350 33 55 -350 minecraft:water[level=0]
setblock 34 55 -350 minecraft:kelp_plant
fill 35 55 -350 37 55 -350 minecraft:water[level=0]
setblock 38 55 -350 minecraft:kelp_plant
fill 39 55 -350 46 55 -350 minecraft:water[level=0]
setblock 47 55 -350 minecraft:kelp_plant
fill 48 55 -350 51 55 -350 minecraft:water[level=0]
setblock 52 55 -350 minecraft:kelp_plant
fill 53 55 -350 54 55 -350 minecraft:water[level=0]
setblock 55 55 -350 minecraft:kelp_plant
setblock 56 55 -350 minecraft:water[level=0]
fill 57 55 -350 58 55 -350 minecraft:kelp_plant
fill 59 55 -350 61 55 -350 minecraft:water[level=0]
fill 8 55 -351 48 55 -351 minecraft:water[level=0]
setblock 49 55 -351 minecraft:kelp[age=25]
setblock 50 55 -351 minecraft:water[level=0]
setblock 51 55 -351 minecraft:kelp_plant
fill 52 55 -351 55 55 -351 minecraft:water[level=0]
setblock 56 55 -351 minecraft:kelp_plant
fill 57 55 -351 63 55 -351 minecraft:water[level=0]
fill 8 55 -352 32 55 -352 minecraft:water[level=0]
setblock 33 55 -352 minecraft:kelp_plant
fill 34 55 -352 42 55 -352 minecraft:water[level=0]
setblock 43 55 -352 minecraft:kelp_plant
fill 44 55 -352 47 55 -352 minecraft:water[level=0]
setblock 48 55 -352 minecraft:kelp_plant
fill 49 55 -352 61 55 -352 minecraft:water[level=0]
setblock 62 55 -352 minecraft:kelp_plant
fill 63 55 -352 65 55 -352 minecraft:water[level=0]
fill 8 55 -353 48 55 -353 minecraft:water[level=0]
setblock 49 55 -353 minecraft:kelp_plant
fill 50 55 -353 65 55 -353 minecraft:water[level=0]
fill 8 55 -354 56 55 -354 minecraft:water[level=0]
setblock 57 55 -354 minecraft:kelp[age=25]
fill 58 55 -354 66 55 -354 minecraft:water[level=0]
fill 8 55 -355 60 55 -355 minecraft:water[level=0]
setblock 61 55 -355 minecraft:kelp_plant
fill 62 55 -355 63 55 -355 minecraft:water[level=0]
setblock 64 55 -355 minecraft:kelp_plant
fill 65 55 -355 71 55 -355 minecraft:water[level=0]
fill 8 55 -356 71 55 -356 minecraft:water[level=0]
fill 8 55 -357 62 55 -357 minecraft:water[level=0]
setblock 63 55 -357 minecraft:kelp_plant
fill 64 55 -357 66 55 -357 minecraft:water[level=0]
setblock 67 55 -357 minecraft:kelp_plant
fill 68 55 -357 71 55 -357 minecraft:water[level=0]
fill 8 55 -358 51 55 -358 minecraft:water[level=0]
setblock 52 55 -358 minecraft:kelp_plant
setblock 53 55 -358 minecraft:water[level=0]
setblock 54 55 -358 minecraft:kelp_plant
fill 55 55 -358 71 55 -358 minecraft:water[level=0]
fill 8 55 -359 71 55 -359 minecraft:water[level=0]
fill 8 55 -360 68 55 -360 minecraft:water[level=0]
setblock 69 55 -360 minecraft:kelp_plant
fill 70 55 -360 71 55 -360 minecraft:water[level=0]
fill 8 55 -361 49 55 -361 minecraft:water[level=0]
setblock 50 55 -361 minecraft:kelp_plant
fill 51 55 -361 52 55 -361 minecraft:water[level=0]
setblock 53 55 -361 minecraft:kelp_plant
fill 54 55 -361 64 55 -361 minecraft:water[level=0]
setblock 65 55 -361 minecraft:kelp_plant
fill 66 55 -361 68 55 -361 minecraft:water[level=0]
setblock 69 55 -361 minecraft:kelp[age=25]
fill 70 55 -361 71 55 -361 minecraft:water[level=0]
fill 8 55 -362 68 55 -362 minecraft:water[level=0]
fill 69 55 -362 70 55 -362 minecraft:kelp_plant
setblock 71 55 -362 minecraft:water[level=0]
fill 8 55 -363 47 55 -363 minecraft:water[level=0]
setblock 48 55 -363 minecraft:kelp_plant
setblock 49 55 -363 minecraft:water[level=0]
setblock 50 55 -363 minecraft:kelp_plant
fill 51 55 -363 71 55 -363 minecraft:water[level=0]
fill 8 55 -364 68 55 -364 minecraft:water[level=0]
setblock 69 55 -364 minecraft:kelp_plant
fill 70 55 -364 71 55 -364 minecraft:water[level=0]
fill 8 55 -365 54 55 -365 minecraft:water[level=0]
setblock 55 55 -365 minecraft:kelp_plant
fill 56 55 -365 60 55 -365 minecraft:water[level=0]
setblock 61 55 -365 minecraft:kelp_plant
fill 62 55 -365 65 55 -365 minecraft:water[level=0]
setblock 66 55 -365 minecraft:kelp_plant
fill 67 55 -365 71 55 -365 minecraft:water[level=0]
fill 8 55 -366 56 55 -366 minecraft:water[level=0]
setblock 57 55 -366 minecraft:kelp_plant
fill 58 55 -366 64 55 -366 minecraft:water[level=0]
setblock 65 55 -366 minecraft:kelp[age=24]
fill 66 55 -366 71 55 -366 minecraft:water[level=0]
fill 8 55 -367 41 55 -367 minecraft:water[level=0]
setblock 42 55 -367 minecraft:tall_seagrass[half=upper]
fill 43 55 -367 56 55 -367 minecraft:water[level=0]
setblock 57 55 -367 minecraft:kelp_plant
fill 58 55 -367 70 55 -367 minecraft:water[level=0]
setblock 71 55 -367 minecraft:kelp_plant
fill 8 55 -368 63 55 -368 minecraft:water[level=0]
setblock 64 55 -368 minecraft:kelp_plant
fill 65 55 -368 71 55 -368 minecraft:water[level=0]
fill 8 55 -369 71 55 -369 minecraft:water[level=0]
fill 8 55 -370 71 55 -370 minecraft:water[level=0]
fill 8 55 -371 71 55 -371 minecraft:water[level=0]
fill 8 55 -372 71 55 -372 minecraft:water[level=0]
fill 8 55 -373 46 55 -373 minecraft:water[level=0]
setblock 47 55 -373 minecraft:tall_seagrass[half=upper]
fill 48 55 -373 71 55 -373 minecraft:water[level=0]
fill 8 55 -374 27 55 -374 minecraft:water[level=0]
setblock 28 55 -374 minecraft:tall_seagrass[half=upper]
fill 29 55 -374 46 55 -374 minecraft:water[level=0]
setblock 47 55 -374 minecraft:tall_seagrass[half=upper]
fill 48 55 -374 71 55 -374 minecraft:water[level=0]
fill 8 55 -375 50 55 -375 minecraft:water[level=0]
setblock 51 55 -375 minecraft:tall_seagrass[half=upper]
fill 52 55 -375 71 55 -375 minecraft:water[level=0]
fill 8 55 -376 24 55 -376 minecraft:water[level=0]
setblock 25 55 -376 minecraft:tall_seagrass[half=upper]
fill 26 55 -376 47 55 -376 minecraft:water[level=0]
fill 49 55 -376 50 55 -376 minecraft:water[level=0]
setblock 51 55 -376 minecraft:seagrass
fill 52 55 -376 71 55 -376 minecraft:water[level=0]
fill 8 55 -377 25 55 -377 minecraft:water[level=0]
setblock 26 55 -377 minecraft:tall_seagrass[half=upper]
fill 27 55 -377 38 55 -377 minecraft:water[level=0]
setblock 39 55 -377 minecraft:tall_seagrass[half=upper]
fill 40 55 -377 46 55 -377 minecraft:water[level=0]
setblock 47 55 -377 minecraft:seagrass
fill 48 55 -377 50 55 -377 minecraft:water[level=0]
setblock 51 55 -377 minecraft:tall_seagrass[half=upper]
fill 52 55 -377 71 55 -377 minecraft:water[level=0]
fill 8 55 -378 27 55 -378 minecraft:water[level=0]
setblock 28 55 -378 minecraft:tall_seagrass[half=upper]
fill 29 55 -378 31 55 -378 minecraft:water[level=0]
setblock 32 55 -378 minecraft:tall_seagrass[half=upper]
fill 33 55 -378 38 55 -378 minecraft:water[level=0]
setblock 39 55 -378 minecraft:tall_seagrass[half=lower]
fill 40 55 -378 71 55 -378 minecraft:water[level=0]
fill 8 55 -379 39 55 -379 minecraft:water[level=0]
fill 40 55 -379 42 55 -379 minecraft:seagrass
fill 43 55 -379 71 55 -379 minecraft:water[level=0]
fill 8 55 -380 25 55 -380 minecraft:water[level=0]
setblock 26 55 -380 minecraft:tall_seagrass[half=upper]
fill 27 55 -380 36 55 -380 minecraft:water[level=0]
setblock 37 55 -380 minecraft:tall_seagrass[half=lower]
setblock 38 55 -380 minecraft:seagrass
fill 39 55 -380 40 55 -380 minecraft:water[level=0]
setblock 41 55 -380 minecraft:tall_seagrass[half=lower]
fill 42 55 -380 43 55 -380 minecraft:water[level=0]
setblock 45 55 -380 minecraft:seagrass
fill 46 55 -380 71 55 -380 minecraft:water[level=0]
fill 8 55 -381 33 55 -381 minecraft:water[level=0]
setblock 34 55 -381 minecraft:seagrass
setblock 35 55 -381 minecraft:water[level=0]
setblock 36 55 -381 minecraft:seagrass
setblock 37 55 -381 minecraft:tall_seagrass[half=lower]
setblock 38 55 -381 minecraft:seagrass
fill 39 55 -381 40 55 -381 minecraft:water[level=0]
setblock 41 55 -381 minecraft:tall_seagrass[half=lower]
setblock 42 55 -381 minecraft:water[level=0]
fill 46 55 -381 71 55 -381 minecraft:water[level=0]
fill 8 55 -382 29 55 -382 minecraft:water[level=0]
setblock 30 55 -382 minecraft:tall_seagrass[half=upper]
fill 31 55 -382 33 55 -382 minecraft:water[level=0]
setblock 34 55 -382 minecraft:seagrass
setblock 35 55 -382 minecraft:water[level=0]
setblock 36 55 -382 minecraft:tall_seagrass[half=lower]
fill 37 55 -382 38 55 -382 minecraft:water[level=0]
setblock 39 55 -382 minecraft:tall_seagrass[half=lower]
fill 40 55 -382 41 55 -382 minecraft:water[level=0]
setblock 42 55 -382 minecraft:seagrass
fill 49 55 -382 71 55 -382 minecraft:water[level=0]
fill 16 54 -319 27 54 -319 minecraft:water[level=0]
fill 43 54 -319 44 54 -319 minecraft:water[level=0]
fill 15 54 -320 27 54 -320 minecraft:water[level=0]
fill 41 54 -320 44 54 -320 minecraft:water[level=0]
fill 15 54 -321 28 54 -321 minecraft:water[level=0]
fill 41 54 -321 44 54 -321 minecraft:water[level=0]
fill 15 54 -322 22 54 -322 minecraft:water[level=0]
fill 24 54 -322 29 54 -322 minecraft:water[level=0]
fill 40 54 -322 42 54 -322 minecraft:water[level=0]
fill 15 54 -323 21 54 -323 minecraft:water[level=0]
fill 25 54 -323 30 54 -323 minecraft:water[level=0]
fill 39 54 -323 42 54 -323 minecraft:water[level=0]
fill 16 54 -324 20 54 -324 minecraft:water[level=0]
fill 26 54 -324 32 54 -324 minecraft:water[level=0]
fill 38 54 -324 42 54 -324 minecraft:water[level=0]
fill 27 54 -325 41 54 -325 minecraft:water[level=0]
fill 27 54 -326 40 54 -326 minecraft:water[level=0]
fill 29 54 -327 39 54 -327 minecraft:water[level=0]
fill 32 54 -328 37 54 -328 minecraft:water[level=0]
setblock 32 54 -339 minecraft:water[level=0]
fill 30 54 -340 32 54 -340 minecraft:water[level=0]
fill 48 54 -340 51 54 -340 minecraft:water[level=0]
fill 52 54 -340 53 54 -340 minecraft:kelp_plant
fill 54 54 -340 56 54 -340 minecraft:water[level=0]
fill 30 54 -341 32 54 -341 minecraft:water[level=0]
fill 47 54 -341 52 54 -341 minecraft:water[level=0]
setblock 53 54 -341 minecraft:kelp_plant
setblock 54 54 -341 minecraft:water[level=0]
setblock 55 54 -341 minecraft:kelp_plant
setblock 56 54 -341 minecraft:water[level=0]
setblock 28 54 -342 minecraft:seagrass
fill 29 54 -342 32 54 -342 minecraft:water[level=0]
setblock 33 54 -342 minecraft:seagrass
fill 47 54 -342 57 54 -342 minecraft:water[level=0]
fill 28 54 -343 34 54 -343 minecraft:water[level=0]
fill 46 54 -343 52 54 -343 minecraft:water[level=0]
setblock 53 54 -343 minecraft:kelp_plant
fill 54 54 -343 57 54 -343 minecraft:water[level=0]
fill 14 54 -344 15 54 -344 minecraft:water[level=0]
setblock 16 54 -344 minecraft:seagrass
fill 28 54 -344 50 54 -344 minecraft:water[level=0]
setblock 51 54 -344 minecraft:kelp_plant
setblock 52 54 -344 minecraft:water[level=0]
setblock 53 54 -344 minecraft:kelp_plant
fill 54 54 -344 58 54 -344 minecraft:water[level=0]
setblock 59 54 -344 minecraft:tall_seagrass[half=lower]
setblock 60 54 -344 minecraft:kelp_plant
fill 13 54 -345 16 54 -345 minecraft:water[level=0]
fill 27 54 -345 47 54 -345 minecraft:water[level=0]
setblock 48 54 -345 minecraft:kelp_plant
fill 49 54 -345 52 54 -345 minecraft:water[level=0]
setblock 53 54 -345 minecraft:kelp_plant
fill 54 54 -345 57 54 -345 minecraft:water[level=0]
setblock 58 54 -345 minecraft:kelp_plant
setblock 59 54 -345 minecraft:water[level=0]
setblock 60 54 -345 minecraft:seagrass
fill 13 54 -346 16 54 -346 minecraft:water[level=0]
fill 27 54 -346 38 54 -346 minecraft:water[level=0]
setblock 39 54 -346 minecraft:kelp_plant
fill 40 54 -346 44 54 -346 minecraft:water[level=0]
fill 45 54 -346 46 54 -346 minecraft:kelp_plant
setblock 47 54 -346 minecraft:water[level=0]
fill 48 54 -346 49 54 -346 minecraft:kelp_plant
fill 50 54 -346 51 54 -346 minecraft:water[level=0]
setblock 52 54 -346 minecraft:kelp_plant
fill 53 54 -346 57 54 -346 minecraft:water[level=0]
setblock 58 54 -346 minecraft:kelp_plant
setblock 59 54 -346 minecraft:water[level=0]
setblock 60 54 -346 minecraft:kelp_plant
fill 12 54 -347 14 54 -347 minecraft:water[level=0]
setblock 15 54 -347 minecraft:tall_seagrass[half=lower]
fill 16 54 -347 17 54 -347 minecraft:water[level=0]
fill 25 54 -347 31 54 -347 minecraft:water[level=0]
setblock 32 54 -347 minecraft:kelp_plant
fill 33 54 -347 47 54 -347 minecraft:water[level=0]
setblock 48 54 -347 minecraft:kelp_plant
fill 49 54 -347 51 54 -347 minecraft:water[level=0]
fill 52 54 -347 53 54 -347 minecraft:kelp_plant
setblock 54 54 -347 minecraft:water[level=0]
setblock 55 54 -347 minecraft:kelp_plant
fill 56 54 -347 57 54 -347 minecraft:water[level=0]
setblock 58 54 -347 minecraft:kelp_plant
fill 59 54 -347 60 54 -347 minecraft:water[level=0]
fill 12 54 -348 18 54 -348 minecraft:water[level=0]
setblock 19 54 -348 minecraft:tall_seagrass[half=upper]
fill 21 54 -348 23 54 -348 minecraft:water[level=0]
setblock 24 54 -348 minecraft:tall_seagrass[half=upper]
fill 25 54 -348 50 54 -348 minecraft:water[level=0]
setblock 51 54 -348 minecraft:kelp_plant
fill 52 54 -348 57 54 -348 minecraft:water[level=0]
setblock 58 54 -348 minecraft:kelp_plant
fill 59 54 -348 60 54 -348 minecraft:water[level=0]
fill 11 54 -349 38 54 -349 minecraft:water[level=0]
setblock 39 54 -349 minecraft:kelp_plant
fill 40 54 -349 43 54 -349 minecraft:water[level=0]
setblock 44 54 -349 minecraft:kelp_plant
fill 45 54 -349 47 54 -349 minecraft:water[level=0]
fill 48 54 -349 49 54 -349 minecraft:kelp_plant
fill 50 54 -349 55 54 -349 minecraft:water[level=0]
setblock 56 54 -349 minecraft:kelp_plant
fill 57 54 -349 59 54 -349 minecraft:water[level=0]
setblock 60 54 -349 minecraft:kelp_plant
fill 11 54 -350 22 54 -350 minecraft:water[level=0]
setblock 23 54 -350 minecraft:tall_seagrass[half=upper]
fill 24 54 -350 33 54 -350 minecraft:water[level=0]
setblock 34 54 -350 minecraft:kelp_plant
fill 35 54 -350 37 54 -350 minecraft:water[level=0]
setblock 38 54 -350 minecraft:kelp_plant
fill 39 54 -350 43 54 -350 minecraft:water[level=0]
setblock 44 54 -350 minecraft:kelp[age=24]
fill 45 54 -350 46 54 -350 minecraft:water[level=0]
setblock 47 54 -350 minecraft:kelp_plant
fill 48 54 -350 51 54 -350 minecraft:water[level=0]
setblock 52 54 -350 minecraft:kelp_plant
fill 53 54 -350 54 54 -350 minecraft:water[level=0]
setblock 55 54 -350 minecraft:kelp_plant
setblock 56 54 -350 minecraft:water[level=0]
fill 57 54 -350 58 54 -350 minecraft:kelp_plant
fill 59 54 -350 61 54 -350 minecraft:water[level=0]
fill 10 54 -351 48 54 -351 minecraft:water[level=0]
setblock 49 54 -351 minecraft:kelp_plant
setblock 50 54 -351 minecraft:water[level=0]
setblock 51 54 -351 minecraft:kelp_plant
fill 52 54 -351 55 54 -351 minecraft:water[level=0]
setblock 56 54 -351 minecraft:kelp_plant
fill 57 54 -351 62 54 -351 minecraft:water[level=0]
fill 10 54 -352 32 54 -352 minecraft:water[level=0]
setblock 33 54 -352 minecraft:kelp_plant
fill 34 54 -352 42 54 -352 minecraft:water[level=0]
setblock 43 54 -352 minecraft:kelp_plant
fill 44 54 -352 47 54 -352 minecraft:water[level=0]
setblock 48 54 -352 minecraft:kelp_plant
fill 49 54 -352 56 54 -352 minecraft:water[level=0]
setblock 57 54 -352 minecraft:kelp[age=25]
fill 58 54 -352 61 54 -352 minecraft:water[level=0]
setblock 62 54 -352 minecraft:kelp_plant
fill 63 54 -352 65 54 -352 minecraft:water[level=0]
fill 9 54 -353 48 54 -353 minecraft:water[level=0]
setblock 49 54 -353 minecraft:kelp_plant
fill 50 54 -353 65 54 -353 minecraft:water[level=0]
fill 8 54 -354 56 54 -354 minecraft:water[level=0]
setblock 57 54 -354 minecraft:kelp_plant
fill 58 54 -354 66 54 -354 minecraft:water[level=0]
fill 8 54 -355 58 54 -355 minecraft:water[level=0]
setblock 59 54 -355 minecraft:kelp[age=25]
setblock 60 54 -355 minecraft:water[level=0]
setblock 61 54 -355 minecraft:kelp_plant
fill 62 54 -355 63 54 -355 minecraft:water[level=0]
setblock 64 54 -355 minecraft:kelp_plant
fill 65 54 -355 71 54 -355 minecraft:water[level=0]
fill 8 54 -356 71 54 -356 minecraft:water[level=0]
fill 8 54 -357 62 54 -357 minecraft:water[level=0]
setblock 63 54 -357 minecraft:kelp_plant
fill 64 54 -357 66 54 -357 minecraft:water[level=0]
setblock 67 54 -357 minecraft:kelp_plant
fill 68 54 -357 71 54 -357 minecraft:water[level=0]
fill 8 54 -358 12 54 -358 minecraft:water[level=0]
setblock 13 54 -358 minecraft:tall_seagrass[half=upper]
fill 14 54 -358 51 54 -358 minecraft:water[level=0]
setblock 52 54 -358 minecraft:kelp_plant
setblock 53 54 -358 minecraft:water[level=0]
setblock 54 54 -358 minecraft:kelp_plant
fill 55 54 -358 71 54 -358 minecraft:water[level=0]
setblock 8 54 -359 minecraft:tall_seagrass[half=upper]
setblock 9 54 -359 minecraft:water[level=0]
setblock 10 54 -359 minecraft:tall_seagrass[half=upper]
fill 11 54 -359 71 54 -359 minecraft:water[level=0]
fill 8 54 -360 10 54 -360 minecraft:water[level=0]
fill 11 54 -360 12 54 -360 minecraft:tall_seagrass[half=upper]
fill 13 54 -360 68 54 -360 minecraft:water[level=0]
setblock 69 54 -360 minecraft:kelp_plant
fill 70 54 -360 71 54 -360 minecraft:water[level=0]
fill 8 54 -361 44 54 -361 minecraft:water[level=0]
setblock 45 54 -361 minecraft:tall_seagrass[half=upper]
fill 46 54 -361 49 54 -361 minecraft:water[level=0]
setblock 50 54 -361 minecraft:kelp_plant
fill 51 54 -361 52 54 -361 minecraft:water[level=0]
setblock 53 54 -361 minecraft:kelp_plant
fill 54 54 -361 64 54 -361 minecraft:water[level=0]
setblock 65 54 -361 minecraft:kelp_plant
fill 66 54 -361 68 54 -361 minecraft:water[level=0]
setblock 69 54 -361 minecraft:kelp_plant
fill 70 54 -361 71 54 -361 minecraft:water[level=0]
setblock 8 54 -362 minecraft:water[level=0]
setblock 9 54 -362 minecraft:tall_seagrass[half=upper]
fill 10 54 -362 68 54 -362 minecraft:water[level=0]
fill 69 54 -362 70 54 -362 minecraft:kelp_plant
setblock 71 54 -362 minecraft:water[level=0]
fill 8 54 -363 47 54 -363 minecraft:water[level=0]
setblock 48 54 -363 minecraft:kelp_plant
setblock 49 54 -363 minecraft:water[level=0]
setblock 50 54 -363 minecraft:kelp_plant
fill 51 54 -363 71 54 -363 minecraft:water[level=0]
setblock 8 54 -364 minecraft:tall_seagrass[half=upper]
fill 9 54 -364 68 54 -364 minecraft:water[level=0]
setblock 69 54 -364 minecraft:kelp_plant
fill 70 54 -364 71 54 -364 minecraft:water[level=0]
fill 8 54 -365 46 54 -365 minecraft:water[level=0]
setblock 47 54 -365 minecraft:tall_seagrass[half=upper]
setblock 48 54 -365 minecraft:water[level=0]
setblock 49 54 -365 minecraft:tall_seagrass[half=upper]
fill 50 54 -365 54 54 -365 minecraft:water[level=0]
setblock 55 54 -365 minecraft:kelp_plant
fill 56 54 -365 60 54 -365 minecraft:water[level=0]
setblock 61 54 -365 minecraft:kelp_plant
fill 62 54 -365 65 54 -365 minecraft:water[level=0]
setblock 66 54 -365 minecraft:kelp_plant
fill 67 54 -365 71 54 -365 minecraft:water[level=0]
fill 8 54 -366 46 54 -366 minecraft:water[level=0]
setblock 47 54 -366 minecraft:tall_seagrass[half=upper]
fill 48 54 -366 56 54 -366 minecraft:water[level=0]
setblock 57 54 -366 minecraft:kelp_plant
fill 58 54 -366 64 54 -366 minecraft:water[level=0]
setblock 65 54 -366 minecraft:kelp_plant
fill 66 54 -366 71 54 -366 minecraft:water[level=0]
fill 8 54 -367 41 54 -367 minecraft:water[level=0]
setblock 42 54 -367 minecraft:tall_seagrass[half=lower]
fill 43 54 -367 56 54 -367 minecraft:water[level=0]
setblock 57 54 -367 minecraft:kelp_plant
fill 58 54 -367 70 54 -367 minecraft:water[level=0]
setblock 71 54 -367 minecraft:kelp_plant
fill 8 54 -368 63 54 -368 minecraft:water[level=0]
setblock 64 54 -368 minecraft:kelp_plant
fill 65 54 -368 71 54 -368 minecraft:water[level=0]
fill 8 54 -369 71 54 -369 minecraft:water[level=0]
fill 8 54 -370 45 54 -370 minecraft:water[level=0]
setblock 46 54 -370 minecraft:tall_seagrass[half=upper]
fill 47 54 -370 71 54 -370 minecraft:water[level=0]
fill 8 54 -371 41 54 -371 minecraft:water[level=0]
setblock 42 54 -371 minecraft:seagrass
setblock 43 54 -371 minecraft:water[level=0]
setblock 44 54 -371 minecraft:tall_seagrass[half=upper]
fill 45 54 -371 71 54 -371 minecraft:water[level=0]
fill 8 54 -372 46 54 -372 minecraft:water[level=0]
setblock 47 54 -372 minecraft:seagrass
fill 48 54 -372 71 54 -372 minecraft:water[level=0]
fill 8 54 -373 23 54 -373 minecraft:water[level=0]
setblock 24 54 -373 minecraft:tall_seagrass[half=upper]
fill 25 54 -373 27 54 -373 minecraft:water[level=0]
setblock 28 54 -373 minecraft:tall_seagrass[half=upper]
fill 29 54 -373 30 54 -373 minecraft:water[level=0]
setblock 31 54 -373 minecraft:seagrass
fill 32 54 -373 44 54 -373 minecraft:water[level=0]
setblock 45 54 -373 minecraft:seagrass
setblock 46 54 -373 minecraft:water[level=0]
setblock 47 54 -373 minecraft:tall_seagrass[half=lower]
setblock 48 54 -373 minecraft:seagrass
fill 49 54 -373 71 54 -373 minecraft:water[level=0]
fill 8 54 -374 27 54 -374 minecraft:water[level=0]
setblock 28 54 -374 minecraft:tall_seagrass[half=lower]
fill 29 54 -374 46 54 -374 minecraft:water[level=0]
setblock 47 54 -374 minecraft:tall_seagrass[half=lower]
fill 48 54 -374 71 54 -374 minecraft:water[level=0]
fill 8 54 -375 29 54 -375 minecraft:water[level=0]
setblock 30 54 -375 minecraft:seagrass
fill 31 54 -375 34 54 -375 minecraft:water[level=0]
setblock 35 54 -375 minecraft:seagrass
fill 36 54 -375 46 54 -375 minecraft:water[level=0]
setblock 50 54 -375 minecraft:water[level=0]
setblock 51 54 -375 minecraft:tall_seagrass[half=lower]
fill 52 54 -375 71 54 -375 minecraft:water[level=0]
fill 8 54 -376 19 54 -376 minecraft:water[level=0]
fill 20 54 -376 21 54 -376 minecraft:tall_seagrass[half=upper]
fill 22 54 -376 24 54 -376 minecraft:water[level=0]
setblock 25 54 -376 minecraft:tall_seagrass[half=lower]
fill 26 54 -376 45 54 -376 minecraft:water[level=0]
setblock 52 54 -376 minecraft:seagrass
fill 53 54 -376 71 54 -376 minecraft:water[level=0]
fill 8 54 -377 19 54 -377 minecraft:water[level=0]
setblock 20 54 -377 minecraft:tall_seagrass[half=upper]
fill 21 54 -377 25 54 -377 minecraft:water[level=0]
setblock 26 54 -377 minecraft:tall_seagrass[half=lower]
fill 27 54 -377 30 54 -377 minecraft:water[level=0]
setblock 31 54 -377 minecraft:seagrass
setblock 32 54 -377 minecraft:water[level=0]
setblock 33 54 -377 minecraft:seagrass
fill 34 54 -377 35 54 -377 minecraft:water[level=0]
setblock 36 54 -377 minecraft:seagrass
setblock 37 54 -377 minecraft:water[level=0]
setblock 38 54 -377 minecraft:seagrass
setblock 39 54 -377 minecraft:tall_seagrass[half=lower]
fill 43 54 -377 44 54 -377 minecraft:water[level=0]
setblock 51 54 -377 minecraft:tall_seagrass[half=lower]
setblock 52 54 -377 minecraft:seagrass
fill 53 54 -377 71 54 -377 minecraft:water[level=0]
fill 8 54 -378 22 54 -378 minecraft:water[level=0]
setblock 23 54 -378 minecraft:tall_seagrass[half=upper]
fill 24 54 -378 26 54 -378 minecraft:water[level=0]
setblock 27 54 -378 minecraft:seagrass
setblock 28 54 -378 minecraft:tall_seagrass[half=lower]
fill 29 54 -378 31 54 -378 minecraft:water[level=0]
setblock 32 54 -378 minecraft:tall_seagrass[half=lower]
fill 33 54 -378 34 54 -378 minecraft:water[level=0]
setblock 35 54 -378 minecraft:seagrass
setblock 36 54 -378 minecraft:water[level=0]
fill 37 54 -378 38 54 -378 minecraft:seagrass
fill 51 54 -378 71 54 -378 minecraft:water[level=0]
fill 8 54 -379 17 54 -379 minecraft:water[level=0]
setblock 18 54 -379 minecraft:tall_seagrass[half=upper]
fill 19 54 -379 28 54 -379 minecraft:water[level=0]
setblock 29 54 -379 minecraft:seagrass
setblock 30 54 -379 minecraft:water[level=0]
fill 31 54 -379 32 54 -379 minecraft:seagrass
fill 33 54 -379 35 54 -379 minecraft:water[level=0]
setblock 36 54 -379 minecraft:seagrass
setblock 37 54 -379 minecraft:water[level=0]
fill 50 54 -379 71 54 -379 minecraft:water[level=0]
fill 8 54 -380 14 54 -380 minecraft:water[level=0]
setblock 15 54 -380 minecraft:tall_seagrass[half=upper]
fill 16 54 -380 17 54 -380 minecraft:water[level=0]
setblock 18 54 -380 minecraft:tall_seagrass[half=upper]
fill 19 54 -380 20 54 -380 minecraft:water[level=0]
setblock 21 54 -380 minecraft:tall_seagrass[half=upper]
fill 22 54 -380 23 54 -380 minecraft:water[level=0]
fill 24 54 -380 25 54 -380 minecraft:seagrass
setblock 26 54 -380 minecraft:tall_seagrass[half=lower]
fill 27 54 -380 29 54 -380 minecraft:water[level=0]
setblock 30 54 -380 minecraft:seagrass
setblock 31 54 -380 minecraft:water[level=0]
fill 32 54 -380 34 54 -380 minecraft:seagrass
setblock 35 54 -380 minecraft:water[level=0]
setblock 36 54 -380 minecraft:seagrass
fill 39 54 -380 40 54 -380 minecraft:water[level=8]
fill 50 54 -380 71 54 -380 minecraft:water[level=0]
fill 8 54 -381 11 54 -381 minecraft:water[level=0]
setblock 12 54 -381 minecraft:tall_seagrass[half=upper]
fill 13 54 -381 23 54 -381 minecraft:water[level=0]
setblock 24 54 -381 minecraft:seagrass
fill 25 54 -381 31 54 -381 minecraft:water[level=0]
setblock 32 54 -381 minecraft:seagrass
setblock 33 54 -381 minecraft:water[level=0]
setblock 39 54 -381 minecraft:water[level=8]
fill 51 54 -381 71 54 -381 minecraft:water[level=0]
fill 8 54 -382 12 54 -382 minecraft:water[level=0]
setblock 13 54 -382 minecraft:tall_seagrass[half=upper]
fill 14 54 -382 28 54 -382 minecraft:water[level=0]
setblock 29 54 -382 minecraft:seagrass
setblock 30 54 -382 minecraft:tall_seagrass[half=lower]
fill 31 54 -382 32 54 -382 minecraft:water[level=0]
setblock 38 54 -382 minecraft:water[level=8]
fill 52 54 -382 71 54 -382 minecraft:water[level=0]
fill 16 53 -319 21 53 -319 minecraft:water[level=0]
fill 23 53 -319 26 53 -319 minecraft:water[level=0]
fill 15 53 -320 21 53 -320 minecraft:water[level=0]
fill 23 53 -320 27 53 -320 minecraft:water[level=0]
fill 15 53 -321 21 53 -321 minecraft:water[level=0]
fill 24 53 -321 28 53 -321 minecraft:water[level=0]
fill 15 53 -322 21 53 -322 minecraft:water[level=0]
fill 24 53 -322 28 53 -322 minecraft:water[level=0]
fill 15 53 -323 21 53 -323 minecraft:water[level=0]
fill 25 53 -323 29 53 -323 minecraft:water[level=0]
fill 15 53 -324 20 53 -324 minecraft:water[level=0]
fill 27 53 -324 30 53 -324 minecraft:water[level=0]
fill 16 53 -325 19 53 -325 minecraft:water[level=0]
fill 27 53 -325 31 53 -325 minecraft:water[level=0]
fill 28 53 -326 32 53 -326 minecraft:water[level=0]
fill 31 53 -340 32 53 -340 minecraft:water[level=0]
fill 48 53 -340 51 53 -340 minecraft:water[level=0]
fill 52 53 -340 53 53 -340 minecraft:kelp_plant
fill 54 53 -340 56 53 -340 minecraft:water[level=0]
fill 31 53 -341 32 53 -341 minecraft:water[level=0]
fill 48 53 -341 52 53 -341 minecraft:water[level=0]
setblock 53 53 -341 minecraft:kelp_plant
setblock 54 53 -341 minecraft:water[level=0]
setblock 55 53 -341 minecraft:kelp_plant
setblock 56 53 -341 minecraft:water[level=0]
fill 30 53 -342 32 53 -342 minecraft:water[level=0]
fill 47 53 -342 56 53 -342 minecraft:water[level=0]
fill 29 53 -343 33 53 -343 minecraft:water[level=0]
fill 46 53 -343 52 53 -343 minecraft:water[level=0]
setblock 53 53 -343 minecraft:kelp_plant
fill 54 53 -343 57 53 -343 minecraft:water[level=0]
fill 28 53 -344 50 53 -344 minecraft:water[level=0]
setblock 51 53 -344 minecraft:kelp_plant
setblock 52 53 -344 minecraft:water[level=0]
setblock 53 53 -344 minecraft:kelp_plant
fill 54 53 -344 58 53 -344 minecraft:water[level=0]
fill 28 53 -345 47 53 -345 minecraft:water[level=0]
setblock 48 53 -345 minecraft:kelp_plant
fill 49 53 -345 52 53 -345 minecraft:water[level=0]
setblock 53 53 -345 minecraft:kelp_plant
fill 54 53 -345 57 53 -345 minecraft:water[level=0]
setblock 58 53 -345 minecraft:kelp_plant
setblock 59 53 -345 minecraft:water[level=0]
fill 27 53 -346 38 53 -346 minecraft:water[level=0]
setblock 39 53 -346 minecraft:kelp_plant
fill 40 53 -346 44 53 -346 minecraft:water[level=0]
fill 45 53 -346 46 53 -346 minecraft:kelp_plant
setblock 47 53 -346 minecraft:water[level=0]
fill 48 53 -346 49 53 -346 minecraft:kelp_plant
fill 50 53 -346 51 53 -346 minecraft:water[level=0]
setblock 52 53 -346 minecraft:kelp_plant
fill 53 53 -346 57 53 -346 minecraft:water[level=0]
setblock 58 53 -346 minecraft:kelp_plant
setblock 59 53 -346 minecraft:tall_seagrass[half=upper]
setblock 60 53 -346 minecraft:kelp_plant
setblock 16 53 -347 minecraft:water[level=0]
fill 27 53 -347 31 53 -347 minecraft:water[level=0]
setblock 32 53 -347 minecraft:kelp_plant
fill 33 53 -347 47 53 -347 minecraft:water[level=0]
setblock 48 53 -347 minecraft:kelp_plant
fill 49 53 -347 51 53 -347 minecraft:water[level=0]
fill 52 53 -347 53 53 -347 minecraft:kelp_plant
setblock 54 53 -347 minecraft:water[level=0]
setblock 55 53 -347 minecraft:kelp_plant
fill 56 53 -347 57 53 -347 minecraft:water[level=0]
setblock 58 53 -347 minecraft:kelp_plant
fill 59 53 -347 60 53 -347 minecraft:water[level=0]
setblock 16 53 -348 minecraft:water[level=0]
setblock 17 53 -348 minecraft:seagrass
setblock 19 53 -348 minecraft:tall_seagrass[half=lower]
setblock 21 53 -348 minecraft:water[level=0]
fill 22 53 -348 23 53 -348 minecraft:seagrass
setblock 24 53 -348 minecraft:tall_seagrass[half=lower]
setblock 25 53 -348 minecraft:seagrass
setblock 26 53 -348 minecraft:water[level=0]
setblock 27 53 -348 minecraft:tall_seagrass[half=upper]
fill 28 53 -348 50 53 -348 minecraft:water[level=0]
setblock 51 53 -348 minecraft:kelp_plant
fill 52 53 -348 57 53 -348 minecraft:water[level=0]
setblock 58 53 -348 minecraft:kelp_plant
fill 59 53 -348 60 53 -348 minecraft:water[level=0]
fill 15 53 -349 17 53 -349 minecraft:water[level=0]
setblock 19 53 -349 minecraft:seagrass
fill 20 53 -349 21 53 -349 minecraft:water[level=0]
setblock 23 53 -349 minecraft:seagrass
setblock 24 53 -349 minecraft:water[level=0]
fill 26 53 -349 38 53 -349 minecraft:water[level=0]
setblock 39 53 -349 minecraft:kelp_plant
fill 40 53 -349 43 53 -349 minecraft:water[level=0]
setblock 44 53 -349 minecraft:kelp_plant
fill 45 53 -349 47 53 -349 minecraft:water[level=0]
fill 48 53 -349 49 53 -349 minecraft:kelp_plant
fill 50 53 -349 55 53 -349 minecraft:water[level=0]
setblock 56 53 -349 minecraft:kelp_plant
fill 57 53 -349 59 53 -349 minecraft:water[level=0]
setblock 60 53 -349 minecraft:kelp_plant
fill 15 53 -350 21 53 -350 minecraft:water[level=0]
setblock 23 53 -350 minecraft:tall_seagrass[half=lower]
fill 24 53 -350 33 53 -350 minecraft:water[level=0]
setblock 34 53 -350 minecraft:kelp_plant
fill 35 53 -350 37 53 -350 minecraft:water[level=0]
setblock 38 53 -350 minecraft:kelp_plant
fill 39 53 -350 43 53 -350 minecraft:water[level=0]
setblock 44 53 -350 minecraft:kelp_plant
fill 45 53 -350 46 53 -350 minecraft:water[level=0]
setblock 47 53 -350 minecraft:kelp_plant
fill 48 53 -350 51 53 -350 minecraft:water[level=0]
setblock 52 53 -350 minecraft:kelp_plant
fill 53 53 -350 54 53 -350 minecraft:water[level=0]
setblock 55 53 -350 minecraft:kelp_plant
setblock 56 53 -350 minecraft:water[level=0]
fill 57 53 -350 58 53 -350 minecraft:kelp_plant
fill 59 53 -350 61 53 -350 minecraft:water[level=0]
fill 14 53 -351 48 53 -351 minecraft:water[level=0]
setblock 49 53 -351 minecraft:kelp_plant
setblock 50 53 -351 minecraft:water[level=0]
setblock 51 53 -351 minecraft:kelp_plant
fill 52 53 -351 55 53 -351 minecraft:water[level=0]
setblock 56 53 -351 minecraft:kelp_plant
fill 57 53 -351 60 53 -351 minecraft:water[level=0]
setblock 61 53 -351 minecraft:kelp[age=25]
setblock 62 53 -351 minecraft:water[level=0]
fill 14 53 -352 19 53 -352 minecraft:water[level=0]
fill 20 53 -352 21 53 -352 minecraft:tall_seagrass[half=upper]
fill 22 53 -352 32 53 -352 minecraft:water[level=0]
setblock 33 53 -352 minecraft:kelp_plant
fill 34 53 -352 42 53 -352 minecraft:water[level=0]
setblock 43 53 -352 minecraft:kelp_plant
fill 44 53 -352 47 53 -352 minecraft:water[level=0]
setblock 48 53 -352 minecraft:kelp_plant
setblock 49 53 -352 minecraft:kelp[age=25]
fill 50 53 -352 56 53 -352 minecraft:water[level=0]
setblock 57 53 -352 minecraft:kelp_plant
fill 58 53 -352 61 53 -352 minecraft:water[level=0]
setblock 62 53 -352 minecraft:kelp_plant
fill 63 53 -352 64 53 -352 minecraft:water[level=0]
setblock 65 53 -352 minecraft:seagrass
fill 13 53 -353 48 53 -353 minecraft:water[level=0]
setblock 49 53 -353 minecraft:kelp_plant
fill 50 53 -353 65 53 -353 minecraft:water[level=0]
fill 13 53 -354 21 53 -354 minecraft:water[level=0]
setblock 22 53 -354 minecraft:tall_seagrass[half=upper]
fill 23 53 -354 56 53 -354 minecraft:water[level=0]
setblock 57 53 -354 minecraft:kelp_plant
fill 58 53 -354 63 53 -354 minecraft:water[level=0]
setblock 64 53 -354 minecraft:kelp[age=25]
fill 65 53 -354 66 53 -354 minecraft:water[level=0]
fill 12 53 -355 58 53 -355 minecraft:water[level=0]
setblock 59 53 -355 minecraft:kelp_plant
setblock 60 53 -355 minecraft:water[level=0]
setblock 61 53 -355 minecraft:kelp_plant
fill 62 53 -355 63 53 -355 minecraft:water[level=0]
setblock 64 53 -355 minecraft:kelp_plant
fill 65 53 -355 71 53 -355 minecraft:water[level=0]
fill 11 53 -356 71 53 -356 minecraft:water[level=0]
fill 10 53 -357 62 53 -357 minecraft:water[level=0]
setblock 63 53 -357 minecraft:kelp_plant
fill 64 53 -357 66 53 -357 minecraft:water[level=0]
setblock 67 53 -357 minecraft:kelp_plant
fill 68 53 -357 71 53 -357 minecraft:water[level=0]
fill 9 53 -358 11 53 -358 minecraft:water[level=0]
setblock 12 53 -358 minecraft:seagrass
setblock 13 53 -358 minecraft:tall_seagrass[half=lower]
fill 14 53 -358 51 53 -358 minecraft:water[level=0]
setblock 52 53 -358 minecraft:kelp_plant
setblock 53 53 -358 minecraft:water[level=0]
setblock 54 53 -358 minecraft:kelp_plant
fill 55 53 -358 71 53 -358 minecraft:water[level=0]
setblock 8 53 -359 minecraft:tall_seagrass[half=lower]
setblock 9 53 -359 minecraft:water[level=0]
setblock 10 53 -359 minecraft:tall_seagrass[half=lower]
fill 11 53 -359 71 53 -359 minecraft:water[level=0]
fill 8 53 -360 10 53 -360 minecraft:water[level=0]
fill 11 53 -360 12 53 -360 minecraft:tall_seagrass[half=lower]
fill 13 53 -360 68 53 -360 minecraft:water[level=0]
setblock 69 53 -360 minecraft:kelp_plant
setblock 70 53 -360 minecraft:kelp[age=25]
setblock 71 53 -360 minecraft:water[level=0]
fill 8 53 -361 11 53 -361 minecraft:water[level=0]
setblock 12 53 -361 minecraft:seagrass
fill 13 53 -361 14 53 -361 minecraft:water[level=0]
setblock 15 53 -361 minecraft:tall_seagrass[half=upper]
fill 16 53 -361 43 53 -361 minecraft:water[level=0]
setblock 44 53 -361 minecraft:seagrass
setblock 45 53 -361 minecraft:tall_seagrass[half=lower]
setblock 46 53 -361 minecraft:seagrass
fill 47 53 -361 49 53 -361 minecraft:water[level=0]
setblock 50 53 -361 minecraft:kelp_plant
fill 51 53 -361 52 53 -361 minecraft:water[level=0]
setblock 53 53 -361 minecraft:kelp_plant
fill 54 53 -361 64 53 -361 minecraft:water[level=0]
setblock 65 53 -361 minecraft:kelp_plant
fill 66 53 -361 68 53 -361 minecraft:water[level=0]
setblock 69 53 -361 minecraft:kelp_plant
fill 70 53 -361 71 53 -361 minecraft:water[level=0]
setblock 8 53 -362 minecraft:water[level=0]
setblock 9 53 -362 minecraft:tall_seagrass[half=lower]
setblock 10 53 -362 minecraft:seagrass
fill 11 53 -362 17 53 -362 minecraft:water[level=0]
setblock 18 53 -362 minecraft:tall_seagrass[half=upper]
fill 19 53 -362 39 53 -362 minecraft:water[level=0]
fill 41 53 -362 68 53 -362 minecraft:water[level=0]
fill 69 53 -362 70 53 -362 minecraft:kelp_plant
setblock 71 53 -362 minecraft:water[level=0]
fill 8 53 -363 39 53 -363 minecraft:water[level=0]
fill 41 53 -363 47 53 -363 minecraft:water[level=0]
setblock 48 53 -363 minecraft:kelp_plant
setblock 49 53 -363 minecraft:seagrass
setblock 50 53 -363 minecraft:kelp_plant
fill 51 53 -363 71 53 -363 minecraft:water[level=0]
setblock 8 53 -364 minecraft:tall_seagrass[half=lower]
fill 9 53 -364 46 53 -364 minecraft:water[level=0]
fill 47 53 -364 48 53 -364 minecraft:seagrass
fill 49 53 -364 52 53 -364 minecraft:water[level=0]
setblock 53 53 -364 minecraft:tall_seagrass[half=upper]
fill 54 53 -364 68 53 -364 minecraft:water[level=0]
setblock 69 53 -364 minecraft:kelp_plant
fill 70 53 -364 71 53 -364 minecraft:water[level=0]
fill 8 53 -365 36 53 -365 minecraft:water[level=0]
setblock 37 53 -365 minecraft:tall_seagrass[half=upper]
fill 38 53 -365 39 53 -365 minecraft:water[level=0]
fill 41 53 -365 42 53 -365 minecraft:water[level=0]
setblock 43 53 -365 minecraft:seagrass
fill 44 53 -365 46 53 -365 minecraft:water[level=0]
setblock 47 53 -365 minecraft:tall_seagrass[half=lower]
setblock 48 53 -365 minecraft:seagrass
setblock 49 53 -365 minecraft:tall_seagrass[half=lower]
fill 50 53 -365 54 53 -365 minecraft:water[level=0]
setblock 55 53 -365 minecraft:kelp_plant
fill 56 53 -365 60 53 -365 minecraft:water[level=0]
setblock 61 53 -365 minecraft:kelp_plant
fill 62 53 -365 65 53 -365 minecraft:water[level=0]
setblock 66 53 -365 minecraft:kelp_plant
fill 67 53 -365 71 53 -365 minecraft:water[level=0]
fill 8 53 -366 37 53 -366 minecraft:water[level=0]
setblock 38 53 -366 minecraft:seagrass
setblock 39 53 -366 minecraft:water[level=0]
fill 42 53 -366 46 53 -366 minecraft:water[level=0]
setblock 47 53 -366 minecraft:tall_seagrass[half=lower]
setblock 48 53 -366 minecraft:water[level=0]
setblock 49 53 -366 minecraft:tall_seagrass[half=upper]
fill 50 53 -366 56 53 -366 minecraft:water[level=0]
setblock 57 53 -366 minecraft:kelp_plant
fill 58 53 -366 64 53 -366 minecraft:water[level=0]
setblock 65 53 -366 minecraft:kelp_plant
fill 66 53 -366 71 53 -366 minecraft:water[level=0]
fill 8 53 -367 38 53 -367 minecraft:water[level=0]
setblock 39 53 -367 minecraft:seagrass
setblock 43 53 -367 minecraft:water[level=0]
setblock 44 53 -367 minecraft:seagrass
setblock 45 53 -367 minecraft:water[level=0]
setblock 46 53 -367 minecraft:seagrass
fill 47 53 -367 56 53 -367 minecraft:water[level=0]
setblock 57 53 -367 minecraft:kelp_plant
fill 58 53 -367 70 53 -367 minecraft:water[level=0]
setblock 71 53 -367 minecraft:kelp_plant
fill 8 53 -368 39 53 -368 minecraft:water[level=0]
fill 43 53 -368 63 53 -368 minecraft:water[level=0]
setblock 64 53 -368 minecraft:kelp_plant
fill 65 53 -368 71 53 -368 minecraft:water[level=0]
fill 8 53 -369 26 53 -369 minecraft:water[level=0]
setblock 27 53 -369 minecraft:tall_seagrass[half=upper]
fill 28 53 -369 39 53 -369 minecraft:water[level=0]
setblock 43 53 -369 minecraft:seagrass
fill 44 53 -369 71 53 -369 minecraft:water[level=0]
fill 8 53 -370 22 53 -370 minecraft:water[level=0]
setblock 23 53 -370 minecraft:tall_seagrass[half=upper]
fill 24 53 -370 39 53 -370 minecraft:water[level=0]
setblock 43 53 -370 minecraft:water[level=0]
fill 44 53 -370 45 53 -370 minecraft:seagrass
setblock 46 53 -370 minecraft:tall_seagrass[half=lower]
fill 47 53 -370 71 53 -370 minecraft:water[level=0]
fill 8 53 -371 22 53 -371 minecraft:water[level=0]
setblock 23 53 -371 minecraft:tall_seagrass[half=upper]
fill 24 53 -371 39 53 -371 minecraft:water[level=0]
setblock 43 53 -371 minecraft:water[level=0]
setblock 44 53 -371 minecraft:tall_seagrass[half=lower]
setblock 45 53 -371 minecraft:water[level=0]
setblock 46 53 -371 minecraft:seagrass
fill 47 53 -371 71 53 -371 minecraft:water[level=0]
fill 8 53 -372 29 53 -372 minecraft:water[level=0]
fill 40 53 -372 42 53 -372 minecraft:water[level=0]
fill 49 53 -372 71 53 -372 minecraft:water[level=0]
fill 8 53 -373 23 53 -373 minecraft:water[level=0]
setblock 24 53 -373 minecraft:tall_seagrass[half=lower]
fill 25 53 -373 26 53 -373 minecraft:water[level=0]
setblock 27 53 -373 minecraft:seagrass
setblock 28 53 -373 minecraft:tall_seagrass[half=lower]
setblock 49 53 -373 minecraft:water[level=8]
fill 50 53 -373 51 53 -373 minecraft:water[level=0]
setblock 52 53 -373 minecraft:seagrass
fill 53 53 -373 71 53 -373 minecraft:water[level=0]
fill 8 53 -374 20 53 -374 minecraft:water[level=0]
fill 21 53 -374 22 53 -374 minecraft:seagrass
setblock 23 53 -374 minecraft:water[level=0]
fill 24 53 -374 25 53 -374 minecraft:seagrass
setblock 26 53 -374 minecraft:water[level=0]
setblock 27 53 -374 minecraft:seagrass
setblock 51 53 -374 minecraft:water[level=8]
fill 52 53 -374 71 53 -374 minecraft:water[level=0]
fill 8 53 -375 24 53 -375 minecraft:water[level=0]
setblock 25 53 -375 minecraft:seagrass
setblock 26 53 -375 minecraft:water[level=0]
fill 53 53 -375 71 53 -375 minecraft:water[level=0]
fill 8 53 -376 16 53 -376 minecraft:water[level=0]
setblock 17 53 -376 minecraft:tall_seagrass[half=upper]
fill 18 53 -376 19 53 -376 minecraft:water[level=0]
fill 20 53 -376 21 53 -376 minecraft:tall_seagrass[half=lower]
setblock 22 53 -376 minecraft:seagrass
setblock 23 53 -376 minecraft:water[level=0]
setblock 24 53 -376 minecraft:seagrass
fill 54 53 -376 71 53 -376 minecraft:water[level=0]
fill 8 53 -377 19 53 -377 minecraft:water[level=0]
setblock 20 53 -377 minecraft:tall_seagrass[half=lower]
fill 21 53 -377 24 53 -377 minecraft:water[level=0]
setblock 54 53 -377 minecraft:seagrass
fill 55 53 -377 71 53 -377 minecraft:water[level=0]
fill 8 53 -378 15 53 -378 minecraft:water[level=0]
setblock 16 53 -378 minecraft:tall_seagrass[half=upper]
fill 17 53 -378 18 53 -378 minecraft:water[level=0]
setblock 19 53 -378 minecraft:seagrass
fill 20 53 -378 21 53 -378 minecraft:water[level=0]
setblock 22 53 -378 minecraft:seagrass
setblock 23 53 -378 minecraft:tall_seagrass[half=lower]
setblock 54 53 -378 minecraft:water[level=0]
setblock 55 53 -378 minecraft:seagrass
fill 56 53 -378 71 53 -378 minecraft:water[level=0]
fill 8 53 -379 11 53 -379 minecraft:water[level=0]
setblock 12 53 -379 minecraft:tall_seagrass[half=upper]
fill 13 53 -379 14 53 -379 minecraft:water[level=0]
setblock 15 53 -379 minecraft:tall_seagrass[half=upper]
fill 16 53 -379 17 53 -379 minecraft:water[level=0]
setblock 18 53 -379 minecraft:tall_seagrass[half=lower]
fill 19 53 -379 23 53 -379 minecraft:water[level=0]
fill 53 53 -379 54 53 -379 minecraft:seagrass
fill 55 53 -379 71 53 -379 minecraft:water[level=0]
fill 8 53 -380 11 53 -380 minecraft:water[level=0]
setblock 12 53 -380 minecraft:seagrass
setblock 13 53 -380 minecraft:water[level=0]
setblock 14 53 -380 minecraft:seagrass
setblock 15 53 -380 minecraft:tall_seagrass[half=lower]
fill 16 53 -380 17 53 -380 minecraft:water[level=0]
setblock 18 53 -380 minecraft:tall_seagrass[half=lower]
setblock 19 53 -380 minecraft:seagrass
setblock 20 53 -380 minecraft:water[level=0]
setblock 21 53 -380 minecraft:tall_seagrass[half=lower]
setblock 22 53 -380 minecraft:water[level=0]
fill 52 53 -380 71 53 -380 minecraft:water[level=0]
fill 8 53 -381 11 53 -381 minecraft:water[level=0]
setblock 12 53 -381 minecraft:tall_seagrass[half=lower]
fill 13 53 -381 22 53 -381 minecraft:water[level=0]
fill 54 53 -381 71 53 -381 minecraft:water[level=0]
fill 8 53 -382 12 53 -382 minecraft:water[level=0]
setblock 13 53 -382 minecraft:tall_seagrass[half=lower]
fill 14 53 -382 16 53 -382 minecraft:water[level=0]
setblock 17 53 -382 minecraft:seagrass
fill 18 53 -382 22 53 -382 minecraft:water[level=0]
fill 55 53 -382 71 53 -382 minecraft:water[level=0]
fill 16 52 -319 20 52 -319 minecraft:water[level=0]
fill 16 52 -320 21 52 -320 minecraft:water[level=0]
fill 15 52 -321 21 52 -321 minecraft:water[level=0]
fill 14 52 -322 21 52 -322 minecraft:water[level=0]
fill 15 52 -323 21 52 -323 minecraft:water[level=0]
fill 15 52 -324 20 52 -324 minecraft:water[level=0]
fill 16 52 -325 19 52 -325 minecraft:water[level=0]
setblock 32 52 -340 minecraft:water[level=0]
fill 48 52 -340 51 52 -340 minecraft:water[level=0]
fill 52 52 -340 53 52 -340 minecraft:kelp_plant
fill 54 52 -340 56 52 -340 minecraft:water[level=0]
setblock 32 52 -341 minecraft:water[level=0]
fill 48 52 -341 52 52 -341 minecraft:water[level=0]
setblock 53 52 -341 minecraft:kelp_plant
setblock 54 52 -341 minecraft:water[level=0]
setblock 55 52 -341 minecraft:kelp_plant
setblock 56 52 -341 minecraft:water[level=0]
fill 31 52 -342 32 52 -342 minecraft:water[level=0]
fill 47 52 -342 56 52 -342 minecraft:water[level=0]
fill 30 52 -343 33 52 -343 minecraft:water[level=0]
fill 46 52 -343 52 52 -343 minecraft:water[level=0]
setblock 53 52 -343 minecraft:kelp_plant
fill 54 52 -343 57 52 -343 minecraft:water[level=0]
fill 28 52 -344 50 52 -344 minecraft:water[level=0]
setblock 51 52 -344 minecraft:kelp_plant
setblock 52 52 -344 minecraft:water[level=0]
setblock 53 52 -344 minecraft:kelp_plant
fill 54 52 -344 57 52 -344 minecraft:water[level=0]
setblock 28 52 -345 minecraft:water[level=0]
setblock 29 52 -345 minecraft:seagrass
fill 30 52 -345 47 52 -345 minecraft:water[level=0]
setblock 48 52 -345 minecraft:kelp_plant
fill 49 52 -345 52 52 -345 minecraft:water[level=0]
setblock 53 52 -345 minecraft:kelp_plant
fill 54 52 -345 57 52 -345 minecraft:water[level=0]
setblock 58 52 -345 minecraft:kelp_plant
setblock 28 52 -346 minecraft:seagrass
fill 29 52 -346 38 52 -346 minecraft:water[level=0]
setblock 39 52 -346 minecraft:kelp_plant
fill 40 52 -346 44 52 -346 minecraft:water[level=0]
fill 45 52 -346 46 52 -346 minecraft:kelp_plant
setblock 47 52 -346 minecraft:water[level=0]
fill 48 52 -346 49 52 -346 minecraft:kelp_plant
fill 50 52 -346 51 52 -346 minecraft:water[level=0]
setblock 52 52 -346 minecraft:kelp_plant
fill 53 52 -346 57 52 -346 minecraft:water[level=0]
setblock 58 52 -346 minecraft:kelp_plant
setblock 59 52 -346 minecraft:tall_seagrass[half=lower]
fill 28 52 -347 31 52 -347 minecraft:water[level=0]
setblock 32 52 -347 minecraft:kelp_plant
fill 33 52 -347 47 52 -347 minecraft:water[level=0]
setblock 48 52 -347 minecraft:kelp_plant
fill 49 52 -347 51 52 -347 minecraft:water[level=0]
fill 52 52 -347 53 52 -347 minecraft:kelp_plant
setblock 54 52 -347 minecraft:water[level=0]
setblock 55 52 -347 minecraft:kelp_plant
fill 56 52 -347 57 52 -347 minecraft:water[level=0]
setblock 58 52 -347 minecraft:kelp_plant
fill 59 52 -347 60 52 -347 minecraft:water[level=0]
setblock 27 52 -348 minecraft:tall_seagrass[half=lower]
fill 28 52 -348 50 52 -348 minecraft:water[level=0]
setblock 51 52 -348 minecraft:kelp_plant
fill 52 52 -348 57 52 -348 minecraft:water[level=0]
setblock 58 52 -348 minecraft:kelp_plant
fill 59 52 -348 60 52 -348 minecraft:water[level=0]
setblock 20 52 -349 minecraft:seagrass
setblock 26 52 -349 minecraft:water[level=0]
setblock 28 52 -349 minecraft:water[level=0]
setblock 29 52 -349 minecraft:tall_seagrass[half=upper]
fill 30 52 -349 38 52 -349 minecraft:water[level=0]
setblock 39 52 -349 minecraft:kelp_plant
fill 40 52 -349 43 52 -349 minecraft:water[level=0]
setblock 44 52 -349 minecraft:kelp_plant
fill 45 52 -349 47 52 -349 minecraft:water[level=0]
fill 48 52 -349 49 52 -349 minecraft:kelp_plant
fill 50 52 -349 55 52 -349 minecraft:water[level=0]
setblock 56 52 -349 minecraft:kelp_plant
fill 57 52 -349 59 52 -349 minecraft:water[level=0]
setblock 60 52 -349 minecraft:kelp_plant
fill 19 52 -350 21 52 -350 minecraft:water[level=0]
setblock 26 52 -350 minecraft:water[level=0]
setblock 27 52 -350 minecraft:seagrass
setblock 28 52 -350 minecraft:water[level=0]
setblock 29 52 -350 minecraft:tall_seagrass[half=upper]
fill 30 52 -350 33 52 -350 minecraft:water[level=0]
setblock 34 52 -350 minecraft:kelp_plant
fill 35 52 -350 37 52 -350 minecraft:water[level=0]
setblock 38 52 -350 minecraft:kelp_plant
fill 39 52 -350 43 52 -350 minecraft:water[level=0]
setblock 44 52 -350 minecraft:kelp_plant
fill 45 52 -350 46 52 -350 minecraft:water[level=0]
setblock 47 52 -350 minecraft:kelp_plant
fill 48 52 -350 51 52 -350 minecraft:water[level=0]
setblock 52 52 -350 minecraft:kelp_plant
fill 53 52 -350 54 52 -350 minecraft:water[level=0]
setblock 55 52 -350 minecraft:kelp_plant
setblock 56 52 -350 minecraft:water[level=0]
fill 57 52 -350 58 52 -350 minecraft:kelp_plant
fill 59 52 -350 60 52 -350 minecraft:water[level=0]
setblock 61 52 -350 minecraft:tall_seagrass[half=upper]
setblock 18 52 -351 minecraft:seagrass
setblock 21 52 -351 minecraft:seagrass
fill 22 52 -351 23 52 -351 minecraft:water[level=0]
setblock 24 52 -351 minecraft:seagrass
setblock 25 52 -351 minecraft:water[level=0]
setblock 26 52 -351 minecraft:seagrass
fill 27 52 -351 29 52 -351 minecraft:water[level=0]
setblock 30 52 -351 minecraft:tall_seagrass[half=upper]
fill 31 52 -351 48 52 -351 minecraft:water[level=0]
setblock 49 52 -351 minecraft:kelp_plant
setblock 50 52 -351 minecraft:water[level=0]
setblock 51 52 -351 minecraft:kelp_plant
fill 52 52 -351 55 52 -351 minecraft:water[level=0]
setblock 56 52 -351 minecraft:kelp_plant
fill 57 52 -351 60 52 -351 minecraft:water[level=0]
setblock 61 52 -351 minecraft:kelp_plant
setblock 62 52 -351 minecraft:water[level=0]
setblock 16 52 -352 minecraft:water[level=0]
setblock 17 52 -352 minecraft:seagrass
fill 18 52 -352 19 52 -352 minecraft:water[level=0]
fill 20 52 -352 21 52 -352 minecraft:tall_seagrass[half=lower]
setblock 24 52 -352 minecraft:water[level=0]
setblock 25 52 -352 minecraft:seagrass
fill 26 52 -352 32 52 -352 minecraft:water[level=0]
setblock 33 52 -352 minecraft:kelp_plant
fill 34 52 -352 42 52 -352 minecraft:water[level=0]
setblock 43 52 -352 minecraft:kelp_plant
fill 44 52 -352 47 52 -352 minecraft:water[level=0]
fill 48 52 -352 49 52 -352 minecraft:kelp_plant
fill 50 52 -352 56 52 -352 minecraft:water[level=0]
setblock 57 52 -352 minecraft:kelp_plant
fill 58 52 -352 61 52 -352 minecraft:water[level=0]
setblock 62 52 -352 minecraft:kelp_plant
fill 63 52 -352 64 52 -352 minecraft:water[level=0]
fill 16 52 -353 18 52 -353 minecraft:water[level=0]
fill 21 52 -353 23 52 -353 minecraft:water[level=0]
fill 25 52 -353 29 52 -353 minecraft:water[level=0]
setblock 30 52 -353 minecraft:tall_seagrass[half=upper]
fill 31 52 -353 48 52 -353 minecraft:water[level=0]
setblock 49 52 -353 minecraft:kelp_plant
fill 50 52 -353 65 52 -353 minecraft:water[level=0]
fill 16 52 -354 21 52 -354 minecraft:water[level=0]
setblock 22 52 -354 minecraft:tall_seagrass[half=lower]
setblock 23 52 -354 minecraft:water[level=0]
fill 25 52 -354 29 52 -354 minecraft:water[level=0]
setblock 30 52 -354 minecraft:tall_seagrass[half=upper]
fill 31 52 -354 56 52 -354 minecraft:water[level=0]
setblock 57 52 -354 minecraft:kelp_plant
fill 58 52 -354 63 52 -354 minecraft:water[level=0]
setblock 64 52 -354 minecraft:kelp_plant
setblock 65 52 -354 minecraft:water[level=0]
fill 15 52 -355 25 52 -355 minecraft:water[level=0]
setblock 26 52 -355 minecraft:tall_seagrass[half=upper]
fill 27 52 -355 58 52 -355 minecraft:water[level=0]
setblock 59 52 -355 minecraft:kelp_plant
setblock 60 52 -355 minecraft:water[level=0]
setblock 61 52 -355 minecraft:kelp_plant
fill 62 52 -355 63 52 -355 minecraft:water[level=0]
setblock 64 52 -355 minecraft:kelp_plant
fill 65 52 -355 67 52 -355 minecraft:water[level=0]
fill 69 52 -355 71 52 -355 minecraft:water[level=0]
fill 15 52 -356 25 52 -356 minecraft:water[level=0]
setblock 26 52 -356 minecraft:tall_seagrass[half=upper]
fill 27 52 -356 71 52 -356 minecraft:water[level=0]
fill 15 52 -357 62 52 -357 minecraft:water[level=0]
setblock 63 52 -357 minecraft:kelp_plant
fill 64 52 -357 66 52 -357 minecraft:water[level=0]
setblock 67 52 -357 minecraft:kelp_plant
fill 68 52 -357 71 52 -357 minecraft:water[level=0]
fill 15 52 -358 24 52 -358 minecraft:water[level=0]
setblock 25 52 -358 minecraft:tall_seagrass[half=upper]
setblock 26 52 -358 minecraft:water[level=0]
setblock 27 52 -358 minecraft:tall_seagrass[half=upper]
fill 28 52 -358 51 52 -358 minecraft:water[level=0]
setblock 52 52 -358 minecraft:kelp_plant
setblock 53 52 -358 minecraft:water[level=0]
setblock 54 52 -358 minecraft:kelp_plant
fill 55 52 -358 71 52 -358 minecraft:water[level=0]
fill 14 52 -359 37 52 -359 minecraft:water[level=0]
setblock 38 52 -359 minecraft:tall_seagrass[half=upper]
fill 39 52 -359 43 52 -359 minecraft:water[level=0]
fill 46 52 -359 61 52 -359 minecraft:water[level=0]
setblock 62 52 -359 minecraft:kelp[age=25]
fill 63 52 -359 71 52 -359 minecraft:water[level=0]
fill 14 52 -360 38 52 -360 minecraft:water[level=0]
setblock 39 52 -360 minecraft:seagrass
fill 40 52 -360 42 52 -360 minecraft:water[level=0]
fill 47 52 -360 48 52 -360 minecraft:water[level=0]
fill 50 52 -360 68 52 -360 minecraft:water[level=0]
fill 69 52 -360 70 52 -360 minecraft:kelp_plant
setblock 71 52 -360 minecraft:water[level=0]
setblock 14 52 -361 minecraft:water[level=0]
setblock 15 52 -361 minecraft:tall_seagrass[half=lower]
fill 16 52 -361 17 52 -361 minecraft:water[level=0]
setblock 18 52 -361 minecraft:seagrass
fill 19 52 -361 39 52 -361 minecraft:water[level=0]
setblock 49 52 -361 minecraft:water[level=0]
setblock 50 52 -361 minecraft:kelp_plant
fill 51 52 -361 52 52 -361 minecraft:water[level=0]
setblock 53 52 -361 minecraft:kelp_plant
fill 54 52 -361 57 52 -361 minecraft:water[level=0]
setblock 58 52 -361 minecraft:kelp[age=23]
fill 59 52 -361 64 52 -361 minecraft:water[level=0]
setblock 65 52 -361 minecraft:kelp_plant
fill 66 52 -361 68 52 -361 minecraft:water[level=0]
setblock 69 52 -361 minecraft:kelp_plant
fill 70 52 -361 71 52 -361 minecraft:water[level=0]
setblock 13 52 -362 minecraft:seagrass
fill 14 52 -362 16 52 -362 minecraft:water[level=0]
setblock 17 52 -362 minecraft:seagrass
setblock 18 52 -362 minecraft:tall_seagrass[half=lower]
fill 19 52 -362 36 52 -362 minecraft:water[level=0]
setblock 37 52 -362 minecraft:tall_seagrass[half=upper]
fill 38 52 -362 39 52 -362 minecraft:water[level=0]
fill 49 52 -362 68 52 -362 minecraft:water[level=0]
fill 69 52 -362 70 52 -362 minecraft:kelp_plant
setblock 71 52 -362 minecraft:water[level=0]
setblock 12 52 -363 minecraft:water[level=0]
setblock 13 52 -363 minecraft:seagrass
fill 14 52 -363 38 52 -363 minecraft:water[level=0]
setblock 50 52 -363 minecraft:kelp_plant
fill 51 52 -363 71 52 -363 minecraft:water[level=0]
fill 9 52 -364 14 52 -364 minecraft:water[level=0]
fill 15 52 -364 16 52 -364 minecraft:seagrass
fill 17 52 -364 38 52 -364 minecraft:water[level=0]
fill 51 52 -364 52 52 -364 minecraft:water[level=0]
setblock 53 52 -364 minecraft:tall_seagrass[half=lower]
fill 54 52 -364 68 52 -364 minecraft:water[level=0]
setblock 69 52 -364 minecraft:kelp_plant
fill 70 52 -364 71 52 -364 minecraft:water[level=0]
setblock 8 52 -365 minecraft:seagrass
fill 9 52 -365 13 52 -365 minecraft:water[level=0]
setblock 14 52 -365 minecraft:seagrass
fill 15 52 -365 17 52 -365 minecraft:water[level=0]
fill 18 52 -365 19 52 -365 minecraft:tall_seagrass[half=upper]
fill 20 52 -365 36 52 -365 minecraft:water[level=0]
setblock 37 52 -365 minecraft:tall_seagrass[half=lower]
fill 50 52 -365 51 52 -365 minecraft:seagrass
fill 52 52 -365 54 52 -365 minecraft:water[level=0]
setblock 55 52 -365 minecraft:kelp_plant
fill 56 52 -365 60 52 -365 minecraft:water[level=0]
setblock 61 52 -365 minecraft:kelp_plant
fill 62 52 -365 65 52 -365 minecraft:water[level=0]
setblock 66 52 -365 minecraft:kelp_plant
fill 67 52 -365 71 52 -365 minecraft:water[level=0]
fill 8 52 -366 11 52 -366 minecraft:water[level=0]
setblock 12 52 -366 minecraft:seagrass
fill 13 52 -366 20 52 -366 minecraft:water[level=0]
setblock 21 52 -366 minecraft:tall_seagrass[half=upper]
fill 22 52 -366 29 52 -366 minecraft:water[level=0]
setblock 30 52 -366 minecraft:tall_seagrass[half=upper]
fill 31 52 -366 37 52 -366 minecraft:water[level=0]
setblock 48 52 -366 minecraft:seagrass
setblock 49 52 -366 minecraft:tall_seagrass[half=lower]
fill 50 52 -366 51 52 -366 minecraft:water[level=0]
setblock 52 52 -366 minecraft:seagrass
fill 53 52 -366 56 52 -366 minecraft:water[level=0]
setblock 57 52 -366 minecraft:kelp_plant
fill 58 52 -366 64 52 -366 minecraft:water[level=0]
setblock 65 52 -366 minecraft:kelp_plant
fill 66 52 -366 71 52 -366 minecraft:water[level=0]
fill 8 52 -367 16 52 -367 minecraft:water[level=0]
setblock 17 52 -367 minecraft:tall_seagrass[half=upper]
fill 18 52 -367 37 52 -367 minecraft:water[level=0]
fill 47 52 -367 48 52 -367 minecraft:water[level=0]
fill 49 52 -367 50 52 -367 minecraft:seagrass
fill 51 52 -367 53 52 -367 minecraft:water[level=0]
setblock 54 52 -367 minecraft:tall_seagrass[half=upper]
fill 55 52 -367 56 52 -367 minecraft:water[level=0]
setblock 57 52 -367 minecraft:kelp_plant
fill 58 52 -367 70 52 -367 minecraft:water[level=0]
setblock 71 52 -367 minecraft:kelp_plant
fill 8 52 -368 33 52 -368 minecraft:water[level=0]
setblock 34 52 -368 minecraft:seagrass
fill 35 52 -368 36 52 -368 minecraft:water[level=0]
setblock 47 52 -368 minecraft:seagrass
fill 48 52 -368 49 52 -368 minecraft:water[level=0]
setblock 50 52 -368 minecraft:tall_seagrass[half=upper]
fill 51 52 -368 52 52 -368 minecraft:water[level=0]
setblock 53 52 -368 minecraft:tall_seagrass[half=upper]
fill 54 52 -368 63 52 -368 minecraft:water[level=0]
setblock 64 52 -368 minecraft:kelp_plant
fill 65 52 -368 71 52 -368 minecraft:water[level=0]
fill 8 52 -369 23 52 -369 minecraft:water[level=0]
setblock 24 52 -369 minecraft:seagrass
fill 25 52 -369 26 52 -369 minecraft:water[level=0]
setblock 27 52 -369 minecraft:tall_seagrass[half=lower]
fill 28 52 -369 29 52 -369 minecraft:water[level=0]
setblock 30 52 -369 minecraft:seagrass
fill 31 52 -369 34 52 -369 minecraft:water[level=0]
setblock 48 52 -369 minecraft:water[level=0]
setblock 49 52 -369 minecraft:seagrass
fill 50 52 -369 71 52 -369 minecraft:water[level=0]
fill 8 52 -370 22 52 -370 minecraft:water[level=0]
setblock 23 52 -370 minecraft:tall_seagrass[half=lower]
setblock 24 52 -370 minecraft:water[level=0]
setblock 25 52 -370 minecraft:seagrass
setblock 26 52 -370 minecraft:water[level=0]
setblock 49 52 -370 minecraft:water[level=0]
fill 50 52 -370 52 52 -370 minecraft:seagrass
fill 53 52 -370 54 52 -370 minecraft:water[level=0]
setblock 55 52 -370 minecraft:tall_seagrass[half=upper]
fill 56 52 -370 71 52 -370 minecraft:water[level=0]
fill 8 52 -371 16 52 -371 minecraft:water[level=0]
setblock 17 52 -371 minecraft:seagrass
fill 18 52 -371 22 52 -371 minecraft:water[level=0]
setblock 23 52 -371 minecraft:tall_seagrass[half=lower]
setblock 24 52 -371 minecraft:water[level=0]
fill 48 52 -371 50 52 -371 minecraft:water[level=8]
setblock 51 52 -371 minecraft:water[level=0]
setblock 52 52 -371 minecraft:seagrass
fill 53 52 -371 71 52 -371 minecraft:water[level=0]
setblock 8 52 -372 minecraft:water[level=0]
setblock 9 52 -372 minecraft:tall_seagrass[half=upper]
fill 10 52 -372 17 52 -372 minecraft:water[level=0]
setblock 18 52 -372 minecraft:seagrass
fill 19 52 -372 22 52 -372 minecraft:water[level=0]
fill 49 52 -372 51 52 -372 minecraft:water[level=8]
setblock 52 52 -372 minecraft:seagrass
fill 53 52 -372 71 52 -372 minecraft:water[level=0]
fill 8 52 -373 21 52 -373 minecraft:water[level=0]
fill 49 52 -373 50 52 -373 minecraft:water[level=8]
setblock 53 52 -373 minecraft:seagrass
fill 54 52 -373 71 52 -373 minecraft:water[level=0]
fill 8 52 -374 16 52 -374 minecraft:water[level=0]
setblock 17 52 -374 minecraft:seagrass
fill 18 52 -374 19 52 -374 minecraft:water[level=0]
setblock 20 52 -374 minecraft:seagrass
setblock 51 52 -374 minecraft:water[level=8]
setblock 54 52 -374 minecraft:seagrass
fill 55 52 -374 71 52 -374 minecraft:water[level=0]
fill 8 52 -375 16 52 -375 minecraft:water[level=0]
setblock 17 52 -375 minecraft:seagrass
setblock 18 52 -375 minecraft:water[level=0]
fill 19 52 -375 20 52 -375 minecraft:seagrass
fill 55 52 -375 71 52 -375 minecraft:water[level=0]
fill 8 52 -376 12 52 -376 minecraft:water[level=0]
setblock 13 52 -376 minecraft:tall_seagrass[half=upper]
setblock 14 52 -376 minecraft:water[level=0]
setblock 15 52 -376 minecraft:tall_seagrass[half=upper]
setblock 16 52 -376 minecraft:seagrass
setblock 17 52 -376 minecraft:tall_seagrass[half=lower]
setblock 18 52 -376 minecraft:water[level=0]
setblock 19 52 -376 minecraft:seagrass
fill 56 52 -376 71 52 -376 minecraft:water[level=0]
fill 8 52 -377 13 52 -377 minecraft:water[level=0]
setblock 14 52 -377 minecraft:seagrass
fill 15 52 -377 17 52 -377 minecraft:water[level=0]
setblock 18 52 -377 minecraft:seagrass
setblock 19 52 -377 minecraft:water[level=0]
fill 56 52 -377 71 52 -377 minecraft:water[level=0]
fill 8 52 -378 11 52 -378 minecraft:water[level=0]
setblock 12 52 -378 minecraft:seagrass
fill 13 52 -378 15 52 -378 minecraft:water[level=0]
setblock 16 52 -378 minecraft:tall_seagrass[half=lower]
fill 17 52 -378 18 52 -378 minecraft:seagrass
fill 56 52 -378 71 52 -378 minecraft:water[level=0]
fill 8 52 -379 11 52 -379 minecraft:water[level=0]
setblock 12 52 -379 minecraft:tall_seagrass[half=lower]
setblock 13 52 -379 minecraft:water[level=0]
setblock 14 52 -379 minecraft:seagrass
setblock 15 52 -379 minecraft:tall_seagrass[half=lower]
setblock 16 52 -379 minecraft:water[level=0]
setblock 17 52 -379 minecraft:seagrass
fill 55 52 -379 71 52 -379 minecraft:water[level=0]
fill 8 52 -380 11 52 -380 minecraft:water[level=0]
setblock 16 52 -380 minecraft:water[level=0]
fill 55 52 -380 71 52 -380 minecraft:water[level=0]
fill 8 52 -381 11 52 -381 minecraft:water[level=0]
fill 55 52 -381 71 52 -381 minecraft:water[level=0]
fill 8 52 -382 12 52 -382 minecraft:water[level=0]
fill 55 52 -382 71 52 -382 minecraft:water[level=0]
fill 16 51 -319 19 51 -319 minecraft:water[level=0]
fill 15 51 -320 20 51 -320 minecraft:water[level=0]
fill 14 51 -321 20 51 -321 minecraft:water[level=0]
fill 14 51 -322 21 51 -322 minecraft:water[level=0]
fill 14 51 -323 21 51 -323 minecraft:water[level=0]
fill 15 51 -324 20 51 -324 minecraft:water[level=0]
fill 15 51 -325 19 51 -325 minecraft:water[level=0]
fill 17 51 -326 18 51 -326 minecraft:water[level=0]
setblock 32 51 -340 minecraft:water[level=0]
fill 48 51 -340 51 51 -340 minecraft:water[level=0]
fill 52 51 -340 53 51 -340 minecraft:kelp_plant
fill 54 51 -340 56 51 -340 minecraft:water[level=0]
setblock 32 51 -341 minecraft:water[level=0]
fill 48 51 -341 52 51 -341 minecraft:water[level=0]
setblock 53 51 -341 minecraft:kelp_plant
setblock 54 51 -341 minecraft:water[level=0]
setblock 55 51 -341 minecraft:kelp_plant
setblock 56 51 -341 minecraft:water[level=0]
setblock 32 51 -342 minecraft:water[level=0]
fill 48 51 -342 56 51 -342 minecraft:water[level=0]
setblock 32 51 -343 minecraft:water[level=0]
fill 47 51 -343 52 51 -343 minecraft:water[level=0]
setblock 53 51 -343 minecraft:kelp_plant
fill 54 51 -343 56 51 -343 minecraft:water[level=0]
fill 30 51 -344 31 51 -344 minecraft:water[level=0]
setblock 32 51 -344 minecraft:seagrass
fill 33 51 -344 36 51 -344 minecraft:water[level=0]
setblock 37 51 -344 minecraft:tall_seagrass[half=upper]
setblock 38 51 -344 minecraft:water[level=0]
setblock 39 51 -344 minecraft:tall_seagrass[half=upper]
fill 40 51 -344 50 51 -344 minecraft:water[level=0]
setblock 51 51 -344 minecraft:kelp_plant
setblock 52 51 -344 minecraft:water[level=0]
setblock 53 51 -344 minecraft:kelp_plant
fill 54 51 -344 57 51 -344 minecraft:water[level=0]
fill 30 51 -345 47 51 -345 minecraft:water[level=0]
setblock 48 51 -345 minecraft:kelp_plant
fill 49 51 -345 52 51 -345 minecraft:water[level=0]
setblock 53 51 -345 minecraft:kelp_plant
fill 54 51 -345 57 51 -345 minecraft:water[level=0]
fill 29 51 -346 35 51 -346 minecraft:water[level=0]
setblock 36 51 -346 minecraft:tall_seagrass[half=upper]
fill 37 51 -346 38 51 -346 minecraft:water[level=0]
setblock 39 51 -346 minecraft:kelp_plant
fill 40 51 -346 41 51 -346 minecraft:tall_seagrass[half=upper]
fill 42 51 -346 44 51 -346 minecraft:water[level=0]
fill 45 51 -346 46 51 -346 minecraft:kelp_plant
setblock 47 51 -346 minecraft:water[level=0]
fill 48 51 -346 49 51 -346 minecraft:kelp_plant
fill 50 51 -346 51 51 -346 minecraft:water[level=0]
setblock 52 51 -346 minecraft:kelp_plant
fill 53 51 -346 57 51 -346 minecraft:water[level=0]
setblock 58 51 -346 minecraft:kelp_plant
setblock 28 51 -347 minecraft:water[level=0]
setblock 29 51 -347 minecraft:seagrass
fill 30 51 -347 31 51 -347 minecraft:water[level=0]
setblock 32 51 -347 minecraft:kelp_plant
fill 33 51 -347 36 51 -347 minecraft:water[level=0]
setblock 37 51 -347 minecraft:tall_seagrass[half=upper]
fill 38 51 -347 47 51 -347 minecraft:water[level=0]
setblock 48 51 -347 minecraft:kelp_plant
fill 49 51 -347 51 51 -347 minecraft:water[level=0]
fill 52 51 -347 53 51 -347 minecraft:kelp_plant
setblock 54 51 -347 minecraft:water[level=0]
setblock 55 51 -347 minecraft:kelp_plant
fill 56 51 -347 57 51 -347 minecraft:water[level=0]
setblock 58 51 -347 minecraft:kelp_plant
setblock 59 51 -347 minecraft:seagrass
setblock 60 51 -347 minecraft:water[level=0]
setblock 28 51 -348 minecraft:seagrass
setblock 29 51 -348 minecraft:water[level=0]
setblock 30 51 -348 minecraft:seagrass
fill 31 51 -348 35 51 -348 minecraft:water[level=0]
setblock 36 51 -348 minecraft:tall_seagrass[half=upper]
fill 37 51 -348 39 51 -348 minecraft:water[level=0]
setblock 40 51 -348 minecraft:tall_seagrass[half=upper]
fill 41 51 -348 50 51 -348 minecraft:water[level=0]
setblock 51 51 -348 minecraft:kelp_plant
fill 52 51 -348 57 51 -348 minecraft:water[level=0]
setblock 58 51 -348 minecraft:kelp_plant
fill 59 51 -348 60 51 -348 minecraft:water[level=0]
setblock 29 51 -349 minecraft:tall_seagrass[half=lower]
fill 30 51 -349 38 51 -349 minecraft:water[level=0]
setblock 39 51 -349 minecraft:kelp_plant
fill 40 51 -349 43 51 -349 minecraft:water[level=0]
setblock 44 51 -349 minecraft:kelp_plant
fill 45 51 -349 47 51 -349 minecraft:water[level=0]
fill 48 51 -349 49 51 -349 minecraft:kelp_plant
fill 50 51 -349 55 51 -349 minecraft:water[level=0]
setblock 56 51 -349 minecraft:kelp_plant
fill 57 51 -349 59 51 -349 minecraft:water[level=0]
setblock 60 51 -349 minecraft:kelp_plant
setblock 28 51 -350 minecraft:water[level=0]
setblock 29 51 -350 minecraft:tall_seagrass[half=lower]
setblock 30 51 -350 minecraft:seagrass
fill 31 51 -350 33 51 -350 minecraft:water[level=0]
setblock 34 51 -350 minecraft:kelp_plant
fill 35 51 -350 37 51 -350 minecraft:water[level=0]
setblock 38 51 -350 minecraft:kelp_plant
fill 39 51 -350 43 51 -350 minecraft:water[level=0]
setblock 44 51 -350 minecraft:kelp_plant
fill 45 51 -350 46 51 -350 minecraft:water[level=0]
setblock 47 51 -350 minecraft:kelp_plant
fill 48 51 -350 51 51 -350 minecraft:water[level=0]
setblock 52 51 -350 minecraft:kelp_plant
fill 53 51 -350 54 51 -350 minecraft:water[level=0]
setblock 55 51 -350 minecraft:kelp_plant
setblock 56 51 -350 minecraft:water[level=0]
fill 57 51 -350 58 51 -350 minecraft:kelp_plant
fill 59 51 -350 60 51 -350 minecraft:water[level=0]
setblock 61 51 -350 minecraft:tall_seagrass[half=lower]
fill 27 51 -351 29 51 -351 minecraft:seagrass
setblock 30 51 -351 minecraft:tall_seagrass[half=lower]
fill 31 51 -351 48 51 -351 minecraft:water[level=0]
setblock 49 51 -351 minecraft:kelp_plant
setblock 50 51 -351 minecraft:water[level=0]
setblock 51 51 -351 minecraft:kelp_plant
fill 52 51 -351 55 51 -351 minecraft:water[level=0]
setblock 56 51 -351 minecraft:kelp_plant
fill 57 51 -351 60 51 -351 minecraft:water[level=0]
setblock 61 51 -351 minecraft:kelp_plant
setblock 62 51 -351 minecraft:water[level=0]
fill 26 51 -352 29 51 -352 minecraft:seagrass
fill 30 51 -352 32 51 -352 minecraft:water[level=0]
setblock 33 51 -352 minecraft:kelp_plant
fill 34 51 -352 35 51 -352 minecraft:water[level=0]
setblock 36 51 -352 minecraft:tall_seagrass[half=upper]
fill 37 51 -352 42 51 -352 minecraft:water[level=0]
setblock 43 51 -352 minecraft:kelp_plant
fill 44 51 -352 47 51 -352 minecraft:water[level=0]
fill 48 51 -352 49 51 -352 minecraft:kelp_plant
fill 50 51 -352 56 51 -352 minecraft:water[level=0]
setblock 57 51 -352 minecraft:kelp_plant
fill 58 51 -352 61 51 -352 minecraft:water[level=0]
setblock 62 51 -352 minecraft:kelp_plant
fill 63 51 -352 64 51 -352 minecraft:water[level=0]
fill 27 51 -353 28 51 -353 minecraft:water[level=0]
setblock 29 51 -353 minecraft:seagrass
setblock 30 51 -353 minecraft:tall_seagrass[half=lower]
fill 31 51 -353 48 51 -353 minecraft:water[level=0]
setblock 49 51 -353 minecraft:kelp_plant
fill 50 51 -353 65 51 -353 minecraft:water[level=0]
fill 25 51 -354 28 51 -354 minecraft:water[level=0]
setblock 29 51 -354 minecraft:seagrass
setblock 30 51 -354 minecraft:tall_seagrass[half=lower]
fill 31 51 -354 56 51 -354 minecraft:water[level=0]
setblock 57 51 -354 minecraft:kelp_plant
fill 58 51 -354 63 51 -354 minecraft:water[level=0]
setblock 64 51 -354 minecraft:kelp_plant
setblock 65 51 -354 minecraft:water[level=0]
setblock 23 51 -355 minecraft:seagrass
fill 24 51 -355 25 51 -355 minecraft:water[level=0]
setblock 26 51 -355 minecraft:tall_seagrass[half=lower]
setblock 27 51 -355 minecraft:water[level=0]
fill 28 51 -355 29 51 -355 minecraft:seagrass
fill 30 51 -355 31 51 -355 minecraft:water[level=0]
setblock 32 51 -355 minecraft:tall_seagrass[half=upper]
fill 33 51 -355 58 51 -355 minecraft:water[level=0]
setblock 59 51 -355 minecraft:kelp_plant
setblock 60 51 -355 minecraft:water[level=0]
setblock 61 51 -355 minecraft:kelp_plant
fill 62 51 -355 63 51 -355 minecraft:water[level=0]
setblock 64 51 -355 minecraft:kelp_plant
fill 65 51 -355 67 51 -355 minecraft:water[level=0]
fill 21 51 -356 25 51 -356 minecraft:water[level=0]
setblock 26 51 -356 minecraft:tall_seagrass[half=lower]
fill 27 51 -356 28 51 -356 minecraft:water[level=0]
setblock 29 51 -356 minecraft:seagrass
fill 30 51 -356 71 51 -356 minecraft:water[level=0]
fill 21 51 -357 62 51 -357 minecraft:water[level=0]
setblock 63 51 -357 minecraft:kelp_plant
fill 64 51 -357 66 51 -357 minecraft:water[level=0]
setblock 67 51 -357 minecraft:kelp_plant
fill 68 51 -357 71 51 -357 minecraft:water[level=0]
fill 21 51 -358 24 51 -358 minecraft:water[level=0]
setblock 25 51 -358 minecraft:tall_seagrass[half=lower]
setblock 26 51 -358 minecraft:water[level=0]
setblock 27 51 -358 minecraft:tall_seagrass[half=lower]
fill 28 51 -358 29 51 -358 minecraft:water[level=0]
setblock 30 51 -358 minecraft:seagrass
fill 31 51 -358 38 51 -358 minecraft:water[level=0]
setblock 39 51 -358 minecraft:seagrass
fill 49 51 -358 51 51 -358 minecraft:water[level=0]
setblock 52 51 -358 minecraft:kelp_plant
setblock 53 51 -358 minecraft:water[level=0]
setblock 54 51 -358 minecraft:kelp_plant
fill 55 51 -358 71 51 -358 minecraft:water[level=0]
fill 21 51 -359 37 51 -359 minecraft:water[level=0]
setblock 38 51 -359 minecraft:tall_seagrass[half=lower]
fill 50 51 -359 61 51 -359 minecraft:water[level=0]
setblock 62 51 -359 minecraft:kelp_plant
fill 63 51 -359 71 51 -359 minecraft:water[level=0]
fill 20 51 -360 34 51 -360 minecraft:water[level=0]
setblock 35 51 -360 minecraft:tall_seagrass[half=upper]
fill 36 51 -360 37 51 -360 minecraft:water[level=0]
setblock 38 51 -360 minecraft:seagrass
fill 51 51 -360 68 51 -360 minecraft:water[level=0]
fill 69 51 -360 70 51 -360 minecraft:kelp_plant
setblock 71 51 -360 minecraft:water[level=0]
setblock 20 51 -361 minecraft:seagrass
setblock 21 51 -361 minecraft:water[level=0]
setblock 22 51 -361 minecraft:seagrass
fill 23 51 -361 32 51 -361 minecraft:water[level=0]
setblock 33 51 -361 minecraft:tall_seagrass[half=upper]
fill 34 51 -361 35 51 -361 minecraft:water[level=0]
setblock 36 51 -361 minecraft:tall_seagrass[half=upper]
setblock 37 51 -361 minecraft:water[level=0]
fill 51 51 -361 52 51 -361 minecraft:water[level=0]
setblock 53 51 -361 minecraft:kelp_plant
fill 54 51 -361 57 51 -361 minecraft:water[level=0]
setblock 58 51 -361 minecraft:kelp_plant
fill 59 51 -361 64 51 -361 minecraft:water[level=0]
setblock 65 51 -361 minecraft:kelp_plant
fill 66 51 -361 68 51 -361 minecraft:water[level=0]
setblock 69 51 -361 minecraft:kelp_plant
fill 70 51 -361 71 51 -361 minecraft:water[level=0]
fill 19 51 -362 36 51 -362 minecraft:water[level=0]
setblock 37 51 -362 minecraft:tall_seagrass[half=lower]
fill 52 51 -362 68 51 -362 minecraft:water[level=0]
fill 69 51 -362 70 51 -362 minecraft:kelp_plant
setblock 71 51 -362 minecraft:water[level=0]
fill 18 51 -363 30 51 -363 minecraft:water[level=0]
fill 31 51 -363 32 51 -363 minecraft:tall_seagrass[half=upper]
fill 33 51 -363 37 51 -363 minecraft:water[level=0]
fill 54 51 -363 71 51 -363 minecraft:water[level=0]
setblock 17 51 -364 minecraft:water[level=0]
setblock 18 51 -364 minecraft:seagrass
setblock 19 51 -364 minecraft:water[level=0]
setblock 20 51 -364 minecraft:seagrass
fill 21 51 -364 36 51 -364 minecraft:water[level=0]
setblock 55 51 -364 minecraft:seagrass
fill 56 51 -364 68 51 -364 minecraft:water[level=0]
setblock 69 51 -364 minecraft:kelp_plant
fill 70 51 -364 71 51 -364 minecraft:water[level=0]
fill 16 51 -365 17 51 -365 minecraft:water[level=0]
fill 18 51 -365 19 51 -365 minecraft:tall_seagrass[half=lower]
fill 20 51 -365 28 51 -365 minecraft:water[level=0]
setblock 29 51 -365 minecraft:tall_seagrass[half=upper]
fill 30 51 -365 31 51 -365 minecraft:water[level=0]
setblock 32 51 -365 minecraft:tall_seagrass[half=upper]
fill 33 51 -365 36 51 -365 minecraft:water[level=0]
setblock 54 51 -365 minecraft:water[level=0]
setblock 55 51 -365 minecraft:kelp_plant
fill 56 51 -365 60 51 -365 minecraft:water[level=0]
setblock 61 51 -365 minecraft:kelp_plant
fill 62 51 -365 65 51 -365 minecraft:water[level=0]
setblock 66 51 -365 minecraft:kelp_plant
fill 67 51 -365 71 51 -365 minecraft:water[level=0]
setblock 15 51 -366 minecraft:water[level=0]
setblock 16 51 -366 minecraft:seagrass
fill 17 51 -366 18 51 -366 minecraft:water[level=0]
setblock 19 51 -366 minecraft:seagrass
setblock 20 51 -366 minecraft:water[level=0]
setblock 21 51 -366 minecraft:tall_seagrass[half=lower]
fill 22 51 -366 27 51 -366 minecraft:water[level=0]
setblock 28 51 -366 minecraft:seagrass
setblock 29 51 -366 minecraft:water[level=0]
setblock 30 51 -366 minecraft:tall_seagrass[half=lower]
setblock 31 51 -366 minecraft:water[level=0]
fill 32 51 -366 33 51 -366 minecraft:seagrass
fill 34 51 -366 35 51 -366 minecraft:water[level=0]
fill 53 51 -366 56 51 -366 minecraft:water[level=0]
setblock 57 51 -366 minecraft:kelp_plant
fill 58 51 -366 64 51 -366 minecraft:water[level=0]
setblock 65 51 -366 minecraft:kelp_plant
fill 66 51 -366 71 51 -366 minecraft:water[level=0]
fill 14 51 -367 16 51 -367 minecraft:water[level=0]
setblock 17 51 -367 minecraft:tall_seagrass[half=lower]
setblock 18 51 -367 minecraft:seagrass
setblock 19 51 -367 minecraft:water[level=0]
setblock 20 51 -367 minecraft:seagrass
fill 21 51 -367 27 51 -367 minecraft:water[level=0]
fill 29 51 -367 33 51 -367 minecraft:water[level=0]
fill 51 51 -367 53 51 -367 minecraft:water[level=0]
setblock 54 51 -367 minecraft:tall_seagrass[half=lower]
setblock 55 51 -367 minecraft:seagrass
setblock 56 51 -367 minecraft:water[level=0]
setblock 57 51 -367 minecraft:kelp_plant
fill 58 51 -367 70 51 -367 minecraft:water[level=0]
setblock 71 51 -367 minecraft:kelp_plant
setblock 12 51 -368 minecraft:seagrass
setblock 13 51 -368 minecraft:water[level=0]
setblock 14 51 -368 minecraft:seagrass
fill 15 51 -368 23 51 -368 minecraft:water[level=0]
setblock 49 51 -368 minecraft:seagrass
setblock 50 51 -368 minecraft:tall_seagrass[half=lower]
fill 51 51 -368 52 51 -368 minecraft:seagrass
setblock 53 51 -368 minecraft:tall_seagrass[half=lower]
setblock 54 51 -368 minecraft:tall_seagrass[half=upper]
fill 55 51 -368 63 51 -368 minecraft:water[level=0]
setblock 64 51 -368 minecraft:kelp_plant
fill 65 51 -368 71 51 -368 minecraft:water[level=0]
fill 12 51 -369 14 51 -369 minecraft:water[level=0]
fill 15 51 -369 16 51 -369 minecraft:seagrass
setblock 17 51 -369 minecraft:water[level=0]
setblock 18 51 -369 minecraft:seagrass
setblock 19 51 -369 minecraft:water[level=0]
fill 52 51 -369 53 51 -369 minecraft:water[level=0]
setblock 54 51 -369 minecraft:seagrass
fill 55 51 -369 71 51 -369 minecraft:water[level=0]
fill 11 51 -370 17 51 -370 minecraft:water[level=0]
fill 53 51 -370 54 51 -370 minecraft:seagrass
setblock 55 51 -370 minecraft:tall_seagrass[half=lower]
fill 56 51 -370 71 51 -370 minecraft:water[level=0]
fill 8 51 -371 16 51 -371 minecraft:water[level=0]
fill 48 51 -371 50 51 -371 minecraft:water[level=8]
fill 54 51 -371 71 51 -371 minecraft:water[level=0]
setblock 8 51 -372 minecraft:water[level=0]
setblock 9 51 -372 minecraft:tall_seagrass[half=lower]
fill 10 51 -372 16 51 -372 minecraft:water[level=0]
fill 49 51 -372 51 51 -372 minecraft:water[level=8]
fill 55 51 -372 71 51 -372 minecraft:water[level=0]
fill 8 51 -373 15 51 -373 minecraft:water[level=0]
setblock 16 51 -373 minecraft:seagrass
fill 49 51 -373 50 51 -373 minecraft:water[level=8]
fill 55 51 -373 71 51 -373 minecraft:water[level=0]
fill 8 51 -374 11 51 -374 minecraft:water[level=0]
setblock 12 51 -374 minecraft:seagrass
fill 13 51 -374 15 51 -374 minecraft:water[level=0]
setblock 51 51 -374 minecraft:water[level=8]
fill 56 51 -374 71 51 -374 minecraft:water[level=0]
fill 8 51 -375 15 51 -375 minecraft:water[level=0]
fill 57 51 -375 71 51 -375 minecraft:water[level=0]
fill 8 51 -376 12 51 -376 minecraft:water[level=0]
setblock 13 51 -376 minecraft:tall_seagrass[half=lower]
setblock 14 51 -376 minecraft:water[level=0]
setblock 15 51 -376 minecraft:tall_seagrass[half=lower]
fill 57 51 -376 71 51 -376 minecraft:water[level=0]
fill 8 51 -377 13 51 -377 minecraft:water[level=0]
fill 57 51 -377 71 51 -377 minecraft:water[level=0]
fill 8 51 -378 11 51 -378 minecraft:water[level=0]
setblock 57 51 -378 minecraft:seagrass
fill 58 51 -378 71 51 -378 minecraft:water[level=0]
fill 8 51 -379 11 51 -379 minecraft:water[level=0]
fill 57 51 -379 71 51 -379 minecraft:water[level=0]
fill 8 51 -380 10 51 -380 minecraft:water[level=0]
setblock 11 51 -380 minecraft:seagrass
fill 56 51 -380 71 51 -380 minecraft:water[level=0]
fill 8 51 -381 10 51 -381 minecraft:water[level=0]
setblock 11 51 -381 minecraft:seagrass
fill 56 51 -381 71 51 -381 minecraft:water[level=0]
fill 8 51 -382 11 51 -382 minecraft:water[level=0]
fill 56 51 -382 71 51 -382 minecraft:water[level=0]
fill 17 50 -319 18 50 -319 minecraft:water[level=0]
fill 15 50 -320 20 50 -320 minecraft:water[level=0]
fill 14 50 -321 20 50 -321 minecraft:water[level=0]
fill 14 50 -322 20 50 -322 minecraft:water[level=0]
fill 14 50 -323 20 50 -323 minecraft:water[level=0]
fill 14 50 -324 20 50 -324 minecraft:water[level=0]
fill 15 50 -325 20 50 -325 minecraft:water[level=0]
fill 16 50 -326 18 50 -326 minecraft:water[level=0]
fill 8 50 -334 9 50 -334 minecraft:water[level=0]
setblock 8 50 -335 minecraft:water[level=0]
setblock 8 50 -337 minecraft:water[level=0]
setblock 8 50 -338 minecraft:water[level=0]
fill 69 50 -338 70 50 -338 minecraft:water[level=0]
fill 66 50 -339 71 50 -339 minecraft:water[level=0]
fill 48 50 -340 51 50 -340 minecraft:water[level=0]
fill 52 50 -340 53 50 -340 minecraft:kelp_plant
setblock 54 50 -340 minecraft:water[level=0]
fill 64 50 -340 71 50 -340 minecraft:water[level=0]
fill 48 50 -341 52 50 -341 minecraft:water[level=0]
setblock 53 50 -341 minecraft:kelp_plant
setblock 54 50 -341 minecraft:water[level=0]
fill 62 50 -341 66 50 -341 minecraft:water[level=0]
setblock 67 50 -341 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=true,waterlogged=true,west=false]
fill 68 50 -341 71 50 -341 minecraft:water[level=0]
fill 48 50 -342 56 50 -342 minecraft:water[level=0]
fill 61 50 -342 66 50 -342 minecraft:water[level=0]
setblock 71 50 -342 minecraft:water[level=0]
fill 47 50 -343 52 50 -343 minecraft:water[level=0]
setblock 53 50 -343 minecraft:kelp_plant
fill 54 50 -343 56 50 -343 minecraft:water[level=0]
fill 60 50 -343 64 50 -343 minecraft:water[level=0]
setblock 71 50 -343 minecraft:water[level=0]
setblock 34 50 -344 minecraft:water[level=0]
fill 35 50 -344 36 50 -344 minecraft:seagrass
setblock 37 50 -344 minecraft:tall_seagrass[half=lower]
setblock 38 50 -344 minecraft:water[level=0]
setblock 39 50 -344 minecraft:tall_seagrass[half=lower]
fill 40 50 -344 50 50 -344 minecraft:water[level=0]
setblock 51 50 -344 minecraft:kelp_plant
setblock 52 50 -344 minecraft:water[level=0]
setblock 53 50 -344 minecraft:kelp_plant
setblock 54 50 -344 minecraft:water[level=0]
setblock 55 50 -344 minecraft:tall_seagrass[half=upper]
fill 56 50 -344 57 50 -344 minecraft:water[level=0]
fill 60 50 -344 63 50 -344 minecraft:water[level=0]
fill 34 50 -345 35 50 -345 minecraft:water[level=0]
fill 36 50 -345 39 50 -345 minecraft:seagrass
fill 40 50 -345 47 50 -345 minecraft:water[level=0]
setblock 48 50 -345 minecraft:kelp_plant
fill 49 50 -345 52 50 -345 minecraft:water[level=0]
setblock 53 50 -345 minecraft:kelp_plant
fill 54 50 -345 57 50 -345 minecraft:water[level=0]
fill 34 50 -346 35 50 -346 minecraft:water[level=0]
setblock 36 50 -346 minecraft:tall_seagrass[half=lower]
fill 37 50 -346 38 50 -346 minecraft:water[level=0]
setblock 39 50 -346 minecraft:kelp_plant
fill 40 50 -346 41 50 -346 minecraft:tall_seagrass[half=lower]
setblock 42 50 -346 minecraft:seagrass
fill 43 50 -346 44 50 -346 minecraft:water[level=0]
fill 45 50 -346 46 50 -346 minecraft:kelp_plant
setblock 47 50 -346 minecraft:water[level=0]
setblock 49 50 -346 minecraft:kelp_plant
fill 50 50 -346 51 50 -346 minecraft:water[level=0]
setblock 52 50 -346 minecraft:kelp_plant
fill 53 50 -346 57 50 -346 minecraft:water[level=0]
fill 33 50 -347 36 50 -347 minecraft:water[level=0]
setblock 37 50 -347 minecraft:tall_seagrass[half=lower]
fill 38 50 -347 46 50 -347 minecraft:water[level=0]
fill 50 50 -347 51 50 -347 minecraft:water[level=0]
fill 52 50 -347 53 50 -347 minecraft:kelp_plant
setblock 54 50 -347 minecraft:water[level=0]
setblock 55 50 -347 minecraft:kelp_plant
fill 56 50 -347 57 50 -347 minecraft:water[level=0]
setblock 58 50 -347 minecraft:kelp_plant
setblock 33 50 -348 minecraft:water[level=0]
fill 34 50 -348 35 50 -348 minecraft:seagrass
setblock 36 50 -348 minecraft:tall_seagrass[half=lower]
setblock 37 50 -348 minecraft:seagrass
fill 38 50 -348 39 50 -348 minecraft:water[level=0]
setblock 40 50 -348 minecraft:tall_seagrass[half=lower]
fill 41 50 -348 44 50 -348 minecraft:water[level=0]
setblock 50 50 -348 minecraft:water[level=0]
setblock 51 50 -348 minecraft:kelp_plant
fill 52 50 -348 57 50 -348 minecraft:water[level=0]
setblock 58 50 -348 minecraft:kelp_plant
fill 59 50 -348 60 50 -348 minecraft:water[level=0]
setblock 32 50 -349 minecraft:seagrass
fill 33 50 -349 35 50 -349 minecraft:water[level=0]
setblock 36 50 -349 minecraft:seagrass
fill 37 50 -349 38 50 -349 minecraft:water[level=0]
setblock 39 50 -349 minecraft:kelp_plant
fill 40 50 -349 42 50 -349 minecraft:water[level=0]
setblock 43 50 -349 minecraft:seagrass
setblock 44 50 -349 minecraft:kelp_plant
fill 50 50 -349 55 50 -349 minecraft:water[level=0]
setblock 56 50 -349 minecraft:kelp_plant
fill 57 50 -349 59 50 -349 minecraft:water[level=0]
setblock 60 50 -349 minecraft:kelp_plant
setblock 32 50 -350 minecraft:seagrass
setblock 33 50 -350 minecraft:water[level=0]
setblock 34 50 -350 minecraft:kelp_plant
setblock 35 50 -350 minecraft:seagrass
fill 36 50 -350 37 50 -350 minecraft:water[level=0]
setblock 38 50 -350 minecraft:kelp_plant
setblock 39 50 -350 minecraft:seagrass
fill 40 50 -350 43 50 -350 minecraft:water[level=0]
fill 50 50 -350 51 50 -350 minecraft:water[level=0]
setblock 52 50 -350 minecraft:kelp_plant
fill 53 50 -350 54 50 -350 minecraft:water[level=0]
setblock 55 50 -350 minecraft:kelp_plant
setblock 56 50 -350 minecraft:water[level=0]
fill 57 50 -350 58 50 -350 minecraft:kelp_plant
fill 59 50 -350 60 50 -350 minecraft:water[level=0]
fill 31 50 -351 41 50 -351 minecraft:water[level=0]
setblock 49 50 -351 minecraft:kelp_plant
setblock 50 50 -351 minecraft:water[level=0]
setblock 51 50 -351 minecraft:kelp_plant
fill 52 50 -351 55 50 -351 minecraft:water[level=0]
setblock 56 50 -351 minecraft:kelp_plant
fill 57 50 -351 60 50 -351 minecraft:water[level=0]
setblock 61 50 -351 minecraft:kelp_plant
setblock 62 50 -351 minecraft:water[level=0]
setblock 31 50 -352 minecraft:seagrass
setblock 32 50 -352 minecraft:water[level=0]
setblock 33 50 -352 minecraft:kelp_plant
fill 34 50 -352 35 50 -352 minecraft:water[level=0]
setblock 36 50 -352 minecraft:tall_seagrass[half=lower]
fill 37 50 -352 41 50 -352 minecraft:water[level=0]
setblock 47 50 -352 minecraft:water[level=0]
fill 48 50 -352 49 50 -352 minecraft:kelp_plant
fill 50 50 -352 56 50 -352 minecraft:water[level=0]
setblock 57 50 -352 minecraft:kelp_plant
fill 58 50 -352 61 50 -352 minecraft:water[level=0]
setblock 62 50 -352 minecraft:kelp_plant
fill 63 50 -352 64 50 -352 minecraft:water[level=0]
fill 31 50 -353 41 50 -353 minecraft:water[level=0]
setblock 48 50 -353 minecraft:water[level=0]
setblock 49 50 -353 minecraft:kelp_plant
fill 50 50 -353 64 50 -353 minecraft:water[level=0]
fill 31 50 -354 33 50 -354 minecraft:water[level=0]
setblock 34 50 -354 minecraft:seagrass
fill 35 50 -354 41 50 -354 minecraft:water[level=0]
fill 49 50 -354 56 50 -354 minecraft:water[level=0]
setblock 57 50 -354 minecraft:kelp_plant
fill 58 50 -354 63 50 -354 minecraft:water[level=0]
setblock 64 50 -354 minecraft:kelp_plant
setblock 65 50 -354 minecraft:water[level=0]
setblock 31 50 -355 minecraft:seagrass
setblock 32 50 -355 minecraft:tall_seagrass[half=lower]
setblock 33 50 -355 minecraft:water[level=0]
setblock 34 50 -355 minecraft:seagrass
setblock 35 50 -355 minecraft:water[level=0]
setblock 36 50 -355 minecraft:seagrass
fill 37 50 -355 40 50 -355 minecraft:water[level=0]
fill 49 50 -355 58 50 -355 minecraft:water[level=0]
setblock 59 50 -355 minecraft:kelp_plant
setblock 60 50 -355 minecraft:water[level=0]
setblock 61 50 -355 minecraft:kelp_plant
fill 62 50 -355 63 50 -355 minecraft:water[level=0]
setblock 64 50 -355 minecraft:kelp_plant
fill 65 50 -355 66 50 -355 minecraft:water[level=0]
setblock 32 50 -356 minecraft:seagrass
fill 33 50 -356 40 50 -356 minecraft:water[level=0]
fill 49 50 -356 71 50 -356 minecraft:water[level=0]
setblock 31 50 -357 minecraft:water[level=0]
setblock 32 50 -357 minecraft:seagrass
fill 33 50 -357 38 50 -357 minecraft:water[level=0]
fill 50 50 -357 62 50 -357 minecraft:water[level=0]
setblock 63 50 -357 minecraft:kelp_plant
fill 64 50 -357 66 50 -357 minecraft:water[level=0]
setblock 67 50 -357 minecraft:kelp_plant
fill 68 50 -357 71 50 -357 minecraft:water[level=0]
fill 31 50 -358 33 50 -358 minecraft:water[level=0]
setblock 34 50 -358 minecraft:tall_seagrass[half=upper]
fill 35 50 -358 38 50 -358 minecraft:water[level=0]
setblock 51 50 -358 minecraft:water[level=0]
setblock 52 50 -358 minecraft:kelp_plant
setblock 53 50 -358 minecraft:water[level=0]
setblock 54 50 -358 minecraft:kelp_plant
fill 55 50 -358 71 50 -358 minecraft:water[level=0]
setblock 30 50 -359 minecraft:water[level=0]
setblock 31 50 -359 minecraft:seagrass
fill 32 50 -359 33 50 -359 minecraft:water[level=0]
setblock 34 50 -359 minecraft:seagrass
fill 35 50 -359 36 50 -359 minecraft:water[level=0]
fill 51 50 -359 61 50 -359 minecraft:water[level=0]
setblock 62 50 -359 minecraft:kelp_plant
fill 63 50 -359 71 50 -359 minecraft:water[level=0]
fill 29 50 -360 32 50 -360 minecraft:water[level=0]
fill 33 50 -360 34 50 -360 minecraft:seagrass
setblock 35 50 -360 minecraft:tall_seagrass[half=lower]
setblock 36 50 -360 minecraft:water[level=0]
fill 52 50 -360 68 50 -360 minecraft:water[level=0]
fill 69 50 -360 70 50 -360 minecraft:kelp_plant
setblock 71 50 -360 minecraft:water[level=0]
fill 28 50 -361 29 50 -361 minecraft:water[level=0]
setblock 30 50 -361 minecraft:seagrass
fill 31 50 -361 32 50 -361 minecraft:water[level=0]
setblock 33 50 -361 minecraft:tall_seagrass[half=lower]
fill 34 50 -361 35 50 -361 minecraft:seagrass
setblock 36 50 -361 minecraft:tall_seagrass[half=lower]
setblock 53 50 -361 minecraft:kelp_plant
fill 54 50 -361 57 50 -361 minecraft:water[level=0]
setblock 58 50 -361 minecraft:kelp_plant
fill 59 50 -361 64 50 -361 minecraft:water[level=0]
setblock 65 50 -361 minecraft:kelp_plant
fill 66 50 -361 68 50 -361 minecraft:water[level=0]
setblock 69 50 -361 minecraft:kelp_plant
fill 70 50 -361 71 50 -361 minecraft:water[level=0]
fill 27 50 -362 33 50 -362 minecraft:water[level=0]
fill 34 50 -362 35 50 -362 minecraft:seagrass
setblock 36 50 -362 minecraft:water[level=0]
fill 55 50 -362 68 50 -362 minecraft:water[level=0]
fill 69 50 -362 70 50 -362 minecraft:kelp_plant
setblock 71 50 -362 minecraft:water[level=0]
setblock 27 50 -363 minecraft:seagrass
fill 28 50 -363 29 50 -363 minecraft:water[level=0]
setblock 30 50 -363 minecraft:seagrass
fill 31 50 -363 32 50 -363 minecraft:tall_seagrass[half=lower]
setblock 33 50 -363 minecraft:seagrass
setblock 34 50 -363 minecraft:water[level=0]
setblock 35 50 -363 minecraft:seagrass
setblock 36 50 -363 minecraft:water[level=0]
fill 56 50 -363 71 50 -363 minecraft:water[level=0]
fill 26 50 -364 30 50 -364 minecraft:water[level=0]
setblock 31 50 -364 minecraft:seagrass
fill 32 50 -364 33 50 -364 minecraft:water[level=0]
fill 34 50 -364 35 50 -364 minecraft:seagrass
fill 57 50 -364 68 50 -364 minecraft:water[level=0]
setblock 69 50 -364 minecraft:kelp_plant
fill 70 50 -364 71 50 -364 minecraft:water[level=0]
setblock 29 50 -365 minecraft:tall_seagrass[half=lower]
fill 30 50 -365 31 50 -365 minecraft:water[level=0]
setblock 32 50 -365 minecraft:tall_seagrass[half=lower]
setblock 33 50 -365 minecraft:water[level=0]
fill 57 50 -365 60 50 -365 minecraft:water[level=0]
setblock 61 50 -365 minecraft:kelp_plant
fill 62 50 -365 65 50 -365 minecraft:water[level=0]
setblock 66 50 -365 minecraft:kelp_plant
fill 67 50 -365 71 50 -365 minecraft:water[level=0]
setblock 56 50 -366 minecraft:water[level=0]
setblock 57 50 -366 minecraft:kelp_plant
fill 58 50 -366 64 50 -366 minecraft:water[level=0]
setblock 65 50 -366 minecraft:kelp_plant
fill 66 50 -366 71 50 -366 minecraft:water[level=0]
setblock 56 50 -367 minecraft:water[level=0]
setblock 57 50 -367 minecraft:kelp_plant
fill 58 50 -367 70 50 -367 minecraft:water[level=0]
setblock 71 50 -367 minecraft:kelp_plant
setblock 54 50 -368 minecraft:tall_seagrass[half=lower]
fill 55 50 -368 63 50 -368 minecraft:water[level=0]
setblock 64 50 -368 minecraft:kelp_plant
fill 65 50 -368 71 50 -368 minecraft:water[level=0]
fill 56 50 -369 71 50 -369 minecraft:water[level=0]
fill 56 50 -370 71 50 -370 minecraft:water[level=0]
fill 56 50 -371 71 50 -371 minecraft:water[level=0]
setblock 56 50 -372 minecraft:seagrass
fill 57 50 -372 71 50 -372 minecraft:water[level=0]
fill 8 50 -373 10 50 -373 minecraft:water[level=0]
fill 57 50 -373 71 50 -373 minecraft:water[level=0]
fill 8 50 -374 11 50 -374 minecraft:water[level=0]
fill 58 50 -374 71 50 -374 minecraft:water[level=0]
fill 8 50 -375 11 50 -375 minecraft:water[level=0]
fill 58 50 -375 71 50 -375 minecraft:water[level=0]
fill 8 50 -376 11 50 -376 minecraft:water[level=0]
fill 58 50 -376 71 50 -376 minecraft:water[level=0]
fill 8 50 -377 11 50 -377 minecraft:water[level=0]
fill 58 50 -377 71 50 -377 minecraft:water[level=0]
fill 8 50 -378 11 50 -378 minecraft:water[level=0]
fill 58 50 -378 71 50 -378 minecraft:water[level=0]
fill 8 50 -379 11 50 -379 minecraft:water[level=0]
fill 57 50 -379 71 50 -379 minecraft:water[level=0]
fill 8 50 -380 10 50 -380 minecraft:water[level=0]
fill 57 50 -380 71 50 -380 minecraft:water[level=0]
fill 8 50 -381 10 50 -381 minecraft:water[level=0]
fill 57 50 -381 71 50 -381 minecraft:water[level=0]
fill 8 50 -382 10 50 -382 minecraft:water[level=0]
fill 56 50 -382 71 50 -382 minecraft:water[level=0]
setblock 65 49 -319 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 15 49 -320 19 49 -320 minecraft:water[level=0]
fill 15 49 -321 20 49 -321 minecraft:water[level=0]
fill 14 49 -322 20 49 -322 minecraft:water[level=0]
fill 14 49 -323 20 49 -323 minecraft:water[level=0]
fill 14 49 -324 20 49 -324 minecraft:water[level=0]
fill 14 49 -325 19 49 -325 minecraft:water[level=0]
fill 15 49 -326 19 49 -326 minecraft:water[level=0]
setblock 8 49 -334 minecraft:water[level=0]
setblock 8 49 -335 minecraft:water[level=0]
setblock 8 49 -337 minecraft:water[level=0]
setblock 8 49 -338 minecraft:water[level=0]
fill 66 49 -338 71 49 -338 minecraft:water[level=0]
fill 64 49 -339 71 49 -339 minecraft:water[level=0]
fill 48 49 -340 51 49 -340 minecraft:water[level=0]
fill 52 49 -340 53 49 -340 minecraft:kelp_plant
fill 63 49 -340 71 49 -340 minecraft:water[level=0]
fill 48 49 -341 52 49 -341 minecraft:water[level=0]
setblock 53 49 -341 minecraft:kelp_plant
fill 61 49 -341 71 49 -341 minecraft:water[level=0]
fill 48 49 -342 52 49 -342 minecraft:water[level=0]
fill 59 49 -342 71 49 -342 minecraft:water[level=0]
fill 58 49 -343 66 49 -343 minecraft:water[level=0]
setblock 71 49 -343 minecraft:water[level=0]
setblock 41 49 -344 minecraft:water[level=0]
fill 42 49 -344 43 49 -344 minecraft:seagrass
fill 44 49 -344 47 49 -344 minecraft:water[level=0]
setblock 55 49 -344 minecraft:tall_seagrass[half=lower]
fill 56 49 -344 64 49 -344 minecraft:water[level=0]
setblock 71 49 -344 minecraft:water[level=0]
setblock 42 49 -345 minecraft:water[level=0]
setblock 43 49 -345 minecraft:seagrass
fill 44 49 -345 45 49 -345 minecraft:water[level=0]
fill 54 49 -345 62 49 -345 minecraft:water[level=0]
fill 43 49 -346 44 49 -346 minecraft:water[level=0]
fill 53 49 -346 59 49 -346 minecraft:water[level=0]
fill 52 49 -347 53 49 -347 minecraft:kelp_plant
setblock 54 49 -347 minecraft:water[level=0]
setblock 55 49 -347 minecraft:kelp_plant
fill 56 49 -347 57 49 -347 minecraft:water[level=0]
fill 52 49 -348 57 49 -348 minecraft:water[level=0]
setblock 58 49 -348 minecraft:kelp_plant
fill 59 49 -348 60 49 -348 minecraft:water[level=0]
fill 52 49 -349 55 49 -349 minecraft:water[level=0]
setblock 56 49 -349 minecraft:kelp_plant
fill 57 49 -349 59 49 -349 minecraft:water[level=0]
setblock 60 49 -349 minecraft:kelp_plant
setblock 52 49 -350 minecraft:kelp_plant
fill 53 49 -350 54 49 -350 minecraft:water[level=0]
setblock 55 49 -350 minecraft:kelp_plant
setblock 56 49 -350 minecraft:water[level=0]
fill 57 49 -350 58 49 -350 minecraft:kelp_plant
fill 59 49 -350 60 49 -350 minecraft:water[level=0]
fill 52 49 -351 55 49 -351 minecraft:water[level=0]
setblock 56 49 -351 minecraft:kelp_plant
setblock 57 49 -351 minecraft:water[level=0]
setblock 58 49 -351 minecraft:tall_seagrass[half=upper]
fill 59 49 -351 60 49 -351 minecraft:water[level=0]
setblock 61 49 -351 minecraft:kelp_plant
fill 53 49 -352 56 49 -352 minecraft:water[level=0]
setblock 57 49 -352 minecraft:kelp_plant
fill 58 49 -352 60 49 -352 minecraft:water[level=0]
setblock 61 49 -352 minecraft:tall_seagrass[half=upper]
setblock 62 49 -352 minecraft:kelp_plant
fill 63 49 -352 64 49 -352 minecraft:water[level=0]
fill 52 49 -353 64 49 -353 minecraft:water[level=0]
fill 52 49 -354 56 49 -354 minecraft:water[level=0]
setblock 57 49 -354 minecraft:kelp_plant
fill 58 49 -354 63 49 -354 minecraft:water[level=0]
setblock 64 49 -354 minecraft:kelp_plant
setblock 65 49 -354 minecraft:water[level=0]
fill 52 49 -355 58 49 -355 minecraft:water[level=0]
setblock 59 49 -355 minecraft:kelp_plant
setblock 60 49 -355 minecraft:water[level=0]
setblock 61 49 -355 minecraft:kelp_plant
fill 62 49 -355 63 49 -355 minecraft:water[level=0]
setblock 64 49 -355 minecraft:kelp_plant
setblock 65 49 -355 minecraft:water[level=0]
fill 34 49 -356 35 49 -356 minecraft:water[level=0]
fill 52 49 -356 70 49 -356 minecraft:water[level=0]
fill 34 49 -357 38 49 -357 minecraft:water[level=0]
fill 52 49 -357 62 49 -357 minecraft:water[level=0]
setblock 63 49 -357 minecraft:kelp_plant
fill 64 49 -357 66 49 -357 minecraft:water[level=0]
setblock 67 49 -357 minecraft:kelp_plant
fill 68 49 -357 71 49 -357 minecraft:water[level=0]
setblock 34 49 -358 minecraft:tall_seagrass[half=lower]
setblock 35 49 -358 minecraft:seagrass
fill 36 49 -358 39 49 -358 minecraft:water[level=0]
setblock 51 49 -358 minecraft:water[level=0]
setblock 52 49 -358 minecraft:kelp_plant
setblock 53 49 -358 minecraft:water[level=0]
setblock 54 49 -358 minecraft:kelp_plant
fill 55 49 -358 71 49 -358 minecraft:water[level=0]
fill 52 49 -359 61 49 -359 minecraft:water[level=0]
setblock 62 49 -359 minecraft:kelp_plant
fill 63 49 -359 71 49 -359 minecraft:water[level=0]
fill 53 49 -360 68 49 -360 minecraft:water[level=0]
fill 69 49 -360 70 49 -360 minecraft:kelp_plant
setblock 71 49 -360 minecraft:water[level=0]
fill 56 49 -361 57 49 -361 minecraft:water[level=0]
setblock 58 49 -361 minecraft:kelp_plant
fill 59 49 -361 64 49 -361 minecraft:water[level=0]
setblock 65 49 -361 minecraft:kelp_plant
fill 66 49 -361 68 49 -361 minecraft:water[level=0]
setblock 69 49 -361 minecraft:kelp_plant
fill 70 49 -361 71 49 -361 minecraft:water[level=0]
fill 59 49 -362 68 49 -362 minecraft:water[level=0]
fill 69 49 -362 70 49 -362 minecraft:kelp_plant
setblock 71 49 -362 minecraft:water[level=0]
fill 61 49 -363 71 49 -363 minecraft:water[level=0]
fill 62 49 -364 68 49 -364 minecraft:water[level=0]
setblock 69 49 -364 minecraft:kelp_plant
fill 70 49 -364 71 49 -364 minecraft:water[level=0]
setblock 61 49 -365 minecraft:kelp_plant
fill 62 49 -365 65 49 -365 minecraft:water[level=0]
setblock 66 49 -365 minecraft:kelp_plant
fill 67 49 -365 71 49 -365 minecraft:water[level=0]
fill 61 49 -366 64 49 -366 minecraft:water[level=0]
setblock 65 49 -366 minecraft:kelp_plant
fill 66 49 -366 71 49 -366 minecraft:water[level=0]
fill 60 49 -367 70 49 -367 minecraft:water[level=0]
setblock 71 49 -367 minecraft:kelp_plant
fill 60 49 -368 63 49 -368 minecraft:water[level=0]
setblock 64 49 -368 minecraft:kelp_plant
fill 65 49 -368 71 49 -368 minecraft:water[level=0]
fill 60 49 -369 71 49 -369 minecraft:water[level=0]
fill 59 49 -370 71 49 -370 minecraft:water[level=0]
fill 59 49 -371 71 49 -371 minecraft:water[level=0]
fill 59 49 -372 71 49 -372 minecraft:water[level=0]
setblock 8 49 -373 minecraft:water[level=0]
fill 59 49 -373 71 49 -373 minecraft:water[level=0]
fill 8 49 -374 10 49 -374 minecraft:water[level=0]
fill 59 49 -374 71 49 -374 minecraft:water[level=0]
fill 8 49 -375 10 49 -375 minecraft:water[level=0]
setblock 11 49 -375 minecraft:seagrass
fill 59 49 -375 71 49 -375 minecraft:water[level=0]
fill 8 49 -376 11 49 -376 minecraft:water[level=0]
fill 59 49 -376 69 49 -376 minecraft:water[level=0]
setblock 70 49 -376 minecraft:tall_seagrass[half=upper]
setblock 71 49 -376 minecraft:water[level=0]
fill 8 49 -377 10 49 -377 minecraft:water[level=0]
setblock 11 49 -377 minecraft:seagrass
fill 59 49 -377 71 49 -377 minecraft:water[level=0]
fill 8 49 -378 10 49 -378 minecraft:water[level=0]
fill 59 49 -378 71 49 -378 minecraft:water[level=0]
fill 8 49 -379 10 49 -379 minecraft:water[level=0]
fill 58 49 -379 71 49 -379 minecraft:water[level=0]
fill 8 49 -380 9 49 -380 minecraft:water[level=0]
setblock 10 49 -380 minecraft:tall_seagrass[half=upper]
fill 58 49 -380 69 49 -380 minecraft:water[level=0]
setblock 70 49 -380 minecraft:tall_seagrass[half=upper]
setblock 71 49 -380 minecraft:water[level=0]
fill 8 49 -381 10 49 -381 minecraft:water[level=0]
fill 57 49 -381 71 49 -381 minecraft:water[level=0]
fill 8 49 -382 10 49 -382 minecraft:water[level=0]
fill 56 49 -382 71 49 -382 minecraft:water[level=0]
setblock 65 48 -319 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 16 48 -320 18 48 -320 minecraft:water[level=0]
fill 14 48 -321 19 48 -321 minecraft:water[level=0]
fill 14 48 -322 20 48 -322 minecraft:water[level=0]
fill 14 48 -323 20 48 -323 minecraft:water[level=0]
fill 14 48 -324 20 48 -324 minecraft:water[level=0]
fill 14 48 -325 20 48 -325 minecraft:water[level=0]
fill 15 48 -326 19 48 -326 minecraft:water[level=0]
setblock 17 48 -327 minecraft:water[level=0]
fill 66 48 -338 71 48 -338 minecraft:water[level=0]
fill 64 48 -339 71 48 -339 minecraft:water[level=0]
setblock 51 48 -340 minecraft:water[level=0]
setblock 52 48 -340 minecraft:kelp_plant
fill 63 48 -340 71 48 -340 minecraft:water[level=0]
setblock 52 48 -341 minecraft:water[level=0]
fill 60 48 -341 71 48 -341 minecraft:water[level=0]
fill 58 48 -342 71 48 -342 minecraft:water[level=0]
fill 57 48 -343 66 48 -343 minecraft:water[level=0]
setblock 71 48 -343 minecraft:water[level=0]
fill 56 48 -344 64 48 -344 minecraft:water[level=0]
fill 55 48 -345 62 48 -345 minecraft:water[level=0]
fill 54 48 -346 60 48 -346 minecraft:water[level=0]
setblock 54 48 -347 minecraft:water[level=0]
setblock 55 48 -347 minecraft:kelp_plant
fill 56 48 -347 58 48 -347 minecraft:water[level=0]
fill 55 48 -348 56 48 -348 minecraft:water[level=0]
setblock 58 48 -348 minecraft:kelp_plant
setblock 59 48 -348 minecraft:seagrass
setblock 60 48 -348 minecraft:water[level=0]
setblock 58 48 -349 minecraft:water[level=0]
setblock 59 48 -349 minecraft:seagrass
setblock 60 48 -349 minecraft:kelp_plant
setblock 58 48 -350 minecraft:kelp_plant
setblock 59 48 -350 minecraft:water[level=0]
setblock 60 48 -350 minecraft:seagrass
setblock 57 48 -351 minecraft:seagrass
setblock 58 48 -351 minecraft:tall_seagrass[half=lower]
setblock 59 48 -351 minecraft:water[level=0]
setblock 60 48 -351 minecraft:seagrass
setblock 57 48 -352 minecraft:kelp_plant
setblock 58 48 -352 minecraft:water[level=0]
setblock 59 48 -352 minecraft:seagrass
setblock 60 48 -352 minecraft:water[level=0]
setblock 61 48 -352 minecraft:tall_seagrass[half=lower]
setblock 62 48 -352 minecraft:kelp_plant
setblock 63 48 -352 minecraft:seagrass
setblock 64 48 -352 minecraft:water[level=0]
fill 57 48 -353 64 48 -353 minecraft:water[level=0]
fill 58 48 -354 63 48 -354 minecraft:water[level=0]
setblock 64 48 -354 minecraft:kelp_plant
setblock 58 48 -355 minecraft:water[level=0]
setblock 59 48 -355 minecraft:kelp_plant
setblock 60 48 -355 minecraft:water[level=0]
setblock 61 48 -355 minecraft:kelp_plant
fill 62 48 -355 63 48 -355 minecraft:water[level=0]
setblock 64 48 -355 minecraft:kelp_plant
setblock 65 48 -355 minecraft:water[level=0]
fill 34 48 -356 37 48 -356 minecraft:water[level=0]
fill 58 48 -356 68 48 -356 minecraft:water[level=0]
fill 34 48 -357 38 48 -357 minecraft:water[level=0]
fill 61 48 -357 62 48 -357 minecraft:water[level=0]
setblock 63 48 -357 minecraft:kelp_plant
fill 64 48 -357 66 48 -357 minecraft:water[level=0]
setblock 67 48 -357 minecraft:kelp_plant
fill 68 48 -357 69 48 -357 minecraft:water[level=0]
fill 36 48 -358 39 48 -358 minecraft:water[level=0]
setblock 51 48 -358 minecraft:water[level=0]
setblock 52 48 -358 minecraft:kelp_plant
setblock 53 48 -358 minecraft:water[level=0]
fill 62 48 -358 69 48 -358 minecraft:water[level=0]
fill 52 48 -359 58 48 -359 minecraft:water[level=0]
setblock 62 48 -359 minecraft:kelp_plant
fill 63 48 -359 71 48 -359 minecraft:water[level=0]
fill 54 48 -360 61 48 -360 minecraft:water[level=0]
fill 63 48 -360 68 48 -360 minecraft:water[level=0]
fill 69 48 -360 70 48 -360 minecraft:kelp_plant
setblock 71 48 -360 minecraft:water[level=0]
setblock 57 48 -361 minecraft:water[level=0]
setblock 58 48 -361 minecraft:kelp_plant
fill 59 48 -361 64 48 -361 minecraft:water[level=0]
setblock 65 48 -361 minecraft:kelp_plant
fill 66 48 -361 68 48 -361 minecraft:water[level=0]
setblock 69 48 -361 minecraft:kelp_plant
fill 70 48 -361 71 48 -361 minecraft:water[level=0]
fill 60 48 -362 68 48 -362 minecraft:water[level=0]
fill 69 48 -362 70 48 -362 minecraft:kelp_plant
setblock 71 48 -362 minecraft:water[level=0]
fill 62 48 -363 71 48 -363 minecraft:water[level=0]
fill 64 48 -364 68 48 -364 minecraft:water[level=0]
setblock 69 48 -364 minecraft:kelp_plant
fill 70 48 -364 71 48 -364 minecraft:water[level=0]
setblock 65 48 -365 minecraft:water[level=0]
setblock 66 48 -365 minecraft:kelp_plant
fill 67 48 -365 71 48 -365 minecraft:water[level=0]
setblock 65 48 -366 minecraft:kelp_plant
fill 66 48 -366 71 48 -366 minecraft:water[level=0]
fill 64 48 -367 70 48 -367 minecraft:water[level=0]
setblock 71 48 -367 minecraft:kelp_plant
setblock 64 48 -368 minecraft:kelp_plant
fill 65 48 -368 71 48 -368 minecraft:water[level=0]
fill 63 48 -369 71 48 -369 minecraft:water[level=0]
fill 63 48 -370 70 48 -370 minecraft:water[level=0]
fill 62 48 -371 70 48 -371 minecraft:water[level=0]
fill 61 48 -372 70 48 -372 minecraft:water[level=0]
fill 60 48 -373 69 48 -373 minecraft:water[level=0]
setblock 70 48 -373 minecraft:seagrass
setblock 71 48 -373 minecraft:water[level=0]
fill 8 48 -374 9 48 -374 minecraft:water[level=0]
fill 60 48 -374 67 48 -374 minecraft:water[level=0]
fill 70 48 -374 71 48 -374 minecraft:water[level=0]
fill 8 48 -375 10 48 -375 minecraft:water[level=0]
fill 60 48 -375 67 48 -375 minecraft:water[level=0]
setblock 68 48 -375 minecraft:seagrass
fill 69 48 -375 70 48 -375 minecraft:water[level=0]
setblock 71 48 -375 minecraft:seagrass
fill 8 48 -376 11 48 -376 minecraft:water[level=0]
fill 60 48 -376 69 48 -376 minecraft:water[level=0]
setblock 70 48 -376 minecraft:tall_seagrass[half=lower]
setblock 71 48 -376 minecraft:seagrass
fill 8 48 -377 10 48 -377 minecraft:water[level=0]
fill 60 48 -377 69 48 -377 minecraft:water[level=0]
setblock 70 48 -377 minecraft:seagrass
setblock 71 48 -377 minecraft:water[level=0]
fill 8 48 -378 10 48 -378 minecraft:water[level=0]
fill 59 48 -378 68 48 -378 minecraft:water[level=0]
setblock 70 48 -378 minecraft:water[level=0]
fill 8 48 -379 9 48 -379 minecraft:water[level=0]
setblock 10 48 -379 minecraft:tall_seagrass[half=upper]
fill 59 48 -379 68 48 -379 minecraft:water[level=0]
fill 70 48 -379 71 48 -379 minecraft:water[level=0]
fill 8 48 -380 9 48 -380 minecraft:water[level=0]
setblock 10 48 -380 minecraft:tall_seagrass[half=lower]
fill 59 48 -380 69 48 -380 minecraft:water[level=0]
setblock 70 48 -380 minecraft:tall_seagrass[half=lower]
setblock 71 48 -380 minecraft:water[level=0]
fill 8 48 -381 10 48 -381 minecraft:water[level=0]
fill 58 48 -381 71 48 -381 minecraft:water[level=0]
fill 8 48 -382 9 48 -382 minecraft:water[level=0]
fill 57 48 -382 71 48 -382 minecraft:water[level=0]
fill 16 47 -320 17 47 -320 minecraft:water[level=0]
fill 15 47 -321 19 47 -321 minecraft:water[level=0]
fill 14 47 -322 20 47 -322 minecraft:water[level=0]
fill 14 47 -323 20 47 -323 minecraft:water[level=0]
fill 14 47 -324 20 47 -324 minecraft:water[level=0]
fill 14 47 -325 20 47 -325 minecraft:water[level=0]
fill 14 47 -326 19 47 -326 minecraft:water[level=0]
fill 16 47 -327 17 47 -327 minecraft:water[level=0]
fill 68 47 -338 70 47 -338 minecraft:water[level=0]
fill 65 47 -339 71 47 -339 minecraft:water[level=0]
fill 64 47 -340 71 47 -340 minecraft:water[level=0]
fill 62 47 -341 71 47 -341 minecraft:water[level=0]
fill 59 47 -342 66 47 -342 minecraft:water[level=0]
fill 57 47 -343 64 47 -343 minecraft:water[level=0]
fill 55 47 -344 63 47 -344 minecraft:water[level=0]
fill 54 47 -345 61 47 -345 minecraft:water[level=0]
fill 53 47 -346 59 47 -346 minecraft:water[level=0]
fill 52 47 -347 54 47 -347 minecraft:water[level=0]
setblock 55 47 -347 minecraft:kelp_plant
fill 56 47 -347 58 47 -347 minecraft:water[level=0]
fill 51 47 -348 57 47 -348 minecraft:water[level=0]
fill 51 47 -349 54 47 -349 minecraft:water[level=0]
fill 51 47 -350 53 47 -350 minecraft:water[level=0]
fill 35 47 -356 40 47 -356 minecraft:water[level=0]
fill 35 47 -357 41 47 -357 minecraft:water[level=0]
fill 40 47 -358 41 47 -358 minecraft:water[level=0]
fill 49 47 -358 51 47 -358 minecraft:water[level=0]
setblock 52 47 -358 minecraft:kelp_plant
fill 53 47 -358 55 47 -358 minecraft:water[level=0]
fill 49 47 -359 59 47 -359 minecraft:water[level=0]
fill 55 47 -360 62 47 -360 minecraft:water[level=0]
setblock 58 47 -361 minecraft:kelp_plant
fill 59 47 -361 63 47 -361 minecraft:water[level=0]
fill 60 47 -362 64 47 -362 minecraft:water[level=0]
fill 62 47 -363 64 47 -363 minecraft:water[level=0]
fill 64 47 -364 65 47 -364 minecraft:water[level=0]
setblock 66 47 -365 minecraft:kelp_plant
setblock 37 47 -373 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 8 47 -374 9 47 -374 minecraft:water[level=0]
fill 8 47 -375 10 47 -375 minecraft:water[level=0]
fill 8 47 -376 10 47 -376 minecraft:water[level=0]
fill 8 47 -377 10 47 -377 minecraft:water[level=0]
fill 8 47 -378 10 47 -378 minecraft:water[level=0]
fill 8 47 -379 9 47 -379 minecraft:water[level=0]
setblock 10 47 -379 minecraft:tall_seagrass[half=lower]
fill 8 47 -380 9 47 -380 minecraft:water[level=0]
fill 8 47 -381 9 47 -381 minecraft:water[level=0]
setblock 8 47 -382 minecraft:water[level=0]
setblock 9 47 -382 minecraft:seagrass
fill 15 46 -321 16 46 -321 minecraft:water[level=0]
fill 17 46 -321 18 46 -321 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=true,west=false]
fill 14 46 -322 19 46 -322 minecraft:water[level=0]
fill 14 46 -323 20 46 -323 minecraft:water[level=0]
fill 13 46 -324 20 46 -324 minecraft:water[level=0]
fill 14 46 -325 19 46 -325 minecraft:water[level=0]
fill 14 46 -326 19 46 -326 minecraft:water[level=0]
fill 15 46 -327 18 46 -327 minecraft:water[level=0]
fill 58 46 -344 59 46 -344 minecraft:water[level=0]
fill 54 46 -345 56 46 -345 minecraft:water[level=0]
fill 58 46 -345 59 46 -345 minecraft:water[level=0]
fill 54 46 -346 58 46 -346 minecraft:water[level=0]
fill 51 46 -347 54 46 -347 minecraft:water[level=0]
setblock 55 46 -347 minecraft:kelp_plant
fill 56 46 -347 57 46 -347 minecraft:water[level=0]
fill 51 46 -348 56 46 -348 minecraft:water[level=0]
fill 50 46 -349 54 46 -349 minecraft:water[level=0]
fill 49 46 -350 54 46 -350 minecraft:water[level=0]
fill 50 46 -351 52 46 -351 minecraft:water[level=0]
fill 36 46 -356 42 46 -356 minecraft:water[level=0]
fill 36 46 -357 50 46 -357 minecraft:water[level=0]
fill 43 46 -358 51 46 -358 minecraft:water[level=0]
setblock 52 46 -358 minecraft:kelp_plant
fill 53 46 -358 56 46 -358 minecraft:water[level=0]
fill 51 46 -359 57 46 -359 minecraft:water[level=0]
fill 56 46 -360 58 46 -360 minecraft:water[level=0]
setblock 58 46 -361 minecraft:kelp_plant
setblock 59 46 -361 minecraft:water[level=0]
fill 37 46 -372 38 46 -372 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 37 46 -373 38 46 -373 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 8 46 -374 9 46 -374 minecraft:water[level=0]
fill 8 46 -375 9 46 -375 minecraft:water[level=0]
fill 8 46 -376 10 46 -376 minecraft:water[level=0]
fill 8 46 -377 10 46 -377 minecraft:water[level=0]
fill 8 46 -378 9 46 -378 minecraft:water[level=0]
fill 8 46 -379 9 46 -379 minecraft:water[level=0]
fill 8 46 -380 9 46 -380 minecraft:water[level=0]
fill 8 46 -381 9 46 -381 minecraft:water[level=0]
setblock 8 46 -382 minecraft:water[level=0]
fill 15 45 -321 18 45 -321 minecraft:water[level=0]
fill 14 45 -322 19 45 -322 minecraft:water[level=0]
fill 14 45 -323 20 45 -323 minecraft:water[level=0]
fill 13 45 -324 20 45 -324 minecraft:water[level=0]
fill 14 45 -325 19 45 -325 minecraft:water[level=0]
fill 14 45 -326 19 45 -326 minecraft:water[level=0]
fill 15 45 -327 18 45 -327 minecraft:water[level=0]
fill 55 45 -346 56 45 -346 minecraft:water[level=0]
fill 52 45 -347 54 45 -347 minecraft:water[level=0]
setblock 55 45 -347 minecraft:kelp_plant
setblock 56 45 -347 minecraft:water[level=0]
fill 50 45 -348 54 45 -348 minecraft:water[level=0]
fill 49 45 -349 54 45 -349 minecraft:water[level=0]
fill 48 45 -350 53 45 -350 minecraft:water[level=0]
fill 45 45 -351 53 45 -351 minecraft:water[level=0]
fill 47 45 -352 52 45 -352 minecraft:water[level=0]
setblock 49 45 -353 minecraft:water[level=0]
fill 37 45 -356 44 45 -356 minecraft:water[level=0]
fill 37 45 -357 52 45 -357 minecraft:water[level=0]
fill 46 45 -358 51 45 -358 minecraft:water[level=0]
setblock 52 45 -358 minecraft:kelp_plant
fill 53 45 -358 54 45 -358 minecraft:water[level=0]
fill 52 45 -359 54 45 -359 minecraft:water[level=0]
setblock 38 45 -372 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 8 45 -374 minecraft:water[level=0]
fill 8 45 -375 9 45 -375 minecraft:water[level=0]
fill 8 45 -376 9 45 -376 minecraft:water[level=0]
fill 8 45 -377 9 45 -377 minecraft:water[level=0]
fill 8 45 -378 9 45 -378 minecraft:water[level=0]
fill 8 45 -379 9 45 -379 minecraft:water[level=0]
fill 8 45 -380 9 45 -380 minecraft:water[level=0]
setblock 8 45 -381 minecraft:water[level=0]
setblock 8 45 -382 minecraft:water[level=0]
forceload remove 8 -382 71 -319
tellraw @a {"text":"Campus zurueck a08 fertig.","color":"green"}
