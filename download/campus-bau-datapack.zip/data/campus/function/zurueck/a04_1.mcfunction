setblock 207 79 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 78 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 78 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 208 78 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 77 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 207 77 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 208 77 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 207 77 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 77 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 77 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 208 77 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 77 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 76 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 76 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 208 76 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 76 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 230 76 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 75 -443 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 75 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 75 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 208 75 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 209 75 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 210 75 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 206 75 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 75 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 208 75 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 209 75 -445 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 229 75 -446 231 75 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 74 -440 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 206 74 -441 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 74 -442 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 74 -443 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 205 74 -444 206 74 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 207 74 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 208 74 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 209 74 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 210 74 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 74 -444 regions_unexplored:silver_birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 206 74 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 74 -445 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 208 74 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 209 74 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 230 74 -445 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 74 -446 minecraft:dark_oak_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 74 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 229 74 -446 231 74 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 73 -440 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 205 73 -441 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 73 -441 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 73 -442 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 207 73 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 208 73 -444 209 73 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 210 73 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 211 73 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 214 73 -444 regions_unexplored:silver_birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 217 73 -444 regions_unexplored:silver_birch_leaves[distance=5,persistent=false,waterlogged=false]
fill 208 73 -445 209 73 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 210 73 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 73 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 212 73 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 224 73 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 233 73 -446 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 234 73 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 235 73 -446 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 206 72 -392 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 206 72 -393 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 72 -394 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 215 72 -394 minecraft:air
setblock 239 72 -394 minecraft:air
setblock 206 72 -395 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 205 72 -396 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 206 72 -396 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 72 -398 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 200 72 -399 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 72 -403 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 204 72 -403 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 72 -404 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 202 72 -436 minecraft:air
setblock 212 72 -436 minecraft:air
setblock 222 72 -436 minecraft:air
setblock 232 72 -436 minecraft:air
setblock 242 72 -436 minecraft:air
setblock 252 72 -436 minecraft:air
setblock 262 72 -436 minecraft:air
setblock 205 72 -440 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 72 -440 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 72 -441 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 72 -441 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 72 -442 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 72 -442 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 207 72 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 208 72 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 209 72 -444 regions_unexplored:silver_birch_log[axis=x,is_base=false]
setblock 210 72 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 211 72 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 212 72 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 72 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 214 72 -444 regions_unexplored:silver_birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 215 72 -444 regions_unexplored:silver_birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 216 72 -444 regions_unexplored:silver_birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 217 72 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 218 72 -444 regions_unexplored:silver_birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 230 72 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 231 72 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 208 72 -445 209 72 -445 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 210 72 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 72 -445 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 234 72 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 72 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 72 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 209 72 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 212 72 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 72 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 218 72 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 233 72 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 234 72 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 235 72 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 71 -392 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 215 71 -392 minecraft:air
setblock 239 71 -392 minecraft:air
setblock 205 71 -393 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 71 -393 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 214 71 -393 216 71 -393 minecraft:air
fill 238 71 -393 240 71 -393 minecraft:air
setblock 206 71 -394 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 213 71 -394 217 71 -394 minecraft:air
fill 237 71 -394 241 71 -394 minecraft:air
setblock 206 71 -395 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 214 71 -395 216 71 -395 minecraft:air
fill 238 71 -395 240 71 -395 minecraft:air
setblock 205 71 -396 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 71 -396 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 215 71 -396 minecraft:air
setblock 239 71 -396 minecraft:air
setblock 206 71 -397 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 71 -398 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 71 -399 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 71 -399 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 71 -400 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 71 -402 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 71 -403 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 71 -403 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 71 -403 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 71 -404 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 202 71 -434 minecraft:air
setblock 212 71 -434 minecraft:air
setblock 222 71 -434 minecraft:air
setblock 232 71 -434 minecraft:air
setblock 242 71 -434 minecraft:air
setblock 252 71 -434 minecraft:air
setblock 262 71 -434 minecraft:air
fill 201 71 -435 203 71 -435 minecraft:air
fill 211 71 -435 213 71 -435 minecraft:air
fill 221 71 -435 223 71 -435 minecraft:air
fill 231 71 -435 233 71 -435 minecraft:air
fill 241 71 -435 243 71 -435 minecraft:air
fill 251 71 -435 253 71 -435 minecraft:air
fill 261 71 -435 263 71 -435 minecraft:air
fill 200 71 -436 204 71 -436 minecraft:air
fill 210 71 -436 214 71 -436 minecraft:air
fill 220 71 -436 224 71 -436 minecraft:air
fill 230 71 -436 234 71 -436 minecraft:air
fill 240 71 -436 244 71 -436 minecraft:air
fill 250 71 -436 254 71 -436 minecraft:air
fill 260 71 -436 263 71 -436 minecraft:air
fill 201 71 -437 203 71 -437 minecraft:air
fill 211 71 -437 213 71 -437 minecraft:air
fill 221 71 -437 223 71 -437 minecraft:air
fill 231 71 -437 233 71 -437 minecraft:air
fill 241 71 -437 243 71 -437 minecraft:air
fill 251 71 -437 253 71 -437 minecraft:air
fill 261 71 -437 263 71 -437 minecraft:air
setblock 202 71 -438 minecraft:air
setblock 212 71 -438 minecraft:air
setblock 222 71 -438 minecraft:air
setblock 232 71 -438 minecraft:air
setblock 242 71 -438 minecraft:air
setblock 252 71 -438 minecraft:air
setblock 262 71 -438 minecraft:air
setblock 206 71 -439 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 71 -440 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 71 -440 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 204 71 -441 205 71 -441 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 71 -441 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 205 71 -442 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 71 -442 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 71 -443 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 208 71 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 211 71 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 212 71 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 213 71 -444 regions_unexplored:silver_birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 214 71 -444 regions_unexplored:silver_birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 215 71 -444 regions_unexplored:silver_birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 216 71 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 217 71 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 71 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 230 71 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 231 71 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 232 71 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 71 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 71 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 218 71 -445 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 231 71 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 233 71 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 234 71 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 235 71 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 71 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 71 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 211 71 -446 213 71 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 71 -446 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 233 71 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 234 71 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 235 71 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 70 -386 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 70 -392 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 70 -392 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 214 70 -392 216 70 -392 minecraft:air
fill 238 70 -392 240 70 -392 minecraft:air
setblock 205 70 -393 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 70 -393 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 213 70 -393 217 70 -393 minecraft:air
fill 237 70 -393 241 70 -393 minecraft:air
setblock 205 70 -394 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 70 -394 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 213 70 -394 217 70 -394 minecraft:air
fill 237 70 -394 241 70 -394 minecraft:air
setblock 205 70 -395 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 70 -395 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 213 70 -395 217 70 -395 minecraft:air
fill 237 70 -395 241 70 -395 minecraft:air
setblock 205 70 -396 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 70 -396 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 214 70 -396 216 70 -396 minecraft:air
fill 238 70 -396 240 70 -396 minecraft:air
setblock 205 70 -397 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 206 70 -397 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 70 -398 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 70 -398 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 200 70 -399 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 70 -399 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 70 -400 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 201 70 -400 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 70 -402 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 70 -402 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 70 -402 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 203 70 -403 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 70 -403 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 70 -403 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 203 70 -404 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 204 70 -404 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 70 -404 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 201 70 -434 203 70 -434 minecraft:air
fill 211 70 -434 213 70 -434 minecraft:air
fill 221 70 -434 223 70 -434 minecraft:air
fill 231 70 -434 233 70 -434 minecraft:air
fill 241 70 -434 243 70 -434 minecraft:air
fill 251 70 -434 253 70 -434 minecraft:air
fill 261 70 -434 263 70 -434 minecraft:air
fill 200 70 -435 204 70 -435 minecraft:air
fill 210 70 -435 214 70 -435 minecraft:air
fill 220 70 -435 224 70 -435 minecraft:air
fill 230 70 -435 234 70 -435 minecraft:air
fill 240 70 -435 244 70 -435 minecraft:air
fill 250 70 -435 254 70 -435 minecraft:air
fill 260 70 -435 263 70 -435 minecraft:air
fill 200 70 -436 204 70 -436 minecraft:air
fill 210 70 -436 214 70 -436 minecraft:air
fill 220 70 -436 224 70 -436 minecraft:air
fill 230 70 -436 234 70 -436 minecraft:air
fill 240 70 -436 244 70 -436 minecraft:air
fill 250 70 -436 254 70 -436 minecraft:air
fill 260 70 -436 263 70 -436 minecraft:air
fill 200 70 -437 204 70 -437 minecraft:air
fill 210 70 -437 214 70 -437 minecraft:air
fill 220 70 -437 224 70 -437 minecraft:air
fill 230 70 -437 234 70 -437 minecraft:air
fill 240 70 -437 244 70 -437 minecraft:air
fill 250 70 -437 254 70 -437 minecraft:air
fill 260 70 -437 263 70 -437 minecraft:air
fill 201 70 -438 203 70 -438 minecraft:air
fill 211 70 -438 213 70 -438 minecraft:air
fill 221 70 -438 223 70 -438 minecraft:air
fill 231 70 -438 233 70 -438 minecraft:air
fill 241 70 -438 243 70 -438 minecraft:air
fill 251 70 -438 253 70 -438 minecraft:air
fill 261 70 -438 263 70 -438 minecraft:air
setblock 206 70 -441 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 208 70 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 211 70 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 212 70 -444 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 213 70 -444 regions_unexplored:silver_birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 217 70 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 70 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 70 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 232 70 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 234 70 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 212 70 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 70 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 70 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 70 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 230 70 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 231 70 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 232 70 -445 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 233 70 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 234 70 -445 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 235 70 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 211 70 -446 213 70 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 70 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 232 70 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 233 70 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 234 70 -446 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 235 70 -446 236 70 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 69 -391 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 69 -392 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 69 -392 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 215 69 -392 minecraft:air
setblock 239 69 -392 minecraft:air
setblock 204 69 -393 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 69 -393 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 69 -393 minecraft:birch_log[axis=y]
fill 214 69 -393 216 69 -393 minecraft:air
fill 238 69 -393 240 69 -393 minecraft:air
setblock 205 69 -394 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 69 -394 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 213 69 -394 217 69 -394 minecraft:air
fill 237 69 -394 241 69 -394 minecraft:air
setblock 205 69 -395 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 69 -395 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 214 69 -395 216 69 -395 minecraft:air
fill 238 69 -395 240 69 -395 minecraft:air
setblock 204 69 -396 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 69 -396 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 69 -396 minecraft:birch_log[axis=y]
setblock 215 69 -396 minecraft:air
setblock 239 69 -396 minecraft:air
setblock 200 69 -397 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 205 69 -397 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 69 -397 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 200 69 -398 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 69 -398 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 206 69 -398 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 69 -399 minecraft:birch_log[axis=y]
setblock 201 69 -399 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 202 69 -399 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 69 -400 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 201 69 -400 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 200 69 -401 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 69 -401 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 203 69 -402 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 69 -402 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 69 -402 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 69 -403 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 203 69 -403 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 204 69 -403 minecraft:birch_log[axis=y]
setblock 205 69 -403 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 206 69 -403 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 203 69 -404 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 69 -404 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 205 69 -404 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 204 69 -405 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 202 69 -434 minecraft:air
setblock 212 69 -434 minecraft:air
setblock 222 69 -434 minecraft:air
setblock 232 69 -434 minecraft:air
setblock 242 69 -434 minecraft:air
setblock 252 69 -434 minecraft:air
setblock 262 69 -434 minecraft:air
fill 201 69 -435 203 69 -435 minecraft:air
fill 211 69 -435 213 69 -435 minecraft:air
fill 221 69 -435 223 69 -435 minecraft:air
fill 231 69 -435 233 69 -435 minecraft:air
fill 241 69 -435 243 69 -435 minecraft:air
fill 251 69 -435 253 69 -435 minecraft:air
fill 261 69 -435 263 69 -435 minecraft:air
fill 200 69 -436 204 69 -436 minecraft:air
fill 210 69 -436 214 69 -436 minecraft:air
fill 220 69 -436 224 69 -436 minecraft:air
fill 230 69 -436 234 69 -436 minecraft:air
fill 240 69 -436 244 69 -436 minecraft:air
fill 250 69 -436 254 69 -436 minecraft:air
fill 260 69 -436 263 69 -436 minecraft:air
fill 201 69 -437 203 69 -437 minecraft:air
fill 211 69 -437 213 69 -437 minecraft:air
fill 221 69 -437 223 69 -437 minecraft:air
fill 231 69 -437 233 69 -437 minecraft:air
fill 241 69 -437 243 69 -437 minecraft:air
fill 251 69 -437 253 69 -437 minecraft:air
fill 261 69 -437 263 69 -437 minecraft:air
setblock 202 69 -438 minecraft:air
setblock 212 69 -438 minecraft:air
setblock 222 69 -438 minecraft:air
setblock 232 69 -438 minecraft:air
setblock 242 69 -438 minecraft:air
setblock 252 69 -438 minecraft:air
setblock 262 69 -438 minecraft:air
setblock 208 69 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 216 69 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 69 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 218 69 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 229 69 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 69 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 231 69 -444 regions_unexplored:silver_birch_log[axis=z,is_base=false]
setblock 232 69 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 233 69 -444 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 69 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 69 -445 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 218 69 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 230 69 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 231 69 -445 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 232 69 -445 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 216 69 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 217 69 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 218 69 -446 regions_unexplored:silver_birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 224 69 -446 regions_unexplored:silver_birch_log[axis=z,is_base=false]
setblock 231 69 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 234 69 -446 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 206 68 -393 minecraft:birch_log[axis=y]
setblock 215 68 -394 minecraft:air
setblock 239 68 -394 minecraft:air
setblock 206 68 -396 minecraft:birch_log[axis=y]
setblock 200 68 -399 minecraft:birch_log[axis=y]
setblock 204 68 -403 minecraft:birch_log[axis=y]
setblock 202 68 -436 minecraft:air
setblock 212 68 -436 minecraft:air
setblock 222 68 -436 minecraft:air
setblock 232 68 -436 minecraft:air
setblock 242 68 -436 minecraft:air
setblock 252 68 -436 minecraft:air
setblock 262 68 -436 minecraft:air
setblock 208 68 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 211 68 -444 regions_unexplored:silver_birch_log[axis=z,is_base=false]
setblock 216 68 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 68 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 218 68 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 215 68 -445 216 68 -445 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 217 68 -445 regions_unexplored:silver_birch_log[axis=z,is_base=false]
fill 218 68 -445 219 68 -445 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 216 68 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 217 68 -446 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 218 68 -446 regions_unexplored:silver_birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 234 68 -446 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 206 67 -393 minecraft:birch_log[axis=y]
setblock 215 67 -394 minecraft:air
setblock 239 67 -394 minecraft:air
setblock 206 67 -396 minecraft:birch_log[axis=y]
setblock 200 67 -399 minecraft:birch_log[axis=y]
setblock 204 67 -403 minecraft:birch_log[axis=y]
setblock 202 67 -436 minecraft:air
setblock 212 67 -436 minecraft:air
setblock 222 67 -436 minecraft:air
setblock 232 67 -436 minecraft:air
setblock 242 67 -436 minecraft:air
setblock 252 67 -436 minecraft:air
setblock 262 67 -436 minecraft:air
setblock 206 67 -437 regions_unexplored:silver_birch_log[axis=x,is_base=false]
setblock 208 67 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 217 67 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 234 67 -446 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 262 66 -386 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 246 66 -387 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 222 66 -389 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 235 66 -392 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 206 66 -393 minecraft:birch_log[axis=y]
setblock 215 66 -394 minecraft:air
setblock 239 66 -394 minecraft:air
setblock 206 66 -396 minecraft:birch_log[axis=y]
setblock 200 66 -399 minecraft:birch_log[axis=y]
setblock 252 66 -401 ars_nouveau:light_block[level=14,waterlogged=false]
setblock 204 66 -403 minecraft:birch_log[axis=y]
setblock 246 66 -409 minecraft:grass_block[snowy=false]
setblock 244 66 -411 minecraft:grass_block[snowy=false]
setblock 202 66 -436 minecraft:air
setblock 212 66 -436 minecraft:air
setblock 222 66 -436 minecraft:air
setblock 232 66 -436 minecraft:air
setblock 242 66 -436 minecraft:air
setblock 252 66 -436 minecraft:air
setblock 262 66 -436 minecraft:air
setblock 200 66 -444 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
setblock 205 66 -444 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 206 66 -444 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
setblock 207 66 -444 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 208 66 -444 regions_unexplored:silver_birch_log[axis=y,is_base=true]
setblock 217 66 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
setblock 205 66 -445 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
setblock 206 66 -445 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 208 66 -445 regions_unexplored:grass_sprouts
setblock 209 66 -445 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
setblock 200 66 -446 regions_unexplored:silt_grass_block[snowy=false]
setblock 201 66 -446 regions_unexplored:grass_sprouts
setblock 206 66 -446 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 209 66 -446 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 210 66 -446 regions_unexplored:grass_sprouts
setblock 213 66 -446 regions_unexplored:silver_birch_shrub[half=upper]
setblock 234 66 -446 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 200 65 -383 201 65 -383 minecraft:air
setblock 202 65 -383 minecraft:short_grass
setblock 203 65 -383 minecraft:air
setblock 204 65 -383 regions_unexplored:grass_sprouts
fill 205 65 -383 207 65 -383 minecraft:air
fill 208 65 -383 220 65 -383 minecraft:grass_block[snowy=false]
fill 221 65 -383 231 65 -383 minecraft:black_concrete
setblock 232 65 -383 minecraft:grass_block[snowy=false]
setblock 233 65 -383 minecraft:black_concrete
fill 234 65 -383 241 65 -383 minecraft:grass_block[snowy=false]
fill 242 65 -383 247 65 -383 minecraft:black_concrete
fill 200 65 -384 207 65 -384 minecraft:air
setblock 208 65 -384 minecraft:short_grass
fill 209 65 -384 248 65 -384 minecraft:grass_block[snowy=false]
fill 200 65 -385 203 65 -385 minecraft:air
setblock 204 65 -385 regions_unexplored:grass_sprouts
fill 205 65 -385 209 65 -385 minecraft:air
fill 210 65 -385 249 65 -385 minecraft:grass_block[snowy=false]
setblock 251 65 -385 minecraft:grass_block[snowy=false]
setblock 263 65 -385 minecraft:stone
fill 200 65 -386 203 65 -386 minecraft:air
setblock 204 65 -386 regions_unexplored:grass_sprouts
setblock 205 65 -386 minecraft:air
setblock 206 65 -386 minecraft:short_grass
setblock 207 65 -386 minecraft:air
setblock 208 65 -386 minecraft:short_grass
setblock 209 65 -386 minecraft:air
fill 210 65 -386 251 65 -386 minecraft:grass_block[snowy=false]
setblock 252 65 -386 minecraft:stone
setblock 254 65 -386 minecraft:stone
setblock 260 65 -386 minecraft:stone
fill 262 65 -386 263 65 -386 minecraft:stone
fill 200 65 -387 206 65 -387 minecraft:air
setblock 207 65 -387 minecraft:short_grass
setblock 208 65 -387 regions_unexplored:grass_sprouts
fill 209 65 -387 210 65 -387 minecraft:air
fill 211 65 -387 251 65 -387 minecraft:grass_block[snowy=false]
fill 252 65 -387 254 65 -387 minecraft:stone
setblock 255 65 -387 minecraft:dirt
setblock 257 65 -387 minecraft:stone
fill 259 65 -387 263 65 -387 minecraft:stone
fill 200 65 -388 204 65 -388 minecraft:air
setblock 205 65 -388 regions_unexplored:grass_sprouts
fill 206 65 -388 208 65 -388 minecraft:air
setblock 209 65 -388 minecraft:short_grass
fill 210 65 -388 211 65 -388 minecraft:air
fill 212 65 -388 253 65 -388 minecraft:grass_block[snowy=false]
fill 254 65 -388 263 65 -388 minecraft:stone
fill 200 65 -389 205 65 -389 minecraft:air
setblock 206 65 -389 regions_unexplored:grass_sprouts
setblock 207 65 -389 minecraft:short_grass
setblock 208 65 -389 productivebees:birch_wood_nest[axis=y,facing=north]
fill 209 65 -389 210 65 -389 minecraft:air
setblock 211 65 -389 minecraft:short_grass
setblock 212 65 -389 minecraft:air
fill 213 65 -389 253 65 -389 minecraft:grass_block[snowy=false]
fill 254 65 -389 263 65 -389 minecraft:stone
fill 200 65 -390 206 65 -390 minecraft:air
setblock 207 65 -390 regions_unexplored:grass_sprouts
fill 208 65 -390 210 65 -390 minecraft:air
setblock 211 65 -390 regions_unexplored:grass_sprouts
fill 212 65 -390 213 65 -390 minecraft:air
fill 214 65 -390 254 65 -390 minecraft:grass_block[snowy=false]
fill 255 65 -390 263 65 -390 minecraft:stone
fill 200 65 -391 211 65 -391 minecraft:air
setblock 212 65 -391 minecraft:short_grass
setblock 213 65 -391 minecraft:air
setblock 214 65 -391 regions_unexplored:grass_sprouts
setblock 215 65 -391 minecraft:air
fill 217 65 -391 237 65 -391 minecraft:grass_block[snowy=false]
fill 241 65 -391 251 65 -391 minecraft:grass_block[snowy=false]
setblock 252 65 -391 minecraft:stone
fill 253 65 -391 254 65 -391 minecraft:grass_block[snowy=false]
fill 255 65 -391 263 65 -391 minecraft:stone
fill 200 65 -392 209 65 -392 minecraft:air
setblock 210 65 -392 regions_unexplored:grass_sprouts
fill 211 65 -392 216 65 -392 minecraft:air
fill 218 65 -392 220 65 -392 minecraft:grass_block[snowy=false]
fill 222 65 -392 236 65 -392 minecraft:grass_block[snowy=false]
fill 242 65 -392 254 65 -392 minecraft:grass_block[snowy=false]
setblock 255 65 -392 minecraft:stone
setblock 256 65 -392 minecraft:dirt
fill 257 65 -392 263 65 -392 minecraft:stone
fill 200 65 -393 205 65 -393 minecraft:air
setblock 206 65 -393 minecraft:birch_log[axis=y]
fill 207 65 -393 217 65 -393 minecraft:air
fill 219 65 -393 235 65 -393 minecraft:grass_block[snowy=false]
fill 243 65 -393 252 65 -393 minecraft:grass_block[snowy=false]
fill 253 65 -393 263 65 -393 minecraft:stone
fill 200 65 -394 211 65 -394 minecraft:air
setblock 212 65 -394 minecraft:birch_log[axis=y]
fill 213 65 -394 217 65 -394 minecraft:air
fill 219 65 -394 235 65 -394 minecraft:grass_block[snowy=false]
fill 243 65 -394 250 65 -394 minecraft:grass_block[snowy=false]
fill 251 65 -394 252 65 -394 minecraft:coal_ore
setblock 253 65 -394 minecraft:grass_block[snowy=false]
fill 254 65 -394 263 65 -394 minecraft:stone
fill 200 65 -395 214 65 -395 minecraft:air
setblock 215 65 -395 minecraft:birch_log[axis=y]
fill 216 65 -395 218 65 -395 minecraft:air
fill 219 65 -395 235 65 -395 minecraft:grass_block[snowy=false]
fill 243 65 -395 250 65 -395 minecraft:grass_block[snowy=false]
fill 251 65 -395 252 65 -395 minecraft:coal_ore
fill 253 65 -395 263 65 -395 minecraft:stone
fill 200 65 -396 205 65 -396 minecraft:air
setblock 206 65 -396 minecraft:birch_log[axis=y]
fill 207 65 -396 218 65 -396 minecraft:air
fill 219 65 -396 236 65 -396 minecraft:grass_block[snowy=false]
fill 242 65 -396 250 65 -396 minecraft:grass_block[snowy=false]
fill 251 65 -396 263 65 -396 minecraft:stone
fill 200 65 -397 218 65 -397 minecraft:air
fill 219 65 -397 237 65 -397 minecraft:grass_block[snowy=false]
fill 241 65 -397 250 65 -397 minecraft:grass_block[snowy=false]
setblock 251 65 -397 minecraft:stone
setblock 252 65 -397 theurgy:sal_ammoniac_ore
fill 253 65 -397 261 65 -397 minecraft:stone
fill 262 65 -397 263 65 -397 minecraft:grass_block[snowy=false]
fill 200 65 -398 219 65 -398 minecraft:air
fill 220 65 -398 251 65 -398 minecraft:grass_block[snowy=false]
fill 252 65 -398 262 65 -398 minecraft:stone
setblock 263 65 -398 minecraft:grass_block[snowy=false]
setblock 200 65 -399 minecraft:birch_log[axis=y]
fill 201 65 -399 219 65 -399 minecraft:air
fill 220 65 -399 252 65 -399 minecraft:grass_block[snowy=false]
fill 253 65 -399 262 65 -399 minecraft:stone
setblock 263 65 -399 evilcraft:dark_ore[glowing=false]
fill 200 65 -400 221 65 -400 minecraft:air
fill 222 65 -400 253 65 -400 minecraft:grass_block[snowy=false]
fill 254 65 -400 262 65 -400 minecraft:stone
setblock 263 65 -400 minecraft:grass_block[snowy=false]
fill 200 65 -401 221 65 -401 minecraft:air
setblock 222 65 -401 minecraft:birch_log[axis=y]
setblock 223 65 -401 minecraft:air
fill 224 65 -401 254 65 -401 minecraft:grass_block[snowy=false]
fill 255 65 -401 263 65 -401 minecraft:stone
fill 200 65 -402 218 65 -402 minecraft:air
setblock 219 65 -402 minecraft:birch_log[axis=y]
fill 220 65 -402 224 65 -402 minecraft:air
fill 225 65 -402 258 65 -402 minecraft:grass_block[snowy=false]
fill 259 65 -402 263 65 -402 minecraft:stone
fill 200 65 -403 203 65 -403 minecraft:air
setblock 204 65 -403 minecraft:birch_log[axis=y]
fill 205 65 -403 220 65 -403 minecraft:air
setblock 221 65 -403 minecraft:short_grass
fill 222 65 -403 224 65 -403 minecraft:air
fill 225 65 -403 263 65 -403 minecraft:grass_block[snowy=false]
fill 200 65 -404 221 65 -404 minecraft:air
setblock 222 65 -404 minecraft:birch_log[axis=y]
fill 223 65 -404 225 65 -404 minecraft:air
fill 226 65 -404 263 65 -404 minecraft:grass_block[snowy=false]
fill 200 65 -405 227 65 -405 minecraft:air
fill 260 65 -405 263 65 -405 minecraft:grass_block[snowy=false]
fill 200 65 -406 212 65 -406 minecraft:air
setblock 213 65 -406 minecraft:birch_log[axis=y]
fill 214 65 -406 223 65 -406 minecraft:air
setblock 224 65 -406 minecraft:short_grass
fill 225 65 -406 228 65 -406 minecraft:air
setblock 229 65 -406 minecraft:short_grass
fill 260 65 -406 263 65 -406 minecraft:grass_block[snowy=false]
fill 200 65 -407 231 65 -407 minecraft:air
fill 260 65 -407 263 65 -407 minecraft:grass_block[snowy=false]
fill 200 65 -408 225 65 -408 minecraft:air
setblock 226 65 -408 minecraft:birch_log[axis=y]
fill 227 65 -408 233 65 -408 minecraft:air
fill 260 65 -408 263 65 -408 minecraft:grass_block[snowy=false]
fill 200 65 -409 236 65 -409 minecraft:air
setblock 237 65 -409 minecraft:birch_log[axis=y]
setblock 238 65 -409 minecraft:short_grass
fill 239 65 -409 242 65 -409 minecraft:air
setblock 246 65 -409 minecraft:dirt
fill 258 65 -409 263 65 -409 minecraft:grass_block[snowy=false]
fill 200 65 -410 229 65 -410 minecraft:air
setblock 230 65 -410 regions_unexplored:grass_sprouts
fill 231 65 -410 232 65 -410 minecraft:air
setblock 233 65 -410 minecraft:birch_log[axis=y]
setblock 234 65 -410 regions_unexplored:grass_sprouts
fill 235 65 -410 241 65 -410 minecraft:air
setblock 242 65 -410 minecraft:short_grass
setblock 243 65 -410 minecraft:air
fill 256 65 -410 263 65 -410 minecraft:grass_block[snowy=false]
fill 200 65 -411 208 65 -411 minecraft:air
setblock 209 65 -411 minecraft:sugar_cane[age=0]
fill 210 65 -411 211 65 -411 minecraft:air
setblock 212 65 -411 minecraft:birch_log[axis=y]
fill 213 65 -411 228 65 -411 minecraft:air
setblock 229 65 -411 minecraft:birch_log[axis=y]
fill 230 65 -411 235 65 -411 minecraft:air
setblock 236 65 -411 minecraft:short_grass
fill 237 65 -411 238 65 -411 minecraft:air
setblock 239 65 -411 minecraft:birch_log[axis=y]
fill 240 65 -411 241 65 -411 minecraft:air
setblock 242 65 -411 minecraft:short_grass
setblock 243 65 -411 minecraft:air
setblock 244 65 -411 minecraft:dirt
fill 255 65 -411 263 65 -411 minecraft:grass_block[snowy=false]
fill 200 65 -412 209 65 -412 minecraft:air
setblock 210 65 -412 minecraft:sugar_cane[age=0]
fill 211 65 -412 243 65 -412 minecraft:air
setblock 248 65 -412 minecraft:air
fill 254 65 -412 263 65 -412 minecraft:grass_block[snowy=false]
fill 200 65 -413 210 65 -413 minecraft:air
setblock 211 65 -413 minecraft:sugar_cane[age=0]
fill 212 65 -413 219 65 -413 minecraft:air
setblock 220 65 -413 minecraft:birch_log[axis=y]
fill 221 65 -413 241 65 -413 minecraft:air
setblock 242 65 -413 minecraft:short_grass
setblock 243 65 -413 minecraft:air
fill 244 65 -413 245 65 -413 regions_unexplored:grass_sprouts
fill 246 65 -413 250 65 -413 minecraft:air
fill 253 65 -413 263 65 -413 minecraft:grass_block[snowy=false]
fill 200 65 -414 211 65 -414 minecraft:air
fill 212 65 -414 214 65 -414 minecraft:sugar_cane[age=0]
fill 215 65 -414 216 65 -414 minecraft:air
setblock 217 65 -414 minecraft:birch_log[axis=y]
fill 218 65 -414 242 65 -414 minecraft:air
setblock 243 65 -414 regions_unexplored:grass_sprouts
fill 244 65 -414 246 65 -414 minecraft:air
setblock 247 65 -414 minecraft:short_grass
fill 248 65 -414 252 65 -414 minecraft:air
fill 253 65 -414 263 65 -414 minecraft:grass_block[snowy=false]
fill 200 65 -415 240 65 -415 minecraft:air
setblock 241 65 -415 minecraft:birch_log[axis=y]
fill 242 65 -415 243 65 -415 minecraft:air
setblock 244 65 -415 minecraft:short_grass
fill 245 65 -415 248 65 -415 minecraft:air
setblock 249 65 -415 regions_unexplored:grass_sprouts
fill 250 65 -415 252 65 -415 minecraft:air
fill 253 65 -415 263 65 -415 minecraft:grass_block[snowy=false]
fill 200 65 -416 245 65 -416 minecraft:air
setblock 246 65 -416 regions_unexplored:grass_sprouts
setblock 247 65 -416 minecraft:air
setblock 248 65 -416 minecraft:short_grass
fill 249 65 -416 253 65 -416 minecraft:air
fill 254 65 -416 263 65 -416 minecraft:grass_block[snowy=false]
fill 200 65 -417 244 65 -417 minecraft:air
setblock 245 65 -417 minecraft:birch_log[axis=y]
fill 246 65 -417 250 65 -417 minecraft:air
setblock 251 65 -417 minecraft:short_grass
fill 252 65 -417 253 65 -417 minecraft:air
setblock 254 65 -417 regions_unexplored:grass_sprouts
fill 255 65 -417 263 65 -417 minecraft:grass_block[snowy=false]
fill 200 65 -418 249 65 -418 minecraft:air
setblock 250 65 -418 minecraft:birch_log[axis=y]
fill 251 65 -418 254 65 -418 minecraft:air
fill 255 65 -418 263 65 -418 minecraft:grass_block[snowy=false]
fill 200 65 -419 255 65 -419 minecraft:air
fill 256 65 -419 263 65 -419 minecraft:grass_block[snowy=false]
fill 200 65 -420 253 65 -420 minecraft:air
setblock 254 65 -420 minecraft:short_grass
setblock 255 65 -420 minecraft:air
fill 256 65 -420 263 65 -420 minecraft:grass_block[snowy=false]
fill 200 65 -421 235 65 -421 minecraft:air
setblock 236 65 -421 minecraft:birch_log[axis=y]
fill 237 65 -421 256 65 -421 minecraft:air
fill 257 65 -421 263 65 -421 minecraft:grass_block[snowy=false]
fill 200 65 -422 240 65 -422 minecraft:air
setblock 241 65 -422 minecraft:birch_log[axis=y]
fill 242 65 -422 257 65 -422 minecraft:air
fill 258 65 -422 263 65 -422 minecraft:grass_block[snowy=false]
fill 200 65 -423 258 65 -423 minecraft:air
fill 259 65 -423 263 65 -423 minecraft:grass_block[snowy=false]
fill 200 65 -424 253 65 -424 minecraft:air
setblock 254 65 -424 minecraft:birch_log[axis=y]
fill 255 65 -424 259 65 -424 minecraft:air
fill 260 65 -424 263 65 -424 minecraft:grass_block[snowy=false]
fill 200 65 -425 260 65 -425 minecraft:air
fill 261 65 -425 263 65 -425 minecraft:grass_block[snowy=false]
fill 200 65 -426 257 65 -426 minecraft:air
setblock 258 65 -426 minecraft:birch_log[axis=y]
fill 259 65 -426 260 65 -426 minecraft:air
setblock 261 65 -426 minecraft:short_grass
setblock 262 65 -426 minecraft:air
setblock 263 65 -426 minecraft:grass_block[snowy=false]
fill 200 65 -427 259 65 -427 minecraft:air
setblock 260 65 -427 minecraft:short_grass
fill 261 65 -427 263 65 -427 minecraft:air
fill 200 65 -428 263 65 -428 minecraft:air
fill 200 65 -429 244 65 -429 minecraft:air
setblock 245 65 -429 minecraft:birch_log[axis=y]
fill 246 65 -429 263 65 -429 minecraft:air
fill 200 65 -430 254 65 -430 minecraft:air
setblock 255 65 -430 minecraft:birch_log[axis=y]
fill 256 65 -430 263 65 -430 minecraft:air
fill 200 65 -431 251 65 -431 minecraft:air
setblock 252 65 -431 minecraft:birch_log[axis=y]
fill 253 65 -431 263 65 -431 minecraft:air
fill 200 65 -432 239 65 -432 minecraft:air
setblock 240 65 -432 minecraft:oak_fence[east=false,north=false,south=false,waterlogged=false,west=false]
fill 241 65 -432 263 65 -432 minecraft:air
fill 200 65 -433 258 65 -433 minecraft:air
setblock 259 65 -433 regions_unexplored:birch_shrub[half=upper]
fill 260 65 -433 262 65 -433 minecraft:air
setblock 263 65 -433 minecraft:birch_log[axis=y]
fill 200 65 -434 263 65 -434 minecraft:air
fill 200 65 -435 263 65 -435 minecraft:air
fill 200 65 -436 263 65 -436 minecraft:air
fill 200 65 -437 206 65 -437 minecraft:air
setblock 207 65 -437 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 208 65 -437 211 65 -437 minecraft:air
setblock 212 65 -437 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 213 65 -437 263 65 -437 minecraft:air
fill 200 65 -438 263 65 -438 minecraft:air
fill 200 65 -439 263 65 -439 minecraft:air
fill 200 65 -440 210 65 -440 minecraft:air
setblock 211 65 -440 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 212 65 -440 263 65 -440 minecraft:air
fill 200 65 -441 206 65 -441 minecraft:air
setblock 207 65 -441 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 208 65 -441 263 65 -441 minecraft:air
fill 200 65 -442 208 65 -442 minecraft:air
setblock 209 65 -442 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
fill 210 65 -442 222 65 -442 minecraft:air
setblock 223 65 -442 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 224 65 -442 227 65 -442 minecraft:air
setblock 228 65 -442 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 229 65 -442 263 65 -442 minecraft:air
fill 200 65 -443 205 65 -443 minecraft:air
setblock 206 65 -443 minecraft:short_grass
setblock 207 65 -443 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 208 65 -443 regions_unexplored:grass_sprouts
setblock 209 65 -443 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 210 65 -443 minecraft:air
setblock 211 65 -443 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 212 65 -443 214 65 -443 minecraft:air
setblock 215 65 -443 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 216 65 -443 226 65 -443 minecraft:air
setblock 227 65 -443 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 228 65 -443 regions_unexplored:silver_birch_branch[facing=north]
setblock 229 65 -443 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 230 65 -443 minecraft:air
setblock 231 65 -443 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 232 65 -443 263 65 -443 minecraft:air
fill 200 65 -444 203 65 -444 regions_unexplored:silt_grass_block[snowy=false]
setblock 204 65 -444 minecraft:air
fill 205 65 -444 207 65 -444 regions_unexplored:silt_grass_block[snowy=false]
setblock 208 65 -444 regions_unexplored:silt_dirt
setblock 209 65 -444 minecraft:air
setblock 210 65 -444 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
setblock 211 65 -444 minecraft:short_grass
fill 212 65 -444 216 65 -444 minecraft:air
setblock 217 65 -444 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 218 65 -444 227 65 -444 minecraft:air
setblock 228 65 -444 regions_unexplored:silver_birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 229 65 -444 263 65 -444 minecraft:air
fill 200 65 -445 209 65 -445 regions_unexplored:silt_grass_block[snowy=false]
fill 210 65 -445 212 65 -445 minecraft:air
setblock 213 65 -445 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=2]
fill 214 65 -445 263 65 -445 minecraft:air
setblock 200 65 -446 regions_unexplored:silt_dirt
fill 201 65 -446 210 65 -446 regions_unexplored:silt_grass_block[snowy=false]
setblock 211 65 -446 minecraft:air
setblock 212 65 -446 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 213 65 -446 regions_unexplored:silver_birch_shrub[half=lower]
setblock 214 65 -446 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
fill 215 65 -446 233 65 -446 minecraft:air
setblock 234 65 -446 regions_unexplored:silver_birch_log[axis=y,is_base=false]
fill 235 65 -446 263 65 -446 minecraft:air
fill 200 64 -383 201 64 -383 minecraft:air
setblock 200 64 -384 minecraft:air
setblock 201 64 -384 regions_unexplored:grass_sprouts
setblock 202 64 -384 minecraft:air
setblock 200 64 -385 regions_unexplored:grass_sprouts
fill 201 64 -385 202 64 -385 minecraft:air
fill 256 64 -385 258 64 -385 minecraft:air
fill 200 64 -386 202 64 -386 minecraft:air
fill 256 64 -386 257 64 -386 minecraft:air
fill 200 64 -387 203 64 -387 minecraft:air
fill 200 64 -388 202 64 -388 minecraft:air
fill 203 64 -388 204 64 -388 regions_unexplored:grass_sprouts
fill 200 64 -389 205 64 -389 minecraft:air
fill 200 64 -390 205 64 -390 minecraft:air
setblock 206 64 -390 minecraft:short_grass
setblock 200 64 -391 minecraft:air
setblock 201 64 -391 minecraft:short_grass
setblock 202 64 -391 regions_unexplored:grass_sprouts
fill 203 64 -391 205 64 -391 minecraft:air
setblock 206 64 -391 minecraft:short_grass
fill 200 64 -392 201 64 -392 minecraft:air
setblock 202 64 -392 minecraft:short_grass
fill 203 64 -392 204 64 -392 minecraft:air
setblock 205 64 -392 regions_unexplored:grass_sprouts
setblock 206 64 -392 minecraft:short_grass
setblock 207 64 -392 minecraft:air
fill 200 64 -393 202 64 -393 minecraft:air
setblock 203 64 -393 regions_unexplored:grass_sprouts
fill 204 64 -393 205 64 -393 minecraft:air
setblock 207 64 -393 regions_unexplored:grass_sprouts
fill 208 64 -393 211 64 -393 minecraft:air
setblock 212 64 -393 minecraft:short_grass
setblock 200 64 -394 minecraft:air
setblock 201 64 -394 regions_unexplored:grass_sprouts
fill 202 64 -394 211 64 -394 minecraft:air
fill 213 64 -394 214 64 -394 minecraft:air
fill 200 64 -395 214 64 -395 minecraft:air
fill 200 64 -396 205 64 -396 minecraft:air
fill 207 64 -396 216 64 -396 minecraft:air
setblock 200 64 -397 minecraft:short_grass
fill 201 64 -397 216 64 -397 minecraft:air
fill 200 64 -398 216 64 -398 minecraft:air
fill 201 64 -399 217 64 -399 minecraft:air
fill 200 64 -400 216 64 -400 minecraft:air
fill 200 64 -401 217 64 -401 minecraft:air
fill 200 64 -402 211 64 -402 minecraft:air
fill 213 64 -402 218 64 -402 minecraft:air
fill 200 64 -403 203 64 -403 minecraft:air
fill 205 64 -403 218 64 -403 minecraft:air
fill 200 64 -404 212 64 -404 minecraft:air
setblock 213 64 -404 regions_unexplored:grass_sprouts
fill 214 64 -404 219 64 -404 minecraft:air
fill 200 64 -405 215 64 -405 minecraft:air
fill 217 64 -405 218 64 -405 minecraft:air
setblock 219 64 -405 minecraft:short_grass
fill 220 64 -405 221 64 -405 minecraft:air
fill 200 64 -406 212 64 -406 minecraft:air
fill 214 64 -406 219 64 -406 minecraft:air
setblock 220 64 -406 regions_unexplored:grass_sprouts
fill 221 64 -406 222 64 -406 minecraft:air
fill 200 64 -407 215 64 -407 minecraft:air
setblock 216 64 -407 minecraft:short_grass
fill 217 64 -407 224 64 -407 minecraft:air
fill 200 64 -408 223 64 -408 minecraft:air
setblock 224 64 -408 regions_unexplored:grass_sprouts
setblock 225 64 -408 minecraft:air
fill 200 64 -409 214 64 -409 minecraft:air
setblock 215 64 -409 minecraft:short_grass
setblock 216 64 -409 minecraft:air
setblock 217 64 -409 regions_unexplored:grass_sprouts
fill 218 64 -409 223 64 -409 minecraft:air
setblock 224 64 -409 minecraft:short_grass
setblock 225 64 -409 minecraft:air
setblock 226 64 -409 regions_unexplored:grass_sprouts
setblock 227 64 -409 minecraft:air
fill 200 64 -410 216 64 -410 minecraft:air
fill 217 64 -410 218 64 -410 regions_unexplored:grass_sprouts
fill 219 64 -410 229 64 -410 minecraft:air
fill 200 64 -411 208 64 -411 minecraft:air
setblock 209 64 -411 minecraft:sugar_cane[age=0]
fill 210 64 -411 211 64 -411 minecraft:air
setblock 213 64 -411 minecraft:air
setblock 214 64 -411 minecraft:short_grass
fill 215 64 -411 216 64 -411 minecraft:air
setblock 217 64 -411 regions_unexplored:grass_sprouts
fill 218 64 -411 220 64 -411 minecraft:air
setblock 221 64 -411 regions_unexplored:grass_sprouts
fill 222 64 -411 226 64 -411 minecraft:air
setblock 227 64 -411 minecraft:short_grass
setblock 228 64 -411 minecraft:air
fill 230 64 -411 233 64 -411 minecraft:air
fill 200 64 -412 209 64 -412 minecraft:air
setblock 210 64 -412 minecraft:sugar_cane[age=0]
fill 211 64 -412 219 64 -412 minecraft:air
setblock 220 64 -412 minecraft:short_grass
fill 221 64 -412 224 64 -412 minecraft:air
setblock 225 64 -412 minecraft:short_grass
fill 226 64 -412 238 64 -412 minecraft:air
setblock 239 64 -412 regions_unexplored:grass_sprouts
setblock 240 64 -412 minecraft:air
fill 200 64 -413 210 64 -413 minecraft:air
setblock 211 64 -413 minecraft:sugar_cane[age=0]
fill 212 64 -413 219 64 -413 minecraft:air
fill 221 64 -413 222 64 -413 minecraft:air
setblock 223 64 -413 regions_unexplored:grass_sprouts
fill 224 64 -413 225 64 -413 minecraft:air
setblock 226 64 -413 regions_unexplored:grass_sprouts
setblock 227 64 -413 minecraft:air
setblock 228 64 -413 regions_unexplored:grass_sprouts
fill 229 64 -413 230 64 -413 minecraft:air
setblock 231 64 -413 minecraft:short_grass
fill 232 64 -413 233 64 -413 minecraft:air
setblock 234 64 -413 regions_unexplored:grass_sprouts
setblock 235 64 -413 minecraft:air
setblock 236 64 -413 minecraft:short_grass
fill 237 64 -413 241 64 -413 minecraft:air
fill 200 64 -414 211 64 -414 minecraft:air
fill 212 64 -414 214 64 -414 minecraft:sugar_cane[age=0]
fill 215 64 -414 216 64 -414 minecraft:air
fill 218 64 -414 239 64 -414 minecraft:air
fill 240 64 -414 241 64 -414 minecraft:short_grass
setblock 242 64 -414 minecraft:air
fill 200 64 -415 215 64 -415 minecraft:air
fill 217 64 -415 218 64 -415 minecraft:air
fill 220 64 -415 222 64 -415 minecraft:air
fill 224 64 -415 227 64 -415 minecraft:air
setblock 228 64 -415 regions_unexplored:grass_sprouts
fill 229 64 -415 230 64 -415 minecraft:air
fill 231 64 -415 232 64 -415 regions_unexplored:grass_sprouts
fill 233 64 -415 240 64 -415 minecraft:air
setblock 242 64 -415 regions_unexplored:grass_sprouts
setblock 243 64 -415 minecraft:air
fill 200 64 -416 220 64 -416 minecraft:air
fill 223 64 -416 224 64 -416 minecraft:air
fill 226 64 -416 229 64 -416 minecraft:air
setblock 230 64 -416 regions_unexplored:grass_sprouts
setblock 231 64 -416 minecraft:air
setblock 232 64 -416 regions_unexplored:grass_sprouts
fill 233 64 -416 234 64 -416 minecraft:air
fill 235 64 -416 236 64 -416 minecraft:short_grass
fill 237 64 -416 245 64 -416 minecraft:air
fill 200 64 -417 225 64 -417 minecraft:air
fill 228 64 -417 236 64 -417 minecraft:air
fill 237 64 -417 238 64 -417 minecraft:short_grass
fill 239 64 -417 244 64 -417 minecraft:air
setblock 246 64 -417 regions_unexplored:grass_sprouts
fill 247 64 -417 248 64 -417 minecraft:air
fill 200 64 -418 234 64 -418 minecraft:air
fill 235 64 -418 236 64 -418 minecraft:short_grass
setblock 237 64 -418 minecraft:air
setblock 238 64 -418 minecraft:short_grass
fill 239 64 -418 245 64 -418 minecraft:air
setblock 246 64 -418 regions_unexplored:grass_sprouts
fill 247 64 -418 249 64 -418 minecraft:air
fill 200 64 -419 235 64 -419 minecraft:air
setblock 236 64 -419 regions_unexplored:grass_sprouts
setblock 237 64 -419 minecraft:short_grass
fill 238 64 -419 244 64 -419 minecraft:air
setblock 245 64 -419 regions_unexplored:grass_sprouts
fill 246 64 -419 250 64 -419 minecraft:air
setblock 251 64 -419 minecraft:short_grass
setblock 252 64 -419 minecraft:air
fill 200 64 -420 238 64 -420 minecraft:air
setblock 239 64 -420 minecraft:short_grass
fill 240 64 -420 241 64 -420 minecraft:air
setblock 242 64 -420 regions_unexplored:grass_sprouts
setblock 243 64 -420 minecraft:short_grass
fill 244 64 -420 253 64 -420 minecraft:air
fill 200 64 -421 235 64 -421 minecraft:air
fill 237 64 -421 240 64 -421 minecraft:air
setblock 241 64 -421 minecraft:short_grass
fill 242 64 -421 245 64 -421 minecraft:air
fill 246 64 -421 247 64 -421 minecraft:short_grass
fill 248 64 -421 253 64 -421 minecraft:air
fill 200 64 -422 240 64 -422 minecraft:air
fill 242 64 -422 244 64 -422 minecraft:air
fill 245 64 -422 248 64 -422 minecraft:short_grass
fill 249 64 -422 254 64 -422 minecraft:air
fill 200 64 -423 255 64 -423 minecraft:air
fill 200 64 -424 243 64 -424 minecraft:air
setblock 244 64 -424 minecraft:short_grass
fill 245 64 -424 253 64 -424 minecraft:air
fill 255 64 -424 256 64 -424 minecraft:air
fill 200 64 -425 252 64 -425 minecraft:air
setblock 253 64 -425 minecraft:short_grass
fill 254 64 -425 257 64 -425 minecraft:air
fill 200 64 -426 257 64 -426 minecraft:air
fill 200 64 -427 259 64 -427 minecraft:air
fill 200 64 -428 241 64 -428 minecraft:air
fill 243 64 -428 259 64 -428 minecraft:air
setblock 260 64 -428 minecraft:short_grass
setblock 261 64 -428 minecraft:air
fill 200 64 -429 238 64 -429 minecraft:air
fill 240 64 -429 243 64 -429 minecraft:air
fill 246 64 -429 263 64 -429 minecraft:air
fill 200 64 -430 241 64 -430 minecraft:air
fill 243 64 -430 254 64 -430 minecraft:air
fill 256 64 -430 263 64 -430 minecraft:air
fill 200 64 -431 237 64 -431 minecraft:air
fill 239 64 -431 251 64 -431 minecraft:air
fill 253 64 -431 263 64 -431 minecraft:air
fill 200 64 -432 237 64 -432 minecraft:air
setblock 239 64 -432 minecraft:air
fill 241 64 -432 262 64 -432 minecraft:air
setblock 263 64 -432 minecraft:short_grass
fill 200 64 -433 238 64 -433 minecraft:air
fill 240 64 -433 255 64 -433 minecraft:air
fill 257 64 -433 258 64 -433 minecraft:air
setblock 260 64 -433 minecraft:air
setblock 261 64 -433 regions_unexplored:grass_sprouts
setblock 262 64 -433 minecraft:air
fill 200 64 -434 261 64 -434 minecraft:air
setblock 262 64 -434 regions_unexplored:grass_sprouts
setblock 263 64 -434 minecraft:air
fill 200 64 -435 263 64 -435 minecraft:air
fill 200 64 -436 257 64 -436 minecraft:air
fill 259 64 -436 263 64 -436 minecraft:air
fill 200 64 -437 206 64 -437 minecraft:air
fill 208 64 -437 211 64 -437 minecraft:air
fill 213 64 -437 263 64 -437 minecraft:air
fill 200 64 -438 206 64 -438 minecraft:air
setblock 207 64 -438 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 208 64 -438 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
fill 209 64 -438 263 64 -438 minecraft:air
fill 200 64 -439 204 64 -439 minecraft:air
setblock 205 64 -439 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
fill 206 64 -439 207 64 -439 minecraft:air
setblock 208 64 -439 regions_unexplored:grass_sprouts
setblock 209 64 -439 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 210 64 -439 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=2]
fill 211 64 -439 263 64 -439 minecraft:air
fill 200 64 -440 206 64 -440 minecraft:air
setblock 207 64 -440 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 208 64 -440 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
setblock 209 64 -440 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
setblock 210 64 -440 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 212 64 -440 minecraft:air
setblock 213 64 -440 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
fill 214 64 -440 263 64 -440 minecraft:air
fill 200 64 -441 206 64 -441 minecraft:air
fill 209 64 -441 211 64 -441 minecraft:air
setblock 212 64 -441 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
setblock 213 64 -441 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 214 64 -441 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=2]
setblock 215 64 -441 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
fill 216 64 -441 263 64 -441 minecraft:air
fill 200 64 -442 204 64 -442 minecraft:air
setblock 205 64 -442 regions_unexplored:grass_sprouts
setblock 210 64 -442 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 211 64 -442 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 212 64 -442 minecraft:air
setblock 213 64 -442 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
setblock 214 64 -442 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
setblock 215 64 -442 minecraft:air
setblock 216 64 -442 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 217 64 -442 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 218 64 -442 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
setblock 219 64 -442 minecraft:air
setblock 220 64 -442 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
setblock 221 64 -442 regions_unexplored:grass_sprouts
setblock 222 64 -442 minecraft:air
fill 224 64 -442 227 64 -442 minecraft:air
fill 229 64 -442 263 64 -442 minecraft:air
fill 212 64 -443 214 64 -443 minecraft:air
setblock 216 64 -443 minecraft:air
setblock 217 64 -443 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 218 64 -443 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 219 64 -443 minecraft:air
setblock 220 64 -443 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
setblock 221 64 -443 minecraft:air
setblock 222 64 -443 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
setblock 223 64 -443 minecraft:air
setblock 224 64 -443 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 225 64 -443 minecraft:air
setblock 226 64 -443 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
setblock 227 64 -443 minecraft:air
setblock 228 64 -443 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=3]
fill 229 64 -443 230 64 -443 minecraft:air
fill 232 64 -443 263 64 -443 minecraft:air
setblock 213 64 -444 minecraft:short_grass
setblock 214 64 -444 minecraft:air
fill 215 64 -444 216 64 -444 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=1]
setblock 218 64 -444 minecraft:air
setblock 219 64 -444 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 220 64 -444 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
setblock 221 64 -444 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 222 64 -444 223 64 -444 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 224 64 -444 minecraft:air
setblock 225 64 -444 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 226 64 -444 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 227 64 -444 minecraft:air
setblock 228 64 -444 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=4]
fill 229 64 -444 263 64 -444 minecraft:air
fill 214 64 -445 215 64 -445 minecraft:air
setblock 216 64 -445 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 217 64 -445 minecraft:air
setblock 218 64 -445 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=3]
fill 219 64 -445 221 64 -445 minecraft:air
setblock 222 64 -445 regions_unexplored:grass_sprouts
setblock 223 64 -445 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=3]
setblock 224 64 -445 minecraft:air
setblock 225 64 -445 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 226 64 -445 minecraft:air
setblock 227 64 -445 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
fill 228 64 -445 230 64 -445 minecraft:air
setblock 231 64 -445 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
setblock 232 64 -445 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
setblock 233 64 -445 minecraft:short_grass
fill 234 64 -445 263 64 -445 minecraft:air
fill 215 64 -446 217 64 -446 minecraft:air
setblock 218 64 -446 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 219 64 -446 222 64 -446 minecraft:air
setblock 223 64 -446 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
setblock 224 64 -446 minecraft:air
setblock 225 64 -446 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
setblock 226 64 -446 minecraft:air
setblock 227 64 -446 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
setblock 228 64 -446 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=1]
fill 229 64 -446 230 64 -446 minecraft:air
setblock 231 64 -446 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
setblock 232 64 -446 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=4]
setblock 233 64 -446 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
fill 235 64 -446 263 64 -446 minecraft:air
fill 255 63 -385 257 63 -385 minecraft:air
fill 256 63 -386 258 63 -386 minecraft:air
setblock 204 63 -396 minecraft:air
setblock 201 63 -397 minecraft:air
fill 203 63 -397 206 63 -397 minecraft:air
fill 201 63 -398 209 63 -398 minecraft:air
fill 201 63 -399 210 63 -399 minecraft:air
fill 200 63 -400 210 63 -400 minecraft:air
fill 200 63 -401 210 63 -401 minecraft:air
fill 200 63 -402 201 63 -402 minecraft:air
setblock 202 63 -402 minecraft:short_grass
fill 203 63 -402 210 63 -402 minecraft:air
fill 200 63 -403 203 63 -403 minecraft:air
fill 205 63 -403 210 63 -403 minecraft:air
fill 200 63 -404 210 63 -404 minecraft:air
fill 200 63 -405 201 63 -405 minecraft:air
fill 203 63 -405 210 63 -405 minecraft:air
fill 200 63 -406 210 63 -406 minecraft:air
fill 200 63 -407 201 63 -407 minecraft:air
fill 203 63 -407 210 63 -407 minecraft:air
fill 200 63 -408 212 63 -408 minecraft:air
fill 200 63 -409 212 63 -409 minecraft:air
fill 200 63 -410 213 63 -410 minecraft:air
fill 200 63 -411 208 63 -411 minecraft:air
setblock 209 63 -411 minecraft:sugar_cane[age=0]
fill 210 63 -411 211 63 -411 minecraft:air
setblock 213 63 -411 minecraft:air
fill 200 63 -412 209 63 -412 minecraft:air
setblock 210 63 -412 minecraft:sugar_cane[age=0]
fill 211 63 -412 214 63 -412 minecraft:air
fill 200 63 -413 210 63 -413 minecraft:air
setblock 211 63 -413 minecraft:sugar_cane[age=0]
fill 212 63 -413 217 63 -413 minecraft:air
setblock 218 63 -413 regions_unexplored:grass_sprouts
setblock 219 63 -413 minecraft:air
setblock 221 63 -413 minecraft:air
fill 200 63 -414 211 63 -414 minecraft:air
fill 212 63 -414 214 63 -414 minecraft:sugar_cane[age=0]
fill 215 63 -414 216 63 -414 minecraft:air
fill 218 63 -414 222 63 -414 minecraft:air
fill 200 63 -415 215 63 -415 minecraft:air
fill 217 63 -415 218 63 -415 minecraft:air
fill 220 63 -415 222 63 -415 minecraft:air
setblock 224 63 -415 minecraft:air
fill 200 63 -416 211 63 -416 minecraft:air
fill 214 63 -416 215 63 -416 minecraft:air
fill 217 63 -416 219 63 -416 minecraft:air
fill 223 63 -416 224 63 -416 minecraft:air
fill 226 63 -416 227 63 -416 minecraft:air
fill 200 63 -417 214 63 -417 minecraft:air
fill 217 63 -417 218 63 -417 minecraft:air
fill 220 63 -417 225 63 -417 minecraft:air
fill 228 63 -417 233 63 -417 minecraft:air
fill 200 63 -418 221 63 -418 minecraft:air
fill 223 63 -418 234 63 -418 minecraft:air
fill 200 63 -419 235 63 -419 minecraft:air
fill 200 63 -420 236 63 -420 minecraft:air
fill 200 63 -421 235 63 -421 minecraft:air
setblock 237 63 -421 minecraft:air
setblock 238 63 -421 regions_unexplored:grass_sprouts
fill 200 63 -422 235 63 -422 minecraft:air
fill 236 63 -422 237 63 -422 minecraft:short_grass
setblock 238 63 -422 regions_unexplored:grass_sprouts
setblock 239 63 -422 minecraft:air
fill 200 63 -423 240 63 -423 minecraft:air
fill 200 63 -424 236 63 -424 minecraft:air
setblock 237 63 -424 regions_unexplored:grass_sprouts
fill 238 63 -424 239 63 -424 minecraft:air
setblock 240 63 -424 minecraft:short_grass
fill 200 63 -425 238 63 -425 minecraft:air
setblock 239 63 -425 minecraft:short_grass
fill 240 63 -425 242 63 -425 minecraft:air
fill 200 63 -426 245 63 -426 minecraft:air
fill 246 63 -426 247 63 -426 minecraft:short_grass
fill 248 63 -426 250 63 -426 minecraft:air
fill 200 63 -427 244 63 -427 minecraft:air
setblock 245 63 -427 minecraft:short_grass
fill 246 63 -427 252 63 -427 minecraft:air
fill 200 63 -428 241 63 -428 minecraft:air
fill 243 63 -428 253 63 -428 minecraft:air
fill 200 63 -429 238 63 -429 minecraft:air
fill 240 63 -429 243 63 -429 minecraft:air
fill 246 63 -429 254 63 -429 minecraft:air
fill 200 63 -430 235 63 -430 minecraft:air
fill 237 63 -430 238 63 -430 minecraft:air
setblock 239 63 -430 regions_unexplored:grass_sprouts
fill 240 63 -430 241 63 -430 minecraft:air
fill 243 63 -430 245 63 -430 minecraft:air
fill 248 63 -430 254 63 -430 minecraft:air
fill 200 63 -431 237 63 -431 minecraft:air
fill 239 63 -431 245 63 -431 minecraft:air
fill 248 63 -431 250 63 -431 minecraft:air
fill 253 63 -431 255 63 -431 minecraft:air
fill 200 63 -432 237 63 -432 minecraft:air
setblock 239 63 -432 minecraft:air
setblock 241 63 -432 minecraft:short_grass
fill 242 63 -432 244 63 -432 minecraft:air
fill 246 63 -432 257 63 -432 minecraft:air
fill 200 63 -433 238 63 -433 minecraft:air
fill 240 63 -433 255 63 -433 minecraft:air
fill 257 63 -433 258 63 -433 minecraft:air
fill 200 63 -434 242 63 -434 minecraft:air
fill 244 63 -434 253 63 -434 minecraft:air
fill 255 63 -434 259 63 -434 minecraft:air
fill 200 63 -435 258 63 -435 minecraft:air
setblock 259 63 -435 minecraft:short_grass
setblock 260 63 -435 minecraft:air
fill 200 63 -436 207 63 -436 minecraft:air
setblock 208 63 -436 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=1]
fill 209 63 -436 210 63 -436 minecraft:air
fill 212 63 -436 257 63 -436 minecraft:air
setblock 259 63 -436 minecraft:air
setblock 260 63 -436 regions_unexplored:grass_sprouts
setblock 261 63 -436 minecraft:air
fill 200 63 -437 206 63 -437 minecraft:air
setblock 208 63 -437 minecraft:air
setblock 209 63 -437 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=4]
setblock 210 63 -437 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
setblock 211 63 -437 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=2]
fill 213 63 -437 262 63 -437 minecraft:air
fill 200 63 -438 206 63 -438 minecraft:air
fill 210 63 -438 211 63 -438 minecraft:air
setblock 212 63 -438 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=2]
fill 213 63 -438 259 63 -438 minecraft:air
fill 261 63 -438 263 63 -438 minecraft:air
fill 200 63 -439 202 63 -439 minecraft:air
fill 214 63 -439 260 63 -439 minecraft:air
fill 262 63 -439 263 63 -439 minecraft:air
fill 218 63 -440 225 63 -440 minecraft:air
setblock 226 63 -440 regions_unexplored:silver_birch_leaf_litter[facing=east,flower_amount=3]
fill 227 63 -440 263 63 -440 minecraft:air
fill 220 63 -441 226 63 -441 minecraft:air
setblock 227 63 -441 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
fill 228 63 -441 263 63 -441 minecraft:air
fill 226 63 -442 227 63 -442 minecraft:air
setblock 229 63 -442 regions_unexplored:silver_birch_leaf_litter[facing=north,flower_amount=4]
fill 230 63 -442 263 63 -442 minecraft:air
setblock 229 63 -443 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=2]
setblock 230 63 -443 minecraft:air
fill 232 63 -443 263 63 -443 minecraft:air
setblock 233 63 -444 minecraft:air
setblock 234 63 -444 regions_unexplored:silver_birch_leaf_litter[facing=west,flower_amount=2]
fill 235 63 -444 263 63 -444 minecraft:air
setblock 234 63 -445 regions_unexplored:silver_birch_leaf_litter[facing=south,flower_amount=1]
fill 235 63 -445 263 63 -445 minecraft:air
fill 235 63 -446 263 63 -446 minecraft:air
fill 254 62 -385 257 62 -385 minecraft:water[level=0]
fill 255 62 -386 257 62 -386 minecraft:water[level=0]
fill 200 62 -405 201 62 -405 minecraft:water[level=0]
fill 200 62 -406 204 62 -406 minecraft:water[level=0]
fill 200 62 -407 201 62 -407 minecraft:water[level=0]
fill 203 62 -407 204 62 -407 minecraft:water[level=0]
fill 200 62 -408 205 62 -408 minecraft:water[level=0]
fill 200 62 -409 204 62 -409 minecraft:water[level=0]
setblock 205 62 -409 minecraft:seagrass
setblock 206 62 -409 minecraft:water[level=0]
fill 200 62 -410 203 62 -410 minecraft:water[level=0]
setblock 204 62 -410 minecraft:tall_seagrass[half=upper]
fill 205 62 -410 206 62 -410 minecraft:water[level=0]
setblock 207 62 -410 minecraft:seagrass
setblock 208 62 -410 minecraft:water[level=0]
fill 200 62 -411 204 62 -411 minecraft:water[level=0]
fill 205 62 -411 206 62 -411 minecraft:tall_seagrass[half=upper]
setblock 207 62 -411 minecraft:seagrass
setblock 208 62 -411 minecraft:water[level=0]
fill 200 62 -412 207 62 -412 minecraft:water[level=0]
setblock 208 62 -412 minecraft:seagrass
setblock 209 62 -412 minecraft:water[level=0]
fill 200 62 -413 206 62 -413 minecraft:water[level=0]
setblock 207 62 -413 minecraft:tall_seagrass[half=upper]
setblock 208 62 -413 minecraft:water[level=0]
fill 209 62 -413 210 62 -413 minecraft:seagrass
fill 200 62 -414 206 62 -414 minecraft:water[level=0]
setblock 207 62 -414 minecraft:tall_seagrass[half=upper]
fill 208 62 -414 210 62 -414 minecraft:water[level=0]
setblock 211 62 -414 minecraft:seagrass
fill 200 62 -415 208 62 -415 minecraft:water[level=0]
setblock 209 62 -415 minecraft:tall_seagrass[half=upper]
setblock 210 62 -415 minecraft:seagrass
fill 211 62 -415 214 62 -415 minecraft:water[level=0]
fill 200 62 -416 211 62 -416 minecraft:water[level=0]
fill 214 62 -416 215 62 -416 minecraft:water[level=0]
fill 217 62 -416 219 62 -416 minecraft:water[level=0]
fill 200 62 -417 214 62 -417 minecraft:water[level=0]
fill 217 62 -417 218 62 -417 minecraft:water[level=0]
fill 220 62 -417 223 62 -417 minecraft:water[level=0]
fill 200 62 -418 221 62 -418 minecraft:water[level=0]
fill 223 62 -418 230 62 -418 minecraft:water[level=0]
setblock 231 62 -418 minecraft:seagrass
fill 200 62 -419 230 62 -419 minecraft:water[level=0]
setblock 231 62 -419 minecraft:tall_seagrass[half=upper]
fill 232 62 -419 233 62 -419 minecraft:water[level=0]
fill 200 62 -420 234 62 -420 minecraft:water[level=0]
fill 200 62 -421 234 62 -421 minecraft:water[level=0]
fill 200 62 -422 235 62 -422 minecraft:water[level=0]
fill 200 62 -423 235 62 -423 minecraft:water[level=0]
fill 200 62 -424 236 62 -424 minecraft:water[level=0]
fill 200 62 -425 237 62 -425 minecraft:water[level=0]
fill 200 62 -426 238 62 -426 minecraft:water[level=0]
fill 200 62 -427 238 62 -427 minecraft:water[level=0]
fill 200 62 -428 238 62 -428 minecraft:water[level=0]
fill 200 62 -429 238 62 -429 minecraft:water[level=0]
fill 200 62 -430 235 62 -430 minecraft:water[level=0]
setblock 237 62 -430 minecraft:water[level=0]
fill 248 62 -430 249 62 -430 minecraft:water[level=0]
fill 200 62 -431 237 62 -431 minecraft:water[level=0]
setblock 245 62 -431 minecraft:water[level=0]
fill 248 62 -431 250 62 -431 minecraft:water[level=0]
fill 200 62 -432 236 62 -432 minecraft:water[level=0]
setblock 244 62 -432 minecraft:water[level=0]
fill 246 62 -432 252 62 -432 minecraft:water[level=0]
fill 200 62 -433 237 62 -433 minecraft:water[level=0]
fill 243 62 -433 253 62 -433 minecraft:water[level=0]
fill 200 62 -434 239 62 -434 minecraft:water[level=0]
fill 241 62 -434 242 62 -434 minecraft:water[level=0]
fill 244 62 -434 253 62 -434 minecraft:water[level=0]
fill 200 62 -435 255 62 -435 minecraft:water[level=0]
fill 200 62 -436 207 62 -436 minecraft:water[level=0]
setblock 210 62 -436 minecraft:water[level=0]
fill 212 62 -436 214 62 -436 minecraft:water[level=0]
fill 217 62 -436 256 62 -436 minecraft:water[level=0]
fill 200 62 -437 204 62 -437 minecraft:water[level=0]
fill 221 62 -437 258 62 -437 minecraft:water[level=0]
fill 224 62 -438 259 62 -438 minecraft:water[level=0]
setblock 261 62 -438 minecraft:water[level=0]
fill 226 62 -439 260 62 -439 minecraft:water[level=0]
fill 262 62 -439 263 62 -439 minecraft:water[level=0]
fill 229 62 -440 263 62 -440 minecraft:water[level=0]
fill 231 62 -441 263 62 -441 minecraft:water[level=0]
fill 233 62 -442 263 62 -442 minecraft:water[level=0]
fill 234 62 -443 263 62 -443 minecraft:water[level=0]
fill 235 62 -444 263 62 -444 minecraft:water[level=0]
fill 236 62 -445 263 62 -445 minecraft:water[level=0]
fill 238 62 -446 263 62 -446 minecraft:water[level=0]
fill 254 61 -385 256 61 -385 minecraft:water[level=0]
fill 254 61 -386 257 61 -386 minecraft:water[level=0]
fill 200 61 -408 201 61 -408 minecraft:water[level=0]
fill 200 61 -409 203 61 -409 minecraft:water[level=0]
fill 200 61 -410 203 61 -410 minecraft:water[level=0]
setblock 204 61 -410 minecraft:tall_seagrass[half=lower]
fill 200 61 -411 203 61 -411 minecraft:water[level=0]
setblock 204 61 -411 minecraft:seagrass
fill 205 61 -411 206 61 -411 minecraft:tall_seagrass[half=lower]
fill 200 61 -412 203 61 -412 minecraft:water[level=0]
setblock 204 61 -412 minecraft:tall_seagrass[half=upper]
fill 205 61 -412 207 61 -412 minecraft:water[level=0]
fill 200 61 -413 206 61 -413 minecraft:water[level=0]
setblock 207 61 -413 minecraft:tall_seagrass[half=lower]
fill 200 61 -414 205 61 -414 minecraft:water[level=0]
setblock 206 61 -414 minecraft:tall_seagrass[half=upper]
setblock 207 61 -414 minecraft:tall_seagrass[half=lower]
setblock 208 61 -414 minecraft:seagrass
fill 200 61 -415 208 61 -415 minecraft:water[level=0]
setblock 209 61 -415 minecraft:tall_seagrass[half=lower]
fill 200 61 -416 208 61 -416 minecraft:water[level=0]
fill 209 61 -416 210 61 -416 minecraft:seagrass
fill 200 61 -417 206 61 -417 minecraft:water[level=0]
setblock 207 61 -417 minecraft:tall_seagrass[half=upper]
setblock 208 61 -417 minecraft:water[level=0]
setblock 209 61 -417 minecraft:seagrass
fill 210 61 -417 212 61 -417 minecraft:water[level=0]
fill 213 61 -417 214 61 -417 minecraft:seagrass
fill 200 61 -418 207 61 -418 minecraft:water[level=0]
setblock 208 61 -418 minecraft:tall_seagrass[half=upper]
fill 209 61 -418 210 61 -418 minecraft:water[level=0]
fill 211 61 -418 212 61 -418 minecraft:seagrass
fill 213 61 -418 220 61 -418 minecraft:water[level=0]
fill 200 61 -419 209 61 -419 minecraft:water[level=0]
setblock 210 61 -419 minecraft:tall_seagrass[half=upper]
fill 211 61 -419 213 61 -419 minecraft:water[level=0]
setblock 214 61 -419 minecraft:tall_seagrass[half=upper]
fill 215 61 -419 220 61 -419 minecraft:water[level=0]
setblock 221 61 -419 minecraft:seagrass
fill 222 61 -419 227 61 -419 minecraft:water[level=0]
setblock 228 61 -419 minecraft:tall_seagrass[half=upper]
fill 229 61 -419 230 61 -419 minecraft:water[level=0]
setblock 231 61 -419 minecraft:tall_seagrass[half=lower]
fill 200 61 -420 232 61 -420 minecraft:water[level=0]
fill 200 61 -421 233 61 -421 minecraft:water[level=0]
fill 200 61 -422 234 61 -422 minecraft:water[level=0]
fill 200 61 -423 234 61 -423 minecraft:water[level=0]
fill 200 61 -424 235 61 -424 minecraft:water[level=0]
fill 200 61 -425 236 61 -425 minecraft:water[level=0]
fill 200 61 -426 236 61 -426 minecraft:water[level=0]
fill 200 61 -427 236 61 -427 minecraft:water[level=0]
fill 200 61 -428 236 61 -428 minecraft:water[level=0]
fill 200 61 -429 236 61 -429 minecraft:water[level=0]
fill 200 61 -430 235 61 -430 minecraft:water[level=0]
fill 200 61 -431 235 61 -431 minecraft:water[level=0]
fill 200 61 -432 235 61 -432 minecraft:water[level=0]
fill 247 61 -432 249 61 -432 minecraft:water[level=0]
fill 200 61 -433 236 61 -433 minecraft:water[level=0]
fill 245 61 -433 250 61 -433 minecraft:water[level=0]
fill 200 61 -434 215 61 -434 minecraft:water[level=0]
fill 218 61 -434 236 61 -434 minecraft:water[level=0]
fill 244 61 -434 249 61 -434 minecraft:water[level=0]
setblock 250 61 -434 minecraft:tall_seagrass[half=upper]
fill 251 61 -434 252 61 -434 minecraft:water[level=0]
fill 200 61 -435 212 61 -435 minecraft:water[level=0]
fill 223 61 -435 238 61 -435 minecraft:water[level=0]
fill 242 61 -435 253 61 -435 minecraft:water[level=0]
fill 200 61 -436 203 61 -436 minecraft:water[level=0]
fill 224 61 -436 254 61 -436 minecraft:water[level=0]
fill 225 61 -437 255 61 -437 minecraft:water[level=0]
fill 227 61 -438 257 61 -438 minecraft:water[level=0]
fill 229 61 -439 260 61 -439 minecraft:water[level=0]
setblock 212 61 -440 minecraft:water[level=0]
fill 232 61 -440 263 61 -440 minecraft:water[level=0]
fill 211 61 -441 212 61 -441 minecraft:water[level=0]
fill 233 61 -441 263 61 -441 minecraft:water[level=0]
fill 212 61 -442 213 61 -442 minecraft:water[level=0]
fill 234 61 -442 263 61 -442 minecraft:water[level=0]
setblock 212 61 -443 minecraft:water[level=0]
fill 236 61 -443 263 61 -443 minecraft:water[level=0]
fill 237 61 -444 263 61 -444 minecraft:water[level=0]
fill 238 61 -445 263 61 -445 minecraft:water[level=0]
fill 240 61 -446 263 61 -446 minecraft:water[level=0]
fill 253 60 -385 256 60 -385 minecraft:water[level=0]
fill 254 60 -386 256 60 -386 minecraft:water[level=0]
setblock 200 60 -410 minecraft:water[level=0]
fill 200 60 -411 203 60 -411 minecraft:water[level=0]
fill 200 60 -412 203 60 -412 minecraft:water[level=0]
setblock 204 60 -412 minecraft:tall_seagrass[half=lower]
setblock 205 60 -412 minecraft:water[level=0]
fill 200 60 -413 204 60 -413 minecraft:water[level=0]
setblock 205 60 -413 minecraft:seagrass
fill 200 60 -414 204 60 -414 minecraft:water[level=0]
setblock 205 60 -414 minecraft:seagrass
setblock 206 60 -414 minecraft:tall_seagrass[half=lower]
fill 200 60 -415 205 60 -415 minecraft:water[level=0]
setblock 206 60 -415 minecraft:seagrass
fill 200 60 -416 207 60 -416 minecraft:water[level=0]
fill 200 60 -417 204 60 -417 minecraft:water[level=0]
setblock 205 60 -417 minecraft:tall_seagrass[half=upper]
setblock 206 60 -417 minecraft:water[level=0]
setblock 207 60 -417 minecraft:tall_seagrass[half=lower]
setblock 208 60 -417 minecraft:water[level=0]
fill 200 60 -418 205 60 -418 minecraft:water[level=0]
setblock 206 60 -418 minecraft:tall_seagrass[half=upper]
setblock 207 60 -418 minecraft:water[level=0]
setblock 208 60 -418 minecraft:tall_seagrass[half=lower]
setblock 209 60 -418 minecraft:seagrass
setblock 210 60 -418 minecraft:water[level=0]
fill 200 60 -419 206 60 -419 minecraft:water[level=0]
setblock 207 60 -419 minecraft:tall_seagrass[half=upper]
fill 208 60 -419 209 60 -419 minecraft:seagrass
setblock 210 60 -419 minecraft:tall_seagrass[half=lower]
setblock 211 60 -419 minecraft:water[level=0]
fill 212 60 -419 213 60 -419 minecraft:seagrass
setblock 214 60 -419 minecraft:tall_seagrass[half=lower]
fill 215 60 -419 216 60 -419 minecraft:seagrass
setblock 217 60 -419 minecraft:water[level=0]
fill 223 60 -419 225 60 -419 minecraft:water[level=0]
setblock 226 60 -419 minecraft:seagrass
setblock 227 60 -419 minecraft:water[level=0]
setblock 228 60 -419 minecraft:tall_seagrass[half=lower]
fill 200 60 -420 210 60 -420 minecraft:water[level=0]
fill 211 60 -420 212 60 -420 minecraft:tall_seagrass[half=upper]
fill 213 60 -420 232 60 -420 minecraft:water[level=0]
fill 200 60 -421 232 60 -421 minecraft:water[level=0]
fill 200 60 -422 233 60 -422 minecraft:water[level=0]
fill 200 60 -423 233 60 -423 minecraft:water[level=0]
fill 200 60 -424 234 60 -424 minecraft:water[level=0]
fill 200 60 -425 235 60 -425 minecraft:water[level=0]
fill 200 60 -426 235 60 -426 minecraft:water[level=0]
fill 200 60 -427 236 60 -427 minecraft:water[level=0]
fill 200 60 -428 236 60 -428 minecraft:water[level=0]
fill 200 60 -429 235 60 -429 minecraft:water[level=0]
fill 200 60 -430 235 60 -430 minecraft:water[level=0]
fill 200 60 -431 223 60 -431 minecraft:water[level=0]
fill 225 60 -431 235 60 -431 minecraft:water[level=0]
fill 200 60 -432 220 60 -432 minecraft:water[level=0]
fill 225 60 -432 235 60 -432 minecraft:water[level=0]
fill 200 60 -433 215 60 -433 minecraft:water[level=0]
fill 225 60 -433 235 60 -433 minecraft:water[level=0]
fill 247 60 -433 248 60 -433 minecraft:water[level=0]
fill 200 60 -434 212 60 -434 minecraft:water[level=0]
fill 226 60 -434 236 60 -434 minecraft:water[level=0]
fill 245 60 -434 248 60 -434 minecraft:water[level=0]
setblock 249 60 -434 minecraft:seagrass
setblock 250 60 -434 minecraft:tall_seagrass[half=lower]
fill 200 60 -435 204 60 -435 minecraft:water[level=0]
fill 226 60 -435 237 60 -435 minecraft:water[level=0]
fill 243 60 -435 251 60 -435 minecraft:water[level=0]
setblock 212 60 -436 minecraft:water[level=0]
fill 226 60 -436 252 60 -436 minecraft:water[level=0]
fill 211 60 -437 213 60 -437 minecraft:water[level=0]
fill 227 60 -437 253 60 -437 minecraft:water[level=0]
fill 210 60 -438 213 60 -438 minecraft:water[level=0]
fill 229 60 -438 255 60 -438 minecraft:water[level=0]
fill 210 60 -439 213 60 -439 minecraft:water[level=0]
fill 232 60 -439 258 60 -439 minecraft:water[level=0]
fill 210 60 -440 213 60 -440 minecraft:water[level=0]
fill 233 60 -440 260 60 -440 minecraft:water[level=0]
fill 210 60 -441 214 60 -441 minecraft:water[level=0]
fill 234 60 -441 263 60 -441 minecraft:water[level=0]
fill 210 60 -442 214 60 -442 minecraft:water[level=0]
fill 236 60 -442 263 60 -442 minecraft:water[level=0]
fill 211 60 -443 214 60 -443 minecraft:water[level=0]
fill 237 60 -443 263 60 -443 minecraft:water[level=0]
fill 211 60 -444 214 60 -444 minecraft:water[level=0]
fill 238 60 -444 263 60 -444 minecraft:water[level=0]
fill 211 60 -445 214 60 -445 minecraft:water[level=0]
fill 239 60 -445 263 60 -445 minecraft:water[level=0]
setblock 200 60 -446 minecraft:water[level=0]
fill 213 60 -446 215 60 -446 minecraft:water[level=0]
fill 241 60 -446 263 60 -446 minecraft:water[level=0]
fill 253 59 -385 255 59 -385 minecraft:water[level=0]
fill 253 59 -386 256 59 -386 minecraft:water[level=0]
fill 200 59 -412 202 59 -412 minecraft:water[level=0]
fill 200 59 -413 204 59 -413 minecraft:water[level=0]
fill 200 59 -414 204 59 -414 minecraft:water[level=0]
fill 200 59 -415 203 59 -415 minecraft:water[level=0]
setblock 204 59 -415 minecraft:seagrass
fill 200 59 -416 205 59 -416 minecraft:water[level=0]
fill 200 59 -417 204 59 -417 minecraft:water[level=0]
setblock 205 59 -417 minecraft:tall_seagrass[half=lower]
setblock 206 59 -417 minecraft:seagrass
fill 200 59 -418 204 59 -418 minecraft:water[level=0]
setblock 205 59 -418 minecraft:tall_seagrass[half=upper]
setblock 206 59 -418 minecraft:tall_seagrass[half=lower]
setblock 207 59 -418 minecraft:water[level=0]
fill 200 59 -419 206 59 -419 minecraft:water[level=0]
setblock 207 59 -419 minecraft:tall_seagrass[half=lower]
fill 200 59 -420 209 59 -420 minecraft:water[level=0]
setblock 210 59 -420 minecraft:seagrass
fill 211 59 -420 212 59 -420 minecraft:tall_seagrass[half=lower]
fill 213 59 -420 216 59 -420 minecraft:water[level=0]
setblock 217 59 -420 minecraft:seagrass
fill 222 59 -420 230 59 -420 minecraft:water[level=0]
fill 200 59 -421 208 59 -421 minecraft:water[level=0]
setblock 209 59 -421 minecraft:tall_seagrass[half=upper]
fill 210 59 -421 211 59 -421 minecraft:water[level=0]
setblock 212 59 -421 minecraft:tall_seagrass[half=upper]
fill 213 59 -421 215 59 -421 minecraft:water[level=0]
setblock 216 59 -421 minecraft:tall_seagrass[half=upper]
fill 217 59 -421 231 59 -421 minecraft:water[level=0]
fill 200 59 -422 232 59 -422 minecraft:water[level=0]
fill 200 59 -423 233 59 -423 minecraft:water[level=0]
fill 200 59 -424 233 59 -424 minecraft:water[level=0]
fill 200 59 -425 234 59 -425 minecraft:water[level=0]
fill 200 59 -426 235 59 -426 minecraft:water[level=0]
fill 200 59 -427 235 59 -427 minecraft:water[level=0]
fill 200 59 -428 236 59 -428 minecraft:water[level=0]
fill 200 59 -429 235 59 -429 minecraft:water[level=0]
fill 200 59 -430 222 59 -430 minecraft:water[level=0]
fill 225 59 -430 235 59 -430 minecraft:water[level=0]
fill 200 59 -431 219 59 -431 minecraft:water[level=0]
fill 225 59 -431 235 59 -431 minecraft:water[level=0]
fill 200 59 -432 216 59 -432 minecraft:water[level=0]
fill 225 59 -432 235 59 -432 minecraft:water[level=0]
fill 200 59 -433 215 59 -433 minecraft:water[level=0]
fill 225 59 -433 235 59 -433 minecraft:water[level=0]
fill 200 59 -434 205 59 -434 minecraft:water[level=0]
fill 211 59 -434 214 59 -434 minecraft:water[level=0]
fill 225 59 -434 236 59 -434 minecraft:water[level=0]
fill 246 59 -434 248 59 -434 minecraft:water[level=0]
fill 210 59 -435 214 59 -435 minecraft:water[level=0]
fill 225 59 -435 237 59 -435 minecraft:water[level=0]
fill 244 59 -435 250 59 -435 minecraft:water[level=0]
fill 210 59 -436 213 59 -436 minecraft:water[level=0]
fill 225 59 -436 251 59 -436 minecraft:water[level=0]
fill 210 59 -437 213 59 -437 minecraft:water[level=0]
fill 228 59 -437 252 59 -437 minecraft:water[level=0]
fill 210 59 -438 213 59 -438 minecraft:water[level=0]
fill 231 59 -438 253 59 -438 minecraft:water[level=0]
fill 210 59 -439 214 59 -439 minecraft:water[level=0]
fill 233 59 -439 256 59 -439 minecraft:water[level=0]
fill 210 59 -440 214 59 -440 minecraft:water[level=0]
fill 234 59 -440 258 59 -440 minecraft:water[level=0]
fill 210 59 -441 214 59 -441 minecraft:water[level=0]
fill 235 59 -441 262 59 -441 minecraft:water[level=0]
fill 210 59 -442 214 59 -442 minecraft:water[level=0]
fill 236 59 -442 263 59 -442 minecraft:water[level=0]
fill 210 59 -443 214 59 -443 minecraft:water[level=0]
fill 238 59 -443 263 59 -443 minecraft:water[level=0]
fill 211 59 -444 215 59 -444 minecraft:water[level=0]
fill 239 59 -444 263 59 -444 minecraft:water[level=0]
fill 211 59 -445 215 59 -445 minecraft:water[level=0]
fill 240 59 -445 263 59 -445 minecraft:water[level=0]
fill 212 59 -446 216 59 -446 minecraft:water[level=0]
fill 243 59 -446 263 59 -446 minecraft:water[level=0]
fill 252 58 -385 255 58 -385 minecraft:water[level=0]
fill 253 58 -386 255 58 -386 minecraft:water[level=0]
setblock 200 58 -406 minecraft:water[level=0]
fill 200 58 -407 202 58 -407 minecraft:water[level=0]
fill 200 58 -408 202 58 -408 minecraft:water[level=0]
fill 200 58 -409 203 58 -409 minecraft:water[level=0]
fill 200 58 -410 203 58 -410 minecraft:water[level=0]
fill 201 58 -411 204 58 -411 minecraft:water[level=0]
fill 201 58 -412 204 58 -412 minecraft:water[level=0]
fill 201 58 -413 203 58 -413 minecraft:water[level=0]
fill 200 58 -414 203 58 -414 minecraft:water[level=0]
fill 200 58 -415 203 58 -415 minecraft:water[level=0]
fill 200 58 -416 203 58 -416 minecraft:water[level=0]
fill 200 58 -417 204 58 -417 minecraft:water[level=0]
fill 200 58 -418 204 58 -418 minecraft:water[level=0]
setblock 205 58 -418 minecraft:tall_seagrass[half=lower]
fill 200 58 -419 203 58 -419 minecraft:water[level=0]
setblock 204 58 -419 minecraft:tall_seagrass[half=upper]
fill 205 58 -419 206 58 -419 minecraft:water[level=0]
fill 200 58 -420 207 58 -420 minecraft:water[level=0]
fill 224 58 -420 226 58 -420 minecraft:water[level=0]
setblock 227 58 -420 minecraft:seagrass
setblock 228 58 -420 minecraft:water[level=0]
fill 200 58 -421 206 58 -421 minecraft:water[level=0]
setblock 207 58 -421 minecraft:seagrass
setblock 208 58 -421 minecraft:water[level=0]
setblock 209 58 -421 minecraft:tall_seagrass[half=lower]
setblock 210 58 -421 minecraft:water[level=0]
setblock 211 58 -421 minecraft:seagrass
setblock 212 58 -421 minecraft:tall_seagrass[half=lower]
setblock 213 58 -421 minecraft:water[level=0]
setblock 214 58 -421 minecraft:seagrass
setblock 215 58 -421 minecraft:water[level=0]
setblock 216 58 -421 minecraft:tall_seagrass[half=lower]
fill 217 58 -421 219 58 -421 minecraft:water[level=0]
fill 221 58 -421 228 58 -421 minecraft:water[level=0]
setblock 229 58 -421 minecraft:seagrass
setblock 230 58 -421 minecraft:water[level=0]
fill 200 58 -422 210 58 -422 minecraft:water[level=0]
setblock 211 58 -422 minecraft:tall_seagrass[half=upper]
fill 212 58 -422 215 58 -422 minecraft:water[level=0]
fill 216 58 -422 217 58 -422 minecraft:tall_seagrass[half=upper]
fill 218 58 -422 231 58 -422 minecraft:water[level=0]
fill 200 58 -423 232 58 -423 minecraft:water[level=0]
fill 200 58 -424 233 58 -424 minecraft:water[level=0]
fill 200 58 -425 233 58 -425 minecraft:water[level=0]
fill 200 58 -426 234 58 -426 minecraft:water[level=0]
fill 200 58 -427 235 58 -427 minecraft:water[level=0]
fill 200 58 -428 235 58 -428 minecraft:water[level=0]
fill 200 58 -429 222 58 -429 minecraft:water[level=0]
fill 225 58 -429 235 58 -429 minecraft:water[level=0]
fill 200 58 -430 219 58 -430 minecraft:water[level=0]
fill 225 58 -430 235 58 -430 minecraft:water[level=0]
fill 200 58 -431 216 58 -431 minecraft:water[level=0]
fill 226 58 -431 235 58 -431 minecraft:water[level=0]
fill 200 58 -432 216 58 -432 minecraft:water[level=0]
fill 226 58 -432 235 58 -432 minecraft:water[level=0]
fill 200 58 -433 216 58 -433 minecraft:water[level=0]
fill 225 58 -433 236 58 -433 minecraft:water[level=0]
fill 211 58 -434 215 58 -434 minecraft:water[level=0]
fill 225 58 -434 236 58 -434 minecraft:water[level=0]
fill 210 58 -435 214 58 -435 minecraft:water[level=0]
fill 225 58 -435 226 58 -435 minecraft:water[level=0]
fill 228 58 -435 238 58 -435 minecraft:water[level=0]
setblock 244 58 -435 minecraft:water[level=0]
setblock 245 58 -435 minecraft:seagrass
fill 246 58 -435 248 58 -435 minecraft:water[level=0]
setblock 249 58 -435 minecraft:seagrass
fill 210 58 -436 214 58 -436 minecraft:water[level=0]
fill 225 58 -436 226 58 -436 minecraft:water[level=0]
fill 228 58 -436 250 58 -436 minecraft:water[level=0]
fill 210 58 -437 213 58 -437 minecraft:water[level=0]
fill 230 58 -437 251 58 -437 minecraft:water[level=0]
fill 210 58 -438 213 58 -438 minecraft:water[level=0]
fill 233 58 -438 251 58 -438 minecraft:water[level=0]
fill 210 58 -439 213 58 -439 minecraft:water[level=0]
fill 234 58 -439 253 58 -439 minecraft:water[level=0]
fill 211 58 -440 213 58 -440 minecraft:water[level=0]
fill 235 58 -440 257 58 -440 minecraft:water[level=0]
fill 211 58 -441 213 58 -441 minecraft:water[level=0]
fill 236 58 -441 259 58 -441 minecraft:water[level=0]
fill 211 58 -442 213 58 -442 minecraft:water[level=0]
fill 237 58 -442 263 58 -442 minecraft:water[level=0]
fill 211 58 -443 214 58 -443 minecraft:water[level=0]
fill 239 58 -443 263 58 -443 minecraft:water[level=0]
fill 211 58 -444 214 58 -444 minecraft:water[level=0]
fill 240 58 -444 263 58 -444 minecraft:water[level=0]
fill 212 58 -445 215 58 -445 minecraft:water[level=0]
fill 242 58 -445 263 58 -445 minecraft:water[level=0]
fill 212 58 -446 216 58 -446 minecraft:water[level=0]
fill 244 58 -446 263 58 -446 minecraft:water[level=0]
fill 251 57 -385 254 57 -385 minecraft:water[level=0]
fill 252 57 -386 255 57 -386 minecraft:water[level=0]
fill 200 57 -406 201 57 -406 minecraft:water[level=0]
fill 200 57 -407 202 57 -407 minecraft:water[level=0]
fill 200 57 -408 203 57 -408 minecraft:water[level=0]
fill 200 57 -409 203 57 -409 minecraft:water[level=0]
fill 200 57 -410 204 57 -410 minecraft:water[level=0]
fill 200 57 -411 204 57 -411 minecraft:water[level=0]
fill 201 57 -412 204 57 -412 minecraft:water[level=0]
fill 201 57 -413 204 57 -413 minecraft:water[level=0]
fill 201 57 -414 204 57 -414 minecraft:water[level=0]
fill 200 57 -415 203 57 -415 minecraft:water[level=0]
fill 200 57 -416 203 57 -416 minecraft:water[level=0]
fill 200 57 -417 203 57 -417 minecraft:water[level=0]
fill 200 57 -418 204 57 -418 minecraft:water[level=0]
fill 200 57 -419 203 57 -419 minecraft:water[level=0]
setblock 204 57 -419 minecraft:tall_seagrass[half=lower]
setblock 205 57 -419 minecraft:water[level=0]
fill 200 57 -420 205 57 -420 minecraft:water[level=0]
fill 200 57 -421 204 57 -421 minecraft:water[level=0]
setblock 205 57 -421 minecraft:tall_seagrass[half=upper]
setblock 206 57 -421 minecraft:seagrass
fill 224 57 -421 228 57 -421 minecraft:water[level=0]
fill 200 57 -422 206 57 -422 minecraft:water[level=0]
setblock 207 57 -422 minecraft:seagrass
fill 208 57 -422 210 57 -422 minecraft:water[level=0]
setblock 211 57 -422 minecraft:tall_seagrass[half=lower]
fill 212 57 -422 214 57 -422 minecraft:water[level=0]
setblock 215 57 -422 minecraft:seagrass
fill 216 57 -422 217 57 -422 minecraft:tall_seagrass[half=lower]
setblock 218 57 -422 minecraft:water[level=0]
setblock 219 57 -422 minecraft:seagrass
fill 220 57 -422 230 57 -422 minecraft:water[level=0]
fill 200 57 -423 208 57 -423 minecraft:water[level=0]
setblock 209 57 -423 minecraft:tall_seagrass[half=upper]
fill 210 57 -423 214 57 -423 minecraft:water[level=0]
setblock 215 57 -423 minecraft:tall_seagrass[half=upper]
fill 216 57 -423 232 57 -423 minecraft:water[level=0]
fill 200 57 -424 232 57 -424 minecraft:water[level=0]
fill 200 57 -425 210 57 -425 minecraft:water[level=0]
setblock 211 57 -425 minecraft:tall_seagrass[half=upper]
fill 212 57 -425 220 57 -425 minecraft:water[level=0]
setblock 221 57 -425 minecraft:tall_seagrass[half=upper]
fill 222 57 -425 233 57 -425 minecraft:water[level=0]
fill 200 57 -426 217 57 -426 minecraft:water[level=0]
setblock 218 57 -426 minecraft:tall_seagrass[half=upper]
fill 219 57 -426 233 57 -426 minecraft:water[level=0]
fill 200 57 -427 234 57 -427 minecraft:water[level=0]
fill 200 57 -428 235 57 -428 minecraft:water[level=0]
fill 200 57 -429 220 57 -429 minecraft:water[level=0]
fill 224 57 -429 235 57 -429 minecraft:water[level=0]
fill 200 57 -430 215 57 -430 minecraft:water[level=0]
fill 225 57 -430 235 57 -430 minecraft:water[level=0]
fill 200 57 -431 216 57 -431 minecraft:water[level=0]
fill 226 57 -431 235 57 -431 minecraft:water[level=0]
fill 200 57 -432 215 57 -432 minecraft:water[level=0]
fill 227 57 -432 236 57 -432 minecraft:water[level=0]
fill 200 57 -433 204 57 -433 minecraft:water[level=0]
fill 212 57 -433 215 57 -433 minecraft:water[level=0]
fill 227 57 -433 236 57 -433 minecraft:water[level=0]
fill 211 57 -434 214 57 -434 minecraft:water[level=0]
fill 227 57 -434 237 57 -434 minecraft:water[level=0]
fill 211 57 -435 213 57 -435 minecraft:water[level=0]
setblock 224 57 -435 minecraft:water[level=0]
fill 227 57 -435 239 57 -435 minecraft:water[level=0]
fill 246 57 -435 248 57 -435 minecraft:water[level=0]
fill 211 57 -436 213 57 -436 minecraft:water[level=0]
setblock 224 57 -436 minecraft:water[level=0]
fill 228 57 -436 249 57 -436 minecraft:water[level=0]
fill 255 57 -436 257 57 -436 minecraft:water[level=0]
fill 211 57 -437 213 57 -437 minecraft:water[level=0]
fill 225 57 -437 226 57 -437 minecraft:water[level=0]
fill 231 57 -437 246 57 -437 minecraft:water[level=0]
setblock 247 57 -437 minecraft:tall_seagrass[half=upper]
fill 248 57 -437 249 57 -437 minecraft:water[level=0]
setblock 250 57 -437 minecraft:seagrass
fill 254 57 -437 257 57 -437 minecraft:water[level=0]
fill 233 57 -438 247 57 -438 minecraft:water[level=0]
setblock 248 57 -438 minecraft:tall_seagrass[half=upper]
fill 249 57 -438 250 57 -438 minecraft:water[level=0]
fill 255 57 -438 256 57 -438 minecraft:water[level=0]
fill 235 57 -439 251 57 -439 minecraft:water[level=0]
fill 235 57 -440 256 57 -440 minecraft:water[level=0]
fill 236 57 -441 258 57 -441 minecraft:water[level=0]
fill 238 57 -442 261 57 -442 minecraft:water[level=0]
fill 239 57 -443 263 57 -443 minecraft:water[level=0]
setblock 240 57 -444 minecraft:water[level=0]
setblock 241 57 -444 minecraft:tall_seagrass[half=upper]
fill 242 57 -444 263 57 -444 minecraft:water[level=0]
setblock 243 57 -445 minecraft:seagrass
setblock 244 57 -445 minecraft:tall_seagrass[half=upper]
fill 245 57 -445 263 57 -445 minecraft:water[level=0]
fill 214 57 -446 215 57 -446 minecraft:water[level=0]
fill 246 57 -446 247 57 -446 minecraft:water[level=0]
setblock 248 57 -446 minecraft:seagrass
fill 249 57 -446 252 57 -446 minecraft:water[level=0]
setblock 253 57 -446 minecraft:tall_seagrass[half=upper]
fill 254 57 -446 263 57 -446 minecraft:water[level=0]
fill 250 56 -385 253 56 -385 minecraft:water[level=0]
fill 251 56 -386 254 56 -386 minecraft:water[level=0]
setblock 200 56 -406 minecraft:water[level=0]
fill 200 56 -407 202 56 -407 minecraft:water[level=0]
fill 200 56 -408 202 56 -408 minecraft:water[level=0]
fill 200 56 -409 203 56 -409 minecraft:water[level=0]
fill 200 56 -410 203 56 -410 minecraft:water[level=0]
fill 201 56 -411 204 56 -411 minecraft:water[level=0]
fill 201 56 -412 204 56 -412 minecraft:water[level=0]
setblock 201 56 -413 minecraft:water[level=0]
setblock 202 56 -413 minecraft:seagrass
fill 203 56 -413 204 56 -413 minecraft:water[level=0]
fill 200 56 -414 203 56 -414 minecraft:water[level=0]
fill 200 56 -415 203 56 -415 minecraft:water[level=0]
fill 200 56 -416 203 56 -416 minecraft:water[level=0]
fill 200 56 -417 201 56 -417 minecraft:water[level=0]
setblock 202 56 -417 minecraft:tall_seagrass[half=upper]
fill 200 56 -418 202 56 -418 minecraft:water[level=0]
fill 200 56 -419 201 56 -419 minecraft:water[level=0]
setblock 202 56 -419 minecraft:tall_seagrass[half=upper]
setblock 203 56 -419 minecraft:water[level=0]
fill 200 56 -420 203 56 -420 minecraft:water[level=0]
setblock 204 56 -420 minecraft:seagrass
fill 200 56 -421 204 56 -421 minecraft:water[level=0]
setblock 205 56 -421 minecraft:tall_seagrass[half=lower]
setblock 200 56 -422 minecraft:tall_seagrass[half=upper]
fill 201 56 -422 204 56 -422 minecraft:water[level=0]
setblock 205 56 -422 minecraft:seagrass
setblock 206 56 -422 minecraft:water[level=0]
fill 222 56 -422 229 56 -422 minecraft:water[level=0]
fill 200 56 -423 207 56 -423 minecraft:water[level=0]
setblock 208 56 -423 minecraft:seagrass
setblock 209 56 -423 minecraft:tall_seagrass[half=lower]
fill 210 56 -423 211 56 -423 minecraft:water[level=0]
fill 212 56 -423 213 56 -423 minecraft:seagrass
setblock 214 56 -423 minecraft:water[level=0]
setblock 215 56 -423 minecraft:tall_seagrass[half=lower]
fill 216 56 -423 230 56 -423 minecraft:water[level=0]
fill 200 56 -424 206 56 -424 minecraft:water[level=0]
setblock 207 56 -424 minecraft:seagrass
fill 208 56 -424 210 56 -424 minecraft:water[level=0]
setblock 211 56 -424 minecraft:seagrass
fill 212 56 -424 213 56 -424 minecraft:water[level=0]
setblock 214 56 -424 minecraft:seagrass
fill 215 56 -424 216 56 -424 minecraft:water[level=0]
setblock 217 56 -424 minecraft:tall_seagrass[half=upper]
fill 218 56 -424 232 56 -424 minecraft:water[level=0]
fill 200 56 -425 210 56 -425 minecraft:water[level=0]
setblock 211 56 -425 minecraft:tall_seagrass[half=lower]
fill 212 56 -425 220 56 -425 minecraft:water[level=0]
setblock 221 56 -425 minecraft:tall_seagrass[half=lower]
fill 222 56 -425 232 56 -425 minecraft:water[level=0]
fill 200 56 -426 214 56 -426 minecraft:water[level=0]
setblock 215 56 -426 minecraft:tall_seagrass[half=upper]
fill 216 56 -426 217 56 -426 minecraft:water[level=0]
setblock 218 56 -426 minecraft:tall_seagrass[half=lower]
fill 219 56 -426 233 56 -426 minecraft:water[level=0]
fill 200 56 -427 213 56 -427 minecraft:water[level=0]
setblock 214 56 -427 minecraft:tall_seagrass[half=upper]
fill 215 56 -427 222 56 -427 minecraft:water[level=0]
fill 225 56 -427 234 56 -427 minecraft:water[level=0]
fill 200 56 -428 212 56 -428 minecraft:water[level=0]
setblock 213 56 -428 minecraft:tall_seagrass[half=upper]
fill 214 56 -428 221 56 -428 minecraft:water[level=0]
fill 224 56 -428 235 56 -428 minecraft:water[level=0]
fill 200 56 -429 217 56 -429 minecraft:water[level=0]
fill 225 56 -429 235 56 -429 minecraft:water[level=0]
fill 200 56 -430 214 56 -430 minecraft:water[level=0]
fill 225 56 -430 235 56 -430 minecraft:water[level=0]
fill 200 56 -431 213 56 -431 minecraft:water[level=0]
setblock 226 56 -431 minecraft:water[level=0]
fill 229 56 -431 236 56 -431 minecraft:water[level=0]
fill 200 56 -432 212 56 -432 minecraft:water[level=0]
fill 229 56 -432 236 56 -432 minecraft:water[level=0]
fill 229 56 -433 236 56 -433 minecraft:water[level=0]
fill 229 56 -434 237 56 -434 minecraft:water[level=0]
fill 259 56 -434 260 56 -434 minecraft:water[level=0]
fill 229 56 -435 240 56 -435 minecraft:water[level=0]
fill 256 56 -435 260 56 -435 minecraft:water[level=0]
fill 229 56 -436 248 56 -436 minecraft:water[level=0]
fill 254 56 -436 260 56 -436 minecraft:water[level=0]
fill 232 56 -437 243 56 -437 minecraft:water[level=0]
fill 244 56 -437 245 56 -437 minecraft:seagrass
setblock 246 56 -437 minecraft:water[level=0]
setblock 247 56 -437 minecraft:tall_seagrass[half=lower]
setblock 248 56 -437 minecraft:water[level=0]
setblock 249 56 -437 minecraft:seagrass
fill 254 56 -437 259 56 -437 minecraft:water[level=0]
fill 234 56 -438 244 56 -438 minecraft:water[level=0]
setblock 245 56 -438 minecraft:seagrass
fill 246 56 -438 247 56 -438 minecraft:water[level=0]
setblock 248 56 -438 minecraft:tall_seagrass[half=lower]
setblock 249 56 -438 minecraft:seagrass
setblock 250 56 -438 minecraft:water[level=0]
fill 254 56 -438 258 56 -438 minecraft:water[level=0]
fill 235 56 -439 249 56 -439 minecraft:water[level=0]
setblock 250 56 -439 minecraft:seagrass
setblock 251 56 -439 minecraft:water[level=0]
fill 236 56 -440 246 56 -440 minecraft:water[level=0]
fill 247 56 -440 248 56 -440 minecraft:tall_seagrass[half=upper]
fill 249 56 -440 250 56 -440 minecraft:water[level=0]
setblock 251 56 -440 minecraft:seagrass
fill 252 56 -440 253 56 -440 minecraft:water[level=0]
fill 237 56 -441 242 56 -441 minecraft:water[level=0]
setblock 243 56 -441 minecraft:tall_seagrass[half=upper]
fill 244 56 -441 249 56 -441 minecraft:water[level=0]
setblock 250 56 -441 minecraft:seagrass
fill 251 56 -441 256 56 -441 minecraft:water[level=0]
fill 239 56 -442 241 56 -442 minecraft:water[level=0]
setblock 242 56 -442 minecraft:tall_seagrass[half=upper]
fill 243 56 -442 259 56 -442 minecraft:water[level=0]
fill 240 56 -443 250 56 -443 minecraft:water[level=0]
setblock 251 56 -443 minecraft:tall_seagrass[half=upper]
fill 252 56 -443 263 56 -443 minecraft:water[level=0]
setblock 241 56 -444 minecraft:tall_seagrass[half=lower]
fill 242 56 -444 263 56 -444 minecraft:water[level=0]
fill 213 56 -445 214 56 -445 minecraft:water[level=0]
setblock 244 56 -445 minecraft:tall_seagrass[half=lower]
fill 245 56 -445 253 56 -445 minecraft:water[level=0]
setblock 254 56 -445 minecraft:tall_seagrass[half=upper]
fill 255 56 -445 263 56 -445 minecraft:water[level=0]
fill 212 56 -446 216 56 -446 minecraft:water[level=0]
fill 249 56 -446 252 56 -446 minecraft:water[level=0]
setblock 253 56 -446 minecraft:tall_seagrass[half=lower]
fill 254 56 -446 263 56 -446 minecraft:water[level=0]
fill 250 55 -385 253 55 -385 minecraft:water[level=0]
fill 251 55 -386 254 55 -386 minecraft:water[level=0]
fill 200 55 -414 201 55 -414 minecraft:water[level=0]
setblock 200 55 -415 minecraft:water[level=0]
setblock 201 55 -415 minecraft:seagrass
fill 200 55 -416 202 55 -416 minecraft:water[level=0]
setblock 200 55 -417 minecraft:water[level=0]
setblock 201 55 -417 minecraft:seagrass
setblock 202 55 -417 minecraft:tall_seagrass[half=lower]
setblock 200 55 -418 minecraft:water[level=0]
setblock 201 55 -418 minecraft:seagrass
setblock 202 55 -418 minecraft:water[level=0]
fill 200 55 -419 201 55 -419 minecraft:water[level=0]
setblock 202 55 -419 minecraft:tall_seagrass[half=lower]
fill 200 55 -420 202 55 -420 minecraft:water[level=0]
fill 200 55 -421 201 55 -421 minecraft:water[level=0]
setblock 202 55 -421 minecraft:seagrass
setblock 200 55 -422 minecraft:tall_seagrass[half=lower]
setblock 201 55 -422 minecraft:water[level=0]
fill 200 55 -423 201 55 -423 minecraft:water[level=0]
fill 222 55 -423 228 55 -423 minecraft:water[level=0]
setblock 215 55 -424 minecraft:seagrass
setblock 216 55 -424 minecraft:water[level=0]
setblock 217 55 -424 minecraft:tall_seagrass[half=lower]
fill 218 55 -424 229 55 -424 minecraft:water[level=0]
setblock 215 55 -425 minecraft:water[level=0]
setblock 216 55 -425 minecraft:seagrass
fill 217 55 -425 218 55 -425 minecraft:water[level=0]
fill 222 55 -425 228 55 -425 minecraft:water[level=0]
fill 200 55 -426 201 55 -426 minecraft:water[level=0]
fill 212 55 -426 213 55 -426 minecraft:water[level=0]
setblock 214 55 -426 minecraft:seagrass
setblock 215 55 -426 minecraft:tall_seagrass[half=lower]
setblock 216 55 -426 minecraft:water[level=0]
fill 200 55 -427 202 55 -427 minecraft:water[level=0]
fill 211 55 -427 213 55 -427 minecraft:water[level=0]
setblock 214 55 -427 minecraft:tall_seagrass[half=lower]
setblock 215 55 -427 minecraft:water[level=0]
fill 231 55 -427 232 55 -427 minecraft:water[level=0]
fill 200 55 -428 202 55 -428 minecraft:water[level=0]
fill 211 55 -428 212 55 -428 minecraft:water[level=0]
setblock 213 55 -428 minecraft:tall_seagrass[half=lower]
fill 214 55 -428 215 55 -428 minecraft:water[level=0]
fill 230 55 -428 234 55 -428 minecraft:water[level=0]
fill 200 55 -429 201 55 -429 minecraft:water[level=0]
fill 211 55 -429 213 55 -429 minecraft:water[level=0]
fill 231 55 -429 234 55 -429 minecraft:water[level=0]
setblock 262 55 -429 minecraft:water[level=0]
fill 231 55 -430 234 55 -430 minecraft:water[level=0]
fill 261 55 -430 263 55 -430 minecraft:water[level=0]
fill 231 55 -431 233 55 -431 minecraft:water[level=0]
fill 261 55 -431 263 55 -431 minecraft:water[level=0]
fill 232 55 -432 233 55 -432 minecraft:water[level=0]
fill 260 55 -432 263 55 -432 minecraft:water[level=0]
fill 232 55 -433 234 55 -433 minecraft:water[level=0]
fill 259 55 -433 263 55 -433 minecraft:water[level=0]
fill 232 55 -434 236 55 -434 minecraft:water[level=0]
fill 258 55 -434 262 55 -434 minecraft:water[level=0]
fill 232 55 -435 237 55 -435 minecraft:water[level=0]
fill 256 55 -435 261 55 -435 minecraft:water[level=0]
fill 233 55 -436 240 55 -436 minecraft:water[level=0]
fill 255 55 -436 261 55 -436 minecraft:water[level=0]
fill 235 55 -437 242 55 -437 minecraft:water[level=0]
fill 255 55 -437 260 55 -437 minecraft:water[level=0]
fill 236 55 -438 242 55 -438 minecraft:water[level=0]
setblock 243 55 -438 minecraft:seagrass
setblock 244 55 -438 minecraft:water[level=0]
fill 256 55 -438 258 55 -438 minecraft:water[level=0]
fill 236 55 -439 244 55 -439 minecraft:water[level=0]
setblock 245 55 -439 minecraft:seagrass
fill 246 55 -439 247 55 -439 minecraft:water[level=0]
setblock 248 55 -439 minecraft:seagrass
fill 237 55 -440 243 55 -440 minecraft:water[level=0]
fill 244 55 -440 245 55 -440 minecraft:seagrass
setblock 246 55 -440 minecraft:water[level=0]
fill 247 55 -440 248 55 -440 minecraft:tall_seagrass[half=lower]
fill 239 55 -441 242 55 -441 minecraft:water[level=0]
setblock 243 55 -441 minecraft:tall_seagrass[half=lower]
fill 244 55 -441 246 55 -441 minecraft:water[level=0]
setblock 247 55 -441 minecraft:seagrass
fill 248 55 -441 249 55 -441 minecraft:water[level=0]
setblock 241 55 -442 minecraft:water[level=0]
setblock 242 55 -442 minecraft:tall_seagrass[half=lower]
fill 243 55 -442 248 55 -442 minecraft:water[level=0]
setblock 249 55 -442 minecraft:seagrass
fill 250 55 -442 251 55 -442 minecraft:water[level=0]
fill 243 55 -443 244 55 -443 minecraft:seagrass
fill 245 55 -443 250 55 -443 minecraft:water[level=0]
setblock 251 55 -443 minecraft:tall_seagrass[half=lower]
fill 252 55 -443 261 55 -443 minecraft:water[level=0]
setblock 213 55 -444 minecraft:water[level=0]
setblock 244 55 -444 minecraft:water[level=0]
setblock 245 55 -444 minecraft:seagrass
fill 246 55 -444 263 55 -444 minecraft:water[level=0]
fill 212 55 -445 214 55 -445 minecraft:water[level=0]
fill 247 55 -445 253 55 -445 minecraft:water[level=0]
setblock 254 55 -445 minecraft:tall_seagrass[half=lower]
fill 255 55 -445 263 55 -445 minecraft:water[level=0]
fill 213 55 -446 215 55 -446 minecraft:water[level=0]
fill 255 55 -446 263 55 -446 minecraft:water[level=0]
fill 250 54 -385 253 54 -385 minecraft:water[level=0]
fill 250 54 -386 254 54 -386 minecraft:water[level=0]
setblock 200 54 -395 minecraft:water[level=0]
setblock 200 54 -396 minecraft:water[level=0]
setblock 200 54 -397 minecraft:water[level=0]
setblock 200 54 -398 minecraft:water[level=0]
setblock 200 54 -399 minecraft:water[level=0]
fill 262 54 -421 263 54 -421 minecraft:water[level=0]
fill 262 54 -422 263 54 -422 minecraft:water[level=0]
fill 262 54 -423 263 54 -423 minecraft:water[level=0]
fill 224 54 -424 225 54 -424 minecraft:water[level=0]
fill 262 54 -424 263 54 -424 minecraft:water[level=0]
fill 262 54 -425 263 54 -425 minecraft:water[level=0]
fill 261 54 -426 263 54 -426 minecraft:water[level=0]
fill 261 54 -427 263 54 -427 minecraft:water[level=0]
fill 261 54 -428 263 54 -428 minecraft:water[level=0]
fill 261 54 -429 263 54 -429 minecraft:water[level=0]
fill 260 54 -430 263 54 -430 minecraft:water[level=0]
fill 260 54 -431 263 54 -431 minecraft:water[level=0]
fill 260 54 -432 263 54 -432 minecraft:water[level=0]
fill 259 54 -433 263 54 -433 minecraft:water[level=0]
fill 258 54 -434 262 54 -434 minecraft:water[level=0]
fill 258 54 -435 262 54 -435 minecraft:water[level=0]
setblock 236 54 -436 minecraft:water[level=0]
fill 258 54 -436 261 54 -436 minecraft:water[level=0]
fill 258 54 -437 259 54 -437 minecraft:water[level=0]
fill 240 54 -439 241 54 -439 minecraft:water[level=0]
fill 239 54 -440 242 54 -440 minecraft:water[level=0]
fill 211 54 -444 213 54 -444 minecraft:water[level=0]
fill 248 54 -444 260 54 -444 minecraft:water[level=0]
fill 212 54 -445 214 54 -445 minecraft:water[level=0]
setblock 213 54 -446 minecraft:water[level=0]
setblock 263 54 -446 minecraft:water[level=0]
fill 249 53 -385 253 53 -385 minecraft:water[level=0]
fill 250 53 -386 254 53 -386 minecraft:water[level=0]
setblock 200 53 -393 minecraft:water[level=0]
setblock 200 53 -394 minecraft:water[level=0]
setblock 200 53 -395 minecraft:water[level=0]
fill 200 53 -396 201 53 -396 minecraft:water[level=0]
fill 200 53 -397 201 53 -397 minecraft:water[level=0]
fill 200 53 -398 201 53 -398 minecraft:water[level=0]
fill 200 53 -399 201 53 -399 minecraft:water[level=0]
fill 200 53 -400 201 53 -400 minecraft:water[level=0]
fill 200 53 -401 201 53 -401 minecraft:water[level=0]
setblock 200 53 -402 minecraft:water[level=0]
setblock 200 53 -403 minecraft:water[level=0]
fill 262 53 -420 263 53 -420 minecraft:water[level=0]
fill 261 53 -421 263 53 -421 minecraft:water[level=0]
fill 261 53 -422 263 53 -422 minecraft:water[level=0]
fill 261 53 -423 263 53 -423 minecraft:water[level=0]
fill 261 53 -424 263 53 -424 minecraft:water[level=0]
fill 261 53 -425 263 53 -425 minecraft:water[level=0]
fill 260 53 -426 263 53 -426 minecraft:water[level=0]
fill 260 53 -427 263 53 -427 minecraft:water[level=0]
fill 260 53 -428 263 53 -428 minecraft:water[level=0]
fill 260 53 -429 263 53 -429 minecraft:water[level=0]
fill 260 53 -430 263 53 -430 minecraft:water[level=0]
fill 260 53 -431 263 53 -431 minecraft:water[level=0]
fill 260 53 -432 263 53 -432 minecraft:water[level=0]
fill 260 53 -433 262 53 -433 minecraft:water[level=0]
fill 261 53 -434 262 53 -434 minecraft:water[level=0]
fill 210 53 -443 212 53 -443 minecraft:water[level=0]
fill 211 53 -444 213 53 -444 minecraft:water[level=0]
fill 212 53 -445 213 53 -445 minecraft:water[level=0]
setblock 248 52 -384 minecraft:water[level=0]
fill 249 52 -385 253 52 -385 minecraft:water[level=0]
fill 250 52 -386 253 52 -386 minecraft:water[level=0]
setblock 200 52 -393 minecraft:water[level=0]
setblock 200 52 -394 minecraft:water[level=0]
setblock 200 52 -395 minecraft:water[level=0]
setblock 200 52 -396 minecraft:water[level=0]
fill 200 52 -397 201 52 -397 minecraft:water[level=0]
fill 200 52 -398 201 52 -398 minecraft:water[level=0]
fill 200 52 -399 201 52 -399 minecraft:water[level=0]
fill 200 52 -400 201 52 -400 minecraft:water[level=0]
fill 200 52 -401 201 52 -401 minecraft:water[level=0]
fill 200 52 -402 201 52 -402 minecraft:water[level=0]
fill 200 52 -403 201 52 -403 minecraft:water[level=0]
fill 200 52 -404 201 52 -404 minecraft:water[level=0]
fill 200 52 -405 201 52 -405 minecraft:water[level=0]
fill 200 52 -406 201 52 -406 minecraft:water[level=0]
setblock 263 52 -420 minecraft:water[level=0]
fill 261 52 -421 263 52 -421 minecraft:water[level=0]
fill 261 52 -422 263 52 -422 minecraft:water[level=0]
fill 261 52 -423 263 52 -423 minecraft:water[level=0]
fill 260 52 -424 263 52 -424 minecraft:water[level=0]
fill 260 52 -425 263 52 -425 minecraft:water[level=0]
fill 260 52 -426 263 52 -426 minecraft:water[level=0]
fill 260 52 -427 263 52 -427 minecraft:water[level=0]
fill 260 52 -428 263 52 -428 minecraft:water[level=0]
fill 261 52 -429 263 52 -429 minecraft:water[level=0]
fill 261 52 -430 263 52 -430 minecraft:water[level=0]
fill 209 52 -442 211 52 -442 minecraft:water[level=0]
fill 210 52 -443 212 52 -443 minecraft:water[level=0]
fill 211 52 -444 212 52 -444 minecraft:water[level=0]
fill 247 51 -384 248 51 -384 minecraft:water[level=0]
fill 249 51 -385 253 51 -385 minecraft:water[level=0]
fill 249 51 -386 253 51 -386 minecraft:water[level=0]
setblock 200 51 -399 minecraft:water[level=0]
fill 200 51 -400 201 51 -400 minecraft:water[level=0]
fill 200 51 -401 201 51 -401 minecraft:water[level=0]
fill 200 51 -402 201 51 -402 minecraft:water[level=0]
fill 200 51 -403 202 51 -403 minecraft:water[level=0]
fill 200 51 -404 202 51 -404 minecraft:water[level=0]
fill 200 51 -405 202 51 -405 minecraft:water[level=0]
fill 200 51 -406 203 51 -406 minecraft:water[level=0]
fill 200 51 -407 203 51 -407 minecraft:water[level=0]
fill 201 51 -408 203 51 -408 minecraft:water[level=0]
fill 202 51 -409 203 51 -409 minecraft:water[level=0]
fill 260 51 -421 263 51 -421 minecraft:water[level=0]
fill 260 51 -422 262 51 -422 minecraft:water[level=0]
fill 259 51 -423 262 51 -423 minecraft:water[level=0]
fill 209 51 -441 210 51 -441 minecraft:water[level=0]
fill 210 51 -442 211 51 -442 minecraft:water[level=0]
fill 210 51 -443 212 51 -443 minecraft:water[level=0]
fill 247 50 -384 249 50 -384 minecraft:water[level=0]
fill 248 50 -385 253 50 -385 minecraft:water[level=0]
fill 249 50 -386 253 50 -386 minecraft:water[level=0]
setblock 200 50 -402 minecraft:water[level=0]
fill 200 50 -403 201 50 -403 minecraft:water[level=0]
fill 200 50 -404 202 50 -404 minecraft:water[level=0]
fill 200 50 -405 203 50 -405 minecraft:water[level=0]
fill 200 50 -406 203 50 -406 minecraft:water[level=0]
fill 200 50 -407 204 50 -407 minecraft:water[level=0]
fill 200 50 -408 204 50 -408 minecraft:water[level=0]
fill 201 50 -409 204 50 -409 minecraft:water[level=0]
fill 201 50 -410 205 50 -410 minecraft:water[level=0]
fill 202 50 -411 205 50 -411 minecraft:water[level=0]
fill 203 50 -412 206 50 -412 minecraft:water[level=0]
fill 203 50 -413 206 50 -413 minecraft:water[level=0]
fill 204 50 -414 206 50 -414 minecraft:water[level=0]
fill 261 50 -420 262 50 -420 minecraft:water[level=0]
fill 259 50 -421 261 50 -421 minecraft:water[level=0]
fill 258 50 -422 261 50 -422 minecraft:water[level=0]
fill 208 50 -440 210 50 -440 minecraft:water[level=0]
fill 209 50 -441 210 50 -441 minecraft:water[level=0]
fill 210 50 -442 211 50 -442 minecraft:water[level=0]
setblock 210 50 -443 minecraft:water[level=0]
setblock 245 49 -383 minecraft:water[level=0]
fill 246 49 -384 249 49 -384 minecraft:water[level=0]
fill 247 49 -385 252 49 -385 minecraft:water[level=0]
fill 248 49 -386 253 49 -386 minecraft:water[level=0]
fill 200 49 -405 202 49 -405 minecraft:water[level=0]
fill 200 49 -406 203 49 -406 minecraft:water[level=0]
fill 200 49 -407 204 49 -407 minecraft:water[level=0]
fill 200 49 -408 204 49 -408 minecraft:water[level=0]
fill 201 49 -409 205 49 -409 minecraft:water[level=0]
fill 201 49 -410 205 49 -410 minecraft:water[level=0]
fill 202 49 -411 206 49 -411 minecraft:water[level=0]
fill 202 49 -412 206 49 -412 minecraft:water[level=0]
fill 203 49 -413 207 49 -413 minecraft:water[level=0]
fill 203 49 -414 207 49 -414 minecraft:water[level=0]
fill 204 49 -415 207 49 -415 minecraft:water[level=0]
fill 205 49 -416 207 49 -416 minecraft:water[level=0]
setblock 206 49 -417 minecraft:water[level=0]
fill 260 49 -419 261 49 -419 minecraft:water[level=0]
fill 258 49 -420 260 49 -420 minecraft:water[level=0]
fill 257 49 -421 260 49 -421 minecraft:water[level=0]
fill 210 49 -437 211 49 -437 minecraft:water[level=0]
fill 209 49 -438 212 49 -438 minecraft:water[level=0]
fill 210 49 -439 214 49 -439 minecraft:water[level=0]
fill 208 49 -440 218 49 -440 minecraft:water[level=0]
fill 209 49 -441 210 49 -441 minecraft:water[level=0]
fill 212 49 -441 218 49 -441 minecraft:water[level=0]
setblock 210 49 -442 minecraft:water[level=0]
fill 214 49 -442 217 49 -442 minecraft:water[level=0]
fill 244 48 -383 245 48 -383 minecraft:water[level=0]
fill 245 48 -384 248 48 -384 minecraft:water[level=0]
setblock 249 48 -384 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=true,west=false]
fill 246 48 -385 252 48 -385 minecraft:water[level=0]
fill 247 48 -386 253 48 -386 minecraft:water[level=0]
fill 203 48 -409 204 48 -409 minecraft:water[level=0]
fill 202 48 -410 205 48 -410 minecraft:water[level=0]
fill 202 48 -411 205 48 -411 minecraft:water[level=0]
fill 203 48 -412 206 48 -412 minecraft:water[level=0]
fill 203 48 -413 207 48 -413 minecraft:water[level=0]
fill 203 48 -414 207 48 -414 minecraft:water[level=0]
fill 204 48 -415 208 48 -415 minecraft:water[level=0]
fill 204 48 -416 208 48 -416 minecraft:water[level=0]
fill 205 48 -417 208 48 -417 minecraft:water[level=0]
fill 205 48 -418 207 48 -418 minecraft:water[level=0]
setblock 260 48 -418 minecraft:water[level=0]
fill 206 48 -419 207 48 -419 minecraft:water[level=0]
fill 257 48 -419 259 48 -419 minecraft:water[level=0]
fill 257 48 -420 259 48 -420 minecraft:water[level=0]
fill 208 48 -435 209 48 -435 minecraft:water[level=0]
fill 208 48 -436 210 48 -436 minecraft:water[level=0]
fill 208 48 -437 211 48 -437 minecraft:water[level=0]
fill 209 48 -438 212 48 -438 minecraft:water[level=0]
fill 208 48 -439 214 48 -439 minecraft:water[level=0]
fill 208 48 -440 218 48 -440 minecraft:water[level=0]
fill 209 48 -441 210 48 -441 minecraft:water[level=0]
fill 212 48 -441 218 48 -441 minecraft:water[level=0]
fill 214 48 -442 218 48 -442 minecraft:water[level=0]
setblock 237 47 -383 minecraft:water[level=0]
setblock 245 47 -383 minecraft:water[level=0]
setblock 237 47 -384 minecraft:water[level=0]
fill 244 47 -384 248 47 -384 minecraft:water[level=0]
setblock 249 47 -384 minecraft:glow_lichen[down=false,east=false,north=false,south=true,up=false,waterlogged=true,west=false]
fill 250 47 -384 251 47 -384 minecraft:water[level=0]
fill 245 47 -385 253 47 -385 minecraft:water[level=0]
fill 247 47 -386 253 47 -386 minecraft:water[level=0]
fill 205 47 -413 206 47 -413 minecraft:water[level=0]
fill 204 47 -414 207 47 -414 minecraft:water[level=0]
fill 204 47 -415 207 47 -415 minecraft:water[level=0]
fill 204 47 -416 208 47 -416 minecraft:water[level=0]
fill 205 47 -417 208 47 -417 minecraft:water[level=0]
fill 205 47 -418 208 47 -418 minecraft:water[level=0]
fill 257 47 -418 259 47 -418 minecraft:water[level=0]
fill 205 47 -419 208 47 -419 minecraft:water[level=0]
fill 257 47 -419 259 47 -419 minecraft:water[level=0]
fill 205 47 -420 208 47 -420 minecraft:water[level=0]
fill 256 47 -420 258 47 -420 minecraft:water[level=0]
setblock 207 47 -433 minecraft:water[level=0]
fill 207 47 -434 209 47 -434 minecraft:water[level=0]
fill 207 47 -435 210 47 -435 minecraft:water[level=0]
fill 207 47 -436 210 47 -436 minecraft:water[level=0]
fill 208 47 -437 211 47 -437 minecraft:water[level=0]
fill 207 47 -438 211 47 -438 minecraft:water[level=0]
fill 208 47 -439 209 47 -439 minecraft:water[level=0]
fill 208 47 -440 210 47 -440 minecraft:water[level=0]
fill 226 46 -383 228 46 -383 minecraft:water[level=0]
fill 235 46 -383 236 46 -383 minecraft:water[level=0]
fill 239 46 -383 240 46 -383 minecraft:air
fill 228 46 -384 237 46 -384 minecraft:water[level=0]
fill 246 46 -384 253 46 -384 minecraft:water[level=0]
fill 231 46 -385 237 46 -385 minecraft:water[level=0]
fill 245 46 -385 253 46 -385 minecraft:water[level=0]
fill 233 46 -386 235 46 -386 minecraft:water[level=0]
fill 246 46 -386 252 46 -386 minecraft:water[level=0]
setblock 206 46 -415 minecraft:water[level=0]
fill 205 46 -416 207 46 -416 minecraft:water[level=0]
fill 205 46 -417 208 46 -417 minecraft:water[level=0]
fill 205 46 -418 208 46 -418 minecraft:water[level=0]
fill 256 46 -418 257 46 -418 minecraft:water[level=0]
fill 205 46 -419 208 46 -419 minecraft:water[level=0]
fill 256 46 -419 258 46 -419 minecraft:water[level=0]
fill 205 46 -420 208 46 -420 minecraft:water[level=0]
fill 255 46 -420 257 46 -420 minecraft:water[level=0]
fill 205 46 -421 208 46 -421 minecraft:water[level=0]
fill 205 46 -422 208 46 -422 minecraft:water[level=0]
fill 206 46 -423 207 46 -423 minecraft:water[level=0]
fill 206 46 -424 207 46 -424 minecraft:water[level=0]
setblock 205 46 -425 minecraft:water[level=0]
fill 205 46 -426 206 46 -426 minecraft:water[level=0]
fill 205 46 -427 206 46 -427 minecraft:water[level=0]
fill 205 46 -428 206 46 -428 minecraft:water[level=0]
setblock 206 46 -429 minecraft:water[level=0]
setblock 206 46 -430 minecraft:water[level=0]
fill 206 46 -431 208 46 -431 minecraft:water[level=0]
fill 206 46 -432 208 46 -432 minecraft:water[level=0]
fill 206 46 -433 209 46 -433 minecraft:water[level=0]
setblock 201 46 -434 minecraft:water[level=0]
fill 206 46 -434 209 46 -434 minecraft:water[level=0]
fill 201 46 -435 202 46 -435 minecraft:water[level=0]
fill 207 46 -435 210 46 -435 minecraft:water[level=0]
fill 201 46 -436 203 46 -436 minecraft:water[level=0]
fill 207 46 -436 210 46 -436 minecraft:water[level=0]
fill 201 46 -437 203 46 -437 minecraft:water[level=0]
fill 207 46 -437 209 46 -437 minecraft:water[level=0]
fill 202 46 -438 204 46 -438 minecraft:water[level=0]
fill 207 46 -438 208 46 -438 minecraft:water[level=0]
fill 203 46 -439 204 46 -439 minecraft:water[level=0]
fill 208 46 -439 209 46 -439 minecraft:water[level=0]
setblock 208 46 -440 minecraft:water[level=0]
fill 223 45 -383 224 45 -383 minecraft:air
fill 228 45 -383 236 45 -383 minecraft:water[level=0]
fill 239 45 -383 242 45 -383 minecraft:air
fill 228 45 -384 236 45 -384 minecraft:water[level=0]
fill 239 45 -384 241 45 -384 minecraft:air
fill 248 45 -384 253 45 -384 minecraft:water[level=0]
fill 228 45 -385 237 45 -385 minecraft:water[level=0]
setblock 240 45 -385 minecraft:air
fill 247 45 -385 253 45 -385 minecraft:water[level=0]
fill 229 45 -386 237 45 -386 minecraft:water[level=0]
fill 231 45 -387 235 45 -387 minecraft:water[level=0]
fill 232 45 -388 235 45 -388 minecraft:water[level=0]
fill 205 45 -418 207 45 -418 minecraft:water[level=0]
setblock 256 45 -418 minecraft:water[level=0]
fill 205 45 -419 208 45 -419 minecraft:water[level=0]
fill 255 45 -419 257 45 -419 minecraft:water[level=0]
fill 205 45 -420 208 45 -420 minecraft:water[level=0]
setblock 229 45 -420 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 205 45 -421 208 45 -421 minecraft:water[level=0]
fill 205 45 -422 208 45 -422 minecraft:water[level=0]
fill 205 45 -423 208 45 -423 minecraft:water[level=0]
fill 205 45 -424 208 45 -424 minecraft:water[level=0]
fill 204 45 -425 207 45 -425 minecraft:water[level=0]
fill 204 45 -426 207 45 -426 minecraft:water[level=0]
fill 204 45 -427 207 45 -427 minecraft:water[level=0]
fill 204 45 -428 207 45 -428 minecraft:water[level=0]
fill 200 45 -429 201 45 -429 minecraft:water[level=0]
fill 204 45 -429 207 45 -429 minecraft:water[level=0]
fill 200 45 -430 201 45 -430 minecraft:water[level=0]
fill 205 45 -430 207 45 -430 minecraft:water[level=0]
fill 200 45 -431 202 45 -431 minecraft:water[level=0]
fill 205 45 -431 208 45 -431 minecraft:water[level=0]
fill 200 45 -432 202 45 -432 minecraft:water[level=0]
fill 206 45 -432 208 45 -432 minecraft:water[level=0]
fill 200 45 -433 203 45 -433 minecraft:water[level=0]
fill 206 45 -433 209 45 -433 minecraft:water[level=0]
fill 200 45 -434 203 45 -434 minecraft:water[level=0]
fill 206 45 -434 208 45 -434 minecraft:water[level=0]
fill 200 45 -435 203 45 -435 minecraft:water[level=0]
fill 200 45 -436 204 45 -436 minecraft:water[level=0]
fill 206 45 -436 207 45 -436 minecraft:water[level=0]
fill 200 45 -437 205 45 -437 minecraft:water[level=0]
fill 207 45 -437 208 45 -437 minecraft:water[level=0]
fill 200 45 -438 205 45 -438 minecraft:water[level=0]
fill 207 45 -438 208 45 -438 minecraft:water[level=0]
fill 201 45 -439 206 45 -439 minecraft:water[level=0]
setblock 208 45 -439 minecraft:water[level=0]
fill 202 45 -440 206 45 -440 minecraft:water[level=0]
fill 204 45 -441 206 45 -441 minecraft:water[level=0]
setblock 205 45 -442 minecraft:water[level=0]
forceload remove 200 -446 263 -383
tellraw @a {"text":"Campus zurueck a04 fertig.","color":"green"}
