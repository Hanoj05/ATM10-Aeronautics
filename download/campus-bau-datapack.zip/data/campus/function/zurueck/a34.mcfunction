# Abschnitt a34: x 328..391, z -190..-127 (53061 Blöcke)
forceload add 328 -190 391 -127
tellraw @a {"text":"Campus zurueck a34: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a34_1 2s
