setblock 331 85 -255 minecraft:white_concrete
setblock 329 85 -258 minecraft:white_concrete
setblock 374 72 -309 minecraft:air
setblock 388 72 -309 minecraft:air
setblock 374 71 -307 minecraft:air
setblock 388 71 -307 minecraft:air
fill 373 71 -308 375 71 -308 minecraft:air
fill 387 71 -308 389 71 -308 minecraft:air
fill 372 71 -309 376 71 -309 minecraft:air
fill 386 71 -309 390 71 -309 minecraft:air
fill 373 71 -310 375 71 -310 minecraft:air
fill 387 71 -310 389 71 -310 minecraft:air
setblock 374 71 -311 minecraft:air
setblock 388 71 -311 minecraft:air
setblock 374 71 -317 minecraft:air
setblock 388 71 -317 minecraft:air
fill 373 71 -318 375 71 -318 minecraft:air
fill 387 71 -318 389 71 -318 minecraft:air
fill 373 70 -307 375 70 -307 minecraft:air
fill 387 70 -307 389 70 -307 minecraft:air
fill 372 70 -308 376 70 -308 minecraft:air
fill 386 70 -308 390 70 -308 minecraft:air
fill 372 70 -309 376 70 -309 minecraft:air
fill 386 70 -309 390 70 -309 minecraft:air
fill 372 70 -310 376 70 -310 minecraft:air
fill 386 70 -310 390 70 -310 minecraft:air
fill 373 70 -311 375 70 -311 minecraft:air
fill 387 70 -311 389 70 -311 minecraft:air
fill 373 70 -317 375 70 -317 minecraft:air
fill 387 70 -317 389 70 -317 minecraft:air
fill 372 70 -318 376 70 -318 minecraft:air
fill 386 70 -318 390 70 -318 minecraft:air
setblock 374 69 -307 minecraft:air
setblock 388 69 -307 minecraft:air
fill 373 69 -308 375 69 -308 minecraft:air
fill 387 69 -308 389 69 -308 minecraft:air
fill 372 69 -309 376 69 -309 minecraft:air
fill 386 69 -309 390 69 -309 minecraft:air
fill 373 69 -310 375 69 -310 minecraft:air
fill 387 69 -310 389 69 -310 minecraft:air
setblock 374 69 -311 minecraft:air
setblock 388 69 -311 minecraft:air
setblock 374 69 -317 minecraft:air
setblock 388 69 -317 minecraft:air
fill 373 69 -318 375 69 -318 minecraft:air
fill 387 69 -318 389 69 -318 minecraft:air
setblock 374 68 -309 minecraft:air
setblock 388 68 -309 minecraft:air
setblock 374 67 -309 minecraft:air
setblock 388 67 -309 minecraft:air
setblock 347 66 -262 minecraft:allium
setblock 347 66 -263 minecraft:cornflower
setblock 342 66 -279 minecraft:poppy
setblock 342 66 -280 minecraft:dandelion
setblock 344 66 -280 minecraft:cornflower
setblock 341 66 -281 minecraft:dandelion
setblock 343 66 -282 minecraft:poppy
setblock 374 66 -309 minecraft:air
setblock 388 66 -309 minecraft:air
fill 344 65 -267 345 65 -267 minecraft:grass_block[snowy=false]
fill 345 65 -268 347 65 -268 minecraft:grass_block[snowy=false]
fill 380 65 -302 382 65 -302 minecraft:grass_block[snowy=false]
fill 379 65 -303 383 65 -303 minecraft:grass_block[snowy=false]
fill 379 65 -304 383 65 -304 minecraft:grass_block[snowy=false]
fill 379 65 -305 383 65 -305 minecraft:grass_block[snowy=false]
fill 379 65 -306 383 65 -306 minecraft:grass_block[snowy=false]
fill 379 65 -307 383 65 -307 minecraft:grass_block[snowy=false]
fill 379 65 -308 383 65 -308 minecraft:grass_block[snowy=false]
fill 379 65 -309 383 65 -309 minecraft:grass_block[snowy=false]
fill 379 65 -310 383 65 -310 minecraft:grass_block[snowy=false]
fill 379 65 -311 383 65 -311 minecraft:grass_block[snowy=false]
fill 379 65 -312 383 65 -312 minecraft:grass_block[snowy=false]
fill 379 65 -313 383 65 -313 minecraft:grass_block[snowy=false]
fill 379 65 -314 383 65 -314 minecraft:grass_block[snowy=false]
fill 379 65 -315 383 65 -315 minecraft:grass_block[snowy=false]
fill 328 65 -316 337 65 -316 minecraft:black_concrete
fill 379 65 -316 383 65 -316 minecraft:grass_block[snowy=false]
fill 328 65 -317 337 65 -317 minecraft:black_concrete
fill 379 65 -317 383 65 -317 minecraft:grass_block[snowy=false]
fill 328 65 -318 337 65 -318 minecraft:black_concrete
fill 379 65 -318 383 65 -318 minecraft:grass_block[snowy=false]
setblock 391 64 -255 minecraft:air
setblock 346 64 -257 minecraft:air
setblock 348 64 -257 minecraft:air
fill 346 64 -258 349 64 -258 minecraft:air
fill 346 64 -259 349 64 -259 minecraft:air
fill 348 64 -260 349 64 -260 minecraft:air
fill 354 64 -262 360 64 -262 minecraft:air
fill 355 64 -263 361 64 -263 minecraft:air
fill 356 64 -264 362 64 -264 minecraft:air
setblock 383 64 -267 minecraft:air
setblock 383 64 -268 minecraft:air
setblock 383 64 -269 minecraft:air
setblock 381 64 -277 minecraft:air
setblock 381 64 -278 minecraft:air
fill 350 64 -279 353 64 -279 minecraft:air
setblock 381 64 -279 minecraft:air
setblock 383 64 -279 minecraft:air
fill 350 64 -280 354 64 -280 minecraft:air
fill 350 64 -281 354 64 -281 minecraft:air
setblock 381 64 -281 minecraft:air
fill 350 64 -282 354 64 -282 minecraft:air
setblock 376 64 -286 minecraft:air
setblock 376 64 -287 minecraft:air
fill 375 64 -288 376 64 -288 minecraft:air
fill 374 64 -290 376 64 -290 minecraft:air
fill 374 64 -291 376 64 -291 minecraft:air
fill 374 64 -292 376 64 -292 minecraft:air
fill 374 64 -293 376 64 -293 minecraft:air
setblock 375 64 -294 minecraft:air
setblock 375 64 -295 minecraft:air
setblock 391 64 -298 minecraft:air
fill 390 64 -299 391 64 -299 minecraft:air
setblock 377 64 -300 minecraft:air
fill 388 64 -300 390 64 -300 minecraft:air
fill 387 64 -301 391 64 -301 minecraft:air
fill 386 64 -302 391 64 -302 minecraft:air
fill 385 64 -303 391 64 -303 minecraft:air
fill 384 64 -304 391 64 -304 minecraft:air
fill 384 64 -305 391 64 -305 minecraft:air
fill 383 64 -306 390 64 -306 minecraft:air
fill 383 64 -307 389 64 -307 minecraft:air
fill 383 64 -308 388 64 -308 minecraft:air
fill 382 64 -309 388 64 -309 minecraft:air
fill 382 64 -310 390 64 -310 minecraft:air
fill 382 64 -311 391 64 -311 minecraft:air
fill 381 64 -312 391 64 -312 minecraft:air
fill 381 64 -313 387 64 -313 minecraft:air
setblock 391 64 -313 minecraft:air
fill 381 64 -314 387 64 -314 minecraft:air
setblock 391 64 -314 minecraft:air
fill 380 64 -315 387 64 -315 minecraft:air
fill 379 64 -316 387 64 -316 minecraft:air
fill 379 64 -317 386 64 -317 minecraft:air
fill 379 64 -318 386 64 -318 minecraft:air
fill 347 63 -259 350 63 -259 minecraft:air
fill 348 63 -260 350 63 -260 minecraft:air
fill 348 63 -261 349 63 -261 minecraft:air
fill 353 63 -262 359 63 -262 minecraft:air
fill 354 63 -263 359 63 -263 minecraft:air
fill 355 63 -264 359 63 -264 minecraft:air
fill 352 63 -279 353 63 -279 minecraft:air
fill 351 63 -280 353 63 -280 minecraft:air
fill 350 63 -281 353 63 -281 minecraft:air
fill 350 63 -282 352 63 -282 minecraft:air
setblock 354 63 -282 minecraft:air
setblock 374 63 -287 minecraft:air
fill 373 63 -290 374 63 -290 minecraft:air
fill 373 63 -291 374 63 -291 minecraft:air
fill 373 63 -292 374 63 -292 minecraft:air
setblock 373 63 -293 minecraft:air
setblock 373 63 -294 minecraft:air
fill 390 63 -298 391 63 -298 minecraft:air
fill 387 63 -299 391 63 -299 minecraft:air
fill 387 63 -300 391 63 -300 minecraft:air
fill 386 63 -301 391 63 -301 minecraft:air
fill 385 63 -302 391 63 -302 minecraft:air
fill 384 63 -303 391 63 -303 minecraft:air
fill 383 63 -304 391 63 -304 minecraft:air
fill 383 63 -305 391 63 -305 minecraft:air
fill 382 63 -306 391 63 -306 minecraft:air
fill 382 63 -307 390 63 -307 minecraft:air
fill 382 63 -308 390 63 -308 minecraft:air
fill 381 63 -309 389 63 -309 minecraft:air
fill 381 63 -310 390 63 -310 minecraft:air
fill 381 63 -311 391 63 -311 minecraft:air
fill 380 63 -312 391 63 -312 minecraft:air
fill 380 63 -313 388 63 -313 minecraft:air
fill 390 63 -313 391 63 -313 minecraft:air
fill 380 63 -314 388 63 -314 minecraft:air
setblock 391 63 -314 minecraft:air
fill 380 63 -315 388 63 -315 minecraft:air
fill 380 63 -316 388 63 -316 minecraft:air
fill 380 63 -317 387 63 -317 minecraft:air
fill 380 63 -318 387 63 -318 minecraft:air
fill 349 62 -259 350 62 -259 minecraft:air
fill 349 62 -260 350 62 -260 minecraft:air
setblock 347 62 -261 minecraft:water[level=0]
fill 349 62 -261 350 62 -261 minecraft:air
setblock 350 62 -262 minecraft:air
fill 352 62 -262 356 62 -262 minecraft:air
fill 353 62 -263 357 62 -263 minecraft:air
fill 353 62 -264 357 62 -264 minecraft:air
fill 351 62 -278 352 62 -278 minecraft:air
setblock 350 62 -279 minecraft:air
fill 353 62 -279 354 62 -279 minecraft:air
fill 350 62 -280 354 62 -280 minecraft:air
fill 351 62 -281 352 62 -281 minecraft:air
setblock 351 62 -282 minecraft:air
setblock 372 62 -290 minecraft:water[level=0]
setblock 372 62 -291 minecraft:water[level=0]
setblock 372 62 -292 minecraft:water[level=0]
setblock 391 62 -297 minecraft:water[level=0]
fill 389 62 -298 391 62 -298 minecraft:water[level=0]
fill 387 62 -299 391 62 -299 minecraft:water[level=0]
fill 386 62 -300 391 62 -300 minecraft:water[level=0]
fill 386 62 -301 391 62 -301 minecraft:water[level=0]
fill 384 62 -302 391 62 -302 minecraft:water[level=0]
fill 383 62 -303 391 62 -303 minecraft:water[level=0]
fill 383 62 -304 391 62 -304 minecraft:water[level=0]
fill 381 62 -305 391 62 -305 minecraft:water[level=0]
fill 381 62 -306 391 62 -306 minecraft:water[level=0]
fill 382 62 -307 391 62 -307 minecraft:water[level=0]
fill 381 62 -308 390 62 -308 minecraft:water[level=0]
fill 381 62 -309 389 62 -309 minecraft:water[level=0]
fill 381 62 -310 390 62 -310 minecraft:water[level=0]
fill 380 62 -311 391 62 -311 minecraft:water[level=0]
fill 380 62 -312 391 62 -312 minecraft:water[level=0]
fill 380 62 -313 388 62 -313 minecraft:water[level=0]
setblock 391 62 -313 minecraft:water[level=0]
fill 380 62 -314 388 62 -314 minecraft:water[level=0]
setblock 391 62 -314 minecraft:water[level=0]
fill 380 62 -315 388 62 -315 minecraft:water[level=0]
fill 380 62 -316 388 62 -316 minecraft:water[level=0]
fill 380 62 -317 388 62 -317 minecraft:water[level=0]
fill 380 62 -318 387 62 -318 minecraft:water[level=0]
setblock 350 61 -259 minecraft:air
fill 349 61 -260 351 61 -260 minecraft:air
fill 349 61 -261 351 61 -261 minecraft:air
fill 350 61 -262 355 61 -262 minecraft:air
setblock 350 61 -263 minecraft:air
fill 352 61 -263 355 61 -263 minecraft:air
fill 352 61 -264 356 61 -264 minecraft:air
fill 390 61 -298 391 61 -298 minecraft:water[level=0]
fill 388 61 -299 391 61 -299 minecraft:water[level=0]
fill 387 61 -300 391 61 -300 minecraft:water[level=0]
fill 386 61 -301 391 61 -301 minecraft:water[level=0]
fill 377 61 -302 378 61 -302 minecraft:water[level=0]
fill 385 61 -302 391 61 -302 minecraft:water[level=0]
setblock 377 61 -303 minecraft:water[level=0]
fill 379 61 -303 380 61 -303 minecraft:water[level=0]
fill 384 61 -303 391 61 -303 minecraft:water[level=0]
fill 379 61 -304 381 61 -304 minecraft:water[level=0]
fill 384 61 -304 391 61 -304 minecraft:water[level=0]
fill 379 61 -305 391 61 -305 minecraft:water[level=0]
fill 380 61 -306 390 61 -306 minecraft:water[level=0]
fill 381 61 -307 390 61 -307 minecraft:water[level=0]
fill 382 61 -308 389 61 -308 minecraft:water[level=0]
fill 382 61 -309 389 61 -309 minecraft:water[level=0]
fill 382 61 -310 390 61 -310 minecraft:water[level=0]
fill 381 61 -311 391 61 -311 minecraft:water[level=0]
fill 381 61 -312 391 61 -312 minecraft:water[level=0]
fill 381 61 -313 387 61 -313 minecraft:water[level=0]
fill 390 61 -313 391 61 -313 minecraft:water[level=0]
fill 380 61 -314 387 61 -314 minecraft:water[level=0]
setblock 391 61 -314 minecraft:water[level=0]
fill 380 61 -315 387 61 -315 minecraft:water[level=0]
fill 380 61 -316 387 61 -316 minecraft:water[level=0]
fill 380 61 -317 387 61 -317 minecraft:water[level=0]
fill 380 61 -318 387 61 -318 minecraft:water[level=0]
fill 349 60 -260 351 60 -260 minecraft:air
fill 349 60 -261 352 60 -261 minecraft:air
fill 350 60 -262 354 60 -262 minecraft:air
fill 350 60 -263 354 60 -263 minecraft:air
fill 351 60 -264 354 60 -264 minecraft:air
fill 390 60 -298 391 60 -298 minecraft:water[level=0]
fill 374 60 -299 375 60 -299 minecraft:water[level=0]
fill 388 60 -299 391 60 -299 minecraft:water[level=0]
fill 375 60 -300 376 60 -300 minecraft:water[level=0]
fill 387 60 -300 391 60 -300 minecraft:water[level=0]
fill 386 60 -301 391 60 -301 minecraft:water[level=0]
fill 377 60 -302 378 60 -302 minecraft:water[level=0]
fill 385 60 -302 391 60 -302 minecraft:water[level=0]
fill 377 60 -303 380 60 -303 minecraft:water[level=0]
fill 384 60 -303 391 60 -303 minecraft:water[level=0]
fill 379 60 -304 381 60 -304 minecraft:water[level=0]
fill 384 60 -304 391 60 -304 minecraft:water[level=0]
fill 379 60 -305 391 60 -305 minecraft:water[level=0]
fill 380 60 -306 390 60 -306 minecraft:water[level=0]
fill 381 60 -307 390 60 -307 minecraft:water[level=0]
fill 382 60 -308 389 60 -308 minecraft:water[level=0]
fill 382 60 -309 389 60 -309 minecraft:water[level=0]
fill 382 60 -310 390 60 -310 minecraft:water[level=0]
fill 381 60 -311 391 60 -311 minecraft:water[level=0]
fill 381 60 -312 391 60 -312 minecraft:water[level=0]
fill 381 60 -313 387 60 -313 minecraft:water[level=0]
fill 390 60 -313 391 60 -313 minecraft:water[level=0]
fill 380 60 -314 387 60 -314 minecraft:water[level=0]
setblock 391 60 -314 minecraft:water[level=0]
fill 380 60 -315 387 60 -315 minecraft:water[level=0]
fill 380 60 -316 387 60 -316 minecraft:water[level=0]
fill 380 60 -317 387 60 -317 minecraft:water[level=0]
fill 380 60 -318 387 60 -318 minecraft:water[level=0]
fill 350 59 -261 353 59 -261 minecraft:air
fill 350 59 -262 353 59 -262 minecraft:air
fill 350 59 -263 353 59 -263 minecraft:air
fill 350 59 -264 353 59 -264 minecraft:air
setblock 351 59 -265 minecraft:air
setblock 374 59 -297 minecraft:water[level=0]
fill 373 59 -298 375 59 -298 minecraft:water[level=0]
fill 390 59 -298 391 59 -298 minecraft:water[level=0]
fill 373 59 -299 376 59 -299 minecraft:water[level=0]
fill 388 59 -299 391 59 -299 minecraft:water[level=0]
fill 374 59 -300 376 59 -300 minecraft:water[level=0]
fill 387 59 -300 391 59 -300 minecraft:water[level=0]
fill 375 59 -301 378 59 -301 minecraft:water[level=0]
fill 386 59 -301 391 59 -301 minecraft:water[level=0]
fill 376 59 -302 378 59 -302 minecraft:water[level=0]
fill 385 59 -302 391 59 -302 minecraft:water[level=0]
fill 377 59 -303 381 59 -303 minecraft:water[level=0]
fill 384 59 -303 391 59 -303 minecraft:water[level=0]
fill 379 59 -304 382 59 -304 minecraft:water[level=0]
fill 384 59 -304 391 59 -304 minecraft:water[level=0]
fill 379 59 -305 391 59 -305 minecraft:water[level=0]
fill 380 59 -306 390 59 -306 minecraft:water[level=0]
fill 381 59 -307 390 59 -307 minecraft:water[level=0]
fill 381 59 -308 389 59 -308 minecraft:water[level=0]
fill 382 59 -309 390 59 -309 minecraft:water[level=0]
fill 382 59 -310 391 59 -310 minecraft:water[level=0]
fill 381 59 -311 391 59 -311 minecraft:water[level=0]
fill 381 59 -312 391 59 -312 minecraft:water[level=0]
fill 381 59 -313 387 59 -313 minecraft:water[level=0]
fill 389 59 -313 391 59 -313 minecraft:water[level=0]
fill 380 59 -314 387 59 -314 minecraft:water[level=0]
fill 390 59 -314 391 59 -314 minecraft:water[level=0]
fill 380 59 -315 387 59 -315 minecraft:water[level=0]
setblock 391 59 -315 minecraft:water[level=0]
fill 380 59 -316 387 59 -316 minecraft:water[level=0]
fill 380 59 -317 387 59 -317 minecraft:water[level=0]
setblock 354 59 -318 minecraft:water[level=0]
fill 380 59 -318 387 59 -318 minecraft:water[level=0]
fill 351 58 -261 354 58 -261 minecraft:air
fill 350 58 -262 354 58 -262 minecraft:air
fill 350 58 -263 354 58 -263 minecraft:air
fill 350 58 -264 352 58 -264 minecraft:air
setblock 350 58 -265 minecraft:air
setblock 374 58 -297 minecraft:water[level=0]
fill 373 58 -298 375 58 -298 minecraft:water[level=0]
fill 390 58 -298 391 58 -298 minecraft:water[level=0]
fill 373 58 -299 376 58 -299 minecraft:water[level=0]
fill 388 58 -299 391 58 -299 minecraft:water[level=0]
fill 374 58 -300 376 58 -300 minecraft:water[level=0]
fill 387 58 -300 391 58 -300 minecraft:water[level=0]
fill 375 58 -301 378 58 -301 minecraft:water[level=0]
fill 386 58 -301 391 58 -301 minecraft:water[level=0]
fill 376 58 -302 378 58 -302 minecraft:water[level=0]
fill 385 58 -302 391 58 -302 minecraft:water[level=0]
fill 377 58 -303 381 58 -303 minecraft:water[level=0]
fill 384 58 -303 391 58 -303 minecraft:water[level=0]
fill 378 58 -304 382 58 -304 minecraft:water[level=0]
fill 384 58 -304 391 58 -304 minecraft:water[level=0]
fill 379 58 -305 391 58 -305 minecraft:water[level=0]
fill 379 58 -306 390 58 -306 minecraft:water[level=0]
fill 381 58 -307 390 58 -307 minecraft:water[level=0]
fill 381 58 -308 389 58 -308 minecraft:water[level=0]
fill 382 58 -309 390 58 -309 minecraft:water[level=0]
fill 382 58 -310 391 58 -310 minecraft:water[level=0]
fill 381 58 -311 391 58 -311 minecraft:water[level=0]
fill 381 58 -312 391 58 -312 minecraft:water[level=0]
fill 381 58 -313 387 58 -313 minecraft:water[level=0]
fill 389 58 -313 391 58 -313 minecraft:water[level=0]
fill 380 58 -314 387 58 -314 minecraft:water[level=0]
fill 390 58 -314 391 58 -314 minecraft:water[level=0]
fill 380 58 -315 387 58 -315 minecraft:water[level=0]
setblock 391 58 -315 minecraft:water[level=0]
fill 380 58 -316 387 58 -316 minecraft:water[level=0]
setblock 353 58 -317 minecraft:water[level=0]
fill 380 58 -317 387 58 -317 minecraft:water[level=0]
fill 353 58 -318 354 58 -318 minecraft:water[level=0]
fill 380 58 -318 387 58 -318 minecraft:water[level=0]
fill 352 57 -261 355 57 -261 minecraft:air
fill 350 57 -262 355 57 -262 minecraft:air
fill 350 57 -263 354 57 -263 minecraft:air
fill 350 57 -264 351 57 -264 minecraft:air
setblock 350 57 -265 minecraft:air
setblock 374 57 -297 minecraft:water[level=0]
fill 373 57 -298 375 57 -298 minecraft:water[level=0]
fill 390 57 -298 391 57 -298 minecraft:water[level=0]
fill 373 57 -299 376 57 -299 minecraft:water[level=0]
fill 388 57 -299 391 57 -299 minecraft:water[level=0]
fill 374 57 -300 376 57 -300 minecraft:water[level=0]
fill 387 57 -300 391 57 -300 minecraft:water[level=0]
fill 375 57 -301 378 57 -301 minecraft:water[level=0]
fill 386 57 -301 391 57 -301 minecraft:water[level=0]
fill 376 57 -302 378 57 -302 minecraft:water[level=0]
fill 385 57 -302 391 57 -302 minecraft:water[level=0]
fill 377 57 -303 381 57 -303 minecraft:water[level=0]
fill 384 57 -303 391 57 -303 minecraft:water[level=0]
fill 378 57 -304 382 57 -304 minecraft:water[level=0]
fill 384 57 -304 391 57 -304 minecraft:water[level=0]
fill 379 57 -305 391 57 -305 minecraft:water[level=0]
fill 379 57 -306 390 57 -306 minecraft:water[level=0]
fill 381 57 -307 390 57 -307 minecraft:water[level=0]
fill 381 57 -308 389 57 -308 minecraft:water[level=0]
fill 382 57 -309 390 57 -309 minecraft:water[level=0]
fill 382 57 -310 391 57 -310 minecraft:water[level=0]
fill 381 57 -311 391 57 -311 minecraft:water[level=0]
fill 381 57 -312 391 57 -312 minecraft:water[level=0]
fill 381 57 -313 391 57 -313 minecraft:water[level=0]
fill 380 57 -314 387 57 -314 minecraft:water[level=0]
fill 390 57 -314 391 57 -314 minecraft:water[level=0]
fill 380 57 -315 387 57 -315 minecraft:water[level=0]
setblock 391 57 -315 minecraft:water[level=0]
fill 380 57 -316 387 57 -316 minecraft:water[level=0]
setblock 353 57 -317 minecraft:water[level=0]
fill 380 57 -317 387 57 -317 minecraft:water[level=0]
fill 353 57 -318 354 57 -318 minecraft:water[level=0]
fill 380 57 -318 387 57 -318 minecraft:water[level=0]
fill 353 56 -261 355 56 -261 minecraft:air
setblock 350 56 -262 minecraft:air
fill 353 56 -262 355 56 -262 minecraft:air
fill 350 56 -263 351 56 -263 minecraft:air
fill 354 56 -263 355 56 -263 minecraft:air
fill 350 56 -264 351 56 -264 minecraft:air
setblock 350 56 -265 minecraft:air
setblock 374 56 -298 minecraft:water[level=0]
fill 390 56 -298 391 56 -298 minecraft:water[level=0]
fill 374 56 -299 375 56 -299 minecraft:water[level=0]
fill 388 56 -299 391 56 -299 minecraft:water[level=0]
fill 375 56 -300 376 56 -300 minecraft:water[level=0]
fill 387 56 -300 391 56 -300 minecraft:water[level=0]
fill 386 56 -301 391 56 -301 minecraft:water[level=0]
fill 377 56 -302 378 56 -302 minecraft:water[level=0]
fill 385 56 -302 391 56 -302 minecraft:water[level=0]
fill 384 56 -303 391 56 -303 minecraft:water[level=0]
fill 379 56 -304 381 56 -304 minecraft:water[level=0]
fill 384 56 -304 391 56 -304 minecraft:water[level=0]
fill 380 56 -305 391 56 -305 minecraft:water[level=0]
fill 381 56 -306 390 56 -306 minecraft:water[level=0]
fill 382 56 -307 390 56 -307 minecraft:water[level=0]
fill 382 56 -308 389 56 -308 minecraft:water[level=0]
fill 382 56 -309 388 56 -309 minecraft:water[level=0]
fill 382 56 -310 390 56 -310 minecraft:water[level=0]
fill 381 56 -311 390 56 -311 minecraft:water[level=0]
fill 381 56 -312 387 56 -312 minecraft:water[level=0]
fill 389 56 -312 391 56 -312 minecraft:water[level=0]
fill 381 56 -313 387 56 -313 minecraft:water[level=0]
setblock 391 56 -313 minecraft:water[level=0]
fill 380 56 -314 387 56 -314 minecraft:water[level=0]
fill 380 56 -315 387 56 -315 minecraft:water[level=0]
fill 352 56 -316 353 56 -316 minecraft:water[level=0]
fill 380 56 -316 387 56 -316 minecraft:water[level=0]
fill 352 56 -317 354 56 -317 minecraft:water[level=0]
fill 380 56 -317 387 56 -317 minecraft:water[level=0]
fill 353 56 -318 355 56 -318 minecraft:water[level=0]
fill 380 56 -318 387 56 -318 minecraft:water[level=0]
setblock 350 55 -262 minecraft:air
fill 350 55 -263 351 55 -263 minecraft:air
setblock 350 55 -264 minecraft:air
setblock 374 55 -297 minecraft:water[level=0]
fill 373 55 -298 375 55 -298 minecraft:water[level=0]
fill 390 55 -298 391 55 -298 minecraft:water[level=0]
fill 373 55 -299 376 55 -299 minecraft:water[level=0]
fill 388 55 -299 391 55 -299 minecraft:water[level=0]
fill 374 55 -300 376 55 -300 minecraft:water[level=0]
fill 387 55 -300 391 55 -300 minecraft:water[level=0]
fill 375 55 -301 378 55 -301 minecraft:water[level=0]
fill 386 55 -301 391 55 -301 minecraft:water[level=0]
fill 376 55 -302 378 55 -302 minecraft:water[level=0]
fill 385 55 -302 391 55 -302 minecraft:water[level=0]
fill 377 55 -303 381 55 -303 minecraft:water[level=0]
fill 384 55 -303 391 55 -303 minecraft:water[level=0]
fill 378 55 -304 382 55 -304 minecraft:water[level=0]
fill 384 55 -304 391 55 -304 minecraft:water[level=0]
fill 379 55 -305 391 55 -305 minecraft:water[level=0]
fill 379 55 -306 390 55 -306 minecraft:water[level=0]
fill 381 55 -307 390 55 -307 minecraft:water[level=0]
fill 381 55 -308 389 55 -308 minecraft:water[level=0]
fill 382 55 -309 390 55 -309 minecraft:water[level=0]
fill 382 55 -310 391 55 -310 minecraft:water[level=0]
fill 381 55 -311 391 55 -311 minecraft:water[level=0]
fill 381 55 -312 391 55 -312 minecraft:water[level=0]
fill 381 55 -313 387 55 -313 minecraft:water[level=0]
fill 389 55 -313 391 55 -313 minecraft:water[level=0]
fill 380 55 -314 387 55 -314 minecraft:water[level=0]
fill 390 55 -314 391 55 -314 minecraft:water[level=0]
fill 352 55 -315 353 55 -315 minecraft:water[level=0]
fill 380 55 -315 387 55 -315 minecraft:water[level=0]
setblock 391 55 -315 minecraft:water[level=0]
fill 352 55 -316 354 55 -316 minecraft:water[level=0]
fill 380 55 -316 387 55 -316 minecraft:water[level=0]
fill 352 55 -317 354 55 -317 minecraft:water[level=0]
fill 380 55 -317 387 55 -317 minecraft:water[level=0]
fill 352 55 -318 354 55 -318 minecraft:water[level=0]
fill 380 55 -318 387 55 -318 minecraft:water[level=0]
setblock 350 54 -262 minecraft:air
setblock 350 54 -263 minecraft:air
setblock 349 54 -266 minecraft:water[level=0]
setblock 374 54 -297 minecraft:water[level=0]
fill 373 54 -298 375 54 -298 minecraft:water[level=0]
fill 373 54 -299 376 54 -299 minecraft:water[level=0]
fill 390 54 -299 391 54 -299 minecraft:water[level=0]
fill 374 54 -300 376 54 -300 minecraft:water[level=0]
fill 388 54 -300 391 54 -300 minecraft:water[level=0]
fill 375 54 -301 378 54 -301 minecraft:water[level=0]
fill 387 54 -301 391 54 -301 minecraft:water[level=0]
fill 376 54 -302 378 54 -302 minecraft:water[level=0]
fill 387 54 -302 391 54 -302 minecraft:water[level=0]
fill 377 54 -303 381 54 -303 minecraft:water[level=0]
fill 385 54 -303 391 54 -303 minecraft:water[level=0]
fill 378 54 -304 382 54 -304 minecraft:water[level=0]
fill 385 54 -304 391 54 -304 minecraft:water[level=0]
fill 379 54 -305 391 54 -305 minecraft:water[level=0]
fill 380 54 -306 389 54 -306 minecraft:water[level=0]
fill 381 54 -307 389 54 -307 minecraft:water[level=0]
fill 381 54 -308 388 54 -308 minecraft:water[level=0]
fill 382 54 -309 390 54 -309 minecraft:water[level=0]
fill 382 54 -310 391 54 -310 minecraft:water[level=0]
fill 382 54 -311 391 54 -311 minecraft:water[level=0]
fill 381 54 -312 390 54 -312 minecraft:water[level=0]
fill 381 54 -313 387 54 -313 minecraft:water[level=0]
fill 389 54 -313 391 54 -313 minecraft:water[level=0]
fill 352 54 -314 353 54 -314 minecraft:water[level=0]
fill 381 54 -314 386 54 -314 minecraft:water[level=0]
fill 390 54 -314 391 54 -314 minecraft:water[level=0]
fill 352 54 -315 354 54 -315 minecraft:water[level=0]
fill 381 54 -315 386 54 -315 minecraft:water[level=0]
setblock 391 54 -315 minecraft:water[level=0]
fill 351 54 -316 353 54 -316 minecraft:water[level=0]
fill 381 54 -316 386 54 -316 minecraft:water[level=0]
fill 352 54 -317 354 54 -317 minecraft:water[level=0]
fill 381 54 -317 386 54 -317 minecraft:water[level=0]
fill 352 54 -318 354 54 -318 minecraft:water[level=0]
fill 381 54 -318 386 54 -318 minecraft:water[level=0]
setblock 350 53 -262 minecraft:air
setblock 348 53 -265 minecraft:water[level=0]
fill 348 53 -266 349 53 -266 minecraft:water[level=0]
fill 373 53 -298 375 53 -298 minecraft:water[level=0]
fill 389 53 -298 391 53 -298 minecraft:water[level=0]
fill 374 53 -299 375 53 -299 minecraft:water[level=0]
fill 387 53 -299 391 53 -299 minecraft:water[level=0]
fill 374 53 -300 376 53 -300 minecraft:water[level=0]
fill 386 53 -300 391 53 -300 minecraft:water[level=0]
setblock 375 53 -301 minecraft:water[level=0]
setblock 377 53 -301 minecraft:water[level=0]
fill 386 53 -301 391 53 -301 minecraft:water[level=0]
fill 377 53 -302 378 53 -302 minecraft:water[level=0]
fill 384 53 -302 391 53 -302 minecraft:water[level=0]
fill 377 53 -303 380 53 -303 minecraft:water[level=0]
fill 383 53 -303 391 53 -303 minecraft:water[level=0]
fill 379 53 -304 381 53 -304 minecraft:water[level=0]
fill 383 53 -304 391 53 -304 minecraft:water[level=0]
fill 379 53 -305 391 53 -305 minecraft:water[level=0]
fill 380 53 -306 391 53 -306 minecraft:water[level=0]
fill 381 53 -307 390 53 -307 minecraft:water[level=0]
fill 381 53 -308 390 53 -308 minecraft:water[level=0]
setblock 381 53 -309 minecraft:bubble_column[drag=true]
fill 382 53 -309 389 53 -309 minecraft:water[level=0]
fill 383 53 -310 390 53 -310 minecraft:water[level=0]
setblock 380 53 -311 minecraft:water[level=0]
fill 351 53 -312 352 53 -312 minecraft:water[level=0]
fill 380 53 -312 388 53 -312 minecraft:water[level=0]
fill 351 53 -313 353 53 -313 minecraft:water[level=0]
fill 380 53 -313 388 53 -313 minecraft:water[level=0]
fill 390 53 -313 391 53 -313 minecraft:water[level=0]
fill 351 53 -314 353 53 -314 minecraft:water[level=0]
fill 380 53 -314 388 53 -314 minecraft:water[level=0]
setblock 391 53 -314 minecraft:water[level=0]
fill 351 53 -315 353 53 -315 minecraft:water[level=0]
fill 380 53 -315 388 53 -315 minecraft:water[level=0]
fill 351 53 -316 353 53 -316 minecraft:water[level=0]
fill 380 53 -316 388 53 -316 minecraft:water[level=0]
fill 351 53 -317 353 53 -317 minecraft:water[level=0]
fill 380 53 -317 388 53 -317 minecraft:water[level=0]
fill 352 53 -318 353 53 -318 minecraft:water[level=0]
fill 380 53 -318 387 53 -318 minecraft:water[level=0]
setblock 348 52 -264 minecraft:water[level=0]
fill 348 52 -265 349 52 -265 minecraft:water[level=0]
fill 348 52 -266 349 52 -266 minecraft:water[level=0]
fill 348 52 -267 349 52 -267 minecraft:water[level=0]
fill 374 52 -298 375 52 -298 minecraft:water[level=0]
fill 390 52 -298 391 52 -298 minecraft:water[level=0]
fill 374 52 -299 375 52 -299 minecraft:water[level=0]
fill 387 52 -299 391 52 -299 minecraft:water[level=0]
fill 374 52 -300 376 52 -300 minecraft:water[level=0]
fill 386 52 -300 391 52 -300 minecraft:water[level=0]
fill 386 52 -301 391 52 -301 minecraft:water[level=0]
fill 377 52 -302 378 52 -302 minecraft:water[level=0]
fill 384 52 -302 391 52 -302 minecraft:water[level=0]
fill 377 52 -303 380 52 -303 minecraft:water[level=0]
fill 384 52 -303 391 52 -303 minecraft:water[level=0]
fill 379 52 -304 381 52 -304 minecraft:water[level=0]
fill 383 52 -304 391 52 -304 minecraft:water[level=0]
fill 379 52 -305 391 52 -305 minecraft:water[level=0]
fill 380 52 -306 391 52 -306 minecraft:water[level=0]
fill 381 52 -307 390 52 -307 minecraft:water[level=0]
fill 381 52 -308 390 52 -308 minecraft:water[level=0]
setblock 381 52 -309 minecraft:bubble_column[drag=true]
fill 382 52 -309 389 52 -309 minecraft:water[level=0]
setblock 351 52 -310 minecraft:water[level=0]
fill 351 52 -311 352 52 -311 minecraft:water[level=0]
fill 351 52 -312 353 52 -312 minecraft:water[level=0]
fill 351 52 -313 353 52 -313 minecraft:water[level=0]
fill 381 52 -313 383 52 -313 minecraft:water[level=0]
fill 351 52 -314 353 52 -314 minecraft:water[level=0]
fill 380 52 -314 388 52 -314 minecraft:water[level=0]
fill 351 52 -315 353 52 -315 minecraft:water[level=0]
fill 380 52 -315 388 52 -315 minecraft:water[level=0]
fill 352 52 -316 353 52 -316 minecraft:water[level=0]
fill 380 52 -316 388 52 -316 minecraft:water[level=0]
fill 352 52 -317 353 52 -317 minecraft:water[level=0]
fill 380 52 -317 388 52 -317 minecraft:water[level=0]
setblock 353 52 -318 minecraft:water[level=0]
fill 380 52 -318 387 52 -318 minecraft:water[level=0]
fill 347 51 -264 348 51 -264 minecraft:water[level=0]
fill 347 51 -265 349 51 -265 minecraft:water[level=0]
fill 348 51 -266 349 51 -266 minecraft:water[level=0]
fill 348 51 -267 349 51 -267 minecraft:water[level=0]
setblock 348 51 -268 minecraft:water[level=0]
fill 374 51 -298 375 51 -298 minecraft:water[level=0]
fill 390 51 -298 391 51 -298 minecraft:water[level=0]
fill 374 51 -299 375 51 -299 minecraft:water[level=0]
fill 387 51 -299 391 51 -299 minecraft:water[level=0]
fill 375 51 -300 376 51 -300 minecraft:water[level=0]
fill 386 51 -300 391 51 -300 minecraft:water[level=0]
fill 386 51 -301 391 51 -301 minecraft:water[level=0]
fill 377 51 -302 378 51 -302 minecraft:water[level=0]
fill 384 51 -302 391 51 -302 minecraft:water[level=0]
setblock 375 51 -303 minecraft:air
setblock 376 51 -303 minecraft:water[level=1]
fill 377 51 -303 380 51 -303 minecraft:water[level=0]
fill 384 51 -303 391 51 -303 minecraft:water[level=0]
fill 375 51 -304 376 51 -304 minecraft:air
setblock 377 51 -304 minecraft:water[level=1]
fill 379 51 -304 381 51 -304 minecraft:water[level=0]
fill 383 51 -304 391 51 -304 minecraft:water[level=0]
fill 375 51 -305 377 51 -305 minecraft:air
fill 379 51 -305 391 51 -305 minecraft:water[level=0]
fill 380 51 -306 391 51 -306 minecraft:water[level=0]
fill 381 51 -307 390 51 -307 minecraft:water[level=0]
setblock 351 51 -308 minecraft:water[level=0]
fill 382 51 -308 390 51 -308 minecraft:water[level=0]
fill 351 51 -309 352 51 -309 minecraft:water[level=0]
fill 351 51 -310 353 51 -310 minecraft:water[level=0]
fill 351 51 -311 353 51 -311 minecraft:water[level=0]
fill 386 51 -311 391 51 -311 minecraft:air
fill 351 51 -312 353 51 -312 minecraft:water[level=0]
fill 350 51 -313 353 51 -313 minecraft:water[level=0]
fill 351 51 -314 352 51 -314 minecraft:water[level=0]
setblock 352 51 -315 minecraft:water[level=0]
setblock 380 51 -315 minecraft:water[level=0]
fill 382 51 -315 384 51 -315 minecraft:water[level=0]
fill 380 51 -316 388 51 -316 minecraft:water[level=0]
fill 380 51 -317 388 51 -317 minecraft:water[level=0]
fill 380 51 -318 387 51 -318 minecraft:water[level=0]
fill 347 50 -263 348 50 -263 minecraft:water[level=0]
fill 347 50 -264 348 50 -264 minecraft:water[level=0]
fill 347 50 -265 348 50 -265 minecraft:water[level=0]
setblock 348 50 -266 minecraft:water[level=0]
fill 347 50 -267 349 50 -267 minecraft:water[level=0]
setblock 348 50 -268 minecraft:water[level=0]
setblock 348 50 -269 minecraft:water[level=0]
setblock 357 50 -287 minecraft:water[level=0]
setblock 357 50 -288 minecraft:water[level=0]
setblock 357 50 -289 minecraft:water[level=0]
setblock 357 50 -290 minecraft:water[level=0]
fill 357 50 -291 358 50 -291 minecraft:water[level=0]
fill 357 50 -292 358 50 -292 minecraft:water[level=0]
setblock 391 50 -298 minecraft:water[level=0]
fill 374 50 -299 375 50 -299 minecraft:water[level=0]
fill 390 50 -299 391 50 -299 minecraft:water[level=0]
fill 375 50 -300 376 50 -300 minecraft:water[level=0]
fill 388 50 -300 391 50 -300 minecraft:water[level=0]
fill 387 50 -301 391 50 -301 minecraft:water[level=0]
fill 377 50 -302 378 50 -302 minecraft:water[level=0]
fill 386 50 -302 391 50 -302 minecraft:water[level=0]
setblock 375 50 -303 minecraft:air
setblock 376 50 -303 minecraft:water[level=8]
setblock 377 50 -303 minecraft:water[level=0]
fill 379 50 -303 380 50 -303 minecraft:water[level=0]
fill 385 50 -303 391 50 -303 minecraft:water[level=0]
fill 375 50 -304 376 50 -304 minecraft:air
setblock 377 50 -304 minecraft:water[level=8]
fill 379 50 -304 381 50 -304 minecraft:water[level=0]
fill 384 50 -304 391 50 -304 minecraft:water[level=0]
fill 375 50 -305 377 50 -305 minecraft:air
fill 379 50 -305 391 50 -305 minecraft:water[level=0]
setblock 351 50 -306 minecraft:water[level=0]
fill 375 50 -306 377 50 -306 minecraft:air
fill 380 50 -306 390 50 -306 minecraft:water[level=0]
fill 351 50 -307 353 50 -307 minecraft:water[level=0]
fill 381 50 -307 389 50 -307 minecraft:water[level=0]
fill 351 50 -308 353 50 -308 minecraft:water[level=0]
fill 351 50 -309 353 50 -309 minecraft:water[level=0]
fill 350 50 -310 353 50 -310 minecraft:water[level=0]
fill 382 50 -310 390 50 -310 minecraft:air
fill 350 50 -311 352 50 -311 minecraft:water[level=0]
fill 381 50 -311 391 50 -311 minecraft:air
fill 351 50 -312 352 50 -312 minecraft:water[level=0]
fill 381 50 -312 391 50 -312 minecraft:air
fill 351 50 -313 352 50 -313 minecraft:water[level=0]
setblock 387 50 -313 minecraft:air
fill 390 50 -313 391 50 -313 minecraft:air
setblock 352 50 -314 minecraft:water[level=0]
setblock 381 50 -317 minecraft:water[level=0]
fill 383 50 -317 385 50 -317 minecraft:water[level=0]
fill 381 50 -318 386 50 -318 minecraft:water[level=0]
setblock 347 49 -263 minecraft:water[level=0]
setblock 347 49 -264 minecraft:water[level=0]
setblock 347 49 -265 minecraft:water[level=0]
setblock 348 49 -266 minecraft:water[level=0]
fill 347 49 -267 348 49 -267 minecraft:water[level=0]
fill 347 49 -268 348 49 -268 minecraft:water[level=0]
setblock 348 49 -269 minecraft:water[level=0]
setblock 348 49 -270 minecraft:water[level=0]
setblock 348 49 -271 minecraft:water[level=0]
setblock 350 49 -279 minecraft:water[level=0]
setblock 351 49 -281 minecraft:water[level=0]
setblock 351 49 -282 minecraft:water[level=0]
setblock 352 49 -283 minecraft:bubble_column[drag=true]
setblock 353 49 -283 minecraft:water[level=0]
fill 352 49 -284 355 49 -284 minecraft:water[level=0]
fill 352 49 -285 356 49 -285 minecraft:water[level=0]
fill 352 49 -286 356 49 -286 minecraft:water[level=0]
fill 353 49 -287 356 49 -287 minecraft:water[level=0]
fill 353 49 -288 357 49 -288 minecraft:water[level=0]
fill 353 49 -289 357 49 -289 minecraft:water[level=0]
fill 353 49 -290 357 49 -290 minecraft:water[level=0]
fill 353 49 -291 357 49 -291 minecraft:water[level=0]
fill 353 49 -292 354 49 -292 minecraft:water[level=0]
fill 353 49 -293 356 49 -293 minecraft:water[level=0]
fill 353 49 -294 357 49 -294 minecraft:water[level=0]
fill 354 49 -295 355 49 -295 minecraft:water[level=0]
setblock 356 49 -295 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=true,west=false]
setblock 356 49 -296 minecraft:water[level=0]
setblock 356 49 -297 minecraft:water[level=0]
setblock 391 49 -298 minecraft:water[level=0]
fill 390 49 -299 391 49 -299 minecraft:water[level=0]
fill 388 49 -300 391 49 -300 minecraft:water[level=0]
fill 387 49 -301 391 49 -301 minecraft:water[level=0]
fill 352 49 -302 354 49 -302 minecraft:water[level=0]
fill 377 49 -302 378 49 -302 minecraft:water[level=0]
fill 386 49 -302 391 49 -302 minecraft:water[level=0]
fill 352 49 -303 354 49 -303 minecraft:water[level=0]
setblock 375 49 -303 minecraft:air
setblock 376 49 -303 minecraft:water[level=8]
setblock 377 49 -303 minecraft:water[level=0]
setblock 380 49 -303 minecraft:water[level=0]
fill 385 49 -303 391 49 -303 minecraft:water[level=0]
fill 351 49 -304 354 49 -304 minecraft:water[level=0]
fill 375 49 -304 376 49 -304 minecraft:air
setblock 377 49 -304 minecraft:water[level=8]
fill 379 49 -304 381 49 -304 minecraft:water[level=0]
fill 384 49 -304 391 49 -304 minecraft:water[level=0]
fill 351 49 -305 354 49 -305 minecraft:water[level=0]
fill 375 49 -305 377 49 -305 minecraft:air
fill 379 49 -305 391 49 -305 minecraft:water[level=0]
fill 351 49 -306 353 49 -306 minecraft:water[level=0]
fill 375 49 -306 377 49 -306 minecraft:air
fill 381 49 -306 390 49 -306 minecraft:water[level=0]
fill 351 49 -307 353 49 -307 minecraft:water[level=0]
fill 375 49 -307 377 49 -307 minecraft:air
fill 350 49 -308 353 49 -308 minecraft:water[level=0]
fill 350 49 -309 352 49 -309 minecraft:water[level=0]
fill 382 49 -309 389 49 -309 minecraft:air
fill 350 49 -310 352 49 -310 minecraft:water[level=0]
fill 382 49 -310 390 49 -310 minecraft:air
setblock 352 49 -311 minecraft:water[level=0]
fill 382 49 -311 391 49 -311 minecraft:air
fill 381 49 -312 391 49 -312 minecraft:air
fill 381 49 -313 387 49 -313 minecraft:air
fill 390 49 -313 391 49 -313 minecraft:air
fill 382 49 -314 387 49 -314 minecraft:air
setblock 391 49 -314 minecraft:air
setblock 346 48 -264 minecraft:water[level=0]
setblock 347 48 -265 minecraft:water[level=0]
setblock 347 48 -267 minecraft:water[level=0]
setblock 347 48 -268 minecraft:water[level=0]
setblock 349 48 -276 minecraft:water[level=0]
fill 349 48 -277 350 48 -277 minecraft:water[level=0]
setblock 349 48 -278 minecraft:water[level=0]
setblock 351 48 -278 minecraft:water[level=0]
fill 349 48 -279 351 48 -279 minecraft:water[level=0]
fill 350 48 -280 353 48 -280 minecraft:water[level=0]
setblock 350 48 -281 minecraft:bubble_column[drag=true]
fill 351 48 -281 353 48 -281 minecraft:water[level=0]
fill 350 48 -282 351 48 -282 minecraft:water[level=0]
setblock 352 48 -282 minecraft:bubble_column[drag=true]
setblock 353 48 -282 minecraft:water[level=0]
setblock 351 48 -283 minecraft:water[level=0]
setblock 352 48 -283 minecraft:bubble_column[drag=true]
fill 353 48 -283 354 48 -283 minecraft:water[level=0]
fill 351 48 -284 354 48 -284 minecraft:water[level=0]
fill 351 48 -285 355 48 -285 minecraft:water[level=0]
fill 351 48 -286 355 48 -286 minecraft:water[level=0]
fill 352 48 -287 355 48 -287 minecraft:water[level=0]
fill 352 48 -288 356 48 -288 minecraft:water[level=0]
fill 352 48 -289 356 48 -289 minecraft:water[level=0]
fill 352 48 -290 356 48 -290 minecraft:water[level=0]
fill 352 48 -291 356 48 -291 minecraft:water[level=0]
fill 352 48 -292 353 48 -292 minecraft:water[level=0]
setblock 352 48 -293 minecraft:water[level=0]
fill 352 48 -294 354 48 -294 minecraft:water[level=0]
fill 352 48 -295 356 48 -295 minecraft:water[level=0]
fill 352 48 -296 356 48 -296 minecraft:water[level=0]
fill 352 48 -297 355 48 -297 minecraft:water[level=0]
fill 352 48 -298 355 48 -298 minecraft:water[level=0]
fill 352 48 -299 355 48 -299 minecraft:water[level=0]
setblock 390 48 -299 minecraft:water[level=0]
fill 352 48 -300 355 48 -300 minecraft:water[level=0]
fill 388 48 -300 391 48 -300 minecraft:water[level=0]
fill 351 48 -301 354 48 -301 minecraft:water[level=0]
fill 387 48 -301 391 48 -301 minecraft:water[level=0]
fill 351 48 -302 354 48 -302 minecraft:water[level=0]
fill 386 48 -302 391 48 -302 minecraft:water[level=0]
fill 351 48 -303 354 48 -303 minecraft:water[level=0]
setblock 375 48 -303 minecraft:air
fill 376 48 -303 377 48 -303 minecraft:water[level=8]
fill 385 48 -303 391 48 -303 minecraft:water[level=0]
fill 351 48 -304 353 48 -304 minecraft:water[level=0]
setblock 375 48 -304 minecraft:air
setblock 376 48 -304 minecraft:water[level=1]
setblock 377 48 -304 minecraft:water[level=8]
setblock 381 48 -304 minecraft:water[level=0]
fill 384 48 -304 391 48 -304 minecraft:water[level=0]
fill 350 48 -305 353 48 -305 minecraft:water[level=0]
fill 375 48 -305 377 48 -305 minecraft:air
fill 380 48 -305 391 48 -305 minecraft:water[level=0]
fill 350 48 -306 353 48 -306 minecraft:water[level=0]
fill 375 48 -306 377 48 -306 minecraft:air
fill 350 48 -307 352 48 -307 minecraft:water[level=0]
fill 375 48 -307 377 48 -307 minecraft:air
fill 351 48 -308 352 48 -308 minecraft:water[level=0]
fill 375 48 -308 377 48 -308 minecraft:air
fill 382 48 -308 388 48 -308 minecraft:air
fill 382 48 -309 389 48 -309 minecraft:air
fill 382 48 -310 390 48 -310 minecraft:air
fill 382 48 -311 391 48 -311 minecraft:air
fill 381 48 -312 391 48 -312 minecraft:air
fill 381 48 -313 387 48 -313 minecraft:air
fill 390 48 -313 391 48 -313 minecraft:air
fill 382 48 -314 387 48 -314 minecraft:air
setblock 391 48 -314 minecraft:air
fill 382 48 -315 387 48 -315 minecraft:air
fill 383 48 -316 387 48 -316 minecraft:air
setblock 381 48 -318 minecraft:water[level=0]
setblock 346 47 -264 minecraft:water[level=0]
setblock 346 47 -265 minecraft:water[level=0]
setblock 346 47 -266 minecraft:water[level=0]
setblock 346 47 -267 minecraft:water[level=0]
setblock 346 47 -268 minecraft:water[level=0]
setblock 346 47 -269 minecraft:water[level=0]
setblock 346 47 -270 minecraft:water[level=0]
setblock 349 47 -270 minecraft:lava[level=0]
setblock 349 47 -271 minecraft:lava[level=2]
setblock 349 47 -272 minecraft:lava[level=4]
setblock 349 47 -273 minecraft:lava[level=6]
fill 348 47 -276 349 47 -276 minecraft:water[level=0]
fill 348 47 -277 351 47 -277 minecraft:water[level=0]
fill 348 47 -278 349 47 -278 minecraft:water[level=0]
setblock 351 47 -278 minecraft:water[level=0]
fill 348 47 -279 351 47 -279 minecraft:water[level=0]
fill 349 47 -280 352 47 -280 minecraft:water[level=0]
setblock 349 47 -281 minecraft:water[level=0]
setblock 350 47 -281 minecraft:bubble_column[drag=true]
fill 351 47 -281 352 47 -281 minecraft:water[level=0]
fill 349 47 -282 351 47 -282 minecraft:water[level=0]
setblock 352 47 -282 minecraft:bubble_column[drag=true]
setblock 353 47 -282 minecraft:water[level=0]
fill 350 47 -283 351 47 -283 minecraft:water[level=0]
setblock 352 47 -283 minecraft:bubble_column[drag=true]
setblock 353 47 -283 minecraft:water[level=0]
fill 351 47 -284 354 47 -284 minecraft:water[level=0]
fill 351 47 -285 354 47 -285 minecraft:water[level=0]
fill 351 47 -286 354 47 -286 minecraft:water[level=0]
fill 351 47 -287 355 47 -287 minecraft:water[level=0]
fill 352 47 -288 354 47 -288 minecraft:water[level=0]
fill 352 47 -289 354 47 -289 minecraft:water[level=0]
fill 351 47 -290 354 47 -290 minecraft:water[level=0]
fill 351 47 -291 353 47 -291 minecraft:water[level=0]
setblock 352 47 -295 minecraft:water[level=0]
fill 352 47 -296 355 47 -296 minecraft:water[level=0]
fill 352 47 -297 355 47 -297 minecraft:water[level=0]
fill 351 47 -298 355 47 -298 minecraft:water[level=0]
fill 351 47 -299 355 47 -299 minecraft:water[level=0]
fill 390 47 -299 391 47 -299 minecraft:water[level=0]
fill 351 47 -300 355 47 -300 minecraft:water[level=0]
fill 389 47 -300 391 47 -300 minecraft:water[level=0]
fill 351 47 -301 354 47 -301 minecraft:water[level=0]
fill 387 47 -301 391 47 -301 minecraft:water[level=0]
fill 351 47 -302 354 47 -302 minecraft:water[level=0]
fill 386 47 -302 391 47 -302 minecraft:water[level=0]
fill 350 47 -303 354 47 -303 minecraft:water[level=0]
fill 385 47 -303 391 47 -303 minecraft:water[level=0]
fill 351 47 -304 353 47 -304 minecraft:water[level=0]
setblock 375 47 -304 minecraft:air
fill 376 47 -304 377 47 -304 minecraft:water[level=8]
fill 384 47 -304 391 47 -304 minecraft:water[level=0]
setblock 375 47 -305 minecraft:air
fill 376 47 -305 377 47 -305 minecraft:water[level=1]
fill 375 47 -306 377 47 -306 minecraft:air
fill 375 47 -307 377 47 -307 minecraft:air
fill 383 47 -307 390 47 -307 minecraft:water[level=0]
fill 375 47 -308 377 47 -308 minecraft:air
fill 382 47 -308 389 47 -308 minecraft:water[level=0]
fill 375 47 -309 377 47 -309 minecraft:air
fill 382 47 -309 388 47 -309 minecraft:water[level=0]
fill 382 47 -310 390 47 -310 minecraft:water[level=0]
fill 381 47 -311 391 47 -311 minecraft:water[level=0]
fill 381 47 -312 391 47 -312 minecraft:water[level=0]
fill 381 47 -313 387 47 -313 minecraft:water[level=0]
setblock 391 47 -313 minecraft:water[level=0]
fill 380 47 -314 387 47 -314 minecraft:water[level=0]
setblock 391 47 -314 minecraft:water[level=0]
setblock 380 47 -315 minecraft:water[level=0]
fill 382 47 -315 387 47 -315 minecraft:water[level=0]
setblock 380 47 -316 minecraft:water[level=0]
fill 383 47 -316 387 47 -316 minecraft:water[level=0]
fill 383 47 -317 387 47 -317 minecraft:water[level=0]
setblock 381 47 -318 minecraft:water[level=0]
fill 384 47 -318 387 47 -318 minecraft:water[level=0]
setblock 345 46 -268 minecraft:water[level=0]
setblock 348 46 -270 minecraft:air
setblock 348 46 -271 minecraft:air
setblock 348 46 -272 minecraft:air
setblock 348 46 -273 minecraft:air
setblock 349 46 -274 minecraft:air
fill 347 46 -277 350 46 -277 minecraft:water[level=0]
fill 348 46 -278 349 46 -278 minecraft:water[level=0]
fill 349 46 -279 351 46 -279 minecraft:water[level=0]
fill 350 46 -280 351 46 -280 minecraft:water[level=0]
setblock 350 46 -281 minecraft:bubble_column[drag=true]
setblock 351 46 -281 minecraft:water[level=0]
setblock 351 46 -282 minecraft:water[level=0]
setblock 352 46 -282 minecraft:bubble_column[drag=true]
setblock 352 46 -283 minecraft:bubble_column[drag=true]
setblock 375 46 -305 minecraft:air
fill 376 46 -305 377 46 -305 minecraft:water[level=8]
setblock 375 46 -306 minecraft:air
fill 376 46 -306 377 46 -306 minecraft:water[level=1]
fill 383 46 -306 390 46 -306 minecraft:water[level=0]
fill 375 46 -307 377 46 -307 minecraft:air
fill 383 46 -307 389 46 -307 minecraft:water[level=0]
fill 375 46 -308 377 46 -308 minecraft:air
fill 382 46 -308 389 46 -308 minecraft:water[level=0]
fill 375 46 -309 377 46 -309 minecraft:air
fill 382 46 -309 387 46 -309 minecraft:water[level=0]
fill 375 46 -310 377 46 -310 minecraft:air
fill 382 46 -310 390 46 -310 minecraft:water[level=0]
fill 381 46 -311 391 46 -311 minecraft:water[level=0]
fill 381 46 -312 390 46 -312 minecraft:water[level=0]
fill 381 46 -313 387 46 -313 minecraft:water[level=0]
fill 381 46 -314 387 46 -314 minecraft:water[level=0]
fill 380 46 -315 387 46 -315 minecraft:water[level=0]
fill 380 46 -316 387 46 -316 minecraft:water[level=0]
fill 381 46 -317 387 46 -317 minecraft:water[level=0]
fill 381 46 -318 387 46 -318 minecraft:water[level=0]
setblock 347 45 -263 minecraft:air
fill 346 45 -264 347 45 -264 minecraft:air
setblock 345 45 -265 minecraft:air
setblock 347 45 -265 minecraft:air
setblock 345 45 -266 minecraft:air
setblock 347 45 -267 minecraft:air
setblock 347 45 -268 minecraft:air
setblock 348 45 -273 minecraft:air
setblock 348 45 -274 minecraft:air
setblock 347 45 -290 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 386 45 -302 388 45 -302 minecraft:air
fill 385 45 -303 387 45 -303 minecraft:air
fill 387 45 -305 390 45 -305 minecraft:water[level=0]
setblock 375 45 -306 minecraft:air
fill 376 45 -306 377 45 -306 minecraft:water[level=8]
fill 385 45 -306 390 45 -306 minecraft:water[level=0]
setblock 375 45 -307 minecraft:air
fill 376 45 -307 377 45 -307 minecraft:water[level=1]
fill 386 45 -307 389 45 -307 minecraft:water[level=0]
fill 375 45 -308 377 45 -308 minecraft:air
fill 383 45 -308 385 45 -308 minecraft:water[level=0]
fill 375 45 -309 377 45 -309 minecraft:air
fill 382 45 -309 386 45 -309 minecraft:water[level=0]
fill 375 45 -310 377 45 -310 minecraft:air
fill 382 45 -310 387 45 -310 minecraft:water[level=0]
fill 375 45 -311 377 45 -311 minecraft:air
fill 381 45 -311 387 45 -311 minecraft:water[level=0]
fill 381 45 -312 387 45 -312 minecraft:water[level=0]
fill 381 45 -313 387 45 -313 minecraft:water[level=0]
fill 381 45 -314 387 45 -314 minecraft:water[level=0]
fill 381 45 -315 387 45 -315 minecraft:water[level=0]
fill 381 45 -316 387 45 -316 minecraft:water[level=0]
fill 381 45 -317 386 45 -317 minecraft:water[level=0]
fill 382 45 -318 386 45 -318 minecraft:water[level=0]
forceload remove 328 -318 391 -255
tellraw @a {"text":"Campus zurueck a20 fertig.","color":"green"}
