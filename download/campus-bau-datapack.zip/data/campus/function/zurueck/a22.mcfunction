# Abschnitt a22: x 8..71, z -254..-191 (19623 Blöcke)
forceload add 8 -254 71 -191
tellraw @a {"text":"Campus zurueck a22: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a22_1 2s
