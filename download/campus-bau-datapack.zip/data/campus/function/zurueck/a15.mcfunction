# Abschnitt a15: x 8..71, z -318..-255 (30808 Blöcke)
forceload add 8 -318 71 -255
tellraw @a {"text":"Campus zurueck a15: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a15_1 2s
