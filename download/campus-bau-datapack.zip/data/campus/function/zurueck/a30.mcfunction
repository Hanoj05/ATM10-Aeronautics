# Abschnitt a30: x 72..135, z -190..-127 (11937 Blöcke)
forceload add 72 -190 135 -127
tellraw @a {"text":"Campus zurueck a30: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a30_1 2s
