setblock 331 86 -195 minecraft:white_concrete
fill 330 86 -196 331 86 -196 minecraft:white_concrete
fill 333 86 -205 334 86 -205 minecraft:white_concrete
fill 334 86 -214 336 86 -214 minecraft:white_concrete
fill 334 86 -223 336 86 -223 minecraft:white_concrete
fill 334 86 -233 335 86 -233 minecraft:white_concrete
fill 331 86 -242 333 86 -242 minecraft:white_concrete
fill 328 86 -251 330 86 -251 minecraft:white_concrete
fill 332 85 -192 333 85 -192 minecraft:white_concrete
setblock 334 85 -195 minecraft:white_concrete
setblock 334 85 -197 minecraft:white_concrete
setblock 335 85 -200 minecraft:white_concrete
setblock 336 85 -203 minecraft:white_concrete
setblock 337 85 -206 minecraft:white_concrete
setblock 337 85 -209 minecraft:white_concrete
setblock 338 85 -212 minecraft:white_concrete
setblock 338 85 -215 minecraft:white_concrete
setblock 338 85 -218 minecraft:white_concrete
setblock 338 85 -221 minecraft:white_concrete
setblock 338 85 -225 minecraft:white_concrete
setblock 338 85 -230 minecraft:white_concrete
setblock 338 85 -231 minecraft:white_concrete
setblock 338 85 -232 minecraft:white_concrete
setblock 338 85 -233 minecraft:white_concrete
setblock 337 85 -234 minecraft:white_concrete
setblock 337 85 -235 minecraft:white_concrete
setblock 337 85 -236 minecraft:white_concrete
setblock 337 85 -237 minecraft:white_concrete
setblock 337 85 -238 minecraft:white_concrete
setblock 335 85 -243 minecraft:white_concrete
setblock 334 85 -247 minecraft:white_concrete
setblock 333 85 -249 minecraft:white_concrete
setblock 332 85 -251 minecraft:white_concrete
fill 348 66 -191 349 66 -191 minecraft:air
fill 351 66 -191 353 66 -191 minecraft:air
fill 356 66 -191 360 66 -191 minecraft:air
setblock 362 66 -191 minecraft:air
setblock 364 66 -191 minecraft:air
fill 370 66 -191 371 66 -191 minecraft:air
setblock 373 66 -191 minecraft:air
fill 377 66 -191 378 66 -191 minecraft:air
setblock 384 66 -191 minecraft:air
fill 389 66 -191 390 66 -191 minecraft:air
fill 348 66 -192 351 66 -192 minecraft:air
fill 355 66 -192 360 66 -192 minecraft:air
fill 362 66 -192 365 66 -192 minecraft:air
setblock 367 66 -192 minecraft:air
setblock 369 66 -192 minecraft:air
fill 374 66 -192 375 66 -192 minecraft:air
setblock 377 66 -192 minecraft:air
setblock 384 66 -192 minecraft:air
fill 386 66 -192 387 66 -192 minecraft:air
fill 348 66 -193 349 66 -193 minecraft:air
fill 351 66 -193 355 66 -193 minecraft:air
setblock 357 66 -193 minecraft:air
setblock 359 66 -193 minecraft:air
setblock 361 66 -193 minecraft:air
fill 363 66 -193 364 66 -193 minecraft:air
fill 366 66 -193 368 66 -193 minecraft:air
setblock 370 66 -193 minecraft:air
fill 372 66 -193 373 66 -193 minecraft:air
fill 375 66 -193 376 66 -193 minecraft:air
setblock 378 66 -193 minecraft:air
fill 385 66 -193 387 66 -193 minecraft:air
fill 389 66 -193 391 66 -193 minecraft:air
fill 350 66 -194 353 66 -194 minecraft:air
fill 355 66 -194 356 66 -194 minecraft:air
fill 362 66 -194 363 66 -194 minecraft:air
setblock 366 66 -194 minecraft:air
fill 369 66 -194 374 66 -194 minecraft:air
fill 376 66 -194 378 66 -194 minecraft:air
fill 385 66 -194 387 66 -194 minecraft:air
setblock 390 66 -194 minecraft:air
setblock 348 66 -195 minecraft:air
fill 351 66 -195 352 66 -195 minecraft:air
setblock 354 66 -195 minecraft:air
setblock 356 66 -195 minecraft:air
setblock 359 66 -195 minecraft:air
setblock 364 66 -195 minecraft:air
fill 368 66 -195 370 66 -195 minecraft:air
setblock 372 66 -195 minecraft:air
fill 374 66 -195 375 66 -195 minecraft:air
setblock 384 66 -195 minecraft:air
fill 387 66 -195 390 66 -195 minecraft:air
setblock 348 66 -196 minecraft:air
setblock 350 66 -196 minecraft:air
setblock 353 66 -196 minecraft:air
setblock 355 66 -196 minecraft:air
setblock 357 66 -196 minecraft:air
fill 359 66 -196 361 66 -196 minecraft:air
fill 363 66 -196 365 66 -196 minecraft:air
fill 367 66 -196 368 66 -196 minecraft:air
setblock 370 66 -196 minecraft:air
fill 374 66 -196 375 66 -196 minecraft:air
setblock 378 66 -196 minecraft:air
setblock 384 66 -196 minecraft:air
setblock 386 66 -196 minecraft:air
setblock 388 66 -196 minecraft:air
fill 349 66 -197 351 66 -197 minecraft:air
fill 353 66 -197 354 66 -197 minecraft:air
fill 359 66 -197 367 66 -197 minecraft:air
setblock 369 66 -197 minecraft:air
fill 371 66 -197 373 66 -197 minecraft:air
fill 376 66 -197 377 66 -197 minecraft:air
setblock 385 66 -197 minecraft:air
setblock 387 66 -197 minecraft:air
fill 389 66 -197 390 66 -197 minecraft:air
fill 350 66 -198 351 66 -198 minecraft:air
fill 354 66 -198 355 66 -198 minecraft:air
fill 358 66 -198 359 66 -198 minecraft:air
setblock 363 66 -198 minecraft:air
setblock 367 66 -198 minecraft:air
setblock 371 66 -198 minecraft:air
setblock 373 66 -198 minecraft:air
setblock 375 66 -198 minecraft:air
setblock 377 66 -198 minecraft:air
fill 385 66 -198 386 66 -198 minecraft:air
fill 389 66 -198 390 66 -198 minecraft:air
setblock 348 66 -199 minecraft:air
fill 354 66 -199 355 66 -199 minecraft:air
fill 358 66 -199 359 66 -199 minecraft:air
setblock 361 66 -199 minecraft:air
setblock 364 66 -199 minecraft:air
setblock 369 66 -199 minecraft:air
setblock 372 66 -199 minecraft:air
setblock 374 66 -199 minecraft:air
setblock 377 66 -199 minecraft:air
fill 384 66 -199 388 66 -199 minecraft:air
setblock 391 66 -199 minecraft:air
fill 349 66 -200 354 66 -200 minecraft:air
setblock 357 66 -200 minecraft:air
setblock 359 66 -200 minecraft:air
setblock 361 66 -200 minecraft:air
fill 363 66 -200 365 66 -200 minecraft:air
fill 368 66 -200 371 66 -200 minecraft:air
fill 374 66 -200 378 66 -200 minecraft:air
fill 384 66 -200 388 66 -200 minecraft:air
setblock 351 66 -201 minecraft:air
setblock 359 66 -201 minecraft:air
fill 361 66 -201 363 66 -201 minecraft:air
fill 366 66 -201 368 66 -201 minecraft:air
setblock 370 66 -201 minecraft:air
fill 372 66 -201 376 66 -201 minecraft:air
setblock 378 66 -201 minecraft:air
fill 389 66 -201 391 66 -201 minecraft:air
fill 349 66 -202 354 66 -202 minecraft:air
setblock 356 66 -202 minecraft:air
setblock 359 66 -202 minecraft:air
fill 362 66 -202 364 66 -202 minecraft:air
fill 366 66 -202 368 66 -202 minecraft:air
setblock 373 66 -202 minecraft:air
setblock 375 66 -202 minecraft:air
setblock 378 66 -202 minecraft:air
fill 385 66 -202 387 66 -202 minecraft:air
setblock 389 66 -202 minecraft:air
setblock 348 66 -203 minecraft:air
fill 351 66 -203 353 66 -203 minecraft:air
fill 355 66 -203 356 66 -203 minecraft:air
setblock 358 66 -203 minecraft:air
fill 360 66 -203 362 66 -203 minecraft:air
fill 364 66 -203 368 66 -203 minecraft:air
fill 370 66 -203 371 66 -203 minecraft:air
setblock 374 66 -203 minecraft:air
fill 377 66 -203 378 66 -203 minecraft:air
fill 384 66 -203 385 66 -203 minecraft:air
fill 388 66 -203 389 66 -203 minecraft:air
setblock 391 66 -203 minecraft:air
fill 349 66 -204 350 66 -204 minecraft:air
fill 352 66 -204 354 66 -204 minecraft:air
setblock 358 66 -204 minecraft:air
setblock 360 66 -204 minecraft:air
setblock 362 66 -204 minecraft:air
fill 365 66 -204 366 66 -204 minecraft:air
fill 368 66 -204 371 66 -204 minecraft:air
fill 373 66 -204 374 66 -204 minecraft:air
fill 386 66 -204 391 66 -204 minecraft:air
fill 348 66 -205 351 66 -205 minecraft:air
setblock 353 66 -205 minecraft:air
fill 355 66 -205 357 66 -205 minecraft:air
fill 359 66 -205 360 66 -205 minecraft:air
fill 362 66 -205 363 66 -205 minecraft:air
setblock 365 66 -205 minecraft:air
fill 368 66 -205 371 66 -205 minecraft:air
setblock 374 66 -205 minecraft:air
fill 377 66 -205 378 66 -205 minecraft:air
fill 384 66 -205 385 66 -205 minecraft:air
setblock 387 66 -205 minecraft:air
setblock 349 66 -206 minecraft:air
setblock 352 66 -206 minecraft:air
setblock 355 66 -206 minecraft:air
setblock 359 66 -206 minecraft:air
fill 364 66 -206 368 66 -206 minecraft:air
setblock 371 66 -206 minecraft:air
fill 376 66 -206 378 66 -206 minecraft:air
fill 385 66 -206 386 66 -206 minecraft:air
fill 388 66 -206 391 66 -206 minecraft:air
fill 348 66 -207 352 66 -207 minecraft:air
fill 354 66 -207 358 66 -207 minecraft:air
setblock 360 66 -207 minecraft:air
fill 362 66 -207 364 66 -207 minecraft:air
fill 368 66 -207 369 66 -207 minecraft:air
fill 372 66 -207 373 66 -207 minecraft:air
fill 375 66 -207 378 66 -207 minecraft:air
setblock 384 66 -207 minecraft:air
fill 386 66 -207 390 66 -207 minecraft:air
fill 348 66 -208 350 66 -208 minecraft:air
setblock 355 66 -208 minecraft:air
fill 358 66 -208 360 66 -208 minecraft:air
setblock 362 66 -208 minecraft:air
setblock 364 66 -208 minecraft:air
fill 368 66 -208 369 66 -208 minecraft:air
setblock 372 66 -208 minecraft:air
fill 374 66 -208 377 66 -208 minecraft:air
setblock 384 66 -208 minecraft:air
fill 388 66 -208 391 66 -208 minecraft:air
fill 348 66 -209 349 66 -209 minecraft:air
fill 352 66 -209 356 66 -209 minecraft:air
fill 359 66 -209 360 66 -209 minecraft:air
setblock 364 66 -209 minecraft:air
setblock 366 66 -209 minecraft:air
setblock 368 66 -209 minecraft:air
setblock 370 66 -209 minecraft:air
fill 373 66 -209 374 66 -209 minecraft:air
fill 376 66 -209 377 66 -209 minecraft:air
fill 384 66 -209 385 66 -209 minecraft:air
setblock 387 66 -209 minecraft:air
setblock 389 66 -209 minecraft:air
setblock 391 66 -209 minecraft:air
setblock 348 66 -210 minecraft:air
setblock 350 66 -210 minecraft:air
setblock 352 66 -210 minecraft:air
fill 354 66 -210 355 66 -210 minecraft:air
setblock 357 66 -210 minecraft:air
fill 359 66 -210 362 66 -210 minecraft:air
fill 364 66 -210 370 66 -210 minecraft:air
setblock 373 66 -210 minecraft:air
setblock 378 66 -210 minecraft:air
fill 386 66 -210 387 66 -210 minecraft:air
setblock 389 66 -210 minecraft:air
setblock 391 66 -210 minecraft:air
setblock 349 66 -211 minecraft:air
fill 352 66 -211 353 66 -211 minecraft:air
setblock 357 66 -211 minecraft:air
setblock 359 66 -211 minecraft:air
fill 361 66 -211 363 66 -211 minecraft:air
setblock 365 66 -211 minecraft:air
setblock 369 66 -211 minecraft:air
setblock 372 66 -211 minecraft:air
setblock 376 66 -211 minecraft:air
fill 386 66 -211 387 66 -211 minecraft:air
fill 389 66 -211 390 66 -211 minecraft:air
fill 348 66 -212 350 66 -212 minecraft:air
fill 352 66 -212 355 66 -212 minecraft:air
setblock 360 66 -212 minecraft:air
fill 362 66 -212 363 66 -212 minecraft:air
fill 366 66 -212 371 66 -212 minecraft:air
setblock 373 66 -212 minecraft:air
setblock 375 66 -212 minecraft:air
setblock 377 66 -212 minecraft:air
setblock 384 66 -212 minecraft:air
setblock 386 66 -212 minecraft:air
fill 388 66 -212 389 66 -212 minecraft:air
setblock 349 66 -213 minecraft:air
setblock 351 66 -213 minecraft:air
fill 353 66 -213 355 66 -213 minecraft:air
fill 357 66 -213 358 66 -213 minecraft:air
fill 361 66 -213 362 66 -213 minecraft:air
setblock 365 66 -213 minecraft:air
setblock 368 66 -213 minecraft:air
fill 370 66 -213 376 66 -213 minecraft:air
fill 384 66 -213 385 66 -213 minecraft:air
fill 387 66 -213 388 66 -213 minecraft:air
fill 390 66 -213 391 66 -213 minecraft:air
fill 349 66 -214 352 66 -214 minecraft:air
fill 354 66 -214 355 66 -214 minecraft:air
setblock 357 66 -214 minecraft:air
fill 362 66 -214 363 66 -214 minecraft:air
fill 365 66 -214 371 66 -214 minecraft:air
fill 373 66 -214 374 66 -214 minecraft:air
fill 376 66 -214 377 66 -214 minecraft:air
setblock 384 66 -214 minecraft:air
fill 389 66 -214 390 66 -214 minecraft:air
fill 348 66 -215 350 66 -215 minecraft:air
fill 352 66 -215 353 66 -215 minecraft:air
fill 355 66 -215 362 66 -215 minecraft:air
setblock 365 66 -215 minecraft:air
fill 368 66 -215 371 66 -215 minecraft:air
setblock 373 66 -215 minecraft:air
fill 375 66 -215 377 66 -215 minecraft:air
fill 386 66 -215 391 66 -215 minecraft:air
fill 351 66 -216 354 66 -216 minecraft:air
fill 356 66 -216 358 66 -216 minecraft:air
setblock 360 66 -216 minecraft:air
fill 363 66 -216 364 66 -216 minecraft:air
fill 366 66 -216 370 66 -216 minecraft:air
setblock 374 66 -216 minecraft:air
fill 376 66 -216 378 66 -216 minecraft:air
setblock 386 66 -216 minecraft:air
fill 388 66 -216 390 66 -216 minecraft:air
setblock 349 66 -217 minecraft:air
setblock 351 66 -217 minecraft:air
fill 353 66 -217 355 66 -217 minecraft:air
setblock 358 66 -217 minecraft:air
fill 366 66 -217 368 66 -217 minecraft:air
fill 370 66 -217 373 66 -217 minecraft:air
fill 375 66 -217 376 66 -217 minecraft:air
setblock 378 66 -217 minecraft:air
fill 384 66 -217 389 66 -217 minecraft:air
fill 348 66 -218 349 66 -218 minecraft:air
fill 353 66 -218 355 66 -218 minecraft:air
setblock 358 66 -218 minecraft:air
fill 360 66 -218 361 66 -218 minecraft:air
setblock 363 66 -218 minecraft:air
fill 365 66 -218 368 66 -218 minecraft:air
fill 372 66 -218 373 66 -218 minecraft:air
setblock 377 66 -218 minecraft:air
setblock 384 66 -218 minecraft:air
setblock 389 66 -218 minecraft:air
fill 348 66 -219 350 66 -219 minecraft:air
fill 354 66 -219 357 66 -219 minecraft:air
fill 359 66 -219 364 66 -219 minecraft:air
setblock 369 66 -219 minecraft:air
setblock 372 66 -219 minecraft:air
setblock 375 66 -219 minecraft:air
setblock 378 66 -219 minecraft:air
setblock 385 66 -219 minecraft:air
setblock 387 66 -219 minecraft:air
setblock 390 66 -219 minecraft:air
fill 349 66 -220 350 66 -220 minecraft:air
fill 353 66 -220 360 66 -220 minecraft:air
setblock 364 66 -220 minecraft:air
fill 366 66 -220 368 66 -220 minecraft:air
fill 370 66 -220 373 66 -220 minecraft:air
setblock 376 66 -220 minecraft:air
fill 384 66 -220 385 66 -220 minecraft:air
fill 390 66 -220 391 66 -220 minecraft:air
fill 348 66 -221 349 66 -221 minecraft:air
fill 351 66 -221 352 66 -221 minecraft:air
setblock 356 66 -221 minecraft:air
setblock 358 66 -221 minecraft:air
setblock 362 66 -221 minecraft:air
fill 364 66 -221 366 66 -221 minecraft:air
setblock 369 66 -221 minecraft:air
fill 371 66 -221 374 66 -221 minecraft:air
setblock 376 66 -221 minecraft:air
setblock 378 66 -221 minecraft:air
setblock 386 66 -221 minecraft:air
fill 389 66 -221 390 66 -221 minecraft:air
setblock 348 66 -222 minecraft:air
fill 351 66 -222 353 66 -222 minecraft:air
fill 355 66 -222 356 66 -222 minecraft:air
fill 358 66 -222 361 66 -222 minecraft:air
setblock 363 66 -222 minecraft:air
fill 366 66 -222 367 66 -222 minecraft:air
fill 372 66 -222 374 66 -222 minecraft:air
setblock 376 66 -222 minecraft:air
fill 384 66 -222 385 66 -222 minecraft:air
fill 387 66 -222 388 66 -222 minecraft:air
setblock 349 66 -223 minecraft:air
setblock 351 66 -223 minecraft:air
setblock 354 66 -223 minecraft:air
setblock 356 66 -223 minecraft:air
fill 358 66 -223 361 66 -223 minecraft:air
setblock 363 66 -223 minecraft:air
fill 365 66 -223 366 66 -223 minecraft:air
setblock 369 66 -223 minecraft:air
setblock 372 66 -223 minecraft:air
fill 376 66 -223 377 66 -223 minecraft:air
fill 384 66 -223 386 66 -223 minecraft:air
fill 388 66 -223 389 66 -223 minecraft:air
setblock 348 66 -224 minecraft:air
fill 351 66 -224 358 66 -224 minecraft:air
fill 360 66 -224 361 66 -224 minecraft:air
setblock 365 66 -224 minecraft:air
fill 367 66 -224 370 66 -224 minecraft:air
fill 372 66 -224 373 66 -224 minecraft:air
setblock 375 66 -224 minecraft:air
fill 377 66 -224 378 66 -224 minecraft:air
setblock 385 66 -224 minecraft:air
fill 387 66 -224 388 66 -224 minecraft:air
setblock 391 66 -224 minecraft:air
fill 350 66 -225 351 66 -225 minecraft:air
fill 353 66 -225 354 66 -225 minecraft:air
fill 358 66 -225 362 66 -225 minecraft:air
fill 364 66 -225 370 66 -225 minecraft:air
fill 374 66 -225 377 66 -225 minecraft:air
fill 384 66 -225 388 66 -225 minecraft:air
fill 390 66 -225 391 66 -225 minecraft:air
fill 348 66 -226 349 66 -226 minecraft:air
setblock 351 66 -226 minecraft:air
fill 354 66 -226 355 66 -226 minecraft:air
fill 359 66 -226 361 66 -226 minecraft:air
setblock 363 66 -226 minecraft:air
setblock 366 66 -226 minecraft:air
fill 368 66 -226 371 66 -226 minecraft:air
fill 373 66 -226 374 66 -226 minecraft:air
setblock 377 66 -226 minecraft:air
fill 385 66 -226 386 66 -226 minecraft:air
fill 388 66 -226 389 66 -226 minecraft:air
setblock 391 66 -226 minecraft:air
setblock 351 66 -227 minecraft:air
fill 353 66 -227 354 66 -227 minecraft:air
fill 356 66 -227 357 66 -227 minecraft:air
setblock 360 66 -227 minecraft:air
fill 364 66 -227 365 66 -227 minecraft:air
fill 367 66 -227 368 66 -227 minecraft:air
setblock 371 66 -227 minecraft:air
fill 373 66 -227 374 66 -227 minecraft:air
fill 376 66 -227 378 66 -227 minecraft:air
fill 385 66 -227 386 66 -227 minecraft:air
fill 389 66 -227 391 66 -227 minecraft:air
fill 349 66 -228 351 66 -228 minecraft:air
setblock 354 66 -228 minecraft:air
fill 358 66 -228 359 66 -228 minecraft:air
fill 363 66 -228 364 66 -228 minecraft:air
setblock 366 66 -228 minecraft:air
setblock 369 66 -228 minecraft:air
setblock 371 66 -228 minecraft:air
fill 373 66 -228 374 66 -228 minecraft:air
setblock 388 66 -228 minecraft:air
fill 390 66 -228 391 66 -228 minecraft:air
setblock 348 66 -229 minecraft:air
setblock 350 66 -229 minecraft:air
setblock 352 66 -229 minecraft:air
setblock 355 66 -229 minecraft:air
setblock 357 66 -229 minecraft:air
fill 360 66 -229 361 66 -229 minecraft:air
setblock 363 66 -229 minecraft:air
setblock 367 66 -229 minecraft:air
fill 369 66 -229 373 66 -229 minecraft:air
setblock 375 66 -229 minecraft:air
fill 377 66 -229 378 66 -229 minecraft:air
setblock 384 66 -229 minecraft:air
fill 386 66 -229 388 66 -229 minecraft:air
setblock 391 66 -229 minecraft:air
fill 348 66 -230 349 66 -230 minecraft:air
setblock 352 66 -230 minecraft:air
fill 354 66 -230 356 66 -230 minecraft:air
setblock 358 66 -230 minecraft:air
fill 360 66 -230 362 66 -230 minecraft:air
setblock 364 66 -230 minecraft:air
fill 366 66 -230 367 66 -230 minecraft:air
setblock 370 66 -230 minecraft:air
setblock 375 66 -230 minecraft:air
setblock 378 66 -230 minecraft:air
fill 384 66 -230 386 66 -230 minecraft:air
setblock 388 66 -230 minecraft:air
setblock 391 66 -230 minecraft:air
fill 349 66 -231 350 66 -231 minecraft:air
fill 353 66 -231 354 66 -231 minecraft:air
setblock 356 66 -231 minecraft:air
setblock 358 66 -231 minecraft:air
fill 361 66 -231 362 66 -231 minecraft:air
setblock 366 66 -231 minecraft:air
setblock 368 66 -231 minecraft:air
fill 370 66 -231 373 66 -231 minecraft:air
setblock 376 66 -231 minecraft:air
setblock 378 66 -231 minecraft:air
setblock 384 66 -231 minecraft:air
setblock 387 66 -231 minecraft:air
setblock 391 66 -231 minecraft:air
fill 350 66 -232 352 66 -232 minecraft:air
fill 354 66 -232 359 66 -232 minecraft:air
fill 362 66 -232 363 66 -232 minecraft:air
fill 365 66 -232 374 66 -232 minecraft:air
setblock 384 66 -232 minecraft:air
fill 389 66 -232 390 66 -232 minecraft:air
fill 349 66 -233 352 66 -233 minecraft:air
fill 354 66 -233 357 66 -233 minecraft:air
fill 360 66 -233 361 66 -233 minecraft:air
setblock 365 66 -233 minecraft:air
fill 367 66 -233 368 66 -233 minecraft:air
fill 374 66 -233 376 66 -233 minecraft:air
setblock 378 66 -233 minecraft:air
setblock 384 66 -233 minecraft:air
setblock 388 66 -233 minecraft:air
setblock 391 66 -233 minecraft:air
setblock 348 66 -234 minecraft:air
fill 350 66 -234 352 66 -234 minecraft:air
fill 356 66 -234 361 66 -234 minecraft:air
fill 368 66 -234 369 66 -234 minecraft:air
fill 372 66 -234 374 66 -234 minecraft:air
setblock 389 66 -234 minecraft:air
setblock 391 66 -234 minecraft:air
fill 342 65 -191 391 65 -191 minecraft:air
fill 342 65 -192 391 65 -192 minecraft:air
fill 343 65 -193 391 65 -193 minecraft:air
fill 343 65 -194 391 65 -194 minecraft:air
fill 343 65 -195 391 65 -195 minecraft:air
fill 344 65 -196 391 65 -196 minecraft:air
fill 344 65 -197 391 65 -197 minecraft:air
fill 344 65 -198 391 65 -198 minecraft:air
fill 345 65 -199 391 65 -199 minecraft:air
fill 345 65 -200 391 65 -200 minecraft:air
fill 345 65 -201 391 65 -201 minecraft:air
fill 345 65 -202 391 65 -202 minecraft:air
fill 346 65 -203 391 65 -203 minecraft:air
fill 346 65 -204 391 65 -204 minecraft:air
fill 346 65 -205 391 65 -205 minecraft:air
fill 346 65 -206 391 65 -206 minecraft:air
fill 346 65 -207 391 65 -207 minecraft:air
fill 346 65 -208 391 65 -208 minecraft:air
fill 347 65 -209 391 65 -209 minecraft:air
fill 347 65 -210 391 65 -210 minecraft:air
fill 347 65 -211 391 65 -211 minecraft:air
fill 347 65 -212 391 65 -212 minecraft:air
fill 347 65 -213 391 65 -213 minecraft:air
fill 347 65 -214 391 65 -214 minecraft:air
fill 347 65 -215 350 65 -215 minecraft:air
setblock 354 65 -215 minecraft:air
setblock 355 65 -215 regions_unexplored:grass_sprouts
fill 356 65 -215 391 65 -215 minecraft:air
fill 347 65 -216 350 65 -216 minecraft:stone
fill 357 65 -216 391 65 -216 minecraft:air
fill 347 65 -217 350 65 -217 minecraft:stone
fill 357 65 -217 374 65 -217 minecraft:air
fill 377 65 -217 391 65 -217 minecraft:air
setblock 357 65 -218 minecraft:coarse_dirt
fill 358 65 -218 373 65 -218 minecraft:air
fill 379 65 -218 380 65 -218 minecraft:grass_block[snowy=false]
fill 381 65 -218 391 65 -218 minecraft:air
setblock 358 65 -219 minecraft:coarse_dirt
fill 359 65 -219 370 65 -219 minecraft:air
setblock 373 65 -219 minecraft:air
setblock 376 65 -219 minecraft:stone
fill 379 65 -219 383 65 -219 minecraft:grass_block[snowy=false]
fill 385 65 -219 391 65 -219 minecraft:air
fill 357 65 -220 358 65 -220 minecraft:stone
setblock 359 65 -220 minecraft:coarse_dirt
setblock 360 65 -220 regions_unexplored:grass_sprouts
fill 361 65 -220 370 65 -220 minecraft:air
fill 379 65 -220 383 65 -220 minecraft:grass_block[snowy=false]
fill 386 65 -220 391 65 -220 minecraft:air
fill 355 65 -221 359 65 -221 minecraft:stone
fill 363 65 -221 369 65 -221 minecraft:air
fill 379 65 -221 383 65 -221 minecraft:grass_block[snowy=false]
fill 387 65 -221 391 65 -221 minecraft:air
fill 353 65 -222 360 65 -222 minecraft:stone
fill 379 65 -222 383 65 -222 minecraft:grass_block[snowy=false]
fill 388 65 -222 391 65 -222 minecraft:air
fill 353 65 -223 358 65 -223 minecraft:stone
fill 359 65 -223 360 65 -223 minecraft:deepslate[axis=y]
fill 379 65 -223 383 65 -223 minecraft:grass_block[snowy=false]
fill 353 65 -224 355 65 -224 minecraft:stone
fill 358 65 -224 365 65 -224 minecraft:deepslate[axis=y]
setblock 366 65 -224 minecraft:stone
setblock 372 65 -224 minecraft:coarse_dirt
fill 379 65 -224 383 65 -224 minecraft:grass_block[snowy=false]
fill 358 65 -225 359 65 -225 minecraft:deepslate[axis=y]
fill 360 65 -225 362 65 -225 minecraft:calcite
fill 363 65 -225 366 65 -225 minecraft:stone
fill 367 65 -225 368 65 -225 alltheores:zinc_ore
fill 379 65 -225 383 65 -225 minecraft:grass_block[snowy=false]
setblock 359 65 -226 minecraft:calcite
fill 364 65 -226 365 65 -226 minecraft:stone
fill 366 65 -226 368 65 -226 alltheores:zinc_ore
fill 379 65 -226 383 65 -226 minecraft:grass_block[snowy=false]
setblock 367 65 -227 alltheores:zinc_ore
fill 379 65 -227 383 65 -227 minecraft:grass_block[snowy=false]
fill 379 65 -228 383 65 -228 minecraft:grass_block[snowy=false]
fill 379 65 -229 383 65 -229 minecraft:grass_block[snowy=false]
fill 379 65 -230 383 65 -230 minecraft:grass_block[snowy=false]
fill 379 65 -231 383 65 -231 minecraft:grass_block[snowy=false]
fill 379 65 -232 383 65 -232 minecraft:grass_block[snowy=false]
fill 379 65 -233 383 65 -233 minecraft:grass_block[snowy=false]
fill 379 65 -234 383 65 -234 minecraft:grass_block[snowy=false]
fill 379 65 -235 383 65 -235 minecraft:grass_block[snowy=false]
fill 379 65 -236 383 65 -236 minecraft:grass_block[snowy=false]
fill 379 65 -237 383 65 -237 minecraft:grass_block[snowy=false]
fill 379 65 -238 383 65 -238 minecraft:grass_block[snowy=false]
fill 379 65 -239 383 65 -239 minecraft:grass_block[snowy=false]
fill 379 65 -240 383 65 -240 minecraft:grass_block[snowy=false]
fill 379 65 -241 383 65 -241 minecraft:grass_block[snowy=false]
fill 379 65 -242 383 65 -242 minecraft:grass_block[snowy=false]
fill 380 65 -243 382 65 -243 minecraft:grass_block[snowy=false]
fill 328 64 -191 391 64 -191 minecraft:air
fill 328 64 -192 391 64 -192 minecraft:air
fill 328 64 -193 391 64 -193 minecraft:air
fill 328 64 -194 391 64 -194 minecraft:air
fill 328 64 -195 391 64 -195 minecraft:air
fill 328 64 -196 391 64 -196 minecraft:air
fill 328 64 -197 391 64 -197 minecraft:air
fill 328 64 -198 391 64 -198 minecraft:air
fill 328 64 -199 391 64 -199 minecraft:air
fill 333 64 -200 391 64 -200 minecraft:air
fill 333 64 -201 391 64 -201 minecraft:air
fill 334 64 -202 391 64 -202 minecraft:air
fill 337 64 -203 391 64 -203 minecraft:air
fill 337 64 -204 391 64 -204 minecraft:air
fill 338 64 -205 391 64 -205 minecraft:air
fill 338 64 -206 391 64 -206 minecraft:air
fill 341 64 -207 391 64 -207 minecraft:air
fill 341 64 -208 391 64 -208 minecraft:air
fill 342 64 -209 391 64 -209 minecraft:air
fill 342 64 -210 391 64 -210 minecraft:air
fill 343 64 -211 391 64 -211 minecraft:air
fill 345 64 -212 391 64 -212 minecraft:air
fill 345 64 -213 391 64 -213 minecraft:air
fill 346 64 -214 391 64 -214 minecraft:air
setblock 348 64 -215 minecraft:air
fill 356 64 -215 391 64 -215 minecraft:air
fill 357 64 -216 375 64 -216 minecraft:air
fill 377 64 -216 391 64 -216 minecraft:air
fill 358 64 -217 372 64 -217 minecraft:air
fill 378 64 -217 391 64 -217 minecraft:air
fill 359 64 -218 371 64 -218 minecraft:air
fill 381 64 -218 391 64 -218 minecraft:air
fill 360 64 -219 370 64 -219 minecraft:air
fill 385 64 -219 391 64 -219 minecraft:air
fill 362 64 -220 369 64 -220 minecraft:air
setblock 386 64 -220 regions_unexplored:grass_sprouts
fill 387 64 -220 391 64 -220 minecraft:air
fill 367 64 -221 368 64 -221 minecraft:air
fill 387 64 -221 391 64 -221 minecraft:air
fill 388 64 -222 391 64 -222 minecraft:air
setblock 328 64 -223 minecraft:air
setblock 373 64 -223 minecraft:air
fill 328 64 -224 329 64 -224 minecraft:air
fill 373 64 -224 374 64 -224 minecraft:air
fill 328 64 -225 331 64 -225 minecraft:air
fill 373 64 -225 374 64 -225 minecraft:air
fill 328 64 -226 332 64 -226 minecraft:air
setblock 356 64 -226 minecraft:air
setblock 358 64 -226 minecraft:air
fill 372 64 -226 374 64 -226 minecraft:air
fill 328 64 -227 333 64 -227 minecraft:air
setblock 355 64 -227 minecraft:air
fill 372 64 -227 374 64 -227 minecraft:air
setblock 328 64 -228 minecraft:air
fill 332 64 -228 333 64 -228 minecraft:air
fill 351 64 -228 352 64 -228 minecraft:air
fill 354 64 -228 356 64 -228 minecraft:air
fill 372 64 -228 374 64 -228 minecraft:air
setblock 332 64 -229 minecraft:air
fill 350 64 -229 357 64 -229 minecraft:air
fill 372 64 -229 373 64 -229 minecraft:air
fill 352 64 -230 360 64 -230 minecraft:air
fill 371 64 -230 372 64 -230 minecraft:air
setblock 352 64 -231 minecraft:air
fill 355 64 -231 360 64 -231 minecraft:air
fill 369 64 -231 371 64 -231 minecraft:air
fill 355 64 -232 370 64 -232 minecraft:air
fill 355 64 -233 359 64 -233 minecraft:air
fill 361 64 -233 368 64 -233 minecraft:air
setblock 370 64 -233 minecraft:air
fill 354 64 -234 357 64 -234 minecraft:air
fill 360 64 -234 362 64 -234 minecraft:air
fill 354 64 -235 357 64 -235 minecraft:air
fill 359 64 -235 360 64 -235 minecraft:air
fill 354 64 -236 358 64 -236 minecraft:air
setblock 391 64 -254 minecraft:air
fill 328 63 -191 329 63 -191 minecraft:air
setblock 330 63 -191 regions_unexplored:grass_sprouts
fill 331 63 -191 391 63 -191 minecraft:air
fill 328 63 -192 391 63 -192 minecraft:air
setblock 328 63 -193 minecraft:air
fill 330 63 -193 391 63 -193 minecraft:air
fill 330 63 -194 391 63 -194 minecraft:air
fill 330 63 -195 391 63 -195 minecraft:air
fill 330 63 -196 391 63 -196 minecraft:air
fill 331 63 -197 391 63 -197 minecraft:air
setblock 328 63 -198 minecraft:air
fill 333 63 -198 391 63 -198 minecraft:air
setblock 328 63 -199 minecraft:air
fill 334 63 -199 391 63 -199 minecraft:air
fill 335 63 -200 391 63 -200 minecraft:air
fill 336 63 -201 391 63 -201 minecraft:air
setblock 337 63 -202 regions_unexplored:grass_sprouts
fill 338 63 -202 391 63 -202 minecraft:air
fill 338 63 -203 391 63 -203 minecraft:air
setblock 338 63 -204 minecraft:short_grass
fill 339 63 -204 391 63 -204 minecraft:air
fill 339 63 -205 391 63 -205 minecraft:air
fill 341 63 -206 391 63 -206 minecraft:air
fill 342 63 -207 391 63 -207 minecraft:air
fill 342 63 -208 391 63 -208 minecraft:air
fill 343 63 -209 391 63 -209 minecraft:air
fill 343 63 -210 391 63 -210 minecraft:air
fill 344 63 -211 391 63 -211 minecraft:air
fill 346 63 -212 391 63 -212 minecraft:air
fill 346 63 -213 391 63 -213 minecraft:air
fill 348 63 -214 349 63 -214 minecraft:air
fill 356 63 -214 375 63 -214 minecraft:air
fill 378 63 -214 391 63 -214 minecraft:air
fill 358 63 -215 374 63 -215 minecraft:air
fill 378 63 -215 391 63 -215 minecraft:air
fill 359 63 -216 373 63 -216 minecraft:air
fill 378 63 -216 391 63 -216 minecraft:air
fill 359 63 -217 371 63 -217 minecraft:air
fill 379 63 -217 391 63 -217 minecraft:air
fill 360 63 -218 369 63 -218 minecraft:air
fill 383 63 -218 391 63 -218 minecraft:air
fill 362 63 -219 369 63 -219 minecraft:air
fill 386 63 -219 391 63 -219 minecraft:air
fill 364 63 -220 368 63 -220 minecraft:air
fill 387 63 -220 391 63 -220 minecraft:air
fill 387 63 -221 391 63 -221 minecraft:air
fill 388 63 -222 391 63 -222 minecraft:air
fill 328 63 -223 329 63 -223 minecraft:air
fill 328 63 -224 330 63 -224 minecraft:air
fill 328 63 -225 331 63 -225 minecraft:air
setblock 373 63 -225 minecraft:air
fill 328 63 -226 332 63 -226 minecraft:air
fill 355 63 -226 356 63 -226 minecraft:air
setblock 373 63 -226 minecraft:air
fill 328 63 -227 333 63 -227 minecraft:air
fill 352 63 -227 355 63 -227 minecraft:air
fill 372 63 -227 373 63 -227 minecraft:air
fill 328 63 -228 329 63 -228 minecraft:air
fill 332 63 -228 333 63 -228 minecraft:air
fill 351 63 -228 354 63 -228 minecraft:air
fill 371 63 -228 373 63 -228 minecraft:air
fill 352 63 -229 357 63 -229 minecraft:air
fill 367 63 -229 369 63 -229 minecraft:air
fill 371 63 -229 373 63 -229 minecraft:air
setblock 352 63 -230 minecraft:air
fill 355 63 -230 360 63 -230 minecraft:air
fill 367 63 -230 369 63 -230 minecraft:air
fill 371 63 -230 373 63 -230 minecraft:air
fill 355 63 -231 372 63 -231 minecraft:air
fill 355 63 -232 358 63 -232 minecraft:air
fill 360 63 -232 368 63 -232 minecraft:air
fill 370 63 -232 371 63 -232 minecraft:air
fill 355 63 -233 357 63 -233 minecraft:air
setblock 370 63 -233 minecraft:air
fill 355 63 -234 357 63 -234 minecraft:air
setblock 369 63 -234 minecraft:air
fill 349 63 -235 350 63 -235 minecraft:air
fill 354 63 -235 356 63 -235 minecraft:air
fill 349 63 -236 350 63 -236 minecraft:air
setblock 368 63 -236 minecraft:air
fill 331 62 -191 359 62 -191 minecraft:water[level=0]
setblock 360 62 -191 minecraft:kelp[age=24]
fill 361 62 -191 364 62 -191 minecraft:water[level=0]
setblock 365 62 -191 minecraft:kelp[age=25]
fill 366 62 -191 369 62 -191 minecraft:water[level=0]
setblock 370 62 -191 minecraft:kelp[age=23]
setblock 371 62 -191 minecraft:kelp[age=24]
setblock 372 62 -191 minecraft:water[level=0]
setblock 373 62 -191 minecraft:kelp[age=22]
setblock 374 62 -191 minecraft:water[level=0]
setblock 375 62 -191 minecraft:kelp[age=23]
fill 376 62 -191 377 62 -191 minecraft:water[level=0]
setblock 378 62 -191 minecraft:kelp[age=21]
fill 379 62 -191 384 62 -191 minecraft:water[level=0]
setblock 385 62 -191 minecraft:kelp[age=24]
fill 386 62 -191 391 62 -191 minecraft:water[level=0]
fill 331 62 -192 348 62 -192 minecraft:water[level=0]
setblock 349 62 -192 minecraft:kelp[age=24]
fill 350 62 -192 361 62 -192 minecraft:water[level=0]
setblock 362 62 -192 minecraft:kelp[age=24]
setblock 363 62 -192 minecraft:water[level=0]
setblock 364 62 -192 minecraft:kelp[age=24]
fill 365 62 -192 366 62 -192 minecraft:water[level=0]
setblock 367 62 -192 minecraft:kelp[age=24]
fill 368 62 -192 376 62 -192 minecraft:water[level=0]
setblock 377 62 -192 minecraft:kelp[age=25]
setblock 378 62 -192 minecraft:water[level=0]
setblock 379 62 -192 minecraft:kelp[age=23]
setblock 380 62 -192 minecraft:kelp[age=25]
fill 381 62 -192 382 62 -192 minecraft:water[level=0]
setblock 383 62 -192 minecraft:kelp[age=22]
fill 384 62 -192 391 62 -192 minecraft:water[level=0]
fill 331 62 -193 351 62 -193 minecraft:water[level=0]
setblock 352 62 -193 minecraft:kelp[age=25]
fill 353 62 -193 369 62 -193 minecraft:water[level=0]
setblock 370 62 -193 minecraft:kelp[age=24]
setblock 371 62 -193 minecraft:kelp[age=25]
setblock 372 62 -193 minecraft:kelp[age=21]
fill 373 62 -193 381 62 -193 minecraft:water[level=0]
setblock 382 62 -193 minecraft:kelp[age=24]
setblock 383 62 -193 minecraft:kelp[age=25]
fill 384 62 -193 391 62 -193 minecraft:water[level=0]
fill 331 62 -194 358 62 -194 minecraft:water[level=0]
setblock 359 62 -194 minecraft:kelp[age=25]
fill 360 62 -194 379 62 -194 minecraft:water[level=0]
setblock 380 62 -194 minecraft:kelp[age=24]
fill 381 62 -194 391 62 -194 minecraft:water[level=0]
fill 331 62 -195 366 62 -195 minecraft:water[level=0]
setblock 367 62 -195 minecraft:kelp[age=25]
fill 368 62 -195 369 62 -195 minecraft:water[level=0]
setblock 370 62 -195 minecraft:kelp[age=25]
setblock 371 62 -195 minecraft:kelp[age=21]
setblock 372 62 -195 minecraft:kelp[age=22]
setblock 373 62 -195 minecraft:kelp[age=24]
setblock 374 62 -195 minecraft:water[level=0]
setblock 375 62 -195 minecraft:kelp[age=24]
fill 376 62 -195 377 62 -195 minecraft:water[level=0]
setblock 378 62 -195 minecraft:kelp[age=21]
fill 379 62 -195 391 62 -195 minecraft:water[level=0]
fill 331 62 -196 362 62 -196 minecraft:water[level=0]
setblock 363 62 -196 minecraft:kelp[age=24]
setblock 364 62 -196 minecraft:water[level=0]
setblock 365 62 -196 minecraft:kelp[age=23]
fill 366 62 -196 369 62 -196 minecraft:water[level=0]
setblock 370 62 -196 minecraft:kelp[age=22]
setblock 371 62 -196 minecraft:water[level=0]
setblock 372 62 -196 minecraft:kelp[age=25]
fill 373 62 -196 377 62 -196 minecraft:water[level=0]
setblock 378 62 -196 minecraft:kelp[age=23]
fill 379 62 -196 380 62 -196 minecraft:water[level=0]
setblock 381 62 -196 minecraft:kelp[age=22]
fill 382 62 -196 391 62 -196 minecraft:water[level=0]
fill 333 62 -197 359 62 -197 minecraft:water[level=0]
setblock 360 62 -197 minecraft:kelp[age=24]
fill 361 62 -197 371 62 -197 minecraft:water[level=0]
setblock 372 62 -197 minecraft:kelp[age=24]
fill 373 62 -197 377 62 -197 minecraft:water[level=0]
fill 378 62 -197 379 62 -197 minecraft:kelp[age=22]
fill 380 62 -197 383 62 -197 minecraft:water[level=0]
setblock 384 62 -197 minecraft:kelp[age=21]
fill 385 62 -197 391 62 -197 minecraft:water[level=0]
setblock 328 62 -198 minecraft:air
fill 334 62 -198 361 62 -198 minecraft:water[level=0]
setblock 362 62 -198 minecraft:kelp[age=24]
fill 363 62 -198 367 62 -198 minecraft:water[level=0]
setblock 368 62 -198 minecraft:kelp[age=24]
fill 369 62 -198 374 62 -198 minecraft:water[level=0]
setblock 375 62 -198 minecraft:kelp[age=25]
fill 376 62 -198 378 62 -198 minecraft:water[level=0]
setblock 379 62 -198 minecraft:kelp[age=22]
setblock 380 62 -198 minecraft:kelp[age=24]
setblock 381 62 -198 minecraft:water[level=0]
setblock 382 62 -198 minecraft:kelp[age=24]
setblock 383 62 -198 minecraft:kelp[age=23]
fill 384 62 -198 391 62 -198 minecraft:water[level=0]
fill 335 62 -199 368 62 -199 minecraft:water[level=0]
setblock 369 62 -199 minecraft:kelp[age=24]
fill 370 62 -199 373 62 -199 minecraft:water[level=0]
setblock 374 62 -199 minecraft:kelp[age=22]
fill 375 62 -199 377 62 -199 minecraft:water[level=0]
setblock 378 62 -199 minecraft:kelp[age=24]
fill 379 62 -199 391 62 -199 minecraft:water[level=0]
fill 336 62 -200 372 62 -200 minecraft:water[level=0]
setblock 373 62 -200 minecraft:kelp[age=24]
fill 374 62 -200 385 62 -200 minecraft:water[level=0]
setblock 386 62 -200 minecraft:kelp[age=23]
fill 387 62 -200 391 62 -200 minecraft:water[level=0]
fill 337 62 -201 353 62 -201 minecraft:water[level=0]
setblock 354 62 -201 minecraft:kelp[age=24]
setblock 355 62 -201 minecraft:kelp[age=21]
fill 356 62 -201 364 62 -201 minecraft:water[level=0]
setblock 365 62 -201 minecraft:kelp[age=23]
fill 366 62 -201 368 62 -201 minecraft:water[level=0]
setblock 369 62 -201 minecraft:kelp[age=24]
fill 370 62 -201 391 62 -201 minecraft:water[level=0]
fill 338 62 -202 366 62 -202 minecraft:water[level=0]
setblock 367 62 -202 minecraft:kelp[age=25]
fill 368 62 -202 372 62 -202 minecraft:water[level=0]
setblock 373 62 -202 minecraft:kelp[age=22]
fill 374 62 -202 391 62 -202 minecraft:water[level=0]
fill 339 62 -203 370 62 -203 minecraft:water[level=0]
setblock 371 62 -203 minecraft:kelp[age=24]
fill 372 62 -203 391 62 -203 minecraft:water[level=0]
fill 339 62 -204 362 62 -204 minecraft:water[level=0]
setblock 363 62 -204 minecraft:kelp[age=24]
fill 364 62 -204 391 62 -204 minecraft:water[level=0]
fill 340 62 -205 391 62 -205 minecraft:water[level=0]
fill 342 62 -206 391 62 -206 minecraft:water[level=0]
fill 342 62 -207 391 62 -207 minecraft:water[level=0]
fill 343 62 -208 391 62 -208 minecraft:water[level=0]
fill 343 62 -209 391 62 -209 minecraft:water[level=0]
fill 344 62 -210 391 62 -210 minecraft:water[level=0]
fill 345 62 -211 391 62 -211 minecraft:water[level=0]
fill 346 62 -212 391 62 -212 minecraft:water[level=0]
fill 347 62 -213 375 62 -213 minecraft:water[level=0]
fill 377 62 -213 391 62 -213 minecraft:water[level=0]
fill 357 62 -214 373 62 -214 minecraft:water[level=0]
fill 378 62 -214 391 62 -214 minecraft:water[level=0]
fill 359 62 -215 372 62 -215 minecraft:water[level=0]
fill 378 62 -215 391 62 -215 minecraft:water[level=0]
fill 359 62 -216 372 62 -216 minecraft:water[level=0]
fill 379 62 -216 391 62 -216 minecraft:water[level=0]
fill 360 62 -217 370 62 -217 minecraft:water[level=0]
fill 380 62 -217 391 62 -217 minecraft:water[level=0]
fill 361 62 -218 369 62 -218 minecraft:water[level=0]
fill 384 62 -218 391 62 -218 minecraft:water[level=0]
fill 363 62 -219 368 62 -219 minecraft:water[level=0]
fill 386 62 -219 391 62 -219 minecraft:water[level=0]
fill 367 62 -220 368 62 -220 minecraft:water[level=0]
fill 387 62 -220 391 62 -220 minecraft:water[level=0]
fill 388 62 -221 391 62 -221 minecraft:water[level=0]
fill 389 62 -222 391 62 -222 minecraft:water[level=0]
setblock 328 62 -223 minecraft:water[level=0]
fill 328 62 -224 331 62 -224 minecraft:water[level=0]
fill 328 62 -225 331 62 -225 minecraft:water[level=0]
fill 328 62 -226 332 62 -226 minecraft:water[level=0]
fill 328 62 -227 332 62 -227 minecraft:water[level=0]
setblock 333 62 -227 minecraft:water[level=1]
fill 353 62 -227 354 62 -227 minecraft:air
fill 328 62 -228 329 62 -228 minecraft:water[level=0]
fill 332 62 -228 333 62 -228 minecraft:air
setblock 368 62 -228 minecraft:air
setblock 333 62 -229 minecraft:air
fill 354 62 -229 357 62 -229 minecraft:air
fill 364 62 -229 368 62 -229 minecraft:air
fill 371 62 -229 372 62 -229 minecraft:air
fill 355 62 -230 372 62 -230 minecraft:air
setblock 355 62 -231 minecraft:air
fill 357 62 -231 367 62 -231 minecraft:air
fill 369 62 -231 372 62 -231 minecraft:air
fill 355 62 -232 358 62 -232 minecraft:air
setblock 360 62 -232 minecraft:air
fill 370 62 -232 372 62 -232 minecraft:air
fill 355 62 -233 357 62 -233 minecraft:air
fill 369 62 -233 371 62 -233 minecraft:air
setblock 349 62 -234 minecraft:air
fill 354 62 -234 357 62 -234 minecraft:air
fill 369 62 -234 370 62 -234 minecraft:air
fill 349 62 -235 350 62 -235 minecraft:air
fill 368 62 -235 369 62 -235 minecraft:air
fill 349 62 -236 350 62 -236 minecraft:air
setblock 368 62 -236 minecraft:air
setblock 367 62 -237 minecraft:air
setblock 366 62 -238 minecraft:air
fill 331 61 -191 359 61 -191 minecraft:water[level=0]
setblock 360 61 -191 minecraft:kelp_plant
fill 361 61 -191 364 61 -191 minecraft:water[level=0]
setblock 365 61 -191 minecraft:kelp_plant
fill 366 61 -191 369 61 -191 minecraft:water[level=0]
fill 370 61 -191 371 61 -191 minecraft:kelp_plant
setblock 372 61 -191 minecraft:water[level=0]
setblock 373 61 -191 minecraft:kelp_plant
setblock 374 61 -191 minecraft:water[level=0]
setblock 375 61 -191 minecraft:kelp_plant
fill 376 61 -191 377 61 -191 minecraft:water[level=0]
setblock 378 61 -191 minecraft:kelp_plant
fill 379 61 -191 384 61 -191 minecraft:water[level=0]
setblock 385 61 -191 minecraft:kelp_plant
fill 386 61 -191 391 61 -191 minecraft:water[level=0]
fill 331 61 -192 348 61 -192 minecraft:water[level=0]
setblock 349 61 -192 minecraft:kelp_plant
fill 350 61 -192 361 61 -192 minecraft:water[level=0]
setblock 362 61 -192 minecraft:kelp_plant
setblock 363 61 -192 minecraft:water[level=0]
setblock 364 61 -192 minecraft:kelp_plant
fill 365 61 -192 366 61 -192 minecraft:water[level=0]
setblock 367 61 -192 minecraft:kelp_plant
fill 368 61 -192 376 61 -192 minecraft:water[level=0]
setblock 377 61 -192 minecraft:kelp_plant
setblock 378 61 -192 minecraft:water[level=0]
fill 379 61 -192 380 61 -192 minecraft:kelp_plant
fill 381 61 -192 382 61 -192 minecraft:water[level=0]
setblock 383 61 -192 minecraft:kelp_plant
fill 384 61 -192 390 61 -192 minecraft:water[level=0]
setblock 391 61 -192 minecraft:kelp[age=25]
fill 331 61 -193 351 61 -193 minecraft:water[level=0]
setblock 352 61 -193 minecraft:kelp_plant
fill 353 61 -193 369 61 -193 minecraft:water[level=0]
fill 370 61 -193 372 61 -193 minecraft:kelp_plant
setblock 373 61 -193 minecraft:water[level=0]
setblock 374 61 -193 minecraft:kelp[age=25]
fill 375 61 -193 381 61 -193 minecraft:water[level=0]
fill 382 61 -193 383 61 -193 minecraft:kelp_plant
fill 384 61 -193 391 61 -193 minecraft:water[level=0]
fill 332 61 -194 358 61 -194 minecraft:water[level=0]
setblock 359 61 -194 minecraft:kelp_plant
fill 360 61 -194 369 61 -194 minecraft:water[level=0]
setblock 370 61 -194 minecraft:kelp[age=25]
fill 371 61 -194 379 61 -194 minecraft:water[level=0]
setblock 380 61 -194 minecraft:kelp_plant
fill 381 61 -194 391 61 -194 minecraft:water[level=0]
fill 332 61 -195 366 61 -195 minecraft:water[level=0]
setblock 367 61 -195 minecraft:kelp_plant
fill 368 61 -195 369 61 -195 minecraft:water[level=0]
fill 370 61 -195 373 61 -195 minecraft:kelp_plant
setblock 374 61 -195 minecraft:water[level=0]
setblock 375 61 -195 minecraft:kelp_plant
fill 376 61 -195 377 61 -195 minecraft:water[level=0]
setblock 378 61 -195 minecraft:kelp_plant
fill 379 61 -195 391 61 -195 minecraft:water[level=0]
fill 332 61 -196 362 61 -196 minecraft:water[level=0]
setblock 363 61 -196 minecraft:kelp_plant
setblock 364 61 -196 minecraft:water[level=0]
setblock 365 61 -196 minecraft:kelp_plant
fill 366 61 -196 369 61 -196 minecraft:water[level=0]
setblock 370 61 -196 minecraft:kelp_plant
setblock 371 61 -196 minecraft:water[level=0]
setblock 372 61 -196 minecraft:kelp_plant
fill 373 61 -196 377 61 -196 minecraft:water[level=0]
setblock 378 61 -196 minecraft:kelp_plant
fill 379 61 -196 380 61 -196 minecraft:water[level=0]
setblock 381 61 -196 minecraft:kelp_plant
setblock 382 61 -196 minecraft:water[level=0]
setblock 383 61 -196 minecraft:kelp[age=25]
fill 384 61 -196 391 61 -196 minecraft:water[level=0]
fill 334 61 -197 359 61 -197 minecraft:water[level=0]
setblock 360 61 -197 minecraft:kelp_plant
fill 361 61 -197 371 61 -197 minecraft:water[level=0]
setblock 372 61 -197 minecraft:kelp_plant
fill 373 61 -197 377 61 -197 minecraft:water[level=0]
fill 378 61 -197 379 61 -197 minecraft:kelp_plant
fill 380 61 -197 383 61 -197 minecraft:water[level=0]
setblock 384 61 -197 minecraft:kelp_plant
fill 385 61 -197 391 61 -197 minecraft:water[level=0]
fill 335 61 -198 361 61 -198 minecraft:water[level=0]
setblock 362 61 -198 minecraft:kelp_plant
fill 363 61 -198 367 61 -198 minecraft:water[level=0]
setblock 368 61 -198 minecraft:kelp_plant
fill 369 61 -198 374 61 -198 minecraft:water[level=0]
setblock 375 61 -198 minecraft:kelp_plant
fill 376 61 -198 378 61 -198 minecraft:water[level=0]
fill 379 61 -198 380 61 -198 minecraft:kelp_plant
setblock 381 61 -198 minecraft:water[level=0]
fill 382 61 -198 383 61 -198 minecraft:kelp_plant
fill 384 61 -198 391 61 -198 minecraft:water[level=0]
fill 336 61 -199 361 61 -199 minecraft:water[level=0]
setblock 362 61 -199 minecraft:kelp[age=25]
fill 363 61 -199 368 61 -199 minecraft:water[level=0]
setblock 369 61 -199 minecraft:kelp_plant
fill 370 61 -199 373 61 -199 minecraft:water[level=0]
setblock 374 61 -199 minecraft:kelp_plant
fill 375 61 -199 377 61 -199 minecraft:water[level=0]
setblock 378 61 -199 minecraft:kelp_plant
fill 379 61 -199 391 61 -199 minecraft:water[level=0]
fill 336 61 -200 372 61 -200 minecraft:water[level=0]
setblock 373 61 -200 minecraft:kelp_plant
fill 374 61 -200 385 61 -200 minecraft:water[level=0]
setblock 386 61 -200 minecraft:kelp_plant
fill 387 61 -200 391 61 -200 minecraft:water[level=0]
fill 338 61 -201 353 61 -201 minecraft:water[level=0]
fill 354 61 -201 355 61 -201 minecraft:kelp_plant
fill 356 61 -201 364 61 -201 minecraft:water[level=0]
setblock 365 61 -201 minecraft:kelp_plant
fill 366 61 -201 368 61 -201 minecraft:water[level=0]
setblock 369 61 -201 minecraft:kelp_plant
fill 370 61 -201 391 61 -201 minecraft:water[level=0]
fill 339 61 -202 366 61 -202 minecraft:water[level=0]
setblock 367 61 -202 minecraft:kelp_plant
fill 368 61 -202 372 61 -202 minecraft:water[level=0]
setblock 373 61 -202 minecraft:kelp_plant
fill 374 61 -202 391 61 -202 minecraft:water[level=0]
fill 339 61 -203 370 61 -203 minecraft:water[level=0]
setblock 371 61 -203 minecraft:kelp_plant
fill 372 61 -203 391 61 -203 minecraft:water[level=0]
fill 340 61 -204 362 61 -204 minecraft:water[level=0]
setblock 363 61 -204 minecraft:kelp_plant
fill 364 61 -204 370 61 -204 minecraft:water[level=0]
setblock 371 61 -204 minecraft:kelp[age=25]
fill 372 61 -204 391 61 -204 minecraft:water[level=0]
fill 341 61 -205 391 61 -205 minecraft:water[level=0]
fill 342 61 -206 391 61 -206 minecraft:water[level=0]
fill 343 61 -207 391 61 -207 minecraft:water[level=0]
fill 343 61 -208 391 61 -208 minecraft:water[level=0]
fill 344 61 -209 391 61 -209 minecraft:water[level=0]
fill 345 61 -210 391 61 -210 minecraft:water[level=0]
fill 346 61 -211 391 61 -211 minecraft:water[level=0]
fill 347 61 -212 391 61 -212 minecraft:water[level=0]
fill 348 61 -213 350 61 -213 minecraft:water[level=0]
fill 356 61 -213 373 61 -213 minecraft:water[level=0]
fill 378 61 -213 391 61 -213 minecraft:water[level=0]
fill 358 61 -214 372 61 -214 minecraft:water[level=0]
fill 378 61 -214 391 61 -214 minecraft:water[level=0]
fill 359 61 -215 371 61 -215 minecraft:water[level=0]
fill 379 61 -215 391 61 -215 minecraft:water[level=0]
fill 360 61 -216 370 61 -216 minecraft:water[level=0]
fill 379 61 -216 391 61 -216 minecraft:water[level=0]
fill 360 61 -217 369 61 -217 minecraft:water[level=0]
fill 381 61 -217 391 61 -217 minecraft:water[level=0]
fill 363 61 -218 368 61 -218 minecraft:water[level=0]
fill 385 61 -218 391 61 -218 minecraft:water[level=0]
fill 364 61 -219 368 61 -219 minecraft:water[level=0]
fill 387 61 -219 391 61 -219 minecraft:water[level=0]
fill 388 61 -220 391 61 -220 minecraft:water[level=0]
fill 388 61 -221 391 61 -221 minecraft:water[level=0]
fill 390 61 -222 391 61 -222 minecraft:water[level=0]
setblock 328 61 -223 minecraft:water[level=0]
fill 328 61 -224 331 61 -224 minecraft:water[level=0]
fill 328 61 -225 332 61 -225 minecraft:water[level=0]
fill 328 61 -226 331 61 -226 minecraft:water[level=0]
fill 328 61 -227 329 61 -227 minecraft:water[level=0]
setblock 333 61 -227 minecraft:water[level=8]
setblock 367 61 -227 minecraft:air
setblock 333 61 -228 minecraft:air
fill 364 61 -228 367 61 -228 minecraft:air
setblock 333 61 -229 minecraft:air
fill 361 61 -229 367 61 -229 minecraft:air
setblock 372 61 -229 minecraft:air
fill 357 61 -230 364 61 -230 minecraft:air
setblock 371 61 -230 minecraft:air
fill 357 61 -231 360 61 -231 minecraft:air
fill 370 61 -231 371 61 -231 minecraft:air
fill 354 61 -232 357 61 -232 minecraft:air
fill 369 61 -232 371 61 -232 minecraft:air
fill 352 61 -233 357 61 -233 minecraft:air
fill 369 61 -233 371 61 -233 minecraft:air
fill 349 61 -234 353 61 -234 minecraft:air
fill 368 61 -234 370 61 -234 minecraft:air
fill 349 61 -235 352 61 -235 minecraft:air
fill 368 61 -235 370 61 -235 minecraft:air
setblock 350 61 -236 minecraft:air
fill 367 61 -236 369 61 -236 minecraft:air
fill 366 61 -237 368 61 -237 minecraft:air
fill 366 61 -238 367 61 -238 minecraft:air
setblock 365 61 -239 minecraft:air
fill 331 60 -191 348 60 -191 minecraft:water[level=0]
setblock 349 60 -191 minecraft:kelp[age=25]
fill 350 60 -191 359 60 -191 minecraft:water[level=0]
setblock 360 60 -191 minecraft:kelp_plant
fill 361 60 -191 364 60 -191 minecraft:water[level=0]
setblock 365 60 -191 minecraft:kelp_plant
fill 366 60 -191 369 60 -191 minecraft:water[level=0]
fill 370 60 -191 371 60 -191 minecraft:kelp_plant
setblock 372 60 -191 minecraft:water[level=0]
setblock 373 60 -191 minecraft:kelp_plant
setblock 374 60 -191 minecraft:water[level=0]
setblock 375 60 -191 minecraft:kelp_plant
fill 376 60 -191 377 60 -191 minecraft:water[level=0]
setblock 378 60 -191 minecraft:kelp_plant
fill 379 60 -191 384 60 -191 minecraft:water[level=0]
setblock 385 60 -191 minecraft:kelp_plant
fill 386 60 -191 391 60 -191 minecraft:water[level=0]
fill 332 60 -192 348 60 -192 minecraft:water[level=0]
setblock 349 60 -192 minecraft:kelp_plant
fill 350 60 -192 361 60 -192 minecraft:water[level=0]
setblock 362 60 -192 minecraft:kelp_plant
setblock 363 60 -192 minecraft:water[level=0]
setblock 364 60 -192 minecraft:kelp_plant
fill 365 60 -192 366 60 -192 minecraft:water[level=0]
setblock 367 60 -192 minecraft:kelp_plant
fill 368 60 -192 376 60 -192 minecraft:water[level=0]
setblock 377 60 -192 minecraft:kelp_plant
setblock 378 60 -192 minecraft:water[level=0]
fill 379 60 -192 380 60 -192 minecraft:kelp_plant
fill 381 60 -192 382 60 -192 minecraft:water[level=0]
setblock 383 60 -192 minecraft:kelp_plant
fill 384 60 -192 390 60 -192 minecraft:water[level=0]
setblock 391 60 -192 minecraft:kelp_plant
fill 332 60 -193 351 60 -193 minecraft:water[level=0]
setblock 352 60 -193 minecraft:kelp_plant
fill 353 60 -193 369 60 -193 minecraft:water[level=0]
fill 370 60 -193 372 60 -193 minecraft:kelp_plant
setblock 373 60 -193 minecraft:water[level=0]
setblock 374 60 -193 minecraft:kelp_plant
fill 375 60 -193 381 60 -193 minecraft:water[level=0]
fill 382 60 -193 383 60 -193 minecraft:kelp_plant
fill 384 60 -193 390 60 -193 minecraft:water[level=0]
setblock 391 60 -193 minecraft:kelp[age=25]
fill 332 60 -194 358 60 -194 minecraft:water[level=0]
setblock 359 60 -194 minecraft:kelp_plant
fill 360 60 -194 369 60 -194 minecraft:water[level=0]
setblock 370 60 -194 minecraft:kelp_plant
setblock 371 60 -194 minecraft:water[level=0]
setblock 372 60 -194 minecraft:kelp[age=25]
fill 373 60 -194 379 60 -194 minecraft:water[level=0]
setblock 380 60 -194 minecraft:kelp_plant
fill 381 60 -194 391 60 -194 minecraft:water[level=0]
fill 332 60 -195 358 60 -195 minecraft:water[level=0]
setblock 359 60 -195 minecraft:kelp[age=25]
fill 360 60 -195 366 60 -195 minecraft:water[level=0]
setblock 367 60 -195 minecraft:kelp_plant
fill 368 60 -195 369 60 -195 minecraft:water[level=0]
fill 370 60 -195 373 60 -195 minecraft:kelp_plant
setblock 374 60 -195 minecraft:water[level=0]
setblock 375 60 -195 minecraft:kelp_plant
fill 376 60 -195 377 60 -195 minecraft:water[level=0]
setblock 378 60 -195 minecraft:kelp_plant
fill 379 60 -195 391 60 -195 minecraft:water[level=0]
fill 333 60 -196 362 60 -196 minecraft:water[level=0]
setblock 363 60 -196 minecraft:kelp_plant
setblock 364 60 -196 minecraft:water[level=0]
setblock 365 60 -196 minecraft:kelp_plant
fill 366 60 -196 369 60 -196 minecraft:water[level=0]
setblock 370 60 -196 minecraft:kelp_plant
setblock 371 60 -196 minecraft:water[level=0]
setblock 372 60 -196 minecraft:kelp_plant
fill 373 60 -196 377 60 -196 minecraft:water[level=0]
setblock 378 60 -196 minecraft:kelp_plant
fill 379 60 -196 380 60 -196 minecraft:water[level=0]
setblock 381 60 -196 minecraft:kelp_plant
setblock 382 60 -196 minecraft:water[level=0]
setblock 383 60 -196 minecraft:kelp_plant
fill 384 60 -196 391 60 -196 minecraft:water[level=0]
fill 334 60 -197 359 60 -197 minecraft:water[level=0]
setblock 360 60 -197 minecraft:kelp_plant
fill 361 60 -197 371 60 -197 minecraft:water[level=0]
setblock 372 60 -197 minecraft:kelp_plant
fill 373 60 -197 376 60 -197 minecraft:water[level=0]
setblock 377 60 -197 minecraft:kelp[age=25]
fill 378 60 -197 379 60 -197 minecraft:kelp_plant
fill 380 60 -197 383 60 -197 minecraft:water[level=0]
setblock 384 60 -197 minecraft:kelp_plant
fill 385 60 -197 391 60 -197 minecraft:water[level=0]
fill 335 60 -198 361 60 -198 minecraft:water[level=0]
setblock 362 60 -198 minecraft:kelp_plant
fill 363 60 -198 367 60 -198 minecraft:water[level=0]
setblock 368 60 -198 minecraft:kelp_plant
fill 369 60 -198 374 60 -198 minecraft:water[level=0]
setblock 375 60 -198 minecraft:kelp_plant
fill 376 60 -198 378 60 -198 minecraft:water[level=0]
fill 379 60 -198 380 60 -198 minecraft:kelp_plant
setblock 381 60 -198 minecraft:water[level=0]
fill 382 60 -198 383 60 -198 minecraft:kelp_plant
fill 384 60 -198 391 60 -198 minecraft:water[level=0]
fill 336 60 -199 361 60 -199 minecraft:water[level=0]
setblock 362 60 -199 minecraft:kelp_plant
fill 363 60 -199 368 60 -199 minecraft:water[level=0]
setblock 369 60 -199 minecraft:kelp_plant
fill 370 60 -199 373 60 -199 minecraft:water[level=0]
setblock 374 60 -199 minecraft:kelp_plant
fill 375 60 -199 377 60 -199 minecraft:water[level=0]
setblock 378 60 -199 minecraft:kelp_plant
fill 379 60 -199 391 60 -199 minecraft:water[level=0]
fill 337 60 -200 372 60 -200 minecraft:water[level=0]
setblock 373 60 -200 minecraft:kelp_plant
fill 374 60 -200 385 60 -200 minecraft:water[level=0]
setblock 386 60 -200 minecraft:kelp_plant
fill 387 60 -200 391 60 -200 minecraft:water[level=0]
fill 338 60 -201 353 60 -201 minecraft:water[level=0]
fill 354 60 -201 355 60 -201 minecraft:kelp_plant
fill 356 60 -201 364 60 -201 minecraft:water[level=0]
setblock 365 60 -201 minecraft:kelp_plant
fill 366 60 -201 368 60 -201 minecraft:water[level=0]
setblock 369 60 -201 minecraft:kelp_plant
fill 370 60 -201 391 60 -201 minecraft:water[level=0]
fill 339 60 -202 352 60 -202 minecraft:water[level=0]
setblock 353 60 -202 minecraft:kelp[age=25]
fill 354 60 -202 355 60 -202 minecraft:water[level=0]
setblock 356 60 -202 minecraft:kelp[age=25]
fill 357 60 -202 366 60 -202 minecraft:water[level=0]
setblock 367 60 -202 minecraft:kelp_plant
fill 368 60 -202 369 60 -202 minecraft:water[level=0]
setblock 370 60 -202 minecraft:kelp[age=25]
fill 371 60 -202 372 60 -202 minecraft:water[level=0]
setblock 373 60 -202 minecraft:kelp_plant
fill 374 60 -202 391 60 -202 minecraft:water[level=0]
fill 340 60 -203 370 60 -203 minecraft:water[level=0]
setblock 371 60 -203 minecraft:kelp_plant
fill 372 60 -203 391 60 -203 minecraft:water[level=0]
fill 340 60 -204 362 60 -204 minecraft:water[level=0]
setblock 363 60 -204 minecraft:kelp_plant
fill 364 60 -204 370 60 -204 minecraft:water[level=0]
setblock 371 60 -204 minecraft:kelp_plant
fill 372 60 -204 391 60 -204 minecraft:water[level=0]
fill 341 60 -205 391 60 -205 minecraft:water[level=0]
fill 343 60 -206 391 60 -206 minecraft:water[level=0]
fill 343 60 -207 391 60 -207 minecraft:water[level=0]
fill 343 60 -208 391 60 -208 minecraft:water[level=0]
fill 344 60 -209 391 60 -209 minecraft:water[level=0]
fill 345 60 -210 391 60 -210 minecraft:water[level=0]
fill 347 60 -211 375 60 -211 minecraft:water[level=0]
fill 377 60 -211 391 60 -211 minecraft:water[level=0]
fill 347 60 -212 373 60 -212 minecraft:water[level=0]
fill 378 60 -212 391 60 -212 minecraft:water[level=0]
fill 357 60 -213 371 60 -213 minecraft:water[level=0]
fill 379 60 -213 391 60 -213 minecraft:water[level=0]
fill 359 60 -214 370 60 -214 minecraft:water[level=0]
fill 379 60 -214 391 60 -214 minecraft:water[level=0]
fill 360 60 -215 370 60 -215 minecraft:water[level=0]
fill 380 60 -215 391 60 -215 minecraft:water[level=0]
fill 360 60 -216 369 60 -216 minecraft:water[level=0]
fill 380 60 -216 391 60 -216 minecraft:water[level=0]
fill 361 60 -217 368 60 -217 minecraft:water[level=0]
fill 383 60 -217 391 60 -217 minecraft:water[level=0]
fill 364 60 -218 367 60 -218 minecraft:water[level=0]
fill 386 60 -218 391 60 -218 minecraft:water[level=0]
fill 387 60 -219 391 60 -219 minecraft:water[level=0]
fill 388 60 -220 391 60 -220 minecraft:water[level=0]
fill 389 60 -221 391 60 -221 minecraft:water[level=0]
setblock 328 60 -223 minecraft:water[level=0]
fill 328 60 -224 331 60 -224 minecraft:water[level=0]
fill 328 60 -225 332 60 -225 minecraft:water[level=0]
fill 328 60 -226 330 60 -226 minecraft:water[level=0]
fill 328 60 -227 329 60 -227 minecraft:water[level=0]
setblock 332 60 -227 minecraft:air
setblock 333 60 -227 minecraft:water[level=8]
fill 363 60 -227 364 60 -227 minecraft:air
setblock 333 60 -228 minecraft:air
fill 361 60 -228 365 60 -228 minecraft:air
fill 359 60 -229 362 60 -229 minecraft:air
fill 357 60 -230 360 60 -230 minecraft:air
fill 353 60 -231 356 60 -231 minecraft:air
setblock 371 60 -231 minecraft:air
fill 352 60 -232 355 60 -232 minecraft:air
fill 370 60 -232 371 60 -232 minecraft:air
fill 349 60 -233 353 60 -233 minecraft:air
fill 369 60 -233 370 60 -233 minecraft:air
fill 349 60 -234 352 60 -234 minecraft:air
fill 368 60 -234 370 60 -234 minecraft:air
fill 349 60 -235 351 60 -235 minecraft:air
fill 367 60 -235 369 60 -235 minecraft:air
fill 367 60 -236 369 60 -236 minecraft:air
fill 366 60 -237 368 60 -237 minecraft:air
fill 365 60 -238 368 60 -238 minecraft:air
fill 364 60 -239 366 60 -239 minecraft:air
setblock 364 60 -240 minecraft:air
fill 332 59 -191 348 59 -191 minecraft:water[level=0]
setblock 349 59 -191 minecraft:kelp_plant
fill 350 59 -191 359 59 -191 minecraft:water[level=0]
setblock 360 59 -191 minecraft:kelp_plant
fill 361 59 -191 364 59 -191 minecraft:water[level=0]
setblock 365 59 -191 minecraft:kelp_plant
fill 366 59 -191 369 59 -191 minecraft:water[level=0]
fill 370 59 -191 371 59 -191 minecraft:kelp_plant
setblock 372 59 -191 minecraft:water[level=0]
setblock 373 59 -191 minecraft:kelp_plant
setblock 374 59 -191 minecraft:water[level=0]
setblock 375 59 -191 minecraft:kelp_plant
fill 376 59 -191 377 59 -191 minecraft:water[level=0]
setblock 378 59 -191 minecraft:kelp_plant
fill 379 59 -191 384 59 -191 minecraft:water[level=0]
setblock 385 59 -191 minecraft:kelp_plant
fill 386 59 -191 391 59 -191 minecraft:water[level=0]
fill 332 59 -192 348 59 -192 minecraft:water[level=0]
setblock 349 59 -192 minecraft:kelp_plant
fill 350 59 -192 361 59 -192 minecraft:water[level=0]
setblock 362 59 -192 minecraft:kelp_plant
setblock 363 59 -192 minecraft:water[level=0]
setblock 364 59 -192 minecraft:kelp_plant
fill 365 59 -192 366 59 -192 minecraft:water[level=0]
setblock 367 59 -192 minecraft:kelp_plant
fill 368 59 -192 376 59 -192 minecraft:water[level=0]
setblock 377 59 -192 minecraft:kelp_plant
setblock 378 59 -192 minecraft:water[level=0]
fill 379 59 -192 380 59 -192 minecraft:kelp_plant
fill 381 59 -192 382 59 -192 minecraft:water[level=0]
setblock 383 59 -192 minecraft:kelp_plant
fill 384 59 -192 390 59 -192 minecraft:water[level=0]
setblock 391 59 -192 minecraft:kelp_plant
fill 332 59 -193 351 59 -193 minecraft:water[level=0]
setblock 352 59 -193 minecraft:kelp_plant
fill 353 59 -193 369 59 -193 minecraft:water[level=0]
fill 370 59 -193 372 59 -193 minecraft:kelp_plant
setblock 373 59 -193 minecraft:water[level=0]
setblock 374 59 -193 minecraft:kelp_plant
setblock 375 59 -193 minecraft:water[level=0]
setblock 376 59 -193 minecraft:kelp[age=25]
fill 377 59 -193 381 59 -193 minecraft:water[level=0]
fill 382 59 -193 383 59 -193 minecraft:kelp_plant
fill 384 59 -193 390 59 -193 minecraft:water[level=0]
setblock 391 59 -193 minecraft:kelp_plant
fill 332 59 -194 358 59 -194 minecraft:water[level=0]
setblock 359 59 -194 minecraft:kelp_plant
fill 360 59 -194 369 59 -194 minecraft:water[level=0]
setblock 370 59 -194 minecraft:kelp_plant
setblock 371 59 -194 minecraft:water[level=0]
setblock 372 59 -194 minecraft:kelp_plant
fill 373 59 -194 379 59 -194 minecraft:water[level=0]
setblock 380 59 -194 minecraft:kelp_plant
fill 381 59 -194 391 59 -194 minecraft:water[level=0]
fill 333 59 -195 358 59 -195 minecraft:water[level=0]
setblock 359 59 -195 minecraft:kelp_plant
fill 360 59 -195 366 59 -195 minecraft:water[level=0]
setblock 367 59 -195 minecraft:kelp_plant
fill 368 59 -195 369 59 -195 minecraft:water[level=0]
fill 370 59 -195 373 59 -195 minecraft:kelp_plant
setblock 374 59 -195 minecraft:water[level=0]
setblock 375 59 -195 minecraft:kelp_plant
fill 376 59 -195 377 59 -195 minecraft:water[level=0]
setblock 378 59 -195 minecraft:kelp_plant
fill 379 59 -195 391 59 -195 minecraft:water[level=0]
fill 333 59 -196 362 59 -196 minecraft:water[level=0]
setblock 363 59 -196 minecraft:kelp_plant
setblock 364 59 -196 minecraft:water[level=0]
setblock 365 59 -196 minecraft:kelp_plant
fill 366 59 -196 368 59 -196 minecraft:water[level=0]
setblock 369 59 -196 minecraft:kelp[age=25]
setblock 370 59 -196 minecraft:kelp_plant
setblock 371 59 -196 minecraft:water[level=0]
setblock 372 59 -196 minecraft:kelp_plant
fill 373 59 -196 377 59 -196 minecraft:water[level=0]
setblock 378 59 -196 minecraft:kelp_plant
fill 379 59 -196 380 59 -196 minecraft:water[level=0]
setblock 381 59 -196 minecraft:kelp_plant
setblock 382 59 -196 minecraft:water[level=0]
setblock 383 59 -196 minecraft:kelp_plant
fill 384 59 -196 391 59 -196 minecraft:water[level=0]
fill 335 59 -197 359 59 -197 minecraft:water[level=0]
setblock 360 59 -197 minecraft:kelp_plant
fill 361 59 -197 370 59 -197 minecraft:water[level=0]
setblock 371 59 -197 minecraft:kelp[age=25]
setblock 372 59 -197 minecraft:kelp_plant
fill 373 59 -197 376 59 -197 minecraft:water[level=0]
fill 377 59 -197 379 59 -197 minecraft:kelp_plant
fill 380 59 -197 383 59 -197 minecraft:water[level=0]
setblock 384 59 -197 minecraft:kelp_plant
fill 385 59 -197 391 59 -197 minecraft:water[level=0]
fill 336 59 -198 361 59 -198 minecraft:water[level=0]
setblock 362 59 -198 minecraft:kelp_plant
fill 363 59 -198 367 59 -198 minecraft:water[level=0]
setblock 368 59 -198 minecraft:kelp_plant
fill 369 59 -198 374 59 -198 minecraft:water[level=0]
setblock 375 59 -198 minecraft:kelp_plant
fill 376 59 -198 378 59 -198 minecraft:water[level=0]
fill 379 59 -198 380 59 -198 minecraft:kelp_plant
setblock 381 59 -198 minecraft:water[level=0]
fill 382 59 -198 383 59 -198 minecraft:kelp_plant
fill 384 59 -198 391 59 -198 minecraft:water[level=0]
fill 337 59 -199 361 59 -199 minecraft:water[level=0]
setblock 362 59 -199 minecraft:kelp_plant
fill 363 59 -199 368 59 -199 minecraft:water[level=0]
setblock 369 59 -199 minecraft:kelp_plant
fill 370 59 -199 373 59 -199 minecraft:water[level=0]
setblock 374 59 -199 minecraft:kelp_plant
fill 375 59 -199 377 59 -199 minecraft:water[level=0]
setblock 378 59 -199 minecraft:kelp_plant
fill 379 59 -199 391 59 -199 minecraft:water[level=0]
fill 338 59 -200 365 59 -200 minecraft:water[level=0]
setblock 366 59 -200 minecraft:kelp[age=25]
fill 367 59 -200 372 59 -200 minecraft:water[level=0]
setblock 373 59 -200 minecraft:kelp_plant
fill 374 59 -200 385 59 -200 minecraft:water[level=0]
setblock 386 59 -200 minecraft:kelp_plant
fill 387 59 -200 391 59 -200 minecraft:water[level=0]
fill 339 59 -201 353 59 -201 minecraft:water[level=0]
fill 354 59 -201 355 59 -201 minecraft:kelp_plant
fill 356 59 -201 364 59 -201 minecraft:water[level=0]
setblock 365 59 -201 minecraft:kelp_plant
fill 366 59 -201 368 59 -201 minecraft:water[level=0]
setblock 369 59 -201 minecraft:kelp_plant
fill 370 59 -201 386 59 -201 minecraft:water[level=0]
setblock 387 59 -201 minecraft:kelp[age=25]
fill 388 59 -201 391 59 -201 minecraft:water[level=0]
fill 339 59 -202 352 59 -202 minecraft:water[level=0]
setblock 353 59 -202 minecraft:kelp_plant
fill 354 59 -202 355 59 -202 minecraft:water[level=0]
setblock 356 59 -202 minecraft:kelp_plant
fill 357 59 -202 366 59 -202 minecraft:water[level=0]
setblock 367 59 -202 minecraft:kelp_plant
fill 368 59 -202 369 59 -202 minecraft:water[level=0]
setblock 370 59 -202 minecraft:kelp_plant
fill 371 59 -202 372 59 -202 minecraft:water[level=0]
setblock 373 59 -202 minecraft:kelp_plant
fill 374 59 -202 391 59 -202 minecraft:water[level=0]
fill 340 59 -203 368 59 -203 minecraft:water[level=0]
setblock 369 59 -203 minecraft:kelp[age=25]
setblock 370 59 -203 minecraft:water[level=0]
setblock 371 59 -203 minecraft:kelp_plant
fill 372 59 -203 373 59 -203 minecraft:water[level=0]
setblock 374 59 -203 minecraft:kelp[age=25]
fill 375 59 -203 391 59 -203 minecraft:water[level=0]
fill 340 59 -204 357 59 -204 minecraft:water[level=0]
setblock 358 59 -204 minecraft:kelp[age=25]
fill 359 59 -204 362 59 -204 minecraft:water[level=0]
setblock 363 59 -204 minecraft:kelp_plant
fill 364 59 -204 370 59 -204 minecraft:water[level=0]
setblock 371 59 -204 minecraft:kelp_plant
fill 372 59 -204 391 59 -204 minecraft:water[level=0]
fill 342 59 -205 391 59 -205 minecraft:water[level=0]
fill 343 59 -206 391 59 -206 minecraft:water[level=0]
fill 343 59 -207 391 59 -207 minecraft:water[level=0]
fill 344 59 -208 391 59 -208 minecraft:water[level=0]
fill 344 59 -209 391 59 -209 minecraft:water[level=0]
fill 346 59 -210 375 59 -210 minecraft:water[level=0]
fill 377 59 -210 391 59 -210 minecraft:water[level=0]
fill 347 59 -211 373 59 -211 minecraft:water[level=0]
fill 378 59 -211 391 59 -211 minecraft:water[level=0]
fill 347 59 -212 371 59 -212 minecraft:water[level=0]
fill 379 59 -212 391 59 -212 minecraft:water[level=0]
fill 358 59 -213 370 59 -213 minecraft:water[level=0]
fill 379 59 -213 391 59 -213 minecraft:water[level=0]
fill 359 59 -214 369 59 -214 minecraft:water[level=0]
fill 380 59 -214 391 59 -214 minecraft:water[level=0]
fill 360 59 -215 368 59 -215 minecraft:water[level=0]
fill 380 59 -215 391 59 -215 minecraft:water[level=0]
fill 360 59 -216 367 59 -216 minecraft:water[level=0]
fill 380 59 -216 391 59 -216 minecraft:water[level=0]
fill 363 59 -217 366 59 -217 minecraft:water[level=0]
fill 384 59 -217 391 59 -217 minecraft:water[level=0]
setblock 364 59 -218 minecraft:water[level=0]
fill 387 59 -218 391 59 -218 minecraft:water[level=0]
fill 388 59 -219 391 59 -219 minecraft:water[level=0]
fill 389 59 -220 391 59 -220 minecraft:water[level=0]
fill 390 59 -221 391 59 -221 minecraft:water[level=0]
setblock 328 59 -223 minecraft:water[level=0]
fill 328 59 -224 332 59 -224 minecraft:water[level=0]
fill 328 59 -225 331 59 -225 minecraft:water[level=0]
fill 328 59 -226 329 59 -226 minecraft:water[level=0]
fill 333 59 -226 334 59 -226 minecraft:air
setblock 328 59 -227 minecraft:water[level=0]
setblock 332 59 -227 minecraft:air
setblock 333 59 -227 minecraft:water[level=8]
fill 362 59 -227 363 59 -227 minecraft:air
setblock 333 59 -228 minecraft:air
fill 359 59 -228 362 59 -228 minecraft:air
fill 357 59 -229 359 59 -229 minecraft:air
fill 353 59 -230 358 59 -230 minecraft:air
fill 349 59 -231 355 59 -231 minecraft:air
fill 349 59 -232 352 59 -232 minecraft:air
fill 349 59 -233 352 59 -233 minecraft:air
fill 369 59 -233 370 59 -233 minecraft:air
fill 348 59 -234 351 59 -234 minecraft:air
fill 368 59 -234 369 59 -234 minecraft:air
fill 367 59 -235 369 59 -235 minecraft:air
fill 366 59 -236 368 59 -236 minecraft:air
fill 365 59 -237 368 59 -237 minecraft:air
fill 365 59 -238 367 59 -238 minecraft:air
fill 364 59 -239 366 59 -239 minecraft:air
fill 363 59 -240 366 59 -240 minecraft:air
fill 362 59 -241 364 59 -241 minecraft:air
fill 332 58 -191 348 58 -191 minecraft:water[level=0]
setblock 349 58 -191 minecraft:kelp_plant
fill 350 58 -191 359 58 -191 minecraft:water[level=0]
setblock 360 58 -191 minecraft:kelp_plant
fill 361 58 -191 364 58 -191 minecraft:water[level=0]
setblock 365 58 -191 minecraft:kelp_plant
fill 366 58 -191 369 58 -191 minecraft:water[level=0]
fill 370 58 -191 371 58 -191 minecraft:kelp_plant
setblock 372 58 -191 minecraft:water[level=0]
setblock 373 58 -191 minecraft:kelp_plant
setblock 374 58 -191 minecraft:water[level=0]
setblock 375 58 -191 minecraft:kelp_plant
fill 376 58 -191 377 58 -191 minecraft:water[level=0]
setblock 378 58 -191 minecraft:kelp_plant
fill 379 58 -191 384 58 -191 minecraft:water[level=0]
setblock 385 58 -191 minecraft:kelp_plant
setblock 386 58 -191 minecraft:kelp[age=25]
fill 387 58 -191 391 58 -191 minecraft:water[level=0]
fill 332 58 -192 348 58 -192 minecraft:water[level=0]
setblock 349 58 -192 minecraft:kelp_plant
fill 350 58 -192 361 58 -192 minecraft:water[level=0]
setblock 362 58 -192 minecraft:kelp_plant
setblock 363 58 -192 minecraft:water[level=0]
setblock 364 58 -192 minecraft:kelp_plant
fill 365 58 -192 366 58 -192 minecraft:water[level=0]
setblock 367 58 -192 minecraft:kelp_plant
fill 368 58 -192 376 58 -192 minecraft:water[level=0]
setblock 377 58 -192 minecraft:kelp_plant
setblock 378 58 -192 minecraft:water[level=0]
fill 379 58 -192 380 58 -192 minecraft:kelp_plant
fill 381 58 -192 382 58 -192 minecraft:water[level=0]
setblock 383 58 -192 minecraft:kelp_plant
fill 384 58 -192 390 58 -192 minecraft:water[level=0]
setblock 391 58 -192 minecraft:kelp_plant
fill 332 58 -193 351 58 -193 minecraft:water[level=0]
setblock 352 58 -193 minecraft:kelp_plant
fill 353 58 -193 369 58 -193 minecraft:water[level=0]
fill 370 58 -193 372 58 -193 minecraft:kelp_plant
setblock 373 58 -193 minecraft:water[level=0]
setblock 374 58 -193 minecraft:kelp_plant
setblock 375 58 -193 minecraft:water[level=0]
setblock 376 58 -193 minecraft:kelp_plant
fill 377 58 -193 381 58 -193 minecraft:water[level=0]
fill 382 58 -193 383 58 -193 minecraft:kelp_plant
fill 384 58 -193 390 58 -193 minecraft:water[level=0]
setblock 391 58 -193 minecraft:kelp_plant
fill 333 58 -194 358 58 -194 minecraft:water[level=0]
setblock 359 58 -194 minecraft:kelp_plant
fill 360 58 -194 369 58 -194 minecraft:water[level=0]
setblock 370 58 -194 minecraft:kelp_plant
setblock 371 58 -194 minecraft:water[level=0]
setblock 372 58 -194 minecraft:kelp_plant
fill 373 58 -194 379 58 -194 minecraft:water[level=0]
setblock 380 58 -194 minecraft:kelp_plant
fill 381 58 -194 391 58 -194 minecraft:water[level=0]
fill 333 58 -195 358 58 -195 minecraft:water[level=0]
setblock 359 58 -195 minecraft:kelp_plant
fill 360 58 -195 366 58 -195 minecraft:water[level=0]
setblock 367 58 -195 minecraft:kelp_plant
fill 368 58 -195 369 58 -195 minecraft:water[level=0]
fill 370 58 -195 373 58 -195 minecraft:kelp_plant
setblock 374 58 -195 minecraft:water[level=0]
setblock 375 58 -195 minecraft:kelp_plant
fill 376 58 -195 377 58 -195 minecraft:water[level=0]
setblock 378 58 -195 minecraft:kelp_plant
fill 379 58 -195 391 58 -195 minecraft:water[level=0]
fill 334 58 -196 362 58 -196 minecraft:water[level=0]
setblock 363 58 -196 minecraft:kelp_plant
setblock 364 58 -196 minecraft:water[level=0]
setblock 365 58 -196 minecraft:kelp_plant
fill 366 58 -196 368 58 -196 minecraft:water[level=0]
fill 369 58 -196 370 58 -196 minecraft:kelp_plant
setblock 371 58 -196 minecraft:water[level=0]
setblock 372 58 -196 minecraft:kelp_plant
fill 373 58 -196 377 58 -196 minecraft:water[level=0]
setblock 378 58 -196 minecraft:kelp_plant
fill 379 58 -196 380 58 -196 minecraft:water[level=0]
setblock 381 58 -196 minecraft:kelp_plant
setblock 382 58 -196 minecraft:water[level=0]
setblock 383 58 -196 minecraft:kelp_plant
fill 384 58 -196 391 58 -196 minecraft:water[level=0]
fill 335 58 -197 359 58 -197 minecraft:water[level=0]
setblock 360 58 -197 minecraft:kelp_plant
fill 361 58 -197 370 58 -197 minecraft:water[level=0]
fill 371 58 -197 372 58 -197 minecraft:kelp_plant
fill 373 58 -197 376 58 -197 minecraft:water[level=0]
fill 377 58 -197 379 58 -197 minecraft:kelp_plant
fill 380 58 -197 383 58 -197 minecraft:water[level=0]
setblock 384 58 -197 minecraft:kelp_plant
fill 385 58 -197 391 58 -197 minecraft:water[level=0]
fill 336 58 -198 361 58 -198 minecraft:water[level=0]
setblock 362 58 -198 minecraft:kelp_plant
fill 363 58 -198 367 58 -198 minecraft:water[level=0]
setblock 368 58 -198 minecraft:kelp_plant
fill 369 58 -198 374 58 -198 minecraft:water[level=0]
setblock 375 58 -198 minecraft:kelp_plant
fill 376 58 -198 378 58 -198 minecraft:water[level=0]
fill 379 58 -198 380 58 -198 minecraft:kelp_plant
setblock 381 58 -198 minecraft:water[level=0]
fill 382 58 -198 383 58 -198 minecraft:kelp_plant
fill 384 58 -198 391 58 -198 minecraft:water[level=0]
fill 337 58 -199 361 58 -199 minecraft:water[level=0]
setblock 362 58 -199 minecraft:kelp_plant
fill 363 58 -199 368 58 -199 minecraft:water[level=0]
setblock 369 58 -199 minecraft:kelp_plant
fill 370 58 -199 373 58 -199 minecraft:water[level=0]
setblock 374 58 -199 minecraft:kelp_plant
fill 375 58 -199 377 58 -199 minecraft:water[level=0]
setblock 378 58 -199 minecraft:kelp_plant
fill 379 58 -199 391 58 -199 minecraft:water[level=0]
fill 338 58 -200 365 58 -200 minecraft:water[level=0]
setblock 366 58 -200 minecraft:kelp_plant
fill 367 58 -200 372 58 -200 minecraft:water[level=0]
setblock 373 58 -200 minecraft:kelp_plant
fill 374 58 -200 385 58 -200 minecraft:water[level=0]
setblock 386 58 -200 minecraft:kelp_plant
fill 387 58 -200 391 58 -200 minecraft:water[level=0]
fill 339 58 -201 353 58 -201 minecraft:water[level=0]
fill 354 58 -201 355 58 -201 minecraft:kelp_plant
fill 356 58 -201 364 58 -201 minecraft:water[level=0]
setblock 365 58 -201 minecraft:kelp_plant
fill 366 58 -201 368 58 -201 minecraft:water[level=0]
setblock 369 58 -201 minecraft:kelp_plant
fill 370 58 -201 386 58 -201 minecraft:water[level=0]
setblock 387 58 -201 minecraft:kelp_plant
fill 388 58 -201 391 58 -201 minecraft:water[level=0]
fill 340 58 -202 352 58 -202 minecraft:water[level=0]
setblock 353 58 -202 minecraft:kelp_plant
fill 354 58 -202 355 58 -202 minecraft:water[level=0]
setblock 356 58 -202 minecraft:kelp_plant
fill 357 58 -202 366 58 -202 minecraft:water[level=0]
setblock 367 58 -202 minecraft:kelp_plant
fill 368 58 -202 369 58 -202 minecraft:water[level=0]
setblock 370 58 -202 minecraft:kelp_plant
fill 371 58 -202 372 58 -202 minecraft:water[level=0]
setblock 373 58 -202 minecraft:kelp_plant
fill 374 58 -202 391 58 -202 minecraft:water[level=0]
fill 340 58 -203 368 58 -203 minecraft:water[level=0]
setblock 369 58 -203 minecraft:kelp_plant
setblock 370 58 -203 minecraft:water[level=0]
setblock 371 58 -203 minecraft:kelp_plant
fill 372 58 -203 373 58 -203 minecraft:water[level=0]
setblock 374 58 -203 minecraft:kelp_plant
fill 375 58 -203 391 58 -203 minecraft:water[level=0]
fill 340 58 -204 357 58 -204 minecraft:water[level=0]
setblock 358 58 -204 minecraft:kelp_plant
fill 359 58 -204 362 58 -204 minecraft:water[level=0]
setblock 363 58 -204 minecraft:kelp_plant
fill 364 58 -204 370 58 -204 minecraft:water[level=0]
setblock 371 58 -204 minecraft:kelp_plant
fill 372 58 -204 391 58 -204 minecraft:water[level=0]
fill 343 58 -205 391 58 -205 minecraft:water[level=0]
fill 343 58 -206 391 58 -206 minecraft:water[level=0]
fill 344 58 -207 391 58 -207 minecraft:water[level=0]
fill 344 58 -208 391 58 -208 minecraft:water[level=0]
fill 344 58 -209 375 58 -209 minecraft:water[level=0]
fill 377 58 -209 391 58 -209 minecraft:water[level=0]
fill 347 58 -210 373 58 -210 minecraft:water[level=0]
fill 378 58 -210 391 58 -210 minecraft:water[level=0]
fill 347 58 -211 371 58 -211 minecraft:water[level=0]
fill 379 58 -211 391 58 -211 minecraft:water[level=0]
fill 348 58 -212 370 58 -212 minecraft:water[level=0]
fill 380 58 -212 391 58 -212 minecraft:water[level=0]
fill 359 58 -213 369 58 -213 minecraft:water[level=0]
fill 380 58 -213 391 58 -213 minecraft:water[level=0]
fill 360 58 -214 368 58 -214 minecraft:water[level=0]
fill 380 58 -214 391 58 -214 minecraft:water[level=0]
fill 360 58 -215 367 58 -215 minecraft:water[level=0]
fill 380 58 -215 391 58 -215 minecraft:water[level=0]
fill 360 58 -216 366 58 -216 minecraft:water[level=0]
fill 381 58 -216 391 58 -216 minecraft:water[level=0]
fill 363 58 -217 365 58 -217 minecraft:water[level=0]
fill 385 58 -217 391 58 -217 minecraft:water[level=0]
fill 388 58 -218 391 58 -218 minecraft:water[level=0]
fill 389 58 -219 391 58 -219 minecraft:water[level=0]
fill 390 58 -220 391 58 -220 minecraft:water[level=0]
setblock 391 58 -221 minecraft:water[level=0]
setblock 328 58 -223 minecraft:water[level=0]
fill 328 58 -224 330 58 -224 minecraft:water[level=0]
fill 328 58 -225 330 58 -225 minecraft:water[level=0]
setblock 329 58 -226 minecraft:water[level=0]
fill 332 58 -226 334 58 -226 minecraft:air
setblock 333 58 -227 minecraft:water[level=8]
setblock 334 58 -227 minecraft:air
fill 360 58 -227 362 58 -227 minecraft:air
setblock 329 58 -228 minecraft:air
setblock 357 58 -228 minecraft:air
setblock 360 58 -228 minecraft:air
fill 353 58 -229 358 58 -229 minecraft:air
fill 351 58 -230 354 58 -230 minecraft:air
fill 351 58 -231 352 58 -231 minecraft:air
fill 350 58 -232 351 58 -232 minecraft:air
fill 349 58 -233 350 58 -233 minecraft:air
setblock 369 58 -234 minecraft:air
setblock 368 58 -235 minecraft:air
fill 366 58 -236 368 58 -236 minecraft:air
fill 365 58 -237 367 58 -237 minecraft:air
fill 364 58 -238 367 58 -238 minecraft:air
fill 364 58 -239 366 58 -239 minecraft:air
fill 363 58 -240 365 58 -240 minecraft:air
fill 362 58 -241 364 58 -241 minecraft:air
fill 332 57 -191 348 57 -191 minecraft:water[level=0]
setblock 349 57 -191 minecraft:kelp_plant
fill 350 57 -191 359 57 -191 minecraft:water[level=0]
setblock 360 57 -191 minecraft:kelp_plant
fill 361 57 -191 364 57 -191 minecraft:water[level=0]
setblock 365 57 -191 minecraft:kelp_plant
fill 366 57 -191 369 57 -191 minecraft:water[level=0]
fill 370 57 -191 371 57 -191 minecraft:kelp_plant
setblock 372 57 -191 minecraft:water[level=0]
setblock 373 57 -191 minecraft:kelp_plant
setblock 374 57 -191 minecraft:water[level=0]
setblock 375 57 -191 minecraft:kelp_plant
fill 376 57 -191 377 57 -191 minecraft:water[level=0]
setblock 378 57 -191 minecraft:kelp_plant
fill 379 57 -191 382 57 -191 minecraft:water[level=0]
setblock 383 57 -191 minecraft:tall_seagrass[half=upper]
setblock 384 57 -191 minecraft:water[level=0]
fill 385 57 -191 386 57 -191 minecraft:kelp_plant
fill 387 57 -191 391 57 -191 minecraft:water[level=0]
fill 332 57 -192 345 57 -192 minecraft:water[level=0]
setblock 346 57 -192 minecraft:kelp[age=25]
fill 347 57 -192 348 57 -192 minecraft:water[level=0]
setblock 349 57 -192 minecraft:kelp_plant
fill 350 57 -192 361 57 -192 minecraft:water[level=0]
setblock 362 57 -192 minecraft:kelp_plant
setblock 363 57 -192 minecraft:water[level=0]
setblock 364 57 -192 minecraft:kelp_plant
fill 365 57 -192 366 57 -192 minecraft:water[level=0]
setblock 367 57 -192 minecraft:kelp_plant
fill 368 57 -192 376 57 -192 minecraft:water[level=0]
setblock 377 57 -192 minecraft:kelp_plant
setblock 378 57 -192 minecraft:water[level=0]
fill 379 57 -192 380 57 -192 minecraft:kelp_plant
fill 381 57 -192 382 57 -192 minecraft:water[level=0]
setblock 383 57 -192 minecraft:kelp_plant
fill 384 57 -192 390 57 -192 minecraft:water[level=0]
setblock 391 57 -192 minecraft:kelp_plant
fill 333 57 -193 351 57 -193 minecraft:water[level=0]
setblock 352 57 -193 minecraft:kelp_plant
fill 353 57 -193 369 57 -193 minecraft:water[level=0]
fill 370 57 -193 372 57 -193 minecraft:kelp_plant
setblock 373 57 -193 minecraft:water[level=0]
setblock 374 57 -193 minecraft:kelp_plant
setblock 375 57 -193 minecraft:water[level=0]
setblock 376 57 -193 minecraft:kelp_plant
fill 377 57 -193 381 57 -193 minecraft:water[level=0]
fill 382 57 -193 383 57 -193 minecraft:kelp_plant
fill 384 57 -193 390 57 -193 minecraft:water[level=0]
setblock 391 57 -193 minecraft:kelp_plant
fill 334 57 -194 358 57 -194 minecraft:water[level=0]
setblock 359 57 -194 minecraft:kelp_plant
fill 360 57 -194 369 57 -194 minecraft:water[level=0]
setblock 370 57 -194 minecraft:kelp_plant
setblock 371 57 -194 minecraft:water[level=0]
setblock 372 57 -194 minecraft:kelp_plant
fill 373 57 -194 379 57 -194 minecraft:water[level=0]
setblock 380 57 -194 minecraft:kelp_plant
fill 381 57 -194 391 57 -194 minecraft:water[level=0]
fill 334 57 -195 358 57 -195 minecraft:water[level=0]
setblock 359 57 -195 minecraft:kelp_plant
fill 360 57 -195 366 57 -195 minecraft:water[level=0]
setblock 367 57 -195 minecraft:kelp_plant
fill 368 57 -195 369 57 -195 minecraft:water[level=0]
fill 370 57 -195 373 57 -195 minecraft:kelp_plant
setblock 374 57 -195 minecraft:water[level=0]
setblock 375 57 -195 minecraft:kelp_plant
fill 376 57 -195 377 57 -195 minecraft:water[level=0]
setblock 378 57 -195 minecraft:kelp_plant
fill 379 57 -195 391 57 -195 minecraft:water[level=0]
fill 334 57 -196 362 57 -196 minecraft:water[level=0]
setblock 363 57 -196 minecraft:kelp_plant
setblock 364 57 -196 minecraft:water[level=0]
setblock 365 57 -196 minecraft:kelp_plant
fill 366 57 -196 368 57 -196 minecraft:water[level=0]
fill 369 57 -196 370 57 -196 minecraft:kelp_plant
setblock 371 57 -196 minecraft:water[level=0]
setblock 372 57 -196 minecraft:kelp_plant
fill 373 57 -196 377 57 -196 minecraft:water[level=0]
setblock 378 57 -196 minecraft:kelp_plant
fill 379 57 -196 380 57 -196 minecraft:water[level=0]
setblock 381 57 -196 minecraft:kelp_plant
setblock 382 57 -196 minecraft:water[level=0]
setblock 383 57 -196 minecraft:kelp_plant
fill 384 57 -196 391 57 -196 minecraft:water[level=0]
fill 336 57 -197 359 57 -197 minecraft:water[level=0]
setblock 360 57 -197 minecraft:kelp_plant
fill 361 57 -197 370 57 -197 minecraft:water[level=0]
fill 371 57 -197 372 57 -197 minecraft:kelp_plant
fill 373 57 -197 376 57 -197 minecraft:water[level=0]
fill 377 57 -197 379 57 -197 minecraft:kelp_plant
fill 380 57 -197 383 57 -197 minecraft:water[level=0]
setblock 384 57 -197 minecraft:kelp_plant
fill 385 57 -197 390 57 -197 minecraft:water[level=0]
setblock 391 57 -197 minecraft:kelp[age=25]
fill 337 57 -198 361 57 -198 minecraft:water[level=0]
setblock 362 57 -198 minecraft:kelp_plant
fill 363 57 -198 367 57 -198 minecraft:water[level=0]
setblock 368 57 -198 minecraft:kelp_plant
fill 369 57 -198 374 57 -198 minecraft:water[level=0]
setblock 375 57 -198 minecraft:kelp_plant
fill 376 57 -198 378 57 -198 minecraft:water[level=0]
fill 379 57 -198 380 57 -198 minecraft:kelp_plant
setblock 381 57 -198 minecraft:water[level=0]
fill 382 57 -198 383 57 -198 minecraft:kelp_plant
fill 384 57 -198 391 57 -198 minecraft:water[level=0]
fill 338 57 -199 361 57 -199 minecraft:water[level=0]
setblock 362 57 -199 minecraft:kelp_plant
fill 363 57 -199 368 57 -199 minecraft:water[level=0]
setblock 369 57 -199 minecraft:kelp_plant
fill 370 57 -199 373 57 -199 minecraft:water[level=0]
setblock 374 57 -199 minecraft:kelp_plant
fill 375 57 -199 377 57 -199 minecraft:water[level=0]
setblock 378 57 -199 minecraft:kelp_plant
fill 379 57 -199 391 57 -199 minecraft:water[level=0]
fill 339 57 -200 355 57 -200 minecraft:water[level=0]
setblock 356 57 -200 minecraft:kelp[age=25]
fill 357 57 -200 365 57 -200 minecraft:water[level=0]
setblock 366 57 -200 minecraft:kelp_plant
fill 367 57 -200 372 57 -200 minecraft:water[level=0]
setblock 373 57 -200 minecraft:kelp_plant
fill 374 57 -200 385 57 -200 minecraft:water[level=0]
setblock 386 57 -200 minecraft:kelp_plant
fill 387 57 -200 391 57 -200 minecraft:water[level=0]
fill 340 57 -201 353 57 -201 minecraft:water[level=0]
fill 354 57 -201 355 57 -201 minecraft:kelp_plant
fill 356 57 -201 364 57 -201 minecraft:water[level=0]
setblock 365 57 -201 minecraft:kelp_plant
fill 366 57 -201 368 57 -201 minecraft:water[level=0]
setblock 369 57 -201 minecraft:kelp_plant
fill 370 57 -201 386 57 -201 minecraft:water[level=0]
setblock 387 57 -201 minecraft:kelp_plant
fill 388 57 -201 391 57 -201 minecraft:water[level=0]
fill 340 57 -202 352 57 -202 minecraft:water[level=0]
setblock 353 57 -202 minecraft:kelp_plant
fill 354 57 -202 355 57 -202 minecraft:water[level=0]
setblock 356 57 -202 minecraft:kelp_plant
fill 357 57 -202 366 57 -202 minecraft:water[level=0]
setblock 367 57 -202 minecraft:kelp_plant
fill 368 57 -202 369 57 -202 minecraft:water[level=0]
setblock 370 57 -202 minecraft:kelp_plant
fill 371 57 -202 372 57 -202 minecraft:water[level=0]
setblock 373 57 -202 minecraft:kelp_plant
fill 374 57 -202 391 57 -202 minecraft:water[level=0]
fill 340 57 -203 368 57 -203 minecraft:water[level=0]
setblock 369 57 -203 minecraft:kelp_plant
setblock 370 57 -203 minecraft:water[level=0]
setblock 371 57 -203 minecraft:kelp_plant
fill 372 57 -203 373 57 -203 minecraft:water[level=0]
setblock 374 57 -203 minecraft:kelp_plant
fill 375 57 -203 391 57 -203 minecraft:water[level=0]
fill 340 57 -204 357 57 -204 minecraft:water[level=0]
setblock 358 57 -204 minecraft:kelp_plant
fill 359 57 -204 362 57 -204 minecraft:water[level=0]
setblock 363 57 -204 minecraft:kelp_plant
fill 364 57 -204 370 57 -204 minecraft:water[level=0]
setblock 371 57 -204 minecraft:kelp_plant
fill 372 57 -204 391 57 -204 minecraft:water[level=0]
fill 343 57 -205 391 57 -205 minecraft:water[level=0]
fill 344 57 -206 391 57 -206 minecraft:water[level=0]
fill 344 57 -207 375 57 -207 minecraft:water[level=0]
fill 377 57 -207 391 57 -207 minecraft:water[level=0]
fill 344 57 -208 375 57 -208 minecraft:water[level=0]
fill 378 57 -208 391 57 -208 minecraft:water[level=0]
fill 345 57 -209 374 57 -209 minecraft:water[level=0]
fill 379 57 -209 391 57 -209 minecraft:water[level=0]
fill 347 57 -210 372 57 -210 minecraft:water[level=0]
fill 380 57 -210 391 57 -210 minecraft:water[level=0]
fill 348 57 -211 370 57 -211 minecraft:water[level=0]
fill 380 57 -211 391 57 -211 minecraft:water[level=0]
fill 348 57 -212 368 57 -212 minecraft:water[level=0]
fill 381 57 -212 391 57 -212 minecraft:water[level=0]
fill 359 57 -213 367 57 -213 minecraft:water[level=0]
fill 381 57 -213 391 57 -213 minecraft:water[level=0]
fill 360 57 -214 367 57 -214 minecraft:water[level=0]
fill 382 57 -214 391 57 -214 minecraft:water[level=0]
fill 360 57 -215 366 57 -215 minecraft:water[level=0]
fill 382 57 -215 391 57 -215 minecraft:water[level=0]
fill 361 57 -216 366 57 -216 minecraft:water[level=0]
fill 383 57 -216 391 57 -216 minecraft:water[level=0]
setblock 364 57 -217 minecraft:water[level=0]
fill 387 57 -217 391 57 -217 minecraft:water[level=0]
fill 389 57 -218 391 57 -218 minecraft:water[level=0]
fill 390 57 -219 391 57 -219 minecraft:water[level=0]
setblock 391 57 -220 minecraft:water[level=0]
setblock 333 57 -225 minecraft:air
fill 332 57 -226 334 57 -226 minecraft:air
setblock 333 57 -227 minecraft:water[level=8]
setblock 334 57 -227 minecraft:air
fill 328 57 -228 329 57 -228 minecraft:air
setblock 355 57 -228 minecraft:air
setblock 354 57 -229 minecraft:air
setblock 367 57 -236 minecraft:air
fill 365 57 -237 367 57 -237 minecraft:air
fill 364 57 -238 366 57 -238 minecraft:air
fill 363 57 -239 365 57 -239 minecraft:air
fill 362 57 -240 365 57 -240 minecraft:air
fill 361 57 -241 364 57 -241 minecraft:air
fill 360 57 -242 363 57 -242 minecraft:air
fill 332 56 -191 348 56 -191 minecraft:water[level=0]
setblock 349 56 -191 minecraft:kelp_plant
fill 350 56 -191 359 56 -191 minecraft:water[level=0]
setblock 360 56 -191 minecraft:kelp_plant
fill 361 56 -191 364 56 -191 minecraft:water[level=0]
setblock 365 56 -191 minecraft:kelp_plant
fill 366 56 -191 369 56 -191 minecraft:water[level=0]
fill 370 56 -191 371 56 -191 minecraft:kelp_plant
setblock 372 56 -191 minecraft:water[level=0]
setblock 373 56 -191 minecraft:kelp_plant
setblock 374 56 -191 minecraft:water[level=0]
setblock 375 56 -191 minecraft:kelp_plant
fill 376 56 -191 377 56 -191 minecraft:water[level=0]
setblock 378 56 -191 minecraft:kelp_plant
fill 379 56 -191 382 56 -191 minecraft:water[level=0]
setblock 383 56 -191 minecraft:tall_seagrass[half=lower]
setblock 384 56 -191 minecraft:water[level=0]
fill 385 56 -191 386 56 -191 minecraft:kelp_plant
fill 387 56 -191 391 56 -191 minecraft:water[level=0]
fill 333 56 -192 345 56 -192 minecraft:water[level=0]
setblock 346 56 -192 minecraft:kelp_plant
fill 347 56 -192 348 56 -192 minecraft:water[level=0]
setblock 349 56 -192 minecraft:kelp_plant
fill 350 56 -192 361 56 -192 minecraft:water[level=0]
setblock 362 56 -192 minecraft:kelp_plant
setblock 363 56 -192 minecraft:water[level=0]
setblock 364 56 -192 minecraft:kelp_plant
fill 365 56 -192 366 56 -192 minecraft:water[level=0]
setblock 367 56 -192 minecraft:kelp_plant
fill 368 56 -192 376 56 -192 minecraft:water[level=0]
setblock 377 56 -192 minecraft:kelp_plant
setblock 378 56 -192 minecraft:water[level=0]
fill 379 56 -192 380 56 -192 minecraft:kelp_plant
fill 381 56 -192 382 56 -192 minecraft:water[level=0]
setblock 383 56 -192 minecraft:kelp_plant
fill 384 56 -192 390 56 -192 minecraft:water[level=0]
setblock 391 56 -192 minecraft:kelp_plant
fill 334 56 -193 351 56 -193 minecraft:water[level=0]
setblock 352 56 -193 minecraft:kelp_plant
fill 353 56 -193 369 56 -193 minecraft:water[level=0]
fill 370 56 -193 372 56 -193 minecraft:kelp_plant
setblock 373 56 -193 minecraft:water[level=0]
setblock 374 56 -193 minecraft:kelp_plant
setblock 375 56 -193 minecraft:water[level=0]
setblock 376 56 -193 minecraft:kelp_plant
fill 377 56 -193 381 56 -193 minecraft:water[level=0]
fill 382 56 -193 383 56 -193 minecraft:kelp_plant
fill 384 56 -193 390 56 -193 minecraft:water[level=0]
setblock 391 56 -193 minecraft:kelp_plant
fill 334 56 -194 358 56 -194 minecraft:water[level=0]
setblock 359 56 -194 minecraft:kelp_plant
fill 360 56 -194 369 56 -194 minecraft:water[level=0]
setblock 370 56 -194 minecraft:kelp_plant
setblock 371 56 -194 minecraft:water[level=0]
setblock 372 56 -194 minecraft:kelp_plant
fill 373 56 -194 379 56 -194 minecraft:water[level=0]
setblock 380 56 -194 minecraft:kelp_plant
fill 381 56 -194 391 56 -194 minecraft:water[level=0]
fill 334 56 -195 358 56 -195 minecraft:water[level=0]
setblock 359 56 -195 minecraft:kelp_plant
fill 360 56 -195 366 56 -195 minecraft:water[level=0]
setblock 367 56 -195 minecraft:kelp_plant
fill 368 56 -195 369 56 -195 minecraft:water[level=0]
fill 370 56 -195 373 56 -195 minecraft:kelp_plant
setblock 374 56 -195 minecraft:water[level=0]
setblock 375 56 -195 minecraft:kelp_plant
fill 376 56 -195 377 56 -195 minecraft:water[level=0]
setblock 378 56 -195 minecraft:kelp_plant
fill 379 56 -195 391 56 -195 minecraft:water[level=0]
fill 335 56 -196 362 56 -196 minecraft:water[level=0]
setblock 363 56 -196 minecraft:kelp_plant
setblock 364 56 -196 minecraft:water[level=0]
setblock 365 56 -196 minecraft:kelp_plant
fill 366 56 -196 368 56 -196 minecraft:water[level=0]
fill 369 56 -196 370 56 -196 minecraft:kelp_plant
setblock 371 56 -196 minecraft:water[level=0]
setblock 372 56 -196 minecraft:kelp_plant
fill 373 56 -196 377 56 -196 minecraft:water[level=0]
setblock 378 56 -196 minecraft:kelp_plant
fill 379 56 -196 380 56 -196 minecraft:water[level=0]
setblock 381 56 -196 minecraft:kelp_plant
setblock 382 56 -196 minecraft:water[level=0]
setblock 383 56 -196 minecraft:kelp_plant
fill 384 56 -196 391 56 -196 minecraft:water[level=0]
fill 336 56 -197 359 56 -197 minecraft:water[level=0]
setblock 360 56 -197 minecraft:kelp_plant
fill 361 56 -197 370 56 -197 minecraft:water[level=0]
fill 371 56 -197 372 56 -197 minecraft:kelp_plant
fill 373 56 -197 376 56 -197 minecraft:water[level=0]
fill 377 56 -197 379 56 -197 minecraft:kelp_plant
fill 380 56 -197 383 56 -197 minecraft:water[level=0]
setblock 384 56 -197 minecraft:kelp_plant
fill 385 56 -197 390 56 -197 minecraft:water[level=0]
setblock 391 56 -197 minecraft:kelp_plant
fill 337 56 -198 361 56 -198 minecraft:water[level=0]
setblock 362 56 -198 minecraft:kelp_plant
fill 363 56 -198 367 56 -198 minecraft:water[level=0]
setblock 368 56 -198 minecraft:kelp_plant
fill 369 56 -198 374 56 -198 minecraft:water[level=0]
setblock 375 56 -198 minecraft:kelp_plant
setblock 380 56 -198 minecraft:kelp_plant
fill 385 56 -198 391 56 -198 minecraft:water[level=0]
fill 339 56 -199 354 56 -199 minecraft:water[level=0]
setblock 355 56 -199 minecraft:kelp[age=25]
fill 356 56 -199 361 56 -199 minecraft:water[level=0]
setblock 362 56 -199 minecraft:kelp_plant
fill 363 56 -199 368 56 -199 minecraft:water[level=0]
setblock 369 56 -199 minecraft:kelp_plant
fill 370 56 -199 373 56 -199 minecraft:water[level=0]
setblock 374 56 -199 minecraft:kelp_plant
fill 385 56 -199 391 56 -199 minecraft:water[level=0]
fill 339 56 -200 355 56 -200 minecraft:water[level=0]
setblock 356 56 -200 minecraft:kelp_plant
fill 357 56 -200 365 56 -200 minecraft:water[level=0]
setblock 366 56 -200 minecraft:kelp_plant
fill 367 56 -200 372 56 -200 minecraft:water[level=0]
setblock 373 56 -200 minecraft:kelp_plant
setblock 385 56 -200 minecraft:water[level=0]
setblock 386 56 -200 minecraft:kelp_plant
fill 387 56 -200 391 56 -200 minecraft:water[level=0]
fill 340 56 -201 353 56 -201 minecraft:water[level=0]
fill 354 56 -201 355 56 -201 minecraft:kelp_plant
fill 356 56 -201 364 56 -201 minecraft:water[level=0]
setblock 365 56 -201 minecraft:kelp_plant
fill 366 56 -201 368 56 -201 minecraft:water[level=0]
setblock 369 56 -201 minecraft:kelp_plant
fill 370 56 -201 375 56 -201 minecraft:water[level=0]
fill 385 56 -201 386 56 -201 minecraft:water[level=0]
setblock 387 56 -201 minecraft:kelp_plant
fill 388 56 -201 391 56 -201 minecraft:water[level=0]
fill 340 56 -202 352 56 -202 minecraft:water[level=0]
setblock 353 56 -202 minecraft:kelp_plant
fill 354 56 -202 355 56 -202 minecraft:water[level=0]
setblock 356 56 -202 minecraft:kelp_plant
fill 357 56 -202 366 56 -202 minecraft:water[level=0]
setblock 367 56 -202 minecraft:kelp_plant
fill 368 56 -202 369 56 -202 minecraft:water[level=0]
setblock 370 56 -202 minecraft:kelp_plant
fill 371 56 -202 372 56 -202 minecraft:water[level=0]
setblock 373 56 -202 minecraft:kelp_plant
fill 374 56 -202 376 56 -202 minecraft:water[level=0]
fill 385 56 -202 391 56 -202 minecraft:water[level=0]
fill 340 56 -203 368 56 -203 minecraft:water[level=0]
setblock 369 56 -203 minecraft:kelp_plant
setblock 370 56 -203 minecraft:water[level=0]
setblock 371 56 -203 minecraft:kelp_plant
fill 372 56 -203 373 56 -203 minecraft:water[level=0]
setblock 374 56 -203 minecraft:kelp_plant
fill 375 56 -203 377 56 -203 minecraft:water[level=0]
fill 385 56 -203 391 56 -203 minecraft:water[level=0]
fill 340 56 -204 357 56 -204 minecraft:water[level=0]
setblock 358 56 -204 minecraft:kelp_plant
fill 359 56 -204 362 56 -204 minecraft:water[level=0]
setblock 363 56 -204 minecraft:kelp_plant
fill 364 56 -204 370 56 -204 minecraft:water[level=0]
setblock 371 56 -204 minecraft:kelp_plant
fill 372 56 -204 377 56 -204 minecraft:water[level=0]
fill 385 56 -204 391 56 -204 minecraft:water[level=0]
fill 343 56 -205 375 56 -205 minecraft:water[level=0]
fill 385 56 -205 391 56 -205 minecraft:water[level=0]
fill 344 56 -206 375 56 -206 minecraft:water[level=0]
fill 385 56 -206 391 56 -206 minecraft:water[level=0]
fill 344 56 -207 374 56 -207 minecraft:water[level=0]
fill 385 56 -207 391 56 -207 minecraft:water[level=0]
fill 344 56 -208 374 56 -208 minecraft:water[level=0]
fill 385 56 -208 391 56 -208 minecraft:water[level=0]
fill 346 56 -209 372 56 -209 minecraft:water[level=0]
fill 383 56 -209 391 56 -209 minecraft:water[level=0]
fill 347 56 -210 370 56 -210 minecraft:water[level=0]
fill 383 56 -210 391 56 -210 minecraft:water[level=0]
fill 348 56 -211 368 56 -211 minecraft:water[level=0]
fill 383 56 -211 391 56 -211 minecraft:water[level=0]
fill 348 56 -212 367 56 -212 minecraft:water[level=0]
fill 383 56 -212 391 56 -212 minecraft:water[level=0]
fill 360 56 -213 366 56 -213 minecraft:water[level=0]
fill 383 56 -213 391 56 -213 minecraft:water[level=0]
fill 360 56 -214 366 56 -214 minecraft:water[level=0]
fill 383 56 -214 391 56 -214 minecraft:water[level=0]
fill 361 56 -215 365 56 -215 minecraft:water[level=0]
fill 384 56 -215 391 56 -215 minecraft:water[level=0]
fill 362 56 -216 365 56 -216 minecraft:water[level=0]
fill 384 56 -216 391 56 -216 minecraft:water[level=0]
fill 388 56 -217 391 56 -217 minecraft:water[level=0]
fill 390 56 -218 391 56 -218 minecraft:water[level=0]
setblock 391 56 -219 minecraft:water[level=0]
setblock 333 56 -224 minecraft:air
fill 332 56 -225 334 56 -225 minecraft:air
setblock 332 56 -226 minecraft:air
setblock 333 56 -226 minecraft:water[level=1]
fill 334 56 -226 335 56 -226 minecraft:air
fill 328 56 -227 329 56 -227 minecraft:air
setblock 333 56 -227 minecraft:water[level=8]
setblock 334 56 -227 minecraft:water[level=1]
setblock 328 56 -228 minecraft:air
setblock 366 56 -237 minecraft:air
fill 363 56 -238 366 56 -238 minecraft:air
fill 363 56 -239 365 56 -239 minecraft:air
fill 362 56 -240 364 56 -240 minecraft:air
fill 361 56 -241 363 56 -241 minecraft:air
fill 360 56 -242 362 56 -242 minecraft:air
fill 333 55 -191 348 55 -191 minecraft:water[level=0]
setblock 349 55 -191 minecraft:kelp_plant
fill 350 55 -191 356 55 -191 minecraft:water[level=0]
setblock 357 55 -191 minecraft:seagrass
fill 358 55 -191 359 55 -191 minecraft:water[level=0]
setblock 360 55 -191 minecraft:kelp_plant
setblock 361 55 -191 minecraft:water[level=0]
setblock 362 55 -191 minecraft:seagrass
fill 363 55 -191 364 55 -191 minecraft:water[level=0]
setblock 365 55 -191 minecraft:kelp_plant
setblock 366 55 -191 minecraft:seagrass
fill 367 55 -191 369 55 -191 minecraft:water[level=0]
fill 370 55 -191 371 55 -191 minecraft:kelp_plant
setblock 372 55 -191 minecraft:water[level=0]
setblock 373 55 -191 minecraft:kelp_plant
setblock 374 55 -191 minecraft:water[level=0]
setblock 375 55 -191 minecraft:kelp_plant
fill 376 55 -191 377 55 -191 minecraft:water[level=0]
setblock 378 55 -191 minecraft:kelp_plant
fill 379 55 -191 381 55 -191 minecraft:water[level=0]
fill 385 55 -191 386 55 -191 minecraft:kelp_plant
fill 387 55 -191 391 55 -191 minecraft:water[level=0]
fill 334 55 -192 345 55 -192 minecraft:water[level=0]
setblock 346 55 -192 minecraft:kelp_plant
fill 347 55 -192 348 55 -192 minecraft:water[level=0]
setblock 349 55 -192 minecraft:kelp_plant
setblock 350 55 -192 minecraft:water[level=0]
fill 351 55 -192 352 55 -192 minecraft:tall_seagrass[half=upper]
fill 353 55 -192 361 55 -192 minecraft:water[level=0]
setblock 362 55 -192 minecraft:kelp_plant
setblock 363 55 -192 minecraft:water[level=0]
setblock 364 55 -192 minecraft:kelp_plant
fill 365 55 -192 366 55 -192 minecraft:water[level=0]
setblock 367 55 -192 minecraft:kelp_plant
setblock 368 55 -192 minecraft:water[level=0]
setblock 369 55 -192 minecraft:seagrass
fill 370 55 -192 376 55 -192 minecraft:water[level=0]
setblock 377 55 -192 minecraft:kelp_plant
setblock 378 55 -192 minecraft:water[level=0]
fill 379 55 -192 380 55 -192 minecraft:kelp_plant
fill 385 55 -192 390 55 -192 minecraft:water[level=0]
setblock 391 55 -192 minecraft:kelp_plant
fill 335 55 -193 351 55 -193 minecraft:water[level=0]
setblock 352 55 -193 minecraft:kelp_plant
fill 353 55 -193 369 55 -193 minecraft:water[level=0]
fill 370 55 -193 372 55 -193 minecraft:kelp_plant
setblock 373 55 -193 minecraft:water[level=0]
setblock 374 55 -193 minecraft:kelp_plant
setblock 375 55 -193 minecraft:water[level=0]
setblock 376 55 -193 minecraft:kelp_plant
fill 377 55 -193 379 55 -193 minecraft:water[level=0]
fill 385 55 -193 390 55 -193 minecraft:water[level=0]
setblock 391 55 -193 minecraft:kelp_plant
fill 335 55 -194 351 55 -194 minecraft:water[level=0]
setblock 352 55 -194 minecraft:tall_seagrass[half=upper]
fill 353 55 -194 358 55 -194 minecraft:water[level=0]
setblock 359 55 -194 minecraft:kelp_plant
fill 360 55 -194 369 55 -194 minecraft:water[level=0]
setblock 370 55 -194 minecraft:kelp_plant
setblock 371 55 -194 minecraft:water[level=0]
setblock 372 55 -194 minecraft:kelp_plant
setblock 373 55 -194 minecraft:water[level=0]
fill 385 55 -194 391 55 -194 minecraft:water[level=0]
fill 335 55 -195 358 55 -195 minecraft:water[level=0]
setblock 359 55 -195 minecraft:kelp_plant
fill 360 55 -195 366 55 -195 minecraft:water[level=0]
setblock 367 55 -195 minecraft:kelp_plant
fill 368 55 -195 369 55 -195 minecraft:water[level=0]
fill 370 55 -195 372 55 -195 minecraft:kelp_plant
fill 385 55 -195 391 55 -195 minecraft:water[level=0]
fill 335 55 -196 362 55 -196 minecraft:water[level=0]
setblock 363 55 -196 minecraft:kelp_plant
setblock 364 55 -196 minecraft:water[level=0]
setblock 365 55 -196 minecraft:kelp_plant
fill 366 55 -196 368 55 -196 minecraft:water[level=0]
fill 369 55 -196 370 55 -196 minecraft:kelp_plant
setblock 371 55 -196 minecraft:water[level=0]
fill 385 55 -196 391 55 -196 minecraft:water[level=0]
fill 336 55 -197 359 55 -197 minecraft:water[level=0]
setblock 360 55 -197 minecraft:kelp_plant
fill 361 55 -197 370 55 -197 minecraft:water[level=0]
setblock 371 55 -197 minecraft:kelp_plant
fill 385 55 -197 390 55 -197 minecraft:water[level=0]
setblock 391 55 -197 minecraft:kelp_plant
fill 338 55 -198 354 55 -198 minecraft:water[level=0]
setblock 355 55 -198 minecraft:tall_seagrass[half=upper]
fill 356 55 -198 357 55 -198 minecraft:water[level=0]
setblock 358 55 -198 minecraft:tall_seagrass[half=upper]
fill 359 55 -198 361 55 -198 minecraft:water[level=0]
setblock 362 55 -198 minecraft:kelp_plant
fill 363 55 -198 367 55 -198 minecraft:water[level=0]
setblock 368 55 -198 minecraft:kelp_plant
fill 369 55 -198 371 55 -198 minecraft:water[level=0]
fill 385 55 -198 391 55 -198 minecraft:water[level=0]
fill 339 55 -199 354 55 -199 minecraft:water[level=0]
setblock 355 55 -199 minecraft:kelp_plant
fill 356 55 -199 361 55 -199 minecraft:water[level=0]
setblock 362 55 -199 minecraft:kelp_plant
fill 363 55 -199 368 55 -199 minecraft:water[level=0]
setblock 369 55 -199 minecraft:kelp_plant
setblock 370 55 -199 minecraft:water[level=0]
fill 385 55 -199 391 55 -199 minecraft:water[level=0]
fill 340 55 -200 355 55 -200 minecraft:water[level=0]
setblock 356 55 -200 minecraft:kelp_plant
fill 357 55 -200 365 55 -200 minecraft:water[level=0]
setblock 366 55 -200 minecraft:kelp_plant
fill 367 55 -200 370 55 -200 minecraft:water[level=0]
setblock 385 55 -200 minecraft:water[level=0]
setblock 386 55 -200 minecraft:kelp_plant
fill 387 55 -200 391 55 -200 minecraft:water[level=0]
fill 340 55 -201 353 55 -201 minecraft:water[level=0]
fill 354 55 -201 355 55 -201 minecraft:kelp_plant
fill 356 55 -201 364 55 -201 minecraft:water[level=0]
setblock 365 55 -201 minecraft:kelp_plant
fill 366 55 -201 368 55 -201 minecraft:water[level=0]
setblock 369 55 -201 minecraft:kelp_plant
fill 370 55 -201 371 55 -201 minecraft:water[level=0]
fill 385 55 -201 386 55 -201 minecraft:water[level=0]
setblock 387 55 -201 minecraft:kelp_plant
fill 388 55 -201 391 55 -201 minecraft:water[level=0]
fill 340 55 -202 352 55 -202 minecraft:water[level=0]
setblock 353 55 -202 minecraft:kelp_plant
fill 354 55 -202 355 55 -202 minecraft:water[level=0]
setblock 356 55 -202 minecraft:kelp_plant
fill 357 55 -202 366 55 -202 minecraft:water[level=0]
setblock 367 55 -202 minecraft:kelp_plant
fill 368 55 -202 369 55 -202 minecraft:water[level=0]
setblock 370 55 -202 minecraft:kelp_plant
fill 371 55 -202 372 55 -202 minecraft:water[level=0]
setblock 373 55 -202 minecraft:kelp_plant
fill 386 55 -202 391 55 -202 minecraft:water[level=0]
fill 341 55 -203 368 55 -203 minecraft:water[level=0]
setblock 369 55 -203 minecraft:kelp_plant
setblock 370 55 -203 minecraft:water[level=0]
setblock 371 55 -203 minecraft:kelp_plant
fill 372 55 -203 373 55 -203 minecraft:water[level=0]
setblock 374 55 -203 minecraft:kelp_plant
fill 386 55 -203 391 55 -203 minecraft:water[level=0]
fill 342 55 -204 357 55 -204 minecraft:water[level=0]
setblock 358 55 -204 minecraft:kelp_plant
fill 359 55 -204 362 55 -204 minecraft:water[level=0]
setblock 363 55 -204 minecraft:kelp_plant
fill 364 55 -204 370 55 -204 minecraft:water[level=0]
setblock 371 55 -204 minecraft:kelp_plant
fill 372 55 -204 374 55 -204 minecraft:water[level=0]
fill 386 55 -204 391 55 -204 minecraft:water[level=0]
fill 344 55 -205 373 55 -205 minecraft:water[level=0]
fill 386 55 -205 391 55 -205 minecraft:water[level=0]
fill 344 55 -206 373 55 -206 minecraft:water[level=0]
fill 387 55 -206 391 55 -206 minecraft:water[level=0]
fill 344 55 -207 373 55 -207 minecraft:water[level=0]
fill 387 55 -207 390 55 -207 minecraft:water[level=0]
setblock 391 55 -207 minecraft:kelp[age=25]
fill 344 55 -208 373 55 -208 minecraft:water[level=0]
fill 388 55 -208 391 55 -208 minecraft:water[level=0]
fill 347 55 -209 370 55 -209 minecraft:water[level=0]
fill 387 55 -209 391 55 -209 minecraft:water[level=0]
fill 348 55 -210 353 55 -210 minecraft:water[level=0]
fill 357 55 -210 367 55 -210 minecraft:water[level=0]
fill 386 55 -210 391 55 -210 minecraft:water[level=0]
fill 348 55 -211 350 55 -211 minecraft:water[level=0]
fill 358 55 -211 365 55 -211 minecraft:water[level=0]
fill 385 55 -211 391 55 -211 minecraft:water[level=0]
fill 348 55 -212 349 55 -212 minecraft:water[level=0]
fill 359 55 -212 365 55 -212 minecraft:water[level=0]
fill 384 55 -212 391 55 -212 minecraft:water[level=0]
fill 360 55 -213 364 55 -213 minecraft:water[level=0]
fill 385 55 -213 391 55 -213 minecraft:water[level=0]
fill 363 55 -214 364 55 -214 minecraft:water[level=0]
fill 386 55 -214 391 55 -214 minecraft:water[level=0]
setblock 364 55 -215 minecraft:water[level=0]
fill 386 55 -215 391 55 -215 minecraft:water[level=0]
setblock 364 55 -216 minecraft:water[level=0]
fill 386 55 -216 391 55 -216 minecraft:water[level=0]
fill 389 55 -217 391 55 -217 minecraft:water[level=0]
fill 390 55 -218 391 55 -218 minecraft:water[level=0]
setblock 391 55 -219 minecraft:water[level=0]
setblock 328 55 -223 minecraft:air
fill 328 55 -224 329 55 -224 minecraft:air
fill 333 55 -224 334 55 -224 minecraft:air
fill 328 55 -225 329 55 -225 minecraft:air
fill 332 55 -225 334 55 -225 minecraft:air
fill 328 55 -226 329 55 -226 minecraft:air
setblock 333 55 -226 minecraft:water[level=8]
setblock 334 55 -226 minecraft:air
setblock 328 55 -227 minecraft:air
setblock 334 55 -227 minecraft:water[level=8]
setblock 366 55 -237 minecraft:air
fill 363 55 -238 365 55 -238 minecraft:air
fill 362 55 -239 364 55 -239 minecraft:air
fill 361 55 -240 364 55 -240 minecraft:air
fill 361 55 -241 363 55 -241 minecraft:air
fill 360 55 -242 362 55 -242 minecraft:air
fill 335 54 -191 343 54 -191 minecraft:water[level=0]
setblock 344 54 -191 minecraft:tall_seagrass[half=upper]
fill 345 54 -191 347 54 -191 minecraft:water[level=0]
setblock 348 54 -191 minecraft:seagrass
setblock 349 54 -191 minecraft:kelp_plant
fill 350 54 -191 356 54 -191 minecraft:water[level=0]
setblock 386 54 -191 minecraft:kelp_plant
fill 387 54 -191 391 54 -191 minecraft:water[level=0]
fill 335 54 -192 345 54 -192 minecraft:water[level=0]
setblock 346 54 -192 minecraft:kelp_plant
fill 347 54 -192 348 54 -192 minecraft:water[level=0]
setblock 349 54 -192 minecraft:kelp_plant
setblock 350 54 -192 minecraft:water[level=0]
fill 351 54 -192 352 54 -192 minecraft:tall_seagrass[half=lower]
fill 353 54 -192 354 54 -192 minecraft:water[level=0]
setblock 355 54 -192 minecraft:seagrass
fill 356 54 -192 357 54 -192 minecraft:water[level=0]
setblock 366 54 -192 minecraft:water[level=0]
setblock 367 54 -192 minecraft:kelp_plant
setblock 368 54 -192 minecraft:water[level=0]
fill 386 54 -192 390 54 -192 minecraft:water[level=0]
setblock 391 54 -192 minecraft:kelp_plant
fill 335 54 -193 351 54 -193 minecraft:water[level=0]
setblock 352 54 -193 minecraft:kelp_plant
fill 353 54 -193 356 54 -193 minecraft:water[level=0]
setblock 357 54 -193 minecraft:seagrass
setblock 368 54 -193 minecraft:water[level=0]
fill 386 54 -193 390 54 -193 minecraft:water[level=0]
setblock 391 54 -193 minecraft:kelp_plant
fill 335 54 -194 344 54 -194 minecraft:water[level=0]
setblock 345 54 -194 minecraft:tall_seagrass[half=upper]
fill 346 54 -194 349 54 -194 minecraft:water[level=0]
fill 350 54 -194 351 54 -194 minecraft:seagrass
setblock 352 54 -194 minecraft:tall_seagrass[half=lower]
fill 353 54 -194 357 54 -194 minecraft:water[level=0]
fill 386 54 -194 391 54 -194 minecraft:water[level=0]
fill 335 54 -195 350 54 -195 minecraft:water[level=0]
setblock 351 54 -195 minecraft:seagrass
setblock 352 54 -195 minecraft:water[level=0]
fill 353 54 -195 354 54 -195 minecraft:seagrass
setblock 355 54 -195 minecraft:water[level=0]
setblock 356 54 -195 minecraft:seagrass
setblock 357 54 -195 minecraft:water[level=0]
fill 386 54 -195 391 54 -195 minecraft:water[level=0]
fill 336 54 -196 347 54 -196 minecraft:water[level=0]
setblock 348 54 -196 minecraft:tall_seagrass[half=upper]
fill 349 54 -196 356 54 -196 minecraft:water[level=0]
fill 386 54 -196 391 54 -196 minecraft:water[level=0]
fill 337 54 -197 347 54 -197 minecraft:water[level=0]
setblock 348 54 -197 minecraft:tall_seagrass[half=upper]
setblock 349 54 -197 minecraft:water[level=0]
setblock 350 54 -197 minecraft:tall_seagrass[half=upper]
fill 351 54 -197 352 54 -197 minecraft:water[level=0]
setblock 353 54 -197 minecraft:seagrass
fill 354 54 -197 355 54 -197 minecraft:water[level=0]
setblock 356 54 -197 minecraft:seagrass
fill 357 54 -197 358 54 -197 minecraft:water[level=0]
fill 386 54 -197 390 54 -197 minecraft:water[level=0]
setblock 391 54 -197 minecraft:kelp_plant
fill 339 54 -198 354 54 -198 minecraft:water[level=0]
setblock 355 54 -198 minecraft:tall_seagrass[half=lower]
setblock 356 54 -198 minecraft:water[level=0]
setblock 357 54 -198 minecraft:seagrass
setblock 358 54 -198 minecraft:tall_seagrass[half=lower]
setblock 359 54 -198 minecraft:water[level=0]
fill 386 54 -198 391 54 -198 minecraft:water[level=0]
fill 340 54 -199 354 54 -199 minecraft:water[level=0]
setblock 355 54 -199 minecraft:kelp_plant
setblock 356 54 -199 minecraft:seagrass
fill 357 54 -199 361 54 -199 minecraft:water[level=0]
fill 386 54 -199 391 54 -199 minecraft:water[level=0]
fill 340 54 -200 351 54 -200 minecraft:water[level=0]
setblock 352 54 -200 minecraft:tall_seagrass[half=upper]
fill 353 54 -200 355 54 -200 minecraft:water[level=0]
setblock 356 54 -200 minecraft:kelp_plant
fill 357 54 -200 362 54 -200 minecraft:water[level=0]
setblock 368 54 -200 minecraft:water[level=0]
setblock 386 54 -200 minecraft:kelp_plant
fill 387 54 -200 391 54 -200 minecraft:water[level=0]
fill 340 54 -201 353 54 -201 minecraft:water[level=0]
fill 354 54 -201 355 54 -201 minecraft:kelp_plant
fill 356 54 -201 364 54 -201 minecraft:water[level=0]
setblock 365 54 -201 minecraft:kelp_plant
fill 366 54 -201 368 54 -201 minecraft:water[level=0]
setblock 386 54 -201 minecraft:water[level=0]
setblock 387 54 -201 minecraft:kelp_plant
fill 388 54 -201 391 54 -201 minecraft:water[level=0]
fill 342 54 -202 352 54 -202 minecraft:water[level=0]
setblock 353 54 -202 minecraft:kelp_plant
setblock 354 54 -202 minecraft:tall_seagrass[half=upper]
setblock 355 54 -202 minecraft:water[level=0]
setblock 356 54 -202 minecraft:kelp_plant
fill 357 54 -202 366 54 -202 minecraft:water[level=0]
setblock 367 54 -202 minecraft:kelp_plant
fill 368 54 -202 369 54 -202 minecraft:water[level=0]
fill 387 54 -202 391 54 -202 minecraft:water[level=0]
fill 343 54 -203 368 54 -203 minecraft:water[level=0]
setblock 369 54 -203 minecraft:kelp_plant
setblock 370 54 -203 minecraft:water[level=0]
fill 387 54 -203 391 54 -203 minecraft:water[level=0]
fill 343 54 -204 357 54 -204 minecraft:water[level=0]
setblock 358 54 -204 minecraft:kelp_plant
fill 359 54 -204 362 54 -204 minecraft:water[level=0]
setblock 363 54 -204 minecraft:kelp_plant
fill 364 54 -204 370 54 -204 minecraft:water[level=0]
setblock 371 54 -204 minecraft:kelp_plant
setblock 372 54 -204 minecraft:water[level=0]
fill 387 54 -204 391 54 -204 minecraft:water[level=0]
fill 344 54 -205 372 54 -205 minecraft:water[level=0]
fill 388 54 -205 391 54 -205 minecraft:water[level=0]
fill 344 54 -206 372 54 -206 minecraft:water[level=0]
fill 388 54 -206 391 54 -206 minecraft:water[level=0]
fill 344 54 -207 372 54 -207 minecraft:water[level=0]
fill 389 54 -207 390 54 -207 minecraft:water[level=0]
setblock 391 54 -207 minecraft:kelp_plant
fill 344 54 -208 372 54 -208 minecraft:water[level=0]
fill 389 54 -208 391 54 -208 minecraft:water[level=0]
fill 347 54 -209 352 54 -209 minecraft:water[level=0]
fill 357 54 -209 366 54 -209 minecraft:water[level=0]
fill 389 54 -209 391 54 -209 minecraft:water[level=0]
fill 348 54 -210 349 54 -210 minecraft:water[level=0]
fill 359 54 -210 364 54 -210 minecraft:water[level=0]
fill 389 54 -210 391 54 -210 minecraft:water[level=0]
setblock 348 54 -211 minecraft:water[level=0]
fill 360 54 -211 364 54 -211 minecraft:water[level=0]
fill 389 54 -211 391 54 -211 minecraft:water[level=0]
setblock 348 54 -212 minecraft:water[level=0]
fill 360 54 -212 363 54 -212 minecraft:water[level=0]
fill 388 54 -212 391 54 -212 minecraft:water[level=0]
fill 388 54 -213 391 54 -213 minecraft:water[level=0]
fill 388 54 -214 391 54 -214 minecraft:water[level=0]
fill 388 54 -215 391 54 -215 minecraft:water[level=0]
fill 388 54 -216 391 54 -216 minecraft:water[level=0]
fill 389 54 -217 391 54 -217 minecraft:water[level=0]
fill 390 54 -218 391 54 -218 minecraft:water[level=0]
setblock 391 54 -219 minecraft:water[level=0]
setblock 391 54 -220 minecraft:water[level=0]
setblock 328 54 -222 minecraft:air
fill 328 54 -223 329 54 -223 minecraft:air
fill 328 54 -224 329 54 -224 minecraft:air
fill 332 54 -224 334 54 -224 minecraft:air
fill 328 54 -225 329 54 -225 minecraft:air
setblock 333 54 -225 minecraft:water[level=1]
fill 334 54 -225 335 54 -225 minecraft:air
fill 328 54 -226 329 54 -226 minecraft:air
setblock 333 54 -226 minecraft:water[level=8]
setblock 334 54 -226 minecraft:water[level=1]
setblock 328 54 -227 minecraft:air
setblock 334 54 -227 minecraft:water[level=8]
fill 362 54 -238 365 54 -238 minecraft:air
fill 362 54 -239 364 54 -239 minecraft:air
fill 361 54 -240 363 54 -240 minecraft:air
fill 360 54 -241 362 54 -241 minecraft:air
fill 359 54 -242 362 54 -242 minecraft:air
fill 335 53 -191 343 53 -191 minecraft:water[level=0]
setblock 344 53 -191 minecraft:tall_seagrass[half=lower]
fill 345 53 -191 346 53 -191 minecraft:water[level=0]
setblock 347 53 -191 minecraft:seagrass
fill 387 53 -191 388 53 -191 minecraft:seagrass
fill 389 53 -191 391 53 -191 minecraft:water[level=0]
fill 336 53 -192 341 53 -192 minecraft:water[level=0]
setblock 342 53 -192 minecraft:tall_seagrass[half=upper]
fill 343 53 -192 345 53 -192 minecraft:water[level=0]
setblock 346 53 -192 minecraft:kelp_plant
setblock 347 53 -192 minecraft:water[level=0]
fill 387 53 -192 390 53 -192 minecraft:water[level=0]
setblock 391 53 -192 minecraft:kelp_plant
fill 336 53 -193 344 53 -193 minecraft:water[level=0]
fill 345 53 -193 346 53 -193 minecraft:seagrass
fill 347 53 -193 348 53 -193 minecraft:water[level=0]
fill 387 53 -193 390 53 -193 minecraft:water[level=0]
setblock 391 53 -193 minecraft:kelp_plant
fill 336 53 -194 344 53 -194 minecraft:water[level=0]
setblock 345 53 -194 minecraft:tall_seagrass[half=lower]
fill 346 53 -194 347 53 -194 minecraft:seagrass
fill 348 53 -194 349 53 -194 minecraft:water[level=0]
fill 387 53 -194 391 53 -194 minecraft:water[level=0]
fill 336 53 -195 346 53 -195 minecraft:water[level=0]
setblock 347 53 -195 minecraft:seagrass
fill 348 53 -195 349 53 -195 minecraft:water[level=0]
setblock 350 53 -195 minecraft:seagrass
fill 387 53 -195 391 53 -195 minecraft:water[level=0]
fill 336 53 -196 347 53 -196 minecraft:water[level=0]
setblock 348 53 -196 minecraft:tall_seagrass[half=lower]
setblock 349 53 -196 minecraft:seagrass
fill 350 53 -196 351 53 -196 minecraft:water[level=0]
fill 387 53 -196 391 53 -196 minecraft:water[level=0]
fill 339 53 -197 347 53 -197 minecraft:water[level=0]
setblock 348 53 -197 minecraft:tall_seagrass[half=lower]
setblock 349 53 -197 minecraft:water[level=0]
setblock 350 53 -197 minecraft:tall_seagrass[half=lower]
fill 351 53 -197 352 53 -197 minecraft:water[level=0]
fill 387 53 -197 390 53 -197 minecraft:water[level=0]
setblock 391 53 -197 minecraft:kelp_plant
fill 340 53 -198 348 53 -198 minecraft:water[level=0]
setblock 349 53 -198 minecraft:seagrass
fill 350 53 -198 351 53 -198 minecraft:water[level=0]
fill 352 53 -198 353 53 -198 minecraft:seagrass
fill 387 53 -198 391 53 -198 minecraft:water[level=0]
fill 340 53 -199 345 53 -199 minecraft:water[level=0]
setblock 346 53 -199 minecraft:tall_seagrass[half=upper]
fill 347 53 -199 348 53 -199 minecraft:water[level=0]
setblock 349 53 -199 minecraft:seagrass
setblock 350 53 -199 minecraft:water[level=0]
fill 351 53 -199 352 53 -199 minecraft:seagrass
fill 353 53 -199 354 53 -199 minecraft:water[level=0]
setblock 355 53 -199 minecraft:kelp_plant
fill 387 53 -199 391 53 -199 minecraft:water[level=0]
fill 340 53 -200 349 53 -200 minecraft:water[level=0]
setblock 350 53 -200 minecraft:seagrass
setblock 351 53 -200 minecraft:water[level=0]
setblock 352 53 -200 minecraft:tall_seagrass[half=lower]
setblock 353 53 -200 minecraft:water[level=0]
fill 354 53 -200 355 53 -200 minecraft:seagrass
setblock 356 53 -200 minecraft:kelp_plant
fill 387 53 -200 391 53 -200 minecraft:water[level=0]
fill 342 53 -201 352 53 -201 minecraft:water[level=0]
setblock 353 53 -201 minecraft:seagrass
fill 354 53 -201 355 53 -201 minecraft:kelp_plant
setblock 356 53 -201 minecraft:water[level=0]
setblock 387 53 -201 minecraft:kelp_plant
fill 388 53 -201 391 53 -201 minecraft:water[level=0]
fill 343 53 -202 352 53 -202 minecraft:water[level=0]
setblock 353 53 -202 minecraft:kelp_plant
setblock 354 53 -202 minecraft:tall_seagrass[half=lower]
setblock 355 53 -202 minecraft:water[level=0]
setblock 356 53 -202 minecraft:kelp_plant
setblock 357 53 -202 minecraft:water[level=0]
fill 388 53 -202 391 53 -202 minecraft:water[level=0]
fill 344 53 -203 352 53 -203 minecraft:water[level=0]
setblock 353 53 -203 minecraft:seagrass
fill 354 53 -203 357 53 -203 minecraft:water[level=0]
fill 388 53 -203 391 53 -203 minecraft:water[level=0]
fill 344 53 -204 357 53 -204 minecraft:water[level=0]
fill 389 53 -204 391 53 -204 minecraft:water[level=0]
fill 344 53 -205 347 53 -205 minecraft:water[level=0]
setblock 348 53 -205 minecraft:tall_seagrass[half=upper]
fill 349 53 -205 353 53 -205 minecraft:water[level=0]
setblock 354 53 -205 minecraft:seagrass
fill 355 53 -205 358 53 -205 minecraft:water[level=0]
setblock 368 53 -205 minecraft:water[level=0]
fill 389 53 -205 391 53 -205 minecraft:water[level=0]
fill 344 53 -206 358 53 -206 minecraft:water[level=0]
fill 365 53 -206 369 53 -206 minecraft:water[level=0]
fill 389 53 -206 391 53 -206 minecraft:water[level=0]
fill 344 53 -207 359 53 -207 minecraft:water[level=0]
fill 361 53 -207 370 53 -207 minecraft:water[level=0]
fill 389 53 -207 390 53 -207 minecraft:water[level=0]
setblock 391 53 -207 minecraft:kelp_plant
fill 344 53 -208 371 53 -208 minecraft:water[level=0]
fill 389 53 -208 391 53 -208 minecraft:water[level=0]
fill 348 53 -209 349 53 -209 minecraft:water[level=0]
fill 389 53 -209 391 53 -209 minecraft:water[level=0]
setblock 348 53 -210 minecraft:water[level=0]
fill 389 53 -210 391 53 -210 minecraft:water[level=0]
fill 389 53 -211 391 53 -211 minecraft:water[level=0]
fill 389 53 -212 391 53 -212 minecraft:water[level=0]
fill 389 53 -213 391 53 -213 minecraft:water[level=0]
fill 389 53 -214 391 53 -214 minecraft:water[level=0]
fill 389 53 -215 391 53 -215 minecraft:water[level=0]
fill 389 53 -216 391 53 -216 minecraft:water[level=0]
fill 390 53 -217 391 53 -217 minecraft:water[level=0]
fill 390 53 -218 391 53 -218 minecraft:water[level=0]
setblock 391 53 -219 minecraft:water[level=0]
setblock 391 53 -220 minecraft:water[level=0]
setblock 328 53 -222 minecraft:air
setblock 333 53 -222 minecraft:water[level=0]
setblock 328 53 -223 minecraft:air
fill 328 53 -224 329 53 -224 minecraft:air
fill 328 53 -225 329 53 -225 minecraft:air
setblock 333 53 -225 minecraft:water[level=8]
setblock 334 53 -225 minecraft:water[level=1]
setblock 335 53 -225 minecraft:air
setblock 328 53 -226 minecraft:air
setblock 334 53 -226 minecraft:water[level=8]
setblock 362 53 -238 minecraft:air
fill 361 53 -239 363 53 -239 minecraft:air
fill 361 53 -240 363 53 -240 minecraft:air
fill 360 53 -241 362 53 -241 minecraft:air
fill 360 53 -242 361 53 -242 minecraft:air
fill 336 52 -191 342 52 -191 minecraft:water[level=0]
setblock 343 52 -191 minecraft:seagrass
fill 389 52 -191 391 52 -191 minecraft:water[level=0]
fill 336 52 -192 341 52 -192 minecraft:water[level=0]
setblock 342 52 -192 minecraft:tall_seagrass[half=lower]
setblock 343 52 -192 minecraft:water[level=0]
fill 388 52 -192 390 52 -192 minecraft:water[level=0]
setblock 391 52 -192 minecraft:kelp_plant
fill 336 52 -193 341 52 -193 minecraft:water[level=0]
setblock 342 52 -193 minecraft:seagrass
setblock 343 52 -193 minecraft:water[level=0]
fill 388 52 -193 390 52 -193 minecraft:water[level=0]
setblock 391 52 -193 minecraft:kelp_plant
fill 336 52 -194 341 52 -194 minecraft:water[level=0]
setblock 342 52 -194 minecraft:seagrass
fill 343 52 -194 344 52 -194 minecraft:water[level=0]
fill 388 52 -194 391 52 -194 minecraft:water[level=0]
fill 336 52 -195 344 52 -195 minecraft:water[level=0]
fill 388 52 -195 391 52 -195 minecraft:water[level=0]
fill 336 52 -196 345 52 -196 minecraft:water[level=0]
fill 388 52 -196 391 52 -196 minecraft:water[level=0]
fill 340 52 -197 346 52 -197 minecraft:water[level=0]
fill 388 52 -197 390 52 -197 minecraft:water[level=0]
setblock 391 52 -197 minecraft:kelp_plant
fill 340 52 -198 344 52 -198 minecraft:water[level=0]
setblock 345 52 -198 minecraft:seagrass
fill 346 52 -198 347 52 -198 minecraft:water[level=0]
fill 388 52 -198 391 52 -198 minecraft:water[level=0]
fill 340 52 -199 345 52 -199 minecraft:water[level=0]
setblock 346 52 -199 minecraft:tall_seagrass[half=lower]
setblock 347 52 -199 minecraft:water[level=0]
fill 388 52 -199 391 52 -199 minecraft:water[level=0]
fill 341 52 -200 349 52 -200 minecraft:water[level=0]
fill 388 52 -200 391 52 -200 minecraft:water[level=0]
fill 343 52 -201 349 52 -201 minecraft:water[level=0]
setblock 350 52 -201 minecraft:seagrass
fill 388 52 -201 391 52 -201 minecraft:water[level=0]
fill 344 52 -202 350 52 -202 minecraft:water[level=0]
fill 351 52 -202 352 52 -202 minecraft:seagrass
fill 389 52 -202 391 52 -202 minecraft:water[level=0]
fill 344 52 -203 352 52 -203 minecraft:water[level=0]
fill 389 52 -203 391 52 -203 minecraft:water[level=0]
fill 344 52 -204 353 52 -204 minecraft:water[level=0]
fill 389 52 -204 391 52 -204 minecraft:water[level=0]
fill 344 52 -205 347 52 -205 minecraft:water[level=0]
setblock 348 52 -205 minecraft:tall_seagrass[half=lower]
fill 349 52 -205 353 52 -205 minecraft:water[level=0]
fill 389 52 -205 391 52 -205 minecraft:water[level=0]
fill 344 52 -206 353 52 -206 minecraft:water[level=0]
fill 389 52 -206 391 52 -206 minecraft:water[level=0]
fill 344 52 -207 353 52 -207 minecraft:water[level=0]
fill 389 52 -207 390 52 -207 minecraft:water[level=0]
setblock 391 52 -207 minecraft:kelp_plant
fill 344 52 -208 353 52 -208 minecraft:water[level=0]
fill 390 52 -208 391 52 -208 minecraft:water[level=0]
fill 390 52 -209 391 52 -209 minecraft:water[level=0]
fill 390 52 -210 391 52 -210 minecraft:water[level=0]
fill 390 52 -211 391 52 -211 minecraft:water[level=0]
fill 390 52 -212 391 52 -212 minecraft:water[level=0]
fill 390 52 -213 391 52 -213 minecraft:water[level=0]
fill 390 52 -214 391 52 -214 minecraft:water[level=0]
fill 389 52 -215 391 52 -215 minecraft:water[level=0]
fill 389 52 -216 391 52 -216 minecraft:water[level=0]
fill 390 52 -217 391 52 -217 minecraft:water[level=0]
setblock 391 52 -218 minecraft:water[level=0]
setblock 391 52 -219 minecraft:water[level=0]
setblock 391 52 -220 minecraft:water[level=0]
fill 332 52 -221 333 52 -221 minecraft:water[level=0]
setblock 328 52 -222 minecraft:air
fill 333 52 -222 334 52 -222 minecraft:water[level=0]
setblock 328 52 -223 minecraft:air
fill 333 52 -223 334 52 -223 minecraft:water[level=0]
setblock 328 52 -224 minecraft:air
setblock 328 52 -225 minecraft:air
setblock 334 52 -225 minecraft:water[level=8]
setblock 328 52 -226 minecraft:air
setblock 334 52 -226 minecraft:water[level=8]
fill 361 52 -238 362 52 -238 minecraft:air
fill 361 52 -239 363 52 -239 minecraft:air
fill 360 52 -240 362 52 -240 minecraft:air
fill 359 52 -241 362 52 -241 minecraft:air
setblock 361 52 -242 minecraft:glow_lichen[down=false,east=false,north=true,south=false,up=false,waterlogged=false,west=false]
fill 336 51 -191 341 51 -191 minecraft:water[level=0]
fill 390 51 -191 391 51 -191 minecraft:water[level=0]
fill 336 51 -192 341 51 -192 minecraft:water[level=0]
fill 389 51 -192 390 51 -192 minecraft:water[level=0]
setblock 391 51 -192 minecraft:kelp_plant
fill 336 51 -193 341 51 -193 minecraft:water[level=0]
fill 389 51 -193 390 51 -193 minecraft:water[level=0]
setblock 391 51 -193 minecraft:kelp_plant
fill 336 51 -194 341 51 -194 minecraft:water[level=0]
setblock 389 51 -194 minecraft:seagrass
fill 390 51 -194 391 51 -194 minecraft:water[level=0]
fill 336 51 -195 341 51 -195 minecraft:water[level=0]
fill 389 51 -195 391 51 -195 minecraft:water[level=0]
fill 336 51 -196 342 51 -196 minecraft:water[level=0]
fill 389 51 -196 391 51 -196 minecraft:water[level=0]
fill 340 51 -197 341 51 -197 minecraft:water[level=0]
fill 389 51 -197 390 51 -197 minecraft:water[level=0]
setblock 391 51 -197 minecraft:kelp_plant
fill 389 51 -198 391 51 -198 minecraft:water[level=0]
setblock 344 51 -199 minecraft:water[level=0]
fill 389 51 -199 391 51 -199 minecraft:water[level=0]
setblock 344 51 -200 minecraft:water[level=0]
fill 389 51 -200 391 51 -200 minecraft:water[level=0]
fill 344 51 -201 345 51 -201 minecraft:water[level=0]
fill 389 51 -201 391 51 -201 minecraft:water[level=0]
fill 344 51 -202 345 51 -202 minecraft:water[level=0]
fill 389 51 -202 391 51 -202 minecraft:water[level=0]
fill 344 51 -203 345 51 -203 minecraft:water[level=0]
fill 389 51 -203 391 51 -203 minecraft:water[level=0]
fill 344 51 -204 346 51 -204 minecraft:water[level=0]
fill 389 51 -204 391 51 -204 minecraft:water[level=0]
fill 344 51 -205 346 51 -205 minecraft:water[level=0]
fill 390 51 -205 391 51 -205 minecraft:water[level=0]
fill 344 51 -206 346 51 -206 minecraft:water[level=0]
fill 390 51 -206 391 51 -206 minecraft:water[level=0]
fill 344 51 -207 346 51 -207 minecraft:water[level=0]
setblock 390 51 -207 minecraft:water[level=0]
setblock 391 51 -207 minecraft:kelp_plant
fill 344 51 -208 346 51 -208 minecraft:water[level=0]
fill 390 51 -208 391 51 -208 minecraft:water[level=0]
fill 390 51 -209 391 51 -209 minecraft:water[level=0]
fill 390 51 -210 391 51 -210 minecraft:water[level=0]
fill 390 51 -211 391 51 -211 minecraft:water[level=0]
fill 390 51 -212 391 51 -212 minecraft:water[level=0]
fill 390 51 -213 391 51 -213 minecraft:water[level=0]
fill 390 51 -214 391 51 -214 minecraft:water[level=0]
fill 390 51 -215 391 51 -215 minecraft:water[level=0]
fill 390 51 -216 391 51 -216 minecraft:water[level=0]
fill 390 51 -217 391 51 -217 minecraft:water[level=0]
setblock 391 51 -218 minecraft:water[level=0]
setblock 391 51 -219 minecraft:water[level=0]
fill 332 51 -220 333 51 -220 minecraft:water[level=0]
setblock 391 51 -220 minecraft:water[level=0]
fill 332 51 -221 333 51 -221 minecraft:water[level=0]
fill 332 51 -222 334 51 -222 minecraft:water[level=0]
setblock 328 51 -223 minecraft:air
fill 333 51 -223 335 51 -223 minecraft:water[level=0]
setblock 328 51 -224 minecraft:air
setblock 328 51 -225 minecraft:air
setblock 334 51 -225 minecraft:water[level=8]
setblock 361 51 -238 minecraft:air
fill 360 51 -239 363 51 -239 minecraft:air
fill 360 51 -240 362 51 -240 minecraft:air
fill 359 51 -241 361 51 -241 minecraft:air
setblock 361 51 -242 minecraft:air
fill 336 50 -191 338 50 -191 minecraft:water[level=0]
setblock 391 50 -191 minecraft:water[level=0]
fill 336 50 -192 338 50 -192 minecraft:water[level=0]
setblock 390 50 -192 minecraft:water[level=0]
setblock 391 50 -192 minecraft:kelp_plant
fill 336 50 -193 338 50 -193 minecraft:water[level=0]
setblock 339 50 -193 minecraft:seagrass
setblock 390 50 -193 minecraft:water[level=0]
setblock 391 50 -193 minecraft:kelp_plant
fill 336 50 -194 339 50 -194 minecraft:water[level=0]
fill 390 50 -194 391 50 -194 minecraft:water[level=0]
fill 336 50 -195 339 50 -195 minecraft:water[level=0]
fill 390 50 -195 391 50 -195 minecraft:water[level=0]
fill 336 50 -196 340 50 -196 minecraft:water[level=0]
fill 390 50 -196 391 50 -196 minecraft:water[level=0]
setblock 390 50 -197 minecraft:water[level=0]
setblock 391 50 -197 minecraft:kelp_plant
fill 390 50 -198 391 50 -198 minecraft:water[level=0]
fill 390 50 -199 391 50 -199 minecraft:water[level=0]
fill 390 50 -200 391 50 -200 minecraft:water[level=0]
fill 390 50 -201 391 50 -201 minecraft:water[level=0]
fill 390 50 -202 391 50 -202 minecraft:water[level=0]
fill 390 50 -203 391 50 -203 minecraft:water[level=0]
fill 390 50 -204 391 50 -204 minecraft:water[level=0]
fill 390 50 -205 391 50 -205 minecraft:water[level=0]
fill 390 50 -206 391 50 -206 minecraft:water[level=0]
setblock 390 50 -207 minecraft:water[level=0]
setblock 391 50 -207 minecraft:kelp_plant
fill 390 50 -208 391 50 -208 minecraft:water[level=0]
fill 390 50 -209 391 50 -209 minecraft:water[level=0]
fill 390 50 -210 391 50 -210 minecraft:water[level=0]
fill 390 50 -211 391 50 -211 minecraft:water[level=0]
setblock 391 50 -212 minecraft:water[level=0]
setblock 391 50 -213 minecraft:water[level=0]
fill 390 50 -214 391 50 -214 minecraft:water[level=0]
fill 390 50 -215 391 50 -215 minecraft:water[level=0]
fill 390 50 -216 391 50 -216 minecraft:water[level=0]
fill 390 50 -217 391 50 -217 minecraft:water[level=0]
setblock 332 50 -218 minecraft:water[level=0]
setblock 391 50 -218 minecraft:water[level=0]
setblock 332 50 -219 minecraft:water[level=0]
setblock 391 50 -219 minecraft:water[level=0]
fill 332 50 -220 333 50 -220 minecraft:water[level=0]
setblock 391 50 -220 minecraft:water[level=0]
fill 332 50 -221 334 50 -221 minecraft:water[level=0]
setblock 391 50 -221 minecraft:water[level=0]
fill 333 50 -222 335 50 -222 minecraft:water[level=0]
fill 333 50 -223 335 50 -223 minecraft:water[level=0]
fill 360 50 -238 361 50 -238 minecraft:air
fill 360 50 -239 362 50 -239 minecraft:air
fill 359 50 -240 362 50 -240 minecraft:air
fill 360 50 -241 361 50 -241 minecraft:air
setblock 391 49 -191 minecraft:water[level=0]
setblock 391 49 -192 minecraft:kelp_plant
setblock 336 49 -193 minecraft:water[level=0]
setblock 391 49 -193 minecraft:kelp_plant
setblock 336 49 -194 minecraft:water[level=0]
setblock 391 49 -194 minecraft:water[level=0]
fill 336 49 -195 337 49 -195 minecraft:water[level=0]
setblock 391 49 -195 minecraft:water[level=0]
fill 336 49 -196 337 49 -196 minecraft:water[level=0]
fill 390 49 -196 391 49 -196 minecraft:water[level=0]
setblock 390 49 -197 minecraft:water[level=0]
setblock 391 49 -197 minecraft:kelp_plant
fill 390 49 -198 391 49 -198 minecraft:water[level=0]
fill 390 49 -199 391 49 -199 minecraft:water[level=0]
fill 390 49 -200 391 49 -200 minecraft:water[level=0]
fill 390 49 -201 391 49 -201 minecraft:water[level=0]
fill 390 49 -202 391 49 -202 minecraft:water[level=0]
setblock 328 49 -203 minecraft:water[level=0]
fill 390 49 -203 391 49 -203 minecraft:water[level=0]
setblock 328 49 -204 minecraft:water[level=0]
fill 390 49 -204 391 49 -204 minecraft:water[level=0]
setblock 328 49 -205 minecraft:water[level=0]
fill 390 49 -205 391 49 -205 minecraft:water[level=0]
setblock 328 49 -206 minecraft:water[level=0]
fill 390 49 -206 391 49 -206 minecraft:water[level=0]
setblock 328 49 -207 minecraft:water[level=0]
setblock 390 49 -207 minecraft:water[level=0]
setblock 391 49 -207 minecraft:kelp_plant
fill 390 49 -208 391 49 -208 minecraft:water[level=0]
setblock 391 49 -209 minecraft:water[level=0]
setblock 391 49 -210 minecraft:water[level=0]
setblock 391 49 -211 minecraft:water[level=0]
setblock 391 49 -212 minecraft:water[level=0]
setblock 391 49 -213 minecraft:water[level=0]
setblock 391 49 -214 minecraft:water[level=0]
setblock 391 49 -215 minecraft:water[level=0]
fill 390 49 -216 391 49 -216 minecraft:water[level=0]
fill 331 49 -217 332 49 -217 minecraft:water[level=0]
setblock 391 49 -217 minecraft:water[level=0]
fill 331 49 -218 332 49 -218 minecraft:water[level=0]
setblock 391 49 -218 minecraft:water[level=0]
fill 331 49 -219 333 49 -219 minecraft:water[level=0]
setblock 391 49 -219 minecraft:water[level=0]
fill 332 49 -220 334 49 -220 minecraft:water[level=0]
setblock 391 49 -220 minecraft:water[level=0]
fill 332 49 -221 335 49 -221 minecraft:water[level=0]
setblock 391 49 -221 minecraft:water[level=0]
fill 333 49 -222 335 49 -222 minecraft:water[level=0]
fill 334 49 -223 335 49 -223 minecraft:water[level=0]
setblock 360 49 -238 minecraft:air
fill 360 49 -239 362 49 -239 minecraft:air
fill 359 49 -240 361 49 -240 minecraft:air
fill 360 49 -241 361 49 -241 minecraft:air
setblock 391 48 -194 minecraft:seagrass
setblock 391 48 -195 minecraft:water[level=0]
setblock 391 48 -196 minecraft:water[level=0]
setblock 391 48 -197 minecraft:kelp_plant
setblock 391 48 -198 minecraft:water[level=0]
setblock 391 48 -199 minecraft:water[level=0]
setblock 391 48 -200 minecraft:water[level=0]
fill 390 48 -201 391 48 -201 minecraft:water[level=0]
fill 390 48 -202 391 48 -202 minecraft:water[level=0]
fill 390 48 -203 391 48 -203 minecraft:water[level=0]
setblock 328 48 -204 minecraft:water[level=0]
fill 390 48 -204 391 48 -204 minecraft:water[level=0]
setblock 328 48 -205 minecraft:water[level=0]
fill 390 48 -205 391 48 -205 minecraft:water[level=0]
setblock 328 48 -206 minecraft:water[level=0]
setblock 391 48 -206 minecraft:water[level=0]
fill 328 48 -207 329 48 -207 minecraft:water[level=0]
setblock 391 48 -207 minecraft:kelp_plant
fill 328 48 -208 329 48 -208 minecraft:water[level=0]
setblock 391 48 -208 minecraft:water[level=0]
fill 328 48 -209 329 48 -209 minecraft:water[level=0]
setblock 391 48 -209 minecraft:water[level=0]
setblock 329 48 -210 minecraft:water[level=0]
setblock 391 48 -210 minecraft:water[level=0]
fill 329 48 -211 330 48 -211 minecraft:water[level=0]
setblock 391 48 -211 minecraft:water[level=0]
setblock 330 48 -212 minecraft:water[level=0]
setblock 391 48 -212 minecraft:water[level=0]
setblock 330 48 -213 minecraft:water[level=0]
setblock 391 48 -213 minecraft:water[level=0]
fill 330 48 -214 331 48 -214 minecraft:water[level=0]
setblock 391 48 -214 minecraft:water[level=0]
fill 330 48 -215 331 48 -215 minecraft:water[level=0]
setblock 391 48 -215 minecraft:water[level=0]
fill 330 48 -216 332 48 -216 minecraft:water[level=0]
setblock 391 48 -216 minecraft:water[level=0]
fill 331 48 -217 332 48 -217 minecraft:water[level=0]
setblock 391 48 -217 minecraft:water[level=0]
fill 331 48 -218 333 48 -218 minecraft:water[level=0]
setblock 391 48 -218 minecraft:water[level=0]
fill 332 48 -219 334 48 -219 minecraft:water[level=0]
setblock 391 48 -219 minecraft:water[level=0]
fill 332 48 -220 335 48 -220 minecraft:water[level=0]
setblock 391 48 -220 minecraft:water[level=0]
fill 333 48 -221 335 48 -221 minecraft:water[level=0]
setblock 391 48 -221 minecraft:water[level=0]
fill 334 48 -222 335 48 -222 minecraft:water[level=0]
setblock 391 48 -222 minecraft:water[level=0]
fill 334 48 -223 335 48 -223 minecraft:water[level=0]
setblock 391 48 -223 minecraft:water[level=0]
setblock 361 48 -236 minecraft:water[level=0]
fill 359 48 -239 361 48 -239 minecraft:air
fill 359 48 -240 361 48 -240 minecraft:air
fill 328 47 -191 329 47 -191 minecraft:cave_air
setblock 328 47 -192 minecraft:cave_air
setblock 330 47 -194 minecraft:cave_air
setblock 391 47 -200 minecraft:water[level=0]
setblock 391 47 -201 minecraft:water[level=0]
setblock 391 47 -202 minecraft:water[level=0]
setblock 391 47 -203 minecraft:water[level=0]
setblock 328 47 -204 minecraft:water[level=0]
setblock 391 47 -204 minecraft:water[level=0]
fill 328 47 -205 329 47 -205 minecraft:water[level=0]
setblock 391 47 -205 minecraft:water[level=0]
fill 328 47 -206 329 47 -206 minecraft:water[level=0]
setblock 391 47 -206 minecraft:water[level=0]
fill 328 47 -207 329 47 -207 minecraft:water[level=0]
setblock 391 47 -207 minecraft:kelp_plant
fill 328 47 -208 329 47 -208 minecraft:water[level=0]
setblock 391 47 -208 minecraft:seagrass
fill 328 47 -209 330 47 -209 minecraft:water[level=0]
fill 329 47 -210 330 47 -210 minecraft:water[level=0]
fill 329 47 -211 330 47 -211 minecraft:water[level=0]
fill 329 47 -212 331 47 -212 minecraft:water[level=0]
fill 330 47 -213 331 47 -213 minecraft:water[level=0]
fill 330 47 -214 331 47 -214 minecraft:water[level=0]
fill 330 47 -215 332 47 -215 minecraft:water[level=0]
fill 331 47 -216 332 47 -216 minecraft:water[level=0]
fill 331 47 -217 333 47 -217 minecraft:water[level=0]
setblock 391 47 -217 minecraft:water[level=0]
fill 332 47 -218 334 47 -218 minecraft:water[level=0]
setblock 391 47 -218 minecraft:water[level=0]
fill 332 47 -219 334 47 -219 minecraft:water[level=0]
setblock 391 47 -219 minecraft:water[level=0]
fill 333 47 -220 335 47 -220 minecraft:water[level=0]
setblock 391 47 -220 minecraft:water[level=0]
fill 334 47 -221 336 47 -221 minecraft:water[level=0]
setblock 391 47 -221 minecraft:water[level=0]
fill 334 47 -222 335 47 -222 minecraft:water[level=0]
setblock 391 47 -222 minecraft:water[level=0]
setblock 360 47 -234 minecraft:water[level=0]
fill 361 47 -235 362 47 -235 minecraft:water[level=0]
fill 361 47 -236 362 47 -236 minecraft:water[level=0]
setblock 362 47 -237 minecraft:water[level=0]
setblock 359 47 -238 minecraft:air
fill 359 47 -239 361 47 -239 minecraft:air
setblock 361 47 -240 minecraft:air
fill 328 46 -191 330 46 -191 minecraft:cave_air
fill 332 46 -191 337 46 -191 minecraft:cave_air
fill 328 46 -192 337 46 -192 minecraft:cave_air
fill 328 46 -193 337 46 -193 minecraft:cave_air
fill 328 46 -194 336 46 -194 minecraft:cave_air
fill 328 46 -195 334 46 -195 minecraft:cave_air
fill 328 46 -196 331 46 -196 minecraft:cave_air
setblock 328 46 -204 minecraft:water[level=0]
fill 328 46 -205 329 46 -205 minecraft:water[level=0]
fill 329 46 -206 330 46 -206 minecraft:water[level=0]
fill 329 46 -207 330 46 -207 minecraft:water[level=0]
fill 329 46 -208 330 46 -208 minecraft:water[level=0]
fill 329 46 -209 330 46 -209 minecraft:water[level=0]
fill 329 46 -210 331 46 -210 minecraft:water[level=0]
fill 330 46 -211 331 46 -211 minecraft:water[level=0]
fill 330 46 -212 331 46 -212 minecraft:water[level=0]
fill 330 46 -213 332 46 -213 minecraft:water[level=0]
fill 331 46 -214 332 46 -214 minecraft:water[level=0]
fill 331 46 -215 333 46 -215 minecraft:water[level=0]
fill 331 46 -216 333 46 -216 minecraft:water[level=0]
fill 332 46 -217 334 46 -217 minecraft:water[level=0]
fill 332 46 -218 334 46 -218 minecraft:water[level=0]
fill 333 46 -219 335 46 -219 minecraft:water[level=0]
fill 333 46 -220 336 46 -220 minecraft:water[level=0]
setblock 391 46 -220 minecraft:water[level=0]
fill 334 46 -221 335 46 -221 minecraft:water[level=0]
setblock 335 46 -222 minecraft:water[level=0]
setblock 360 46 -233 minecraft:water[level=0]
fill 360 46 -234 362 46 -234 minecraft:water[level=0]
fill 360 46 -235 362 46 -235 minecraft:water[level=0]
fill 360 46 -236 362 46 -236 minecraft:water[level=0]
setblock 361 46 -237 minecraft:water[level=0]
setblock 361 46 -239 minecraft:air
fill 328 45 -191 338 45 -191 minecraft:cave_air
fill 328 45 -192 338 45 -192 minecraft:cave_air
fill 328 45 -193 337 45 -193 minecraft:cave_air
fill 328 45 -194 337 45 -194 minecraft:cave_air
fill 328 45 -195 336 45 -195 minecraft:cave_air
setblock 391 45 -195 minecraft:water[level=0]
fill 328 45 -196 332 45 -196 minecraft:cave_air
setblock 391 45 -196 minecraft:water[level=0]
fill 328 45 -197 331 45 -197 minecraft:cave_air
fill 390 45 -197 391 45 -197 minecraft:water[level=0]
fill 390 45 -198 391 45 -198 minecraft:water[level=0]
fill 390 45 -199 391 45 -199 minecraft:water[level=0]
fill 390 45 -200 391 45 -200 minecraft:water[level=0]
fill 389 45 -201 391 45 -201 minecraft:water[level=0]
fill 390 45 -202 391 45 -202 minecraft:water[level=0]
fill 390 45 -203 391 45 -203 minecraft:water[level=0]
setblock 329 45 -206 minecraft:water[level=0]
fill 329 45 -207 330 45 -207 minecraft:water[level=0]
fill 329 45 -208 331 45 -208 minecraft:water[level=0]
fill 330 45 -209 331 45 -209 minecraft:water[level=0]
fill 330 45 -210 331 45 -210 minecraft:water[level=0]
fill 330 45 -211 332 45 -211 minecraft:water[level=0]
fill 330 45 -212 332 45 -212 minecraft:water[level=0]
fill 331 45 -213 332 45 -213 minecraft:water[level=0]
fill 331 45 -214 333 45 -214 minecraft:water[level=0]
fill 332 45 -215 333 45 -215 minecraft:water[level=0]
fill 332 45 -216 334 45 -216 minecraft:water[level=0]
fill 332 45 -217 334 45 -217 minecraft:water[level=0]
fill 333 45 -218 335 45 -218 minecraft:water[level=0]
fill 333 45 -219 336 45 -219 minecraft:water[level=0]
fill 334 45 -220 336 45 -220 minecraft:water[level=0]
setblock 335 45 -221 minecraft:water[level=0]
setblock 335 45 -222 minecraft:water[level=0]
fill 359 45 -231 360 45 -231 minecraft:water[level=0]
fill 359 45 -232 361 45 -232 minecraft:water[level=0]
fill 359 45 -233 361 45 -233 minecraft:water[level=0]
fill 359 45 -234 361 45 -234 minecraft:water[level=0]
fill 359 45 -235 361 45 -235 minecraft:water[level=0]
fill 360 45 -236 361 45 -236 minecraft:water[level=0]
setblock 361 45 -237 minecraft:water[level=0]
forceload remove 328 -254 391 -191
tellraw @a {"text":"Campus zurueck a27 fertig.","color":"green"}
