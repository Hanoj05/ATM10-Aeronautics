# Abschnitt a21: x 392..455, z -318..-255 (5791 Blöcke)
forceload add 392 -318 455 -255
tellraw @a {"text":"Campus zurueck a21: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a21_1 2s
