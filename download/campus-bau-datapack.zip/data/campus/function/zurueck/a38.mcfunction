# Abschnitt a38: x 136..199, z -126..-63 (3726 Blöcke)
forceload add 136 -126 199 -63
tellraw @a {"text":"Campus zurueck a38: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a38_1 2s
