setblock 164 82 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 82 -329 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 82 -330 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 81 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 81 -329 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 81 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 81 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 81 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 81 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 81 -330 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 81 -330 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 81 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 81 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 81 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 81 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 145 81 -334 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 144 81 -335 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 145 81 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 81 -336 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 81 -337 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 81 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 80 -326 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 146 80 -328 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 80 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 80 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 80 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 80 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 80 -329 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 80 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 80 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 80 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 80 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 80 -330 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 80 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 80 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 80 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 162 80 -330 163 80 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 80 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 80 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 80 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 80 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 80 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 80 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 80 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 80 -333 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 143 80 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 80 -334 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 145 80 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 80 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 80 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 80 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 80 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 80 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 80 -336 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 80 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 80 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 80 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 80 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 80 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 80 -338 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 136 79 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 137 79 -325 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 139 79 -325 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 140 79 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 79 -325 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 136 79 -326 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 79 -326 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 79 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 79 -326 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 79 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 79 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 79 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 79 -328 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 79 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 79 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 79 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 79 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 79 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 79 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 79 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 79 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 79 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 79 -329 minecraft:birch_log[axis=y]
setblock 165 79 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 79 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 79 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 79 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 79 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 79 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 79 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 162 79 -330 163 79 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 79 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 79 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 79 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 145 79 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 79 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 79 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 79 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 79 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 79 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 79 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 79 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 79 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 163 79 -331 164 79 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 79 -332 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 79 -332 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 79 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 79 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 79 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 79 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 79 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 79 -333 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 142 79 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 79 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 79 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 79 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 79 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 79 -334 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 143 79 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 79 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 79 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 79 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 79 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 79 -335 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 157 79 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 79 -335 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 144 79 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 79 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 79 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 79 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 79 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 79 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 79 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 79 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 79 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 79 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 79 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 79 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 79 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 79 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 79 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 79 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 79 -338 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 79 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 79 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 79 -339 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 79 -339 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 152 79 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 79 -340 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 136 78 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 78 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 136 78 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 137 78 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 78 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 78 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 78 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 78 -325 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 136 78 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 78 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 78 -326 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 163 78 -326 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 164 78 -326 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 78 -326 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 164 78 -327 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 78 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 78 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 78 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 78 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 143 78 -329 144 78 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 78 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 78 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 78 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 78 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 78 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 78 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 78 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 78 -329 minecraft:birch_log[axis=y]
setblock 141 78 -330 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 145 78 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 78 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 147 78 -330 148 78 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 78 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 78 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 78 -330 minecraft:birch_log[axis=y]
setblock 156 78 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 78 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 78 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 78 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 78 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 78 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 141 78 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 78 -331 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 144 78 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 78 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 146 78 -331 147 78 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 78 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 78 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 78 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 78 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 78 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 78 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 78 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 78 -331 minecraft:birch_log[axis=y]
setblock 163 78 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 78 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 78 -332 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 145 78 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 78 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 78 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 78 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 78 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 78 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 78 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 78 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 78 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 78 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 78 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 78 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 78 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 78 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 78 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 78 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 78 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 78 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 78 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 78 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 78 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 157 78 -334 158 78 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 78 -334 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 166 78 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 78 -334 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 142 78 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 78 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 78 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 145 78 -335 minecraft:birch_log[axis=y]
setblock 146 78 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 78 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 150 78 -335 151 78 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 78 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 78 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 78 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 78 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 78 -335 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 144 78 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 78 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 78 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 78 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 78 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 78 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 78 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 78 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 78 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 78 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 78 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 78 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 78 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 78 -337 minecraft:birch_log[axis=y]
setblock 151 78 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 78 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 78 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 78 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 78 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 169 78 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 78 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 78 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 78 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 78 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 78 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 78 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 78 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 78 -338 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 167 78 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 78 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 78 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 78 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 78 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 78 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 78 -339 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 78 -340 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 151 78 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 78 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 78 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 78 -340 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 147 78 -341 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 78 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 78 -341 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 152 78 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 78 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 78 -342 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 78 -343 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 78 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 78 -343 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 167 78 -345 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 168 78 -345 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 169 78 -345 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 78 -349 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 78 -350 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 78 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 163 78 -350 164 78 -350 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 78 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 78 -350 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 78 -351 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 78 -351 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 78 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 78 -355 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 136 77 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 137 77 -324 139 77 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 77 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 77 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 77 -324 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 136 77 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 137 77 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 77 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 77 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 77 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 77 -325 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 136 77 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 137 77 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 77 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 77 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 77 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 77 -326 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 143 77 -326 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 144 77 -326 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 146 77 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 77 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 77 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 77 -328 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 77 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 77 -329 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 143 77 -329 144 77 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 77 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 77 -329 minecraft:birch_log[axis=y]
setblock 147 77 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 77 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 77 -329 minecraft:birch_log[axis=y]
setblock 141 77 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 143 77 -330 144 77 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 77 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 77 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 147 77 -330 148 77 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 77 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 77 -330 minecraft:birch_log[axis=y]
setblock 140 77 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 77 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 77 -331 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 77 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 77 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 146 77 -331 147 77 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 77 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 77 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 77 -331 minecraft:birch_log[axis=y]
setblock 141 77 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 77 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 77 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 77 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 146 77 -332 147 77 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 77 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 77 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 77 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 77 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 77 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 77 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 77 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 77 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 77 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 77 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 77 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 77 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 77 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 77 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 77 -334 minecraft:birch_log[axis=y]
fill 144 77 -334 145 77 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 77 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 77 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 77 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 77 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 157 77 -334 158 77 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 77 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 77 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 77 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 77 -334 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 77 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 143 77 -335 144 77 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 145 77 -335 minecraft:birch_log[axis=y]
setblock 150 77 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 77 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 77 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 77 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 77 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 77 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 77 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 77 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 77 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 77 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 77 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 77 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 77 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 77 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 77 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 77 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 77 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 169 77 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 77 -337 minecraft:birch_log[axis=y]
setblock 155 77 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 77 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 77 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 77 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 77 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 77 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 168 77 -337 minecraft:birch_log[axis=y]
setblock 169 77 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 170 77 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 77 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 77 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 77 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 77 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 77 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 77 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 77 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 77 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 169 77 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 77 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 77 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 77 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 77 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 77 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 77 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 77 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 77 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 77 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 77 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 77 -340 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 77 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 77 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 77 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 77 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 77 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 77 -341 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 151 77 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 77 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 153 77 -341 154 77 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 77 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 77 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 77 -341 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 77 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 77 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 155 77 -342 156 77 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 77 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 77 -342 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 77 -343 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 77 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 77 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 77 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 77 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 77 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 77 -345 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 77 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 77 -345 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 77 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 77 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 77 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 77 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 77 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 163 77 -350 164 77 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 77 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 77 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 77 -350 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 77 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 77 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 77 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 77 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 77 -352 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 77 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 77 -352 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 151 77 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 77 -353 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 77 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 77 -353 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 77 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 77 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 77 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 77 -355 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 136 76 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 76 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 76 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 136 76 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 137 76 -324 139 76 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 76 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 76 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 76 -324 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 136 76 -325 minecraft:birch_log[axis=y]
setblock 137 76 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 138 76 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 76 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 76 -325 minecraft:birch_log[axis=y]
setblock 141 76 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 76 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 136 76 -326 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 137 76 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 76 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 76 -326 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 76 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 76 -326 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 76 -326 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 144 76 -326 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 136 76 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 76 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 76 -327 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 76 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 76 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 76 -328 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 76 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 76 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 76 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 76 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 76 -329 minecraft:birch_log[axis=y]
setblock 148 76 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 76 -329 minecraft:birch_log[axis=y]
setblock 140 76 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 76 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 76 -330 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 143 76 -330 144 76 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 145 76 -330 146 76 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 76 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 76 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 76 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 76 -330 minecraft:birch_log[axis=y]
setblock 140 76 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 76 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 142 76 -331 143 76 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 76 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 145 76 -331 minecraft:birch_log[axis=y]
fill 146 76 -331 147 76 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 76 -331 minecraft:birch_log[axis=y]
setblock 149 76 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 76 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 76 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 76 -331 minecraft:birch_log[axis=y]
setblock 140 76 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 76 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 76 -332 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 76 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 76 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 146 76 -332 147 76 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 76 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 76 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 76 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 76 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 76 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 76 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 76 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 76 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 76 -333 minecraft:birch_log[axis=y]
setblock 159 76 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 76 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 76 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 76 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 76 -333 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 76 -334 minecraft:birch_log[axis=y]
setblock 150 76 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 76 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 157 76 -334 158 76 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 76 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 76 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 76 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 76 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 76 -335 minecraft:birch_log[axis=y]
setblock 149 76 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 76 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 76 -335 minecraft:birch_log[axis=y]
setblock 152 76 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 76 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 76 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 76 -335 minecraft:birch_log[axis=y]
setblock 158 76 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 76 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 76 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 76 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 76 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 150 76 -336 151 76 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 76 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 76 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 76 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 76 -337 minecraft:birch_log[axis=y]
setblock 151 76 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 76 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 76 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 76 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 76 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 76 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 76 -337 minecraft:birch_log[axis=y]
setblock 152 76 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 76 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 76 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 76 -338 minecraft:birch_log[axis=y]
setblock 157 76 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 76 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 76 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 76 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 76 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 76 -339 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 76 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 76 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -339 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 76 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 76 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 76 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 76 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 76 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 76 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 76 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -340 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 76 -340 minecraft:birch_log[axis=y]
setblock 153 76 -340 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 154 76 -340 156 76 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 76 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 76 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 76 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 76 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 76 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 76 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 153 76 -341 154 76 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 76 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 76 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 76 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 76 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 76 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 76 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 76 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 76 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 155 76 -342 156 76 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 76 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 76 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 76 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 76 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 76 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -343 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 76 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 76 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 76 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 76 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 76 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 76 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 76 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 76 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 76 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 76 -345 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 169 76 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 76 -345 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 76 -345 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 167 76 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 76 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 76 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 76 -346 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 151 76 -349 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 152 76 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 76 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 76 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 163 76 -349 164 76 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 76 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 76 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 76 -350 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 76 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 76 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 76 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 163 76 -350 164 76 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 76 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 76 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 76 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 76 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 76 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 76 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 76 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 163 76 -351 164 76 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 76 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 76 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 76 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 76 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 76 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 76 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 76 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 76 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 76 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 76 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 76 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 76 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 76 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 76 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 76 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 76 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 76 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 76 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 76 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 76 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 76 -354 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 76 -355 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 76 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 76 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 76 -365 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 76 -366 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 76 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 76 -370 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 136 75 -320 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 137 75 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 138 75 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 75 -323 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 137 75 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 75 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 139 75 -324 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 136 75 -325 minecraft:birch_log[axis=y]
setblock 137 75 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 138 75 -325 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 75 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 75 -325 minecraft:birch_log[axis=y]
setblock 143 75 -327 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 75 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 75 -328 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 75 -328 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 75 -329 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 75 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 75 -329 minecraft:birch_log[axis=y]
fill 144 75 -329 145 75 -329 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 75 -329 minecraft:birch_log[axis=y]
setblock 164 75 -329 minecraft:birch_log[axis=y]
setblock 140 75 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 75 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 75 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 75 -330 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 75 -330 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 75 -330 minecraft:birch_log[axis=y]
setblock 139 75 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 75 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 75 -331 minecraft:birch_log[axis=y]
setblock 142 75 -331 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 75 -331 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 75 -331 minecraft:birch_log[axis=y]
setblock 148 75 -331 minecraft:birch_log[axis=y]
setblock 162 75 -331 minecraft:birch_log[axis=y]
setblock 140 75 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 75 -332 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 75 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 75 -332 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 75 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 75 -333 minecraft:birch_log[axis=y]
setblock 165 75 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 75 -333 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 75 -333 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 75 -334 minecraft:birch_log[axis=y]
setblock 164 75 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 75 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 75 -334 minecraft:birch_log[axis=y]
setblock 167 75 -334 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 168 75 -334 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 75 -335 minecraft:birch_log[axis=y]
setblock 151 75 -335 minecraft:birch_log[axis=y]
setblock 157 75 -335 minecraft:birch_log[axis=y]
setblock 165 75 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 75 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 75 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 75 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 75 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 75 -337 minecraft:birch_log[axis=y]
setblock 162 75 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 75 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 75 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 75 -337 minecraft:birch_log[axis=y]
setblock 156 75 -338 minecraft:birch_log[axis=y]
setblock 161 75 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 75 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 75 -338 minecraft:birch_log[axis=y]
setblock 164 75 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 75 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 75 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 75 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 75 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 75 -339 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 75 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 75 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 75 -340 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 75 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 75 -340 minecraft:birch_log[axis=y]
setblock 154 75 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 75 -340 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 75 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 75 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 75 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 75 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 75 -341 minecraft:birch_log[axis=y]
setblock 149 75 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 75 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 75 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 75 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 75 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 75 -341 minecraft:birch_log[axis=y]
setblock 156 75 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 75 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 75 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 75 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 75 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 75 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 75 -342 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 75 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 75 -342 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 75 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 75 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 155 75 -342 156 75 -342 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 75 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 75 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 75 -342 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 75 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 75 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 75 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 75 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 75 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 75 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 75 -343 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 75 -343 minecraft:birch_log[axis=y]
setblock 157 75 -343 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 75 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 75 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 75 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 75 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 75 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 75 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 75 -344 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 75 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 75 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 75 -344 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 169 75 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 75 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 75 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 75 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 75 -345 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 168 75 -345 minecraft:birch_log[axis=y]
setblock 169 75 -345 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 170 75 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 75 -345 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 192 75 -345 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 75 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 75 -345 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 75 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 75 -346 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 169 75 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 75 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 75 -346 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 75 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 75 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 75 -348 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 75 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 75 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 75 -348 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 151 75 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 75 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 75 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 75 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 75 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 163 75 -349 164 75 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 75 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 75 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 75 -349 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 75 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 75 -349 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 152 75 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 75 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 75 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 75 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 75 -350 minecraft:birch_log[axis=y]
fill 163 75 -350 164 75 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 75 -350 minecraft:birch_log[axis=y]
setblock 166 75 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 75 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 75 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 75 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 75 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 75 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 75 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 75 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 163 75 -351 164 75 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 75 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 75 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 75 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 75 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 75 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 75 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 75 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 75 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 75 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 75 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 75 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 75 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 75 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 75 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 75 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 75 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 75 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 75 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 75 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 75 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 75 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 75 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 75 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 75 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 75 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 75 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 75 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 75 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 75 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 75 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 75 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 75 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 75 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 75 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 75 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 75 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 75 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 75 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 75 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 75 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 75 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 75 -354 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 75 -354 minecraft:birch_log[axis=y]
setblock 198 75 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 75 -355 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 75 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 75 -358 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 75 -358 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 75 -359 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 192 75 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 75 -360 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 75 -360 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 75 -361 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 75 -361 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 75 -362 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 171 75 -363 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 172 75 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 75 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 75 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 75 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 75 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 75 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 75 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 75 -368 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 75 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 75 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 75 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 138 74 -322 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 137 74 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 74 -323 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 139 74 -323 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 136 74 -324 137 74 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 138 74 -324 minecraft:birch_log[axis=y]
fill 139 74 -324 140 74 -324 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 136 74 -325 minecraft:birch_log[axis=y]
fill 137 74 -325 139 74 -325 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 74 -325 minecraft:birch_log[axis=y]
setblock 138 74 -326 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 74 -329 minecraft:birch_log[axis=y]
setblock 146 74 -329 minecraft:birch_log[axis=y]
setblock 164 74 -329 minecraft:birch_log[axis=y]
setblock 155 74 -330 minecraft:birch_log[axis=y]
setblock 141 74 -331 minecraft:birch_log[axis=y]
setblock 145 74 -331 minecraft:birch_log[axis=y]
setblock 148 74 -331 minecraft:birch_log[axis=y]
setblock 162 74 -331 minecraft:birch_log[axis=y]
setblock 158 74 -333 minecraft:birch_log[axis=y]
setblock 143 74 -334 minecraft:birch_log[axis=y]
setblock 166 74 -334 minecraft:birch_log[axis=y]
setblock 145 74 -335 minecraft:birch_log[axis=y]
setblock 151 74 -335 minecraft:birch_log[axis=y]
setblock 157 74 -335 minecraft:birch_log[axis=y]
setblock 184 74 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 74 -335 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 74 -336 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 74 -337 minecraft:birch_log[axis=y]
setblock 168 74 -337 minecraft:birch_log[axis=y]
setblock 180 74 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 74 -338 minecraft:birch_log[axis=y]
setblock 163 74 -338 minecraft:birch_log[axis=y]
setblock 180 74 -338 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 179 74 -339 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 74 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 74 -340 minecraft:birch_log[axis=y]
setblock 178 74 -340 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 179 74 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 74 -340 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 192 74 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 74 -341 minecraft:birch_log[axis=y]
fill 149 74 -341 150 74 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 74 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 74 -341 minecraft:birch_log[axis=y]
setblock 191 74 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 74 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 74 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 148 74 -342 149 74 -342 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 74 -342 minecraft:birch_log[axis=y]
setblock 151 74 -342 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 74 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 74 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 74 -342 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 74 -342 minecraft:birch_log[axis=y]
setblock 193 74 -342 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 74 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 74 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 74 -343 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 74 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 74 -343 minecraft:birch_log[axis=y]
setblock 177 74 -343 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 74 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 74 -343 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 191 74 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 74 -343 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 74 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 74 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 74 -344 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 192 74 -344 193 74 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 74 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 74 -345 minecraft:birch_log[axis=y]
setblock 187 74 -345 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 74 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 74 -345 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 74 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 74 -346 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 74 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 74 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 74 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 74 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 74 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 74 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 74 -347 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 74 -347 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 74 -347 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 74 -348 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 74 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 74 -348 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 74 -348 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 74 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 74 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 74 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 74 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 74 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 74 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 74 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 74 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 74 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 74 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 74 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 74 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 160 74 -350 161 74 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 74 -350 minecraft:birch_log[axis=y]
setblock 165 74 -350 minecraft:birch_log[axis=y]
setblock 170 74 -350 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 171 74 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 74 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 74 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 74 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 74 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 74 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 74 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 74 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 74 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 74 -351 minecraft:birch_log[axis=y]
fill 161 74 -351 162 74 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 74 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 74 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 74 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 74 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 74 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 74 -351 minecraft:birch_log[axis=y]
setblock 150 74 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 74 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 74 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 74 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 74 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 74 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 74 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 74 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 74 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 74 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 74 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 74 -352 minecraft:birch_log[axis=y]
setblock 195 74 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 74 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 74 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 74 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 74 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 74 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 74 -353 minecraft:birch_log[axis=y]
setblock 152 74 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 74 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 74 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 74 -353 minecraft:birch_log[axis=y]
setblock 156 74 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 74 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 74 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 74 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 74 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 74 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 74 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 74 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 74 -354 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 74 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 74 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 74 -354 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 74 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 74 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 74 -354 minecraft:birch_log[axis=y]
setblock 151 74 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 74 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 74 -355 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 179 74 -356 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 74 -357 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 74 -358 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 74 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 74 -358 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 74 -358 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 74 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 74 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 74 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 74 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 74 -360 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 74 -360 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 192 74 -360 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -360 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 74 -361 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 74 -361 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 74 -361 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 74 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 74 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 74 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 74 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 74 -363 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 190 74 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 74 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 74 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 74 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 74 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 74 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 74 -365 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 74 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 74 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 74 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 74 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 74 -366 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 74 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 74 -366 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 74 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 74 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 74 -367 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 74 -367 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 74 -368 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 74 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 74 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 74 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 74 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 74 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 74 -376 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 188 74 -376 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 74 -380 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 191 74 -381 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 192 74 -381 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 74 -381 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 138 73 -324 minecraft:birch_log[axis=y]
setblock 136 73 -325 minecraft:birch_log[axis=y]
setblock 140 73 -325 minecraft:birch_log[axis=y]
setblock 136 73 -326 regions_unexplored:birch_branch[facing=north]
setblock 165 73 -328 regions_unexplored:birch_shrub[half=upper]
setblock 172 73 -328 minecraft:short_grass
setblock 143 73 -329 minecraft:birch_log[axis=y]
setblock 146 73 -329 minecraft:birch_log[axis=y]
setblock 164 73 -329 minecraft:birch_log[axis=y]
setblock 155 73 -330 minecraft:birch_log[axis=y]
setblock 141 73 -331 minecraft:birch_log[axis=y]
setblock 145 73 -331 minecraft:birch_log[axis=y]
setblock 148 73 -331 minecraft:birch_log[axis=y]
setblock 162 73 -331 minecraft:birch_log[axis=y]
setblock 158 73 -333 minecraft:birch_log[axis=y]
setblock 143 73 -334 minecraft:birch_log[axis=y]
setblock 166 73 -334 minecraft:birch_log[axis=y]
setblock 145 73 -335 minecraft:birch_log[axis=y]
setblock 151 73 -335 minecraft:birch_log[axis=y]
setblock 157 73 -335 minecraft:birch_log[axis=y]
setblock 183 73 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 73 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 73 -335 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 73 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 73 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 73 -337 minecraft:birch_log[axis=y]
setblock 168 73 -337 minecraft:birch_log[axis=y]
setblock 179 73 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 73 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 73 -337 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 73 -338 minecraft:birch_log[axis=y]
setblock 163 73 -338 minecraft:birch_log[axis=y]
setblock 180 73 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 73 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 73 -340 minecraft:birch_log[axis=y]
setblock 178 73 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 73 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 73 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -340 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 73 -341 minecraft:birch_log[axis=y]
setblock 155 73 -341 minecraft:birch_log[axis=y]
setblock 179 73 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 73 -342 minecraft:birch_log[axis=y]
setblock 178 73 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -342 minecraft:birch_log[axis=y]
setblock 156 73 -343 minecraft:birch_log[axis=y]
setblock 177 73 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 73 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 73 -343 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 73 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 73 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 73 -344 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 73 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 73 -345 minecraft:birch_log[axis=y]
setblock 186 73 -345 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 73 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 73 -345 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 73 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 73 -345 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 73 -345 minecraft:birch_log[axis=y]
setblock 194 73 -345 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 73 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 73 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 73 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 73 -346 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 73 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 73 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 73 -346 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 73 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 73 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 73 -347 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 73 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 73 -347 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 73 -347 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 73 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 73 -347 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 73 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 73 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 73 -348 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 73 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 73 -348 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 73 -348 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 73 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 73 -348 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 73 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 73 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 73 -349 minecraft:birch_log[axis=y]
setblock 153 73 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 73 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 73 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 73 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 73 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 73 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 73 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 73 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 73 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -350 minecraft:birch_log[axis=y]
setblock 165 73 -350 minecraft:birch_log[axis=y]
setblock 170 73 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 73 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 73 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 73 -350 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 185 73 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 73 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 73 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 73 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 73 -351 minecraft:birch_log[axis=y]
setblock 171 73 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 73 -351 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 176 73 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 73 -351 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 73 -351 minecraft:birch_log[axis=y]
setblock 180 73 -352 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 73 -352 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 73 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 73 -352 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 73 -352 minecraft:birch_log[axis=y]
setblock 151 73 -353 minecraft:birch_log[axis=y]
setblock 155 73 -353 minecraft:birch_log[axis=y]
setblock 180 73 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 73 -353 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 73 -354 minecraft:birch_log[axis=y]
setblock 179 73 -355 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 73 -356 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 73 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 73 -356 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 73 -357 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 73 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -357 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 73 -357 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 73 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 73 -358 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 73 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 73 -358 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 73 -358 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 73 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 73 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 73 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 73 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 73 -359 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 73 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 73 -360 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 73 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 73 -360 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 73 -360 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 193 73 -360 194 73 -360 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 73 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 73 -360 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 73 -361 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 73 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 73 -361 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 73 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 73 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 73 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 73 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 73 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 73 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 73 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 73 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 73 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 73 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 73 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 73 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 73 -363 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 189 73 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 73 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 73 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 73 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 73 -364 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 171 73 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 73 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 73 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 73 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 73 -364 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 190 73 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 73 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 73 -364 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 73 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 73 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 73 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 73 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 73 -365 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 73 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 73 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 73 -365 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 73 -365 minecraft:birch_log[axis=y]
setblock 196 73 -365 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 73 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 73 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 170 73 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 171 73 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 73 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 73 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 73 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 73 -366 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 73 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 73 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 73 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 73 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 73 -367 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 73 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 73 -367 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 73 -367 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 73 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 73 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 73 -368 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 73 -368 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 73 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 73 -368 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 73 -369 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 174 73 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 73 -369 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 73 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 73 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 73 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 73 -369 minecraft:birch_log[axis=y]
setblock 174 73 -370 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 73 -370 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 191 73 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 73 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 73 -370 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 73 -371 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 73 -371 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 73 -375 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 73 -375 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 73 -376 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 73 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 73 -376 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 73 -376 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 73 -376 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 188 73 -377 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 73 -379 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -380 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 73 -381 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 73 -381 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 73 -382 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 192 73 -382 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 138 72 -324 minecraft:birch_log[axis=y]
setblock 136 72 -325 minecraft:birch_log[axis=y]
setblock 140 72 -325 minecraft:birch_log[axis=y]
setblock 150 72 -327 minecraft:short_grass
setblock 165 72 -328 regions_unexplored:birch_shrub[half=lower]
setblock 172 72 -328 minecraft:grass_block[snowy=false]
setblock 143 72 -329 minecraft:birch_log[axis=y]
setblock 146 72 -329 minecraft:birch_log[axis=y]
setblock 153 72 -329 minecraft:short_grass
fill 158 72 -329 159 72 -329 regions_unexplored:grass_sprouts
setblock 163 72 -329 minecraft:short_grass
setblock 164 72 -329 minecraft:birch_log[axis=y]
setblock 154 72 -330 regions_unexplored:grass_sprouts
setblock 155 72 -330 minecraft:birch_log[axis=y]
fill 156 72 -330 157 72 -330 regions_unexplored:grass_sprouts
setblock 141 72 -331 minecraft:birch_log[axis=y]
setblock 145 72 -331 minecraft:birch_log[axis=y]
setblock 148 72 -331 minecraft:birch_log[axis=y]
setblock 153 72 -331 regions_unexplored:grass_sprouts
setblock 162 72 -331 minecraft:birch_log[axis=y]
setblock 158 72 -333 minecraft:birch_log[axis=y]
setblock 143 72 -334 minecraft:birch_log[axis=y]
setblock 166 72 -334 minecraft:birch_log[axis=y]
setblock 145 72 -335 minecraft:birch_log[axis=y]
setblock 151 72 -335 minecraft:birch_log[axis=y]
setblock 157 72 -335 minecraft:birch_log[axis=y]
setblock 183 72 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 72 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 72 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 72 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 72 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 72 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 72 -336 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 72 -337 minecraft:birch_log[axis=y]
setblock 168 72 -337 minecraft:birch_log[axis=y]
setblock 179 72 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 72 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 72 -338 minecraft:birch_log[axis=y]
setblock 163 72 -338 minecraft:birch_log[axis=y]
setblock 179 72 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 72 -338 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 72 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 72 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -339 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 72 -340 minecraft:birch_log[axis=y]
setblock 178 72 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -340 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 72 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 72 -341 minecraft:birch_log[axis=y]
setblock 155 72 -341 minecraft:birch_log[axis=y]
setblock 178 72 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 72 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -341 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 72 -342 minecraft:birch_log[axis=y]
setblock 177 72 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 72 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -342 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 72 -342 minecraft:birch_log[axis=y]
setblock 156 72 -343 minecraft:birch_log[axis=y]
setblock 177 72 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 72 -343 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 72 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 72 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 72 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -344 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 72 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 72 -345 minecraft:birch_log[axis=y]
setblock 186 72 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 72 -345 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 72 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 72 -345 minecraft:birch_log[axis=y]
setblock 179 72 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 72 -346 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 72 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 72 -346 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 72 -346 minecraft:birch_log[axis=y]
setblock 188 72 -346 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 72 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -347 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 72 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 72 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 72 -347 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 72 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -348 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 72 -348 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 72 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 72 -348 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 72 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 72 -349 minecraft:birch_log[axis=y]
setblock 170 72 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 72 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 72 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 72 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 72 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 72 -349 minecraft:birch_log[axis=y]
setblock 187 72 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 72 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 72 -350 minecraft:birch_log[axis=y]
setblock 165 72 -350 minecraft:birch_log[axis=y]
setblock 170 72 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 72 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 72 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 72 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 72 -350 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 72 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 72 -350 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 185 72 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 72 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 72 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 72 -351 minecraft:birch_log[axis=y]
setblock 170 72 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 72 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 72 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 72 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 72 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 72 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 72 -351 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 72 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 72 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 72 -351 minecraft:birch_log[axis=y]
setblock 176 72 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 72 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 72 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 72 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 72 -352 minecraft:birch_log[axis=y]
setblock 151 72 -353 minecraft:birch_log[axis=y]
setblock 155 72 -353 minecraft:birch_log[axis=y]
setblock 179 72 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 72 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 72 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 72 -354 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 72 -354 minecraft:birch_log[axis=y]
setblock 178 72 -355 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 72 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -355 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -355 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 72 -355 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 72 -355 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 72 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 72 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -356 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 72 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 72 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 72 -357 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 72 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 72 -357 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 72 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -357 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 72 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 72 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 72 -358 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 72 -358 minecraft:birch_log[axis=y]
setblock 155 72 -358 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 72 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 72 -358 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 72 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 72 -358 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 72 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 72 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 72 -359 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 72 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 72 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 72 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 72 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 72 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 72 -359 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 72 -359 minecraft:birch_log[axis=y]
setblock 193 72 -359 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 194 72 -359 195 72 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 72 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 72 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 72 -360 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 72 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 72 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 72 -360 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 193 72 -360 194 72 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 72 -360 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 72 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 72 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 72 -361 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 72 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 72 -361 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 192 72 -361 193 72 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 72 -361 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 72 -361 minecraft:birch_log[axis=y]
setblock 196 72 -361 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 72 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 72 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 72 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 72 -362 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 72 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 72 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 72 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 72 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 72 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 72 -362 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 72 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 72 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 72 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 72 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 72 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 72 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 72 -363 minecraft:birch_log[axis=y]
setblock 173 72 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 174 72 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 72 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 72 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 72 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 72 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 72 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 72 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 170 72 -364 171 72 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 72 -364 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 72 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 72 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 72 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 72 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 72 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 72 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 72 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 169 72 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 170 72 -365 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 171 72 -365 172 72 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 72 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 72 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 72 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 72 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 72 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 72 -365 minecraft:birch_log[axis=y]
setblock 168 72 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 72 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 170 72 -366 minecraft:birch_log[axis=y]
setblock 171 72 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 72 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 72 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 72 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 72 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 72 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 72 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 72 -366 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 169 72 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 170 72 -367 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 171 72 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 72 -367 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 72 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 72 -367 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 72 -367 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 72 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 72 -368 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -368 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 173 72 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 174 72 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 72 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 72 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 72 -369 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 191 72 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 72 -369 minecraft:birch_log[axis=y]
setblock 174 72 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 72 -370 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 72 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 72 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 72 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 72 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 72 -371 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 191 72 -371 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 72 -375 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 179 72 -375 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -375 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 72 -375 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 72 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 72 -375 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 72 -375 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 72 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 72 -376 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 72 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 72 -376 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 72 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 72 -376 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 72 -377 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 72 -377 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 72 -377 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 72 -377 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 72 -378 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 72 -379 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 72 -380 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 72 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 193 72 -380 194 72 -380 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 72 -380 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 72 -380 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 72 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 72 -381 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 72 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 72 -382 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 72 -382 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 72 -382 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 72 -382 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 138 71 -324 minecraft:birch_log[axis=y]
setblock 136 71 -325 minecraft:birch_log[axis=y]
setblock 140 71 -325 minecraft:birch_log[axis=y]
fill 148 71 -326 166 71 -326 minecraft:grass_block[snowy=false]
fill 148 71 -327 165 71 -327 minecraft:grass_block[snowy=false]
setblock 172 71 -327 minecraft:grass_block[snowy=false]
fill 149 71 -328 165 71 -328 minecraft:grass_block[snowy=false]
setblock 171 71 -328 minecraft:grass_block[snowy=false]
setblock 172 71 -328 minecraft:dirt
setblock 143 71 -329 minecraft:birch_log[axis=y]
setblock 146 71 -329 minecraft:birch_log[axis=y]
setblock 148 71 -329 minecraft:short_grass
fill 150 71 -329 163 71 -329 minecraft:grass_block[snowy=false]
setblock 164 71 -329 minecraft:dirt
setblock 149 71 -330 minecraft:short_grass
fill 151 71 -330 154 71 -330 minecraft:grass_block[snowy=false]
setblock 155 71 -330 minecraft:dirt
fill 156 71 -330 159 71 -330 minecraft:grass_block[snowy=false]
fill 162 71 -330 164 71 -330 minecraft:grass_block[snowy=false]
setblock 141 71 -331 minecraft:birch_log[axis=y]
setblock 145 71 -331 minecraft:birch_log[axis=y]
setblock 148 71 -331 minecraft:birch_log[axis=y]
fill 152 71 -331 156 71 -331 minecraft:grass_block[snowy=false]
setblock 162 71 -331 minecraft:birch_log[axis=y]
setblock 146 71 -332 minecraft:short_grass
setblock 161 71 -332 minecraft:short_grass
setblock 163 71 -332 minecraft:short_grass
setblock 172 71 -332 minecraft:grass_block[snowy=false]
setblock 148 71 -333 minecraft:short_grass
setblock 149 71 -333 regions_unexplored:grass_sprouts
fill 155 71 -333 156 71 -333 minecraft:short_grass
setblock 158 71 -333 minecraft:birch_log[axis=y]
setblock 159 71 -333 regions_unexplored:grass_sprouts
setblock 143 71 -334 minecraft:birch_log[axis=y]
setblock 153 71 -334 minecraft:short_grass
setblock 157 71 -334 regions_unexplored:grass_sprouts
setblock 159 71 -334 regions_unexplored:grass_sprouts
setblock 166 71 -334 minecraft:birch_log[axis=y]
setblock 145 71 -335 minecraft:birch_log[axis=y]
setblock 148 71 -335 regions_unexplored:grass_sprouts
setblock 149 71 -335 minecraft:short_grass
setblock 151 71 -335 minecraft:birch_log[axis=y]
setblock 152 71 -335 regions_unexplored:grass_sprouts
setblock 157 71 -335 minecraft:birch_log[axis=y]
setblock 180 71 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 71 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 71 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 71 -335 minecraft:birch_log[axis=y]
setblock 185 71 -335 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 71 -335 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 71 -336 regions_unexplored:grass_sprouts
setblock 160 71 -336 minecraft:short_grass
setblock 162 71 -336 minecraft:short_grass
setblock 179 71 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 71 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 71 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 71 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 71 -336 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 71 -336 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 71 -337 minecraft:birch_log[axis=y]
setblock 153 71 -337 regions_unexplored:grass_sprouts
setblock 156 71 -337 minecraft:short_grass
setblock 159 71 -337 minecraft:short_grass
setblock 168 71 -337 minecraft:birch_log[axis=y]
setblock 178 71 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 71 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 71 -337 minecraft:birch_log[axis=y]
setblock 181 71 -337 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 71 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 71 -337 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 71 -338 minecraft:birch_log[axis=y]
setblock 163 71 -338 minecraft:birch_log[axis=y]
setblock 179 71 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 71 -338 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 71 -338 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 71 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 71 -339 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 71 -339 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 71 -340 minecraft:birch_log[axis=y]
setblock 177 71 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 71 -340 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 71 -340 minecraft:birch_log[axis=y]
setblock 180 71 -340 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 71 -340 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 71 -341 minecraft:birch_log[axis=y]
setblock 155 71 -341 minecraft:birch_log[axis=y]
setblock 178 71 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 71 -341 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 71 -341 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 71 -342 minecraft:birch_log[axis=y]
setblock 177 71 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 71 -342 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 71 -342 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -342 minecraft:birch_log[axis=y]
setblock 156 71 -343 minecraft:birch_log[axis=y]
setblock 176 71 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 71 -343 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 71 -343 minecraft:birch_log[axis=y]
setblock 179 71 -343 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 71 -343 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 71 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 71 -344 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 71 -344 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 71 -345 minecraft:birch_log[axis=y]
setblock 178 71 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 71 -345 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 71 -345 minecraft:birch_log[axis=y]
setblock 179 71 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 71 -346 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 71 -346 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -346 minecraft:birch_log[axis=y]
setblock 178 71 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 71 -347 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 71 -347 minecraft:birch_log[axis=y]
setblock 181 71 -347 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 71 -347 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 71 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 71 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 71 -348 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 71 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 71 -349 minecraft:birch_log[axis=y]
setblock 170 71 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 71 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 71 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 71 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 71 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 71 -349 minecraft:birch_log[axis=y]
setblock 162 71 -350 minecraft:birch_log[axis=y]
setblock 165 71 -350 minecraft:birch_log[axis=y]
setblock 169 71 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 170 71 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 171 71 -350 minecraft:birch_log[axis=y]
setblock 172 71 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 71 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 71 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 71 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 71 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 71 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 71 -350 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 71 -351 minecraft:birch_log[axis=y]
setblock 165 71 -351 regions_unexplored:birch_branch[facing=north]
setblock 170 71 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 71 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 71 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 71 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 71 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 177 71 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 71 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 71 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 71 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 71 -351 minecraft:birch_log[axis=y]
setblock 171 71 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 71 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 71 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 71 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 71 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 71 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 71 -352 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 71 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 71 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 71 -352 minecraft:birch_log[axis=y]
setblock 151 71 -353 minecraft:birch_log[axis=y]
setblock 155 71 -353 minecraft:birch_log[axis=y]
setblock 179 71 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 71 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 71 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 71 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 71 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -353 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 179 71 -354 180 71 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 181 71 -354 182 71 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 71 -354 minecraft:birch_log[axis=y]
setblock 178 71 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 71 -355 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 71 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 71 -355 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 71 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 71 -355 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 71 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 71 -356 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 71 -356 minecraft:birch_log[axis=y]
setblock 180 71 -356 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 71 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 71 -356 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 174 71 -357 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 71 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 71 -357 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 71 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 71 -358 minecraft:birch_log[axis=y]
setblock 173 71 -358 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 174 71 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 71 -358 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 71 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 71 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 71 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -359 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 71 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -359 minecraft:birch_log[axis=y]
setblock 186 71 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -360 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 71 -360 minecraft:birch_log[axis=y]
setblock 189 71 -360 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 71 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -361 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 189 71 -361 190 71 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 71 -361 minecraft:birch_log[axis=y]
setblock 163 71 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 71 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 71 -362 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 188 71 -362 189 71 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -362 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 71 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 71 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 71 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 71 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 71 -363 minecraft:birch_log[axis=y]
setblock 174 71 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 71 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 71 -363 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 71 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 71 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 71 -363 minecraft:birch_log[axis=y]
setblock 191 71 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 71 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 71 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 71 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 71 -364 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 174 71 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 71 -364 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 176 71 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 71 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 71 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -364 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 71 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 71 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 71 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 71 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 71 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 71 -365 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 71 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 71 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 71 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -365 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 71 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 71 -365 minecraft:birch_log[axis=y]
setblock 170 71 -366 minecraft:birch_log[axis=y]
setblock 181 71 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 71 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 71 -366 minecraft:birch_log[axis=y]
setblock 184 71 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 71 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 71 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 71 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 71 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 71 -367 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 71 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 71 -367 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 71 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -367 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 173 71 -368 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 174 71 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 71 -368 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 71 -368 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 71 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 71 -368 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 71 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 71 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 71 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 175 71 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 71 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 71 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 71 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 71 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 71 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 71 -369 minecraft:birch_log[axis=y]
setblock 173 71 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 174 71 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 71 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 71 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 71 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 71 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 71 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 71 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -370 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 71 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 71 -370 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 71 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -371 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 71 -371 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 71 -371 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -371 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 71 -374 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 71 -374 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 71 -375 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 71 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 71 -375 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 71 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -375 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 71 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 71 -375 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 71 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 71 -375 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 71 -376 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 71 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -376 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 71 -376 minecraft:birch_log[axis=y]
setblock 189 71 -376 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 71 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 71 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 71 -376 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 71 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -377 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -377 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 71 -377 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 71 -377 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 71 -377 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 71 -377 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 71 -378 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 71 -378 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -379 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 71 -379 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 71 -379 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 71 -379 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 71 -380 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 71 -380 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 71 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -380 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 193 71 -380 194 71 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 71 -380 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 71 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 71 -381 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 190 71 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 71 -381 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 71 -381 minecraft:birch_log[axis=y]
setblock 193 71 -381 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 71 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 71 -382 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 71 -382 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 71 -382 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 71 -382 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -382 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 71 -382 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 140 70 -319 142 70 -319 minecraft:grass_block[snowy=false]
fill 141 70 -320 142 70 -320 minecraft:grass_block[snowy=false]
setblock 142 70 -321 minecraft:grass_block[snowy=false]
setblock 140 70 -322 minecraft:short_grass
setblock 142 70 -322 minecraft:grass_block[snowy=false]
setblock 138 70 -324 minecraft:birch_log[axis=y]
setblock 136 70 -325 minecraft:birch_log[axis=y]
setblock 140 70 -325 minecraft:birch_log[axis=y]
fill 144 70 -326 147 70 -326 minecraft:grass_block[snowy=false]
fill 148 70 -326 166 70 -326 minecraft:dirt
setblock 167 70 -326 minecraft:grass_block[snowy=false]
setblock 141 70 -327 minecraft:short_grass
fill 144 70 -327 147 70 -327 minecraft:grass_block[snowy=false]
fill 148 70 -327 165 70 -327 minecraft:dirt
fill 166 70 -327 167 70 -327 minecraft:grass_block[snowy=false]
setblock 171 70 -327 minecraft:grass_block[snowy=false]
setblock 172 70 -327 minecraft:dirt
setblock 140 70 -328 regions_unexplored:grass_sprouts
fill 145 70 -328 148 70 -328 minecraft:grass_block[snowy=false]
fill 149 70 -328 165 70 -328 minecraft:dirt
setblock 166 70 -328 minecraft:grass_block[snowy=false]
fill 171 70 -328 172 70 -328 minecraft:dirt
setblock 143 70 -329 minecraft:birch_log[axis=y]
setblock 145 70 -329 minecraft:grass_block[snowy=false]
setblock 146 70 -329 minecraft:dirt
fill 147 70 -329 149 70 -329 minecraft:grass_block[snowy=false]
fill 150 70 -329 164 70 -329 minecraft:dirt
setblock 165 70 -329 minecraft:grass_block[snowy=false]
setblock 166 70 -329 minecraft:short_grass
fill 145 70 -330 150 70 -330 minecraft:grass_block[snowy=false]
fill 151 70 -330 159 70 -330 minecraft:dirt
fill 160 70 -330 161 70 -330 minecraft:grass_block[snowy=false]
fill 162 70 -330 164 70 -330 minecraft:dirt
setblock 165 70 -330 minecraft:grass_block[snowy=false]
setblock 140 70 -331 minecraft:short_grass
setblock 141 70 -331 minecraft:birch_log[axis=y]
setblock 145 70 -331 minecraft:dirt
fill 146 70 -331 147 70 -331 minecraft:grass_block[snowy=false]
setblock 148 70 -331 minecraft:dirt
fill 149 70 -331 151 70 -331 minecraft:grass_block[snowy=false]
fill 152 70 -331 156 70 -331 minecraft:dirt
fill 157 70 -331 161 70 -331 minecraft:grass_block[snowy=false]
setblock 162 70 -331 minecraft:dirt
fill 163 70 -331 164 70 -331 minecraft:grass_block[snowy=false]
fill 145 70 -332 164 70 -332 minecraft:grass_block[snowy=false]
setblock 172 70 -332 minecraft:dirt
fill 145 70 -333 157 70 -333 minecraft:grass_block[snowy=false]
setblock 158 70 -333 minecraft:dirt
fill 159 70 -333 164 70 -333 minecraft:grass_block[snowy=false]
setblock 165 70 -333 regions_unexplored:grass_sprouts
setblock 172 70 -333 minecraft:grass_block[snowy=false]
setblock 142 70 -334 regions_unexplored:grass_sprouts
setblock 143 70 -334 minecraft:birch_log[axis=y]
fill 145 70 -334 164 70 -334 minecraft:grass_block[snowy=false]
setblock 166 70 -334 minecraft:birch_log[axis=y]
setblock 171 70 -334 regions_unexplored:grass_sprouts
setblock 172 70 -334 minecraft:grass_block[snowy=false]
setblock 145 70 -335 minecraft:dirt
fill 146 70 -335 150 70 -335 minecraft:grass_block[snowy=false]
setblock 151 70 -335 minecraft:dirt
fill 152 70 -335 156 70 -335 minecraft:grass_block[snowy=false]
setblock 157 70 -335 minecraft:dirt
fill 158 70 -335 165 70 -335 minecraft:grass_block[snowy=false]
setblock 166 70 -335 minecraft:short_grass
setblock 184 70 -335 minecraft:birch_log[axis=y]
fill 144 70 -336 169 70 -336 minecraft:grass_block[snowy=false]
fill 147 70 -337 149 70 -337 minecraft:grass_block[snowy=false]
setblock 150 70 -337 minecraft:dirt
fill 151 70 -337 159 70 -337 minecraft:grass_block[snowy=false]
setblock 161 70 -337 minecraft:short_grass
setblock 164 70 -337 minecraft:short_grass
setblock 168 70 -337 minecraft:dirt
setblock 180 70 -337 minecraft:birch_log[axis=y]
setblock 151 70 -338 minecraft:short_grass
fill 153 70 -338 155 70 -338 minecraft:grass_block[snowy=false]
setblock 156 70 -338 minecraft:dirt
setblock 157 70 -338 minecraft:grass_block[snowy=false]
setblock 163 70 -338 minecraft:birch_log[axis=y]
setblock 150 70 -339 minecraft:short_grass
fill 152 70 -339 153 70 -339 minecraft:short_grass
setblock 154 70 -339 regions_unexplored:grass_sprouts
setblock 167 70 -339 minecraft:short_grass
setblock 146 70 -340 minecraft:short_grass
setblock 148 70 -340 minecraft:short_grass
setblock 150 70 -340 minecraft:short_grass
setblock 151 70 -340 regions_unexplored:grass_sprouts
setblock 152 70 -340 minecraft:birch_log[axis=y]
setblock 154 70 -340 minecraft:short_grass
setblock 155 70 -340 regions_unexplored:grass_sprouts
setblock 158 70 -340 regions_unexplored:grass_sprouts
setblock 159 70 -340 minecraft:short_grass
setblock 162 70 -340 minecraft:short_grass
setblock 179 70 -340 minecraft:birch_log[axis=y]
setblock 148 70 -341 minecraft:birch_log[axis=y]
setblock 151 70 -341 minecraft:short_grass
setblock 155 70 -341 minecraft:birch_log[axis=y]
fill 156 70 -341 157 70 -341 minecraft:short_grass
setblock 160 70 -341 regions_unexplored:grass_sprouts
setblock 150 70 -342 minecraft:birch_log[axis=y]
setblock 153 70 -342 regions_unexplored:grass_sprouts
setblock 156 70 -342 minecraft:grass_block[snowy=false]
setblock 192 70 -342 minecraft:birch_log[axis=y]
setblock 155 70 -343 regions_unexplored:grass_sprouts
setblock 156 70 -343 minecraft:birch_log[axis=y]
setblock 178 70 -343 minecraft:birch_log[axis=y]
setblock 156 70 -344 regions_unexplored:grass_sprouts
setblock 149 70 -345 minecraft:tall_grass[half=upper]
setblock 168 70 -345 minecraft:birch_log[axis=y]
setblock 193 70 -345 minecraft:birch_log[axis=y]
setblock 187 70 -346 minecraft:birch_log[axis=y]
setblock 180 70 -347 minecraft:birch_log[axis=y]
setblock 152 70 -349 minecraft:birch_log[axis=y]
setblock 176 70 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 70 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 70 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -349 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 70 -349 minecraft:birch_log[axis=y]
setblock 162 70 -350 minecraft:birch_log[axis=y]
setblock 165 70 -350 minecraft:birch_log[axis=y]
setblock 171 70 -350 minecraft:birch_log[axis=y]
setblock 175 70 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 70 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 177 70 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 70 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 70 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 70 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 70 -351 minecraft:birch_log[axis=y]
setblock 174 70 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 70 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 176 70 -351 minecraft:birch_log[axis=y]
setblock 177 70 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 70 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -351 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 70 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 70 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 70 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 70 -351 minecraft:birch_log[axis=y]
setblock 175 70 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 70 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 177 70 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 70 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 70 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 70 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 70 -352 minecraft:birch_log[axis=y]
setblock 188 70 -352 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 70 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 70 -352 minecraft:birch_log[axis=y]
setblock 151 70 -353 minecraft:birch_log[axis=y]
setblock 155 70 -353 minecraft:birch_log[axis=y]
setblock 176 70 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 70 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 70 -353 minecraft:birch_log[axis=y]
setblock 181 70 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 70 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 70 -353 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 70 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 70 -354 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 181 70 -354 182 70 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 70 -354 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 70 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 70 -354 minecraft:birch_log[axis=y]
fill 180 70 -355 181 70 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 70 -355 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 70 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -356 minecraft:birch_log[axis=y]
setblock 181 70 -356 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 70 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 70 -356 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 173 70 -357 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 174 70 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 70 -357 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 70 -358 minecraft:birch_log[axis=y]
setblock 173 70 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 70 -358 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 175 70 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 70 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 174 70 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 70 -359 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 70 -359 minecraft:birch_log[axis=y]
setblock 188 70 -360 minecraft:birch_log[axis=y]
setblock 164 70 -361 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 70 -361 minecraft:birch_log[axis=y]
setblock 163 70 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 70 -362 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 70 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 70 -362 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 70 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 70 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 70 -363 minecraft:birch_log[axis=y]
setblock 165 70 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 70 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 70 -363 minecraft:birch_log[axis=y]
setblock 174 70 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 70 -363 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 176 70 -363 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 70 -363 minecraft:birch_log[axis=y]
setblock 163 70 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 70 -364 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 70 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 70 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 70 -364 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 175 70 -364 minecraft:birch_log[axis=y]
setblock 176 70 -364 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 177 70 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -364 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 70 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 70 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 70 -365 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 176 70 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 70 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -365 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 70 -365 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 70 -365 minecraft:birch_log[axis=y]
setblock 170 70 -366 minecraft:birch_log[axis=y]
setblock 175 70 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 70 -366 minecraft:birch_log[axis=y]
fill 184 70 -366 185 70 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 70 -366 minecraft:birch_log[axis=y]
setblock 187 70 -366 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 70 -366 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 70 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 70 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 70 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -367 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 70 -367 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 70 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 70 -368 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 175 70 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 70 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 70 -368 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 70 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 70 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 70 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 70 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 174 70 -369 minecraft:birch_log[axis=y]
setblock 175 70 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 176 70 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 70 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 70 -369 minecraft:birch_log[axis=y]
setblock 182 70 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 70 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 70 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 70 -369 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 70 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 70 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 70 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 70 -369 minecraft:birch_log[axis=y]
setblock 173 70 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 70 -370 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 175 70 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 70 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 70 -370 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 70 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 70 -370 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 188 70 -370 189 70 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 70 -370 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 70 -370 minecraft:birch_log[axis=y]
setblock 192 70 -370 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 70 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 70 -371 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 70 -371 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -371 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 70 -371 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 70 -371 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 70 -371 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 70 -371 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 70 -371 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 70 -372 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 70 -374 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 70 -374 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 70 -374 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 70 -374 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 70 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -375 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 70 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 70 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 70 -375 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 70 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 70 -376 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 70 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 70 -376 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 70 -376 minecraft:birch_log[axis=y]
setblock 196 70 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 70 -376 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 70 -376 minecraft:birch_log[axis=y]
setblock 199 70 -376 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 70 -377 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 70 -377 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 70 -377 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 70 -378 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 70 -379 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 70 -379 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 70 -379 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 70 -379 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 70 -380 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 70 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 70 -380 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 70 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 70 -380 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 70 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 70 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 70 -381 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 70 -381 minecraft:birch_log[axis=y]
setblock 193 70 -381 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 70 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 70 -381 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 70 -382 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 70 -382 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 70 -382 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 137 69 -319 139 69 -319 minecraft:grass_block[snowy=false]
fill 140 69 -319 142 69 -319 minecraft:dirt
fill 137 69 -320 140 69 -320 minecraft:grass_block[snowy=false]
fill 141 69 -320 142 69 -320 minecraft:dirt
fill 138 69 -321 141 69 -321 minecraft:grass_block[snowy=false]
setblock 142 69 -321 minecraft:dirt
fill 138 69 -322 141 69 -322 minecraft:grass_block[snowy=false]
setblock 142 69 -322 minecraft:dirt
fill 139 69 -323 142 69 -323 minecraft:grass_block[snowy=false]
setblock 138 69 -324 minecraft:birch_log[axis=y]
fill 139 69 -324 142 69 -324 minecraft:grass_block[snowy=false]
setblock 136 69 -325 minecraft:birch_log[axis=y]
setblock 138 69 -325 minecraft:short_grass
setblock 139 69 -325 minecraft:grass_block[snowy=false]
setblock 140 69 -325 minecraft:dirt
fill 141 69 -325 142 69 -325 minecraft:grass_block[snowy=false]
setblock 139 69 -326 regions_unexplored:grass_sprouts
fill 140 69 -326 143 69 -326 minecraft:grass_block[snowy=false]
fill 144 69 -326 167 69 -326 minecraft:dirt
fill 170 69 -326 172 69 -326 minecraft:grass_block[snowy=false]
setblock 136 69 -327 minecraft:short_grass
fill 140 69 -327 143 69 -327 minecraft:grass_block[snowy=false]
fill 144 69 -327 167 69 -327 minecraft:dirt
setblock 170 69 -327 minecraft:grass_block[snowy=false]
fill 171 69 -327 172 69 -327 minecraft:dirt
setblock 138 69 -328 minecraft:short_grass
fill 140 69 -328 144 69 -328 minecraft:grass_block[snowy=false]
fill 145 69 -328 166 69 -328 minecraft:dirt
setblock 167 69 -328 minecraft:grass_block[snowy=false]
setblock 170 69 -328 minecraft:grass_block[snowy=false]
fill 171 69 -328 172 69 -328 minecraft:dirt
fill 138 69 -329 139 69 -329 minecraft:short_grass
fill 140 69 -329 142 69 -329 minecraft:grass_block[snowy=false]
setblock 143 69 -329 minecraft:dirt
setblock 144 69 -329 minecraft:grass_block[snowy=false]
fill 145 69 -329 165 69 -329 minecraft:dirt
setblock 166 69 -329 minecraft:grass_block[snowy=false]
fill 170 69 -329 171 69 -329 minecraft:grass_block[snowy=false]
fill 138 69 -330 139 69 -330 minecraft:short_grass
fill 140 69 -330 144 69 -330 minecraft:grass_block[snowy=false]
fill 145 69 -330 165 69 -330 minecraft:dirt
setblock 166 69 -330 minecraft:grass_block[snowy=false]
setblock 137 69 -331 minecraft:short_grass
setblock 140 69 -331 minecraft:grass_block[snowy=false]
setblock 141 69 -331 minecraft:dirt
fill 142 69 -331 144 69 -331 minecraft:grass_block[snowy=false]
fill 145 69 -331 164 69 -331 minecraft:dirt
setblock 165 69 -331 minecraft:grass_block[snowy=false]
setblock 171 69 -331 minecraft:grass_block[snowy=false]
fill 140 69 -332 144 69 -332 minecraft:grass_block[snowy=false]
fill 145 69 -332 164 69 -332 minecraft:dirt
setblock 165 69 -332 minecraft:grass_block[snowy=false]
setblock 171 69 -332 minecraft:grass_block[snowy=false]
setblock 172 69 -332 minecraft:dirt
fill 140 69 -333 144 69 -333 minecraft:grass_block[snowy=false]
fill 145 69 -333 164 69 -333 minecraft:dirt
setblock 165 69 -333 minecraft:grass_block[snowy=false]
setblock 171 69 -333 minecraft:grass_block[snowy=false]
setblock 172 69 -333 minecraft:dirt
fill 140 69 -334 142 69 -334 minecraft:grass_block[snowy=false]
setblock 143 69 -334 minecraft:dirt
setblock 144 69 -334 minecraft:grass_block[snowy=false]
fill 145 69 -334 164 69 -334 minecraft:dirt
setblock 165 69 -334 minecraft:grass_block[snowy=false]
setblock 166 69 -334 minecraft:dirt
setblock 171 69 -334 minecraft:grass_block[snowy=false]
setblock 172 69 -334 minecraft:dirt
fill 140 69 -335 144 69 -335 minecraft:grass_block[snowy=false]
fill 145 69 -335 165 69 -335 minecraft:dirt
fill 166 69 -335 172 69 -335 minecraft:grass_block[snowy=false]
setblock 184 69 -335 minecraft:birch_log[axis=y]
fill 140 69 -336 143 69 -336 minecraft:grass_block[snowy=false]
fill 144 69 -336 169 69 -336 minecraft:dirt
fill 170 69 -336 172 69 -336 minecraft:grass_block[snowy=false]
setblock 140 69 -337 minecraft:short_grass
fill 141 69 -337 146 69 -337 minecraft:grass_block[snowy=false]
fill 147 69 -337 159 69 -337 minecraft:dirt
fill 160 69 -337 167 69 -337 minecraft:grass_block[snowy=false]
setblock 168 69 -337 minecraft:dirt
setblock 169 69 -337 minecraft:grass_block[snowy=false]
setblock 180 69 -337 minecraft:birch_log[axis=y]
setblock 139 69 -338 minecraft:short_grass
fill 142 69 -338 152 69 -338 minecraft:grass_block[snowy=false]
fill 153 69 -338 157 69 -338 minecraft:dirt
fill 158 69 -338 162 69 -338 minecraft:grass_block[snowy=false]
setblock 163 69 -338 minecraft:dirt
fill 164 69 -338 168 69 -338 minecraft:grass_block[snowy=false]
fill 143 69 -339 168 69 -339 minecraft:grass_block[snowy=false]
fill 145 69 -340 151 69 -340 minecraft:grass_block[snowy=false]
setblock 152 69 -340 minecraft:dirt
fill 153 69 -340 168 69 -340 minecraft:grass_block[snowy=false]
setblock 179 69 -340 minecraft:birch_log[axis=y]
setblock 148 69 -341 minecraft:dirt
fill 149 69 -341 154 69 -341 minecraft:grass_block[snowy=false]
setblock 155 69 -341 minecraft:dirt
fill 156 69 -341 163 69 -341 minecraft:grass_block[snowy=false]
fill 167 69 -341 168 69 -341 minecraft:grass_block[snowy=false]
setblock 150 69 -342 minecraft:birch_log[axis=y]
fill 151 69 -342 155 69 -342 minecraft:grass_block[snowy=false]
setblock 156 69 -342 minecraft:dirt
fill 157 69 -342 160 69 -342 minecraft:grass_block[snowy=false]
setblock 192 69 -342 productivebees:birch_wood_nest[axis=y,facing=north]
setblock 142 69 -343 minecraft:tall_grass[half=upper]
setblock 144 69 -343 minecraft:tall_grass[half=upper]
setblock 147 69 -343 regions_unexplored:grass_sprouts
setblock 153 69 -343 regions_unexplored:grass_sprouts
setblock 155 69 -343 minecraft:grass_block[snowy=false]
setblock 156 69 -343 minecraft:dirt
fill 157 69 -343 158 69 -343 minecraft:grass_block[snowy=false]
setblock 178 69 -343 minecraft:birch_log[axis=y]
setblock 148 69 -344 minecraft:short_grass
fill 151 69 -344 152 69 -344 regions_unexplored:grass_sprouts
setblock 154 69 -344 minecraft:short_grass
setblock 156 69 -344 minecraft:grass_block[snowy=false]
setblock 149 69 -345 minecraft:tall_grass[half=lower]
setblock 152 69 -345 regions_unexplored:grass_sprouts
setblock 156 69 -345 regions_unexplored:grass_sprouts
setblock 168 69 -345 minecraft:birch_log[axis=y]
setblock 193 69 -345 minecraft:birch_log[axis=y]
setblock 187 69 -346 minecraft:birch_log[axis=y]
setblock 152 69 -347 regions_unexplored:grass_sprouts
setblock 156 69 -347 minecraft:short_grass
setblock 180 69 -347 minecraft:birch_log[axis=y]
setblock 152 69 -348 minecraft:short_grass
setblock 178 69 -348 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 69 -349 minecraft:birch_log[axis=y]
setblock 177 69 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 69 -349 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 69 -349 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 69 -349 minecraft:birch_log[axis=y]
setblock 162 69 -350 minecraft:birch_log[axis=y]
setblock 165 69 -350 minecraft:birch_log[axis=y]
setblock 171 69 -350 minecraft:birch_log[axis=y]
fill 176 69 -350 177 69 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 69 -350 minecraft:birch_log[axis=y]
setblock 179 69 -350 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 69 -350 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 69 -351 minecraft:grass_block[snowy=false]
setblock 160 69 -351 minecraft:birch_log[axis=y]
setblock 176 69 -351 minecraft:birch_log[axis=y]
fill 177 69 -351 178 69 -351 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 69 -351 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 69 -351 minecraft:birch_log[axis=y]
setblock 178 69 -352 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 69 -352 minecraft:birch_log[axis=y]
setblock 194 69 -352 minecraft:birch_log[axis=y]
setblock 151 69 -353 minecraft:birch_log[axis=y]
setblock 155 69 -353 minecraft:birch_log[axis=y]
setblock 180 69 -353 minecraft:birch_log[axis=y]
setblock 182 69 -353 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 69 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 69 -354 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 69 -354 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 69 -354 minecraft:birch_log[axis=y]
setblock 180 69 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 69 -355 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 69 -355 minecraft:birch_log[axis=y]
setblock 183 69 -355 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 69 -355 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 69 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 69 -356 minecraft:birch_log[axis=y]
setblock 181 69 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 69 -356 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 69 -356 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 69 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 69 -357 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 175 69 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 69 -357 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 69 -358 minecraft:birch_log[axis=y]
setblock 172 69 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 69 -358 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 174 69 -358 minecraft:birch_log[axis=y]
setblock 175 69 -358 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 176 69 -358 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 69 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 69 -359 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 175 69 -359 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 69 -359 minecraft:birch_log[axis=y]
setblock 174 69 -360 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 69 -360 minecraft:birch_log[axis=y]
setblock 195 69 -361 minecraft:birch_log[axis=y]
setblock 164 69 -363 minecraft:birch_log[axis=y]
setblock 172 69 -363 minecraft:birch_log[axis=y]
setblock 190 69 -363 minecraft:birch_log[axis=y]
setblock 175 69 -364 minecraft:birch_log[axis=y]
setblock 195 69 -365 minecraft:birch_log[axis=y]
setblock 170 69 -366 minecraft:birch_log[axis=y]
setblock 183 69 -366 minecraft:birch_log[axis=y]
setblock 186 69 -366 minecraft:birch_log[axis=y]
setblock 187 69 -368 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 69 -369 minecraft:birch_log[axis=y]
setblock 181 69 -369 minecraft:birch_log[axis=y]
setblock 186 69 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 69 -369 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 69 -369 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 69 -369 minecraft:birch_log[axis=y]
setblock 185 69 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 69 -370 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 69 -370 minecraft:birch_log[axis=y]
setblock 188 69 -370 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 69 -370 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 69 -370 minecraft:birch_log[axis=y]
setblock 186 69 -371 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 69 -371 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 69 -371 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 69 -372 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 69 -373 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 69 -374 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 69 -374 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 69 -374 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 69 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 69 -375 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 69 -375 minecraft:birch_log[axis=y]
setblock 180 69 -375 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 69 -375 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 69 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 69 -376 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 69 -376 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 69 -376 minecraft:birch_log[axis=y]
setblock 198 69 -376 minecraft:birch_log[axis=y]
setblock 179 69 -377 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 69 -378 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 69 -379 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 69 -379 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 69 -379 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 69 -379 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 69 -379 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 69 -379 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 69 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 69 -380 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 69 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 192 69 -380 193 69 -380 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 69 -380 minecraft:birch_log[axis=y]
setblock 195 69 -380 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 69 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 69 -381 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 69 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 69 -381 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 69 -381 minecraft:birch_log[axis=y]
fill 193 69 -381 194 69 -381 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 69 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 69 -382 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 136 68 -319 minecraft:grass_block[snowy=false]
fill 137 68 -319 142 68 -319 minecraft:dirt
setblock 136 68 -320 minecraft:grass_block[snowy=false]
fill 137 68 -320 142 68 -320 minecraft:dirt
fill 136 68 -321 137 68 -321 minecraft:grass_block[snowy=false]
fill 138 68 -321 142 68 -321 minecraft:dirt
fill 136 68 -322 137 68 -322 minecraft:grass_block[snowy=false]
fill 138 68 -322 142 68 -322 minecraft:dirt
fill 136 68 -323 138 68 -323 minecraft:grass_block[snowy=false]
fill 139 68 -323 142 68 -323 minecraft:dirt
fill 136 68 -324 137 68 -324 minecraft:grass_block[snowy=false]
fill 138 68 -324 142 68 -324 minecraft:dirt
setblock 136 68 -325 minecraft:dirt
fill 137 68 -325 138 68 -325 minecraft:grass_block[snowy=false]
fill 139 68 -325 142 68 -325 minecraft:dirt
fill 136 68 -326 139 68 -326 minecraft:grass_block[snowy=false]
fill 140 68 -326 167 68 -326 minecraft:dirt
fill 168 68 -326 169 68 -326 minecraft:grass_block[snowy=false]
fill 170 68 -326 172 68 -326 minecraft:dirt
fill 136 68 -327 139 68 -327 minecraft:grass_block[snowy=false]
fill 140 68 -327 167 68 -327 minecraft:dirt
setblock 169 68 -327 minecraft:grass_block[snowy=false]
fill 170 68 -327 172 68 -327 minecraft:dirt
fill 137 68 -328 139 68 -328 minecraft:grass_block[snowy=false]
fill 140 68 -328 167 68 -328 minecraft:dirt
setblock 169 68 -328 minecraft:grass_block[snowy=false]
fill 170 68 -328 171 68 -328 minecraft:dirt
setblock 172 68 -328 alltheores:zinc_ore
fill 137 68 -329 139 68 -329 minecraft:grass_block[snowy=false]
fill 140 68 -329 166 68 -329 minecraft:dirt
setblock 167 68 -329 minecraft:grass_block[snowy=false]
fill 170 68 -329 171 68 -329 minecraft:dirt
setblock 172 68 -329 minecraft:grass_block[snowy=false]
fill 137 68 -330 139 68 -330 minecraft:grass_block[snowy=false]
fill 140 68 -330 166 68 -330 minecraft:dirt
fill 170 68 -330 172 68 -330 minecraft:grass_block[snowy=false]
fill 137 68 -331 139 68 -331 minecraft:grass_block[snowy=false]
fill 140 68 -331 165 68 -331 minecraft:dirt
setblock 166 68 -331 minecraft:grass_block[snowy=false]
setblock 170 68 -331 regions_unexplored:grass_sprouts
setblock 171 68 -331 minecraft:dirt
setblock 172 68 -331 minecraft:grass_block[snowy=false]
fill 137 68 -332 139 68 -332 minecraft:grass_block[snowy=false]
fill 140 68 -332 165 68 -332 minecraft:dirt
setblock 166 68 -332 minecraft:grass_block[snowy=false]
fill 171 68 -332 172 68 -332 minecraft:dirt
fill 137 68 -333 139 68 -333 minecraft:grass_block[snowy=false]
fill 140 68 -333 165 68 -333 minecraft:dirt
setblock 166 68 -333 minecraft:grass_block[snowy=false]
setblock 170 68 -333 minecraft:grass_block[snowy=false]
fill 171 68 -333 172 68 -333 minecraft:dirt
fill 137 68 -334 139 68 -334 minecraft:grass_block[snowy=false]
fill 140 68 -334 166 68 -334 minecraft:dirt
setblock 167 68 -334 minecraft:grass_block[snowy=false]
fill 169 68 -334 170 68 -334 minecraft:grass_block[snowy=false]
fill 171 68 -334 172 68 -334 minecraft:dirt
fill 138 68 -335 139 68 -335 minecraft:grass_block[snowy=false]
fill 140 68 -335 172 68 -335 minecraft:dirt
setblock 173 68 -335 minecraft:grass_block[snowy=false]
setblock 184 68 -335 minecraft:birch_log[axis=y]
fill 138 68 -336 139 68 -336 minecraft:grass_block[snowy=false]
fill 140 68 -336 172 68 -336 minecraft:dirt
setblock 173 68 -336 minecraft:grass_block[snowy=false]
setblock 136 68 -337 minecraft:short_grass
fill 138 68 -337 140 68 -337 minecraft:grass_block[snowy=false]
fill 141 68 -337 169 68 -337 minecraft:dirt
fill 170 68 -337 171 68 -337 minecraft:grass_block[snowy=false]
setblock 180 68 -337 minecraft:birch_log[axis=y]
fill 139 68 -338 141 68 -338 minecraft:grass_block[snowy=false]
fill 142 68 -338 168 68 -338 minecraft:dirt
fill 169 68 -338 170 68 -338 minecraft:grass_block[snowy=false]
fill 140 68 -339 142 68 -339 minecraft:grass_block[snowy=false]
fill 143 68 -339 168 68 -339 minecraft:dirt
setblock 169 68 -339 minecraft:grass_block[snowy=false]
fill 141 68 -340 144 68 -340 minecraft:grass_block[snowy=false]
fill 145 68 -340 168 68 -340 minecraft:dirt
setblock 179 68 -340 minecraft:birch_log[axis=y]
fill 142 68 -341 147 68 -341 minecraft:grass_block[snowy=false]
fill 148 68 -341 163 68 -341 minecraft:dirt
fill 164 68 -341 166 68 -341 minecraft:grass_block[snowy=false]
fill 167 68 -341 168 68 -341 minecraft:dirt
fill 143 68 -342 149 68 -342 minecraft:grass_block[snowy=false]
fill 150 68 -342 160 68 -342 minecraft:dirt
fill 161 68 -342 168 68 -342 minecraft:grass_block[snowy=false]
setblock 192 68 -342 minecraft:birch_log[axis=y]
setblock 142 68 -343 minecraft:tall_grass[half=lower]
setblock 144 68 -343 minecraft:tall_grass[half=lower]
fill 145 68 -343 154 68 -343 minecraft:grass_block[snowy=false]
fill 155 68 -343 158 68 -343 minecraft:dirt
fill 159 68 -343 168 68 -343 minecraft:grass_block[snowy=false]
setblock 178 68 -343 minecraft:birch_log[axis=y]
setblock 196 68 -343 minecraft:short_grass
fill 147 68 -344 155 68 -344 minecraft:grass_block[snowy=false]
setblock 156 68 -344 minecraft:dirt
fill 157 68 -344 168 68 -344 minecraft:grass_block[snowy=false]
setblock 147 68 -345 minecraft:short_grass
fill 149 68 -345 163 68 -345 minecraft:grass_block[snowy=false]
fill 165 68 -345 167 68 -345 minecraft:grass_block[snowy=false]
setblock 168 68 -345 minecraft:dirt
setblock 193 68 -345 minecraft:birch_log[axis=y]
setblock 196 68 -345 regions_unexplored:grass_sprouts
setblock 198 68 -345 minecraft:short_grass
setblock 199 68 -345 regions_unexplored:grass_sprouts
setblock 146 68 -346 regions_unexplored:grass_sprouts
setblock 149 68 -346 regions_unexplored:grass_sprouts
fill 150 68 -346 160 68 -346 minecraft:grass_block[snowy=false]
fill 167 68 -346 168 68 -346 minecraft:grass_block[snowy=false]
setblock 187 68 -346 minecraft:birch_log[axis=y]
setblock 199 68 -346 minecraft:short_grass
setblock 144 68 -347 minecraft:tall_grass[half=upper]
setblock 149 68 -347 regions_unexplored:grass_sprouts
fill 151 68 -347 158 68 -347 minecraft:grass_block[snowy=false]
setblock 162 68 -347 minecraft:short_grass
setblock 167 68 -347 regions_unexplored:grass_sprouts
setblock 168 68 -347 minecraft:grass_block[snowy=false]
setblock 180 68 -347 minecraft:birch_log[axis=y]
setblock 199 68 -347 regions_unexplored:grass_sprouts
setblock 146 68 -348 minecraft:tall_grass[half=upper]
setblock 149 68 -348 minecraft:short_grass
fill 152 68 -348 156 68 -348 minecraft:grass_block[snowy=false]
setblock 165 68 -348 regions_unexplored:grass_sprouts
setblock 195 68 -348 minecraft:short_grass
setblock 149 68 -349 minecraft:short_grass
setblock 151 68 -349 regions_unexplored:grass_sprouts
setblock 152 68 -349 minecraft:birch_log[axis=y]
setblock 186 68 -349 minecraft:birch_log[axis=y]
setblock 160 68 -350 minecraft:grass_block[snowy=false]
setblock 162 68 -350 minecraft:birch_log[axis=y]
setblock 165 68 -350 minecraft:birch_log[axis=y]
setblock 166 68 -350 regions_unexplored:grass_sprouts
setblock 168 68 -350 regions_unexplored:grass_sprouts
setblock 171 68 -350 minecraft:birch_log[axis=y]
setblock 178 68 -350 minecraft:birch_log[axis=y]
setblock 199 68 -350 minecraft:short_grass
setblock 151 68 -351 minecraft:dirt
setblock 155 68 -351 regions_unexplored:grass_sprouts
setblock 160 68 -351 minecraft:birch_log[axis=y]
setblock 176 68 -351 minecraft:birch_log[axis=y]
setblock 199 68 -351 minecraft:birch_log[axis=y]
setblock 187 68 -352 minecraft:birch_log[axis=y]
setblock 194 68 -352 minecraft:birch_log[axis=y]
setblock 151 68 -353 minecraft:birch_log[axis=y]
setblock 155 68 -353 minecraft:birch_log[axis=y]
setblock 180 68 -353 minecraft:birch_log[axis=y]
setblock 199 68 -354 minecraft:birch_log[axis=y]
setblock 182 68 -355 minecraft:birch_log[axis=y]
setblock 179 68 -356 minecraft:birch_log[axis=y]
setblock 198 68 -357 regions_unexplored:grass_sprouts
setblock 154 68 -358 minecraft:birch_log[axis=y]
setblock 174 68 -358 minecraft:birch_log[axis=y]
setblock 192 68 -359 minecraft:birch_log[axis=y]
setblock 188 68 -360 minecraft:birch_log[axis=y]
setblock 196 68 -360 minecraft:short_grass
setblock 195 68 -361 minecraft:birch_log[axis=y]
setblock 164 68 -363 minecraft:birch_log[axis=y]
setblock 172 68 -363 minecraft:birch_log[axis=y]
setblock 190 68 -363 minecraft:birch_log[axis=y]
setblock 197 68 -363 regions_unexplored:grass_sprouts
setblock 198 68 -363 minecraft:short_grass
setblock 175 68 -364 minecraft:birch_log[axis=y]
setblock 195 68 -365 minecraft:birch_log[axis=y]
setblock 199 68 -365 minecraft:short_grass
setblock 170 68 -366 minecraft:birch_log[axis=y]
setblock 183 68 -366 minecraft:birch_log[axis=y]
setblock 186 68 -366 minecraft:birch_log[axis=y]
setblock 174 68 -369 minecraft:birch_log[axis=y]
setblock 181 68 -369 minecraft:birch_log[axis=y]
setblock 199 68 -369 minecraft:birch_log[axis=y]
setblock 187 68 -370 minecraft:birch_log[axis=y]
setblock 191 68 -370 minecraft:birch_log[axis=y]
setblock 179 68 -375 minecraft:birch_log[axis=y]
setblock 188 68 -376 minecraft:birch_log[axis=y]
setblock 198 68 -376 minecraft:birch_log[axis=y]
setblock 182 68 -378 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 68 -379 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 68 -379 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 68 -379 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 68 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 68 -380 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 68 -380 minecraft:birch_log[axis=y]
setblock 183 68 -380 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 68 -380 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 68 -380 minecraft:birch_log[axis=y]
setblock 181 68 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 68 -381 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 68 -381 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 68 -381 productivebees:birch_wood_nest[axis=y,facing=north]
setblock 182 68 -382 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 136 67 -319 142 67 -319 minecraft:dirt
fill 136 67 -320 142 67 -320 minecraft:dirt
fill 136 67 -321 142 67 -321 minecraft:dirt
fill 136 67 -322 142 67 -322 minecraft:dirt
fill 136 67 -323 142 67 -323 minecraft:dirt
fill 136 67 -324 142 67 -324 minecraft:dirt
fill 136 67 -325 142 67 -325 minecraft:dirt
fill 136 67 -326 149 67 -326 minecraft:dirt
setblock 150 67 -326 minecraft:stone
fill 151 67 -326 157 67 -326 alltheores:fluorite_ore
fill 158 67 -326 166 67 -326 minecraft:stone
fill 167 67 -326 172 67 -326 minecraft:dirt
fill 136 67 -327 150 67 -327 minecraft:dirt
setblock 151 67 -327 minecraft:stone
fill 152 67 -327 158 67 -327 alltheores:fluorite_ore
fill 159 67 -327 165 67 -327 minecraft:stone
fill 166 67 -327 167 67 -327 minecraft:dirt
setblock 168 67 -327 minecraft:grass_block[snowy=false]
fill 169 67 -327 171 67 -327 minecraft:dirt
setblock 172 67 -327 minecraft:stone
setblock 136 67 -328 minecraft:grass_block[snowy=false]
fill 137 67 -328 149 67 -328 minecraft:dirt
fill 150 67 -328 151 67 -328 minecraft:stone
setblock 152 67 -328 minecraft:dirt
fill 153 67 -328 157 67 -328 alltheores:fluorite_ore
fill 158 67 -328 165 67 -328 minecraft:stone
fill 166 67 -328 167 67 -328 minecraft:dirt
setblock 168 67 -328 minecraft:grass_block[snowy=false]
fill 169 67 -328 170 67 -328 minecraft:dirt
setblock 171 67 -328 alltheores:zinc_ore
setblock 172 67 -328 minecraft:stone
setblock 136 67 -329 minecraft:grass_block[snowy=false]
fill 137 67 -329 149 67 -329 minecraft:dirt
setblock 150 67 -329 minecraft:stone
setblock 151 67 -329 minecraft:dirt
fill 152 67 -329 164 67 -329 minecraft:stone
fill 165 67 -329 167 67 -329 minecraft:dirt
setblock 169 67 -329 minecraft:grass_block[snowy=false]
fill 170 67 -329 171 67 -329 minecraft:dirt
setblock 172 67 -329 alltheores:zinc_ore
setblock 136 67 -330 minecraft:grass_block[snowy=false]
fill 137 67 -330 150 67 -330 minecraft:dirt
fill 151 67 -330 159 67 -330 minecraft:stone
fill 160 67 -330 161 67 -330 minecraft:dirt
fill 162 67 -330 164 67 -330 minecraft:stone
fill 165 67 -330 166 67 -330 minecraft:dirt
setblock 167 67 -330 minecraft:grass_block[snowy=false]
fill 170 67 -330 171 67 -330 minecraft:dirt
setblock 172 67 -330 minecraft:stone
setblock 136 67 -331 minecraft:grass_block[snowy=false]
fill 137 67 -331 151 67 -331 minecraft:dirt
fill 152 67 -331 156 67 -331 minecraft:stone
fill 157 67 -331 166 67 -331 minecraft:dirt
setblock 170 67 -331 minecraft:grass_block[snowy=false]
setblock 171 67 -331 minecraft:dirt
setblock 172 67 -331 minecraft:stone
setblock 136 67 -332 minecraft:grass_block[snowy=false]
fill 137 67 -332 166 67 -332 minecraft:dirt
setblock 170 67 -332 minecraft:grass_block[snowy=false]
setblock 171 67 -332 minecraft:dirt
setblock 172 67 -332 minecraft:stone
setblock 136 67 -333 minecraft:grass_block[snowy=false]
fill 137 67 -333 166 67 -333 minecraft:dirt
setblock 167 67 -333 minecraft:grass_block[snowy=false]
fill 170 67 -333 172 67 -333 minecraft:dirt
setblock 136 67 -334 minecraft:grass_block[snowy=false]
fill 137 67 -334 167 67 -334 minecraft:dirt
setblock 168 67 -334 minecraft:grass_block[snowy=false]
fill 169 67 -334 171 67 -334 minecraft:dirt
setblock 172 67 -334 minecraft:stone
fill 136 67 -335 137 67 -335 minecraft:grass_block[snowy=false]
fill 138 67 -335 173 67 -335 minecraft:dirt
setblock 174 67 -335 minecraft:grass_block[snowy=false]
setblock 184 67 -335 minecraft:birch_log[axis=y]
fill 136 67 -336 137 67 -336 minecraft:grass_block[snowy=false]
fill 138 67 -336 167 67 -336 minecraft:dirt
fill 168 67 -336 169 67 -336 minecraft:stone
fill 170 67 -336 173 67 -336 minecraft:dirt
fill 136 67 -337 137 67 -337 minecraft:grass_block[snowy=false]
fill 138 67 -337 167 67 -337 minecraft:dirt
setblock 168 67 -337 minecraft:stone
fill 169 67 -337 171 67 -337 minecraft:dirt
setblock 172 67 -337 minecraft:grass_block[snowy=false]
setblock 180 67 -337 minecraft:birch_log[axis=y]
fill 137 67 -338 138 67 -338 minecraft:grass_block[snowy=false]
fill 139 67 -338 170 67 -338 minecraft:dirt
fill 137 67 -339 139 67 -339 minecraft:grass_block[snowy=false]
fill 140 67 -339 169 67 -339 minecraft:dirt
setblock 170 67 -339 minecraft:grass_block[snowy=false]
fill 138 67 -340 140 67 -340 minecraft:grass_block[snowy=false]
fill 141 67 -340 168 67 -340 minecraft:dirt
setblock 169 67 -340 minecraft:grass_block[snowy=false]
setblock 179 67 -340 minecraft:birch_log[axis=y]
setblock 192 67 -340 regions_unexplored:grass_sprouts
fill 197 67 -340 199 67 -340 minecraft:grass_block[snowy=false]
fill 138 67 -341 141 67 -341 minecraft:grass_block[snowy=false]
fill 142 67 -341 168 67 -341 minecraft:dirt
setblock 169 67 -341 minecraft:grass_block[snowy=false]
setblock 194 67 -341 minecraft:short_grass
setblock 195 67 -341 regions_unexplored:grass_sprouts
fill 197 67 -341 199 67 -341 minecraft:grass_block[snowy=false]
setblock 137 67 -342 regions_unexplored:grass_sprouts
fill 139 67 -342 142 67 -342 minecraft:grass_block[snowy=false]
fill 143 67 -342 168 67 -342 minecraft:dirt
setblock 169 67 -342 minecraft:grass_block[snowy=false]
setblock 192 67 -342 minecraft:birch_log[axis=y]
setblock 193 67 -342 minecraft:short_grass
setblock 194 67 -342 regions_unexplored:grass_sprouts
fill 196 67 -342 199 67 -342 minecraft:grass_block[snowy=false]
setblock 138 67 -343 regions_unexplored:grass_sprouts
setblock 139 67 -343 minecraft:short_grass
fill 140 67 -343 143 67 -343 minecraft:grass_block[snowy=false]
setblock 144 67 -343 regions_unexplored:peat_mud
fill 145 67 -343 168 67 -343 minecraft:dirt
setblock 178 67 -343 minecraft:birch_log[axis=y]
setblock 194 67 -343 minecraft:short_grass
fill 196 67 -343 199 67 -343 minecraft:grass_block[snowy=false]
setblock 136 67 -344 minecraft:tall_grass[half=upper]
setblock 141 67 -344 minecraft:grass_block[snowy=false]
fill 142 67 -344 145 67 -344 regions_unexplored:peat_mud
setblock 146 67 -344 minecraft:grass_block[snowy=false]
fill 147 67 -344 168 67 -344 minecraft:dirt
setblock 192 67 -344 minecraft:short_grass
fill 196 67 -344 199 67 -344 minecraft:grass_block[snowy=false]
setblock 139 67 -345 minecraft:short_grass
setblock 144 67 -345 regions_unexplored:peat_mud
fill 145 67 -345 148 67 -345 minecraft:grass_block[snowy=false]
fill 149 67 -345 163 67 -345 minecraft:dirt
setblock 164 67 -345 minecraft:grass_block[snowy=false]
fill 165 67 -345 168 67 -345 minecraft:dirt
setblock 193 67 -345 minecraft:birch_log[axis=y]
setblock 194 67 -345 minecraft:short_grass
fill 196 67 -345 199 67 -345 minecraft:grass_block[snowy=false]
fill 146 67 -346 149 67 -346 minecraft:grass_block[snowy=false]
fill 150 67 -346 160 67 -346 minecraft:dirt
fill 161 67 -346 166 67 -346 minecraft:grass_block[snowy=false]
fill 167 67 -346 168 67 -346 minecraft:dirt
setblock 187 67 -346 minecraft:birch_log[axis=y]
fill 196 67 -346 199 67 -346 minecraft:grass_block[snowy=false]
setblock 144 67 -347 minecraft:tall_grass[half=lower]
fill 147 67 -347 150 67 -347 minecraft:grass_block[snowy=false]
fill 151 67 -347 158 67 -347 minecraft:dirt
fill 159 67 -347 167 67 -347 minecraft:grass_block[snowy=false]
setblock 168 67 -347 minecraft:dirt
setblock 180 67 -347 minecraft:birch_log[axis=y]
setblock 195 67 -347 regions_unexplored:grass_sprouts
fill 196 67 -347 199 67 -347 minecraft:grass_block[snowy=false]
setblock 143 67 -348 minecraft:tall_grass[half=upper]
setblock 146 67 -348 minecraft:tall_grass[half=lower]
fill 148 67 -348 151 67 -348 minecraft:grass_block[snowy=false]
fill 152 67 -348 156 67 -348 minecraft:dirt
fill 157 67 -348 168 67 -348 minecraft:grass_block[snowy=false]
setblock 191 67 -348 regions_unexplored:grass_sprouts
fill 195 67 -348 199 67 -348 minecraft:grass_block[snowy=false]
setblock 143 67 -349 minecraft:tall_grass[half=upper]
setblock 148 67 -349 regions_unexplored:peat_mud
fill 149 67 -349 151 67 -349 minecraft:grass_block[snowy=false]
setblock 152 67 -349 minecraft:dirt
fill 153 67 -349 163 67 -349 minecraft:grass_block[snowy=false]
fill 165 67 -349 168 67 -349 minecraft:grass_block[snowy=false]
setblock 186 67 -349 minecraft:birch_log[axis=y]
fill 196 67 -349 199 67 -349 minecraft:grass_block[snowy=false]
fill 149 67 -350 159 67 -350 minecraft:grass_block[snowy=false]
setblock 160 67 -350 minecraft:dirt
setblock 161 67 -350 minecraft:grass_block[snowy=false]
setblock 162 67 -350 minecraft:dirt
setblock 165 67 -350 minecraft:dirt
fill 166 67 -350 168 67 -350 minecraft:grass_block[snowy=false]
setblock 171 67 -350 minecraft:birch_log[axis=y]
setblock 178 67 -350 minecraft:birch_log[axis=y]
setblock 193 67 -350 regions_unexplored:grass_sprouts
setblock 194 67 -350 minecraft:short_grass
fill 196 67 -350 199 67 -350 minecraft:grass_block[snowy=false]
setblock 149 67 -351 regions_unexplored:grass_sprouts
setblock 150 67 -351 minecraft:grass_block[snowy=false]
setblock 151 67 -351 minecraft:dirt
fill 152 67 -351 159 67 -351 minecraft:grass_block[snowy=false]
setblock 160 67 -351 minecraft:birch_log[axis=y]
setblock 161 67 -351 regions_unexplored:grass_sprouts
setblock 163 67 -351 regions_unexplored:grass_sprouts
fill 167 67 -351 168 67 -351 minecraft:grass_block[snowy=false]
setblock 176 67 -351 minecraft:birch_log[axis=y]
fill 196 67 -351 198 67 -351 minecraft:grass_block[snowy=false]
setblock 199 67 -351 minecraft:dirt
fill 151 67 -352 157 67 -352 minecraft:grass_block[snowy=false]
setblock 167 67 -352 regions_unexplored:grass_sprouts
setblock 187 67 -352 minecraft:birch_log[axis=y]
setblock 194 67 -352 minecraft:birch_log[axis=y]
fill 196 67 -352 199 67 -352 minecraft:grass_block[snowy=false]
setblock 151 67 -353 minecraft:birch_log[axis=y]
fill 152 67 -353 154 67 -353 minecraft:grass_block[snowy=false]
setblock 155 67 -353 minecraft:dirt
setblock 156 67 -353 minecraft:grass_block[snowy=false]
setblock 167 67 -353 regions_unexplored:grass_sprouts
setblock 180 67 -353 minecraft:birch_log[axis=y]
fill 196 67 -353 199 67 -353 minecraft:grass_block[snowy=false]
setblock 160 67 -354 regions_unexplored:grass_sprouts
setblock 162 67 -354 minecraft:short_grass
setblock 164 67 -354 regions_unexplored:grass_sprouts
setblock 168 67 -354 minecraft:short_grass
fill 196 67 -354 198 67 -354 minecraft:grass_block[snowy=false]
setblock 199 67 -354 minecraft:dirt
setblock 158 67 -355 minecraft:short_grass
fill 162 67 -355 163 67 -355 regions_unexplored:grass_sprouts
setblock 166 67 -355 minecraft:short_grass
setblock 182 67 -355 minecraft:birch_log[axis=y]
fill 196 67 -355 199 67 -355 minecraft:grass_block[snowy=false]
setblock 157 67 -356 minecraft:short_grass
setblock 165 67 -356 regions_unexplored:grass_sprouts
setblock 179 67 -356 minecraft:birch_log[axis=y]
fill 196 67 -356 199 67 -356 minecraft:grass_block[snowy=false]
fill 196 67 -357 199 67 -357 minecraft:grass_block[snowy=false]
setblock 154 67 -358 minecraft:birch_log[axis=y]
setblock 174 67 -358 minecraft:birch_log[axis=y]
fill 196 67 -358 199 67 -358 minecraft:grass_block[snowy=false]
setblock 192 67 -359 minecraft:birch_log[axis=y]
fill 196 67 -359 199 67 -359 minecraft:grass_block[snowy=false]
setblock 188 67 -360 minecraft:birch_log[axis=y]
fill 196 67 -360 199 67 -360 minecraft:grass_block[snowy=false]
setblock 195 67 -361 minecraft:birch_log[axis=y]
fill 196 67 -361 199 67 -361 minecraft:grass_block[snowy=false]
setblock 194 67 -362 regions_unexplored:grass_sprouts
setblock 195 67 -362 minecraft:short_grass
fill 197 67 -362 199 67 -362 minecraft:grass_block[snowy=false]
setblock 164 67 -363 minecraft:birch_log[axis=y]
setblock 172 67 -363 minecraft:birch_log[axis=y]
setblock 190 67 -363 minecraft:birch_log[axis=y]
fill 197 67 -363 199 67 -363 minecraft:grass_block[snowy=false]
setblock 175 67 -364 minecraft:birch_log[axis=y]
setblock 199 67 -364 minecraft:grass_block[snowy=false]
setblock 195 67 -365 minecraft:birch_log[axis=y]
setblock 199 67 -365 minecraft:grass_block[snowy=false]
setblock 170 67 -366 minecraft:birch_log[axis=y]
setblock 183 67 -366 minecraft:birch_log[axis=y]
setblock 186 67 -366 minecraft:birch_log[axis=y]
setblock 198 67 -366 regions_unexplored:grass_sprouts
setblock 199 67 -367 regions_unexplored:grass_sprouts
setblock 198 67 -368 minecraft:short_grass
setblock 174 67 -369 minecraft:birch_log[axis=y]
setblock 181 67 -369 minecraft:birch_log[axis=y]
setblock 199 67 -369 minecraft:birch_log[axis=y]
setblock 187 67 -370 minecraft:birch_log[axis=y]
setblock 191 67 -370 minecraft:birch_log[axis=y]
setblock 197 67 -374 regions_unexplored:birch_shrub[half=upper]
setblock 179 67 -375 minecraft:birch_log[axis=y]
setblock 188 67 -376 minecraft:birch_log[axis=y]
setblock 198 67 -376 minecraft:birch_log[axis=y]
setblock 182 67 -380 minecraft:birch_log[axis=y]
setblock 194 67 -380 minecraft:birch_log[axis=y]
setblock 192 67 -381 minecraft:birch_log[axis=y]
fill 136 66 -319 142 66 -319 minecraft:dirt
fill 136 66 -320 142 66 -320 minecraft:dirt
fill 136 66 -321 142 66 -321 minecraft:dirt
fill 136 66 -322 142 66 -322 minecraft:dirt
fill 136 66 -323 142 66 -323 minecraft:dirt
fill 136 66 -324 142 66 -324 minecraft:dirt
fill 136 66 -325 142 66 -325 minecraft:dirt
fill 136 66 -326 147 66 -326 minecraft:dirt
fill 148 66 -326 152 66 -326 minecraft:stone
fill 153 66 -326 157 66 -326 alltheores:fluorite_ore
fill 158 66 -326 167 66 -326 minecraft:stone
fill 168 66 -326 172 66 -326 minecraft:dirt
fill 136 66 -327 147 66 -327 minecraft:dirt
fill 148 66 -327 152 66 -327 minecraft:stone
fill 153 66 -327 158 66 -327 alltheores:fluorite_ore
fill 159 66 -327 167 66 -327 minecraft:stone
fill 168 66 -327 170 66 -327 minecraft:dirt
setblock 171 66 -327 minecraft:copper_ore
setblock 172 66 -327 minecraft:stone
fill 136 66 -328 147 66 -328 minecraft:dirt
fill 148 66 -328 154 66 -328 minecraft:stone
fill 155 66 -328 157 66 -328 alltheores:fluorite_ore
fill 158 66 -328 166 66 -328 minecraft:stone
fill 167 66 -328 170 66 -328 minecraft:dirt
fill 171 66 -328 172 66 -328 minecraft:stone
fill 136 66 -329 145 66 -329 minecraft:dirt
setblock 146 66 -329 minecraft:stone
fill 147 66 -329 149 66 -329 minecraft:dirt
fill 150 66 -329 165 66 -329 minecraft:stone
fill 166 66 -329 167 66 -329 minecraft:dirt
setblock 168 66 -329 minecraft:grass_block[snowy=false]
fill 169 66 -329 170 66 -329 minecraft:dirt
fill 171 66 -329 172 66 -329 minecraft:stone
fill 136 66 -330 148 66 -330 minecraft:dirt
fill 149 66 -330 166 66 -330 minecraft:stone
setblock 167 66 -330 minecraft:dirt
setblock 169 66 -330 minecraft:grass_block[snowy=false]
setblock 170 66 -330 minecraft:dirt
fill 171 66 -330 172 66 -330 minecraft:stone
fill 136 66 -331 148 66 -331 minecraft:dirt
fill 149 66 -331 157 66 -331 minecraft:stone
setblock 158 66 -331 minecraft:copper_ore
fill 159 66 -331 164 66 -331 minecraft:stone
fill 165 66 -331 166 66 -331 minecraft:dirt
setblock 167 66 -331 minecraft:grass_block[snowy=false]
setblock 169 66 -331 silentgear:wild_fluffy_plant
setblock 170 66 -331 minecraft:dirt
fill 171 66 -331 172 66 -331 minecraft:stone
fill 136 66 -332 144 66 -332 minecraft:dirt
setblock 145 66 -332 minecraft:copper_ore
setblock 146 66 -332 minecraft:dirt
fill 147 66 -332 150 66 -332 minecraft:stone
setblock 151 66 -332 minecraft:dirt
fill 152 66 -332 164 66 -332 minecraft:stone
fill 165 66 -332 166 66 -332 minecraft:dirt
setblock 167 66 -332 minecraft:grass_block[snowy=false]
fill 170 66 -332 171 66 -332 minecraft:dirt
setblock 172 66 -332 minecraft:stone
fill 136 66 -333 144 66 -333 minecraft:dirt
fill 145 66 -333 150 66 -333 minecraft:stone
setblock 151 66 -333 minecraft:dirt
fill 152 66 -333 164 66 -333 minecraft:stone
fill 165 66 -333 167 66 -333 minecraft:dirt
setblock 169 66 -333 minecraft:grass_block[snowy=false]
setblock 170 66 -333 minecraft:dirt
fill 171 66 -333 172 66 -333 minecraft:stone
fill 136 66 -334 144 66 -334 minecraft:dirt
fill 145 66 -334 146 66 -334 minecraft:stone
setblock 147 66 -334 minecraft:dirt
fill 148 66 -334 164 66 -334 minecraft:stone
fill 165 66 -334 171 66 -334 minecraft:dirt
setblock 172 66 -334 minecraft:stone
fill 136 66 -335 144 66 -335 minecraft:dirt
fill 145 66 -335 150 66 -335 minecraft:stone
setblock 151 66 -335 minecraft:dirt
fill 152 66 -335 157 66 -335 minecraft:stone
fill 158 66 -335 159 66 -335 minecraft:coal_ore
fill 160 66 -335 166 66 -335 minecraft:stone
setblock 167 66 -335 minecraft:dirt
fill 168 66 -335 172 66 -335 minecraft:stone
fill 173 66 -335 174 66 -335 minecraft:dirt
setblock 184 66 -335 minecraft:birch_log[axis=y]
setblock 136 66 -336 regions_unexplored:peat_mud
fill 137 66 -336 143 66 -336 minecraft:dirt
setblock 144 66 -336 minecraft:stone
fill 145 66 -336 146 66 -336 minecraft:dirt
setblock 147 66 -336 minecraft:stone
setblock 148 66 -336 minecraft:dirt
setblock 149 66 -336 minecraft:stone
fill 150 66 -336 151 66 -336 minecraft:dirt
fill 152 66 -336 157 66 -336 minecraft:stone
fill 158 66 -336 160 66 -336 minecraft:coal_ore
fill 161 66 -336 172 66 -336 minecraft:stone
setblock 173 66 -336 minecraft:dirt
setblock 174 66 -336 minecraft:grass_block[snowy=false]
setblock 188 66 -336 regions_unexplored:grass_sprouts
setblock 136 66 -337 regions_unexplored:peat_mud
fill 137 66 -337 146 66 -337 minecraft:dirt
fill 147 66 -337 148 66 -337 minecraft:coal_ore
setblock 149 66 -337 minecraft:dirt
fill 150 66 -337 158 66 -337 minecraft:stone
setblock 159 66 -337 minecraft:coal_ore
fill 160 66 -337 165 66 -337 minecraft:dirt
fill 166 66 -337 169 66 -337 minecraft:stone
fill 170 66 -337 172 66 -337 minecraft:dirt
setblock 173 66 -337 minecraft:grass_block[snowy=false]
setblock 180 66 -337 minecraft:birch_log[axis=y]
setblock 136 66 -338 minecraft:grass_block[snowy=false]
fill 137 66 -338 152 66 -338 minecraft:dirt
fill 153 66 -338 157 66 -338 minecraft:stone
fill 158 66 -338 165 66 -338 minecraft:dirt
fill 166 66 -338 168 66 -338 minecraft:stone
fill 169 66 -338 170 66 -338 minecraft:dirt
setblock 171 66 -338 minecraft:grass_block[snowy=false]
setblock 189 66 -338 regions_unexplored:grass_sprouts
setblock 190 66 -338 minecraft:short_grass
setblock 136 66 -339 minecraft:grass_block[snowy=false]
fill 137 66 -339 165 66 -339 minecraft:dirt
fill 166 66 -339 168 66 -339 minecraft:stone
fill 169 66 -339 170 66 -339 minecraft:dirt
setblock 188 66 -339 minecraft:short_grass
setblock 190 66 -339 minecraft:short_grass
fill 136 66 -340 137 66 -340 minecraft:grass_block[snowy=false]
fill 138 66 -340 165 66 -340 minecraft:dirt
fill 166 66 -340 168 66 -340 minecraft:stone
setblock 169 66 -340 minecraft:dirt
setblock 170 66 -340 minecraft:grass_block[snowy=false]
setblock 179 66 -340 minecraft:birch_log[axis=y]
setblock 187 66 -340 minecraft:short_grass
fill 192 66 -340 196 66 -340 minecraft:grass_block[snowy=false]
fill 197 66 -340 199 66 -340 minecraft:dirt
fill 136 66 -341 137 66 -341 regions_unexplored:peat_mud
fill 138 66 -341 166 66 -341 minecraft:dirt
fill 167 66 -341 168 66 -341 minecraft:stone
setblock 169 66 -341 minecraft:dirt
fill 192 66 -341 196 66 -341 minecraft:grass_block[snowy=false]
fill 197 66 -341 199 66 -341 minecraft:dirt
fill 136 66 -342 137 66 -342 regions_unexplored:peat_mud
setblock 138 66 -342 minecraft:grass_block[snowy=false]
fill 139 66 -342 169 66 -342 minecraft:dirt
setblock 192 66 -342 minecraft:dirt
fill 193 66 -342 195 66 -342 minecraft:grass_block[snowy=false]
fill 196 66 -342 199 66 -342 minecraft:dirt
setblock 136 66 -343 regions_unexplored:grass_sprouts
setblock 137 66 -343 regions_unexplored:peat_mud
fill 138 66 -343 139 66 -343 minecraft:grass_block[snowy=false]
fill 140 66 -343 168 66 -343 minecraft:dirt
setblock 169 66 -343 minecraft:grass_block[snowy=false]
setblock 178 66 -343 minecraft:birch_log[axis=y]
setblock 190 66 -343 minecraft:short_grass
setblock 191 66 -343 regions_unexplored:grass_sprouts
fill 192 66 -343 195 66 -343 minecraft:grass_block[snowy=false]
fill 196 66 -343 199 66 -343 minecraft:dirt
setblock 136 66 -344 minecraft:tall_grass[half=lower]
setblock 138 66 -344 regions_unexplored:peat_mud
fill 139 66 -344 140 66 -344 minecraft:grass_block[snowy=false]
fill 141 66 -344 142 66 -344 minecraft:dirt
setblock 143 66 -344 regions_unexplored:peat_mud
fill 144 66 -344 168 66 -344 minecraft:dirt
setblock 169 66 -344 minecraft:grass_block[snowy=false]
fill 192 66 -344 195 66 -344 minecraft:grass_block[snowy=false]
fill 196 66 -344 199 66 -344 minecraft:dirt
setblock 136 66 -345 minecraft:short_grass
fill 139 66 -345 142 66 -345 regions_unexplored:peat_mud
setblock 143 66 -345 minecraft:grass_block[snowy=false]
fill 144 66 -345 168 66 -345 minecraft:dirt
setblock 169 66 -345 minecraft:grass_block[snowy=false]
fill 191 66 -345 192 66 -345 minecraft:grass_block[snowy=false]
setblock 193 66 -345 minecraft:dirt
fill 194 66 -345 195 66 -345 minecraft:grass_block[snowy=false]
fill 196 66 -345 199 66 -345 minecraft:dirt
fill 141 66 -346 143 66 -346 regions_unexplored:peat_mud
fill 144 66 -346 145 66 -346 minecraft:grass_block[snowy=false]
fill 146 66 -346 168 66 -346 minecraft:dirt
setblock 169 66 -346 minecraft:grass_block[snowy=false]
setblock 187 66 -346 minecraft:birch_log[axis=y]
fill 191 66 -346 195 66 -346 minecraft:grass_block[snowy=false]
fill 196 66 -346 199 66 -346 minecraft:dirt
fill 144 66 -347 146 66 -347 minecraft:grass_block[snowy=false]
fill 147 66 -347 168 66 -347 minecraft:dirt
setblock 169 66 -347 minecraft:grass_block[snowy=false]
setblock 180 66 -347 minecraft:birch_log[axis=y]
fill 191 66 -347 195 66 -347 minecraft:grass_block[snowy=false]
fill 196 66 -347 199 66 -347 minecraft:dirt
setblock 143 66 -348 minecraft:tall_grass[half=lower]
fill 145 66 -348 147 66 -348 minecraft:grass_block[snowy=false]
fill 148 66 -348 168 66 -348 minecraft:dirt
setblock 169 66 -348 minecraft:grass_block[snowy=false]
fill 191 66 -348 194 66 -348 minecraft:grass_block[snowy=false]
fill 195 66 -348 199 66 -348 minecraft:dirt
setblock 142 66 -349 regions_unexplored:grass_sprouts
setblock 143 66 -349 minecraft:tall_grass[half=lower]
fill 146 66 -349 148 66 -349 regions_unexplored:peat_mud
fill 149 66 -349 163 66 -349 minecraft:dirt
setblock 164 66 -349 minecraft:grass_block[snowy=false]
fill 165 66 -349 168 66 -349 minecraft:dirt
setblock 169 66 -349 minecraft:grass_block[snowy=false]
setblock 186 66 -349 minecraft:birch_log[axis=y]
fill 191 66 -349 195 66 -349 minecraft:grass_block[snowy=false]
fill 196 66 -349 199 66 -349 minecraft:dirt
setblock 139 66 -350 minecraft:tall_grass[half=upper]
setblock 141 66 -350 minecraft:tall_grass[half=upper]
setblock 143 66 -350 regions_unexplored:grass_sprouts
fill 146 66 -350 148 66 -350 regions_unexplored:peat_mud
fill 149 66 -350 162 66 -350 minecraft:dirt
fill 163 66 -350 164 66 -350 minecraft:grass_block[snowy=false]
fill 165 66 -350 168 66 -350 minecraft:dirt
setblock 169 66 -350 minecraft:grass_block[snowy=false]
setblock 171 66 -350 minecraft:birch_log[axis=y]
setblock 178 66 -350 minecraft:birch_log[axis=y]
fill 191 66 -350 195 66 -350 minecraft:grass_block[snowy=false]
fill 196 66 -350 199 66 -350 minecraft:dirt
fill 147 66 -351 148 66 -351 regions_unexplored:peat_mud
setblock 149 66 -351 minecraft:grass_block[snowy=false]
fill 150 66 -351 160 66 -351 minecraft:dirt
fill 161 66 -351 166 66 -351 minecraft:grass_block[snowy=false]
fill 167 66 -351 168 66 -351 minecraft:dirt
setblock 176 66 -351 minecraft:birch_log[axis=y]
fill 192 66 -351 195 66 -351 minecraft:grass_block[snowy=false]
fill 196 66 -351 199 66 -351 minecraft:dirt
fill 147 66 -352 148 66 -352 regions_unexplored:peat_mud
fill 149 66 -352 150 66 -352 minecraft:grass_block[snowy=false]
fill 151 66 -352 157 66 -352 minecraft:dirt
fill 158 66 -352 168 66 -352 minecraft:grass_block[snowy=false]
setblock 187 66 -352 minecraft:birch_log[axis=y]
fill 192 66 -352 193 66 -352 minecraft:grass_block[snowy=false]
setblock 194 66 -352 minecraft:dirt
setblock 195 66 -352 minecraft:grass_block[snowy=false]
fill 196 66 -352 199 66 -352 minecraft:dirt
setblock 146 66 -353 regions_unexplored:grass_sprouts
setblock 148 66 -353 regions_unexplored:peat_mud
fill 149 66 -353 150 66 -353 minecraft:grass_block[snowy=false]
fill 151 66 -353 156 66 -353 minecraft:dirt
fill 157 66 -353 168 66 -353 minecraft:grass_block[snowy=false]
setblock 180 66 -353 minecraft:birch_log[axis=y]
fill 192 66 -353 195 66 -353 minecraft:grass_block[snowy=false]
fill 196 66 -353 199 66 -353 minecraft:dirt
setblock 148 66 -354 minecraft:short_grass
fill 150 66 -354 168 66 -354 minecraft:grass_block[snowy=false]
fill 192 66 -354 195 66 -354 minecraft:grass_block[snowy=false]
fill 196 66 -354 199 66 -354 minecraft:dirt
fill 151 66 -355 168 66 -355 minecraft:grass_block[snowy=false]
setblock 182 66 -355 minecraft:birch_log[axis=y]
fill 192 66 -355 195 66 -355 minecraft:grass_block[snowy=false]
fill 196 66 -355 199 66 -355 minecraft:dirt
fill 153 66 -356 159 66 -356 minecraft:grass_block[snowy=false]
setblock 160 66 -356 minecraft:short_grass
setblock 163 66 -356 regions_unexplored:grass_sprouts
fill 165 66 -356 168 66 -356 minecraft:grass_block[snowy=false]
setblock 179 66 -356 minecraft:birch_log[axis=y]
fill 193 66 -356 195 66 -356 minecraft:grass_block[snowy=false]
fill 196 66 -356 199 66 -356 minecraft:dirt
setblock 152 66 -357 regions_unexplored:grass_sprouts
setblock 154 66 -357 regions_unexplored:grass_sprouts
fill 156 66 -357 157 66 -357 regions_unexplored:grass_sprouts
setblock 160 66 -357 minecraft:short_grass
setblock 165 66 -357 regions_unexplored:grass_sprouts
setblock 168 66 -357 minecraft:grass_block[snowy=false]
fill 193 66 -357 195 66 -357 minecraft:grass_block[snowy=false]
fill 196 66 -357 199 66 -357 minecraft:dirt
setblock 154 66 -358 minecraft:birch_log[axis=y]
setblock 160 66 -358 regions_unexplored:grass_sprouts
setblock 166 66 -358 regions_unexplored:grass_sprouts
setblock 167 66 -358 minecraft:short_grass
setblock 174 66 -358 minecraft:birch_log[axis=y]
fill 193 66 -358 195 66 -358 minecraft:grass_block[snowy=false]
fill 196 66 -358 199 66 -358 minecraft:dirt
fill 159 66 -359 160 66 -359 minecraft:short_grass
fill 161 66 -359 163 66 -359 regions_unexplored:grass_sprouts
setblock 165 66 -359 regions_unexplored:grass_sprouts
setblock 192 66 -359 minecraft:birch_log[axis=y]
fill 193 66 -359 195 66 -359 minecraft:grass_block[snowy=false]
fill 196 66 -359 199 66 -359 minecraft:dirt
setblock 152 66 -360 minecraft:tall_grass[half=upper]
fill 160 66 -360 161 66 -360 minecraft:short_grass
setblock 163 66 -360 regions_unexplored:grass_sprouts
setblock 165 66 -360 regions_unexplored:grass_sprouts
setblock 172 66 -360 minecraft:short_grass
setblock 188 66 -360 minecraft:birch_log[axis=y]
fill 193 66 -360 195 66 -360 minecraft:grass_block[snowy=false]
fill 196 66 -360 199 66 -360 minecraft:dirt
setblock 155 66 -361 minecraft:tall_grass[half=upper]
setblock 169 66 -361 minecraft:short_grass
setblock 191 66 -361 regions_unexplored:grass_sprouts
fill 193 66 -361 194 66 -361 minecraft:grass_block[snowy=false]
fill 195 66 -361 199 66 -361 minecraft:dirt
fill 193 66 -362 196 66 -362 minecraft:grass_block[snowy=false]
fill 197 66 -362 199 66 -362 minecraft:dirt
setblock 164 66 -363 minecraft:birch_log[axis=y]
setblock 172 66 -363 minecraft:birch_log[axis=y]
setblock 190 66 -363 minecraft:birch_log[axis=y]
fill 193 66 -363 196 66 -363 minecraft:grass_block[snowy=false]
fill 197 66 -363 199 66 -363 minecraft:dirt
setblock 175 66 -364 minecraft:birch_log[axis=y]
fill 193 66 -364 198 66 -364 minecraft:grass_block[snowy=false]
setblock 199 66 -364 minecraft:dirt
setblock 194 66 -365 minecraft:grass_block[snowy=false]
setblock 195 66 -365 minecraft:dirt
fill 196 66 -365 198 66 -365 minecraft:grass_block[snowy=false]
setblock 199 66 -365 minecraft:dirt
setblock 170 66 -366 minecraft:birch_log[axis=y]
setblock 183 66 -366 minecraft:birch_log[axis=y]
setblock 186 66 -366 minecraft:birch_log[axis=y]
setblock 191 66 -366 minecraft:short_grass
fill 194 66 -366 199 66 -366 minecraft:grass_block[snowy=false]
fill 195 66 -367 199 66 -367 minecraft:grass_block[snowy=false]
fill 195 66 -368 199 66 -368 minecraft:grass_block[snowy=false]
setblock 174 66 -369 minecraft:birch_log[axis=y]
setblock 181 66 -369 minecraft:birch_log[axis=y]
fill 196 66 -369 198 66 -369 minecraft:grass_block[snowy=false]
setblock 199 66 -369 minecraft:dirt
setblock 187 66 -370 minecraft:birch_log[axis=y]
setblock 191 66 -370 minecraft:birch_log[axis=y]
fill 197 66 -370 199 66 -370 minecraft:grass_block[snowy=false]
fill 198 66 -371 199 66 -371 minecraft:grass_block[snowy=false]
setblock 199 66 -372 minecraft:grass_block[snowy=false]
setblock 197 66 -374 regions_unexplored:birch_shrub[half=lower]
setblock 179 66 -375 minecraft:birch_log[axis=y]
setblock 188 66 -376 minecraft:birch_log[axis=y]
setblock 198 66 -376 minecraft:birch_log[axis=y]
setblock 182 66 -380 minecraft:birch_log[axis=y]
setblock 194 66 -380 minecraft:birch_log[axis=y]
setblock 192 66 -381 minecraft:birch_log[axis=y]
fill 136 65 -319 139 65 -319 minecraft:dirt
setblock 140 65 -319 minecraft:coal_ore
fill 141 65 -319 143 65 -319 minecraft:stone
fill 144 65 -319 146 65 -319 minecraft:andesite
fill 147 65 -319 149 65 -319 alltheores:zinc_ore
fill 150 65 -319 163 65 -319 minecraft:stone
fill 164 65 -319 171 65 -319 minecraft:dirt
setblock 172 65 -319 minecraft:air
setblock 173 65 -319 minecraft:dirt
fill 174 65 -319 185 65 -319 minecraft:stone
setblock 192 65 -319 minecraft:air
fill 136 65 -320 140 65 -320 minecraft:dirt
fill 141 65 -320 147 65 -320 minecraft:stone
fill 148 65 -320 150 65 -320 alltheores:zinc_ore
fill 151 65 -320 164 65 -320 minecraft:stone
fill 165 65 -320 170 65 -320 minecraft:dirt
fill 171 65 -320 172 65 -320 minecraft:air
fill 173 65 -320 185 65 -320 minecraft:stone
setblock 192 65 -320 minecraft:air
fill 136 65 -321 141 65 -321 minecraft:dirt
fill 142 65 -321 148 65 -321 minecraft:stone
fill 149 65 -321 150 65 -321 alltheores:zinc_ore
fill 151 65 -321 170 65 -321 minecraft:stone
fill 171 65 -321 172 65 -321 minecraft:air
fill 173 65 -321 184 65 -321 minecraft:stone
fill 136 65 -322 141 65 -322 minecraft:dirt
fill 142 65 -322 157 65 -322 minecraft:stone
fill 160 65 -322 169 65 -322 minecraft:stone
fill 170 65 -322 172 65 -322 minecraft:air
fill 174 65 -322 182 65 -322 minecraft:stone
fill 136 65 -323 142 65 -323 minecraft:dirt
fill 143 65 -323 150 65 -323 minecraft:stone
setblock 151 65 -323 minecraft:air
setblock 152 65 -323 minecraft:stone
fill 160 65 -323 169 65 -323 minecraft:stone
fill 170 65 -323 172 65 -323 minecraft:air
fill 175 65 -323 181 65 -323 minecraft:stone
fill 136 65 -324 142 65 -324 minecraft:dirt
fill 143 65 -324 151 65 -324 minecraft:stone
fill 159 65 -324 167 65 -324 minecraft:stone
fill 168 65 -324 172 65 -324 minecraft:air
fill 175 65 -324 181 65 -324 minecraft:stone
fill 136 65 -325 143 65 -325 minecraft:dirt
fill 144 65 -325 151 65 -325 minecraft:stone
fill 152 65 -325 156 65 -325 minecraft:air
fill 158 65 -325 168 65 -325 minecraft:stone
fill 175 65 -325 176 65 -325 minecraft:stone
setblock 177 65 -325 minecraft:dirt
fill 178 65 -325 180 65 -325 minecraft:stone
fill 136 65 -326 143 65 -326 minecraft:dirt
fill 144 65 -326 155 65 -326 minecraft:stone
setblock 156 65 -326 minecraft:air
fill 157 65 -326 167 65 -326 minecraft:stone
fill 168 65 -326 169 65 -326 minecraft:dirt
setblock 170 65 -326 minecraft:stone
setblock 171 65 -326 minecraft:copper_ore
fill 172 65 -326 181 65 -326 minecraft:stone
fill 187 65 -326 188 65 -326 minecraft:air
fill 136 65 -327 143 65 -327 minecraft:dirt
fill 144 65 -327 167 65 -327 minecraft:stone
fill 168 65 -327 169 65 -327 minecraft:dirt
setblock 170 65 -327 minecraft:stone
setblock 171 65 -327 minecraft:copper_ore
fill 172 65 -327 180 65 -327 minecraft:stone
setblock 187 65 -327 minecraft:air
fill 136 65 -328 144 65 -328 minecraft:dirt
fill 145 65 -328 167 65 -328 minecraft:stone
setblock 168 65 -328 minecraft:dirt
fill 169 65 -328 181 65 -328 minecraft:stone
fill 186 65 -328 187 65 -328 minecraft:air
fill 136 65 -329 143 65 -329 minecraft:dirt
fill 144 65 -329 166 65 -329 minecraft:stone
fill 167 65 -329 169 65 -329 minecraft:dirt
fill 170 65 -329 173 65 -329 minecraft:stone
fill 174 65 -329 176 65 -329 alltheores:tin_ore
fill 177 65 -329 180 65 -329 minecraft:stone
fill 186 65 -329 187 65 -329 minecraft:air
fill 136 65 -330 142 65 -330 minecraft:dirt
fill 143 65 -330 166 65 -330 minecraft:stone
setblock 167 65 -330 minecraft:dirt
fill 169 65 -330 170 65 -330 minecraft:dirt
fill 171 65 -330 173 65 -330 minecraft:stone
fill 174 65 -330 176 65 -330 alltheores:tin_ore
fill 177 65 -330 180 65 -330 minecraft:stone
fill 184 65 -330 186 65 -330 minecraft:air
fill 136 65 -331 141 65 -331 minecraft:dirt
fill 142 65 -331 143 65 -331 minecraft:stone
setblock 144 65 -331 minecraft:dirt
fill 145 65 -331 157 65 -331 minecraft:stone
setblock 158 65 -331 minecraft:copper_ore
fill 159 65 -331 165 65 -331 minecraft:stone
fill 166 65 -331 167 65 -331 minecraft:dirt
setblock 168 65 -331 minecraft:air
setblock 170 65 -331 minecraft:dirt
fill 171 65 -331 175 65 -331 minecraft:stone
fill 176 65 -331 178 65 -331 minecraft:air
fill 179 65 -331 180 65 -331 minecraft:stone
fill 181 65 -331 183 65 -331 minecraft:air
fill 185 65 -331 186 65 -331 minecraft:air
setblock 199 65 -331 minecraft:air
fill 136 65 -332 140 65 -332 minecraft:dirt
fill 141 65 -332 142 65 -332 minecraft:stone
setblock 143 65 -332 minecraft:dirt
setblock 144 65 -332 minecraft:stone
setblock 145 65 -332 minecraft:copper_ore
fill 146 65 -332 157 65 -332 minecraft:stone
setblock 158 65 -332 minecraft:copper_ore
fill 159 65 -332 165 65 -332 minecraft:stone
fill 166 65 -332 167 65 -332 minecraft:dirt
setblock 168 65 -332 minecraft:air
setblock 170 65 -332 minecraft:dirt
fill 171 65 -332 174 65 -332 minecraft:stone
fill 175 65 -332 179 65 -332 minecraft:air
setblock 180 65 -332 minecraft:stone
fill 181 65 -332 183 65 -332 minecraft:air
setblock 199 65 -332 regions_unexplored:grass_sprouts
fill 136 65 -333 142 65 -333 minecraft:dirt
setblock 143 65 -333 minecraft:stone
setblock 144 65 -333 minecraft:dirt
setblock 145 65 -333 minecraft:stone
setblock 146 65 -333 minecraft:copper_ore
fill 147 65 -333 156 65 -333 minecraft:stone
fill 157 65 -333 158 65 -333 minecraft:copper_ore
fill 159 65 -333 166 65 -333 minecraft:stone
setblock 167 65 -333 minecraft:dirt
fill 169 65 -333 170 65 -333 minecraft:dirt
fill 171 65 -333 174 65 -333 minecraft:stone
fill 175 65 -333 176 65 -333 minecraft:air
setblock 177 65 -333 minecraft:birch_log[axis=y]
fill 178 65 -333 181 65 -333 minecraft:air
setblock 199 65 -333 minecraft:short_grass
fill 136 65 -334 140 65 -334 minecraft:dirt
fill 141 65 -334 142 65 -334 minecraft:stone
fill 143 65 -334 144 65 -334 minecraft:dirt
fill 145 65 -334 156 65 -334 minecraft:stone
setblock 157 65 -334 minecraft:copper_ore
fill 158 65 -334 167 65 -334 minecraft:stone
setblock 168 65 -334 minecraft:dirt
fill 169 65 -334 174 65 -334 minecraft:stone
fill 175 65 -334 180 65 -334 minecraft:air
setblock 181 65 -334 regions_unexplored:grass_sprouts
setblock 182 65 -334 minecraft:air
fill 136 65 -335 140 65 -335 minecraft:dirt
fill 141 65 -335 143 65 -335 minecraft:stone
setblock 144 65 -335 minecraft:dirt
fill 145 65 -335 173 65 -335 minecraft:stone
setblock 174 65 -335 minecraft:dirt
fill 175 65 -335 183 65 -335 minecraft:air
setblock 184 65 -335 minecraft:birch_log[axis=y]
setblock 185 65 -335 minecraft:air
setblock 136 65 -336 regions_unexplored:peat_mud
fill 137 65 -336 139 65 -336 minecraft:dirt
fill 140 65 -336 144 65 -336 minecraft:stone
fill 145 65 -336 146 65 -336 minecraft:coal_ore
fill 147 65 -336 158 65 -336 minecraft:stone
fill 159 65 -336 160 65 -336 minecraft:coal_ore
fill 161 65 -336 173 65 -336 minecraft:stone
setblock 174 65 -336 minecraft:dirt
fill 175 65 -336 182 65 -336 minecraft:air
setblock 183 65 -336 minecraft:short_grass
setblock 184 65 -336 minecraft:air
setblock 185 65 -336 regions_unexplored:grass_sprouts
fill 186 65 -336 187 65 -336 minecraft:air
setblock 136 65 -337 regions_unexplored:peat_mud
fill 137 65 -337 141 65 -337 minecraft:dirt
setblock 142 65 -337 minecraft:stone
setblock 143 65 -337 minecraft:dirt
setblock 144 65 -337 minecraft:stone
setblock 145 65 -337 minecraft:dirt
setblock 146 65 -337 minecraft:coal_ore
fill 147 65 -337 158 65 -337 minecraft:stone
fill 159 65 -337 160 65 -337 minecraft:coal_ore
fill 161 65 -337 171 65 -337 minecraft:stone
fill 172 65 -337 173 65 -337 minecraft:dirt
fill 174 65 -337 179 65 -337 minecraft:air
setblock 180 65 -337 minecraft:birch_log[axis=y]
fill 181 65 -337 186 65 -337 minecraft:air
setblock 187 65 -337 regions_unexplored:grass_sprouts
fill 136 65 -338 141 65 -338 minecraft:dirt
fill 142 65 -338 145 65 -338 minecraft:stone
fill 146 65 -338 147 65 -338 minecraft:coal_ore
fill 148 65 -338 151 65 -338 minecraft:stone
setblock 152 65 -338 minecraft:dirt
fill 153 65 -338 170 65 -338 minecraft:stone
setblock 171 65 -338 minecraft:dirt
fill 173 65 -338 187 65 -338 minecraft:air
fill 136 65 -339 143 65 -339 minecraft:dirt
fill 144 65 -339 145 65 -339 minecraft:stone
setblock 146 65 -339 minecraft:dirt
fill 147 65 -339 148 65 -339 minecraft:stone
setblock 149 65 -339 minecraft:dirt
fill 150 65 -339 153 65 -339 minecraft:stone
setblock 154 65 -339 minecraft:dirt
fill 155 65 -339 169 65 -339 minecraft:stone
setblock 170 65 -339 minecraft:dirt
fill 172 65 -339 184 65 -339 minecraft:air
fill 185 65 -339 186 65 -339 regions_unexplored:grass_sprouts
setblock 187 65 -339 minecraft:air
fill 136 65 -340 144 65 -340 minecraft:dirt
setblock 145 65 -340 minecraft:stone
setblock 146 65 -340 minecraft:dirt
fill 147 65 -340 148 65 -340 minecraft:stone
fill 149 65 -340 150 65 -340 minecraft:dirt
fill 151 65 -340 153 65 -340 minecraft:stone
setblock 154 65 -340 minecraft:dirt
fill 155 65 -340 158 65 -340 minecraft:stone
setblock 159 65 -340 minecraft:coal_ore
fill 160 65 -340 168 65 -340 minecraft:stone
fill 169 65 -340 170 65 -340 minecraft:dirt
setblock 171 65 -340 minecraft:short_grass
fill 172 65 -340 178 65 -340 minecraft:air
setblock 179 65 -340 minecraft:birch_log[axis=y]
fill 180 65 -340 186 65 -340 minecraft:air
fill 192 65 -340 199 65 -340 minecraft:dirt
fill 136 65 -341 147 65 -341 minecraft:dirt
setblock 148 65 -341 minecraft:stone
setblock 149 65 -341 minecraft:dirt
fill 150 65 -341 157 65 -341 minecraft:stone
fill 158 65 -341 160 65 -341 minecraft:coal_ore
fill 161 65 -341 163 65 -341 minecraft:stone
setblock 164 65 -341 minecraft:dirt
fill 165 65 -341 168 65 -341 minecraft:stone
setblock 169 65 -341 minecraft:dirt
fill 171 65 -341 183 65 -341 minecraft:air
setblock 184 65 -341 regions_unexplored:grass_sprouts
fill 185 65 -341 186 65 -341 minecraft:air
setblock 187 65 -341 minecraft:short_grass
fill 192 65 -341 199 65 -341 minecraft:dirt
fill 136 65 -342 137 65 -342 regions_unexplored:peat_mud
fill 138 65 -342 150 65 -342 minecraft:dirt
fill 151 65 -342 153 65 -342 minecraft:stone
setblock 154 65 -342 minecraft:dirt
fill 155 65 -342 157 65 -342 minecraft:stone
fill 158 65 -342 160 65 -342 minecraft:coal_ore
fill 161 65 -342 166 65 -342 minecraft:dirt
fill 167 65 -342 168 65 -342 minecraft:stone
setblock 169 65 -342 minecraft:dirt
fill 171 65 -342 185 65 -342 minecraft:air
fill 186 65 -342 187 65 -342 regions_unexplored:grass_sprouts
fill 192 65 -342 199 65 -342 minecraft:dirt
setblock 136 65 -343 regions_unexplored:peat_mud
fill 137 65 -343 154 65 -343 minecraft:dirt
fill 155 65 -343 157 65 -343 minecraft:stone
setblock 158 65 -343 minecraft:coal_ore
fill 159 65 -343 164 65 -343 minecraft:dirt
setblock 165 65 -343 minecraft:stone
setblock 166 65 -343 minecraft:dirt
fill 167 65 -343 168 65 -343 minecraft:stone
setblock 169 65 -343 minecraft:dirt
fill 171 65 -343 177 65 -343 minecraft:air
setblock 178 65 -343 minecraft:birch_log[axis=y]
fill 179 65 -343 187 65 -343 minecraft:air
fill 192 65 -343 199 65 -343 minecraft:dirt
fill 136 65 -344 137 65 -344 regions_unexplored:peat_mud
fill 138 65 -344 155 65 -344 minecraft:dirt
setblock 156 65 -344 minecraft:stone
fill 157 65 -344 165 65 -344 minecraft:dirt
fill 166 65 -344 168 65 -344 minecraft:stone
setblock 169 65 -344 minecraft:dirt
setblock 170 65 -344 minecraft:short_grass
fill 171 65 -344 187 65 -344 minecraft:air
fill 192 65 -344 199 65 -344 minecraft:dirt
fill 136 65 -345 139 65 -345 regions_unexplored:peat_mud
fill 140 65 -345 141 65 -345 minecraft:dirt
setblock 142 65 -345 regions_unexplored:peat_mud
fill 143 65 -345 166 65 -345 minecraft:dirt
fill 167 65 -345 168 65 -345 minecraft:stone
setblock 169 65 -345 minecraft:dirt
fill 170 65 -345 187 65 -345 minecraft:air
fill 191 65 -345 199 65 -345 minecraft:dirt
fill 136 65 -346 137 65 -346 minecraft:air
fill 138 65 -346 143 65 -346 regions_unexplored:peat_mud
fill 144 65 -346 166 65 -346 minecraft:dirt
fill 167 65 -346 168 65 -346 minecraft:stone
setblock 169 65 -346 minecraft:dirt
fill 171 65 -346 186 65 -346 minecraft:air
setblock 187 65 -346 minecraft:dirt
fill 191 65 -346 199 65 -346 minecraft:dirt
fill 136 65 -347 138 65 -347 minecraft:air
fill 139 65 -347 143 65 -347 regions_unexplored:peat_mud
fill 144 65 -347 167 65 -347 minecraft:dirt
setblock 168 65 -347 minecraft:stone
setblock 169 65 -347 minecraft:dirt
fill 171 65 -347 179 65 -347 minecraft:air
setblock 180 65 -347 minecraft:birch_log[axis=y]
fill 181 65 -347 186 65 -347 minecraft:air
fill 191 65 -347 199 65 -347 minecraft:dirt
fill 136 65 -348 139 65 -348 minecraft:air
setblock 140 65 -348 minecraft:short_grass
fill 141 65 -348 144 65 -348 regions_unexplored:peat_mud
fill 145 65 -348 169 65 -348 minecraft:dirt
fill 172 65 -348 186 65 -348 minecraft:air
fill 191 65 -348 199 65 -348 minecraft:dirt
fill 136 65 -349 138 65 -349 minecraft:air
setblock 139 65 -349 minecraft:short_grass
fill 140 65 -349 141 65 -349 minecraft:air
fill 142 65 -349 145 65 -349 regions_unexplored:peat_mud
setblock 146 65 -349 minecraft:dirt
fill 147 65 -349 148 65 -349 regions_unexplored:peat_mud
fill 149 65 -349 169 65 -349 minecraft:dirt
fill 171 65 -349 185 65 -349 minecraft:air
setblock 186 65 -349 minecraft:birch_log[axis=y]
setblock 187 65 -349 minecraft:air
fill 191 65 -349 199 65 -349 minecraft:dirt
fill 136 65 -350 138 65 -350 minecraft:air
setblock 139 65 -350 minecraft:tall_grass[half=lower]
setblock 140 65 -350 minecraft:short_grass
setblock 141 65 -350 minecraft:tall_grass[half=lower]
setblock 142 65 -350 minecraft:air
fill 143 65 -350 148 65 -350 regions_unexplored:peat_mud
fill 149 65 -350 169 65 -350 minecraft:dirt
setblock 171 65 -350 minecraft:birch_log[axis=y]
fill 172 65 -350 177 65 -350 minecraft:air
setblock 178 65 -350 minecraft:birch_log[axis=y]
fill 179 65 -350 187 65 -350 minecraft:air
fill 191 65 -350 199 65 -350 minecraft:dirt
fill 136 65 -351 141 65 -351 minecraft:air
setblock 142 65 -351 minecraft:short_grass
setblock 143 65 -351 minecraft:air
fill 144 65 -351 148 65 -351 regions_unexplored:peat_mud
fill 149 65 -351 168 65 -351 minecraft:dirt
fill 170 65 -351 175 65 -351 minecraft:air
setblock 176 65 -351 minecraft:birch_log[axis=y]
fill 177 65 -351 187 65 -351 minecraft:air
fill 192 65 -351 199 65 -351 minecraft:dirt
fill 136 65 -352 142 65 -352 minecraft:air
setblock 143 65 -352 regions_unexplored:grass_sprouts
setblock 144 65 -352 minecraft:short_grass
fill 145 65 -352 148 65 -352 regions_unexplored:peat_mud
fill 149 65 -352 168 65 -352 minecraft:dirt
fill 170 65 -352 186 65 -352 minecraft:air
setblock 187 65 -352 minecraft:birch_log[axis=y]
setblock 188 65 -352 minecraft:air
fill 192 65 -352 199 65 -352 minecraft:dirt
fill 136 65 -353 143 65 -353 minecraft:air
setblock 144 65 -353 regions_unexplored:grass_sprouts
setblock 145 65 -353 minecraft:air
fill 146 65 -353 148 65 -353 regions_unexplored:peat_mud
fill 149 65 -353 168 65 -353 minecraft:dirt
fill 170 65 -353 179 65 -353 minecraft:air
setblock 180 65 -353 minecraft:birch_log[axis=y]
fill 181 65 -353 188 65 -353 minecraft:air
fill 192 65 -353 199 65 -353 minecraft:dirt
fill 136 65 -354 145 65 -354 minecraft:air
fill 146 65 -354 147 65 -354 regions_unexplored:peat_mud
fill 150 65 -354 168 65 -354 minecraft:dirt
setblock 170 65 -354 minecraft:short_grass
fill 171 65 -354 189 65 -354 minecraft:air
fill 192 65 -354 199 65 -354 minecraft:dirt
fill 136 65 -355 144 65 -355 minecraft:air
setblock 145 65 -355 regions_unexplored:grass_sprouts
setblock 146 65 -355 minecraft:air
fill 147 65 -355 148 65 -355 regions_unexplored:peat_mud
fill 151 65 -355 168 65 -355 minecraft:dirt
fill 170 65 -355 181 65 -355 minecraft:air
setblock 182 65 -355 minecraft:birch_log[axis=y]
fill 183 65 -355 189 65 -355 minecraft:air
fill 192 65 -355 199 65 -355 minecraft:dirt
fill 136 65 -356 147 65 -356 minecraft:air
setblock 148 65 -356 regions_unexplored:grass_sprouts
fill 153 65 -356 159 65 -356 minecraft:dirt
fill 165 65 -356 168 65 -356 minecraft:dirt
fill 170 65 -356 178 65 -356 minecraft:air
setblock 179 65 -356 minecraft:birch_log[axis=y]
fill 180 65 -356 189 65 -356 minecraft:air
fill 193 65 -356 199 65 -356 minecraft:dirt
fill 136 65 -357 147 65 -357 minecraft:air
setblock 148 65 -357 minecraft:short_grass
setblock 149 65 -357 minecraft:air
setblock 150 65 -357 regions_unexplored:peat_mud
setblock 168 65 -357 minecraft:dirt
fill 170 65 -357 176 65 -357 minecraft:air
setblock 177 65 -357 regions_unexplored:birch_shrub[half=upper]
fill 178 65 -357 190 65 -357 minecraft:air
fill 193 65 -357 199 65 -357 minecraft:dirt
fill 136 65 -358 149 65 -358 minecraft:air
setblock 150 65 -358 regions_unexplored:grass_sprouts
setblock 151 65 -358 minecraft:air
setblock 154 65 -358 minecraft:dirt
fill 170 65 -358 173 65 -358 minecraft:air
setblock 174 65 -358 minecraft:birch_log[axis=y]
fill 175 65 -358 189 65 -358 minecraft:air
setblock 190 65 -358 regions_unexplored:grass_sprouts
fill 193 65 -358 199 65 -358 minecraft:dirt
fill 136 65 -359 156 65 -359 minecraft:air
fill 171 65 -359 190 65 -359 minecraft:air
fill 192 65 -359 199 65 -359 minecraft:dirt
fill 136 65 -360 151 65 -360 minecraft:air
setblock 152 65 -360 minecraft:tall_grass[half=lower]
fill 153 65 -360 156 65 -360 minecraft:air
fill 157 65 -360 158 65 -360 minecraft:short_grass
setblock 159 65 -360 regions_unexplored:grass_sprouts
fill 160 65 -360 161 65 -360 regions_unexplored:peat_mud
setblock 164 65 -360 minecraft:air
fill 173 65 -360 187 65 -360 minecraft:air
setblock 188 65 -360 minecraft:birch_log[axis=y]
fill 189 65 -360 190 65 -360 minecraft:air
fill 193 65 -360 199 65 -360 minecraft:dirt
fill 136 65 -361 154 65 -361 minecraft:air
setblock 155 65 -361 minecraft:tall_grass[half=lower]
setblock 156 65 -361 minecraft:air
fill 157 65 -361 159 65 -361 minecraft:short_grass
fill 160 65 -361 166 65 -361 minecraft:air
fill 173 65 -361 190 65 -361 minecraft:air
fill 193 65 -361 199 65 -361 minecraft:dirt
fill 136 65 -362 150 65 -362 minecraft:air
setblock 151 65 -362 minecraft:tall_grass[half=upper]
setblock 152 65 -362 minecraft:air
setblock 153 65 -362 minecraft:tall_grass[half=upper]
fill 154 65 -362 159 65 -362 minecraft:air
setblock 160 65 -362 regions_unexplored:grass_sprouts
fill 161 65 -362 164 65 -362 minecraft:air
setblock 165 65 -362 minecraft:short_grass
fill 166 65 -362 169 65 -362 minecraft:air
fill 172 65 -362 190 65 -362 minecraft:air
fill 193 65 -362 199 65 -362 minecraft:dirt
fill 136 65 -363 155 65 -363 minecraft:air
setblock 156 65 -363 minecraft:tall_grass[half=upper]
fill 157 65 -363 159 65 -363 minecraft:air
fill 160 65 -363 161 65 -363 minecraft:short_grass
fill 162 65 -363 163 65 -363 minecraft:air
setblock 164 65 -363 minecraft:birch_log[axis=y]
fill 165 65 -363 171 65 -363 minecraft:air
setblock 172 65 -363 minecraft:dirt
setblock 173 65 -363 regions_unexplored:grass_sprouts
fill 174 65 -363 189 65 -363 minecraft:air
setblock 190 65 -363 minecraft:birch_log[axis=y]
fill 193 65 -363 199 65 -363 minecraft:dirt
fill 136 65 -364 151 65 -364 minecraft:air
setblock 152 65 -364 minecraft:tall_grass[half=upper]
fill 153 65 -364 160 65 -364 minecraft:air
setblock 161 65 -364 minecraft:short_grass
fill 162 65 -364 174 65 -364 minecraft:air
setblock 175 65 -364 minecraft:birch_log[axis=y]
fill 176 65 -364 190 65 -364 minecraft:air
fill 193 65 -364 199 65 -364 minecraft:dirt
fill 136 65 -365 190 65 -365 minecraft:air
fill 194 65 -365 199 65 -365 minecraft:dirt
fill 136 65 -366 169 65 -366 minecraft:air
setblock 170 65 -366 minecraft:birch_log[axis=y]
fill 171 65 -366 182 65 -366 minecraft:air
setblock 183 65 -366 minecraft:birch_log[axis=y]
fill 184 65 -366 185 65 -366 minecraft:air
setblock 186 65 -366 minecraft:birch_log[axis=y]
fill 187 65 -366 190 65 -366 minecraft:air
fill 194 65 -366 199 65 -366 minecraft:dirt
fill 136 65 -367 190 65 -367 minecraft:air
fill 195 65 -367 199 65 -367 minecraft:dirt
fill 136 65 -368 190 65 -368 minecraft:air
fill 195 65 -368 199 65 -368 minecraft:dirt
fill 136 65 -369 173 65 -369 minecraft:air
setblock 174 65 -369 minecraft:birch_log[axis=y]
fill 175 65 -369 180 65 -369 minecraft:air
setblock 181 65 -369 minecraft:birch_log[axis=y]
fill 182 65 -369 190 65 -369 minecraft:air
setblock 191 65 -369 minecraft:short_grass
fill 196 65 -369 199 65 -369 minecraft:dirt
fill 136 65 -370 186 65 -370 minecraft:air
setblock 187 65 -370 minecraft:birch_log[axis=y]
fill 188 65 -370 190 65 -370 minecraft:air
setblock 191 65 -370 minecraft:birch_log[axis=y]
setblock 192 65 -370 minecraft:air
fill 197 65 -370 199 65 -370 minecraft:dirt
fill 136 65 -371 193 65 -371 minecraft:air
fill 198 65 -371 199 65 -371 minecraft:dirt
fill 136 65 -372 194 65 -372 minecraft:air
setblock 199 65 -372 minecraft:dirt
fill 136 65 -373 195 65 -373 minecraft:air
fill 136 65 -374 196 65 -374 minecraft:air
fill 136 65 -375 178 65 -375 minecraft:air
setblock 179 65 -375 minecraft:birch_log[axis=y]
fill 180 65 -375 197 65 -375 minecraft:air
fill 136 65 -376 187 65 -376 minecraft:air
setblock 188 65 -376 minecraft:birch_log[axis=y]
fill 189 65 -376 197 65 -376 minecraft:air
setblock 198 65 -376 minecraft:birch_log[axis=y]
setblock 199 65 -376 minecraft:air
fill 136 65 -377 199 65 -377 minecraft:air
fill 136 65 -378 197 65 -378 minecraft:air
setblock 198 65 -378 regions_unexplored:grass_sprouts
setblock 199 65 -378 minecraft:air
fill 136 65 -379 199 65 -379 minecraft:air
fill 136 65 -380 181 65 -380 minecraft:air
setblock 182 65 -380 minecraft:birch_log[axis=y]
fill 183 65 -380 193 65 -380 minecraft:air
setblock 194 65 -380 minecraft:birch_log[axis=y]
fill 195 65 -380 199 65 -380 minecraft:air
fill 136 65 -381 191 65 -381 minecraft:air
setblock 192 65 -381 minecraft:birch_log[axis=y]
fill 193 65 -381 199 65 -381 minecraft:air
fill 136 65 -382 199 65 -382 minecraft:air
fill 172 64 -319 173 64 -319 minecraft:air
fill 171 64 -320 172 64 -320 minecraft:air
fill 171 64 -321 172 64 -321 minecraft:air
fill 170 64 -322 172 64 -322 minecraft:air
setblock 151 64 -323 minecraft:air
fill 169 64 -323 172 64 -323 minecraft:air
fill 168 64 -324 172 64 -324 minecraft:air
fill 152 64 -325 155 64 -325 minecraft:air
setblock 187 64 -325 minecraft:air
fill 152 64 -326 156 64 -326 minecraft:air
fill 187 64 -326 188 64 -326 minecraft:air
fill 186 64 -327 188 64 -327 minecraft:air
fill 186 64 -328 187 64 -328 minecraft:air
fill 186 64 -329 187 64 -329 minecraft:air
setblock 176 64 -330 minecraft:air
fill 185 64 -330 186 64 -330 minecraft:air
fill 176 64 -331 178 64 -331 minecraft:air
setblock 185 64 -331 minecraft:air
setblock 168 64 -332 minecraft:air
fill 175 64 -332 179 64 -332 minecraft:air
fill 175 64 -333 176 64 -333 minecraft:air
fill 178 64 -333 180 64 -333 minecraft:air
setblock 175 64 -334 minecraft:short_grass
fill 176 64 -334 180 64 -334 minecraft:air
fill 175 64 -335 181 64 -335 minecraft:air
fill 175 64 -336 182 64 -336 minecraft:air
fill 175 64 -337 179 64 -337 minecraft:air
fill 181 64 -337 182 64 -337 minecraft:air
fill 174 64 -338 176 64 -338 minecraft:air
setblock 177 64 -338 minecraft:short_grass
fill 178 64 -338 182 64 -338 minecraft:air
fill 172 64 -339 182 64 -339 minecraft:air
setblock 183 64 -339 regions_unexplored:grass_sprouts
fill 172 64 -340 178 64 -340 minecraft:air
fill 180 64 -340 183 64 -340 minecraft:air
fill 171 64 -341 180 64 -341 minecraft:air
setblock 181 64 -341 regions_unexplored:grass_sprouts
fill 182 64 -341 183 64 -341 minecraft:air
fill 171 64 -342 181 64 -342 minecraft:air
setblock 182 64 -342 minecraft:short_grass
setblock 183 64 -342 minecraft:air
fill 171 64 -343 177 64 -343 minecraft:air
fill 179 64 -343 183 64 -343 minecraft:air
fill 171 64 -344 183 64 -344 minecraft:air
fill 171 64 -345 185 64 -345 minecraft:air
fill 172 64 -346 184 64 -346 minecraft:air
fill 172 64 -347 179 64 -347 minecraft:air
fill 181 64 -347 183 64 -347 minecraft:air
setblock 136 64 -348 minecraft:air
fill 173 64 -348 184 64 -348 minecraft:air
setblock 136 64 -349 minecraft:short_grass
fill 172 64 -349 184 64 -349 minecraft:air
fill 136 64 -350 137 64 -350 minecraft:air
fill 172 64 -350 177 64 -350 minecraft:air
fill 179 64 -350 185 64 -350 minecraft:air
fill 136 64 -351 139 64 -351 minecraft:air
setblock 140 64 -351 minecraft:short_grass
fill 171 64 -351 175 64 -351 minecraft:air
fill 177 64 -351 185 64 -351 minecraft:air
fill 136 64 -352 137 64 -352 minecraft:air
setblock 138 64 -352 minecraft:short_grass
fill 139 64 -352 140 64 -352 regions_unexplored:grass_sprouts
setblock 141 64 -352 minecraft:air
fill 171 64 -352 186 64 -352 minecraft:air
setblock 136 64 -353 regions_unexplored:grass_sprouts
setblock 137 64 -353 minecraft:short_grass
fill 138 64 -353 139 64 -353 minecraft:air
setblock 140 64 -353 regions_unexplored:grass_sprouts
setblock 141 64 -353 minecraft:air
fill 171 64 -353 179 64 -353 minecraft:air
fill 181 64 -353 186 64 -353 minecraft:air
setblock 136 64 -354 regions_unexplored:grass_sprouts
setblock 137 64 -354 minecraft:air
setblock 138 64 -354 minecraft:short_grass
setblock 139 64 -354 minecraft:air
setblock 140 64 -354 minecraft:short_grass
setblock 141 64 -354 regions_unexplored:grass_sprouts
setblock 142 64 -354 minecraft:air
fill 171 64 -354 181 64 -354 minecraft:air
fill 183 64 -354 186 64 -354 minecraft:air
setblock 136 64 -355 minecraft:air
setblock 137 64 -355 regions_unexplored:grass_sprouts
setblock 138 64 -355 minecraft:air
setblock 139 64 -355 minecraft:short_grass
setblock 140 64 -355 regions_unexplored:grass_sprouts
setblock 141 64 -355 minecraft:air
fill 142 64 -355 143 64 -355 minecraft:short_grass
fill 170 64 -355 181 64 -355 minecraft:air
fill 183 64 -355 187 64 -355 minecraft:air
setblock 136 64 -356 regions_unexplored:grass_sprouts
fill 137 64 -356 140 64 -356 minecraft:air
setblock 141 64 -356 regions_unexplored:grass_sprouts
fill 142 64 -356 143 64 -356 minecraft:air
setblock 144 64 -356 minecraft:short_grass
fill 170 64 -356 178 64 -356 minecraft:air
setblock 180 64 -356 minecraft:air
setblock 181 64 -356 minecraft:short_grass
fill 182 64 -356 187 64 -356 minecraft:air
fill 136 64 -357 137 64 -357 minecraft:air
setblock 138 64 -357 regions_unexplored:grass_sprouts
fill 139 64 -357 140 64 -357 minecraft:air
fill 141 64 -357 143 64 -357 regions_unexplored:grass_sprouts
setblock 144 64 -357 minecraft:air
setblock 145 64 -357 regions_unexplored:grass_sprouts
setblock 146 64 -357 minecraft:short_grass
fill 171 64 -357 176 64 -357 minecraft:air
fill 178 64 -357 185 64 -357 minecraft:air
setblock 186 64 -357 regions_unexplored:grass_sprouts
fill 187 64 -357 188 64 -357 minecraft:air
fill 136 64 -358 146 64 -358 minecraft:air
setblock 147 64 -358 minecraft:short_grass
fill 171 64 -358 173 64 -358 minecraft:air
setblock 175 64 -358 minecraft:short_grass
setblock 176 64 -358 regions_unexplored:grass_sprouts
fill 177 64 -358 188 64 -358 minecraft:air
fill 136 64 -359 146 64 -359 minecraft:air
setblock 147 64 -359 regions_unexplored:grass_sprouts
setblock 148 64 -359 minecraft:air
fill 173 64 -359 188 64 -359 minecraft:air
fill 136 64 -360 150 64 -360 minecraft:air
fill 174 64 -360 187 64 -360 minecraft:air
fill 136 64 -361 151 64 -361 minecraft:air
fill 174 64 -361 184 64 -361 minecraft:air
fill 185 64 -361 186 64 -361 regions_unexplored:grass_sprouts
fill 187 64 -361 188 64 -361 minecraft:air
fill 136 64 -362 150 64 -362 minecraft:air
setblock 151 64 -362 minecraft:tall_grass[half=lower]
setblock 152 64 -362 minecraft:air
setblock 153 64 -362 minecraft:tall_grass[half=lower]
setblock 154 64 -362 minecraft:air
fill 174 64 -362 181 64 -362 minecraft:air
setblock 182 64 -362 regions_unexplored:grass_sprouts
setblock 183 64 -362 minecraft:short_grass
fill 184 64 -362 185 64 -362 minecraft:air
setblock 186 64 -362 regions_unexplored:grass_sprouts
fill 187 64 -362 188 64 -362 minecraft:air
fill 136 64 -363 155 64 -363 minecraft:air
setblock 156 64 -363 minecraft:tall_grass[half=lower]
setblock 174 64 -363 minecraft:air
setblock 175 64 -363 regions_unexplored:grass_sprouts
setblock 176 64 -363 minecraft:short_grass
fill 177 64 -363 186 64 -363 minecraft:air
setblock 187 64 -363 regions_unexplored:grass_sprouts
setblock 188 64 -363 minecraft:short_grass
fill 136 64 -364 147 64 -364 minecraft:air
fill 149 64 -364 151 64 -364 minecraft:air
setblock 152 64 -364 minecraft:tall_grass[half=lower]
fill 153 64 -364 159 64 -364 minecraft:air
setblock 174 64 -364 minecraft:air
fill 176 64 -364 178 64 -364 minecraft:air
setblock 179 64 -364 regions_unexplored:grass_sprouts
fill 180 64 -364 188 64 -364 minecraft:air
fill 136 64 -365 151 64 -365 minecraft:air
fill 153 64 -365 164 64 -365 minecraft:air
setblock 165 64 -365 regions_unexplored:grass_sprouts
setblock 166 64 -365 minecraft:air
fill 174 64 -365 178 64 -365 minecraft:air
setblock 179 64 -365 regions_unexplored:grass_sprouts
fill 180 64 -365 181 64 -365 minecraft:air
setblock 182 64 -365 minecraft:short_grass
fill 183 64 -365 188 64 -365 minecraft:air
fill 136 64 -366 152 64 -366 minecraft:air
fill 154 64 -366 169 64 -366 minecraft:air
fill 174 64 -366 176 64 -366 minecraft:air
setblock 177 64 -366 regions_unexplored:grass_sprouts
fill 178 64 -366 182 64 -366 minecraft:air
fill 184 64 -366 185 64 -366 minecraft:air
fill 187 64 -366 188 64 -366 minecraft:air
fill 136 64 -367 162 64 -367 minecraft:air
setblock 163 64 -367 regions_unexplored:grass_sprouts
fill 164 64 -367 167 64 -367 minecraft:air
setblock 168 64 -367 minecraft:short_grass
fill 169 64 -367 170 64 -367 minecraft:air
setblock 175 64 -367 minecraft:air
setblock 176 64 -367 minecraft:short_grass
fill 177 64 -367 184 64 -367 minecraft:air
setblock 185 64 -367 minecraft:short_grass
fill 186 64 -367 188 64 -367 minecraft:air
fill 136 64 -368 172 64 -368 minecraft:air
fill 177 64 -368 187 64 -368 minecraft:air
fill 136 64 -369 173 64 -369 minecraft:air
fill 175 64 -369 180 64 -369 minecraft:air
fill 182 64 -369 188 64 -369 minecraft:air
fill 136 64 -370 168 64 -370 minecraft:air
setblock 169 64 -370 minecraft:short_grass
fill 170 64 -370 171 64 -370 minecraft:air
setblock 172 64 -370 regions_unexplored:grass_sprouts
fill 173 64 -370 174 64 -370 minecraft:air
fill 176 64 -370 186 64 -370 minecraft:air
fill 188 64 -370 189 64 -370 minecraft:air
fill 136 64 -371 172 64 -371 minecraft:air
setblock 173 64 -371 regions_unexplored:grass_sprouts
fill 174 64 -371 190 64 -371 minecraft:air
fill 136 64 -372 168 64 -372 minecraft:air
setblock 169 64 -372 regions_unexplored:grass_sprouts
fill 170 64 -372 178 64 -372 minecraft:air
setblock 179 64 -372 minecraft:short_grass
fill 180 64 -372 191 64 -372 minecraft:air
fill 136 64 -373 178 64 -373 minecraft:air
setblock 179 64 -373 minecraft:short_grass
fill 180 64 -373 183 64 -373 minecraft:air
setblock 184 64 -373 minecraft:short_grass
fill 185 64 -373 191 64 -373 minecraft:air
fill 136 64 -374 174 64 -374 minecraft:air
setblock 175 64 -374 regions_unexplored:grass_sprouts
fill 176 64 -374 177 64 -374 minecraft:air
setblock 178 64 -374 regions_unexplored:grass_sprouts
fill 179 64 -374 183 64 -374 minecraft:air
setblock 184 64 -374 minecraft:short_grass
fill 185 64 -374 192 64 -374 minecraft:air
fill 136 64 -375 173 64 -375 minecraft:air
fill 175 64 -375 176 64 -375 minecraft:air
setblock 178 64 -375 minecraft:air
fill 180 64 -375 185 64 -375 minecraft:air
fill 187 64 -375 193 64 -375 minecraft:air
fill 136 64 -376 178 64 -376 minecraft:air
fill 180 64 -376 187 64 -376 minecraft:air
fill 189 64 -376 194 64 -376 minecraft:air
fill 136 64 -377 173 64 -377 minecraft:air
fill 175 64 -377 177 64 -377 minecraft:air
fill 179 64 -377 183 64 -377 minecraft:air
setblock 184 64 -377 regions_unexplored:grass_sprouts
fill 185 64 -377 195 64 -377 minecraft:air
fill 136 64 -378 176 64 -378 minecraft:air
setblock 178 64 -378 minecraft:air
fill 181 64 -378 185 64 -378 minecraft:air
setblock 186 64 -378 regions_unexplored:grass_sprouts
fill 187 64 -378 188 64 -378 minecraft:air
setblock 189 64 -378 regions_unexplored:grass_sprouts
fill 190 64 -378 193 64 -378 minecraft:air
setblock 194 64 -378 regions_unexplored:grass_sprouts
fill 195 64 -378 196 64 -378 minecraft:air
setblock 197 64 -378 regions_unexplored:grass_sprouts
fill 136 64 -379 175 64 -379 minecraft:air
fill 177 64 -379 179 64 -379 minecraft:air
fill 181 64 -379 187 64 -379 minecraft:air
setblock 188 64 -379 minecraft:short_grass
fill 189 64 -379 191 64 -379 minecraft:air
setblock 192 64 -379 regions_unexplored:grass_sprouts
fill 193 64 -379 199 64 -379 minecraft:air
fill 136 64 -380 181 64 -380 minecraft:air
setblock 183 64 -380 minecraft:short_grass
fill 184 64 -380 189 64 -380 minecraft:air
fill 190 64 -380 191 64 -380 regions_unexplored:grass_sprouts
fill 192 64 -380 193 64 -380 minecraft:air
fill 195 64 -380 199 64 -380 minecraft:air
fill 136 64 -381 183 64 -381 minecraft:air
setblock 184 64 -381 minecraft:short_grass
fill 185 64 -381 191 64 -381 minecraft:air
fill 193 64 -381 198 64 -381 minecraft:air
setblock 199 64 -381 minecraft:short_grass
fill 136 64 -382 178 64 -382 minecraft:air
fill 180 64 -382 187 64 -382 minecraft:air
setblock 188 64 -382 regions_unexplored:grass_sprouts
fill 189 64 -382 190 64 -382 minecraft:air
setblock 191 64 -382 minecraft:short_grass
fill 193 64 -382 196 64 -382 minecraft:air
setblock 197 64 -382 minecraft:short_grass
setblock 198 64 -382 minecraft:air
setblock 199 64 -382 regions_unexplored:grass_sprouts
setblock 151 63 -323 minecraft:air
fill 152 63 -325 155 63 -325 minecraft:air
fill 152 63 -326 156 63 -326 minecraft:air
setblock 187 63 -326 minecraft:air
setblock 187 63 -327 minecraft:air
fill 186 63 -328 187 63 -328 minecraft:air
setblock 186 63 -329 minecraft:air
setblock 176 63 -345 minecraft:air
fill 183 63 -345 184 63 -345 minecraft:air
setblock 176 63 -346 minecraft:air
fill 183 63 -346 184 63 -346 minecraft:air
setblock 176 63 -347 minecraft:air
setblock 176 63 -348 minecraft:air
setblock 176 63 -349 minecraft:air
setblock 176 63 -350 minecraft:air
setblock 176 63 -352 minecraft:air
setblock 136 63 -358 regions_unexplored:grass_sprouts
fill 137 63 -358 138 63 -358 minecraft:air
setblock 139 63 -358 regions_unexplored:grass_sprouts
setblock 140 63 -358 minecraft:air
setblock 141 63 -358 minecraft:short_grass
setblock 142 63 -358 minecraft:air
setblock 143 63 -358 minecraft:short_grass
setblock 144 63 -358 minecraft:air
fill 136 63 -359 141 63 -359 minecraft:air
fill 143 63 -359 144 63 -359 minecraft:air
setblock 145 63 -359 regions_unexplored:grass_sprouts
fill 176 63 -359 179 63 -359 minecraft:air
fill 136 63 -360 146 63 -360 minecraft:air
setblock 176 63 -360 minecraft:air
setblock 177 63 -360 regions_unexplored:grass_sprouts
fill 178 63 -360 179 63 -360 minecraft:air
fill 136 63 -361 145 63 -361 minecraft:air
setblock 146 63 -361 regions_unexplored:grass_sprouts
setblock 147 63 -361 minecraft:short_grass
fill 176 63 -361 178 63 -361 minecraft:air
fill 136 63 -362 148 63 -362 minecraft:air
fill 136 63 -363 149 63 -363 minecraft:air
fill 136 63 -364 147 63 -364 minecraft:air
fill 149 63 -364 150 63 -364 minecraft:air
fill 136 63 -365 151 63 -365 minecraft:air
setblock 153 63 -365 minecraft:air
fill 136 63 -366 152 63 -366 minecraft:air
fill 154 63 -366 155 63 -366 minecraft:air
fill 136 63 -367 152 63 -367 minecraft:air
fill 155 63 -367 158 63 -367 minecraft:air
fill 136 63 -368 161 63 -368 minecraft:air
fill 136 63 -369 155 63 -369 minecraft:air
fill 157 63 -369 161 63 -369 minecraft:air
fill 136 63 -370 162 63 -370 minecraft:air
fill 136 63 -371 157 63 -371 minecraft:air
fill 159 63 -371 160 63 -371 minecraft:air
setblock 161 63 -371 regions_unexplored:grass_sprouts
setblock 162 63 -371 minecraft:air
setblock 163 63 -371 minecraft:short_grass
fill 136 63 -372 163 63 -372 minecraft:air
fill 136 63 -373 163 63 -373 minecraft:air
setblock 164 63 -373 regions_unexplored:grass_sprouts
fill 165 63 -373 166 63 -373 minecraft:air
setblock 167 63 -373 regions_unexplored:grass_sprouts
fill 168 63 -373 169 63 -373 minecraft:air
fill 136 63 -374 170 63 -374 minecraft:air
fill 171 63 -374 172 63 -374 regions_unexplored:grass_sprouts
fill 173 63 -374 174 63 -374 minecraft:air
fill 136 63 -375 163 63 -375 minecraft:air
setblock 164 63 -375 minecraft:short_grass
fill 165 63 -375 167 63 -375 minecraft:air
fill 168 63 -375 169 63 -375 minecraft:short_grass
setblock 170 63 -375 minecraft:air
setblock 171 63 -375 minecraft:short_grass
setblock 172 63 -375 minecraft:air
setblock 173 63 -375 minecraft:short_grass
fill 175 63 -375 176 63 -375 minecraft:air
setblock 178 63 -375 minecraft:short_grass
setblock 180 63 -375 minecraft:short_grass
fill 136 63 -376 162 63 -376 minecraft:air
setblock 164 63 -376 minecraft:air
fill 166 63 -376 167 63 -376 minecraft:air
setblock 168 63 -376 regions_unexplored:grass_sprouts
setblock 169 63 -376 minecraft:short_grass
setblock 170 63 -376 minecraft:air
setblock 171 63 -376 minecraft:short_grass
fill 172 63 -376 176 63 -376 minecraft:air
setblock 177 63 -376 minecraft:short_grass
setblock 178 63 -376 minecraft:air
fill 180 63 -376 182 63 -376 minecraft:air
fill 136 63 -377 172 63 -377 minecraft:air
setblock 173 63 -377 regions_unexplored:grass_sprouts
setblock 175 63 -377 regions_unexplored:grass_sprouts
fill 176 63 -377 177 63 -377 minecraft:air
fill 179 63 -377 182 63 -377 minecraft:air
fill 136 63 -378 169 63 -378 minecraft:air
fill 171 63 -378 173 63 -378 minecraft:air
setblock 174 63 -378 regions_unexplored:grass_sprouts
fill 175 63 -378 176 63 -378 minecraft:air
setblock 178 63 -378 regions_unexplored:grass_sprouts
fill 181 63 -378 182 63 -378 minecraft:air
fill 136 63 -379 172 63 -379 minecraft:air
fill 174 63 -379 175 63 -379 minecraft:air
setblock 177 63 -379 minecraft:air
fill 178 63 -379 179 63 -379 regions_unexplored:grass_sprouts
setblock 181 63 -379 minecraft:air
setblock 182 63 -379 minecraft:short_grass
fill 136 63 -380 174 63 -380 minecraft:air
fill 176 63 -380 177 63 -380 regions_unexplored:grass_sprouts
fill 178 63 -380 181 63 -380 minecraft:air
fill 136 63 -381 176 63 -381 minecraft:air
setblock 177 63 -381 regions_unexplored:grass_sprouts
setblock 178 63 -381 minecraft:short_grass
fill 179 63 -381 181 63 -381 minecraft:air
setblock 182 63 -381 minecraft:short_grass
fill 136 63 -382 178 63 -382 minecraft:air
setblock 180 63 -382 minecraft:air
fill 181 63 -382 183 63 -382 regions_unexplored:grass_sprouts
setblock 151 62 -323 minecraft:air
fill 152 62 -325 155 62 -325 minecraft:water[level=0]
fill 153 62 -326 156 62 -326 minecraft:water[level=0]
fill 183 62 -345 184 62 -345 minecraft:water[level=0]
fill 182 62 -346 183 62 -346 minecraft:water[level=0]
fill 139 62 -359 141 62 -359 minecraft:water[level=0]
setblock 143 62 -359 minecraft:water[level=0]
setblock 144 62 -359 minecraft:seagrass
fill 136 62 -360 139 62 -360 minecraft:water[level=0]
setblock 140 62 -360 minecraft:seagrass
fill 141 62 -360 144 62 -360 minecraft:water[level=0]
fill 136 62 -361 145 62 -361 minecraft:water[level=0]
setblock 136 62 -362 minecraft:seagrass
fill 137 62 -362 146 62 -362 minecraft:water[level=0]
fill 136 62 -363 137 62 -363 minecraft:water[level=0]
setblock 138 62 -363 minecraft:tall_seagrass[half=upper]
fill 139 62 -363 145 62 -363 minecraft:water[level=0]
setblock 146 62 -363 minecraft:seagrass
fill 136 62 -364 144 62 -364 minecraft:water[level=0]
fill 145 62 -364 146 62 -364 minecraft:tall_seagrass[half=upper]
setblock 147 62 -364 minecraft:seagrass
fill 136 62 -365 146 62 -365 minecraft:water[level=0]
setblock 147 62 -365 minecraft:seagrass
fill 148 62 -365 149 62 -365 minecraft:water[level=0]
fill 136 62 -366 151 62 -366 minecraft:water[level=0]
fill 136 62 -367 149 62 -367 minecraft:water[level=0]
setblock 150 62 -367 minecraft:tall_seagrass[half=upper]
setblock 151 62 -367 minecraft:water[level=0]
setblock 152 62 -367 minecraft:seagrass
fill 136 62 -368 156 62 -368 minecraft:water[level=0]
fill 136 62 -369 155 62 -369 minecraft:water[level=0]
setblock 157 62 -369 minecraft:water[level=0]
fill 136 62 -370 159 62 -370 minecraft:water[level=0]
fill 136 62 -371 157 62 -371 minecraft:water[level=0]
setblock 159 62 -371 minecraft:water[level=0]
fill 136 62 -372 160 62 -372 minecraft:water[level=0]
fill 136 62 -373 161 62 -373 minecraft:water[level=0]
fill 136 62 -374 162 62 -374 minecraft:water[level=0]
fill 136 62 -375 160 62 -375 minecraft:water[level=0]
setblock 161 62 -375 minecraft:tall_seagrass[half=upper]
fill 162 62 -375 163 62 -375 minecraft:water[level=0]
fill 136 62 -376 160 62 -376 minecraft:water[level=0]
setblock 161 62 -376 minecraft:tall_seagrass[half=upper]
setblock 162 62 -376 minecraft:water[level=0]
setblock 164 62 -376 minecraft:water[level=0]
fill 166 62 -376 167 62 -376 minecraft:water[level=0]
fill 136 62 -377 164 62 -377 minecraft:water[level=0]
setblock 165 62 -377 minecraft:seagrass
fill 166 62 -377 172 62 -377 minecraft:water[level=0]
fill 136 62 -378 169 62 -378 minecraft:water[level=0]
fill 171 62 -378 173 62 -378 minecraft:water[level=0]
fill 136 62 -379 172 62 -379 minecraft:water[level=0]
setblock 174 62 -379 minecraft:water[level=0]
fill 136 62 -380 174 62 -380 minecraft:water[level=0]
fill 136 62 -381 176 62 -381 minecraft:water[level=0]
fill 136 62 -382 177 62 -382 minecraft:water[level=0]
setblock 151 61 -323 minecraft:air
fill 152 61 -325 156 61 -325 minecraft:water[level=0]
fill 153 61 -326 156 61 -326 minecraft:water[level=0]
fill 182 61 -346 183 61 -346 minecraft:water[level=0]
fill 182 61 -347 183 61 -347 minecraft:water[level=0]
fill 139 61 -361 143 61 -361 minecraft:water[level=0]
setblock 144 61 -361 minecraft:seagrass
fill 137 61 -362 139 61 -362 minecraft:water[level=0]
setblock 140 61 -362 minecraft:seagrass
fill 141 61 -362 144 61 -362 minecraft:water[level=0]
fill 136 61 -363 137 61 -363 minecraft:seagrass
setblock 138 61 -363 minecraft:tall_seagrass[half=lower]
fill 139 61 -363 144 61 -363 minecraft:water[level=0]
setblock 145 61 -363 minecraft:seagrass
setblock 136 61 -364 minecraft:seagrass
setblock 137 61 -364 minecraft:tall_seagrass[half=upper]
setblock 138 61 -364 minecraft:water[level=0]
setblock 139 61 -364 minecraft:tall_seagrass[half=upper]
fill 140 61 -364 144 61 -364 minecraft:water[level=0]
fill 145 61 -364 146 61 -364 minecraft:tall_seagrass[half=lower]
fill 136 61 -365 146 61 -365 minecraft:water[level=0]
fill 136 61 -366 146 61 -366 minecraft:water[level=0]
setblock 147 61 -366 minecraft:seagrass
setblock 148 61 -366 minecraft:water[level=0]
fill 136 61 -367 148 61 -367 minecraft:water[level=0]
setblock 149 61 -367 minecraft:seagrass
setblock 150 61 -367 minecraft:tall_seagrass[half=lower]
setblock 151 61 -367 minecraft:water[level=0]
fill 136 61 -368 151 61 -368 minecraft:water[level=0]
setblock 152 61 -368 minecraft:seagrass
setblock 153 61 -368 minecraft:water[level=0]
fill 136 61 -369 152 61 -369 minecraft:water[level=0]
setblock 153 61 -369 minecraft:tall_seagrass[half=upper]
fill 154 61 -369 155 61 -369 minecraft:water[level=0]
fill 136 61 -370 156 61 -370 minecraft:water[level=0]
fill 136 61 -371 157 61 -371 minecraft:water[level=0]
fill 136 61 -372 158 61 -372 minecraft:water[level=0]
fill 136 61 -373 159 61 -373 minecraft:water[level=0]
fill 136 61 -374 158 61 -374 minecraft:water[level=0]
setblock 159 61 -374 minecraft:seagrass
setblock 160 61 -374 minecraft:water[level=0]
fill 136 61 -375 160 61 -375 minecraft:water[level=0]
setblock 161 61 -375 minecraft:tall_seagrass[half=lower]
fill 136 61 -376 160 61 -376 minecraft:water[level=0]
setblock 161 61 -376 minecraft:tall_seagrass[half=lower]
setblock 162 61 -376 minecraft:water[level=0]
fill 136 61 -377 163 61 -377 minecraft:water[level=0]
fill 136 61 -378 159 61 -378 minecraft:water[level=0]
setblock 160 61 -378 minecraft:tall_seagrass[half=upper]
fill 161 61 -378 168 61 -378 minecraft:water[level=0]
fill 136 61 -379 171 61 -379 minecraft:water[level=0]
fill 136 61 -380 161 61 -380 minecraft:water[level=0]
setblock 162 61 -380 minecraft:tall_seagrass[half=upper]
fill 163 61 -380 172 61 -380 minecraft:water[level=0]
fill 136 61 -381 165 61 -381 minecraft:water[level=0]
setblock 166 61 -381 minecraft:tall_seagrass[half=upper]
fill 167 61 -381 173 61 -381 minecraft:water[level=0]
fill 136 61 -382 174 61 -382 minecraft:water[level=0]
setblock 151 60 -323 minecraft:air
fill 152 60 -325 156 60 -325 minecraft:water[level=0]
fill 153 60 -326 156 60 -326 minecraft:water[level=0]
fill 182 60 -346 183 60 -346 minecraft:water[level=0]
setblock 182 60 -347 minecraft:water[level=0]
setblock 139 60 -363 minecraft:water[level=0]
setblock 140 60 -363 minecraft:seagrass
fill 141 60 -363 144 60 -363 minecraft:water[level=0]
setblock 137 60 -364 minecraft:tall_seagrass[half=lower]
setblock 138 60 -364 minecraft:seagrass
setblock 139 60 -364 minecraft:tall_seagrass[half=lower]
fill 140 60 -364 143 60 -364 minecraft:water[level=0]
setblock 144 60 -364 minecraft:seagrass
fill 136 60 -365 140 60 -365 minecraft:water[level=0]
setblock 141 60 -365 minecraft:tall_seagrass[half=upper]
fill 142 60 -365 144 60 -365 minecraft:water[level=0]
setblock 145 60 -365 minecraft:seagrass
fill 136 60 -366 145 60 -366 minecraft:water[level=0]
setblock 146 60 -366 minecraft:seagrass
fill 136 60 -367 143 60 -367 minecraft:water[level=0]
setblock 144 60 -367 minecraft:tall_seagrass[half=upper]
fill 145 60 -367 146 60 -367 minecraft:water[level=0]
setblock 147 60 -367 minecraft:seagrass
fill 136 60 -368 146 60 -368 minecraft:water[level=0]
fill 147 60 -368 148 60 -368 minecraft:seagrass
fill 149 60 -368 151 60 -368 minecraft:water[level=0]
fill 136 60 -369 146 60 -369 minecraft:water[level=0]
setblock 147 60 -369 minecraft:tall_seagrass[half=upper]
fill 148 60 -369 152 60 -369 minecraft:water[level=0]
setblock 153 60 -369 minecraft:tall_seagrass[half=lower]
fill 136 60 -370 154 60 -370 minecraft:water[level=0]
fill 136 60 -371 156 60 -371 minecraft:water[level=0]
fill 136 60 -372 157 60 -372 minecraft:water[level=0]
fill 136 60 -373 157 60 -373 minecraft:water[level=0]
fill 136 60 -374 157 60 -374 minecraft:water[level=0]
setblock 158 60 -374 minecraft:seagrass
fill 136 60 -375 159 60 -375 minecraft:water[level=0]
fill 136 60 -376 158 60 -376 minecraft:water[level=0]
setblock 159 60 -376 minecraft:seagrass
setblock 160 60 -376 minecraft:water[level=0]
fill 136 60 -377 160 60 -377 minecraft:water[level=0]
fill 136 60 -378 159 60 -378 minecraft:water[level=0]
setblock 160 60 -378 minecraft:tall_seagrass[half=lower]
setblock 161 60 -378 minecraft:water[level=0]
fill 136 60 -379 163 60 -379 minecraft:water[level=0]
fill 136 60 -380 161 60 -380 minecraft:water[level=0]
setblock 162 60 -380 minecraft:tall_seagrass[half=lower]
fill 163 60 -380 169 60 -380 minecraft:water[level=0]
fill 136 60 -381 160 60 -381 minecraft:water[level=0]
fill 161 60 -381 162 60 -381 minecraft:tall_seagrass[half=upper]
fill 163 60 -381 164 60 -381 minecraft:water[level=0]
setblock 165 60 -381 minecraft:seagrass
setblock 166 60 -381 minecraft:tall_seagrass[half=lower]
fill 167 60 -381 170 60 -381 minecraft:water[level=0]
fill 136 60 -382 171 60 -382 minecraft:water[level=0]
setblock 151 59 -323 minecraft:air
fill 152 59 -325 156 59 -325 minecraft:water[level=0]
fill 153 59 -326 156 59 -326 minecraft:water[level=0]
fill 181 59 -346 182 59 -346 minecraft:water[level=0]
fill 181 59 -347 182 59 -347 minecraft:water[level=0]
setblock 140 59 -365 minecraft:water[level=0]
setblock 141 59 -365 minecraft:tall_seagrass[half=lower]
setblock 142 59 -365 minecraft:water[level=0]
setblock 143 59 -365 minecraft:seagrass
setblock 144 59 -365 minecraft:water[level=0]
fill 138 59 -366 144 59 -366 minecraft:water[level=0]
fill 136 59 -367 137 59 -367 minecraft:seagrass
fill 138 59 -367 143 59 -367 minecraft:water[level=0]
setblock 144 59 -367 minecraft:tall_seagrass[half=lower]
setblock 145 59 -367 minecraft:water[level=0]
fill 136 59 -368 145 59 -368 minecraft:water[level=0]
setblock 146 59 -368 minecraft:seagrass
fill 136 59 -369 143 59 -369 minecraft:water[level=0]
setblock 144 59 -369 minecraft:tall_seagrass[half=upper]
setblock 145 59 -369 minecraft:water[level=0]
setblock 146 59 -369 minecraft:seagrass
setblock 147 59 -369 minecraft:tall_seagrass[half=lower]
fill 148 59 -369 149 59 -369 minecraft:seagrass
fill 136 59 -370 148 59 -370 minecraft:water[level=0]
fill 149 59 -370 150 59 -370 minecraft:seagrass
setblock 151 59 -370 minecraft:water[level=0]
setblock 152 59 -370 minecraft:seagrass
fill 136 59 -371 149 59 -371 minecraft:water[level=0]
setblock 150 59 -371 minecraft:tall_seagrass[half=upper]
fill 151 59 -371 154 59 -371 minecraft:water[level=0]
fill 136 59 -372 156 59 -372 minecraft:water[level=0]
fill 136 59 -373 156 59 -373 minecraft:water[level=0]
fill 136 59 -374 157 59 -374 minecraft:water[level=0]
fill 136 59 -375 157 59 -375 minecraft:water[level=0]
fill 136 59 -376 158 59 -376 minecraft:water[level=0]
fill 136 59 -377 158 59 -377 minecraft:water[level=0]
fill 136 59 -378 159 59 -378 minecraft:water[level=0]
fill 136 59 -379 158 59 -379 minecraft:water[level=0]
setblock 159 59 -379 minecraft:seagrass
setblock 160 59 -379 minecraft:water[level=0]
fill 136 59 -380 158 59 -380 minecraft:water[level=0]
setblock 159 59 -380 minecraft:seagrass
fill 160 59 -380 161 59 -380 minecraft:water[level=0]
fill 136 59 -381 160 59 -381 minecraft:water[level=0]
fill 161 59 -381 162 59 -381 minecraft:tall_seagrass[half=lower]
fill 136 59 -382 157 59 -382 minecraft:water[level=0]
setblock 158 59 -382 minecraft:tall_seagrass[half=upper]
fill 159 59 -382 161 59 -382 minecraft:water[level=0]
fill 162 59 -382 163 59 -382 minecraft:seagrass
setblock 151 58 -323 minecraft:air
fill 152 58 -325 156 58 -325 minecraft:water[level=0]
fill 153 58 -326 156 58 -326 minecraft:water[level=0]
fill 181 58 -346 182 58 -346 minecraft:water[level=0]
fill 181 58 -347 182 58 -347 minecraft:water[level=0]
fill 139 58 -368 143 58 -368 minecraft:water[level=0]
fill 137 58 -369 143 58 -369 minecraft:water[level=0]
setblock 144 58 -369 minecraft:tall_seagrass[half=lower]
setblock 145 58 -369 minecraft:seagrass
fill 136 58 -370 143 58 -370 minecraft:water[level=0]
fill 144 58 -370 145 58 -370 minecraft:seagrass
setblock 146 58 -370 minecraft:water[level=0]
setblock 147 58 -370 minecraft:seagrass
fill 136 58 -371 144 58 -371 minecraft:water[level=0]
setblock 145 58 -371 minecraft:seagrass
setblock 146 58 -371 minecraft:water[level=0]
setblock 147 58 -371 minecraft:seagrass
fill 148 58 -371 149 58 -371 minecraft:water[level=0]
setblock 150 58 -371 minecraft:tall_seagrass[half=lower]
fill 151 58 -371 152 58 -371 minecraft:water[level=0]
fill 136 58 -372 144 58 -372 minecraft:water[level=0]
setblock 145 58 -372 minecraft:tall_seagrass[half=upper]
fill 146 58 -372 148 58 -372 minecraft:water[level=0]
setblock 149 58 -372 minecraft:tall_seagrass[half=upper]
fill 150 58 -372 154 58 -372 minecraft:water[level=0]
fill 136 58 -373 152 58 -373 minecraft:water[level=0]
setblock 153 58 -373 minecraft:tall_seagrass[half=upper]
fill 154 58 -373 155 58 -373 minecraft:water[level=0]
fill 136 58 -374 155 58 -374 minecraft:water[level=0]
fill 136 58 -375 156 58 -375 minecraft:water[level=0]
fill 136 58 -376 156 58 -376 minecraft:water[level=0]
fill 136 58 -377 157 58 -377 minecraft:water[level=0]
fill 136 58 -378 154 58 -378 minecraft:water[level=0]
setblock 155 58 -378 minecraft:tall_seagrass[half=upper]
fill 156 58 -378 157 58 -378 minecraft:water[level=0]
fill 136 58 -379 157 58 -379 minecraft:water[level=0]
setblock 158 58 -379 minecraft:seagrass
fill 136 58 -380 158 58 -380 minecraft:water[level=0]
fill 136 58 -381 159 58 -381 minecraft:water[level=0]
fill 136 58 -382 157 58 -382 minecraft:water[level=0]
setblock 158 58 -382 minecraft:tall_seagrass[half=lower]
setblock 159 58 -382 minecraft:seagrass
setblock 151 57 -323 minecraft:air
fill 152 57 -325 156 57 -325 minecraft:water[level=0]
fill 153 57 -326 157 57 -326 minecraft:water[level=0]
setblock 182 57 -346 minecraft:water[level=0]
setblock 181 57 -347 minecraft:water[level=0]
fill 139 57 -371 141 57 -371 minecraft:water[level=0]
setblock 142 57 -371 minecraft:seagrass
fill 143 57 -371 144 57 -371 minecraft:water[level=0]
fill 136 57 -372 144 57 -372 minecraft:water[level=0]
setblock 145 57 -372 minecraft:tall_seagrass[half=lower]
fill 146 57 -372 148 57 -372 minecraft:water[level=0]
setblock 149 57 -372 minecraft:tall_seagrass[half=lower]
fill 150 57 -372 152 57 -372 minecraft:water[level=0]
fill 136 57 -373 141 57 -373 minecraft:water[level=0]
setblock 142 57 -373 minecraft:tall_seagrass[half=upper]
fill 143 57 -373 152 57 -373 minecraft:water[level=0]
setblock 153 57 -373 minecraft:tall_seagrass[half=lower]
fill 136 57 -374 144 57 -374 minecraft:water[level=0]
setblock 145 57 -374 minecraft:tall_seagrass[half=upper]
fill 146 57 -374 147 57 -374 minecraft:water[level=0]
setblock 148 57 -374 minecraft:tall_seagrass[half=upper]
fill 149 57 -374 153 57 -374 minecraft:water[level=0]
fill 136 57 -375 154 57 -375 minecraft:water[level=0]
fill 136 57 -376 155 57 -376 minecraft:water[level=0]
fill 136 57 -377 155 57 -377 minecraft:water[level=0]
fill 136 57 -378 154 57 -378 minecraft:water[level=0]
setblock 155 57 -378 minecraft:tall_seagrass[half=lower]
fill 136 57 -379 156 57 -379 minecraft:water[level=0]
fill 136 57 -380 154 57 -380 minecraft:water[level=0]
setblock 155 57 -380 minecraft:seagrass
setblock 156 57 -380 minecraft:water[level=0]
fill 136 57 -381 157 57 -381 minecraft:water[level=0]
fill 136 57 -382 157 57 -382 minecraft:water[level=0]
setblock 151 56 -323 minecraft:air
fill 152 56 -325 156 56 -325 minecraft:water[level=0]
fill 153 56 -326 157 56 -326 minecraft:water[level=0]
fill 180 56 -347 181 56 -347 minecraft:water[level=0]
fill 180 56 -348 181 56 -348 minecraft:water[level=0]
fill 139 56 -373 141 56 -373 minecraft:water[level=0]
setblock 142 56 -373 minecraft:tall_seagrass[half=lower]
fill 136 56 -374 142 56 -374 minecraft:water[level=0]
setblock 143 56 -374 minecraft:seagrass
setblock 144 56 -374 minecraft:water[level=0]
setblock 145 56 -374 minecraft:tall_seagrass[half=lower]
setblock 146 56 -374 minecraft:water[level=0]
setblock 147 56 -374 minecraft:seagrass
setblock 148 56 -374 minecraft:tall_seagrass[half=lower]
setblock 149 56 -374 minecraft:water[level=0]
fill 136 56 -375 143 56 -375 minecraft:water[level=0]
setblock 144 56 -375 minecraft:seagrass
fill 145 56 -375 146 56 -375 minecraft:water[level=0]
setblock 147 56 -375 minecraft:seagrass
fill 148 56 -375 152 56 -375 minecraft:water[level=0]
fill 136 56 -376 151 56 -376 minecraft:water[level=0]
setblock 152 56 -376 minecraft:seagrass
setblock 153 56 -376 minecraft:water[level=0]
fill 136 56 -377 137 56 -377 minecraft:water[level=0]
setblock 138 56 -377 minecraft:seagrass
fill 139 56 -377 142 56 -377 minecraft:water[level=0]
setblock 143 56 -377 minecraft:seagrass
fill 144 56 -377 153 56 -377 minecraft:water[level=0]
fill 136 56 -378 154 56 -378 minecraft:water[level=0]
fill 136 56 -379 154 56 -379 minecraft:water[level=0]
fill 136 56 -380 139 56 -380 minecraft:water[level=0]
setblock 140 56 -380 minecraft:tall_seagrass[half=upper]
fill 141 56 -380 154 56 -380 minecraft:water[level=0]
fill 136 56 -381 144 56 -381 minecraft:water[level=0]
setblock 145 56 -381 minecraft:tall_seagrass[half=upper]
fill 146 56 -381 155 56 -381 minecraft:water[level=0]
setblock 136 56 -382 minecraft:tall_seagrass[half=upper]
fill 137 56 -382 154 56 -382 minecraft:water[level=0]
setblock 155 56 -382 minecraft:seagrass
setblock 151 55 -323 minecraft:air
fill 154 55 -325 158 55 -325 minecraft:water[level=0]
fill 154 55 -326 158 55 -326 minecraft:water[level=0]
fill 180 55 -347 181 55 -347 minecraft:water[level=0]
fill 180 55 -348 181 55 -348 minecraft:water[level=0]
fill 137 55 -378 142 55 -378 minecraft:water[level=0]
fill 136 55 -379 144 55 -379 minecraft:water[level=0]
setblock 136 55 -380 minecraft:water[level=0]
setblock 137 55 -380 minecraft:seagrass
fill 138 55 -380 139 55 -380 minecraft:water[level=0]
setblock 140 55 -380 minecraft:tall_seagrass[half=lower]
fill 141 55 -380 142 55 -380 minecraft:water[level=0]
fill 143 55 -380 144 55 -380 minecraft:seagrass
fill 145 55 -380 146 55 -380 minecraft:water[level=0]
fill 136 55 -381 144 55 -381 minecraft:water[level=0]
setblock 145 55 -381 minecraft:tall_seagrass[half=lower]
setblock 146 55 -381 minecraft:water[level=0]
setblock 147 55 -381 minecraft:seagrass
setblock 148 55 -381 minecraft:water[level=0]
setblock 136 55 -382 minecraft:tall_seagrass[half=lower]
fill 137 55 -382 139 55 -382 minecraft:water[level=0]
setblock 140 55 -382 minecraft:seagrass
setblock 141 55 -382 minecraft:water[level=0]
setblock 142 55 -382 minecraft:seagrass
fill 143 55 -382 148 55 -382 minecraft:water[level=0]
setblock 151 54 -323 minecraft:air
fill 155 54 -324 159 54 -324 minecraft:water[level=0]
fill 155 54 -325 159 54 -325 minecraft:water[level=0]
setblock 181 54 -347 minecraft:water[level=0]
fill 180 54 -348 181 54 -348 minecraft:water[level=0]
setblock 180 54 -349 minecraft:water[level=0]
setblock 151 53 -323 minecraft:air
fill 157 53 -324 161 53 -324 minecraft:water[level=0]
fill 157 53 -325 161 53 -325 minecraft:water[level=0]
fill 180 53 -348 181 53 -348 minecraft:water[level=0]
setblock 180 53 -349 minecraft:water[level=0]
setblock 151 52 -323 minecraft:air
fill 159 52 -323 163 52 -323 minecraft:water[level=0]
fill 158 52 -324 162 52 -324 minecraft:water[level=0]
fill 159 52 -325 162 52 -325 minecraft:water[level=0]
setblock 180 52 -348 minecraft:water[level=0]
setblock 180 52 -349 minecraft:water[level=0]
setblock 151 51 -323 minecraft:air
fill 160 51 -323 165 51 -323 minecraft:water[level=0]
fill 160 51 -324 164 51 -324 minecraft:water[level=0]
fill 179 51 -349 180 51 -349 minecraft:water[level=0]
fill 179 51 -350 180 51 -350 minecraft:water[level=0]
fill 163 50 -322 165 50 -322 minecraft:water[level=0]
setblock 151 50 -323 minecraft:air
fill 162 50 -323 164 50 -323 minecraft:water[level=0]
fill 162 50 -324 164 50 -324 minecraft:water[level=0]
fill 179 50 -349 180 50 -349 minecraft:water[level=0]
fill 179 50 -350 180 50 -350 minecraft:water[level=0]
fill 179 50 -351 180 50 -351 minecraft:water[level=0]
setblock 168 49 -322 minecraft:air
setblock 151 49 -323 minecraft:air
fill 179 49 -350 180 49 -350 minecraft:water[level=0]
fill 179 49 -351 180 49 -351 minecraft:water[level=0]
fill 167 48 -322 169 48 -322 minecraft:air
setblock 151 48 -323 minecraft:air
fill 166 48 -323 168 48 -323 minecraft:air
fill 166 48 -324 168 48 -324 minecraft:air
setblock 136 48 -327 minecraft:water[level=0]
fill 136 48 -328 137 48 -328 minecraft:water[level=0]
fill 136 48 -329 139 48 -329 minecraft:water[level=0]
fill 136 48 -330 140 48 -330 minecraft:water[level=0]
fill 136 48 -331 141 48 -331 minecraft:water[level=0]
fill 136 48 -332 141 48 -332 minecraft:water[level=0]
fill 136 48 -333 142 48 -333 minecraft:water[level=0]
fill 136 48 -334 142 48 -334 minecraft:water[level=0]
fill 136 48 -335 143 48 -335 minecraft:water[level=0]
fill 136 48 -336 144 48 -336 minecraft:water[level=0]
fill 136 48 -337 143 48 -337 minecraft:water[level=0]
fill 136 48 -338 143 48 -338 minecraft:water[level=0]
fill 136 48 -339 142 48 -339 minecraft:water[level=0]
fill 136 48 -340 142 48 -340 minecraft:water[level=0]
fill 136 48 -341 141 48 -341 minecraft:water[level=0]
fill 136 48 -342 140 48 -342 minecraft:water[level=0]
fill 136 48 -343 138 48 -343 minecraft:water[level=0]
fill 179 48 -350 180 48 -350 minecraft:water[level=0]
setblock 179 48 -351 minecraft:water[level=0]
fill 178 48 -352 179 48 -352 minecraft:water[level=0]
setblock 168 47 -321 minecraft:air
fill 168 47 -322 170 47 -322 minecraft:air
setblock 151 47 -323 minecraft:air
fill 167 47 -323 170 47 -323 minecraft:air
fill 167 47 -324 169 47 -324 minecraft:air
setblock 136 47 -330 minecraft:water[level=0]
fill 136 47 -331 137 47 -331 minecraft:water[level=0]
fill 136 47 -332 138 47 -332 minecraft:water[level=0]
fill 136 47 -333 138 47 -333 minecraft:water[level=0]
fill 136 47 -334 139 47 -334 minecraft:water[level=0]
fill 136 47 -335 140 47 -335 minecraft:water[level=0]
fill 136 47 -336 140 47 -336 minecraft:water[level=0]
fill 136 47 -337 140 47 -337 minecraft:water[level=0]
fill 136 47 -338 139 47 -338 minecraft:water[level=0]
fill 136 47 -339 139 47 -339 minecraft:water[level=0]
fill 136 47 -340 139 47 -340 minecraft:water[level=0]
fill 136 47 -341 137 47 -341 minecraft:water[level=0]
fill 179 47 -351 180 47 -351 minecraft:water[level=0]
fill 179 47 -352 180 47 -352 minecraft:water[level=0]
fill 169 46 -322 171 46 -322 minecraft:air
setblock 151 46 -323 minecraft:air
fill 169 46 -323 171 46 -323 minecraft:air
fill 168 46 -324 170 46 -324 minecraft:air
setblock 165 46 -337 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
setblock 164 46 -338 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 179 46 -352 180 46 -352 minecraft:water[level=0]
fill 179 46 -353 180 46 -353 minecraft:water[level=0]
fill 170 45 -322 172 45 -322 minecraft:air
setblock 151 45 -323 minecraft:air
fill 170 45 -323 172 45 -323 minecraft:air
fill 169 45 -324 172 45 -324 minecraft:air
setblock 171 45 -325 minecraft:air
setblock 164 45 -337 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 164 45 -338 165 45 -338 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 179 45 -352 180 45 -352 minecraft:water[level=0]
fill 179 45 -353 180 45 -353 minecraft:water[level=0]
fill 179 45 -354 180 45 -354 minecraft:water[level=0]
forceload remove 136 -382 199 -319
tellraw @a {"text":"Campus zurueck a10 fertig.","color":"green"}
