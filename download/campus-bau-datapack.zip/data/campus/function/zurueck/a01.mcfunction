# Abschnitt a01: x 8..71, z -446..-383 (49473 Blöcke)
forceload add 8 -446 71 -383
tellraw @a {"text":"Campus zurueck a01: Chunks werden geladen …","color":"gray"}
schedule function campus:zurueck/a01_1 2s
