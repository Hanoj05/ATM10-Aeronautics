setblock 142 85 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 141 85 -118 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 142 85 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 85 -118 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 142 85 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 142 84 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 83 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 83 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 83 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 83 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 83 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 83 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 82 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 82 -116 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 82 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 82 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 82 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 82 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 82 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 82 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 82 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 82 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 82 -118 minecraft:spruce_log[axis=y]
setblock 143 82 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 82 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 82 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 82 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 82 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 82 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 82 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 82 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 82 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 82 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 82 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 82 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 82 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 82 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 82 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 82 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 82 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 82 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 82 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 82 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 82 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 82 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 82 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 81 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 81 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 141 81 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 81 -118 minecraft:spruce_log[axis=y]
setblock 143 81 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 81 -118 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 81 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 81 -118 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 142 81 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 81 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 81 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 81 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 81 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 81 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 81 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 81 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 81 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 152 81 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 141 80 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 80 -116 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 80 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 80 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 80 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 80 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 80 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 80 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 80 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 80 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 80 -118 minecraft:spruce_log[axis=y]
setblock 143 80 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 80 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 80 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 80 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 80 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 80 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 80 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 80 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 80 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 80 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 80 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 80 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 80 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 80 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 80 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 80 -124 minecraft:spruce_log[axis=y]
setblock 151 80 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 80 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 80 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 80 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 80 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 80 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 80 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 80 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 80 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 80 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 80 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 79 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 79 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 79 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 79 -118 minecraft:spruce_log[axis=y]
setblock 143 79 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 79 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 79 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 79 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 79 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 79 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 79 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 79 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 79 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 79 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 79 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 79 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 79 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 79 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 79 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 79 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 79 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 79 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 79 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 79 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 79 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 152 79 -123 153 79 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 79 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 79 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 79 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 79 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 79 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 79 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 79 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 79 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 79 -124 minecraft:spruce_log[axis=y]
setblock 151 79 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
fill 152 79 -124 153 79 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 79 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 79 -124 minecraft:spruce_log[axis=y]
setblock 156 79 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 79 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 79 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 79 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 79 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 79 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 79 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 79 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 79 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 152 79 -125 153 79 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 79 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 79 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 79 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 79 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 79 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 183 79 -125 184 79 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 79 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 79 -125 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 149 79 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 79 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 79 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 79 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 79 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 79 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 79 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 79 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 79 -126 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
fill 182 79 -126 183 79 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 79 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 79 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 79 -126 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 79 -126 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 141 78 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 78 -116 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 78 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 78 -116 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 78 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 78 -116 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 140 78 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 78 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 78 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 78 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 78 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 78 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 78 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 78 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 78 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 78 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 140 78 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 78 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 78 -118 minecraft:spruce_log[axis=y]
setblock 143 78 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 78 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 78 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 78 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 78 -118 minecraft:spruce_log[axis=y]
setblock 156 78 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 78 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 78 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 78 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 78 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 78 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 78 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 78 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 78 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 78 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 78 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 78 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 78 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 78 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 78 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 78 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 78 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 78 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 78 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 78 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 78 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 78 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 78 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 78 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 78 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 78 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 78 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 78 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 78 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 78 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 78 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 78 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 78 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 78 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 78 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 78 -124 minecraft:spruce_log[axis=y]
setblock 151 78 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 78 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 78 -124 minecraft:spruce_log[axis=y]
setblock 156 78 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 78 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 78 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 78 -124 minecraft:spruce_log[axis=y]
setblock 183 78 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 78 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 78 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 78 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 78 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 78 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 78 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 78 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 78 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 78 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 78 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 78 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 78 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 78 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 78 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 78 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 78 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 77 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 77 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 77 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 77 -118 minecraft:spruce_log[axis=y]
setblock 143 77 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 77 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 77 -118 minecraft:spruce_log[axis=y]
setblock 156 77 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 77 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 77 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 77 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 77 -121 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 77 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 77 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 77 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 77 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 77 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 77 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 77 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 77 -122 minecraft:spruce_log[axis=y]
setblock 166 77 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 77 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 77 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 77 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 77 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 152 77 -123 153 77 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 77 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 77 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 77 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 77 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 77 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 77 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 77 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 77 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 77 -124 minecraft:spruce_log[axis=y]
setblock 151 77 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
fill 152 77 -124 153 77 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 77 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 77 -124 minecraft:spruce_log[axis=y]
setblock 156 77 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 77 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 77 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 77 -124 minecraft:spruce_log[axis=y]
setblock 183 77 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 77 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 77 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 77 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 77 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 152 77 -125 153 77 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 77 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 77 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 77 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 77 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 77 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 77 -126 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 141 77 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 77 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 77 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 77 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 77 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 77 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 77 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 77 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 77 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 77 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 76 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 76 -116 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 76 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 76 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 76 -116 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 76 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 76 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 76 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 76 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 76 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 76 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 76 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 76 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 76 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 76 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 76 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 76 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 76 -118 minecraft:spruce_log[axis=y]
setblock 143 76 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 76 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 76 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 76 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 76 -118 minecraft:spruce_log[axis=y]
setblock 156 76 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 76 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 76 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 76 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 76 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 76 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 76 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 76 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 76 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 76 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 76 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 76 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 76 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 76 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 76 -119 minecraft:spruce_log[axis=y]
setblock 185 76 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 76 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 76 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 76 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 76 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 76 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 76 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 76 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 76 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 76 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 76 -120 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 76 -121 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 149 76 -121 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 150 76 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 151 76 -121 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 152 76 -121 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 163 76 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 76 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 76 -121 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 76 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 76 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 76 -122 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 148 76 -122 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 149 76 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 76 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 76 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 152 76 -122 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 153 76 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 76 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 76 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 76 -122 minecraft:spruce_log[axis=y]
setblock 166 76 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 76 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 76 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 76 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 76 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 76 -123 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 148 76 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 76 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 76 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 153 76 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 76 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 76 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 76 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 76 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 76 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 76 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 76 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 76 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 76 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 76 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 76 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 76 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 76 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 76 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 76 -124 minecraft:spruce_log[axis=y]
setblock 151 76 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 76 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 76 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 76 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 76 -124 minecraft:spruce_log[axis=y]
setblock 156 76 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 76 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 76 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 76 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 76 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 76 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 76 -124 minecraft:spruce_log[axis=y]
setblock 183 76 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 76 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 76 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 76 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 76 -125 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 147 76 -125 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 148 76 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 76 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 76 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 76 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 76 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 76 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 76 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 76 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 76 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 76 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 76 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 76 -125 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 140 76 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 76 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 76 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 76 -126 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 76 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 76 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 76 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 76 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 76 -126 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 76 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 76 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 76 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 76 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 76 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 76 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 76 -126 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 76 -126 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 197 76 -126 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 76 -126 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 75 -117 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 139 75 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 75 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 75 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 75 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 75 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 75 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 75 -118 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 141 75 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 75 -118 minecraft:spruce_log[axis=y]
setblock 143 75 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 75 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 75 -118 minecraft:spruce_log[axis=y]
setblock 156 75 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 75 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 75 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 75 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 75 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 75 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 75 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 75 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 75 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 75 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 75 -119 minecraft:spruce_log[axis=y]
setblock 185 75 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 75 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 75 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 75 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 75 -120 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 75 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 75 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 75 -121 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 75 -121 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 181 75 -121 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 75 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 75 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 75 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 75 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 75 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 75 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 75 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 75 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 75 -122 minecraft:spruce_log[axis=y]
setblock 166 75 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 75 -122 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 180 75 -122 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 181 75 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 75 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 75 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 75 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 75 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 75 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 75 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 75 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 75 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 75 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 75 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 75 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 75 -123 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 180 75 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 75 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 75 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 75 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 75 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 185 75 -123 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 145 75 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 75 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 75 -124 minecraft:spruce_log[axis=y]
setblock 151 75 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 75 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 75 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 75 -124 minecraft:spruce_log[axis=y]
setblock 156 75 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 75 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 75 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 75 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 75 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 75 -124 minecraft:spruce_log[axis=y]
setblock 183 75 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 75 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 75 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 140 75 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 75 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 75 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 75 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 75 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 75 -125 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 75 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 75 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 75 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 75 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 75 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 75 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 75 -125 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 180 75 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 75 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 75 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 183 75 -125 184 75 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 75 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 140 75 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 75 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 75 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 75 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 75 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 75 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 75 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 75 -126 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 180 75 -126 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 181 75 -126 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
fill 182 75 -126 183 75 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 75 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 75 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 75 -126 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 139 74 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 74 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 74 -116 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 74 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 74 -116 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 74 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 74 -116 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 138 74 -117 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 74 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 74 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 74 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 74 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 74 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 74 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 74 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 74 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 74 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 74 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 74 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 139 74 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 74 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 74 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 74 -118 minecraft:spruce_log[axis=y]
setblock 143 74 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 74 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 74 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 74 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 74 -118 minecraft:spruce_log[axis=y]
setblock 156 74 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 74 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 74 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 74 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 74 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 74 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 74 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 74 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 74 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 74 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 74 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 74 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 74 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 74 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 74 -119 minecraft:spruce_log[axis=y]
setblock 185 74 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 74 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 74 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 74 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 74 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 74 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 74 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 74 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 74 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 74 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 74 -120 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 74 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 74 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 74 -121 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 74 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 74 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 74 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 74 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 74 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 74 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 74 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 74 -122 minecraft:spruce_log[axis=y]
setblock 166 74 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 74 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 74 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 74 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 74 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 74 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 74 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 74 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 74 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 74 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 74 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 74 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 74 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 74 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 74 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 74 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 74 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 74 -124 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 74 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 74 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 74 -124 minecraft:spruce_log[axis=y]
setblock 151 74 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 74 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 74 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 74 -124 minecraft:spruce_log[axis=y]
setblock 156 74 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 74 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 74 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 74 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 74 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 74 -124 minecraft:spruce_log[axis=y]
setblock 183 74 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 74 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 74 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 74 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 74 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 74 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 74 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 74 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 74 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 74 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 74 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 74 -125 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 74 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 74 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 74 -126 minecraft:birch_log[axis=y]
setblock 142 74 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 74 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 74 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 74 -126 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 74 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 74 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 74 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 74 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 74 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 74 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 74 -126 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 74 -126 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 74 -126 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 73 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 73 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 73 -116 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 138 73 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 73 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 73 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 73 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 73 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 73 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 73 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 73 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 138 73 -118 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 139 73 -118 140 73 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 73 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 73 -118 minecraft:spruce_log[axis=y]
setblock 143 73 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 73 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 73 -118 minecraft:spruce_log[axis=y]
setblock 156 73 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 73 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 73 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 73 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 73 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 73 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 73 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 73 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 73 -119 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 164 73 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 73 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 73 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 167 73 -119 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 73 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 73 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 73 -119 minecraft:spruce_log[axis=y]
setblock 185 73 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 73 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -120 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 163 73 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 73 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 73 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 73 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 73 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 168 73 -120 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 73 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 73 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 73 -120 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 73 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 73 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 73 -121 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 149 73 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 73 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 73 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 152 73 -121 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 162 73 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 73 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 73 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 73 -121 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 73 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 73 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 73 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 73 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 73 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 73 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 73 -122 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 148 73 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 73 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 73 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 73 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 152 73 -122 153 73 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 73 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 73 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 73 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 73 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 73 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 73 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 73 -122 minecraft:spruce_log[axis=y]
setblock 166 73 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 73 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 73 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 73 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 73 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 73 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 73 -123 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 73 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 73 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 73 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 73 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 73 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 152 73 -123 153 73 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 73 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 73 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 73 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 73 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 73 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 73 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 73 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 73 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 73 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 73 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 73 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 73 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 73 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 73 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 73 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 73 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 73 -124 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 73 -124 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 73 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 73 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 73 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 73 -124 minecraft:spruce_log[axis=y]
setblock 151 73 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
fill 152 73 -124 153 73 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 73 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 73 -124 minecraft:spruce_log[axis=y]
setblock 156 73 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 73 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -124 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 163 73 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 73 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 73 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 73 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 73 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 168 73 -124 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 180 73 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 73 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 73 -124 minecraft:spruce_log[axis=y]
setblock 183 73 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 73 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 73 -125 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 73 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 145 73 -125 minecraft:birch_log[axis=y]
setblock 146 73 -125 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 73 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 73 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 73 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 73 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
fill 151 73 -125 152 73 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 73 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 73 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 73 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 73 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 73 -125 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 164 73 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 73 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 73 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 167 73 -125 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 180 73 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 73 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 73 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 73 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 73 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 73 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 73 -125 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 196 73 -125 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 197 73 -125 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 73 -125 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 73 -125 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 73 -126 minecraft:birch_log[axis=y]
setblock 144 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 73 -126 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 73 -126 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 147 73 -126 148 73 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 149 73 -126 151 73 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 73 -126 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 73 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 73 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 73 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 73 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 73 -126 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 160 73 -126 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 161 73 -126 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 181 73 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 73 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 73 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 73 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 73 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 73 -126 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 73 -126 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 196 73 -126 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 73 -126 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 73 -126 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 73 -126 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 72 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 72 -116 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 72 -116 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 72 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 72 -116 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 72 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 72 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 72 -116 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 72 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 72 -116 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 183 72 -116 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 72 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 72 -116 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 72 -116 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 137 72 -117 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 72 -117 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 139 72 -117 minecraft:birch_log[axis=y]
setblock 140 72 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 72 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 72 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 72 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 72 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 72 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 72 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 72 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 72 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 72 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -117 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 72 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 72 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 72 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 72 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 72 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 72 -117 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 138 72 -118 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 72 -118 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 72 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 72 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 72 -118 minecraft:spruce_log[axis=y]
setblock 143 72 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 72 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 72 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 72 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 72 -118 minecraft:spruce_log[axis=y]
setblock 156 72 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 72 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 72 -118 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 72 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 72 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 72 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 72 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 72 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 72 -118 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 139 72 -119 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 72 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 72 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 72 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 72 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 72 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 72 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 72 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 72 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 72 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 72 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 72 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 72 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 72 -119 minecraft:spruce_log[axis=y]
setblock 185 72 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 72 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 72 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 72 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 72 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 72 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 72 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 72 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 72 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 72 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 72 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 72 -120 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 72 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 72 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 72 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 72 -121 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 72 -121 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 181 72 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
fill 182 72 -121 183 72 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 72 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 72 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 72 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 72 -121 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 164 72 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 72 -122 minecraft:spruce_log[axis=y]
setblock 166 72 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 72 -122 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 180 72 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 72 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 72 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 183 72 -122 184 72 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 72 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 72 -122 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 155 72 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 72 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 72 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 72 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 72 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 72 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 72 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 72 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 72 -124 minecraft:spruce_log[axis=y]
setblock 154 72 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 72 -124 minecraft:spruce_log[axis=y]
setblock 156 72 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 72 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 72 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 72 -124 minecraft:spruce_log[axis=y]
setblock 183 72 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 72 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 72 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 72 -125 minecraft:birch_log[axis=y]
setblock 155 72 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 72 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 72 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 72 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 72 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 72 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 72 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 72 -125 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 72 -125 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 72 -125 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 72 -125 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 72 -126 minecraft:birch_log[axis=y]
setblock 142 72 -126 minecraft:air
setblock 152 72 -126 minecraft:air
setblock 159 72 -126 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 160 72 -126 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 72 -126 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 162 72 -126 minecraft:air
setblock 172 72 -126 minecraft:air
setblock 179 72 -126 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 180 72 -126 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 72 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 72 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 72 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 72 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 72 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 72 -126 minecraft:air
setblock 196 72 -126 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 72 -126 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 72 -126 regions_unexplored:maple_branch[facing=south]
setblock 199 72 -126 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 139 71 -117 minecraft:birch_log[axis=y]
setblock 155 71 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 71 -118 minecraft:spruce_log[axis=y]
setblock 154 71 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 71 -118 minecraft:spruce_log[axis=y]
setblock 156 71 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 71 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 71 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 71 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 71 -119 minecraft:spruce_log[axis=y]
setblock 185 71 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 71 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 71 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 71 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 71 -120 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 71 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 71 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 71 -121 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 71 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 71 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 71 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 71 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 71 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 71 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 71 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 71 -122 minecraft:spruce_log[axis=y]
setblock 166 71 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 71 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 71 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 71 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 71 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 71 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 71 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 71 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 71 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 71 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 71 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 71 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 71 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 71 -124 minecraft:air
setblock 150 71 -124 minecraft:spruce_log[axis=y]
setblock 152 71 -124 minecraft:air
setblock 153 71 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 71 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 71 -124 minecraft:spruce_log[axis=y]
setblock 156 71 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 71 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 71 -124 minecraft:air
setblock 164 71 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 71 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 71 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 71 -124 minecraft:air
setblock 181 71 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 71 -124 minecraft:spruce_log[axis=y]
setblock 183 71 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 71 -124 minecraft:air
fill 141 71 -125 143 71 -125 minecraft:air
setblock 145 71 -125 minecraft:birch_log[axis=y]
fill 151 71 -125 152 71 -125 minecraft:air
setblock 153 71 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 71 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 71 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 71 -125 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 71 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 161 71 -125 163 71 -125 minecraft:air
fill 171 71 -125 173 71 -125 minecraft:air
setblock 181 71 -125 minecraft:air
setblock 182 71 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 71 -125 minecraft:air
fill 191 71 -125 193 71 -125 minecraft:air
setblock 140 71 -126 minecraft:air
setblock 141 71 -126 minecraft:birch_log[axis=y]
fill 142 71 -126 144 71 -126 minecraft:air
fill 150 71 -126 153 71 -126 minecraft:air
setblock 154 71 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 71 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 71 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 71 -126 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 71 -126 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 71 -126 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 162 71 -126 164 71 -126 minecraft:air
fill 170 71 -126 174 71 -126 minecraft:air
fill 180 71 -126 182 71 -126 minecraft:air
setblock 183 71 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 71 -126 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 71 -126 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 190 71 -126 194 71 -126 minecraft:air
setblock 198 71 -126 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 70 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 70 -116 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 70 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 70 -117 minecraft:birch_log[axis=y]
setblock 153 70 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 70 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 70 -117 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 70 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 70 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 70 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 70 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 70 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 70 -118 minecraft:spruce_log[axis=y]
setblock 153 70 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 70 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 70 -118 minecraft:spruce_log[axis=y]
setblock 156 70 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 70 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 70 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 70 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 70 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 70 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 70 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 70 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 70 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 70 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 70 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 70 -119 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 164 70 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 70 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 70 -119 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 167 70 -119 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 70 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 70 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 70 -119 minecraft:spruce_log[axis=y]
setblock 185 70 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 70 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 70 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 70 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 70 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 70 -120 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 163 70 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 70 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 70 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 70 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 70 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 168 70 -120 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 70 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 70 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 70 -120 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 70 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 70 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 70 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 70 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 70 -121 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 70 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 70 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 70 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 70 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 70 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 70 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 70 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 70 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 70 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 70 -122 minecraft:spruce_log[axis=y]
setblock 166 70 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 167 70 -122 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 70 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 70 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 70 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 70 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 70 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 70 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 70 -123 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 70 -123 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 70 -123 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
fill 141 70 -124 143 70 -124 minecraft:air
setblock 150 70 -124 minecraft:spruce_log[axis=y]
fill 151 70 -124 153 70 -124 minecraft:air
setblock 154 70 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 70 -124 minecraft:spruce_log[axis=y]
setblock 156 70 -124 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 70 -124 minecraft:air
setblock 162 70 -124 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 163 70 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 70 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 70 -124 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 70 -124 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 70 -124 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 168 70 -124 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
fill 171 70 -124 173 70 -124 minecraft:air
setblock 181 70 -124 minecraft:air
setblock 182 70 -124 minecraft:spruce_log[axis=y]
setblock 183 70 -124 minecraft:air
fill 191 70 -124 193 70 -124 minecraft:air
fill 140 70 -125 144 70 -125 minecraft:air
setblock 145 70 -125 minecraft:birch_log[axis=y]
fill 150 70 -125 154 70 -125 minecraft:air
setblock 155 70 -125 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
fill 160 70 -125 162 70 -125 minecraft:air
setblock 163 70 -125 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 164 70 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 70 -125 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 70 -125 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 167 70 -125 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
fill 170 70 -125 174 70 -125 minecraft:air
fill 180 70 -125 184 70 -125 minecraft:air
fill 190 70 -125 194 70 -125 minecraft:air
setblock 140 70 -126 minecraft:air
setblock 141 70 -126 minecraft:birch_log[axis=y]
fill 142 70 -126 144 70 -126 minecraft:air
fill 150 70 -126 154 70 -126 minecraft:air
fill 160 70 -126 164 70 -126 minecraft:air
fill 170 70 -126 174 70 -126 minecraft:air
fill 180 70 -126 184 70 -126 minecraft:air
fill 190 70 -126 194 70 -126 minecraft:air
setblock 182 69 -116 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 183 69 -116 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 69 -116 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 69 -116 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 69 -116 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 139 69 -117 minecraft:birch_log[axis=y]
setblock 181 69 -117 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 69 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 69 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 69 -117 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 69 -117 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 69 -117 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 69 -117 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 142 69 -118 minecraft:spruce_log[axis=y]
setblock 155 69 -118 minecraft:spruce_log[axis=y]
setblock 181 69 -118 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 69 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 69 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 69 -118 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 69 -118 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 69 -118 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 69 -118 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 69 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 69 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 69 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 69 -119 minecraft:spruce_log[axis=y]
setblock 185 69 -119 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 69 -119 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 69 -119 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 69 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 69 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 69 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 69 -120 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 69 -120 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 69 -120 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 69 -120 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 165 69 -121 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 69 -121 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 69 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 69 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 69 -121 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 69 -121 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 69 -121 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 69 -121 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 164 69 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 69 -122 minecraft:spruce_log[axis=y]
setblock 166 69 -122 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 69 -122 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 183 69 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 69 -122 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 69 -122 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 69 -122 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 165 69 -123 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 69 -124 minecraft:air
setblock 150 69 -124 minecraft:spruce_log[axis=y]
setblock 152 69 -124 minecraft:air
setblock 155 69 -124 minecraft:spruce_log[axis=y]
setblock 162 69 -124 minecraft:air
setblock 172 69 -124 minecraft:air
setblock 182 69 -124 minecraft:spruce_log[axis=y]
setblock 192 69 -124 minecraft:air
fill 141 69 -125 143 69 -125 minecraft:air
setblock 145 69 -125 minecraft:birch_log[axis=y]
fill 151 69 -125 153 69 -125 minecraft:air
fill 161 69 -125 163 69 -125 minecraft:air
fill 171 69 -125 173 69 -125 minecraft:air
fill 181 69 -125 183 69 -125 minecraft:air
fill 191 69 -125 193 69 -125 minecraft:air
setblock 140 69 -126 minecraft:air
setblock 141 69 -126 minecraft:birch_log[axis=y]
fill 142 69 -126 144 69 -126 minecraft:air
fill 150 69 -126 154 69 -126 minecraft:air
fill 160 69 -126 164 69 -126 minecraft:air
fill 170 69 -126 174 69 -126 minecraft:air
fill 180 69 -126 184 69 -126 minecraft:air
fill 190 69 -126 194 69 -126 minecraft:air
setblock 139 68 -117 minecraft:birch_log[axis=y]
setblock 142 68 -118 minecraft:spruce_log[axis=y]
setblock 155 68 -118 minecraft:spruce_log[axis=y]
setblock 146 68 -119 regions_unexplored:grass_sprouts
setblock 149 68 -119 regions_unexplored:grass_sprouts
setblock 150 68 -119 minecraft:short_grass
setblock 184 68 -119 minecraft:spruce_log[axis=y]
setblock 143 68 -120 regions_unexplored:grass_sprouts
setblock 146 68 -120 regions_unexplored:grass_sprouts
setblock 144 68 -121 minecraft:short_grass
setblock 150 68 -121 regions_unexplored:white_trillium
setblock 151 68 -122 regions_unexplored:white_trillium
setblock 165 68 -122 minecraft:spruce_log[axis=y]
setblock 144 68 -123 minecraft:short_grass
setblock 145 68 -123 regions_unexplored:grass_sprouts
setblock 150 68 -124 minecraft:spruce_log[axis=y]
setblock 155 68 -124 minecraft:spruce_log[axis=y]
setblock 182 68 -124 minecraft:spruce_log[axis=y]
setblock 145 68 -125 minecraft:birch_log[axis=y]
setblock 151 68 -125 minecraft:short_grass
setblock 141 68 -126 minecraft:birch_log[axis=y]
setblock 142 68 -126 minecraft:air
setblock 143 68 -126 regions_unexplored:grass_sprouts
fill 147 68 -126 148 68 -126 minecraft:grass_block[snowy=false]
setblock 150 68 -126 minecraft:short_grass
setblock 151 68 -126 regions_unexplored:grass_sprouts
setblock 152 68 -126 minecraft:air
setblock 162 68 -126 minecraft:air
setblock 172 68 -126 minecraft:air
setblock 182 68 -126 minecraft:air
setblock 192 68 -126 minecraft:air
setblock 141 67 -116 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=4]
setblock 142 67 -116 minecraft:short_grass
setblock 143 67 -116 regions_unexplored:grass_sprouts
setblock 139 67 -117 minecraft:birch_log[axis=y]
fill 140 67 -117 141 67 -117 regions_unexplored:grass_sprouts
setblock 142 67 -117 minecraft:short_grass
setblock 146 67 -117 regions_unexplored:grass_sprouts
setblock 148 67 -117 minecraft:grass_block[snowy=false]
setblock 140 67 -118 minecraft:short_grass
setblock 142 67 -118 minecraft:spruce_log[axis=y]
fill 146 67 -118 149 67 -118 minecraft:grass_block[snowy=false]
setblock 155 67 -118 minecraft:spruce_log[axis=y]
setblock 138 67 -119 regions_unexplored:grass_sprouts
fill 144 67 -119 152 67 -119 minecraft:grass_block[snowy=false]
setblock 154 67 -119 regions_unexplored:white_trillium
setblock 184 67 -119 minecraft:spruce_log[axis=y]
fill 143 67 -120 152 67 -120 minecraft:grass_block[snowy=false]
setblock 140 67 -121 minecraft:short_grass
setblock 141 67 -121 regions_unexplored:grass_sprouts
fill 143 67 -121 152 67 -121 minecraft:grass_block[snowy=false]
setblock 139 67 -122 minecraft:short_grass
fill 142 67 -122 152 67 -122 minecraft:grass_block[snowy=false]
setblock 165 67 -122 minecraft:spruce_log[axis=y]
setblock 136 67 -123 regions_unexplored:grass_sprouts
setblock 139 67 -123 minecraft:short_grass
setblock 140 67 -123 regions_unexplored:grass_sprouts
fill 141 67 -123 152 67 -123 minecraft:grass_block[snowy=false]
fill 140 67 -124 149 67 -124 minecraft:grass_block[snowy=false]
setblock 150 67 -124 minecraft:dirt
fill 151 67 -124 152 67 -124 minecraft:grass_block[snowy=false]
setblock 155 67 -124 minecraft:spruce_log[axis=y]
setblock 182 67 -124 minecraft:spruce_log[axis=y]
setblock 138 67 -125 regions_unexplored:grass_sprouts
fill 140 67 -125 144 67 -125 minecraft:grass_block[snowy=false]
setblock 145 67 -125 minecraft:dirt
fill 146 67 -125 152 67 -125 minecraft:grass_block[snowy=false]
setblock 137 67 -126 regions_unexplored:grass_sprouts
fill 139 67 -126 140 67 -126 minecraft:grass_block[snowy=false]
setblock 141 67 -126 minecraft:dirt
fill 142 67 -126 146 67 -126 minecraft:grass_block[snowy=false]
fill 147 67 -126 148 67 -126 minecraft:dirt
fill 149 67 -126 152 67 -126 minecraft:grass_block[snowy=false]
setblock 162 67 -126 minecraft:air
setblock 172 67 -126 minecraft:air
setblock 182 67 -126 minecraft:air
setblock 192 67 -126 minecraft:air
setblock 197 67 -126 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=3]
setblock 136 66 -116 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
setblock 139 66 -116 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
setblock 140 66 -116 regions_unexplored:grass_sprouts
fill 141 66 -116 150 66 -116 minecraft:grass_block[snowy=false]
setblock 151 66 -116 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
setblock 152 66 -116 regions_unexplored:white_trillium
setblock 170 66 -116 regions_unexplored:grass_sprouts
setblock 179 66 -116 regions_unexplored:mossy_stone
setblock 180 66 -116 minecraft:coarse_dirt
setblock 139 66 -117 minecraft:birch_log[axis=y]
fill 140 66 -117 147 66 -117 minecraft:grass_block[snowy=false]
setblock 148 66 -117 minecraft:dirt
fill 149 66 -117 152 66 -117 minecraft:grass_block[snowy=false]
setblock 171 66 -117 regions_unexplored:grass_sprouts
setblock 173 66 -117 regions_unexplored:grass_sprouts
setblock 176 66 -117 regions_unexplored:grass_sprouts
setblock 181 66 -117 regions_unexplored:grass_sprouts
setblock 137 66 -118 minecraft:short_grass
fill 139 66 -118 141 66 -118 minecraft:grass_block[snowy=false]
setblock 142 66 -118 minecraft:dirt
fill 143 66 -118 145 66 -118 minecraft:grass_block[snowy=false]
fill 146 66 -118 149 66 -118 minecraft:dirt
fill 150 66 -118 153 66 -118 minecraft:grass_block[snowy=false]
setblock 154 66 -118 regions_unexplored:white_trillium
setblock 155 66 -118 minecraft:spruce_log[axis=y]
setblock 181 66 -118 regions_unexplored:grass_sprouts
setblock 136 66 -119 minecraft:short_grass
setblock 137 66 -119 regions_unexplored:grass_sprouts
fill 138 66 -119 143 66 -119 minecraft:grass_block[snowy=false]
fill 144 66 -119 152 66 -119 minecraft:dirt
fill 153 66 -119 154 66 -119 minecraft:grass_block[snowy=false]
setblock 173 66 -119 regions_unexplored:grass_sprouts
setblock 184 66 -119 minecraft:spruce_log[axis=y]
fill 136 66 -120 142 66 -120 minecraft:grass_block[snowy=false]
fill 143 66 -120 152 66 -120 minecraft:dirt
fill 153 66 -120 155 66 -120 minecraft:grass_block[snowy=false]
setblock 179 66 -120 minecraft:short_grass
fill 136 66 -121 142 66 -121 minecraft:grass_block[snowy=false]
fill 143 66 -121 152 66 -121 minecraft:dirt
fill 153 66 -121 154 66 -121 minecraft:grass_block[snowy=false]
fill 136 66 -122 141 66 -122 minecraft:grass_block[snowy=false]
fill 142 66 -122 152 66 -122 minecraft:dirt
fill 153 66 -122 154 66 -122 minecraft:grass_block[snowy=false]
setblock 155 66 -122 regions_unexplored:white_trillium
setblock 165 66 -122 minecraft:spruce_log[axis=y]
setblock 179 66 -122 minecraft:lily_of_the_valley
fill 136 66 -123 140 66 -123 minecraft:grass_block[snowy=false]
fill 141 66 -123 152 66 -123 minecraft:dirt
setblock 153 66 -123 minecraft:grass_block[snowy=false]
fill 136 66 -124 139 66 -124 minecraft:grass_block[snowy=false]
fill 140 66 -124 152 66 -124 minecraft:dirt
setblock 153 66 -124 minecraft:grass_block[snowy=false]
setblock 155 66 -124 minecraft:spruce_log[axis=y]
setblock 182 66 -124 minecraft:spruce_log[axis=y]
fill 197 66 -124 199 66 -124 minecraft:grass_block[snowy=false]
fill 136 66 -125 139 66 -125 minecraft:grass_block[snowy=false]
fill 140 66 -125 152 66 -125 minecraft:dirt
setblock 153 66 -125 minecraft:grass_block[snowy=false]
fill 196 66 -125 199 66 -125 minecraft:grass_block[snowy=false]
fill 136 66 -126 138 66 -126 minecraft:grass_block[snowy=false]
fill 139 66 -126 152 66 -126 minecraft:dirt
setblock 153 66 -126 minecraft:grass_block[snowy=false]
setblock 162 66 -126 minecraft:air
setblock 172 66 -126 minecraft:air
setblock 182 66 -126 minecraft:air
setblock 192 66 -126 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=3]
fill 195 66 -126 199 66 -126 minecraft:grass_block[snowy=false]
fill 136 65 -116 140 65 -116 minecraft:grass_block[snowy=false]
fill 141 65 -116 150 65 -116 minecraft:dirt
fill 151 65 -116 152 65 -116 minecraft:grass_block[snowy=false]
fill 153 65 -116 169 65 -116 minecraft:air
setblock 170 65 -116 regions_unexplored:mossy_stone
fill 171 65 -116 172 65 -116 minecraft:stone
setblock 173 65 -116 regions_unexplored:mossy_stone
fill 174 65 -116 175 65 -116 minecraft:coarse_dirt
setblock 176 65 -116 regions_unexplored:mossy_stone
setblock 177 65 -116 minecraft:stone
setblock 178 65 -116 minecraft:grass_block[snowy=false]
fill 179 65 -116 180 65 -116 minecraft:dirt
setblock 181 65 -116 regions_unexplored:mossy_stone
fill 182 65 -116 199 65 -116 minecraft:air
fill 136 65 -117 138 65 -117 minecraft:grass_block[snowy=false]
fill 139 65 -117 152 65 -117 minecraft:dirt
setblock 153 65 -117 minecraft:grass_block[snowy=false]
fill 154 65 -117 157 65 -117 minecraft:air
setblock 158 65 -117 regions_unexplored:oak_shrub[half=upper]
fill 159 65 -117 169 65 -117 minecraft:air
setblock 170 65 -117 regions_unexplored:mossy_stone
setblock 171 65 -117 minecraft:stone
setblock 172 65 -117 regions_unexplored:mossy_stone
fill 173 65 -117 176 65 -117 minecraft:stone
fill 177 65 -117 179 65 -117 minecraft:grass_block[snowy=false]
setblock 180 65 -117 minecraft:coarse_dirt
setblock 181 65 -117 regions_unexplored:mossy_stone
fill 182 65 -117 199 65 -117 minecraft:air
fill 136 65 -118 138 65 -118 minecraft:grass_block[snowy=false]
fill 139 65 -118 153 65 -118 minecraft:dirt
setblock 154 65 -118 minecraft:grass_block[snowy=false]
setblock 155 65 -118 minecraft:spruce_log[axis=y]
setblock 156 65 -118 minecraft:air
setblock 157 65 -118 regions_unexplored:white_trillium
fill 158 65 -118 171 65 -118 minecraft:air
fill 172 65 -118 174 65 -118 minecraft:stone
setblock 175 65 -118 regions_unexplored:mossy_stone
fill 176 65 -118 179 65 -118 minecraft:grass_block[snowy=false]
setblock 180 65 -118 minecraft:coarse_dirt
setblock 181 65 -118 minecraft:grass_block[snowy=false]
fill 182 65 -118 199 65 -118 minecraft:air
fill 136 65 -119 137 65 -119 minecraft:grass_block[snowy=false]
fill 138 65 -119 154 65 -119 minecraft:dirt
fill 155 65 -119 156 65 -119 minecraft:grass_block[snowy=false]
setblock 157 65 -119 minecraft:air
setblock 158 65 -119 minecraft:short_grass
fill 159 65 -119 172 65 -119 minecraft:air
setblock 173 65 -119 minecraft:stone
setblock 174 65 -119 minecraft:grass_block[snowy=false]
setblock 175 65 -119 regions_unexplored:mossy_stone
fill 176 65 -119 181 65 -119 minecraft:grass_block[snowy=false]
fill 182 65 -119 183 65 -119 minecraft:air
setblock 184 65 -119 minecraft:spruce_log[axis=y]
fill 185 65 -119 199 65 -119 minecraft:air
fill 136 65 -120 155 65 -120 minecraft:dirt
fill 156 65 -120 157 65 -120 minecraft:grass_block[snowy=false]
fill 158 65 -120 167 65 -120 minecraft:air
setblock 168 65 -120 regions_unexplored:grass_sprouts
fill 169 65 -120 171 65 -120 minecraft:air
setblock 172 65 -120 regions_unexplored:grass_sprouts
fill 173 65 -120 174 65 -120 minecraft:air
setblock 175 65 -120 regions_unexplored:mossy_stone
fill 176 65 -120 178 65 -120 minecraft:grass_block[snowy=false]
setblock 179 65 -120 minecraft:coarse_dirt
fill 180 65 -120 182 65 -120 minecraft:grass_block[snowy=false]
fill 183 65 -120 199 65 -120 minecraft:air
fill 136 65 -121 154 65 -121 minecraft:dirt
setblock 155 65 -121 minecraft:grass_block[snowy=false]
fill 156 65 -121 174 65 -121 minecraft:air
setblock 175 65 -121 regions_unexplored:mossy_stone
fill 176 65 -121 178 65 -121 minecraft:grass_block[snowy=false]
setblock 179 65 -121 minecraft:coarse_dirt
fill 180 65 -121 182 65 -121 minecraft:grass_block[snowy=false]
fill 183 65 -121 194 65 -121 minecraft:air
setblock 195 65 -121 supplementaries:barnacles[down=true,east=false,north=false,south=false,up=false,waterlogged=false,west=false]
fill 196 65 -121 199 65 -121 minecraft:air
fill 136 65 -122 154 65 -122 minecraft:dirt
fill 156 65 -122 164 65 -122 minecraft:air
setblock 165 65 -122 minecraft:spruce_log[axis=y]
fill 166 65 -122 174 65 -122 minecraft:air
setblock 176 65 -122 minecraft:stone
setblock 177 65 -122 minecraft:coal_ore
fill 184 65 -122 188 65 -122 minecraft:air
setblock 189 65 -122 supplementaries:barnacles[down=true,east=false,north=false,south=false,up=false,waterlogged=false,west=false]
setblock 190 65 -122 minecraft:air
setblock 191 65 -122 supplementaries:barnacles[down=true,east=false,north=false,south=false,up=false,waterlogged=false,west=false]
fill 192 65 -122 199 65 -122 minecraft:air
fill 136 65 -123 153 65 -123 minecraft:dirt
fill 155 65 -123 175 65 -123 minecraft:air
fill 176 65 -123 178 65 -123 minecraft:stone
fill 187 65 -123 190 65 -123 minecraft:air
setblock 191 65 -123 supplementaries:barnacles[down=true,east=false,north=false,south=false,up=false,waterlogged=false,west=false]
fill 192 65 -123 193 65 -123 minecraft:air
fill 194 65 -123 199 65 -123 minecraft:gravel
fill 136 65 -124 153 65 -124 minecraft:dirt
setblock 155 65 -124 minecraft:spruce_log[axis=y]
fill 156 65 -124 176 65 -124 minecraft:air
setblock 177 65 -124 regions_unexplored:mossy_stone
setblock 178 65 -124 minecraft:stone
setblock 179 65 -124 minecraft:coarse_dirt
setblock 182 65 -124 minecraft:dirt
fill 189 65 -124 196 65 -124 minecraft:gravel
fill 197 65 -124 199 65 -124 minecraft:dirt
fill 136 65 -125 153 65 -125 minecraft:dirt
fill 155 65 -125 176 65 -125 minecraft:air
fill 177 65 -125 179 65 -125 minecraft:stone
setblock 180 65 -125 regions_unexplored:mossy_stone
fill 190 65 -125 192 65 -125 minecraft:gravel
fill 196 65 -125 199 65 -125 minecraft:dirt
fill 136 65 -126 153 65 -126 minecraft:dirt
fill 154 65 -126 176 65 -126 minecraft:air
fill 177 65 -126 179 65 -126 minecraft:stone
setblock 180 65 -126 regions_unexplored:mossy_stone
setblock 181 65 -126 minecraft:coarse_dirt
fill 195 65 -126 199 65 -126 minecraft:dirt
fill 155 64 -116 157 64 -116 minecraft:air
setblock 158 64 -116 minecraft:short_grass
fill 159 64 -116 161 64 -116 minecraft:air
fill 183 64 -116 199 64 -116 minecraft:air
fill 156 64 -117 157 64 -117 minecraft:air
setblock 159 64 -117 regions_unexplored:grass_sprouts
fill 160 64 -117 162 64 -117 minecraft:air
fill 183 64 -117 194 64 -117 minecraft:air
setblock 196 64 -117 minecraft:air
fill 198 64 -117 199 64 -117 minecraft:air
fill 158 64 -118 162 64 -118 minecraft:air
fill 184 64 -118 199 64 -118 minecraft:air
setblock 159 64 -119 regions_unexplored:grass_sprouts
fill 160 64 -119 163 64 -119 minecraft:air
fill 185 64 -119 195 64 -119 minecraft:air
fill 159 64 -120 164 64 -120 minecraft:air
fill 186 64 -120 188 64 -120 minecraft:air
setblock 190 64 -120 minecraft:air
fill 192 64 -120 196 64 -120 minecraft:air
fill 198 64 -120 199 64 -120 minecraft:air
fill 159 64 -121 161 64 -121 minecraft:air
setblock 162 64 -121 regions_unexplored:grass_sprouts
fill 163 64 -121 164 64 -121 minecraft:air
fill 191 64 -121 193 64 -121 minecraft:air
setblock 158 64 -122 minecraft:air
setblock 159 64 -122 minecraft:short_grass
fill 160 64 -122 164 64 -122 minecraft:air
setblock 156 64 -123 minecraft:air
fill 157 64 -123 158 64 -123 minecraft:short_grass
fill 159 64 -123 165 64 -123 minecraft:air
fill 156 64 -124 157 64 -124 minecraft:air
setblock 158 64 -124 minecraft:short_grass
fill 159 64 -124 166 64 -124 minecraft:air
fill 155 64 -125 160 64 -125 minecraft:air
setblock 161 64 -125 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
fill 162 64 -125 164 64 -125 minecraft:air
setblock 165 64 -125 regions_unexplored:grass_sprouts
setblock 166 64 -125 minecraft:air
fill 155 64 -126 159 64 -126 minecraft:air
setblock 160 64 -126 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 161 64 -126 minecraft:short_grass
setblock 162 64 -126 minecraft:air
setblock 163 64 -126 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
fill 164 64 -126 167 64 -126 minecraft:air
fill 152 63 -116 153 63 -116 minecraft:air
fill 151 62 -116 155 62 -116 minecraft:air
fill 151 61 -116 155 61 -116 minecraft:air
fill 154 61 -117 155 61 -117 minecraft:air
fill 153 60 -116 155 60 -116 minecraft:air
fill 173 57 -123 174 57 -123 minecraft:air
fill 174 57 -124 175 57 -124 minecraft:air
fill 173 57 -125 176 57 -125 minecraft:air
fill 174 57 -126 176 57 -126 minecraft:air
setblock 173 56 -119 minecraft:air
fill 172 56 -120 174 56 -120 minecraft:air
fill 172 56 -121 174 56 -121 minecraft:air
fill 172 56 -122 175 56 -122 minecraft:air
fill 172 56 -123 176 56 -123 minecraft:air
fill 172 56 -124 176 56 -124 minecraft:air
fill 173 56 -125 177 56 -125 minecraft:air
fill 173 56 -126 177 56 -126 minecraft:air
setblock 174 55 -117 minecraft:air
fill 173 55 -118 174 55 -118 minecraft:air
fill 171 55 -119 174 55 -119 minecraft:air
fill 171 55 -120 175 55 -120 minecraft:air
fill 171 55 -121 175 55 -121 minecraft:air
fill 171 55 -122 176 55 -122 minecraft:air
fill 171 55 -123 176 55 -123 minecraft:air
fill 172 55 -124 177 55 -124 minecraft:air
fill 172 55 -125 177 55 -125 minecraft:air
fill 173 55 -126 177 55 -126 minecraft:air
fill 174 54 -116 178 54 -116 minecraft:air
fill 173 54 -117 177 54 -117 minecraft:air
fill 172 54 -118 176 54 -118 minecraft:air
fill 171 54 -119 175 54 -119 minecraft:air
fill 171 54 -120 175 54 -120 minecraft:air
fill 171 54 -121 175 54 -121 minecraft:air
fill 171 54 -122 176 54 -122 minecraft:air
fill 171 54 -123 176 54 -123 minecraft:air
fill 172 54 -124 177 54 -124 minecraft:air
fill 172 54 -125 177 54 -125 minecraft:air
fill 172 54 -126 177 54 -126 minecraft:air
fill 173 53 -116 179 53 -116 minecraft:air
fill 172 53 -117 178 53 -117 minecraft:air
fill 171 53 -118 177 53 -118 minecraft:air
fill 171 53 -119 176 53 -119 minecraft:air
fill 171 53 -120 175 53 -120 minecraft:air
fill 171 53 -121 175 53 -121 minecraft:air
fill 171 53 -122 176 53 -122 minecraft:air
fill 171 53 -123 176 53 -123 minecraft:air
fill 172 53 -124 176 53 -124 minecraft:air
fill 172 53 -125 176 53 -125 minecraft:air
setblock 177 53 -125 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
fill 173 53 -126 176 53 -126 minecraft:air
setblock 177 53 -126 minecraft:glow_lichen[down=false,east=true,north=false,south=false,up=false,waterlogged=false,west=false]
fill 172 52 -116 179 52 -116 minecraft:air
fill 172 52 -117 178 52 -117 minecraft:air
fill 171 52 -118 177 52 -118 minecraft:air
fill 171 52 -119 176 52 -119 minecraft:air
fill 171 52 -120 175 52 -120 minecraft:air
fill 171 52 -121 175 52 -121 minecraft:air
fill 171 52 -122 175 52 -122 minecraft:air
fill 172 52 -123 175 52 -123 minecraft:air
fill 173 52 -124 174 52 -124 minecraft:air
fill 173 51 -116 179 51 -116 minecraft:air
fill 172 51 -117 178 51 -117 minecraft:air
fill 171 51 -118 177 51 -118 minecraft:air
fill 172 51 -119 176 51 -119 minecraft:air
fill 172 51 -120 175 51 -120 minecraft:air
fill 192 49 -116 193 49 -116 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 192 49 -117 193 49 -117 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 174 48 -116 187 48 -116 minecraft:air
fill 191 48 -116 196 48 -116 minecraft:water[level=0]
fill 157 48 -117 158 48 -117 minecraft:air
fill 175 48 -117 187 48 -117 minecraft:air
fill 191 48 -117 197 48 -117 minecraft:water[level=0]
fill 157 48 -118 158 48 -118 minecraft:air
setblock 160 48 -118 minecraft:air
fill 175 48 -118 187 48 -118 minecraft:air
fill 191 48 -118 197 48 -118 minecraft:water[level=0]
fill 159 48 -119 160 48 -119 minecraft:air
fill 175 48 -119 187 48 -119 minecraft:air
fill 190 48 -119 197 48 -119 minecraft:water[level=0]
fill 175 48 -120 187 48 -120 minecraft:air
fill 190 48 -120 198 48 -120 minecraft:water[level=0]
fill 161 48 -121 162 48 -121 minecraft:air
fill 176 48 -121 187 48 -121 minecraft:air
fill 190 48 -121 198 48 -121 minecraft:water[level=0]
fill 161 48 -122 162 48 -122 minecraft:air
fill 178 48 -122 187 48 -122 minecraft:air
fill 190 48 -122 198 48 -122 minecraft:water[level=0]
fill 161 48 -123 162 48 -123 minecraft:air
fill 179 48 -123 187 48 -123 minecraft:air
fill 190 48 -123 199 48 -123 minecraft:water[level=0]
fill 160 48 -124 161 48 -124 minecraft:air
fill 180 48 -124 186 48 -124 minecraft:air
fill 190 48 -124 199 48 -124 minecraft:water[level=0]
fill 151 48 -125 155 48 -125 minecraft:air
fill 158 48 -125 161 48 -125 minecraft:air
fill 182 48 -125 185 48 -125 minecraft:air
fill 190 48 -125 198 48 -125 minecraft:water[level=0]
fill 150 48 -126 160 48 -126 minecraft:air
fill 183 48 -126 186 48 -126 minecraft:air
fill 190 48 -126 198 48 -126 minecraft:water[level=0]
fill 156 47 -116 157 47 -116 minecraft:air
fill 176 47 -116 189 47 -116 minecraft:air
fill 156 47 -117 158 47 -117 minecraft:air
fill 176 47 -117 188 47 -117 minecraft:air
setblock 192 47 -117 minecraft:water[level=0]
fill 157 47 -118 160 47 -118 minecraft:air
fill 176 47 -118 188 47 -118 minecraft:air
setblock 192 47 -118 minecraft:water[level=0]
fill 158 47 -119 160 47 -119 minecraft:air
fill 177 47 -119 188 47 -119 minecraft:air
setblock 192 47 -119 minecraft:water[level=0]
fill 159 47 -120 162 47 -120 minecraft:air
fill 177 47 -120 188 47 -120 minecraft:air
fill 192 47 -120 193 47 -120 minecraft:water[level=0]
fill 160 47 -121 163 47 -121 minecraft:air
fill 178 47 -121 188 47 -121 minecraft:air
fill 192 47 -121 193 47 -121 minecraft:water[level=0]
fill 160 47 -122 163 47 -122 minecraft:air
fill 180 47 -122 188 47 -122 minecraft:air
fill 191 47 -122 193 47 -122 minecraft:water[level=0]
fill 159 47 -123 163 47 -123 minecraft:air
fill 181 47 -123 188 47 -123 minecraft:air
fill 191 47 -123 194 47 -123 minecraft:water[level=0]
fill 158 47 -124 162 47 -124 minecraft:air
fill 182 47 -124 188 47 -124 minecraft:air
fill 191 47 -124 194 47 -124 minecraft:water[level=0]
fill 148 47 -125 162 47 -125 minecraft:air
fill 184 47 -125 188 47 -125 minecraft:air
fill 191 47 -125 194 47 -125 minecraft:water[level=0]
fill 147 47 -126 161 47 -126 minecraft:air
fill 186 47 -126 188 47 -126 minecraft:air
fill 191 47 -126 195 47 -126 minecraft:water[level=0]
setblock 158 46 -116 minecraft:air
fill 179 46 -116 190 46 -116 minecraft:air
fill 195 46 -116 199 46 -116 minecraft:air
fill 157 46 -117 160 46 -117 minecraft:air
fill 179 46 -117 190 46 -117 minecraft:air
fill 196 46 -117 199 46 -117 minecraft:air
fill 157 46 -118 160 46 -118 minecraft:air
fill 179 46 -118 190 46 -118 minecraft:air
fill 196 46 -118 199 46 -118 minecraft:air
fill 158 46 -119 160 46 -119 minecraft:air
fill 180 46 -119 190 46 -119 minecraft:air
fill 196 46 -119 199 46 -119 minecraft:air
setblock 159 46 -120 minecraft:air
fill 161 46 -120 162 46 -120 minecraft:air
fill 180 46 -120 189 46 -120 minecraft:air
fill 197 46 -120 199 46 -120 minecraft:air
fill 160 46 -121 163 46 -121 minecraft:air
fill 181 46 -121 189 46 -121 minecraft:air
fill 197 46 -121 199 46 -121 minecraft:air
fill 160 46 -122 163 46 -122 minecraft:air
fill 183 46 -122 189 46 -122 minecraft:air
fill 197 46 -122 199 46 -122 minecraft:air
fill 159 46 -123 163 46 -123 minecraft:air
fill 184 46 -123 189 46 -123 minecraft:air
fill 198 46 -123 199 46 -123 minecraft:air
setblock 149 46 -124 minecraft:air
fill 158 46 -124 163 46 -124 minecraft:air
fill 185 46 -124 189 46 -124 minecraft:air
fill 198 46 -124 199 46 -124 minecraft:air
fill 147 46 -125 162 46 -125 minecraft:air
fill 188 46 -125 189 46 -125 minecraft:air
fill 198 46 -125 199 46 -125 minecraft:air
fill 144 46 -126 145 46 -126 minecraft:air
fill 147 46 -126 161 46 -126 minecraft:air
fill 189 45 -116 191 45 -116 minecraft:air
fill 193 45 -116 199 45 -116 minecraft:air
fill 188 45 -117 191 45 -117 minecraft:air
fill 193 45 -117 199 45 -117 minecraft:air
fill 186 45 -118 191 45 -118 minecraft:air
fill 193 45 -118 199 45 -118 minecraft:air
fill 186 45 -119 191 45 -119 minecraft:air
fill 193 45 -119 199 45 -119 minecraft:air
fill 185 45 -120 190 45 -120 minecraft:air
fill 193 45 -120 199 45 -120 minecraft:air
fill 187 45 -121 190 45 -121 minecraft:air
fill 193 45 -121 199 45 -121 minecraft:air
fill 188 45 -122 190 45 -122 minecraft:air
fill 193 45 -122 199 45 -122 minecraft:air
fill 189 45 -123 190 45 -123 minecraft:air
fill 193 45 -123 199 45 -123 minecraft:air
fill 189 45 -124 190 45 -124 minecraft:air
fill 193 45 -124 199 45 -124 minecraft:air
fill 147 45 -125 150 45 -125 minecraft:air
fill 193 45 -125 199 45 -125 minecraft:air
fill 143 45 -126 150 45 -126 minecraft:air
fill 194 45 -126 199 45 -126 minecraft:air
forceload remove 136 -126 199 -63
tellraw @a {"text":"Campus zurueck a38 fertig.","color":"green"}
