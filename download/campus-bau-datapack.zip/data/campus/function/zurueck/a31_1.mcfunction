setblock 184 85 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 85 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 85 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 85 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 85 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 85 -142 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 85 -182 minecraft:white_concrete
setblock 197 85 -183 minecraft:white_concrete
setblock 194 85 -188 minecraft:white_concrete
setblock 194 85 -189 minecraft:white_concrete
setblock 193 85 -190 minecraft:white_concrete
setblock 184 84 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 83 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 83 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 83 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 83 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 83 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 82 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 82 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 82 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 82 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 82 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 82 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 82 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 82 -128 minecraft:spruce_log[axis=y]
setblock 185 82 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 82 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 82 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 82 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 82 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 82 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 82 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 82 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 82 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 82 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 82 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 82 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 82 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 82 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 82 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 151 81 -127 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 152 81 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 81 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 81 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 81 -128 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 81 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 81 -128 minecraft:spruce_log[axis=y]
setblock 185 81 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 81 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 81 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 80 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 80 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 80 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 80 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 80 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 80 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 80 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 80 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 80 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 80 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 80 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 80 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 80 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 80 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 80 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 80 -128 minecraft:spruce_log[axis=y]
setblock 185 80 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 80 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 80 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 80 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 80 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 80 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 80 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 80 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 80 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 80 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 80 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 80 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 80 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 80 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 80 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 80 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 80 -141 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 80 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 80 -142 minecraft:spruce_log[axis=y]
setblock 197 80 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 80 -143 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 80 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 80 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 80 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 80 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 80 -149 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 80 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 80 -149 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 80 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 80 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 80 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 80 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 80 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 80 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 80 -151 minecraft:spruce_log[axis=y]
setblock 196 80 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 80 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 80 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 80 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 80 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 80 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 80 -153 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 80 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 79 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 79 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 79 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 79 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 79 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 79 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 79 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 79 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 79 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 79 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 79 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 79 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 79 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 79 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 79 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 79 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 79 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 79 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 79 -128 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 79 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 79 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 79 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 79 -128 minecraft:spruce_log[axis=y]
setblock 185 79 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 79 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 79 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 79 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 79 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 79 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 79 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 79 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 79 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 79 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 79 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 79 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 79 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 79 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 79 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 79 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 79 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 79 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 79 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 79 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 79 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 79 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 79 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 79 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 79 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 79 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 79 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 79 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 79 -131 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 183 79 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 79 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 79 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 79 -131 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 79 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 79 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 79 -131 minecraft:spruce_log[axis=y]
setblock 197 79 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 79 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 79 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 79 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 79 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 79 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 79 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 79 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 79 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 79 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 79 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 79 -140 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 79 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 79 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 79 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 79 -141 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 79 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 79 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 79 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 79 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 79 -142 minecraft:spruce_log[axis=y]
setblock 197 79 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 79 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 79 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 79 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 79 -143 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 79 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 79 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 79 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 79 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 79 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 79 -149 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 195 79 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 79 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 79 -151 minecraft:spruce_log[axis=y]
setblock 196 79 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 79 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 78 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 78 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 78 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 78 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 78 -127 minecraft:birch_log[axis=y]
setblock 153 78 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 78 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 78 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 78 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 78 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 78 -128 minecraft:birch_log[axis=y]
setblock 150 78 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 78 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 78 -128 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 78 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 78 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 78 -128 minecraft:spruce_log[axis=y]
setblock 185 78 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 78 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 78 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 78 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 78 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 78 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 78 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 78 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 78 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 78 -131 minecraft:spruce_log[axis=y]
setblock 197 78 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 78 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 78 -132 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 78 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 78 -133 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 139 78 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 139 78 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 78 -139 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 78 -139 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 195 78 -139 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 78 -139 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 78 -139 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 78 -139 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 78 -140 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 78 -140 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 78 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 78 -140 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 78 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 78 -140 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 78 -140 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 78 -141 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 78 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 78 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 78 -141 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 78 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 78 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 78 -141 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 78 -142 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 78 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 78 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 78 -142 minecraft:spruce_log[axis=y]
setblock 197 78 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 78 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 78 -142 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 78 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 78 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 78 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 78 -143 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 78 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 78 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 78 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 78 -144 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 78 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 78 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 78 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 78 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 198 78 -144 199 78 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 78 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 78 -145 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 195 78 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 78 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 197 78 -145 198 78 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 78 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 78 -146 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 78 -146 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 78 -146 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 78 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 78 -147 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 78 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 78 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 78 -149 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 78 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 78 -149 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 78 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 78 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 78 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 78 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 78 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 78 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 78 -151 minecraft:spruce_log[axis=y]
setblock 196 78 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 78 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 78 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 78 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 78 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 78 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 78 -153 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 78 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 77 -127 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 152 77 -127 minecraft:birch_log[axis=y]
setblock 182 77 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 77 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 77 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 77 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 77 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 77 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 77 -128 minecraft:birch_log[axis=y]
setblock 182 77 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 77 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 77 -128 minecraft:spruce_log[axis=y]
setblock 185 77 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 77 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 77 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 77 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 77 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 77 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 77 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 77 -129 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 77 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 77 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 77 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 77 -130 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 144 77 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 77 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 77 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 77 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 77 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 77 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 77 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 77 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 77 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 77 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 77 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 77 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 77 -131 minecraft:spruce_log[axis=y]
setblock 197 77 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 77 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 77 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 77 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 77 -132 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 77 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 77 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 77 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 77 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 77 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 77 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 77 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 77 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 77 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 77 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 138 77 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 77 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 77 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 77 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 77 -139 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 77 -140 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 77 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 77 -141 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 77 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 77 -142 minecraft:spruce_log[axis=y]
setblock 197 77 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 77 -143 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 77 -143 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 198 77 -144 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 199 77 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 77 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 77 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 77 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 77 -146 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 77 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 77 -147 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 77 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 77 -148 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 77 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 77 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 77 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 197 77 -148 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 198 77 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 77 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 77 -149 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 77 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 77 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 77 -149 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 77 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 77 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 77 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 77 -149 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 77 -150 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 77 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 77 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 77 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 77 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 77 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 77 -151 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 77 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 77 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 77 -151 minecraft:spruce_log[axis=y]
setblock 196 77 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 77 -152 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 77 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 77 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 77 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 77 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 77 -153 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 77 -153 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 77 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 77 -153 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 77 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 76 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 76 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 76 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 76 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 76 -127 minecraft:birch_log[axis=y]
setblock 181 76 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 76 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 76 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 76 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 76 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 76 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 76 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 197 76 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 76 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 76 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 76 -128 minecraft:birch_log[axis=y]
setblock 181 76 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 76 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 76 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 76 -128 minecraft:spruce_log[axis=y]
setblock 185 76 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 76 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 76 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 76 -128 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 76 -128 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 76 -128 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 195 76 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
fill 196 76 -128 197 76 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 76 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 76 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 76 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 76 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 76 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 76 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 76 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 76 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 76 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 76 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 189 76 -129 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 76 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 76 -129 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 76 -129 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 76 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 76 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 76 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 197 76 -129 198 76 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 76 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 143 76 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 76 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 76 -130 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 76 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 76 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 76 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 76 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 76 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 76 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 76 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 189 76 -130 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 76 -130 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 76 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 76 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 76 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 76 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 76 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 76 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 76 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 142 76 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 76 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 76 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 76 -131 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 183 76 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 76 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 76 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 76 -131 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 76 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 76 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 76 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 76 -131 minecraft:spruce_log[axis=y]
setblock 197 76 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 76 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 76 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 76 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 76 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 76 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 76 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 76 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 76 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 76 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 76 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 76 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 76 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 142 76 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 76 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 76 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 76 -133 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 76 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 76 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 76 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 76 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 76 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 76 -133 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 141 76 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 76 -134 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 195 76 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 76 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 76 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 76 -134 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 141 76 -135 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 138 76 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 76 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 76 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 138 76 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 76 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 76 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 76 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 76 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 76 -140 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 76 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 76 -140 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 76 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 76 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 76 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 76 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 76 -141 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 76 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 76 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 76 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 76 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 76 -142 minecraft:spruce_log[axis=y]
setblock 197 76 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 76 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 76 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 76 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 76 -143 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 76 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 76 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 76 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 76 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 76 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 76 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 76 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 76 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 76 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 76 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 76 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 76 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 76 -151 minecraft:spruce_log[axis=y]
setblock 196 76 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 76 -152 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 179 76 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 76 -152 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 76 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 76 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 158 76 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 159 76 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 76 -160 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 76 -160 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 76 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 76 -160 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 76 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 76 -173 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 76 -181 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 76 -181 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 140 75 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 75 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 75 -127 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 75 -127 minecraft:birch_log[axis=y]
setblock 180 75 -127 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 181 75 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 75 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 75 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 75 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 75 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 75 -127 regions_unexplored:maple_log[axis=y]
setblock 199 75 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 75 -128 minecraft:birch_log[axis=y]
setblock 183 75 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 75 -128 minecraft:spruce_log[axis=y]
setblock 185 75 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 75 -128 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 75 -128 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 75 -128 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 75 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 75 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 75 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 75 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 75 -129 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 75 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 75 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 75 -129 regions_unexplored:maple_log[axis=y]
setblock 191 75 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 75 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 75 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 145 75 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 75 -130 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 75 -130 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 75 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 75 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 75 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 75 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 75 -131 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 75 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 75 -131 minecraft:spruce_log[axis=y]
setblock 197 75 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 75 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 75 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 75 -132 minecraft:birch_log[axis=y]
setblock 144 75 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 145 75 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 75 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 75 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 75 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 75 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 75 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 75 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 75 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 75 -134 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 143 75 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 75 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 75 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 75 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 75 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 75 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 75 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 75 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 147 75 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 75 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 137 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 138 75 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 139 75 -138 minecraft:birch_log[axis=y]
setblock 140 75 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 75 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 75 -138 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 138 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 75 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 140 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 75 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 75 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 75 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 75 -139 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 195 75 -139 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 196 75 -139 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 197 75 -139 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 198 75 -139 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 139 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 75 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 75 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 75 -140 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 194 75 -140 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 195 75 -140 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 75 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 75 -140 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 75 -140 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 199 75 -140 minecraft:spruce_leaves[distance=6,persistent=false,waterlogged=false]
setblock 149 75 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 75 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 75 -141 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 75 -141 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 75 -141 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 75 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 75 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 75 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 75 -141 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 75 -141 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 75 -142 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 75 -142 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 75 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 75 -142 minecraft:spruce_log[axis=y]
setblock 197 75 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 75 -142 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 75 -142 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 75 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 75 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 75 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 193 75 -143 194 75 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 75 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 75 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 75 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 75 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 75 -143 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 150 75 -144 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 177 75 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 75 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 75 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 75 -144 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 75 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 194 75 -144 195 75 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 75 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 75 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 75 -144 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 199 75 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 176 75 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 75 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 75 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 75 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 75 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 194 75 -145 195 75 -145 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 196 75 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 197 75 -145 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 198 75 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 75 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 75 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 75 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 75 -146 minecraft:spruce_log[axis=y]
setblock 179 75 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 75 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 75 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 75 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 75 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 75 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 75 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 75 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 75 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 75 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 75 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 75 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 75 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 75 -149 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 75 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 75 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 75 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 75 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 75 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 75 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 75 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 75 -151 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 75 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 75 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 75 -151 minecraft:spruce_log[axis=y]
setblock 196 75 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 75 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 75 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 75 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 75 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 75 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 75 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 75 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
fill 196 75 -152 197 75 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 75 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 75 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 75 -153 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 75 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 75 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 179 75 -155 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 75 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 75 -155 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 75 -156 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 159 75 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 75 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 75 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 75 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 75 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 75 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 75 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 75 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 75 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 75 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 75 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 75 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 75 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 75 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 75 -173 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 75 -175 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 75 -176 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 75 -176 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 159 75 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 75 -177 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 75 -180 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 75 -181 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 75 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 75 -181 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 75 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 75 -186 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 75 -186 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 75 -187 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 75 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 75 -187 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 75 -187 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 140 74 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 74 -127 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 74 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 74 -127 minecraft:birch_log[axis=y]
setblock 160 74 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 74 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 74 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 74 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 74 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 74 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 74 -127 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 74 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 74 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 74 -127 regions_unexplored:maple_log[axis=y]
setblock 199 74 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 74 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 74 -128 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 74 -128 minecraft:birch_log[axis=y]
setblock 159 74 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 160 74 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 74 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 74 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 74 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 74 -128 minecraft:spruce_log[axis=y]
setblock 185 74 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 74 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 74 -128 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 74 -128 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 74 -128 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 74 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 74 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 74 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 74 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 74 -129 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 145 74 -129 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 74 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 74 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 74 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 74 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 74 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 74 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 74 -129 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 74 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 74 -129 regions_unexplored:maple_log[axis=y]
setblock 191 74 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 74 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 74 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 74 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 74 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 74 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 74 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 74 -130 minecraft:birch_log[axis=y]
setblock 145 74 -130 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 74 -130 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 74 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 74 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 74 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 74 -130 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 74 -130 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 74 -130 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 74 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 74 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 74 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 74 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 143 74 -131 144 74 -131 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 145 74 -131 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 74 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 74 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 74 -131 minecraft:spruce_log[axis=y]
setblock 197 74 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 74 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 74 -132 minecraft:birch_log[axis=y]
setblock 144 74 -132 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 74 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 74 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 74 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 74 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 74 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 74 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 74 -133 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 74 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 74 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 140 74 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 74 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 74 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 74 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 74 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 74 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 74 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 74 -135 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 74 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 74 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 74 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 74 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 74 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 74 -136 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 74 -136 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 74 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 74 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 74 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 74 -138 minecraft:birch_log[axis=y]
setblock 147 74 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 74 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 74 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 74 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 74 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 74 -140 minecraft:birch_log[axis=y]
setblock 151 74 -140 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 74 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 74 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 74 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 74 -141 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 74 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 74 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 74 -142 minecraft:spruce_log[axis=y]
setblock 197 74 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 74 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 74 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 74 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 74 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 154 74 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 74 -143 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 191 74 -143 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 74 -143 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 74 -143 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 150 74 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 74 -144 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 74 -144 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 199 74 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 74 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 74 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 74 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 74 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 74 -146 minecraft:spruce_log[axis=y]
setblock 179 74 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 74 -146 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 74 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 74 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 74 -147 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 74 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 74 -148 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 74 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 74 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 74 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
fill 197 74 -148 198 74 -148 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 199 74 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 192 74 -149 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 74 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 74 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -149 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 74 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 74 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
fill 198 74 -149 199 74 -149 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 188 74 -150 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 74 -150 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 74 -150 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 74 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 74 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 74 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 74 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 74 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 74 -150 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 74 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 74 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 74 -151 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 74 -151 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 74 -151 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 74 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 74 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 74 -151 minecraft:spruce_log[axis=y]
setblock 196 74 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 74 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 74 -151 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 74 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 74 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 74 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 74 -152 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 74 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 74 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 74 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 74 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 74 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 74 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 74 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 74 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 74 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 74 -153 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 74 -153 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 74 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 74 -153 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 74 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 74 -153 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 74 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 74 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 74 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 74 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 74 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 74 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 74 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 74 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 74 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 74 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 74 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 74 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 74 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 74 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 74 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 74 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 74 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 74 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 74 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 74 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 74 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 74 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 74 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 74 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 74 -167 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 74 -167 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 74 -167 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 74 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 74 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 74 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 74 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 74 -172 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 74 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 74 -173 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 74 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 74 -173 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 74 -175 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 74 -176 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 74 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 74 -176 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 74 -176 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 74 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 74 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 74 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 74 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 74 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 74 -180 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 74 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 74 -180 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 74 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 74 -181 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 74 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 74 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 74 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 74 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 74 -185 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 74 -186 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 74 -186 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 74 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 74 -186 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 74 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 74 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 74 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 74 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 74 -188 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 74 -188 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 145 73 -127 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 73 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 73 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 73 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 73 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 73 -127 minecraft:birch_log[axis=y]
setblock 158 73 -127 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 159 73 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 160 73 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 73 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 162 73 -127 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 181 73 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 73 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 73 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 73 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 73 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 73 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 73 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 189 73 -127 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 73 -127 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 73 -127 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -127 regions_unexplored:red_maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 73 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 73 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 73 -127 regions_unexplored:maple_log[axis=y]
setblock 199 73 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 73 -128 minecraft:birch_log[axis=y]
fill 157 73 -128 158 73 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 159 73 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 73 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 73 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 73 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 181 73 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 73 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 73 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 73 -128 minecraft:spruce_log[axis=y]
setblock 185 73 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 73 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 73 -128 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 73 -128 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 73 -128 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 73 -128 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 73 -128 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 73 -128 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 73 -128 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 195 73 -128 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 73 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 73 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 73 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 73 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 73 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 157 73 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 158 73 -129 159 73 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 160 73 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 161 73 -129 162 73 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 181 73 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 73 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 73 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 73 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 73 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 186 73 -129 187 73 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 73 -129 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 73 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 73 -129 regions_unexplored:maple_log[axis=y]
setblock 191 73 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 73 -129 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 73 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 73 -129 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 73 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 73 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 73 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 73 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 73 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 73 -130 minecraft:birch_log[axis=y]
setblock 157 73 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 159 73 -130 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 160 73 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 161 73 -130 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 181 73 -130 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 73 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 73 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 73 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 73 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 186 73 -130 187 73 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 188 73 -130 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 73 -130 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 73 -130 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 73 -130 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 73 -130 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 73 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 73 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 73 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 73 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 73 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 73 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 73 -130 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 73 -131 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 183 73 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 73 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 73 -131 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 186 73 -131 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 188 73 -131 regions_unexplored:red_maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 189 73 -131 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 73 -131 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 73 -131 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -131 regions_unexplored:red_maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 73 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 73 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 73 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 73 -131 minecraft:spruce_log[axis=y]
setblock 197 73 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 73 -131 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 73 -131 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 73 -132 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 73 -132 minecraft:birch_log[axis=y]
setblock 193 73 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 73 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 73 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 73 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 73 -132 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 73 -132 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 73 -132 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 140 73 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 73 -133 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 73 -133 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 73 -133 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 73 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 73 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 73 -133 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 73 -133 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 73 -133 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 73 -133 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 139 73 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 140 73 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 73 -134 minecraft:birch_log[axis=y]
setblock 142 73 -134 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 73 -134 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 73 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 73 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 73 -134 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 195 73 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 73 -134 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 73 -134 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 73 -134 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 140 73 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 73 -135 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 73 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 73 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 73 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 73 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 73 -135 regions_unexplored:maple_log[axis=y]
setblock 187 73 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 141 73 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 73 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 73 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 73 -136 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 73 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 73 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 73 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 73 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 73 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 73 -137 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 146 73 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 73 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 73 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 73 -137 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 73 -138 minecraft:birch_log[axis=y]
setblock 142 73 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 73 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 73 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 73 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 73 -140 minecraft:birch_log[axis=y]
setblock 195 73 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 73 -140 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 73 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 73 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 73 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 73 -141 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 73 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 73 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 73 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 73 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 73 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 73 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 73 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 73 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 73 -142 minecraft:spruce_log[axis=y]
setblock 197 73 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 73 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 73 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 73 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 73 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -143 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 73 -143 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 73 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 73 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 73 -143 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 73 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 73 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 73 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 73 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 73 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 73 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 73 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 73 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 73 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 73 -144 regions_unexplored:maple_log[axis=y]
setblock 195 73 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 73 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 73 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 73 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 73 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 73 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 73 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 73 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 73 -145 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 73 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 73 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 73 -146 minecraft:spruce_log[axis=y]
setblock 179 73 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 73 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 73 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 73 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 73 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 73 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 73 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 73 -147 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 73 -147 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 73 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 73 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 73 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 73 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 73 -150 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 73 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 73 -151 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 73 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 73 -151 regions_unexplored:maple_log[axis=y]
setblock 194 73 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 73 -151 minecraft:spruce_log[axis=y]
setblock 196 73 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 177 73 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 73 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 73 -152 minecraft:birch_log[axis=y]
setblock 180 73 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 73 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 73 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 73 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 73 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 73 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 179 73 -154 180 73 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 73 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 73 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 73 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 73 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 73 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 73 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 73 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 73 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 73 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 73 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 73 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 73 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 73 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 73 -159 minecraft:birch_log[axis=y]
setblock 160 73 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 73 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 73 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 73 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 73 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 73 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 73 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 73 -160 minecraft:birch_log[axis=y]
setblock 163 73 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 73 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 73 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 73 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 73 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 159 73 -162 160 73 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 73 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 73 -163 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 73 -166 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 73 -167 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 73 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -167 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 73 -168 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 73 -170 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 73 -171 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 73 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 73 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -172 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 73 -172 minecraft:birch_log[axis=y]
setblock 164 73 -172 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 73 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 73 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 73 -173 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 73 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 73 -174 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -175 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 73 -175 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 73 -175 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 73 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 73 -176 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 73 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 73 -176 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 73 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 73 -176 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 73 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 73 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 73 -177 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 73 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 73 -177 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 73 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 73 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 73 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 73 -178 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 73 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 73 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 73 -180 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 73 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 73 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 73 -181 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 73 -181 minecraft:birch_log[axis=y]
setblock 162 73 -181 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 73 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 73 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 73 -182 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 73 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 73 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 73 -185 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 73 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 73 -185 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 73 -186 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 73 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -186 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 73 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 73 -186 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 73 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 73 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 73 -187 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 73 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 73 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 73 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 73 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 73 -187 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 153 73 -188 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 73 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 73 -188 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 73 -188 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 167 73 -188 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 152 72 -127 minecraft:birch_log[axis=y]
fill 156 72 -127 158 72 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 159 72 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 72 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 72 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 72 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 180 72 -127 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 181 72 -127 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 72 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 72 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 72 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 72 -127 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 72 -127 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 72 -127 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 72 -127 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 72 -127 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 72 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 72 -127 regions_unexplored:maple_branch[facing=west]
setblock 198 72 -127 regions_unexplored:maple_log[axis=y]
setblock 199 72 -127 regions_unexplored:maple_branch[facing=east]
setblock 149 72 -128 minecraft:birch_log[axis=y]
setblock 155 72 -128 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 156 72 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 157 72 -128 158 72 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 159 72 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 72 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 72 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 72 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 72 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 72 -128 minecraft:spruce_log[axis=y]
setblock 185 72 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 72 -128 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 72 -128 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 72 -128 regions_unexplored:maple_branch[facing=south]
setblock 191 72 -128 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 72 -128 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 72 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 72 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 72 -128 regions_unexplored:maple_branch[facing=north]
setblock 199 72 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 72 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 156 72 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 157 72 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 158 72 -129 159 72 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 72 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 161 72 -129 162 72 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 72 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 184 72 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 72 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 72 -129 regions_unexplored:maple_branch[facing=west]
setblock 190 72 -129 regions_unexplored:maple_log[axis=y]
setblock 191 72 -129 regions_unexplored:maple_branch[facing=east]
setblock 192 72 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 196 72 -129 197 72 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 72 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 72 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 144 72 -130 minecraft:birch_log[axis=y]
setblock 155 72 -130 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 156 72 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 157 72 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 158 72 -130 159 72 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 160 72 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 161 72 -130 162 72 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 188 72 -130 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 72 -130 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 72 -130 regions_unexplored:maple_branch[facing=north]
setblock 191 72 -130 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 72 -130 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 72 -130 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 72 -131 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 157 72 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 158 72 -131 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 189 72 -131 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 72 -131 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 72 -131 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 72 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 72 -131 minecraft:spruce_log[axis=y]
setblock 197 72 -131 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 72 -132 minecraft:birch_log[axis=y]
setblock 196 72 -132 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 72 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 72 -134 minecraft:birch_log[axis=y]
setblock 185 72 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 72 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 72 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 72 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 72 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 72 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 72 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 72 -135 regions_unexplored:maple_log[axis=y]
setblock 187 72 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 72 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 72 -136 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 72 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 72 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 72 -136 regions_unexplored:maple_log[axis=y]
setblock 158 72 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 72 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 72 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 72 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 72 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 72 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 72 -137 minecraft:birch_log[axis=y]
setblock 148 72 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 72 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 72 -137 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 139 72 -138 minecraft:birch_log[axis=y]
setblock 141 72 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 72 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 72 -138 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 72 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 72 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 72 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 72 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 72 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 72 -139 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 195 72 -139 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 72 -139 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 72 -139 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 72 -139 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 150 72 -140 minecraft:birch_log[axis=y]
setblock 193 72 -140 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 72 -140 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 72 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 72 -140 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 72 -140 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 72 -140 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 72 -140 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 150 72 -141 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 72 -141 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 72 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 72 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 72 -141 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 72 -141 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 72 -141 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 72 -141 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 72 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 72 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 72 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 72 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 72 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 72 -142 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 72 -142 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 72 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 72 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 72 -142 minecraft:spruce_log[axis=y]
setblock 197 72 -142 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 72 -142 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 199 72 -142 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 72 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 72 -143 minecraft:birch_log[axis=y]
setblock 151 72 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 152 72 -143 153 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 72 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 72 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 72 -143 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 177 72 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 72 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 72 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 72 -143 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 191 72 -143 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 72 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 72 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 72 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 72 -143 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 72 -143 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 72 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 72 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 72 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 72 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 72 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 72 -144 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 72 -144 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 176 72 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 177 72 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 72 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 72 -144 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 192 72 -144 regions_unexplored:maple_log[axis=y]
setblock 193 72 -144 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 72 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 72 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 72 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 72 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 198 72 -144 199 72 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 72 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 72 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 176 72 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 72 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 72 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 72 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 72 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 191 72 -145 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 72 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 72 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 72 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 197 72 -145 198 72 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 199 72 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 72 -146 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 72 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 72 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 72 -146 minecraft:spruce_log[axis=y]
setblock 179 72 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 72 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 72 -146 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 72 -146 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 72 -146 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 199 72 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 72 -147 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 176 72 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 72 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 72 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 72 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
fill 180 72 -147 181 72 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 72 -147 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 72 -147 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 199 72 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 72 -148 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 176 72 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 177 72 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 72 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 180 72 -148 181 72 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 185 72 -148 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 136 72 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 72 -149 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 177 72 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 72 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 72 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 72 -149 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 189 72 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 72 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 72 -149 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 72 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 72 -150 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 72 -150 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 72 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 72 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 72 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 72 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 72 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 72 -151 regions_unexplored:maple_log[axis=y]
setblock 193 72 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 72 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 72 -151 minecraft:spruce_log[axis=y]
setblock 196 72 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 72 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -152 minecraft:birch_log[axis=y]
setblock 188 72 -152 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 72 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 72 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 72 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 72 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 72 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 72 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 72 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 72 -153 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 72 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 72 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 72 -155 minecraft:birch_log[axis=y]
setblock 181 72 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 72 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 72 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 72 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 72 -157 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 72 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 72 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 148 72 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 153 72 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 159 72 -159 minecraft:birch_log[axis=y]
setblock 153 72 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 72 -160 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 72 -160 minecraft:birch_log[axis=y]
setblock 149 72 -161 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 150 72 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 72 -161 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 153 72 -161 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 72 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 72 -162 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 159 72 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 72 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 72 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 72 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 72 -166 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 72 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 72 -166 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 72 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 72 -167 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 72 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 72 -168 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 72 -168 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 72 -168 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 72 -170 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 168 72 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 169 72 -171 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 72 -172 minecraft:birch_log[axis=y]
setblock 168 72 -172 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 72 -174 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 72 -175 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 72 -175 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 72 -175 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 72 -175 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 72 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 72 -176 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 72 -176 minecraft:birch_log[axis=y]
setblock 157 72 -176 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 72 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 72 -176 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 72 -176 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 72 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 72 -177 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 72 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 72 -177 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 72 -177 minecraft:birch_log[axis=y]
setblock 160 72 -177 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 72 -177 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 72 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 72 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 72 -178 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 72 -178 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 72 -179 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 72 -180 minecraft:air
setblock 161 72 -181 minecraft:birch_log[axis=y]
setblock 164 72 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 72 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 72 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 72 -185 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 72 -185 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 72 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 72 -186 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 72 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 72 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 72 -186 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 72 -186 minecraft:birch_log[axis=y]
setblock 165 72 -186 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 72 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 72 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 72 -187 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 72 -187 minecraft:birch_log[axis=y]
setblock 155 72 -187 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 72 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 72 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 72 -187 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 72 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 72 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 72 -187 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 168 72 -187 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
fill 151 72 -188 152 72 -188 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 72 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 72 -188 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 72 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 72 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 72 -188 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 167 72 -188 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 168 72 -188 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 154 72 -189 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 166 72 -189 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 167 72 -189 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 165 72 -190 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 141 71 -127 143 71 -127 minecraft:air
setblock 151 71 -127 minecraft:air
setblock 152 71 -127 minecraft:birch_log[axis=y]
setblock 153 71 -127 minecraft:air
fill 156 71 -127 158 71 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 159 71 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 71 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 71 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 71 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 71 -127 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 171 71 -127 173 71 -127 minecraft:air
setblock 181 71 -127 minecraft:air
setblock 182 71 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 71 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 71 -127 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 71 -127 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 71 -127 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
fill 191 71 -127 193 71 -127 minecraft:air
setblock 197 71 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 198 71 -127 regions_unexplored:maple_log[axis=y]
setblock 199 71 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 71 -128 minecraft:air
setblock 149 71 -128 minecraft:birch_log[axis=y]
setblock 152 71 -128 minecraft:air
setblock 155 71 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 156 71 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 157 71 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 71 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 159 71 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 71 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 71 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 71 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 71 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 71 -128 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 172 71 -128 minecraft:air
setblock 182 71 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 71 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 71 -128 minecraft:spruce_log[axis=y]
setblock 185 71 -128 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 71 -128 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -128 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 71 -128 minecraft:air
setblock 198 71 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 71 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 71 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 71 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 158 71 -129 159 71 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 71 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 161 71 -129 162 71 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 71 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 71 -129 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 71 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 71 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 71 -129 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 71 -129 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 71 -129 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 71 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 71 -129 regions_unexplored:maple_log[axis=y]
setblock 191 71 -129 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 71 -130 minecraft:birch_log[axis=y]
setblock 155 71 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 156 71 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 157 71 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 158 71 -130 159 71 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 71 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 161 71 -130 162 71 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 71 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 164 71 -130 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 183 71 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 71 -130 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 71 -130 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 71 -130 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 71 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 157 71 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 158 71 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
fill 161 71 -131 162 71 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 163 71 -131 regions_unexplored:maple_leaves[distance=6,persistent=false,waterlogged=false]
setblock 196 71 -131 minecraft:spruce_log[axis=y]
setblock 143 71 -132 minecraft:birch_log[axis=y]
setblock 184 71 -133 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 185 71 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 71 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 71 -133 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 141 71 -134 minecraft:birch_log[axis=y]
setblock 184 71 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 71 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 71 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 71 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 71 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 71 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 71 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 71 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 71 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 71 -135 regions_unexplored:maple_log[axis=y]
setblock 187 71 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 71 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 71 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 71 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 71 -136 regions_unexplored:maple_log[axis=y]
setblock 158 71 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 71 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 71 -136 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 71 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -136 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 71 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 71 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 71 -137 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 71 -137 minecraft:birch_log[axis=y]
setblock 156 71 -137 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 71 -137 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 71 -137 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 71 -137 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -137 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 139 71 -138 minecraft:birch_log[axis=y]
setblock 141 71 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 71 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 71 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 71 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 142 71 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 143 71 -139 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 71 -140 minecraft:birch_log[axis=y]
setblock 154 71 -141 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 71 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 71 -142 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 71 -142 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -142 regions_unexplored:red_maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 191 71 -142 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 71 -142 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 193 71 -142 194 71 -142 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 71 -142 minecraft:spruce_log[axis=y]
setblock 150 71 -143 minecraft:birch_log[axis=y]
setblock 152 71 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 71 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 71 -143 minecraft:birch_log[axis=y]
setblock 155 71 -143 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 71 -143 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -143 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 71 -143 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 71 -143 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 71 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 71 -144 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 71 -144 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -144 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -144 regions_unexplored:maple_log[axis=y]
setblock 154 71 -145 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 71 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 71 -145 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 71 -145 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 71 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 71 -146 minecraft:spruce_log[axis=y]
setblock 179 71 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
fill 184 71 -146 185 71 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 71 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -146 regions_unexplored:red_maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 71 -146 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 71 -147 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 71 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 71 -147 regions_unexplored:maple_log[axis=y]
setblock 186 71 -147 regions_unexplored:maple_log[axis=y]
setblock 136 71 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 71 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 71 -148 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 71 -148 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 71 -148 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 194 71 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 195 71 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 71 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 197 71 -148 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 136 71 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 71 -149 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 71 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -149 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 191 71 -149 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 192 71 -149 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 71 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 71 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 71 -149 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 71 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 71 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 71 -149 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 136 71 -150 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 187 71 -150 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 71 -150 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -150 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 71 -150 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 71 -150 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 71 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 71 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 71 -150 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 71 -150 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 71 -150 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 71 -150 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 187 71 -151 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 71 -151 regions_unexplored:maple_log[axis=y]
setblock 191 71 -151 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -151 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 193 71 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 71 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 71 -151 minecraft:spruce_log[axis=y]
setblock 196 71 -151 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 197 71 -151 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 198 71 -151 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 71 -152 minecraft:birch_log[axis=y]
setblock 187 71 -152 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 71 -152 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 71 -152 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 193 71 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 194 71 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 195 71 -152 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 196 71 -152 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 197 71 -152 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 198 71 -152 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 146 71 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 71 -153 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 188 71 -153 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 71 -153 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 190 71 -153 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 192 71 -153 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 193 71 -153 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 194 71 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 195 71 -153 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 196 71 -153 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 197 71 -153 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 198 71 -153 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 172 71 -154 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 171 71 -155 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 172 71 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 71 -155 minecraft:birch_log[axis=y]
setblock 172 71 -156 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 71 -156 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 71 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 71 -157 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 173 71 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 174 71 -157 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 176 71 -157 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 183 71 -157 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 71 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 71 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 71 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 71 -158 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 176 71 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 71 -158 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 145 71 -159 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 146 71 -159 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 148 71 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 71 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 71 -159 minecraft:birch_log[axis=y]
setblock 171 71 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 172 71 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 173 71 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 176 71 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 71 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 71 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 71 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 71 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 71 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 71 -160 minecraft:birch_log[axis=y]
setblock 149 71 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 71 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 71 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 71 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 71 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 71 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 71 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 71 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 71 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 71 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 71 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 71 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 71 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 71 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 71 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 71 -165 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 71 -165 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 71 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 71 -166 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 71 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 71 -166 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 71 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 71 -167 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 71 -167 minecraft:birch_log[axis=y]
setblock 162 71 -167 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 71 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 71 -167 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 160 71 -168 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 71 -168 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 71 -168 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 71 -169 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 71 -170 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 71 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 71 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 71 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 71 -171 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 172 71 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 173 71 -171 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 71 -172 minecraft:birch_log[axis=y]
setblock 168 71 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 71 -172 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 71 -176 minecraft:birch_log[axis=y]
setblock 159 71 -177 minecraft:birch_log[axis=y]
setblock 163 71 -178 minecraft:air
fill 162 71 -179 164 71 -179 minecraft:air
fill 161 71 -180 165 71 -180 minecraft:air
setblock 161 71 -181 minecraft:birch_log[axis=y]
fill 162 71 -181 164 71 -181 minecraft:air
setblock 163 71 -182 minecraft:air
setblock 164 71 -186 minecraft:birch_log[axis=y]
setblock 151 71 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 71 -187 minecraft:birch_log[axis=y]
setblock 150 71 -188 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 71 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 71 -188 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 71 -189 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 140 70 -127 144 70 -127 minecraft:air
fill 150 70 -127 151 70 -127 minecraft:air
setblock 152 70 -127 minecraft:birch_log[axis=y]
fill 153 70 -127 154 70 -127 minecraft:air
setblock 156 70 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 157 70 -127 158 70 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 70 -127 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 70 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 70 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 70 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 70 -127 minecraft:air
fill 170 70 -127 174 70 -127 minecraft:air
fill 180 70 -127 184 70 -127 minecraft:air
fill 190 70 -127 194 70 -127 minecraft:air
setblock 198 70 -127 regions_unexplored:maple_log[axis=y]
fill 141 70 -128 143 70 -128 minecraft:air
setblock 149 70 -128 minecraft:birch_log[axis=y]
fill 151 70 -128 153 70 -128 minecraft:air
setblock 155 70 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 70 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
fill 157 70 -128 158 70 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 70 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 70 -128 regions_unexplored:maple_log[axis=y]
setblock 161 70 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 70 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 70 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 70 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 171 70 -128 173 70 -128 minecraft:air
fill 181 70 -128 183 70 -128 minecraft:air
setblock 184 70 -128 minecraft:spruce_log[axis=y]
fill 191 70 -128 193 70 -128 minecraft:air
setblock 155 70 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 70 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 70 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 70 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 70 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 70 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 161 70 -129 162 70 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 70 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 70 -129 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 190 70 -129 regions_unexplored:maple_log[axis=y]
setblock 144 70 -130 minecraft:birch_log[axis=y]
setblock 155 70 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 70 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 70 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 158 70 -130 159 70 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 70 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 161 70 -130 162 70 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 70 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 70 -130 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 156 70 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 157 70 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 70 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 161 70 -131 162 70 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 70 -131 regions_unexplored:maple_leaves[distance=5,persistent=false,waterlogged=false]
setblock 196 70 -131 minecraft:spruce_log[axis=y]
setblock 143 70 -132 minecraft:birch_log[axis=y]
setblock 185 70 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -133 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 70 -133 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 70 -133 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 70 -134 minecraft:birch_log[axis=y]
setblock 156 70 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 70 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 70 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 70 -134 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 184 70 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 70 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 70 -134 regions_unexplored:maple_branch[facing=south]
setblock 187 70 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 70 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 70 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 70 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 70 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 70 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 70 -135 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 70 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 70 -135 regions_unexplored:maple_branch[facing=west]
setblock 186 70 -135 regions_unexplored:maple_log[axis=y]
setblock 187 70 -135 regions_unexplored:maple_branch[facing=east]
setblock 188 70 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 70 -136 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 70 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 70 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 70 -136 regions_unexplored:maple_log[axis=y]
setblock 158 70 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 70 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 70 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 70 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 70 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 70 -136 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 141 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 70 -137 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 70 -137 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 70 -137 minecraft:birch_log[axis=y]
setblock 155 70 -137 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 70 -137 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 70 -137 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 70 -137 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 70 -137 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 70 -137 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 70 -137 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 70 -138 minecraft:birch_log[axis=y]
fill 140 70 -138 141 70 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 142 70 -138 minecraft:birch_log[axis=y]
setblock 143 70 -138 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 144 70 -138 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 70 -138 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 70 -138 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 70 -138 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 70 -138 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 141 70 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 70 -139 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 143 70 -139 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 142 70 -140 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 70 -140 minecraft:birch_log[axis=y]
setblock 191 70 -142 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 192 70 -142 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 193 70 -142 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 194 70 -142 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 196 70 -142 minecraft:spruce_log[axis=y]
setblock 150 70 -143 minecraft:birch_log[axis=y]
setblock 154 70 -143 minecraft:birch_log[axis=y]
setblock 190 70 -143 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 70 -143 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 70 -143 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 70 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 70 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 70 -144 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 192 70 -144 regions_unexplored:maple_log[axis=y]
setblock 176 70 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 70 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 70 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 70 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 70 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 70 -145 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 70 -145 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 191 70 -145 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 194 70 -145 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 70 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 70 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 70 -146 minecraft:spruce_log[axis=y]
setblock 179 70 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 70 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 70 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 184 70 -146 185 70 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 70 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 193 70 -146 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 70 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 70 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 70 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 70 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 70 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 70 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 70 -147 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 70 -147 regions_unexplored:maple_log[axis=y]
setblock 186 70 -147 regions_unexplored:maple_log[axis=y]
setblock 136 70 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 70 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 70 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 70 -148 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 70 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 70 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 70 -148 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 184 70 -148 185 70 -148 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 70 -148 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 136 70 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 137 70 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 70 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 70 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 70 -149 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 70 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 70 -149 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 70 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 136 70 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 70 -150 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 70 -150 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 70 -150 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 191 70 -150 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 70 -151 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 189 70 -151 regions_unexplored:maple_log[axis=y]
setblock 191 70 -151 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 195 70 -151 minecraft:spruce_log[axis=y]
setblock 146 70 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 70 -152 minecraft:birch_log[axis=y]
setblock 187 70 -152 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 70 -152 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 145 70 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 70 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 70 -153 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 188 70 -153 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 70 -153 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 70 -153 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 70 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 70 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 70 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 70 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 70 -155 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 70 -155 minecraft:birch_log[axis=y]
fill 172 70 -156 173 70 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 184 70 -156 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 70 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 70 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 70 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 70 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 173 70 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 70 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 70 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 70 -157 regions_unexplored:maple_log[axis=y]
setblock 145 70 -158 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 147 70 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 70 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 70 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 172 70 -158 173 70 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 70 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 70 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 177 70 -158 178 70 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 144 70 -159 minecraft:birch_leaves[distance=6,persistent=false,waterlogged=false]
setblock 145 70 -159 minecraft:birch_leaves[distance=5,persistent=false,waterlogged=false]
setblock 146 70 -159 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 147 70 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 70 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 70 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 70 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 70 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 70 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 70 -159 minecraft:birch_log[axis=y]
setblock 171 70 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 70 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 70 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 176 70 -159 177 70 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 70 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 70 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 70 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 152 70 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 70 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 70 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 70 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 70 -160 minecraft:birch_log[axis=y]
setblock 172 70 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 70 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 70 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 70 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 70 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 70 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 70 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 70 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 70 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 70 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 70 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 70 -161 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 70 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 70 -161 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 70 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 70 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 70 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 70 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 158 70 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 70 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 70 -162 minecraft:birch_log[axis=y]
setblock 161 70 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 70 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 70 -162 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 149 70 -163 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 156 70 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 70 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 70 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 70 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 70 -163 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 70 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 70 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 70 -164 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 70 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 70 -164 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 165 70 -164 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 171 70 -164 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 164 70 -165 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 177 70 -165 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 70 -166 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 70 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 70 -166 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 70 -167 minecraft:birch_log[axis=y]
setblock 177 70 -167 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 70 -170 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 70 -170 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 70 -170 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 70 -170 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 167 70 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 70 -171 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 169 70 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 70 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 70 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 70 -171 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 70 -172 minecraft:birch_log[axis=y]
setblock 167 70 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 70 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 70 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 70 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 162 70 -178 164 70 -178 minecraft:air
fill 161 70 -179 165 70 -179 minecraft:air
fill 161 70 -180 165 70 -180 minecraft:air
setblock 155 70 -181 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 161 70 -181 165 70 -181 minecraft:air
setblock 154 70 -182 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
setblock 155 70 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 70 -182 minecraft:birch_leaves[distance=4,persistent=false,waterlogged=false]
fill 162 70 -182 164 70 -182 minecraft:air
setblock 150 70 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 70 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 70 -187 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 70 -187 minecraft:birch_log[axis=y]
setblock 150 70 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 70 -188 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 70 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 70 -189 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 70 -189 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 70 -189 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 70 -190 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 141 69 -127 143 69 -127 minecraft:air
setblock 151 69 -127 minecraft:air
setblock 152 69 -127 minecraft:birch_log[axis=y]
setblock 153 69 -127 minecraft:air
setblock 161 69 -127 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 69 -127 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 69 -127 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
fill 171 69 -127 173 69 -127 minecraft:air
fill 181 69 -127 183 69 -127 minecraft:air
fill 191 69 -127 193 69 -127 minecraft:air
setblock 198 69 -127 regions_unexplored:maple_log[axis=y]
setblock 142 69 -128 minecraft:air
setblock 149 69 -128 minecraft:birch_log[axis=y]
setblock 152 69 -128 minecraft:air
setblock 157 69 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 69 -128 regions_unexplored:maple_log[axis=y]
setblock 161 69 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 69 -128 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 69 -128 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 69 -128 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 172 69 -128 minecraft:air
setblock 182 69 -128 minecraft:air
setblock 184 69 -128 minecraft:spruce_log[axis=y]
setblock 192 69 -128 minecraft:air
setblock 148 69 -129 regions_unexplored:grass_sprouts
setblock 156 69 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 69 -129 regions_unexplored:maple_log[axis=x]
setblock 158 69 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 69 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 69 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 69 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 69 -129 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 69 -129 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 190 69 -129 regions_unexplored:maple_log[axis=y]
setblock 144 69 -130 minecraft:birch_log[axis=y]
fill 147 69 -130 148 69 -130 regions_unexplored:grass_sprouts
setblock 157 69 -130 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 160 69 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 69 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 69 -130 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 69 -130 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 69 -130 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 147 69 -131 regions_unexplored:grass_sprouts
setblock 161 69 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 162 69 -131 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 69 -131 regions_unexplored:maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 196 69 -131 minecraft:spruce_log[axis=y]
setblock 142 69 -132 regions_unexplored:grass_sprouts
setblock 143 69 -132 minecraft:birch_log[axis=y]
setblock 141 69 -134 minecraft:birch_log[axis=y]
setblock 156 69 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 69 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 69 -134 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 69 -134 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 69 -134 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 69 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 69 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 69 -135 regions_unexplored:maple_branch[facing=south]
setblock 158 69 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 69 -135 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 69 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 69 -135 regions_unexplored:maple_log[axis=y]
setblock 187 69 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 69 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 69 -136 regions_unexplored:maple_branch[facing=west]
setblock 157 69 -136 regions_unexplored:maple_log[axis=y]
setblock 158 69 -136 regions_unexplored:maple_branch[facing=east]
setblock 159 69 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 69 -137 minecraft:birch_log[axis=y]
setblock 148 69 -137 regions_unexplored:birch_branch[facing=east]
setblock 155 69 -137 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 69 -137 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 69 -137 regions_unexplored:maple_branch[facing=north]
setblock 158 69 -137 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 69 -137 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 139 69 -138 minecraft:birch_log[axis=y]
setblock 142 69 -138 minecraft:birch_log[axis=y]
setblock 156 69 -138 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 69 -138 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 69 -138 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 69 -140 minecraft:birch_log[axis=y]
setblock 196 69 -142 minecraft:spruce_log[axis=y]
setblock 150 69 -143 minecraft:birch_log[axis=y]
setblock 154 69 -143 minecraft:birch_log[axis=y]
setblock 176 69 -143 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 177 69 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 69 -143 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 69 -143 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 69 -143 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 175 69 -144 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 176 69 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 177 69 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 69 -144 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 69 -144 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 69 -144 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 69 -144 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 192 69 -144 regions_unexplored:maple_log[axis=y]
setblock 175 69 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 176 69 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 69 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 69 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 69 -145 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 69 -145 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 69 -145 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 182 69 -145 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 69 -145 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 184 69 -145 185 69 -145 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 69 -145 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 69 -145 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 69 -146 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 69 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 69 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 69 -146 minecraft:spruce_log[axis=y]
setblock 179 69 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 69 -146 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 69 -146 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 69 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 184 69 -146 185 69 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 69 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 69 -146 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 69 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 69 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 69 -147 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 69 -147 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 176 69 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 69 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 69 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 69 -147 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 69 -147 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 69 -147 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 69 -147 regions_unexplored:maple_log[axis=y]
setblock 186 69 -147 regions_unexplored:maple_log[axis=y]
setblock 188 69 -147 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 69 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 69 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 69 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 69 -148 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 176 69 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 177 69 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 69 -148 minecraft:spruce_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 69 -148 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 69 -148 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 181 69 -148 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 69 -148 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 184 69 -148 185 69 -148 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 187 69 -148 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 69 -148 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 147 69 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 69 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 149 69 -149 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 69 -149 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 177 69 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 178 69 -149 minecraft:spruce_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 69 -149 minecraft:spruce_leaves[distance=4,persistent=false,waterlogged=false]
setblock 180 69 -149 minecraft:spruce_leaves[distance=5,persistent=false,waterlogged=false]
setblock 182 69 -149 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 69 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 184 69 -149 185 69 -149 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 186 69 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
fill 187 69 -149 188 69 -149 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 189 69 -151 regions_unexplored:maple_log[axis=y]
setblock 195 69 -151 minecraft:spruce_log[axis=y]
setblock 145 69 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 69 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 69 -152 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 69 -152 minecraft:birch_log[axis=y]
setblock 145 69 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 69 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 69 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 69 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 146 69 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 69 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 69 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 69 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 69 -154 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 69 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 69 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 69 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 69 -155 minecraft:birch_log[axis=y]
setblock 183 69 -155 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 69 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 69 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 172 69 -156 173 69 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 69 -156 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 69 -156 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 69 -156 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 69 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 69 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 69 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 69 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 69 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 174 69 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 69 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 69 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 69 -157 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 69 -157 regions_unexplored:maple_log[axis=y]
setblock 147 69 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 69 -158 minecraft:birch_log[axis=y]
setblock 149 69 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 69 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 69 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 69 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 172 69 -158 173 69 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 174 69 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 175 69 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 69 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 177 69 -158 178 69 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 69 -158 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 69 -158 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 69 -158 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 69 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 149 69 -159 150 69 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 69 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 69 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 69 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 69 -159 minecraft:birch_log[axis=y]
setblock 171 69 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 69 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 69 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 69 -159 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 176 69 -159 177 69 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 69 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 69 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 69 -159 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 69 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 69 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 69 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 69 -160 minecraft:birch_log[axis=y]
setblock 154 69 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 69 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 69 -160 minecraft:birch_log[axis=y]
setblock 171 69 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 69 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 69 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 69 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 178 69 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 179 69 -160 180 69 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 149 69 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 69 -161 minecraft:birch_log[axis=y]
setblock 151 69 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 69 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 69 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 69 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 69 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 69 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 69 -161 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 69 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 69 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 69 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 69 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 69 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 69 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 69 -162 minecraft:birch_log[axis=y]
setblock 171 69 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 69 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 69 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 69 -163 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 69 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 69 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 69 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 69 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 69 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 156 69 -164 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 157 69 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 158 69 -164 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 69 -164 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 69 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 69 -164 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 69 -164 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 69 -165 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 69 -165 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 69 -165 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 69 -165 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 69 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 69 -166 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 69 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 69 -167 minecraft:birch_log[axis=y]
setblock 176 69 -167 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 69 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 69 -167 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 69 -169 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 69 -170 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 69 -170 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 169 69 -170 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 69 -170 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 69 -170 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 69 -170 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 166 69 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 167 69 -171 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 168 69 -171 minecraft:birch_log[axis=y]
setblock 169 69 -171 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 170 69 -171 171 69 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 69 -171 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 69 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 69 -172 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 69 -172 minecraft:birch_log[axis=y]
setblock 167 69 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 69 -172 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 169 69 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 69 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 172 69 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 69 -172 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 69 -173 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 69 -173 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 69 -173 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 168 69 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 69 -174 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 69 -178 minecraft:air
fill 162 69 -179 164 69 -179 minecraft:air
fill 161 69 -180 165 69 -180 minecraft:air
setblock 155 69 -181 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
fill 162 69 -181 164 69 -181 minecraft:air
setblock 154 69 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 69 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 69 -182 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 69 -182 minecraft:air
setblock 155 69 -183 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 151 69 -186 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 69 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 69 -187 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 69 -187 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 69 -187 minecraft:birch_log[axis=y]
setblock 149 69 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 69 -188 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 151 69 -188 minecraft:birch_log[axis=y]
setblock 152 69 -188 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 153 69 -188 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 69 -189 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 69 -189 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 152 69 -189 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 151 69 -190 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 69 -190 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 69 -190 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 69 -190 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 138 68 -127 regions_unexplored:grass_sprouts
fill 146 68 -127 148 68 -127 minecraft:grass_block[snowy=false]
setblock 152 68 -127 minecraft:birch_log[axis=y]
setblock 198 68 -127 regions_unexplored:maple_log[axis=y]
setblock 140 68 -128 regions_unexplored:grass_sprouts
fill 144 68 -128 148 68 -128 minecraft:grass_block[snowy=false]
setblock 149 68 -128 minecraft:birch_log[axis=y]
setblock 159 68 -128 regions_unexplored:maple_log[axis=x]
setblock 160 68 -128 regions_unexplored:maple_log[axis=y]
setblock 161 68 -128 regions_unexplored:maple_log[axis=x]
setblock 162 68 -128 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 68 -128 minecraft:spruce_log[axis=y]
fill 144 68 -129 148 68 -129 minecraft:grass_block[snowy=false]
setblock 158 68 -129 regions_unexplored:maple_log[axis=x]
setblock 161 68 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 68 -129 regions_unexplored:maple_log[axis=x]
setblock 163 68 -129 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 190 68 -129 regions_unexplored:maple_log[axis=y]
setblock 139 68 -130 regions_unexplored:grass_sprouts
setblock 143 68 -130 minecraft:grass_block[snowy=false]
setblock 144 68 -130 minecraft:dirt
fill 145 68 -130 148 68 -130 minecraft:grass_block[snowy=false]
setblock 162 68 -130 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 141 68 -131 142 68 -131 regions_unexplored:grass_sprouts
fill 143 68 -131 148 68 -131 minecraft:grass_block[snowy=false]
setblock 196 68 -131 minecraft:spruce_log[axis=y]
setblock 142 68 -132 minecraft:grass_block[snowy=false]
setblock 143 68 -132 minecraft:dirt
fill 144 68 -132 148 68 -132 minecraft:grass_block[snowy=false]
setblock 141 68 -134 minecraft:birch_log[axis=y]
setblock 136 68 -135 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 68 -135 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 186 68 -135 regions_unexplored:maple_log[axis=y]
setblock 156 68 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 68 -136 regions_unexplored:maple_log[axis=y]
setblock 158 68 -136 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 68 -137 minecraft:birch_log[axis=y]
setblock 157 68 -137 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 139 68 -138 minecraft:birch_log[axis=y]
setblock 142 68 -138 minecraft:birch_log[axis=y]
setblock 150 68 -140 minecraft:birch_log[axis=y]
setblock 196 68 -142 minecraft:spruce_log[axis=y]
setblock 150 68 -143 minecraft:birch_log[axis=y]
setblock 154 68 -143 minecraft:birch_log[axis=y]
setblock 192 68 -144 regions_unexplored:maple_log[axis=y]
setblock 178 68 -145 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 68 -145 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 68 -145 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 184 68 -145 185 68 -145 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 68 -145 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 68 -145 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 68 -146 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 68 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 68 -146 minecraft:spruce_log[axis=y]
setblock 179 68 -146 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 68 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 68 -146 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 184 68 -146 185 68 -146 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 68 -146 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 68 -146 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 68 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 68 -147 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 68 -147 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 68 -147 minecraft:spruce_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 68 -147 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 68 -147 regions_unexplored:maple_log[axis=y]
setblock 186 68 -147 regions_unexplored:maple_log[axis=y]
setblock 188 68 -147 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 68 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 68 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 68 -148 minecraft:birch_log[axis=y]
setblock 149 68 -148 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 150 68 -148 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 68 -148 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 68 -148 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 184 68 -148 185 68 -148 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 68 -148 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 188 68 -148 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 147 68 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 68 -149 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 149 68 -149 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 68 -149 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 68 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 68 -149 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 184 68 -149 185 68 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 186 68 -149 regions_unexplored:maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 187 68 -149 regions_unexplored:maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 188 68 -149 regions_unexplored:maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 148 68 -150 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 68 -151 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 189 68 -151 regions_unexplored:maple_log[axis=y]
setblock 195 68 -151 minecraft:spruce_log[axis=y]
setblock 145 68 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 68 -152 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 68 -152 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 68 -152 minecraft:birch_log[axis=y]
setblock 144 68 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 68 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 146 68 -153 minecraft:birch_log[axis=y]
setblock 147 68 -153 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 68 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -153 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 145 68 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 68 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 147 68 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 68 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -154 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 68 -154 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 146 68 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 170 68 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 68 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 68 -155 minecraft:birch_log[axis=y]
setblock 173 68 -155 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 174 68 -155 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 68 -155 minecraft:birch_log[axis=y]
setblock 181 68 -155 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
fill 182 68 -155 183 68 -155 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 68 -155 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 68 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 172 68 -156 173 68 -156 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 174 68 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 68 -156 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 181 68 -156 182 68 -156 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 68 -156 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 68 -156 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 68 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 68 -157 minecraft:birch_log[axis=y]
setblock 174 68 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 175 68 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 68 -157 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 177 68 -157 178 68 -157 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 68 -157 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 68 -157 regions_unexplored:maple_log[axis=y]
setblock 185 68 -157 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 148 68 -158 minecraft:birch_log[axis=y]
setblock 171 68 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 172 68 -158 173 68 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 174 68 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 68 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 176 68 -158 minecraft:birch_log[axis=y]
fill 177 68 -158 178 68 -158 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 68 -158 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 68 -158 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 68 -158 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 68 -158 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 68 -158 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 68 -159 minecraft:birch_log[axis=y]
setblock 170 68 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 68 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 68 -159 minecraft:birch_log[axis=y]
setblock 173 68 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 174 68 -159 175 68 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 176 68 -159 177 68 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 68 -159 minecraft:birch_log[axis=y]
setblock 179 68 -159 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 68 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 68 -159 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 183 68 -159 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 184 68 -159 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 185 68 -159 regions_unexplored:red_maple_leaves[distance=4,persistent=false,waterlogged=false]
setblock 153 68 -160 minecraft:birch_log[axis=y]
setblock 162 68 -160 minecraft:birch_log[axis=y]
setblock 171 68 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 68 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 176 68 -160 177 68 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 68 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
fill 179 68 -160 180 68 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 68 -160 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 150 68 -161 minecraft:birch_log[axis=y]
setblock 157 68 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
fill 178 68 -161 179 68 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 68 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 68 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 68 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 68 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 68 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 68 -162 minecraft:birch_log[axis=y]
setblock 170 68 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 68 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 179 68 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 180 68 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 181 68 -162 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 68 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 68 -163 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 68 -163 minecraft:birch_log[axis=y]
setblock 158 68 -163 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 159 68 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 68 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 68 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 68 -163 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 170 68 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 68 -163 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 68 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 68 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 68 -164 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 158 68 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 68 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 68 -164 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 68 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 170 68 -164 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 171 68 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -164 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 177 68 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 68 -165 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 68 -165 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 164 68 -165 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 165 68 -165 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 176 68 -165 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 68 -165 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 68 -165 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 175 68 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 176 68 -166 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 177 68 -166 minecraft:birch_log[axis=y]
setblock 178 68 -166 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 179 68 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 68 -167 minecraft:birch_log[axis=y]
setblock 176 68 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 68 -167 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 178 68 -167 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 68 -168 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -169 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 68 -170 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -170 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 68 -170 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 68 -171 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 161 68 -171 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 162 68 -171 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 68 -171 minecraft:birch_log[axis=y]
setblock 170 68 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 68 -171 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 68 -171 minecraft:birch_log[axis=y]
setblock 173 68 -171 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 174 68 -171 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 68 -172 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 68 -172 herbsandharvest:pear_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 162 68 -172 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 68 -172 minecraft:birch_log[axis=y]
setblock 171 68 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 172 68 -172 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 68 -172 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 68 -173 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 68 -173 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 68 -173 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 68 -173 herbsandharvest:pear_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 172 68 -173 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 68 -174 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 68 -174 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 163 68 -174 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 68 -175 herbsandharvest:fruit_leaves[distance=4,persistent=false,waterlogged=false]
setblock 163 68 -180 minecraft:air
setblock 154 68 -181 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 68 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 68 -181 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 68 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 68 -182 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 68 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 68 -183 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 68 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 156 68 -183 minecraft:birch_leaves[distance=3,persistent=false,waterlogged=false]
setblock 154 68 -187 minecraft:birch_log[axis=y]
setblock 151 68 -188 minecraft:birch_log[axis=y]
setblock 153 68 -189 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 152 68 -190 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 68 -190 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 154 68 -190 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 136 67 -127 minecraft:short_grass
fill 138 67 -127 145 67 -127 minecraft:grass_block[snowy=false]
fill 146 67 -127 148 67 -127 minecraft:dirt
fill 149 67 -127 151 67 -127 minecraft:grass_block[snowy=false]
setblock 152 67 -127 minecraft:birch_log[axis=y]
setblock 196 67 -127 minecraft:short_grass
setblock 197 67 -127 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 198 67 -127 regions_unexplored:maple_log[axis=y]
fill 137 67 -128 143 67 -128 minecraft:grass_block[snowy=false]
fill 144 67 -128 149 67 -128 minecraft:dirt
setblock 150 67 -128 minecraft:grass_block[snowy=false]
setblock 160 67 -128 regions_unexplored:maple_log[axis=y]
setblock 184 67 -128 minecraft:spruce_log[axis=y]
setblock 190 67 -128 minecraft:short_grass
setblock 195 67 -128 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
fill 198 67 -128 199 67 -128 minecraft:brown_mushroom
fill 139 67 -129 143 67 -129 minecraft:grass_block[snowy=false]
fill 144 67 -129 148 67 -129 minecraft:dirt
setblock 149 67 -129 minecraft:grass_block[snowy=false]
setblock 190 67 -129 regions_unexplored:maple_log[axis=y]
setblock 192 67 -129 regions_unexplored:red_maple_leaf_litter[facing=north,flower_amount=3]
setblock 194 67 -129 regions_unexplored:grass_sprouts
setblock 195 67 -129 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
fill 196 67 -129 198 67 -129 minecraft:brown_mushroom
fill 139 67 -130 142 67 -130 minecraft:grass_block[snowy=false]
fill 143 67 -130 148 67 -130 minecraft:dirt
setblock 149 67 -130 minecraft:grass_block[snowy=false]
setblock 196 67 -130 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
setblock 197 67 -130 regions_unexplored:grass_sprouts
setblock 198 67 -130 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
fill 140 67 -131 142 67 -131 minecraft:grass_block[snowy=false]
fill 143 67 -131 148 67 -131 minecraft:dirt
setblock 149 67 -131 minecraft:grass_block[snowy=false]
setblock 192 67 -131 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=4]
setblock 196 67 -131 minecraft:spruce_log[axis=y]
fill 140 67 -132 141 67 -132 minecraft:grass_block[snowy=false]
fill 142 67 -132 148 67 -132 minecraft:dirt
setblock 149 67 -132 minecraft:grass_block[snowy=false]
setblock 143 67 -133 regions_unexplored:grass_sprouts
setblock 146 67 -133 regions_unexplored:grass_sprouts
setblock 148 67 -133 regions_unexplored:grass_sprouts
setblock 141 67 -134 minecraft:birch_log[axis=y]
setblock 186 67 -135 regions_unexplored:maple_log[axis=y]
setblock 157 67 -136 regions_unexplored:maple_log[axis=y]
setblock 192 67 -136 minecraft:moss_carpet
setblock 147 67 -137 minecraft:birch_log[axis=y]
setblock 139 67 -138 minecraft:birch_log[axis=y]
setblock 142 67 -138 minecraft:birch_log[axis=y]
setblock 192 67 -138 minecraft:moss_carpet
setblock 150 67 -140 minecraft:birch_log[axis=y]
setblock 196 67 -142 minecraft:spruce_log[axis=y]
setblock 198 67 -142 regions_unexplored:grass_sprouts
setblock 150 67 -143 minecraft:birch_log[axis=y]
setblock 154 67 -143 minecraft:birch_log[axis=y]
setblock 192 67 -144 regions_unexplored:maple_log[axis=y]
setblock 197 67 -145 regions_unexplored:grass_sprouts
setblock 178 67 -146 minecraft:spruce_log[axis=y]
setblock 183 67 -147 regions_unexplored:maple_log[axis=y]
setblock 186 67 -147 regions_unexplored:maple_log[axis=y]
setblock 148 67 -148 minecraft:birch_log[axis=y]
setblock 189 67 -151 regions_unexplored:maple_log[axis=y]
setblock 195 67 -151 minecraft:spruce_log[axis=y]
setblock 179 67 -152 minecraft:birch_log[axis=y]
setblock 146 67 -153 minecraft:birch_log[axis=y]
setblock 172 67 -155 minecraft:birch_log[axis=y]
setblock 180 67 -155 minecraft:birch_log[axis=y]
setblock 181 67 -155 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 67 -155 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 67 -155 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 67 -155 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 67 -155 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 181 67 -156 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 67 -156 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 67 -156 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 67 -156 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 173 67 -157 minecraft:birch_log[axis=y]
setblock 181 67 -157 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 183 67 -157 regions_unexplored:maple_log[axis=y]
setblock 185 67 -157 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 148 67 -158 minecraft:birch_log[axis=y]
setblock 176 67 -158 minecraft:birch_log[axis=y]
setblock 181 67 -158 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 67 -158 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 67 -158 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 67 -158 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 159 67 -159 minecraft:birch_log[axis=y]
setblock 172 67 -159 minecraft:birch_log[axis=y]
setblock 178 67 -159 minecraft:birch_log[axis=y]
setblock 180 67 -159 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 182 67 -159 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 183 67 -159 regions_unexplored:red_maple_leaves[distance=1,persistent=false,waterlogged=false]
setblock 184 67 -159 regions_unexplored:red_maple_leaves[distance=2,persistent=false,waterlogged=false]
setblock 185 67 -159 regions_unexplored:red_maple_leaves[distance=3,persistent=false,waterlogged=false]
setblock 153 67 -160 minecraft:birch_log[axis=y]
setblock 162 67 -160 minecraft:birch_log[axis=y]
setblock 179 67 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 67 -160 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 67 -160 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 150 67 -161 minecraft:birch_log[axis=y]
setblock 171 67 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 178 67 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 67 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 180 67 -161 minecraft:birch_log[axis=y]
setblock 181 67 -161 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 182 67 -161 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 67 -162 minecraft:birch_log[axis=y]
setblock 164 67 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 170 67 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 67 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 67 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 179 67 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 67 -162 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 181 67 -162 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 157 67 -163 minecraft:birch_log[axis=y]
setblock 163 67 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 67 -163 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 67 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 169 67 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 170 67 -163 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 171 67 -163 minecraft:birch_log[axis=y]
setblock 172 67 -163 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 173 67 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 180 67 -163 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 67 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 67 -164 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 164 67 -164 minecraft:birch_log[axis=y]
setblock 165 67 -164 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 166 67 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 170 67 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 67 -164 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 172 67 -164 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 67 -165 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 67 -165 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 165 67 -165 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 171 67 -165 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 164 67 -166 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 177 67 -166 minecraft:birch_log[axis=y]
setblock 161 67 -167 minecraft:birch_log[axis=y]
setblock 160 67 -171 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
fill 161 67 -171 162 67 -171 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 67 -171 minecraft:birch_log[axis=y]
setblock 172 67 -171 minecraft:birch_log[axis=y]
setblock 160 67 -172 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 67 -172 herbsandharvest:pear_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 162 67 -172 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 67 -172 minecraft:birch_log[axis=y]
setblock 160 67 -173 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 67 -173 minecraft:oak_log[axis=y]
fill 162 67 -173 163 67 -173 herbsandharvest:pear_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 161 67 -174 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
fill 162 67 -174 163 67 -174 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 67 -175 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 155 67 -180 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 163 67 -180 minecraft:air
setblock 154 67 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 67 -181 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 67 -181 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 153 67 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 67 -182 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 155 67 -182 minecraft:birch_log[axis=y]
setblock 156 67 -182 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 157 67 -182 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 67 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 67 -183 minecraft:birch_leaves[distance=1,persistent=false,waterlogged=false]
setblock 156 67 -183 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 155 67 -184 minecraft:birch_leaves[distance=2,persistent=false,waterlogged=false]
setblock 154 67 -187 minecraft:birch_log[axis=y]
setblock 151 67 -188 minecraft:birch_log[axis=y]
fill 136 66 -127 137 66 -127 minecraft:grass_block[snowy=false]
fill 138 66 -127 152 66 -127 minecraft:dirt
setblock 187 66 -127 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=2]
setblock 189 66 -127 regions_unexplored:grass_sprouts
setblock 190 66 -127 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=4]
setblock 193 66 -127 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=3]
fill 194 66 -127 197 66 -127 minecraft:grass_block[snowy=false]
setblock 198 66 -127 minecraft:dirt
setblock 199 66 -127 minecraft:grass_block[snowy=false]
setblock 136 66 -128 minecraft:grass_block[snowy=false]
fill 137 66 -128 150 66 -128 minecraft:dirt
fill 151 66 -128 152 66 -128 minecraft:grass_block[snowy=false]
setblock 160 66 -128 regions_unexplored:maple_log[axis=y]
setblock 184 66 -128 minecraft:spruce_log[axis=y]
setblock 189 66 -128 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=3]
fill 190 66 -128 199 66 -128 minecraft:grass_block[snowy=false]
fill 136 66 -129 138 66 -129 minecraft:grass_block[snowy=false]
fill 139 66 -129 149 66 -129 minecraft:dirt
fill 150 66 -129 151 66 -129 minecraft:grass_block[snowy=false]
setblock 185 66 -129 regions_unexplored:grass_sprouts
setblock 186 66 -129 minecraft:short_grass
setblock 187 66 -129 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=1]
setblock 189 66 -129 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=2]
setblock 190 66 -129 regions_unexplored:maple_log[axis=y]
fill 191 66 -129 199 66 -129 minecraft:grass_block[snowy=false]
setblock 138 66 -130 minecraft:grass_block[snowy=false]
fill 139 66 -130 149 66 -130 minecraft:dirt
setblock 150 66 -130 minecraft:grass_block[snowy=false]
setblock 188 66 -130 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=4]
fill 191 66 -130 199 66 -130 minecraft:grass_block[snowy=false]
setblock 139 66 -131 minecraft:grass_block[snowy=false]
fill 140 66 -131 149 66 -131 minecraft:dirt
setblock 189 66 -131 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=3]
fill 191 66 -131 195 66 -131 minecraft:grass_block[snowy=false]
setblock 196 66 -131 minecraft:dirt
fill 197 66 -131 199 66 -131 minecraft:grass_block[snowy=false]
setblock 139 66 -132 minecraft:grass_block[snowy=false]
fill 140 66 -132 149 66 -132 minecraft:dirt
setblock 150 66 -132 minecraft:short_grass
setblock 186 66 -132 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
setblock 188 66 -132 regions_unexplored:red_maple_leaf_litter[facing=north,flower_amount=1]
setblock 191 66 -132 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=2]
fill 192 66 -132 199 66 -132 minecraft:grass_block[snowy=false]
fill 140 66 -133 148 66 -133 minecraft:grass_block[snowy=false]
setblock 183 66 -133 minecraft:lily_of_the_valley
setblock 188 66 -133 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
setblock 189 66 -133 minecraft:short_grass
setblock 192 66 -133 regions_unexplored:maple_log[axis=y]
fill 194 66 -133 199 66 -133 minecraft:grass_block[snowy=false]
setblock 140 66 -134 minecraft:grass_block[snowy=false]
setblock 141 66 -134 minecraft:dirt
setblock 143 66 -134 regions_unexplored:grass_sprouts
setblock 188 66 -134 minecraft:short_grass
setblock 189 66 -134 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 190 66 -134 minecraft:short_grass
fill 195 66 -134 199 66 -134 minecraft:grass_block[snowy=false]
setblock 186 66 -135 regions_unexplored:maple_log[axis=y]
setblock 187 66 -135 minecraft:short_grass
setblock 188 66 -135 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
setblock 189 66 -135 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=3]
fill 195 66 -135 199 66 -135 minecraft:grass_block[snowy=false]
setblock 157 66 -136 regions_unexplored:maple_log[axis=y]
setblock 191 66 -136 regions_unexplored:grass_sprouts
setblock 192 66 -136 regions_unexplored:maple_log[axis=z]
fill 195 66 -136 199 66 -136 minecraft:grass_block[snowy=false]
setblock 147 66 -137 minecraft:birch_log[axis=y]
setblock 189 66 -137 regions_unexplored:grass_sprouts
setblock 192 66 -137 regions_unexplored:maple_log[axis=z]
fill 195 66 -137 199 66 -137 minecraft:grass_block[snowy=false]
setblock 139 66 -138 minecraft:birch_log[axis=y]
setblock 142 66 -138 minecraft:birch_log[axis=y]
setblock 192 66 -138 regions_unexplored:maple_log[axis=z]
setblock 193 66 -138 minecraft:moss_carpet
fill 195 66 -138 199 66 -138 minecraft:grass_block[snowy=false]
setblock 192 66 -139 regions_unexplored:maple_log[axis=z]
fill 195 66 -139 199 66 -139 minecraft:grass_block[snowy=false]
setblock 150 66 -140 minecraft:birch_log[axis=y]
setblock 192 66 -140 regions_unexplored:maple_log[axis=z]
fill 196 66 -140 199 66 -140 minecraft:grass_block[snowy=false]
fill 196 66 -141 199 66 -141 minecraft:grass_block[snowy=false]
setblock 194 66 -142 regions_unexplored:grass_sprouts
setblock 196 66 -142 minecraft:dirt
fill 197 66 -142 199 66 -142 minecraft:grass_block[snowy=false]
setblock 150 66 -143 minecraft:birch_log[axis=y]
setblock 154 66 -143 minecraft:birch_log[axis=y]
setblock 194 66 -143 regions_unexplored:grass_sprouts
fill 197 66 -143 199 66 -143 minecraft:grass_block[snowy=false]
setblock 192 66 -144 regions_unexplored:maple_log[axis=y]
setblock 197 66 -145 minecraft:grass_block[snowy=false]
setblock 178 66 -146 minecraft:spruce_log[axis=y]
fill 198 66 -146 199 66 -146 minecraft:grass_block[snowy=false]
setblock 183 66 -147 regions_unexplored:maple_log[axis=y]
setblock 186 66 -147 regions_unexplored:maple_log[axis=y]
fill 198 66 -147 199 66 -147 minecraft:grass_block[snowy=false]
setblock 148 66 -148 minecraft:birch_log[axis=y]
setblock 197 66 -148 regions_unexplored:grass_sprouts
setblock 199 66 -148 minecraft:grass_block[snowy=false]
setblock 189 66 -151 regions_unexplored:maple_log[axis=y]
setblock 195 66 -151 minecraft:spruce_log[axis=y]
setblock 197 66 -151 minecraft:short_grass
setblock 179 66 -152 minecraft:birch_log[axis=y]
setblock 146 66 -153 minecraft:birch_log[axis=y]
setblock 172 66 -155 minecraft:birch_log[axis=y]
setblock 180 66 -155 minecraft:birch_log[axis=y]
setblock 173 66 -157 minecraft:birch_log[axis=y]
setblock 183 66 -157 regions_unexplored:maple_log[axis=y]
setblock 148 66 -158 minecraft:birch_log[axis=y]
setblock 176 66 -158 minecraft:birch_log[axis=y]
setblock 159 66 -159 minecraft:birch_log[axis=y]
setblock 172 66 -159 minecraft:birch_log[axis=y]
setblock 178 66 -159 minecraft:birch_log[axis=y]
setblock 153 66 -160 minecraft:birch_log[axis=y]
setblock 162 66 -160 minecraft:birch_log[axis=y]
setblock 150 66 -161 minecraft:birch_log[axis=y]
setblock 180 66 -161 minecraft:birch_log[axis=y]
setblock 160 66 -162 minecraft:birch_log[axis=y]
setblock 157 66 -163 minecraft:birch_log[axis=y]
setblock 171 66 -163 minecraft:birch_log[axis=y]
setblock 164 66 -164 minecraft:birch_log[axis=y]
setblock 177 66 -166 minecraft:birch_log[axis=y]
setblock 161 66 -167 minecraft:birch_log[axis=y]
setblock 160 66 -171 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 66 -171 herbsandharvest:pear_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 162 66 -171 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 168 66 -171 minecraft:birch_log[axis=y]
setblock 172 66 -171 minecraft:birch_log[axis=y]
setblock 159 66 -172 herbsandharvest:pear_fruit_leaves[age=2,distance=3,persistent=false,waterlogged=false]
setblock 160 66 -172 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 66 -172 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 162 66 -172 herbsandharvest:pear_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 163 66 -172 minecraft:birch_log[axis=y]
setblock 159 66 -173 herbsandharvest:pear_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 160 66 -173 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 66 -173 minecraft:oak_log[axis=y]
setblock 162 66 -173 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 163 66 -173 herbsandharvest:pear_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 159 66 -174 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 160 66 -174 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 161 66 -174 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
fill 162 66 -174 163 66 -174 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 160 66 -175 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 161 66 -175 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
setblock 162 66 -175 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 159 66 -177 minecraft:birch_log[axis=y]
setblock 160 66 -177 regions_unexplored:birch_branch[facing=east]
setblock 163 66 -180 minecraft:air
setblock 161 66 -181 minecraft:birch_log[axis=y]
setblock 155 66 -182 minecraft:birch_log[axis=y]
setblock 161 66 -185 minecraft:birch_log[axis=y]
setblock 164 66 -186 minecraft:birch_log[axis=y]
setblock 154 66 -187 minecraft:birch_log[axis=y]
setblock 151 66 -188 minecraft:birch_log[axis=y]
setblock 167 66 -188 minecraft:birch_log[axis=y]
fill 136 65 -127 152 65 -127 minecraft:dirt
fill 154 65 -127 176 65 -127 minecraft:air
fill 177 65 -127 179 65 -127 minecraft:stone
setblock 180 65 -127 regions_unexplored:mossy_stone
setblock 181 65 -127 minecraft:coarse_dirt
fill 194 65 -127 199 65 -127 minecraft:dirt
fill 136 65 -128 152 65 -128 minecraft:dirt
fill 154 65 -128 159 65 -128 minecraft:air
setblock 160 65 -128 regions_unexplored:maple_log[axis=y]
fill 161 65 -128 176 65 -128 minecraft:air
fill 177 65 -128 179 65 -128 minecraft:stone
fill 180 65 -128 181 65 -128 minecraft:coarse_dirt
setblock 184 65 -128 minecraft:dirt
fill 190 65 -128 199 65 -128 minecraft:dirt
fill 136 65 -129 151 65 -129 minecraft:dirt
fill 153 65 -129 177 65 -129 minecraft:air
setblock 178 65 -129 minecraft:stone
fill 179 65 -129 181 65 -129 minecraft:coarse_dirt
fill 190 65 -129 199 65 -129 minecraft:dirt
setblock 136 65 -130 minecraft:air
fill 138 65 -130 150 65 -130 minecraft:dirt
fill 152 65 -130 179 65 -130 minecraft:air
fill 191 65 -130 199 65 -130 minecraft:dirt
fill 136 65 -131 137 65 -131 minecraft:air
fill 139 65 -131 149 65 -131 minecraft:dirt
fill 151 65 -131 180 65 -131 minecraft:air
fill 191 65 -131 199 65 -131 minecraft:dirt
fill 136 65 -132 137 65 -132 minecraft:air
fill 139 65 -132 149 65 -132 minecraft:dirt
fill 151 65 -132 181 65 -132 minecraft:air
fill 192 65 -132 199 65 -132 minecraft:dirt
fill 136 65 -133 138 65 -133 minecraft:air
fill 140 65 -133 148 65 -133 minecraft:dirt
fill 150 65 -133 181 65 -133 minecraft:air
setblock 182 65 -133 minecraft:lily_of_the_valley
setblock 192 65 -133 minecraft:dirt
fill 194 65 -133 199 65 -133 minecraft:dirt
fill 136 65 -134 139 65 -134 minecraft:air
fill 140 65 -134 141 65 -134 minecraft:dirt
setblock 148 65 -134 minecraft:air
setblock 149 65 -134 minecraft:short_grass
fill 150 65 -134 180 65 -134 minecraft:air
fill 181 65 -134 182 65 -134 minecraft:lily_of_the_valley
fill 183 65 -134 184 65 -134 minecraft:air
fill 195 65 -134 199 65 -134 minecraft:dirt
fill 136 65 -135 177 65 -135 minecraft:air
setblock 178 65 -135 regions_unexplored:grass_sprouts
fill 179 65 -135 185 65 -135 minecraft:air
setblock 186 65 -135 regions_unexplored:maple_log[axis=y]
fill 195 65 -135 199 65 -135 minecraft:dirt
fill 136 65 -136 156 65 -136 minecraft:air
setblock 157 65 -136 regions_unexplored:maple_log[axis=y]
fill 158 65 -136 185 65 -136 minecraft:air
setblock 187 65 -136 minecraft:air
setblock 192 65 -136 minecraft:dirt
fill 195 65 -136 199 65 -136 minecraft:dirt
fill 136 65 -137 146 65 -137 minecraft:air
setblock 147 65 -137 minecraft:birch_log[axis=y]
fill 148 65 -137 183 65 -137 minecraft:air
fill 186 65 -137 188 65 -137 minecraft:air
setblock 192 65 -137 minecraft:dirt
fill 195 65 -137 199 65 -137 minecraft:dirt
fill 136 65 -138 138 65 -138 minecraft:air
setblock 139 65 -138 minecraft:birch_log[axis=y]
fill 140 65 -138 141 65 -138 minecraft:air
setblock 142 65 -138 minecraft:birch_log[axis=y]
fill 143 65 -138 185 65 -138 minecraft:air
setblock 186 65 -138 regions_unexplored:grass_sprouts
fill 187 65 -138 188 65 -138 minecraft:air
setblock 189 65 -138 minecraft:short_grass
setblock 192 65 -138 minecraft:dirt
fill 195 65 -138 199 65 -138 minecraft:dirt
fill 136 65 -139 190 65 -139 minecraft:air
setblock 192 65 -139 minecraft:dirt
fill 195 65 -139 199 65 -139 minecraft:dirt
fill 136 65 -140 149 65 -140 minecraft:air
setblock 150 65 -140 minecraft:birch_log[axis=y]
fill 151 65 -140 189 65 -140 minecraft:air
setblock 190 65 -140 minecraft:short_grass
setblock 192 65 -140 minecraft:dirt
fill 196 65 -140 199 65 -140 minecraft:dirt
fill 136 65 -141 189 65 -141 minecraft:air
setblock 190 65 -141 regions_unexplored:grass_sprouts
fill 196 65 -141 199 65 -141 minecraft:dirt
fill 136 65 -142 191 65 -142 minecraft:air
fill 195 65 -142 197 65 -142 minecraft:air
fill 198 65 -142 199 65 -142 minecraft:dirt
fill 136 65 -143 149 65 -143 minecraft:air
setblock 150 65 -143 minecraft:birch_log[axis=y]
fill 151 65 -143 153 65 -143 minecraft:air
setblock 154 65 -143 minecraft:birch_log[axis=y]
fill 155 65 -143 188 65 -143 minecraft:air
fill 190 65 -143 191 65 -143 minecraft:air
fill 195 65 -143 199 65 -143 minecraft:air
fill 136 65 -144 188 65 -144 minecraft:air
setblock 189 65 -144 minecraft:short_grass
setblock 190 65 -144 minecraft:air
setblock 192 65 -144 minecraft:dirt
fill 196 65 -144 199 65 -144 minecraft:air
fill 136 65 -145 189 65 -145 minecraft:air
setblock 191 65 -145 minecraft:air
fill 197 65 -145 199 65 -145 minecraft:air
fill 136 65 -146 177 65 -146 minecraft:air
setblock 178 65 -146 minecraft:spruce_log[axis=y]
fill 179 65 -146 182 65 -146 minecraft:air
fill 184 65 -146 185 65 -146 minecraft:air
fill 187 65 -146 188 65 -146 minecraft:air
setblock 190 65 -146 minecraft:short_grass
setblock 198 65 -146 minecraft:dirt
setblock 199 65 -146 minecraft:air
fill 136 65 -147 150 65 -147 minecraft:air
fill 151 65 -147 154 65 -147 minecraft:cave_air
fill 155 65 -147 181 65 -147 minecraft:air
setblock 183 65 -147 regions_unexplored:maple_log[axis=y]
setblock 186 65 -147 regions_unexplored:maple_log[axis=y]
fill 188 65 -147 190 65 -147 minecraft:air
setblock 192 65 -147 minecraft:air
fill 198 65 -147 199 65 -147 minecraft:dirt
fill 136 65 -148 147 65 -148 minecraft:air
setblock 148 65 -148 minecraft:birch_log[axis=y]
fill 149 65 -148 150 65 -148 minecraft:air
fill 151 65 -148 154 65 -148 minecraft:cave_air
fill 155 65 -148 182 65 -148 minecraft:air
fill 184 65 -148 185 65 -148 minecraft:air
fill 187 65 -148 192 65 -148 minecraft:air
setblock 199 65 -148 minecraft:dirt
fill 136 65 -149 151 65 -149 minecraft:air
fill 152 65 -149 155 65 -149 minecraft:cave_air
fill 156 65 -149 192 65 -149 minecraft:air
fill 136 65 -150 151 65 -150 minecraft:air
fill 152 65 -150 155 65 -150 minecraft:cave_air
fill 156 65 -150 188 65 -150 minecraft:air
fill 190 65 -150 193 65 -150 minecraft:air
fill 136 65 -151 149 65 -151 minecraft:air
setblock 150 65 -151 minecraft:cave_air
fill 151 65 -151 152 65 -151 minecraft:air
fill 153 65 -151 154 65 -151 minecraft:cave_air
fill 155 65 -151 187 65 -151 minecraft:air
setblock 189 65 -151 regions_unexplored:maple_log[axis=y]
setblock 191 65 -151 minecraft:air
setblock 193 65 -151 minecraft:air
setblock 195 65 -151 minecraft:dirt
fill 136 65 -152 178 65 -152 minecraft:air
setblock 179 65 -152 minecraft:birch_log[axis=y]
fill 180 65 -152 188 65 -152 minecraft:air
fill 192 65 -152 194 65 -152 minecraft:air
fill 136 65 -153 145 65 -153 minecraft:air
setblock 146 65 -153 minecraft:birch_log[axis=y]
fill 147 65 -153 154 65 -153 minecraft:air
setblock 155 65 -153 minecraft:cave_air
fill 156 65 -153 190 65 -153 minecraft:air
fill 192 65 -153 194 65 -153 minecraft:air
fill 136 65 -154 195 65 -154 minecraft:air
fill 136 65 -155 171 65 -155 minecraft:air
setblock 172 65 -155 minecraft:birch_log[axis=y]
fill 173 65 -155 179 65 -155 minecraft:air
setblock 180 65 -155 minecraft:birch_log[axis=y]
fill 181 65 -155 196 65 -155 minecraft:air
fill 136 65 -156 182 65 -156 minecraft:air
fill 184 65 -156 188 65 -156 minecraft:air
setblock 189 65 -156 regions_unexplored:maple_log[axis=y]
fill 190 65 -156 195 65 -156 minecraft:air
setblock 197 65 -156 minecraft:air
fill 136 65 -157 172 65 -157 minecraft:air
setblock 173 65 -157 minecraft:birch_log[axis=y]
fill 174 65 -157 181 65 -157 minecraft:air
setblock 183 65 -157 regions_unexplored:maple_log[axis=y]
fill 185 65 -157 198 65 -157 minecraft:air
fill 136 65 -158 147 65 -158 minecraft:air
setblock 148 65 -158 minecraft:birch_log[axis=y]
fill 149 65 -158 175 65 -158 minecraft:air
setblock 176 65 -158 minecraft:birch_log[axis=y]
fill 177 65 -158 182 65 -158 minecraft:air
fill 184 65 -158 199 65 -158 minecraft:air
fill 136 65 -159 158 65 -159 minecraft:air
setblock 159 65 -159 minecraft:birch_log[axis=y]
fill 160 65 -159 171 65 -159 minecraft:air
setblock 172 65 -159 minecraft:birch_log[axis=y]
fill 173 65 -159 177 65 -159 minecraft:air
setblock 178 65 -159 minecraft:birch_log[axis=y]
fill 179 65 -159 196 65 -159 minecraft:air
setblock 197 65 -159 regions_unexplored:grass_sprouts
setblock 198 65 -159 minecraft:short_grass
setblock 199 65 -159 minecraft:air
fill 136 65 -160 152 65 -160 minecraft:air
setblock 153 65 -160 minecraft:birch_log[axis=y]
fill 154 65 -160 161 65 -160 minecraft:air
setblock 162 65 -160 minecraft:birch_log[axis=y]
fill 163 65 -160 191 65 -160 minecraft:air
setblock 192 65 -160 minecraft:birch_log[axis=y]
fill 193 65 -160 199 65 -160 minecraft:air
fill 136 65 -161 149 65 -161 minecraft:air
setblock 150 65 -161 minecraft:birch_log[axis=y]
fill 151 65 -161 179 65 -161 minecraft:air
setblock 180 65 -161 minecraft:birch_log[axis=y]
fill 181 65 -161 185 65 -161 minecraft:air
setblock 186 65 -161 minecraft:birch_log[axis=y]
fill 187 65 -161 199 65 -161 minecraft:air
fill 136 65 -162 159 65 -162 minecraft:air
setblock 160 65 -162 minecraft:birch_log[axis=y]
fill 161 65 -162 198 65 -162 minecraft:air
setblock 199 65 -162 regions_unexplored:grass_sprouts
fill 136 65 -163 156 65 -163 minecraft:air
setblock 157 65 -163 minecraft:birch_log[axis=y]
fill 158 65 -163 170 65 -163 minecraft:air
setblock 171 65 -163 minecraft:birch_log[axis=y]
fill 172 65 -163 195 65 -163 minecraft:air
setblock 196 65 -163 minecraft:birch_log[axis=y]
fill 197 65 -163 199 65 -163 minecraft:air
fill 136 65 -164 163 65 -164 minecraft:air
setblock 164 65 -164 minecraft:birch_log[axis=y]
fill 165 65 -164 184 65 -164 minecraft:air
fill 186 65 -164 199 65 -164 minecraft:air
fill 136 65 -165 183 65 -165 minecraft:air
setblock 186 65 -165 minecraft:birch_log[axis=y]
fill 187 65 -165 199 65 -165 minecraft:air
fill 136 65 -166 176 65 -166 minecraft:air
setblock 177 65 -166 minecraft:birch_log[axis=y]
fill 178 65 -166 184 65 -166 minecraft:air
fill 186 65 -166 199 65 -166 minecraft:air
fill 136 65 -167 160 65 -167 minecraft:air
setblock 161 65 -167 minecraft:birch_log[axis=y]
fill 162 65 -167 183 65 -167 minecraft:air
fill 186 65 -167 187 65 -167 minecraft:air
setblock 188 65 -167 minecraft:birch_log[axis=y]
fill 189 65 -167 198 65 -167 minecraft:air
fill 136 65 -168 150 65 -168 minecraft:air
setblock 151 65 -168 minecraft:birch_log[axis=y]
fill 152 65 -168 182 65 -168 minecraft:air
fill 186 65 -168 197 65 -168 minecraft:air
fill 136 65 -169 183 65 -169 minecraft:air
fill 186 65 -169 197 65 -169 minecraft:air
fill 136 65 -170 184 65 -170 minecraft:air
fill 186 65 -170 196 65 -170 minecraft:air
fill 136 65 -171 167 65 -171 minecraft:air
setblock 168 65 -171 minecraft:birch_log[axis=y]
fill 169 65 -171 171 65 -171 minecraft:air
setblock 172 65 -171 minecraft:birch_log[axis=y]
fill 173 65 -171 181 65 -171 minecraft:air
fill 183 65 -171 195 65 -171 minecraft:air
fill 136 65 -172 160 65 -172 minecraft:air
setblock 161 65 -172 herbsandharvest:pear_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
setblock 162 65 -172 minecraft:air
setblock 163 65 -172 minecraft:birch_log[axis=y]
fill 164 65 -172 180 65 -172 minecraft:air
fill 184 65 -172 191 65 -172 minecraft:air
setblock 192 65 -172 minecraft:birch_log[axis=y]
fill 193 65 -172 194 65 -172 minecraft:air
fill 136 65 -173 159 65 -173 minecraft:air
setblock 160 65 -173 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 161 65 -173 minecraft:oak_log[axis=y]
setblock 162 65 -173 herbsandharvest:pear_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
fill 163 65 -173 179 65 -173 minecraft:air
fill 185 65 -173 194 65 -173 minecraft:air
fill 136 65 -174 160 65 -174 minecraft:air
setblock 161 65 -174 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
fill 162 65 -174 180 65 -174 minecraft:air
fill 184 65 -174 188 65 -174 minecraft:air
setblock 189 65 -174 minecraft:birch_log[axis=y]
fill 190 65 -174 193 65 -174 minecraft:air
fill 136 65 -175 181 65 -175 minecraft:air
fill 183 65 -175 192 65 -175 minecraft:air
fill 136 65 -176 155 65 -176 minecraft:air
setblock 156 65 -176 minecraft:birch_log[axis=y]
fill 157 65 -176 170 65 -176 minecraft:air
setblock 171 65 -176 minecraft:birch_log[axis=y]
fill 172 65 -176 185 65 -176 minecraft:air
setblock 186 65 -176 minecraft:birch_log[axis=y]
fill 187 65 -176 192 65 -176 minecraft:air
fill 136 65 -177 158 65 -177 minecraft:air
setblock 159 65 -177 minecraft:birch_log[axis=y]
fill 160 65 -177 191 65 -177 minecraft:air
fill 136 65 -178 190 65 -178 minecraft:air
fill 136 65 -179 190 65 -179 minecraft:air
fill 136 65 -180 174 65 -180 minecraft:air
setblock 175 65 -180 minecraft:birch_log[axis=y]
fill 176 65 -180 189 65 -180 minecraft:air
fill 136 65 -181 160 65 -181 minecraft:air
setblock 161 65 -181 minecraft:birch_log[axis=y]
fill 162 65 -181 189 65 -181 minecraft:air
fill 136 65 -182 154 65 -182 minecraft:air
setblock 155 65 -182 minecraft:birch_log[axis=y]
fill 156 65 -182 169 65 -182 minecraft:air
setblock 170 65 -182 minecraft:birch_log[axis=y]
fill 171 65 -182 188 65 -182 minecraft:air
fill 137 65 -183 180 65 -183 minecraft:air
setblock 181 65 -183 minecraft:birch_log[axis=y]
fill 182 65 -183 188 65 -183 minecraft:air
fill 138 65 -184 187 65 -184 minecraft:air
fill 138 65 -185 160 65 -185 minecraft:air
setblock 161 65 -185 minecraft:birch_log[axis=y]
fill 162 65 -185 181 65 -185 minecraft:air
setblock 182 65 -185 minecraft:birch_log[axis=y]
fill 183 65 -185 187 65 -185 minecraft:air
fill 139 65 -186 163 65 -186 minecraft:air
setblock 164 65 -186 minecraft:birch_log[axis=y]
fill 165 65 -186 186 65 -186 minecraft:air
fill 140 65 -187 153 65 -187 minecraft:air
setblock 154 65 -187 minecraft:birch_log[axis=y]
fill 155 65 -187 186 65 -187 minecraft:air
fill 140 65 -188 150 65 -188 minecraft:air
setblock 151 65 -188 minecraft:birch_log[axis=y]
fill 152 65 -188 166 65 -188 minecraft:air
setblock 167 65 -188 minecraft:birch_log[axis=y]
fill 168 65 -188 185 65 -188 minecraft:air
fill 141 65 -189 174 65 -189 minecraft:air
setblock 175 65 -189 minecraft:birch_log[axis=y]
fill 176 65 -189 181 65 -189 minecraft:air
setblock 184 65 -189 minecraft:birch_log[axis=y]
setblock 185 65 -189 minecraft:air
fill 142 65 -190 180 65 -190 minecraft:air
fill 155 64 -127 158 64 -127 minecraft:air
setblock 159 64 -127 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 160 64 -127 minecraft:air
setblock 161 64 -127 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
setblock 162 64 -127 regions_unexplored:grass_sprouts
setblock 163 64 -127 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
fill 164 64 -127 168 64 -127 minecraft:air
fill 155 64 -128 159 64 -128 minecraft:air
fill 161 64 -128 168 64 -128 minecraft:air
fill 154 64 -129 159 64 -129 minecraft:air
setblock 160 64 -129 regions_unexplored:grass_sprouts
fill 161 64 -129 168 64 -129 minecraft:air
setblock 153 64 -130 regions_unexplored:grass_sprouts
fill 154 64 -130 169 64 -130 minecraft:air
setblock 136 64 -131 minecraft:air
fill 152 64 -131 153 64 -131 minecraft:air
setblock 154 64 -131 minecraft:short_grass
fill 155 64 -131 169 64 -131 minecraft:air
setblock 136 64 -132 minecraft:short_grass
setblock 137 64 -132 minecraft:air
setblock 151 64 -132 regions_unexplored:grass_sprouts
fill 152 64 -132 155 64 -132 minecraft:air
fill 156 64 -132 157 64 -132 minecraft:short_grass
fill 158 64 -132 170 64 -132 minecraft:air
setblock 136 64 -133 minecraft:air
setblock 137 64 -133 minecraft:short_grass
fill 151 64 -133 154 64 -133 minecraft:air
setblock 155 64 -133 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
fill 156 64 -133 157 64 -133 minecraft:air
setblock 158 64 -133 regions_unexplored:grass_sprouts
fill 159 64 -133 161 64 -133 minecraft:air
fill 162 64 -133 163 64 -133 regions_unexplored:grass_sprouts
fill 164 64 -133 170 64 -133 minecraft:air
fill 136 64 -134 138 64 -134 minecraft:air
fill 150 64 -134 156 64 -134 minecraft:air
setblock 157 64 -134 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
fill 158 64 -134 159 64 -134 minecraft:air
setblock 160 64 -134 regions_unexplored:grass_sprouts
fill 161 64 -134 169 64 -134 minecraft:air
setblock 170 64 -134 regions_unexplored:grass_sprouts
fill 136 64 -135 139 64 -135 minecraft:air
fill 144 64 -135 153 64 -135 minecraft:air
setblock 154 64 -135 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
setblock 155 64 -135 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
fill 156 64 -135 159 64 -135 minecraft:air
setblock 160 64 -135 regions_unexplored:grass_sprouts
fill 161 64 -135 171 64 -135 minecraft:air
fill 136 64 -136 153 64 -136 minecraft:air
setblock 154 64 -136 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=1]
setblock 155 64 -136 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 156 64 -136 minecraft:air
fill 158 64 -136 168 64 -136 minecraft:air
fill 169 64 -136 170 64 -136 regions_unexplored:grass_sprouts
fill 171 64 -136 172 64 -136 minecraft:air
fill 136 64 -137 141 64 -137 minecraft:air
setblock 142 64 -137 regions_unexplored:grass_sprouts
fill 143 64 -137 146 64 -137 minecraft:air
fill 148 64 -137 174 64 -137 minecraft:air
fill 136 64 -138 138 64 -138 minecraft:air
fill 140 64 -138 141 64 -138 minecraft:air
fill 143 64 -138 180 64 -138 minecraft:air
setblock 181 64 -138 regions_unexplored:grass_sprouts
setblock 182 64 -138 minecraft:air
setblock 183 64 -138 regions_unexplored:grass_sprouts
setblock 184 64 -138 minecraft:air
setblock 193 64 -138 minecraft:air
fill 136 64 -139 142 64 -139 minecraft:air
setblock 143 64 -139 minecraft:short_grass
fill 144 64 -139 166 64 -139 minecraft:air
fill 167 64 -139 168 64 -139 regions_unexplored:grass_sprouts
fill 169 64 -139 178 64 -139 minecraft:air
setblock 179 64 -139 regions_unexplored:grass_sprouts
fill 180 64 -139 185 64 -139 minecraft:air
fill 193 64 -139 194 64 -139 minecraft:air
fill 136 64 -140 149 64 -140 minecraft:air
fill 151 64 -140 152 64 -140 minecraft:air
setblock 153 64 -140 regions_unexplored:grass_sprouts
fill 154 64 -140 167 64 -140 minecraft:air
setblock 168 64 -140 regions_unexplored:grass_sprouts
fill 169 64 -140 183 64 -140 minecraft:air
setblock 184 64 -140 regions_unexplored:grass_sprouts
fill 185 64 -140 186 64 -140 minecraft:air
fill 193 64 -140 195 64 -140 minecraft:air
fill 136 64 -141 171 64 -141 minecraft:air
setblock 172 64 -141 regions_unexplored:grass_sprouts
fill 173 64 -141 185 64 -141 minecraft:air
setblock 186 64 -141 minecraft:short_grass
setblock 187 64 -141 minecraft:air
fill 193 64 -141 196 64 -141 minecraft:air
fill 136 64 -142 183 64 -142 minecraft:air
fill 184 64 -142 185 64 -142 regions_unexplored:grass_sprouts
setblock 186 64 -142 minecraft:air
setblock 187 64 -142 minecraft:short_grass
fill 194 64 -142 197 64 -142 minecraft:air
fill 136 64 -143 137 64 -143 minecraft:air
fill 139 64 -143 149 64 -143 minecraft:air
fill 151 64 -143 153 64 -143 minecraft:air
fill 155 64 -143 183 64 -143 minecraft:air
setblock 184 64 -143 minecraft:short_grass
fill 185 64 -143 188 64 -143 minecraft:air
fill 194 64 -143 199 64 -143 minecraft:air
fill 136 64 -144 179 64 -144 minecraft:air
setblock 180 64 -144 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=3]
setblock 181 64 -144 minecraft:short_grass
fill 182 64 -144 183 64 -144 minecraft:air
setblock 184 64 -144 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 185 64 -144 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=2]
setblock 186 64 -144 minecraft:air
setblock 187 64 -144 minecraft:short_grass
setblock 188 64 -144 minecraft:air
fill 195 64 -144 199 64 -144 minecraft:air
fill 136 64 -145 179 64 -145 minecraft:air
setblock 180 64 -145 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
setblock 181 64 -145 minecraft:short_grass
fill 182 64 -145 183 64 -145 minecraft:air
fill 184 64 -145 185 64 -145 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 186 64 -145 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
setblock 187 64 -145 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
setblock 188 64 -145 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=4]
fill 196 64 -145 199 64 -145 minecraft:air
fill 136 64 -146 150 64 -146 minecraft:air
fill 151 64 -146 154 64 -146 minecraft:cave_air
fill 155 64 -146 177 64 -146 minecraft:air
fill 179 64 -146 183 64 -146 minecraft:air
setblock 184 64 -146 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
setblock 185 64 -146 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
setblock 186 64 -146 minecraft:short_grass
fill 187 64 -146 188 64 -146 minecraft:air
fill 136 64 -147 149 64 -147 minecraft:air
fill 150 64 -147 155 64 -147 minecraft:cave_air
fill 156 64 -147 182 64 -147 minecraft:air
setblock 184 64 -147 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
setblock 185 64 -147 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
fill 187 64 -147 188 64 -147 minecraft:air
fill 136 64 -148 147 64 -148 minecraft:air
fill 149 64 -148 155 64 -148 minecraft:cave_air
fill 156 64 -148 165 64 -148 minecraft:air
setblock 166 64 -148 regions_unexplored:day_lily[half=upper]
fill 167 64 -148 184 64 -148 minecraft:air
setblock 185 64 -148 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
setblock 186 64 -148 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=2]
setblock 187 64 -148 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 188 64 -148 minecraft:air
fill 136 64 -149 147 64 -149 minecraft:air
fill 148 64 -149 155 64 -149 minecraft:cave_air
fill 156 64 -149 188 64 -149 minecraft:air
fill 136 64 -150 147 64 -150 minecraft:air
fill 148 64 -150 156 64 -150 minecraft:cave_air
fill 157 64 -150 184 64 -150 minecraft:air
setblock 185 64 -150 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 186 64 -150 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 187 64 -150 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 188 64 -150 minecraft:air
setblock 189 64 -150 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
fill 136 64 -151 147 64 -151 minecraft:air
fill 148 64 -151 155 64 -151 minecraft:cave_air
fill 156 64 -151 163 64 -151 minecraft:air
setblock 164 64 -151 regions_unexplored:day_lily[half=upper]
setblock 165 64 -151 minecraft:air
setblock 166 64 -151 regions_unexplored:day_lily[half=upper]
fill 167 64 -151 186 64 -151 minecraft:air
setblock 187 64 -151 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
setblock 188 64 -151 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=2]
fill 136 64 -152 146 64 -152 minecraft:air
fill 147 64 -152 156 64 -152 minecraft:cave_air
fill 157 64 -152 178 64 -152 minecraft:air
fill 180 64 -152 189 64 -152 minecraft:air
fill 136 64 -153 145 64 -153 minecraft:air
fill 147 64 -153 156 64 -153 minecraft:cave_air
fill 157 64 -153 162 64 -153 minecraft:air
setblock 163 64 -153 regions_unexplored:day_lily[half=upper]
fill 164 64 -153 185 64 -153 minecraft:air
setblock 186 64 -153 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=4]
setblock 187 64 -153 minecraft:air
setblock 188 64 -153 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
setblock 189 64 -153 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
setblock 190 64 -153 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
fill 136 64 -154 148 64 -154 minecraft:air
fill 149 64 -154 152 64 -154 minecraft:cave_air
setblock 153 64 -154 minecraft:air
fill 154 64 -154 156 64 -154 minecraft:cave_air
fill 157 64 -154 159 64 -154 minecraft:air
setblock 160 64 -154 regions_unexplored:day_lily[half=upper]
fill 161 64 -154 190 64 -154 minecraft:air
setblock 191 64 -154 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=1]
fill 136 64 -155 141 64 -155 minecraft:air
fill 143 64 -155 153 64 -155 minecraft:air
fill 154 64 -155 155 64 -155 minecraft:cave_air
fill 156 64 -155 160 64 -155 minecraft:air
setblock 161 64 -155 regions_unexplored:day_lily[half=upper]
fill 162 64 -155 164 64 -155 minecraft:air
setblock 165 64 -155 regions_unexplored:day_lily[half=upper]
fill 166 64 -155 171 64 -155 minecraft:air
fill 173 64 -155 179 64 -155 minecraft:air
fill 181 64 -155 188 64 -155 minecraft:air
setblock 189 64 -155 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=2]
setblock 190 64 -155 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=3]
fill 191 64 -155 192 64 -155 minecraft:air
fill 136 64 -156 161 64 -156 minecraft:air
setblock 162 64 -156 regions_unexplored:day_lily[half=upper]
setblock 163 64 -156 minecraft:air
setblock 164 64 -156 regions_unexplored:day_lily[half=upper]
fill 165 64 -156 188 64 -156 minecraft:air
setblock 190 64 -156 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=1]
setblock 191 64 -156 minecraft:air
setblock 192 64 -156 regions_unexplored:grass_sprouts
setblock 193 64 -156 minecraft:air
fill 136 64 -157 172 64 -157 minecraft:air
fill 174 64 -157 182 64 -157 minecraft:air
fill 184 64 -157 190 64 -157 minecraft:air
setblock 191 64 -157 regions_unexplored:maple_leaf_litter[facing=east,flower_amount=3]
fill 192 64 -157 193 64 -157 minecraft:air
fill 136 64 -158 138 64 -158 minecraft:air
fill 140 64 -158 147 64 -158 minecraft:air
fill 149 64 -158 175 64 -158 minecraft:air
fill 177 64 -158 189 64 -158 minecraft:air
setblock 190 64 -158 regions_unexplored:grass_sprouts
setblock 191 64 -158 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 192 64 -158 regions_unexplored:maple_leaf_litter[facing=north,flower_amount=4]
fill 193 64 -158 194 64 -158 minecraft:air
fill 136 64 -159 158 64 -159 minecraft:air
fill 160 64 -159 171 64 -159 minecraft:air
fill 173 64 -159 177 64 -159 minecraft:air
fill 179 64 -159 193 64 -159 minecraft:air
setblock 194 64 -159 minecraft:short_grass
fill 136 64 -160 152 64 -160 minecraft:air
fill 154 64 -160 161 64 -160 minecraft:air
fill 163 64 -160 190 64 -160 minecraft:air
setblock 191 64 -160 regions_unexplored:grass_sprouts
fill 193 64 -160 195 64 -160 minecraft:air
fill 136 64 -161 149 64 -161 minecraft:air
fill 151 64 -161 179 64 -161 minecraft:air
fill 181 64 -161 185 64 -161 minecraft:air
fill 187 64 -161 192 64 -161 minecraft:air
setblock 193 64 -161 minecraft:short_grass
fill 194 64 -161 196 64 -161 minecraft:air
fill 136 64 -162 159 64 -162 minecraft:air
fill 161 64 -162 191 64 -162 minecraft:air
setblock 192 64 -162 minecraft:short_grass
setblock 193 64 -162 minecraft:air
setblock 194 64 -162 regions_unexplored:grass_sprouts
fill 195 64 -162 196 64 -162 minecraft:air
setblock 197 64 -162 regions_unexplored:grass_sprouts
setblock 198 64 -162 minecraft:air
fill 136 64 -163 156 64 -163 minecraft:air
fill 158 64 -163 170 64 -163 minecraft:air
fill 172 64 -163 191 64 -163 minecraft:air
setblock 192 64 -163 regions_unexplored:grass_sprouts
fill 193 64 -163 195 64 -163 minecraft:air
fill 197 64 -163 199 64 -163 minecraft:air
fill 136 64 -164 163 64 -164 minecraft:air
fill 165 64 -164 194 64 -164 minecraft:air
setblock 195 64 -164 regions_unexplored:grass_sprouts
fill 196 64 -164 199 64 -164 minecraft:air
fill 136 64 -165 185 64 -165 minecraft:air
fill 187 64 -165 192 64 -165 minecraft:air
setblock 193 64 -165 regions_unexplored:grass_sprouts
fill 194 64 -165 195 64 -165 minecraft:air
setblock 196 64 -165 minecraft:short_grass
fill 197 64 -165 198 64 -165 minecraft:air
setblock 199 64 -165 minecraft:short_grass
fill 136 64 -166 176 64 -166 minecraft:air
fill 178 64 -166 199 64 -166 minecraft:air
fill 136 64 -167 160 64 -167 minecraft:air
fill 162 64 -167 187 64 -167 minecraft:air
fill 189 64 -167 199 64 -167 minecraft:air
fill 136 64 -168 150 64 -168 minecraft:air
fill 152 64 -168 184 64 -168 minecraft:air
fill 186 64 -168 198 64 -168 minecraft:air
setblock 199 64 -168 minecraft:short_grass
fill 136 64 -169 199 64 -169 minecraft:air
fill 136 64 -170 199 64 -170 minecraft:air
fill 136 64 -171 167 64 -171 minecraft:air
fill 169 64 -171 171 64 -171 minecraft:air
fill 173 64 -171 199 64 -171 minecraft:air
fill 136 64 -172 162 64 -172 minecraft:air
fill 164 64 -172 191 64 -172 minecraft:air
fill 193 64 -172 199 64 -172 minecraft:air
fill 136 64 -173 160 64 -173 minecraft:air
fill 162 64 -173 181 64 -173 minecraft:air
fill 183 64 -173 199 64 -173 minecraft:air
fill 136 64 -174 188 64 -174 minecraft:air
fill 190 64 -174 199 64 -174 minecraft:air
fill 136 64 -175 199 64 -175 minecraft:air
fill 136 64 -176 155 64 -176 minecraft:air
fill 157 64 -176 170 64 -176 minecraft:air
fill 172 64 -176 185 64 -176 minecraft:air
fill 187 64 -176 195 64 -176 minecraft:air
fill 197 64 -176 199 64 -176 minecraft:air
fill 136 64 -177 158 64 -177 minecraft:air
fill 160 64 -177 199 64 -177 minecraft:air
fill 136 64 -178 195 64 -178 minecraft:air
fill 197 64 -178 199 64 -178 minecraft:air
fill 136 64 -179 199 64 -179 minecraft:air
fill 136 64 -180 174 64 -180 minecraft:air
fill 176 64 -180 199 64 -180 minecraft:air
fill 136 64 -181 160 64 -181 minecraft:air
fill 162 64 -181 190 64 -181 minecraft:air
fill 192 64 -181 199 64 -181 minecraft:air
fill 136 64 -182 154 64 -182 minecraft:air
fill 156 64 -182 169 64 -182 minecraft:air
fill 171 64 -182 185 64 -182 minecraft:air
fill 187 64 -182 199 64 -182 minecraft:air
fill 136 64 -183 180 64 -183 minecraft:air
fill 182 64 -183 195 64 -183 minecraft:air
fill 197 64 -183 199 64 -183 minecraft:air
fill 136 64 -184 198 64 -184 minecraft:air
fill 136 64 -185 160 64 -185 minecraft:air
fill 162 64 -185 181 64 -185 minecraft:air
fill 183 64 -185 190 64 -185 minecraft:air
fill 192 64 -185 196 64 -185 minecraft:air
setblock 198 64 -185 minecraft:air
fill 136 64 -186 163 64 -186 minecraft:air
fill 165 64 -186 197 64 -186 minecraft:air
fill 136 64 -187 153 64 -187 minecraft:air
fill 155 64 -187 195 64 -187 minecraft:air
setblock 196 64 -187 minecraft:short_grass
setblock 197 64 -187 minecraft:air
fill 136 64 -188 150 64 -188 minecraft:air
fill 152 64 -188 166 64 -188 minecraft:air
fill 168 64 -188 193 64 -188 minecraft:air
fill 194 64 -188 195 64 -188 minecraft:short_grass
setblock 196 64 -188 regions_unexplored:grass_sprouts
fill 136 64 -189 174 64 -189 minecraft:air
fill 176 64 -189 181 64 -189 minecraft:air
setblock 182 64 -189 herbsandharvest:plum_fruit_leaves[age=2,distance=2,persistent=false,waterlogged=false]
setblock 183 64 -189 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
fill 185 64 -189 196 64 -189 minecraft:air
fill 136 64 -190 180 64 -190 minecraft:air
setblock 181 64 -190 herbsandharvest:fruit_leaves[distance=3,persistent=false,waterlogged=false]
setblock 182 64 -190 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
fill 183 64 -190 184 64 -190 herbsandharvest:fruit_leaves[distance=1,persistent=false,waterlogged=false]
setblock 185 64 -190 herbsandharvest:fruit_leaves[distance=2,persistent=false,waterlogged=false]
fill 186 64 -190 190 64 -190 minecraft:air
fill 192 64 -190 195 64 -190 minecraft:air
setblock 156 63 -127 regions_unexplored:grass_sprouts
setblock 156 63 -128 minecraft:air
setblock 156 63 -129 minecraft:air
setblock 156 63 -130 minecraft:air
setblock 191 63 -130 minecraft:air
fill 152 63 -132 155 63 -132 minecraft:air
setblock 164 63 -132 minecraft:air
fill 191 63 -132 193 63 -132 minecraft:air
fill 152 63 -133 154 63 -133 minecraft:air
setblock 164 63 -133 minecraft:air
fill 191 63 -133 193 63 -133 minecraft:air
setblock 136 63 -134 minecraft:air
fill 152 63 -134 154 63 -134 minecraft:air
fill 163 63 -134 164 63 -134 minecraft:air
fill 192 63 -134 194 63 -134 minecraft:air
fill 136 63 -135 139 63 -135 minecraft:air
fill 152 63 -135 153 63 -135 minecraft:air
fill 163 63 -135 164 63 -135 minecraft:air
fill 192 63 -135 194 63 -135 minecraft:air
fill 136 63 -136 140 63 -136 minecraft:air
fill 147 63 -136 153 63 -136 minecraft:air
fill 163 63 -136 164 63 -136 minecraft:air
fill 192 63 -136 194 63 -136 minecraft:air
fill 136 63 -137 141 63 -137 minecraft:air
fill 148 63 -137 152 63 -137 minecraft:air
fill 163 63 -137 164 63 -137 minecraft:air
fill 192 63 -137 194 63 -137 minecraft:air
fill 136 63 -138 141 63 -138 minecraft:air
fill 147 63 -138 152 63 -138 minecraft:air
fill 163 63 -138 165 63 -138 minecraft:air
fill 192 63 -138 194 63 -138 minecraft:air
fill 136 63 -139 141 63 -139 minecraft:air
fill 144 63 -139 152 63 -139 minecraft:air
setblock 163 63 -139 regions_unexplored:grass_sprouts
fill 164 63 -139 165 63 -139 minecraft:air
fill 192 63 -139 195 63 -139 minecraft:air
fill 136 63 -140 148 63 -140 minecraft:air
setblock 149 63 -140 minecraft:short_grass
fill 151 63 -140 152 63 -140 minecraft:air
fill 163 63 -140 166 63 -140 minecraft:air
fill 192 63 -140 196 63 -140 minecraft:air
fill 136 63 -141 153 63 -141 minecraft:air
fill 163 63 -141 168 63 -141 minecraft:air
fill 192 63 -141 196 63 -141 minecraft:air
fill 136 63 -142 156 63 -142 minecraft:air
fill 162 63 -142 169 63 -142 minecraft:air
fill 193 63 -142 197 63 -142 minecraft:air
fill 136 63 -143 137 63 -143 minecraft:air
fill 139 63 -143 149 63 -143 minecraft:air
fill 151 63 -143 153 63 -143 minecraft:air
fill 155 63 -143 157 63 -143 minecraft:air
fill 162 63 -143 171 63 -143 minecraft:air
fill 194 63 -143 196 63 -143 minecraft:air
setblock 198 63 -143 minecraft:air
fill 136 63 -144 158 63 -144 minecraft:air
fill 161 63 -144 176 63 -144 minecraft:air
fill 195 63 -144 198 63 -144 minecraft:air
setblock 136 63 -145 minecraft:short_grass
fill 137 63 -145 178 63 -145 minecraft:air
setblock 197 63 -145 minecraft:air
fill 136 63 -146 137 63 -146 minecraft:air
setblock 138 63 -146 regions_unexplored:grass_sprouts
fill 139 63 -146 150 63 -146 minecraft:air
fill 151 63 -146 155 63 -146 minecraft:cave_air
fill 156 63 -146 177 63 -146 minecraft:air
setblock 179 63 -146 minecraft:air
setblock 180 63 -146 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=1]
fill 136 63 -147 148 63 -147 minecraft:air
fill 149 63 -147 155 63 -147 minecraft:cave_air
fill 156 63 -147 160 63 -147 minecraft:air
setblock 161 63 -147 regions_unexplored:grass_sprouts
fill 162 63 -147 163 63 -147 minecraft:air
setblock 164 63 -147 regions_unexplored:grass_sprouts
fill 165 63 -147 181 63 -147 minecraft:air
setblock 136 63 -148 minecraft:air
setblock 137 63 -148 regions_unexplored:grass_sprouts
fill 138 63 -148 139 63 -148 minecraft:air
setblock 140 63 -148 minecraft:short_grass
fill 141 63 -148 147 63 -148 minecraft:air
fill 149 63 -148 156 63 -148 minecraft:cave_air
setblock 157 63 -148 minecraft:short_grass
fill 158 63 -148 165 63 -148 minecraft:air
setblock 166 63 -148 regions_unexplored:day_lily[half=lower]
fill 167 63 -148 168 63 -148 minecraft:air
setblock 169 63 -148 regions_unexplored:grass_sprouts
fill 170 63 -148 182 63 -148 minecraft:air
setblock 136 63 -149 minecraft:air
setblock 137 63 -149 regions_unexplored:grass_sprouts
fill 138 63 -149 144 63 -149 minecraft:air
setblock 145 63 -149 regions_unexplored:grass_sprouts
fill 146 63 -149 147 63 -149 minecraft:air
fill 148 63 -149 156 63 -149 minecraft:cave_air
fill 157 63 -149 167 63 -149 minecraft:air
setblock 168 63 -149 minecraft:short_grass
fill 169 63 -149 181 63 -149 minecraft:air
setblock 182 63 -149 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=3]
fill 136 63 -150 141 63 -150 minecraft:air
setblock 142 63 -150 regions_unexplored:grass_sprouts
fill 143 63 -150 147 63 -150 minecraft:air
fill 148 63 -150 156 63 -150 minecraft:cave_air
setblock 157 63 -150 minecraft:short_grass
fill 158 63 -150 161 63 -150 minecraft:air
setblock 162 63 -150 regions_unexplored:grass_sprouts
fill 163 63 -150 165 63 -150 minecraft:air
setblock 166 63 -150 minecraft:short_grass
fill 167 63 -150 180 63 -150 minecraft:air
setblock 181 63 -150 regions_unexplored:maple_leaf_litter[facing=west,flower_amount=4]
setblock 182 63 -150 minecraft:air
setblock 183 63 -150 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=4]
setblock 136 63 -151 minecraft:air
setblock 137 63 -151 minecraft:short_grass
fill 138 63 -151 142 63 -151 minecraft:air
setblock 143 63 -151 regions_unexplored:grass_sprouts
setblock 144 63 -151 minecraft:short_grass
fill 145 63 -151 146 63 -151 minecraft:air
fill 147 63 -151 156 63 -151 minecraft:cave_air
fill 157 63 -151 158 63 -151 minecraft:air
setblock 159 63 -151 regions_unexplored:grass_sprouts
fill 160 63 -151 163 63 -151 minecraft:air
setblock 164 63 -151 regions_unexplored:day_lily[half=lower]
setblock 165 63 -151 minecraft:air
setblock 166 63 -151 regions_unexplored:day_lily[half=lower]
setblock 167 63 -151 minecraft:short_grass
setblock 168 63 -151 regions_unexplored:grass_sprouts
setblock 169 63 -151 minecraft:short_grass
fill 170 63 -151 184 63 -151 minecraft:air
fill 136 63 -152 137 63 -152 minecraft:air
setblock 138 63 -152 regions_unexplored:grass_sprouts
fill 139 63 -152 146 63 -152 minecraft:air
fill 147 63 -152 156 63 -152 minecraft:cave_air
setblock 157 63 -152 minecraft:air
setblock 158 63 -152 minecraft:short_grass
fill 159 63 -152 161 63 -152 minecraft:air
fill 162 63 -152 163 63 -152 minecraft:short_grass
fill 164 63 -152 167 63 -152 minecraft:air
fill 168 63 -152 169 63 -152 regions_unexplored:day_lily[half=upper]
fill 170 63 -152 178 63 -152 minecraft:air
fill 180 63 -152 184 63 -152 minecraft:air
setblock 136 63 -153 regions_unexplored:grass_sprouts
fill 137 63 -153 138 63 -153 minecraft:air
fill 139 63 -153 141 63 -153 minecraft:short_grass
fill 142 63 -153 144 63 -153 minecraft:air
setblock 145 63 -153 regions_unexplored:grass_sprouts
fill 147 63 -153 156 63 -153 minecraft:cave_air
fill 157 63 -153 158 63 -153 minecraft:air
fill 159 63 -153 160 63 -153 regions_unexplored:grass_sprouts
fill 161 63 -153 162 63 -153 minecraft:air
setblock 163 63 -153 regions_unexplored:day_lily[half=lower]
fill 164 63 -153 185 63 -153 minecraft:air
fill 136 63 -154 137 63 -154 minecraft:air
setblock 138 63 -154 regions_unexplored:grass_sprouts
fill 139 63 -154 147 63 -154 minecraft:air
fill 148 63 -154 156 63 -154 minecraft:cave_air
fill 157 63 -154 159 63 -154 minecraft:air
setblock 160 63 -154 regions_unexplored:day_lily[half=lower]
setblock 161 63 -154 minecraft:short_grass
fill 162 63 -154 165 63 -154 minecraft:air
setblock 166 63 -154 minecraft:short_grass
fill 167 63 -154 169 63 -154 minecraft:air
setblock 170 63 -154 regions_unexplored:day_lily[half=upper]
fill 171 63 -154 185 63 -154 minecraft:air
setblock 186 63 -154 regions_unexplored:red_maple_leaf_litter[facing=north,flower_amount=2]
fill 136 63 -155 141 63 -155 minecraft:air
setblock 143 63 -155 minecraft:short_grass
setblock 144 63 -155 minecraft:air
setblock 145 63 -155 minecraft:short_grass
fill 146 63 -155 149 63 -155 minecraft:air
fill 150 63 -155 151 63 -155 minecraft:cave_air
fill 152 63 -155 153 63 -155 minecraft:air
fill 154 63 -155 156 63 -155 minecraft:cave_air
fill 157 63 -155 160 63 -155 minecraft:air
setblock 161 63 -155 regions_unexplored:day_lily[half=lower]
setblock 162 63 -155 minecraft:short_grass
fill 163 63 -155 164 63 -155 minecraft:air
setblock 165 63 -155 regions_unexplored:day_lily[half=lower]
setblock 166 63 -155 regions_unexplored:day_lily[half=upper]
fill 167 63 -155 168 63 -155 minecraft:air
setblock 169 63 -155 regions_unexplored:day_lily[half=upper]
fill 170 63 -155 171 63 -155 minecraft:air
fill 173 63 -155 179 63 -155 minecraft:air
fill 181 63 -155 184 63 -155 minecraft:air
setblock 185 63 -155 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=4]
setblock 186 63 -155 minecraft:air
fill 136 63 -156 153 63 -156 minecraft:air
fill 154 63 -156 155 63 -156 minecraft:cave_air
fill 156 63 -156 161 63 -156 minecraft:air
setblock 162 63 -156 regions_unexplored:day_lily[half=lower]
setblock 163 63 -156 regions_unexplored:grass_sprouts
setblock 164 63 -156 regions_unexplored:day_lily[half=lower]
fill 165 63 -156 184 63 -156 minecraft:air
setblock 185 63 -156 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=2]
setblock 186 63 -156 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=3]
setblock 187 63 -156 minecraft:air
fill 136 63 -157 172 63 -157 minecraft:air
fill 174 63 -157 182 63 -157 minecraft:air
setblock 184 63 -157 minecraft:air
setblock 185 63 -157 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=2]
setblock 186 63 -157 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=3]
setblock 187 63 -157 minecraft:air
setblock 188 63 -157 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=2]
setblock 136 63 -158 minecraft:short_grass
fill 137 63 -158 138 63 -158 minecraft:air
fill 140 63 -158 147 63 -158 minecraft:air
fill 149 63 -158 175 63 -158 minecraft:air
fill 177 63 -158 187 63 -158 minecraft:air
setblock 188 63 -158 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=3]
fill 136 63 -159 142 63 -159 minecraft:air
setblock 143 63 -159 minecraft:short_grass
fill 144 63 -159 151 63 -159 minecraft:air
setblock 152 63 -159 regions_unexplored:grass_sprouts
fill 153 63 -159 158 63 -159 minecraft:air
fill 160 63 -159 171 63 -159 minecraft:air
fill 173 63 -159 177 63 -159 minecraft:air
fill 179 63 -159 184 63 -159 minecraft:air
setblock 185 63 -159 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=2]
setblock 186 63 -159 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=2]
setblock 187 63 -159 regions_unexplored:grass_sprouts
setblock 188 63 -159 minecraft:air
setblock 189 63 -159 regions_unexplored:maple_leaf_litter[facing=south,flower_amount=2]
fill 136 63 -160 152 63 -160 minecraft:air
fill 154 63 -160 161 63 -160 minecraft:air
fill 163 63 -160 184 63 -160 minecraft:air
setblock 185 63 -160 regions_unexplored:red_maple_leaf_litter[facing=east,flower_amount=1]
setblock 186 63 -160 regions_unexplored:grass_sprouts
setblock 187 63 -160 minecraft:air
setblock 188 63 -160 minecraft:short_grass
setblock 189 63 -160 minecraft:air
fill 136 63 -161 149 63 -161 minecraft:air
fill 151 63 -161 179 63 -161 minecraft:air
fill 181 63 -161 185 63 -161 minecraft:air
fill 187 63 -161 190 63 -161 minecraft:air
fill 136 63 -162 159 63 -162 minecraft:air
fill 161 63 -162 190 63 -162 minecraft:air
fill 136 63 -163 156 63 -163 minecraft:air
fill 158 63 -163 170 63 -163 minecraft:air
setblock 172 63 -163 minecraft:air
fill 174 63 -163 189 63 -163 minecraft:air
setblock 190 63 -163 minecraft:short_grass
fill 136 63 -164 163 63 -164 minecraft:air
fill 165 63 -164 186 63 -164 minecraft:air
setblock 187 63 -164 minecraft:short_grass
fill 188 63 -164 189 63 -164 minecraft:air
setblock 190 63 -164 minecraft:short_grass
setblock 191 63 -164 minecraft:air
fill 136 63 -165 185 63 -165 minecraft:air
fill 187 63 -165 191 63 -165 minecraft:air
fill 136 63 -166 176 63 -166 minecraft:air
fill 178 63 -166 186 63 -166 minecraft:air
setblock 187 63 -166 regions_unexplored:grass_sprouts
fill 188 63 -166 191 63 -166 minecraft:air
fill 136 63 -167 160 63 -167 minecraft:air
fill 162 63 -167 187 63 -167 minecraft:air
fill 189 63 -167 192 63 -167 minecraft:air
fill 136 63 -168 150 63 -168 minecraft:air
fill 152 63 -168 177 63 -168 minecraft:air
fill 179 63 -168 184 63 -168 minecraft:air
fill 186 63 -168 192 63 -168 minecraft:air
fill 136 63 -169 145 63 -169 minecraft:air
fill 147 63 -169 187 63 -169 minecraft:air
setblock 188 63 -169 regions_unexplored:grass_sprouts
fill 189 63 -169 192 63 -169 minecraft:air
fill 136 63 -170 193 63 -170 minecraft:air
fill 136 63 -171 167 63 -171 minecraft:air
fill 169 63 -171 171 63 -171 minecraft:air
fill 173 63 -171 193 63 -171 minecraft:air
fill 136 63 -172 162 63 -172 minecraft:air
fill 164 63 -172 191 63 -172 minecraft:air
setblock 193 63 -172 minecraft:air
fill 136 63 -173 160 63 -173 minecraft:air
fill 162 63 -173 181 63 -173 minecraft:air
fill 183 63 -173 194 63 -173 minecraft:air
fill 136 63 -174 188 63 -174 minecraft:air
fill 190 63 -174 194 63 -174 minecraft:air
fill 136 63 -175 194 63 -175 minecraft:air
fill 136 63 -176 155 63 -176 minecraft:air
fill 157 63 -176 170 63 -176 minecraft:air
fill 172 63 -176 185 63 -176 minecraft:air
fill 187 63 -176 195 63 -176 minecraft:air
fill 136 63 -177 158 63 -177 minecraft:air
fill 160 63 -177 195 63 -177 minecraft:air
fill 136 63 -178 195 63 -178 minecraft:air
fill 136 63 -179 196 63 -179 minecraft:air
fill 136 63 -180 174 63 -180 minecraft:air
fill 176 63 -180 196 63 -180 minecraft:air
fill 136 63 -181 160 63 -181 minecraft:air
fill 162 63 -181 190 63 -181 minecraft:air
fill 192 63 -181 196 63 -181 minecraft:air
fill 136 63 -182 154 63 -182 minecraft:air
fill 156 63 -182 169 63 -182 minecraft:air
fill 171 63 -182 185 63 -182 minecraft:air
fill 187 63 -182 193 63 -182 minecraft:air
setblock 194 63 -182 regions_unexplored:grass_sprouts
fill 195 63 -182 196 63 -182 minecraft:air
fill 136 63 -183 162 63 -183 minecraft:air
fill 164 63 -183 180 63 -183 minecraft:air
fill 182 63 -183 192 63 -183 minecraft:air
setblock 193 63 -183 regions_unexplored:grass_sprouts
fill 194 63 -183 195 63 -183 minecraft:air
fill 136 63 -184 187 63 -184 minecraft:air
setblock 188 63 -184 regions_unexplored:grass_sprouts
fill 189 63 -184 194 63 -184 minecraft:air
setblock 195 63 -184 regions_unexplored:grass_sprouts
setblock 196 63 -184 minecraft:air
fill 136 63 -185 160 63 -185 minecraft:air
fill 162 63 -185 181 63 -185 minecraft:air
fill 183 63 -185 190 63 -185 minecraft:air
fill 192 63 -185 194 63 -185 minecraft:air
fill 136 63 -186 163 63 -186 minecraft:air
fill 165 63 -186 187 63 -186 minecraft:air
setblock 188 63 -186 regions_unexplored:grass_sprouts
fill 189 63 -186 190 63 -186 minecraft:air
setblock 191 63 -186 regions_unexplored:grass_sprouts
fill 192 63 -186 194 63 -186 minecraft:air
fill 136 63 -187 153 63 -187 minecraft:air
fill 155 63 -187 187 63 -187 minecraft:air
setblock 188 63 -187 minecraft:short_grass
fill 189 63 -187 193 63 -187 minecraft:air
fill 136 63 -188 150 63 -188 minecraft:air
fill 152 63 -188 166 63 -188 minecraft:air
fill 168 63 -188 186 63 -188 minecraft:air
setblock 187 63 -188 regions_unexplored:grass_sprouts
fill 188 63 -188 190 63 -188 minecraft:air
setblock 191 63 -188 minecraft:short_grass
fill 192 63 -188 193 63 -188 minecraft:air
fill 136 63 -189 174 63 -189 minecraft:air
fill 176 63 -189 183 63 -189 minecraft:air
fill 185 63 -189 193 63 -189 minecraft:air
fill 136 63 -190 182 63 -190 minecraft:air
setblock 183 63 -190 herbsandharvest:plum_fruit_leaves[age=2,distance=1,persistent=false,waterlogged=false]
fill 184 63 -190 188 63 -190 minecraft:air
setblock 189 63 -190 regions_unexplored:grass_sprouts
setblock 190 63 -190 minecraft:air
setblock 192 63 -190 regions_unexplored:grass_sprouts
setblock 193 63 -190 minecraft:air
setblock 187 62 -128 minecraft:air
fill 185 62 -129 187 62 -129 minecraft:air
fill 185 62 -130 187 62 -130 minecraft:air
setblock 192 62 -130 minecraft:air
fill 192 62 -131 193 62 -131 minecraft:air
fill 191 62 -132 194 62 -132 minecraft:air
fill 191 62 -133 194 62 -133 minecraft:air
setblock 136 62 -134 minecraft:air
fill 191 62 -134 194 62 -134 minecraft:air
fill 136 62 -135 140 62 -135 minecraft:air
fill 191 62 -135 194 62 -135 minecraft:air
fill 136 62 -136 140 62 -136 minecraft:air
fill 191 62 -136 194 62 -136 minecraft:air
fill 136 62 -137 140 62 -137 minecraft:air
fill 191 62 -137 194 62 -137 minecraft:air
fill 136 62 -138 140 62 -138 minecraft:air
fill 191 62 -138 194 62 -138 minecraft:air
fill 136 62 -139 140 62 -139 minecraft:air
fill 191 62 -139 195 62 -139 minecraft:air
fill 136 62 -140 139 62 -140 minecraft:air
setblock 141 62 -140 minecraft:air
fill 192 62 -140 195 62 -140 minecraft:air
fill 136 62 -141 141 62 -141 minecraft:air
fill 192 62 -141 196 62 -141 minecraft:air
fill 136 62 -142 140 62 -142 minecraft:air
fill 193 62 -142 195 62 -142 minecraft:air
fill 151 62 -146 155 62 -146 pneumaticcraft:oil[level=0]
fill 150 62 -147 155 62 -147 pneumaticcraft:oil[level=0]
fill 149 62 -148 156 62 -148 pneumaticcraft:oil[level=0]
fill 148 62 -149 156 62 -149 pneumaticcraft:oil[level=0]
fill 148 62 -150 156 62 -150 pneumaticcraft:oil[level=0]
fill 175 62 -150 176 62 -150 minecraft:air
fill 148 62 -151 156 62 -151 pneumaticcraft:oil[level=0]
fill 171 62 -151 178 62 -151 minecraft:air
fill 147 62 -152 156 62 -152 pneumaticcraft:oil[level=0]
fill 168 62 -152 169 62 -152 regions_unexplored:day_lily[half=lower]
setblock 170 62 -152 regions_unexplored:grass_sprouts
fill 171 62 -152 178 62 -152 minecraft:air
setblock 180 62 -152 minecraft:air
fill 147 62 -153 156 62 -153 pneumaticcraft:oil[level=0]
setblock 168 62 -153 regions_unexplored:grass_sprouts
setblock 169 62 -153 minecraft:air
setblock 170 62 -153 minecraft:short_grass
fill 171 62 -153 180 62 -153 minecraft:air
fill 149 62 -154 156 62 -154 pneumaticcraft:oil[level=0]
fill 167 62 -154 169 62 -154 minecraft:air
setblock 170 62 -154 regions_unexplored:day_lily[half=lower]
setblock 171 62 -154 minecraft:short_grass
fill 172 62 -154 180 62 -154 minecraft:air
setblock 181 62 -154 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=4]
fill 154 62 -155 156 62 -155 pneumaticcraft:oil[level=0]
setblock 166 62 -155 regions_unexplored:day_lily[half=lower]
fill 167 62 -155 168 62 -155 minecraft:air
setblock 169 62 -155 regions_unexplored:day_lily[half=lower]
fill 170 62 -155 171 62 -155 minecraft:air
setblock 173 62 -155 minecraft:air
fill 175 62 -155 179 62 -155 minecraft:air
setblock 181 62 -155 minecraft:air
setblock 182 62 -155 minecraft:lily_of_the_valley
fill 154 62 -156 155 62 -156 pneumaticcraft:oil[level=0]
fill 165 62 -156 167 62 -156 minecraft:air
setblock 168 62 -156 minecraft:short_grass
fill 169 62 -156 179 62 -156 minecraft:air
setblock 180 62 -156 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=1]
setblock 181 62 -156 minecraft:air
setblock 182 62 -156 regions_unexplored:red_maple_leaf_litter[facing=north,flower_amount=3]
fill 165 62 -157 166 62 -157 minecraft:short_grass
setblock 167 62 -157 regions_unexplored:grass_sprouts
setblock 168 62 -157 minecraft:air
setblock 169 62 -157 minecraft:short_grass
setblock 170 62 -157 minecraft:air
fill 171 62 -157 172 62 -157 regions_unexplored:grass_sprouts
fill 174 62 -157 176 62 -157 minecraft:air
fill 178 62 -157 179 62 -157 minecraft:air
setblock 180 62 -157 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=2]
setblock 181 62 -157 minecraft:air
setblock 182 62 -157 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=3]
fill 165 62 -158 166 62 -158 minecraft:air
setblock 167 62 -158 minecraft:short_grass
fill 168 62 -158 171 62 -158 minecraft:air
fill 172 62 -158 173 62 -158 regions_unexplored:grass_sprouts
fill 174 62 -158 175 62 -158 minecraft:air
fill 177 62 -158 182 62 -158 minecraft:air
setblock 183 62 -158 regions_unexplored:red_maple_leaf_litter[facing=south,flower_amount=2]
fill 153 62 -159 158 62 -159 minecraft:air
fill 160 62 -159 161 62 -159 minecraft:air
setblock 162 62 -159 regions_unexplored:grass_sprouts
fill 163 62 -159 165 62 -159 minecraft:air
setblock 166 62 -159 minecraft:short_grass
setblock 167 62 -159 regions_unexplored:grass_sprouts
fill 168 62 -159 169 62 -159 minecraft:air
setblock 170 62 -159 minecraft:short_grass
setblock 171 62 -159 minecraft:air
fill 173 62 -159 175 62 -159 minecraft:air
setblock 176 62 -159 minecraft:short_grass
setblock 177 62 -159 minecraft:air
setblock 179 62 -159 minecraft:air
setblock 180 62 -159 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=2]
setblock 181 62 -159 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=1]
setblock 182 62 -159 minecraft:air
setblock 183 62 -159 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=3]
setblock 184 62 -159 minecraft:air
fill 136 62 -160 152 62 -160 minecraft:air
fill 154 62 -160 158 62 -160 minecraft:air
setblock 159 62 -160 regions_unexplored:grass_sprouts
fill 160 62 -160 161 62 -160 minecraft:air
setblock 163 62 -160 regions_unexplored:grass_sprouts
fill 164 62 -160 174 62 -160 minecraft:air
fill 176 62 -160 180 62 -160 minecraft:air
setblock 181 62 -160 minecraft:short_grass
setblock 182 62 -160 regions_unexplored:red_maple_leaf_litter[facing=west,flower_amount=4]
fill 183 62 -160 184 62 -160 minecraft:air
fill 136 62 -161 149 62 -161 minecraft:air
fill 151 62 -161 157 62 -161 minecraft:air
setblock 158 62 -161 regions_unexplored:grass_sprouts
fill 159 62 -161 160 62 -161 minecraft:air
setblock 161 62 -161 minecraft:short_grass
fill 162 62 -161 167 62 -161 minecraft:air
setblock 168 62 -161 regions_unexplored:grass_sprouts
fill 169 62 -161 170 62 -161 minecraft:air
setblock 171 62 -161 minecraft:short_grass
fill 172 62 -161 173 62 -161 minecraft:air
setblock 175 62 -161 minecraft:short_grass
setblock 176 62 -161 minecraft:air
setblock 177 62 -161 minecraft:short_grass
setblock 178 62 -161 minecraft:air
setblock 179 62 -161 minecraft:short_grass
setblock 181 62 -161 minecraft:air
setblock 182 62 -161 regions_unexplored:grass_sprouts
fill 183 62 -161 185 62 -161 minecraft:air
fill 136 62 -162 153 62 -162 minecraft:air
setblock 154 62 -162 regions_unexplored:grass_sprouts
fill 155 62 -162 159 62 -162 minecraft:air
fill 161 62 -162 163 62 -162 minecraft:air
setblock 164 62 -162 minecraft:short_grass
fill 165 62 -162 167 62 -162 minecraft:air
setblock 168 62 -162 regions_unexplored:grass_sprouts
setblock 169 62 -162 minecraft:air
fill 170 62 -162 171 62 -162 minecraft:short_grass
setblock 172 62 -162 minecraft:air
setblock 174 62 -162 minecraft:air
setblock 175 62 -162 regions_unexplored:grass_sprouts
setblock 176 62 -162 minecraft:short_grass
setblock 177 62 -162 minecraft:air
fill 179 62 -162 185 62 -162 minecraft:air
fill 136 62 -163 151 62 -163 minecraft:air
setblock 152 62 -163 regions_unexplored:grass_sprouts
fill 153 62 -163 156 62 -163 minecraft:air
fill 158 62 -163 159 62 -163 minecraft:air
setblock 160 62 -163 regions_unexplored:grass_sprouts
setblock 161 62 -163 minecraft:air
setblock 162 62 -163 minecraft:short_grass
fill 163 62 -163 164 62 -163 minecraft:air
setblock 165 62 -163 minecraft:short_grass
fill 166 62 -163 170 62 -163 minecraft:air
setblock 172 62 -163 minecraft:short_grass
setblock 174 62 -163 minecraft:air
setblock 176 62 -163 regions_unexplored:grass_sprouts
fill 177 62 -163 185 62 -163 minecraft:air
fill 136 62 -164 149 62 -164 minecraft:air
setblock 150 62 -164 minecraft:short_grass
fill 151 62 -164 154 62 -164 minecraft:air
fill 155 62 -164 156 62 -164 regions_unexplored:grass_sprouts
fill 157 62 -164 160 62 -164 minecraft:air
setblock 161 62 -164 minecraft:short_grass
setblock 162 62 -164 regions_unexplored:grass_sprouts
setblock 163 62 -164 minecraft:air
fill 165 62 -164 171 62 -164 minecraft:air
setblock 172 62 -164 regions_unexplored:grass_sprouts
setblock 175 62 -164 minecraft:air
setblock 176 62 -164 regions_unexplored:grass_sprouts
fill 177 62 -164 186 62 -164 minecraft:air
fill 136 62 -165 149 62 -165 minecraft:air
setblock 150 62 -165 regions_unexplored:grass_sprouts
fill 151 62 -165 157 62 -165 minecraft:air
setblock 158 62 -165 regions_unexplored:grass_sprouts
fill 159 62 -165 167 62 -165 minecraft:air
setblock 168 62 -165 minecraft:short_grass
fill 169 62 -165 172 62 -165 minecraft:air
setblock 173 62 -165 minecraft:short_grass
fill 174 62 -165 175 62 -165 minecraft:air
setblock 176 62 -165 minecraft:short_grass
fill 177 62 -165 178 62 -165 minecraft:air
setblock 179 62 -165 regions_unexplored:grass_sprouts
setblock 180 62 -165 minecraft:short_grass
fill 181 62 -165 185 62 -165 minecraft:air
fill 136 62 -166 159 62 -166 minecraft:air
setblock 160 62 -166 regions_unexplored:grass_sprouts
fill 161 62 -166 162 62 -166 minecraft:air
setblock 163 62 -166 minecraft:short_grass
fill 164 62 -166 166 62 -166 minecraft:air
setblock 167 62 -166 minecraft:short_grass
setblock 168 62 -166 regions_unexplored:grass_sprouts
setblock 169 62 -166 minecraft:air
setblock 170 62 -166 regions_unexplored:grass_sprouts
setblock 171 62 -166 minecraft:air
setblock 172 62 -166 minecraft:short_grass
fill 173 62 -166 174 62 -166 minecraft:air
setblock 175 62 -166 minecraft:short_grass
setblock 176 62 -166 minecraft:air
fill 178 62 -166 186 62 -166 minecraft:air
fill 136 62 -167 151 62 -167 minecraft:air
setblock 152 62 -167 regions_unexplored:grass_sprouts
fill 153 62 -167 154 62 -167 minecraft:air
setblock 155 62 -167 regions_unexplored:grass_sprouts
fill 156 62 -167 160 62 -167 minecraft:air
fill 162 62 -167 169 62 -167 minecraft:air
setblock 170 62 -167 minecraft:short_grass
fill 171 62 -167 178 62 -167 minecraft:air
setblock 179 62 -167 minecraft:short_grass
fill 180 62 -167 186 62 -167 minecraft:air
fill 136 62 -168 150 62 -168 minecraft:air
fill 152 62 -168 160 62 -168 minecraft:air
setblock 161 62 -168 regions_unexplored:grass_sprouts
fill 162 62 -168 168 62 -168 minecraft:air
setblock 169 62 -168 regions_unexplored:grass_sprouts
fill 170 62 -168 177 62 -168 minecraft:air
setblock 179 62 -168 regions_unexplored:grass_sprouts
fill 180 62 -168 184 62 -168 minecraft:air
fill 136 62 -169 170 62 -169 minecraft:air
setblock 171 62 -169 regions_unexplored:grass_sprouts
fill 172 62 -169 174 62 -169 minecraft:air
setblock 175 62 -169 regions_unexplored:grass_sprouts
fill 176 62 -169 179 62 -169 minecraft:air
setblock 180 62 -169 regions_unexplored:grass_sprouts
fill 181 62 -169 185 62 -169 minecraft:air
fill 136 62 -170 153 62 -170 minecraft:air
setblock 154 62 -170 regions_unexplored:grass_sprouts
fill 155 62 -170 167 62 -170 minecraft:air
setblock 168 62 -170 minecraft:short_grass
fill 169 62 -170 185 62 -170 minecraft:air
fill 136 62 -171 161 62 -171 minecraft:air
setblock 162 62 -171 regions_unexplored:grass_sprouts
setblock 163 62 -171 minecraft:air
setblock 164 62 -171 minecraft:short_grass
fill 165 62 -171 167 62 -171 minecraft:air
setblock 169 62 -171 regions_unexplored:grass_sprouts
fill 170 62 -171 171 62 -171 minecraft:air
fill 173 62 -171 174 62 -171 minecraft:air
setblock 175 62 -171 regions_unexplored:grass_sprouts
fill 176 62 -171 177 62 -171 minecraft:air
setblock 178 62 -171 regions_unexplored:grass_sprouts
fill 179 62 -171 185 62 -171 minecraft:air
fill 136 62 -172 154 62 -172 minecraft:air
setblock 155 62 -172 minecraft:short_grass
fill 156 62 -172 162 62 -172 minecraft:air
fill 164 62 -172 166 62 -172 minecraft:air
fill 167 62 -172 168 62 -172 regions_unexplored:grass_sprouts
fill 169 62 -172 177 62 -172 minecraft:air
setblock 178 62 -172 minecraft:short_grass
fill 179 62 -172 183 62 -172 minecraft:air
setblock 184 62 -172 regions_unexplored:grass_sprouts
fill 136 62 -173 158 62 -173 minecraft:air
setblock 159 62 -173 regions_unexplored:grass_sprouts
setblock 160 62 -173 minecraft:air
setblock 162 62 -173 minecraft:air
setblock 163 62 -173 minecraft:short_grass
fill 164 62 -173 170 62 -173 minecraft:air
setblock 171 62 -173 minecraft:short_grass
fill 172 62 -173 180 62 -173 minecraft:air
setblock 181 62 -173 minecraft:short_grass
fill 183 62 -173 184 62 -173 minecraft:air
fill 136 62 -174 178 62 -174 minecraft:air
setblock 179 62 -174 regions_unexplored:grass_sprouts
fill 180 62 -174 183 62 -174 minecraft:air
fill 136 62 -175 159 62 -175 minecraft:air
setblock 160 62 -175 minecraft:short_grass
fill 161 62 -175 172 62 -175 minecraft:air
setblock 173 62 -175 minecraft:short_grass
fill 174 62 -175 175 62 -175 minecraft:air
setblock 176 62 -175 minecraft:short_grass
setblock 177 62 -175 minecraft:air
setblock 178 62 -175 regions_unexplored:grass_sprouts
fill 179 62 -175 182 62 -175 minecraft:air
fill 136 62 -176 149 62 -176 minecraft:air
setblock 150 62 -176 minecraft:short_grass
fill 151 62 -176 153 62 -176 minecraft:air
setblock 154 62 -176 minecraft:short_grass
setblock 155 62 -176 minecraft:air
fill 157 62 -176 158 62 -176 minecraft:air
fill 159 62 -176 160 62 -176 regions_unexplored:grass_sprouts
fill 161 62 -176 162 62 -176 minecraft:air
setblock 163 62 -176 minecraft:short_grass
fill 164 62 -176 170 62 -176 minecraft:air
fill 172 62 -176 181 62 -176 minecraft:air
fill 136 62 -177 153 62 -177 minecraft:air
setblock 154 62 -177 regions_unexplored:grass_sprouts
setblock 155 62 -177 minecraft:air
setblock 156 62 -177 regions_unexplored:grass_sprouts
fill 157 62 -177 158 62 -177 minecraft:air
fill 160 62 -177 173 62 -177 minecraft:air
setblock 174 62 -177 regions_unexplored:grass_sprouts
fill 175 62 -177 182 62 -177 minecraft:air
fill 136 62 -178 156 62 -178 minecraft:air
setblock 157 62 -178 regions_unexplored:grass_sprouts
fill 158 62 -178 182 62 -178 minecraft:air
fill 136 62 -179 154 62 -179 minecraft:air
setblock 155 62 -179 regions_unexplored:grass_sprouts
setblock 156 62 -179 minecraft:short_grass
fill 157 62 -179 167 62 -179 minecraft:air
setblock 168 62 -179 regions_unexplored:grass_sprouts
fill 169 62 -179 182 62 -179 minecraft:air
fill 136 62 -180 157 62 -180 minecraft:air
setblock 158 62 -180 regions_unexplored:grass_sprouts
setblock 159 62 -180 minecraft:short_grass
fill 160 62 -180 174 62 -180 minecraft:air
setblock 176 62 -180 regions_unexplored:grass_sprouts
fill 177 62 -180 182 62 -180 minecraft:air
fill 136 62 -181 155 62 -181 minecraft:air
setblock 156 62 -181 minecraft:short_grass
fill 157 62 -181 160 62 -181 minecraft:air
fill 162 62 -181 164 62 -181 minecraft:air
setblock 165 62 -181 minecraft:short_grass
fill 166 62 -181 175 62 -181 minecraft:air
setblock 176 62 -181 minecraft:short_grass
fill 177 62 -181 178 62 -181 minecraft:air
setblock 179 62 -181 minecraft:short_grass
fill 180 62 -181 183 62 -181 minecraft:air
fill 136 62 -182 154 62 -182 minecraft:air
fill 156 62 -182 168 62 -182 minecraft:air
setblock 169 62 -182 regions_unexplored:grass_sprouts
setblock 171 62 -182 minecraft:short_grass
fill 172 62 -182 183 62 -182 minecraft:air
fill 136 62 -183 155 62 -183 minecraft:air
setblock 156 62 -183 regions_unexplored:grass_sprouts
fill 157 62 -183 162 62 -183 minecraft:air
fill 164 62 -183 180 62 -183 minecraft:air
fill 182 62 -183 184 62 -183 minecraft:air
fill 136 62 -184 154 62 -184 minecraft:air
fill 155 62 -184 156 62 -184 minecraft:short_grass
fill 157 62 -184 164 62 -184 minecraft:air
setblock 165 62 -184 regions_unexplored:grass_sprouts
fill 166 62 -184 169 62 -184 minecraft:air
setblock 170 62 -184 regions_unexplored:grass_sprouts
fill 171 62 -184 176 62 -184 minecraft:air
setblock 177 62 -184 regions_unexplored:grass_sprouts
fill 178 62 -184 185 62 -184 minecraft:air
fill 136 62 -185 151 62 -185 minecraft:air
setblock 152 62 -185 minecraft:short_grass
fill 153 62 -185 160 62 -185 minecraft:air
fill 162 62 -185 163 62 -185 minecraft:air
setblock 164 62 -185 regions_unexplored:grass_sprouts
fill 165 62 -185 171 62 -185 minecraft:air
setblock 172 62 -185 regions_unexplored:grass_sprouts
fill 173 62 -185 174 62 -185 minecraft:air
setblock 175 62 -185 regions_unexplored:grass_sprouts
fill 176 62 -185 181 62 -185 minecraft:air
fill 183 62 -185 185 62 -185 minecraft:air
fill 136 62 -186 150 62 -186 minecraft:air
setblock 151 62 -186 minecraft:short_grass
fill 152 62 -186 163 62 -186 minecraft:air
fill 165 62 -186 170 62 -186 minecraft:air
setblock 171 62 -186 minecraft:short_grass
fill 172 62 -186 173 62 -186 regions_unexplored:grass_sprouts
setblock 174 62 -186 minecraft:air
setblock 175 62 -186 minecraft:short_grass
setblock 176 62 -186 regions_unexplored:grass_sprouts
setblock 177 62 -186 minecraft:air
setblock 178 62 -186 regions_unexplored:grass_sprouts
fill 179 62 -186 183 62 -186 minecraft:air
setblock 184 62 -186 minecraft:short_grass
setblock 185 62 -186 regions_unexplored:grass_sprouts
setblock 186 62 -186 minecraft:short_grass
fill 136 62 -187 153 62 -187 minecraft:air
fill 155 62 -187 166 62 -187 minecraft:air
setblock 167 62 -187 regions_unexplored:grass_sprouts
fill 168 62 -187 169 62 -187 minecraft:air
setblock 170 62 -187 regions_unexplored:grass_sprouts
fill 171 62 -187 172 62 -187 minecraft:air
setblock 173 62 -187 minecraft:short_grass
fill 174 62 -187 184 62 -187 minecraft:air
setblock 185 62 -187 minecraft:short_grass
setblock 186 62 -187 minecraft:air
fill 136 62 -188 149 62 -188 minecraft:air
setblock 150 62 -188 minecraft:short_grass
fill 152 62 -188 157 62 -188 minecraft:air
setblock 158 62 -188 regions_unexplored:grass_sprouts
fill 159 62 -188 164 62 -188 minecraft:air
setblock 165 62 -188 minecraft:short_grass
setblock 166 62 -188 minecraft:air
fill 168 62 -188 178 62 -188 minecraft:air
setblock 179 62 -188 regions_unexplored:grass_sprouts
fill 180 62 -188 183 62 -188 minecraft:air
setblock 184 62 -188 minecraft:short_grass
fill 185 62 -188 186 62 -188 minecraft:air
fill 136 62 -189 152 62 -189 minecraft:air
setblock 153 62 -189 regions_unexplored:grass_sprouts
fill 154 62 -189 172 62 -189 minecraft:air
setblock 173 62 -189 regions_unexplored:grass_sprouts
setblock 174 62 -189 minecraft:air
fill 176 62 -189 183 62 -189 minecraft:air
setblock 185 62 -189 regions_unexplored:grass_sprouts
fill 186 62 -189 187 62 -189 minecraft:air
fill 136 62 -190 154 62 -190 minecraft:air
setblock 155 62 -190 regions_unexplored:grass_sprouts
fill 156 62 -190 172 62 -190 minecraft:air
setblock 173 62 -190 regions_unexplored:grass_sprouts
fill 174 62 -190 187 62 -190 minecraft:air
fill 185 61 -128 186 61 -128 minecraft:air
fill 189 61 -128 190 61 -128 minecraft:water[level=0]
fill 184 61 -129 187 61 -129 minecraft:air
fill 189 61 -129 190 61 -129 minecraft:water[level=0]
fill 183 61 -130 187 61 -130 minecraft:air
setblock 189 61 -130 minecraft:water[level=0]
fill 183 61 -131 187 61 -131 minecraft:air
fill 184 61 -132 185 61 -132 minecraft:air
fill 193 61 -132 194 61 -132 minecraft:air
fill 193 61 -133 194 61 -133 minecraft:air
setblock 136 61 -134 minecraft:air
fill 191 61 -134 194 61 -134 minecraft:air
fill 136 61 -135 139 61 -135 minecraft:air
fill 191 61 -135 194 61 -135 minecraft:air
fill 136 61 -136 140 61 -136 minecraft:air
fill 191 61 -136 194 61 -136 minecraft:air
fill 136 61 -137 140 61 -137 minecraft:air
fill 191 61 -137 194 61 -137 minecraft:air
fill 136 61 -138 140 61 -138 minecraft:air
fill 191 61 -138 194 61 -138 minecraft:air
fill 136 61 -139 138 61 -139 minecraft:air
setblock 140 61 -139 minecraft:air
fill 192 61 -139 194 61 -139 minecraft:air
fill 192 61 -140 194 61 -140 minecraft:air
setblock 193 61 -141 minecraft:air
fill 151 61 -147 155 61 -147 pneumaticcraft:oil[level=0]
fill 151 61 -148 155 61 -148 pneumaticcraft:oil[level=0]
fill 152 61 -149 155 61 -149 pneumaticcraft:oil[level=0]
fill 150 61 -150 155 61 -150 pneumaticcraft:oil[level=0]
fill 150 61 -151 155 61 -151 pneumaticcraft:oil[level=0]
fill 150 61 -152 156 61 -152 pneumaticcraft:oil[level=0]
fill 154 61 -153 156 61 -153 pneumaticcraft:oil[level=0]
fill 154 61 -154 156 61 -154 pneumaticcraft:oil[level=0]
fill 154 61 -155 155 61 -155 pneumaticcraft:oil[level=0]
fill 136 61 -160 149 61 -160 minecraft:air
fill 136 61 -161 149 61 -161 minecraft:air
fill 136 61 -162 149 61 -162 minecraft:air
fill 136 61 -163 149 61 -163 minecraft:air
fill 136 61 -164 149 61 -164 minecraft:air
fill 136 61 -165 149 61 -165 minecraft:air
fill 136 61 -166 149 61 -166 minecraft:air
fill 136 61 -167 149 61 -167 minecraft:air
fill 136 61 -168 149 61 -168 minecraft:air
fill 136 61 -169 149 61 -169 minecraft:air
fill 136 61 -170 149 61 -170 minecraft:air
fill 136 61 -171 149 61 -171 minecraft:air
fill 136 61 -172 149 61 -172 minecraft:air
fill 136 61 -173 149 61 -173 minecraft:air
fill 136 61 -174 149 61 -174 minecraft:air
fill 136 61 -175 149 61 -175 minecraft:air
fill 136 61 -176 149 61 -176 minecraft:air
fill 136 61 -177 149 61 -177 minecraft:air
fill 136 61 -178 149 61 -178 minecraft:air
fill 136 61 -179 149 61 -179 minecraft:air
fill 136 61 -180 149 61 -180 minecraft:air
fill 136 61 -181 149 61 -181 minecraft:air
fill 136 61 -182 149 61 -182 minecraft:air
fill 136 61 -183 149 61 -183 minecraft:air
fill 136 61 -184 149 61 -184 minecraft:air
fill 136 61 -185 149 61 -185 minecraft:air
fill 136 61 -186 149 61 -186 minecraft:air
fill 136 61 -187 149 61 -187 minecraft:air
setblock 168 61 -187 minecraft:air
setblock 169 61 -187 regions_unexplored:grass_sprouts
fill 136 61 -188 149 61 -188 minecraft:air
fill 168 61 -188 172 61 -188 minecraft:air
fill 136 61 -189 149 61 -189 minecraft:air
setblock 166 61 -189 minecraft:air
setblock 167 61 -189 regions_unexplored:grass_sprouts
setblock 168 61 -189 minecraft:short_grass
fill 169 61 -189 170 61 -189 minecraft:water[level=7]
fill 171 61 -189 172 61 -189 minecraft:air
fill 136 61 -190 149 61 -190 minecraft:air
fill 165 61 -190 167 61 -190 minecraft:air
setblock 168 61 -190 minecraft:water[level=7]
fill 169 61 -190 170 61 -190 minecraft:water[level=6]
setblock 171 61 -190 minecraft:water[level=7]
setblock 172 61 -190 regions_unexplored:grass_sprouts
fill 185 61 -190 189 61 -190 minecraft:air
setblock 189 60 -127 minecraft:water[level=0]
fill 184 60 -128 186 60 -128 minecraft:air
fill 188 60 -128 191 60 -128 minecraft:water[level=0]
fill 182 60 -129 186 60 -129 minecraft:air
fill 189 60 -129 192 60 -129 minecraft:water[level=0]
fill 182 60 -130 186 60 -130 minecraft:air
fill 189 60 -130 191 60 -130 minecraft:water[level=0]
fill 181 60 -131 187 60 -131 minecraft:air
fill 189 60 -131 190 60 -131 minecraft:water[level=0]
fill 181 60 -132 186 60 -132 minecraft:air
setblock 190 60 -132 minecraft:water[level=0]
setblock 182 60 -133 minecraft:air
setblock 136 60 -134 minecraft:air
setblock 194 60 -134 minecraft:air
fill 136 60 -135 138 60 -135 minecraft:air
fill 191 60 -135 194 60 -135 minecraft:air
fill 136 60 -136 139 60 -136 minecraft:air
fill 191 60 -136 194 60 -136 minecraft:air
fill 136 60 -137 140 60 -137 minecraft:air
fill 192 60 -137 193 60 -137 minecraft:air
fill 136 60 -138 140 60 -138 minecraft:air
fill 136 60 -139 140 60 -139 minecraft:air
setblock 155 60 -152 pneumaticcraft:oil[level=0]
fill 154 60 -153 155 60 -153 pneumaticcraft:oil[level=0]
setblock 155 60 -154 pneumaticcraft:oil[level=0]
fill 136 60 -160 149 60 -160 minecraft:air
fill 136 60 -161 149 60 -161 minecraft:air
fill 136 60 -162 149 60 -162 minecraft:air
fill 136 60 -163 149 60 -163 minecraft:air
fill 136 60 -164 149 60 -164 minecraft:air
fill 136 60 -165 149 60 -165 minecraft:air
fill 136 60 -166 149 60 -166 minecraft:air
fill 136 60 -167 149 60 -167 minecraft:air
fill 136 60 -168 149 60 -168 minecraft:air
fill 136 60 -169 149 60 -169 minecraft:air
fill 136 60 -170 149 60 -170 minecraft:air
fill 136 60 -171 149 60 -171 minecraft:air
fill 136 60 -172 149 60 -172 minecraft:air
fill 136 60 -173 149 60 -173 minecraft:air
fill 136 60 -174 149 60 -174 minecraft:air
setblock 197 60 -174 minecraft:air
fill 136 60 -175 149 60 -175 minecraft:air
fill 136 60 -176 149 60 -176 minecraft:air
fill 136 60 -177 149 60 -177 minecraft:air
fill 136 60 -178 149 60 -178 minecraft:air
fill 136 60 -179 149 60 -179 minecraft:air
fill 136 60 -180 149 60 -180 minecraft:air
fill 136 60 -181 149 60 -181 minecraft:air
fill 136 60 -182 149 60 -182 minecraft:air
fill 136 60 -183 149 60 -183 minecraft:air
fill 136 60 -184 149 60 -184 minecraft:air
fill 136 60 -185 149 60 -185 minecraft:air
fill 136 60 -186 149 60 -186 minecraft:air
fill 136 60 -187 149 60 -187 minecraft:air
fill 136 60 -188 149 60 -188 minecraft:air
fill 136 60 -189 149 60 -189 minecraft:air
fill 185 60 -189 187 60 -189 minecraft:air
fill 136 60 -190 149 60 -190 minecraft:air
fill 184 60 -190 190 60 -190 minecraft:air
setblock 187 59 -127 minecraft:water[level=0]
fill 184 59 -128 185 59 -128 minecraft:air
fill 188 59 -128 190 59 -128 minecraft:water[level=0]
fill 182 59 -129 186 59 -129 minecraft:air
fill 188 59 -129 192 59 -129 minecraft:water[level=0]
fill 181 59 -130 186 59 -130 minecraft:air
fill 188 59 -130 192 59 -130 minecraft:water[level=0]
fill 179 59 -131 186 59 -131 minecraft:air
fill 189 59 -131 192 59 -131 minecraft:water[level=0]
fill 179 59 -132 186 59 -132 minecraft:air
setblock 191 59 -132 minecraft:water[level=0]
fill 179 59 -133 184 59 -133 minecraft:air
setblock 136 59 -134 minecraft:air
setblock 136 59 -135 minecraft:air
setblock 136 59 -136 minecraft:air
setblock 136 59 -137 minecraft:air
setblock 136 59 -138 minecraft:air
fill 136 59 -160 149 59 -160 minecraft:air
fill 136 59 -161 149 59 -161 minecraft:air
fill 136 59 -162 149 59 -162 minecraft:air
fill 136 59 -163 149 59 -163 minecraft:air
fill 136 59 -164 149 59 -164 minecraft:air
fill 136 59 -165 149 59 -165 minecraft:air
fill 136 59 -166 149 59 -166 minecraft:air
fill 136 59 -167 149 59 -167 minecraft:air
fill 136 59 -168 149 59 -168 minecraft:air
fill 136 59 -169 149 59 -169 minecraft:air
fill 136 59 -170 149 59 -170 minecraft:air
fill 136 59 -171 149 59 -171 minecraft:air
fill 136 59 -172 149 59 -172 minecraft:air
fill 136 59 -173 149 59 -173 minecraft:air
setblock 197 59 -173 minecraft:air
fill 136 59 -174 149 59 -174 minecraft:air
fill 197 59 -174 198 59 -174 minecraft:air
fill 136 59 -175 149 59 -175 minecraft:air
setblock 197 59 -175 minecraft:air
fill 136 59 -176 149 59 -176 minecraft:air
fill 136 59 -177 149 59 -177 minecraft:air
fill 136 59 -178 149 59 -178 minecraft:air
fill 136 59 -179 149 59 -179 minecraft:air
fill 136 59 -180 149 59 -180 minecraft:air
fill 136 59 -181 149 59 -181 minecraft:air
fill 136 59 -182 149 59 -182 minecraft:air
fill 136 59 -183 149 59 -183 minecraft:air
fill 136 59 -184 149 59 -184 minecraft:air
fill 186 59 -184 190 59 -184 minecraft:air
fill 136 59 -185 149 59 -185 minecraft:air
fill 185 59 -185 190 59 -185 minecraft:air
fill 136 59 -186 149 59 -186 minecraft:air
fill 184 59 -186 186 59 -186 minecraft:air
setblock 191 59 -186 minecraft:air
fill 136 59 -187 149 59 -187 minecraft:air
fill 184 59 -187 186 59 -187 minecraft:air
fill 191 59 -187 192 59 -187 minecraft:air
fill 136 59 -188 149 59 -188 minecraft:air
fill 184 59 -188 185 59 -188 minecraft:air
setblock 192 59 -188 minecraft:air
fill 136 59 -189 149 59 -189 minecraft:air
fill 183 59 -189 188 59 -189 minecraft:air
setblock 192 59 -189 minecraft:air
fill 136 59 -190 149 59 -190 minecraft:air
fill 183 59 -190 190 59 -190 minecraft:air
fill 184 58 -128 185 58 -128 minecraft:air
setblock 187 58 -128 minecraft:water[level=0]
fill 176 58 -129 177 58 -129 minecraft:air
fill 182 58 -129 185 58 -129 minecraft:air
setblock 187 58 -129 minecraft:water[level=0]
fill 176 58 -130 185 58 -130 minecraft:air
fill 177 58 -131 186 58 -131 minecraft:air
fill 177 58 -132 186 58 -132 minecraft:air
fill 178 58 -133 184 58 -133 minecraft:air
fill 179 58 -134 182 58 -134 minecraft:air
setblock 197 58 -173 minecraft:air
fill 197 58 -174 198 58 -174 minecraft:air
setblock 197 58 -175 minecraft:air
fill 187 58 -183 190 58 -183 minecraft:air
fill 185 58 -184 190 58 -184 minecraft:air
fill 184 58 -185 192 58 -185 minecraft:air
fill 184 58 -186 187 58 -186 minecraft:air
fill 189 58 -186 192 58 -186 minecraft:air
fill 184 58 -187 186 58 -187 minecraft:air
fill 190 58 -187 193 58 -187 minecraft:air
fill 183 58 -188 186 58 -188 minecraft:air
fill 191 58 -188 193 58 -188 minecraft:air
fill 183 58 -189 188 58 -189 minecraft:air
fill 191 58 -189 193 58 -189 minecraft:air
fill 183 58 -190 190 58 -190 minecraft:air
fill 192 58 -190 194 58 -190 minecraft:air
fill 174 57 -127 177 57 -127 minecraft:air
fill 174 57 -128 178 57 -128 minecraft:air
fill 175 57 -129 179 57 -129 minecraft:air
fill 182 57 -129 184 57 -129 minecraft:air
fill 175 57 -130 185 57 -130 minecraft:air
fill 176 57 -131 185 57 -131 minecraft:air
fill 176 57 -132 185 57 -132 minecraft:air
fill 177 57 -133 183 57 -133 minecraft:air
fill 178 57 -134 182 57 -134 minecraft:air
fill 198 57 -176 199 57 -176 minecraft:air
fill 198 57 -177 199 57 -177 minecraft:air
fill 186 57 -183 190 57 -183 minecraft:air
fill 185 57 -184 191 57 -184 minecraft:air
fill 184 57 -185 192 57 -185 minecraft:air
fill 184 57 -186 193 57 -186 minecraft:air
fill 183 57 -187 186 57 -187 minecraft:air
fill 190 57 -187 193 57 -187 minecraft:air
fill 183 57 -188 186 57 -188 minecraft:air
fill 191 57 -188 193 57 -188 minecraft:air
fill 183 57 -189 187 57 -189 minecraft:air
fill 191 57 -189 194 57 -189 minecraft:air
fill 183 57 -190 189 57 -190 minecraft:air
fill 191 57 -190 194 57 -190 minecraft:air
fill 173 56 -127 178 56 -127 minecraft:air
fill 174 56 -128 178 56 -128 minecraft:air
fill 174 56 -129 179 56 -129 minecraft:air
fill 174 56 -130 183 56 -130 minecraft:air
fill 175 56 -131 183 56 -131 minecraft:air
fill 176 56 -132 183 56 -132 minecraft:air
fill 177 56 -133 183 56 -133 minecraft:air
fill 178 56 -134 181 56 -134 minecraft:air
fill 198 56 -176 199 56 -176 minecraft:air
fill 198 56 -177 199 56 -177 minecraft:air
setblock 199 56 -178 minecraft:air
setblock 199 56 -179 minecraft:air
fill 187 56 -183 190 56 -183 minecraft:air
fill 185 56 -184 191 56 -184 minecraft:air
fill 184 56 -185 192 56 -185 minecraft:air
fill 184 56 -186 187 56 -186 minecraft:air
fill 189 56 -186 193 56 -186 minecraft:air
fill 184 56 -187 186 56 -187 minecraft:air
fill 190 56 -187 193 56 -187 minecraft:air
fill 183 56 -188 186 56 -188 minecraft:air
fill 191 56 -188 193 56 -188 minecraft:air
setblock 185 56 -189 minecraft:air
fill 191 56 -189 194 56 -189 minecraft:air
fill 191 56 -190 194 56 -190 minecraft:air
fill 173 55 -127 178 55 -127 minecraft:air
fill 173 55 -128 178 55 -128 minecraft:air
fill 174 55 -129 179 55 -129 minecraft:air
fill 174 55 -130 181 55 -130 minecraft:air
fill 175 55 -131 182 55 -131 minecraft:air
fill 176 55 -132 182 55 -132 minecraft:air
fill 177 55 -133 182 55 -133 minecraft:air
fill 178 55 -134 181 55 -134 minecraft:air
fill 198 55 -176 199 55 -176 minecraft:air
fill 198 55 -177 199 55 -177 minecraft:air
fill 198 55 -178 199 55 -178 minecraft:air
setblock 199 55 -179 minecraft:air
setblock 199 55 -180 minecraft:air
fill 173 54 -127 178 54 -127 minecraft:air
fill 173 54 -128 178 54 -128 minecraft:air
fill 174 54 -129 179 54 -129 minecraft:air
fill 174 54 -130 180 54 -130 minecraft:air
fill 175 54 -131 180 54 -131 minecraft:air
fill 176 54 -132 180 54 -132 minecraft:air
fill 177 54 -133 180 54 -133 minecraft:air
fill 173 54 -136 174 54 -136 minecraft:air
fill 173 54 -137 174 54 -137 minecraft:air
fill 173 54 -138 174 54 -138 minecraft:air
fill 173 54 -139 174 54 -139 minecraft:air
fill 172 54 -140 174 54 -140 minecraft:air
fill 172 54 -141 174 54 -141 minecraft:air
fill 171 54 -142 173 54 -142 minecraft:air
fill 170 54 -143 172 54 -143 minecraft:air
fill 170 54 -144 171 54 -144 minecraft:air
setblock 199 54 -178 minecraft:air
setblock 199 54 -179 minecraft:air
setblock 199 54 -180 minecraft:air
setblock 199 54 -190 minecraft:air
fill 173 53 -127 177 53 -127 minecraft:air
fill 174 53 -128 177 53 -128 minecraft:air
fill 174 53 -129 177 53 -129 minecraft:air
fill 173 53 -135 174 53 -135 minecraft:air
fill 172 53 -136 175 53 -136 minecraft:air
fill 172 53 -137 175 53 -137 minecraft:air
fill 172 53 -138 175 53 -138 minecraft:air
fill 172 53 -139 175 53 -139 minecraft:air
fill 172 53 -140 174 53 -140 minecraft:air
fill 171 53 -141 174 53 -141 minecraft:air
fill 170 53 -142 174 53 -142 minecraft:air
fill 169 53 -143 173 53 -143 minecraft:air
setblock 166 53 -144 minecraft:air
fill 169 53 -144 172 53 -144 minecraft:air
setblock 166 53 -145 minecraft:air
fill 169 53 -145 171 53 -145 minecraft:air
setblock 199 53 -190 minecraft:air
fill 173 52 -135 174 52 -135 minecraft:air
fill 173 52 -136 174 52 -136 minecraft:air
fill 152 52 -137 153 52 -137 minecraft:air
fill 173 52 -137 174 52 -137 minecraft:air
fill 151 52 -138 152 52 -138 minecraft:air
fill 151 52 -139 152 52 -139 minecraft:air
setblock 151 52 -140 minecraft:air
setblock 151 52 -141 minecraft:air
fill 171 52 -141 173 52 -141 minecraft:air
fill 170 52 -142 173 52 -142 minecraft:air
fill 166 52 -143 167 52 -143 minecraft:air
fill 169 52 -143 173 52 -143 minecraft:air
fill 163 52 -144 167 52 -144 minecraft:air
fill 169 52 -144 172 52 -144 minecraft:air
fill 155 52 -145 156 52 -145 minecraft:air
fill 161 52 -145 167 52 -145 minecraft:air
fill 169 52 -145 171 52 -145 minecraft:air
fill 155 52 -146 156 52 -146 minecraft:air
fill 163 52 -146 167 52 -146 minecraft:air
setblock 199 52 -189 minecraft:air
setblock 199 52 -190 minecraft:air
fill 152 51 -135 156 51 -135 minecraft:air
fill 151 51 -136 157 51 -136 minecraft:air
fill 150 51 -137 157 51 -137 minecraft:air
fill 150 51 -138 157 51 -138 minecraft:air
fill 150 51 -139 153 51 -139 minecraft:air
fill 150 51 -140 153 51 -140 minecraft:air
fill 149 51 -141 153 51 -141 minecraft:air
fill 150 51 -142 153 51 -142 minecraft:air
fill 150 51 -143 153 51 -143 minecraft:air
setblock 164 51 -143 minecraft:air
fill 166 51 -143 167 51 -143 minecraft:air
fill 151 51 -144 167 51 -144 minecraft:air
fill 151 51 -145 167 51 -145 minecraft:air
fill 152 51 -146 167 51 -146 minecraft:air
fill 155 51 -147 163 51 -147 minecraft:air
setblock 199 51 -190 minecraft:air
setblock 154 50 -134 minecraft:air
fill 152 50 -135 157 50 -135 minecraft:air
fill 151 50 -136 158 50 -136 minecraft:air
fill 150 50 -137 158 50 -137 minecraft:air
fill 150 50 -138 159 50 -138 minecraft:air
fill 150 50 -139 153 50 -139 minecraft:air
fill 156 50 -139 159 50 -139 minecraft:air
fill 149 50 -140 153 50 -140 minecraft:air
fill 157 50 -140 159 50 -140 minecraft:air
fill 149 50 -141 153 50 -141 minecraft:air
fill 158 50 -141 159 50 -141 minecraft:air
fill 150 50 -142 153 50 -142 minecraft:air
fill 150 50 -143 154 50 -143 minecraft:air
fill 150 50 -144 164 50 -144 minecraft:air
fill 151 50 -145 165 50 -145 minecraft:air
fill 152 50 -146 164 50 -146 minecraft:air
fill 153 50 -147 162 50 -147 minecraft:air
setblock 172 50 -184 minecraft:water[level=0]
setblock 172 50 -185 minecraft:water[level=0]
setblock 172 50 -186 minecraft:water[level=0]
fill 172 50 -187 173 50 -187 minecraft:water[level=0]
setblock 169 50 -188 minecraft:air
fill 171 50 -188 173 50 -188 minecraft:water[level=0]
setblock 169 50 -189 minecraft:air
fill 171 50 -189 174 50 -189 minecraft:water[level=0]
setblock 137 50 -190 oritech:still_oil_block[level=0]
fill 171 50 -190 174 50 -190 minecraft:water[level=0]
fill 152 49 -135 157 49 -135 minecraft:air
fill 151 49 -136 158 49 -136 minecraft:air
fill 151 49 -137 159 49 -137 minecraft:air
fill 151 49 -138 159 49 -138 minecraft:air
fill 152 49 -139 153 49 -139 minecraft:air
fill 156 49 -139 160 49 -139 minecraft:air
fill 156 49 -140 160 49 -140 minecraft:air
fill 151 49 -141 152 49 -141 minecraft:air
fill 157 49 -141 160 49 -141 minecraft:air
fill 150 49 -142 153 49 -142 minecraft:air
fill 157 49 -142 160 49 -142 minecraft:air
fill 150 49 -143 154 49 -143 minecraft:air
fill 157 49 -143 160 49 -143 minecraft:air
fill 151 49 -144 153 49 -144 minecraft:air
fill 157 49 -144 160 49 -144 minecraft:air
fill 151 49 -145 153 49 -145 minecraft:air
fill 158 49 -145 159 49 -145 minecraft:air
setblock 158 49 -146 minecraft:air
setblock 158 49 -147 minecraft:air
fill 172 49 -179 174 49 -179 minecraft:air
fill 171 49 -180 174 49 -180 minecraft:air
fill 170 49 -181 173 49 -181 minecraft:air
fill 168 49 -182 170 49 -182 minecraft:air
setblock 173 49 -182 minecraft:air
fill 168 49 -183 170 49 -183 minecraft:air
fill 167 49 -184 170 49 -184 minecraft:air
fill 172 49 -184 173 49 -184 minecraft:water[level=0]
fill 167 49 -185 170 49 -185 minecraft:air
fill 172 49 -185 173 49 -185 minecraft:water[level=0]
fill 166 49 -186 169 49 -186 minecraft:air
fill 172 49 -186 173 49 -186 minecraft:water[level=0]
setblock 137 49 -187 oritech:still_oil_block[level=0]
fill 165 49 -187 169 49 -187 minecraft:air
fill 172 49 -187 174 49 -187 minecraft:water[level=0]
setblock 138 49 -188 oritech:still_oil_block[level=0]
fill 165 49 -188 169 49 -188 minecraft:air
fill 171 49 -188 174 49 -188 minecraft:water[level=0]
fill 136 49 -189 137 49 -189 oritech:still_oil_block[level=0]
fill 140 49 -189 141 49 -189 oritech:still_oil_block[level=0]
fill 165 49 -189 169 49 -189 minecraft:air
fill 171 49 -189 175 49 -189 minecraft:water[level=0]
fill 136 49 -190 141 49 -190 oritech:still_oil_block[level=0]
fill 166 49 -190 168 49 -190 minecraft:air
fill 171 49 -190 177 49 -190 minecraft:water[level=0]
fill 151 48 -127 156 48 -127 minecraft:air
setblock 158 48 -127 minecraft:air
setblock 186 48 -127 minecraft:air
fill 190 48 -127 198 48 -127 minecraft:water[level=0]
fill 153 48 -128 156 48 -128 minecraft:air
fill 190 48 -128 196 48 -128 minecraft:water[level=0]
fill 192 48 -129 194 48 -129 minecraft:water[level=0]
fill 197 48 -130 199 48 -130 minecraft:air
fill 156 48 -136 158 48 -136 minecraft:air
fill 155 48 -137 159 48 -137 minecraft:air
fill 155 48 -138 159 48 -138 minecraft:air
fill 156 48 -139 160 48 -139 minecraft:air
fill 156 48 -140 160 48 -140 minecraft:air
fill 156 48 -141 160 48 -141 minecraft:air
fill 156 48 -142 160 48 -142 minecraft:air
fill 157 48 -143 160 48 -143 minecraft:air
fill 157 48 -144 160 48 -144 minecraft:air
fill 156 48 -145 160 48 -145 minecraft:air
fill 156 48 -146 160 48 -146 minecraft:air
fill 156 48 -147 159 48 -147 minecraft:air
fill 156 48 -148 159 48 -148 minecraft:air
fill 156 48 -149 159 48 -149 minecraft:air
fill 157 48 -150 159 48 -150 minecraft:air
fill 157 48 -151 159 48 -151 minecraft:air
fill 188 48 -166 189 48 -166 minecraft:air
fill 187 48 -167 191 48 -167 minecraft:air
fill 186 48 -168 193 48 -168 minecraft:air
fill 187 48 -169 195 48 -169 minecraft:air
fill 188 48 -170 196 48 -170 minecraft:air
fill 188 48 -171 197 48 -171 minecraft:air
fill 189 48 -172 198 48 -172 minecraft:air
fill 190 48 -173 199 48 -173 minecraft:air
fill 192 48 -174 199 48 -174 minecraft:air
fill 193 48 -175 199 48 -175 minecraft:air
fill 172 48 -176 176 48 -176 minecraft:air
fill 194 48 -176 199 48 -176 minecraft:air
fill 171 48 -177 176 48 -177 minecraft:air
fill 194 48 -177 199 48 -177 minecraft:air
fill 170 48 -178 175 48 -178 minecraft:air
fill 194 48 -178 199 48 -178 minecraft:air
fill 170 48 -179 174 48 -179 minecraft:air
fill 194 48 -179 199 48 -179 minecraft:air
fill 169 48 -180 174 48 -180 minecraft:air
fill 194 48 -180 199 48 -180 minecraft:air
fill 168 48 -181 174 48 -181 minecraft:air
fill 194 48 -181 199 48 -181 minecraft:air
fill 168 48 -182 171 48 -182 minecraft:air
fill 193 48 -182 199 48 -182 minecraft:air
fill 167 48 -183 170 48 -183 minecraft:air
fill 192 48 -183 199 48 -183 minecraft:air
fill 167 48 -184 170 48 -184 minecraft:air
fill 192 48 -184 198 48 -184 minecraft:air
fill 167 48 -185 169 48 -185 minecraft:air
fill 192 48 -185 199 48 -185 minecraft:air
setblock 139 48 -186 oritech:still_oil_block[level=0]
fill 167 48 -186 169 48 -186 minecraft:air
fill 193 48 -186 199 48 -186 minecraft:air
fill 139 48 -187 140 48 -187 oritech:still_oil_block[level=0]
fill 167 48 -187 168 48 -187 minecraft:air
fill 193 48 -187 199 48 -187 minecraft:air
fill 136 48 -188 140 48 -188 oritech:still_oil_block[level=0]
setblock 142 48 -188 oritech:still_oil_block[level=0]
fill 167 48 -188 168 48 -188 minecraft:air
fill 194 48 -188 199 48 -188 minecraft:air
fill 136 48 -189 142 48 -189 oritech:still_oil_block[level=0]
fill 167 48 -189 168 48 -189 minecraft:air
setblock 176 48 -189 minecraft:water[level=0]
fill 194 48 -189 199 48 -189 minecraft:air
fill 136 48 -190 143 48 -190 oritech:still_oil_block[level=0]
setblock 168 48 -190 minecraft:air
fill 176 48 -190 178 48 -190 minecraft:water[level=0]
fill 195 48 -190 199 48 -190 minecraft:air
fill 147 47 -127 160 47 -127 minecraft:air
fill 191 47 -127 195 47 -127 minecraft:water[level=0]
fill 150 47 -128 156 47 -128 minecraft:air
setblock 158 47 -128 minecraft:air
fill 193 47 -128 195 47 -128 minecraft:water[level=0]
fill 140 47 -129 141 47 -129 minecraft:air
setblock 198 47 -129 minecraft:air
fill 139 47 -130 142 47 -130 minecraft:air
fill 139 47 -131 142 47 -131 minecraft:air
fill 140 47 -132 141 47 -132 minecraft:air
setblock 136 47 -135 minecraft:air
setblock 136 47 -136 minecraft:air
fill 158 47 -139 159 47 -139 minecraft:air
fill 157 47 -140 160 47 -140 minecraft:air
fill 157 47 -141 160 47 -141 minecraft:air
fill 157 47 -142 160 47 -142 minecraft:air
fill 157 47 -143 160 47 -143 minecraft:air
fill 156 47 -144 160 47 -144 minecraft:air
fill 156 47 -145 160 47 -145 minecraft:air
fill 156 47 -146 160 47 -146 minecraft:air
fill 150 47 -147 151 47 -147 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 156 47 -147 160 47 -147 minecraft:air
fill 150 47 -148 151 47 -148 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 156 47 -148 160 47 -148 minecraft:air
fill 156 47 -149 160 47 -149 minecraft:air
fill 156 47 -150 160 47 -150 minecraft:air
fill 156 47 -151 160 47 -151 minecraft:air
fill 157 47 -152 161 47 -152 minecraft:air
fill 158 47 -153 161 47 -153 minecraft:air
setblock 160 47 -154 minecraft:air
fill 187 47 -166 191 47 -166 minecraft:air
fill 186 47 -167 192 47 -167 minecraft:air
fill 186 47 -168 193 47 -168 minecraft:air
fill 187 47 -169 195 47 -169 minecraft:air
fill 188 47 -170 196 47 -170 minecraft:air
fill 188 47 -171 197 47 -171 minecraft:air
fill 188 47 -172 199 47 -172 minecraft:air
fill 190 47 -173 199 47 -173 minecraft:air
fill 191 47 -174 199 47 -174 minecraft:air
fill 172 47 -175 177 47 -175 minecraft:air
fill 192 47 -175 199 47 -175 minecraft:air
fill 171 47 -176 176 47 -176 minecraft:air
fill 194 47 -176 199 47 -176 minecraft:air
fill 171 47 -177 176 47 -177 minecraft:air
fill 194 47 -177 199 47 -177 minecraft:air
fill 170 47 -178 175 47 -178 minecraft:air
fill 193 47 -178 199 47 -178 minecraft:air
fill 169 47 -179 175 47 -179 minecraft:air
fill 193 47 -179 199 47 -179 minecraft:air
setblock 169 47 -180 minecraft:glow_lichen[down=false,east=false,north=false,south=false,up=false,waterlogged=false,west=true]
fill 170 47 -180 171 47 -180 minecraft:air
fill 193 47 -180 199 47 -180 minecraft:air
fill 168 47 -181 170 47 -181 minecraft:air
fill 193 47 -181 199 47 -181 minecraft:air
fill 168 47 -182 169 47 -182 minecraft:air
fill 193 47 -182 199 47 -182 minecraft:air
setblock 168 47 -183 minecraft:air
fill 192 47 -183 199 47 -183 minecraft:air
setblock 167 47 -184 minecraft:air
fill 192 47 -184 198 47 -184 minecraft:air
setblock 136 47 -185 oritech:still_oil_block[level=0]
fill 192 47 -185 199 47 -185 minecraft:air
fill 136 47 -186 141 47 -186 oritech:still_oil_block[level=0]
fill 193 47 -186 199 47 -186 minecraft:air
fill 136 47 -187 140 47 -187 oritech:still_oil_block[level=0]
setblock 142 47 -187 oritech:still_oil_block[level=0]
fill 193 47 -187 199 47 -187 minecraft:air
fill 136 47 -188 142 47 -188 oritech:still_oil_block[level=0]
setblock 144 47 -188 oritech:still_oil_block[level=0]
fill 193 47 -188 199 47 -188 minecraft:air
fill 136 47 -189 144 47 -189 oritech:still_oil_block[level=0]
fill 194 47 -189 199 47 -189 minecraft:air
fill 136 47 -190 144 47 -190 oritech:still_oil_block[level=0]
fill 179 47 -190 181 47 -190 minecraft:water[level=0]
fill 194 47 -190 199 47 -190 minecraft:air
fill 143 46 -127 160 46 -127 minecraft:air
fill 139 46 -128 146 46 -128 minecraft:air
fill 148 46 -128 156 46 -128 minecraft:air
setblock 158 46 -128 minecraft:air
setblock 199 46 -128 minecraft:air
fill 138 46 -129 145 46 -129 minecraft:air
setblock 199 46 -129 minecraft:air
fill 138 46 -130 143 46 -130 minecraft:air
fill 138 46 -131 143 46 -131 minecraft:air
fill 138 46 -132 143 46 -132 minecraft:air
fill 137 46 -133 142 46 -133 minecraft:air
fill 136 46 -134 140 46 -134 minecraft:air
fill 136 46 -135 139 46 -135 minecraft:air
fill 136 46 -136 138 46 -136 minecraft:air
fill 136 46 -137 137 46 -137 minecraft:air
fill 157 46 -144 159 46 -144 minecraft:air
fill 156 46 -145 160 46 -145 minecraft:air
fill 156 46 -146 160 46 -146 minecraft:air
fill 150 46 -147 151 46 -147 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 156 46 -147 160 46 -147 minecraft:air
fill 150 46 -148 151 46 -148 xycraft_world:xychorium_ore_stone_light[allow_spawns=false]
fill 156 46 -148 159 46 -148 minecraft:air
fill 156 46 -149 160 46 -149 minecraft:air
fill 156 46 -150 160 46 -150 minecraft:air
fill 156 46 -151 161 46 -151 minecraft:air
fill 157 46 -152 162 46 -152 minecraft:air
fill 157 46 -153 162 46 -153 minecraft:air
fill 158 46 -154 162 46 -154 minecraft:air
fill 160 46 -155 162 46 -155 minecraft:air
fill 170 46 -155 171 46 -155 minecraft:air
fill 160 46 -156 162 46 -156 minecraft:air
fill 170 46 -156 171 46 -156 minecraft:air
fill 169 46 -157 171 46 -157 minecraft:air
fill 169 46 -158 171 46 -158 minecraft:air
fill 168 46 -159 171 46 -159 minecraft:air
fill 166 46 -160 171 46 -160 minecraft:air
fill 165 46 -161 170 46 -161 minecraft:air
fill 165 46 -162 169 46 -162 minecraft:air
fill 165 46 -163 168 46 -163 minecraft:air
fill 188 46 -165 189 46 -165 minecraft:air
fill 186 46 -166 192 46 -166 minecraft:air
fill 186 46 -167 192 46 -167 minecraft:air
fill 186 46 -168 193 46 -168 minecraft:air
fill 186 46 -169 195 46 -169 minecraft:air
fill 187 46 -170 196 46 -170 minecraft:air
fill 188 46 -171 197 46 -171 minecraft:air
fill 188 46 -172 199 46 -172 minecraft:air
fill 189 46 -173 199 46 -173 minecraft:air
fill 173 46 -174 177 46 -174 minecraft:air
fill 190 46 -174 199 46 -174 minecraft:air
fill 172 46 -175 177 46 -175 minecraft:air
fill 192 46 -175 199 46 -175 minecraft:air
fill 171 46 -176 176 46 -176 minecraft:air
fill 193 46 -176 199 46 -176 minecraft:air
fill 170 46 -177 176 46 -177 minecraft:air
fill 193 46 -177 199 46 -177 minecraft:air
fill 167 46 -178 171 46 -178 minecraft:air
fill 193 46 -178 199 46 -178 minecraft:air
fill 167 46 -179 170 46 -179 minecraft:air
fill 193 46 -179 199 46 -179 minecraft:air
fill 193 46 -180 199 46 -180 minecraft:air
fill 193 46 -181 199 46 -181 minecraft:air
fill 193 46 -182 199 46 -182 minecraft:air
fill 192 46 -183 199 46 -183 minecraft:air
fill 192 46 -184 197 46 -184 minecraft:air
fill 136 46 -185 142 46 -185 oritech:still_oil_block[level=0]
fill 192 46 -185 199 46 -185 minecraft:air
fill 136 46 -186 141 46 -186 oritech:still_oil_block[level=0]
fill 193 46 -186 199 46 -186 minecraft:air
fill 136 46 -187 143 46 -187 oritech:still_oil_block[level=0]
fill 193 46 -187 199 46 -187 minecraft:air
fill 136 46 -188 144 46 -188 oritech:still_oil_block[level=0]
fill 193 46 -188 199 46 -188 minecraft:air
fill 136 46 -189 145 46 -189 oritech:still_oil_block[level=0]
fill 194 46 -189 199 46 -189 minecraft:air
fill 136 46 -190 146 46 -190 oritech:still_oil_block[level=0]
fill 181 46 -190 186 46 -190 minecraft:water[level=0]
fill 194 46 -190 199 46 -190 minecraft:air
fill 138 45 -127 150 45 -127 minecraft:air
fill 196 45 -127 199 45 -127 minecraft:air
fill 137 45 -128 146 45 -128 minecraft:air
fill 148 45 -128 149 45 -128 minecraft:air
fill 198 45 -128 199 45 -128 minecraft:air
fill 137 45 -129 145 45 -129 minecraft:air
fill 137 45 -130 144 45 -130 minecraft:air
fill 137 45 -131 144 45 -131 minecraft:air
fill 138 45 -132 144 45 -132 minecraft:air
fill 137 45 -133 143 45 -133 minecraft:air
fill 136 45 -134 141 45 -134 minecraft:air
fill 136 45 -135 140 45 -135 minecraft:air
fill 136 45 -136 139 45 -136 minecraft:air
fill 136 45 -137 138 45 -137 minecraft:air
setblock 136 45 -138 minecraft:air
fill 157 45 -150 160 45 -150 minecraft:air
setblock 172 45 -150 minecraft:air
fill 157 45 -151 161 45 -151 minecraft:air
fill 172 45 -151 173 45 -151 minecraft:air
fill 157 45 -152 162 45 -152 minecraft:air
fill 171 45 -152 173 45 -152 minecraft:air
fill 158 45 -153 162 45 -153 minecraft:air
fill 170 45 -153 173 45 -153 minecraft:air
fill 158 45 -154 163 45 -154 minecraft:air
fill 169 45 -154 173 45 -154 minecraft:air
fill 159 45 -155 163 45 -155 minecraft:air
fill 169 45 -155 173 45 -155 minecraft:air
fill 159 45 -156 163 45 -156 minecraft:air
fill 169 45 -156 173 45 -156 minecraft:air
fill 160 45 -157 164 45 -157 minecraft:air
fill 168 45 -157 173 45 -157 minecraft:air
fill 161 45 -158 164 45 -158 minecraft:air
fill 168 45 -158 173 45 -158 minecraft:air
fill 162 45 -159 164 45 -159 minecraft:air
fill 166 45 -159 172 45 -159 minecraft:air
fill 163 45 -160 172 45 -160 minecraft:air
fill 163 45 -161 172 45 -161 minecraft:air
fill 163 45 -162 171 45 -162 minecraft:air
fill 163 45 -163 170 45 -163 minecraft:air
fill 164 45 -164 168 45 -164 minecraft:air
setblock 164 45 -165 minecraft:air
fill 186 45 -165 192 45 -165 minecraft:air
setblock 164 45 -166 minecraft:air
fill 185 45 -166 192 45 -166 minecraft:air
setblock 164 45 -167 minecraft:air
fill 185 45 -167 193 45 -167 minecraft:air
fill 185 45 -168 193 45 -168 minecraft:air
fill 186 45 -169 195 45 -169 minecraft:air
fill 187 45 -170 196 45 -170 minecraft:air
fill 187 45 -171 197 45 -171 minecraft:air
fill 174 45 -172 177 45 -172 minecraft:air
fill 187 45 -172 199 45 -172 minecraft:air
fill 173 45 -173 178 45 -173 minecraft:air
fill 188 45 -173 199 45 -173 minecraft:air
fill 172 45 -174 177 45 -174 minecraft:air
fill 189 45 -174 199 45 -174 minecraft:air
fill 171 45 -175 177 45 -175 minecraft:air
fill 191 45 -175 199 45 -175 minecraft:air
setblock 171 45 -176 minecraft:air
fill 192 45 -176 199 45 -176 minecraft:air
fill 168 45 -177 171 45 -177 minecraft:air
fill 192 45 -177 199 45 -177 minecraft:air
fill 167 45 -178 173 45 -178 minecraft:air
fill 187 45 -178 188 45 -178 minecraft:air
fill 192 45 -178 199 45 -178 minecraft:air
fill 167 45 -179 172 45 -179 minecraft:air
fill 187 45 -179 189 45 -179 minecraft:air
fill 192 45 -179 199 45 -179 minecraft:air
fill 168 45 -180 170 45 -180 minecraft:air
fill 187 45 -180 189 45 -180 minecraft:air
fill 192 45 -180 199 45 -180 minecraft:air
fill 186 45 -181 188 45 -181 minecraft:air
fill 192 45 -181 199 45 -181 minecraft:air
fill 186 45 -182 188 45 -182 minecraft:air
fill 192 45 -182 199 45 -182 minecraft:air
fill 186 45 -183 187 45 -183 minecraft:air
fill 192 45 -183 199 45 -183 minecraft:air
fill 137 45 -184 141 45 -184 oritech:still_oil_block[level=0]
fill 192 45 -184 197 45 -184 minecraft:air
fill 136 45 -185 142 45 -185 oritech:still_oil_block[level=0]
fill 192 45 -185 199 45 -185 minecraft:air
fill 136 45 -186 144 45 -186 oritech:still_oil_block[level=0]
fill 193 45 -186 199 45 -186 minecraft:air
fill 136 45 -187 144 45 -187 oritech:still_oil_block[level=0]
fill 193 45 -187 199 45 -187 minecraft:air
fill 136 45 -188 146 45 -188 oritech:still_oil_block[level=0]
fill 193 45 -188 199 45 -188 minecraft:air
fill 136 45 -189 146 45 -189 oritech:still_oil_block[level=0]
fill 193 45 -189 199 45 -189 minecraft:air
fill 136 45 -190 146 45 -190 oritech:still_oil_block[level=0]
fill 194 45 -190 199 45 -190 minecraft:air
forceload remove 136 -190 199 -127
tellraw @a {"text":"Campus zurueck a31 fertig.","color":"green"}
