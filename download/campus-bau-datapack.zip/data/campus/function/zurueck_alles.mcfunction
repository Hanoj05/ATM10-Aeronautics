function campus:zurueck_alles/01
