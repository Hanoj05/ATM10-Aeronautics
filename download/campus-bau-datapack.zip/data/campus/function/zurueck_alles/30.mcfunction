function campus:zurueck/a13
schedule function campus:zurueck_alles/31 20s
