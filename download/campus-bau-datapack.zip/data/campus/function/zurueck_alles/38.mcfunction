function campus:zurueck/a05
schedule function campus:zurueck_alles/39 20s
