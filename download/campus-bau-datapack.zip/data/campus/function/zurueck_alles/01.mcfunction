function campus:zurueck/a42
schedule function campus:zurueck_alles/02 20s
