function campus:zurueck/a21
schedule function campus:zurueck_alles/23 20s
