function campus:zurueck/a08
schedule function campus:zurueck_alles/36 20s
