function campus:zurueck/a19
schedule function campus:zurueck_alles/25 20s
