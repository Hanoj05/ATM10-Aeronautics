function campus:zurueck/a12
schedule function campus:zurueck_alles/32 20s
