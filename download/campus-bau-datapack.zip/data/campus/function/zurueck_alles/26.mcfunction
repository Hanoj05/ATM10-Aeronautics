function campus:zurueck/a17
schedule function campus:zurueck_alles/27 20s
