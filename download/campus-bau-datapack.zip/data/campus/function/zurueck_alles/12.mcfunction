function campus:zurueck/a31
schedule function campus:zurueck_alles/13 20s
