function campus:zurueck/a27
schedule function campus:zurueck_alles/17 20s
