function campus:zurueck/a29
schedule function campus:zurueck_alles/15 20s
