function campus:zurueck/a07
schedule function campus:zurueck_alles/37 20s
