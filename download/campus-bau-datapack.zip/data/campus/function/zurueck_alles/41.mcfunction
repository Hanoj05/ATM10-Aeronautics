function campus:zurueck/a02
schedule function campus:zurueck_alles/42 20s
