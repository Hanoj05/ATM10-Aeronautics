function campus:zurueck/a24
schedule function campus:zurueck_alles/20 20s
