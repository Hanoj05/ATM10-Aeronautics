function campus:zurueck/a41
schedule function campus:zurueck_alles/03 20s
