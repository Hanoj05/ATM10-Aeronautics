function campus:zurueck/a23
schedule function campus:zurueck_alles/21 20s
