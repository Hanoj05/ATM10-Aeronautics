function campus:zurueck/a18
schedule function campus:zurueck_alles/26 20s
