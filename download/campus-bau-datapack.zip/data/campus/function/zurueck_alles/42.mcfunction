function campus:zurueck/a01
tellraw @a {"text":"Campus: alle Abschnitte fertig (zurueck).","color":"green"}
