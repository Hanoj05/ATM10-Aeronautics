function campus:zurueck/a11
schedule function campus:zurueck_alles/33 20s
