function campus:zurueck/a26
schedule function campus:zurueck_alles/18 20s
