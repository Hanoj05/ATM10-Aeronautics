function campus:zurueck/a40
schedule function campus:zurueck_alles/04 20s
