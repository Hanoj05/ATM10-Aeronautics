function campus:zurueck/a38
schedule function campus:zurueck_alles/06 20s
