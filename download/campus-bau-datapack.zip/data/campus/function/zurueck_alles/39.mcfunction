function campus:zurueck/a04
schedule function campus:zurueck_alles/40 20s
