function campus:zurueck/a25
schedule function campus:zurueck_alles/19 20s
