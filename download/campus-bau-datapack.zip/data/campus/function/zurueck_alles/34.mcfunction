function campus:zurueck/a09
schedule function campus:zurueck_alles/35 20s
