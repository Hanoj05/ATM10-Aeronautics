function campus:zurueck/a22
schedule function campus:zurueck_alles/22 20s
