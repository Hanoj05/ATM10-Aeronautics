function campus:zurueck/a32
schedule function campus:zurueck_alles/12 20s
