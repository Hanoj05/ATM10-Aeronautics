function campus:zurueck/a30
schedule function campus:zurueck_alles/14 20s
