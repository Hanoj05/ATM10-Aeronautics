function campus:zurueck/a39
schedule function campus:zurueck_alles/05 20s
