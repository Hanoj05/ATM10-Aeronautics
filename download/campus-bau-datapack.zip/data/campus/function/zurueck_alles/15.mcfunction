function campus:zurueck/a28
schedule function campus:zurueck_alles/16 20s
