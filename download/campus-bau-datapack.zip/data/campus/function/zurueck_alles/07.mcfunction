function campus:zurueck/a36
schedule function campus:zurueck_alles/08 20s
