function campus:zurueck/a10
schedule function campus:zurueck_alles/34 20s
