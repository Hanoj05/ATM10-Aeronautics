function campus:zurueck/a03
schedule function campus:zurueck_alles/41 20s
