function campus:zurueck/a06
schedule function campus:zurueck_alles/38 20s
