function campus:zurueck/a20
schedule function campus:zurueck_alles/24 20s
