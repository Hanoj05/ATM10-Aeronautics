function campus:zurueck/a34
schedule function campus:zurueck_alles/10 20s
