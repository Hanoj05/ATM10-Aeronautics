function campus:bau/a22
schedule function campus:bau_alles/23 20s
