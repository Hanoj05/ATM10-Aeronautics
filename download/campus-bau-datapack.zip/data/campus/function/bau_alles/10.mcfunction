function campus:bau/a10
schedule function campus:bau_alles/11 20s
