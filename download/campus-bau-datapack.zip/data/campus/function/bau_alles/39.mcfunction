function campus:bau/a39
schedule function campus:bau_alles/40 20s
