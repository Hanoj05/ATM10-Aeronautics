function campus:bau/a31
schedule function campus:bau_alles/32 20s
