function campus:bau/a42
tellraw @a {"text":"Campus: alle Abschnitte fertig (bau).","color":"green"}
