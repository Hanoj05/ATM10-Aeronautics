function campus:bau/a34
schedule function campus:bau_alles/35 20s
