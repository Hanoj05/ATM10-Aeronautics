function campus:bau/a17
schedule function campus:bau_alles/18 20s
