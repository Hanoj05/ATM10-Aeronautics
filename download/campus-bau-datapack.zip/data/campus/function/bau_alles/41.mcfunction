function campus:bau/a41
schedule function campus:bau_alles/42 20s
