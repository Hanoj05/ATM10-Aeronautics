function campus:bau/a11
schedule function campus:bau_alles/12 20s
