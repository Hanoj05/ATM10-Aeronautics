function campus:bau/a38
schedule function campus:bau_alles/39 20s
