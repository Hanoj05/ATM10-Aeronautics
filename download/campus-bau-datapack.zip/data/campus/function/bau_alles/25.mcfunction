function campus:bau/a25
schedule function campus:bau_alles/26 20s
