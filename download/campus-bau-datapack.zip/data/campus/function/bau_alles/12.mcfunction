function campus:bau/a12
schedule function campus:bau_alles/13 20s
