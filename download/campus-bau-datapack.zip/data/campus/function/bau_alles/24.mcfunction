function campus:bau/a24
schedule function campus:bau_alles/25 20s
