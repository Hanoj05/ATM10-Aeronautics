function campus:bau/a30
schedule function campus:bau_alles/31 20s
