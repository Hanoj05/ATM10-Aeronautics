function campus:bau/a08
schedule function campus:bau_alles/09 20s
