function campus:bau/a14
schedule function campus:bau_alles/15 20s
