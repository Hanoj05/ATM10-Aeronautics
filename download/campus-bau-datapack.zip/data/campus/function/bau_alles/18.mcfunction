function campus:bau/a18
schedule function campus:bau_alles/19 20s
