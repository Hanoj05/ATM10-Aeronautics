function campus:bau/a04
schedule function campus:bau_alles/05 20s
