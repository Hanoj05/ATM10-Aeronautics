function campus:bau/a21
schedule function campus:bau_alles/22 20s
