function campus:bau/a01
schedule function campus:bau_alles/02 20s
