function campus:bau/a26
schedule function campus:bau_alles/27 20s
