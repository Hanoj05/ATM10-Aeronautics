function campus:bau/a32
schedule function campus:bau_alles/33 20s
