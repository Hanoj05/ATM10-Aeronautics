function campus:bau/a35
schedule function campus:bau_alles/36 20s
