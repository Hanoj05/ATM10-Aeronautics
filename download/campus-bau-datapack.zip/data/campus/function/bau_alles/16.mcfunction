function campus:bau/a16
schedule function campus:bau_alles/17 20s
