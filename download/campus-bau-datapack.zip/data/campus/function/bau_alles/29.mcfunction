function campus:bau/a29
schedule function campus:bau_alles/30 20s
