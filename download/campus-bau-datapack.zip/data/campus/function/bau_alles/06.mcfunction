function campus:bau/a06
schedule function campus:bau_alles/07 20s
