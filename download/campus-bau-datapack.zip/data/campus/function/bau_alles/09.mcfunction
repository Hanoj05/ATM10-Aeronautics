function campus:bau/a09
schedule function campus:bau_alles/10 20s
