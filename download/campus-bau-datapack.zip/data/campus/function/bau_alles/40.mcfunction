function campus:bau/a40
schedule function campus:bau_alles/41 20s
