function campus:bau/a36
schedule function campus:bau_alles/37 20s
