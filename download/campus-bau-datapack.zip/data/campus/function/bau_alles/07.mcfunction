function campus:bau/a07
schedule function campus:bau_alles/08 20s
