function campus:bau/a27
schedule function campus:bau_alles/28 20s
