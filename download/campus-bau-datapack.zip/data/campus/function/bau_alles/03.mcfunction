function campus:bau/a03
schedule function campus:bau_alles/04 20s
