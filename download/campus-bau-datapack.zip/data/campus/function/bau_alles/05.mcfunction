function campus:bau/a05
schedule function campus:bau_alles/06 20s
