function campus:bau/a19
schedule function campus:bau_alles/20 20s
