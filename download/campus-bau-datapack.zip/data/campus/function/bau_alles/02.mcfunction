function campus:bau/a02
schedule function campus:bau_alles/03 20s
