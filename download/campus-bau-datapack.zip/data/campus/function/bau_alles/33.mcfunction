function campus:bau/a33
schedule function campus:bau_alles/34 20s
