function campus:bau/a20
schedule function campus:bau_alles/21 20s
