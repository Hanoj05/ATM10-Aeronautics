function campus:bau/a15
schedule function campus:bau_alles/16 20s
