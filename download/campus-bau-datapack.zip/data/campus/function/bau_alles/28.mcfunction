function campus:bau/a28
schedule function campus:bau_alles/29 20s
