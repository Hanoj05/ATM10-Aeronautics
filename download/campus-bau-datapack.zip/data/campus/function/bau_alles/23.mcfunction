function campus:bau/a23
schedule function campus:bau_alles/24 20s
