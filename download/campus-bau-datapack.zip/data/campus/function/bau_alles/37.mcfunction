function campus:bau/a37
schedule function campus:bau_alles/38 20s
