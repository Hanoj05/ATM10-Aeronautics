fill 179 45 -354 180 45 -354 minecraft:stone
fill 179 45 -353 180 45 -353 minecraft:stone
fill 179 45 -352 180 45 -352 minecraft:stone
fill 164 45 -338 165 45 -338 minecraft:stone
setblock 164 45 -337 minecraft:stone
setblock 171 45 -325 minecraft:stone
fill 169 45 -324 172 45 -324 minecraft:stone
setblock 151 45 -323 minecraft:stone
fill 170 45 -323 172 45 -323 minecraft:stone
fill 170 45 -322 172 45 -322 minecraft:stone
fill 179 46 -353 180 46 -353 minecraft:stone
fill 179 46 -352 180 46 -352 minecraft:stone
setblock 164 46 -338 minecraft:stone
setblock 165 46 -337 minecraft:stone
fill 168 46 -324 170 46 -324 minecraft:stone
setblock 151 46 -323 minecraft:stone
fill 169 46 -323 171 46 -323 minecraft:stone
fill 169 46 -322 171 46 -322 minecraft:stone
fill 179 47 -352 180 47 -352 minecraft:stone
fill 179 47 -351 180 47 -351 minecraft:stone
fill 136 47 -341 137 47 -341 minecraft:stone
fill 136 47 -340 139 47 -340 minecraft:stone
fill 136 47 -339 139 47 -339 minecraft:stone
fill 136 47 -338 139 47 -338 minecraft:stone
fill 136 47 -337 140 47 -337 minecraft:stone
fill 136 47 -336 140 47 -336 minecraft:stone
fill 136 47 -335 140 47 -335 minecraft:stone
fill 136 47 -334 139 47 -334 minecraft:stone
fill 136 47 -333 138 47 -333 minecraft:stone
fill 136 47 -332 138 47 -332 minecraft:stone
fill 136 47 -331 137 47 -331 minecraft:stone
setblock 136 47 -330 minecraft:stone
fill 167 47 -324 169 47 -324 minecraft:stone
setblock 151 47 -323 minecraft:stone
fill 167 47 -323 170 47 -323 minecraft:stone
fill 168 47 -322 170 47 -322 minecraft:stone
setblock 168 47 -321 minecraft:stone
fill 178 48 -352 179 48 -352 minecraft:stone
setblock 179 48 -351 minecraft:stone
fill 179 48 -350 180 48 -350 minecraft:stone
fill 136 48 -343 138 48 -343 minecraft:stone
fill 136 48 -342 140 48 -342 minecraft:stone
fill 136 48 -341 141 48 -341 minecraft:stone
fill 136 48 -340 142 48 -340 minecraft:stone
fill 136 48 -339 142 48 -339 minecraft:stone
fill 136 48 -338 143 48 -338 minecraft:stone
fill 136 48 -337 143 48 -337 minecraft:stone
fill 136 48 -336 144 48 -336 minecraft:stone
fill 136 48 -335 143 48 -335 minecraft:stone
fill 136 48 -334 142 48 -334 minecraft:stone
fill 136 48 -333 142 48 -333 minecraft:stone
fill 136 48 -332 141 48 -332 minecraft:stone
fill 136 48 -331 141 48 -331 minecraft:stone
fill 136 48 -330 140 48 -330 minecraft:stone
fill 136 48 -329 139 48 -329 minecraft:stone
fill 136 48 -328 137 48 -328 minecraft:stone
setblock 136 48 -327 minecraft:stone
fill 166 48 -324 168 48 -324 minecraft:stone
setblock 151 48 -323 minecraft:stone
fill 166 48 -323 168 48 -323 minecraft:stone
fill 167 48 -322 169 48 -322 minecraft:stone
fill 179 49 -351 180 49 -351 minecraft:stone
fill 179 49 -350 180 49 -350 minecraft:stone
setblock 151 49 -323 minecraft:stone
setblock 168 49 -322 minecraft:stone
fill 179 50 -351 180 50 -351 minecraft:stone
fill 179 50 -350 180 50 -350 minecraft:stone
fill 179 50 -349 180 50 -349 minecraft:stone
fill 162 50 -324 164 50 -324 minecraft:stone
setblock 151 50 -323 minecraft:stone
fill 162 50 -323 164 50 -323 minecraft:stone
fill 163 50 -322 165 50 -322 minecraft:stone
fill 179 51 -350 180 51 -350 minecraft:stone
fill 179 51 -349 180 51 -349 minecraft:stone
fill 160 51 -324 164 51 -324 minecraft:stone
setblock 151 51 -323 minecraft:stone
fill 160 51 -323 165 51 -323 minecraft:stone
setblock 180 52 -349 minecraft:stone
setblock 180 52 -348 minecraft:stone
fill 159 52 -325 162 52 -325 minecraft:stone
fill 158 52 -324 162 52 -324 minecraft:stone
setblock 151 52 -323 minecraft:stone
fill 159 52 -323 163 52 -323 minecraft:stone
setblock 180 53 -349 minecraft:stone
fill 180 53 -348 181 53 -348 minecraft:stone
fill 157 53 -325 161 53 -325 minecraft:stone
fill 157 53 -324 161 53 -324 minecraft:stone
setblock 151 53 -323 minecraft:stone
setblock 180 54 -349 minecraft:stone
fill 180 54 -348 181 54 -348 minecraft:stone
setblock 181 54 -347 minecraft:stone
fill 155 54 -325 159 54 -325 minecraft:stone
fill 155 54 -324 159 54 -324 minecraft:stone
setblock 151 54 -323 minecraft:stone
fill 136 55 -382 148 55 -382 minecraft:stone
fill 136 55 -381 148 55 -381 minecraft:stone
fill 136 55 -380 146 55 -380 minecraft:stone
fill 136 55 -379 144 55 -379 minecraft:stone
fill 137 55 -378 142 55 -378 minecraft:stone
fill 180 55 -348 181 55 -348 minecraft:stone
fill 180 55 -347 181 55 -347 minecraft:stone
fill 154 55 -326 158 55 -326 minecraft:stone
fill 154 55 -325 158 55 -325 minecraft:stone
setblock 151 55 -323 minecraft:stone
fill 136 56 -382 155 56 -382 minecraft:stone
fill 136 56 -381 155 56 -381 minecraft:stone
fill 136 56 -380 154 56 -380 minecraft:stone
fill 136 56 -379 154 56 -379 minecraft:stone
fill 136 56 -378 154 56 -378 minecraft:stone
fill 136 56 -377 153 56 -377 minecraft:stone
fill 136 56 -376 153 56 -376 minecraft:stone
fill 136 56 -375 152 56 -375 minecraft:stone
fill 136 56 -374 149 56 -374 minecraft:stone
fill 139 56 -373 142 56 -373 minecraft:stone
fill 180 56 -348 181 56 -348 minecraft:stone
fill 180 56 -347 181 56 -347 minecraft:stone
fill 153 56 -326 157 56 -326 minecraft:stone
fill 152 56 -325 156 56 -325 minecraft:stone
setblock 151 56 -323 minecraft:stone
fill 136 57 -382 157 57 -382 minecraft:stone
fill 136 57 -381 157 57 -381 minecraft:stone
fill 136 57 -380 156 57 -380 minecraft:stone
fill 136 57 -379 156 57 -379 minecraft:stone
fill 136 57 -378 155 57 -378 minecraft:stone
fill 136 57 -377 155 57 -377 minecraft:stone
fill 136 57 -376 155 57 -376 minecraft:stone
fill 136 57 -375 154 57 -375 minecraft:stone
fill 136 57 -374 153 57 -374 minecraft:stone
fill 136 57 -373 153 57 -373 minecraft:stone
fill 136 57 -372 152 57 -372 minecraft:stone
fill 139 57 -371 144 57 -371 minecraft:stone
setblock 181 57 -347 minecraft:stone
setblock 182 57 -346 minecraft:stone
fill 153 57 -326 157 57 -326 minecraft:stone
fill 152 57 -325 156 57 -325 minecraft:stone
setblock 151 57 -323 minecraft:stone
fill 136 58 -382 159 58 -382 minecraft:stone
fill 136 58 -381 159 58 -381 minecraft:stone
fill 136 58 -380 158 58 -380 minecraft:stone
fill 136 58 -379 158 58 -379 minecraft:stone
fill 136 58 -378 157 58 -378 minecraft:stone
fill 136 58 -377 157 58 -377 minecraft:stone
fill 136 58 -376 156 58 -376 minecraft:stone
fill 136 58 -375 156 58 -375 minecraft:stone
fill 136 58 -374 155 58 -374 minecraft:stone
fill 136 58 -373 155 58 -373 minecraft:stone
fill 136 58 -372 154 58 -372 minecraft:stone
fill 136 58 -371 152 58 -371 minecraft:stone
fill 136 58 -370 147 58 -370 minecraft:stone
fill 137 58 -369 145 58 -369 minecraft:stone
fill 139 58 -368 143 58 -368 minecraft:stone
fill 181 58 -347 182 58 -347 minecraft:stone
fill 181 58 -346 182 58 -346 minecraft:stone
fill 153 58 -326 156 58 -326 minecraft:stone
fill 152 58 -325 156 58 -325 minecraft:stone
setblock 151 58 -323 minecraft:stone
fill 136 59 -382 163 59 -382 minecraft:stone
fill 136 59 -381 162 59 -381 minecraft:stone
fill 136 59 -380 161 59 -380 minecraft:stone
fill 136 59 -379 160 59 -379 minecraft:stone
fill 136 59 -378 159 59 -378 minecraft:stone
fill 136 59 -377 158 59 -377 minecraft:stone
fill 136 59 -376 158 59 -376 minecraft:stone
fill 136 59 -375 157 59 -375 minecraft:stone
fill 136 59 -374 157 59 -374 minecraft:stone
fill 136 59 -373 156 59 -373 minecraft:stone
fill 136 59 -372 156 59 -372 minecraft:stone
fill 136 59 -371 154 59 -371 minecraft:stone
fill 136 59 -370 152 59 -370 minecraft:stone
fill 136 59 -369 149 59 -369 minecraft:stone
fill 136 59 -368 146 59 -368 minecraft:stone
fill 136 59 -367 145 59 -367 minecraft:stone
fill 138 59 -366 144 59 -366 minecraft:stone
fill 140 59 -365 144 59 -365 minecraft:stone
fill 181 59 -347 182 59 -347 minecraft:stone
fill 181 59 -346 182 59 -346 minecraft:stone
fill 153 59 -326 156 59 -326 minecraft:stone
fill 152 59 -325 156 59 -325 minecraft:stone
setblock 151 59 -323 minecraft:stone
fill 136 60 -382 171 60 -382 minecraft:stone
fill 136 60 -381 170 60 -381 minecraft:stone
fill 136 60 -380 169 60 -380 minecraft:stone
fill 136 60 -379 163 60 -379 minecraft:stone
fill 136 60 -378 161 60 -378 minecraft:stone
fill 136 60 -377 160 60 -377 minecraft:stone
fill 136 60 -376 160 60 -376 minecraft:stone
fill 136 60 -375 159 60 -375 minecraft:stone
fill 136 60 -374 158 60 -374 minecraft:stone
fill 136 60 -373 157 60 -373 minecraft:stone
fill 136 60 -372 157 60 -372 minecraft:stone
fill 136 60 -371 156 60 -371 minecraft:stone
fill 136 60 -370 154 60 -370 minecraft:stone
fill 136 60 -369 153 60 -369 minecraft:stone
fill 136 60 -368 151 60 -368 minecraft:stone
fill 136 60 -367 147 60 -367 minecraft:stone
fill 136 60 -366 146 60 -366 minecraft:stone
fill 136 60 -365 145 60 -365 minecraft:stone
fill 137 60 -364 144 60 -364 minecraft:stone
fill 139 60 -363 144 60 -363 minecraft:stone
setblock 182 60 -347 minecraft:stone
fill 182 60 -346 183 60 -346 minecraft:stone
fill 153 60 -326 156 60 -326 minecraft:stone
fill 152 60 -325 156 60 -325 minecraft:stone
setblock 151 60 -323 minecraft:stone
fill 136 61 -382 174 61 -382 minecraft:stone
fill 136 61 -381 173 61 -381 minecraft:stone
fill 136 61 -380 172 61 -380 minecraft:stone
fill 136 61 -379 171 61 -379 minecraft:stone
fill 136 61 -378 168 61 -378 minecraft:stone
fill 136 61 -377 163 61 -377 minecraft:stone
fill 136 61 -376 162 61 -376 minecraft:stone
fill 136 61 -375 161 61 -375 minecraft:stone
fill 136 61 -374 160 61 -374 minecraft:stone
fill 136 61 -373 159 61 -373 minecraft:stone
fill 136 61 -372 158 61 -372 minecraft:stone
fill 136 61 -371 157 61 -371 minecraft:stone
fill 136 61 -370 156 61 -370 minecraft:stone
fill 136 61 -369 155 61 -369 minecraft:stone
fill 136 61 -368 153 61 -368 minecraft:stone
fill 136 61 -367 151 61 -367 minecraft:stone
fill 136 61 -366 148 61 -366 minecraft:stone
fill 136 61 -365 146 61 -365 minecraft:stone
fill 136 61 -364 146 61 -364 minecraft:stone
fill 136 61 -363 145 61 -363 minecraft:stone
fill 137 61 -362 144 61 -362 minecraft:stone
fill 139 61 -361 144 61 -361 minecraft:stone
fill 182 61 -347 183 61 -347 minecraft:stone
fill 182 61 -346 183 61 -346 minecraft:stone
fill 153 61 -326 156 61 -326 minecraft:stone
fill 152 61 -325 156 61 -325 minecraft:stone
setblock 151 61 -323 minecraft:stone
fill 136 62 -382 177 62 -382 minecraft:dirt
fill 136 62 -381 176 62 -381 minecraft:dirt
fill 136 62 -380 174 62 -380 minecraft:dirt
fill 136 62 -379 172 62 -379 minecraft:dirt
setblock 174 62 -379 minecraft:dirt
fill 136 62 -378 169 62 -378 minecraft:dirt
fill 171 62 -378 173 62 -378 minecraft:dirt
fill 136 62 -377 172 62 -377 minecraft:dirt
fill 136 62 -376 162 62 -376 minecraft:dirt
setblock 164 62 -376 minecraft:dirt
fill 166 62 -376 167 62 -376 minecraft:dirt
fill 136 62 -375 163 62 -375 minecraft:dirt
fill 136 62 -374 162 62 -374 minecraft:dirt
fill 136 62 -373 161 62 -373 minecraft:dirt
fill 136 62 -372 160 62 -372 minecraft:dirt
fill 136 62 -371 157 62 -371 minecraft:dirt
setblock 159 62 -371 minecraft:dirt
fill 136 62 -370 159 62 -370 minecraft:dirt
fill 136 62 -369 155 62 -369 minecraft:dirt
setblock 157 62 -369 minecraft:dirt
fill 136 62 -368 156 62 -368 minecraft:dirt
fill 136 62 -367 152 62 -367 minecraft:dirt
fill 136 62 -366 151 62 -366 minecraft:dirt
fill 136 62 -365 149 62 -365 minecraft:dirt
fill 136 62 -364 147 62 -364 minecraft:dirt
fill 136 62 -363 146 62 -363 minecraft:dirt
fill 136 62 -362 146 62 -362 minecraft:dirt
fill 136 62 -361 145 62 -361 minecraft:dirt
fill 136 62 -360 144 62 -360 minecraft:dirt
fill 139 62 -359 141 62 -359 minecraft:dirt
fill 143 62 -359 144 62 -359 minecraft:dirt
fill 182 62 -346 183 62 -346 minecraft:dirt
fill 183 62 -345 184 62 -345 minecraft:dirt
fill 153 62 -326 156 62 -326 minecraft:dirt
fill 152 62 -325 155 62 -325 minecraft:dirt
setblock 151 62 -323 minecraft:dirt
fill 136 63 -382 178 63 -382 minecraft:dirt
fill 180 63 -382 183 63 -382 minecraft:dirt
fill 136 63 -381 182 63 -381 minecraft:dirt
fill 136 63 -380 174 63 -380 minecraft:dirt
fill 176 63 -380 181 63 -380 minecraft:dirt
fill 136 63 -379 172 63 -379 minecraft:dirt
fill 174 63 -379 175 63 -379 minecraft:dirt
fill 177 63 -379 179 63 -379 minecraft:dirt
fill 181 63 -379 182 63 -379 minecraft:dirt
fill 136 63 -378 169 63 -378 minecraft:dirt
fill 171 63 -378 176 63 -378 minecraft:dirt
setblock 178 63 -378 minecraft:dirt
fill 181 63 -378 182 63 -378 minecraft:dirt
fill 136 63 -377 173 63 -377 minecraft:dirt
fill 175 63 -377 177 63 -377 minecraft:dirt
fill 179 63 -377 182 63 -377 minecraft:dirt
fill 136 63 -376 162 63 -376 minecraft:dirt
setblock 164 63 -376 minecraft:dirt
fill 166 63 -376 178 63 -376 minecraft:dirt
fill 180 63 -376 182 63 -376 minecraft:dirt
fill 136 63 -375 173 63 -375 minecraft:dirt
fill 175 63 -375 176 63 -375 minecraft:dirt
setblock 178 63 -375 minecraft:dirt
setblock 180 63 -375 minecraft:dirt
fill 136 63 -374 174 63 -374 minecraft:dirt
fill 136 63 -373 169 63 -373 minecraft:dirt
fill 136 63 -372 163 63 -372 minecraft:dirt
fill 136 63 -371 157 63 -371 minecraft:dirt
fill 159 63 -371 163 63 -371 minecraft:dirt
fill 136 63 -370 162 63 -370 minecraft:dirt
fill 136 63 -369 155 63 -369 minecraft:dirt
fill 157 63 -369 161 63 -369 minecraft:dirt
fill 136 63 -368 161 63 -368 minecraft:dirt
fill 136 63 -367 152 63 -367 minecraft:dirt
fill 155 63 -367 158 63 -367 minecraft:dirt
fill 136 63 -366 152 63 -366 minecraft:dirt
fill 154 63 -366 155 63 -366 minecraft:dirt
fill 136 63 -365 151 63 -365 minecraft:dirt
setblock 153 63 -365 minecraft:dirt
fill 136 63 -364 147 63 -364 minecraft:dirt
fill 149 63 -364 150 63 -364 minecraft:dirt
fill 136 63 -363 149 63 -363 minecraft:dirt
fill 136 63 -362 148 63 -362 minecraft:dirt
fill 136 63 -361 147 63 -361 minecraft:dirt
fill 176 63 -361 178 63 -361 minecraft:dirt
fill 136 63 -360 146 63 -360 minecraft:dirt
fill 176 63 -360 179 63 -360 minecraft:dirt
fill 136 63 -359 141 63 -359 minecraft:dirt
fill 143 63 -359 145 63 -359 minecraft:dirt
fill 176 63 -359 179 63 -359 minecraft:dirt
fill 136 63 -358 144 63 -358 minecraft:dirt
setblock 176 63 -352 minecraft:dirt
setblock 176 63 -350 minecraft:dirt
setblock 176 63 -349 minecraft:dirt
setblock 176 63 -348 minecraft:dirt
setblock 176 63 -347 minecraft:dirt
setblock 176 63 -346 minecraft:dirt
fill 183 63 -346 184 63 -346 minecraft:dirt
setblock 176 63 -345 minecraft:dirt
fill 183 63 -345 184 63 -345 minecraft:dirt
setblock 186 63 -329 minecraft:dirt
fill 186 63 -328 187 63 -328 minecraft:dirt
setblock 187 63 -327 minecraft:dirt
fill 152 63 -326 156 63 -326 minecraft:dirt
setblock 187 63 -326 minecraft:dirt
fill 152 63 -325 155 63 -325 minecraft:dirt
setblock 151 63 -323 minecraft:dirt
fill 136 64 -382 178 64 -382 minecraft:dirt
fill 180 64 -382 191 64 -382 minecraft:dirt
fill 193 64 -382 199 64 -382 minecraft:dirt
fill 136 64 -381 191 64 -381 minecraft:dirt
fill 193 64 -381 199 64 -381 minecraft:dirt
fill 136 64 -380 181 64 -380 minecraft:dirt
fill 183 64 -380 193 64 -380 minecraft:dirt
fill 195 64 -380 199 64 -380 minecraft:dirt
fill 136 64 -379 175 64 -379 minecraft:dirt
fill 177 64 -379 179 64 -379 minecraft:dirt
fill 181 64 -379 199 64 -379 minecraft:dirt
fill 136 64 -378 176 64 -378 minecraft:dirt
setblock 178 64 -378 minecraft:dirt
fill 181 64 -378 197 64 -378 minecraft:dirt
fill 136 64 -377 173 64 -377 minecraft:dirt
fill 175 64 -377 177 64 -377 minecraft:dirt
fill 179 64 -377 195 64 -377 minecraft:dirt
fill 136 64 -376 178 64 -376 minecraft:dirt
fill 180 64 -376 187 64 -376 minecraft:dirt
fill 189 64 -376 194 64 -376 minecraft:dirt
fill 136 64 -375 173 64 -375 minecraft:dirt
fill 175 64 -375 176 64 -375 minecraft:dirt
setblock 178 64 -375 minecraft:dirt
fill 180 64 -375 185 64 -375 minecraft:dirt
fill 187 64 -375 193 64 -375 minecraft:dirt
fill 136 64 -374 192 64 -374 minecraft:dirt
fill 136 64 -373 191 64 -373 minecraft:dirt
fill 136 64 -372 191 64 -372 minecraft:dirt
fill 136 64 -371 190 64 -371 minecraft:dirt
fill 136 64 -370 174 64 -370 minecraft:dirt
fill 176 64 -370 186 64 -370 minecraft:dirt
fill 188 64 -370 189 64 -370 minecraft:dirt
fill 136 64 -369 173 64 -369 minecraft:dirt
fill 175 64 -369 180 64 -369 minecraft:dirt
fill 182 64 -369 188 64 -369 minecraft:dirt
fill 136 64 -368 172 64 -368 minecraft:dirt
fill 177 64 -368 187 64 -368 minecraft:dirt
fill 136 64 -367 170 64 -367 minecraft:dirt
fill 175 64 -367 188 64 -367 minecraft:dirt
fill 136 64 -366 152 64 -366 minecraft:dirt
fill 154 64 -366 169 64 -366 minecraft:dirt
fill 174 64 -366 182 64 -366 minecraft:dirt
fill 184 64 -366 185 64 -366 minecraft:dirt
fill 187 64 -366 188 64 -366 minecraft:dirt
fill 136 64 -365 151 64 -365 minecraft:dirt
fill 153 64 -365 166 64 -365 minecraft:dirt
fill 174 64 -365 188 64 -365 minecraft:dirt
fill 136 64 -364 147 64 -364 minecraft:dirt
fill 149 64 -364 159 64 -364 minecraft:dirt
setblock 174 64 -364 minecraft:dirt
fill 176 64 -364 188 64 -364 minecraft:dirt
fill 136 64 -363 156 64 -363 minecraft:dirt
fill 174 64 -363 188 64 -363 minecraft:dirt
fill 136 64 -362 154 64 -362 minecraft:dirt
fill 174 64 -362 188 64 -362 minecraft:dirt
fill 136 64 -361 151 64 -361 minecraft:dirt
fill 174 64 -361 188 64 -361 minecraft:dirt
fill 136 64 -360 150 64 -360 minecraft:dirt
fill 174 64 -360 187 64 -360 minecraft:dirt
fill 136 64 -359 148 64 -359 minecraft:dirt
fill 173 64 -359 188 64 -359 minecraft:dirt
fill 136 64 -358 147 64 -358 minecraft:dirt
fill 171 64 -358 173 64 -358 minecraft:dirt
fill 175 64 -358 188 64 -358 minecraft:dirt
fill 136 64 -357 146 64 -357 minecraft:dirt
fill 171 64 -357 176 64 -357 minecraft:dirt
fill 178 64 -357 188 64 -357 minecraft:dirt
fill 136 64 -356 144 64 -356 minecraft:dirt
fill 170 64 -356 178 64 -356 minecraft:dirt
fill 180 64 -356 187 64 -356 minecraft:dirt
fill 136 64 -355 143 64 -355 minecraft:dirt
fill 170 64 -355 181 64 -355 minecraft:dirt
fill 183 64 -355 187 64 -355 minecraft:dirt
fill 136 64 -354 142 64 -354 minecraft:dirt
fill 171 64 -354 181 64 -354 minecraft:dirt
fill 183 64 -354 186 64 -354 minecraft:dirt
fill 136 64 -353 141 64 -353 minecraft:dirt
fill 171 64 -353 179 64 -353 minecraft:dirt
fill 181 64 -353 186 64 -353 minecraft:dirt
fill 136 64 -352 141 64 -352 minecraft:dirt
fill 171 64 -352 186 64 -352 minecraft:dirt
fill 136 64 -351 140 64 -351 minecraft:dirt
fill 171 64 -351 175 64 -351 minecraft:dirt
fill 177 64 -351 185 64 -351 minecraft:dirt
fill 136 64 -350 137 64 -350 minecraft:dirt
fill 172 64 -350 177 64 -350 minecraft:dirt
fill 179 64 -350 185 64 -350 minecraft:dirt
setblock 136 64 -349 minecraft:dirt
fill 172 64 -349 184 64 -349 minecraft:dirt
setblock 136 64 -348 minecraft:dirt
fill 173 64 -348 184 64 -348 minecraft:dirt
fill 172 64 -347 179 64 -347 minecraft:dirt
fill 181 64 -347 183 64 -347 minecraft:dirt
fill 172 64 -346 184 64 -346 minecraft:dirt
fill 171 64 -345 185 64 -345 minecraft:dirt
fill 171 64 -344 183 64 -344 minecraft:dirt
fill 171 64 -343 177 64 -343 minecraft:dirt
fill 179 64 -343 183 64 -343 minecraft:dirt
fill 171 64 -342 183 64 -342 minecraft:dirt
fill 171 64 -341 183 64 -341 minecraft:dirt
fill 172 64 -340 178 64 -340 minecraft:dirt
fill 180 64 -340 183 64 -340 minecraft:dirt
fill 172 64 -339 183 64 -339 minecraft:dirt
fill 174 64 -338 182 64 -338 minecraft:dirt
fill 175 64 -337 179 64 -337 minecraft:dirt
fill 181 64 -337 182 64 -337 minecraft:dirt
fill 175 64 -336 182 64 -336 minecraft:dirt
fill 175 64 -335 181 64 -335 minecraft:dirt
fill 175 64 -334 180 64 -334 minecraft:dirt
fill 175 64 -333 176 64 -333 minecraft:dirt
fill 178 64 -333 180 64 -333 minecraft:dirt
setblock 168 64 -332 minecraft:dirt
fill 175 64 -332 179 64 -332 minecraft:dirt
fill 176 64 -331 178 64 -331 minecraft:dirt
setblock 185 64 -331 minecraft:dirt
setblock 176 64 -330 minecraft:dirt
fill 185 64 -330 186 64 -330 minecraft:dirt
fill 186 64 -329 187 64 -329 minecraft:dirt
fill 186 64 -328 187 64 -328 minecraft:dirt
fill 186 64 -327 188 64 -327 minecraft:dirt
fill 152 64 -326 156 64 -326 minecraft:dirt
fill 187 64 -326 188 64 -326 minecraft:dirt
fill 152 64 -325 155 64 -325 minecraft:dirt
setblock 187 64 -325 minecraft:dirt
fill 168 64 -324 172 64 -324 minecraft:dirt
setblock 151 64 -323 minecraft:dirt
fill 169 64 -323 172 64 -323 minecraft:dirt
fill 170 64 -322 172 64 -322 minecraft:dirt
fill 171 64 -321 172 64 -321 minecraft:dirt
fill 171 64 -320 172 64 -320 minecraft:dirt
fill 172 64 -319 173 64 -319 minecraft:dirt
fill 136 65 -382 199 65 -382 minecraft:grass_block
fill 136 65 -381 199 65 -381 minecraft:grass_block
fill 136 65 -380 199 65 -380 minecraft:grass_block
fill 136 65 -379 199 65 -379 minecraft:grass_block
fill 136 65 -378 199 65 -378 minecraft:grass_block
fill 136 65 -377 199 65 -377 minecraft:grass_block
fill 136 65 -376 199 65 -376 minecraft:grass_block
fill 136 65 -375 197 65 -375 minecraft:grass_block
fill 136 65 -374 196 65 -374 minecraft:grass_block
fill 136 65 -373 195 65 -373 minecraft:grass_block
fill 136 65 -372 194 65 -372 minecraft:grass_block
setblock 199 65 -372 minecraft:grass_block
fill 136 65 -371 193 65 -371 minecraft:grass_block
fill 198 65 -371 199 65 -371 minecraft:grass_block
fill 136 65 -370 192 65 -370 minecraft:grass_block
fill 197 65 -370 199 65 -370 minecraft:grass_block
fill 136 65 -369 191 65 -369 minecraft:grass_block
fill 196 65 -369 199 65 -369 minecraft:grass_block
fill 136 65 -368 190 65 -368 minecraft:grass_block
fill 195 65 -368 199 65 -368 minecraft:grass_block
fill 136 65 -367 190 65 -367 minecraft:grass_block
fill 195 65 -367 199 65 -367 minecraft:grass_block
fill 136 65 -366 190 65 -366 minecraft:grass_block
fill 194 65 -366 199 65 -366 minecraft:grass_block
fill 136 65 -365 190 65 -365 minecraft:grass_block
fill 194 65 -365 199 65 -365 minecraft:grass_block
fill 136 65 -364 190 65 -364 minecraft:grass_block
fill 193 65 -364 199 65 -364 minecraft:grass_block
fill 136 65 -363 190 65 -363 minecraft:grass_block
fill 193 65 -363 199 65 -363 minecraft:grass_block
fill 136 65 -362 169 65 -362 minecraft:grass_block
fill 172 65 -362 190 65 -362 minecraft:grass_block
fill 193 65 -362 199 65 -362 minecraft:grass_block
fill 136 65 -361 166 65 -361 minecraft:grass_block
fill 173 65 -361 190 65 -361 minecraft:grass_block
fill 193 65 -361 199 65 -361 minecraft:grass_block
fill 136 65 -360 161 65 -360 minecraft:grass_block
setblock 164 65 -360 minecraft:grass_block
fill 173 65 -360 190 65 -360 minecraft:grass_block
fill 193 65 -360 199 65 -360 minecraft:grass_block
fill 136 65 -359 156 65 -359 minecraft:grass_block
fill 171 65 -359 190 65 -359 minecraft:grass_block
fill 192 65 -359 199 65 -359 minecraft:grass_block
fill 136 65 -358 151 65 -358 minecraft:grass_block
setblock 154 65 -358 minecraft:grass_block
fill 170 65 -358 190 65 -358 minecraft:grass_block
fill 193 65 -358 199 65 -358 minecraft:grass_block
fill 136 65 -357 150 65 -357 minecraft:grass_block
setblock 168 65 -357 minecraft:grass_block
fill 170 65 -357 190 65 -357 minecraft:grass_block
fill 193 65 -357 199 65 -357 minecraft:grass_block
fill 136 65 -356 148 65 -356 minecraft:grass_block
fill 153 65 -356 159 65 -356 minecraft:grass_block
fill 165 65 -356 168 65 -356 minecraft:grass_block
fill 170 65 -356 189 65 -356 minecraft:grass_block
fill 193 65 -356 199 65 -356 minecraft:grass_block
fill 136 65 -355 148 65 -355 minecraft:grass_block
fill 151 65 -355 168 65 -355 minecraft:grass_block
fill 170 65 -355 189 65 -355 minecraft:grass_block
fill 192 65 -355 199 65 -355 minecraft:grass_block
fill 136 65 -354 147 65 -354 minecraft:grass_block
fill 150 65 -354 168 65 -354 minecraft:grass_block
fill 170 65 -354 189 65 -354 minecraft:grass_block
fill 192 65 -354 199 65 -354 minecraft:grass_block
fill 136 65 -353 168 65 -353 minecraft:grass_block
fill 170 65 -353 188 65 -353 minecraft:grass_block
fill 192 65 -353 199 65 -353 minecraft:grass_block
fill 136 65 -352 168 65 -352 minecraft:grass_block
fill 170 65 -352 188 65 -352 minecraft:grass_block
fill 192 65 -352 199 65 -352 minecraft:grass_block
fill 136 65 -351 168 65 -351 minecraft:grass_block
fill 170 65 -351 187 65 -351 minecraft:grass_block
fill 192 65 -351 199 65 -351 minecraft:grass_block
fill 136 65 -350 169 65 -350 minecraft:grass_block
fill 171 65 -350 187 65 -350 minecraft:grass_block
fill 191 65 -350 199 65 -350 minecraft:grass_block
fill 136 65 -349 169 65 -349 minecraft:grass_block
fill 171 65 -349 187 65 -349 minecraft:grass_block
fill 191 65 -349 199 65 -349 minecraft:grass_block
fill 136 65 -348 169 65 -348 minecraft:grass_block
fill 172 65 -348 186 65 -348 minecraft:grass_block
fill 191 65 -348 199 65 -348 minecraft:grass_block
fill 136 65 -347 169 65 -347 minecraft:grass_block
fill 171 65 -347 186 65 -347 minecraft:grass_block
fill 191 65 -347 199 65 -347 minecraft:grass_block
fill 136 65 -346 169 65 -346 minecraft:grass_block
fill 171 65 -346 187 65 -346 minecraft:grass_block
fill 191 65 -346 199 65 -346 minecraft:grass_block
fill 136 65 -345 187 65 -345 minecraft:grass_block
fill 191 65 -345 199 65 -345 minecraft:grass_block
fill 136 65 -344 187 65 -344 minecraft:grass_block
fill 192 65 -344 199 65 -344 minecraft:grass_block
fill 136 65 -343 169 65 -343 minecraft:grass_block
fill 171 65 -343 187 65 -343 minecraft:grass_block
fill 192 65 -343 199 65 -343 minecraft:grass_block
fill 136 65 -342 169 65 -342 minecraft:grass_block
fill 171 65 -342 187 65 -342 minecraft:grass_block
fill 192 65 -342 199 65 -342 minecraft:grass_block
fill 136 65 -341 169 65 -341 minecraft:grass_block
fill 171 65 -341 187 65 -341 minecraft:grass_block
fill 192 65 -341 199 65 -341 minecraft:grass_block
fill 136 65 -340 186 65 -340 minecraft:grass_block
fill 192 65 -340 199 65 -340 minecraft:grass_block
fill 136 65 -339 170 65 -339 minecraft:grass_block
fill 172 65 -339 187 65 -339 minecraft:grass_block
fill 136 65 -338 171 65 -338 minecraft:grass_block
fill 173 65 -338 187 65 -338 minecraft:grass_block
fill 136 65 -337 187 65 -337 minecraft:grass_block
fill 136 65 -336 187 65 -336 minecraft:grass_block
fill 136 65 -335 185 65 -335 minecraft:grass_block
fill 136 65 -334 182 65 -334 minecraft:grass_block
fill 136 65 -333 167 65 -333 minecraft:grass_block
fill 169 65 -333 181 65 -333 minecraft:grass_block
setblock 199 65 -333 minecraft:grass_block
fill 136 65 -332 168 65 -332 minecraft:grass_block
fill 170 65 -332 183 65 -332 minecraft:grass_block
setblock 199 65 -332 minecraft:grass_block
fill 136 65 -331 168 65 -331 minecraft:grass_block
fill 170 65 -331 183 65 -331 minecraft:grass_block
fill 185 65 -331 186 65 -331 minecraft:grass_block
setblock 199 65 -331 minecraft:grass_block
fill 136 65 -330 167 65 -330 minecraft:grass_block
fill 169 65 -330 180 65 -330 minecraft:grass_block
fill 184 65 -330 186 65 -330 minecraft:grass_block
fill 136 65 -329 180 65 -329 minecraft:grass_block
fill 186 65 -329 187 65 -329 minecraft:grass_block
fill 136 65 -328 181 65 -328 minecraft:grass_block
fill 186 65 -328 187 65 -328 minecraft:grass_block
fill 136 65 -327 180 65 -327 minecraft:grass_block
setblock 187 65 -327 minecraft:grass_block
fill 136 65 -326 181 65 -326 minecraft:grass_block
fill 187 65 -326 188 65 -326 minecraft:grass_block
fill 136 65 -325 156 65 -325 minecraft:grass_block
fill 158 65 -325 168 65 -325 minecraft:grass_block
fill 175 65 -325 180 65 -325 minecraft:grass_block
fill 136 65 -324 151 65 -324 minecraft:grass_block
fill 159 65 -324 172 65 -324 minecraft:grass_block
fill 175 65 -324 181 65 -324 minecraft:grass_block
fill 136 65 -323 152 65 -323 minecraft:grass_block
fill 160 65 -323 172 65 -323 minecraft:grass_block
fill 175 65 -323 181 65 -323 minecraft:grass_block
fill 136 65 -322 157 65 -322 minecraft:grass_block
fill 160 65 -322 172 65 -322 minecraft:grass_block
fill 174 65 -322 182 65 -322 minecraft:grass_block
fill 136 65 -321 184 65 -321 minecraft:grass_block
fill 136 65 -320 185 65 -320 minecraft:grass_block
setblock 192 65 -320 minecraft:grass_block
fill 136 65 -319 185 65 -319 minecraft:grass_block
setblock 192 65 -319 minecraft:grass_block
setblock 192 66 -381 minecraft:air
setblock 182 66 -380 minecraft:air
setblock 194 66 -380 minecraft:air
setblock 188 66 -376 minecraft:air
setblock 198 66 -376 minecraft:air
setblock 179 66 -375 minecraft:air
setblock 197 66 -374 minecraft:air
setblock 199 66 -372 minecraft:air
fill 198 66 -371 199 66 -371 minecraft:air
setblock 187 66 -370 minecraft:air
setblock 191 66 -370 minecraft:air
fill 197 66 -370 199 66 -370 minecraft:air
setblock 174 66 -369 minecraft:air
setblock 181 66 -369 minecraft:air
fill 196 66 -369 199 66 -369 minecraft:air
fill 195 66 -368 199 66 -368 minecraft:air
fill 195 66 -367 199 66 -367 minecraft:air
setblock 170 66 -366 minecraft:air
setblock 183 66 -366 minecraft:air
setblock 186 66 -366 minecraft:air
setblock 191 66 -366 minecraft:air
fill 194 66 -366 199 66 -366 minecraft:air
fill 194 66 -365 199 66 -365 minecraft:air
setblock 175 66 -364 minecraft:air
fill 193 66 -364 199 66 -364 minecraft:air
setblock 164 66 -363 minecraft:air
setblock 172 66 -363 minecraft:air
setblock 190 66 -363 minecraft:air
fill 193 66 -363 199 66 -363 minecraft:air
fill 193 66 -362 199 66 -362 minecraft:air
setblock 155 66 -361 minecraft:air
setblock 169 66 -361 minecraft:air
setblock 191 66 -361 minecraft:air
fill 193 66 -361 199 66 -361 minecraft:air
setblock 152 66 -360 minecraft:air
fill 160 66 -360 161 66 -360 minecraft:air
setblock 163 66 -360 minecraft:air
setblock 165 66 -360 minecraft:air
setblock 172 66 -360 minecraft:air
setblock 188 66 -360 minecraft:air
fill 193 66 -360 199 66 -360 minecraft:air
fill 159 66 -359 163 66 -359 minecraft:air
setblock 165 66 -359 minecraft:air
fill 192 66 -359 199 66 -359 minecraft:air
setblock 154 66 -358 minecraft:air
setblock 160 66 -358 minecraft:air
fill 166 66 -358 167 66 -358 minecraft:air
setblock 174 66 -358 minecraft:air
fill 193 66 -358 199 66 -358 minecraft:air
setblock 152 66 -357 minecraft:air
setblock 154 66 -357 minecraft:air
fill 156 66 -357 157 66 -357 minecraft:air
setblock 160 66 -357 minecraft:air
setblock 165 66 -357 minecraft:air
setblock 168 66 -357 minecraft:air
fill 193 66 -357 199 66 -357 minecraft:air
fill 153 66 -356 160 66 -356 minecraft:air
setblock 163 66 -356 minecraft:air
fill 165 66 -356 168 66 -356 minecraft:air
setblock 179 66 -356 minecraft:air
fill 193 66 -356 199 66 -356 minecraft:air
fill 151 66 -355 168 66 -355 minecraft:air
setblock 182 66 -355 minecraft:air
fill 192 66 -355 199 66 -355 minecraft:air
setblock 148 66 -354 minecraft:air
fill 150 66 -354 168 66 -354 minecraft:air
fill 192 66 -354 199 66 -354 minecraft:air
setblock 146 66 -353 minecraft:air
fill 148 66 -353 168 66 -353 minecraft:air
setblock 180 66 -353 minecraft:air
fill 192 66 -353 199 66 -353 minecraft:air
fill 147 66 -352 168 66 -352 minecraft:air
setblock 187 66 -352 minecraft:air
fill 192 66 -352 199 66 -352 minecraft:air
fill 147 66 -351 168 66 -351 minecraft:air
setblock 176 66 -351 minecraft:air
fill 192 66 -351 199 66 -351 minecraft:air
setblock 139 66 -350 minecraft:air
setblock 141 66 -350 minecraft:air
setblock 143 66 -350 minecraft:air
fill 146 66 -350 169 66 -350 minecraft:air
setblock 171 66 -350 minecraft:air
setblock 178 66 -350 minecraft:air
fill 191 66 -350 199 66 -350 minecraft:air
fill 142 66 -349 143 66 -349 minecraft:air
fill 146 66 -349 169 66 -349 minecraft:air
setblock 186 66 -349 minecraft:air
fill 191 66 -349 199 66 -349 minecraft:air
setblock 143 66 -348 minecraft:air
fill 145 66 -348 169 66 -348 minecraft:air
fill 191 66 -348 199 66 -348 minecraft:air
fill 144 66 -347 169 66 -347 minecraft:air
setblock 180 66 -347 minecraft:air
fill 191 66 -347 199 66 -347 minecraft:air
fill 141 66 -346 169 66 -346 minecraft:air
setblock 187 66 -346 minecraft:air
fill 191 66 -346 199 66 -346 minecraft:air
setblock 136 66 -345 minecraft:air
fill 139 66 -345 169 66 -345 minecraft:air
fill 191 66 -345 199 66 -345 minecraft:air
setblock 136 66 -344 minecraft:air
fill 138 66 -344 169 66 -344 minecraft:air
fill 192 66 -344 199 66 -344 minecraft:air
fill 136 66 -343 169 66 -343 minecraft:air
setblock 178 66 -343 minecraft:air
fill 190 66 -343 199 66 -343 minecraft:air
fill 136 66 -342 169 66 -342 minecraft:air
fill 192 66 -342 199 66 -342 minecraft:air
fill 136 66 -341 169 66 -341 minecraft:air
fill 192 66 -341 199 66 -341 minecraft:air
fill 136 66 -340 170 66 -340 minecraft:air
setblock 179 66 -340 minecraft:air
setblock 187 66 -340 minecraft:air
fill 192 66 -340 199 66 -340 minecraft:air
fill 136 66 -339 170 66 -339 minecraft:air
setblock 188 66 -339 minecraft:air
setblock 190 66 -339 minecraft:air
fill 136 66 -338 171 66 -338 minecraft:air
fill 189 66 -338 190 66 -338 minecraft:air
fill 136 66 -337 173 66 -337 minecraft:air
setblock 180 66 -337 minecraft:air
fill 136 66 -336 174 66 -336 minecraft:air
setblock 188 66 -336 minecraft:air
fill 136 66 -335 174 66 -335 minecraft:air
setblock 184 66 -335 minecraft:air
fill 136 66 -334 172 66 -334 minecraft:air
fill 136 66 -333 167 66 -333 minecraft:air
fill 169 66 -333 172 66 -333 minecraft:air
fill 136 66 -332 167 66 -332 minecraft:air
fill 170 66 -332 172 66 -332 minecraft:air
fill 136 66 -331 167 66 -331 minecraft:air
fill 169 66 -331 172 66 -331 minecraft:air
fill 136 66 -330 167 66 -330 minecraft:air
fill 169 66 -330 172 66 -330 minecraft:air
fill 136 66 -329 172 66 -329 minecraft:air
fill 136 66 -328 172 66 -328 minecraft:air
fill 136 66 -327 172 66 -327 minecraft:air
fill 136 66 -326 172 66 -326 minecraft:air
fill 136 66 -325 142 66 -325 minecraft:air
fill 136 66 -324 142 66 -324 minecraft:air
fill 136 66 -323 142 66 -323 minecraft:air
fill 136 66 -322 142 66 -322 minecraft:air
fill 136 66 -321 142 66 -321 minecraft:air
fill 136 66 -320 142 66 -320 minecraft:air
fill 136 66 -319 142 66 -319 minecraft:air
setblock 192 67 -381 minecraft:air
setblock 182 67 -380 minecraft:air
setblock 194 67 -380 minecraft:air
setblock 188 67 -376 minecraft:air
setblock 198 67 -376 minecraft:air
setblock 179 67 -375 minecraft:air
setblock 197 67 -374 minecraft:air
setblock 187 67 -370 minecraft:air
setblock 191 67 -370 minecraft:air
setblock 174 67 -369 minecraft:air
setblock 181 67 -369 minecraft:air
setblock 199 67 -369 minecraft:air
setblock 198 67 -368 minecraft:air
setblock 199 67 -367 minecraft:air
setblock 170 67 -366 minecraft:air
setblock 183 67 -366 minecraft:air
setblock 186 67 -366 minecraft:air
setblock 198 67 -366 minecraft:air
setblock 195 67 -365 minecraft:air
setblock 199 67 -365 minecraft:air
setblock 175 67 -364 minecraft:air
setblock 199 67 -364 minecraft:air
setblock 164 67 -363 minecraft:air
setblock 172 67 -363 minecraft:air
setblock 190 67 -363 minecraft:air
fill 197 67 -363 199 67 -363 minecraft:air
fill 194 67 -362 195 67 -362 minecraft:air
fill 197 67 -362 199 67 -362 minecraft:air
fill 195 67 -361 199 67 -361 minecraft:air
setblock 188 67 -360 minecraft:air
fill 196 67 -360 199 67 -360 minecraft:air
setblock 192 67 -359 minecraft:air
fill 196 67 -359 199 67 -359 minecraft:air
setblock 154 67 -358 minecraft:air
setblock 174 67 -358 minecraft:air
fill 196 67 -358 199 67 -358 minecraft:air
fill 196 67 -357 199 67 -357 minecraft:air
setblock 157 67 -356 minecraft:air
setblock 165 67 -356 minecraft:air
setblock 179 67 -356 minecraft:air
fill 196 67 -356 199 67 -356 minecraft:air
setblock 158 67 -355 minecraft:air
fill 162 67 -355 163 67 -355 minecraft:air
setblock 166 67 -355 minecraft:air
setblock 182 67 -355 minecraft:air
fill 196 67 -355 199 67 -355 minecraft:air
setblock 160 67 -354 minecraft:air
setblock 162 67 -354 minecraft:air
setblock 164 67 -354 minecraft:air
setblock 168 67 -354 minecraft:air
fill 196 67 -354 199 67 -354 minecraft:air
fill 151 67 -353 156 67 -353 minecraft:air
setblock 167 67 -353 minecraft:air
setblock 180 67 -353 minecraft:air
fill 196 67 -353 199 67 -353 minecraft:air
fill 151 67 -352 157 67 -352 minecraft:air
setblock 167 67 -352 minecraft:air
setblock 187 67 -352 minecraft:air
setblock 194 67 -352 minecraft:air
fill 196 67 -352 199 67 -352 minecraft:air
fill 149 67 -351 161 67 -351 minecraft:air
setblock 163 67 -351 minecraft:air
fill 167 67 -351 168 67 -351 minecraft:air
setblock 176 67 -351 minecraft:air
fill 196 67 -351 199 67 -351 minecraft:air
fill 149 67 -350 162 67 -350 minecraft:air
fill 165 67 -350 168 67 -350 minecraft:air
setblock 171 67 -350 minecraft:air
setblock 178 67 -350 minecraft:air
fill 193 67 -350 194 67 -350 minecraft:air
fill 196 67 -350 199 67 -350 minecraft:air
setblock 143 67 -349 minecraft:air
fill 148 67 -349 163 67 -349 minecraft:air
fill 165 67 -349 168 67 -349 minecraft:air
setblock 186 67 -349 minecraft:air
fill 196 67 -349 199 67 -349 minecraft:air
setblock 143 67 -348 minecraft:air
setblock 146 67 -348 minecraft:air
fill 148 67 -348 168 67 -348 minecraft:air
setblock 191 67 -348 minecraft:air
fill 195 67 -348 199 67 -348 minecraft:air
setblock 144 67 -347 minecraft:air
fill 147 67 -347 168 67 -347 minecraft:air
setblock 180 67 -347 minecraft:air
fill 195 67 -347 199 67 -347 minecraft:air
fill 146 67 -346 168 67 -346 minecraft:air
setblock 187 67 -346 minecraft:air
fill 196 67 -346 199 67 -346 minecraft:air
setblock 139 67 -345 minecraft:air
fill 144 67 -345 168 67 -345 minecraft:air
fill 193 67 -345 194 67 -345 minecraft:air
fill 196 67 -345 199 67 -345 minecraft:air
setblock 136 67 -344 minecraft:air
fill 141 67 -344 168 67 -344 minecraft:air
setblock 192 67 -344 minecraft:air
fill 196 67 -344 199 67 -344 minecraft:air
fill 138 67 -343 168 67 -343 minecraft:air
setblock 178 67 -343 minecraft:air
setblock 194 67 -343 minecraft:air
fill 196 67 -343 199 67 -343 minecraft:air
setblock 137 67 -342 minecraft:air
fill 139 67 -342 169 67 -342 minecraft:air
fill 192 67 -342 194 67 -342 minecraft:air
fill 196 67 -342 199 67 -342 minecraft:air
fill 138 67 -341 169 67 -341 minecraft:air
fill 194 67 -341 195 67 -341 minecraft:air
fill 197 67 -341 199 67 -341 minecraft:air
fill 138 67 -340 169 67 -340 minecraft:air
setblock 179 67 -340 minecraft:air
setblock 192 67 -340 minecraft:air
fill 197 67 -340 199 67 -340 minecraft:air
fill 137 67 -339 170 67 -339 minecraft:air
fill 137 67 -338 170 67 -338 minecraft:air
fill 136 67 -337 172 67 -337 minecraft:air
setblock 180 67 -337 minecraft:air
fill 136 67 -336 173 67 -336 minecraft:air
fill 136 67 -335 174 67 -335 minecraft:air
setblock 184 67 -335 minecraft:air
fill 136 67 -334 172 67 -334 minecraft:air
fill 136 67 -333 167 67 -333 minecraft:air
fill 170 67 -333 172 67 -333 minecraft:air
fill 136 67 -332 166 67 -332 minecraft:air
fill 170 67 -332 172 67 -332 minecraft:air
fill 136 67 -331 166 67 -331 minecraft:air
fill 170 67 -331 172 67 -331 minecraft:air
fill 136 67 -330 167 67 -330 minecraft:air
fill 170 67 -330 172 67 -330 minecraft:air
fill 136 67 -329 167 67 -329 minecraft:air
fill 169 67 -329 172 67 -329 minecraft:air
fill 136 67 -328 172 67 -328 minecraft:air
fill 136 67 -327 172 67 -327 minecraft:air
fill 136 67 -326 172 67 -326 minecraft:air
fill 136 67 -325 142 67 -325 minecraft:air
fill 136 67 -324 142 67 -324 minecraft:air
fill 136 67 -323 142 67 -323 minecraft:air
fill 136 67 -322 142 67 -322 minecraft:air
fill 136 67 -321 142 67 -321 minecraft:air
fill 136 67 -320 142 67 -320 minecraft:air
fill 136 67 -319 142 67 -319 minecraft:air
setblock 182 68 -382 minecraft:air
fill 181 68 -381 183 68 -381 minecraft:air
setblock 192 68 -381 minecraft:air
fill 180 68 -380 184 68 -380 minecraft:air
setblock 194 68 -380 minecraft:air
fill 181 68 -379 183 68 -379 minecraft:air
setblock 182 68 -378 minecraft:air
setblock 188 68 -376 minecraft:air
setblock 198 68 -376 minecraft:air
setblock 179 68 -375 minecraft:air
setblock 187 68 -370 minecraft:air
setblock 191 68 -370 minecraft:air
setblock 174 68 -369 minecraft:air
setblock 181 68 -369 minecraft:air
setblock 199 68 -369 minecraft:air
setblock 170 68 -366 minecraft:air
setblock 183 68 -366 minecraft:air
setblock 186 68 -366 minecraft:air
setblock 195 68 -365 minecraft:air
setblock 199 68 -365 minecraft:air
setblock 175 68 -364 minecraft:air
setblock 164 68 -363 minecraft:air
setblock 172 68 -363 minecraft:air
setblock 190 68 -363 minecraft:air
fill 197 68 -363 198 68 -363 minecraft:air
setblock 195 68 -361 minecraft:air
setblock 188 68 -360 minecraft:air
setblock 196 68 -360 minecraft:air
setblock 192 68 -359 minecraft:air
setblock 154 68 -358 minecraft:air
setblock 174 68 -358 minecraft:air
setblock 198 68 -357 minecraft:air
setblock 179 68 -356 minecraft:air
setblock 182 68 -355 minecraft:air
setblock 199 68 -354 minecraft:air
setblock 151 68 -353 minecraft:air
setblock 155 68 -353 minecraft:air
setblock 180 68 -353 minecraft:air
setblock 187 68 -352 minecraft:air
setblock 194 68 -352 minecraft:air
setblock 151 68 -351 minecraft:air
setblock 155 68 -351 minecraft:air
setblock 160 68 -351 minecraft:air
setblock 176 68 -351 minecraft:air
setblock 199 68 -351 minecraft:air
setblock 160 68 -350 minecraft:air
setblock 162 68 -350 minecraft:air
fill 165 68 -350 166 68 -350 minecraft:air
setblock 168 68 -350 minecraft:air
setblock 171 68 -350 minecraft:air
setblock 178 68 -350 minecraft:air
setblock 199 68 -350 minecraft:air
setblock 149 68 -349 minecraft:air
fill 151 68 -349 152 68 -349 minecraft:air
setblock 186 68 -349 minecraft:air
setblock 146 68 -348 minecraft:air
setblock 149 68 -348 minecraft:air
fill 152 68 -348 156 68 -348 minecraft:air
setblock 165 68 -348 minecraft:air
setblock 195 68 -348 minecraft:air
setblock 144 68 -347 minecraft:air
setblock 149 68 -347 minecraft:air
fill 151 68 -347 158 68 -347 minecraft:air
setblock 162 68 -347 minecraft:air
fill 167 68 -347 168 68 -347 minecraft:air
setblock 180 68 -347 minecraft:air
setblock 199 68 -347 minecraft:air
setblock 146 68 -346 minecraft:air
fill 149 68 -346 160 68 -346 minecraft:air
fill 167 68 -346 168 68 -346 minecraft:air
setblock 187 68 -346 minecraft:air
setblock 199 68 -346 minecraft:air
setblock 147 68 -345 minecraft:air
fill 149 68 -345 163 68 -345 minecraft:air
fill 165 68 -345 168 68 -345 minecraft:air
setblock 193 68 -345 minecraft:air
setblock 196 68 -345 minecraft:air
fill 198 68 -345 199 68 -345 minecraft:air
fill 147 68 -344 168 68 -344 minecraft:air
setblock 142 68 -343 minecraft:air
fill 144 68 -343 168 68 -343 minecraft:air
setblock 178 68 -343 minecraft:air
setblock 196 68 -343 minecraft:air
fill 143 68 -342 168 68 -342 minecraft:air
setblock 192 68 -342 minecraft:air
fill 142 68 -341 168 68 -341 minecraft:air
fill 141 68 -340 168 68 -340 minecraft:air
setblock 179 68 -340 minecraft:air
fill 140 68 -339 169 68 -339 minecraft:air
fill 139 68 -338 170 68 -338 minecraft:air
setblock 136 68 -337 minecraft:air
fill 138 68 -337 171 68 -337 minecraft:air
setblock 180 68 -337 minecraft:air
fill 138 68 -336 173 68 -336 minecraft:air
fill 138 68 -335 173 68 -335 minecraft:air
setblock 184 68 -335 minecraft:air
fill 137 68 -334 167 68 -334 minecraft:air
fill 169 68 -334 172 68 -334 minecraft:air
fill 137 68 -333 166 68 -333 minecraft:air
fill 170 68 -333 172 68 -333 minecraft:air
fill 137 68 -332 166 68 -332 minecraft:air
fill 171 68 -332 172 68 -332 minecraft:air
fill 137 68 -331 166 68 -331 minecraft:air
fill 170 68 -331 172 68 -331 minecraft:air
fill 137 68 -330 166 68 -330 minecraft:air
fill 170 68 -330 172 68 -330 minecraft:air
fill 137 68 -329 167 68 -329 minecraft:air
fill 170 68 -329 172 68 -329 minecraft:air
fill 137 68 -328 167 68 -328 minecraft:air
fill 169 68 -328 172 68 -328 minecraft:air
fill 136 68 -327 167 68 -327 minecraft:air
fill 169 68 -327 172 68 -327 minecraft:air
fill 136 68 -326 172 68 -326 minecraft:air
fill 136 68 -325 142 68 -325 minecraft:air
fill 136 68 -324 142 68 -324 minecraft:air
fill 136 68 -323 142 68 -323 minecraft:air
fill 136 68 -322 142 68 -322 minecraft:air
fill 136 68 -321 142 68 -321 minecraft:air
fill 136 68 -320 142 68 -320 minecraft:air
fill 136 68 -319 142 68 -319 minecraft:air
setblock 194 69 -382 minecraft:air
fill 181 69 -381 183 69 -381 minecraft:air
fill 192 69 -381 195 69 -381 minecraft:air
fill 181 69 -380 183 69 -380 minecraft:air
fill 192 69 -380 196 69 -380 minecraft:air
fill 181 69 -379 183 69 -379 minecraft:air
fill 193 69 -379 195 69 -379 minecraft:air
setblock 194 69 -378 minecraft:air
setblock 179 69 -377 minecraft:air
fill 178 69 -376 180 69 -376 minecraft:air
setblock 188 69 -376 minecraft:air
setblock 198 69 -376 minecraft:air
fill 177 69 -375 181 69 -375 minecraft:air
fill 178 69 -374 180 69 -374 minecraft:air
setblock 179 69 -373 minecraft:air
setblock 187 69 -372 minecraft:air
fill 186 69 -371 188 69 -371 minecraft:air
fill 185 69 -370 189 69 -370 minecraft:air
setblock 191 69 -370 minecraft:air
setblock 174 69 -369 minecraft:air
setblock 181 69 -369 minecraft:air
fill 186 69 -369 188 69 -369 minecraft:air
setblock 199 69 -369 minecraft:air
setblock 187 69 -368 minecraft:air
setblock 170 69 -366 minecraft:air
setblock 183 69 -366 minecraft:air
setblock 186 69 -366 minecraft:air
setblock 195 69 -365 minecraft:air
setblock 175 69 -364 minecraft:air
setblock 164 69 -363 minecraft:air
setblock 172 69 -363 minecraft:air
setblock 190 69 -363 minecraft:air
setblock 195 69 -361 minecraft:air
setblock 174 69 -360 minecraft:air
setblock 188 69 -360 minecraft:air
fill 173 69 -359 175 69 -359 minecraft:air
setblock 192 69 -359 minecraft:air
setblock 154 69 -358 minecraft:air
fill 172 69 -358 176 69 -358 minecraft:air
fill 173 69 -357 175 69 -357 minecraft:air
setblock 182 69 -357 minecraft:air
setblock 174 69 -356 minecraft:air
setblock 179 69 -356 minecraft:air
fill 181 69 -356 183 69 -356 minecraft:air
fill 180 69 -355 184 69 -355 minecraft:air
fill 181 69 -354 183 69 -354 minecraft:air
setblock 199 69 -354 minecraft:air
setblock 151 69 -353 minecraft:air
setblock 155 69 -353 minecraft:air
setblock 180 69 -353 minecraft:air
setblock 182 69 -353 minecraft:air
setblock 178 69 -352 minecraft:air
setblock 187 69 -352 minecraft:air
setblock 194 69 -352 minecraft:air
setblock 151 69 -351 minecraft:air
setblock 160 69 -351 minecraft:air
fill 176 69 -351 179 69 -351 minecraft:air
setblock 199 69 -351 minecraft:air
setblock 162 69 -350 minecraft:air
setblock 165 69 -350 minecraft:air
setblock 171 69 -350 minecraft:air
fill 176 69 -350 180 69 -350 minecraft:air
setblock 152 69 -349 minecraft:air
fill 177 69 -349 179 69 -349 minecraft:air
setblock 186 69 -349 minecraft:air
setblock 152 69 -348 minecraft:air
setblock 178 69 -348 minecraft:air
setblock 152 69 -347 minecraft:air
setblock 156 69 -347 minecraft:air
setblock 180 69 -347 minecraft:air
setblock 187 69 -346 minecraft:air
setblock 149 69 -345 minecraft:air
setblock 152 69 -345 minecraft:air
setblock 156 69 -345 minecraft:air
setblock 168 69 -345 minecraft:air
setblock 193 69 -345 minecraft:air
setblock 148 69 -344 minecraft:air
fill 151 69 -344 152 69 -344 minecraft:air
setblock 154 69 -344 minecraft:air
setblock 156 69 -344 minecraft:air
setblock 142 69 -343 minecraft:air
setblock 144 69 -343 minecraft:air
setblock 147 69 -343 minecraft:air
setblock 153 69 -343 minecraft:air
fill 155 69 -343 158 69 -343 minecraft:air
setblock 178 69 -343 minecraft:air
fill 150 69 -342 160 69 -342 minecraft:air
setblock 192 69 -342 minecraft:air
fill 148 69 -341 163 69 -341 minecraft:air
fill 167 69 -341 168 69 -341 minecraft:air
fill 145 69 -340 168 69 -340 minecraft:air
setblock 179 69 -340 minecraft:air
fill 143 69 -339 168 69 -339 minecraft:air
setblock 139 69 -338 minecraft:air
fill 142 69 -338 168 69 -338 minecraft:air
fill 140 69 -337 169 69 -337 minecraft:air
setblock 180 69 -337 minecraft:air
fill 140 69 -336 172 69 -336 minecraft:air
fill 140 69 -335 172 69 -335 minecraft:air
setblock 184 69 -335 minecraft:air
fill 140 69 -334 166 69 -334 minecraft:air
fill 171 69 -334 172 69 -334 minecraft:air
fill 140 69 -333 165 69 -333 minecraft:air
fill 171 69 -333 172 69 -333 minecraft:air
fill 140 69 -332 165 69 -332 minecraft:air
fill 171 69 -332 172 69 -332 minecraft:air
setblock 137 69 -331 minecraft:air
fill 140 69 -331 165 69 -331 minecraft:air
setblock 171 69 -331 minecraft:air
fill 138 69 -330 166 69 -330 minecraft:air
fill 138 69 -329 166 69 -329 minecraft:air
fill 170 69 -329 171 69 -329 minecraft:air
setblock 138 69 -328 minecraft:air
fill 140 69 -328 167 69 -328 minecraft:air
fill 170 69 -328 172 69 -328 minecraft:air
setblock 136 69 -327 minecraft:air
fill 140 69 -327 167 69 -327 minecraft:air
fill 170 69 -327 172 69 -327 minecraft:air
fill 139 69 -326 167 69 -326 minecraft:air
fill 170 69 -326 172 69 -326 minecraft:air
setblock 136 69 -325 minecraft:air
fill 138 69 -325 142 69 -325 minecraft:air
fill 138 69 -324 142 69 -324 minecraft:air
fill 139 69 -323 142 69 -323 minecraft:air
fill 138 69 -322 142 69 -322 minecraft:air
fill 138 69 -321 142 69 -321 minecraft:air
fill 137 69 -320 142 69 -320 minecraft:air
fill 137 69 -319 142 69 -319 minecraft:air
fill 180 70 -382 182 70 -382 minecraft:air
fill 181 70 -381 182 70 -381 minecraft:air
fill 192 70 -381 195 70 -381 minecraft:air
fill 181 70 -380 183 70 -380 minecraft:air
fill 193 70 -380 195 70 -380 minecraft:air
setblock 182 70 -379 minecraft:air
fill 193 70 -379 195 70 -379 minecraft:air
setblock 198 70 -378 minecraft:air
fill 197 70 -377 199 70 -377 minecraft:air
fill 178 70 -376 180 70 -376 minecraft:air
setblock 188 70 -376 minecraft:air
fill 196 70 -376 199 70 -376 minecraft:air
fill 178 70 -375 180 70 -375 minecraft:air
fill 197 70 -375 199 70 -375 minecraft:air
fill 178 70 -374 180 70 -374 minecraft:air
setblock 198 70 -374 minecraft:air
setblock 191 70 -372 minecraft:air
setblock 174 70 -371 minecraft:air
setblock 181 70 -371 minecraft:air
fill 186 70 -371 188 70 -371 minecraft:air
fill 190 70 -371 192 70 -371 minecraft:air
fill 173 70 -370 175 70 -370 minecraft:air
fill 180 70 -370 182 70 -370 minecraft:air
fill 186 70 -370 193 70 -370 minecraft:air
fill 172 70 -369 176 70 -369 minecraft:air
fill 179 70 -369 183 70 -369 minecraft:air
fill 186 70 -369 188 70 -369 minecraft:air
fill 190 70 -369 192 70 -369 minecraft:air
setblock 199 70 -369 minecraft:air
fill 173 70 -368 175 70 -368 minecraft:air
fill 180 70 -368 182 70 -368 minecraft:air
setblock 186 70 -368 minecraft:air
setblock 191 70 -368 minecraft:air
setblock 174 70 -367 minecraft:air
setblock 181 70 -367 minecraft:air
fill 185 70 -367 187 70 -367 minecraft:air
setblock 170 70 -366 minecraft:air
setblock 175 70 -366 minecraft:air
fill 183 70 -366 188 70 -366 minecraft:air
setblock 164 70 -365 minecraft:air
fill 174 70 -365 176 70 -365 minecraft:air
fill 185 70 -365 187 70 -365 minecraft:air
setblock 195 70 -365 minecraft:air
fill 163 70 -364 165 70 -364 minecraft:air
fill 173 70 -364 177 70 -364 minecraft:air
setblock 186 70 -364 minecraft:air
fill 162 70 -363 166 70 -363 minecraft:air
setblock 172 70 -363 minecraft:air
fill 174 70 -363 176 70 -363 minecraft:air
setblock 190 70 -363 minecraft:air
fill 163 70 -362 165 70 -362 minecraft:air
setblock 175 70 -362 minecraft:air
setblock 164 70 -361 minecraft:air
setblock 195 70 -361 minecraft:air
setblock 188 70 -360 minecraft:air
fill 173 70 -359 175 70 -359 minecraft:air
setblock 192 70 -359 minecraft:air
setblock 154 70 -358 minecraft:air
fill 173 70 -358 175 70 -358 minecraft:air
fill 173 70 -357 175 70 -357 minecraft:air
setblock 179 70 -356 minecraft:air
fill 181 70 -356 183 70 -356 minecraft:air
fill 180 70 -355 183 70 -355 minecraft:air
fill 179 70 -354 183 70 -354 minecraft:air
setblock 187 70 -354 minecraft:air
setblock 199 70 -354 minecraft:air
setblock 151 70 -353 minecraft:air
setblock 155 70 -353 minecraft:air
setblock 176 70 -353 minecraft:air
fill 178 70 -353 182 70 -353 minecraft:air
fill 186 70 -353 188 70 -353 minecraft:air
fill 175 70 -352 177 70 -352 minecraft:air
fill 179 70 -352 181 70 -352 minecraft:air
fill 185 70 -352 189 70 -352 minecraft:air
setblock 194 70 -352 minecraft:air
setblock 160 70 -351 minecraft:air
fill 174 70 -351 180 70 -351 minecraft:air
fill 186 70 -351 188 70 -351 minecraft:air
setblock 199 70 -351 minecraft:air
setblock 162 70 -350 minecraft:air
setblock 165 70 -350 minecraft:air
setblock 171 70 -350 minecraft:air
fill 175 70 -350 179 70 -350 minecraft:air
setblock 187 70 -350 minecraft:air
setblock 152 70 -349 minecraft:air
fill 176 70 -349 179 70 -349 minecraft:air
setblock 186 70 -349 minecraft:air
setblock 180 70 -347 minecraft:air
setblock 187 70 -346 minecraft:air
setblock 149 70 -345 minecraft:air
setblock 168 70 -345 minecraft:air
setblock 193 70 -345 minecraft:air
setblock 156 70 -344 minecraft:air
fill 155 70 -343 156 70 -343 minecraft:air
setblock 178 70 -343 minecraft:air
setblock 150 70 -342 minecraft:air
setblock 153 70 -342 minecraft:air
setblock 156 70 -342 minecraft:air
setblock 192 70 -342 minecraft:air
setblock 148 70 -341 minecraft:air
setblock 151 70 -341 minecraft:air
fill 155 70 -341 157 70 -341 minecraft:air
setblock 160 70 -341 minecraft:air
setblock 146 70 -340 minecraft:air
setblock 148 70 -340 minecraft:air
fill 150 70 -340 152 70 -340 minecraft:air
fill 154 70 -340 155 70 -340 minecraft:air
fill 158 70 -340 159 70 -340 minecraft:air
setblock 162 70 -340 minecraft:air
setblock 179 70 -340 minecraft:air
setblock 150 70 -339 minecraft:air
fill 152 70 -339 154 70 -339 minecraft:air
setblock 167 70 -339 minecraft:air
setblock 151 70 -338 minecraft:air
fill 153 70 -338 157 70 -338 minecraft:air
setblock 163 70 -338 minecraft:air
fill 147 70 -337 159 70 -337 minecraft:air
setblock 161 70 -337 minecraft:air
setblock 164 70 -337 minecraft:air
setblock 168 70 -337 minecraft:air
setblock 180 70 -337 minecraft:air
fill 144 70 -336 169 70 -336 minecraft:air
fill 145 70 -335 166 70 -335 minecraft:air
setblock 184 70 -335 minecraft:air
fill 142 70 -334 143 70 -334 minecraft:air
fill 145 70 -334 164 70 -334 minecraft:air
setblock 166 70 -334 minecraft:air
fill 171 70 -334 172 70 -334 minecraft:air
fill 145 70 -333 165 70 -333 minecraft:air
setblock 172 70 -333 minecraft:air
fill 145 70 -332 164 70 -332 minecraft:air
setblock 172 70 -332 minecraft:air
fill 140 70 -331 141 70 -331 minecraft:air
fill 145 70 -331 164 70 -331 minecraft:air
fill 145 70 -330 165 70 -330 minecraft:air
setblock 143 70 -329 minecraft:air
fill 145 70 -329 166 70 -329 minecraft:air
setblock 140 70 -328 minecraft:air
fill 145 70 -328 166 70 -328 minecraft:air
fill 171 70 -328 172 70 -328 minecraft:air
setblock 141 70 -327 minecraft:air
fill 144 70 -327 167 70 -327 minecraft:air
fill 171 70 -327 172 70 -327 minecraft:air
fill 144 70 -326 167 70 -326 minecraft:air
setblock 136 70 -325 minecraft:air
setblock 140 70 -325 minecraft:air
setblock 138 70 -324 minecraft:air
setblock 140 70 -322 minecraft:air
setblock 142 70 -322 minecraft:air
setblock 142 70 -321 minecraft:air
fill 141 70 -320 142 70 -320 minecraft:air
fill 140 70 -319 142 70 -319 minecraft:air
fill 180 71 -382 182 71 -382 minecraft:air
fill 191 71 -382 193 71 -382 minecraft:air
setblock 182 71 -381 minecraft:air
fill 190 71 -381 194 71 -381 minecraft:air
fill 181 71 -380 182 71 -380 minecraft:air
fill 191 71 -380 195 71 -380 minecraft:air
setblock 199 71 -380 minecraft:air
setblock 192 71 -379 minecraft:air
setblock 194 71 -379 minecraft:air
fill 198 71 -379 199 71 -379 minecraft:air
setblock 188 71 -378 minecraft:air
setblock 199 71 -378 minecraft:air
fill 187 71 -377 189 71 -377 minecraft:air
fill 197 71 -377 199 71 -377 minecraft:air
setblock 179 71 -376 minecraft:air
fill 186 71 -376 190 71 -376 minecraft:air
fill 197 71 -376 199 71 -376 minecraft:air
fill 178 71 -375 180 71 -375 minecraft:air
fill 187 71 -375 189 71 -375 minecraft:air
fill 197 71 -375 199 71 -375 minecraft:air
setblock 179 71 -374 minecraft:air
setblock 188 71 -374 minecraft:air
setblock 187 71 -371 minecraft:air
fill 190 71 -371 192 71 -371 minecraft:air
fill 173 71 -370 175 71 -370 minecraft:air
fill 180 71 -370 182 71 -370 minecraft:air
fill 186 71 -370 188 71 -370 minecraft:air
fill 190 71 -370 192 71 -370 minecraft:air
fill 173 71 -369 175 71 -369 minecraft:air
fill 180 71 -369 182 71 -369 minecraft:air
setblock 187 71 -369 minecraft:air
fill 190 71 -369 192 71 -369 minecraft:air
setblock 199 71 -369 minecraft:air
fill 173 71 -368 175 71 -368 minecraft:air
fill 180 71 -368 183 71 -368 minecraft:air
fill 182 71 -367 187 71 -367 minecraft:air
setblock 170 71 -366 minecraft:air
fill 181 71 -366 187 71 -366 minecraft:air
fill 174 71 -365 176 71 -365 minecraft:air
fill 182 71 -365 187 71 -365 minecraft:air
setblock 190 71 -365 minecraft:air
setblock 195 71 -365 minecraft:air
fill 163 71 -364 165 71 -364 minecraft:air
fill 174 71 -364 176 71 -364 minecraft:air
setblock 183 71 -364 minecraft:air
fill 189 71 -364 191 71 -364 minecraft:air
fill 163 71 -363 165 71 -363 minecraft:air
setblock 172 71 -363 minecraft:air
fill 174 71 -363 176 71 -363 minecraft:air
fill 188 71 -363 192 71 -363 minecraft:air
fill 163 71 -362 165 71 -362 minecraft:air
fill 188 71 -362 191 71 -362 minecraft:air
fill 187 71 -361 190 71 -361 minecraft:air
setblock 195 71 -361 minecraft:air
fill 186 71 -360 190 71 -360 minecraft:air
setblock 174 71 -359 minecraft:air
fill 187 71 -359 189 71 -359 minecraft:air
setblock 192 71 -359 minecraft:air
setblock 154 71 -358 minecraft:air
fill 173 71 -358 175 71 -358 minecraft:air
setblock 179 71 -358 minecraft:air
setblock 188 71 -358 minecraft:air
setblock 174 71 -357 minecraft:air
fill 178 71 -357 180 71 -357 minecraft:air
fill 177 71 -356 182 71 -356 minecraft:air
fill 178 71 -355 183 71 -355 minecraft:air
fill 179 71 -354 182 71 -354 minecraft:air
setblock 199 71 -354 minecraft:air
setblock 151 71 -353 minecraft:air
setblock 155 71 -353 minecraft:air
fill 179 71 -353 181 71 -353 minecraft:air
fill 186 71 -353 188 71 -353 minecraft:air
setblock 171 71 -352 minecraft:air
fill 175 71 -352 177 71 -352 minecraft:air
fill 179 71 -352 181 71 -352 minecraft:air
fill 186 71 -352 188 71 -352 minecraft:air
setblock 194 71 -352 minecraft:air
setblock 160 71 -351 minecraft:air
setblock 165 71 -351 minecraft:air
fill 170 71 -351 172 71 -351 minecraft:air
fill 175 71 -351 178 71 -351 minecraft:air
fill 186 71 -351 188 71 -351 minecraft:air
setblock 199 71 -351 minecraft:air
setblock 162 71 -350 minecraft:air
setblock 165 71 -350 minecraft:air
fill 169 71 -350 173 71 -350 minecraft:air
fill 175 71 -350 179 71 -350 minecraft:air
setblock 152 71 -349 minecraft:air
fill 170 71 -349 172 71 -349 minecraft:air
setblock 178 71 -349 minecraft:air
setblock 180 71 -349 minecraft:air
setblock 186 71 -349 minecraft:air
setblock 171 71 -348 minecraft:air
fill 179 71 -348 181 71 -348 minecraft:air
fill 178 71 -347 182 71 -347 minecraft:air
fill 179 71 -346 181 71 -346 minecraft:air
setblock 187 71 -346 minecraft:air
setblock 168 71 -345 minecraft:air
setblock 178 71 -345 minecraft:air
setblock 180 71 -345 minecraft:air
setblock 193 71 -345 minecraft:air
fill 177 71 -344 179 71 -344 minecraft:air
setblock 156 71 -343 minecraft:air
fill 176 71 -343 180 71 -343 minecraft:air
setblock 150 71 -342 minecraft:air
fill 177 71 -342 179 71 -342 minecraft:air
setblock 192 71 -342 minecraft:air
setblock 148 71 -341 minecraft:air
setblock 155 71 -341 minecraft:air
fill 178 71 -341 180 71 -341 minecraft:air
setblock 152 71 -340 minecraft:air
fill 177 71 -340 181 71 -340 minecraft:air
fill 178 71 -339 180 71 -339 minecraft:air
setblock 156 71 -338 minecraft:air
setblock 163 71 -338 minecraft:air
fill 179 71 -338 181 71 -338 minecraft:air
setblock 150 71 -337 minecraft:air
setblock 153 71 -337 minecraft:air
setblock 156 71 -337 minecraft:air
setblock 159 71 -337 minecraft:air
setblock 168 71 -337 minecraft:air
fill 178 71 -337 182 71 -337 minecraft:air
setblock 184 71 -337 minecraft:air
setblock 152 71 -336 minecraft:air
setblock 160 71 -336 minecraft:air
setblock 162 71 -336 minecraft:air
fill 179 71 -336 181 71 -336 minecraft:air
fill 183 71 -336 185 71 -336 minecraft:air
setblock 145 71 -335 minecraft:air
fill 148 71 -335 149 71 -335 minecraft:air
fill 151 71 -335 152 71 -335 minecraft:air
setblock 157 71 -335 minecraft:air
setblock 180 71 -335 minecraft:air
fill 182 71 -335 186 71 -335 minecraft:air
setblock 143 71 -334 minecraft:air
setblock 153 71 -334 minecraft:air
setblock 157 71 -334 minecraft:air
setblock 159 71 -334 minecraft:air
setblock 166 71 -334 minecraft:air
fill 148 71 -333 149 71 -333 minecraft:air
fill 155 71 -333 156 71 -333 minecraft:air
fill 158 71 -333 159 71 -333 minecraft:air
setblock 146 71 -332 minecraft:air
setblock 161 71 -332 minecraft:air
setblock 163 71 -332 minecraft:air
setblock 172 71 -332 minecraft:air
setblock 141 71 -331 minecraft:air
setblock 145 71 -331 minecraft:air
setblock 148 71 -331 minecraft:air
fill 152 71 -331 156 71 -331 minecraft:air
setblock 162 71 -331 minecraft:air
setblock 149 71 -330 minecraft:air
fill 151 71 -330 159 71 -330 minecraft:air
fill 162 71 -330 164 71 -330 minecraft:air
setblock 143 71 -329 minecraft:air
setblock 146 71 -329 minecraft:air
setblock 148 71 -329 minecraft:air
fill 150 71 -329 164 71 -329 minecraft:air
fill 149 71 -328 165 71 -328 minecraft:air
fill 171 71 -328 172 71 -328 minecraft:air
fill 148 71 -327 165 71 -327 minecraft:air
setblock 172 71 -327 minecraft:air
fill 148 71 -326 166 71 -326 minecraft:air
setblock 136 71 -325 minecraft:air
setblock 140 71 -325 minecraft:air
setblock 138 71 -324 minecraft:air
setblock 181 72 -382 minecraft:air
fill 191 72 -382 193 72 -382 minecraft:air
fill 191 72 -381 193 72 -381 minecraft:air
fill 191 72 -380 195 72 -380 minecraft:air
setblock 199 72 -380 minecraft:air
setblock 199 72 -379 minecraft:air
setblock 199 72 -378 minecraft:air
fill 187 72 -377 189 72 -377 minecraft:air
setblock 198 72 -377 minecraft:air
fill 187 72 -376 189 72 -376 minecraft:air
fill 197 72 -376 199 72 -376 minecraft:air
fill 178 72 -375 180 72 -375 minecraft:air
fill 187 72 -375 189 72 -375 minecraft:air
setblock 198 72 -375 minecraft:air
setblock 187 72 -371 minecraft:air
setblock 191 72 -371 minecraft:air
setblock 174 72 -370 minecraft:air
setblock 181 72 -370 minecraft:air
fill 186 72 -370 187 72 -370 minecraft:air
fill 190 72 -370 192 72 -370 minecraft:air
fill 173 72 -369 175 72 -369 minecraft:air
fill 180 72 -369 182 72 -369 minecraft:air
setblock 187 72 -369 minecraft:air
setblock 191 72 -369 minecraft:air
setblock 199 72 -369 minecraft:air
setblock 170 72 -368 minecraft:air
setblock 174 72 -368 minecraft:air
setblock 181 72 -368 minecraft:air
fill 169 72 -367 171 72 -367 minecraft:air
fill 182 72 -367 184 72 -367 minecraft:air
setblock 186 72 -367 minecraft:air
fill 168 72 -366 172 72 -366 minecraft:air
fill 182 72 -366 187 72 -366 minecraft:air
fill 169 72 -365 172 72 -365 minecraft:air
setblock 175 72 -365 minecraft:air
fill 182 72 -365 184 72 -365 minecraft:air
setblock 186 72 -365 minecraft:air
setblock 195 72 -365 minecraft:air
setblock 164 72 -364 minecraft:air
fill 170 72 -364 176 72 -364 minecraft:air
fill 189 72 -364 191 72 -364 minecraft:air
fill 163 72 -363 165 72 -363 minecraft:air
fill 170 72 -363 175 72 -363 minecraft:air
fill 189 72 -363 191 72 -363 minecraft:air
setblock 195 72 -363 minecraft:air
setblock 164 72 -362 minecraft:air
fill 171 72 -362 173 72 -362 minecraft:air
fill 189 72 -362 191 72 -362 minecraft:air
fill 194 72 -362 196 72 -362 minecraft:air
setblock 172 72 -361 minecraft:air
fill 187 72 -361 189 72 -361 minecraft:air
fill 192 72 -361 197 72 -361 minecraft:air
setblock 154 72 -360 minecraft:air
fill 187 72 -360 189 72 -360 minecraft:air
fill 191 72 -360 196 72 -360 minecraft:air
fill 153 72 -359 155 72 -359 minecraft:air
fill 187 72 -359 195 72 -359 minecraft:air
fill 152 72 -358 156 72 -358 minecraft:air
setblock 174 72 -358 minecraft:air
fill 191 72 -358 193 72 -358 minecraft:air
fill 153 72 -357 155 72 -357 minecraft:air
fill 178 72 -357 180 72 -357 minecraft:air
setblock 192 72 -357 minecraft:air
setblock 154 72 -356 minecraft:air
fill 178 72 -356 180 72 -356 minecraft:air
fill 178 72 -355 183 72 -355 minecraft:air
setblock 180 72 -354 minecraft:air
setblock 182 72 -354 minecraft:air
setblock 199 72 -354 minecraft:air
setblock 151 72 -353 minecraft:air
setblock 155 72 -353 minecraft:air
fill 179 72 -353 181 72 -353 minecraft:air
setblock 187 72 -353 minecraft:air
setblock 176 72 -352 minecraft:air
setblock 180 72 -352 minecraft:air
fill 186 72 -352 188 72 -352 minecraft:air
setblock 194 72 -352 minecraft:air
setblock 160 72 -351 minecraft:air
fill 170 72 -351 172 72 -351 minecraft:air
fill 175 72 -351 178 72 -351 minecraft:air
fill 186 72 -351 187 72 -351 minecraft:air
setblock 199 72 -351 minecraft:air
setblock 162 72 -350 minecraft:air
setblock 165 72 -350 minecraft:air
fill 170 72 -350 172 72 -350 minecraft:air
fill 176 72 -350 179 72 -350 minecraft:air
fill 185 72 -350 187 72 -350 minecraft:air
setblock 152 72 -349 minecraft:air
fill 170 72 -349 172 72 -349 minecraft:air
fill 184 72 -349 188 72 -349 minecraft:air
fill 179 72 -348 181 72 -348 minecraft:air
fill 185 72 -348 187 72 -348 minecraft:air
fill 179 72 -347 181 72 -347 minecraft:air
fill 186 72 -347 188 72 -347 minecraft:air
fill 179 72 -346 181 72 -346 minecraft:air
fill 185 72 -346 189 72 -346 minecraft:air
setblock 168 72 -345 minecraft:air
fill 186 72 -345 188 72 -345 minecraft:air
setblock 193 72 -345 minecraft:air
fill 177 72 -344 179 72 -344 minecraft:air
setblock 187 72 -344 minecraft:air
setblock 156 72 -343 minecraft:air
fill 177 72 -343 179 72 -343 minecraft:air
setblock 150 72 -342 minecraft:air
fill 177 72 -342 179 72 -342 minecraft:air
setblock 192 72 -342 minecraft:air
setblock 148 72 -341 minecraft:air
setblock 155 72 -341 minecraft:air
fill 178 72 -341 180 72 -341 minecraft:air
setblock 152 72 -340 minecraft:air
fill 178 72 -340 180 72 -340 minecraft:air
fill 178 72 -339 180 72 -339 minecraft:air
setblock 156 72 -338 minecraft:air
setblock 163 72 -338 minecraft:air
fill 179 72 -338 181 72 -338 minecraft:air
setblock 150 72 -337 minecraft:air
setblock 168 72 -337 minecraft:air
fill 179 72 -337 181 72 -337 minecraft:air
fill 179 72 -336 181 72 -336 minecraft:air
fill 183 72 -336 185 72 -336 minecraft:air
setblock 145 72 -335 minecraft:air
setblock 151 72 -335 minecraft:air
setblock 157 72 -335 minecraft:air
fill 183 72 -335 185 72 -335 minecraft:air
setblock 143 72 -334 minecraft:air
setblock 166 72 -334 minecraft:air
setblock 158 72 -333 minecraft:air
setblock 141 72 -331 minecraft:air
setblock 145 72 -331 minecraft:air
setblock 148 72 -331 minecraft:air
setblock 153 72 -331 minecraft:air
setblock 162 72 -331 minecraft:air
fill 154 72 -330 157 72 -330 minecraft:air
setblock 143 72 -329 minecraft:air
setblock 146 72 -329 minecraft:air
setblock 153 72 -329 minecraft:air
fill 158 72 -329 159 72 -329 minecraft:air
fill 163 72 -329 164 72 -329 minecraft:air
setblock 165 72 -328 minecraft:air
setblock 172 72 -328 minecraft:air
setblock 150 72 -327 minecraft:air
setblock 136 72 -325 minecraft:air
setblock 140 72 -325 minecraft:air
setblock 138 72 -324 minecraft:air
setblock 181 73 -382 minecraft:air
setblock 192 73 -382 minecraft:air
fill 191 73 -381 193 73 -381 minecraft:air
setblock 192 73 -380 minecraft:air
setblock 199 73 -379 minecraft:air
setblock 188 73 -377 minecraft:air
fill 187 73 -376 189 73 -376 minecraft:air
fill 198 73 -376 199 73 -376 minecraft:air
setblock 188 73 -375 minecraft:air
setblock 198 73 -375 minecraft:air
setblock 191 73 -371 minecraft:air
setblock 199 73 -371 minecraft:air
setblock 174 73 -370 minecraft:air
setblock 181 73 -370 minecraft:air
setblock 191 73 -370 minecraft:air
fill 198 73 -370 199 73 -370 minecraft:air
fill 173 73 -369 175 73 -369 minecraft:air
setblock 181 73 -369 minecraft:air
fill 197 73 -369 199 73 -369 minecraft:air
setblock 174 73 -368 minecraft:air
setblock 181 73 -368 minecraft:air
fill 198 73 -368 199 73 -368 minecraft:air
fill 169 73 -367 171 73 -367 minecraft:air
setblock 183 73 -367 minecraft:air
setblock 195 73 -367 minecraft:air
setblock 199 73 -367 minecraft:air
fill 169 73 -366 171 73 -366 minecraft:air
fill 182 73 -366 186 73 -366 minecraft:air
fill 194 73 -366 196 73 -366 minecraft:air
fill 169 73 -365 171 73 -365 minecraft:air
setblock 175 73 -365 minecraft:air
setblock 183 73 -365 minecraft:air
fill 193 73 -365 197 73 -365 minecraft:air
setblock 164 73 -364 minecraft:air
fill 171 73 -364 173 73 -364 minecraft:air
fill 175 73 -364 176 73 -364 minecraft:air
setblock 190 73 -364 minecraft:air
fill 194 73 -364 196 73 -364 minecraft:air
setblock 164 73 -363 minecraft:air
fill 171 73 -363 173 73 -363 minecraft:air
setblock 175 73 -363 minecraft:air
fill 189 73 -363 191 73 -363 minecraft:air
setblock 195 73 -363 minecraft:air
fill 171 73 -362 173 73 -362 minecraft:air
setblock 190 73 -362 minecraft:air
fill 194 73 -362 196 73 -362 minecraft:air
setblock 188 73 -361 minecraft:air
fill 194 73 -361 196 73 -361 minecraft:air
fill 187 73 -360 189 73 -360 minecraft:air
fill 191 73 -360 196 73 -360 minecraft:air
fill 153 73 -359 155 73 -359 minecraft:air
setblock 188 73 -359 minecraft:air
fill 191 73 -359 193 73 -359 minecraft:air
fill 153 73 -358 155 73 -358 minecraft:air
fill 191 73 -358 193 73 -358 minecraft:air
fill 153 73 -357 155 73 -357 minecraft:air
setblock 179 73 -357 minecraft:air
fill 178 73 -356 180 73 -356 minecraft:air
setblock 179 73 -355 minecraft:air
setblock 199 73 -354 minecraft:air
setblock 151 73 -353 minecraft:air
setblock 155 73 -353 minecraft:air
setblock 180 73 -353 minecraft:air
setblock 187 73 -353 minecraft:air
setblock 180 73 -352 minecraft:air
fill 186 73 -352 188 73 -352 minecraft:air
setblock 194 73 -352 minecraft:air
setblock 152 73 -351 minecraft:air
setblock 160 73 -351 minecraft:air
setblock 171 73 -351 minecraft:air
fill 175 73 -351 176 73 -351 minecraft:air
setblock 187 73 -351 minecraft:air
setblock 199 73 -351 minecraft:air
fill 151 73 -350 153 73 -350 minecraft:air
setblock 162 73 -350 minecraft:air
setblock 165 73 -350 minecraft:air
fill 170 73 -350 172 73 -350 minecraft:air
setblock 176 73 -350 minecraft:air
fill 185 73 -350 187 73 -350 minecraft:air
fill 150 73 -349 154 73 -349 minecraft:air
setblock 171 73 -349 minecraft:air
fill 185 73 -349 187 73 -349 minecraft:air
fill 151 73 -348 153 73 -348 minecraft:air
setblock 180 73 -348 minecraft:air
fill 185 73 -348 187 73 -348 minecraft:air
setblock 152 73 -347 minecraft:air
fill 179 73 -347 181 73 -347 minecraft:air
fill 186 73 -347 188 73 -347 minecraft:air
setblock 193 73 -347 minecraft:air
setblock 180 73 -346 minecraft:air
fill 186 73 -346 188 73 -346 minecraft:air
fill 192 73 -346 194 73 -346 minecraft:air
setblock 168 73 -345 minecraft:air
fill 186 73 -345 188 73 -345 minecraft:air
fill 191 73 -345 195 73 -345 minecraft:air
setblock 178 73 -344 minecraft:air
fill 192 73 -344 194 73 -344 minecraft:air
setblock 156 73 -343 minecraft:air
fill 177 73 -343 179 73 -343 minecraft:air
setblock 193 73 -343 minecraft:air
setblock 150 73 -342 minecraft:air
setblock 178 73 -342 minecraft:air
setblock 192 73 -342 minecraft:air
setblock 148 73 -341 minecraft:air
setblock 155 73 -341 minecraft:air
setblock 179 73 -341 minecraft:air
setblock 152 73 -340 minecraft:air
fill 178 73 -340 180 73 -340 minecraft:air
setblock 192 73 -340 minecraft:air
setblock 179 73 -339 minecraft:air
setblock 156 73 -338 minecraft:air
setblock 163 73 -338 minecraft:air
setblock 180 73 -338 minecraft:air
setblock 150 73 -337 minecraft:air
setblock 168 73 -337 minecraft:air
fill 179 73 -337 181 73 -337 minecraft:air
setblock 180 73 -336 minecraft:air
setblock 184 73 -336 minecraft:air
setblock 145 73 -335 minecraft:air
setblock 151 73 -335 minecraft:air
setblock 157 73 -335 minecraft:air
fill 183 73 -335 185 73 -335 minecraft:air
setblock 143 73 -334 minecraft:air
setblock 166 73 -334 minecraft:air
setblock 158 73 -333 minecraft:air
setblock 141 73 -331 minecraft:air
setblock 145 73 -331 minecraft:air
setblock 148 73 -331 minecraft:air
setblock 162 73 -331 minecraft:air
setblock 155 73 -330 minecraft:air
setblock 143 73 -329 minecraft:air
setblock 146 73 -329 minecraft:air
setblock 164 73 -329 minecraft:air
setblock 165 73 -328 minecraft:air
setblock 172 73 -328 minecraft:air
setblock 136 73 -326 minecraft:air
setblock 136 73 -325 minecraft:air
setblock 140 73 -325 minecraft:air
setblock 138 73 -324 minecraft:air
fill 191 74 -381 193 74 -381 minecraft:air
setblock 192 74 -380 minecraft:air
fill 187 74 -376 188 74 -376 minecraft:air
fill 198 74 -370 199 74 -370 minecraft:air
fill 198 74 -369 199 74 -369 minecraft:air
fill 198 74 -368 199 74 -368 minecraft:air
setblock 170 74 -367 minecraft:air
setblock 183 74 -367 minecraft:air
fill 169 74 -366 171 74 -366 minecraft:air
fill 182 74 -366 184 74 -366 minecraft:air
fill 194 74 -366 196 74 -366 minecraft:air
setblock 170 74 -365 minecraft:air
fill 194 74 -365 196 74 -365 minecraft:air
setblock 172 74 -364 minecraft:air
fill 194 74 -364 196 74 -364 minecraft:air
fill 171 74 -363 173 74 -363 minecraft:air
fill 189 74 -363 190 74 -363 minecraft:air
setblock 172 74 -362 minecraft:air
setblock 195 74 -362 minecraft:air
setblock 188 74 -361 minecraft:air
fill 194 74 -361 196 74 -361 minecraft:air
fill 188 74 -360 189 74 -360 minecraft:air
setblock 192 74 -360 minecraft:air
setblock 195 74 -360 minecraft:air
setblock 154 74 -359 minecraft:air
fill 191 74 -359 193 74 -359 minecraft:air
fill 153 74 -358 155 74 -358 minecraft:air
setblock 192 74 -358 minecraft:air
setblock 154 74 -357 minecraft:air
setblock 179 74 -356 minecraft:air
setblock 151 74 -355 minecraft:air
setblock 155 74 -355 minecraft:air
setblock 179 74 -355 minecraft:air
fill 150 74 -354 152 74 -354 minecraft:air
fill 154 74 -354 156 74 -354 minecraft:air
setblock 194 74 -354 minecraft:air
setblock 199 74 -354 minecraft:air
fill 149 74 -353 157 74 -353 minecraft:air
setblock 160 74 -353 minecraft:air
fill 193 74 -353 195 74 -353 minecraft:air
setblock 199 74 -353 minecraft:air
fill 150 74 -352 152 74 -352 minecraft:air
fill 154 74 -352 156 74 -352 minecraft:air
fill 159 74 -352 161 74 -352 minecraft:air
fill 192 74 -352 196 74 -352 minecraft:air
fill 198 74 -352 199 74 -352 minecraft:air
setblock 151 74 -351 minecraft:air
setblock 155 74 -351 minecraft:air
fill 158 74 -351 162 74 -351 minecraft:air
fill 193 74 -351 195 74 -351 minecraft:air
fill 197 74 -351 199 74 -351 minecraft:air
fill 151 74 -350 153 74 -350 minecraft:air
fill 159 74 -350 162 74 -350 minecraft:air
setblock 165 74 -350 minecraft:air
fill 170 74 -350 171 74 -350 minecraft:air
setblock 186 74 -350 minecraft:air
setblock 194 74 -350 minecraft:air
fill 198 74 -350 199 74 -350 minecraft:air
fill 151 74 -349 153 74 -349 minecraft:air
setblock 160 74 -349 minecraft:air
fill 185 74 -349 187 74 -349 minecraft:air
setblock 199 74 -349 minecraft:air
fill 151 74 -348 153 74 -348 minecraft:air
setblock 186 74 -348 minecraft:air
fill 180 74 -347 181 74 -347 minecraft:air
setblock 187 74 -347 minecraft:air
setblock 180 74 -346 minecraft:air
fill 186 74 -346 188 74 -346 minecraft:air
fill 192 74 -346 194 74 -346 minecraft:air
setblock 168 74 -345 minecraft:air
setblock 187 74 -345 minecraft:air
fill 192 74 -345 194 74 -345 minecraft:air
setblock 150 74 -344 minecraft:air
setblock 178 74 -344 minecraft:air
fill 192 74 -344 194 74 -344 minecraft:air
fill 149 74 -343 151 74 -343 minecraft:air
setblock 156 74 -343 minecraft:air
fill 177 74 -343 179 74 -343 minecraft:air
fill 191 74 -343 193 74 -343 minecraft:air
fill 148 74 -342 152 74 -342 minecraft:air
fill 190 74 -342 194 74 -342 minecraft:air
fill 148 74 -341 151 74 -341 minecraft:air
setblock 155 74 -341 minecraft:air
fill 191 74 -341 193 74 -341 minecraft:air
setblock 150 74 -340 minecraft:air
setblock 152 74 -340 minecraft:air
fill 178 74 -340 180 74 -340 minecraft:air
setblock 192 74 -340 minecraft:air
setblock 179 74 -339 minecraft:air
setblock 156 74 -338 minecraft:air
setblock 163 74 -338 minecraft:air
setblock 180 74 -338 minecraft:air
setblock 150 74 -337 minecraft:air
setblock 168 74 -337 minecraft:air
setblock 180 74 -337 minecraft:air
setblock 184 74 -336 minecraft:air
setblock 145 74 -335 minecraft:air
setblock 151 74 -335 minecraft:air
setblock 157 74 -335 minecraft:air
fill 184 74 -335 185 74 -335 minecraft:air
setblock 143 74 -334 minecraft:air
setblock 166 74 -334 minecraft:air
setblock 158 74 -333 minecraft:air
setblock 141 74 -331 minecraft:air
setblock 145 74 -331 minecraft:air
setblock 148 74 -331 minecraft:air
setblock 162 74 -331 minecraft:air
setblock 155 74 -330 minecraft:air
setblock 143 74 -329 minecraft:air
setblock 146 74 -329 minecraft:air
setblock 164 74 -329 minecraft:air
setblock 138 74 -326 minecraft:air
fill 136 74 -325 140 74 -325 minecraft:air
fill 136 74 -324 140 74 -324 minecraft:air
fill 137 74 -323 139 74 -323 minecraft:air
setblock 138 74 -322 minecraft:air
setblock 199 75 -370 minecraft:air
fill 198 75 -369 199 75 -369 minecraft:air
setblock 199 75 -368 minecraft:air
setblock 170 75 -366 minecraft:air
setblock 195 75 -366 minecraft:air
fill 194 75 -365 196 75 -365 minecraft:air
setblock 195 75 -364 minecraft:air
fill 171 75 -363 172 75 -363 minecraft:air
setblock 195 75 -362 minecraft:air
fill 194 75 -361 195 75 -361 minecraft:air
setblock 192 75 -360 minecraft:air
setblock 195 75 -360 minecraft:air
fill 191 75 -359 192 75 -359 minecraft:air
fill 153 75 -358 154 75 -358 minecraft:air
setblock 199 75 -356 minecraft:air
fill 198 75 -355 199 75 -355 minecraft:air
fill 150 75 -354 152 75 -354 minecraft:air
fill 154 75 -354 156 75 -354 minecraft:air
fill 197 75 -354 199 75 -354 minecraft:air
fill 150 75 -353 152 75 -353 minecraft:air
fill 154 75 -353 156 75 -353 minecraft:air
fill 193 75 -353 195 75 -353 minecraft:air
fill 198 75 -353 199 75 -353 minecraft:air
fill 150 75 -352 152 75 -352 minecraft:air
fill 154 75 -352 156 75 -352 minecraft:air
fill 159 75 -352 162 75 -352 minecraft:air
setblock 165 75 -352 minecraft:air
fill 193 75 -352 195 75 -352 minecraft:air
fill 198 75 -352 199 75 -352 minecraft:air
fill 159 75 -351 166 75 -351 minecraft:air
fill 193 75 -351 195 75 -351 minecraft:air
fill 198 75 -351 199 75 -351 minecraft:air
setblock 152 75 -350 minecraft:air
fill 159 75 -350 167 75 -350 minecraft:air
fill 198 75 -350 199 75 -350 minecraft:air
fill 151 75 -349 153 75 -349 minecraft:air
fill 161 75 -349 166 75 -349 minecraft:air
fill 185 75 -349 187 75 -349 minecraft:air
setblock 152 75 -348 minecraft:air
setblock 162 75 -348 minecraft:air
setblock 165 75 -348 minecraft:air
setblock 186 75 -348 minecraft:air
setblock 168 75 -347 minecraft:air
fill 167 75 -346 169 75 -346 minecraft:air
fill 187 75 -346 188 75 -346 minecraft:air
setblock 193 75 -346 minecraft:air
setblock 156 75 -345 minecraft:air
fill 166 75 -345 170 75 -345 minecraft:air
setblock 187 75 -345 minecraft:air
fill 192 75 -345 194 75 -345 minecraft:air
fill 155 75 -344 157 75 -344 minecraft:air
fill 167 75 -344 169 75 -344 minecraft:air
setblock 193 75 -344 minecraft:air
fill 148 75 -343 151 75 -343 minecraft:air
fill 154 75 -343 158 75 -343 minecraft:air
setblock 168 75 -343 minecraft:air
fill 191 75 -343 193 75 -343 minecraft:air
fill 147 75 -342 151 75 -342 minecraft:air
fill 154 75 -342 157 75 -342 minecraft:air
fill 191 75 -342 193 75 -342 minecraft:air
fill 146 75 -341 151 75 -341 minecraft:air
fill 153 75 -341 157 75 -341 minecraft:air
fill 191 75 -341 193 75 -341 minecraft:air
fill 147 75 -340 149 75 -340 minecraft:air
setblock 152 75 -340 minecraft:air
fill 154 75 -340 156 75 -340 minecraft:air
setblock 163 75 -340 minecraft:air
setblock 148 75 -339 minecraft:air
setblock 155 75 -339 minecraft:air
fill 162 75 -339 164 75 -339 minecraft:air
setblock 156 75 -338 minecraft:air
fill 161 75 -338 165 75 -338 minecraft:air
setblock 150 75 -337 minecraft:air
fill 162 75 -337 164 75 -337 minecraft:air
setblock 168 75 -337 minecraft:air
setblock 163 75 -336 minecraft:air
setblock 166 75 -336 minecraft:air
setblock 145 75 -335 minecraft:air
setblock 151 75 -335 minecraft:air
setblock 157 75 -335 minecraft:air
fill 165 75 -335 167 75 -335 minecraft:air
setblock 143 75 -334 minecraft:air
fill 164 75 -334 168 75 -334 minecraft:air
setblock 141 75 -333 minecraft:air
setblock 158 75 -333 minecraft:air
fill 165 75 -333 167 75 -333 minecraft:air
fill 140 75 -332 142 75 -332 minecraft:air
setblock 166 75 -332 minecraft:air
fill 139 75 -331 143 75 -331 minecraft:air
setblock 145 75 -331 minecraft:air
setblock 148 75 -331 minecraft:air
setblock 162 75 -331 minecraft:air
fill 140 75 -330 144 75 -330 minecraft:air
setblock 155 75 -330 minecraft:air
fill 141 75 -329 146 75 -329 minecraft:air
setblock 164 75 -329 minecraft:air
fill 142 75 -328 144 75 -328 minecraft:air
setblock 143 75 -327 minecraft:air
fill 136 75 -325 140 75 -325 minecraft:air
fill 137 75 -324 139 75 -324 minecraft:air
fill 137 75 -323 139 75 -323 minecraft:air
setblock 136 75 -320 minecraft:air
setblock 199 76 -370 minecraft:air
setblock 199 76 -369 minecraft:air
setblock 195 76 -366 minecraft:air
fill 195 76 -365 196 76 -365 minecraft:air
fill 198 76 -355 199 76 -355 minecraft:air
setblock 151 76 -354 minecraft:air
setblock 155 76 -354 minecraft:air
fill 198 76 -354 199 76 -354 minecraft:air
fill 150 76 -353 152 76 -353 minecraft:air
fill 154 76 -353 156 76 -353 minecraft:air
setblock 194 76 -353 minecraft:air
fill 198 76 -353 199 76 -353 minecraft:air
setblock 151 76 -352 minecraft:air
setblock 155 76 -352 minecraft:air
setblock 160 76 -352 minecraft:air
fill 193 76 -352 195 76 -352 minecraft:air
setblock 199 76 -352 minecraft:air
fill 159 76 -351 166 76 -351 minecraft:air
setblock 194 76 -351 minecraft:air
fill 198 76 -351 199 76 -351 minecraft:air
setblock 152 76 -350 minecraft:air
fill 160 76 -350 166 76 -350 minecraft:air
setblock 199 76 -350 minecraft:air
fill 151 76 -349 152 76 -349 minecraft:air
fill 161 76 -349 166 76 -349 minecraft:air
fill 167 76 -346 169 76 -346 minecraft:air
setblock 193 76 -346 minecraft:air
fill 167 76 -345 169 76 -345 minecraft:air
fill 193 76 -345 194 76 -345 minecraft:air
fill 155 76 -344 157 76 -344 minecraft:air
fill 167 76 -344 169 76 -344 minecraft:air
setblock 150 76 -343 minecraft:air
fill 155 76 -343 157 76 -343 minecraft:air
setblock 192 76 -343 minecraft:air
fill 147 76 -342 152 76 -342 minecraft:air
fill 154 76 -342 157 76 -342 minecraft:air
fill 191 76 -342 193 76 -342 minecraft:air
fill 147 76 -341 156 76 -341 minecraft:air
setblock 192 76 -341 minecraft:air
fill 147 76 -340 156 76 -340 minecraft:air
fill 151 76 -339 153 76 -339 minecraft:air
fill 155 76 -339 157 76 -339 minecraft:air
fill 162 76 -339 164 76 -339 minecraft:air
setblock 152 76 -338 minecraft:air
fill 154 76 -338 158 76 -338 minecraft:air
fill 162 76 -338 164 76 -338 minecraft:air
fill 150 76 -337 151 76 -337 minecraft:air
fill 155 76 -337 157 76 -337 minecraft:air
fill 162 76 -337 164 76 -337 minecraft:air
setblock 168 76 -337 minecraft:air
fill 150 76 -336 152 76 -336 minecraft:air
fill 156 76 -336 158 76 -336 minecraft:air
setblock 145 76 -335 minecraft:air
fill 149 76 -335 153 76 -335 minecraft:air
fill 155 76 -335 159 76 -335 minecraft:air
fill 165 76 -335 167 76 -335 minecraft:air
setblock 143 76 -334 minecraft:air
fill 150 76 -334 152 76 -334 minecraft:air
fill 156 76 -334 159 76 -334 minecraft:air
fill 165 76 -334 167 76 -334 minecraft:air
setblock 145 76 -333 minecraft:air
setblock 148 76 -333 minecraft:air
setblock 151 76 -333 minecraft:air
fill 156 76 -333 160 76 -333 minecraft:air
fill 165 76 -333 167 76 -333 minecraft:air
fill 140 76 -332 142 76 -332 minecraft:air
fill 144 76 -332 149 76 -332 minecraft:air
fill 157 76 -332 159 76 -332 minecraft:air
fill 140 76 -331 150 76 -331 minecraft:air
setblock 158 76 -331 minecraft:air
setblock 162 76 -331 minecraft:air
fill 140 76 -330 149 76 -330 minecraft:air
setblock 155 76 -330 minecraft:air
fill 142 76 -329 146 76 -329 minecraft:air
setblock 148 76 -329 minecraft:air
setblock 164 76 -329 minecraft:air
fill 142 76 -328 144 76 -328 minecraft:air
setblock 136 76 -327 minecraft:air
setblock 140 76 -327 minecraft:air
setblock 143 76 -327 minecraft:air
fill 136 76 -326 137 76 -326 minecraft:air
fill 139 76 -326 144 76 -326 minecraft:air
fill 136 76 -325 142 76 -325 minecraft:air
fill 136 76 -324 142 76 -324 minecraft:air
setblock 136 76 -323 minecraft:air
setblock 138 76 -323 minecraft:air
setblock 140 76 -323 minecraft:air
setblock 199 77 -355 minecraft:air
fill 198 77 -354 199 77 -354 minecraft:air
setblock 151 77 -353 minecraft:air
fill 154 77 -353 155 77 -353 minecraft:air
setblock 194 77 -353 minecraft:air
setblock 199 77 -353 minecraft:air
fill 193 77 -352 194 77 -352 minecraft:air
setblock 199 77 -352 minecraft:air
setblock 160 77 -351 minecraft:air
setblock 162 77 -351 minecraft:air
setblock 165 77 -351 minecraft:air
setblock 199 77 -351 minecraft:air
fill 161 77 -350 166 77 -350 minecraft:air
setblock 199 77 -350 minecraft:air
setblock 162 77 -349 minecraft:air
setblock 165 77 -349 minecraft:air
setblock 168 77 -346 minecraft:air
fill 167 77 -345 169 77 -345 minecraft:air
setblock 156 77 -344 minecraft:air
setblock 168 77 -344 minecraft:air
setblock 150 77 -343 minecraft:air
fill 155 77 -343 157 77 -343 minecraft:air
setblock 148 77 -342 minecraft:air
setblock 150 77 -342 minecraft:air
fill 155 77 -342 156 77 -342 minecraft:air
fill 192 77 -342 193 77 -342 minecraft:air
fill 147 77 -341 156 77 -341 minecraft:air
setblock 192 77 -341 minecraft:air
setblock 148 77 -340 minecraft:air
fill 151 77 -340 153 77 -340 minecraft:air
setblock 155 77 -340 minecraft:air
fill 151 77 -339 153 77 -339 minecraft:air
fill 155 77 -339 157 77 -339 minecraft:air
setblock 163 77 -339 minecraft:air
setblock 168 77 -339 minecraft:air
fill 155 77 -338 157 77 -338 minecraft:air
fill 162 77 -338 164 77 -338 minecraft:air
fill 167 77 -338 169 77 -338 minecraft:air
setblock 150 77 -337 minecraft:air
fill 155 77 -337 157 77 -337 minecraft:air
setblock 163 77 -337 minecraft:air
fill 166 77 -337 170 77 -337 minecraft:air
setblock 143 77 -336 minecraft:air
fill 150 77 -336 152 77 -336 minecraft:air
fill 156 77 -336 158 77 -336 minecraft:air
fill 167 77 -336 169 77 -336 minecraft:air
fill 142 77 -335 145 77 -335 minecraft:air
fill 150 77 -335 152 77 -335 minecraft:air
fill 156 77 -335 158 77 -335 minecraft:air
setblock 166 77 -335 minecraft:air
setblock 168 77 -335 minecraft:air
fill 141 77 -334 145 77 -334 minecraft:air
fill 150 77 -334 152 77 -334 minecraft:air
fill 156 77 -334 159 77 -334 minecraft:air
fill 165 77 -334 167 77 -334 minecraft:air
fill 142 77 -333 144 77 -333 minecraft:air
fill 157 77 -333 159 77 -333 minecraft:air
setblock 166 77 -333 minecraft:air
setblock 141 77 -332 minecraft:air
fill 143 77 -332 149 77 -332 minecraft:air
fill 157 77 -332 159 77 -332 minecraft:air
fill 140 77 -331 142 77 -331 minecraft:air
fill 144 77 -331 149 77 -331 minecraft:air
setblock 162 77 -331 minecraft:air
setblock 141 77 -330 minecraft:air
fill 143 77 -330 149 77 -330 minecraft:air
setblock 155 77 -330 minecraft:air
fill 142 77 -329 148 77 -329 minecraft:air
setblock 164 77 -329 minecraft:air
setblock 143 77 -328 minecraft:air
fill 145 77 -328 147 77 -328 minecraft:air
setblock 146 77 -327 minecraft:air
fill 136 77 -326 137 77 -326 minecraft:air
fill 139 77 -326 144 77 -326 minecraft:air
fill 136 77 -325 137 77 -325 minecraft:air
fill 139 77 -325 142 77 -325 minecraft:air
fill 136 77 -324 142 77 -324 minecraft:air
setblock 199 78 -355 minecraft:air
setblock 199 78 -354 minecraft:air
setblock 162 78 -351 minecraft:air
setblock 165 78 -351 minecraft:air
fill 161 78 -350 166 78 -350 minecraft:air
setblock 165 78 -349 minecraft:air
fill 167 78 -345 169 78 -345 minecraft:air
fill 155 78 -343 157 78 -343 minecraft:air
setblock 156 78 -342 minecraft:air
fill 147 78 -341 149 78 -341 minecraft:air
setblock 152 78 -341 minecraft:air
setblock 155 78 -341 minecraft:air
setblock 148 78 -340 minecraft:air
fill 151 78 -340 153 78 -340 minecraft:air
setblock 155 78 -340 minecraft:air
setblock 150 78 -339 minecraft:air
setblock 152 78 -339 minecraft:air
setblock 156 78 -339 minecraft:air
setblock 163 78 -339 minecraft:air
fill 149 78 -338 151 78 -338 minecraft:air
fill 155 78 -338 157 78 -338 minecraft:air
fill 163 78 -338 164 78 -338 minecraft:air
fill 167 78 -338 169 78 -338 minecraft:air
setblock 145 78 -337 minecraft:air
fill 148 78 -337 152 78 -337 minecraft:air
setblock 156 78 -337 minecraft:air
fill 167 78 -337 169 78 -337 minecraft:air
fill 144 78 -336 146 78 -336 minecraft:air
fill 149 78 -336 151 78 -336 minecraft:air
setblock 157 78 -336 minecraft:air
fill 167 78 -336 169 78 -336 minecraft:air
fill 142 78 -335 147 78 -335 minecraft:air
fill 150 78 -335 152 78 -335 minecraft:air
fill 156 78 -335 158 78 -335 minecraft:air
setblock 166 78 -335 minecraft:air
fill 142 78 -334 146 78 -334 minecraft:air
setblock 151 78 -334 minecraft:air
fill 157 78 -334 158 78 -334 minecraft:air
fill 165 78 -334 167 78 -334 minecraft:air
fill 142 78 -333 145 78 -333 minecraft:air
fill 157 78 -333 159 78 -333 minecraft:air
setblock 162 78 -333 minecraft:air
setblock 141 78 -332 minecraft:air
setblock 145 78 -332 minecraft:air
setblock 148 78 -332 minecraft:air
setblock 155 78 -332 minecraft:air
setblock 158 78 -332 minecraft:air
fill 161 78 -332 163 78 -332 minecraft:air
fill 140 78 -331 142 78 -331 minecraft:air
fill 144 78 -331 149 78 -331 minecraft:air
fill 154 78 -331 156 78 -331 minecraft:air
fill 160 78 -331 164 78 -331 minecraft:air
setblock 141 78 -330 minecraft:air
fill 145 78 -330 148 78 -330 minecraft:air
fill 153 78 -330 157 78 -330 minecraft:air
fill 161 78 -330 163 78 -330 minecraft:air
fill 143 78 -329 147 78 -329 minecraft:air
fill 154 78 -329 156 78 -329 minecraft:air
setblock 162 78 -329 minecraft:air
setblock 164 78 -329 minecraft:air
fill 145 78 -328 147 78 -328 minecraft:air
setblock 155 78 -328 minecraft:air
setblock 164 78 -327 minecraft:air
setblock 136 78 -326 minecraft:air
setblock 140 78 -326 minecraft:air
setblock 143 78 -326 minecraft:air
fill 163 78 -326 165 78 -326 minecraft:air
fill 136 78 -325 137 78 -325 minecraft:air
fill 139 78 -325 142 78 -325 minecraft:air
setblock 136 78 -324 minecraft:air
setblock 140 78 -324 minecraft:air
fill 152 79 -340 153 79 -340 minecraft:air
setblock 152 79 -339 minecraft:air
setblock 156 79 -339 minecraft:air
fill 149 79 -338 151 79 -338 minecraft:air
fill 155 79 -338 156 79 -338 minecraft:air
setblock 168 79 -338 minecraft:air
fill 149 79 -337 151 79 -337 minecraft:air
fill 167 79 -337 169 79 -337 minecraft:air
fill 144 79 -336 146 79 -336 minecraft:air
fill 149 79 -336 151 79 -336 minecraft:air
setblock 168 79 -336 minecraft:air
fill 143 79 -335 146 79 -335 minecraft:air
fill 151 79 -335 152 79 -335 minecraft:air
fill 157 79 -335 158 79 -335 minecraft:air
fill 142 79 -334 146 79 -334 minecraft:air
setblock 151 79 -334 minecraft:air
setblock 143 79 -333 minecraft:air
fill 158 79 -333 159 79 -333 minecraft:air
setblock 145 79 -332 minecraft:air
setblock 148 79 -332 minecraft:air
fill 161 79 -332 163 79 -332 minecraft:air
fill 144 79 -331 145 79 -331 minecraft:air
fill 147 79 -331 149 79 -331 minecraft:air
fill 154 79 -331 156 79 -331 minecraft:air
fill 161 79 -331 164 79 -331 minecraft:air
setblock 146 79 -330 minecraft:air
fill 154 79 -330 156 79 -330 minecraft:air
fill 161 79 -330 165 79 -330 minecraft:air
fill 145 79 -329 147 79 -329 minecraft:air
fill 154 79 -329 156 79 -329 minecraft:air
fill 162 79 -329 166 79 -329 minecraft:air
setblock 146 79 -328 minecraft:air
fill 163 79 -328 165 79 -328 minecraft:air
setblock 164 79 -327 minecraft:air
setblock 136 79 -326 minecraft:air
fill 163 79 -326 165 79 -326 minecraft:air
fill 136 79 -325 137 79 -325 minecraft:air
fill 139 79 -325 141 79 -325 minecraft:air
setblock 150 80 -338 minecraft:air
setblock 168 80 -338 minecraft:air
fill 149 80 -337 151 80 -337 minecraft:air
setblock 168 80 -337 minecraft:air
setblock 145 80 -336 minecraft:air
setblock 150 80 -336 minecraft:air
setblock 168 80 -336 minecraft:air
fill 144 80 -335 146 80 -335 minecraft:air
fill 143 80 -334 145 80 -334 minecraft:air
setblock 143 80 -333 minecraft:air
setblock 162 80 -332 minecraft:air
setblock 155 80 -331 minecraft:air
fill 161 80 -331 163 80 -331 minecraft:air
setblock 146 80 -330 minecraft:air
fill 154 80 -330 156 80 -330 minecraft:air
fill 162 80 -330 165 80 -330 minecraft:air
fill 146 80 -329 147 80 -329 minecraft:air
setblock 155 80 -329 minecraft:air
fill 163 80 -329 165 80 -329 minecraft:air
setblock 146 80 -328 minecraft:air
fill 163 80 -328 165 80 -328 minecraft:air
setblock 164 80 -326 minecraft:air
fill 149 81 -337 150 81 -337 minecraft:air
setblock 150 81 -336 minecraft:air
fill 144 81 -335 145 81 -335 minecraft:air
setblock 145 81 -334 minecraft:air
fill 161 81 -331 163 81 -331 minecraft:air
fill 155 81 -330 156 81 -330 minecraft:air
setblock 162 81 -330 minecraft:air
setblock 164 81 -330 minecraft:air
setblock 155 81 -329 minecraft:air
fill 163 81 -329 165 81 -329 minecraft:air
setblock 164 81 -328 minecraft:air
setblock 164 82 -330 minecraft:air
fill 164 82 -329 165 82 -329 minecraft:air
forceload remove 136 -382 199 -319
tellraw @a {"text":"Campus bau a10 fertig.","color":"green"}
