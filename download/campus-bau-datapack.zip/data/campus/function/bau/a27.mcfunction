# Abschnitt a27: x 328..391, z -254..-191 (18047 Blöcke)
forceload add 328 -254 391 -191
tellraw @a {"text":"Campus bau a27: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a27_1 2s
