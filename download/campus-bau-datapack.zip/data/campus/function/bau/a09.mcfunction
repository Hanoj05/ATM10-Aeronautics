# Abschnitt a09: x 72..135, z -382..-319 (37720 Blöcke)
forceload add 72 -382 135 -319
tellraw @a {"text":"Campus bau a09: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a09_1 2s
