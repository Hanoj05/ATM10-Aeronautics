# Abschnitt a19: x 264..327, z -318..-255 (7595 Blöcke)
forceload add 264 -318 327 -255
tellraw @a {"text":"Campus bau a19: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a19_1 2s
