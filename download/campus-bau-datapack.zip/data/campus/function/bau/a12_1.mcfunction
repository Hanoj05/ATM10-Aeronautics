fill 276 45 -377 280 45 -377 minecraft:stone
fill 275 45 -376 280 45 -376 minecraft:stone
fill 275 45 -375 279 45 -375 minecraft:stone
fill 276 45 -374 277 45 -374 minecraft:stone
fill 275 45 -330 276 45 -330 minecraft:stone
fill 275 45 -329 277 45 -329 minecraft:stone
setblock 276 45 -328 minecraft:stone
setblock 309 45 -323 minecraft:stone
fill 310 45 -322 311 45 -322 minecraft:stone
fill 310 45 -321 313 45 -321 minecraft:stone
fill 310 45 -320 315 45 -320 minecraft:stone
fill 312 45 -319 316 45 -319 minecraft:stone
setblock 283 46 -379 minecraft:stone
fill 279 46 -378 282 46 -378 minecraft:stone
fill 278 46 -377 282 46 -377 minecraft:stone
fill 278 46 -376 281 46 -376 minecraft:stone
fill 276 46 -375 280 46 -375 minecraft:stone
fill 278 46 -374 279 46 -374 minecraft:stone
setblock 275 46 -331 minecraft:stone
fill 274 46 -330 276 46 -330 minecraft:stone
fill 275 46 -329 276 46 -329 minecraft:stone
setblock 306 46 -324 minecraft:stone
fill 306 46 -323 309 46 -323 minecraft:stone
fill 307 46 -322 311 46 -322 minecraft:stone
fill 307 46 -321 312 46 -321 minecraft:stone
fill 309 46 -320 313 46 -320 minecraft:stone
fill 311 46 -319 314 46 -319 minecraft:stone
setblock 283 47 -380 minecraft:stone
fill 281 47 -379 283 47 -379 minecraft:stone
fill 281 47 -378 283 47 -378 minecraft:stone
fill 280 47 -377 283 47 -377 minecraft:stone
fill 279 47 -376 282 47 -376 minecraft:stone
fill 278 47 -375 281 47 -375 minecraft:stone
fill 279 47 -374 281 47 -374 minecraft:stone
setblock 280 47 -373 minecraft:stone
setblock 275 47 -331 minecraft:stone
fill 274 47 -330 275 47 -330 minecraft:stone
setblock 275 47 -329 minecraft:stone
setblock 304 47 -325 minecraft:stone
fill 304 47 -324 306 47 -324 minecraft:stone
fill 304 47 -323 308 47 -323 minecraft:stone
fill 305 47 -322 309 47 -322 minecraft:stone
fill 307 47 -321 309 47 -321 minecraft:stone
fill 309 47 -320 310 47 -320 minecraft:stone
setblock 311 47 -319 minecraft:stone
setblock 283 48 -380 minecraft:stone
setblock 283 48 -379 minecraft:stone
setblock 285 48 -379 minecraft:stone
fill 282 48 -378 283 48 -378 minecraft:stone
fill 281 48 -377 283 48 -377 minecraft:stone
fill 281 48 -376 282 48 -376 minecraft:stone
fill 280 48 -375 282 48 -375 minecraft:stone
fill 280 48 -374 282 48 -374 minecraft:stone
setblock 274 48 -331 minecraft:stone
fill 274 48 -330 275 48 -330 minecraft:stone
fill 274 48 -329 275 48 -329 minecraft:stone
setblock 302 48 -326 minecraft:stone
fill 302 48 -325 303 48 -325 minecraft:stone
fill 301 48 -324 305 48 -324 minecraft:stone
fill 302 48 -323 306 48 -323 minecraft:stone
fill 304 48 -322 306 48 -322 minecraft:stone
setblock 306 48 -321 minecraft:stone
fill 286 49 -382 287 49 -382 minecraft:stone
setblock 286 49 -381 minecraft:stone
fill 285 49 -380 286 49 -380 minecraft:stone
setblock 283 49 -379 minecraft:stone
setblock 285 49 -379 minecraft:stone
setblock 283 49 -378 minecraft:stone
setblock 285 49 -378 minecraft:stone
setblock 282 49 -377 minecraft:stone
setblock 282 49 -376 minecraft:stone
setblock 284 49 -376 minecraft:stone
fill 281 49 -375 282 49 -375 minecraft:stone
fill 281 49 -374 282 49 -374 minecraft:stone
fill 273 49 -331 274 49 -331 minecraft:stone
fill 273 49 -330 275 49 -330 minecraft:stone
setblock 274 49 -329 minecraft:stone
fill 301 49 -326 302 49 -326 minecraft:stone
fill 300 49 -325 303 49 -325 minecraft:stone
fill 300 49 -324 304 49 -324 minecraft:stone
fill 302 49 -323 304 49 -323 minecraft:stone
fill 303 49 -322 304 49 -322 minecraft:stone
fill 286 50 -382 288 50 -382 minecraft:stone
fill 285 50 -381 287 50 -381 minecraft:stone
fill 285 50 -380 287 50 -380 minecraft:stone
fill 285 50 -379 286 50 -379 minecraft:stone
fill 285 50 -378 286 50 -378 minecraft:stone
fill 284 50 -377 285 50 -377 minecraft:stone
fill 284 50 -376 285 50 -376 minecraft:stone
setblock 282 50 -375 minecraft:stone
setblock 284 50 -375 minecraft:stone
setblock 281 50 -374 minecraft:stone
fill 273 50 -331 274 50 -331 minecraft:stone
fill 273 50 -330 275 50 -330 minecraft:stone
setblock 274 50 -329 minecraft:stone
setblock 300 50 -327 minecraft:stone
fill 299 50 -326 301 50 -326 minecraft:stone
fill 299 50 -325 302 50 -325 minecraft:stone
fill 300 50 -324 302 50 -324 minecraft:stone
fill 301 50 -323 302 50 -323 minecraft:stone
fill 286 51 -382 288 51 -382 minecraft:stone
fill 286 51 -381 288 51 -381 minecraft:stone
fill 286 51 -380 287 51 -380 minecraft:stone
fill 285 51 -379 287 51 -379 minecraft:stone
fill 285 51 -378 286 51 -378 minecraft:stone
fill 284 51 -377 286 51 -377 minecraft:stone
fill 284 51 -376 285 51 -376 minecraft:stone
fill 284 51 -375 285 51 -375 minecraft:stone
setblock 284 51 -374 minecraft:stone
fill 283 51 -373 284 51 -373 minecraft:stone
setblock 283 51 -372 minecraft:stone
setblock 273 51 -332 minecraft:stone
fill 272 51 -331 274 51 -331 minecraft:stone
fill 273 51 -330 274 51 -330 minecraft:stone
fill 298 51 -327 300 51 -327 minecraft:stone
fill 297 51 -326 301 51 -326 minecraft:stone
fill 298 51 -325 301 51 -325 minecraft:stone
fill 299 51 -324 300 51 -324 minecraft:stone
fill 287 52 -382 289 52 -382 minecraft:stone
fill 287 52 -381 288 52 -381 minecraft:stone
fill 286 52 -380 288 52 -380 minecraft:stone
fill 286 52 -379 288 52 -379 minecraft:stone
fill 285 52 -378 287 52 -378 minecraft:stone
fill 285 52 -377 287 52 -377 minecraft:stone
fill 284 52 -376 286 52 -376 minecraft:stone
fill 284 52 -375 286 52 -375 minecraft:stone
fill 283 52 -374 285 52 -374 minecraft:stone
setblock 284 52 -373 minecraft:stone
fill 283 52 -372 284 52 -372 minecraft:stone
setblock 283 52 -371 minecraft:stone
fill 264 52 -332 266 52 -332 minecraft:stone
setblock 273 52 -332 minecraft:stone
fill 264 52 -331 267 52 -331 minecraft:stone
fill 272 52 -331 273 52 -331 minecraft:stone
fill 264 52 -330 267 52 -330 minecraft:stone
fill 273 52 -330 274 52 -330 minecraft:stone
fill 264 52 -329 268 52 -329 minecraft:stone
fill 264 52 -328 267 52 -328 minecraft:stone
setblock 298 52 -328 minecraft:stone
fill 264 52 -327 267 52 -327 minecraft:stone
fill 297 52 -327 299 52 -327 minecraft:stone
fill 264 52 -326 267 52 -326 minecraft:stone
fill 297 52 -326 300 52 -326 minecraft:stone
fill 264 52 -325 267 52 -325 minecraft:stone
fill 298 52 -325 299 52 -325 minecraft:stone
fill 264 52 -324 267 52 -324 minecraft:stone
fill 264 52 -323 267 52 -323 minecraft:stone
fill 264 52 -322 267 52 -322 minecraft:stone
fill 264 52 -321 267 52 -321 minecraft:stone
fill 264 52 -320 267 52 -320 minecraft:stone
fill 264 52 -319 266 52 -319 minecraft:stone
fill 288 53 -382 289 53 -382 minecraft:stone
fill 287 53 -381 289 53 -381 minecraft:stone
fill 287 53 -380 289 53 -380 minecraft:stone
fill 286 53 -379 288 53 -379 minecraft:stone
fill 286 53 -378 288 53 -378 minecraft:stone
fill 286 53 -377 287 53 -377 minecraft:stone
fill 285 53 -376 287 53 -376 minecraft:stone
fill 285 53 -375 286 53 -375 minecraft:stone
fill 284 53 -374 286 53 -374 minecraft:stone
fill 283 53 -373 285 53 -373 minecraft:stone
fill 283 53 -372 284 53 -372 minecraft:stone
fill 283 53 -371 284 53 -371 minecraft:stone
setblock 283 53 -370 minecraft:stone
fill 265 53 -334 267 53 -334 minecraft:stone
fill 264 53 -333 268 53 -333 minecraft:stone
fill 264 53 -332 269 53 -332 minecraft:stone
setblock 272 53 -332 minecraft:stone
fill 264 53 -331 269 53 -331 minecraft:stone
fill 272 53 -331 273 53 -331 minecraft:stone
fill 264 53 -330 269 53 -330 minecraft:stone
fill 272 53 -330 273 53 -330 minecraft:stone
fill 264 53 -329 268 53 -329 minecraft:stone
fill 264 53 -328 268 53 -328 minecraft:stone
fill 297 53 -328 298 53 -328 minecraft:stone
fill 264 53 -327 267 53 -327 minecraft:stone
fill 295 53 -327 299 53 -327 minecraft:stone
fill 264 53 -326 267 53 -326 minecraft:stone
fill 296 53 -326 298 53 -326 minecraft:stone
fill 264 53 -325 267 53 -325 minecraft:stone
fill 297 53 -325 298 53 -325 minecraft:stone
fill 264 53 -324 267 53 -324 minecraft:stone
fill 264 53 -323 267 53 -323 minecraft:stone
fill 264 53 -322 267 53 -322 minecraft:stone
fill 264 53 -321 267 53 -321 minecraft:stone
fill 264 53 -320 267 53 -320 minecraft:stone
fill 264 53 -319 267 53 -319 minecraft:stone
fill 288 54 -382 290 54 -382 minecraft:stone
fill 288 54 -381 290 54 -381 minecraft:stone
fill 288 54 -380 289 54 -380 minecraft:stone
fill 287 54 -379 289 54 -379 minecraft:stone
fill 287 54 -378 288 54 -378 minecraft:stone
fill 286 54 -377 288 54 -377 minecraft:stone
fill 286 54 -376 288 54 -376 minecraft:stone
fill 285 54 -375 287 54 -375 minecraft:stone
fill 285 54 -374 286 54 -374 minecraft:stone
fill 284 54 -373 286 54 -373 minecraft:stone
fill 283 54 -372 285 54 -372 minecraft:stone
fill 282 54 -371 284 54 -371 minecraft:stone
setblock 283 54 -370 minecraft:stone
fill 264 54 -337 265 54 -337 minecraft:stone
fill 264 54 -336 266 54 -336 minecraft:stone
fill 264 54 -335 266 54 -335 minecraft:stone
fill 264 54 -334 268 54 -334 minecraft:stone
fill 264 54 -333 269 54 -333 minecraft:stone
fill 264 54 -332 269 54 -332 minecraft:stone
fill 271 54 -332 272 54 -332 minecraft:stone
fill 264 54 -331 273 54 -331 minecraft:stone
fill 264 54 -330 270 54 -330 minecraft:stone
setblock 272 54 -330 minecraft:stone
fill 264 54 -329 271 54 -329 minecraft:stone
setblock 297 54 -329 minecraft:stone
fill 264 54 -328 272 54 -328 minecraft:stone
fill 295 54 -328 298 54 -328 minecraft:stone
fill 264 54 -327 272 54 -327 minecraft:stone
fill 295 54 -327 298 54 -327 minecraft:stone
fill 264 54 -326 273 54 -326 minecraft:stone
fill 296 54 -326 297 54 -326 minecraft:stone
fill 264 54 -325 273 54 -325 minecraft:stone
fill 264 54 -324 274 54 -324 minecraft:stone
fill 264 54 -323 267 54 -323 minecraft:stone
fill 269 54 -323 274 54 -323 minecraft:stone
fill 264 54 -322 267 54 -322 minecraft:stone
fill 269 54 -322 273 54 -322 minecraft:stone
fill 264 54 -321 267 54 -321 minecraft:stone
fill 270 54 -321 272 54 -321 minecraft:stone
fill 264 54 -320 267 54 -320 minecraft:stone
fill 264 54 -319 267 54 -319 minecraft:stone
fill 289 55 -382 291 55 -382 minecraft:stone
fill 289 55 -381 290 55 -381 minecraft:stone
fill 288 55 -380 290 55 -380 minecraft:stone
fill 288 55 -379 289 55 -379 minecraft:stone
fill 287 55 -378 289 55 -378 minecraft:stone
fill 287 55 -377 289 55 -377 minecraft:stone
fill 287 55 -376 288 55 -376 minecraft:stone
fill 286 55 -375 288 55 -375 minecraft:stone
fill 285 55 -374 287 55 -374 minecraft:stone
fill 285 55 -373 287 55 -373 minecraft:stone
fill 284 55 -372 286 55 -372 minecraft:stone
fill 283 55 -371 285 55 -371 minecraft:stone
fill 282 55 -370 284 55 -370 minecraft:stone
setblock 283 55 -369 minecraft:stone
fill 271 55 -347 272 55 -347 minecraft:stone
fill 271 55 -346 272 55 -346 minecraft:stone
setblock 264 55 -339 minecraft:stone
fill 264 55 -338 265 55 -338 minecraft:stone
fill 264 55 -337 266 55 -337 minecraft:stone
fill 264 55 -336 266 55 -336 minecraft:stone
fill 264 55 -335 267 55 -335 minecraft:stone
fill 264 55 -334 268 55 -334 minecraft:stone
fill 264 55 -333 269 55 -333 minecraft:stone
fill 264 55 -332 272 55 -332 minecraft:stone
fill 264 55 -331 273 55 -331 minecraft:stone
fill 264 55 -330 270 55 -330 minecraft:stone
fill 264 55 -329 271 55 -329 minecraft:stone
fill 295 55 -329 297 55 -329 minecraft:stone
fill 264 55 -328 272 55 -328 minecraft:stone
fill 294 55 -328 297 55 -328 minecraft:stone
fill 264 55 -327 272 55 -327 minecraft:stone
fill 295 55 -327 297 55 -327 minecraft:stone
fill 264 55 -326 273 55 -326 minecraft:stone
setblock 296 55 -326 minecraft:stone
fill 264 55 -325 274 55 -325 minecraft:stone
fill 264 55 -324 274 55 -324 minecraft:stone
fill 264 55 -323 274 55 -323 minecraft:stone
fill 264 55 -322 267 55 -322 minecraft:stone
fill 269 55 -322 276 55 -322 minecraft:stone
fill 264 55 -321 267 55 -321 minecraft:stone
fill 270 55 -321 277 55 -321 minecraft:stone
fill 264 55 -320 267 55 -320 minecraft:stone
fill 272 55 -320 278 55 -320 minecraft:stone
fill 264 55 -319 267 55 -319 minecraft:stone
fill 272 55 -319 279 55 -319 minecraft:stone
fill 290 56 -382 291 56 -382 minecraft:stone
fill 289 56 -381 291 56 -381 minecraft:stone
fill 289 56 -380 290 56 -380 minecraft:stone
fill 288 56 -379 290 56 -379 minecraft:stone
fill 288 56 -378 290 56 -378 minecraft:stone
fill 288 56 -377 289 56 -377 minecraft:stone
fill 287 56 -376 289 56 -376 minecraft:stone
fill 287 56 -375 288 56 -375 minecraft:stone
fill 286 56 -374 288 56 -374 minecraft:stone
fill 286 56 -373 287 56 -373 minecraft:stone
fill 285 56 -372 287 56 -372 minecraft:stone
fill 284 56 -371 286 56 -371 minecraft:stone
fill 283 56 -370 285 56 -370 minecraft:stone
fill 282 56 -369 284 56 -369 minecraft:stone
fill 282 56 -368 283 56 -368 minecraft:stone
setblock 327 56 -356 minecraft:stone
fill 326 56 -355 327 56 -355 minecraft:stone
setblock 325 56 -354 minecraft:stone
fill 271 56 -347 272 56 -347 minecraft:stone
fill 271 56 -346 272 56 -346 minecraft:stone
setblock 264 56 -339 minecraft:stone
fill 264 56 -338 265 56 -338 minecraft:stone
fill 264 56 -337 266 56 -337 minecraft:stone
fill 264 56 -336 266 56 -336 minecraft:stone
fill 264 56 -335 267 56 -335 minecraft:stone
fill 264 56 -334 267 56 -334 minecraft:stone
fill 264 56 -333 268 56 -333 minecraft:stone
setblock 271 56 -333 minecraft:stone
fill 264 56 -332 271 56 -332 minecraft:stone
fill 264 56 -331 272 56 -331 minecraft:stone
fill 264 56 -330 271 56 -330 minecraft:stone
setblock 296 56 -330 minecraft:stone
fill 264 56 -329 271 56 -329 minecraft:stone
fill 294 56 -329 297 56 -329 minecraft:stone
fill 264 56 -328 272 56 -328 minecraft:stone
fill 294 56 -328 296 56 -328 minecraft:stone
fill 264 56 -327 272 56 -327 minecraft:stone
fill 294 56 -327 295 56 -327 minecraft:stone
fill 264 56 -326 273 56 -326 minecraft:stone
fill 264 56 -325 266 56 -325 minecraft:stone
fill 268 56 -325 273 56 -325 minecraft:stone
fill 264 56 -324 266 56 -324 minecraft:stone
fill 268 56 -324 274 56 -324 minecraft:stone
fill 316 56 -324 317 56 -324 minecraft:stone
fill 264 56 -323 266 56 -323 minecraft:stone
fill 269 56 -323 275 56 -323 minecraft:stone
fill 264 56 -322 266 56 -322 minecraft:stone
fill 269 56 -322 276 56 -322 minecraft:stone
fill 264 56 -321 266 56 -321 minecraft:stone
fill 270 56 -321 278 56 -321 minecraft:stone
fill 264 56 -320 267 56 -320 minecraft:stone
fill 272 56 -320 283 56 -320 minecraft:stone
fill 318 56 -320 319 56 -320 minecraft:stone
fill 264 56 -319 267 56 -319 minecraft:stone
fill 272 56 -319 284 56 -319 minecraft:stone
setblock 319 56 -319 minecraft:stone
fill 290 57 -382 292 57 -382 minecraft:stone
fill 290 57 -381 292 57 -381 minecraft:stone
fill 289 57 -380 291 57 -380 minecraft:stone
fill 289 57 -379 291 57 -379 minecraft:stone
fill 289 57 -378 290 57 -378 minecraft:stone
fill 288 57 -377 289 57 -377 minecraft:stone
setblock 288 57 -376 minecraft:stone
fill 287 57 -375 288 57 -375 minecraft:stone
setblock 287 57 -374 minecraft:stone
fill 286 57 -373 287 57 -373 minecraft:stone
setblock 286 57 -372 minecraft:stone
fill 285 57 -371 286 57 -371 minecraft:stone
fill 284 57 -370 286 57 -370 minecraft:stone
fill 283 57 -369 285 57 -369 minecraft:stone
fill 282 57 -368 284 57 -368 minecraft:stone
fill 282 57 -367 283 57 -367 minecraft:stone
setblock 327 57 -357 minecraft:stone
fill 326 57 -356 327 57 -356 minecraft:stone
fill 325 57 -355 327 57 -355 minecraft:stone
fill 324 57 -354 325 57 -354 minecraft:stone
setblock 322 57 -353 minecraft:stone
setblock 264 57 -339 minecraft:stone
fill 264 57 -338 265 57 -338 minecraft:stone
fill 264 57 -337 265 57 -337 minecraft:stone
fill 264 57 -336 266 57 -336 minecraft:stone
fill 264 57 -335 266 57 -335 minecraft:stone
fill 264 57 -334 266 57 -334 minecraft:stone
fill 264 57 -333 267 57 -333 minecraft:stone
fill 264 57 -332 268 57 -332 minecraft:stone
fill 270 57 -332 271 57 -332 minecraft:stone
fill 264 57 -331 272 57 -331 minecraft:stone
fill 264 57 -330 269 57 -330 minecraft:stone
fill 295 57 -330 296 57 -330 minecraft:stone
fill 264 57 -329 270 57 -329 minecraft:stone
fill 294 57 -329 296 57 -329 minecraft:stone
fill 264 57 -328 271 57 -328 minecraft:stone
fill 293 57 -328 296 57 -328 minecraft:stone
fill 264 57 -327 265 57 -327 minecraft:stone
fill 267 57 -327 271 57 -327 minecraft:stone
fill 294 57 -327 295 57 -327 minecraft:stone
fill 268 57 -326 272 57 -326 minecraft:stone
fill 268 57 -325 273 57 -325 minecraft:stone
fill 315 57 -325 317 57 -325 minecraft:stone
fill 269 57 -324 273 57 -324 minecraft:stone
fill 315 57 -324 318 57 -324 minecraft:stone
fill 269 57 -323 274 57 -323 minecraft:stone
fill 314 57 -323 317 57 -323 minecraft:stone
setblock 264 57 -322 minecraft:stone
fill 270 57 -322 276 57 -322 minecraft:stone
fill 314 57 -322 320 57 -322 minecraft:stone
fill 264 57 -321 265 57 -321 minecraft:stone
fill 272 57 -321 278 57 -321 minecraft:stone
fill 315 57 -321 320 57 -321 minecraft:stone
fill 264 57 -320 265 57 -320 minecraft:stone
fill 272 57 -320 284 57 -320 minecraft:stone
fill 317 57 -320 320 57 -320 minecraft:stone
fill 264 57 -319 265 57 -319 minecraft:stone
fill 272 57 -319 287 57 -319 minecraft:stone
fill 315 57 -319 320 57 -319 minecraft:stone
fill 291 58 -382 293 58 -382 minecraft:stone
fill 290 58 -381 292 58 -381 minecraft:stone
fill 290 58 -380 291 58 -380 minecraft:stone
setblock 290 58 -379 minecraft:stone
setblock 289 58 -378 minecraft:stone
setblock 285 58 -371 minecraft:stone
fill 284 58 -370 285 58 -370 minecraft:stone
fill 283 58 -369 285 58 -369 minecraft:stone
fill 282 58 -368 285 58 -368 minecraft:stone
fill 282 58 -367 283 58 -367 minecraft:stone
setblock 282 58 -366 minecraft:stone
setblock 327 58 -357 minecraft:stone
fill 326 58 -356 327 58 -356 minecraft:stone
fill 324 58 -355 327 58 -355 minecraft:stone
fill 323 58 -354 325 58 -354 minecraft:stone
fill 322 58 -353 323 58 -353 minecraft:stone
setblock 320 58 -352 minecraft:stone
setblock 264 58 -337 minecraft:stone
setblock 264 58 -336 minecraft:stone
setblock 270 58 -333 minecraft:stone
setblock 266 58 -332 minecraft:stone
fill 269 58 -332 271 58 -332 minecraft:stone
fill 265 58 -331 267 58 -331 minecraft:stone
fill 270 58 -331 271 58 -331 minecraft:stone
fill 265 58 -330 267 58 -330 minecraft:stone
fill 295 58 -330 296 58 -330 minecraft:stone
fill 293 58 -329 296 58 -329 minecraft:stone
fill 293 58 -328 295 58 -328 minecraft:stone
fill 293 58 -327 294 58 -327 minecraft:stone
fill 315 58 -326 319 58 -326 minecraft:stone
fill 314 58 -325 320 58 -325 minecraft:stone
fill 314 58 -324 320 58 -324 minecraft:stone
fill 314 58 -323 319 58 -323 minecraft:stone
fill 273 58 -322 275 58 -322 minecraft:stone
fill 314 58 -322 320 58 -322 minecraft:stone
fill 272 58 -321 278 58 -321 minecraft:stone
fill 314 58 -321 320 58 -321 minecraft:stone
fill 272 58 -320 284 58 -320 minecraft:stone
setblock 300 58 -320 minecraft:stone
fill 314 58 -320 321 58 -320 minecraft:stone
fill 272 58 -319 288 58 -319 minecraft:stone
fill 315 58 -319 321 58 -319 minecraft:stone
fill 291 59 -382 292 59 -382 minecraft:stone
setblock 291 59 -381 minecraft:stone
setblock 284 59 -369 minecraft:stone
fill 283 59 -368 284 59 -368 minecraft:stone
fill 281 59 -367 284 59 -367 minecraft:stone
fill 282 59 -366 283 59 -366 minecraft:stone
setblock 327 59 -357 minecraft:stone
fill 325 59 -356 327 59 -356 minecraft:stone
fill 324 59 -355 326 59 -355 minecraft:stone
fill 322 59 -354 325 59 -354 minecraft:stone
fill 321 59 -353 323 59 -353 minecraft:stone
fill 319 59 -352 320 59 -352 minecraft:stone
setblock 318 59 -351 minecraft:stone
setblock 270 59 -333 minecraft:stone
fill 269 59 -332 270 59 -332 minecraft:stone
fill 269 59 -331 271 59 -331 minecraft:stone
fill 294 59 -330 295 59 -330 minecraft:stone
fill 293 59 -329 296 59 -329 minecraft:stone
fill 292 59 -328 295 59 -328 minecraft:stone
fill 293 59 -327 294 59 -327 minecraft:stone
fill 315 59 -326 318 59 -326 minecraft:stone
fill 314 59 -325 319 59 -325 minecraft:stone
fill 314 59 -324 319 59 -324 minecraft:stone
fill 314 59 -323 318 59 -323 minecraft:stone
setblock 300 59 -322 minecraft:stone
fill 313 59 -322 319 59 -322 minecraft:stone
setblock 274 59 -321 minecraft:stone
setblock 276 59 -321 minecraft:stone
fill 299 59 -321 301 59 -321 minecraft:stone
fill 313 59 -321 320 59 -321 minecraft:stone
fill 274 59 -320 283 59 -320 minecraft:stone
fill 299 59 -320 302 59 -320 minecraft:stone
fill 314 59 -320 320 59 -320 minecraft:stone
fill 274 59 -319 289 59 -319 minecraft:stone
fill 299 59 -319 301 59 -319 minecraft:stone
fill 315 59 -319 320 59 -319 minecraft:stone
setblock 292 60 -382 minecraft:stone
setblock 284 60 -368 minecraft:stone
fill 282 60 -367 284 60 -367 minecraft:stone
fill 281 60 -366 283 60 -366 minecraft:stone
fill 281 60 -365 282 60 -365 minecraft:stone
setblock 327 60 -357 minecraft:stone
fill 325 60 -356 327 60 -356 minecraft:stone
fill 323 60 -355 325 60 -355 minecraft:stone
fill 322 60 -354 324 60 -354 minecraft:stone
fill 320 60 -353 323 60 -353 minecraft:stone
fill 319 60 -352 321 60 -352 minecraft:stone
fill 317 60 -351 318 60 -351 minecraft:stone
fill 315 60 -350 316 60 -350 minecraft:stone
setblock 269 60 -333 minecraft:stone
fill 268 60 -332 270 60 -332 minecraft:stone
fill 269 60 -331 271 60 -331 minecraft:stone
setblock 295 60 -331 minecraft:stone
fill 294 60 -330 295 60 -330 minecraft:stone
fill 293 60 -329 295 60 -329 minecraft:stone
fill 291 60 -328 295 60 -328 minecraft:stone
fill 292 60 -327 293 60 -327 minecraft:stone
setblock 300 60 -325 minecraft:stone
fill 315 60 -325 317 60 -325 minecraft:stone
fill 299 60 -324 301 60 -324 minecraft:stone
fill 315 60 -324 317 60 -324 minecraft:stone
fill 299 60 -323 302 60 -323 minecraft:stone
fill 315 60 -323 317 60 -323 minecraft:stone
fill 298 60 -322 302 60 -322 minecraft:stone
fill 315 60 -322 316 60 -322 minecraft:stone
fill 298 60 -321 303 60 -321 minecraft:stone
fill 297 60 -320 304 60 -320 minecraft:stone
fill 281 60 -319 283 60 -319 minecraft:stone
fill 285 60 -319 289 60 -319 minecraft:stone
fill 297 60 -319 303 60 -319 minecraft:stone
setblock 283 61 -367 minecraft:stone
fill 281 61 -366 283 61 -366 minecraft:stone
fill 281 61 -365 282 61 -365 minecraft:stone
setblock 281 61 -364 minecraft:stone
setblock 327 61 -357 minecraft:stone
fill 325 61 -356 326 61 -356 minecraft:stone
fill 322 61 -355 325 61 -355 minecraft:stone
fill 321 61 -354 323 61 -354 minecraft:stone
fill 319 61 -353 322 61 -353 minecraft:stone
fill 318 61 -352 320 61 -352 minecraft:stone
fill 316 61 -351 319 61 -351 minecraft:stone
fill 315 61 -350 316 61 -350 minecraft:stone
fill 313 61 -349 314 61 -349 minecraft:stone
fill 268 61 -333 269 61 -333 minecraft:stone
fill 268 61 -332 269 61 -332 minecraft:stone
fill 268 61 -331 270 61 -331 minecraft:stone
setblock 294 61 -330 minecraft:stone
fill 292 61 -329 295 61 -329 minecraft:stone
fill 291 61 -328 294 61 -328 minecraft:stone
setblock 300 61 -328 minecraft:stone
fill 291 61 -327 293 61 -327 minecraft:stone
fill 299 61 -327 300 61 -327 minecraft:stone
fill 298 61 -326 301 61 -326 minecraft:stone
fill 297 61 -325 302 61 -325 minecraft:stone
fill 297 61 -324 303 61 -324 minecraft:stone
fill 297 61 -323 303 61 -323 minecraft:stone
fill 296 61 -322 304 61 -322 minecraft:stone
fill 296 61 -321 305 61 -321 minecraft:stone
fill 296 61 -320 306 61 -320 minecraft:stone
fill 295 61 -319 305 61 -319 minecraft:stone
fill 282 62 -366 283 62 -366 minecraft:dirt
fill 281 62 -365 283 62 -365 minecraft:dirt
setblock 281 62 -364 minecraft:dirt
setblock 325 62 -356 minecraft:dirt
fill 323 62 -355 324 62 -355 minecraft:dirt
fill 320 62 -354 323 62 -354 minecraft:dirt
fill 318 62 -353 321 62 -353 minecraft:dirt
fill 317 62 -352 320 62 -352 minecraft:dirt
fill 315 62 -351 318 62 -351 minecraft:dirt
fill 314 62 -350 316 62 -350 minecraft:dirt
fill 312 62 -349 314 62 -349 minecraft:dirt
fill 311 62 -348 312 62 -348 minecraft:dirt
setblock 327 62 -346 minecraft:dirt
fill 325 62 -345 327 62 -345 minecraft:dirt
setblock 321 62 -344 minecraft:dirt
setblock 323 62 -344 minecraft:dirt
fill 326 62 -344 327 62 -344 minecraft:dirt
setblock 324 62 -343 minecraft:dirt
fill 326 62 -343 327 62 -343 minecraft:dirt
fill 316 62 -340 317 62 -340 minecraft:dirt
fill 267 62 -333 268 62 -333 minecraft:dirt
fill 267 62 -332 269 62 -332 minecraft:dirt
fill 268 62 -331 270 62 -331 minecraft:dirt
fill 293 62 -330 294 62 -330 minecraft:dirt
fill 292 62 -329 294 62 -329 minecraft:dirt
setblock 300 62 -329 minecraft:dirt
fill 290 62 -328 294 62 -328 minecraft:dirt
fill 296 62 -328 301 62 -328 minecraft:dirt
fill 290 62 -327 292 62 -327 minecraft:dirt
fill 296 62 -327 297 62 -327 minecraft:dirt
fill 299 62 -327 301 62 -327 minecraft:dirt
setblock 291 62 -326 minecraft:dirt
fill 296 62 -326 302 62 -326 minecraft:dirt
fill 295 62 -325 303 62 -325 minecraft:dirt
fill 295 62 -324 304 62 -324 minecraft:dirt
fill 295 62 -323 304 62 -323 minecraft:dirt
fill 295 62 -322 305 62 -322 minecraft:dirt
fill 295 62 -321 305 62 -321 minecraft:dirt
fill 294 62 -320 307 62 -320 minecraft:dirt
fill 295 62 -319 308 62 -319 minecraft:dirt
fill 281 63 -365 283 63 -365 minecraft:dirt
fill 280 63 -364 282 63 -364 minecraft:dirt
setblock 323 63 -355 minecraft:dirt
fill 321 63 -354 322 63 -354 minecraft:dirt
fill 318 63 -353 320 63 -353 minecraft:dirt
fill 316 63 -352 319 63 -352 minecraft:dirt
fill 314 63 -351 317 63 -351 minecraft:dirt
fill 313 63 -350 315 63 -350 minecraft:dirt
fill 311 63 -349 314 63 -349 minecraft:dirt
fill 310 63 -348 312 63 -348 minecraft:dirt
setblock 327 63 -348 minecraft:dirt
fill 309 63 -347 310 63 -347 minecraft:dirt
fill 325 63 -347 326 63 -347 minecraft:dirt
setblock 308 63 -346 minecraft:dirt
fill 322 63 -346 327 63 -346 minecraft:dirt
fill 320 63 -345 327 63 -345 minecraft:dirt
fill 319 63 -344 321 63 -344 minecraft:dirt
setblock 323 63 -344 minecraft:dirt
fill 326 63 -344 327 63 -344 minecraft:dirt
fill 318 63 -343 322 63 -343 minecraft:dirt
setblock 324 63 -343 minecraft:dirt
fill 326 63 -343 327 63 -343 minecraft:dirt
fill 317 63 -342 327 63 -342 minecraft:dirt
setblock 313 63 -341 minecraft:dirt
setblock 315 63 -341 minecraft:dirt
fill 319 63 -341 327 63 -341 minecraft:dirt
setblock 310 63 -340 minecraft:dirt
fill 312 63 -340 323 63 -340 minecraft:dirt
fill 310 63 -339 312 63 -339 minecraft:dirt
fill 314 63 -339 315 63 -339 minecraft:dirt
fill 317 63 -339 321 63 -339 minecraft:dirt
fill 308 63 -338 310 63 -338 minecraft:dirt
fill 308 63 -337 310 63 -337 minecraft:dirt
fill 307 63 -336 310 63 -336 minecraft:dirt
fill 307 63 -335 309 63 -335 minecraft:dirt
fill 307 63 -334 309 63 -334 minecraft:dirt
fill 266 63 -333 268 63 -333 minecraft:dirt
setblock 308 63 -333 minecraft:dirt
fill 267 63 -332 269 63 -332 minecraft:dirt
fill 268 63 -331 269 63 -331 minecraft:dirt
fill 293 63 -330 294 63 -330 minecraft:dirt
setblock 300 63 -330 minecraft:dirt
fill 292 63 -329 294 63 -329 minecraft:dirt
fill 298 63 -329 302 63 -329 minecraft:dirt
fill 290 63 -328 302 63 -328 minecraft:dirt
fill 290 63 -327 292 63 -327 minecraft:dirt
fill 294 63 -327 297 63 -327 minecraft:dirt
fill 299 63 -327 303 63 -327 minecraft:dirt
setblock 290 63 -326 minecraft:dirt
fill 293 63 -326 303 63 -326 minecraft:dirt
fill 293 63 -325 304 63 -325 minecraft:dirt
fill 294 63 -324 304 63 -324 minecraft:dirt
fill 293 63 -323 305 63 -323 minecraft:dirt
fill 293 63 -322 306 63 -322 minecraft:dirt
fill 293 63 -321 305 63 -321 minecraft:dirt
setblock 307 63 -321 minecraft:dirt
fill 293 63 -320 308 63 -320 minecraft:dirt
fill 292 63 -319 293 63 -319 minecraft:dirt
fill 295 63 -319 308 63 -319 minecraft:dirt
fill 281 64 -365 282 64 -365 minecraft:dirt
fill 280 64 -364 282 64 -364 minecraft:dirt
fill 280 64 -363 281 64 -363 minecraft:dirt
setblock 321 64 -354 minecraft:dirt
fill 318 64 -353 319 64 -353 minecraft:dirt
fill 316 64 -352 318 64 -352 minecraft:dirt
setblock 280 64 -351 minecraft:dirt
fill 314 64 -351 316 64 -351 minecraft:dirt
fill 279 64 -350 282 64 -350 minecraft:dirt
fill 312 64 -350 315 64 -350 minecraft:dirt
setblock 327 64 -350 minecraft:dirt
fill 278 64 -349 279 64 -349 minecraft:dirt
fill 281 64 -349 288 64 -349 minecraft:dirt
fill 311 64 -349 313 64 -349 minecraft:dirt
fill 326 64 -349 327 64 -349 minecraft:dirt
fill 277 64 -348 286 64 -348 minecraft:dirt
fill 288 64 -348 292 64 -348 minecraft:dirt
fill 309 64 -348 311 64 -348 minecraft:dirt
fill 323 64 -348 327 64 -348 minecraft:dirt
fill 272 64 -347 274 64 -347 minecraft:dirt
fill 277 64 -347 278 64 -347 minecraft:dirt
fill 280 64 -347 286 64 -347 minecraft:dirt
fill 288 64 -347 292 64 -347 minecraft:dirt
fill 308 64 -347 310 64 -347 minecraft:dirt
fill 320 64 -347 326 64 -347 minecraft:dirt
fill 270 64 -346 275 64 -346 minecraft:dirt
fill 277 64 -346 292 64 -346 minecraft:dirt
fill 307 64 -346 308 64 -346 minecraft:dirt
fill 319 64 -346 327 64 -346 minecraft:dirt
fill 268 64 -345 272 64 -345 minecraft:dirt
fill 274 64 -345 275 64 -345 minecraft:dirt
fill 277 64 -345 292 64 -345 minecraft:dirt
setblock 306 64 -345 minecraft:dirt
fill 317 64 -345 327 64 -345 minecraft:dirt
fill 266 64 -344 276 64 -344 minecraft:dirt
fill 278 64 -344 292 64 -344 minecraft:dirt
fill 316 64 -344 317 64 -344 minecraft:dirt
fill 319 64 -344 327 64 -344 minecraft:dirt
fill 267 64 -343 292 64 -343 minecraft:dirt
fill 315 64 -343 327 64 -343 minecraft:dirt
fill 268 64 -342 290 64 -342 minecraft:dirt
fill 312 64 -342 315 64 -342 minecraft:dirt
fill 317 64 -342 327 64 -342 minecraft:dirt
fill 268 64 -341 289 64 -341 minecraft:dirt
fill 309 64 -341 313 64 -341 minecraft:dirt
setblock 315 64 -341 minecraft:dirt
fill 319 64 -341 327 64 -341 minecraft:dirt
fill 268 64 -340 289 64 -340 minecraft:dirt
fill 307 64 -340 310 64 -340 minecraft:dirt
fill 312 64 -340 327 64 -340 minecraft:dirt
fill 270 64 -339 274 64 -339 minecraft:dirt
fill 276 64 -339 289 64 -339 minecraft:dirt
fill 306 64 -339 312 64 -339 minecraft:dirt
fill 314 64 -339 315 64 -339 minecraft:dirt
fill 317 64 -339 326 64 -339 minecraft:dirt
fill 269 64 -338 289 64 -338 minecraft:dirt
fill 306 64 -338 323 64 -338 minecraft:dirt
fill 270 64 -337 289 64 -337 minecraft:dirt
fill 305 64 -337 320 64 -337 minecraft:dirt
fill 270 64 -336 288 64 -336 minecraft:dirt
fill 305 64 -336 315 64 -336 minecraft:dirt
fill 270 64 -335 288 64 -335 minecraft:dirt
fill 304 64 -335 313 64 -335 minecraft:dirt
setblock 270 64 -334 minecraft:dirt
fill 272 64 -334 287 64 -334 minecraft:dirt
fill 304 64 -334 313 64 -334 minecraft:dirt
fill 266 64 -333 267 64 -333 minecraft:dirt
fill 270 64 -333 286 64 -333 minecraft:dirt
fill 303 64 -333 312 64 -333 minecraft:dirt
fill 266 64 -332 268 64 -332 minecraft:dirt
fill 270 64 -332 285 64 -332 minecraft:dirt
fill 302 64 -332 312 64 -332 minecraft:dirt
fill 267 64 -331 268 64 -331 minecraft:dirt
fill 271 64 -331 285 64 -331 minecraft:dirt
setblock 292 64 -331 minecraft:dirt
fill 300 64 -331 310 64 -331 minecraft:dirt
fill 271 64 -330 283 64 -330 minecraft:dirt
fill 291 64 -330 293 64 -330 minecraft:dirt
fill 298 64 -330 306 64 -330 minecraft:dirt
fill 272 64 -329 282 64 -329 minecraft:dirt
fill 290 64 -329 304 64 -329 minecraft:dirt
fill 272 64 -328 282 64 -328 minecraft:dirt
fill 289 64 -328 303 64 -328 minecraft:dirt
fill 278 64 -327 280 64 -327 minecraft:dirt
fill 289 64 -327 292 64 -327 minecraft:dirt
fill 294 64 -327 304 64 -327 minecraft:dirt
fill 289 64 -326 305 64 -326 minecraft:dirt
fill 291 64 -325 305 64 -325 minecraft:dirt
fill 292 64 -324 305 64 -324 minecraft:dirt
fill 291 64 -323 306 64 -323 minecraft:dirt
fill 291 64 -322 307 64 -322 minecraft:dirt
fill 291 64 -321 308 64 -321 minecraft:dirt
fill 290 64 -320 309 64 -320 minecraft:dirt
fill 289 64 -319 309 64 -319 minecraft:dirt
fill 268 65 -382 276 65 -382 minecraft:smooth_quartz
fill 298 65 -382 300 65 -382 minecraft:smooth_quartz
setblock 301 65 -382 minecraft:light_gray_concrete
fill 302 65 -382 312 65 -382 minecraft:smooth_quartz
setblock 313 65 -382 minecraft:light_gray_concrete
fill 314 65 -382 324 65 -382 minecraft:smooth_quartz
setblock 325 65 -382 minecraft:light_gray_concrete
setblock 326 65 -382 minecraft:smooth_quartz
setblock 327 65 -382 minecraft:grass_block
fill 267 65 -381 276 65 -381 minecraft:smooth_quartz
setblock 277 65 -381 minecraft:light_gray_concrete
fill 297 65 -381 300 65 -381 minecraft:smooth_quartz
setblock 301 65 -381 minecraft:light_gray_concrete
fill 302 65 -381 312 65 -381 minecraft:smooth_quartz
setblock 313 65 -381 minecraft:light_gray_concrete
fill 314 65 -381 324 65 -381 minecraft:smooth_quartz
setblock 325 65 -381 minecraft:light_gray_concrete
setblock 326 65 -381 minecraft:smooth_quartz
setblock 327 65 -381 minecraft:grass_block
fill 268 65 -380 276 65 -380 minecraft:light_gray_concrete
fill 298 65 -380 326 65 -380 minecraft:light_gray_concrete
setblock 327 65 -380 minecraft:grass_block
fill 269 65 -379 275 65 -379 minecraft:smooth_quartz
fill 299 65 -379 300 65 -379 minecraft:smooth_quartz
setblock 301 65 -379 minecraft:light_gray_concrete
fill 302 65 -379 312 65 -379 minecraft:smooth_quartz
setblock 313 65 -379 minecraft:light_gray_concrete
fill 314 65 -379 324 65 -379 minecraft:smooth_quartz
setblock 325 65 -379 minecraft:light_gray_concrete
setblock 326 65 -379 minecraft:smooth_quartz
setblock 327 65 -379 minecraft:grass_block
fill 268 65 -378 276 65 -378 minecraft:smooth_quartz
fill 298 65 -378 300 65 -378 minecraft:smooth_quartz
setblock 301 65 -378 minecraft:light_gray_concrete
fill 302 65 -378 312 65 -378 minecraft:smooth_quartz
setblock 313 65 -378 minecraft:light_gray_concrete
fill 314 65 -378 324 65 -378 minecraft:smooth_quartz
setblock 325 65 -378 minecraft:light_gray_concrete
setblock 326 65 -378 minecraft:smooth_quartz
setblock 327 65 -378 minecraft:grass_block
fill 269 65 -377 275 65 -377 minecraft:smooth_quartz
fill 299 65 -377 300 65 -377 minecraft:smooth_quartz
setblock 301 65 -377 minecraft:light_gray_concrete
fill 302 65 -377 312 65 -377 minecraft:smooth_quartz
setblock 313 65 -377 minecraft:light_gray_concrete
fill 314 65 -377 324 65 -377 minecraft:smooth_quartz
setblock 325 65 -377 minecraft:light_gray_concrete
setblock 326 65 -377 minecraft:smooth_quartz
setblock 327 65 -377 minecraft:grass_block
fill 269 65 -376 275 65 -376 minecraft:smooth_quartz
setblock 300 65 -376 minecraft:smooth_quartz
setblock 301 65 -376 minecraft:light_gray_concrete
fill 302 65 -376 312 65 -376 minecraft:smooth_quartz
setblock 313 65 -376 minecraft:light_gray_concrete
fill 314 65 -376 324 65 -376 minecraft:smooth_quartz
setblock 325 65 -376 minecraft:light_gray_concrete
setblock 326 65 -376 minecraft:smooth_quartz
setblock 327 65 -376 minecraft:grass_block
fill 299 65 -375 300 65 -375 minecraft:smooth_quartz
setblock 301 65 -375 minecraft:light_gray_concrete
fill 302 65 -375 312 65 -375 minecraft:smooth_quartz
setblock 313 65 -375 minecraft:light_gray_concrete
fill 314 65 -375 324 65 -375 minecraft:smooth_quartz
setblock 325 65 -375 minecraft:light_gray_concrete
setblock 326 65 -375 minecraft:smooth_quartz
setblock 327 65 -375 minecraft:grass_block
setblock 300 65 -374 minecraft:smooth_quartz
setblock 301 65 -374 minecraft:light_gray_concrete
fill 302 65 -374 310 65 -374 minecraft:smooth_quartz
setblock 311 65 -374 minecraft:sea_lantern
setblock 312 65 -374 minecraft:smooth_quartz
setblock 313 65 -374 minecraft:light_gray_concrete
fill 314 65 -374 324 65 -374 minecraft:smooth_quartz
setblock 325 65 -374 minecraft:light_gray_concrete
setblock 326 65 -374 minecraft:smooth_quartz
setblock 327 65 -374 minecraft:grass_block
fill 299 65 -373 300 65 -373 minecraft:smooth_quartz
setblock 301 65 -373 minecraft:light_gray_concrete
fill 302 65 -373 309 65 -373 minecraft:smooth_quartz
fill 310 65 -373 312 65 -373 minecraft:grass_block
setblock 313 65 -373 minecraft:light_gray_concrete
fill 314 65 -373 324 65 -373 minecraft:smooth_quartz
setblock 325 65 -373 minecraft:light_gray_concrete
setblock 326 65 -373 minecraft:smooth_quartz
setblock 327 65 -373 minecraft:grass_block
fill 298 65 -372 300 65 -372 minecraft:smooth_quartz
setblock 301 65 -372 minecraft:light_gray_concrete
fill 302 65 -372 308 65 -372 minecraft:smooth_quartz
fill 309 65 -372 313 65 -372 minecraft:grass_block
fill 314 65 -372 324 65 -372 minecraft:smooth_quartz
setblock 325 65 -372 minecraft:light_gray_concrete
setblock 326 65 -372 minecraft:smooth_quartz
setblock 327 65 -372 minecraft:grass_block
fill 299 65 -371 300 65 -371 minecraft:smooth_quartz
setblock 301 65 -371 minecraft:light_gray_concrete
fill 302 65 -371 307 65 -371 minecraft:smooth_quartz
fill 308 65 -371 314 65 -371 minecraft:grass_block
fill 315 65 -371 324 65 -371 minecraft:smooth_quartz
setblock 325 65 -371 minecraft:light_gray_concrete
setblock 326 65 -371 minecraft:smooth_quartz
setblock 327 65 -371 minecraft:grass_block
fill 298 65 -370 300 65 -370 minecraft:smooth_quartz
setblock 301 65 -370 minecraft:light_gray_concrete
fill 302 65 -370 306 65 -370 minecraft:smooth_quartz
setblock 307 65 -370 minecraft:sea_lantern
fill 308 65 -370 314 65 -370 minecraft:grass_block
setblock 315 65 -370 minecraft:sea_lantern
fill 316 65 -370 324 65 -370 minecraft:smooth_quartz
setblock 325 65 -370 minecraft:light_gray_concrete
setblock 326 65 -370 minecraft:smooth_quartz
setblock 327 65 -370 minecraft:grass_block
fill 297 65 -369 300 65 -369 minecraft:smooth_quartz
setblock 301 65 -369 minecraft:light_gray_concrete
fill 302 65 -369 307 65 -369 minecraft:smooth_quartz
fill 308 65 -369 314 65 -369 minecraft:grass_block
fill 315 65 -369 324 65 -369 minecraft:smooth_quartz
setblock 325 65 -369 minecraft:light_gray_concrete
setblock 326 65 -369 minecraft:smooth_quartz
setblock 327 65 -369 minecraft:grass_block
fill 298 65 -368 308 65 -368 minecraft:light_gray_concrete
fill 309 65 -368 313 65 -368 minecraft:grass_block
fill 314 65 -368 326 65 -368 minecraft:light_gray_concrete
setblock 327 65 -368 minecraft:grass_block
fill 297 65 -367 300 65 -367 minecraft:smooth_quartz
setblock 301 65 -367 minecraft:light_gray_concrete
fill 302 65 -367 309 65 -367 minecraft:smooth_quartz
fill 310 65 -367 312 65 -367 minecraft:grass_block
setblock 313 65 -367 minecraft:light_gray_concrete
fill 314 65 -367 324 65 -367 minecraft:smooth_quartz
setblock 325 65 -367 minecraft:light_gray_concrete
setblock 326 65 -367 minecraft:smooth_quartz
setblock 327 65 -367 minecraft:grass_block
fill 296 65 -366 300 65 -366 minecraft:smooth_quartz
setblock 301 65 -366 minecraft:light_gray_concrete
fill 302 65 -366 310 65 -366 minecraft:smooth_quartz
setblock 311 65 -366 minecraft:sea_lantern
setblock 312 65 -366 minecraft:smooth_quartz
setblock 313 65 -366 minecraft:light_gray_concrete
fill 314 65 -366 324 65 -366 minecraft:smooth_quartz
setblock 325 65 -366 minecraft:light_gray_concrete
setblock 326 65 -366 minecraft:smooth_quartz
setblock 327 65 -366 minecraft:grass_block
setblock 293 65 -365 minecraft:smooth_quartz
fill 295 65 -365 300 65 -365 minecraft:smooth_quartz
setblock 301 65 -365 minecraft:light_gray_concrete
fill 302 65 -365 312 65 -365 minecraft:smooth_quartz
setblock 313 65 -365 minecraft:light_gray_concrete
fill 314 65 -365 324 65 -365 minecraft:smooth_quartz
setblock 325 65 -365 minecraft:light_gray_concrete
setblock 326 65 -365 minecraft:smooth_quartz
setblock 327 65 -365 minecraft:grass_block
setblock 290 65 -364 minecraft:smooth_quartz
fill 292 65 -364 300 65 -364 minecraft:smooth_quartz
setblock 301 65 -364 minecraft:light_gray_concrete
fill 302 65 -364 312 65 -364 minecraft:smooth_quartz
setblock 313 65 -364 minecraft:light_gray_concrete
fill 314 65 -364 324 65 -364 minecraft:smooth_quartz
setblock 325 65 -364 minecraft:light_gray_concrete
setblock 326 65 -364 minecraft:smooth_quartz
setblock 327 65 -364 minecraft:grass_block
setblock 288 65 -363 minecraft:smooth_quartz
setblock 289 65 -363 minecraft:light_gray_concrete
fill 290 65 -363 300 65 -363 minecraft:smooth_quartz
setblock 301 65 -363 minecraft:light_gray_concrete
fill 302 65 -363 312 65 -363 minecraft:smooth_quartz
setblock 313 65 -363 minecraft:light_gray_concrete
fill 314 65 -363 324 65 -363 minecraft:smooth_quartz
setblock 325 65 -363 minecraft:light_gray_concrete
setblock 326 65 -363 minecraft:smooth_quartz
setblock 327 65 -363 minecraft:grass_block
setblock 288 65 -362 minecraft:smooth_quartz
setblock 289 65 -362 minecraft:light_gray_concrete
fill 290 65 -362 300 65 -362 minecraft:smooth_quartz
setblock 301 65 -362 minecraft:light_gray_concrete
fill 302 65 -362 312 65 -362 minecraft:smooth_quartz
setblock 313 65 -362 minecraft:light_gray_concrete
fill 314 65 -362 324 65 -362 minecraft:smooth_quartz
setblock 325 65 -362 minecraft:light_gray_concrete
setblock 326 65 -362 minecraft:smooth_quartz
setblock 327 65 -362 minecraft:grass_block
setblock 288 65 -361 minecraft:smooth_quartz
setblock 289 65 -361 minecraft:light_gray_concrete
fill 290 65 -361 300 65 -361 minecraft:smooth_quartz
setblock 301 65 -361 minecraft:light_gray_concrete
fill 302 65 -361 312 65 -361 minecraft:smooth_quartz
setblock 313 65 -361 minecraft:light_gray_concrete
fill 314 65 -361 324 65 -361 minecraft:smooth_quartz
setblock 325 65 -361 minecraft:light_gray_concrete
setblock 326 65 -361 minecraft:smooth_quartz
setblock 327 65 -361 minecraft:grass_block
setblock 288 65 -360 minecraft:smooth_quartz
setblock 289 65 -360 minecraft:light_gray_concrete
fill 290 65 -360 300 65 -360 minecraft:smooth_quartz
setblock 301 65 -360 minecraft:light_gray_concrete
fill 302 65 -360 312 65 -360 minecraft:smooth_quartz
setblock 313 65 -360 minecraft:light_gray_concrete
fill 314 65 -360 324 65 -360 minecraft:smooth_quartz
setblock 325 65 -360 minecraft:light_gray_concrete
setblock 326 65 -360 minecraft:smooth_quartz
setblock 327 65 -360 minecraft:grass_block
setblock 288 65 -359 minecraft:smooth_quartz
setblock 289 65 -359 minecraft:light_gray_concrete
fill 290 65 -359 300 65 -359 minecraft:smooth_quartz
setblock 301 65 -359 minecraft:light_gray_concrete
fill 302 65 -359 312 65 -359 minecraft:smooth_quartz
setblock 313 65 -359 minecraft:light_gray_concrete
fill 314 65 -359 324 65 -359 minecraft:smooth_quartz
setblock 325 65 -359 minecraft:light_gray_concrete
setblock 326 65 -359 minecraft:smooth_quartz
setblock 327 65 -359 minecraft:grass_block
setblock 288 65 -358 minecraft:smooth_quartz
setblock 289 65 -358 minecraft:light_gray_concrete
fill 290 65 -358 300 65 -358 minecraft:smooth_quartz
setblock 301 65 -358 minecraft:light_gray_concrete
fill 302 65 -358 312 65 -358 minecraft:smooth_quartz
setblock 313 65 -358 minecraft:light_gray_concrete
fill 314 65 -358 324 65 -358 minecraft:smooth_quartz
setblock 325 65 -358 minecraft:light_gray_concrete
setblock 326 65 -358 minecraft:smooth_quartz
setblock 327 65 -358 minecraft:grass_block
setblock 288 65 -357 minecraft:smooth_quartz
setblock 289 65 -357 minecraft:light_gray_concrete
fill 290 65 -357 300 65 -357 minecraft:smooth_quartz
setblock 301 65 -357 minecraft:light_gray_concrete
fill 302 65 -357 312 65 -357 minecraft:smooth_quartz
setblock 313 65 -357 minecraft:light_gray_concrete
fill 314 65 -357 324 65 -357 minecraft:smooth_quartz
setblock 325 65 -357 minecraft:light_gray_concrete
setblock 326 65 -357 minecraft:smooth_quartz
setblock 327 65 -357 minecraft:grass_block
setblock 290 65 -356 minecraft:light_gray_concrete
fill 292 65 -356 326 65 -356 minecraft:light_gray_concrete
setblock 327 65 -356 minecraft:grass_block
setblock 293 65 -355 minecraft:smooth_quartz
fill 295 65 -355 300 65 -355 minecraft:smooth_quartz
setblock 301 65 -355 minecraft:light_gray_concrete
fill 302 65 -355 312 65 -355 minecraft:smooth_quartz
setblock 313 65 -355 minecraft:light_gray_concrete
fill 314 65 -355 324 65 -355 minecraft:smooth_quartz
setblock 325 65 -355 minecraft:light_gray_concrete
setblock 326 65 -355 minecraft:smooth_quartz
setblock 327 65 -355 minecraft:grass_block
fill 296 65 -354 300 65 -354 minecraft:smooth_quartz
setblock 301 65 -354 minecraft:light_gray_concrete
fill 302 65 -354 312 65 -354 minecraft:smooth_quartz
setblock 313 65 -354 minecraft:light_gray_concrete
fill 314 65 -354 324 65 -354 minecraft:smooth_quartz
setblock 325 65 -354 minecraft:light_gray_concrete
setblock 326 65 -354 minecraft:smooth_quartz
setblock 327 65 -354 minecraft:grass_block
fill 297 65 -353 300 65 -353 minecraft:smooth_quartz
setblock 301 65 -353 minecraft:light_gray_concrete
fill 302 65 -353 312 65 -353 minecraft:smooth_quartz
setblock 313 65 -353 minecraft:light_gray_concrete
fill 314 65 -353 324 65 -353 minecraft:smooth_quartz
setblock 325 65 -353 minecraft:light_gray_concrete
setblock 326 65 -353 minecraft:smooth_quartz
setblock 327 65 -353 minecraft:grass_block
fill 298 65 -352 300 65 -352 minecraft:smooth_quartz
setblock 301 65 -352 minecraft:light_gray_concrete
fill 302 65 -352 312 65 -352 minecraft:smooth_quartz
setblock 313 65 -352 minecraft:light_gray_concrete
fill 314 65 -352 324 65 -352 minecraft:smooth_quartz
setblock 325 65 -352 minecraft:light_gray_concrete
setblock 326 65 -352 minecraft:smooth_quartz
setblock 327 65 -352 minecraft:grass_block
fill 297 65 -351 300 65 -351 minecraft:smooth_quartz
setblock 301 65 -351 minecraft:light_gray_concrete
fill 302 65 -351 312 65 -351 minecraft:smooth_quartz
setblock 313 65 -351 minecraft:light_gray_concrete
fill 314 65 -351 324 65 -351 minecraft:smooth_quartz
setblock 325 65 -351 minecraft:light_gray_concrete
setblock 326 65 -351 minecraft:smooth_quartz
setblock 327 65 -351 minecraft:grass_block
fill 298 65 -350 300 65 -350 minecraft:smooth_quartz
setblock 301 65 -350 minecraft:light_gray_concrete
fill 302 65 -350 310 65 -350 minecraft:smooth_quartz
setblock 311 65 -350 minecraft:sea_lantern
setblock 312 65 -350 minecraft:smooth_quartz
setblock 313 65 -350 minecraft:light_gray_concrete
fill 314 65 -350 324 65 -350 minecraft:smooth_quartz
setblock 325 65 -350 minecraft:light_gray_concrete
setblock 326 65 -350 minecraft:smooth_quartz
setblock 327 65 -350 minecraft:grass_block
fill 299 65 -349 300 65 -349 minecraft:smooth_quartz
setblock 301 65 -349 minecraft:light_gray_concrete
fill 302 65 -349 309 65 -349 minecraft:smooth_quartz
fill 310 65 -349 312 65 -349 minecraft:grass_block
setblock 313 65 -349 minecraft:light_gray_concrete
fill 314 65 -349 324 65 -349 minecraft:smooth_quartz
setblock 325 65 -349 minecraft:light_gray_concrete
setblock 326 65 -349 minecraft:smooth_quartz
setblock 327 65 -349 minecraft:grass_block
fill 298 65 -348 300 65 -348 minecraft:smooth_quartz
setblock 301 65 -348 minecraft:light_gray_concrete
fill 302 65 -348 308 65 -348 minecraft:smooth_quartz
fill 309 65 -348 313 65 -348 minecraft:grass_block
fill 314 65 -348 324 65 -348 minecraft:smooth_quartz
setblock 325 65 -348 minecraft:light_gray_concrete
setblock 326 65 -348 minecraft:smooth_quartz
setblock 327 65 -348 minecraft:grass_block
fill 299 65 -347 300 65 -347 minecraft:smooth_quartz
setblock 301 65 -347 minecraft:light_gray_concrete
fill 302 65 -347 307 65 -347 minecraft:smooth_quartz
fill 308 65 -347 314 65 -347 minecraft:grass_block
fill 315 65 -347 324 65 -347 minecraft:smooth_quartz
setblock 325 65 -347 minecraft:light_gray_concrete
setblock 326 65 -347 minecraft:smooth_quartz
setblock 327 65 -347 minecraft:grass_block
setblock 300 65 -346 minecraft:smooth_quartz
setblock 301 65 -346 minecraft:light_gray_concrete
fill 302 65 -346 306 65 -346 minecraft:smooth_quartz
setblock 307 65 -346 minecraft:sea_lantern
fill 308 65 -346 314 65 -346 minecraft:grass_block
setblock 315 65 -346 minecraft:sea_lantern
fill 316 65 -346 324 65 -346 minecraft:smooth_quartz
setblock 325 65 -346 minecraft:light_gray_concrete
setblock 326 65 -346 minecraft:smooth_quartz
setblock 327 65 -346 minecraft:grass_block
fill 299 65 -345 300 65 -345 minecraft:smooth_quartz
setblock 301 65 -345 minecraft:light_gray_concrete
fill 302 65 -345 307 65 -345 minecraft:smooth_quartz
fill 308 65 -345 314 65 -345 minecraft:grass_block
fill 315 65 -345 324 65 -345 minecraft:smooth_quartz
setblock 325 65 -345 minecraft:light_gray_concrete
setblock 326 65 -345 minecraft:smooth_quartz
setblock 327 65 -345 minecraft:grass_block
fill 269 65 -344 275 65 -344 minecraft:light_gray_concrete
fill 300 65 -344 308 65 -344 minecraft:light_gray_concrete
fill 309 65 -344 313 65 -344 minecraft:grass_block
fill 314 65 -344 326 65 -344 minecraft:light_gray_concrete
setblock 327 65 -344 minecraft:grass_block
fill 269 65 -343 275 65 -343 minecraft:smooth_quartz
fill 299 65 -343 300 65 -343 minecraft:smooth_quartz
setblock 301 65 -343 minecraft:light_gray_concrete
fill 302 65 -343 309 65 -343 minecraft:smooth_quartz
fill 310 65 -343 312 65 -343 minecraft:grass_block
setblock 313 65 -343 minecraft:light_gray_concrete
fill 314 65 -343 324 65 -343 minecraft:smooth_quartz
setblock 325 65 -343 minecraft:light_gray_concrete
setblock 326 65 -343 minecraft:smooth_quartz
setblock 327 65 -343 minecraft:grass_block
fill 268 65 -342 276 65 -342 minecraft:smooth_quartz
fill 298 65 -342 300 65 -342 minecraft:smooth_quartz
setblock 301 65 -342 minecraft:light_gray_concrete
fill 302 65 -342 310 65 -342 minecraft:smooth_quartz
setblock 311 65 -342 minecraft:sea_lantern
setblock 312 65 -342 minecraft:smooth_quartz
setblock 313 65 -342 minecraft:light_gray_concrete
fill 314 65 -342 324 65 -342 minecraft:smooth_quartz
setblock 325 65 -342 minecraft:light_gray_concrete
setblock 326 65 -342 minecraft:smooth_quartz
setblock 327 65 -342 minecraft:grass_block
fill 269 65 -341 275 65 -341 minecraft:smooth_quartz
fill 299 65 -341 300 65 -341 minecraft:smooth_quartz
setblock 301 65 -341 minecraft:light_gray_concrete
fill 302 65 -341 312 65 -341 minecraft:smooth_quartz
setblock 313 65 -341 minecraft:light_gray_concrete
fill 314 65 -341 324 65 -341 minecraft:smooth_quartz
setblock 325 65 -341 minecraft:light_gray_concrete
setblock 326 65 -341 minecraft:smooth_quartz
setblock 327 65 -341 minecraft:grass_block
fill 268 65 -340 276 65 -340 minecraft:smooth_quartz
fill 298 65 -340 300 65 -340 minecraft:smooth_quartz
setblock 301 65 -340 minecraft:light_gray_concrete
fill 302 65 -340 312 65 -340 minecraft:smooth_quartz
setblock 313 65 -340 minecraft:light_gray_concrete
fill 314 65 -340 324 65 -340 minecraft:smooth_quartz
setblock 325 65 -340 minecraft:light_gray_concrete
setblock 326 65 -340 minecraft:smooth_quartz
setblock 327 65 -340 minecraft:grass_block
fill 267 65 -339 276 65 -339 minecraft:smooth_quartz
setblock 277 65 -339 minecraft:light_gray_concrete
fill 297 65 -339 300 65 -339 minecraft:smooth_quartz
setblock 301 65 -339 minecraft:light_gray_concrete
fill 302 65 -339 312 65 -339 minecraft:smooth_quartz
setblock 313 65 -339 minecraft:light_gray_concrete
fill 314 65 -339 324 65 -339 minecraft:smooth_quartz
setblock 325 65 -339 minecraft:light_gray_concrete
setblock 326 65 -339 minecraft:smooth_quartz
setblock 327 65 -339 minecraft:grass_block
fill 268 65 -338 276 65 -338 minecraft:smooth_quartz
fill 298 65 -338 300 65 -338 minecraft:smooth_quartz
setblock 301 65 -338 minecraft:light_gray_concrete
fill 302 65 -338 312 65 -338 minecraft:smooth_quartz
setblock 313 65 -338 minecraft:light_gray_concrete
fill 314 65 -338 324 65 -338 minecraft:smooth_quartz
setblock 325 65 -338 minecraft:light_gray_concrete
setblock 326 65 -338 minecraft:smooth_quartz
setblock 327 65 -338 minecraft:grass_block
fill 267 65 -337 276 65 -337 minecraft:smooth_quartz
setblock 277 65 -337 minecraft:light_gray_concrete
fill 297 65 -337 300 65 -337 minecraft:smooth_quartz
setblock 301 65 -337 minecraft:light_gray_concrete
fill 302 65 -337 312 65 -337 minecraft:smooth_quartz
setblock 313 65 -337 minecraft:light_gray_concrete
fill 314 65 -337 324 65 -337 minecraft:smooth_quartz
setblock 325 65 -337 minecraft:light_gray_concrete
setblock 326 65 -337 minecraft:smooth_quartz
setblock 327 65 -337 minecraft:grass_block
fill 266 65 -336 276 65 -336 minecraft:smooth_quartz
setblock 277 65 -336 minecraft:light_gray_concrete
setblock 278 65 -336 minecraft:smooth_quartz
fill 296 65 -336 300 65 -336 minecraft:smooth_quartz
setblock 301 65 -336 minecraft:light_gray_concrete
fill 302 65 -336 312 65 -336 minecraft:smooth_quartz
setblock 313 65 -336 minecraft:light_gray_concrete
fill 314 65 -336 324 65 -336 minecraft:smooth_quartz
setblock 325 65 -336 minecraft:light_gray_concrete
setblock 326 65 -336 minecraft:smooth_quartz
setblock 327 65 -336 minecraft:grass_block
setblock 265 65 -335 minecraft:light_gray_concrete
fill 266 65 -335 276 65 -335 minecraft:smooth_quartz
setblock 277 65 -335 minecraft:light_gray_concrete
fill 278 65 -335 279 65 -335 minecraft:smooth_quartz
setblock 281 65 -335 minecraft:smooth_quartz
setblock 293 65 -335 minecraft:smooth_quartz
fill 295 65 -335 300 65 -335 minecraft:smooth_quartz
setblock 301 65 -335 minecraft:light_gray_concrete
fill 302 65 -335 312 65 -335 minecraft:smooth_quartz
setblock 313 65 -335 minecraft:light_gray_concrete
fill 314 65 -335 324 65 -335 minecraft:smooth_quartz
setblock 325 65 -335 minecraft:light_gray_concrete
setblock 326 65 -335 minecraft:smooth_quartz
setblock 327 65 -335 minecraft:grass_block
setblock 264 65 -334 minecraft:smooth_quartz
setblock 265 65 -334 minecraft:light_gray_concrete
fill 266 65 -334 276 65 -334 minecraft:smooth_quartz
setblock 277 65 -334 minecraft:light_gray_concrete
fill 278 65 -334 282 65 -334 minecraft:smooth_quartz
setblock 284 65 -334 minecraft:smooth_quartz
setblock 290 65 -334 minecraft:smooth_quartz
fill 292 65 -334 300 65 -334 minecraft:smooth_quartz
setblock 301 65 -334 minecraft:light_gray_concrete
fill 302 65 -334 312 65 -334 minecraft:smooth_quartz
setblock 313 65 -334 minecraft:light_gray_concrete
fill 314 65 -334 324 65 -334 minecraft:smooth_quartz
setblock 325 65 -334 minecraft:light_gray_concrete
setblock 326 65 -334 minecraft:smooth_quartz
setblock 327 65 -334 minecraft:grass_block
setblock 264 65 -333 minecraft:smooth_quartz
setblock 265 65 -333 minecraft:light_gray_concrete
fill 266 65 -333 267 65 -333 minecraft:smooth_quartz
setblock 269 65 -333 minecraft:smooth_quartz
fill 273 65 -333 276 65 -333 minecraft:smooth_quartz
setblock 277 65 -333 minecraft:light_gray_concrete
fill 278 65 -333 285 65 -333 minecraft:smooth_quartz
setblock 287 65 -333 minecraft:smooth_quartz
setblock 289 65 -333 minecraft:light_gray_concrete
fill 290 65 -333 300 65 -333 minecraft:smooth_quartz
setblock 301 65 -333 minecraft:light_gray_concrete
fill 302 65 -333 312 65 -333 minecraft:smooth_quartz
setblock 313 65 -333 minecraft:light_gray_concrete
fill 314 65 -333 324 65 -333 minecraft:smooth_quartz
setblock 325 65 -333 minecraft:light_gray_concrete
setblock 326 65 -333 minecraft:smooth_quartz
setblock 327 65 -333 minecraft:grass_block
fill 264 65 -332 267 65 -332 minecraft:light_gray_concrete
setblock 269 65 -332 minecraft:light_gray_concrete
setblock 275 65 -332 minecraft:light_gray_concrete
fill 277 65 -332 326 65 -332 minecraft:light_gray_concrete
setblock 327 65 -332 minecraft:grass_block
setblock 264 65 -331 minecraft:smooth_quartz
setblock 265 65 -331 minecraft:light_gray_concrete
fill 266 65 -331 267 65 -331 minecraft:smooth_quartz
setblock 269 65 -331 minecraft:smooth_quartz
setblock 275 65 -331 minecraft:smooth_quartz
setblock 277 65 -331 minecraft:light_gray_concrete
fill 278 65 -331 288 65 -331 minecraft:smooth_quartz
setblock 289 65 -331 minecraft:light_gray_concrete
fill 290 65 -331 300 65 -331 minecraft:smooth_quartz
setblock 301 65 -331 minecraft:light_gray_concrete
fill 302 65 -331 312 65 -331 minecraft:smooth_quartz
setblock 313 65 -331 minecraft:light_gray_concrete
fill 314 65 -331 324 65 -331 minecraft:smooth_quartz
setblock 325 65 -331 minecraft:light_gray_concrete
setblock 326 65 -331 minecraft:smooth_quartz
setblock 327 65 -331 minecraft:grass_block
setblock 264 65 -330 minecraft:smooth_quartz
setblock 265 65 -330 minecraft:light_gray_concrete
fill 266 65 -330 267 65 -330 minecraft:smooth_quartz
setblock 269 65 -330 minecraft:smooth_quartz
setblock 275 65 -330 minecraft:smooth_quartz
setblock 277 65 -330 minecraft:light_gray_concrete
fill 278 65 -330 279 65 -330 minecraft:smooth_quartz
fill 281 65 -330 288 65 -330 minecraft:smooth_quartz
setblock 289 65 -330 minecraft:light_gray_concrete
fill 290 65 -330 300 65 -330 minecraft:smooth_quartz
setblock 301 65 -330 minecraft:light_gray_concrete
fill 302 65 -330 312 65 -330 minecraft:smooth_quartz
setblock 313 65 -330 minecraft:light_gray_concrete
fill 314 65 -330 324 65 -330 minecraft:smooth_quartz
setblock 325 65 -330 minecraft:light_gray_concrete
setblock 326 65 -330 minecraft:smooth_quartz
setblock 327 65 -330 minecraft:grass_block
setblock 264 65 -329 minecraft:smooth_quartz
setblock 265 65 -329 minecraft:light_gray_concrete
fill 266 65 -329 267 65 -329 minecraft:smooth_quartz
setblock 269 65 -329 minecraft:smooth_quartz
setblock 275 65 -329 minecraft:smooth_quartz
setblock 277 65 -329 minecraft:light_gray_concrete
fill 278 65 -329 279 65 -329 minecraft:smooth_quartz
fill 282 65 -329 288 65 -329 minecraft:smooth_quartz
setblock 289 65 -329 minecraft:light_gray_concrete
fill 290 65 -329 300 65 -329 minecraft:smooth_quartz
setblock 301 65 -329 minecraft:light_gray_concrete
fill 302 65 -329 312 65 -329 minecraft:smooth_quartz
setblock 313 65 -329 minecraft:light_gray_concrete
fill 314 65 -329 324 65 -329 minecraft:smooth_quartz
setblock 325 65 -329 minecraft:light_gray_concrete
setblock 326 65 -329 minecraft:smooth_quartz
setblock 327 65 -329 minecraft:grass_block
setblock 264 65 -328 minecraft:smooth_quartz
setblock 265 65 -328 minecraft:light_gray_concrete
fill 266 65 -328 267 65 -328 minecraft:smooth_quartz
setblock 269 65 -328 minecraft:smooth_quartz
setblock 275 65 -328 minecraft:smooth_quartz
setblock 277 65 -328 minecraft:light_gray_concrete
fill 278 65 -328 279 65 -328 minecraft:smooth_quartz
fill 282 65 -328 288 65 -328 minecraft:smooth_quartz
setblock 289 65 -328 minecraft:light_gray_concrete
fill 290 65 -328 300 65 -328 minecraft:smooth_quartz
setblock 301 65 -328 minecraft:light_gray_concrete
fill 302 65 -328 312 65 -328 minecraft:smooth_quartz
setblock 313 65 -328 minecraft:light_gray_concrete
fill 314 65 -328 324 65 -328 minecraft:smooth_quartz
setblock 325 65 -328 minecraft:light_gray_concrete
setblock 326 65 -328 minecraft:smooth_quartz
setblock 327 65 -328 minecraft:grass_block
setblock 264 65 -327 minecraft:smooth_quartz
setblock 265 65 -327 minecraft:light_gray_concrete
fill 266 65 -327 267 65 -327 minecraft:smooth_quartz
setblock 269 65 -327 minecraft:smooth_quartz
setblock 275 65 -327 minecraft:smooth_quartz
setblock 277 65 -327 minecraft:light_gray_concrete
fill 278 65 -327 279 65 -327 minecraft:smooth_quartz
fill 282 65 -327 288 65 -327 minecraft:smooth_quartz
setblock 289 65 -327 minecraft:light_gray_concrete
fill 290 65 -327 300 65 -327 minecraft:smooth_quartz
setblock 301 65 -327 minecraft:light_gray_concrete
fill 302 65 -327 312 65 -327 minecraft:smooth_quartz
setblock 313 65 -327 minecraft:light_gray_concrete
fill 314 65 -327 324 65 -327 minecraft:smooth_quartz
setblock 325 65 -327 minecraft:light_gray_concrete
setblock 326 65 -327 minecraft:smooth_quartz
setblock 327 65 -327 minecraft:grass_block
setblock 264 65 -326 minecraft:smooth_quartz
setblock 265 65 -326 minecraft:light_gray_concrete
setblock 266 65 -326 minecraft:smooth_quartz
setblock 276 65 -326 minecraft:smooth_quartz
setblock 277 65 -326 minecraft:light_gray_concrete
fill 278 65 -326 279 65 -326 minecraft:smooth_quartz
fill 281 65 -326 288 65 -326 minecraft:smooth_quartz
setblock 289 65 -326 minecraft:light_gray_concrete
fill 290 65 -326 300 65 -326 minecraft:smooth_quartz
setblock 301 65 -326 minecraft:light_gray_concrete
fill 302 65 -326 310 65 -326 minecraft:smooth_quartz
setblock 311 65 -326 minecraft:sea_lantern
setblock 312 65 -326 minecraft:smooth_quartz
setblock 313 65 -326 minecraft:light_gray_concrete
fill 314 65 -326 324 65 -326 minecraft:smooth_quartz
setblock 325 65 -326 minecraft:light_gray_concrete
setblock 326 65 -326 minecraft:smooth_quartz
setblock 327 65 -326 minecraft:grass_block
setblock 264 65 -325 minecraft:smooth_quartz
setblock 265 65 -325 minecraft:light_gray_concrete
setblock 266 65 -325 minecraft:smooth_quartz
setblock 276 65 -325 minecraft:smooth_quartz
setblock 277 65 -325 minecraft:light_gray_concrete
fill 278 65 -325 288 65 -325 minecraft:smooth_quartz
setblock 289 65 -325 minecraft:light_gray_concrete
fill 290 65 -325 300 65 -325 minecraft:smooth_quartz
setblock 301 65 -325 minecraft:light_gray_concrete
fill 302 65 -325 309 65 -325 minecraft:smooth_quartz
fill 310 65 -325 312 65 -325 minecraft:grass_block
setblock 313 65 -325 minecraft:light_gray_concrete
fill 314 65 -325 324 65 -325 minecraft:smooth_quartz
setblock 325 65 -325 minecraft:light_gray_concrete
setblock 326 65 -325 minecraft:smooth_quartz
setblock 327 65 -325 minecraft:grass_block
setblock 264 65 -324 minecraft:smooth_quartz
setblock 265 65 -324 minecraft:light_gray_concrete
setblock 266 65 -324 minecraft:smooth_quartz
setblock 276 65 -324 minecraft:smooth_quartz
setblock 277 65 -324 minecraft:light_gray_concrete
fill 278 65 -324 288 65 -324 minecraft:smooth_quartz
setblock 289 65 -324 minecraft:light_gray_concrete
fill 290 65 -324 300 65 -324 minecraft:smooth_quartz
setblock 301 65 -324 minecraft:light_gray_concrete
fill 302 65 -324 308 65 -324 minecraft:smooth_quartz
fill 309 65 -324 313 65 -324 minecraft:grass_block
fill 314 65 -324 324 65 -324 minecraft:smooth_quartz
setblock 325 65 -324 minecraft:light_gray_concrete
setblock 326 65 -324 minecraft:smooth_quartz
setblock 327 65 -324 minecraft:grass_block
setblock 264 65 -323 minecraft:smooth_quartz
setblock 265 65 -323 minecraft:light_gray_concrete
setblock 266 65 -323 minecraft:smooth_quartz
setblock 276 65 -323 minecraft:smooth_quartz
setblock 277 65 -323 minecraft:light_gray_concrete
fill 278 65 -323 279 65 -323 minecraft:smooth_quartz
fill 281 65 -323 288 65 -323 minecraft:smooth_quartz
setblock 289 65 -323 minecraft:light_gray_concrete
fill 290 65 -323 300 65 -323 minecraft:smooth_quartz
setblock 301 65 -323 minecraft:light_gray_concrete
fill 302 65 -323 307 65 -323 minecraft:smooth_quartz
fill 308 65 -323 314 65 -323 minecraft:grass_block
fill 315 65 -323 324 65 -323 minecraft:smooth_quartz
setblock 325 65 -323 minecraft:light_gray_concrete
setblock 326 65 -323 minecraft:smooth_quartz
setblock 327 65 -323 minecraft:grass_block
setblock 264 65 -322 minecraft:smooth_quartz
setblock 265 65 -322 minecraft:light_gray_concrete
setblock 266 65 -322 minecraft:smooth_quartz
setblock 276 65 -322 minecraft:smooth_quartz
setblock 277 65 -322 minecraft:light_gray_concrete
fill 278 65 -322 279 65 -322 minecraft:smooth_quartz
fill 281 65 -322 288 65 -322 minecraft:smooth_quartz
setblock 289 65 -322 minecraft:light_gray_concrete
fill 290 65 -322 300 65 -322 minecraft:smooth_quartz
setblock 301 65 -322 minecraft:light_gray_concrete
fill 302 65 -322 306 65 -322 minecraft:smooth_quartz
setblock 307 65 -322 minecraft:sea_lantern
fill 308 65 -322 314 65 -322 minecraft:grass_block
setblock 315 65 -322 minecraft:sea_lantern
fill 316 65 -322 324 65 -322 minecraft:smooth_quartz
setblock 325 65 -322 minecraft:light_gray_concrete
setblock 326 65 -322 minecraft:smooth_quartz
setblock 327 65 -322 minecraft:grass_block
setblock 264 65 -321 minecraft:smooth_quartz
setblock 265 65 -321 minecraft:light_gray_concrete
setblock 266 65 -321 minecraft:smooth_quartz
setblock 276 65 -321 minecraft:smooth_quartz
setblock 277 65 -321 minecraft:light_gray_concrete
fill 278 65 -321 279 65 -321 minecraft:smooth_quartz
fill 281 65 -321 288 65 -321 minecraft:smooth_quartz
setblock 289 65 -321 minecraft:light_gray_concrete
fill 290 65 -321 300 65 -321 minecraft:smooth_quartz
setblock 301 65 -321 minecraft:light_gray_concrete
fill 302 65 -321 307 65 -321 minecraft:smooth_quartz
fill 308 65 -321 314 65 -321 minecraft:grass_block
fill 315 65 -321 324 65 -321 minecraft:smooth_quartz
setblock 325 65 -321 minecraft:light_gray_concrete
setblock 326 65 -321 minecraft:smooth_quartz
setblock 327 65 -321 minecraft:grass_block
fill 264 65 -320 266 65 -320 minecraft:light_gray_concrete
fill 276 65 -320 278 65 -320 minecraft:light_gray_concrete
fill 280 65 -320 308 65 -320 minecraft:light_gray_concrete
fill 309 65 -320 313 65 -320 minecraft:grass_block
fill 314 65 -320 326 65 -320 minecraft:light_gray_concrete
setblock 327 65 -320 minecraft:grass_block
setblock 264 65 -319 minecraft:smooth_quartz
setblock 265 65 -319 minecraft:light_gray_concrete
setblock 266 65 -319 minecraft:smooth_quartz
setblock 276 65 -319 minecraft:smooth_quartz
setblock 277 65 -319 minecraft:light_gray_concrete
fill 278 65 -319 288 65 -319 minecraft:smooth_quartz
setblock 289 65 -319 minecraft:light_gray_concrete
fill 290 65 -319 300 65 -319 minecraft:smooth_quartz
setblock 301 65 -319 minecraft:light_gray_concrete
fill 302 65 -319 309 65 -319 minecraft:smooth_quartz
fill 310 65 -319 312 65 -319 minecraft:grass_block
setblock 313 65 -319 minecraft:light_gray_concrete
fill 314 65 -319 324 65 -319 minecraft:smooth_quartz
setblock 325 65 -319 minecraft:light_gray_concrete
setblock 326 65 -319 minecraft:smooth_quartz
setblock 327 65 -319 minecraft:grass_block
setblock 268 66 -380 minecraft:air
setblock 272 66 -378 minecraft:air
setblock 308 66 -378 minecraft:air
setblock 321 66 -372 minecraft:air
setblock 300 66 -371 minecraft:air
setblock 311 66 -370 minecraft:oak_log
setblock 312 66 -365 minecraft:air
setblock 301 66 -358 minecraft:air
setblock 325 66 -356 minecraft:air
setblock 311 66 -347 minecraft:air
setblock 311 66 -346 minecraft:oak_log
setblock 322 66 -340 minecraft:air
setblock 302 66 -333 minecraft:air
setblock 319 66 -331 minecraft:air
setblock 265 66 -329 minecraft:air
setblock 279 66 -328 minecraft:air
setblock 288 66 -327 minecraft:air
setblock 264 66 -323 minecraft:air
setblock 278 66 -322 minecraft:air
setblock 311 66 -322 minecraft:oak_log
setblock 277 66 -320 minecraft:air
setblock 306 66 -320 minecraft:air
setblock 311 67 -370 minecraft:oak_log
setblock 311 67 -346 minecraft:oak_log
setblock 265 67 -329 minecraft:air
setblock 279 67 -328 minecraft:air
setblock 264 67 -323 minecraft:air
setblock 278 67 -322 minecraft:air
setblock 311 67 -322 minecraft:oak_log
setblock 311 68 -370 minecraft:oak_log
setblock 311 68 -346 minecraft:oak_log
setblock 265 68 -329 minecraft:air
setblock 279 68 -328 minecraft:air
setblock 264 68 -323 minecraft:air
setblock 278 68 -322 minecraft:air
setblock 311 68 -322 minecraft:oak_log
setblock 311 69 -372 minecraft:oak_leaves[persistent=true]
fill 310 69 -371 312 69 -371 minecraft:oak_leaves[persistent=true]
fill 309 69 -370 310 69 -370 minecraft:oak_leaves[persistent=true]
setblock 311 69 -370 minecraft:oak_log
fill 312 69 -370 313 69 -370 minecraft:oak_leaves[persistent=true]
fill 310 69 -369 312 69 -369 minecraft:oak_leaves[persistent=true]
setblock 311 69 -368 minecraft:oak_leaves[persistent=true]
setblock 311 69 -348 minecraft:oak_leaves[persistent=true]
fill 310 69 -347 312 69 -347 minecraft:oak_leaves[persistent=true]
fill 309 69 -346 310 69 -346 minecraft:oak_leaves[persistent=true]
setblock 311 69 -346 minecraft:oak_log
fill 312 69 -346 313 69 -346 minecraft:oak_leaves[persistent=true]
fill 310 69 -345 312 69 -345 minecraft:oak_leaves[persistent=true]
setblock 311 69 -344 minecraft:oak_leaves[persistent=true]
fill 264 69 -330 266 69 -330 minecraft:air
fill 264 69 -329 266 69 -329 minecraft:air
fill 278 69 -329 279 69 -329 minecraft:air
fill 264 69 -328 266 69 -328 minecraft:air
fill 278 69 -328 279 69 -328 minecraft:air
fill 278 69 -327 279 69 -327 minecraft:air
fill 264 69 -324 265 69 -324 minecraft:air
setblock 311 69 -324 minecraft:oak_leaves[persistent=true]
fill 264 69 -323 265 69 -323 minecraft:air
fill 277 69 -323 279 69 -323 minecraft:air
fill 310 69 -323 312 69 -323 minecraft:oak_leaves[persistent=true]
fill 264 69 -322 265 69 -322 minecraft:air
fill 277 69 -322 279 69 -322 minecraft:air
fill 309 69 -322 310 69 -322 minecraft:oak_leaves[persistent=true]
setblock 311 69 -322 minecraft:oak_log
fill 312 69 -322 313 69 -322 minecraft:oak_leaves[persistent=true]
fill 277 69 -321 279 69 -321 minecraft:air
fill 310 69 -321 312 69 -321 minecraft:oak_leaves[persistent=true]
setblock 311 69 -320 minecraft:oak_leaves[persistent=true]
fill 310 70 -372 312 70 -372 minecraft:oak_leaves[persistent=true]
fill 309 70 -371 313 70 -371 minecraft:oak_leaves[persistent=true]
fill 309 70 -370 310 70 -370 minecraft:oak_leaves[persistent=true]
setblock 311 70 -370 minecraft:oak_log
fill 312 70 -370 313 70 -370 minecraft:oak_leaves[persistent=true]
fill 309 70 -369 313 70 -369 minecraft:oak_leaves[persistent=true]
fill 310 70 -368 312 70 -368 minecraft:oak_leaves[persistent=true]
fill 310 70 -348 312 70 -348 minecraft:oak_leaves[persistent=true]
fill 309 70 -347 313 70 -347 minecraft:oak_leaves[persistent=true]
fill 309 70 -346 310 70 -346 minecraft:oak_leaves[persistent=true]
setblock 311 70 -346 minecraft:oak_log
fill 312 70 -346 313 70 -346 minecraft:oak_leaves[persistent=true]
fill 309 70 -345 313 70 -345 minecraft:oak_leaves[persistent=true]
fill 310 70 -344 312 70 -344 minecraft:oak_leaves[persistent=true]
fill 264 70 -331 266 70 -331 minecraft:air
fill 264 70 -330 267 70 -330 minecraft:air
fill 278 70 -330 279 70 -330 minecraft:air
fill 264 70 -329 267 70 -329 minecraft:air
fill 277 70 -329 279 70 -329 minecraft:air
fill 264 70 -328 267 70 -328 minecraft:air
fill 277 70 -328 279 70 -328 minecraft:air
fill 264 70 -327 266 70 -327 minecraft:air
fill 277 70 -327 279 70 -327 minecraft:air
fill 278 70 -326 279 70 -326 minecraft:air
fill 264 70 -325 265 70 -325 minecraft:air
fill 264 70 -324 266 70 -324 minecraft:air
fill 277 70 -324 279 70 -324 minecraft:air
fill 310 70 -324 312 70 -324 minecraft:oak_leaves[persistent=true]
fill 264 70 -323 266 70 -323 minecraft:air
fill 276 70 -323 279 70 -323 minecraft:air
fill 309 70 -323 313 70 -323 minecraft:oak_leaves[persistent=true]
fill 264 70 -322 266 70 -322 minecraft:air
fill 276 70 -322 279 70 -322 minecraft:air
fill 309 70 -322 310 70 -322 minecraft:oak_leaves[persistent=true]
setblock 311 70 -322 minecraft:oak_log
fill 312 70 -322 313 70 -322 minecraft:oak_leaves[persistent=true]
fill 264 70 -321 265 70 -321 minecraft:air
fill 276 70 -321 279 70 -321 minecraft:air
fill 309 70 -321 313 70 -321 minecraft:oak_leaves[persistent=true]
fill 277 70 -320 278 70 -320 minecraft:air
fill 310 70 -320 312 70 -320 minecraft:oak_leaves[persistent=true]
fill 264 70 -319 265 70 -319 minecraft:air
setblock 311 71 -372 minecraft:oak_leaves[persistent=true]
fill 310 71 -371 312 71 -371 minecraft:oak_leaves[persistent=true]
fill 309 71 -370 313 71 -370 minecraft:oak_leaves[persistent=true]
fill 310 71 -369 312 71 -369 minecraft:oak_leaves[persistent=true]
setblock 311 71 -368 minecraft:oak_leaves[persistent=true]
setblock 311 71 -348 minecraft:oak_leaves[persistent=true]
fill 310 71 -347 312 71 -347 minecraft:oak_leaves[persistent=true]
fill 309 71 -346 313 71 -346 minecraft:oak_leaves[persistent=true]
fill 310 71 -345 312 71 -345 minecraft:oak_leaves[persistent=true]
setblock 311 71 -344 minecraft:oak_leaves[persistent=true]
fill 264 71 -331 266 71 -331 minecraft:air
fill 264 71 -330 267 71 -330 minecraft:air
fill 278 71 -330 279 71 -330 minecraft:air
fill 264 71 -329 267 71 -329 minecraft:air
fill 277 71 -329 279 71 -329 minecraft:air
fill 264 71 -328 267 71 -328 minecraft:air
fill 277 71 -328 279 71 -328 minecraft:air
fill 264 71 -327 266 71 -327 minecraft:air
fill 277 71 -327 279 71 -327 minecraft:air
fill 278 71 -326 279 71 -326 minecraft:air
fill 264 71 -325 265 71 -325 minecraft:air
fill 264 71 -324 266 71 -324 minecraft:air
fill 277 71 -324 279 71 -324 minecraft:air
setblock 311 71 -324 minecraft:oak_leaves[persistent=true]
fill 264 71 -323 266 71 -323 minecraft:air
fill 276 71 -323 279 71 -323 minecraft:air
fill 310 71 -323 312 71 -323 minecraft:oak_leaves[persistent=true]
fill 264 71 -322 266 71 -322 minecraft:air
fill 276 71 -322 279 71 -322 minecraft:air
fill 309 71 -322 313 71 -322 minecraft:oak_leaves[persistent=true]
fill 264 71 -321 265 71 -321 minecraft:air
fill 276 71 -321 279 71 -321 minecraft:air
fill 310 71 -321 312 71 -321 minecraft:oak_leaves[persistent=true]
fill 277 71 -320 278 71 -320 minecraft:air
setblock 311 71 -320 minecraft:oak_leaves[persistent=true]
fill 264 71 -319 265 71 -319 minecraft:air
setblock 311 72 -370 minecraft:oak_leaves[persistent=true]
setblock 311 72 -346 minecraft:oak_leaves[persistent=true]
setblock 265 72 -330 minecraft:air
fill 264 72 -329 266 72 -329 minecraft:air
setblock 279 72 -329 minecraft:air
setblock 265 72 -328 minecraft:air
fill 278 72 -328 279 72 -328 minecraft:air
setblock 279 72 -327 minecraft:air
setblock 264 72 -324 minecraft:air
fill 264 72 -323 265 72 -323 minecraft:air
setblock 278 72 -323 minecraft:air
setblock 264 72 -322 minecraft:air
fill 277 72 -322 279 72 -322 minecraft:air
setblock 311 72 -322 minecraft:oak_leaves[persistent=true]
setblock 278 72 -321 minecraft:air
forceload remove 264 -382 327 -319
tellraw @a {"text":"Campus bau a12 fertig.","color":"green"}
