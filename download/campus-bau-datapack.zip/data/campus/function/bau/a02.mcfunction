# Abschnitt a02: x 72..135, z -446..-383 (53990 Blöcke)
forceload add 72 -446 135 -383
tellraw @a {"text":"Campus bau a02: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a02_1 2s
