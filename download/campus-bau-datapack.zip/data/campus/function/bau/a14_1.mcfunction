setblock 419 45 -382 minecraft:stone
setblock 419 45 -381 minecraft:stone
setblock 419 45 -380 minecraft:stone
setblock 419 45 -379 minecraft:stone
fill 420 45 -378 422 45 -378 minecraft:stone
fill 420 45 -377 422 45 -377 minecraft:stone
fill 420 45 -376 422 45 -376 minecraft:stone
fill 420 45 -375 422 45 -375 minecraft:stone
fill 420 45 -374 422 45 -374 minecraft:stone
fill 420 45 -373 422 45 -373 minecraft:stone
fill 414 45 -372 415 45 -372 minecraft:stone
fill 420 45 -372 422 45 -372 minecraft:stone
fill 413 45 -371 415 45 -371 minecraft:stone
fill 420 45 -371 422 45 -371 minecraft:stone
setblock 414 45 -370 minecraft:stone
fill 420 45 -370 422 45 -370 minecraft:stone
fill 420 45 -369 422 45 -369 minecraft:stone
fill 420 45 -368 422 45 -368 minecraft:stone
fill 420 45 -367 422 45 -367 minecraft:stone
fill 420 45 -366 422 45 -366 minecraft:stone
fill 420 45 -365 422 45 -365 minecraft:stone
fill 420 45 -364 422 45 -364 minecraft:stone
fill 420 45 -363 422 45 -363 minecraft:stone
fill 420 45 -362 422 45 -362 minecraft:stone
fill 420 45 -361 422 45 -361 minecraft:stone
fill 417 45 -360 418 45 -360 minecraft:stone
fill 420 45 -360 422 45 -360 minecraft:stone
fill 417 45 -359 418 45 -359 minecraft:stone
fill 420 45 -359 422 45 -359 minecraft:stone
fill 417 45 -358 418 45 -358 minecraft:stone
fill 420 45 -358 422 45 -358 minecraft:stone
fill 417 45 -357 418 45 -357 minecraft:stone
fill 420 45 -357 422 45 -357 minecraft:stone
fill 417 45 -356 418 45 -356 minecraft:stone
fill 420 45 -356 422 45 -356 minecraft:stone
fill 417 45 -355 418 45 -355 minecraft:stone
fill 420 45 -355 422 45 -355 minecraft:stone
fill 420 45 -354 422 45 -354 minecraft:stone
fill 395 45 -334 396 45 -334 minecraft:stone
fill 396 45 -333 400 45 -333 minecraft:stone
fill 396 45 -332 399 45 -332 minecraft:stone
fill 396 45 -331 399 45 -331 minecraft:stone
fill 396 45 -330 399 45 -330 minecraft:stone
fill 397 45 -329 399 45 -329 minecraft:stone
fill 416 45 -328 418 45 -328 minecraft:stone
fill 415 45 -327 419 45 -327 minecraft:stone
fill 415 45 -326 419 45 -326 minecraft:stone
fill 415 45 -325 419 45 -325 minecraft:stone
fill 416 45 -324 418 45 -324 minecraft:stone
fill 399 45 -320 400 45 -320 minecraft:stone
fill 397 45 -319 401 45 -319 minecraft:stone
setblock 419 46 -382 minecraft:stone
setblock 419 46 -381 minecraft:stone
setblock 419 46 -380 minecraft:stone
setblock 419 46 -379 minecraft:stone
fill 420 46 -378 422 46 -378 minecraft:stone
fill 420 46 -377 422 46 -377 minecraft:stone
fill 420 46 -376 422 46 -376 minecraft:stone
fill 420 46 -375 422 46 -375 minecraft:stone
fill 420 46 -374 422 46 -374 minecraft:stone
fill 420 46 -373 422 46 -373 minecraft:stone
fill 413 46 -372 415 46 -372 minecraft:stone
fill 420 46 -372 422 46 -372 minecraft:stone
fill 413 46 -371 415 46 -371 minecraft:stone
fill 420 46 -371 422 46 -371 minecraft:stone
setblock 414 46 -370 minecraft:stone
fill 420 46 -370 422 46 -370 minecraft:stone
fill 420 46 -369 422 46 -369 minecraft:stone
fill 420 46 -368 422 46 -368 minecraft:stone
fill 420 46 -367 422 46 -367 minecraft:stone
fill 420 46 -366 422 46 -366 minecraft:stone
fill 420 46 -365 422 46 -365 minecraft:stone
fill 420 46 -364 422 46 -364 minecraft:stone
fill 420 46 -363 422 46 -363 minecraft:stone
fill 420 46 -362 422 46 -362 minecraft:stone
fill 420 46 -361 422 46 -361 minecraft:stone
fill 420 46 -360 422 46 -360 minecraft:stone
fill 417 46 -359 418 46 -359 minecraft:stone
fill 420 46 -359 422 46 -359 minecraft:stone
fill 417 46 -358 418 46 -358 minecraft:stone
fill 420 46 -358 422 46 -358 minecraft:stone
fill 417 46 -357 418 46 -357 minecraft:stone
fill 420 46 -357 422 46 -357 minecraft:stone
fill 417 46 -356 418 46 -356 minecraft:stone
fill 420 46 -356 422 46 -356 minecraft:stone
fill 417 46 -355 418 46 -355 minecraft:stone
fill 420 46 -355 422 46 -355 minecraft:stone
fill 420 46 -354 422 46 -354 minecraft:stone
setblock 395 46 -334 minecraft:stone
fill 396 46 -333 398 46 -333 minecraft:stone
fill 396 46 -332 399 46 -332 minecraft:stone
setblock 422 46 -332 minecraft:stone
fill 396 46 -331 399 46 -331 minecraft:stone
fill 421 46 -331 422 46 -331 minecraft:stone
fill 396 46 -330 399 46 -330 minecraft:stone
fill 421 46 -330 422 46 -330 minecraft:stone
fill 396 46 -329 399 46 -329 minecraft:stone
fill 421 46 -329 422 46 -329 minecraft:stone
fill 416 46 -328 418 46 -328 minecraft:stone
setblock 422 46 -328 minecraft:stone
fill 415 46 -327 419 46 -327 minecraft:stone
fill 411 46 -326 419 46 -326 minecraft:stone
fill 409 46 -325 419 46 -325 minecraft:stone
fill 408 46 -324 418 46 -324 minecraft:stone
fill 405 46 -323 414 46 -323 minecraft:stone
fill 404 46 -322 414 46 -322 minecraft:stone
fill 401 46 -321 402 46 -321 minecraft:stone
fill 404 46 -321 412 46 -321 minecraft:stone
fill 399 46 -320 403 46 -320 minecraft:stone
fill 405 46 -320 408 46 -320 minecraft:stone
fill 398 46 -319 407 46 -319 minecraft:stone
setblock 419 47 -379 minecraft:stone
fill 420 47 -378 422 47 -378 minecraft:stone
fill 420 47 -377 422 47 -377 minecraft:stone
fill 420 47 -376 422 47 -376 minecraft:stone
fill 420 47 -375 422 47 -375 minecraft:stone
fill 420 47 -374 422 47 -374 minecraft:stone
fill 420 47 -373 422 47 -373 minecraft:stone
fill 414 47 -372 415 47 -372 minecraft:stone
fill 420 47 -372 422 47 -372 minecraft:stone
fill 413 47 -371 415 47 -371 minecraft:stone
fill 420 47 -371 422 47 -371 minecraft:stone
fill 420 47 -370 422 47 -370 minecraft:stone
fill 420 47 -369 422 47 -369 minecraft:stone
fill 420 47 -368 422 47 -368 minecraft:stone
fill 420 47 -367 422 47 -367 minecraft:stone
fill 420 47 -366 422 47 -366 minecraft:stone
fill 420 47 -365 422 47 -365 minecraft:stone
fill 420 47 -364 422 47 -364 minecraft:stone
fill 420 47 -363 422 47 -363 minecraft:stone
fill 420 47 -362 422 47 -362 minecraft:stone
fill 420 47 -361 422 47 -361 minecraft:stone
fill 420 47 -360 422 47 -360 minecraft:stone
fill 417 47 -359 418 47 -359 minecraft:stone
fill 420 47 -359 422 47 -359 minecraft:stone
fill 417 47 -358 418 47 -358 minecraft:stone
fill 420 47 -358 422 47 -358 minecraft:stone
fill 417 47 -357 418 47 -357 minecraft:stone
fill 420 47 -357 422 47 -357 minecraft:stone
fill 417 47 -356 418 47 -356 minecraft:stone
fill 420 47 -356 422 47 -356 minecraft:stone
fill 417 47 -355 418 47 -355 minecraft:stone
fill 420 47 -355 422 47 -355 minecraft:stone
fill 420 47 -354 422 47 -354 minecraft:stone
fill 399 47 -353 419 47 -353 minecraft:stone
fill 420 47 -352 421 47 -352 minecraft:stone
setblock 395 47 -333 minecraft:stone
fill 396 47 -332 399 47 -332 minecraft:stone
setblock 422 47 -332 minecraft:stone
fill 396 47 -331 399 47 -331 minecraft:stone
fill 421 47 -331 422 47 -331 minecraft:stone
fill 396 47 -330 399 47 -330 minecraft:stone
fill 420 47 -330 422 47 -330 minecraft:stone
fill 396 47 -329 399 47 -329 minecraft:stone
fill 420 47 -329 422 47 -329 minecraft:stone
fill 416 47 -328 418 47 -328 minecraft:stone
fill 420 47 -328 422 47 -328 minecraft:stone
fill 414 47 -327 422 47 -327 minecraft:stone
fill 410 47 -326 419 47 -326 minecraft:stone
fill 421 47 -326 422 47 -326 minecraft:stone
fill 409 47 -325 419 47 -325 minecraft:stone
fill 408 47 -324 418 47 -324 minecraft:stone
fill 404 47 -323 416 47 -323 minecraft:stone
fill 403 47 -322 414 47 -322 minecraft:stone
fill 401 47 -321 413 47 -321 minecraft:stone
fill 399 47 -320 408 47 -320 minecraft:stone
fill 398 47 -319 407 47 -319 minecraft:stone
setblock 419 48 -382 minecraft:stone
setblock 419 48 -381 minecraft:stone
setblock 419 48 -380 minecraft:stone
setblock 419 48 -379 minecraft:stone
fill 414 48 -372 416 48 -372 minecraft:stone
fill 414 48 -371 416 48 -371 minecraft:stone
fill 392 48 -355 393 48 -355 minecraft:stone
fill 392 48 -354 396 48 -354 minecraft:stone
fill 392 48 -353 396 48 -353 minecraft:stone
fill 392 48 -352 396 48 -352 minecraft:stone
fill 392 48 -351 396 48 -351 minecraft:stone
fill 392 48 -350 396 48 -350 minecraft:stone
fill 392 48 -349 396 48 -349 minecraft:stone
fill 392 48 -348 396 48 -348 minecraft:stone
setblock 392 48 -344 minecraft:stone
fill 396 48 -332 399 48 -332 minecraft:stone
setblock 422 48 -332 minecraft:stone
fill 396 48 -331 399 48 -331 minecraft:stone
fill 421 48 -331 422 48 -331 minecraft:stone
fill 396 48 -330 399 48 -330 minecraft:stone
fill 420 48 -330 422 48 -330 minecraft:stone
fill 396 48 -329 399 48 -329 minecraft:stone
fill 419 48 -329 422 48 -329 minecraft:stone
fill 416 48 -328 422 48 -328 minecraft:stone
fill 413 48 -327 422 48 -327 minecraft:stone
fill 410 48 -326 422 48 -326 minecraft:stone
fill 409 48 -325 419 48 -325 minecraft:stone
fill 408 48 -324 418 48 -324 minecraft:stone
fill 404 48 -323 416 48 -323 minecraft:stone
fill 403 48 -322 415 48 -322 minecraft:stone
fill 401 48 -321 413 48 -321 minecraft:stone
fill 399 48 -320 408 48 -320 minecraft:stone
fill 398 48 -319 407 48 -319 minecraft:stone
fill 414 49 -372 416 49 -372 minecraft:stone
fill 414 49 -371 416 49 -371 minecraft:stone
setblock 392 49 -360 minecraft:stone
fill 392 49 -359 393 49 -359 minecraft:stone
fill 392 49 -358 395 49 -358 minecraft:stone
fill 392 49 -357 396 49 -357 minecraft:stone
fill 392 49 -356 396 49 -356 minecraft:stone
fill 392 49 -355 396 49 -355 minecraft:stone
fill 392 49 -354 396 49 -354 minecraft:stone
fill 392 49 -353 397 49 -353 minecraft:stone
setblock 421 49 -353 minecraft:stone
fill 392 49 -352 397 49 -352 minecraft:stone
fill 392 49 -351 397 49 -351 minecraft:stone
fill 392 49 -350 397 49 -350 minecraft:stone
fill 392 49 -349 397 49 -349 minecraft:stone
fill 392 49 -348 396 49 -348 minecraft:stone
setblock 392 49 -345 minecraft:stone
setblock 392 49 -344 minecraft:stone
fill 395 49 -332 398 49 -332 minecraft:stone
setblock 422 49 -332 minecraft:stone
fill 395 49 -331 398 49 -331 minecraft:stone
fill 421 49 -331 422 49 -331 minecraft:stone
fill 395 49 -330 398 49 -330 minecraft:stone
fill 420 49 -330 422 49 -330 minecraft:stone
fill 396 49 -329 398 49 -329 minecraft:stone
fill 419 49 -329 422 49 -329 minecraft:stone
fill 416 49 -328 422 49 -328 minecraft:stone
fill 413 49 -327 422 49 -327 minecraft:stone
fill 410 49 -326 422 49 -326 minecraft:stone
fill 409 49 -325 419 49 -325 minecraft:stone
fill 408 49 -324 418 49 -324 minecraft:stone
fill 404 49 -323 416 49 -323 minecraft:stone
fill 403 49 -322 415 49 -322 minecraft:stone
fill 401 49 -321 413 49 -321 minecraft:stone
fill 399 49 -320 408 49 -320 minecraft:stone
fill 398 49 -319 407 49 -319 minecraft:stone
fill 415 50 -372 416 50 -372 minecraft:stone
fill 415 50 -371 416 50 -371 minecraft:stone
setblock 422 50 -365 minecraft:stone
fill 421 50 -364 422 50 -364 minecraft:stone
fill 421 50 -363 422 50 -363 minecraft:stone
fill 421 50 -362 422 50 -362 minecraft:stone
fill 392 50 -361 393 50 -361 minecraft:stone
fill 421 50 -361 422 50 -361 minecraft:stone
fill 392 50 -360 396 50 -360 minecraft:stone
setblock 422 50 -360 minecraft:stone
fill 392 50 -359 396 50 -359 minecraft:stone
fill 421 50 -359 422 50 -359 minecraft:stone
fill 392 50 -358 396 50 -358 minecraft:stone
setblock 422 50 -358 minecraft:stone
fill 392 50 -357 396 50 -357 minecraft:stone
setblock 422 50 -357 minecraft:stone
fill 392 50 -356 397 50 -356 minecraft:stone
setblock 422 50 -356 minecraft:stone
fill 392 50 -355 397 50 -355 minecraft:stone
setblock 422 50 -355 minecraft:stone
fill 392 50 -354 397 50 -354 minecraft:stone
setblock 422 50 -354 minecraft:stone
fill 392 50 -353 397 50 -353 minecraft:stone
fill 392 50 -352 398 50 -352 minecraft:stone
setblock 422 50 -352 minecraft:stone
fill 392 50 -351 398 50 -351 minecraft:stone
setblock 422 50 -351 minecraft:stone
fill 392 50 -350 397 50 -350 minecraft:stone
setblock 422 50 -350 minecraft:stone
fill 392 50 -349 397 50 -349 minecraft:stone
setblock 422 50 -349 minecraft:stone
fill 392 50 -348 397 50 -348 minecraft:stone
fill 392 50 -347 394 50 -347 minecraft:stone
fill 392 50 -346 394 50 -346 minecraft:stone
fill 392 50 -345 393 50 -345 minecraft:stone
setblock 392 50 -344 minecraft:stone
setblock 392 50 -343 minecraft:stone
fill 394 50 -332 395 50 -332 minecraft:stone
setblock 422 50 -332 minecraft:stone
fill 394 50 -331 397 50 -331 minecraft:stone
fill 421 50 -331 422 50 -331 minecraft:stone
fill 395 50 -330 398 50 -330 minecraft:stone
fill 420 50 -330 422 50 -330 minecraft:stone
fill 395 50 -329 398 50 -329 minecraft:stone
fill 419 50 -329 422 50 -329 minecraft:stone
setblock 396 50 -328 minecraft:stone
fill 416 50 -328 422 50 -328 minecraft:stone
fill 413 50 -327 422 50 -327 minecraft:stone
fill 410 50 -326 422 50 -326 minecraft:stone
fill 409 50 -325 419 50 -325 minecraft:stone
fill 408 50 -324 418 50 -324 minecraft:stone
fill 404 50 -323 416 50 -323 minecraft:stone
fill 403 50 -322 415 50 -322 minecraft:stone
fill 401 50 -321 413 50 -321 minecraft:stone
fill 399 50 -320 408 50 -320 minecraft:stone
fill 398 50 -319 407 50 -319 minecraft:stone
fill 415 51 -372 416 51 -372 minecraft:stone
fill 415 51 -371 416 51 -371 minecraft:stone
fill 415 51 -370 416 51 -370 minecraft:stone
setblock 392 51 -363 minecraft:stone
setblock 422 51 -363 minecraft:stone
fill 392 51 -362 394 51 -362 minecraft:stone
setblock 422 51 -362 minecraft:stone
fill 392 51 -361 396 51 -361 minecraft:stone
setblock 422 51 -361 minecraft:stone
fill 392 51 -360 396 51 -360 minecraft:stone
setblock 422 51 -360 minecraft:stone
fill 392 51 -359 396 51 -359 minecraft:stone
fill 421 51 -359 422 51 -359 minecraft:stone
fill 392 51 -358 397 51 -358 minecraft:stone
setblock 422 51 -358 minecraft:stone
fill 392 51 -357 397 51 -357 minecraft:stone
fill 421 51 -357 422 51 -357 minecraft:stone
fill 392 51 -356 397 51 -356 minecraft:stone
setblock 422 51 -356 minecraft:stone
fill 392 51 -355 398 51 -355 minecraft:stone
setblock 422 51 -355 minecraft:stone
fill 392 51 -354 398 51 -354 minecraft:stone
setblock 422 51 -354 minecraft:stone
fill 392 51 -353 398 51 -353 minecraft:stone
fill 392 51 -352 399 51 -352 minecraft:stone
setblock 422 51 -352 minecraft:stone
fill 392 51 -351 399 51 -351 minecraft:stone
setblock 422 51 -351 minecraft:stone
fill 392 51 -350 398 51 -350 minecraft:stone
fill 421 51 -350 422 51 -350 minecraft:stone
fill 392 51 -349 398 51 -349 minecraft:stone
fill 421 51 -349 422 51 -349 minecraft:stone
fill 392 51 -348 398 51 -348 minecraft:stone
setblock 422 51 -348 minecraft:stone
fill 392 51 -347 396 51 -347 minecraft:stone
fill 392 51 -346 395 51 -346 minecraft:stone
fill 392 51 -345 394 51 -345 minecraft:stone
fill 392 51 -344 393 51 -344 minecraft:stone
fill 392 51 -343 393 51 -343 minecraft:stone
setblock 392 51 -342 minecraft:stone
fill 393 51 -332 394 51 -332 minecraft:stone
setblock 422 51 -332 minecraft:stone
fill 394 51 -331 397 51 -331 minecraft:stone
fill 421 51 -331 422 51 -331 minecraft:stone
fill 394 51 -330 397 51 -330 minecraft:stone
fill 420 51 -330 422 51 -330 minecraft:stone
fill 394 51 -329 397 51 -329 minecraft:stone
fill 419 51 -329 422 51 -329 minecraft:stone
fill 395 51 -328 396 51 -328 minecraft:stone
fill 416 51 -328 422 51 -328 minecraft:stone
fill 413 51 -327 422 51 -327 minecraft:stone
fill 410 51 -326 422 51 -326 minecraft:stone
fill 409 51 -325 419 51 -325 minecraft:stone
fill 408 51 -324 418 51 -324 minecraft:stone
fill 404 51 -323 416 51 -323 minecraft:stone
fill 403 51 -322 415 51 -322 minecraft:stone
fill 401 51 -321 413 51 -321 minecraft:stone
fill 399 51 -320 408 51 -320 minecraft:stone
fill 398 51 -319 407 51 -319 minecraft:stone
setblock 415 52 -373 minecraft:stone
fill 414 52 -372 416 52 -372 minecraft:stone
fill 414 52 -371 416 52 -371 minecraft:stone
fill 415 52 -370 416 52 -370 minecraft:stone
setblock 392 52 -365 minecraft:stone
fill 392 52 -364 394 52 -364 minecraft:stone
fill 392 52 -363 396 52 -363 minecraft:stone
fill 392 52 -362 396 52 -362 minecraft:stone
fill 392 52 -361 397 52 -361 minecraft:stone
fill 392 52 -360 397 52 -360 minecraft:stone
fill 392 52 -359 397 52 -359 minecraft:stone
fill 392 52 -358 398 52 -358 minecraft:stone
fill 392 52 -357 398 52 -357 minecraft:stone
fill 392 52 -356 399 52 -356 minecraft:stone
fill 392 52 -355 399 52 -355 minecraft:stone
fill 392 52 -354 399 52 -354 minecraft:stone
fill 392 52 -353 400 52 -353 minecraft:stone
fill 392 52 -352 400 52 -352 minecraft:stone
setblock 422 52 -352 minecraft:stone
fill 392 52 -351 400 52 -351 minecraft:stone
setblock 422 52 -351 minecraft:stone
fill 392 52 -350 400 52 -350 minecraft:stone
setblock 422 52 -350 minecraft:stone
fill 392 52 -349 399 52 -349 minecraft:stone
setblock 422 52 -349 minecraft:stone
fill 392 52 -348 399 52 -348 minecraft:stone
fill 392 52 -347 397 52 -347 minecraft:stone
fill 392 52 -346 396 52 -346 minecraft:stone
fill 392 52 -345 394 52 -345 minecraft:stone
fill 392 52 -344 393 52 -344 minecraft:stone
fill 392 52 -343 393 52 -343 minecraft:stone
setblock 392 52 -342 minecraft:stone
setblock 393 52 -332 minecraft:stone
setblock 422 52 -332 minecraft:stone
fill 393 52 -331 396 52 -331 minecraft:stone
fill 421 52 -331 422 52 -331 minecraft:stone
fill 393 52 -330 396 52 -330 minecraft:stone
fill 420 52 -330 422 52 -330 minecraft:stone
fill 394 52 -329 396 52 -329 minecraft:stone
fill 419 52 -329 422 52 -329 minecraft:stone
fill 394 52 -328 397 52 -328 minecraft:stone
fill 416 52 -328 422 52 -328 minecraft:stone
fill 413 52 -327 422 52 -327 minecraft:stone
fill 410 52 -326 422 52 -326 minecraft:stone
fill 409 52 -325 419 52 -325 minecraft:stone
fill 408 52 -324 418 52 -324 minecraft:stone
fill 404 52 -323 416 52 -323 minecraft:stone
fill 403 52 -322 415 52 -322 minecraft:stone
fill 401 52 -321 413 52 -321 minecraft:stone
fill 399 52 -320 409 52 -320 minecraft:stone
fill 398 52 -319 407 52 -319 minecraft:stone
fill 415 53 -373 416 53 -373 minecraft:stone
fill 414 53 -372 416 53 -372 minecraft:stone
fill 414 53 -371 416 53 -371 minecraft:stone
setblock 392 53 -367 minecraft:stone
fill 392 53 -366 393 53 -366 minecraft:stone
fill 392 53 -365 396 53 -365 minecraft:stone
fill 392 53 -364 396 53 -364 minecraft:stone
fill 392 53 -363 397 53 -363 minecraft:stone
fill 392 53 -362 397 53 -362 minecraft:stone
fill 392 53 -361 398 53 -361 minecraft:stone
fill 392 53 -360 398 53 -360 minecraft:stone
fill 392 53 -359 398 53 -359 minecraft:stone
fill 392 53 -358 399 53 -358 minecraft:stone
fill 392 53 -357 399 53 -357 minecraft:stone
fill 392 53 -356 400 53 -356 minecraft:stone
fill 392 53 -355 400 53 -355 minecraft:stone
fill 392 53 -354 400 53 -354 minecraft:stone
fill 392 53 -353 401 53 -353 minecraft:stone
fill 392 53 -352 401 53 -352 minecraft:stone
fill 392 53 -351 401 53 -351 minecraft:stone
fill 392 53 -350 401 53 -350 minecraft:stone
fill 392 53 -349 401 53 -349 minecraft:stone
fill 392 53 -348 401 53 -348 minecraft:stone
fill 392 53 -347 399 53 -347 minecraft:stone
fill 392 53 -346 397 53 -346 minecraft:stone
fill 392 53 -345 394 53 -345 minecraft:stone
fill 392 53 -344 393 53 -344 minecraft:stone
fill 392 53 -343 393 53 -343 minecraft:stone
setblock 392 53 -342 minecraft:stone
setblock 422 53 -332 minecraft:stone
fill 392 53 -331 395 53 -331 minecraft:stone
fill 421 53 -331 422 53 -331 minecraft:stone
fill 393 53 -330 396 53 -330 minecraft:stone
fill 420 53 -330 422 53 -330 minecraft:stone
fill 393 53 -329 396 53 -329 minecraft:stone
fill 419 53 -329 422 53 -329 minecraft:stone
fill 393 53 -328 396 53 -328 minecraft:stone
fill 416 53 -328 422 53 -328 minecraft:stone
fill 413 53 -327 422 53 -327 minecraft:stone
fill 410 53 -326 422 53 -326 minecraft:stone
fill 409 53 -325 419 53 -325 minecraft:stone
fill 408 53 -324 418 53 -324 minecraft:stone
fill 404 53 -323 417 53 -323 minecraft:stone
fill 403 53 -322 415 53 -322 minecraft:stone
fill 401 53 -321 413 53 -321 minecraft:stone
fill 399 53 -320 409 53 -320 minecraft:stone
fill 398 53 -319 407 53 -319 minecraft:stone
setblock 392 54 -370 minecraft:stone
fill 392 54 -369 394 54 -369 minecraft:stone
fill 392 54 -368 395 54 -368 minecraft:stone
fill 392 54 -367 396 54 -367 minecraft:stone
fill 392 54 -366 397 54 -366 minecraft:stone
fill 392 54 -365 398 54 -365 minecraft:stone
fill 392 54 -364 398 54 -364 minecraft:stone
fill 392 54 -363 398 54 -363 minecraft:stone
setblock 422 54 -363 minecraft:stone
fill 392 54 -362 399 54 -362 minecraft:stone
setblock 422 54 -362 minecraft:stone
fill 392 54 -361 399 54 -361 minecraft:stone
fill 392 54 -360 399 54 -360 minecraft:stone
setblock 421 54 -360 minecraft:stone
fill 392 54 -359 400 54 -359 minecraft:stone
fill 392 54 -358 400 54 -358 minecraft:stone
fill 392 54 -357 401 54 -357 minecraft:stone
fill 392 54 -356 401 54 -356 minecraft:stone
fill 392 54 -355 401 54 -355 minecraft:stone
fill 392 54 -354 402 54 -354 minecraft:stone
fill 392 54 -353 402 54 -353 minecraft:stone
fill 392 54 -352 402 54 -352 minecraft:stone
fill 392 54 -351 403 54 -351 minecraft:stone
fill 392 54 -350 403 54 -350 minecraft:stone
fill 392 54 -349 403 54 -349 minecraft:stone
fill 392 54 -348 404 54 -348 minecraft:stone
fill 392 54 -347 402 54 -347 minecraft:stone
fill 392 54 -346 399 54 -346 minecraft:stone
fill 392 54 -345 397 54 -345 minecraft:stone
setblock 392 54 -344 minecraft:stone
setblock 392 54 -343 minecraft:stone
fill 421 54 -332 422 54 -332 minecraft:stone
fill 392 54 -331 395 54 -331 minecraft:stone
fill 420 54 -331 422 54 -331 minecraft:stone
fill 392 54 -330 395 54 -330 minecraft:stone
fill 419 54 -330 422 54 -330 minecraft:stone
fill 392 54 -329 395 54 -329 minecraft:stone
fill 417 54 -329 422 54 -329 minecraft:stone
fill 393 54 -328 395 54 -328 minecraft:stone
fill 413 54 -328 422 54 -328 minecraft:stone
fill 410 54 -327 422 54 -327 minecraft:stone
fill 409 54 -326 422 54 -326 minecraft:stone
fill 408 54 -325 421 54 -325 minecraft:stone
fill 405 54 -324 419 54 -324 minecraft:stone
fill 403 54 -323 417 54 -323 minecraft:stone
fill 402 54 -322 417 54 -322 minecraft:stone
fill 400 54 -321 414 54 -321 minecraft:stone
fill 398 54 -320 412 54 -320 minecraft:stone
fill 397 54 -319 408 54 -319 minecraft:stone
fill 402 55 -380 405 55 -380 minecraft:stone
fill 395 55 -379 399 55 -379 minecraft:stone
fill 401 55 -379 404 55 -379 minecraft:stone
fill 392 55 -378 403 55 -378 minecraft:stone
fill 392 55 -377 402 55 -377 minecraft:stone
fill 392 55 -376 402 55 -376 minecraft:stone
fill 392 55 -375 401 55 -375 minecraft:stone
fill 392 55 -374 401 55 -374 minecraft:stone
fill 392 55 -373 401 55 -373 minecraft:stone
fill 392 55 -372 401 55 -372 minecraft:stone
fill 392 55 -371 401 55 -371 minecraft:stone
fill 392 55 -370 401 55 -370 minecraft:stone
fill 392 55 -369 401 55 -369 minecraft:stone
fill 392 55 -368 402 55 -368 minecraft:stone
fill 392 55 -367 401 55 -367 minecraft:stone
fill 392 55 -366 401 55 -366 minecraft:stone
fill 392 55 -365 401 55 -365 minecraft:stone
fill 392 55 -364 401 55 -364 minecraft:stone
fill 392 55 -363 401 55 -363 minecraft:stone
fill 392 55 -362 402 55 -362 minecraft:stone
fill 392 55 -361 402 55 -361 minecraft:stone
fill 392 55 -360 402 55 -360 minecraft:stone
setblock 421 55 -360 minecraft:stone
fill 392 55 -359 403 55 -359 minecraft:stone
fill 392 55 -358 403 55 -358 minecraft:stone
fill 392 55 -357 403 55 -357 minecraft:stone
fill 392 55 -356 403 55 -356 minecraft:stone
fill 392 55 -355 404 55 -355 minecraft:stone
fill 392 55 -354 404 55 -354 minecraft:stone
fill 392 55 -353 404 55 -353 minecraft:stone
fill 392 55 -352 404 55 -352 minecraft:stone
fill 392 55 -351 404 55 -351 minecraft:stone
fill 392 55 -350 405 55 -350 minecraft:stone
fill 392 55 -349 405 55 -349 minecraft:stone
fill 392 55 -348 406 55 -348 minecraft:stone
fill 392 55 -347 406 55 -347 minecraft:stone
fill 392 55 -346 408 55 -346 minecraft:stone
fill 392 55 -345 401 55 -345 minecraft:stone
fill 406 55 -345 408 55 -345 minecraft:stone
fill 392 55 -344 398 55 -344 minecraft:stone
fill 406 55 -344 409 55 -344 minecraft:stone
setblock 392 55 -343 minecraft:stone
setblock 396 55 -343 minecraft:stone
fill 406 55 -343 409 55 -343 minecraft:stone
fill 406 55 -342 409 55 -342 minecraft:stone
fill 406 55 -341 410 55 -341 minecraft:stone
fill 406 55 -340 411 55 -340 minecraft:stone
fill 406 55 -339 411 55 -339 minecraft:stone
fill 406 55 -338 410 55 -338 minecraft:stone
fill 407 55 -337 410 55 -337 minecraft:stone
fill 407 55 -336 410 55 -336 minecraft:stone
fill 408 55 -335 410 55 -335 minecraft:stone
fill 411 55 -334 412 55 -334 minecraft:stone
fill 411 55 -333 412 55 -333 minecraft:stone
fill 411 55 -332 412 55 -332 minecraft:stone
fill 421 55 -332 422 55 -332 minecraft:stone
fill 392 55 -331 394 55 -331 minecraft:stone
setblock 412 55 -331 minecraft:stone
fill 420 55 -331 422 55 -331 minecraft:stone
fill 392 55 -330 394 55 -330 minecraft:stone
setblock 412 55 -330 minecraft:stone
fill 419 55 -330 422 55 -330 minecraft:stone
fill 392 55 -329 395 55 -329 minecraft:stone
setblock 412 55 -329 minecraft:stone
fill 417 55 -329 422 55 -329 minecraft:stone
fill 392 55 -328 395 55 -328 minecraft:stone
fill 412 55 -328 422 55 -328 minecraft:stone
setblock 392 55 -327 minecraft:stone
fill 410 55 -327 422 55 -327 minecraft:stone
fill 409 55 -326 422 55 -326 minecraft:stone
fill 408 55 -325 421 55 -325 minecraft:stone
fill 405 55 -324 419 55 -324 minecraft:stone
fill 403 55 -323 417 55 -323 minecraft:stone
fill 402 55 -322 417 55 -322 minecraft:stone
fill 400 55 -321 414 55 -321 minecraft:stone
fill 398 55 -320 412 55 -320 minecraft:stone
fill 397 55 -319 408 55 -319 minecraft:stone
fill 392 56 -382 422 56 -382 minecraft:stone
fill 392 56 -381 421 56 -381 minecraft:stone
fill 392 56 -380 420 56 -380 minecraft:stone
fill 392 56 -379 419 56 -379 minecraft:stone
fill 392 56 -378 419 56 -378 minecraft:stone
fill 392 56 -377 419 56 -377 minecraft:stone
fill 392 56 -376 418 56 -376 minecraft:stone
fill 392 56 -375 419 56 -375 minecraft:stone
fill 392 56 -374 420 56 -374 minecraft:stone
fill 392 56 -373 421 56 -373 minecraft:stone
fill 392 56 -372 422 56 -372 minecraft:stone
fill 392 56 -371 422 56 -371 minecraft:stone
fill 392 56 -370 422 56 -370 minecraft:stone
fill 392 56 -369 422 56 -369 minecraft:stone
fill 392 56 -368 422 56 -368 minecraft:stone
fill 392 56 -367 422 56 -367 minecraft:stone
fill 392 56 -366 422 56 -366 minecraft:stone
fill 392 56 -365 422 56 -365 minecraft:stone
fill 392 56 -364 422 56 -364 minecraft:stone
fill 392 56 -363 422 56 -363 minecraft:stone
fill 392 56 -362 422 56 -362 minecraft:stone
fill 392 56 -361 422 56 -361 minecraft:stone
fill 392 56 -360 411 56 -360 minecraft:stone
fill 417 56 -360 422 56 -360 minecraft:stone
fill 392 56 -359 409 56 -359 minecraft:stone
fill 417 56 -359 422 56 -359 minecraft:stone
fill 392 56 -358 407 56 -358 minecraft:stone
fill 417 56 -358 422 56 -358 minecraft:stone
fill 392 56 -357 407 56 -357 minecraft:stone
fill 418 56 -357 422 56 -357 minecraft:stone
fill 392 56 -356 407 56 -356 minecraft:stone
fill 419 56 -356 422 56 -356 minecraft:stone
fill 392 56 -355 407 56 -355 minecraft:stone
fill 420 56 -355 421 56 -355 minecraft:stone
fill 392 56 -354 406 56 -354 minecraft:stone
setblock 420 56 -354 minecraft:stone
fill 392 56 -353 406 56 -353 minecraft:stone
fill 392 56 -352 406 56 -352 minecraft:stone
fill 392 56 -351 407 56 -351 minecraft:stone
fill 392 56 -350 407 56 -350 minecraft:stone
fill 392 56 -349 408 56 -349 minecraft:stone
fill 392 56 -348 409 56 -348 minecraft:stone
fill 392 56 -347 410 56 -347 minecraft:stone
fill 392 56 -346 410 56 -346 minecraft:stone
fill 392 56 -345 411 56 -345 minecraft:stone
fill 392 56 -344 411 56 -344 minecraft:stone
fill 392 56 -343 412 56 -343 minecraft:stone
fill 392 56 -342 413 56 -342 minecraft:stone
fill 396 56 -341 413 56 -341 minecraft:stone
fill 401 56 -340 414 56 -340 minecraft:stone
fill 401 56 -339 414 56 -339 minecraft:stone
fill 402 56 -338 414 56 -338 minecraft:stone
fill 402 56 -337 414 56 -337 minecraft:stone
fill 402 56 -336 414 56 -336 minecraft:stone
fill 404 56 -335 415 56 -335 minecraft:stone
fill 405 56 -334 415 56 -334 minecraft:stone
fill 406 56 -333 416 56 -333 minecraft:stone
fill 407 56 -332 420 56 -332 minecraft:stone
fill 407 56 -331 418 56 -331 minecraft:stone
setblock 422 56 -331 minecraft:stone
fill 392 56 -330 393 56 -330 minecraft:stone
fill 408 56 -330 418 56 -330 minecraft:stone
fill 421 56 -330 422 56 -330 minecraft:stone
fill 392 56 -329 394 56 -329 minecraft:stone
fill 408 56 -329 418 56 -329 minecraft:stone
fill 420 56 -329 422 56 -329 minecraft:stone
fill 392 56 -328 394 56 -328 minecraft:stone
fill 408 56 -328 422 56 -328 minecraft:stone
fill 392 56 -327 393 56 -327 minecraft:stone
fill 409 56 -327 418 56 -327 minecraft:stone
fill 420 56 -327 422 56 -327 minecraft:stone
fill 410 56 -326 419 56 -326 minecraft:stone
fill 410 56 -325 418 56 -325 minecraft:stone
fill 409 56 -324 417 56 -324 minecraft:stone
fill 407 56 -323 415 56 -323 minecraft:stone
fill 404 56 -322 413 56 -322 minecraft:stone
fill 403 56 -321 409 56 -321 minecraft:stone
fill 401 56 -320 407 56 -320 minecraft:stone
fill 399 56 -319 406 56 -319 minecraft:stone
fill 392 57 -382 422 57 -382 minecraft:stone
fill 392 57 -381 422 57 -381 minecraft:stone
fill 392 57 -380 422 57 -380 minecraft:stone
fill 392 57 -379 422 57 -379 minecraft:stone
fill 392 57 -378 422 57 -378 minecraft:stone
fill 392 57 -377 422 57 -377 minecraft:stone
fill 392 57 -376 422 57 -376 minecraft:stone
fill 392 57 -375 422 57 -375 minecraft:stone
fill 392 57 -374 422 57 -374 minecraft:stone
fill 392 57 -373 422 57 -373 minecraft:stone
fill 392 57 -372 422 57 -372 minecraft:stone
fill 392 57 -371 422 57 -371 minecraft:stone
fill 392 57 -370 422 57 -370 minecraft:stone
fill 392 57 -369 422 57 -369 minecraft:stone
fill 392 57 -368 422 57 -368 minecraft:stone
fill 392 57 -367 422 57 -367 minecraft:stone
fill 392 57 -366 422 57 -366 minecraft:stone
fill 392 57 -365 422 57 -365 minecraft:stone
fill 392 57 -364 422 57 -364 minecraft:stone
fill 392 57 -363 422 57 -363 minecraft:stone
fill 392 57 -362 422 57 -362 minecraft:stone
fill 392 57 -361 422 57 -361 minecraft:stone
fill 392 57 -360 422 57 -360 minecraft:stone
fill 392 57 -359 422 57 -359 minecraft:stone
fill 392 57 -358 422 57 -358 minecraft:stone
fill 392 57 -357 422 57 -357 minecraft:stone
fill 392 57 -356 422 57 -356 minecraft:stone
fill 392 57 -355 422 57 -355 minecraft:stone
fill 392 57 -354 408 57 -354 minecraft:stone
fill 415 57 -354 422 57 -354 minecraft:stone
fill 392 57 -353 407 57 -353 minecraft:stone
fill 416 57 -353 422 57 -353 minecraft:stone
fill 392 57 -352 407 57 -352 minecraft:stone
fill 417 57 -352 422 57 -352 minecraft:stone
fill 392 57 -351 408 57 -351 minecraft:stone
fill 418 57 -351 421 57 -351 minecraft:stone
fill 392 57 -350 409 57 -350 minecraft:stone
setblock 420 57 -350 minecraft:stone
fill 392 57 -349 410 57 -349 minecraft:stone
fill 392 57 -348 410 57 -348 minecraft:stone
fill 392 57 -347 411 57 -347 minecraft:stone
fill 392 57 -346 412 57 -346 minecraft:stone
fill 392 57 -345 413 57 -345 minecraft:stone
fill 392 57 -344 414 57 -344 minecraft:stone
fill 392 57 -343 414 57 -343 minecraft:stone
fill 392 57 -342 415 57 -342 minecraft:stone
fill 392 57 -341 415 57 -341 minecraft:stone
fill 395 57 -340 415 57 -340 minecraft:stone
fill 396 57 -339 415 57 -339 minecraft:stone
fill 397 57 -338 416 57 -338 minecraft:stone
fill 398 57 -337 416 57 -337 minecraft:stone
fill 399 57 -336 416 57 -336 minecraft:stone
fill 401 57 -335 417 57 -335 minecraft:stone
fill 403 57 -334 418 57 -334 minecraft:stone
fill 404 57 -333 420 57 -333 minecraft:stone
setblock 422 57 -333 minecraft:stone
fill 405 57 -332 422 57 -332 minecraft:stone
fill 406 57 -331 422 57 -331 minecraft:stone
setblock 392 57 -330 minecraft:stone
fill 407 57 -330 422 57 -330 minecraft:stone
fill 392 57 -329 393 57 -329 minecraft:stone
fill 407 57 -329 422 57 -329 minecraft:stone
fill 392 57 -328 393 57 -328 minecraft:stone
fill 408 57 -328 422 57 -328 minecraft:stone
setblock 392 57 -327 minecraft:stone
fill 408 57 -327 422 57 -327 minecraft:stone
fill 409 57 -326 422 57 -326 minecraft:stone
fill 408 57 -325 421 57 -325 minecraft:stone
fill 405 57 -324 419 57 -324 minecraft:stone
fill 403 57 -323 418 57 -323 minecraft:stone
fill 402 57 -322 417 57 -322 minecraft:stone
fill 400 57 -321 415 57 -321 minecraft:stone
fill 398 57 -320 412 57 -320 minecraft:stone
fill 396 57 -319 408 57 -319 minecraft:stone
fill 392 58 -382 422 58 -382 minecraft:stone
fill 392 58 -381 422 58 -381 minecraft:stone
fill 392 58 -380 422 58 -380 minecraft:stone
fill 392 58 -379 422 58 -379 minecraft:stone
fill 392 58 -378 422 58 -378 minecraft:stone
fill 392 58 -377 422 58 -377 minecraft:stone
fill 392 58 -376 422 58 -376 minecraft:stone
fill 392 58 -375 422 58 -375 minecraft:stone
fill 392 58 -374 422 58 -374 minecraft:stone
fill 392 58 -373 422 58 -373 minecraft:stone
fill 392 58 -372 422 58 -372 minecraft:stone
fill 392 58 -371 422 58 -371 minecraft:stone
fill 392 58 -370 422 58 -370 minecraft:stone
fill 392 58 -369 422 58 -369 minecraft:stone
fill 392 58 -368 422 58 -368 minecraft:stone
fill 392 58 -367 422 58 -367 minecraft:stone
fill 392 58 -366 422 58 -366 minecraft:stone
fill 392 58 -365 422 58 -365 minecraft:stone
fill 392 58 -364 422 58 -364 minecraft:stone
fill 392 58 -363 422 58 -363 minecraft:stone
fill 392 58 -362 422 58 -362 minecraft:stone
fill 392 58 -361 422 58 -361 minecraft:stone
fill 392 58 -360 422 58 -360 minecraft:stone
fill 392 58 -359 422 58 -359 minecraft:stone
fill 392 58 -358 422 58 -358 minecraft:stone
fill 392 58 -357 422 58 -357 minecraft:stone
fill 392 58 -356 422 58 -356 minecraft:stone
fill 392 58 -355 422 58 -355 minecraft:stone
fill 392 58 -354 422 58 -354 minecraft:stone
fill 392 58 -353 422 58 -353 minecraft:stone
fill 392 58 -352 411 58 -352 minecraft:stone
fill 413 58 -352 422 58 -352 minecraft:stone
fill 392 58 -351 411 58 -351 minecraft:stone
fill 413 58 -351 422 58 -351 minecraft:stone
fill 392 58 -350 422 58 -350 minecraft:stone
fill 392 58 -349 422 58 -349 minecraft:stone
fill 392 58 -348 415 58 -348 minecraft:stone
fill 417 58 -348 421 58 -348 minecraft:stone
fill 392 58 -347 421 58 -347 minecraft:stone
fill 392 58 -346 421 58 -346 minecraft:stone
fill 392 58 -345 421 58 -345 minecraft:stone
fill 392 58 -344 421 58 -344 minecraft:stone
fill 392 58 -343 420 58 -343 minecraft:stone
fill 392 58 -342 418 58 -342 minecraft:stone
fill 392 58 -341 417 58 -341 minecraft:stone
fill 392 58 -340 417 58 -340 minecraft:stone
fill 393 58 -339 417 58 -339 minecraft:stone
fill 394 58 -338 417 58 -338 minecraft:stone
fill 394 58 -337 417 58 -337 minecraft:stone
fill 395 58 -336 418 58 -336 minecraft:stone
fill 396 58 -335 419 58 -335 minecraft:stone
fill 401 58 -334 421 58 -334 minecraft:stone
fill 402 58 -333 422 58 -333 minecraft:stone
fill 403 58 -332 422 58 -332 minecraft:stone
fill 405 58 -331 422 58 -331 minecraft:stone
fill 406 58 -330 422 58 -330 minecraft:stone
setblock 392 58 -329 minecraft:stone
fill 407 58 -329 422 58 -329 minecraft:stone
setblock 392 58 -328 minecraft:stone
fill 407 58 -328 422 58 -328 minecraft:stone
setblock 392 58 -327 minecraft:stone
fill 408 58 -327 422 58 -327 minecraft:stone
fill 408 58 -326 422 58 -326 minecraft:stone
fill 408 58 -325 422 58 -325 minecraft:stone
fill 405 58 -324 419 58 -324 minecraft:stone
fill 421 58 -324 422 58 -324 minecraft:stone
fill 403 58 -323 418 58 -323 minecraft:stone
fill 402 58 -322 417 58 -322 minecraft:stone
fill 400 58 -321 415 58 -321 minecraft:stone
fill 398 58 -320 412 58 -320 minecraft:stone
fill 396 58 -319 408 58 -319 minecraft:stone
fill 392 59 -382 422 59 -382 minecraft:stone
fill 392 59 -381 422 59 -381 minecraft:stone
fill 392 59 -380 422 59 -380 minecraft:stone
fill 392 59 -379 422 59 -379 minecraft:stone
fill 392 59 -378 422 59 -378 minecraft:stone
fill 392 59 -377 422 59 -377 minecraft:stone
fill 392 59 -376 422 59 -376 minecraft:stone
fill 392 59 -375 422 59 -375 minecraft:stone
fill 392 59 -374 422 59 -374 minecraft:stone
fill 392 59 -373 422 59 -373 minecraft:stone
fill 392 59 -372 422 59 -372 minecraft:stone
fill 392 59 -371 422 59 -371 minecraft:stone
fill 392 59 -370 422 59 -370 minecraft:stone
fill 392 59 -369 422 59 -369 minecraft:stone
fill 392 59 -368 422 59 -368 minecraft:stone
fill 392 59 -367 422 59 -367 minecraft:stone
fill 392 59 -366 422 59 -366 minecraft:stone
fill 392 59 -365 422 59 -365 minecraft:stone
fill 392 59 -364 422 59 -364 minecraft:stone
fill 392 59 -363 422 59 -363 minecraft:stone
fill 392 59 -362 422 59 -362 minecraft:stone
fill 392 59 -361 422 59 -361 minecraft:stone
fill 392 59 -360 422 59 -360 minecraft:stone
fill 392 59 -359 422 59 -359 minecraft:stone
fill 392 59 -358 422 59 -358 minecraft:stone
fill 392 59 -357 422 59 -357 minecraft:stone
fill 392 59 -356 422 59 -356 minecraft:stone
fill 392 59 -355 422 59 -355 minecraft:stone
fill 392 59 -354 422 59 -354 minecraft:stone
fill 392 59 -353 422 59 -353 minecraft:stone
fill 392 59 -352 422 59 -352 minecraft:stone
fill 392 59 -351 422 59 -351 minecraft:stone
fill 392 59 -350 422 59 -350 minecraft:stone
fill 392 59 -349 422 59 -349 minecraft:stone
fill 392 59 -348 422 59 -348 minecraft:stone
fill 392 59 -347 422 59 -347 minecraft:stone
fill 392 59 -346 422 59 -346 minecraft:stone
fill 392 59 -345 422 59 -345 minecraft:stone
fill 392 59 -344 422 59 -344 minecraft:stone
fill 392 59 -343 422 59 -343 minecraft:stone
fill 392 59 -342 421 59 -342 minecraft:stone
fill 392 59 -341 419 59 -341 minecraft:stone
fill 392 59 -340 419 59 -340 minecraft:stone
fill 392 59 -339 419 59 -339 minecraft:stone
fill 392 59 -338 419 59 -338 minecraft:stone
fill 392 59 -337 419 59 -337 minecraft:stone
fill 392 59 -336 419 59 -336 minecraft:stone
fill 394 59 -335 422 59 -335 minecraft:stone
fill 395 59 -334 422 59 -334 minecraft:stone
fill 396 59 -333 422 59 -333 minecraft:stone
fill 396 59 -332 398 59 -332 minecraft:stone
fill 401 59 -332 422 59 -332 minecraft:stone
fill 403 59 -331 422 59 -331 minecraft:stone
fill 405 59 -330 422 59 -330 minecraft:stone
fill 406 59 -329 422 59 -329 minecraft:stone
fill 406 59 -328 422 59 -328 minecraft:stone
fill 407 59 -327 422 59 -327 minecraft:stone
fill 407 59 -326 422 59 -326 minecraft:stone
fill 408 59 -325 422 59 -325 minecraft:stone
fill 405 59 -324 422 59 -324 minecraft:stone
fill 403 59 -323 422 59 -323 minecraft:stone
fill 402 59 -322 417 59 -322 minecraft:stone
setblock 422 59 -322 minecraft:stone
fill 400 59 -321 415 59 -321 minecraft:stone
fill 398 59 -320 412 59 -320 minecraft:stone
fill 396 59 -319 408 59 -319 minecraft:stone
fill 392 60 -382 422 60 -382 minecraft:stone
fill 392 60 -381 422 60 -381 minecraft:stone
fill 392 60 -380 422 60 -380 minecraft:stone
fill 392 60 -379 422 60 -379 minecraft:stone
fill 392 60 -378 422 60 -378 minecraft:stone
fill 392 60 -377 422 60 -377 minecraft:stone
fill 392 60 -376 422 60 -376 minecraft:stone
fill 392 60 -375 422 60 -375 minecraft:stone
fill 392 60 -374 422 60 -374 minecraft:stone
fill 392 60 -373 422 60 -373 minecraft:stone
fill 392 60 -372 422 60 -372 minecraft:stone
fill 392 60 -371 422 60 -371 minecraft:stone
fill 392 60 -370 422 60 -370 minecraft:stone
fill 392 60 -369 422 60 -369 minecraft:stone
fill 392 60 -368 422 60 -368 minecraft:stone
fill 392 60 -367 422 60 -367 minecraft:stone
fill 392 60 -366 422 60 -366 minecraft:stone
fill 392 60 -365 422 60 -365 minecraft:stone
fill 392 60 -364 422 60 -364 minecraft:stone
fill 392 60 -363 422 60 -363 minecraft:stone
fill 392 60 -362 422 60 -362 minecraft:stone
fill 392 60 -361 422 60 -361 minecraft:stone
fill 392 60 -360 422 60 -360 minecraft:stone
fill 392 60 -359 422 60 -359 minecraft:stone
fill 392 60 -358 422 60 -358 minecraft:stone
fill 392 60 -357 422 60 -357 minecraft:stone
fill 392 60 -356 422 60 -356 minecraft:stone
fill 392 60 -355 422 60 -355 minecraft:stone
fill 392 60 -354 422 60 -354 minecraft:stone
fill 392 60 -353 422 60 -353 minecraft:stone
fill 392 60 -352 422 60 -352 minecraft:stone
fill 392 60 -351 422 60 -351 minecraft:stone
fill 392 60 -350 422 60 -350 minecraft:stone
fill 392 60 -349 422 60 -349 minecraft:stone
fill 392 60 -348 422 60 -348 minecraft:stone
fill 392 60 -347 422 60 -347 minecraft:stone
fill 392 60 -346 422 60 -346 minecraft:stone
fill 392 60 -345 422 60 -345 minecraft:stone
fill 392 60 -344 422 60 -344 minecraft:stone
fill 392 60 -343 422 60 -343 minecraft:stone
fill 392 60 -342 422 60 -342 minecraft:stone
fill 392 60 -341 422 60 -341 minecraft:stone
fill 392 60 -340 422 60 -340 minecraft:stone
fill 392 60 -339 422 60 -339 minecraft:stone
fill 392 60 -338 422 60 -338 minecraft:stone
fill 392 60 -337 422 60 -337 minecraft:stone
fill 392 60 -336 422 60 -336 minecraft:stone
fill 392 60 -335 422 60 -335 minecraft:stone
fill 394 60 -334 422 60 -334 minecraft:stone
fill 395 60 -333 422 60 -333 minecraft:stone
fill 395 60 -332 422 60 -332 minecraft:stone
setblock 396 60 -331 minecraft:stone
fill 401 60 -331 422 60 -331 minecraft:stone
fill 403 60 -330 422 60 -330 minecraft:stone
fill 404 60 -329 422 60 -329 minecraft:stone
fill 405 60 -328 422 60 -328 minecraft:stone
fill 406 60 -327 422 60 -327 minecraft:stone
fill 406 60 -326 422 60 -326 minecraft:stone
fill 407 60 -325 422 60 -325 minecraft:stone
fill 407 60 -324 422 60 -324 minecraft:stone
fill 404 60 -323 422 60 -323 minecraft:stone
fill 403 60 -322 422 60 -322 minecraft:stone
fill 401 60 -321 413 60 -321 minecraft:stone
fill 421 60 -321 422 60 -321 minecraft:stone
fill 399 60 -320 409 60 -320 minecraft:stone
fill 398 60 -319 407 60 -319 minecraft:stone
fill 392 61 -382 422 61 -382 minecraft:stone
fill 392 61 -381 422 61 -381 minecraft:stone
fill 392 61 -380 422 61 -380 minecraft:stone
fill 392 61 -379 422 61 -379 minecraft:stone
fill 392 61 -378 422 61 -378 minecraft:stone
fill 392 61 -377 422 61 -377 minecraft:stone
fill 392 61 -376 422 61 -376 minecraft:stone
fill 392 61 -375 422 61 -375 minecraft:stone
fill 392 61 -374 422 61 -374 minecraft:stone
fill 392 61 -373 422 61 -373 minecraft:stone
fill 392 61 -372 422 61 -372 minecraft:stone
fill 392 61 -371 422 61 -371 minecraft:stone
fill 392 61 -370 422 61 -370 minecraft:stone
fill 392 61 -369 422 61 -369 minecraft:stone
fill 392 61 -368 422 61 -368 minecraft:stone
fill 392 61 -367 422 61 -367 minecraft:stone
fill 392 61 -366 422 61 -366 minecraft:stone
fill 392 61 -365 422 61 -365 minecraft:stone
fill 392 61 -364 422 61 -364 minecraft:stone
fill 392 61 -363 422 61 -363 minecraft:stone
fill 392 61 -362 422 61 -362 minecraft:stone
fill 392 61 -361 422 61 -361 minecraft:stone
fill 392 61 -360 422 61 -360 minecraft:stone
fill 392 61 -359 422 61 -359 minecraft:stone
fill 392 61 -358 422 61 -358 minecraft:stone
fill 392 61 -357 422 61 -357 minecraft:stone
fill 392 61 -356 422 61 -356 minecraft:stone
fill 392 61 -355 422 61 -355 minecraft:stone
fill 392 61 -354 422 61 -354 minecraft:stone
fill 392 61 -353 422 61 -353 minecraft:stone
fill 392 61 -352 422 61 -352 minecraft:stone
fill 392 61 -351 422 61 -351 minecraft:stone
fill 392 61 -350 422 61 -350 minecraft:stone
fill 392 61 -349 422 61 -349 minecraft:stone
fill 392 61 -348 422 61 -348 minecraft:stone
fill 392 61 -347 422 61 -347 minecraft:stone
fill 392 61 -346 422 61 -346 minecraft:stone
fill 392 61 -345 422 61 -345 minecraft:stone
fill 392 61 -344 422 61 -344 minecraft:stone
fill 392 61 -343 422 61 -343 minecraft:stone
fill 392 61 -342 422 61 -342 minecraft:stone
fill 392 61 -341 422 61 -341 minecraft:stone
fill 392 61 -340 422 61 -340 minecraft:stone
fill 392 61 -339 422 61 -339 minecraft:stone
fill 392 61 -338 422 61 -338 minecraft:stone
fill 392 61 -337 422 61 -337 minecraft:stone
fill 392 61 -336 422 61 -336 minecraft:stone
fill 392 61 -335 422 61 -335 minecraft:stone
fill 392 61 -334 422 61 -334 minecraft:stone
fill 393 61 -333 422 61 -333 minecraft:stone
fill 394 61 -332 422 61 -332 minecraft:stone
fill 395 61 -331 422 61 -331 minecraft:stone
fill 396 61 -330 398 61 -330 minecraft:stone
fill 401 61 -330 422 61 -330 minecraft:stone
fill 402 61 -329 422 61 -329 minecraft:stone
fill 404 61 -328 422 61 -328 minecraft:stone
fill 405 61 -327 422 61 -327 minecraft:stone
fill 405 61 -326 422 61 -326 minecraft:stone
fill 406 61 -325 422 61 -325 minecraft:stone
fill 406 61 -324 422 61 -324 minecraft:stone
fill 404 61 -323 422 61 -323 minecraft:stone
fill 403 61 -322 422 61 -322 minecraft:stone
fill 401 61 -321 422 61 -321 minecraft:stone
fill 399 61 -320 409 61 -320 minecraft:stone
setblock 412 61 -320 minecraft:stone
fill 420 61 -320 422 61 -320 minecraft:stone
fill 398 61 -319 407 61 -319 minecraft:stone
setblock 422 61 -319 minecraft:stone
fill 392 62 -382 422 62 -382 minecraft:dirt
fill 392 62 -381 422 62 -381 minecraft:dirt
fill 392 62 -380 422 62 -380 minecraft:dirt
fill 392 62 -379 422 62 -379 minecraft:dirt
fill 392 62 -378 422 62 -378 minecraft:dirt
fill 392 62 -377 422 62 -377 minecraft:dirt
fill 392 62 -376 422 62 -376 minecraft:dirt
fill 392 62 -375 422 62 -375 minecraft:dirt
fill 392 62 -374 422 62 -374 minecraft:dirt
fill 392 62 -373 422 62 -373 minecraft:dirt
fill 392 62 -372 422 62 -372 minecraft:dirt
fill 392 62 -371 422 62 -371 minecraft:dirt
fill 392 62 -370 422 62 -370 minecraft:dirt
fill 392 62 -369 422 62 -369 minecraft:dirt
fill 392 62 -368 422 62 -368 minecraft:dirt
fill 392 62 -367 422 62 -367 minecraft:dirt
fill 392 62 -366 422 62 -366 minecraft:dirt
fill 392 62 -365 422 62 -365 minecraft:dirt
fill 392 62 -364 422 62 -364 minecraft:dirt
fill 392 62 -363 422 62 -363 minecraft:dirt
fill 392 62 -362 422 62 -362 minecraft:dirt
fill 392 62 -361 422 62 -361 minecraft:dirt
fill 392 62 -360 422 62 -360 minecraft:dirt
fill 392 62 -359 422 62 -359 minecraft:dirt
fill 392 62 -358 422 62 -358 minecraft:dirt
fill 392 62 -357 422 62 -357 minecraft:dirt
fill 392 62 -356 422 62 -356 minecraft:dirt
fill 392 62 -355 422 62 -355 minecraft:dirt
fill 392 62 -354 422 62 -354 minecraft:dirt
fill 392 62 -353 422 62 -353 minecraft:dirt
fill 392 62 -352 422 62 -352 minecraft:dirt
fill 392 62 -351 422 62 -351 minecraft:dirt
fill 392 62 -350 422 62 -350 minecraft:dirt
fill 392 62 -349 422 62 -349 minecraft:dirt
fill 392 62 -348 422 62 -348 minecraft:dirt
fill 392 62 -347 422 62 -347 minecraft:dirt
fill 392 62 -346 422 62 -346 minecraft:dirt
fill 392 62 -345 422 62 -345 minecraft:dirt
fill 392 62 -344 422 62 -344 minecraft:dirt
fill 392 62 -343 422 62 -343 minecraft:dirt
fill 392 62 -342 422 62 -342 minecraft:dirt
fill 392 62 -341 422 62 -341 minecraft:dirt
fill 392 62 -340 422 62 -340 minecraft:dirt
fill 392 62 -339 422 62 -339 minecraft:dirt
fill 392 62 -338 422 62 -338 minecraft:dirt
fill 392 62 -337 422 62 -337 minecraft:dirt
fill 392 62 -336 422 62 -336 minecraft:dirt
fill 392 62 -335 422 62 -335 minecraft:dirt
fill 392 62 -334 422 62 -334 minecraft:dirt
fill 392 62 -333 422 62 -333 minecraft:dirt
fill 393 62 -332 422 62 -332 minecraft:dirt
fill 393 62 -331 422 62 -331 minecraft:dirt
fill 394 62 -330 422 62 -330 minecraft:dirt
fill 395 62 -329 422 62 -329 minecraft:dirt
fill 401 62 -328 422 62 -328 minecraft:dirt
fill 402 62 -327 422 62 -327 minecraft:dirt
fill 403 62 -326 422 62 -326 minecraft:dirt
fill 404 62 -325 422 62 -325 minecraft:dirt
fill 405 62 -324 422 62 -324 minecraft:dirt
fill 405 62 -323 422 62 -323 minecraft:dirt
fill 403 62 -322 422 62 -322 minecraft:dirt
fill 402 62 -321 422 62 -321 minecraft:dirt
fill 400 62 -320 415 62 -320 minecraft:dirt
fill 418 62 -320 422 62 -320 minecraft:dirt
fill 398 62 -319 407 62 -319 minecraft:dirt
fill 410 62 -319 413 62 -319 minecraft:dirt
fill 420 62 -319 422 62 -319 minecraft:dirt
fill 392 63 -382 422 63 -382 minecraft:dirt
fill 392 63 -381 422 63 -381 minecraft:dirt
fill 392 63 -380 422 63 -380 minecraft:dirt
fill 392 63 -379 422 63 -379 minecraft:dirt
fill 392 63 -378 422 63 -378 minecraft:dirt
fill 392 63 -377 422 63 -377 minecraft:dirt
fill 392 63 -376 422 63 -376 minecraft:dirt
fill 392 63 -375 422 63 -375 minecraft:dirt
fill 392 63 -374 422 63 -374 minecraft:dirt
fill 392 63 -373 422 63 -373 minecraft:dirt
fill 392 63 -372 422 63 -372 minecraft:dirt
fill 392 63 -371 422 63 -371 minecraft:dirt
fill 392 63 -370 422 63 -370 minecraft:dirt
fill 392 63 -369 422 63 -369 minecraft:dirt
fill 392 63 -368 422 63 -368 minecraft:dirt
fill 392 63 -367 422 63 -367 minecraft:dirt
fill 392 63 -366 422 63 -366 minecraft:dirt
fill 392 63 -365 422 63 -365 minecraft:dirt
fill 392 63 -364 422 63 -364 minecraft:dirt
fill 392 63 -363 422 63 -363 minecraft:dirt
fill 392 63 -362 422 63 -362 minecraft:dirt
fill 392 63 -361 422 63 -361 minecraft:dirt
fill 392 63 -360 422 63 -360 minecraft:dirt
fill 392 63 -359 422 63 -359 minecraft:dirt
fill 392 63 -358 422 63 -358 minecraft:dirt
fill 392 63 -357 422 63 -357 minecraft:dirt
fill 392 63 -356 422 63 -356 minecraft:dirt
fill 392 63 -355 422 63 -355 minecraft:dirt
fill 392 63 -354 422 63 -354 minecraft:dirt
fill 392 63 -353 422 63 -353 minecraft:dirt
fill 392 63 -352 422 63 -352 minecraft:dirt
fill 392 63 -351 422 63 -351 minecraft:dirt
fill 392 63 -350 422 63 -350 minecraft:dirt
fill 392 63 -349 422 63 -349 minecraft:dirt
fill 392 63 -348 422 63 -348 minecraft:dirt
fill 392 63 -347 422 63 -347 minecraft:dirt
fill 392 63 -346 422 63 -346 minecraft:dirt
fill 392 63 -345 422 63 -345 minecraft:dirt
fill 392 63 -344 422 63 -344 minecraft:dirt
fill 392 63 -343 422 63 -343 minecraft:dirt
fill 392 63 -342 422 63 -342 minecraft:dirt
fill 392 63 -341 422 63 -341 minecraft:dirt
fill 392 63 -340 422 63 -340 minecraft:dirt
fill 392 63 -339 422 63 -339 minecraft:dirt
fill 392 63 -338 422 63 -338 minecraft:dirt
fill 392 63 -337 422 63 -337 minecraft:dirt
fill 392 63 -336 422 63 -336 minecraft:dirt
fill 392 63 -335 422 63 -335 minecraft:dirt
fill 392 63 -334 422 63 -334 minecraft:dirt
fill 392 63 -333 422 63 -333 minecraft:dirt
fill 393 63 -332 422 63 -332 minecraft:dirt
fill 392 63 -331 422 63 -331 minecraft:dirt
fill 392 63 -330 422 63 -330 minecraft:dirt
fill 392 63 -329 422 63 -329 minecraft:dirt
fill 393 63 -328 422 63 -328 minecraft:dirt
fill 394 63 -327 422 63 -327 minecraft:dirt
fill 395 63 -326 422 63 -326 minecraft:dirt
fill 402 63 -325 422 63 -325 minecraft:dirt
fill 402 63 -324 422 63 -324 minecraft:dirt
fill 402 63 -323 422 63 -323 minecraft:dirt
fill 402 63 -322 422 63 -322 minecraft:dirt
fill 402 63 -321 422 63 -321 minecraft:dirt
setblock 399 63 -320 minecraft:dirt
fill 402 63 -320 422 63 -320 minecraft:dirt
fill 398 63 -319 400 63 -319 minecraft:dirt
fill 403 63 -319 415 63 -319 minecraft:dirt
setblock 417 63 -319 minecraft:dirt
fill 419 63 -319 422 63 -319 minecraft:dirt
fill 392 64 -382 422 64 -382 minecraft:dirt
fill 392 64 -381 422 64 -381 minecraft:dirt
fill 392 64 -380 422 64 -380 minecraft:dirt
fill 392 64 -379 422 64 -379 minecraft:dirt
fill 392 64 -378 422 64 -378 minecraft:dirt
fill 392 64 -377 422 64 -377 minecraft:dirt
fill 392 64 -376 422 64 -376 minecraft:dirt
fill 392 64 -375 422 64 -375 minecraft:dirt
fill 392 64 -374 422 64 -374 minecraft:dirt
fill 392 64 -373 422 64 -373 minecraft:dirt
fill 392 64 -372 422 64 -372 minecraft:dirt
fill 392 64 -371 422 64 -371 minecraft:dirt
fill 392 64 -370 422 64 -370 minecraft:dirt
fill 392 64 -369 422 64 -369 minecraft:dirt
fill 392 64 -368 422 64 -368 minecraft:dirt
fill 392 64 -367 422 64 -367 minecraft:dirt
fill 392 64 -366 422 64 -366 minecraft:dirt
fill 392 64 -365 422 64 -365 minecraft:dirt
fill 392 64 -364 422 64 -364 minecraft:dirt
fill 392 64 -363 422 64 -363 minecraft:dirt
fill 392 64 -362 422 64 -362 minecraft:dirt
fill 392 64 -361 422 64 -361 minecraft:dirt
fill 392 64 -360 422 64 -360 minecraft:dirt
fill 392 64 -359 422 64 -359 minecraft:dirt
fill 392 64 -358 422 64 -358 minecraft:dirt
fill 392 64 -357 422 64 -357 minecraft:dirt
fill 392 64 -356 422 64 -356 minecraft:dirt
fill 392 64 -355 422 64 -355 minecraft:dirt
fill 392 64 -354 422 64 -354 minecraft:dirt
fill 392 64 -353 422 64 -353 minecraft:dirt
fill 392 64 -352 422 64 -352 minecraft:dirt
fill 392 64 -351 422 64 -351 minecraft:dirt
fill 392 64 -350 422 64 -350 minecraft:dirt
fill 392 64 -349 422 64 -349 minecraft:dirt
fill 392 64 -348 422 64 -348 minecraft:dirt
fill 392 64 -347 422 64 -347 minecraft:dirt
fill 392 64 -346 422 64 -346 minecraft:dirt
fill 392 64 -345 422 64 -345 minecraft:dirt
fill 392 64 -344 422 64 -344 minecraft:dirt
fill 392 64 -343 422 64 -343 minecraft:dirt
fill 392 64 -342 422 64 -342 minecraft:dirt
fill 392 64 -341 422 64 -341 minecraft:dirt
fill 392 64 -340 422 64 -340 minecraft:dirt
fill 392 64 -339 422 64 -339 minecraft:dirt
fill 392 64 -338 422 64 -338 minecraft:dirt
fill 392 64 -337 422 64 -337 minecraft:dirt
fill 392 64 -336 422 64 -336 minecraft:dirt
fill 392 64 -335 422 64 -335 minecraft:dirt
fill 392 64 -334 422 64 -334 minecraft:dirt
fill 392 64 -333 422 64 -333 minecraft:dirt
fill 392 64 -332 422 64 -332 minecraft:dirt
fill 392 64 -331 422 64 -331 minecraft:dirt
fill 392 64 -330 422 64 -330 minecraft:dirt
fill 392 64 -329 422 64 -329 minecraft:dirt
fill 392 64 -328 422 64 -328 minecraft:dirt
fill 392 64 -327 422 64 -327 minecraft:dirt
fill 392 64 -326 422 64 -326 minecraft:dirt
fill 393 64 -325 400 64 -325 minecraft:dirt
fill 402 64 -325 422 64 -325 minecraft:dirt
fill 395 64 -324 422 64 -324 minecraft:dirt
fill 392 64 -323 393 64 -323 minecraft:dirt
fill 398 64 -323 422 64 -323 minecraft:dirt
fill 392 64 -322 394 64 -322 minecraft:dirt
fill 398 64 -322 422 64 -322 minecraft:dirt
fill 393 64 -321 395 64 -321 minecraft:dirt
fill 399 64 -321 422 64 -321 minecraft:dirt
fill 394 64 -320 396 64 -320 minecraft:dirt
fill 400 64 -320 422 64 -320 minecraft:dirt
fill 396 64 -319 397 64 -319 minecraft:dirt
fill 401 64 -319 422 64 -319 minecraft:dirt
fill 392 65 -382 416 65 -382 minecraft:grass_block
setblock 417 65 -382 minecraft:smooth_quartz
setblock 418 65 -382 minecraft:sea_lantern
fill 419 65 -382 422 65 -382 minecraft:light_gray_concrete
fill 392 65 -381 416 65 -381 minecraft:grass_block
setblock 417 65 -381 minecraft:smooth_quartz
fill 418 65 -381 422 65 -381 minecraft:light_gray_concrete
fill 392 65 -380 416 65 -380 minecraft:grass_block
setblock 417 65 -380 minecraft:smooth_quartz
fill 418 65 -380 422 65 -380 minecraft:light_gray_concrete
fill 392 65 -379 416 65 -379 minecraft:grass_block
setblock 417 65 -379 minecraft:smooth_quartz
fill 418 65 -379 422 65 -379 minecraft:light_gray_concrete
fill 392 65 -378 416 65 -378 minecraft:grass_block
setblock 417 65 -378 minecraft:smooth_quartz
fill 418 65 -378 422 65 -378 minecraft:light_gray_concrete
fill 392 65 -377 416 65 -377 minecraft:grass_block
setblock 417 65 -377 minecraft:smooth_quartz
fill 418 65 -377 422 65 -377 minecraft:light_gray_concrete
fill 392 65 -376 416 65 -376 minecraft:grass_block
setblock 417 65 -376 minecraft:smooth_quartz
fill 418 65 -376 420 65 -376 minecraft:light_gray_concrete
setblock 421 65 -376 minecraft:sea_lantern
setblock 422 65 -376 minecraft:light_gray_concrete
fill 392 65 -375 416 65 -375 minecraft:grass_block
setblock 417 65 -375 minecraft:smooth_quartz
fill 418 65 -375 419 65 -375 minecraft:light_gray_concrete
setblock 420 65 -375 minecraft:sea_lantern
fill 421 65 -375 422 65 -375 minecraft:light_gray_concrete
fill 392 65 -374 416 65 -374 minecraft:grass_block
setblock 417 65 -374 minecraft:smooth_quartz
setblock 418 65 -374 minecraft:light_gray_concrete
setblock 419 65 -374 minecraft:sea_lantern
fill 420 65 -374 422 65 -374 minecraft:light_gray_concrete
fill 392 65 -373 416 65 -373 minecraft:grass_block
setblock 417 65 -373 minecraft:smooth_quartz
setblock 418 65 -373 minecraft:sea_lantern
fill 419 65 -373 422 65 -373 minecraft:light_gray_concrete
fill 392 65 -372 416 65 -372 minecraft:grass_block
setblock 417 65 -372 minecraft:smooth_quartz
fill 418 65 -372 422 65 -372 minecraft:light_gray_concrete
fill 392 65 -371 416 65 -371 minecraft:grass_block
setblock 417 65 -371 minecraft:smooth_quartz
fill 418 65 -371 422 65 -371 minecraft:light_gray_concrete
fill 392 65 -370 416 65 -370 minecraft:grass_block
setblock 417 65 -370 minecraft:smooth_quartz
fill 418 65 -370 422 65 -370 minecraft:light_gray_concrete
fill 392 65 -369 416 65 -369 minecraft:grass_block
setblock 417 65 -369 minecraft:smooth_quartz
fill 418 65 -369 422 65 -369 minecraft:light_gray_concrete
fill 392 65 -368 416 65 -368 minecraft:grass_block
setblock 417 65 -368 minecraft:smooth_quartz
fill 418 65 -368 422 65 -368 minecraft:light_gray_concrete
fill 392 65 -367 416 65 -367 minecraft:grass_block
setblock 417 65 -367 minecraft:smooth_quartz
fill 418 65 -367 420 65 -367 minecraft:light_gray_concrete
setblock 421 65 -367 minecraft:sea_lantern
setblock 422 65 -367 minecraft:light_gray_concrete
fill 392 65 -366 416 65 -366 minecraft:grass_block
setblock 417 65 -366 minecraft:smooth_quartz
fill 418 65 -366 419 65 -366 minecraft:light_gray_concrete
setblock 420 65 -366 minecraft:sea_lantern
fill 421 65 -366 422 65 -366 minecraft:light_gray_concrete
fill 392 65 -365 416 65 -365 minecraft:grass_block
setblock 417 65 -365 minecraft:smooth_quartz
setblock 418 65 -365 minecraft:light_gray_concrete
setblock 419 65 -365 minecraft:sea_lantern
fill 420 65 -365 422 65 -365 minecraft:light_gray_concrete
fill 392 65 -364 416 65 -364 minecraft:grass_block
setblock 417 65 -364 minecraft:smooth_quartz
setblock 418 65 -364 minecraft:sea_lantern
fill 419 65 -364 422 65 -364 minecraft:light_gray_concrete
fill 392 65 -363 416 65 -363 minecraft:grass_block
setblock 417 65 -363 minecraft:smooth_quartz
fill 418 65 -363 422 65 -363 minecraft:light_gray_concrete
fill 392 65 -362 416 65 -362 minecraft:grass_block
setblock 417 65 -362 minecraft:smooth_quartz
fill 418 65 -362 422 65 -362 minecraft:light_gray_concrete
fill 392 65 -361 416 65 -361 minecraft:grass_block
setblock 417 65 -361 minecraft:smooth_quartz
fill 418 65 -361 422 65 -361 minecraft:light_gray_concrete
fill 392 65 -360 416 65 -360 minecraft:grass_block
setblock 417 65 -360 minecraft:smooth_quartz
fill 418 65 -360 422 65 -360 minecraft:light_gray_concrete
fill 392 65 -359 416 65 -359 minecraft:grass_block
setblock 417 65 -359 minecraft:smooth_quartz
fill 418 65 -359 422 65 -359 minecraft:light_gray_concrete
fill 392 65 -358 416 65 -358 minecraft:grass_block
setblock 417 65 -358 minecraft:smooth_quartz
fill 418 65 -358 420 65 -358 minecraft:light_gray_concrete
setblock 421 65 -358 minecraft:sea_lantern
setblock 422 65 -358 minecraft:light_gray_concrete
fill 392 65 -357 416 65 -357 minecraft:grass_block
setblock 417 65 -357 minecraft:smooth_quartz
fill 418 65 -357 419 65 -357 minecraft:light_gray_concrete
setblock 420 65 -357 minecraft:sea_lantern
fill 421 65 -357 422 65 -357 minecraft:light_gray_concrete
fill 392 65 -356 416 65 -356 minecraft:grass_block
setblock 417 65 -356 minecraft:smooth_quartz
setblock 418 65 -356 minecraft:light_gray_concrete
setblock 419 65 -356 minecraft:sea_lantern
fill 420 65 -356 422 65 -356 minecraft:light_gray_concrete
fill 392 65 -355 416 65 -355 minecraft:grass_block
setblock 417 65 -355 minecraft:smooth_quartz
setblock 418 65 -355 minecraft:sea_lantern
fill 419 65 -355 422 65 -355 minecraft:light_gray_concrete
fill 392 65 -354 416 65 -354 minecraft:grass_block
setblock 417 65 -354 minecraft:smooth_quartz
fill 418 65 -354 422 65 -354 minecraft:light_gray_concrete
fill 392 65 -353 416 65 -353 minecraft:grass_block
setblock 417 65 -353 minecraft:smooth_quartz
fill 418 65 -353 422 65 -353 minecraft:light_gray_concrete
fill 392 65 -352 416 65 -352 minecraft:grass_block
setblock 417 65 -352 minecraft:smooth_quartz
fill 418 65 -352 422 65 -352 minecraft:light_gray_concrete
fill 392 65 -351 416 65 -351 minecraft:grass_block
setblock 417 65 -351 minecraft:smooth_quartz
fill 418 65 -351 422 65 -351 minecraft:light_gray_concrete
fill 392 65 -350 416 65 -350 minecraft:grass_block
setblock 417 65 -350 minecraft:smooth_quartz
fill 418 65 -350 422 65 -350 minecraft:light_gray_concrete
fill 392 65 -349 416 65 -349 minecraft:grass_block
setblock 417 65 -349 minecraft:smooth_quartz
fill 418 65 -349 420 65 -349 minecraft:light_gray_concrete
setblock 421 65 -349 minecraft:sea_lantern
setblock 422 65 -349 minecraft:light_gray_concrete
fill 392 65 -348 416 65 -348 minecraft:grass_block
setblock 417 65 -348 minecraft:smooth_quartz
fill 418 65 -348 419 65 -348 minecraft:light_gray_concrete
setblock 420 65 -348 minecraft:sea_lantern
fill 421 65 -348 422 65 -348 minecraft:light_gray_concrete
fill 392 65 -347 416 65 -347 minecraft:grass_block
setblock 417 65 -347 minecraft:smooth_quartz
setblock 418 65 -347 minecraft:light_gray_concrete
setblock 419 65 -347 minecraft:sea_lantern
fill 420 65 -347 422 65 -347 minecraft:light_gray_concrete
fill 392 65 -346 416 65 -346 minecraft:grass_block
setblock 417 65 -346 minecraft:smooth_quartz
setblock 418 65 -346 minecraft:sea_lantern
fill 419 65 -346 422 65 -346 minecraft:light_gray_concrete
fill 392 65 -345 416 65 -345 minecraft:grass_block
setblock 417 65 -345 minecraft:smooth_quartz
fill 418 65 -345 422 65 -345 minecraft:light_gray_concrete
fill 392 65 -344 416 65 -344 minecraft:grass_block
setblock 417 65 -344 minecraft:smooth_quartz
fill 418 65 -344 422 65 -344 minecraft:light_gray_concrete
fill 392 65 -343 416 65 -343 minecraft:grass_block
setblock 417 65 -343 minecraft:smooth_quartz
fill 418 65 -343 422 65 -343 minecraft:light_gray_concrete
fill 392 65 -342 416 65 -342 minecraft:grass_block
setblock 417 65 -342 minecraft:smooth_quartz
fill 418 65 -342 422 65 -342 minecraft:light_gray_concrete
fill 392 65 -341 416 65 -341 minecraft:grass_block
setblock 417 65 -341 minecraft:smooth_quartz
fill 418 65 -341 422 65 -341 minecraft:light_gray_concrete
fill 392 65 -340 416 65 -340 minecraft:grass_block
setblock 417 65 -340 minecraft:smooth_quartz
fill 418 65 -340 420 65 -340 minecraft:light_gray_concrete
setblock 421 65 -340 minecraft:sea_lantern
setblock 422 65 -340 minecraft:light_gray_concrete
fill 392 65 -339 416 65 -339 minecraft:grass_block
setblock 417 65 -339 minecraft:smooth_quartz
fill 418 65 -339 419 65 -339 minecraft:light_gray_concrete
setblock 420 65 -339 minecraft:sea_lantern
fill 421 65 -339 422 65 -339 minecraft:light_gray_concrete
fill 392 65 -338 416 65 -338 minecraft:grass_block
setblock 417 65 -338 minecraft:smooth_quartz
setblock 418 65 -338 minecraft:light_gray_concrete
setblock 419 65 -338 minecraft:sea_lantern
fill 420 65 -338 422 65 -338 minecraft:light_gray_concrete
fill 392 65 -337 416 65 -337 minecraft:grass_block
setblock 417 65 -337 minecraft:smooth_quartz
setblock 418 65 -337 minecraft:sea_lantern
fill 419 65 -337 422 65 -337 minecraft:light_gray_concrete
fill 392 65 -336 416 65 -336 minecraft:grass_block
setblock 417 65 -336 minecraft:smooth_quartz
fill 418 65 -336 422 65 -336 minecraft:light_gray_concrete
fill 392 65 -335 416 65 -335 minecraft:grass_block
setblock 417 65 -335 minecraft:smooth_quartz
fill 418 65 -335 422 65 -335 minecraft:light_gray_concrete
fill 392 65 -334 416 65 -334 minecraft:grass_block
setblock 417 65 -334 minecraft:smooth_quartz
fill 418 65 -334 422 65 -334 minecraft:light_gray_concrete
fill 392 65 -333 416 65 -333 minecraft:grass_block
setblock 417 65 -333 minecraft:smooth_quartz
fill 418 65 -333 422 65 -333 minecraft:light_gray_concrete
fill 392 65 -332 416 65 -332 minecraft:grass_block
setblock 417 65 -332 minecraft:smooth_quartz
fill 418 65 -332 422 65 -332 minecraft:light_gray_concrete
fill 392 65 -331 416 65 -331 minecraft:grass_block
setblock 417 65 -331 minecraft:smooth_quartz
fill 418 65 -331 420 65 -331 minecraft:light_gray_concrete
setblock 421 65 -331 minecraft:sea_lantern
setblock 422 65 -331 minecraft:light_gray_concrete
fill 392 65 -330 416 65 -330 minecraft:grass_block
setblock 417 65 -330 minecraft:smooth_quartz
fill 418 65 -330 419 65 -330 minecraft:light_gray_concrete
setblock 420 65 -330 minecraft:sea_lantern
fill 421 65 -330 422 65 -330 minecraft:light_gray_concrete
fill 392 65 -329 416 65 -329 minecraft:grass_block
setblock 417 65 -329 minecraft:smooth_quartz
setblock 418 65 -329 minecraft:light_gray_concrete
setblock 419 65 -329 minecraft:sea_lantern
fill 420 65 -329 422 65 -329 minecraft:light_gray_concrete
fill 392 65 -328 416 65 -328 minecraft:grass_block
setblock 417 65 -328 minecraft:smooth_quartz
setblock 418 65 -328 minecraft:sea_lantern
fill 419 65 -328 422 65 -328 minecraft:light_gray_concrete
fill 392 65 -327 416 65 -327 minecraft:grass_block
setblock 417 65 -327 minecraft:smooth_quartz
fill 418 65 -327 422 65 -327 minecraft:light_gray_concrete
fill 392 65 -326 416 65 -326 minecraft:grass_block
setblock 417 65 -326 minecraft:smooth_quartz
fill 418 65 -326 422 65 -326 minecraft:light_gray_concrete
fill 392 65 -325 416 65 -325 minecraft:grass_block
setblock 417 65 -325 minecraft:smooth_quartz
fill 418 65 -325 422 65 -325 minecraft:light_gray_concrete
fill 392 65 -324 416 65 -324 minecraft:grass_block
setblock 417 65 -324 minecraft:smooth_quartz
fill 418 65 -324 422 65 -324 minecraft:light_gray_concrete
fill 394 65 -323 416 65 -323 minecraft:grass_block
setblock 417 65 -323 minecraft:smooth_quartz
fill 418 65 -323 422 65 -323 minecraft:light_gray_concrete
fill 395 65 -322 416 65 -322 minecraft:grass_block
setblock 417 65 -322 minecraft:smooth_quartz
fill 418 65 -322 420 65 -322 minecraft:light_gray_concrete
setblock 421 65 -322 minecraft:sea_lantern
setblock 422 65 -322 minecraft:light_gray_concrete
fill 397 65 -321 416 65 -321 minecraft:grass_block
setblock 417 65 -321 minecraft:smooth_quartz
fill 418 65 -321 419 65 -321 minecraft:light_gray_concrete
setblock 420 65 -321 minecraft:sea_lantern
fill 421 65 -321 422 65 -321 minecraft:light_gray_concrete
fill 397 65 -320 416 65 -320 minecraft:grass_block
setblock 417 65 -320 minecraft:smooth_quartz
setblock 418 65 -320 minecraft:light_gray_concrete
setblock 419 65 -320 minecraft:sea_lantern
fill 420 65 -320 422 65 -320 minecraft:light_gray_concrete
fill 398 65 -319 416 65 -319 minecraft:grass_block
setblock 417 65 -319 minecraft:smooth_quartz
setblock 418 65 -319 minecraft:sea_lantern
fill 419 65 -319 422 65 -319 minecraft:light_gray_concrete
setblock 412 66 -376 minecraft:oak_log
setblock 412 66 -366 minecraft:oak_log
setblock 412 66 -356 minecraft:oak_log
setblock 412 66 -346 minecraft:oak_log
setblock 412 66 -336 minecraft:oak_log
setblock 412 66 -326 minecraft:oak_log
setblock 412 67 -376 minecraft:oak_log
setblock 412 67 -366 minecraft:oak_log
setblock 412 67 -356 minecraft:oak_log
setblock 412 67 -346 minecraft:oak_log
setblock 412 67 -336 minecraft:oak_log
setblock 412 67 -326 minecraft:oak_log
setblock 412 68 -376 minecraft:oak_log
setblock 412 68 -366 minecraft:oak_log
setblock 412 68 -356 minecraft:oak_log
setblock 412 68 -346 minecraft:oak_log
setblock 412 68 -336 minecraft:oak_log
setblock 412 68 -326 minecraft:oak_log
setblock 412 69 -378 minecraft:oak_leaves[persistent=true]
fill 411 69 -377 413 69 -377 minecraft:oak_leaves[persistent=true]
fill 410 69 -376 411 69 -376 minecraft:oak_leaves[persistent=true]
setblock 412 69 -376 minecraft:oak_log
fill 413 69 -376 414 69 -376 minecraft:oak_leaves[persistent=true]
fill 411 69 -375 413 69 -375 minecraft:oak_leaves[persistent=true]
setblock 412 69 -374 minecraft:oak_leaves[persistent=true]
setblock 412 69 -368 minecraft:oak_leaves[persistent=true]
fill 411 69 -367 413 69 -367 minecraft:oak_leaves[persistent=true]
fill 410 69 -366 411 69 -366 minecraft:oak_leaves[persistent=true]
setblock 412 69 -366 minecraft:oak_log
fill 413 69 -366 414 69 -366 minecraft:oak_leaves[persistent=true]
fill 411 69 -365 413 69 -365 minecraft:oak_leaves[persistent=true]
setblock 412 69 -364 minecraft:oak_leaves[persistent=true]
setblock 412 69 -358 minecraft:oak_leaves[persistent=true]
fill 411 69 -357 413 69 -357 minecraft:oak_leaves[persistent=true]
fill 410 69 -356 411 69 -356 minecraft:oak_leaves[persistent=true]
setblock 412 69 -356 minecraft:oak_log
fill 413 69 -356 414 69 -356 minecraft:oak_leaves[persistent=true]
fill 411 69 -355 413 69 -355 minecraft:oak_leaves[persistent=true]
setblock 412 69 -354 minecraft:oak_leaves[persistent=true]
setblock 412 69 -348 minecraft:oak_leaves[persistent=true]
fill 411 69 -347 413 69 -347 minecraft:oak_leaves[persistent=true]
fill 410 69 -346 411 69 -346 minecraft:oak_leaves[persistent=true]
setblock 412 69 -346 minecraft:oak_log
fill 413 69 -346 414 69 -346 minecraft:oak_leaves[persistent=true]
fill 411 69 -345 413 69 -345 minecraft:oak_leaves[persistent=true]
setblock 412 69 -344 minecraft:oak_leaves[persistent=true]
setblock 412 69 -338 minecraft:oak_leaves[persistent=true]
fill 411 69 -337 413 69 -337 minecraft:oak_leaves[persistent=true]
fill 410 69 -336 411 69 -336 minecraft:oak_leaves[persistent=true]
setblock 412 69 -336 minecraft:oak_log
fill 413 69 -336 414 69 -336 minecraft:oak_leaves[persistent=true]
fill 411 69 -335 413 69 -335 minecraft:oak_leaves[persistent=true]
setblock 412 69 -334 minecraft:oak_leaves[persistent=true]
setblock 412 69 -328 minecraft:oak_leaves[persistent=true]
fill 411 69 -327 413 69 -327 minecraft:oak_leaves[persistent=true]
fill 410 69 -326 411 69 -326 minecraft:oak_leaves[persistent=true]
setblock 412 69 -326 minecraft:oak_log
fill 413 69 -326 414 69 -326 minecraft:oak_leaves[persistent=true]
fill 411 69 -325 413 69 -325 minecraft:oak_leaves[persistent=true]
setblock 412 69 -324 minecraft:oak_leaves[persistent=true]
fill 411 70 -378 413 70 -378 minecraft:oak_leaves[persistent=true]
fill 410 70 -377 414 70 -377 minecraft:oak_leaves[persistent=true]
fill 410 70 -376 411 70 -376 minecraft:oak_leaves[persistent=true]
setblock 412 70 -376 minecraft:oak_log
fill 413 70 -376 414 70 -376 minecraft:oak_leaves[persistent=true]
fill 410 70 -375 414 70 -375 minecraft:oak_leaves[persistent=true]
fill 411 70 -374 413 70 -374 minecraft:oak_leaves[persistent=true]
fill 411 70 -368 413 70 -368 minecraft:oak_leaves[persistent=true]
fill 410 70 -367 414 70 -367 minecraft:oak_leaves[persistent=true]
fill 410 70 -366 411 70 -366 minecraft:oak_leaves[persistent=true]
setblock 412 70 -366 minecraft:oak_log
fill 413 70 -366 414 70 -366 minecraft:oak_leaves[persistent=true]
fill 410 70 -365 414 70 -365 minecraft:oak_leaves[persistent=true]
fill 411 70 -364 413 70 -364 minecraft:oak_leaves[persistent=true]
fill 411 70 -358 413 70 -358 minecraft:oak_leaves[persistent=true]
fill 410 70 -357 414 70 -357 minecraft:oak_leaves[persistent=true]
fill 410 70 -356 411 70 -356 minecraft:oak_leaves[persistent=true]
setblock 412 70 -356 minecraft:oak_log
fill 413 70 -356 414 70 -356 minecraft:oak_leaves[persistent=true]
fill 410 70 -355 414 70 -355 minecraft:oak_leaves[persistent=true]
fill 411 70 -354 413 70 -354 minecraft:oak_leaves[persistent=true]
fill 411 70 -348 413 70 -348 minecraft:oak_leaves[persistent=true]
fill 410 70 -347 414 70 -347 minecraft:oak_leaves[persistent=true]
fill 410 70 -346 411 70 -346 minecraft:oak_leaves[persistent=true]
setblock 412 70 -346 minecraft:oak_log
fill 413 70 -346 414 70 -346 minecraft:oak_leaves[persistent=true]
fill 410 70 -345 414 70 -345 minecraft:oak_leaves[persistent=true]
fill 411 70 -344 413 70 -344 minecraft:oak_leaves[persistent=true]
fill 411 70 -338 413 70 -338 minecraft:oak_leaves[persistent=true]
fill 410 70 -337 414 70 -337 minecraft:oak_leaves[persistent=true]
fill 410 70 -336 411 70 -336 minecraft:oak_leaves[persistent=true]
setblock 412 70 -336 minecraft:oak_log
fill 413 70 -336 414 70 -336 minecraft:oak_leaves[persistent=true]
fill 410 70 -335 414 70 -335 minecraft:oak_leaves[persistent=true]
fill 411 70 -334 413 70 -334 minecraft:oak_leaves[persistent=true]
fill 411 70 -328 413 70 -328 minecraft:oak_leaves[persistent=true]
fill 410 70 -327 414 70 -327 minecraft:oak_leaves[persistent=true]
fill 410 70 -326 411 70 -326 minecraft:oak_leaves[persistent=true]
setblock 412 70 -326 minecraft:oak_log
fill 413 70 -326 414 70 -326 minecraft:oak_leaves[persistent=true]
fill 410 70 -325 414 70 -325 minecraft:oak_leaves[persistent=true]
fill 411 70 -324 413 70 -324 minecraft:oak_leaves[persistent=true]
setblock 412 71 -378 minecraft:oak_leaves[persistent=true]
fill 411 71 -377 413 71 -377 minecraft:oak_leaves[persistent=true]
fill 410 71 -376 414 71 -376 minecraft:oak_leaves[persistent=true]
fill 411 71 -375 413 71 -375 minecraft:oak_leaves[persistent=true]
setblock 412 71 -374 minecraft:oak_leaves[persistent=true]
setblock 412 71 -368 minecraft:oak_leaves[persistent=true]
fill 411 71 -367 413 71 -367 minecraft:oak_leaves[persistent=true]
fill 410 71 -366 414 71 -366 minecraft:oak_leaves[persistent=true]
fill 411 71 -365 413 71 -365 minecraft:oak_leaves[persistent=true]
setblock 412 71 -364 minecraft:oak_leaves[persistent=true]
setblock 412 71 -358 minecraft:oak_leaves[persistent=true]
fill 411 71 -357 413 71 -357 minecraft:oak_leaves[persistent=true]
fill 410 71 -356 414 71 -356 minecraft:oak_leaves[persistent=true]
fill 411 71 -355 413 71 -355 minecraft:oak_leaves[persistent=true]
setblock 412 71 -354 minecraft:oak_leaves[persistent=true]
setblock 412 71 -348 minecraft:oak_leaves[persistent=true]
fill 411 71 -347 413 71 -347 minecraft:oak_leaves[persistent=true]
fill 410 71 -346 414 71 -346 minecraft:oak_leaves[persistent=true]
fill 411 71 -345 413 71 -345 minecraft:oak_leaves[persistent=true]
setblock 412 71 -344 minecraft:oak_leaves[persistent=true]
setblock 412 71 -338 minecraft:oak_leaves[persistent=true]
fill 411 71 -337 413 71 -337 minecraft:oak_leaves[persistent=true]
fill 410 71 -336 414 71 -336 minecraft:oak_leaves[persistent=true]
fill 411 71 -335 413 71 -335 minecraft:oak_leaves[persistent=true]
setblock 412 71 -334 minecraft:oak_leaves[persistent=true]
setblock 412 71 -328 minecraft:oak_leaves[persistent=true]
fill 411 71 -327 413 71 -327 minecraft:oak_leaves[persistent=true]
fill 410 71 -326 414 71 -326 minecraft:oak_leaves[persistent=true]
fill 411 71 -325 413 71 -325 minecraft:oak_leaves[persistent=true]
setblock 412 71 -324 minecraft:oak_leaves[persistent=true]
setblock 412 72 -376 minecraft:oak_leaves[persistent=true]
setblock 412 72 -366 minecraft:oak_leaves[persistent=true]
setblock 412 72 -356 minecraft:oak_leaves[persistent=true]
setblock 412 72 -346 minecraft:oak_leaves[persistent=true]
setblock 412 72 -336 minecraft:oak_leaves[persistent=true]
setblock 412 72 -326 minecraft:oak_leaves[persistent=true]
forceload remove 392 -382 455 -319
tellraw @a {"text":"Campus bau a14 fertig.","color":"green"}
