fill 288 45 -190 290 45 -190 minecraft:stone
setblock 327 45 -190 minecraft:stone
fill 288 45 -189 290 45 -189 minecraft:stone
setblock 327 45 -189 minecraft:stone
fill 289 45 -188 290 45 -188 minecraft:stone
setblock 327 45 -188 minecraft:stone
fill 288 45 -187 290 45 -187 minecraft:stone
setblock 327 45 -187 minecraft:stone
fill 288 45 -186 290 45 -186 minecraft:stone
fill 288 45 -185 289 45 -185 minecraft:stone
setblock 268 45 -162 minecraft:stone
setblock 265 45 -161 minecraft:stone
setblock 268 45 -161 minecraft:stone
fill 264 45 -160 265 45 -160 minecraft:stone
fill 268 45 -160 269 45 -160 minecraft:stone
setblock 264 45 -159 minecraft:stone
setblock 268 45 -159 minecraft:stone
setblock 265 45 -153 minecraft:stone
fill 264 45 -152 265 45 -152 minecraft:stone
fill 264 45 -151 266 45 -151 minecraft:stone
fill 264 45 -150 267 45 -150 minecraft:stone
fill 264 45 -149 267 45 -149 minecraft:stone
fill 264 45 -148 268 45 -148 minecraft:stone
fill 267 45 -147 269 45 -147 minecraft:stone
setblock 271 45 -146 minecraft:stone
fill 264 45 -145 267 45 -145 minecraft:stone
fill 271 45 -145 272 45 -145 minecraft:stone
fill 264 45 -144 273 45 -144 minecraft:stone
fill 264 45 -143 274 45 -143 minecraft:stone
fill 264 45 -142 275 45 -142 minecraft:stone
fill 264 45 -141 275 45 -141 minecraft:stone
fill 264 45 -140 276 45 -140 minecraft:stone
fill 264 45 -139 276 45 -139 minecraft:stone
fill 264 45 -138 276 45 -138 minecraft:stone
fill 264 45 -137 277 45 -137 minecraft:stone
fill 264 45 -136 277 45 -136 minecraft:stone
fill 264 45 -135 278 45 -135 minecraft:stone
fill 264 45 -134 278 45 -134 minecraft:stone
fill 264 45 -133 279 45 -133 minecraft:stone
fill 264 45 -132 280 45 -132 minecraft:stone
fill 264 45 -131 281 45 -131 minecraft:stone
fill 264 45 -130 282 45 -130 minecraft:stone
fill 264 45 -129 283 45 -129 minecraft:stone
fill 264 45 -128 284 45 -128 minecraft:stone
fill 264 45 -127 284 45 -127 minecraft:stone
fill 289 46 -190 290 46 -190 minecraft:stone
setblock 327 46 -190 minecraft:stone
fill 289 46 -189 290 46 -189 minecraft:stone
setblock 327 46 -189 minecraft:stone
fill 289 46 -188 290 46 -188 minecraft:stone
fill 289 46 -187 290 46 -187 minecraft:stone
setblock 289 46 -186 minecraft:stone
fill 264 46 -161 266 46 -161 minecraft:stone
fill 264 46 -160 266 46 -160 minecraft:stone
fill 264 46 -159 266 46 -159 minecraft:stone
fill 264 46 -158 266 46 -158 minecraft:stone
fill 264 46 -157 265 46 -157 minecraft:stone
setblock 264 46 -156 minecraft:stone
setblock 267 46 -153 minecraft:stone
setblock 267 46 -152 minecraft:stone
fill 266 46 -151 267 46 -151 minecraft:stone
fill 265 46 -150 268 46 -150 minecraft:stone
fill 264 46 -149 269 46 -149 minecraft:stone
fill 264 46 -148 269 46 -148 minecraft:stone
setblock 271 46 -147 minecraft:stone
setblock 264 46 -146 minecraft:stone
fill 270 46 -146 273 46 -146 minecraft:stone
fill 264 46 -145 268 46 -145 minecraft:stone
fill 270 46 -145 274 46 -145 minecraft:stone
fill 264 46 -144 275 46 -144 minecraft:stone
fill 264 46 -143 276 46 -143 minecraft:stone
fill 264 46 -142 276 46 -142 minecraft:stone
fill 264 46 -141 277 46 -141 minecraft:stone
fill 264 46 -140 277 46 -140 minecraft:stone
fill 264 46 -139 277 46 -139 minecraft:stone
fill 264 46 -138 277 46 -138 minecraft:stone
fill 264 46 -137 278 46 -137 minecraft:stone
fill 264 46 -136 278 46 -136 minecraft:stone
fill 264 46 -135 279 46 -135 minecraft:stone
fill 264 46 -134 279 46 -134 minecraft:stone
fill 264 46 -133 280 46 -133 minecraft:stone
fill 264 46 -132 282 46 -132 minecraft:stone
fill 264 46 -131 283 46 -131 minecraft:stone
fill 264 46 -130 284 46 -130 minecraft:stone
fill 264 46 -129 285 46 -129 minecraft:stone
fill 264 46 -128 287 46 -128 minecraft:stone
fill 264 46 -127 285 46 -127 minecraft:stone
fill 289 47 -190 291 47 -190 minecraft:stone
fill 289 47 -189 291 47 -189 minecraft:stone
fill 289 47 -188 291 47 -188 minecraft:stone
fill 289 47 -187 291 47 -187 minecraft:stone
setblock 268 47 -167 minecraft:stone
fill 267 47 -166 269 47 -166 minecraft:stone
fill 267 47 -165 268 47 -165 minecraft:stone
fill 267 47 -164 268 47 -164 minecraft:stone
fill 270 47 -164 273 47 -164 minecraft:stone
fill 266 47 -163 274 47 -163 minecraft:stone
fill 265 47 -162 274 47 -162 minecraft:stone
fill 264 47 -161 275 47 -161 minecraft:stone
fill 264 47 -160 266 47 -160 minecraft:stone
fill 269 47 -160 276 47 -160 minecraft:stone
fill 264 47 -159 266 47 -159 minecraft:stone
fill 269 47 -159 275 47 -159 minecraft:stone
fill 264 47 -158 266 47 -158 minecraft:stone
fill 269 47 -158 272 47 -158 minecraft:stone
fill 264 47 -157 267 47 -157 minecraft:stone
fill 269 47 -157 271 47 -157 minecraft:stone
fill 264 47 -156 266 47 -156 minecraft:stone
setblock 269 47 -156 minecraft:stone
fill 264 47 -155 266 47 -155 minecraft:stone
fill 264 47 -154 265 47 -154 minecraft:stone
setblock 264 47 -153 minecraft:stone
fill 268 47 -151 269 47 -151 minecraft:stone
fill 267 47 -150 269 47 -150 minecraft:stone
fill 267 47 -149 269 47 -149 minecraft:stone
fill 266 47 -148 268 47 -148 minecraft:stone
fill 271 47 -148 273 47 -148 minecraft:stone
fill 270 47 -147 275 47 -147 minecraft:stone
fill 264 47 -146 266 47 -146 minecraft:stone
fill 270 47 -146 276 47 -146 minecraft:stone
fill 264 47 -145 277 47 -145 minecraft:stone
fill 264 47 -144 277 47 -144 minecraft:stone
fill 264 47 -143 277 47 -143 minecraft:stone
fill 264 47 -142 278 47 -142 minecraft:stone
fill 264 47 -141 278 47 -141 minecraft:stone
fill 264 47 -140 278 47 -140 minecraft:stone
fill 264 47 -139 278 47 -139 minecraft:stone
fill 264 47 -138 278 47 -138 minecraft:stone
fill 264 47 -137 279 47 -137 minecraft:stone
fill 264 47 -136 279 47 -136 minecraft:stone
fill 264 47 -135 280 47 -135 minecraft:stone
fill 264 47 -134 281 47 -134 minecraft:stone
fill 264 47 -133 282 47 -133 minecraft:stone
fill 264 47 -132 285 47 -132 minecraft:stone
fill 264 47 -131 287 47 -131 minecraft:stone
fill 264 47 -130 288 47 -130 minecraft:stone
fill 264 47 -129 288 47 -129 minecraft:stone
fill 264 47 -128 288 47 -128 minecraft:stone
fill 264 47 -127 288 47 -127 minecraft:stone
fill 290 48 -190 291 48 -190 minecraft:stone
fill 290 48 -189 291 48 -189 minecraft:stone
fill 290 48 -188 291 48 -188 minecraft:stone
setblock 264 48 -170 minecraft:stone
fill 264 48 -169 268 48 -169 minecraft:stone
fill 264 48 -168 269 48 -168 minecraft:stone
fill 265 48 -167 269 48 -167 minecraft:stone
fill 266 48 -166 273 48 -166 minecraft:stone
fill 266 48 -165 275 48 -165 minecraft:stone
fill 266 48 -164 276 48 -164 minecraft:stone
fill 265 48 -163 277 48 -163 minecraft:stone
fill 264 48 -162 277 48 -162 minecraft:stone
fill 264 48 -161 278 48 -161 minecraft:stone
fill 264 48 -160 278 48 -160 minecraft:stone
fill 264 48 -159 278 48 -159 minecraft:stone
fill 264 48 -158 279 48 -158 minecraft:stone
fill 264 48 -157 280 48 -157 minecraft:stone
fill 264 48 -156 280 48 -156 minecraft:stone
fill 264 48 -155 280 48 -155 minecraft:stone
fill 264 48 -154 267 48 -154 minecraft:stone
fill 269 48 -154 271 48 -154 minecraft:stone
fill 277 48 -154 280 48 -154 minecraft:stone
fill 264 48 -153 266 48 -153 minecraft:stone
setblock 270 48 -153 minecraft:stone
fill 264 48 -152 266 48 -152 minecraft:stone
setblock 270 48 -152 minecraft:stone
fill 264 48 -151 265 48 -151 minecraft:stone
fill 270 48 -151 271 48 -151 minecraft:stone
setblock 264 48 -150 minecraft:stone
fill 271 48 -150 279 48 -150 minecraft:stone
fill 272 48 -149 280 48 -149 minecraft:stone
fill 270 48 -148 280 48 -148 minecraft:stone
fill 269 48 -147 280 48 -147 minecraft:stone
fill 264 48 -146 266 48 -146 minecraft:stone
fill 269 48 -146 280 48 -146 minecraft:stone
setblock 320 48 -146 minecraft:stone
fill 264 48 -145 280 48 -145 minecraft:stone
setblock 320 48 -145 minecraft:stone
fill 264 48 -144 280 48 -144 minecraft:stone
setblock 320 48 -144 minecraft:stone
fill 264 48 -143 279 48 -143 minecraft:stone
fill 319 48 -143 321 48 -143 minecraft:stone
fill 264 48 -142 279 48 -142 minecraft:stone
fill 319 48 -142 322 48 -142 minecraft:stone
fill 264 48 -141 279 48 -141 minecraft:stone
fill 319 48 -141 323 48 -141 minecraft:stone
fill 264 48 -140 279 48 -140 minecraft:stone
fill 319 48 -140 323 48 -140 minecraft:stone
fill 264 48 -139 279 48 -139 minecraft:stone
fill 319 48 -139 322 48 -139 minecraft:stone
fill 264 48 -138 279 48 -138 minecraft:stone
fill 320 48 -138 321 48 -138 minecraft:stone
fill 264 48 -137 280 48 -137 minecraft:stone
fill 264 48 -136 280 48 -136 minecraft:stone
fill 264 48 -135 281 48 -135 minecraft:stone
fill 264 48 -134 282 48 -134 minecraft:stone
fill 264 48 -133 286 48 -133 minecraft:stone
fill 264 48 -132 289 48 -132 minecraft:stone
fill 264 48 -131 288 48 -131 minecraft:stone
fill 264 48 -130 288 48 -130 minecraft:stone
fill 264 48 -129 288 48 -129 minecraft:stone
fill 264 48 -128 288 48 -128 minecraft:stone
fill 298 48 -128 304 48 -128 minecraft:stone
fill 264 48 -127 288 48 -127 minecraft:stone
fill 297 48 -127 304 48 -127 minecraft:stone
fill 290 49 -190 291 49 -190 minecraft:stone
fill 290 49 -189 291 49 -189 minecraft:stone
setblock 320 49 -148 minecraft:stone
setblock 320 49 -147 minecraft:stone
setblock 320 49 -146 minecraft:stone
setblock 320 49 -145 minecraft:stone
fill 319 49 -144 321 49 -144 minecraft:stone
fill 319 49 -143 321 49 -143 minecraft:stone
fill 319 49 -142 322 49 -142 minecraft:stone
fill 318 49 -141 323 49 -141 minecraft:stone
fill 318 49 -140 324 49 -140 minecraft:stone
fill 318 49 -139 323 49 -139 minecraft:stone
fill 319 49 -138 322 49 -138 minecraft:stone
fill 319 49 -137 321 49 -137 minecraft:stone
fill 267 49 -133 270 49 -133 minecraft:stone
fill 264 49 -132 271 49 -132 minecraft:stone
fill 264 49 -131 272 49 -131 minecraft:stone
fill 265 49 -130 273 49 -130 minecraft:stone
fill 267 49 -129 273 49 -129 minecraft:stone
fill 269 49 -128 274 49 -128 minecraft:stone
fill 296 49 -128 305 49 -128 minecraft:stone
fill 270 49 -127 274 49 -127 minecraft:stone
fill 296 49 -127 305 49 -127 minecraft:stone
fill 290 50 -190 291 50 -190 minecraft:stone
setblock 320 50 -148 minecraft:stone
setblock 320 50 -147 minecraft:stone
fill 320 50 -146 321 50 -146 minecraft:stone
fill 319 50 -145 321 50 -145 minecraft:stone
fill 319 50 -144 321 50 -144 minecraft:stone
fill 318 50 -143 322 50 -143 minecraft:stone
fill 318 50 -142 323 50 -142 minecraft:stone
fill 317 50 -141 323 50 -141 minecraft:stone
fill 317 50 -140 326 50 -140 minecraft:stone
fill 317 50 -139 323 50 -139 minecraft:stone
fill 316 50 -138 323 50 -138 minecraft:stone
fill 316 50 -137 322 50 -137 minecraft:stone
fill 316 50 -136 322 50 -136 minecraft:stone
fill 316 50 -135 321 50 -135 minecraft:stone
fill 316 50 -134 320 50 -134 minecraft:stone
fill 316 50 -133 320 50 -133 minecraft:stone
fill 267 50 -132 271 50 -132 minecraft:stone
fill 315 50 -132 316 50 -132 minecraft:stone
fill 267 50 -131 272 50 -131 minecraft:stone
setblock 316 50 -131 minecraft:stone
fill 267 50 -130 273 50 -130 minecraft:stone
fill 268 50 -129 274 50 -129 minecraft:stone
fill 301 50 -129 306 50 -129 minecraft:stone
fill 269 50 -128 274 50 -128 minecraft:stone
fill 296 50 -128 307 50 -128 minecraft:stone
fill 270 50 -127 274 50 -127 minecraft:stone
fill 295 50 -127 307 50 -127 minecraft:stone
fill 320 51 -148 321 51 -148 minecraft:stone
fill 319 51 -147 321 51 -147 minecraft:stone
fill 319 51 -146 321 51 -146 minecraft:stone
fill 318 51 -145 322 51 -145 minecraft:stone
fill 318 51 -144 322 51 -144 minecraft:stone
fill 317 51 -143 323 51 -143 minecraft:stone
fill 316 51 -142 323 51 -142 minecraft:stone
fill 316 51 -141 325 51 -141 minecraft:stone
fill 316 51 -140 327 51 -140 minecraft:stone
fill 316 51 -139 326 51 -139 minecraft:stone
fill 316 51 -138 323 51 -138 minecraft:stone
fill 316 51 -137 323 51 -137 minecraft:stone
fill 316 51 -136 323 51 -136 minecraft:stone
fill 316 51 -135 322 51 -135 minecraft:stone
fill 315 51 -134 322 51 -134 minecraft:stone
fill 314 51 -133 322 51 -133 minecraft:stone
fill 307 51 -132 321 51 -132 minecraft:stone
fill 270 51 -131 272 51 -131 minecraft:stone
fill 306 51 -131 321 51 -131 minecraft:stone
fill 269 51 -130 273 51 -130 minecraft:stone
fill 304 51 -130 321 51 -130 minecraft:stone
fill 269 51 -129 274 51 -129 minecraft:stone
fill 299 51 -129 321 51 -129 minecraft:stone
fill 270 51 -128 274 51 -128 minecraft:stone
fill 296 51 -128 320 51 -128 minecraft:stone
fill 270 51 -127 274 51 -127 minecraft:stone
fill 295 51 -127 320 51 -127 minecraft:stone
fill 318 52 -148 322 52 -148 minecraft:stone
fill 317 52 -147 322 52 -147 minecraft:stone
fill 317 52 -146 322 52 -146 minecraft:stone
fill 316 52 -145 323 52 -145 minecraft:stone
fill 316 52 -144 323 52 -144 minecraft:stone
fill 316 52 -143 323 52 -143 minecraft:stone
fill 316 52 -142 325 52 -142 minecraft:stone
fill 316 52 -141 327 52 -141 minecraft:stone
fill 316 52 -140 327 52 -140 minecraft:stone
fill 316 52 -139 327 52 -139 minecraft:stone
fill 316 52 -138 327 52 -138 minecraft:stone
fill 316 52 -137 327 52 -137 minecraft:stone
fill 315 52 -136 323 52 -136 minecraft:stone
fill 326 52 -136 327 52 -136 minecraft:stone
fill 315 52 -135 323 52 -135 minecraft:stone
fill 326 52 -135 327 52 -135 minecraft:stone
fill 314 52 -134 323 52 -134 minecraft:stone
fill 326 52 -134 327 52 -134 minecraft:stone
fill 309 52 -133 323 52 -133 minecraft:stone
fill 326 52 -133 327 52 -133 minecraft:stone
fill 305 52 -132 323 52 -132 minecraft:stone
setblock 327 52 -132 minecraft:stone
fill 304 52 -131 323 52 -131 minecraft:stone
fill 302 52 -130 323 52 -130 minecraft:stone
fill 271 52 -129 272 52 -129 minecraft:stone
fill 297 52 -129 322 52 -129 minecraft:stone
fill 271 52 -128 273 52 -128 minecraft:stone
fill 295 52 -128 322 52 -128 minecraft:stone
fill 271 52 -127 273 52 -127 minecraft:stone
fill 295 52 -127 322 52 -127 minecraft:stone
fill 316 53 -148 323 53 -148 minecraft:stone
fill 316 53 -147 323 53 -147 minecraft:stone
fill 316 53 -146 323 53 -146 minecraft:stone
fill 316 53 -145 324 53 -145 minecraft:stone
fill 316 53 -144 326 53 -144 minecraft:stone
fill 316 53 -143 327 53 -143 minecraft:stone
fill 316 53 -142 327 53 -142 minecraft:stone
fill 316 53 -141 327 53 -141 minecraft:stone
fill 316 53 -140 327 53 -140 minecraft:stone
fill 316 53 -139 327 53 -139 minecraft:stone
fill 315 53 -138 327 53 -138 minecraft:stone
fill 315 53 -137 327 53 -137 minecraft:stone
fill 314 53 -136 327 53 -136 minecraft:stone
fill 314 53 -135 327 53 -135 minecraft:stone
fill 312 53 -134 327 53 -134 minecraft:stone
fill 307 53 -133 327 53 -133 minecraft:stone
fill 304 53 -132 327 53 -132 minecraft:stone
fill 303 53 -131 327 53 -131 minecraft:stone
fill 301 53 -130 327 53 -130 minecraft:stone
fill 296 53 -129 324 53 -129 minecraft:stone
fill 295 53 -128 323 53 -128 minecraft:stone
fill 294 53 -127 323 53 -127 minecraft:stone
fill 324 54 -152 327 54 -152 minecraft:stone
fill 324 54 -151 326 54 -151 minecraft:stone
fill 324 54 -150 326 54 -150 minecraft:stone
fill 324 54 -149 326 54 -149 minecraft:stone
fill 316 54 -148 325 54 -148 minecraft:stone
fill 316 54 -147 326 54 -147 minecraft:stone
fill 316 54 -146 327 54 -146 minecraft:stone
fill 316 54 -145 327 54 -145 minecraft:stone
fill 316 54 -144 327 54 -144 minecraft:stone
fill 316 54 -143 327 54 -143 minecraft:stone
fill 316 54 -142 327 54 -142 minecraft:stone
fill 316 54 -141 327 54 -141 minecraft:stone
fill 316 54 -140 327 54 -140 minecraft:stone
fill 315 54 -139 327 54 -139 minecraft:stone
fill 315 54 -138 327 54 -138 minecraft:stone
fill 315 54 -137 327 54 -137 minecraft:stone
fill 313 54 -136 327 54 -136 minecraft:stone
fill 312 54 -135 327 54 -135 minecraft:stone
fill 310 54 -134 327 54 -134 minecraft:stone
fill 305 54 -133 327 54 -133 minecraft:stone
fill 303 54 -132 327 54 -132 minecraft:stone
fill 301 54 -131 327 54 -131 minecraft:stone
fill 299 54 -130 327 54 -130 minecraft:stone
fill 296 54 -129 327 54 -129 minecraft:stone
fill 295 54 -128 326 54 -128 minecraft:stone
fill 294 54 -127 326 54 -127 minecraft:stone
fill 324 55 -152 327 55 -152 minecraft:stone
fill 324 55 -151 327 55 -151 minecraft:stone
fill 324 55 -150 327 55 -150 minecraft:stone
fill 322 55 -149 327 55 -149 minecraft:stone
fill 316 55 -148 327 55 -148 minecraft:stone
fill 316 55 -147 327 55 -147 minecraft:stone
fill 316 55 -146 327 55 -146 minecraft:stone
fill 316 55 -145 327 55 -145 minecraft:stone
fill 316 55 -144 327 55 -144 minecraft:stone
fill 316 55 -143 327 55 -143 minecraft:stone
fill 316 55 -142 327 55 -142 minecraft:stone
fill 316 55 -141 327 55 -141 minecraft:stone
fill 316 55 -140 327 55 -140 minecraft:stone
fill 315 55 -139 327 55 -139 minecraft:stone
fill 315 55 -138 327 55 -138 minecraft:stone
fill 314 55 -137 327 55 -137 minecraft:stone
fill 312 55 -136 327 55 -136 minecraft:stone
fill 311 55 -135 327 55 -135 minecraft:stone
fill 309 55 -134 327 55 -134 minecraft:stone
fill 304 55 -133 327 55 -133 minecraft:stone
fill 301 55 -132 327 55 -132 minecraft:stone
fill 300 55 -131 327 55 -131 minecraft:stone
fill 298 55 -130 327 55 -130 minecraft:stone
fill 296 55 -129 327 55 -129 minecraft:stone
fill 295 55 -128 327 55 -128 minecraft:stone
fill 294 55 -127 327 55 -127 minecraft:stone
fill 323 56 -152 327 56 -152 minecraft:stone
fill 323 56 -151 327 56 -151 minecraft:stone
fill 322 56 -150 327 56 -150 minecraft:stone
fill 319 56 -149 327 56 -149 minecraft:stone
fill 315 56 -148 327 56 -148 minecraft:stone
fill 316 56 -147 327 56 -147 minecraft:stone
fill 316 56 -146 327 56 -146 minecraft:stone
fill 316 56 -145 327 56 -145 minecraft:stone
fill 316 56 -144 327 56 -144 minecraft:stone
fill 316 56 -143 327 56 -143 minecraft:stone
fill 316 56 -142 327 56 -142 minecraft:stone
fill 316 56 -141 327 56 -141 minecraft:stone
fill 316 56 -140 327 56 -140 minecraft:stone
fill 315 56 -139 327 56 -139 minecraft:stone
fill 315 56 -138 327 56 -138 minecraft:stone
fill 313 56 -137 327 56 -137 minecraft:stone
fill 311 56 -136 327 56 -136 minecraft:stone
fill 310 56 -135 327 56 -135 minecraft:stone
fill 308 56 -134 327 56 -134 minecraft:stone
fill 303 56 -133 327 56 -133 minecraft:stone
fill 300 56 -132 327 56 -132 minecraft:stone
fill 299 56 -131 327 56 -131 minecraft:stone
fill 298 56 -130 327 56 -130 minecraft:stone
fill 296 56 -129 327 56 -129 minecraft:stone
fill 295 56 -128 327 56 -128 minecraft:stone
fill 294 56 -127 327 56 -127 minecraft:stone
setblock 327 57 -153 minecraft:stone
fill 323 57 -152 327 57 -152 minecraft:stone
fill 322 57 -151 327 57 -151 minecraft:stone
fill 321 57 -150 327 57 -150 minecraft:stone
fill 316 57 -149 327 57 -149 minecraft:stone
fill 315 57 -148 327 57 -148 minecraft:stone
fill 315 57 -147 327 57 -147 minecraft:stone
fill 316 57 -146 327 57 -146 minecraft:stone
fill 316 57 -145 327 57 -145 minecraft:stone
fill 316 57 -144 327 57 -144 minecraft:stone
fill 316 57 -143 327 57 -143 minecraft:stone
fill 316 57 -142 327 57 -142 minecraft:stone
fill 316 57 -141 327 57 -141 minecraft:stone
fill 315 57 -140 327 57 -140 minecraft:stone
fill 315 57 -139 327 57 -139 minecraft:stone
fill 314 57 -138 327 57 -138 minecraft:stone
fill 313 57 -137 327 57 -137 minecraft:stone
fill 310 57 -136 327 57 -136 minecraft:stone
fill 309 57 -135 327 57 -135 minecraft:stone
fill 306 57 -134 327 57 -134 minecraft:stone
fill 302 57 -133 327 57 -133 minecraft:stone
fill 300 57 -132 327 57 -132 minecraft:stone
fill 299 57 -131 327 57 -131 minecraft:stone
fill 297 57 -130 327 57 -130 minecraft:stone
fill 295 57 -129 327 57 -129 minecraft:stone
fill 294 57 -128 327 57 -128 minecraft:stone
fill 293 57 -127 327 57 -127 minecraft:stone
setblock 327 58 -153 minecraft:stone
fill 322 58 -152 327 58 -152 minecraft:stone
fill 322 58 -151 327 58 -151 minecraft:stone
fill 320 58 -150 327 58 -150 minecraft:stone
fill 316 58 -149 327 58 -149 minecraft:stone
fill 315 58 -148 327 58 -148 minecraft:stone
fill 315 58 -147 327 58 -147 minecraft:stone
fill 315 58 -146 327 58 -146 minecraft:stone
fill 316 58 -145 327 58 -145 minecraft:stone
fill 316 58 -144 327 58 -144 minecraft:stone
fill 316 58 -143 327 58 -143 minecraft:stone
fill 315 58 -142 327 58 -142 minecraft:stone
fill 315 58 -141 327 58 -141 minecraft:stone
fill 315 58 -140 327 58 -140 minecraft:stone
fill 315 58 -139 327 58 -139 minecraft:stone
fill 314 58 -138 327 58 -138 minecraft:stone
fill 312 58 -137 327 58 -137 minecraft:stone
fill 310 58 -136 327 58 -136 minecraft:stone
fill 308 58 -135 327 58 -135 minecraft:stone
fill 304 58 -134 327 58 -134 minecraft:stone
fill 301 58 -133 327 58 -133 minecraft:stone
fill 299 58 -132 327 58 -132 minecraft:stone
fill 298 58 -131 327 58 -131 minecraft:stone
fill 296 58 -130 327 58 -130 minecraft:stone
fill 295 58 -129 327 58 -129 minecraft:stone
fill 294 58 -128 327 58 -128 minecraft:stone
fill 293 58 -127 327 58 -127 minecraft:stone
setblock 327 59 -154 minecraft:stone
fill 326 59 -153 327 59 -153 minecraft:stone
fill 322 59 -152 327 59 -152 minecraft:stone
fill 321 59 -151 327 59 -151 minecraft:stone
fill 319 59 -150 327 59 -150 minecraft:stone
fill 315 59 -149 327 59 -149 minecraft:stone
fill 314 59 -148 327 59 -148 minecraft:stone
fill 315 59 -147 327 59 -147 minecraft:stone
fill 315 59 -146 327 59 -146 minecraft:stone
fill 315 59 -145 327 59 -145 minecraft:stone
fill 316 59 -144 327 59 -144 minecraft:stone
fill 315 59 -143 327 59 -143 minecraft:stone
fill 307 59 -142 309 59 -142 minecraft:stone
fill 315 59 -142 327 59 -142 minecraft:stone
fill 307 59 -141 310 59 -141 minecraft:stone
fill 315 59 -141 327 59 -141 minecraft:stone
fill 307 59 -140 310 59 -140 minecraft:stone
fill 315 59 -140 327 59 -140 minecraft:stone
fill 307 59 -139 310 59 -139 minecraft:stone
fill 314 59 -139 327 59 -139 minecraft:stone
fill 307 59 -138 310 59 -138 minecraft:stone
fill 313 59 -138 327 59 -138 minecraft:stone
fill 307 59 -137 309 59 -137 minecraft:stone
fill 311 59 -137 327 59 -137 minecraft:stone
fill 306 59 -136 327 59 -136 minecraft:stone
fill 306 59 -135 327 59 -135 minecraft:stone
fill 303 59 -134 327 59 -134 minecraft:stone
fill 300 59 -133 327 59 -133 minecraft:stone
fill 299 59 -132 327 59 -132 minecraft:stone
fill 297 59 -131 327 59 -131 minecraft:stone
fill 296 59 -130 327 59 -130 minecraft:stone
fill 294 59 -129 327 59 -129 minecraft:stone
fill 293 59 -128 327 59 -128 minecraft:stone
fill 292 59 -127 327 59 -127 minecraft:stone
setblock 327 60 -155 minecraft:stone
setblock 327 60 -154 minecraft:stone
fill 325 60 -153 327 60 -153 minecraft:stone
fill 321 60 -152 327 60 -152 minecraft:stone
fill 320 60 -151 327 60 -151 minecraft:stone
fill 316 60 -150 327 60 -150 minecraft:stone
fill 315 60 -149 327 60 -149 minecraft:stone
fill 314 60 -148 327 60 -148 minecraft:stone
fill 314 60 -147 327 60 -147 minecraft:stone
fill 315 60 -146 327 60 -146 minecraft:stone
fill 315 60 -145 327 60 -145 minecraft:stone
fill 306 60 -144 309 60 -144 minecraft:stone
fill 315 60 -144 327 60 -144 minecraft:stone
fill 305 60 -143 310 60 -143 minecraft:stone
fill 315 60 -143 327 60 -143 minecraft:stone
fill 305 60 -142 310 60 -142 minecraft:stone
fill 315 60 -142 327 60 -142 minecraft:stone
fill 305 60 -141 311 60 -141 minecraft:stone
fill 315 60 -141 327 60 -141 minecraft:stone
fill 306 60 -140 311 60 -140 minecraft:stone
fill 314 60 -140 327 60 -140 minecraft:stone
fill 306 60 -139 311 60 -139 minecraft:stone
fill 314 60 -139 327 60 -139 minecraft:stone
fill 306 60 -138 311 60 -138 minecraft:stone
fill 313 60 -138 327 60 -138 minecraft:stone
fill 306 60 -137 327 60 -137 minecraft:stone
fill 305 60 -136 327 60 -136 minecraft:stone
fill 304 60 -135 327 60 -135 minecraft:stone
fill 301 60 -134 327 60 -134 minecraft:stone
fill 299 60 -133 327 60 -133 minecraft:stone
fill 298 60 -132 327 60 -132 minecraft:stone
fill 296 60 -131 327 60 -131 minecraft:stone
fill 295 60 -130 327 60 -130 minecraft:stone
fill 294 60 -129 327 60 -129 minecraft:stone
fill 292 60 -128 327 60 -128 minecraft:stone
fill 291 60 -127 327 60 -127 minecraft:stone
setblock 327 61 -156 minecraft:stone
setblock 327 61 -155 minecraft:stone
fill 326 61 -154 327 61 -154 minecraft:stone
fill 324 61 -153 327 61 -153 minecraft:stone
fill 321 61 -152 327 61 -152 minecraft:stone
fill 319 61 -151 327 61 -151 minecraft:stone
fill 315 61 -150 327 61 -150 minecraft:stone
fill 304 61 -149 305 61 -149 minecraft:stone
fill 314 61 -149 327 61 -149 minecraft:stone
fill 304 61 -148 306 61 -148 minecraft:stone
fill 313 61 -148 327 61 -148 minecraft:stone
fill 303 61 -147 307 61 -147 minecraft:stone
fill 314 61 -147 327 61 -147 minecraft:stone
fill 304 61 -146 308 61 -146 minecraft:stone
fill 314 61 -146 327 61 -146 minecraft:stone
fill 304 61 -145 309 61 -145 minecraft:stone
fill 314 61 -145 327 61 -145 minecraft:stone
fill 304 61 -144 310 61 -144 minecraft:stone
fill 315 61 -144 327 61 -144 minecraft:stone
setblock 266 61 -143 minecraft:stone
fill 304 61 -143 310 61 -143 minecraft:stone
fill 315 61 -143 327 61 -143 minecraft:stone
setblock 266 61 -142 minecraft:stone
fill 304 61 -142 311 61 -142 minecraft:stone
fill 314 61 -142 327 61 -142 minecraft:stone
fill 305 61 -141 311 61 -141 minecraft:stone
fill 314 61 -141 327 61 -141 minecraft:stone
fill 305 61 -140 312 61 -140 minecraft:stone
fill 314 61 -140 327 61 -140 minecraft:stone
fill 305 61 -139 327 61 -139 minecraft:stone
fill 305 61 -138 327 61 -138 minecraft:stone
fill 305 61 -137 327 61 -137 minecraft:stone
fill 304 61 -136 327 61 -136 minecraft:stone
fill 301 61 -135 327 61 -135 minecraft:stone
fill 299 61 -134 327 61 -134 minecraft:stone
fill 298 61 -133 327 61 -133 minecraft:stone
fill 297 61 -132 327 61 -132 minecraft:stone
fill 295 61 -131 313 61 -131 minecraft:dirt
fill 314 61 -131 327 61 -131 minecraft:stone
fill 294 61 -130 313 61 -130 minecraft:dirt
fill 314 61 -130 327 61 -130 minecraft:stone
fill 293 61 -129 313 61 -129 minecraft:dirt
fill 314 61 -129 327 61 -129 minecraft:stone
fill 291 61 -128 313 61 -128 minecraft:dirt
fill 314 61 -128 327 61 -128 minecraft:stone
fill 290 61 -127 313 61 -127 minecraft:dirt
fill 314 61 -127 327 61 -127 minecraft:stone
setblock 264 62 -190 minecraft:dirt
setblock 327 62 -172 minecraft:dirt
setblock 327 62 -171 minecraft:dirt
setblock 327 62 -170 minecraft:dirt
setblock 327 62 -169 minecraft:dirt
setblock 327 62 -158 minecraft:dirt
setblock 327 62 -157 minecraft:dirt
setblock 327 62 -156 minecraft:dirt
setblock 327 62 -155 minecraft:dirt
fill 303 62 -154 304 62 -154 minecraft:dirt
fill 326 62 -154 327 62 -154 minecraft:dirt
fill 302 62 -153 305 62 -153 minecraft:dirt
fill 322 62 -153 327 62 -153 minecraft:dirt
fill 302 62 -152 305 62 -152 minecraft:dirt
fill 320 62 -152 327 62 -152 minecraft:dirt
fill 302 62 -151 306 62 -151 minecraft:dirt
fill 315 62 -151 327 62 -151 minecraft:dirt
fill 302 62 -150 306 62 -150 minecraft:dirt
fill 313 62 -150 327 62 -150 minecraft:dirt
fill 302 62 -149 307 62 -149 minecraft:dirt
fill 312 62 -149 327 62 -149 minecraft:dirt
fill 302 62 -148 307 62 -148 minecraft:dirt
fill 311 62 -148 327 62 -148 minecraft:dirt
fill 302 62 -147 308 62 -147 minecraft:dirt
fill 313 62 -147 327 62 -147 minecraft:dirt
fill 303 62 -146 309 62 -146 minecraft:dirt
fill 313 62 -146 327 62 -146 minecraft:dirt
fill 265 62 -145 267 62 -145 minecraft:dirt
fill 303 62 -145 310 62 -145 minecraft:dirt
fill 314 62 -145 327 62 -145 minecraft:dirt
fill 265 62 -144 267 62 -144 minecraft:dirt
fill 303 62 -144 311 62 -144 minecraft:dirt
fill 314 62 -144 327 62 -144 minecraft:dirt
fill 265 62 -143 267 62 -143 minecraft:dirt
fill 303 62 -143 311 62 -143 minecraft:dirt
fill 314 62 -143 327 62 -143 minecraft:dirt
fill 265 62 -142 267 62 -142 minecraft:dirt
fill 304 62 -142 311 62 -142 minecraft:dirt
fill 314 62 -142 327 62 -142 minecraft:dirt
fill 265 62 -141 267 62 -141 minecraft:dirt
fill 304 62 -141 327 62 -141 minecraft:dirt
setblock 266 62 -140 minecraft:dirt
fill 305 62 -140 327 62 -140 minecraft:dirt
fill 305 62 -139 327 62 -139 minecraft:dirt
fill 305 62 -138 327 62 -138 minecraft:dirt
fill 302 62 -137 327 62 -137 minecraft:dirt
setblock 264 62 -136 minecraft:dirt
fill 301 62 -136 327 62 -136 minecraft:dirt
setblock 264 62 -135 minecraft:dirt
fill 298 62 -135 327 62 -135 minecraft:dirt
fill 297 62 -134 327 62 -134 minecraft:dirt
fill 296 62 -133 327 62 -133 minecraft:dirt
fill 295 62 -132 327 62 -132 minecraft:dirt
fill 294 62 -131 327 62 -131 minecraft:dirt
fill 293 62 -130 327 62 -130 minecraft:dirt
fill 291 62 -129 327 62 -129 minecraft:dirt
fill 290 62 -128 327 62 -128 minecraft:dirt
fill 288 62 -127 327 62 -127 minecraft:dirt
setblock 264 63 -190 minecraft:dirt
setblock 327 63 -174 minecraft:dirt
fill 326 63 -173 327 63 -173 minecraft:dirt
fill 326 63 -172 327 63 -172 minecraft:dirt
fill 326 63 -171 327 63 -171 minecraft:dirt
fill 326 63 -170 327 63 -170 minecraft:dirt
fill 326 63 -169 327 63 -169 minecraft:dirt
fill 326 63 -168 327 63 -168 minecraft:dirt
fill 308 63 -163 315 63 -163 minecraft:dirt
fill 303 63 -162 305 63 -162 minecraft:dirt
fill 307 63 -162 316 63 -162 minecraft:dirt
fill 303 63 -161 316 63 -161 minecraft:dirt
fill 303 63 -160 316 63 -160 minecraft:dirt
fill 302 63 -159 316 63 -159 minecraft:dirt
setblock 327 63 -159 minecraft:dirt
fill 302 63 -158 316 63 -158 minecraft:dirt
setblock 327 63 -158 minecraft:dirt
fill 302 63 -157 316 63 -157 minecraft:dirt
setblock 327 63 -157 minecraft:dirt
fill 300 63 -156 316 63 -156 minecraft:dirt
setblock 327 63 -156 minecraft:dirt
fill 301 63 -155 317 63 -155 minecraft:dirt
fill 326 63 -155 327 63 -155 minecraft:dirt
fill 301 63 -154 304 63 -154 minecraft:dirt
fill 306 63 -154 317 63 -154 minecraft:dirt
fill 325 63 -154 327 63 -154 minecraft:dirt
fill 301 63 -153 319 63 -153 minecraft:dirt
fill 321 63 -153 327 63 -153 minecraft:dirt
fill 301 63 -152 327 63 -152 minecraft:dirt
fill 301 63 -151 327 63 -151 minecraft:dirt
fill 301 63 -150 327 63 -150 minecraft:dirt
fill 301 63 -149 327 63 -149 minecraft:dirt
fill 301 63 -148 308 63 -148 minecraft:dirt
fill 310 63 -148 327 63 -148 minecraft:dirt
fill 302 63 -147 327 63 -147 minecraft:dirt
fill 265 63 -146 267 63 -146 minecraft:dirt
fill 301 63 -146 327 63 -146 minecraft:dirt
fill 265 63 -145 268 63 -145 minecraft:dirt
fill 300 63 -145 327 63 -145 minecraft:dirt
fill 264 63 -144 268 63 -144 minecraft:dirt
fill 300 63 -144 311 63 -144 minecraft:dirt
fill 313 63 -144 327 63 -144 minecraft:dirt
fill 264 63 -143 267 63 -143 minecraft:dirt
fill 299 63 -143 311 63 -143 minecraft:dirt
fill 313 63 -143 327 63 -143 minecraft:dirt
fill 264 63 -142 267 63 -142 minecraft:dirt
fill 298 63 -142 327 63 -142 minecraft:dirt
fill 265 63 -141 267 63 -141 minecraft:dirt
fill 296 63 -141 327 63 -141 minecraft:dirt
fill 265 63 -140 267 63 -140 minecraft:dirt
fill 295 63 -140 327 63 -140 minecraft:dirt
fill 295 63 -139 327 63 -139 minecraft:dirt
fill 295 63 -138 327 63 -138 minecraft:dirt
setblock 264 63 -137 minecraft:dirt
fill 295 63 -137 327 63 -137 minecraft:dirt
fill 264 63 -136 265 63 -136 minecraft:dirt
fill 295 63 -136 327 63 -136 minecraft:dirt
fill 264 63 -135 265 63 -135 minecraft:dirt
fill 295 63 -135 327 63 -135 minecraft:dirt
setblock 264 63 -134 minecraft:dirt
fill 294 63 -134 327 63 -134 minecraft:dirt
fill 271 63 -133 274 63 -133 minecraft:dirt
fill 294 63 -133 327 63 -133 minecraft:dirt
fill 269 63 -132 275 63 -132 minecraft:dirt
fill 293 63 -132 327 63 -132 minecraft:dirt
setblock 266 63 -131 minecraft:dirt
fill 268 63 -131 276 63 -131 minecraft:dirt
fill 291 63 -131 327 63 -131 minecraft:dirt
fill 264 63 -130 265 63 -130 minecraft:dirt
setblock 267 63 -130 minecraft:dirt
fill 269 63 -130 277 63 -130 minecraft:dirt
fill 289 63 -130 327 63 -130 minecraft:dirt
fill 264 63 -129 279 63 -129 minecraft:dirt
fill 287 63 -129 327 63 -129 minecraft:dirt
fill 264 63 -128 265 63 -128 minecraft:dirt
fill 267 63 -128 280 63 -128 minecraft:dirt
fill 286 63 -128 327 63 -128 minecraft:dirt
fill 264 63 -127 280 63 -127 minecraft:dirt
fill 285 63 -127 327 63 -127 minecraft:dirt
fill 264 64 -190 286 64 -190 minecraft:dirt
fill 288 64 -190 300 64 -190 minecraft:dirt
fill 316 64 -190 327 64 -190 minecraft:dirt
fill 264 64 -189 274 64 -189 minecraft:dirt
fill 283 64 -189 285 64 -189 minecraft:dirt
fill 290 64 -189 300 64 -189 minecraft:dirt
fill 316 64 -189 327 64 -189 minecraft:dirt
fill 264 64 -188 273 64 -188 minecraft:dirt
fill 290 64 -188 299 64 -188 minecraft:dirt
fill 317 64 -188 327 64 -188 minecraft:dirt
fill 264 64 -187 272 64 -187 minecraft:dirt
fill 291 64 -187 296 64 -187 minecraft:dirt
setblock 317 64 -187 minecraft:dirt
fill 320 64 -187 327 64 -187 minecraft:dirt
fill 264 64 -186 271 64 -186 minecraft:dirt
setblock 292 64 -186 minecraft:dirt
fill 322 64 -186 327 64 -186 minecraft:dirt
fill 265 64 -185 270 64 -185 minecraft:dirt
fill 287 64 -185 288 64 -185 minecraft:dirt
fill 323 64 -185 327 64 -185 minecraft:dirt
fill 264 64 -184 269 64 -184 minecraft:dirt
fill 286 64 -184 289 64 -184 minecraft:dirt
fill 323 64 -184 324 64 -184 minecraft:dirt
fill 326 64 -184 327 64 -184 minecraft:dirt
fill 264 64 -183 268 64 -183 minecraft:dirt
setblock 288 64 -183 minecraft:dirt
fill 323 64 -183 327 64 -183 minecraft:dirt
fill 264 64 -182 266 64 -182 minecraft:dirt
fill 324 64 -182 327 64 -182 minecraft:dirt
fill 324 64 -181 327 64 -181 minecraft:dirt
fill 324 64 -180 327 64 -180 minecraft:dirt
fill 323 64 -179 327 64 -179 minecraft:dirt
fill 323 64 -178 327 64 -178 minecraft:dirt
fill 321 64 -177 327 64 -177 minecraft:dirt
setblock 296 64 -176 minecraft:dirt
fill 320 64 -176 327 64 -176 minecraft:dirt
fill 296 64 -175 297 64 -175 minecraft:dirt
fill 319 64 -175 327 64 -175 minecraft:dirt
fill 296 64 -174 297 64 -174 minecraft:dirt
fill 317 64 -174 327 64 -174 minecraft:dirt
fill 296 64 -173 297 64 -173 minecraft:dirt
fill 315 64 -173 327 64 -173 minecraft:dirt
fill 296 64 -172 297 64 -172 minecraft:dirt
fill 314 64 -172 327 64 -172 minecraft:dirt
fill 296 64 -171 298 64 -171 minecraft:dirt
fill 311 64 -171 327 64 -171 minecraft:dirt
fill 296 64 -170 298 64 -170 minecraft:dirt
fill 305 64 -170 327 64 -170 minecraft:dirt
setblock 296 64 -169 minecraft:dirt
setblock 298 64 -169 minecraft:dirt
fill 302 64 -169 327 64 -169 minecraft:dirt
fill 296 64 -168 299 64 -168 minecraft:dirt
fill 301 64 -168 327 64 -168 minecraft:dirt
fill 296 64 -167 305 64 -167 minecraft:dirt
fill 308 64 -167 327 64 -167 minecraft:dirt
fill 296 64 -166 322 64 -166 minecraft:dirt
setblock 327 64 -166 minecraft:dirt
fill 295 64 -165 322 64 -165 minecraft:dirt
fill 295 64 -164 321 64 -164 minecraft:dirt
fill 295 64 -163 321 64 -163 minecraft:dirt
fill 295 64 -162 319 64 -162 minecraft:dirt
fill 295 64 -161 318 64 -161 minecraft:dirt
fill 295 64 -160 317 64 -160 minecraft:dirt
setblock 327 64 -160 minecraft:dirt
fill 295 64 -159 318 64 -159 minecraft:dirt
setblock 327 64 -159 minecraft:dirt
fill 294 64 -158 318 64 -158 minecraft:dirt
fill 326 64 -158 327 64 -158 minecraft:dirt
setblock 264 64 -157 minecraft:dirt
fill 293 64 -157 318 64 -157 minecraft:dirt
fill 326 64 -157 327 64 -157 minecraft:dirt
fill 264 64 -156 266 64 -156 minecraft:dirt
fill 291 64 -156 318 64 -156 minecraft:dirt
fill 326 64 -156 327 64 -156 minecraft:dirt
fill 264 64 -155 267 64 -155 minecraft:dirt
fill 292 64 -155 318 64 -155 minecraft:dirt
fill 325 64 -155 327 64 -155 minecraft:dirt
fill 264 64 -154 268 64 -154 minecraft:dirt
fill 293 64 -154 319 64 -154 minecraft:dirt
fill 322 64 -154 327 64 -154 minecraft:dirt
fill 264 64 -153 271 64 -153 minecraft:dirt
fill 294 64 -153 327 64 -153 minecraft:dirt
fill 264 64 -152 272 64 -152 minecraft:dirt
fill 295 64 -152 327 64 -152 minecraft:dirt
fill 264 64 -151 272 64 -151 minecraft:dirt
fill 295 64 -151 297 64 -151 minecraft:dirt
fill 299 64 -151 327 64 -151 minecraft:dirt
fill 264 64 -150 273 64 -150 minecraft:dirt
fill 295 64 -150 327 64 -150 minecraft:dirt
fill 264 64 -149 273 64 -149 minecraft:dirt
fill 295 64 -149 327 64 -149 minecraft:dirt
fill 264 64 -148 274 64 -148 minecraft:dirt
fill 296 64 -148 308 64 -148 minecraft:dirt
fill 310 64 -148 327 64 -148 minecraft:dirt
fill 264 64 -147 279 64 -147 minecraft:dirt
setblock 281 64 -147 minecraft:dirt
setblock 283 64 -147 minecraft:dirt
fill 295 64 -147 327 64 -147 minecraft:dirt
fill 264 64 -146 272 64 -146 minecraft:dirt
fill 274 64 -146 280 64 -146 minecraft:dirt
fill 284 64 -146 287 64 -146 minecraft:dirt
fill 292 64 -146 327 64 -146 minecraft:dirt
fill 264 64 -145 280 64 -145 minecraft:dirt
fill 284 64 -145 295 64 -145 minecraft:dirt
fill 297 64 -145 327 64 -145 minecraft:dirt
fill 264 64 -144 285 64 -144 minecraft:dirt
fill 287 64 -144 327 64 -144 minecraft:dirt
fill 264 64 -143 327 64 -143 minecraft:dirt
fill 264 64 -142 327 64 -142 minecraft:dirt
fill 264 64 -141 327 64 -141 minecraft:dirt
fill 264 64 -140 287 64 -140 minecraft:dirt
fill 289 64 -140 327 64 -140 minecraft:dirt
fill 264 64 -139 293 64 -139 minecraft:dirt
fill 295 64 -139 327 64 -139 minecraft:dirt
fill 264 64 -138 327 64 -138 minecraft:dirt
fill 264 64 -137 327 64 -137 minecraft:dirt
fill 264 64 -136 327 64 -136 minecraft:dirt
fill 264 64 -135 327 64 -135 minecraft:dirt
fill 264 64 -134 327 64 -134 minecraft:dirt
fill 264 64 -133 269 64 -133 minecraft:dirt
fill 271 64 -133 327 64 -133 minecraft:dirt
fill 264 64 -132 290 64 -132 minecraft:dirt
fill 292 64 -132 327 64 -132 minecraft:dirt
fill 264 64 -131 313 64 -131 minecraft:water
fill 314 64 -131 327 64 -131 minecraft:dirt
fill 264 64 -130 313 64 -130 minecraft:water
fill 314 64 -130 327 64 -130 minecraft:dirt
fill 264 64 -129 313 64 -129 minecraft:water
fill 314 64 -129 327 64 -129 minecraft:dirt
fill 264 64 -128 313 64 -128 minecraft:water
fill 314 64 -128 327 64 -128 minecraft:dirt
fill 264 64 -127 313 64 -127 minecraft:water
fill 314 64 -127 327 64 -127 minecraft:dirt
setblock 327 65 -166 minecraft:grass_block
fill 326 65 -165 327 65 -165 minecraft:grass_block
fill 325 65 -164 327 65 -164 minecraft:grass_block
fill 324 65 -163 327 65 -163 minecraft:grass_block
fill 323 65 -162 327 65 -162 minecraft:grass_block
fill 322 65 -161 327 65 -161 minecraft:grass_block
fill 321 65 -160 327 65 -160 minecraft:grass_block
fill 320 65 -159 327 65 -159 minecraft:grass_block
fill 319 65 -158 327 65 -158 minecraft:grass_block
fill 318 65 -157 327 65 -157 minecraft:grass_block
fill 317 65 -156 327 65 -156 minecraft:grass_block
fill 315 65 -155 327 65 -155 minecraft:grass_block
fill 314 65 -154 327 65 -154 minecraft:grass_block
fill 313 65 -153 327 65 -153 minecraft:grass_block
fill 311 65 -152 327 65 -152 minecraft:grass_block
fill 310 65 -151 327 65 -151 minecraft:grass_block
fill 311 65 -150 327 65 -150 minecraft:grass_block
fill 312 65 -149 327 65 -149 minecraft:grass_block
fill 305 65 -148 306 65 -148 minecraft:grass_block
fill 312 65 -148 327 65 -148 minecraft:grass_block
fill 303 65 -147 306 65 -147 minecraft:grass_block
fill 312 65 -147 327 65 -147 minecraft:grass_block
fill 301 65 -146 306 65 -146 minecraft:grass_block
setblock 312 65 -146 minecraft:light_gray_concrete
fill 313 65 -146 327 65 -146 minecraft:grass_block
fill 299 65 -145 307 65 -145 minecraft:grass_block
setblock 308 65 -145 minecraft:light_gray_concrete
fill 309 65 -145 312 65 -145 minecraft:smooth_quartz
setblock 313 65 -145 minecraft:light_gray_concrete
fill 314 65 -145 327 65 -145 minecraft:grass_block
fill 299 65 -144 307 65 -144 minecraft:grass_block
fill 308 65 -144 309 65 -144 minecraft:light_gray_concrete
fill 310 65 -144 312 65 -144 minecraft:smooth_quartz
setblock 313 65 -144 minecraft:light_gray_concrete
fill 314 65 -144 327 65 -144 minecraft:grass_block
fill 299 65 -143 308 65 -143 minecraft:grass_block
setblock 309 65 -143 minecraft:light_gray_concrete
fill 310 65 -143 313 65 -143 minecraft:smooth_quartz
setblock 314 65 -143 minecraft:light_gray_concrete
fill 315 65 -143 327 65 -143 minecraft:grass_block
fill 292 65 -142 309 65 -142 minecraft:grass_block
setblock 310 65 -142 minecraft:light_gray_concrete
fill 311 65 -142 313 65 -142 minecraft:smooth_quartz
fill 314 65 -142 315 65 -142 minecraft:light_gray_concrete
fill 316 65 -142 327 65 -142 minecraft:grass_block
setblock 291 65 -141 minecraft:grass_block
fill 297 65 -141 309 65 -141 minecraft:grass_block
setblock 310 65 -141 minecraft:light_gray_concrete
fill 311 65 -141 314 65 -141 minecraft:smooth_quartz
setblock 315 65 -141 minecraft:sea_lantern
fill 316 65 -141 327 65 -141 minecraft:grass_block
setblock 291 65 -140 minecraft:grass_block
fill 297 65 -140 310 65 -140 minecraft:grass_block
setblock 311 65 -140 minecraft:light_gray_concrete
fill 312 65 -140 315 65 -140 minecraft:smooth_quartz
setblock 316 65 -140 minecraft:light_gray_concrete
fill 317 65 -140 327 65 -140 minecraft:grass_block
fill 282 65 -139 285 65 -139 minecraft:grass_block
setblock 291 65 -139 minecraft:grass_block
fill 297 65 -139 311 65 -139 minecraft:grass_block
setblock 312 65 -139 minecraft:sea_lantern
fill 313 65 -139 315 65 -139 minecraft:smooth_quartz
setblock 316 65 -139 minecraft:light_gray_concrete
fill 317 65 -139 327 65 -139 minecraft:grass_block
fill 276 65 -138 285 65 -138 minecraft:grass_block
fill 290 65 -138 291 65 -138 minecraft:grass_block
fill 297 65 -138 311 65 -138 minecraft:grass_block
setblock 312 65 -138 minecraft:light_gray_concrete
fill 313 65 -138 316 65 -138 minecraft:smooth_quartz
setblock 317 65 -138 minecraft:light_gray_concrete
fill 318 65 -138 327 65 -138 minecraft:grass_block
fill 264 65 -137 291 65 -137 minecraft:grass_block
fill 296 65 -137 312 65 -137 minecraft:grass_block
setblock 313 65 -137 minecraft:light_gray_concrete
fill 314 65 -137 316 65 -137 minecraft:smooth_quartz
fill 317 65 -137 318 65 -137 minecraft:light_gray_concrete
fill 319 65 -137 327 65 -137 minecraft:grass_block
fill 264 65 -136 312 65 -136 minecraft:grass_block
fill 313 65 -136 314 65 -136 minecraft:light_gray_concrete
fill 315 65 -136 317 65 -136 minecraft:smooth_quartz
setblock 318 65 -136 minecraft:light_gray_concrete
fill 319 65 -136 327 65 -136 minecraft:grass_block
fill 264 65 -135 313 65 -135 minecraft:grass_block
setblock 314 65 -135 minecraft:light_gray_concrete
fill 315 65 -135 318 65 -135 minecraft:smooth_quartz
setblock 319 65 -135 minecraft:light_gray_concrete
fill 320 65 -135 327 65 -135 minecraft:grass_block
fill 264 65 -134 314 65 -134 minecraft:grass_block
setblock 315 65 -134 minecraft:light_gray_concrete
fill 316 65 -134 318 65 -134 minecraft:smooth_quartz
setblock 319 65 -134 minecraft:sea_lantern
fill 320 65 -134 327 65 -134 minecraft:grass_block
fill 264 65 -133 314 65 -133 minecraft:grass_block
setblock 315 65 -133 minecraft:light_gray_concrete
fill 316 65 -133 319 65 -133 minecraft:smooth_quartz
setblock 320 65 -133 minecraft:light_gray_concrete
fill 321 65 -133 327 65 -133 minecraft:grass_block
setblock 264 65 -132 minecraft:sea_lantern
fill 265 65 -132 269 65 -132 minecraft:smooth_quartz
setblock 270 65 -132 minecraft:sea_lantern
fill 271 65 -132 275 65 -132 minecraft:smooth_quartz
setblock 276 65 -132 minecraft:sea_lantern
fill 277 65 -132 281 65 -132 minecraft:smooth_quartz
setblock 282 65 -132 minecraft:sea_lantern
fill 283 65 -132 287 65 -132 minecraft:smooth_quartz
setblock 288 65 -132 minecraft:sea_lantern
fill 289 65 -132 293 65 -132 minecraft:smooth_quartz
setblock 294 65 -132 minecraft:sea_lantern
fill 295 65 -132 299 65 -132 minecraft:smooth_quartz
setblock 300 65 -132 minecraft:sea_lantern
fill 301 65 -132 305 65 -132 minecraft:smooth_quartz
setblock 306 65 -132 minecraft:sea_lantern
fill 307 65 -132 311 65 -132 minecraft:smooth_quartz
setblock 312 65 -132 minecraft:sea_lantern
fill 313 65 -132 314 65 -132 minecraft:smooth_quartz
setblock 315 65 -132 minecraft:grass_block
setblock 316 65 -132 minecraft:sea_lantern
fill 317 65 -132 320 65 -132 minecraft:smooth_quartz
setblock 321 65 -132 minecraft:light_gray_concrete
fill 322 65 -132 327 65 -132 minecraft:grass_block
setblock 314 65 -131 minecraft:smooth_quartz
setblock 315 65 -131 minecraft:grass_block
fill 316 65 -131 317 65 -131 minecraft:light_gray_concrete
fill 318 65 -131 320 65 -131 minecraft:smooth_quartz
setblock 321 65 -131 minecraft:light_gray_concrete
fill 322 65 -131 327 65 -131 minecraft:grass_block
setblock 314 65 -130 minecraft:smooth_quartz
fill 315 65 -130 316 65 -130 minecraft:grass_block
setblock 317 65 -130 minecraft:light_gray_concrete
fill 318 65 -130 321 65 -130 minecraft:smooth_quartz
setblock 322 65 -130 minecraft:light_gray_concrete
fill 323 65 -130 327 65 -130 minecraft:grass_block
setblock 314 65 -129 minecraft:smooth_quartz
fill 315 65 -129 317 65 -129 minecraft:grass_block
setblock 318 65 -129 minecraft:light_gray_concrete
fill 319 65 -129 321 65 -129 minecraft:smooth_quartz
fill 322 65 -129 323 65 -129 minecraft:light_gray_concrete
fill 324 65 -129 327 65 -129 minecraft:grass_block
setblock 314 65 -128 minecraft:sea_lantern
fill 315 65 -128 317 65 -128 minecraft:grass_block
setblock 318 65 -128 minecraft:light_gray_concrete
fill 319 65 -128 322 65 -128 minecraft:smooth_quartz
setblock 323 65 -128 minecraft:light_gray_concrete
fill 324 65 -128 327 65 -128 minecraft:grass_block
setblock 314 65 -127 minecraft:smooth_quartz
fill 315 65 -127 318 65 -127 minecraft:grass_block
setblock 319 65 -127 minecraft:light_gray_concrete
fill 320 65 -127 323 65 -127 minecraft:smooth_quartz
setblock 324 65 -127 minecraft:sea_lantern
fill 325 65 -127 327 65 -127 minecraft:grass_block
setblock 319 66 -159 minecraft:air
setblock 306 66 -139 minecraft:birch_log
setblock 291 66 -132 minecraft:air
setblock 306 67 -139 minecraft:birch_log
setblock 291 67 -132 minecraft:air
setblock 306 68 -139 minecraft:birch_log
setblock 291 68 -132 minecraft:air
setblock 306 69 -141 minecraft:birch_leaves[persistent=true]
fill 305 69 -140 307 69 -140 minecraft:birch_leaves[persistent=true]
fill 304 69 -139 305 69 -139 minecraft:birch_leaves[persistent=true]
setblock 306 69 -139 minecraft:birch_log
fill 307 69 -139 308 69 -139 minecraft:birch_leaves[persistent=true]
fill 305 69 -138 307 69 -138 minecraft:birch_leaves[persistent=true]
setblock 306 69 -137 minecraft:birch_leaves[persistent=true]
setblock 291 69 -132 minecraft:air
fill 305 70 -141 307 70 -141 minecraft:birch_leaves[persistent=true]
fill 304 70 -140 308 70 -140 minecraft:birch_leaves[persistent=true]
fill 304 70 -139 305 70 -139 minecraft:birch_leaves[persistent=true]
setblock 306 70 -139 minecraft:birch_log
fill 307 70 -139 308 70 -139 minecraft:birch_leaves[persistent=true]
fill 304 70 -138 308 70 -138 minecraft:birch_leaves[persistent=true]
fill 305 70 -137 307 70 -137 minecraft:birch_leaves[persistent=true]
setblock 291 70 -133 minecraft:air
fill 290 70 -132 292 70 -132 minecraft:air
setblock 291 70 -131 minecraft:air
setblock 306 71 -141 minecraft:birch_leaves[persistent=true]
fill 305 71 -140 307 71 -140 minecraft:birch_leaves[persistent=true]
fill 304 71 -139 308 71 -139 minecraft:birch_leaves[persistent=true]
fill 305 71 -138 307 71 -138 minecraft:birch_leaves[persistent=true]
setblock 306 71 -137 minecraft:birch_leaves[persistent=true]
fill 289 71 -134 292 71 -134 minecraft:air
fill 289 71 -133 293 71 -133 minecraft:air
fill 289 71 -132 293 71 -132 minecraft:air
fill 289 71 -131 293 71 -131 minecraft:air
fill 290 71 -130 293 71 -130 minecraft:air
setblock 306 72 -139 minecraft:birch_leaves[persistent=true]
fill 289 72 -134 292 72 -134 minecraft:air
fill 289 72 -133 293 72 -133 minecraft:air
fill 289 72 -132 293 72 -132 minecraft:air
fill 289 72 -131 293 72 -131 minecraft:air
fill 289 72 -130 293 72 -130 minecraft:air
setblock 291 73 -134 minecraft:air
fill 290 73 -133 292 73 -133 minecraft:air
fill 289 73 -132 293 73 -132 minecraft:air
fill 290 73 -131 292 73 -131 minecraft:air
setblock 291 74 -133 minecraft:air
fill 290 74 -132 292 74 -132 minecraft:air
fill 290 74 -131 292 74 -131 minecraft:air
fill 290 75 -133 291 75 -133 minecraft:air
fill 290 75 -132 292 75 -132 minecraft:air
fill 290 75 -131 291 75 -131 minecraft:air
setblock 291 76 -132 minecraft:air
setblock 308 85 -190 minecraft:sea_lantern
setblock 304 85 -185 minecraft:sea_lantern
setblock 303 85 -183 minecraft:sea_lantern
setblock 301 85 -181 minecraft:sea_lantern
setblock 327 85 -181 minecraft:sea_lantern
setblock 298 85 -179 minecraft:sea_lantern
fill 325 85 -179 326 85 -179 minecraft:sea_lantern
setblock 296 85 -177 minecraft:sea_lantern
setblock 323 85 -176 minecraft:sea_lantern
setblock 291 85 -174 minecraft:sea_lantern
setblock 322 85 -174 minecraft:sea_lantern
setblock 288 85 -172 minecraft:sea_lantern
fill 285 85 -171 286 85 -171 minecraft:sea_lantern
setblock 283 85 -170 minecraft:sea_lantern
setblock 280 85 -169 minecraft:sea_lantern
setblock 318 85 -169 minecraft:sea_lantern
setblock 277 85 -168 minecraft:sea_lantern
setblock 271 85 -167 minecraft:sea_lantern
fill 274 85 -167 275 85 -167 minecraft:sea_lantern
fill 315 85 -167 316 85 -167 minecraft:sea_lantern
setblock 265 85 -166 minecraft:sea_lantern
setblock 269 85 -166 minecraft:sea_lantern
fill 313 85 -165 314 85 -165 minecraft:sea_lantern
setblock 311 85 -163 minecraft:sea_lantern
setblock 309 85 -161 minecraft:sea_lantern
setblock 304 85 -158 minecraft:sea_lantern
fill 301 85 -156 302 85 -156 minecraft:sea_lantern
setblock 299 85 -155 minecraft:sea_lantern
fill 293 85 -152 294 85 -152 minecraft:sea_lantern
fill 290 85 -151 291 85 -151 minecraft:sea_lantern
fill 287 85 -150 288 85 -150 minecraft:sea_lantern
fill 284 85 -149 285 85 -149 minecraft:sea_lantern
fill 282 85 -148 283 85 -148 minecraft:sea_lantern
setblock 276 85 -147 minecraft:sea_lantern
setblock 264 85 -146 minecraft:sea_lantern
setblock 267 85 -146 minecraft:sea_lantern
setblock 270 85 -146 minecraft:sea_lantern
setblock 274 85 -146 minecraft:sea_lantern
fill 326 86 -187 327 86 -187 minecraft:sea_lantern
setblock 306 86 -181 minecraft:sea_lantern
setblock 321 86 -180 minecraft:sea_lantern
fill 321 86 -179 322 86 -179 minecraft:sea_lantern
fill 315 86 -172 316 86 -172 minecraft:sea_lantern
setblock 316 86 -171 minecraft:sea_lantern
setblock 308 86 -166 minecraft:sea_lantern
setblock 280 86 -165 minecraft:sea_lantern
setblock 309 86 -165 minecraft:sea_lantern
setblock 273 86 -163 minecraft:sea_lantern
setblock 301 86 -161 minecraft:sea_lantern
setblock 301 86 -160 minecraft:sea_lantern
setblock 302 86 -159 minecraft:sea_lantern
fill 292 86 -156 293 86 -156 minecraft:sea_lantern
setblock 293 86 -155 minecraft:sea_lantern
setblock 293 86 -154 minecraft:sea_lantern
setblock 284 86 -153 minecraft:sea_lantern
setblock 284 86 -152 minecraft:sea_lantern
setblock 275 86 -151 minecraft:sea_lantern
setblock 284 86 -151 minecraft:sea_lantern
setblock 265 86 -150 minecraft:sea_lantern
setblock 275 86 -150 minecraft:sea_lantern
setblock 265 86 -149 minecraft:sea_lantern
setblock 275 86 -149 minecraft:sea_lantern
setblock 265 86 -148 minecraft:sea_lantern
forceload remove 264 -190 327 -127
tellraw @a {"text":"Campus bau a33 fertig.","color":"green"}
