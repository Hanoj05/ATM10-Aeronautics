setblock 8 45 -382 minecraft:stone
setblock 8 45 -381 minecraft:stone
fill 8 45 -380 9 45 -380 minecraft:stone
fill 8 45 -379 9 45 -379 minecraft:stone
fill 8 45 -378 9 45 -378 minecraft:stone
fill 8 45 -377 9 45 -377 minecraft:stone
fill 8 45 -376 9 45 -376 minecraft:stone
fill 8 45 -375 9 45 -375 minecraft:stone
setblock 8 45 -374 minecraft:stone
setblock 38 45 -372 minecraft:stone
fill 52 45 -359 54 45 -359 minecraft:stone
fill 46 45 -358 54 45 -358 minecraft:stone
fill 37 45 -357 52 45 -357 minecraft:stone
fill 37 45 -356 44 45 -356 minecraft:stone
setblock 49 45 -353 minecraft:stone
fill 47 45 -352 52 45 -352 minecraft:stone
fill 45 45 -351 53 45 -351 minecraft:stone
fill 48 45 -350 53 45 -350 minecraft:stone
fill 49 45 -349 54 45 -349 minecraft:stone
fill 50 45 -348 54 45 -348 minecraft:stone
fill 52 45 -347 56 45 -347 minecraft:stone
fill 55 45 -346 56 45 -346 minecraft:stone
fill 15 45 -327 18 45 -327 minecraft:stone
fill 14 45 -326 19 45 -326 minecraft:stone
fill 14 45 -325 19 45 -325 minecraft:stone
fill 13 45 -324 20 45 -324 minecraft:stone
fill 14 45 -323 20 45 -323 minecraft:stone
fill 14 45 -322 19 45 -322 minecraft:stone
fill 15 45 -321 18 45 -321 minecraft:stone
setblock 8 46 -382 minecraft:stone
fill 8 46 -381 9 46 -381 minecraft:stone
fill 8 46 -380 9 46 -380 minecraft:stone
fill 8 46 -379 9 46 -379 minecraft:stone
fill 8 46 -378 9 46 -378 minecraft:stone
fill 8 46 -377 10 46 -377 minecraft:stone
fill 8 46 -376 10 46 -376 minecraft:stone
fill 8 46 -375 9 46 -375 minecraft:stone
fill 8 46 -374 9 46 -374 minecraft:stone
fill 37 46 -373 38 46 -373 minecraft:stone
fill 37 46 -372 38 46 -372 minecraft:stone
fill 58 46 -361 59 46 -361 minecraft:stone
fill 56 46 -360 58 46 -360 minecraft:stone
fill 51 46 -359 57 46 -359 minecraft:stone
fill 43 46 -358 56 46 -358 minecraft:stone
fill 36 46 -357 50 46 -357 minecraft:stone
fill 36 46 -356 42 46 -356 minecraft:stone
fill 50 46 -351 52 46 -351 minecraft:stone
fill 49 46 -350 54 46 -350 minecraft:stone
fill 50 46 -349 54 46 -349 minecraft:stone
fill 51 46 -348 56 46 -348 minecraft:stone
fill 51 46 -347 57 46 -347 minecraft:stone
fill 54 46 -346 58 46 -346 minecraft:stone
fill 54 46 -345 56 46 -345 minecraft:stone
fill 58 46 -345 59 46 -345 minecraft:stone
fill 58 46 -344 59 46 -344 minecraft:stone
fill 15 46 -327 18 46 -327 minecraft:stone
fill 14 46 -326 19 46 -326 minecraft:stone
fill 14 46 -325 19 46 -325 minecraft:stone
fill 13 46 -324 20 46 -324 minecraft:stone
fill 14 46 -323 20 46 -323 minecraft:stone
fill 14 46 -322 19 46 -322 minecraft:stone
fill 15 46 -321 18 46 -321 minecraft:stone
fill 8 47 -382 9 47 -382 minecraft:stone
fill 8 47 -381 9 47 -381 minecraft:stone
fill 8 47 -380 9 47 -380 minecraft:stone
fill 8 47 -379 10 47 -379 minecraft:stone
fill 8 47 -378 10 47 -378 minecraft:stone
fill 8 47 -377 10 47 -377 minecraft:stone
fill 8 47 -376 10 47 -376 minecraft:stone
fill 8 47 -375 10 47 -375 minecraft:stone
fill 8 47 -374 9 47 -374 minecraft:stone
setblock 37 47 -373 minecraft:stone
setblock 66 47 -365 minecraft:stone
fill 64 47 -364 65 47 -364 minecraft:stone
fill 62 47 -363 64 47 -363 minecraft:stone
fill 60 47 -362 64 47 -362 minecraft:stone
fill 58 47 -361 63 47 -361 minecraft:stone
fill 55 47 -360 62 47 -360 minecraft:stone
fill 49 47 -359 59 47 -359 minecraft:stone
fill 40 47 -358 41 47 -358 minecraft:stone
fill 49 47 -358 55 47 -358 minecraft:stone
fill 35 47 -357 41 47 -357 minecraft:stone
fill 35 47 -356 40 47 -356 minecraft:stone
fill 51 47 -350 53 47 -350 minecraft:stone
fill 51 47 -349 54 47 -349 minecraft:stone
fill 51 47 -348 57 47 -348 minecraft:stone
fill 52 47 -347 58 47 -347 minecraft:stone
fill 53 47 -346 59 47 -346 minecraft:stone
fill 54 47 -345 61 47 -345 minecraft:stone
fill 55 47 -344 63 47 -344 minecraft:stone
fill 57 47 -343 64 47 -343 minecraft:stone
fill 59 47 -342 66 47 -342 minecraft:stone
fill 62 47 -341 71 47 -341 minecraft:stone
fill 64 47 -340 71 47 -340 minecraft:stone
fill 65 47 -339 71 47 -339 minecraft:stone
fill 68 47 -338 70 47 -338 minecraft:stone
fill 16 47 -327 17 47 -327 minecraft:stone
fill 14 47 -326 19 47 -326 minecraft:stone
fill 14 47 -325 20 47 -325 minecraft:stone
fill 14 47 -324 20 47 -324 minecraft:stone
fill 14 47 -323 20 47 -323 minecraft:stone
fill 14 47 -322 20 47 -322 minecraft:stone
fill 15 47 -321 19 47 -321 minecraft:stone
fill 16 47 -320 17 47 -320 minecraft:stone
fill 8 48 -382 9 48 -382 minecraft:stone
fill 57 48 -382 71 48 -382 minecraft:stone
fill 8 48 -381 10 48 -381 minecraft:stone
fill 58 48 -381 71 48 -381 minecraft:stone
fill 8 48 -380 10 48 -380 minecraft:stone
fill 59 48 -380 71 48 -380 minecraft:stone
fill 8 48 -379 10 48 -379 minecraft:stone
fill 59 48 -379 68 48 -379 minecraft:stone
fill 70 48 -379 71 48 -379 minecraft:stone
fill 8 48 -378 10 48 -378 minecraft:stone
fill 59 48 -378 68 48 -378 minecraft:stone
setblock 70 48 -378 minecraft:stone
fill 8 48 -377 10 48 -377 minecraft:stone
fill 60 48 -377 71 48 -377 minecraft:stone
fill 8 48 -376 11 48 -376 minecraft:stone
fill 60 48 -376 71 48 -376 minecraft:stone
fill 8 48 -375 10 48 -375 minecraft:stone
fill 60 48 -375 71 48 -375 minecraft:stone
fill 8 48 -374 9 48 -374 minecraft:stone
fill 60 48 -374 67 48 -374 minecraft:stone
fill 70 48 -374 71 48 -374 minecraft:stone
fill 60 48 -373 71 48 -373 minecraft:stone
fill 61 48 -372 70 48 -372 minecraft:stone
fill 62 48 -371 70 48 -371 minecraft:stone
fill 63 48 -370 70 48 -370 minecraft:stone
fill 63 48 -369 71 48 -369 minecraft:stone
fill 64 48 -368 71 48 -368 minecraft:stone
fill 64 48 -367 71 48 -367 minecraft:stone
fill 65 48 -366 71 48 -366 minecraft:stone
fill 65 48 -365 71 48 -365 minecraft:stone
fill 64 48 -364 71 48 -364 minecraft:stone
fill 62 48 -363 71 48 -363 minecraft:stone
fill 60 48 -362 71 48 -362 minecraft:stone
fill 57 48 -361 71 48 -361 minecraft:stone
fill 54 48 -360 61 48 -360 minecraft:stone
fill 63 48 -360 71 48 -360 minecraft:stone
fill 52 48 -359 58 48 -359 minecraft:stone
fill 62 48 -359 71 48 -359 minecraft:stone
fill 36 48 -358 39 48 -358 minecraft:stone
fill 51 48 -358 53 48 -358 minecraft:stone
fill 62 48 -358 69 48 -358 minecraft:stone
fill 34 48 -357 38 48 -357 minecraft:stone
fill 61 48 -357 69 48 -357 minecraft:stone
fill 34 48 -356 37 48 -356 minecraft:stone
fill 58 48 -356 68 48 -356 minecraft:stone
fill 58 48 -355 65 48 -355 minecraft:stone
fill 58 48 -354 64 48 -354 minecraft:stone
fill 57 48 -353 64 48 -353 minecraft:stone
fill 57 48 -352 64 48 -352 minecraft:stone
fill 57 48 -351 60 48 -351 minecraft:stone
fill 58 48 -350 60 48 -350 minecraft:stone
fill 58 48 -349 60 48 -349 minecraft:stone
fill 55 48 -348 56 48 -348 minecraft:stone
fill 58 48 -348 60 48 -348 minecraft:stone
fill 54 48 -347 58 48 -347 minecraft:stone
fill 54 48 -346 60 48 -346 minecraft:stone
fill 55 48 -345 62 48 -345 minecraft:stone
fill 56 48 -344 64 48 -344 minecraft:stone
fill 57 48 -343 66 48 -343 minecraft:stone
setblock 71 48 -343 minecraft:stone
fill 58 48 -342 71 48 -342 minecraft:stone
setblock 52 48 -341 minecraft:stone
fill 60 48 -341 71 48 -341 minecraft:stone
fill 51 48 -340 52 48 -340 minecraft:stone
fill 63 48 -340 71 48 -340 minecraft:stone
fill 64 48 -339 71 48 -339 minecraft:stone
fill 66 48 -338 71 48 -338 minecraft:stone
setblock 17 48 -327 minecraft:stone
fill 15 48 -326 19 48 -326 minecraft:stone
fill 14 48 -325 20 48 -325 minecraft:stone
fill 14 48 -324 20 48 -324 minecraft:stone
fill 14 48 -323 20 48 -323 minecraft:stone
fill 14 48 -322 20 48 -322 minecraft:stone
fill 14 48 -321 19 48 -321 minecraft:stone
fill 16 48 -320 18 48 -320 minecraft:stone
setblock 65 48 -319 minecraft:stone
fill 8 49 -382 10 49 -382 minecraft:stone
fill 56 49 -382 71 49 -382 minecraft:stone
fill 8 49 -381 10 49 -381 minecraft:stone
fill 57 49 -381 71 49 -381 minecraft:stone
fill 8 49 -380 10 49 -380 minecraft:stone
fill 58 49 -380 71 49 -380 minecraft:stone
fill 8 49 -379 10 49 -379 minecraft:stone
fill 58 49 -379 71 49 -379 minecraft:stone
fill 8 49 -378 10 49 -378 minecraft:stone
fill 59 49 -378 71 49 -378 minecraft:stone
fill 8 49 -377 11 49 -377 minecraft:stone
fill 59 49 -377 71 49 -377 minecraft:stone
fill 8 49 -376 11 49 -376 minecraft:stone
fill 59 49 -376 71 49 -376 minecraft:stone
fill 8 49 -375 11 49 -375 minecraft:stone
fill 59 49 -375 71 49 -375 minecraft:stone
fill 8 49 -374 10 49 -374 minecraft:stone
fill 59 49 -374 71 49 -374 minecraft:stone
setblock 8 49 -373 minecraft:stone
fill 59 49 -373 71 49 -373 minecraft:stone
fill 59 49 -372 71 49 -372 minecraft:stone
fill 59 49 -371 71 49 -371 minecraft:stone
fill 59 49 -370 71 49 -370 minecraft:stone
fill 60 49 -369 71 49 -369 minecraft:stone
fill 60 49 -368 71 49 -368 minecraft:stone
fill 60 49 -367 71 49 -367 minecraft:stone
fill 61 49 -366 71 49 -366 minecraft:stone
fill 61 49 -365 71 49 -365 minecraft:stone
fill 62 49 -364 71 49 -364 minecraft:stone
fill 61 49 -363 71 49 -363 minecraft:stone
fill 59 49 -362 71 49 -362 minecraft:stone
fill 56 49 -361 71 49 -361 minecraft:stone
fill 53 49 -360 71 49 -360 minecraft:stone
fill 52 49 -359 71 49 -359 minecraft:stone
fill 34 49 -358 39 49 -358 minecraft:stone
fill 51 49 -358 71 49 -358 minecraft:stone
fill 34 49 -357 38 49 -357 minecraft:stone
fill 52 49 -357 71 49 -357 minecraft:stone
fill 34 49 -356 35 49 -356 minecraft:stone
fill 52 49 -356 70 49 -356 minecraft:stone
fill 52 49 -355 65 49 -355 minecraft:stone
fill 52 49 -354 65 49 -354 minecraft:stone
fill 52 49 -353 64 49 -353 minecraft:stone
fill 53 49 -352 64 49 -352 minecraft:stone
fill 52 49 -351 61 49 -351 minecraft:stone
fill 52 49 -350 60 49 -350 minecraft:stone
fill 52 49 -349 60 49 -349 minecraft:stone
fill 52 49 -348 60 49 -348 minecraft:stone
fill 52 49 -347 57 49 -347 minecraft:stone
fill 43 49 -346 44 49 -346 minecraft:stone
fill 53 49 -346 59 49 -346 minecraft:stone
fill 42 49 -345 45 49 -345 minecraft:stone
fill 54 49 -345 62 49 -345 minecraft:stone
fill 41 49 -344 47 49 -344 minecraft:stone
fill 55 49 -344 64 49 -344 minecraft:stone
setblock 71 49 -344 minecraft:stone
fill 58 49 -343 66 49 -343 minecraft:stone
setblock 71 49 -343 minecraft:stone
fill 48 49 -342 52 49 -342 minecraft:stone
fill 59 49 -342 71 49 -342 minecraft:stone
fill 48 49 -341 53 49 -341 minecraft:stone
fill 61 49 -341 71 49 -341 minecraft:stone
fill 48 49 -340 53 49 -340 minecraft:stone
fill 63 49 -340 71 49 -340 minecraft:stone
fill 64 49 -339 71 49 -339 minecraft:stone
setblock 8 49 -338 minecraft:stone
fill 66 49 -338 71 49 -338 minecraft:stone
setblock 8 49 -337 minecraft:stone
setblock 8 49 -335 minecraft:stone
setblock 8 49 -334 minecraft:stone
fill 15 49 -326 19 49 -326 minecraft:stone
fill 14 49 -325 19 49 -325 minecraft:stone
fill 14 49 -324 20 49 -324 minecraft:stone
fill 14 49 -323 20 49 -323 minecraft:stone
fill 14 49 -322 20 49 -322 minecraft:stone
fill 15 49 -321 20 49 -321 minecraft:stone
fill 15 49 -320 19 49 -320 minecraft:stone
setblock 65 49 -319 minecraft:stone
fill 8 50 -382 10 50 -382 minecraft:stone
fill 56 50 -382 71 50 -382 minecraft:stone
fill 8 50 -381 10 50 -381 minecraft:stone
fill 57 50 -381 71 50 -381 minecraft:stone
fill 8 50 -380 10 50 -380 minecraft:stone
fill 57 50 -380 71 50 -380 minecraft:stone
fill 8 50 -379 11 50 -379 minecraft:stone
fill 57 50 -379 71 50 -379 minecraft:stone
fill 8 50 -378 11 50 -378 minecraft:stone
fill 58 50 -378 71 50 -378 minecraft:stone
fill 8 50 -377 11 50 -377 minecraft:stone
fill 58 50 -377 71 50 -377 minecraft:stone
fill 8 50 -376 11 50 -376 minecraft:stone
fill 58 50 -376 71 50 -376 minecraft:stone
fill 8 50 -375 11 50 -375 minecraft:stone
fill 58 50 -375 71 50 -375 minecraft:stone
fill 8 50 -374 11 50 -374 minecraft:stone
fill 58 50 -374 71 50 -374 minecraft:stone
fill 8 50 -373 10 50 -373 minecraft:stone
fill 57 50 -373 71 50 -373 minecraft:stone
fill 56 50 -372 71 50 -372 minecraft:stone
fill 56 50 -371 71 50 -371 minecraft:stone
fill 56 50 -370 71 50 -370 minecraft:stone
fill 56 50 -369 71 50 -369 minecraft:stone
fill 54 50 -368 71 50 -368 minecraft:stone
fill 56 50 -367 71 50 -367 minecraft:stone
fill 56 50 -366 71 50 -366 minecraft:stone
fill 29 50 -365 33 50 -365 minecraft:stone
fill 57 50 -365 71 50 -365 minecraft:stone
fill 26 50 -364 35 50 -364 minecraft:stone
fill 57 50 -364 71 50 -364 minecraft:stone
fill 27 50 -363 36 50 -363 minecraft:stone
fill 56 50 -363 71 50 -363 minecraft:stone
fill 27 50 -362 36 50 -362 minecraft:stone
fill 55 50 -362 71 50 -362 minecraft:stone
fill 28 50 -361 36 50 -361 minecraft:stone
fill 53 50 -361 71 50 -361 minecraft:stone
fill 29 50 -360 36 50 -360 minecraft:stone
fill 52 50 -360 71 50 -360 minecraft:stone
fill 30 50 -359 36 50 -359 minecraft:stone
fill 51 50 -359 71 50 -359 minecraft:stone
fill 31 50 -358 38 50 -358 minecraft:stone
fill 51 50 -358 71 50 -358 minecraft:stone
fill 31 50 -357 38 50 -357 minecraft:stone
fill 50 50 -357 71 50 -357 minecraft:stone
fill 32 50 -356 40 50 -356 minecraft:stone
fill 49 50 -356 71 50 -356 minecraft:stone
fill 31 50 -355 40 50 -355 minecraft:stone
fill 49 50 -355 66 50 -355 minecraft:stone
fill 31 50 -354 41 50 -354 minecraft:stone
fill 49 50 -354 65 50 -354 minecraft:stone
fill 31 50 -353 41 50 -353 minecraft:stone
fill 48 50 -353 64 50 -353 minecraft:stone
fill 31 50 -352 41 50 -352 minecraft:stone
fill 47 50 -352 64 50 -352 minecraft:stone
fill 31 50 -351 41 50 -351 minecraft:stone
fill 49 50 -351 62 50 -351 minecraft:stone
fill 32 50 -350 43 50 -350 minecraft:stone
fill 50 50 -350 60 50 -350 minecraft:stone
fill 32 50 -349 44 50 -349 minecraft:stone
fill 50 50 -349 60 50 -349 minecraft:stone
fill 33 50 -348 44 50 -348 minecraft:stone
fill 50 50 -348 60 50 -348 minecraft:stone
fill 33 50 -347 46 50 -347 minecraft:stone
fill 50 50 -347 58 50 -347 minecraft:stone
fill 34 50 -346 47 50 -346 minecraft:stone
fill 49 50 -346 57 50 -346 minecraft:stone
fill 34 50 -345 57 50 -345 minecraft:stone
fill 34 50 -344 57 50 -344 minecraft:stone
fill 60 50 -344 63 50 -344 minecraft:stone
fill 47 50 -343 56 50 -343 minecraft:stone
fill 60 50 -343 64 50 -343 minecraft:stone
setblock 71 50 -343 minecraft:stone
fill 48 50 -342 56 50 -342 minecraft:stone
fill 61 50 -342 66 50 -342 minecraft:stone
setblock 71 50 -342 minecraft:stone
fill 48 50 -341 54 50 -341 minecraft:stone
fill 62 50 -341 71 50 -341 minecraft:stone
fill 48 50 -340 54 50 -340 minecraft:stone
fill 64 50 -340 71 50 -340 minecraft:stone
fill 66 50 -339 71 50 -339 minecraft:stone
setblock 8 50 -338 minecraft:stone
fill 69 50 -338 70 50 -338 minecraft:stone
setblock 8 50 -337 minecraft:stone
setblock 8 50 -335 minecraft:stone
fill 8 50 -334 9 50 -334 minecraft:stone
fill 16 50 -326 18 50 -326 minecraft:stone
fill 15 50 -325 20 50 -325 minecraft:stone
fill 14 50 -324 20 50 -324 minecraft:stone
fill 14 50 -323 20 50 -323 minecraft:stone
fill 14 50 -322 20 50 -322 minecraft:stone
fill 14 50 -321 20 50 -321 minecraft:stone
fill 15 50 -320 20 50 -320 minecraft:stone
fill 17 50 -319 18 50 -319 minecraft:stone
fill 8 51 -382 11 51 -382 minecraft:stone
fill 56 51 -382 71 51 -382 minecraft:stone
fill 8 51 -381 11 51 -381 minecraft:stone
fill 56 51 -381 71 51 -381 minecraft:stone
fill 8 51 -380 11 51 -380 minecraft:stone
fill 56 51 -380 71 51 -380 minecraft:stone
fill 8 51 -379 11 51 -379 minecraft:stone
fill 57 51 -379 71 51 -379 minecraft:stone
fill 8 51 -378 11 51 -378 minecraft:stone
fill 57 51 -378 71 51 -378 minecraft:stone
fill 8 51 -377 13 51 -377 minecraft:stone
fill 57 51 -377 71 51 -377 minecraft:stone
fill 8 51 -376 15 51 -376 minecraft:stone
fill 57 51 -376 71 51 -376 minecraft:stone
fill 8 51 -375 15 51 -375 minecraft:stone
fill 57 51 -375 71 51 -375 minecraft:stone
fill 8 51 -374 15 51 -374 minecraft:stone
setblock 51 51 -374 minecraft:stone
fill 56 51 -374 71 51 -374 minecraft:stone
fill 8 51 -373 16 51 -373 minecraft:stone
fill 49 51 -373 50 51 -373 minecraft:stone
fill 55 51 -373 71 51 -373 minecraft:stone
fill 8 51 -372 16 51 -372 minecraft:stone
fill 49 51 -372 51 51 -372 minecraft:stone
fill 55 51 -372 71 51 -372 minecraft:stone
fill 8 51 -371 16 51 -371 minecraft:stone
fill 48 51 -371 50 51 -371 minecraft:stone
fill 54 51 -371 71 51 -371 minecraft:stone
fill 11 51 -370 17 51 -370 minecraft:stone
fill 53 51 -370 71 51 -370 minecraft:stone
fill 12 51 -369 19 51 -369 minecraft:stone
fill 52 51 -369 71 51 -369 minecraft:stone
fill 12 51 -368 23 51 -368 minecraft:stone
fill 49 51 -368 71 51 -368 minecraft:stone
fill 14 51 -367 27 51 -367 minecraft:stone
fill 29 51 -367 33 51 -367 minecraft:stone
fill 51 51 -367 71 51 -367 minecraft:stone
fill 15 51 -366 35 51 -366 minecraft:stone
fill 53 51 -366 71 51 -366 minecraft:stone
fill 16 51 -365 36 51 -365 minecraft:stone
fill 54 51 -365 71 51 -365 minecraft:stone
fill 17 51 -364 36 51 -364 minecraft:stone
fill 55 51 -364 71 51 -364 minecraft:stone
fill 18 51 -363 37 51 -363 minecraft:stone
fill 54 51 -363 71 51 -363 minecraft:stone
fill 19 51 -362 37 51 -362 minecraft:stone
fill 52 51 -362 71 51 -362 minecraft:stone
fill 20 51 -361 37 51 -361 minecraft:stone
fill 51 51 -361 71 51 -361 minecraft:stone
fill 20 51 -360 38 51 -360 minecraft:stone
fill 51 51 -360 71 51 -360 minecraft:stone
fill 21 51 -359 38 51 -359 minecraft:stone
fill 50 51 -359 71 51 -359 minecraft:stone
fill 21 51 -358 39 51 -358 minecraft:stone
fill 49 51 -358 71 51 -358 minecraft:stone
fill 21 51 -357 71 51 -357 minecraft:stone
fill 21 51 -356 71 51 -356 minecraft:stone
fill 23 51 -355 67 51 -355 minecraft:stone
fill 25 51 -354 65 51 -354 minecraft:stone
fill 27 51 -353 65 51 -353 minecraft:stone
fill 26 51 -352 64 51 -352 minecraft:stone
fill 27 51 -351 62 51 -351 minecraft:stone
fill 28 51 -350 61 51 -350 minecraft:stone
fill 29 51 -349 60 51 -349 minecraft:stone
fill 28 51 -348 60 51 -348 minecraft:stone
fill 28 51 -347 60 51 -347 minecraft:stone
fill 29 51 -346 58 51 -346 minecraft:stone
fill 30 51 -345 57 51 -345 minecraft:stone
fill 30 51 -344 57 51 -344 minecraft:stone
setblock 32 51 -343 minecraft:stone
fill 47 51 -343 56 51 -343 minecraft:stone
setblock 32 51 -342 minecraft:stone
fill 48 51 -342 56 51 -342 minecraft:stone
setblock 32 51 -341 minecraft:stone
fill 48 51 -341 56 51 -341 minecraft:stone
setblock 32 51 -340 minecraft:stone
fill 48 51 -340 56 51 -340 minecraft:stone
fill 17 51 -326 18 51 -326 minecraft:stone
fill 15 51 -325 19 51 -325 minecraft:stone
fill 15 51 -324 20 51 -324 minecraft:stone
fill 14 51 -323 21 51 -323 minecraft:stone
fill 14 51 -322 21 51 -322 minecraft:stone
fill 14 51 -321 20 51 -321 minecraft:stone
fill 15 51 -320 20 51 -320 minecraft:stone
fill 16 51 -319 19 51 -319 minecraft:stone
fill 8 52 -382 12 52 -382 minecraft:stone
fill 55 52 -382 71 52 -382 minecraft:stone
fill 8 52 -381 11 52 -381 minecraft:stone
fill 55 52 -381 71 52 -381 minecraft:stone
fill 8 52 -380 11 52 -380 minecraft:stone
setblock 16 52 -380 minecraft:stone
fill 55 52 -380 71 52 -380 minecraft:stone
fill 8 52 -379 17 52 -379 minecraft:stone
fill 55 52 -379 71 52 -379 minecraft:stone
fill 8 52 -378 18 52 -378 minecraft:stone
fill 56 52 -378 71 52 -378 minecraft:stone
fill 8 52 -377 19 52 -377 minecraft:stone
fill 56 52 -377 71 52 -377 minecraft:stone
fill 8 52 -376 19 52 -376 minecraft:stone
fill 56 52 -376 71 52 -376 minecraft:stone
fill 8 52 -375 20 52 -375 minecraft:stone
fill 55 52 -375 71 52 -375 minecraft:stone
fill 8 52 -374 20 52 -374 minecraft:stone
setblock 51 52 -374 minecraft:stone
fill 54 52 -374 71 52 -374 minecraft:stone
fill 8 52 -373 21 52 -373 minecraft:stone
fill 49 52 -373 50 52 -373 minecraft:stone
fill 53 52 -373 71 52 -373 minecraft:stone
fill 8 52 -372 22 52 -372 minecraft:stone
fill 49 52 -372 71 52 -372 minecraft:stone
fill 8 52 -371 24 52 -371 minecraft:stone
fill 48 52 -371 71 52 -371 minecraft:stone
fill 8 52 -370 26 52 -370 minecraft:stone
fill 49 52 -370 71 52 -370 minecraft:stone
fill 8 52 -369 34 52 -369 minecraft:stone
fill 48 52 -369 71 52 -369 minecraft:stone
fill 8 52 -368 36 52 -368 minecraft:stone
fill 47 52 -368 71 52 -368 minecraft:stone
fill 8 52 -367 37 52 -367 minecraft:stone
fill 47 52 -367 71 52 -367 minecraft:stone
fill 8 52 -366 37 52 -366 minecraft:stone
fill 48 52 -366 71 52 -366 minecraft:stone
fill 8 52 -365 37 52 -365 minecraft:stone
fill 50 52 -365 71 52 -365 minecraft:stone
fill 9 52 -364 38 52 -364 minecraft:stone
fill 51 52 -364 71 52 -364 minecraft:stone
fill 12 52 -363 38 52 -363 minecraft:stone
fill 50 52 -363 71 52 -363 minecraft:stone
fill 13 52 -362 39 52 -362 minecraft:stone
fill 49 52 -362 71 52 -362 minecraft:stone
fill 14 52 -361 39 52 -361 minecraft:stone
fill 49 52 -361 71 52 -361 minecraft:stone
fill 14 52 -360 42 52 -360 minecraft:stone
fill 47 52 -360 48 52 -360 minecraft:stone
fill 50 52 -360 71 52 -360 minecraft:stone
fill 14 52 -359 43 52 -359 minecraft:stone
fill 46 52 -359 71 52 -359 minecraft:stone
fill 15 52 -358 71 52 -358 minecraft:stone
fill 15 52 -357 71 52 -357 minecraft:stone
fill 15 52 -356 71 52 -356 minecraft:stone
fill 15 52 -355 67 52 -355 minecraft:stone
fill 69 52 -355 71 52 -355 minecraft:stone
fill 16 52 -354 23 52 -354 minecraft:stone
fill 25 52 -354 65 52 -354 minecraft:stone
fill 16 52 -353 18 52 -353 minecraft:stone
fill 21 52 -353 23 52 -353 minecraft:stone
fill 25 52 -353 65 52 -353 minecraft:stone
fill 16 52 -352 21 52 -352 minecraft:stone
fill 24 52 -352 64 52 -352 minecraft:stone
setblock 18 52 -351 minecraft:stone
fill 21 52 -351 62 52 -351 minecraft:stone
fill 19 52 -350 21 52 -350 minecraft:stone
fill 26 52 -350 61 52 -350 minecraft:stone
setblock 20 52 -349 minecraft:stone
setblock 26 52 -349 minecraft:stone
fill 28 52 -349 60 52 -349 minecraft:stone
fill 27 52 -348 60 52 -348 minecraft:stone
fill 28 52 -347 60 52 -347 minecraft:stone
fill 28 52 -346 59 52 -346 minecraft:stone
fill 28 52 -345 58 52 -345 minecraft:stone
fill 28 52 -344 57 52 -344 minecraft:stone
fill 30 52 -343 33 52 -343 minecraft:stone
fill 46 52 -343 57 52 -343 minecraft:stone
fill 31 52 -342 32 52 -342 minecraft:stone
fill 47 52 -342 56 52 -342 minecraft:stone
setblock 32 52 -341 minecraft:stone
fill 48 52 -341 56 52 -341 minecraft:stone
setblock 32 52 -340 minecraft:stone
fill 48 52 -340 56 52 -340 minecraft:stone
fill 16 52 -325 19 52 -325 minecraft:stone
fill 15 52 -324 20 52 -324 minecraft:stone
fill 15 52 -323 21 52 -323 minecraft:stone
fill 14 52 -322 21 52 -322 minecraft:stone
fill 15 52 -321 21 52 -321 minecraft:stone
fill 16 52 -320 21 52 -320 minecraft:stone
fill 16 52 -319 20 52 -319 minecraft:stone
fill 8 53 -382 22 53 -382 minecraft:stone
fill 55 53 -382 71 53 -382 minecraft:stone
fill 8 53 -381 22 53 -381 minecraft:stone
fill 54 53 -381 71 53 -381 minecraft:stone
fill 8 53 -380 22 53 -380 minecraft:stone
fill 52 53 -380 71 53 -380 minecraft:stone
fill 8 53 -379 23 53 -379 minecraft:stone
fill 53 53 -379 71 53 -379 minecraft:stone
fill 8 53 -378 23 53 -378 minecraft:stone
fill 54 53 -378 71 53 -378 minecraft:stone
fill 8 53 -377 24 53 -377 minecraft:stone
fill 54 53 -377 71 53 -377 minecraft:stone
fill 8 53 -376 24 53 -376 minecraft:stone
fill 54 53 -376 71 53 -376 minecraft:stone
fill 8 53 -375 26 53 -375 minecraft:stone
fill 53 53 -375 71 53 -375 minecraft:stone
fill 8 53 -374 27 53 -374 minecraft:stone
fill 51 53 -374 71 53 -374 minecraft:stone
fill 8 53 -373 28 53 -373 minecraft:stone
fill 49 53 -373 71 53 -373 minecraft:stone
fill 8 53 -372 29 53 -372 minecraft:stone
fill 40 53 -372 42 53 -372 minecraft:stone
fill 49 53 -372 71 53 -372 minecraft:stone
fill 8 53 -371 39 53 -371 minecraft:stone
fill 43 53 -371 71 53 -371 minecraft:stone
fill 8 53 -370 39 53 -370 minecraft:stone
fill 43 53 -370 71 53 -370 minecraft:stone
fill 8 53 -369 39 53 -369 minecraft:stone
fill 43 53 -369 71 53 -369 minecraft:stone
fill 8 53 -368 39 53 -368 minecraft:stone
fill 43 53 -368 71 53 -368 minecraft:stone
fill 8 53 -367 39 53 -367 minecraft:stone
fill 43 53 -367 71 53 -367 minecraft:stone
fill 8 53 -366 39 53 -366 minecraft:stone
fill 42 53 -366 71 53 -366 minecraft:stone
fill 8 53 -365 39 53 -365 minecraft:stone
fill 41 53 -365 71 53 -365 minecraft:stone
fill 8 53 -364 71 53 -364 minecraft:stone
fill 8 53 -363 39 53 -363 minecraft:stone
fill 41 53 -363 71 53 -363 minecraft:stone
fill 8 53 -362 39 53 -362 minecraft:stone
fill 41 53 -362 71 53 -362 minecraft:stone
fill 8 53 -361 71 53 -361 minecraft:stone
fill 8 53 -360 71 53 -360 minecraft:stone
fill 8 53 -359 71 53 -359 minecraft:stone
fill 9 53 -358 71 53 -358 minecraft:stone
fill 10 53 -357 71 53 -357 minecraft:stone
fill 11 53 -356 71 53 -356 minecraft:stone
fill 12 53 -355 71 53 -355 minecraft:stone
fill 13 53 -354 66 53 -354 minecraft:stone
fill 13 53 -353 65 53 -353 minecraft:stone
fill 14 53 -352 65 53 -352 minecraft:stone
fill 14 53 -351 62 53 -351 minecraft:stone
fill 15 53 -350 21 53 -350 minecraft:stone
fill 23 53 -350 61 53 -350 minecraft:stone
fill 15 53 -349 17 53 -349 minecraft:stone
fill 19 53 -349 21 53 -349 minecraft:stone
fill 23 53 -349 24 53 -349 minecraft:stone
fill 26 53 -349 60 53 -349 minecraft:stone
fill 16 53 -348 17 53 -348 minecraft:stone
setblock 19 53 -348 minecraft:stone
fill 21 53 -348 60 53 -348 minecraft:stone
setblock 16 53 -347 minecraft:stone
fill 27 53 -347 60 53 -347 minecraft:stone
fill 27 53 -346 60 53 -346 minecraft:stone
fill 28 53 -345 59 53 -345 minecraft:stone
fill 28 53 -344 58 53 -344 minecraft:stone
fill 29 53 -343 33 53 -343 minecraft:stone
fill 46 53 -343 57 53 -343 minecraft:stone
fill 30 53 -342 32 53 -342 minecraft:stone
fill 47 53 -342 56 53 -342 minecraft:stone
fill 31 53 -341 32 53 -341 minecraft:stone
fill 48 53 -341 56 53 -341 minecraft:stone
fill 31 53 -340 32 53 -340 minecraft:stone
fill 48 53 -340 56 53 -340 minecraft:stone
fill 28 53 -326 32 53 -326 minecraft:stone
fill 16 53 -325 19 53 -325 minecraft:stone
fill 27 53 -325 31 53 -325 minecraft:stone
fill 15 53 -324 20 53 -324 minecraft:stone
fill 27 53 -324 30 53 -324 minecraft:stone
fill 15 53 -323 21 53 -323 minecraft:stone
fill 25 53 -323 29 53 -323 minecraft:stone
fill 15 53 -322 21 53 -322 minecraft:stone
fill 24 53 -322 28 53 -322 minecraft:stone
fill 15 53 -321 21 53 -321 minecraft:stone
fill 24 53 -321 28 53 -321 minecraft:stone
fill 15 53 -320 21 53 -320 minecraft:stone
fill 23 53 -320 27 53 -320 minecraft:stone
fill 16 53 -319 21 53 -319 minecraft:stone
fill 23 53 -319 26 53 -319 minecraft:stone
fill 8 54 -382 32 54 -382 minecraft:stone
setblock 38 54 -382 minecraft:stone
fill 52 54 -382 71 54 -382 minecraft:stone
fill 8 54 -381 33 54 -381 minecraft:stone
setblock 39 54 -381 minecraft:stone
fill 51 54 -381 71 54 -381 minecraft:stone
fill 8 54 -380 36 54 -380 minecraft:stone
fill 39 54 -380 40 54 -380 minecraft:stone
fill 50 54 -380 71 54 -380 minecraft:stone
fill 8 54 -379 37 54 -379 minecraft:stone
fill 50 54 -379 71 54 -379 minecraft:stone
fill 8 54 -378 38 54 -378 minecraft:stone
fill 51 54 -378 71 54 -378 minecraft:stone
fill 8 54 -377 39 54 -377 minecraft:stone
fill 43 54 -377 44 54 -377 minecraft:stone
fill 51 54 -377 71 54 -377 minecraft:stone
fill 8 54 -376 45 54 -376 minecraft:stone
fill 52 54 -376 71 54 -376 minecraft:stone
fill 8 54 -375 46 54 -375 minecraft:stone
fill 50 54 -375 71 54 -375 minecraft:stone
fill 8 54 -374 71 54 -374 minecraft:stone
fill 8 54 -373 71 54 -373 minecraft:stone
fill 8 54 -372 71 54 -372 minecraft:stone
fill 8 54 -371 71 54 -371 minecraft:stone
fill 8 54 -370 71 54 -370 minecraft:stone
fill 8 54 -369 71 54 -369 minecraft:stone
fill 8 54 -368 71 54 -368 minecraft:stone
fill 8 54 -367 71 54 -367 minecraft:stone
fill 8 54 -366 71 54 -366 minecraft:stone
fill 8 54 -365 71 54 -365 minecraft:stone
fill 8 54 -364 71 54 -364 minecraft:stone
fill 8 54 -363 71 54 -363 minecraft:stone
fill 8 54 -362 71 54 -362 minecraft:stone
fill 8 54 -361 71 54 -361 minecraft:stone
fill 8 54 -360 71 54 -360 minecraft:stone
fill 8 54 -359 71 54 -359 minecraft:stone
fill 8 54 -358 71 54 -358 minecraft:stone
fill 8 54 -357 71 54 -357 minecraft:stone
fill 8 54 -356 71 54 -356 minecraft:stone
fill 8 54 -355 71 54 -355 minecraft:stone
fill 8 54 -354 66 54 -354 minecraft:stone
fill 9 54 -353 65 54 -353 minecraft:stone
fill 10 54 -352 65 54 -352 minecraft:stone
fill 10 54 -351 62 54 -351 minecraft:stone
fill 11 54 -350 61 54 -350 minecraft:stone
fill 11 54 -349 60 54 -349 minecraft:stone
fill 12 54 -348 19 54 -348 minecraft:stone
fill 21 54 -348 60 54 -348 minecraft:stone
fill 12 54 -347 17 54 -347 minecraft:stone
fill 25 54 -347 60 54 -347 minecraft:stone
fill 13 54 -346 16 54 -346 minecraft:stone
fill 27 54 -346 60 54 -346 minecraft:stone
fill 13 54 -345 16 54 -345 minecraft:stone
fill 27 54 -345 60 54 -345 minecraft:stone
fill 14 54 -344 16 54 -344 minecraft:stone
fill 28 54 -344 60 54 -344 minecraft:stone
fill 28 54 -343 34 54 -343 minecraft:stone
fill 46 54 -343 57 54 -343 minecraft:stone
fill 28 54 -342 33 54 -342 minecraft:stone
fill 47 54 -342 57 54 -342 minecraft:stone
fill 30 54 -341 32 54 -341 minecraft:stone
fill 47 54 -341 56 54 -341 minecraft:stone
fill 30 54 -340 32 54 -340 minecraft:stone
fill 48 54 -340 56 54 -340 minecraft:stone
setblock 32 54 -339 minecraft:stone
fill 32 54 -328 37 54 -328 minecraft:stone
fill 29 54 -327 39 54 -327 minecraft:stone
fill 27 54 -326 40 54 -326 minecraft:stone
fill 27 54 -325 41 54 -325 minecraft:stone
fill 16 54 -324 20 54 -324 minecraft:stone
fill 26 54 -324 32 54 -324 minecraft:stone
fill 38 54 -324 42 54 -324 minecraft:stone
fill 15 54 -323 21 54 -323 minecraft:stone
fill 25 54 -323 30 54 -323 minecraft:stone
fill 39 54 -323 42 54 -323 minecraft:stone
fill 15 54 -322 22 54 -322 minecraft:stone
fill 24 54 -322 29 54 -322 minecraft:stone
fill 40 54 -322 42 54 -322 minecraft:stone
fill 15 54 -321 28 54 -321 minecraft:stone
fill 41 54 -321 44 54 -321 minecraft:stone
fill 15 54 -320 27 54 -320 minecraft:stone
fill 41 54 -320 44 54 -320 minecraft:stone
fill 16 54 -319 27 54 -319 minecraft:stone
fill 43 54 -319 44 54 -319 minecraft:stone
fill 8 55 -382 42 55 -382 minecraft:stone
fill 49 55 -382 71 55 -382 minecraft:stone
fill 8 55 -381 42 55 -381 minecraft:stone
fill 46 55 -381 71 55 -381 minecraft:stone
fill 8 55 -380 43 55 -380 minecraft:stone
fill 45 55 -380 71 55 -380 minecraft:stone
fill 8 55 -379 71 55 -379 minecraft:stone
fill 8 55 -378 71 55 -378 minecraft:stone
fill 8 55 -377 71 55 -377 minecraft:stone
fill 8 55 -376 47 55 -376 minecraft:stone
fill 49 55 -376 71 55 -376 minecraft:stone
fill 8 55 -375 71 55 -375 minecraft:stone
fill 8 55 -374 71 55 -374 minecraft:stone
fill 8 55 -373 71 55 -373 minecraft:stone
fill 8 55 -372 71 55 -372 minecraft:stone
fill 8 55 -371 71 55 -371 minecraft:stone
fill 8 55 -370 71 55 -370 minecraft:stone
fill 8 55 -369 71 55 -369 minecraft:stone
fill 8 55 -368 71 55 -368 minecraft:stone
fill 8 55 -367 71 55 -367 minecraft:stone
fill 8 55 -366 71 55 -366 minecraft:stone
fill 8 55 -365 71 55 -365 minecraft:stone
fill 8 55 -364 71 55 -364 minecraft:stone
fill 8 55 -363 71 55 -363 minecraft:stone
fill 8 55 -362 71 55 -362 minecraft:stone
fill 8 55 -361 71 55 -361 minecraft:stone
fill 8 55 -360 71 55 -360 minecraft:stone
fill 8 55 -359 71 55 -359 minecraft:stone
fill 8 55 -358 71 55 -358 minecraft:stone
fill 8 55 -357 71 55 -357 minecraft:stone
fill 8 55 -356 71 55 -356 minecraft:stone
fill 8 55 -355 71 55 -355 minecraft:stone
fill 8 55 -354 66 55 -354 minecraft:stone
fill 8 55 -353 65 55 -353 minecraft:stone
fill 8 55 -352 65 55 -352 minecraft:stone
fill 8 55 -351 63 55 -351 minecraft:stone
fill 8 55 -350 61 55 -350 minecraft:stone
fill 8 55 -349 60 55 -349 minecraft:stone
fill 8 55 -348 60 55 -348 minecraft:stone
fill 8 55 -347 60 55 -347 minecraft:stone
fill 8 55 -346 17 55 -346 minecraft:stone
fill 26 55 -346 60 55 -346 minecraft:stone
fill 8 55 -345 16 55 -345 minecraft:stone
fill 27 55 -345 60 55 -345 minecraft:stone
fill 9 55 -344 16 55 -344 minecraft:stone
fill 27 55 -344 60 55 -344 minecraft:stone
fill 28 55 -343 34 55 -343 minecraft:stone
fill 46 55 -343 58 55 -343 minecraft:stone
fill 28 55 -342 33 55 -342 minecraft:stone
fill 47 55 -342 57 55 -342 minecraft:stone
fill 28 55 -341 32 55 -341 minecraft:stone
fill 47 55 -341 57 55 -341 minecraft:stone
fill 29 55 -340 32 55 -340 minecraft:stone
fill 48 55 -340 56 55 -340 minecraft:stone
fill 31 55 -339 32 55 -339 minecraft:stone
fill 33 55 -329 35 55 -329 minecraft:stone
fill 30 55 -328 39 55 -328 minecraft:stone
fill 29 55 -327 40 55 -327 minecraft:stone
fill 27 55 -326 41 55 -326 minecraft:stone
fill 26 55 -325 42 55 -325 minecraft:stone
fill 17 55 -324 20 55 -324 minecraft:stone
fill 26 55 -324 33 55 -324 minecraft:stone
fill 36 55 -324 43 55 -324 minecraft:stone
fill 16 55 -323 21 55 -323 minecraft:stone
fill 25 55 -323 31 55 -323 minecraft:stone
fill 38 55 -323 43 55 -323 minecraft:stone
fill 15 55 -322 22 55 -322 minecraft:stone
fill 24 55 -322 29 55 -322 minecraft:stone
fill 39 55 -322 45 55 -322 minecraft:stone
fill 15 55 -321 28 55 -321 minecraft:stone
fill 40 55 -321 44 55 -321 minecraft:stone
fill 15 55 -320 27 55 -320 minecraft:stone
fill 40 55 -320 44 55 -320 minecraft:stone
fill 16 55 -319 27 55 -319 minecraft:stone
fill 41 55 -319 45 55 -319 minecraft:stone
fill 8 56 -382 71 56 -382 minecraft:stone
fill 8 56 -381 71 56 -381 minecraft:stone
fill 8 56 -380 71 56 -380 minecraft:stone
fill 8 56 -379 71 56 -379 minecraft:stone
fill 8 56 -378 71 56 -378 minecraft:stone
fill 8 56 -377 71 56 -377 minecraft:stone
fill 8 56 -376 71 56 -376 minecraft:stone
fill 8 56 -375 71 56 -375 minecraft:stone
fill 8 56 -374 71 56 -374 minecraft:stone
fill 8 56 -373 71 56 -373 minecraft:stone
fill 8 56 -372 71 56 -372 minecraft:stone
fill 8 56 -371 71 56 -371 minecraft:stone
fill 8 56 -370 71 56 -370 minecraft:stone
fill 8 56 -369 71 56 -369 minecraft:stone
fill 8 56 -368 71 56 -368 minecraft:stone
fill 8 56 -367 71 56 -367 minecraft:stone
fill 8 56 -366 71 56 -366 minecraft:stone
fill 8 56 -365 71 56 -365 minecraft:stone
fill 8 56 -364 71 56 -364 minecraft:stone
fill 8 56 -363 71 56 -363 minecraft:stone
fill 8 56 -362 71 56 -362 minecraft:stone
fill 8 56 -361 71 56 -361 minecraft:stone
fill 8 56 -360 71 56 -360 minecraft:stone
fill 8 56 -359 71 56 -359 minecraft:stone
fill 8 56 -358 71 56 -358 minecraft:stone
fill 8 56 -357 71 56 -357 minecraft:stone
fill 8 56 -356 71 56 -356 minecraft:stone
fill 8 56 -355 71 56 -355 minecraft:stone
fill 8 56 -354 66 56 -354 minecraft:stone
setblock 71 56 -354 minecraft:stone
fill 8 56 -353 65 56 -353 minecraft:stone
fill 8 56 -352 65 56 -352 minecraft:stone
fill 8 56 -351 63 56 -351 minecraft:stone
fill 8 56 -350 61 56 -350 minecraft:stone
fill 8 56 -349 60 56 -349 minecraft:stone
fill 8 56 -348 60 56 -348 minecraft:stone
fill 8 56 -347 60 56 -347 minecraft:stone
fill 8 56 -346 20 56 -346 minecraft:stone
fill 26 56 -346 60 56 -346 minecraft:stone
fill 8 56 -345 18 56 -345 minecraft:stone
fill 27 56 -345 60 56 -345 minecraft:stone
fill 8 56 -344 17 56 -344 minecraft:stone
fill 27 56 -344 60 56 -344 minecraft:stone
fill 27 56 -343 34 56 -343 minecraft:stone
fill 45 56 -343 58 56 -343 minecraft:stone
fill 27 56 -342 33 56 -342 minecraft:stone
fill 47 56 -342 57 56 -342 minecraft:stone
fill 27 56 -341 32 56 -341 minecraft:stone
fill 49 56 -341 57 56 -341 minecraft:stone
fill 28 56 -340 32 56 -340 minecraft:stone
fill 49 56 -340 56 56 -340 minecraft:stone
fill 29 56 -339 32 56 -339 minecraft:stone
fill 33 56 -329 35 56 -329 minecraft:stone
fill 31 56 -328 39 56 -328 minecraft:stone
fill 29 56 -327 40 56 -327 minecraft:stone
fill 28 56 -326 41 56 -326 minecraft:stone
fill 27 56 -325 42 56 -325 minecraft:stone
fill 18 56 -324 20 56 -324 minecraft:stone
fill 27 56 -324 33 56 -324 minecraft:stone
fill 36 56 -324 43 56 -324 minecraft:stone
fill 16 56 -323 21 56 -323 minecraft:stone
fill 25 56 -323 30 56 -323 minecraft:stone
fill 38 56 -323 46 56 -323 minecraft:stone
fill 16 56 -322 22 56 -322 minecraft:stone
fill 25 56 -322 28 56 -322 minecraft:stone
fill 39 56 -322 44 56 -322 minecraft:stone
fill 16 56 -321 28 56 -321 minecraft:stone
fill 40 56 -321 44 56 -321 minecraft:stone
setblock 48 56 -321 minecraft:stone
fill 16 56 -320 26 56 -320 minecraft:stone
fill 40 56 -320 44 56 -320 minecraft:stone
fill 46 56 -320 47 56 -320 minecraft:stone
fill 16 56 -319 26 56 -319 minecraft:stone
fill 40 56 -319 45 56 -319 minecraft:stone
fill 8 57 -382 71 57 -382 minecraft:stone
fill 8 57 -381 71 57 -381 minecraft:stone
fill 8 57 -380 71 57 -380 minecraft:stone
fill 8 57 -379 71 57 -379 minecraft:stone
fill 8 57 -378 71 57 -378 minecraft:stone
fill 8 57 -377 71 57 -377 minecraft:stone
fill 8 57 -376 71 57 -376 minecraft:stone
fill 8 57 -375 71 57 -375 minecraft:stone
fill 8 57 -374 71 57 -374 minecraft:stone
fill 8 57 -373 71 57 -373 minecraft:stone
fill 8 57 -372 71 57 -372 minecraft:stone
fill 8 57 -371 71 57 -371 minecraft:stone
fill 8 57 -370 71 57 -370 minecraft:stone
fill 8 57 -369 71 57 -369 minecraft:stone
fill 8 57 -368 71 57 -368 minecraft:stone
fill 8 57 -367 71 57 -367 minecraft:stone
fill 8 57 -366 71 57 -366 minecraft:stone
fill 8 57 -365 71 57 -365 minecraft:stone
fill 8 57 -364 71 57 -364 minecraft:stone
fill 8 57 -363 71 57 -363 minecraft:stone
fill 8 57 -362 71 57 -362 minecraft:stone
fill 8 57 -361 71 57 -361 minecraft:stone
fill 8 57 -360 71 57 -360 minecraft:stone
fill 8 57 -359 71 57 -359 minecraft:stone
fill 8 57 -358 71 57 -358 minecraft:stone
fill 8 57 -357 71 57 -357 minecraft:stone
fill 8 57 -356 71 57 -356 minecraft:stone
fill 8 57 -355 71 57 -355 minecraft:stone
fill 8 57 -354 67 57 -354 minecraft:stone
fill 70 57 -354 71 57 -354 minecraft:stone
fill 8 57 -353 66 57 -353 minecraft:stone
fill 8 57 -352 65 57 -352 minecraft:stone
fill 8 57 -351 63 57 -351 minecraft:stone
fill 8 57 -350 61 57 -350 minecraft:stone
fill 8 57 -349 61 57 -349 minecraft:stone
fill 8 57 -348 60 57 -348 minecraft:stone
fill 8 57 -347 60 57 -347 minecraft:stone
fill 8 57 -346 22 57 -346 minecraft:stone
fill 25 57 -346 60 57 -346 minecraft:stone
fill 8 57 -345 19 57 -345 minecraft:stone
fill 26 57 -345 60 57 -345 minecraft:stone
fill 8 57 -344 18 57 -344 minecraft:stone
fill 27 57 -344 60 57 -344 minecraft:stone
setblock 8 57 -343 minecraft:stone
setblock 16 57 -343 minecraft:stone
fill 27 57 -343 35 57 -343 minecraft:stone
setblock 45 57 -343 minecraft:stone
fill 48 57 -343 59 57 -343 minecraft:stone
fill 27 57 -342 33 57 -342 minecraft:stone
fill 49 57 -342 57 57 -342 minecraft:stone
fill 27 57 -341 33 57 -341 minecraft:stone
fill 50 57 -341 57 57 -341 minecraft:stone
fill 27 57 -340 32 57 -340 minecraft:stone
fill 50 57 -340 57 57 -340 minecraft:stone
fill 28 57 -339 32 57 -339 minecraft:stone
setblock 54 57 -336 minecraft:stone
fill 52 57 -335 55 57 -335 minecraft:stone
fill 52 57 -334 55 57 -334 minecraft:stone
fill 51 57 -333 55 57 -333 minecraft:stone
fill 51 57 -332 54 57 -332 minecraft:stone
fill 51 57 -331 53 57 -331 minecraft:stone
fill 32 57 -328 38 57 -328 minecraft:stone
fill 30 57 -327 40 57 -327 minecraft:stone
fill 46 57 -327 47 57 -327 minecraft:stone
fill 29 57 -326 41 57 -326 minecraft:stone
fill 45 57 -326 48 57 -326 minecraft:stone
fill 29 57 -325 42 57 -325 minecraft:stone
fill 45 57 -325 48 57 -325 minecraft:stone
fill 28 57 -324 31 57 -324 minecraft:stone
fill 37 57 -324 47 57 -324 minecraft:stone
fill 18 57 -323 21 57 -323 minecraft:stone
fill 38 57 -323 46 57 -323 minecraft:stone
fill 17 57 -322 22 57 -322 minecraft:stone
fill 39 57 -322 45 57 -322 minecraft:stone
fill 16 57 -321 23 57 -321 minecraft:stone
fill 40 57 -321 44 57 -321 minecraft:stone
fill 48 57 -321 49 57 -321 minecraft:stone
fill 16 57 -320 24 57 -320 minecraft:stone
fill 40 57 -320 44 57 -320 minecraft:stone
fill 46 57 -320 49 57 -320 minecraft:stone
fill 17 57 -319 24 57 -319 minecraft:stone
fill 41 57 -319 45 57 -319 minecraft:stone
fill 47 57 -319 48 57 -319 minecraft:stone
fill 8 58 -382 71 58 -382 minecraft:stone
fill 8 58 -381 71 58 -381 minecraft:stone
fill 8 58 -380 71 58 -380 minecraft:stone
fill 8 58 -379 71 58 -379 minecraft:stone
fill 8 58 -378 71 58 -378 minecraft:stone
fill 8 58 -377 71 58 -377 minecraft:stone
fill 8 58 -376 71 58 -376 minecraft:stone
fill 8 58 -375 71 58 -375 minecraft:stone
fill 8 58 -374 71 58 -374 minecraft:stone
fill 8 58 -373 71 58 -373 minecraft:stone
fill 8 58 -372 71 58 -372 minecraft:stone
fill 8 58 -371 71 58 -371 minecraft:stone
fill 8 58 -370 71 58 -370 minecraft:stone
fill 8 58 -369 71 58 -369 minecraft:stone
fill 8 58 -368 71 58 -368 minecraft:stone
fill 8 58 -367 71 58 -367 minecraft:stone
fill 8 58 -366 71 58 -366 minecraft:stone
fill 8 58 -365 71 58 -365 minecraft:stone
fill 8 58 -364 71 58 -364 minecraft:stone
fill 8 58 -363 71 58 -363 minecraft:stone
fill 8 58 -362 71 58 -362 minecraft:stone
fill 8 58 -361 71 58 -361 minecraft:stone
fill 8 58 -360 71 58 -360 minecraft:stone
fill 8 58 -359 71 58 -359 minecraft:stone
fill 8 58 -358 71 58 -358 minecraft:stone
fill 8 58 -357 71 58 -357 minecraft:stone
fill 8 58 -356 71 58 -356 minecraft:stone
fill 8 58 -355 71 58 -355 minecraft:stone
fill 8 58 -354 67 58 -354 minecraft:stone
fill 69 58 -354 71 58 -354 minecraft:stone
fill 8 58 -353 66 58 -353 minecraft:stone
fill 8 58 -352 65 58 -352 minecraft:stone
fill 8 58 -351 64 58 -351 minecraft:stone
fill 8 58 -350 62 58 -350 minecraft:stone
fill 8 58 -349 61 58 -349 minecraft:stone
fill 8 58 -348 61 58 -348 minecraft:stone
fill 8 58 -347 61 58 -347 minecraft:stone
fill 8 58 -346 60 58 -346 minecraft:stone
fill 8 58 -345 20 58 -345 minecraft:stone
fill 26 58 -345 60 58 -345 minecraft:stone
fill 8 58 -344 18 58 -344 minecraft:stone
fill 26 58 -344 45 58 -344 minecraft:stone
fill 47 58 -344 60 58 -344 minecraft:stone
fill 8 58 -343 9 58 -343 minecraft:stone
fill 16 58 -343 17 58 -343 minecraft:stone
fill 26 58 -343 39 58 -343 minecraft:stone
fill 41 58 -343 45 58 -343 minecraft:stone
fill 49 58 -343 60 58 -343 minecraft:stone
setblock 8 58 -342 minecraft:stone
fill 27 58 -342 34 58 -342 minecraft:stone
fill 50 58 -342 58 58 -342 minecraft:stone
fill 27 58 -341 33 58 -341 minecraft:stone
fill 50 58 -341 57 58 -341 minecraft:stone
fill 27 58 -340 33 58 -340 minecraft:stone
fill 50 58 -340 57 58 -340 minecraft:stone
fill 28 58 -339 32 58 -339 minecraft:stone
fill 50 58 -339 56 58 -339 minecraft:stone
setblock 32 58 -338 minecraft:stone
setblock 54 58 -336 minecraft:stone
fill 52 58 -335 55 58 -335 minecraft:stone
fill 51 58 -334 55 58 -334 minecraft:stone
fill 50 58 -333 55 58 -333 minecraft:stone
fill 49 58 -332 54 58 -332 minecraft:stone
fill 48 58 -331 55 58 -331 minecraft:stone
fill 47 58 -330 52 58 -330 minecraft:stone
fill 54 58 -330 56 58 -330 minecraft:stone
fill 47 58 -329 51 58 -329 minecraft:stone
fill 55 58 -329 56 58 -329 minecraft:stone
fill 46 58 -328 50 58 -328 minecraft:stone
fill 45 58 -327 49 58 -327 minecraft:stone
fill 37 58 -326 39 58 -326 minecraft:stone
fill 45 58 -326 49 58 -326 minecraft:stone
fill 38 58 -325 41 58 -325 minecraft:stone
fill 44 58 -325 49 58 -325 minecraft:stone
fill 39 58 -324 42 58 -324 minecraft:stone
fill 44 58 -324 48 58 -324 minecraft:stone
fill 55 58 -324 57 58 -324 minecraft:stone
fill 40 58 -323 47 58 -323 minecraft:stone
fill 55 58 -323 57 58 -323 minecraft:stone
fill 18 58 -322 22 58 -322 minecraft:stone
fill 40 58 -322 45 58 -322 minecraft:stone
fill 55 58 -322 57 58 -322 minecraft:stone
fill 17 58 -321 23 58 -321 minecraft:stone
fill 41 58 -321 45 58 -321 minecraft:stone
fill 50 58 -321 51 58 -321 minecraft:stone
fill 55 58 -321 57 58 -321 minecraft:stone
fill 17 58 -320 24 58 -320 minecraft:stone
fill 41 58 -320 45 58 -320 minecraft:stone
fill 48 58 -320 50 58 -320 minecraft:stone
fill 17 58 -319 24 58 -319 minecraft:stone
fill 41 58 -319 44 58 -319 minecraft:stone
fill 47 58 -319 49 58 -319 minecraft:stone
fill 56 58 -319 57 58 -319 minecraft:stone
fill 8 59 -382 71 59 -382 minecraft:stone
fill 8 59 -381 71 59 -381 minecraft:stone
fill 8 59 -380 71 59 -380 minecraft:stone
fill 8 59 -379 71 59 -379 minecraft:stone
fill 8 59 -378 71 59 -378 minecraft:stone
fill 8 59 -377 71 59 -377 minecraft:stone
fill 8 59 -376 71 59 -376 minecraft:stone
fill 8 59 -375 71 59 -375 minecraft:stone
fill 8 59 -374 71 59 -374 minecraft:stone
fill 8 59 -373 71 59 -373 minecraft:stone
fill 8 59 -372 71 59 -372 minecraft:stone
fill 8 59 -371 71 59 -371 minecraft:stone
fill 8 59 -370 71 59 -370 minecraft:stone
fill 8 59 -369 71 59 -369 minecraft:stone
fill 8 59 -368 71 59 -368 minecraft:stone
fill 8 59 -367 71 59 -367 minecraft:stone
fill 8 59 -366 71 59 -366 minecraft:stone
fill 8 59 -365 71 59 -365 minecraft:stone
fill 8 59 -364 71 59 -364 minecraft:stone
fill 8 59 -363 71 59 -363 minecraft:stone
fill 8 59 -362 71 59 -362 minecraft:stone
fill 8 59 -361 71 59 -361 minecraft:stone
fill 8 59 -360 71 59 -360 minecraft:stone
fill 8 59 -359 71 59 -359 minecraft:stone
fill 8 59 -358 71 59 -358 minecraft:stone
fill 8 59 -357 71 59 -357 minecraft:stone
fill 8 59 -356 71 59 -356 minecraft:stone
fill 8 59 -355 71 59 -355 minecraft:stone
fill 8 59 -354 71 59 -354 minecraft:stone
fill 8 59 -353 66 59 -353 minecraft:stone
setblock 71 59 -353 minecraft:stone
fill 8 59 -352 66 59 -352 minecraft:stone
fill 8 59 -351 64 59 -351 minecraft:stone
fill 8 59 -350 62 59 -350 minecraft:stone
fill 8 59 -349 61 59 -349 minecraft:stone
fill 8 59 -348 61 59 -348 minecraft:stone
fill 8 59 -347 61 59 -347 minecraft:stone
fill 8 59 -346 61 59 -346 minecraft:stone
fill 8 59 -345 22 59 -345 minecraft:stone
fill 25 59 -345 61 59 -345 minecraft:stone
fill 8 59 -344 19 59 -344 minecraft:stone
fill 26 59 -344 45 59 -344 minecraft:stone
setblock 48 59 -344 minecraft:stone
fill 50 59 -344 61 59 -344 minecraft:stone
fill 8 59 -343 9 59 -343 minecraft:stone
fill 15 59 -343 17 59 -343 minecraft:stone
fill 26 59 -343 44 59 -343 minecraft:stone
fill 50 59 -343 60 59 -343 minecraft:stone
setblock 8 59 -342 minecraft:stone
fill 26 59 -342 34 59 -342 minecraft:stone
fill 50 59 -342 58 59 -342 minecraft:stone
fill 26 59 -341 33 59 -341 minecraft:stone
fill 50 59 -341 58 59 -341 minecraft:stone
fill 27 59 -340 33 59 -340 minecraft:stone
fill 51 59 -340 57 59 -340 minecraft:stone
fill 27 59 -339 32 59 -339 minecraft:stone
fill 50 59 -339 56 59 -339 minecraft:stone
fill 30 59 -338 32 59 -338 minecraft:stone
setblock 54 59 -335 minecraft:stone
fill 52 59 -334 55 59 -334 minecraft:stone
fill 50 59 -333 54 59 -333 minecraft:stone
fill 48 59 -332 55 59 -332 minecraft:stone
fill 48 59 -331 56 59 -331 minecraft:stone
fill 47 59 -330 56 59 -330 minecraft:stone
fill 46 59 -329 51 59 -329 minecraft:stone
fill 54 59 -329 56 59 -329 minecraft:stone
fill 46 59 -328 50 59 -328 minecraft:stone
fill 55 59 -328 57 59 -328 minecraft:stone
fill 45 59 -327 50 59 -327 minecraft:stone
fill 55 59 -327 57 59 -327 minecraft:stone
fill 45 59 -326 49 59 -326 minecraft:stone
setblock 55 59 -326 minecraft:stone
fill 45 59 -325 49 59 -325 minecraft:stone
fill 44 59 -324 50 59 -324 minecraft:stone
fill 44 59 -323 50 59 -323 minecraft:stone
fill 56 59 -323 57 59 -323 minecraft:stone
setblock 20 59 -322 minecraft:stone
fill 43 59 -322 48 59 -322 minecraft:stone
fill 55 59 -322 58 59 -322 minecraft:stone
fill 18 59 -321 22 59 -321 minecraft:stone
fill 42 59 -321 46 59 -321 minecraft:stone
setblock 52 59 -321 minecraft:stone
fill 55 59 -321 58 59 -321 minecraft:stone
fill 18 59 -320 24 59 -320 minecraft:stone
fill 39 59 -320 45 59 -320 minecraft:stone
fill 50 59 -320 51 59 -320 minecraft:stone
fill 55 59 -320 57 59 -320 minecraft:stone
fill 18 59 -319 24 59 -319 minecraft:stone
fill 42 59 -319 44 59 -319 minecraft:stone
fill 55 59 -319 58 59 -319 minecraft:stone
fill 8 60 -382 71 60 -382 minecraft:stone
fill 8 60 -381 71 60 -381 minecraft:stone
fill 8 60 -380 71 60 -380 minecraft:stone
fill 8 60 -379 71 60 -379 minecraft:stone
fill 8 60 -378 71 60 -378 minecraft:stone
fill 8 60 -377 71 60 -377 minecraft:stone
fill 8 60 -376 71 60 -376 minecraft:stone
fill 8 60 -375 71 60 -375 minecraft:stone
fill 8 60 -374 71 60 -374 minecraft:stone
fill 8 60 -373 71 60 -373 minecraft:stone
fill 8 60 -372 71 60 -372 minecraft:stone
fill 8 60 -371 71 60 -371 minecraft:stone
fill 8 60 -370 71 60 -370 minecraft:stone
fill 8 60 -369 71 60 -369 minecraft:stone
fill 8 60 -368 71 60 -368 minecraft:stone
fill 8 60 -367 71 60 -367 minecraft:stone
fill 8 60 -366 71 60 -366 minecraft:stone
fill 8 60 -365 71 60 -365 minecraft:stone
fill 8 60 -364 71 60 -364 minecraft:stone
fill 8 60 -363 71 60 -363 minecraft:stone
fill 8 60 -362 71 60 -362 minecraft:stone
fill 8 60 -361 71 60 -361 minecraft:stone
fill 8 60 -360 71 60 -360 minecraft:stone
fill 8 60 -359 71 60 -359 minecraft:stone
fill 8 60 -358 71 60 -358 minecraft:stone
fill 8 60 -357 71 60 -357 minecraft:stone
fill 8 60 -356 71 60 -356 minecraft:stone
fill 8 60 -355 71 60 -355 minecraft:stone
fill 8 60 -354 71 60 -354 minecraft:stone
fill 8 60 -353 67 60 -353 minecraft:stone
fill 69 60 -353 71 60 -353 minecraft:stone
fill 8 60 -352 66 60 -352 minecraft:stone
setblock 71 60 -352 minecraft:stone
fill 8 60 -351 65 60 -351 minecraft:stone
fill 8 60 -350 63 60 -350 minecraft:stone
fill 8 60 -349 62 60 -349 minecraft:stone
fill 8 60 -348 61 60 -348 minecraft:stone
fill 8 60 -347 61 60 -347 minecraft:stone
fill 8 60 -346 61 60 -346 minecraft:stone
fill 8 60 -345 61 60 -345 minecraft:stone
fill 8 60 -344 20 60 -344 minecraft:stone
fill 25 60 -344 48 60 -344 minecraft:stone
fill 50 60 -344 61 60 -344 minecraft:stone
fill 8 60 -343 11 60 -343 minecraft:stone
fill 13 60 -343 18 60 -343 minecraft:stone
fill 26 60 -343 44 60 -343 minecraft:stone
fill 50 60 -343 60 60 -343 minecraft:stone
setblock 8 60 -342 minecraft:stone
fill 26 60 -342 35 60 -342 minecraft:stone
fill 50 60 -342 59 60 -342 minecraft:stone
setblock 8 60 -341 minecraft:stone
fill 26 60 -341 34 60 -341 minecraft:stone
fill 50 60 -341 58 60 -341 minecraft:stone
fill 26 60 -340 33 60 -340 minecraft:stone
fill 51 60 -340 57 60 -340 minecraft:stone
fill 27 60 -339 33 60 -339 minecraft:stone
fill 50 60 -339 57 60 -339 minecraft:stone
fill 28 60 -338 32 60 -338 minecraft:stone
fill 49 60 -332 52 60 -332 minecraft:stone
fill 54 60 -332 55 60 -332 minecraft:stone
fill 48 60 -331 56 60 -331 minecraft:stone
fill 47 60 -330 51 60 -330 minecraft:stone
fill 54 60 -330 56 60 -330 minecraft:stone
fill 47 60 -329 50 60 -329 minecraft:stone
fill 54 60 -329 56 60 -329 minecraft:stone
fill 46 60 -328 50 60 -328 minecraft:stone
fill 55 60 -328 57 60 -328 minecraft:stone
fill 46 60 -327 49 60 -327 minecraft:stone
fill 55 60 -327 57 60 -327 minecraft:stone
fill 46 60 -326 49 60 -326 minecraft:stone
setblock 56 60 -326 minecraft:stone
fill 46 60 -325 48 60 -325 minecraft:stone
setblock 56 60 -325 minecraft:stone
fill 46 60 -324 52 60 -324 minecraft:stone
fill 45 60 -323 52 60 -323 minecraft:stone
fill 44 60 -322 50 60 -322 minecraft:stone
fill 56 60 -322 57 60 -322 minecraft:stone
fill 42 60 -321 49 60 -321 minecraft:stone
fill 54 60 -321 57 60 -321 minecraft:stone
fill 20 60 -320 23 60 -320 minecraft:stone
fill 38 60 -320 47 60 -320 minecraft:stone
fill 56 60 -320 57 60 -320 minecraft:stone
fill 19 60 -319 24 60 -319 minecraft:stone
fill 44 60 -319 45 60 -319 minecraft:stone
setblock 51 60 -319 minecraft:stone
fill 55 60 -319 58 60 -319 minecraft:stone
fill 8 61 -382 71 61 -382 minecraft:stone
fill 8 61 -381 71 61 -381 minecraft:stone
fill 8 61 -380 71 61 -380 minecraft:stone
fill 8 61 -379 71 61 -379 minecraft:stone
fill 8 61 -378 71 61 -378 minecraft:stone
fill 8 61 -377 71 61 -377 minecraft:stone
fill 8 61 -376 71 61 -376 minecraft:stone
fill 8 61 -375 71 61 -375 minecraft:stone
fill 8 61 -374 71 61 -374 minecraft:stone
fill 8 61 -373 71 61 -373 minecraft:stone
fill 8 61 -372 71 61 -372 minecraft:stone
fill 8 61 -371 71 61 -371 minecraft:stone
fill 8 61 -370 71 61 -370 minecraft:stone
fill 8 61 -369 71 61 -369 minecraft:stone
fill 8 61 -368 71 61 -368 minecraft:stone
fill 8 61 -367 71 61 -367 minecraft:stone
fill 8 61 -366 71 61 -366 minecraft:stone
fill 8 61 -365 71 61 -365 minecraft:stone
fill 8 61 -364 71 61 -364 minecraft:stone
fill 8 61 -363 71 61 -363 minecraft:stone
fill 8 61 -362 71 61 -362 minecraft:stone
fill 8 61 -361 71 61 -361 minecraft:stone
fill 8 61 -360 71 61 -360 minecraft:stone
fill 8 61 -359 71 61 -359 minecraft:stone
fill 8 61 -358 71 61 -358 minecraft:stone
fill 8 61 -357 71 61 -357 minecraft:stone
fill 8 61 -356 71 61 -356 minecraft:stone
fill 8 61 -355 71 61 -355 minecraft:stone
fill 8 61 -354 71 61 -354 minecraft:stone
fill 8 61 -353 71 61 -353 minecraft:stone
fill 8 61 -352 67 61 -352 minecraft:stone
fill 70 61 -352 71 61 -352 minecraft:stone
fill 8 61 -351 66 61 -351 minecraft:stone
setblock 71 61 -351 minecraft:stone
fill 8 61 -350 64 61 -350 minecraft:stone
setblock 71 61 -350 minecraft:stone
fill 8 61 -349 62 61 -349 minecraft:stone
fill 8 61 -348 62 61 -348 minecraft:stone
fill 8 61 -347 61 61 -347 minecraft:stone
fill 8 61 -346 61 61 -346 minecraft:stone
fill 8 61 -345 61 61 -345 minecraft:stone
fill 8 61 -344 23 61 -344 minecraft:stone
fill 25 61 -344 61 61 -344 minecraft:stone
fill 8 61 -343 19 61 -343 minecraft:stone
fill 25 61 -343 46 61 -343 minecraft:stone
fill 48 61 -343 61 61 -343 minecraft:stone
fill 8 61 -342 9 61 -342 minecraft:stone
fill 26 61 -342 37 61 -342 minecraft:stone
fill 44 61 -342 45 61 -342 minecraft:stone
fill 50 61 -342 60 61 -342 minecraft:stone
setblock 8 61 -341 minecraft:stone
fill 26 61 -341 34 61 -341 minecraft:stone
fill 50 61 -341 59 61 -341 minecraft:stone
setblock 8 61 -340 minecraft:stone
fill 26 61 -340 34 61 -340 minecraft:stone
fill 50 61 -340 58 61 -340 minecraft:stone
fill 27 61 -339 33 61 -339 minecraft:stone
fill 48 61 -339 57 61 -339 minecraft:stone
fill 28 61 -338 32 61 -338 minecraft:stone
fill 48 61 -338 56 61 -338 minecraft:stone
fill 70 61 -335 71 61 -335 minecraft:stone
fill 69 61 -334 71 61 -334 minecraft:stone
fill 69 61 -333 71 61 -333 minecraft:stone
fill 48 61 -324 54 61 -324 minecraft:stone
fill 47 61 -323 54 61 -323 minecraft:stone
fill 46 61 -322 53 61 -322 minecraft:stone
fill 46 61 -321 51 61 -321 minecraft:stone
fill 38 61 -320 44 61 -320 minecraft:stone
fill 46 61 -320 48 61 -320 minecraft:stone
fill 21 61 -319 24 61 -319 minecraft:stone
fill 55 61 -319 57 61 -319 minecraft:stone
fill 8 62 -382 71 62 -382 minecraft:dirt
fill 8 62 -381 71 62 -381 minecraft:dirt
fill 8 62 -380 71 62 -380 minecraft:dirt
fill 8 62 -379 71 62 -379 minecraft:dirt
fill 8 62 -378 71 62 -378 minecraft:dirt
fill 8 62 -377 71 62 -377 minecraft:dirt
fill 8 62 -376 71 62 -376 minecraft:dirt
fill 8 62 -375 71 62 -375 minecraft:dirt
fill 8 62 -374 71 62 -374 minecraft:dirt
fill 8 62 -373 71 62 -373 minecraft:dirt
fill 8 62 -372 71 62 -372 minecraft:dirt
fill 8 62 -371 71 62 -371 minecraft:dirt
fill 8 62 -370 71 62 -370 minecraft:dirt
fill 8 62 -369 71 62 -369 minecraft:dirt
fill 8 62 -368 71 62 -368 minecraft:dirt
fill 8 62 -367 71 62 -367 minecraft:dirt
fill 8 62 -366 71 62 -366 minecraft:dirt
fill 8 62 -365 71 62 -365 minecraft:dirt
fill 8 62 -364 71 62 -364 minecraft:dirt
fill 8 62 -363 71 62 -363 minecraft:dirt
fill 8 62 -362 71 62 -362 minecraft:dirt
fill 8 62 -361 71 62 -361 minecraft:dirt
fill 8 62 -360 71 62 -360 minecraft:dirt
fill 8 62 -359 71 62 -359 minecraft:dirt
fill 8 62 -358 71 62 -358 minecraft:dirt
fill 8 62 -357 71 62 -357 minecraft:dirt
fill 8 62 -356 71 62 -356 minecraft:dirt
fill 8 62 -355 71 62 -355 minecraft:dirt
fill 8 62 -354 71 62 -354 minecraft:dirt
fill 8 62 -353 71 62 -353 minecraft:dirt
fill 8 62 -352 67 62 -352 minecraft:dirt
fill 69 62 -352 71 62 -352 minecraft:dirt
fill 8 62 -351 67 62 -351 minecraft:dirt
fill 69 62 -351 71 62 -351 minecraft:dirt
fill 8 62 -350 66 62 -350 minecraft:dirt
fill 70 62 -350 71 62 -350 minecraft:dirt
fill 8 62 -349 63 62 -349 minecraft:dirt
fill 66 62 -349 68 62 -349 minecraft:dirt
fill 70 62 -349 71 62 -349 minecraft:dirt
fill 8 62 -348 62 62 -348 minecraft:dirt
fill 65 62 -348 68 62 -348 minecraft:dirt
setblock 71 62 -348 minecraft:dirt
fill 8 62 -347 62 62 -347 minecraft:dirt
fill 65 62 -347 68 62 -347 minecraft:dirt
fill 8 62 -346 62 62 -346 minecraft:dirt
fill 65 62 -346 68 62 -346 minecraft:dirt
fill 8 62 -345 62 62 -345 minecraft:dirt
fill 65 62 -345 68 62 -345 minecraft:dirt
fill 8 62 -344 62 62 -344 minecraft:dirt
fill 66 62 -344 68 62 -344 minecraft:dirt
fill 8 62 -343 22 62 -343 minecraft:dirt
fill 25 62 -343 61 62 -343 minecraft:dirt
fill 8 62 -342 10 62 -342 minecraft:dirt
setblock 16 62 -342 minecraft:dirt
fill 25 62 -342 46 62 -342 minecraft:dirt
fill 49 62 -342 61 62 -342 minecraft:dirt
fill 8 62 -341 9 62 -341 minecraft:dirt
fill 26 62 -341 35 62 -341 minecraft:dirt
fill 45 62 -341 59 62 -341 minecraft:dirt
setblock 8 62 -340 minecraft:dirt
fill 26 62 -340 34 62 -340 minecraft:dirt
fill 46 62 -340 59 62 -340 minecraft:dirt
fill 27 62 -339 33 62 -339 minecraft:dirt
fill 46 62 -339 57 62 -339 minecraft:dirt
fill 27 62 -338 33 62 -338 minecraft:dirt
fill 47 62 -338 57 62 -338 minecraft:dirt
fill 67 62 -336 68 62 -336 minecraft:dirt
fill 70 62 -336 71 62 -336 minecraft:dirt
fill 62 62 -335 63 62 -335 minecraft:dirt
fill 65 62 -335 71 62 -335 minecraft:dirt
fill 62 62 -334 63 62 -334 minecraft:dirt
fill 65 62 -334 71 62 -334 minecraft:dirt
fill 62 62 -333 71 62 -333 minecraft:dirt
fill 62 62 -332 64 62 -332 minecraft:dirt
fill 66 62 -332 71 62 -332 minecraft:dirt
fill 62 62 -331 65 62 -331 minecraft:dirt
fill 63 62 -330 66 62 -330 minecraft:dirt
fill 63 62 -329 67 62 -329 minecraft:dirt
setblock 71 62 -329 minecraft:dirt
fill 64 62 -328 71 62 -328 minecraft:dirt
fill 65 62 -327 71 62 -327 minecraft:dirt
fill 66 62 -326 71 62 -326 minecraft:dirt
fill 68 62 -325 70 62 -325 minecraft:dirt
fill 49 62 -324 56 62 -324 minecraft:dirt
fill 48 62 -323 57 62 -323 minecraft:dirt
fill 47 62 -322 55 62 -322 minecraft:dirt
fill 47 62 -321 53 62 -321 minecraft:dirt
setblock 38 62 -320 minecraft:dirt
setblock 48 62 -320 minecraft:dirt
setblock 37 62 -319 minecraft:dirt
setblock 42 62 -319 minecraft:dirt
setblock 51 62 -319 minecraft:dirt
fill 8 63 -382 71 63 -382 minecraft:dirt
fill 8 63 -381 71 63 -381 minecraft:dirt
fill 8 63 -380 71 63 -380 minecraft:dirt
fill 8 63 -379 71 63 -379 minecraft:dirt
fill 8 63 -378 71 63 -378 minecraft:dirt
fill 8 63 -377 71 63 -377 minecraft:dirt
fill 8 63 -376 71 63 -376 minecraft:dirt
fill 8 63 -375 71 63 -375 minecraft:dirt
fill 8 63 -374 71 63 -374 minecraft:dirt
fill 8 63 -373 71 63 -373 minecraft:dirt
fill 8 63 -372 71 63 -372 minecraft:dirt
fill 8 63 -371 71 63 -371 minecraft:dirt
fill 8 63 -370 71 63 -370 minecraft:dirt
fill 8 63 -369 71 63 -369 minecraft:dirt
fill 8 63 -368 71 63 -368 minecraft:dirt
fill 8 63 -367 71 63 -367 minecraft:dirt
fill 8 63 -366 71 63 -366 minecraft:dirt
fill 8 63 -365 71 63 -365 minecraft:dirt
fill 8 63 -364 71 63 -364 minecraft:dirt
fill 8 63 -363 71 63 -363 minecraft:dirt
fill 8 63 -362 71 63 -362 minecraft:dirt
fill 8 63 -361 71 63 -361 minecraft:dirt
fill 8 63 -360 71 63 -360 minecraft:dirt
fill 8 63 -359 71 63 -359 minecraft:dirt
fill 8 63 -358 71 63 -358 minecraft:dirt
fill 8 63 -357 71 63 -357 minecraft:dirt
fill 8 63 -356 71 63 -356 minecraft:dirt
fill 8 63 -355 71 63 -355 minecraft:dirt
fill 8 63 -354 71 63 -354 minecraft:dirt
fill 8 63 -353 71 63 -353 minecraft:dirt
fill 8 63 -352 71 63 -352 minecraft:dirt
fill 8 63 -351 71 63 -351 minecraft:dirt
fill 8 63 -350 67 63 -350 minecraft:dirt
fill 69 63 -350 71 63 -350 minecraft:dirt
fill 8 63 -349 71 63 -349 minecraft:dirt
fill 8 63 -348 68 63 -348 minecraft:dirt
fill 70 63 -348 71 63 -348 minecraft:dirt
fill 8 63 -347 71 63 -347 minecraft:dirt
fill 8 63 -346 68 63 -346 minecraft:dirt
fill 70 63 -346 71 63 -346 minecraft:dirt
fill 8 63 -345 63 63 -345 minecraft:dirt
fill 65 63 -345 68 63 -345 minecraft:dirt
fill 70 63 -345 71 63 -345 minecraft:dirt
fill 8 63 -344 63 63 -344 minecraft:dirt
fill 65 63 -344 68 63 -344 minecraft:dirt
fill 70 63 -344 71 63 -344 minecraft:dirt
fill 8 63 -343 63 63 -343 minecraft:dirt
fill 66 63 -343 71 63 -343 minecraft:dirt
fill 8 63 -342 17 63 -342 minecraft:dirt
fill 25 63 -342 62 63 -342 minecraft:dirt
fill 66 63 -342 69 63 -342 minecraft:dirt
setblock 71 63 -342 minecraft:dirt
fill 8 63 -341 10 63 -341 minecraft:dirt
fill 25 63 -341 39 63 -341 minecraft:dirt
fill 41 63 -341 63 63 -341 minecraft:dirt
fill 66 63 -341 69 63 -341 minecraft:dirt
fill 8 63 -340 9 63 -340 minecraft:dirt
fill 26 63 -340 35 63 -340 minecraft:dirt
fill 45 63 -340 60 63 -340 minecraft:dirt
fill 62 63 -340 63 63 -340 minecraft:dirt
fill 67 63 -340 69 63 -340 minecraft:dirt
fill 26 63 -339 34 63 -339 minecraft:dirt
fill 45 63 -339 57 63 -339 minecraft:dirt
setblock 59 63 -339 minecraft:dirt
fill 62 63 -339 63 63 -339 minecraft:dirt
fill 27 63 -338 33 63 -338 minecraft:dirt
fill 46 63 -338 59 63 -338 minecraft:dirt
fill 61 63 -338 64 63 -338 minecraft:dirt
fill 31 63 -337 32 63 -337 minecraft:dirt
fill 47 63 -337 59 63 -337 minecraft:dirt
fill 61 63 -337 64 63 -337 minecraft:dirt
fill 61 63 -336 71 63 -336 minecraft:dirt
fill 61 63 -335 71 63 -335 minecraft:dirt
fill 60 63 -334 71 63 -334 minecraft:dirt
fill 60 63 -333 71 63 -333 minecraft:dirt
fill 61 63 -332 71 63 -332 minecraft:dirt
fill 61 63 -331 65 63 -331 minecraft:dirt
fill 62 63 -330 66 63 -330 minecraft:dirt
setblock 71 63 -330 minecraft:dirt
fill 62 63 -329 68 63 -329 minecraft:dirt
fill 70 63 -329 71 63 -329 minecraft:dirt
fill 63 63 -328 71 63 -328 minecraft:dirt
fill 64 63 -327 71 63 -327 minecraft:dirt
fill 65 63 -326 71 63 -326 minecraft:dirt
fill 54 63 -325 56 63 -325 minecraft:dirt
fill 66 63 -325 71 63 -325 minecraft:dirt
fill 51 63 -324 58 63 -324 minecraft:dirt
fill 49 63 -323 58 63 -323 minecraft:dirt
fill 49 63 -322 58 63 -322 minecraft:dirt
fill 49 63 -321 57 63 -321 minecraft:dirt
fill 51 63 -320 56 63 -320 minecraft:dirt
setblock 36 63 -319 minecraft:dirt
fill 38 63 -319 40 63 -319 minecraft:dirt
fill 8 64 -382 71 64 -382 minecraft:dirt
fill 8 64 -381 71 64 -381 minecraft:dirt
fill 8 64 -380 71 64 -380 minecraft:dirt
fill 8 64 -379 71 64 -379 minecraft:dirt
fill 8 64 -378 71 64 -378 minecraft:dirt
fill 8 64 -377 71 64 -377 minecraft:dirt
fill 8 64 -376 71 64 -376 minecraft:dirt
fill 8 64 -375 71 64 -375 minecraft:dirt
fill 8 64 -374 71 64 -374 minecraft:dirt
fill 8 64 -373 71 64 -373 minecraft:dirt
fill 8 64 -372 71 64 -372 minecraft:dirt
fill 8 64 -371 71 64 -371 minecraft:dirt
fill 8 64 -370 71 64 -370 minecraft:dirt
fill 8 64 -369 71 64 -369 minecraft:dirt
fill 8 64 -368 71 64 -368 minecraft:dirt
fill 8 64 -367 71 64 -367 minecraft:dirt
fill 8 64 -366 71 64 -366 minecraft:dirt
fill 8 64 -365 71 64 -365 minecraft:dirt
fill 8 64 -364 71 64 -364 minecraft:dirt
fill 8 64 -363 71 64 -363 minecraft:dirt
fill 8 64 -362 71 64 -362 minecraft:dirt
fill 8 64 -361 71 64 -361 minecraft:dirt
fill 8 64 -360 71 64 -360 minecraft:dirt
fill 8 64 -359 71 64 -359 minecraft:dirt
fill 8 64 -358 71 64 -358 minecraft:dirt
fill 8 64 -357 71 64 -357 minecraft:dirt
fill 8 64 -356 71 64 -356 minecraft:dirt
fill 8 64 -355 71 64 -355 minecraft:dirt
fill 8 64 -354 71 64 -354 minecraft:dirt
fill 8 64 -353 71 64 -353 minecraft:dirt
fill 8 64 -352 71 64 -352 minecraft:dirt
fill 8 64 -351 71 64 -351 minecraft:dirt
fill 8 64 -350 71 64 -350 minecraft:dirt
fill 8 64 -349 71 64 -349 minecraft:dirt
fill 8 64 -348 71 64 -348 minecraft:dirt
fill 8 64 -347 71 64 -347 minecraft:dirt
fill 8 64 -346 71 64 -346 minecraft:dirt
fill 8 64 -345 71 64 -345 minecraft:dirt
fill 8 64 -344 71 64 -344 minecraft:dirt
fill 8 64 -343 71 64 -343 minecraft:dirt
fill 8 64 -342 18 64 -342 minecraft:dirt
fill 24 64 -342 71 64 -342 minecraft:dirt
fill 8 64 -341 11 64 -341 minecraft:dirt
fill 25 64 -341 71 64 -341 minecraft:dirt
fill 8 64 -340 10 64 -340 minecraft:dirt
fill 26 64 -340 39 64 -340 minecraft:dirt
fill 41 64 -340 71 64 -340 minecraft:dirt
setblock 8 64 -339 minecraft:dirt
fill 26 64 -339 38 64 -339 minecraft:dirt
fill 41 64 -339 71 64 -339 minecraft:dirt
fill 27 64 -338 35 64 -338 minecraft:dirt
fill 41 64 -338 71 64 -338 minecraft:dirt
fill 28 64 -337 29 64 -337 minecraft:dirt
fill 31 64 -337 34 64 -337 minecraft:dirt
fill 41 64 -337 71 64 -337 minecraft:dirt
fill 41 64 -336 47 64 -336 minecraft:dirt
fill 49 64 -336 71 64 -336 minecraft:dirt
fill 43 64 -335 71 64 -335 minecraft:dirt
fill 44 64 -334 71 64 -334 minecraft:dirt
fill 44 64 -333 51 64 -333 minecraft:dirt
fill 53 64 -333 71 64 -333 minecraft:dirt
fill 44 64 -332 71 64 -332 minecraft:dirt
fill 44 64 -331 55 64 -331 minecraft:dirt
fill 57 64 -331 71 64 -331 minecraft:dirt
fill 45 64 -330 71 64 -330 minecraft:dirt
fill 46 64 -329 71 64 -329 minecraft:dirt
fill 46 64 -328 71 64 -328 minecraft:dirt
fill 48 64 -327 71 64 -327 minecraft:dirt
fill 55 64 -326 71 64 -326 minecraft:dirt
fill 54 64 -325 58 64 -325 minecraft:dirt
fill 60 64 -325 71 64 -325 minecraft:dirt
fill 52 64 -324 59 64 -324 minecraft:dirt
fill 63 64 -324 71 64 -324 minecraft:dirt
fill 51 64 -323 59 64 -323 minecraft:dirt
fill 65 64 -323 70 64 -323 minecraft:dirt
fill 51 64 -322 59 64 -322 minecraft:dirt
fill 66 64 -322 69 64 -322 minecraft:dirt
fill 51 64 -321 58 64 -321 minecraft:dirt
fill 68 64 -321 71 64 -321 minecraft:dirt
fill 26 64 -320 30 64 -320 minecraft:dirt
fill 52 64 -320 56 64 -320 minecraft:dirt
setblock 70 64 -320 minecraft:dirt
fill 23 64 -319 26 64 -319 minecraft:dirt
fill 28 64 -319 33 64 -319 minecraft:dirt
fill 8 65 -382 12 65 -382 minecraft:light_gray_concrete
setblock 13 65 -382 minecraft:smooth_quartz
fill 14 65 -382 71 65 -382 minecraft:grass_block
fill 8 65 -381 11 65 -381 minecraft:light_gray_concrete
setblock 12 65 -381 minecraft:sea_lantern
setblock 13 65 -381 minecraft:smooth_quartz
fill 14 65 -381 71 65 -381 minecraft:grass_block
fill 8 65 -380 10 65 -380 minecraft:light_gray_concrete
setblock 11 65 -380 minecraft:sea_lantern
setblock 12 65 -380 minecraft:light_gray_concrete
setblock 13 65 -380 minecraft:smooth_quartz
fill 14 65 -380 71 65 -380 minecraft:grass_block
fill 8 65 -379 9 65 -379 minecraft:light_gray_concrete
setblock 10 65 -379 minecraft:sea_lantern
fill 11 65 -379 12 65 -379 minecraft:light_gray_concrete
setblock 13 65 -379 minecraft:smooth_quartz
fill 14 65 -379 71 65 -379 minecraft:grass_block
setblock 8 65 -378 minecraft:light_gray_concrete
setblock 9 65 -378 minecraft:sea_lantern
fill 10 65 -378 12 65 -378 minecraft:light_gray_concrete
setblock 13 65 -378 minecraft:smooth_quartz
fill 14 65 -378 71 65 -378 minecraft:grass_block
fill 8 65 -377 12 65 -377 minecraft:light_gray_concrete
setblock 13 65 -377 minecraft:smooth_quartz
fill 14 65 -377 71 65 -377 minecraft:grass_block
fill 8 65 -376 12 65 -376 minecraft:light_gray_concrete
setblock 13 65 -376 minecraft:smooth_quartz
fill 14 65 -376 71 65 -376 minecraft:grass_block
fill 8 65 -375 12 65 -375 minecraft:light_gray_concrete
setblock 13 65 -375 minecraft:smooth_quartz
fill 14 65 -375 71 65 -375 minecraft:grass_block
fill 8 65 -374 12 65 -374 minecraft:light_gray_concrete
setblock 13 65 -374 minecraft:smooth_quartz
fill 14 65 -374 71 65 -374 minecraft:grass_block
fill 8 65 -373 12 65 -373 minecraft:light_gray_concrete
setblock 13 65 -373 minecraft:smooth_quartz
fill 14 65 -373 71 65 -373 minecraft:grass_block
fill 8 65 -372 11 65 -372 minecraft:light_gray_concrete
setblock 12 65 -372 minecraft:sea_lantern
setblock 13 65 -372 minecraft:smooth_quartz
fill 14 65 -372 71 65 -372 minecraft:grass_block
fill 8 65 -371 10 65 -371 minecraft:light_gray_concrete
setblock 11 65 -371 minecraft:sea_lantern
setblock 12 65 -371 minecraft:light_gray_concrete
setblock 13 65 -371 minecraft:smooth_quartz
fill 14 65 -371 71 65 -371 minecraft:grass_block
fill 8 65 -370 9 65 -370 minecraft:light_gray_concrete
setblock 10 65 -370 minecraft:sea_lantern
fill 11 65 -370 12 65 -370 minecraft:light_gray_concrete
setblock 13 65 -370 minecraft:smooth_quartz
fill 14 65 -370 71 65 -370 minecraft:grass_block
setblock 8 65 -369 minecraft:light_gray_concrete
setblock 9 65 -369 minecraft:sea_lantern
fill 10 65 -369 12 65 -369 minecraft:light_gray_concrete
setblock 13 65 -369 minecraft:smooth_quartz
fill 14 65 -369 71 65 -369 minecraft:grass_block
fill 8 65 -368 12 65 -368 minecraft:light_gray_concrete
setblock 13 65 -368 minecraft:smooth_quartz
fill 14 65 -368 71 65 -368 minecraft:grass_block
fill 8 65 -367 12 65 -367 minecraft:light_gray_concrete
setblock 13 65 -367 minecraft:smooth_quartz
fill 14 65 -367 71 65 -367 minecraft:grass_block
fill 8 65 -366 12 65 -366 minecraft:light_gray_concrete
setblock 13 65 -366 minecraft:smooth_quartz
fill 14 65 -366 71 65 -366 minecraft:grass_block
fill 8 65 -365 12 65 -365 minecraft:light_gray_concrete
setblock 13 65 -365 minecraft:smooth_quartz
fill 14 65 -365 71 65 -365 minecraft:grass_block
fill 8 65 -364 12 65 -364 minecraft:light_gray_concrete
setblock 13 65 -364 minecraft:smooth_quartz
fill 14 65 -364 71 65 -364 minecraft:grass_block
fill 8 65 -363 11 65 -363 minecraft:light_gray_concrete
setblock 12 65 -363 minecraft:sea_lantern
setblock 13 65 -363 minecraft:smooth_quartz
fill 14 65 -363 71 65 -363 minecraft:grass_block
fill 8 65 -362 10 65 -362 minecraft:light_gray_concrete
setblock 11 65 -362 minecraft:sea_lantern
setblock 12 65 -362 minecraft:light_gray_concrete
setblock 13 65 -362 minecraft:smooth_quartz
fill 14 65 -362 71 65 -362 minecraft:grass_block
fill 8 65 -361 9 65 -361 minecraft:light_gray_concrete
setblock 10 65 -361 minecraft:sea_lantern
fill 11 65 -361 12 65 -361 minecraft:light_gray_concrete
setblock 13 65 -361 minecraft:smooth_quartz
fill 14 65 -361 71 65 -361 minecraft:grass_block
setblock 8 65 -360 minecraft:light_gray_concrete
setblock 9 65 -360 minecraft:sea_lantern
fill 10 65 -360 12 65 -360 minecraft:light_gray_concrete
setblock 13 65 -360 minecraft:smooth_quartz
fill 14 65 -360 71 65 -360 minecraft:grass_block
fill 8 65 -359 12 65 -359 minecraft:light_gray_concrete
setblock 13 65 -359 minecraft:smooth_quartz
fill 14 65 -359 71 65 -359 minecraft:grass_block
fill 8 65 -358 12 65 -358 minecraft:light_gray_concrete
setblock 13 65 -358 minecraft:smooth_quartz
fill 14 65 -358 71 65 -358 minecraft:grass_block
fill 8 65 -357 12 65 -357 minecraft:light_gray_concrete
setblock 13 65 -357 minecraft:smooth_quartz
fill 14 65 -357 71 65 -357 minecraft:grass_block
fill 8 65 -356 12 65 -356 minecraft:light_gray_concrete
setblock 13 65 -356 minecraft:smooth_quartz
fill 14 65 -356 71 65 -356 minecraft:grass_block
fill 8 65 -355 12 65 -355 minecraft:light_gray_concrete
setblock 13 65 -355 minecraft:smooth_quartz
fill 14 65 -355 71 65 -355 minecraft:grass_block
fill 8 65 -354 11 65 -354 minecraft:light_gray_concrete
setblock 12 65 -354 minecraft:sea_lantern
setblock 13 65 -354 minecraft:smooth_quartz
fill 14 65 -354 71 65 -354 minecraft:grass_block
fill 8 65 -353 10 65 -353 minecraft:light_gray_concrete
setblock 11 65 -353 minecraft:sea_lantern
setblock 12 65 -353 minecraft:light_gray_concrete
setblock 13 65 -353 minecraft:smooth_quartz
fill 14 65 -353 71 65 -353 minecraft:grass_block
fill 8 65 -352 9 65 -352 minecraft:light_gray_concrete
setblock 10 65 -352 minecraft:sea_lantern
fill 11 65 -352 12 65 -352 minecraft:light_gray_concrete
setblock 13 65 -352 minecraft:smooth_quartz
fill 14 65 -352 71 65 -352 minecraft:grass_block
setblock 8 65 -351 minecraft:light_gray_concrete
setblock 9 65 -351 minecraft:sea_lantern
fill 10 65 -351 12 65 -351 minecraft:light_gray_concrete
setblock 13 65 -351 minecraft:smooth_quartz
fill 14 65 -351 71 65 -351 minecraft:grass_block
fill 8 65 -350 12 65 -350 minecraft:light_gray_concrete
setblock 13 65 -350 minecraft:smooth_quartz
fill 14 65 -350 71 65 -350 minecraft:grass_block
fill 8 65 -349 12 65 -349 minecraft:light_gray_concrete
setblock 13 65 -349 minecraft:smooth_quartz
fill 14 65 -349 71 65 -349 minecraft:grass_block
fill 8 65 -348 12 65 -348 minecraft:light_gray_concrete
setblock 13 65 -348 minecraft:smooth_quartz
fill 14 65 -348 71 65 -348 minecraft:grass_block
fill 8 65 -347 12 65 -347 minecraft:light_gray_concrete
setblock 13 65 -347 minecraft:smooth_quartz
fill 14 65 -347 71 65 -347 minecraft:grass_block
fill 8 65 -346 12 65 -346 minecraft:light_gray_concrete
setblock 13 65 -346 minecraft:smooth_quartz
fill 14 65 -346 71 65 -346 minecraft:grass_block
fill 8 65 -345 11 65 -345 minecraft:light_gray_concrete
setblock 12 65 -345 minecraft:sea_lantern
setblock 13 65 -345 minecraft:smooth_quartz
fill 14 65 -345 71 65 -345 minecraft:grass_block
fill 8 65 -344 10 65 -344 minecraft:light_gray_concrete
setblock 11 65 -344 minecraft:sea_lantern
setblock 12 65 -344 minecraft:light_gray_concrete
setblock 13 65 -344 minecraft:smooth_quartz
fill 14 65 -344 71 65 -344 minecraft:grass_block
fill 8 65 -343 9 65 -343 minecraft:light_gray_concrete
setblock 10 65 -343 minecraft:sea_lantern
fill 11 65 -343 12 65 -343 minecraft:light_gray_concrete
setblock 13 65 -343 minecraft:smooth_quartz
fill 14 65 -343 71 65 -343 minecraft:grass_block
setblock 8 65 -342 minecraft:light_gray_concrete
setblock 9 65 -342 minecraft:sea_lantern
fill 10 65 -342 12 65 -342 minecraft:light_gray_concrete
setblock 13 65 -342 minecraft:smooth_quartz
fill 14 65 -342 71 65 -342 minecraft:grass_block
fill 8 65 -341 12 65 -341 minecraft:light_gray_concrete
setblock 13 65 -341 minecraft:smooth_quartz
fill 16 65 -341 22 65 -341 minecraft:grass_block
fill 25 65 -341 71 65 -341 minecraft:grass_block
fill 8 65 -340 12 65 -340 minecraft:light_gray_concrete
setblock 13 65 -340 minecraft:smooth_quartz
fill 14 65 -340 71 65 -340 minecraft:grass_block
fill 8 65 -339 12 65 -339 minecraft:light_gray_concrete
setblock 13 65 -339 minecraft:smooth_quartz
fill 14 65 -339 24 65 -339 minecraft:grass_block
fill 26 65 -339 71 65 -339 minecraft:grass_block
fill 8 65 -338 12 65 -338 minecraft:light_gray_concrete
setblock 13 65 -338 minecraft:smooth_quartz
fill 14 65 -338 24 65 -338 minecraft:grass_block
fill 26 65 -338 71 65 -338 minecraft:grass_block
fill 8 65 -337 12 65 -337 minecraft:light_gray_concrete
setblock 13 65 -337 minecraft:smooth_quartz
fill 14 65 -337 25 65 -337 minecraft:grass_block
fill 27 65 -337 71 65 -337 minecraft:grass_block
fill 8 65 -336 11 65 -336 minecraft:light_gray_concrete
setblock 12 65 -336 minecraft:sea_lantern
setblock 13 65 -336 minecraft:smooth_quartz
fill 14 65 -336 32 65 -336 minecraft:grass_block
fill 37 65 -336 71 65 -336 minecraft:grass_block
fill 8 65 -335 10 65 -335 minecraft:light_gray_concrete
setblock 11 65 -335 minecraft:sea_lantern
setblock 12 65 -335 minecraft:light_gray_concrete
setblock 13 65 -335 minecraft:smooth_quartz
fill 14 65 -335 33 65 -335 minecraft:grass_block
fill 39 65 -335 71 65 -335 minecraft:grass_block
fill 8 65 -334 9 65 -334 minecraft:light_gray_concrete
setblock 10 65 -334 minecraft:sea_lantern
fill 11 65 -334 12 65 -334 minecraft:light_gray_concrete
setblock 13 65 -334 minecraft:smooth_quartz
fill 14 65 -334 36 65 -334 minecraft:grass_block
fill 41 65 -334 71 65 -334 minecraft:grass_block
setblock 8 65 -333 minecraft:light_gray_concrete
setblock 9 65 -333 minecraft:sea_lantern
fill 10 65 -333 12 65 -333 minecraft:light_gray_concrete
setblock 13 65 -333 minecraft:smooth_quartz
fill 14 65 -333 38 65 -333 minecraft:grass_block
fill 42 65 -333 71 65 -333 minecraft:grass_block
fill 8 65 -332 12 65 -332 minecraft:light_gray_concrete
setblock 13 65 -332 minecraft:smooth_quartz
fill 14 65 -332 39 65 -332 minecraft:grass_block
fill 42 65 -332 71 65 -332 minecraft:grass_block
fill 8 65 -331 12 65 -331 minecraft:light_gray_concrete
setblock 13 65 -331 minecraft:smooth_quartz
fill 14 65 -331 40 65 -331 minecraft:grass_block
fill 43 65 -331 71 65 -331 minecraft:grass_block
fill 8 65 -330 12 65 -330 minecraft:light_gray_concrete
setblock 13 65 -330 minecraft:smooth_quartz
fill 14 65 -330 41 65 -330 minecraft:grass_block
fill 43 65 -330 71 65 -330 minecraft:grass_block
fill 8 65 -329 12 65 -329 minecraft:light_gray_concrete
setblock 13 65 -329 minecraft:smooth_quartz
fill 14 65 -329 41 65 -329 minecraft:grass_block
fill 44 65 -329 71 65 -329 minecraft:grass_block
fill 8 65 -328 12 65 -328 minecraft:light_gray_concrete
setblock 13 65 -328 minecraft:smooth_quartz
fill 14 65 -328 42 65 -328 minecraft:grass_block
fill 44 65 -328 71 65 -328 minecraft:grass_block
fill 8 65 -327 11 65 -327 minecraft:light_gray_concrete
setblock 12 65 -327 minecraft:sea_lantern
setblock 13 65 -327 minecraft:smooth_quartz
fill 14 65 -327 42 65 -327 minecraft:grass_block
fill 45 65 -327 71 65 -327 minecraft:grass_block
fill 8 65 -326 10 65 -326 minecraft:light_gray_concrete
setblock 11 65 -326 minecraft:sea_lantern
setblock 12 65 -326 minecraft:light_gray_concrete
setblock 13 65 -326 minecraft:smooth_quartz
fill 14 65 -326 43 65 -326 minecraft:grass_block
fill 47 65 -326 71 65 -326 minecraft:grass_block
fill 8 65 -325 9 65 -325 minecraft:light_gray_concrete
setblock 10 65 -325 minecraft:sea_lantern
fill 11 65 -325 12 65 -325 minecraft:light_gray_concrete
setblock 13 65 -325 minecraft:smooth_quartz
fill 14 65 -325 44 65 -325 minecraft:grass_block
fill 53 65 -325 71 65 -325 minecraft:grass_block
setblock 8 65 -324 minecraft:light_gray_concrete
setblock 9 65 -324 minecraft:sea_lantern
fill 10 65 -324 12 65 -324 minecraft:light_gray_concrete
setblock 13 65 -324 minecraft:smooth_quartz
fill 14 65 -324 46 65 -324 minecraft:grass_block
fill 48 65 -324 71 65 -324 minecraft:grass_block
fill 8 65 -323 12 65 -323 minecraft:light_gray_concrete
setblock 13 65 -323 minecraft:smooth_quartz
fill 14 65 -323 71 65 -323 minecraft:grass_block
fill 8 65 -322 12 65 -322 minecraft:light_gray_concrete
setblock 13 65 -322 minecraft:smooth_quartz
fill 14 65 -322 71 65 -322 minecraft:grass_block
fill 8 65 -321 12 65 -321 minecraft:light_gray_concrete
setblock 13 65 -321 minecraft:smooth_quartz
fill 14 65 -321 71 65 -321 minecraft:grass_block
fill 8 65 -320 12 65 -320 minecraft:light_gray_concrete
setblock 13 65 -320 minecraft:smooth_quartz
fill 14 65 -320 55 65 -320 minecraft:grass_block
fill 59 65 -320 71 65 -320 minecraft:grass_block
fill 8 65 -319 12 65 -319 minecraft:light_gray_concrete
setblock 13 65 -319 minecraft:smooth_quartz
fill 14 65 -319 54 65 -319 minecraft:grass_block
fill 60 65 -319 71 65 -319 minecraft:grass_block
setblock 18 66 -379 minecraft:oak_log
setblock 18 66 -369 minecraft:oak_log
setblock 18 66 -359 minecraft:oak_log
setblock 18 66 -349 minecraft:oak_log
fill 16 66 -341 22 66 -341 minecraft:air
fill 12 66 -340 25 66 -340 minecraft:air
fill 11 66 -339 17 66 -339 minecraft:air
setblock 18 66 -339 minecraft:oak_log
fill 19 66 -339 25 66 -339 minecraft:air
setblock 39 66 -339 minecraft:air
fill 8 66 -338 25 66 -338 minecraft:air
fill 8 66 -337 25 66 -337 minecraft:air
setblock 35 66 -337 minecraft:air
fill 8 66 -336 32 66 -336 minecraft:air
setblock 48 66 -336 minecraft:air
fill 8 66 -335 34 66 -335 minecraft:air
setblock 36 66 -335 minecraft:air
fill 8 66 -334 36 66 -334 minecraft:air
fill 8 66 -333 38 66 -333 minecraft:air
setblock 52 66 -333 minecraft:air
fill 8 66 -332 39 66 -332 minecraft:air
fill 8 66 -331 40 66 -331 minecraft:air
setblock 56 66 -331 minecraft:air
fill 8 66 -330 41 66 -330 minecraft:air
fill 8 66 -329 17 66 -329 minecraft:air
setblock 18 66 -329 minecraft:oak_log
fill 19 66 -329 41 66 -329 minecraft:air
setblock 43 66 -329 minecraft:air
fill 8 66 -328 42 66 -328 minecraft:air
fill 8 66 -327 42 66 -327 minecraft:air
fill 8 66 -326 43 66 -326 minecraft:air
fill 8 66 -325 45 66 -325 minecraft:air
fill 47 66 -325 48 66 -325 minecraft:air
fill 8 66 -324 46 66 -324 minecraft:air
fill 8 66 -323 48 66 -323 minecraft:air
fill 8 66 -322 52 66 -322 minecraft:air
fill 8 66 -321 53 66 -321 minecraft:air
fill 8 66 -320 24 66 -320 minecraft:air
setblock 26 66 -320 minecraft:air
fill 32 66 -320 54 66 -320 minecraft:air
setblock 58 66 -320 minecraft:air
fill 8 66 -319 17 66 -319 minecraft:air
setblock 18 66 -319 minecraft:oak_log
fill 19 66 -319 22 66 -319 minecraft:air
setblock 27 66 -319 minecraft:air
fill 33 66 -319 54 66 -319 minecraft:air
setblock 58 66 -319 minecraft:air
fill 61 66 -319 62 66 -319 minecraft:air
setblock 18 67 -379 minecraft:oak_log
setblock 18 67 -369 minecraft:oak_log
setblock 18 67 -359 minecraft:oak_log
setblock 18 67 -349 minecraft:oak_log
fill 13 67 -340 24 67 -340 minecraft:air
fill 11 67 -339 17 67 -339 minecraft:air
setblock 18 67 -339 minecraft:oak_log
fill 19 67 -339 25 67 -339 minecraft:air
setblock 39 67 -339 minecraft:air
fill 9 67 -338 24 67 -338 minecraft:air
fill 8 67 -337 24 67 -337 minecraft:air
fill 8 67 -336 25 67 -336 minecraft:air
setblock 32 67 -336 minecraft:air
setblock 48 67 -336 minecraft:air
fill 8 67 -335 27 67 -335 minecraft:air
fill 8 67 -334 29 67 -334 minecraft:air
fill 8 67 -333 30 67 -333 minecraft:air
setblock 38 67 -333 minecraft:air
setblock 52 67 -333 minecraft:air
fill 8 67 -332 31 67 -332 minecraft:air
setblock 36 67 -332 minecraft:air
fill 8 67 -331 37 67 -331 minecraft:air
setblock 39 67 -331 minecraft:air
setblock 56 67 -331 minecraft:air
fill 8 67 -330 39 67 -330 minecraft:air
fill 8 67 -329 17 67 -329 minecraft:air
setblock 18 67 -329 minecraft:oak_log
fill 19 67 -329 40 67 -329 minecraft:air
fill 8 67 -328 40 67 -328 minecraft:air
setblock 42 67 -328 minecraft:air
fill 8 67 -327 40 67 -327 minecraft:air
fill 8 67 -326 41 67 -326 minecraft:air
fill 8 67 -325 41 67 -325 minecraft:air
fill 8 67 -324 43 67 -324 minecraft:air
fill 8 67 -323 43 67 -323 minecraft:air
setblock 47 67 -323 minecraft:air
fill 8 67 -322 44 67 -322 minecraft:air
fill 8 67 -321 46 67 -321 minecraft:air
fill 8 67 -320 26 67 -320 minecraft:air
fill 30 67 -320 48 67 -320 minecraft:air
setblock 58 67 -320 minecraft:air
fill 8 67 -319 17 67 -319 minecraft:air
setblock 18 67 -319 minecraft:oak_log
fill 19 67 -319 23 67 -319 minecraft:air
setblock 27 67 -319 minecraft:air
fill 32 67 -319 48 67 -319 minecraft:air
setblock 58 67 -319 minecraft:air
setblock 18 68 -379 minecraft:oak_log
setblock 18 68 -369 minecraft:oak_log
setblock 18 68 -359 minecraft:oak_log
setblock 18 68 -349 minecraft:oak_log
fill 14 68 -340 21 68 -340 minecraft:air
fill 12 68 -339 17 68 -339 minecraft:air
setblock 18 68 -339 minecraft:oak_log
fill 19 68 -339 21 68 -339 minecraft:air
setblock 39 68 -339 minecraft:air
fill 11 68 -338 22 68 -338 minecraft:air
fill 8 68 -337 23 68 -337 minecraft:air
fill 8 68 -336 22 68 -336 minecraft:air
setblock 32 68 -336 minecraft:air
setblock 48 68 -336 minecraft:air
fill 8 68 -335 23 68 -335 minecraft:air
fill 8 68 -334 25 68 -334 minecraft:air
fill 8 68 -333 26 68 -333 minecraft:air
setblock 38 68 -333 minecraft:air
setblock 52 68 -333 minecraft:air
fill 8 68 -332 28 68 -332 minecraft:air
fill 8 68 -331 30 68 -331 minecraft:air
setblock 36 68 -331 minecraft:air
setblock 39 68 -331 minecraft:air
setblock 56 68 -331 minecraft:air
fill 8 68 -330 31 68 -330 minecraft:air
fill 35 68 -330 36 68 -330 minecraft:air
setblock 56 68 -330 minecraft:air
fill 8 68 -329 17 68 -329 minecraft:air
setblock 18 68 -329 minecraft:oak_log
fill 19 68 -329 37 68 -329 minecraft:air
fill 8 68 -328 38 68 -328 minecraft:air
fill 8 68 -327 38 68 -327 minecraft:air
setblock 40 68 -327 minecraft:air
fill 8 68 -326 39 68 -326 minecraft:air
setblock 41 68 -326 minecraft:air
fill 8 68 -325 39 68 -325 minecraft:air
fill 8 68 -324 41 68 -324 minecraft:air
fill 8 68 -323 40 68 -323 minecraft:air
fill 8 68 -322 40 68 -322 minecraft:air
fill 8 68 -321 41 68 -321 minecraft:air
fill 8 68 -320 42 68 -320 minecraft:air
fill 8 68 -319 17 68 -319 minecraft:air
setblock 18 68 -319 minecraft:oak_log
fill 19 68 -319 27 68 -319 minecraft:air
fill 29 68 -319 42 68 -319 minecraft:air
setblock 45 68 -319 minecraft:air
setblock 18 69 -381 minecraft:oak_leaves[persistent=true]
fill 17 69 -380 19 69 -380 minecraft:oak_leaves[persistent=true]
fill 16 69 -379 17 69 -379 minecraft:oak_leaves[persistent=true]
setblock 18 69 -379 minecraft:oak_log
fill 19 69 -379 20 69 -379 minecraft:oak_leaves[persistent=true]
fill 17 69 -378 19 69 -378 minecraft:oak_leaves[persistent=true]
setblock 18 69 -377 minecraft:oak_leaves[persistent=true]
setblock 18 69 -371 minecraft:oak_leaves[persistent=true]
fill 17 69 -370 19 69 -370 minecraft:oak_leaves[persistent=true]
fill 16 69 -369 17 69 -369 minecraft:oak_leaves[persistent=true]
setblock 18 69 -369 minecraft:oak_log
fill 19 69 -369 20 69 -369 minecraft:oak_leaves[persistent=true]
fill 17 69 -368 19 69 -368 minecraft:oak_leaves[persistent=true]
setblock 18 69 -367 minecraft:oak_leaves[persistent=true]
setblock 18 69 -361 minecraft:oak_leaves[persistent=true]
fill 17 69 -360 19 69 -360 minecraft:oak_leaves[persistent=true]
fill 16 69 -359 17 69 -359 minecraft:oak_leaves[persistent=true]
setblock 18 69 -359 minecraft:oak_log
fill 19 69 -359 20 69 -359 minecraft:oak_leaves[persistent=true]
fill 17 69 -358 19 69 -358 minecraft:oak_leaves[persistent=true]
setblock 18 69 -357 minecraft:oak_leaves[persistent=true]
setblock 18 69 -351 minecraft:oak_leaves[persistent=true]
fill 17 69 -350 19 69 -350 minecraft:oak_leaves[persistent=true]
fill 16 69 -349 17 69 -349 minecraft:oak_leaves[persistent=true]
setblock 18 69 -349 minecraft:oak_log
fill 19 69 -349 20 69 -349 minecraft:oak_leaves[persistent=true]
fill 17 69 -348 19 69 -348 minecraft:oak_leaves[persistent=true]
setblock 18 69 -347 minecraft:oak_leaves[persistent=true]
setblock 18 69 -341 minecraft:oak_leaves[persistent=true]
setblock 16 69 -340 minecraft:air
fill 17 69 -340 19 69 -340 minecraft:oak_leaves[persistent=true]
setblock 13 69 -339 minecraft:air
setblock 15 69 -339 minecraft:air
fill 16 69 -339 17 69 -339 minecraft:oak_leaves[persistent=true]
setblock 18 69 -339 minecraft:oak_log
fill 19 69 -339 20 69 -339 minecraft:oak_leaves[persistent=true]
setblock 39 69 -339 minecraft:air
fill 12 69 -338 16 69 -338 minecraft:air
fill 17 69 -338 19 69 -338 minecraft:oak_leaves[persistent=true]
fill 20 69 -338 21 69 -338 minecraft:air
fill 9 69 -337 17 69 -337 minecraft:air
setblock 18 69 -337 minecraft:oak_leaves[persistent=true]
setblock 19 69 -337 minecraft:air
setblock 48 69 -337 minecraft:air
fill 8 69 -336 20 69 -336 minecraft:air
setblock 48 69 -336 minecraft:air
fill 8 69 -335 21 69 -335 minecraft:air
fill 8 69 -334 22 69 -334 minecraft:air
fill 8 69 -333 24 69 -333 minecraft:air
setblock 38 69 -333 minecraft:air
fill 52 69 -333 53 69 -333 minecraft:air
fill 8 69 -332 24 69 -332 minecraft:air
setblock 27 69 -332 minecraft:air
fill 8 69 -331 17 69 -331 minecraft:air
setblock 18 69 -331 minecraft:oak_leaves[persistent=true]
fill 19 69 -331 25 69 -331 minecraft:air
setblock 30 69 -331 minecraft:air
setblock 36 69 -331 minecraft:air
setblock 39 69 -331 minecraft:air
setblock 56 69 -331 minecraft:air
fill 8 69 -330 16 69 -330 minecraft:air
fill 17 69 -330 19 69 -330 minecraft:oak_leaves[persistent=true]
fill 20 69 -330 27 69 -330 minecraft:air
fill 8 69 -329 15 69 -329 minecraft:air
fill 16 69 -329 17 69 -329 minecraft:oak_leaves[persistent=true]
setblock 18 69 -329 minecraft:oak_log
fill 19 69 -329 20 69 -329 minecraft:oak_leaves[persistent=true]
fill 21 69 -329 26 69 -329 minecraft:air
setblock 35 69 -329 minecraft:air
setblock 37 69 -329 minecraft:air
fill 8 69 -328 16 69 -328 minecraft:air
fill 17 69 -328 19 69 -328 minecraft:oak_leaves[persistent=true]
fill 20 69 -328 27 69 -328 minecraft:air
fill 8 69 -327 17 69 -327 minecraft:air
setblock 18 69 -327 minecraft:oak_leaves[persistent=true]
fill 19 69 -327 36 69 -327 minecraft:air
setblock 40 69 -327 minecraft:air
fill 8 69 -326 37 69 -326 minecraft:air
fill 8 69 -325 36 69 -325 minecraft:air
setblock 38 69 -325 minecraft:air
fill 8 69 -324 36 69 -324 minecraft:air
fill 8 69 -323 36 69 -323 minecraft:air
setblock 40 69 -323 minecraft:air
fill 8 69 -322 36 69 -322 minecraft:air
fill 8 69 -321 17 69 -321 minecraft:air
setblock 18 69 -321 minecraft:oak_leaves[persistent=true]
fill 19 69 -321 37 69 -321 minecraft:air
fill 8 69 -320 16 69 -320 minecraft:air
fill 17 69 -320 19 69 -320 minecraft:oak_leaves[persistent=true]
fill 20 69 -320 36 69 -320 minecraft:air
fill 8 69 -319 15 69 -319 minecraft:air
fill 16 69 -319 17 69 -319 minecraft:oak_leaves[persistent=true]
setblock 18 69 -319 minecraft:oak_log
fill 19 69 -319 20 69 -319 minecraft:oak_leaves[persistent=true]
fill 21 69 -319 37 69 -319 minecraft:air
fill 17 70 -381 19 70 -381 minecraft:oak_leaves[persistent=true]
fill 16 70 -380 20 70 -380 minecraft:oak_leaves[persistent=true]
fill 16 70 -379 17 70 -379 minecraft:oak_leaves[persistent=true]
setblock 18 70 -379 minecraft:oak_log
fill 19 70 -379 20 70 -379 minecraft:oak_leaves[persistent=true]
fill 16 70 -378 20 70 -378 minecraft:oak_leaves[persistent=true]
fill 17 70 -377 19 70 -377 minecraft:oak_leaves[persistent=true]
fill 17 70 -371 19 70 -371 minecraft:oak_leaves[persistent=true]
fill 16 70 -370 20 70 -370 minecraft:oak_leaves[persistent=true]
fill 16 70 -369 17 70 -369 minecraft:oak_leaves[persistent=true]
setblock 18 70 -369 minecraft:oak_log
fill 19 70 -369 20 70 -369 minecraft:oak_leaves[persistent=true]
fill 16 70 -368 20 70 -368 minecraft:oak_leaves[persistent=true]
fill 17 70 -367 19 70 -367 minecraft:oak_leaves[persistent=true]
fill 17 70 -361 19 70 -361 minecraft:oak_leaves[persistent=true]
fill 16 70 -360 20 70 -360 minecraft:oak_leaves[persistent=true]
fill 16 70 -359 17 70 -359 minecraft:oak_leaves[persistent=true]
setblock 18 70 -359 minecraft:oak_log
fill 19 70 -359 20 70 -359 minecraft:oak_leaves[persistent=true]
fill 16 70 -358 20 70 -358 minecraft:oak_leaves[persistent=true]
fill 17 70 -357 19 70 -357 minecraft:oak_leaves[persistent=true]
fill 17 70 -351 19 70 -351 minecraft:oak_leaves[persistent=true]
fill 16 70 -350 20 70 -350 minecraft:oak_leaves[persistent=true]
fill 16 70 -349 17 70 -349 minecraft:oak_leaves[persistent=true]
setblock 18 70 -349 minecraft:oak_log
fill 19 70 -349 20 70 -349 minecraft:oak_leaves[persistent=true]
fill 16 70 -348 20 70 -348 minecraft:oak_leaves[persistent=true]
fill 17 70 -347 19 70 -347 minecraft:oak_leaves[persistent=true]
fill 17 70 -341 19 70 -341 minecraft:oak_leaves[persistent=true]
fill 16 70 -340 20 70 -340 minecraft:oak_leaves[persistent=true]
fill 16 70 -339 17 70 -339 minecraft:oak_leaves[persistent=true]
setblock 18 70 -339 minecraft:oak_log
fill 19 70 -339 20 70 -339 minecraft:oak_leaves[persistent=true]
setblock 39 70 -339 minecraft:air
fill 16 70 -338 20 70 -338 minecraft:oak_leaves[persistent=true]
setblock 11 70 -337 minecraft:air
setblock 14 70 -337 minecraft:air
fill 17 70 -337 19 70 -337 minecraft:oak_leaves[persistent=true]
fill 8 70 -336 14 70 -336 minecraft:air
setblock 48 70 -336 minecraft:air
fill 8 70 -335 17 70 -335 minecraft:air
setblock 19 70 -335 minecraft:air
fill 8 70 -334 18 70 -334 minecraft:air
setblock 21 70 -334 minecraft:air
fill 8 70 -333 19 70 -333 minecraft:air
fill 23 70 -333 24 70 -333 minecraft:air
setblock 38 70 -333 minecraft:air
setblock 52 70 -333 minecraft:air
setblock 56 70 -333 minecraft:air
fill 8 70 -332 20 70 -332 minecraft:air
setblock 52 70 -332 minecraft:air
fill 55 70 -332 57 70 -332 minecraft:air
fill 8 70 -331 16 70 -331 minecraft:air
fill 17 70 -331 19 70 -331 minecraft:oak_leaves[persistent=true]
fill 20 70 -331 21 70 -331 minecraft:air
setblock 30 70 -331 minecraft:air
setblock 36 70 -331 minecraft:air
setblock 39 70 -331 minecraft:air
fill 54 70 -331 58 70 -331 minecraft:air
fill 8 70 -330 15 70 -330 minecraft:air
fill 16 70 -330 20 70 -330 minecraft:oak_leaves[persistent=true]
fill 21 70 -330 22 70 -330 minecraft:air
setblock 27 70 -330 minecraft:air
fill 55 70 -330 57 70 -330 minecraft:air
fill 8 70 -329 15 70 -329 minecraft:air
fill 16 70 -329 17 70 -329 minecraft:oak_leaves[persistent=true]
setblock 18 70 -329 minecraft:oak_log
fill 19 70 -329 20 70 -329 minecraft:oak_leaves[persistent=true]
fill 21 70 -329 23 70 -329 minecraft:air
setblock 37 70 -329 minecraft:air
setblock 56 70 -329 minecraft:air
fill 8 70 -328 15 70 -328 minecraft:air
fill 16 70 -328 20 70 -328 minecraft:oak_leaves[persistent=true]
fill 21 70 -328 23 70 -328 minecraft:air
fill 8 70 -327 16 70 -327 minecraft:air
fill 17 70 -327 19 70 -327 minecraft:oak_leaves[persistent=true]
fill 20 70 -327 24 70 -327 minecraft:air
setblock 40 70 -327 minecraft:air
fill 8 70 -326 25 70 -326 minecraft:air
fill 8 70 -325 26 70 -325 minecraft:air
fill 8 70 -324 27 70 -324 minecraft:air
fill 29 70 -324 34 70 -324 minecraft:air
fill 8 70 -323 32 70 -323 minecraft:air
fill 8 70 -322 32 70 -322 minecraft:air
fill 8 70 -321 16 70 -321 minecraft:air
fill 17 70 -321 19 70 -321 minecraft:oak_leaves[persistent=true]
fill 20 70 -321 32 70 -321 minecraft:air
fill 8 70 -320 15 70 -320 minecraft:air
fill 16 70 -320 20 70 -320 minecraft:oak_leaves[persistent=true]
fill 21 70 -320 32 70 -320 minecraft:air
setblock 35 70 -320 minecraft:air
fill 8 70 -319 15 70 -319 minecraft:air
fill 16 70 -319 17 70 -319 minecraft:oak_leaves[persistent=true]
setblock 18 70 -319 minecraft:oak_log
fill 19 70 -319 20 70 -319 minecraft:oak_leaves[persistent=true]
fill 21 70 -319 32 70 -319 minecraft:air
setblock 64 70 -319 minecraft:air
setblock 71 70 -319 minecraft:air
setblock 18 71 -381 minecraft:oak_leaves[persistent=true]
fill 17 71 -380 19 71 -380 minecraft:oak_leaves[persistent=true]
fill 16 71 -379 20 71 -379 minecraft:oak_leaves[persistent=true]
fill 17 71 -378 19 71 -378 minecraft:oak_leaves[persistent=true]
setblock 18 71 -377 minecraft:oak_leaves[persistent=true]
setblock 18 71 -371 minecraft:oak_leaves[persistent=true]
fill 17 71 -370 19 71 -370 minecraft:oak_leaves[persistent=true]
fill 16 71 -369 20 71 -369 minecraft:oak_leaves[persistent=true]
fill 17 71 -368 19 71 -368 minecraft:oak_leaves[persistent=true]
setblock 18 71 -367 minecraft:oak_leaves[persistent=true]
setblock 18 71 -361 minecraft:oak_leaves[persistent=true]
fill 17 71 -360 19 71 -360 minecraft:oak_leaves[persistent=true]
fill 16 71 -359 20 71 -359 minecraft:oak_leaves[persistent=true]
fill 17 71 -358 19 71 -358 minecraft:oak_leaves[persistent=true]
setblock 18 71 -357 minecraft:oak_leaves[persistent=true]
setblock 18 71 -351 minecraft:oak_leaves[persistent=true]
fill 17 71 -350 19 71 -350 minecraft:oak_leaves[persistent=true]
fill 16 71 -349 20 71 -349 minecraft:oak_leaves[persistent=true]
fill 17 71 -348 19 71 -348 minecraft:oak_leaves[persistent=true]
setblock 18 71 -347 minecraft:oak_leaves[persistent=true]
setblock 18 71 -341 minecraft:oak_leaves[persistent=true]
fill 17 71 -340 19 71 -340 minecraft:oak_leaves[persistent=true]
fill 16 71 -339 20 71 -339 minecraft:oak_leaves[persistent=true]
setblock 39 71 -339 minecraft:air
fill 17 71 -338 19 71 -338 minecraft:oak_leaves[persistent=true]
setblock 18 71 -337 minecraft:oak_leaves[persistent=true]
fill 9 71 -336 13 71 -336 minecraft:air
setblock 48 71 -336 minecraft:air
fill 9 71 -335 11 71 -335 minecraft:air
setblock 19 71 -335 minecraft:air
setblock 10 71 -334 minecraft:air
setblock 16 71 -334 minecraft:air
fill 10 71 -333 15 71 -333 minecraft:air
setblock 24 71 -333 minecraft:air
setblock 38 71 -333 minecraft:air
setblock 52 71 -333 minecraft:air
fill 8 71 -332 17 71 -332 minecraft:air
fill 55 71 -332 57 71 -332 minecraft:air
fill 8 71 -331 17 71 -331 minecraft:air
setblock 18 71 -331 minecraft:oak_leaves[persistent=true]
setblock 30 71 -331 minecraft:air
setblock 36 71 -331 minecraft:air
setblock 39 71 -331 minecraft:air
fill 55 71 -331 57 71 -331 minecraft:air
fill 8 71 -330 16 71 -330 minecraft:air
fill 17 71 -330 19 71 -330 minecraft:oak_leaves[persistent=true]
setblock 20 71 -330 minecraft:air
setblock 27 71 -330 minecraft:air
fill 55 71 -330 57 71 -330 minecraft:air
fill 8 71 -329 15 71 -329 minecraft:air
fill 16 71 -329 20 71 -329 minecraft:oak_leaves[persistent=true]
setblock 37 71 -329 minecraft:air
fill 8 71 -328 16 71 -328 minecraft:air
fill 17 71 -328 19 71 -328 minecraft:oak_leaves[persistent=true]
fill 20 71 -328 23 71 -328 minecraft:air
fill 8 71 -327 17 71 -327 minecraft:air
setblock 18 71 -327 minecraft:oak_leaves[persistent=true]
fill 19 71 -327 23 71 -327 minecraft:air
setblock 40 71 -327 minecraft:air
fill 8 71 -326 24 71 -326 minecraft:air
fill 8 71 -325 24 71 -325 minecraft:air
fill 8 71 -324 24 71 -324 minecraft:air
setblock 34 71 -324 minecraft:air
fill 8 71 -323 24 71 -323 minecraft:air
fill 8 71 -322 24 71 -322 minecraft:air
fill 8 71 -321 17 71 -321 minecraft:air
setblock 18 71 -321 minecraft:oak_leaves[persistent=true]
fill 19 71 -321 25 71 -321 minecraft:air
fill 8 71 -320 16 71 -320 minecraft:air
fill 17 71 -320 19 71 -320 minecraft:oak_leaves[persistent=true]
fill 20 71 -320 25 71 -320 minecraft:air
setblock 30 71 -320 minecraft:air
setblock 35 71 -320 minecraft:air
fill 8 71 -319 15 71 -319 minecraft:air
fill 16 71 -319 20 71 -319 minecraft:oak_leaves[persistent=true]
fill 21 71 -319 26 71 -319 minecraft:air
setblock 18 72 -379 minecraft:oak_leaves[persistent=true]
setblock 18 72 -369 minecraft:oak_leaves[persistent=true]
setblock 18 72 -359 minecraft:oak_leaves[persistent=true]
setblock 18 72 -349 minecraft:oak_leaves[persistent=true]
setblock 18 72 -339 minecraft:oak_leaves[persistent=true]
setblock 39 72 -339 minecraft:air
setblock 48 72 -338 minecraft:air
fill 47 72 -337 49 72 -337 minecraft:air
fill 9 72 -336 10 72 -336 minecraft:air
setblock 13 72 -336 minecraft:air
fill 46 72 -336 50 72 -336 minecraft:air
fill 9 72 -335 10 72 -335 minecraft:air
setblock 19 72 -335 minecraft:air
fill 47 72 -335 49 72 -335 minecraft:air
setblock 16 72 -334 minecraft:air
setblock 48 72 -334 minecraft:air
setblock 11 72 -333 minecraft:air
setblock 24 72 -333 minecraft:air
setblock 38 72 -333 minecraft:air
setblock 52 72 -333 minecraft:air
setblock 10 72 -332 minecraft:air
setblock 56 72 -332 minecraft:air
setblock 13 72 -331 minecraft:air
setblock 30 72 -331 minecraft:air
setblock 36 72 -331 minecraft:air
setblock 39 72 -331 minecraft:air
fill 55 72 -331 57 72 -331 minecraft:air
setblock 9 72 -330 minecraft:air
setblock 11 72 -330 minecraft:air
setblock 27 72 -330 minecraft:air
setblock 56 72 -330 minecraft:air
fill 8 72 -329 15 72 -329 minecraft:air
setblock 18 72 -329 minecraft:oak_leaves[persistent=true]
setblock 37 72 -329 minecraft:air
fill 8 72 -328 16 72 -328 minecraft:air
setblock 18 72 -328 minecraft:air
fill 8 72 -327 22 72 -327 minecraft:air
setblock 40 72 -327 minecraft:air
fill 8 72 -326 23 72 -326 minecraft:air
fill 8 72 -325 23 72 -325 minecraft:air
fill 8 72 -324 23 72 -324 minecraft:air
setblock 34 72 -324 minecraft:air
fill 8 72 -323 23 72 -323 minecraft:air
fill 8 72 -322 23 72 -322 minecraft:air
fill 8 72 -321 22 72 -321 minecraft:air
fill 8 72 -320 20 72 -320 minecraft:air
setblock 30 72 -320 minecraft:air
setblock 35 72 -320 minecraft:air
fill 8 72 -319 17 72 -319 minecraft:air
setblock 18 72 -319 minecraft:oak_leaves[persistent=true]
setblock 19 72 -319 minecraft:air
setblock 39 73 -341 minecraft:air
fill 38 73 -340 40 73 -340 minecraft:air
fill 37 73 -339 41 73 -339 minecraft:air
fill 38 73 -338 40 73 -338 minecraft:air
setblock 39 73 -337 minecraft:air
fill 47 73 -337 49 73 -337 minecraft:air
fill 9 73 -336 10 73 -336 minecraft:air
fill 47 73 -336 49 73 -336 minecraft:air
fill 9 73 -335 10 73 -335 minecraft:air
setblock 19 73 -335 minecraft:air
fill 47 73 -335 49 73 -335 minecraft:air
setblock 52 73 -335 minecraft:air
setblock 16 73 -334 minecraft:air
fill 51 73 -334 53 73 -334 minecraft:air
setblock 24 73 -333 minecraft:air
setblock 30 73 -333 minecraft:air
setblock 38 73 -333 minecraft:air
fill 50 73 -333 54 73 -333 minecraft:air
fill 29 73 -332 31 73 -332 minecraft:air
fill 51 73 -332 53 73 -332 minecraft:air
fill 28 73 -331 32 73 -331 minecraft:air
setblock 36 73 -331 minecraft:air
setblock 39 73 -331 minecraft:air
setblock 52 73 -331 minecraft:air
fill 55 73 -331 56 73 -331 minecraft:air
setblock 27 73 -330 minecraft:air
fill 29 73 -330 31 73 -330 minecraft:air
setblock 12 73 -329 minecraft:air
setblock 15 73 -329 minecraft:air
setblock 30 73 -329 minecraft:air
setblock 37 73 -329 minecraft:air
setblock 40 73 -327 minecraft:air
setblock 11 73 -326 minecraft:air
fill 8 73 -325 12 73 -325 minecraft:air
setblock 18 73 -325 minecraft:air
setblock 21 73 -325 minecraft:air
fill 8 73 -324 12 73 -324 minecraft:air
setblock 34 73 -324 minecraft:air
fill 8 73 -323 14 73 -323 minecraft:air
setblock 18 73 -323 minecraft:air
setblock 23 73 -323 minecraft:air
fill 8 73 -322 14 73 -322 minecraft:air
fill 8 73 -321 13 73 -321 minecraft:air
fill 8 73 -320 15 73 -320 minecraft:air
setblock 30 73 -320 minecraft:air
setblock 35 73 -320 minecraft:air
fill 8 73 -319 13 73 -319 minecraft:air
fill 38 74 -340 40 74 -340 minecraft:air
fill 38 74 -339 40 74 -339 minecraft:air
fill 38 74 -338 40 74 -338 minecraft:air
setblock 11 74 -337 minecraft:air
setblock 48 74 -337 minecraft:air
fill 9 74 -336 10 74 -336 minecraft:air
fill 47 74 -336 49 74 -336 minecraft:air
fill 9 74 -335 10 74 -335 minecraft:air
setblock 19 74 -335 minecraft:air
setblock 24 74 -335 minecraft:air
setblock 48 74 -335 minecraft:air
setblock 16 74 -334 minecraft:air
fill 23 74 -334 25 74 -334 minecraft:air
fill 51 74 -334 53 74 -334 minecraft:air
fill 22 74 -333 26 74 -333 minecraft:air
fill 38 74 -333 39 74 -333 minecraft:air
fill 51 74 -333 53 74 -333 minecraft:air
fill 23 74 -332 25 74 -332 minecraft:air
fill 29 74 -332 31 74 -332 minecraft:air
fill 38 74 -332 40 74 -332 minecraft:air
fill 51 74 -332 53 74 -332 minecraft:air
setblock 24 74 -331 minecraft:air
fill 29 74 -331 31 74 -331 minecraft:air
fill 36 74 -331 41 74 -331 minecraft:air
setblock 27 74 -330 minecraft:air
fill 29 74 -330 31 74 -330 minecraft:air
fill 38 74 -330 40 74 -330 minecraft:air
setblock 12 74 -329 minecraft:air
setblock 15 74 -329 minecraft:air
setblock 37 74 -329 minecraft:air
setblock 39 74 -329 minecraft:air
setblock 40 74 -327 minecraft:air
setblock 11 74 -326 minecraft:air
setblock 10 74 -325 minecraft:air
setblock 18 74 -325 minecraft:air
setblock 11 74 -324 minecraft:air
setblock 34 74 -324 minecraft:air
setblock 8 74 -323 minecraft:air
setblock 12 74 -322 minecraft:air
setblock 9 74 -321 minecraft:air
setblock 12 74 -321 minecraft:air
setblock 30 74 -320 minecraft:air
setblock 35 74 -320 minecraft:air
setblock 8 74 -319 minecraft:air
setblock 10 74 -319 minecraft:air
setblock 51 74 -319 minecraft:air
setblock 39 75 -340 minecraft:air
fill 38 75 -339 40 75 -339 minecraft:air
setblock 39 75 -338 minecraft:air
setblock 11 75 -337 minecraft:air
fill 9 75 -336 10 75 -336 minecraft:air
fill 47 75 -336 49 75 -336 minecraft:air
fill 9 75 -335 10 75 -335 minecraft:air
setblock 16 75 -335 minecraft:air
setblock 19 75 -335 minecraft:air
setblock 16 75 -334 minecraft:air
fill 23 75 -334 25 75 -334 minecraft:air
setblock 52 75 -334 minecraft:air
fill 23 75 -333 25 75 -333 minecraft:air
setblock 36 75 -333 minecraft:air
setblock 38 75 -333 minecraft:air
fill 51 75 -333 53 75 -333 minecraft:air
fill 23 75 -332 25 75 -332 minecraft:air
setblock 27 75 -332 minecraft:air
setblock 30 75 -332 minecraft:air
fill 35 75 -332 40 75 -332 minecraft:air
setblock 52 75 -332 minecraft:air
fill 26 75 -331 31 75 -331 minecraft:air
fill 34 75 -331 40 75 -331 minecraft:air
fill 25 75 -330 30 75 -330 minecraft:air
fill 35 75 -330 40 75 -330 minecraft:air
setblock 12 75 -329 minecraft:air
setblock 15 75 -329 minecraft:air
fill 26 75 -329 28 75 -329 minecraft:air
fill 36 75 -329 37 75 -329 minecraft:air
setblock 40 75 -329 minecraft:air
setblock 27 75 -328 minecraft:air
fill 39 75 -328 41 75 -328 minecraft:air
fill 38 75 -327 42 75 -327 minecraft:air
setblock 11 75 -326 minecraft:air
fill 39 75 -326 41 75 -326 minecraft:air
fill 18 75 -325 20 75 -325 minecraft:air
setblock 40 75 -325 minecraft:air
setblock 34 75 -324 minecraft:air
setblock 8 75 -323 minecraft:air
setblock 35 75 -322 minecraft:air
fill 34 75 -321 36 75 -321 minecraft:air
setblock 30 75 -320 minecraft:air
fill 33 75 -320 37 75 -320 minecraft:air
setblock 61 75 -320 minecraft:air
fill 34 75 -319 36 75 -319 minecraft:air
fill 60 75 -319 62 75 -319 minecraft:air
fill 38 76 -339 40 76 -339 minecraft:air
setblock 39 76 -338 minecraft:air
setblock 11 76 -337 minecraft:air
fill 9 76 -336 10 76 -336 minecraft:air
fill 9 76 -335 10 76 -335 minecraft:air
setblock 19 76 -335 minecraft:air
setblock 38 76 -335 minecraft:air
setblock 8 76 -334 minecraft:air
setblock 16 76 -334 minecraft:air
setblock 24 76 -334 minecraft:air
fill 37 76 -334 39 76 -334 minecraft:air
fill 23 76 -333 25 76 -333 minecraft:air
fill 36 76 -333 40 76 -333 minecraft:air
fill 52 76 -333 53 76 -333 minecraft:air
setblock 24 76 -332 minecraft:air
fill 35 76 -332 39 76 -332 minecraft:air
setblock 52 76 -332 minecraft:air
fill 26 76 -331 28 76 -331 minecraft:air
fill 30 76 -331 31 76 -331 minecraft:air
fill 35 76 -331 40 76 -331 minecraft:air
fill 26 76 -330 28 76 -330 minecraft:air
fill 35 76 -330 37 76 -330 minecraft:air
setblock 39 76 -330 minecraft:air
setblock 12 76 -329 minecraft:air
setblock 15 76 -329 minecraft:air
fill 26 76 -329 28 76 -329 minecraft:air
setblock 37 76 -329 minecraft:air
fill 39 76 -328 41 76 -328 minecraft:air
fill 39 76 -327 41 76 -327 minecraft:air
setblock 11 76 -326 minecraft:air
fill 39 76 -326 41 76 -326 minecraft:air
setblock 18 76 -325 minecraft:air
setblock 34 76 -324 minecraft:air
setblock 8 76 -323 minecraft:air
fill 34 76 -321 36 76 -321 minecraft:air
setblock 30 76 -320 minecraft:air
fill 34 76 -320 36 76 -320 minecraft:air
fill 34 76 -319 36 76 -319 minecraft:air
setblock 47 76 -319 minecraft:air
fill 60 76 -319 62 76 -319 minecraft:air
fill 10 77 -337 12 77 -337 minecraft:air
setblock 19 77 -337 minecraft:air
fill 8 77 -336 13 77 -336 minecraft:air
fill 18 77 -336 20 77 -336 minecraft:air
fill 8 77 -335 13 77 -335 minecraft:air
fill 17 77 -335 21 77 -335 minecraft:air
fill 8 77 -334 13 77 -334 minecraft:air
setblock 16 77 -334 minecraft:air
fill 18 77 -334 20 77 -334 minecraft:air
setblock 24 77 -334 minecraft:air
fill 37 77 -334 39 77 -334 minecraft:air
fill 8 77 -333 12 77 -333 minecraft:air
setblock 19 77 -333 minecraft:air
fill 24 77 -333 25 77 -333 minecraft:air
fill 37 77 -333 39 77 -333 minecraft:air
fill 8 77 -332 12 77 -332 minecraft:air
fill 36 77 -332 39 77 -332 minecraft:air
fill 8 77 -331 12 77 -331 minecraft:air
setblock 27 77 -331 minecraft:air
fill 35 77 -331 37 77 -331 minecraft:air
fill 39 77 -331 40 77 -331 minecraft:air
fill 8 77 -330 9 77 -330 minecraft:air
fill 26 77 -330 28 77 -330 minecraft:air
setblock 36 77 -330 minecraft:air
setblock 39 77 -330 minecraft:air
setblock 12 77 -329 minecraft:air
setblock 15 77 -329 minecraft:air
setblock 27 77 -329 minecraft:air
setblock 37 77 -329 minecraft:air
setblock 40 77 -328 minecraft:air
fill 39 77 -327 41 77 -327 minecraft:air
setblock 11 77 -326 minecraft:air
setblock 40 77 -326 minecraft:air
fill 19 77 -325 20 77 -325 minecraft:air
setblock 34 77 -324 minecraft:air
setblock 8 77 -323 minecraft:air
setblock 35 77 -321 minecraft:air
setblock 30 77 -320 minecraft:air
fill 34 77 -320 36 77 -320 minecraft:air
setblock 35 77 -319 minecraft:air
setblock 61 77 -319 minecraft:air
fill 8 78 -337 11 78 -337 minecraft:air
fill 8 78 -336 13 78 -336 minecraft:air
fill 18 78 -336 20 78 -336 minecraft:air
fill 8 78 -335 13 78 -335 minecraft:air
fill 18 78 -335 20 78 -335 minecraft:air
fill 8 78 -334 13 78 -334 minecraft:air
setblock 16 78 -334 minecraft:air
fill 18 78 -334 20 78 -334 minecraft:air
setblock 38 78 -334 minecraft:air
fill 8 78 -333 13 78 -333 minecraft:air
fill 37 78 -333 39 78 -333 minecraft:air
fill 8 78 -332 13 78 -332 minecraft:air
setblock 36 78 -332 minecraft:air
setblock 38 78 -332 minecraft:air
fill 8 78 -331 11 78 -331 minecraft:air
setblock 27 78 -331 minecraft:air
setblock 36 78 -331 minecraft:air
fill 8 78 -330 11 78 -330 minecraft:air
fill 27 78 -330 28 78 -330 minecraft:air
setblock 36 78 -330 minecraft:air
setblock 12 78 -329 minecraft:air
setblock 15 78 -329 minecraft:air
setblock 27 78 -329 minecraft:air
setblock 37 78 -329 minecraft:air
setblock 40 78 -328 minecraft:air
fill 40 78 -327 41 78 -327 minecraft:air
setblock 11 78 -326 minecraft:air
setblock 40 78 -326 minecraft:air
setblock 34 78 -324 minecraft:air
setblock 8 78 -323 minecraft:air
setblock 35 78 -321 minecraft:air
setblock 30 78 -320 minecraft:air
fill 34 78 -320 35 78 -320 minecraft:air
setblock 26 78 -319 minecraft:air
setblock 35 78 -319 minecraft:air
setblock 61 78 -319 minecraft:air
fill 9 79 -336 10 79 -336 minecraft:air
setblock 16 79 -336 minecraft:air
setblock 19 79 -336 minecraft:air
fill 8 79 -335 11 79 -335 minecraft:air
fill 15 79 -335 20 79 -335 minecraft:air
fill 8 79 -334 12 79 -334 minecraft:air
fill 14 79 -334 19 79 -334 minecraft:air
fill 8 79 -333 12 79 -333 minecraft:air
fill 15 79 -333 17 79 -333 minecraft:air
fill 38 79 -333 39 79 -333 minecraft:air
fill 8 79 -332 11 79 -332 minecraft:air
setblock 16 79 -332 minecraft:air
fill 9 79 -331 10 79 -331 minecraft:air
setblock 15 79 -331 minecraft:air
fill 14 79 -330 16 79 -330 minecraft:air
fill 12 79 -329 17 79 -329 minecraft:air
setblock 37 79 -329 minecraft:air
fill 14 79 -328 16 79 -328 minecraft:air
setblock 15 79 -327 minecraft:air
setblock 11 79 -326 minecraft:air
setblock 34 79 -326 minecraft:air
fill 33 79 -325 35 79 -325 minecraft:air
fill 32 79 -324 36 79 -324 minecraft:air
setblock 8 79 -323 minecraft:air
fill 33 79 -323 35 79 -323 minecraft:air
setblock 34 79 -322 minecraft:air
setblock 30 79 -320 minecraft:air
setblock 19 80 -336 minecraft:air
fill 15 80 -335 17 80 -335 minecraft:air
fill 19 80 -335 20 80 -335 minecraft:air
fill 9 80 -334 10 80 -334 minecraft:air
fill 15 80 -334 17 80 -334 minecraft:air
fill 9 80 -333 10 80 -333 minecraft:air
fill 15 80 -333 17 80 -333 minecraft:air
setblock 12 80 -331 minecraft:air
setblock 37 80 -331 minecraft:air
fill 11 80 -330 16 80 -330 minecraft:air
fill 36 80 -330 38 80 -330 minecraft:air
fill 10 80 -329 16 80 -329 minecraft:air
fill 35 80 -329 39 80 -329 minecraft:air
fill 11 80 -328 16 80 -328 minecraft:air
fill 36 80 -328 38 80 -328 minecraft:air
setblock 12 80 -327 minecraft:air
setblock 37 80 -327 minecraft:air
setblock 11 80 -326 minecraft:air
fill 33 80 -325 35 80 -325 minecraft:air
fill 33 80 -324 35 80 -324 minecraft:air
setblock 8 80 -323 minecraft:air
fill 33 80 -323 35 80 -323 minecraft:air
setblock 30 80 -322 minecraft:air
fill 29 80 -321 31 80 -321 minecraft:air
fill 28 80 -320 32 80 -320 minecraft:air
fill 29 80 -319 31 80 -319 minecraft:air
setblock 16 81 -335 minecraft:air
fill 15 81 -334 17 81 -334 minecraft:air
setblock 16 81 -333 minecraft:air
fill 11 81 -330 13 81 -330 minecraft:air
setblock 15 81 -330 minecraft:air
fill 36 81 -330 38 81 -330 minecraft:air
fill 11 81 -329 16 81 -329 minecraft:air
fill 36 81 -329 38 81 -329 minecraft:air
fill 11 81 -328 13 81 -328 minecraft:air
setblock 15 81 -328 minecraft:air
fill 36 81 -328 38 81 -328 minecraft:air
setblock 11 81 -326 minecraft:air
setblock 34 81 -325 minecraft:air
fill 33 81 -324 35 81 -324 minecraft:air
setblock 8 81 -323 minecraft:air
setblock 34 81 -323 minecraft:air
fill 29 81 -321 31 81 -321 minecraft:air
fill 29 81 -320 31 81 -320 minecraft:air
fill 29 81 -319 31 81 -319 minecraft:air
setblock 16 82 -335 minecraft:air
fill 16 82 -334 17 82 -334 minecraft:air
setblock 16 82 -333 minecraft:air
setblock 12 82 -330 minecraft:air
setblock 37 82 -330 minecraft:air
fill 11 82 -329 15 82 -329 minecraft:air
fill 36 82 -329 38 82 -329 minecraft:air
setblock 12 82 -328 minecraft:air
setblock 15 82 -328 minecraft:air
setblock 37 82 -328 minecraft:air
setblock 11 82 -326 minecraft:air
setblock 34 82 -324 minecraft:air
setblock 8 82 -323 minecraft:air
setblock 30 82 -321 minecraft:air
fill 29 82 -320 31 82 -320 minecraft:air
setblock 30 82 -319 minecraft:air
fill 11 83 -329 13 83 -329 minecraft:air
setblock 37 83 -329 minecraft:air
setblock 11 83 -326 minecraft:air
setblock 8 83 -325 minecraft:air
fill 8 83 -324 9 83 -324 minecraft:air
fill 8 83 -323 10 83 -323 minecraft:air
fill 8 83 -322 9 83 -322 minecraft:air
setblock 8 83 -321 minecraft:air
fill 29 83 -320 31 83 -320 minecraft:air
setblock 30 83 -319 minecraft:air
setblock 11 84 -328 minecraft:air
fill 10 84 -327 12 84 -327 minecraft:air
fill 9 84 -326 13 84 -326 minecraft:air
fill 10 84 -325 12 84 -325 minecraft:air
fill 8 84 -324 9 84 -324 minecraft:air
setblock 11 84 -324 minecraft:air
fill 8 84 -323 9 84 -323 minecraft:air
fill 8 84 -322 9 84 -322 minecraft:air
fill 10 85 -327 12 85 -327 minecraft:air
fill 10 85 -326 12 85 -326 minecraft:air
fill 10 85 -325 12 85 -325 minecraft:air
setblock 8 85 -324 minecraft:air
fill 8 85 -323 9 85 -323 minecraft:air
setblock 8 85 -322 minecraft:air
setblock 11 86 -327 minecraft:air
fill 10 86 -326 12 86 -326 minecraft:air
setblock 11 86 -325 minecraft:air
setblock 8 86 -324 minecraft:air
fill 8 86 -323 9 86 -323 minecraft:air
setblock 11 87 -326 minecraft:air
setblock 11 87 -325 minecraft:air
forceload remove 8 -382 71 -319
tellraw @a {"text":"Campus bau a08 fertig.","color":"green"}
