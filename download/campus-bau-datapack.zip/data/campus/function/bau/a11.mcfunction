# Abschnitt a11: x 200..263, z -382..-319 (6502 Blöcke)
forceload add 200 -382 263 -319
tellraw @a {"text":"Campus bau a11: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a11_1 2s
