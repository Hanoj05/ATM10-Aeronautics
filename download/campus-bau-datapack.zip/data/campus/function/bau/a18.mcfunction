# Abschnitt a18: x 200..263, z -318..-255 (11688 Blöcke)
forceload add 200 -318 263 -255
tellraw @a {"text":"Campus bau a18: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a18_1 2s
