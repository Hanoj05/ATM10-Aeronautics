# Abschnitt a03: x 136..199, z -446..-383 (36852 Blöcke)
forceload add 136 -446 199 -383
tellraw @a {"text":"Campus bau a03: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a03_1 2s
