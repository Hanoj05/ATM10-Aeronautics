# Abschnitt a10: x 136..199, z -382..-319 (15424 Blöcke)
forceload add 136 -382 199 -319
tellraw @a {"text":"Campus bau a10: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a10_1 2s
