fill 371 45 -441 372 45 -441 minecraft:stone
fill 370 45 -440 372 45 -440 minecraft:stone
fill 370 45 -439 371 45 -439 minecraft:stone
setblock 328 45 -435 minecraft:stone
fill 328 45 -434 329 45 -434 minecraft:stone
fill 328 45 -433 329 45 -433 minecraft:stone
fill 328 45 -432 330 45 -432 minecraft:stone
fill 328 45 -431 330 45 -431 minecraft:stone
fill 328 45 -430 330 45 -430 minecraft:stone
fill 328 45 -429 330 45 -429 minecraft:stone
fill 328 45 -428 329 45 -428 minecraft:stone
setblock 333 45 -398 minecraft:stone
fill 333 45 -397 334 45 -397 minecraft:stone
setblock 333 45 -396 minecraft:stone
fill 371 46 -441 372 46 -441 minecraft:stone
fill 370 46 -440 372 46 -440 minecraft:stone
fill 370 46 -439 371 46 -439 minecraft:stone
setblock 328 46 -435 minecraft:stone
fill 328 46 -434 329 46 -434 minecraft:stone
fill 328 46 -433 330 46 -433 minecraft:stone
fill 328 46 -432 330 46 -432 minecraft:stone
fill 328 46 -431 330 46 -431 minecraft:stone
fill 328 46 -430 330 46 -430 minecraft:stone
fill 328 46 -429 330 46 -429 minecraft:stone
fill 328 46 -428 329 46 -428 minecraft:stone
setblock 333 46 -398 minecraft:stone
setblock 334 46 -397 minecraft:stone
fill 370 47 -440 372 47 -440 minecraft:stone
fill 370 47 -439 371 47 -439 minecraft:stone
setblock 328 47 -435 minecraft:stone
fill 328 47 -434 329 47 -434 minecraft:stone
fill 328 47 -433 330 47 -433 minecraft:stone
fill 328 47 -432 330 47 -432 minecraft:stone
fill 328 47 -431 330 47 -431 minecraft:stone
fill 328 47 -430 330 47 -430 minecraft:stone
fill 328 47 -429 330 47 -429 minecraft:stone
fill 328 47 -428 330 47 -428 minecraft:stone
setblock 328 47 -427 minecraft:stone
setblock 334 47 -397 minecraft:stone
fill 370 48 -440 372 48 -440 minecraft:stone
fill 370 48 -439 371 48 -439 minecraft:stone
setblock 328 48 -436 minecraft:stone
setblock 328 48 -435 minecraft:stone
fill 328 48 -434 329 48 -434 minecraft:stone
fill 328 48 -433 330 48 -433 minecraft:stone
fill 328 48 -432 330 48 -432 minecraft:stone
fill 328 48 -431 330 48 -431 minecraft:stone
fill 328 48 -430 330 48 -430 minecraft:stone
fill 328 48 -429 330 48 -429 minecraft:stone
fill 328 48 -428 330 48 -428 minecraft:stone
setblock 328 48 -427 minecraft:stone
setblock 332 48 -397 minecraft:stone
setblock 332 48 -396 minecraft:stone
fill 383 49 -446 386 49 -446 minecraft:stone
fill 383 49 -445 391 49 -445 minecraft:stone
fill 383 49 -444 388 49 -444 minecraft:stone
fill 390 49 -444 391 49 -444 minecraft:stone
fill 382 49 -443 387 49 -443 minecraft:stone
fill 390 49 -443 391 49 -443 minecraft:stone
fill 383 49 -442 386 49 -442 minecraft:stone
fill 390 49 -442 391 49 -442 minecraft:stone
fill 383 49 -441 387 49 -441 minecraft:stone
setblock 391 49 -441 minecraft:stone
fill 370 49 -440 372 49 -440 minecraft:stone
fill 383 49 -440 387 49 -440 minecraft:stone
setblock 391 49 -440 minecraft:stone
fill 370 49 -439 371 49 -439 minecraft:stone
fill 383 49 -439 388 49 -439 minecraft:stone
fill 384 49 -438 388 49 -438 minecraft:stone
fill 384 49 -437 388 49 -437 minecraft:stone
setblock 328 49 -436 minecraft:stone
fill 385 49 -436 388 49 -436 minecraft:stone
setblock 328 49 -435 minecraft:stone
setblock 386 49 -435 minecraft:stone
fill 328 49 -434 329 49 -434 minecraft:stone
fill 328 49 -433 330 49 -433 minecraft:stone
fill 328 49 -432 330 49 -432 minecraft:stone
fill 328 49 -431 330 49 -431 minecraft:stone
fill 328 49 -430 330 49 -430 minecraft:stone
fill 328 49 -429 331 49 -429 minecraft:stone
fill 328 49 -428 331 49 -428 minecraft:stone
fill 328 49 -427 329 49 -427 minecraft:stone
setblock 328 49 -426 minecraft:stone
fill 332 49 -397 333 49 -397 minecraft:stone
fill 332 49 -396 333 49 -396 minecraft:stone
fill 383 50 -446 386 50 -446 minecraft:stone
fill 383 50 -445 391 50 -445 minecraft:stone
fill 383 50 -444 391 50 -444 minecraft:stone
fill 382 50 -443 387 50 -443 minecraft:stone
fill 390 50 -443 391 50 -443 minecraft:stone
fill 382 50 -442 386 50 -442 minecraft:stone
fill 390 50 -442 391 50 -442 minecraft:stone
fill 383 50 -441 387 50 -441 minecraft:stone
setblock 391 50 -441 minecraft:stone
fill 370 50 -440 372 50 -440 minecraft:stone
fill 383 50 -440 387 50 -440 minecraft:stone
setblock 391 50 -440 minecraft:stone
fill 370 50 -439 371 50 -439 minecraft:stone
fill 383 50 -439 388 50 -439 minecraft:stone
fill 390 50 -439 391 50 -439 minecraft:stone
fill 383 50 -438 391 50 -438 minecraft:stone
fill 384 50 -437 391 50 -437 minecraft:stone
fill 385 50 -436 391 50 -436 minecraft:stone
setblock 328 50 -435 minecraft:stone
fill 386 50 -435 391 50 -435 minecraft:stone
fill 328 50 -434 329 50 -434 minecraft:stone
fill 388 50 -434 389 50 -434 minecraft:stone
fill 328 50 -433 329 50 -433 minecraft:stone
fill 328 50 -432 330 50 -432 minecraft:stone
fill 328 50 -431 330 50 -431 minecraft:stone
fill 328 50 -430 330 50 -430 minecraft:stone
fill 328 50 -429 331 50 -429 minecraft:stone
fill 328 50 -428 331 50 -428 minecraft:stone
fill 328 50 -427 330 50 -427 minecraft:stone
setblock 328 50 -426 minecraft:stone
setblock 332 50 -397 minecraft:stone
fill 331 50 -396 333 50 -396 minecraft:stone
fill 331 50 -395 332 50 -395 minecraft:stone
fill 383 51 -446 386 51 -446 minecraft:stone
fill 384 51 -445 391 51 -445 minecraft:stone
fill 383 51 -444 387 51 -444 minecraft:stone
fill 389 51 -444 391 51 -444 minecraft:stone
fill 383 51 -443 386 51 -443 minecraft:stone
fill 390 51 -443 391 51 -443 minecraft:stone
fill 383 51 -442 386 51 -442 minecraft:stone
setblock 391 51 -442 minecraft:stone
fill 383 51 -441 387 51 -441 minecraft:stone
setblock 391 51 -441 minecraft:stone
fill 370 51 -440 372 51 -440 minecraft:stone
fill 383 51 -440 387 51 -440 minecraft:stone
setblock 391 51 -440 minecraft:stone
fill 370 51 -439 371 51 -439 minecraft:stone
fill 384 51 -439 388 51 -439 minecraft:stone
fill 390 51 -439 391 51 -439 minecraft:stone
fill 384 51 -438 391 51 -438 minecraft:stone
fill 385 51 -437 391 51 -437 minecraft:stone
fill 385 51 -436 391 51 -436 minecraft:stone
setblock 328 51 -435 minecraft:stone
fill 386 51 -435 391 51 -435 minecraft:stone
fill 328 51 -434 329 51 -434 minecraft:stone
fill 388 51 -434 389 51 -434 minecraft:stone
fill 328 51 -433 329 51 -433 minecraft:stone
fill 328 51 -432 330 51 -432 minecraft:stone
fill 328 51 -431 330 51 -431 minecraft:stone
fill 328 51 -430 330 51 -430 minecraft:stone
fill 328 51 -429 331 51 -429 minecraft:stone
fill 328 51 -428 332 51 -428 minecraft:stone
fill 328 51 -427 330 51 -427 minecraft:stone
fill 328 51 -426 329 51 -426 minecraft:stone
setblock 328 51 -425 minecraft:stone
fill 382 51 -401 383 51 -401 minecraft:stone
fill 382 51 -400 383 51 -400 minecraft:stone
setblock 383 51 -399 minecraft:stone
fill 383 51 -398 384 51 -398 minecraft:stone
fill 331 51 -397 332 51 -397 minecraft:stone
fill 331 51 -396 333 51 -396 minecraft:stone
setblock 384 51 -396 minecraft:stone
fill 331 51 -395 332 51 -395 minecraft:stone
setblock 331 51 -394 minecraft:stone
fill 385 52 -446 386 52 -446 minecraft:stone
setblock 386 52 -445 minecraft:stone
fill 370 52 -440 372 52 -440 minecraft:stone
fill 370 52 -439 371 52 -439 minecraft:stone
setblock 391 52 -439 minecraft:stone
fill 386 52 -438 387 52 -438 minecraft:stone
fill 389 52 -438 391 52 -438 minecraft:stone
fill 386 52 -437 391 52 -437 minecraft:stone
fill 387 52 -436 391 52 -436 minecraft:stone
setblock 328 52 -435 minecraft:stone
fill 387 52 -435 391 52 -435 minecraft:stone
setblock 328 52 -434 minecraft:stone
fill 328 52 -433 329 52 -433 minecraft:stone
fill 328 52 -432 330 52 -432 minecraft:stone
fill 328 52 -431 330 52 -431 minecraft:stone
fill 328 52 -430 330 52 -430 minecraft:stone
fill 328 52 -429 331 52 -429 minecraft:stone
fill 328 52 -428 332 52 -428 minecraft:stone
fill 328 52 -427 331 52 -427 minecraft:stone
fill 328 52 -426 330 52 -426 minecraft:stone
fill 328 52 -425 329 52 -425 minecraft:stone
fill 382 52 -404 383 52 -404 minecraft:stone
setblock 382 52 -403 minecraft:stone
setblock 382 52 -402 minecraft:stone
fill 381 52 -401 383 52 -401 minecraft:stone
fill 382 52 -400 383 52 -400 minecraft:stone
fill 382 52 -399 384 52 -399 minecraft:stone
fill 383 52 -398 384 52 -398 minecraft:stone
fill 383 52 -397 385 52 -397 minecraft:stone
fill 331 52 -396 332 52 -396 minecraft:stone
fill 383 52 -396 385 52 -396 minecraft:stone
fill 330 52 -395 332 52 -395 minecraft:stone
fill 384 52 -395 385 52 -395 minecraft:stone
fill 330 52 -394 332 52 -394 minecraft:stone
fill 370 53 -440 372 53 -440 minecraft:stone
fill 370 53 -439 371 53 -439 minecraft:stone
setblock 328 53 -435 minecraft:stone
setblock 328 53 -434 minecraft:stone
fill 328 53 -433 329 53 -433 minecraft:stone
fill 328 53 -432 330 53 -432 minecraft:stone
fill 328 53 -431 330 53 -431 minecraft:stone
fill 328 53 -430 330 53 -430 minecraft:stone
fill 328 53 -429 331 53 -429 minecraft:stone
fill 328 53 -428 332 53 -428 minecraft:stone
fill 328 53 -427 331 53 -427 minecraft:stone
fill 328 53 -426 330 53 -426 minecraft:stone
fill 328 53 -425 329 53 -425 minecraft:stone
setblock 328 53 -424 minecraft:stone
fill 382 53 -405 383 53 -405 minecraft:stone
fill 382 53 -404 384 53 -404 minecraft:stone
fill 382 53 -403 383 53 -403 minecraft:stone
fill 382 53 -401 383 53 -401 minecraft:stone
fill 382 53 -400 383 53 -400 minecraft:stone
fill 383 53 -399 384 53 -399 minecraft:stone
fill 383 53 -398 384 53 -398 minecraft:stone
fill 384 53 -397 385 53 -397 minecraft:stone
setblock 331 53 -396 minecraft:stone
fill 383 53 -396 386 53 -396 minecraft:stone
fill 330 53 -395 332 53 -395 minecraft:stone
fill 340 53 -395 346 53 -395 minecraft:stone
fill 384 53 -395 386 53 -395 minecraft:stone
fill 330 53 -394 332 53 -394 minecraft:stone
fill 340 53 -394 347 53 -394 minecraft:stone
fill 385 53 -394 387 53 -394 minecraft:stone
setblock 331 53 -393 minecraft:stone
fill 339 53 -393 343 53 -393 minecraft:stone
setblock 331 53 -392 minecraft:stone
setblock 340 53 -389 minecraft:stone
fill 340 53 -388 341 53 -388 minecraft:stone
fill 370 54 -440 372 54 -440 minecraft:stone
fill 369 54 -439 371 54 -439 minecraft:stone
setblock 328 54 -434 minecraft:stone
fill 328 54 -433 329 54 -433 minecraft:stone
fill 328 54 -432 329 54 -432 minecraft:stone
fill 328 54 -431 330 54 -431 minecraft:stone
fill 328 54 -430 330 54 -430 minecraft:stone
fill 328 54 -429 331 54 -429 minecraft:stone
fill 328 54 -428 332 54 -428 minecraft:stone
fill 328 54 -427 332 54 -427 minecraft:stone
fill 328 54 -426 331 54 -426 minecraft:stone
fill 328 54 -425 330 54 -425 minecraft:stone
fill 328 54 -424 329 54 -424 minecraft:stone
setblock 383 54 -405 minecraft:stone
fill 382 54 -404 383 54 -404 minecraft:stone
setblock 382 54 -403 minecraft:stone
setblock 384 54 -397 minecraft:stone
fill 345 54 -396 348 54 -396 minecraft:stone
fill 384 54 -396 385 54 -396 minecraft:stone
setblock 331 54 -395 minecraft:stone
fill 339 54 -395 350 54 -395 minecraft:stone
fill 384 54 -395 387 54 -395 minecraft:stone
fill 330 54 -394 332 54 -394 minecraft:stone
fill 336 54 -394 348 54 -394 minecraft:stone
fill 385 54 -394 388 54 -394 minecraft:stone
fill 330 54 -393 332 54 -393 minecraft:stone
fill 336 54 -393 345 54 -393 minecraft:stone
fill 386 54 -393 388 54 -393 minecraft:stone
fill 330 54 -392 332 54 -392 minecraft:stone
fill 336 54 -392 339 54 -392 minecraft:stone
fill 331 54 -391 338 54 -391 minecraft:stone
fill 334 54 -390 339 54 -390 minecraft:stone
fill 337 54 -389 341 54 -389 minecraft:stone
fill 339 54 -388 344 54 -388 minecraft:stone
fill 340 54 -387 347 54 -387 minecraft:stone
fill 343 54 -386 349 54 -386 minecraft:stone
fill 370 55 -440 372 55 -440 minecraft:stone
fill 369 55 -439 371 55 -439 minecraft:stone
setblock 328 55 -434 minecraft:stone
fill 328 55 -433 329 55 -433 minecraft:stone
fill 328 55 -432 329 55 -432 minecraft:stone
fill 328 55 -431 330 55 -431 minecraft:stone
fill 328 55 -430 330 55 -430 minecraft:stone
fill 328 55 -429 331 55 -429 minecraft:stone
fill 328 55 -428 332 55 -428 minecraft:stone
fill 328 55 -427 332 55 -427 minecraft:stone
fill 328 55 -426 332 55 -426 minecraft:stone
fill 328 55 -425 331 55 -425 minecraft:stone
fill 328 55 -424 330 55 -424 minecraft:stone
setblock 354 55 -419 minecraft:stone
fill 354 55 -418 355 55 -418 minecraft:stone
fill 354 55 -417 355 55 -417 minecraft:stone
fill 354 55 -416 355 55 -416 minecraft:stone
fill 355 55 -415 356 55 -415 minecraft:stone
fill 356 55 -414 357 55 -414 minecraft:stone
setblock 349 55 -397 minecraft:stone
fill 347 55 -396 350 55 -396 minecraft:stone
fill 342 55 -395 352 55 -395 minecraft:stone
fill 385 55 -395 388 55 -395 minecraft:stone
fill 335 55 -394 349 55 -394 minecraft:stone
fill 385 55 -394 389 55 -394 minecraft:stone
fill 330 55 -393 332 55 -393 minecraft:stone
fill 335 55 -393 346 55 -393 minecraft:stone
fill 386 55 -393 389 55 -393 minecraft:stone
fill 330 55 -392 333 55 -392 minecraft:stone
fill 335 55 -392 341 55 -392 minecraft:stone
fill 388 55 -392 389 55 -392 minecraft:stone
fill 331 55 -391 339 55 -391 minecraft:stone
fill 332 55 -390 340 55 -390 minecraft:stone
fill 336 55 -389 342 55 -389 minecraft:stone
fill 339 55 -388 345 55 -388 minecraft:stone
fill 340 55 -387 351 55 -387 minecraft:stone
fill 342 55 -386 352 55 -386 minecraft:stone
fill 345 55 -385 351 55 -385 minecraft:stone
fill 370 56 -440 372 56 -440 minecraft:stone
fill 369 56 -439 371 56 -439 minecraft:stone
setblock 371 56 -438 minecraft:stone
setblock 328 56 -434 minecraft:stone
setblock 328 56 -433 minecraft:stone
fill 328 56 -432 329 56 -432 minecraft:stone
fill 328 56 -431 330 56 -431 minecraft:stone
fill 328 56 -430 330 56 -430 minecraft:stone
fill 328 56 -429 331 56 -429 minecraft:stone
fill 328 56 -428 332 56 -428 minecraft:stone
fill 328 56 -427 332 56 -427 minecraft:stone
fill 328 56 -426 332 56 -426 minecraft:stone
fill 328 56 -425 332 56 -425 minecraft:stone
fill 328 56 -424 331 56 -424 minecraft:stone
setblock 328 56 -423 minecraft:stone
fill 353 56 -422 354 56 -422 minecraft:stone
fill 352 56 -421 353 56 -421 minecraft:stone
setblock 351 56 -420 minecraft:stone
fill 353 56 -418 354 56 -418 minecraft:stone
fill 352 56 -417 355 56 -417 minecraft:stone
fill 353 56 -416 356 56 -416 minecraft:stone
fill 353 56 -415 356 56 -415 minecraft:stone
fill 354 56 -414 357 56 -414 minecraft:stone
fill 354 56 -413 358 56 -413 minecraft:stone
fill 355 56 -412 358 56 -412 minecraft:stone
fill 355 56 -411 359 56 -411 minecraft:stone
fill 350 56 -397 351 56 -397 minecraft:stone
fill 348 56 -396 352 56 -396 minecraft:stone
fill 344 56 -395 353 56 -395 minecraft:stone
fill 335 56 -394 351 56 -394 minecraft:stone
fill 386 56 -394 389 56 -394 minecraft:stone
fill 335 56 -393 347 56 -393 minecraft:stone
fill 387 56 -393 390 56 -393 minecraft:stone
fill 331 56 -392 342 56 -392 minecraft:stone
fill 388 56 -392 391 56 -392 minecraft:stone
fill 331 56 -391 338 56 -391 minecraft:stone
fill 389 56 -391 391 56 -391 minecraft:stone
fill 332 56 -390 339 56 -390 minecraft:stone
fill 336 56 -389 341 56 -389 minecraft:stone
fill 339 56 -388 345 56 -388 minecraft:stone
fill 341 56 -387 353 56 -387 minecraft:stone
fill 343 56 -386 354 56 -386 minecraft:stone
fill 382 56 -386 390 56 -386 minecraft:stone
fill 346 56 -385 352 56 -385 minecraft:stone
fill 380 56 -385 391 56 -385 minecraft:stone
fill 380 56 -384 391 56 -384 minecraft:stone
fill 380 56 -383 391 56 -383 minecraft:stone
fill 370 57 -440 372 57 -440 minecraft:stone
fill 369 57 -439 371 57 -439 minecraft:stone
fill 369 57 -438 370 57 -438 minecraft:stone
setblock 328 57 -433 minecraft:stone
setblock 328 57 -432 minecraft:stone
fill 328 57 -431 329 57 -431 minecraft:stone
fill 328 57 -430 330 57 -430 minecraft:stone
fill 328 57 -429 331 57 -429 minecraft:stone
fill 328 57 -428 332 57 -428 minecraft:stone
fill 328 57 -427 332 57 -427 minecraft:stone
fill 328 57 -426 333 57 -426 minecraft:stone
setblock 354 57 -426 minecraft:stone
fill 328 57 -425 333 57 -425 minecraft:stone
fill 353 57 -425 354 57 -425 minecraft:stone
fill 328 57 -424 334 57 -424 minecraft:stone
fill 352 57 -424 354 57 -424 minecraft:stone
fill 328 57 -423 333 57 -423 minecraft:stone
fill 351 57 -423 354 57 -423 minecraft:stone
fill 329 57 -422 332 57 -422 minecraft:stone
fill 352 57 -422 355 57 -422 minecraft:stone
fill 352 57 -421 355 57 -421 minecraft:stone
fill 352 57 -420 354 57 -420 minecraft:stone
setblock 353 57 -419 minecraft:stone
fill 355 57 -417 356 57 -417 minecraft:stone
fill 354 57 -416 357 57 -416 minecraft:stone
fill 354 57 -415 358 57 -415 minecraft:stone
fill 355 57 -414 358 57 -414 minecraft:stone
fill 355 57 -413 359 57 -413 minecraft:stone
fill 356 57 -412 359 57 -412 minecraft:stone
fill 356 57 -411 360 57 -411 minecraft:stone
fill 357 57 -410 358 57 -410 minecraft:stone
fill 350 57 -396 352 57 -396 minecraft:stone
fill 329 57 -395 330 57 -395 minecraft:stone
fill 347 57 -395 353 57 -395 minecraft:stone
fill 332 57 -394 333 57 -394 minecraft:stone
fill 336 57 -394 354 57 -394 minecraft:stone
setblock 388 57 -394 minecraft:stone
fill 335 57 -393 350 57 -393 minecraft:stone
fill 388 57 -393 390 57 -393 minecraft:stone
fill 335 57 -392 346 57 -392 minecraft:stone
setblock 360 57 -392 minecraft:stone
fill 388 57 -392 391 57 -392 minecraft:stone
fill 334 57 -391 336 57 -391 minecraft:stone
fill 360 57 -391 361 57 -391 minecraft:stone
fill 389 57 -391 391 57 -391 minecraft:stone
fill 334 57 -390 337 57 -390 minecraft:stone
fill 362 57 -390 363 57 -390 minecraft:stone
fill 390 57 -390 391 57 -390 minecraft:stone
fill 361 57 -389 364 57 -389 minecraft:stone
fill 384 57 -389 388 57 -389 minecraft:stone
fill 390 57 -389 391 57 -389 minecraft:stone
fill 362 57 -388 365 57 -388 minecraft:stone
fill 380 57 -388 391 57 -388 minecraft:stone
fill 344 57 -387 355 57 -387 minecraft:stone
fill 363 57 -387 366 57 -387 minecraft:stone
fill 380 57 -387 391 57 -387 minecraft:stone
fill 345 57 -386 355 57 -386 minecraft:stone
fill 363 57 -386 368 57 -386 minecraft:stone
fill 380 57 -386 391 57 -386 minecraft:stone
fill 348 57 -385 354 57 -385 minecraft:stone
fill 365 57 -385 368 57 -385 minecraft:stone
fill 380 57 -385 391 57 -385 minecraft:stone
fill 365 57 -384 367 57 -384 minecraft:stone
setblock 369 57 -384 minecraft:stone
fill 379 57 -384 391 57 -384 minecraft:stone
fill 366 57 -383 367 57 -383 minecraft:stone
setblock 369 57 -383 minecraft:stone
fill 379 57 -383 391 57 -383 minecraft:stone
setblock 370 58 -441 minecraft:stone
fill 370 58 -440 372 58 -440 minecraft:stone
fill 369 58 -439 371 58 -439 minecraft:stone
fill 369 58 -438 370 58 -438 minecraft:stone
setblock 328 58 -432 minecraft:stone
fill 328 58 -431 329 58 -431 minecraft:stone
fill 328 58 -430 330 58 -430 minecraft:stone
fill 328 58 -429 331 58 -429 minecraft:stone
fill 328 58 -428 332 58 -428 minecraft:stone
fill 328 58 -427 332 58 -427 minecraft:stone
fill 354 58 -427 355 58 -427 minecraft:stone
fill 328 58 -426 333 58 -426 minecraft:stone
fill 353 58 -426 355 58 -426 minecraft:stone
fill 328 58 -425 334 58 -425 minecraft:stone
fill 352 58 -425 355 58 -425 minecraft:stone
fill 328 58 -424 335 58 -424 minecraft:stone
fill 352 58 -424 356 58 -424 minecraft:stone
fill 328 58 -423 334 58 -423 minecraft:stone
fill 352 58 -423 355 58 -423 minecraft:stone
fill 328 58 -422 334 58 -422 minecraft:stone
fill 353 58 -422 356 58 -422 minecraft:stone
fill 331 58 -421 333 58 -421 minecraft:stone
fill 353 58 -421 356 58 -421 minecraft:stone
setblock 332 58 -420 minecraft:stone
fill 353 58 -420 356 58 -420 minecraft:stone
setblock 354 58 -419 minecraft:stone
setblock 357 58 -418 minecraft:stone
fill 355 58 -417 358 58 -417 minecraft:stone
fill 355 58 -416 358 58 -416 minecraft:stone
fill 356 58 -415 359 58 -415 minecraft:stone
fill 356 58 -414 359 58 -414 minecraft:stone
fill 357 58 -413 360 58 -413 minecraft:stone
fill 357 58 -412 360 58 -412 minecraft:stone
fill 358 58 -411 361 58 -411 minecraft:stone
fill 358 58 -410 361 58 -410 minecraft:stone
fill 364 58 -402 365 58 -402 minecraft:stone
fill 363 58 -401 365 58 -401 minecraft:stone
fill 362 58 -400 364 58 -400 minecraft:stone
fill 362 58 -399 363 58 -399 minecraft:stone
fill 361 58 -398 362 58 -398 minecraft:stone
fill 361 58 -397 362 58 -397 minecraft:stone
fill 361 58 -396 362 58 -396 minecraft:stone
fill 329 58 -395 330 58 -395 minecraft:stone
fill 350 58 -395 353 58 -395 minecraft:stone
setblock 360 58 -395 minecraft:stone
fill 328 58 -394 333 58 -394 minecraft:stone
fill 345 58 -394 354 58 -394 minecraft:stone
fill 359 58 -394 361 58 -394 minecraft:stone
fill 331 58 -393 332 58 -393 minecraft:stone
fill 335 58 -393 353 58 -393 minecraft:stone
fill 359 58 -393 361 58 -393 minecraft:stone
fill 389 58 -393 390 58 -393 minecraft:stone
fill 335 58 -392 349 58 -392 minecraft:stone
fill 358 58 -392 362 58 -392 minecraft:stone
fill 389 58 -392 391 58 -392 minecraft:stone
fill 336 58 -391 339 58 -391 minecraft:stone
fill 358 58 -391 363 58 -391 minecraft:stone
fill 386 58 -391 391 58 -391 minecraft:stone
fill 357 58 -390 364 58 -390 minecraft:stone
fill 382 58 -390 391 58 -390 minecraft:stone
fill 356 58 -389 358 58 -389 minecraft:stone
fill 360 58 -389 365 58 -389 minecraft:stone
fill 380 58 -389 391 58 -389 minecraft:stone
fill 354 58 -388 357 58 -388 minecraft:stone
fill 361 58 -388 366 58 -388 minecraft:stone
fill 380 58 -388 391 58 -388 minecraft:stone
fill 351 58 -387 356 58 -387 minecraft:stone
fill 362 58 -387 367 58 -387 minecraft:stone
fill 380 58 -387 391 58 -387 minecraft:stone
fill 350 58 -386 355 58 -386 minecraft:stone
fill 363 58 -386 368 58 -386 minecraft:stone
fill 379 58 -386 391 58 -386 minecraft:stone
fill 351 58 -385 354 58 -385 minecraft:stone
fill 364 58 -385 369 58 -385 minecraft:stone
fill 379 58 -385 391 58 -385 minecraft:stone
fill 365 58 -384 370 58 -384 minecraft:stone
fill 378 58 -384 391 58 -384 minecraft:stone
fill 366 58 -383 370 58 -383 minecraft:stone
fill 377 58 -383 391 58 -383 minecraft:stone
fill 370 59 -440 372 59 -440 minecraft:stone
setblock 368 59 -439 minecraft:stone
fill 370 59 -439 371 59 -439 minecraft:stone
setblock 367 59 -438 minecraft:stone
setblock 370 59 -438 minecraft:stone
setblock 328 59 -432 minecraft:stone
fill 328 59 -431 329 59 -431 minecraft:stone
fill 328 59 -430 330 59 -430 minecraft:stone
fill 328 59 -429 331 59 -429 minecraft:stone
fill 354 59 -429 355 59 -429 minecraft:stone
fill 328 59 -428 332 59 -428 minecraft:stone
fill 353 59 -428 356 59 -428 minecraft:stone
fill 328 59 -427 332 59 -427 minecraft:stone
fill 352 59 -427 356 59 -427 minecraft:stone
fill 328 59 -426 333 59 -426 minecraft:stone
fill 352 59 -426 356 59 -426 minecraft:stone
fill 328 59 -425 334 59 -425 minecraft:stone
fill 353 59 -425 356 59 -425 minecraft:stone
fill 328 59 -424 335 59 -424 minecraft:stone
fill 353 59 -424 356 59 -424 minecraft:stone
fill 328 59 -423 335 59 -423 minecraft:stone
fill 353 59 -423 356 59 -423 minecraft:stone
fill 328 59 -422 335 59 -422 minecraft:stone
fill 354 59 -422 355 59 -422 minecraft:stone
fill 330 59 -421 334 59 -421 minecraft:stone
fill 354 59 -421 355 59 -421 minecraft:stone
fill 331 59 -420 334 59 -420 minecraft:stone
fill 354 59 -420 355 59 -420 minecraft:stone
setblock 332 59 -419 minecraft:stone
fill 357 59 -418 358 59 -418 minecraft:stone
fill 356 59 -417 359 59 -417 minecraft:stone
fill 356 59 -416 359 59 -416 minecraft:stone
fill 357 59 -415 360 59 -415 minecraft:stone
fill 357 59 -414 360 59 -414 minecraft:stone
fill 358 59 -413 361 59 -413 minecraft:stone
fill 358 59 -412 362 59 -412 minecraft:stone
fill 359 59 -411 362 59 -411 minecraft:stone
fill 359 59 -410 362 59 -410 minecraft:stone
fill 364 59 -403 367 59 -403 minecraft:stone
fill 363 59 -402 367 59 -402 minecraft:stone
fill 362 59 -401 367 59 -401 minecraft:stone
fill 362 59 -400 365 59 -400 minecraft:stone
fill 361 59 -399 364 59 -399 minecraft:stone
fill 361 59 -398 363 59 -398 minecraft:stone
fill 360 59 -397 363 59 -397 minecraft:stone
fill 360 59 -396 363 59 -396 minecraft:stone
fill 328 59 -395 329 59 -395 minecraft:stone
setblock 353 59 -395 minecraft:stone
fill 359 59 -395 362 59 -395 minecraft:stone
fill 328 59 -394 333 59 -394 minecraft:stone
fill 349 59 -394 354 59 -394 minecraft:stone
fill 359 59 -394 362 59 -394 minecraft:stone
fill 328 59 -393 332 59 -393 minecraft:stone
setblock 335 59 -393 minecraft:stone
fill 343 59 -393 355 59 -393 minecraft:stone
fill 358 59 -393 361 59 -393 minecraft:stone
fill 330 59 -392 331 59 -392 minecraft:stone
fill 334 59 -392 336 59 -392 minecraft:stone
fill 344 59 -392 353 59 -392 minecraft:stone
fill 358 59 -392 362 59 -392 minecraft:stone
fill 383 59 -392 391 59 -392 minecraft:stone
fill 335 59 -391 337 59 -391 minecraft:stone
fill 345 59 -391 348 59 -391 minecraft:stone
fill 357 59 -391 364 59 -391 minecraft:stone
fill 380 59 -391 391 59 -391 minecraft:stone
fill 356 59 -390 364 59 -390 minecraft:stone
fill 380 59 -390 391 59 -390 minecraft:stone
fill 355 59 -389 365 59 -389 minecraft:stone
fill 380 59 -389 391 59 -389 minecraft:stone
fill 354 59 -388 358 59 -388 minecraft:stone
fill 360 59 -388 366 59 -388 minecraft:stone
fill 379 59 -388 391 59 -388 minecraft:stone
fill 353 59 -387 357 59 -387 minecraft:stone
fill 361 59 -387 368 59 -387 minecraft:stone
fill 379 59 -387 391 59 -387 minecraft:stone
fill 352 59 -386 356 59 -386 minecraft:stone
fill 362 59 -386 369 59 -386 minecraft:stone
fill 379 59 -386 391 59 -386 minecraft:stone
fill 363 59 -385 369 59 -385 minecraft:stone
fill 378 59 -385 391 59 -385 minecraft:stone
fill 364 59 -384 370 59 -384 minecraft:stone
fill 377 59 -384 391 59 -384 minecraft:stone
fill 365 59 -383 370 59 -383 minecraft:stone
fill 376 59 -383 391 59 -383 minecraft:stone
fill 370 60 -440 372 60 -440 minecraft:stone
setblock 368 60 -439 minecraft:stone
fill 370 60 -439 371 60 -439 minecraft:stone
fill 367 60 -438 368 60 -438 minecraft:stone
setblock 328 60 -432 minecraft:stone
fill 328 60 -431 329 60 -431 minecraft:stone
setblock 356 60 -431 minecraft:stone
fill 328 60 -430 330 60 -430 minecraft:stone
fill 354 60 -430 357 60 -430 minecraft:stone
fill 328 60 -429 331 60 -429 minecraft:stone
fill 353 60 -429 357 60 -429 minecraft:stone
fill 328 60 -428 332 60 -428 minecraft:stone
fill 353 60 -428 357 60 -428 minecraft:stone
fill 328 60 -427 332 60 -427 minecraft:stone
fill 353 60 -427 356 60 -427 minecraft:stone
fill 328 60 -426 333 60 -426 minecraft:stone
fill 354 60 -426 356 60 -426 minecraft:stone
fill 328 60 -425 334 60 -425 minecraft:stone
fill 354 60 -425 355 60 -425 minecraft:stone
fill 328 60 -424 335 60 -424 minecraft:stone
fill 328 60 -423 335 60 -423 minecraft:stone
fill 328 60 -422 335 60 -422 minecraft:stone
fill 329 60 -421 335 60 -421 minecraft:stone
fill 331 60 -420 335 60 -420 minecraft:stone
fill 332 60 -419 333 60 -419 minecraft:stone
setblock 332 60 -418 minecraft:stone
fill 357 60 -416 360 60 -416 minecraft:stone
fill 358 60 -415 361 60 -415 minecraft:stone
fill 358 60 -414 362 60 -414 minecraft:stone
fill 359 60 -413 362 60 -413 minecraft:stone
fill 360 60 -412 363 60 -412 minecraft:stone
fill 360 60 -411 364 60 -411 minecraft:stone
fill 361 60 -410 362 60 -410 minecraft:stone
fill 364 60 -403 369 60 -403 minecraft:stone
fill 363 60 -402 369 60 -402 minecraft:stone
fill 362 60 -401 368 60 -401 minecraft:stone
fill 361 60 -400 365 60 -400 minecraft:stone
fill 361 60 -399 364 60 -399 minecraft:stone
fill 360 60 -398 364 60 -398 minecraft:stone
fill 360 60 -397 363 60 -397 minecraft:stone
fill 360 60 -396 363 60 -396 minecraft:stone
setblock 328 60 -395 minecraft:stone
fill 359 60 -395 362 60 -395 minecraft:stone
fill 328 60 -394 331 60 -394 minecraft:stone
fill 352 60 -394 353 60 -394 minecraft:stone
fill 359 60 -394 362 60 -394 minecraft:stone
fill 328 60 -393 332 60 -393 minecraft:stone
fill 346 60 -393 354 60 -393 minecraft:stone
fill 358 60 -393 362 60 -393 minecraft:stone
fill 330 60 -392 331 60 -392 minecraft:stone
setblock 334 60 -392 minecraft:stone
fill 345 60 -392 355 60 -392 minecraft:stone
fill 358 60 -392 363 60 -392 minecraft:stone
fill 380 60 -392 391 60 -392 minecraft:stone
setblock 334 60 -391 minecraft:stone
fill 346 60 -391 353 60 -391 minecraft:stone
fill 357 60 -391 364 60 -391 minecraft:stone
fill 380 60 -391 391 60 -391 minecraft:stone
fill 356 60 -390 365 60 -390 minecraft:stone
fill 379 60 -390 391 60 -390 minecraft:stone
fill 356 60 -389 365 60 -389 minecraft:stone
fill 379 60 -389 391 60 -389 minecraft:stone
fill 355 60 -388 358 60 -388 minecraft:stone
fill 360 60 -388 366 60 -388 minecraft:stone
fill 379 60 -388 391 60 -388 minecraft:stone
fill 354 60 -387 357 60 -387 minecraft:stone
fill 361 60 -387 367 60 -387 minecraft:stone
fill 378 60 -387 391 60 -387 minecraft:stone
setblock 354 60 -386 minecraft:stone
fill 362 60 -386 368 60 -386 minecraft:stone
fill 378 60 -386 391 60 -386 minecraft:stone
fill 363 60 -385 369 60 -385 minecraft:stone
fill 377 60 -385 391 60 -385 minecraft:stone
fill 365 60 -384 370 60 -384 minecraft:stone
fill 376 60 -384 391 60 -384 minecraft:stone
fill 365 60 -383 371 60 -383 minecraft:stone
fill 375 60 -383 391 60 -383 minecraft:stone
fill 370 61 -440 371 61 -440 minecraft:stone
setblock 367 61 -439 minecraft:stone
fill 370 61 -439 371 61 -439 minecraft:stone
fill 366 61 -438 368 61 -438 minecraft:stone
setblock 368 61 -437 minecraft:stone
setblock 358 61 -433 minecraft:stone
setblock 328 61 -432 minecraft:stone
fill 356 61 -432 358 61 -432 minecraft:stone
fill 328 61 -431 329 61 -431 minecraft:stone
fill 354 61 -431 358 61 -431 minecraft:stone
fill 328 61 -430 329 61 -430 minecraft:stone
fill 353 61 -430 358 61 -430 minecraft:stone
fill 328 61 -429 330 61 -429 minecraft:stone
fill 354 61 -429 357 61 -429 minecraft:stone
fill 328 61 -428 331 61 -428 minecraft:stone
fill 354 61 -428 355 61 -428 minecraft:stone
fill 328 61 -427 332 61 -427 minecraft:stone
setblock 354 61 -427 minecraft:stone
fill 328 61 -426 333 61 -426 minecraft:stone
fill 328 61 -425 334 61 -425 minecraft:stone
fill 328 61 -424 335 61 -424 minecraft:stone
fill 328 61 -423 336 61 -423 minecraft:stone
fill 328 61 -422 336 61 -422 minecraft:stone
fill 329 61 -421 336 61 -421 minecraft:stone
fill 330 61 -420 336 61 -420 minecraft:stone
fill 331 61 -419 334 61 -419 minecraft:stone
fill 332 61 -418 333 61 -418 minecraft:stone
setblock 332 61 -417 minecraft:stone
fill 359 61 -415 362 61 -415 minecraft:stone
fill 359 61 -414 363 61 -414 minecraft:stone
fill 360 61 -413 363 61 -413 minecraft:stone
fill 361 61 -412 364 61 -412 minecraft:stone
fill 361 61 -411 365 61 -411 minecraft:stone
setblock 362 61 -410 minecraft:stone
fill 364 61 -403 370 61 -403 minecraft:stone
fill 364 61 -402 370 61 -402 minecraft:stone
fill 362 61 -401 369 61 -401 minecraft:stone
fill 362 61 -400 365 61 -400 minecraft:stone
fill 362 61 -399 364 61 -399 minecraft:stone
fill 361 61 -398 363 61 -398 minecraft:stone
fill 361 61 -397 363 61 -397 minecraft:stone
setblock 371 61 -397 minecraft:stone
fill 361 61 -396 363 61 -396 minecraft:stone
fill 371 61 -396 372 61 -396 minecraft:stone
fill 360 61 -395 362 61 -395 minecraft:stone
fill 328 61 -394 330 61 -394 minecraft:stone
fill 359 61 -394 361 61 -394 minecraft:stone
fill 328 61 -393 331 61 -393 minecraft:stone
fill 352 61 -393 354 61 -393 minecraft:stone
fill 358 61 -393 362 61 -393 minecraft:stone
fill 382 61 -393 391 61 -393 minecraft:stone
fill 330 61 -392 331 61 -392 minecraft:stone
fill 346 61 -392 354 61 -392 minecraft:stone
fill 358 61 -392 362 61 -392 minecraft:stone
fill 379 61 -392 391 61 -392 minecraft:stone
setblock 333 61 -391 minecraft:stone
fill 346 61 -391 356 61 -391 minecraft:stone
fill 358 61 -391 364 61 -391 minecraft:stone
fill 379 61 -391 391 61 -391 minecraft:stone
fill 347 61 -390 351 61 -390 minecraft:stone
fill 357 61 -390 364 61 -390 minecraft:stone
fill 378 61 -390 391 61 -390 minecraft:stone
fill 356 61 -389 365 61 -389 minecraft:stone
fill 378 61 -389 391 61 -389 minecraft:stone
fill 356 61 -388 357 61 -388 minecraft:stone
fill 360 61 -388 366 61 -388 minecraft:stone
fill 378 61 -388 391 61 -388 minecraft:stone
fill 361 61 -387 367 61 -387 minecraft:stone
fill 378 61 -387 391 61 -387 minecraft:stone
fill 362 61 -386 368 61 -386 minecraft:stone
fill 377 61 -386 391 61 -386 minecraft:stone
fill 364 61 -385 369 61 -385 minecraft:stone
fill 376 61 -385 391 61 -385 minecraft:stone
fill 365 61 -384 370 61 -384 minecraft:stone
fill 375 61 -384 391 61 -384 minecraft:stone
fill 366 61 -383 371 61 -383 minecraft:stone
fill 373 61 -383 391 61 -383 minecraft:stone
setblock 369 62 -441 minecraft:dirt
fill 369 62 -440 371 62 -440 minecraft:dirt
setblock 367 62 -439 minecraft:dirt
setblock 370 62 -439 minecraft:dirt
fill 365 62 -438 367 62 -438 minecraft:dirt
fill 364 62 -437 368 62 -437 minecraft:dirt
fill 358 62 -434 359 62 -434 minecraft:dirt
fill 356 62 -433 360 62 -433 minecraft:dirt
setblock 328 62 -432 minecraft:dirt
fill 354 62 -432 359 62 -432 minecraft:dirt
setblock 328 62 -431 minecraft:dirt
fill 354 62 -431 358 62 -431 minecraft:dirt
fill 328 62 -430 329 62 -430 minecraft:dirt
fill 354 62 -430 357 62 -430 minecraft:dirt
fill 328 62 -429 330 62 -429 minecraft:dirt
setblock 355 62 -429 minecraft:dirt
fill 328 62 -428 331 62 -428 minecraft:dirt
fill 328 62 -427 332 62 -427 minecraft:dirt
fill 328 62 -426 333 62 -426 minecraft:dirt
fill 328 62 -425 334 62 -425 minecraft:dirt
fill 328 62 -424 336 62 -424 minecraft:dirt
fill 328 62 -423 336 62 -423 minecraft:dirt
fill 328 62 -422 336 62 -422 minecraft:dirt
fill 329 62 -421 336 62 -421 minecraft:dirt
fill 330 62 -420 337 62 -420 minecraft:dirt
fill 331 62 -419 335 62 -419 minecraft:dirt
fill 332 62 -418 333 62 -418 minecraft:dirt
setblock 332 62 -417 minecraft:dirt
fill 362 62 -415 363 62 -415 minecraft:dirt
fill 361 62 -414 364 62 -414 minecraft:dirt
fill 361 62 -413 365 62 -413 minecraft:dirt
fill 362 62 -412 365 62 -412 minecraft:dirt
fill 363 62 -411 365 62 -411 minecraft:dirt
setblock 363 62 -410 minecraft:dirt
fill 368 62 -404 371 62 -404 minecraft:dirt
fill 366 62 -403 371 62 -403 minecraft:dirt
fill 364 62 -402 371 62 -402 minecraft:dirt
fill 364 62 -401 370 62 -401 minecraft:dirt
setblock 363 62 -400 minecraft:dirt
fill 362 62 -399 363 62 -399 minecraft:dirt
fill 367 62 -399 369 62 -399 minecraft:dirt
setblock 362 62 -398 minecraft:dirt
fill 368 62 -398 371 62 -398 minecraft:dirt
setblock 362 62 -397 minecraft:dirt
fill 369 62 -397 372 62 -397 minecraft:dirt
fill 370 62 -396 373 62 -396 minecraft:dirt
fill 371 62 -395 374 62 -395 minecraft:dirt
setblock 328 62 -394 minecraft:dirt
setblock 360 62 -394 minecraft:dirt
fill 373 62 -394 375 62 -394 minecraft:dirt
fill 384 62 -394 391 62 -394 minecraft:dirt
fill 328 62 -393 329 62 -393 minecraft:dirt
fill 359 62 -393 361 62 -393 minecraft:dirt
fill 374 62 -393 375 62 -393 minecraft:dirt
fill 378 62 -393 391 62 -393 minecraft:dirt
setblock 330 62 -392 minecraft:dirt
fill 350 62 -392 354 62 -392 minecraft:dirt
fill 358 62 -392 362 62 -392 minecraft:dirt
fill 377 62 -392 391 62 -392 minecraft:dirt
fill 347 62 -391 355 62 -391 minecraft:dirt
fill 358 62 -391 363 62 -391 minecraft:dirt
fill 377 62 -391 391 62 -391 minecraft:dirt
fill 348 62 -390 357 62 -390 minecraft:dirt
fill 359 62 -390 364 62 -390 minecraft:dirt
fill 377 62 -390 391 62 -390 minecraft:dirt
fill 360 62 -389 364 62 -389 minecraft:dirt
fill 377 62 -389 391 62 -389 minecraft:dirt
fill 361 62 -388 365 62 -388 minecraft:dirt
fill 377 62 -388 391 62 -388 minecraft:dirt
fill 362 62 -387 365 62 -387 minecraft:dirt
fill 377 62 -387 391 62 -387 minecraft:dirt
fill 363 62 -386 367 62 -386 minecraft:dirt
fill 375 62 -386 391 62 -386 minecraft:dirt
fill 366 62 -385 368 62 -385 minecraft:dirt
fill 374 62 -385 391 62 -385 minecraft:dirt
fill 366 62 -384 369 62 -384 minecraft:dirt
fill 373 62 -384 391 62 -384 minecraft:dirt
fill 367 62 -383 391 62 -383 minecraft:dirt
setblock 340 63 -446 minecraft:dirt
setblock 344 63 -446 minecraft:dirt
setblock 350 63 -446 minecraft:dirt
fill 354 63 -446 355 63 -446 minecraft:dirt
setblock 358 63 -446 minecraft:dirt
setblock 363 63 -446 minecraft:dirt
setblock 371 63 -446 minecraft:dirt
setblock 381 63 -446 minecraft:dirt
setblock 385 63 -446 minecraft:dirt
setblock 333 63 -445 minecraft:dirt
fill 335 63 -445 336 63 -445 minecraft:dirt
setblock 349 63 -445 minecraft:dirt
setblock 353 63 -445 minecraft:dirt
fill 357 63 -445 359 63 -445 minecraft:dirt
setblock 363 63 -445 minecraft:dirt
fill 365 63 -445 366 63 -445 minecraft:dirt
setblock 368 63 -445 minecraft:dirt
setblock 373 63 -445 minecraft:dirt
setblock 377 63 -445 minecraft:dirt
setblock 384 63 -445 minecraft:dirt
fill 390 63 -445 391 63 -445 minecraft:dirt
setblock 337 63 -444 minecraft:dirt
setblock 341 63 -444 minecraft:dirt
setblock 344 63 -444 minecraft:dirt
fill 348 63 -444 349 63 -444 minecraft:dirt
setblock 354 63 -444 minecraft:dirt
setblock 359 63 -444 minecraft:dirt
setblock 362 63 -444 minecraft:dirt
setblock 367 63 -444 minecraft:dirt
setblock 369 63 -444 minecraft:dirt
setblock 372 63 -444 minecraft:dirt
fill 376 63 -444 377 63 -444 minecraft:dirt
setblock 380 63 -444 minecraft:dirt
fill 389 63 -444 391 63 -444 minecraft:dirt
fill 334 63 -443 335 63 -443 minecraft:dirt
setblock 338 63 -443 minecraft:dirt
fill 349 63 -443 350 63 -443 minecraft:dirt
setblock 352 63 -443 minecraft:dirt
setblock 356 63 -443 minecraft:dirt
fill 360 63 -443 363 63 -443 minecraft:dirt
setblock 366 63 -443 minecraft:dirt
setblock 368 63 -443 minecraft:dirt
setblock 371 63 -443 minecraft:dirt
setblock 373 63 -443 minecraft:dirt
setblock 375 63 -443 minecraft:dirt
fill 377 63 -443 378 63 -443 minecraft:dirt
setblock 382 63 -443 minecraft:dirt
fill 390 63 -443 391 63 -443 minecraft:dirt
setblock 333 63 -442 minecraft:dirt
fill 338 63 -442 339 63 -442 minecraft:dirt
setblock 341 63 -442 minecraft:dirt
fill 348 63 -442 351 63 -442 minecraft:dirt
fill 355 63 -442 356 63 -442 minecraft:dirt
fill 360 63 -442 361 63 -442 minecraft:dirt
setblock 364 63 -442 minecraft:dirt
setblock 368 63 -442 minecraft:dirt
setblock 372 63 -442 minecraft:dirt
fill 378 63 -442 380 63 -442 minecraft:dirt
fill 390 63 -442 391 63 -442 minecraft:dirt
setblock 369 63 -441 minecraft:dirt
setblock 391 63 -441 minecraft:dirt
fill 368 63 -440 370 63 -440 minecraft:dirt
fill 366 63 -439 370 63 -439 minecraft:dirt
fill 365 63 -438 369 63 -438 minecraft:dirt
fill 363 63 -437 367 63 -437 minecraft:dirt
fill 361 63 -436 363 63 -436 minecraft:dirt
fill 365 63 -436 366 63 -436 minecraft:dirt
fill 359 63 -435 362 63 -435 minecraft:dirt
fill 357 63 -434 361 63 -434 minecraft:dirt
fill 355 63 -433 360 63 -433 minecraft:dirt
setblock 328 63 -432 minecraft:dirt
fill 355 63 -432 358 63 -432 minecraft:dirt
setblock 328 63 -431 minecraft:dirt
fill 355 63 -431 357 63 -431 minecraft:dirt
fill 328 63 -430 329 63 -430 minecraft:dirt
setblock 355 63 -430 minecraft:dirt
fill 328 63 -429 330 63 -429 minecraft:dirt
fill 328 63 -428 331 63 -428 minecraft:dirt
fill 328 63 -427 332 63 -427 minecraft:dirt
fill 328 63 -426 334 63 -426 minecraft:dirt
fill 328 63 -425 335 63 -425 minecraft:dirt
fill 328 63 -424 336 63 -424 minecraft:dirt
fill 328 63 -423 336 63 -423 minecraft:dirt
fill 328 63 -422 336 63 -422 minecraft:dirt
fill 328 63 -421 337 63 -421 minecraft:dirt
fill 330 63 -420 338 63 -420 minecraft:dirt
fill 331 63 -419 335 63 -419 minecraft:dirt
fill 332 63 -418 334 63 -418 minecraft:dirt
setblock 332 63 -417 minecraft:dirt
setblock 364 63 -415 minecraft:dirt
fill 362 63 -414 365 63 -414 minecraft:dirt
fill 362 63 -413 366 63 -413 minecraft:dirt
fill 363 63 -412 366 63 -412 minecraft:dirt
fill 364 63 -411 365 63 -411 minecraft:dirt
setblock 391 63 -407 minecraft:dirt
fill 370 63 -405 371 63 -405 minecraft:dirt
fill 369 63 -404 371 63 -404 minecraft:dirt
setblock 391 63 -404 minecraft:dirt
fill 367 63 -403 371 63 -403 minecraft:dirt
setblock 391 63 -403 minecraft:dirt
fill 367 63 -402 371 63 -402 minecraft:dirt
fill 368 63 -401 370 63 -401 minecraft:dirt
fill 366 63 -400 368 63 -400 minecraft:dirt
fill 367 63 -399 369 63 -399 minecraft:dirt
fill 368 63 -398 371 63 -398 minecraft:dirt
fill 368 63 -397 372 63 -397 minecraft:dirt
fill 370 63 -396 373 63 -396 minecraft:dirt
setblock 375 63 -396 minecraft:dirt
setblock 381 63 -396 minecraft:dirt
fill 371 63 -395 375 63 -395 minecraft:dirt
fill 380 63 -395 382 63 -395 minecraft:dirt
setblock 391 63 -395 minecraft:dirt
fill 373 63 -394 377 63 -394 minecraft:dirt
setblock 380 63 -394 minecraft:dirt
setblock 382 63 -394 minecraft:dirt
fill 390 63 -394 391 63 -394 minecraft:dirt
fill 374 63 -393 381 63 -393 minecraft:dirt
fill 389 63 -393 391 63 -393 minecraft:dirt
setblock 329 63 -392 minecraft:dirt
fill 359 63 -392 361 63 -392 minecraft:dirt
fill 374 63 -392 375 63 -392 minecraft:dirt
fill 377 63 -392 381 63 -392 minecraft:dirt
fill 389 63 -392 391 63 -392 minecraft:dirt
fill 347 63 -391 355 63 -391 minecraft:dirt
fill 359 63 -391 362 63 -391 minecraft:dirt
fill 376 63 -391 380 63 -391 minecraft:dirt
fill 388 63 -391 391 63 -391 minecraft:dirt
fill 348 63 -390 356 63 -390 minecraft:dirt
fill 360 63 -390 362 63 -390 minecraft:dirt
fill 376 63 -390 380 63 -390 minecraft:dirt
fill 388 63 -390 391 63 -390 minecraft:dirt
fill 349 63 -389 357 63 -389 minecraft:dirt
fill 362 63 -389 363 63 -389 minecraft:dirt
fill 375 63 -389 379 63 -389 minecraft:dirt
fill 388 63 -389 391 63 -389 minecraft:dirt
fill 375 63 -388 379 63 -388 minecraft:dirt
fill 387 63 -388 391 63 -388 minecraft:dirt
fill 374 63 -387 379 63 -387 minecraft:dirt
fill 387 63 -387 391 63 -387 minecraft:dirt
fill 372 63 -386 379 63 -386 minecraft:dirt
fill 386 63 -386 391 63 -386 minecraft:dirt
fill 371 63 -385 379 63 -385 minecraft:dirt
fill 386 63 -385 391 63 -385 minecraft:dirt
fill 370 63 -384 378 63 -384 minecraft:dirt
fill 386 63 -384 391 63 -384 minecraft:dirt
fill 367 63 -383 378 63 -383 minecraft:dirt
fill 385 63 -383 391 63 -383 minecraft:dirt
fill 332 64 -446 386 64 -446 minecraft:dirt
fill 332 64 -445 391 64 -445 minecraft:dirt
fill 332 64 -444 391 64 -444 minecraft:dirt
fill 332 64 -443 391 64 -443 minecraft:dirt
fill 333 64 -442 386 64 -442 minecraft:dirt
fill 388 64 -442 391 64 -442 minecraft:dirt
setblock 369 64 -441 minecraft:dirt
fill 383 64 -441 391 64 -441 minecraft:dirt
fill 367 64 -440 370 64 -440 minecraft:dirt
fill 383 64 -440 391 64 -440 minecraft:dirt
fill 366 64 -439 370 64 -439 minecraft:dirt
fill 383 64 -439 391 64 -439 minecraft:dirt
fill 364 64 -438 368 64 -438 minecraft:dirt
fill 384 64 -438 391 64 -438 minecraft:dirt
fill 362 64 -437 367 64 -437 minecraft:dirt
fill 386 64 -437 391 64 -437 minecraft:dirt
fill 360 64 -436 365 64 -436 minecraft:dirt
fill 388 64 -436 391 64 -436 minecraft:dirt
fill 357 64 -435 363 64 -435 minecraft:dirt
fill 389 64 -435 391 64 -435 minecraft:dirt
fill 355 64 -434 361 64 -434 minecraft:dirt
fill 390 64 -434 391 64 -434 minecraft:dirt
fill 355 64 -433 359 64 -433 minecraft:dirt
fill 389 64 -433 391 64 -433 minecraft:dirt
fill 356 64 -432 357 64 -432 minecraft:dirt
fill 390 64 -432 391 64 -432 minecraft:dirt
setblock 328 64 -431 minecraft:dirt
setblock 391 64 -431 minecraft:dirt
fill 328 64 -430 329 64 -430 minecraft:dirt
setblock 391 64 -430 minecraft:dirt
fill 328 64 -429 330 64 -429 minecraft:dirt
setblock 391 64 -429 minecraft:dirt
fill 328 64 -428 331 64 -428 minecraft:dirt
setblock 391 64 -428 minecraft:dirt
fill 328 64 -427 332 64 -427 minecraft:dirt
fill 328 64 -426 334 64 -426 minecraft:dirt
fill 328 64 -425 335 64 -425 minecraft:dirt
fill 328 64 -424 336 64 -424 minecraft:dirt
fill 328 64 -423 336 64 -423 minecraft:dirt
fill 328 64 -422 336 64 -422 minecraft:dirt
fill 328 64 -421 337 64 -421 minecraft:dirt
fill 330 64 -420 338 64 -420 minecraft:dirt
fill 331 64 -419 336 64 -419 minecraft:dirt
fill 332 64 -418 334 64 -418 minecraft:dirt
fill 332 64 -417 333 64 -417 minecraft:dirt
setblock 332 64 -416 minecraft:dirt
fill 364 64 -415 365 64 -415 minecraft:dirt
fill 363 64 -414 366 64 -414 minecraft:dirt
fill 364 64 -413 367 64 -413 minecraft:dirt
fill 364 64 -412 367 64 -412 minecraft:dirt
setblock 365 64 -411 minecraft:dirt
setblock 391 64 -411 minecraft:dirt
setblock 391 64 -410 minecraft:dirt
fill 390 64 -409 391 64 -409 minecraft:dirt
fill 389 64 -408 391 64 -408 minecraft:dirt
fill 389 64 -407 391 64 -407 minecraft:dirt
fill 369 64 -406 371 64 -406 minecraft:dirt
fill 389 64 -406 391 64 -406 minecraft:dirt
fill 369 64 -405 372 64 -405 minecraft:dirt
fill 388 64 -405 391 64 -405 minecraft:dirt
fill 363 64 -404 364 64 -404 minecraft:dirt
fill 369 64 -404 372 64 -404 minecraft:dirt
fill 388 64 -404 391 64 -404 minecraft:dirt
fill 363 64 -403 364 64 -403 minecraft:dirt
fill 366 64 -403 372 64 -403 minecraft:dirt
fill 388 64 -403 391 64 -403 minecraft:dirt
setblock 356 64 -402 minecraft:dirt
fill 362 64 -402 366 64 -402 minecraft:dirt
fill 368 64 -402 371 64 -402 minecraft:dirt
fill 387 64 -402 391 64 -402 minecraft:dirt
setblock 356 64 -401 minecraft:dirt
fill 362 64 -401 367 64 -401 minecraft:dirt
setblock 370 64 -401 minecraft:dirt
fill 386 64 -401 391 64 -401 minecraft:dirt
fill 356 64 -400 357 64 -400 minecraft:dirt
fill 361 64 -400 372 64 -400 minecraft:dirt
fill 386 64 -400 391 64 -400 minecraft:dirt
fill 361 64 -399 377 64 -399 minecraft:dirt
fill 385 64 -399 391 64 -399 minecraft:dirt
setblock 361 64 -398 minecraft:dirt
fill 363 64 -398 366 64 -398 minecraft:dirt
fill 368 64 -398 377 64 -398 minecraft:dirt
fill 385 64 -398 391 64 -398 minecraft:dirt
fill 361 64 -397 377 64 -397 minecraft:dirt
fill 385 64 -397 391 64 -397 minecraft:dirt
fill 361 64 -396 367 64 -396 minecraft:dirt
fill 369 64 -396 377 64 -396 minecraft:dirt
fill 385 64 -396 391 64 -396 minecraft:dirt
fill 361 64 -395 377 64 -395 minecraft:dirt
fill 385 64 -395 391 64 -395 minecraft:dirt
fill 362 64 -394 377 64 -394 minecraft:dirt
fill 384 64 -394 391 64 -394 minecraft:dirt
fill 361 64 -393 377 64 -393 minecraft:dirt
fill 384 64 -393 391 64 -393 minecraft:dirt
fill 362 64 -392 377 64 -392 minecraft:dirt
fill 384 64 -392 391 64 -392 minecraft:dirt
fill 362 64 -391 374 64 -391 minecraft:dirt
setblock 376 64 -391 minecraft:dirt
fill 384 64 -391 391 64 -391 minecraft:dirt
fill 348 64 -390 355 64 -390 minecraft:dirt
fill 360 64 -390 361 64 -390 minecraft:dirt
fill 365 64 -390 376 64 -390 minecraft:dirt
fill 384 64 -390 391 64 -390 minecraft:dirt
fill 349 64 -389 357 64 -389 minecraft:dirt
fill 360 64 -389 361 64 -389 minecraft:dirt
setblock 366 64 -389 minecraft:dirt
fill 368 64 -389 377 64 -389 minecraft:dirt
fill 384 64 -389 391 64 -389 minecraft:dirt
fill 349 64 -388 356 64 -388 minecraft:dirt
fill 360 64 -388 361 64 -388 minecraft:dirt
fill 367 64 -388 376 64 -388 minecraft:dirt
fill 383 64 -388 391 64 -388 minecraft:dirt
fill 359 64 -387 363 64 -387 minecraft:dirt
fill 365 64 -387 376 64 -387 minecraft:dirt
fill 383 64 -387 391 64 -387 minecraft:dirt
fill 358 64 -386 376 64 -386 minecraft:dirt
fill 383 64 -386 391 64 -386 minecraft:dirt
fill 357 64 -385 376 64 -385 minecraft:dirt
fill 383 64 -385 391 64 -385 minecraft:dirt
fill 356 64 -384 376 64 -384 minecraft:dirt
fill 383 64 -384 391 64 -384 minecraft:dirt
fill 354 64 -383 356 64 -383 minecraft:dirt
fill 358 64 -383 364 64 -383 minecraft:dirt
fill 366 64 -383 375 64 -383 minecraft:dirt
fill 383 64 -383 391 64 -383 minecraft:dirt
fill 328 65 -446 386 65 -446 minecraft:light_gray_concrete
setblock 328 65 -445 minecraft:sea_lantern
fill 329 65 -445 336 65 -445 minecraft:light_gray_concrete
setblock 337 65 -445 minecraft:sea_lantern
fill 338 65 -445 345 65 -445 minecraft:light_gray_concrete
setblock 346 65 -445 minecraft:sea_lantern
fill 347 65 -445 354 65 -445 minecraft:light_gray_concrete
setblock 355 65 -445 minecraft:sea_lantern
fill 356 65 -445 363 65 -445 minecraft:light_gray_concrete
setblock 364 65 -445 minecraft:sea_lantern
fill 365 65 -445 372 65 -445 minecraft:light_gray_concrete
setblock 373 65 -445 minecraft:sea_lantern
fill 374 65 -445 381 65 -445 minecraft:light_gray_concrete
setblock 382 65 -445 minecraft:sea_lantern
fill 383 65 -445 391 65 -445 minecraft:light_gray_concrete
fill 328 65 -444 335 65 -444 minecraft:light_gray_concrete
setblock 336 65 -444 minecraft:sea_lantern
fill 337 65 -444 344 65 -444 minecraft:light_gray_concrete
setblock 345 65 -444 minecraft:sea_lantern
fill 346 65 -444 353 65 -444 minecraft:light_gray_concrete
setblock 354 65 -444 minecraft:sea_lantern
fill 355 65 -444 362 65 -444 minecraft:light_gray_concrete
setblock 363 65 -444 minecraft:sea_lantern
fill 364 65 -444 371 65 -444 minecraft:light_gray_concrete
setblock 372 65 -444 minecraft:sea_lantern
fill 373 65 -444 380 65 -444 minecraft:light_gray_concrete
setblock 381 65 -444 minecraft:sea_lantern
fill 382 65 -444 389 65 -444 minecraft:light_gray_concrete
setblock 390 65 -444 minecraft:sea_lantern
setblock 391 65 -444 minecraft:light_gray_concrete
fill 328 65 -443 334 65 -443 minecraft:light_gray_concrete
setblock 335 65 -443 minecraft:sea_lantern
fill 336 65 -443 343 65 -443 minecraft:light_gray_concrete
setblock 344 65 -443 minecraft:sea_lantern
fill 345 65 -443 352 65 -443 minecraft:light_gray_concrete
setblock 353 65 -443 minecraft:sea_lantern
fill 354 65 -443 361 65 -443 minecraft:light_gray_concrete
setblock 362 65 -443 minecraft:sea_lantern
fill 363 65 -443 370 65 -443 minecraft:light_gray_concrete
setblock 371 65 -443 minecraft:sea_lantern
fill 372 65 -443 379 65 -443 minecraft:light_gray_concrete
setblock 380 65 -443 minecraft:sea_lantern
fill 381 65 -443 388 65 -443 minecraft:light_gray_concrete
setblock 389 65 -443 minecraft:sea_lantern
fill 390 65 -443 391 65 -443 minecraft:light_gray_concrete
fill 328 65 -442 331 65 -442 minecraft:light_gray_concrete
setblock 333 65 -442 minecraft:light_gray_concrete
setblock 334 65 -442 minecraft:sea_lantern
fill 335 65 -442 342 65 -442 minecraft:light_gray_concrete
setblock 343 65 -442 minecraft:sea_lantern
fill 344 65 -442 351 65 -442 minecraft:light_gray_concrete
setblock 352 65 -442 minecraft:sea_lantern
fill 353 65 -442 360 65 -442 minecraft:light_gray_concrete
setblock 361 65 -442 minecraft:sea_lantern
fill 362 65 -442 369 65 -442 minecraft:light_gray_concrete
setblock 370 65 -442 minecraft:sea_lantern
fill 371 65 -442 378 65 -442 minecraft:light_gray_concrete
setblock 379 65 -442 minecraft:sea_lantern
fill 380 65 -442 386 65 -442 minecraft:light_gray_concrete
setblock 388 65 -442 minecraft:sea_lantern
fill 389 65 -442 391 65 -442 minecraft:light_gray_concrete
fill 328 65 -441 386 65 -441 minecraft:smooth_quartz
setblock 387 65 -441 minecraft:sea_lantern
fill 388 65 -441 391 65 -441 minecraft:light_gray_concrete
fill 328 65 -440 344 65 -440 minecraft:grass_block
fill 366 65 -440 369 65 -440 minecraft:grass_block
fill 379 65 -440 386 65 -440 minecraft:grass_block
fill 387 65 -440 391 65 -440 minecraft:smooth_quartz
fill 328 65 -439 344 65 -439 minecraft:grass_block
fill 365 65 -439 369 65 -439 minecraft:grass_block
fill 380 65 -439 391 65 -439 minecraft:grass_block
fill 328 65 -438 344 65 -438 minecraft:grass_block
fill 363 65 -438 368 65 -438 minecraft:grass_block
fill 379 65 -438 391 65 -438 minecraft:grass_block
fill 328 65 -437 344 65 -437 minecraft:grass_block
fill 360 65 -437 366 65 -437 minecraft:grass_block
fill 380 65 -437 391 65 -437 minecraft:grass_block
fill 328 65 -436 345 65 -436 minecraft:grass_block
fill 358 65 -436 364 65 -436 minecraft:grass_block
fill 381 65 -436 391 65 -436 minecraft:grass_block
fill 328 65 -435 345 65 -435 minecraft:grass_block
fill 356 65 -435 362 65 -435 minecraft:grass_block
fill 382 65 -435 391 65 -435 minecraft:grass_block
fill 329 65 -434 345 65 -434 minecraft:grass_block
fill 356 65 -434 360 65 -434 minecraft:grass_block
fill 384 65 -434 391 65 -434 minecraft:grass_block
fill 330 65 -433 346 65 -433 minecraft:grass_block
fill 356 65 -433 357 65 -433 minecraft:grass_block
fill 385 65 -433 391 65 -433 minecraft:grass_block
setblock 328 65 -432 minecraft:grass_block
fill 331 65 -432 346 65 -432 minecraft:grass_block
fill 387 65 -432 391 65 -432 minecraft:grass_block
fill 328 65 -431 329 65 -431 minecraft:grass_block
fill 332 65 -431 346 65 -431 minecraft:grass_block
fill 388 65 -431 391 65 -431 minecraft:grass_block
fill 328 65 -430 330 65 -430 minecraft:grass_block
fill 334 65 -430 346 65 -430 minecraft:grass_block
fill 388 65 -430 391 65 -430 minecraft:grass_block
fill 328 65 -429 331 65 -429 minecraft:grass_block
fill 335 65 -429 346 65 -429 minecraft:grass_block
fill 388 65 -429 391 65 -429 minecraft:grass_block
fill 328 65 -428 332 65 -428 minecraft:grass_block
fill 337 65 -428 346 65 -428 minecraft:grass_block
fill 388 65 -428 391 65 -428 minecraft:grass_block
fill 328 65 -427 333 65 -427 minecraft:grass_block
fill 338 65 -427 346 65 -427 minecraft:grass_block
fill 388 65 -427 391 65 -427 minecraft:grass_block
fill 328 65 -426 334 65 -426 minecraft:grass_block
fill 338 65 -426 346 65 -426 minecraft:grass_block
fill 388 65 -426 391 65 -426 minecraft:grass_block
fill 328 65 -425 335 65 -425 minecraft:grass_block
fill 340 65 -425 345 65 -425 minecraft:grass_block
fill 388 65 -425 391 65 -425 minecraft:grass_block
fill 328 65 -424 336 65 -424 minecraft:grass_block
fill 342 65 -424 345 65 -424 minecraft:grass_block
fill 388 65 -424 391 65 -424 minecraft:grass_block
fill 328 65 -423 337 65 -423 minecraft:grass_block
fill 388 65 -423 391 65 -423 minecraft:grass_block
fill 328 65 -422 337 65 -422 minecraft:grass_block
fill 387 65 -422 391 65 -422 minecraft:grass_block
fill 328 65 -421 338 65 -421 minecraft:grass_block
fill 387 65 -421 391 65 -421 minecraft:grass_block
fill 329 65 -420 340 65 -420 minecraft:grass_block
fill 387 65 -420 391 65 -420 minecraft:grass_block
fill 330 65 -419 338 65 -419 minecraft:grass_block
fill 387 65 -419 391 65 -419 minecraft:grass_block
setblock 328 65 -418 minecraft:grass_block
fill 331 65 -418 336 65 -418 minecraft:grass_block
fill 387 65 -418 391 65 -418 minecraft:grass_block
fill 328 65 -417 329 65 -417 minecraft:grass_block
fill 332 65 -417 334 65 -417 minecraft:grass_block
fill 387 65 -417 391 65 -417 minecraft:grass_block
fill 328 65 -416 329 65 -416 minecraft:grass_block
fill 332 65 -416 333 65 -416 minecraft:grass_block
fill 387 65 -416 391 65 -416 minecraft:grass_block
fill 328 65 -415 330 65 -415 minecraft:grass_block
setblock 341 65 -415 minecraft:grass_block
setblock 345 65 -415 minecraft:grass_block
setblock 386 65 -415 minecraft:grass_block
fill 388 65 -415 391 65 -415 minecraft:grass_block
fill 328 65 -414 330 65 -414 minecraft:grass_block
fill 340 65 -414 342 65 -414 minecraft:grass_block
fill 344 65 -414 345 65 -414 minecraft:grass_block
fill 364 65 -414 367 65 -414 minecraft:grass_block
fill 386 65 -414 391 65 -414 minecraft:grass_block
fill 328 65 -413 331 65 -413 minecraft:grass_block
fill 339 65 -413 345 65 -413 minecraft:grass_block
setblock 365 65 -413 minecraft:grass_block
setblock 368 65 -413 minecraft:grass_block
fill 385 65 -413 391 65 -413 minecraft:grass_block
fill 328 65 -412 333 65 -412 minecraft:grass_block
fill 338 65 -412 345 65 -412 minecraft:grass_block
fill 385 65 -412 391 65 -412 minecraft:grass_block
fill 328 65 -411 334 65 -411 minecraft:grass_block
fill 338 65 -411 344 65 -411 minecraft:grass_block
fill 384 65 -411 391 65 -411 minecraft:grass_block
fill 328 65 -410 334 65 -410 minecraft:grass_block
fill 338 65 -410 344 65 -410 minecraft:grass_block
fill 384 65 -410 391 65 -410 minecraft:grass_block
fill 328 65 -409 334 65 -409 minecraft:grass_block
fill 338 65 -409 344 65 -409 minecraft:grass_block
fill 384 65 -409 391 65 -409 minecraft:grass_block
fill 328 65 -408 335 65 -408 minecraft:grass_block
fill 338 65 -408 343 65 -408 minecraft:grass_block
setblock 366 65 -408 minecraft:grass_block
fill 384 65 -408 391 65 -408 minecraft:grass_block
fill 328 65 -407 335 65 -407 minecraft:grass_block
fill 337 65 -407 342 65 -407 minecraft:grass_block
fill 384 65 -407 391 65 -407 minecraft:grass_block
fill 328 65 -406 342 65 -406 minecraft:grass_block
fill 384 65 -406 391 65 -406 minecraft:grass_block
fill 328 65 -405 341 65 -405 minecraft:grass_block
setblock 361 65 -405 minecraft:grass_block
setblock 367 65 -405 minecraft:grass_block
fill 384 65 -405 391 65 -405 minecraft:grass_block
fill 328 65 -404 340 65 -404 minecraft:grass_block
fill 384 65 -404 391 65 -404 minecraft:grass_block
fill 328 65 -403 339 65 -403 minecraft:grass_block
setblock 365 65 -403 minecraft:grass_block
fill 384 65 -403 391 65 -403 minecraft:grass_block
fill 328 65 -402 338 65 -402 minecraft:grass_block
fill 384 65 -402 391 65 -402 minecraft:grass_block
fill 328 65 -401 338 65 -401 minecraft:grass_block
fill 384 65 -401 391 65 -401 minecraft:grass_block
fill 328 65 -400 338 65 -400 minecraft:grass_block
fill 384 65 -400 391 65 -400 minecraft:grass_block
fill 328 65 -399 338 65 -399 minecraft:grass_block
setblock 356 65 -399 minecraft:grass_block
fill 383 65 -399 391 65 -399 minecraft:grass_block
fill 328 65 -398 338 65 -398 minecraft:grass_block
setblock 359 65 -398 minecraft:grass_block
setblock 362 65 -398 minecraft:grass_block
setblock 367 65 -398 minecraft:grass_block
fill 383 65 -398 391 65 -398 minecraft:grass_block
fill 328 65 -397 337 65 -397 minecraft:grass_block
fill 383 65 -397 391 65 -397 minecraft:grass_block
fill 328 65 -396 337 65 -396 minecraft:grass_block
fill 382 65 -396 391 65 -396 minecraft:grass_block
fill 328 65 -395 335 65 -395 minecraft:grass_block
fill 382 65 -395 391 65 -395 minecraft:grass_block
fill 328 65 -394 333 65 -394 minecraft:grass_block
setblock 359 65 -394 minecraft:grass_block
fill 382 65 -394 391 65 -394 minecraft:grass_block
fill 328 65 -393 330 65 -393 minecraft:grass_block
setblock 375 65 -393 minecraft:grass_block
fill 381 65 -393 391 65 -393 minecraft:grass_block
fill 328 65 -392 329 65 -392 minecraft:grass_block
setblock 375 65 -392 minecraft:grass_block
fill 381 65 -392 391 65 -392 minecraft:grass_block
setblock 328 65 -391 minecraft:grass_block
setblock 375 65 -391 minecraft:grass_block
fill 380 65 -391 391 65 -391 minecraft:grass_block
setblock 356 65 -390 minecraft:grass_block
setblock 362 65 -390 minecraft:grass_block
fill 380 65 -390 391 65 -390 minecraft:grass_block
setblock 367 65 -389 minecraft:grass_block
fill 380 65 -389 391 65 -389 minecraft:grass_block
fill 379 65 -388 391 65 -388 minecraft:grass_block
setblock 344 65 -387 minecraft:grass_block
fill 347 65 -387 353 65 -387 minecraft:grass_block
fill 379 65 -387 391 65 -387 minecraft:grass_block
fill 328 65 -386 330 65 -386 minecraft:grass_block
fill 332 65 -386 335 65 -386 minecraft:grass_block
fill 344 65 -386 352 65 -386 minecraft:grass_block
fill 378 65 -386 391 65 -386 minecraft:grass_block
fill 328 65 -385 352 65 -385 minecraft:grass_block
fill 378 65 -385 391 65 -385 minecraft:grass_block
fill 328 65 -384 351 65 -384 minecraft:grass_block
fill 378 65 -384 391 65 -384 minecraft:grass_block
fill 328 65 -383 350 65 -383 minecraft:grass_block
setblock 357 65 -383 minecraft:grass_block
setblock 365 65 -383 minecraft:grass_block
fill 378 65 -383 391 65 -383 minecraft:grass_block
fill 328 66 -446 331 66 -446 minecraft:air
setblock 346 66 -446 minecraft:air
setblock 383 66 -446 minecraft:air
fill 328 66 -445 331 66 -445 minecraft:air
setblock 376 66 -445 minecraft:air
fill 328 66 -444 331 66 -444 minecraft:air
setblock 373 66 -440 minecraft:air
setblock 344 66 -439 minecraft:air
setblock 338 66 -437 minecraft:air
setblock 329 66 -436 minecraft:air
setblock 332 66 -436 minecraft:oak_log
setblock 342 66 -436 minecraft:oak_log
setblock 352 66 -436 minecraft:oak_log
setblock 362 66 -436 minecraft:oak_log
setblock 372 66 -436 minecraft:oak_log
setblock 379 66 -436 minecraft:air
setblock 382 66 -436 minecraft:oak_log
setblock 333 66 -433 minecraft:air
setblock 347 66 -432 minecraft:air
setblock 373 66 -432 minecraft:air
setblock 381 66 -432 minecraft:air
setblock 360 66 -431 minecraft:air
setblock 339 66 -430 minecraft:air
setblock 345 66 -426 minecraft:air
setblock 381 66 -426 minecraft:air
setblock 357 66 -418 minecraft:air
setblock 369 66 -416 minecraft:air
setblock 334 66 -412 minecraft:air
setblock 377 66 -409 minecraft:air
setblock 347 66 -407 minecraft:air
setblock 364 66 -404 minecraft:air
setblock 354 66 -394 minecraft:air
setblock 375 66 -394 minecraft:air
setblock 338 66 -393 minecraft:air
setblock 328 66 -385 minecraft:air
setblock 363 66 -385 minecraft:air
fill 328 67 -446 331 67 -446 minecraft:air
setblock 358 67 -446 minecraft:air
fill 328 67 -445 331 67 -445 minecraft:air
fill 328 67 -444 331 67 -444 minecraft:air
setblock 356 67 -442 minecraft:air
setblock 332 67 -439 minecraft:air
setblock 332 67 -436 minecraft:oak_log
setblock 342 67 -436 minecraft:oak_log
setblock 352 67 -436 minecraft:oak_log
setblock 362 67 -436 minecraft:oak_log
setblock 372 67 -436 minecraft:oak_log
setblock 382 67 -436 minecraft:oak_log
setblock 341 67 -433 minecraft:air
setblock 384 67 -430 minecraft:air
setblock 375 67 -428 minecraft:air
setblock 334 67 -426 minecraft:air
setblock 388 67 -426 minecraft:air
fill 328 68 -446 331 68 -446 minecraft:air
setblock 373 68 -446 minecraft:air
fill 328 68 -445 331 68 -445 minecraft:air
setblock 353 68 -445 minecraft:air
fill 328 68 -444 332 68 -444 minecraft:air
setblock 366 68 -444 minecraft:air
setblock 343 68 -443 minecraft:air
setblock 378 68 -443 minecraft:air
setblock 385 68 -443 minecraft:air
setblock 361 68 -442 minecraft:air
setblock 371 68 -442 minecraft:air
setblock 389 68 -441 minecraft:air
setblock 336 68 -440 minecraft:air
setblock 380 68 -439 minecraft:air
setblock 347 68 -437 minecraft:air
setblock 374 68 -437 minecraft:air
setblock 332 68 -436 minecraft:oak_log
setblock 334 68 -436 minecraft:air
setblock 342 68 -436 minecraft:oak_log
setblock 352 68 -436 minecraft:oak_log
setblock 362 68 -436 minecraft:oak_log
setblock 372 68 -436 minecraft:oak_log
setblock 382 68 -436 minecraft:oak_log
setblock 377 68 -433 minecraft:air
setblock 391 68 -433 minecraft:air
setblock 335 68 -430 minecraft:air
setblock 343 68 -428 minecraft:air
fill 329 69 -446 331 69 -446 minecraft:air
fill 328 69 -445 331 69 -445 minecraft:air
fill 328 69 -444 331 69 -444 minecraft:air
setblock 340 69 -441 minecraft:air
setblock 332 69 -438 minecraft:oak_leaves[persistent=true]
setblock 342 69 -438 minecraft:oak_leaves[persistent=true]
setblock 352 69 -438 minecraft:oak_leaves[persistent=true]
setblock 362 69 -438 minecraft:oak_leaves[persistent=true]
setblock 372 69 -438 minecraft:oak_leaves[persistent=true]
setblock 382 69 -438 minecraft:oak_leaves[persistent=true]
fill 331 69 -437 333 69 -437 minecraft:oak_leaves[persistent=true]
fill 341 69 -437 343 69 -437 minecraft:oak_leaves[persistent=true]
fill 351 69 -437 353 69 -437 minecraft:oak_leaves[persistent=true]
fill 361 69 -437 363 69 -437 minecraft:oak_leaves[persistent=true]
fill 371 69 -437 373 69 -437 minecraft:oak_leaves[persistent=true]
fill 381 69 -437 383 69 -437 minecraft:oak_leaves[persistent=true]
fill 330 69 -436 331 69 -436 minecraft:oak_leaves[persistent=true]
setblock 332 69 -436 minecraft:oak_log
fill 333 69 -436 334 69 -436 minecraft:oak_leaves[persistent=true]
fill 340 69 -436 341 69 -436 minecraft:oak_leaves[persistent=true]
setblock 342 69 -436 minecraft:oak_log
fill 343 69 -436 344 69 -436 minecraft:oak_leaves[persistent=true]
fill 350 69 -436 351 69 -436 minecraft:oak_leaves[persistent=true]
setblock 352 69 -436 minecraft:oak_log
fill 353 69 -436 354 69 -436 minecraft:oak_leaves[persistent=true]
fill 360 69 -436 361 69 -436 minecraft:oak_leaves[persistent=true]
setblock 362 69 -436 minecraft:oak_log
fill 363 69 -436 364 69 -436 minecraft:oak_leaves[persistent=true]
fill 370 69 -436 371 69 -436 minecraft:oak_leaves[persistent=true]
setblock 372 69 -436 minecraft:oak_log
fill 373 69 -436 374 69 -436 minecraft:oak_leaves[persistent=true]
fill 380 69 -436 381 69 -436 minecraft:oak_leaves[persistent=true]
setblock 382 69 -436 minecraft:oak_log
fill 383 69 -436 384 69 -436 minecraft:oak_leaves[persistent=true]
fill 331 69 -435 333 69 -435 minecraft:oak_leaves[persistent=true]
setblock 339 69 -435 minecraft:air
fill 341 69 -435 343 69 -435 minecraft:oak_leaves[persistent=true]
fill 351 69 -435 353 69 -435 minecraft:oak_leaves[persistent=true]
fill 361 69 -435 363 69 -435 minecraft:oak_leaves[persistent=true]
fill 371 69 -435 373 69 -435 minecraft:oak_leaves[persistent=true]
fill 381 69 -435 383 69 -435 minecraft:oak_leaves[persistent=true]
setblock 388 69 -435 minecraft:air
setblock 332 69 -434 minecraft:oak_leaves[persistent=true]
setblock 342 69 -434 minecraft:oak_leaves[persistent=true]
setblock 352 69 -434 minecraft:oak_leaves[persistent=true]
setblock 362 69 -434 minecraft:oak_leaves[persistent=true]
setblock 372 69 -434 minecraft:oak_leaves[persistent=true]
setblock 382 69 -434 minecraft:oak_leaves[persistent=true]
setblock 345 69 -433 minecraft:air
setblock 330 69 -430 minecraft:air
setblock 380 69 -430 minecraft:air
setblock 391 69 -427 minecraft:air
setblock 340 69 -426 minecraft:air
setblock 333 70 -441 minecraft:air
setblock 375 70 -441 minecraft:air
setblock 345 70 -440 minecraft:air
setblock 386 70 -439 minecraft:air
fill 331 70 -438 333 70 -438 minecraft:oak_leaves[persistent=true]
fill 341 70 -438 343 70 -438 minecraft:oak_leaves[persistent=true]
fill 351 70 -438 353 70 -438 minecraft:oak_leaves[persistent=true]
fill 361 70 -438 363 70 -438 minecraft:oak_leaves[persistent=true]
fill 371 70 -438 373 70 -438 minecraft:oak_leaves[persistent=true]
fill 381 70 -438 383 70 -438 minecraft:oak_leaves[persistent=true]
fill 330 70 -437 334 70 -437 minecraft:oak_leaves[persistent=true]
fill 340 70 -437 344 70 -437 minecraft:oak_leaves[persistent=true]
fill 350 70 -437 354 70 -437 minecraft:oak_leaves[persistent=true]
fill 360 70 -437 364 70 -437 minecraft:oak_leaves[persistent=true]
fill 370 70 -437 374 70 -437 minecraft:oak_leaves[persistent=true]
setblock 378 70 -437 minecraft:air
fill 380 70 -437 384 70 -437 minecraft:oak_leaves[persistent=true]
fill 330 70 -436 331 70 -436 minecraft:oak_leaves[persistent=true]
setblock 332 70 -436 minecraft:oak_log
fill 333 70 -436 334 70 -436 minecraft:oak_leaves[persistent=true]
fill 340 70 -436 341 70 -436 minecraft:oak_leaves[persistent=true]
setblock 342 70 -436 minecraft:oak_log
fill 343 70 -436 344 70 -436 minecraft:oak_leaves[persistent=true]
fill 350 70 -436 351 70 -436 minecraft:oak_leaves[persistent=true]
setblock 352 70 -436 minecraft:oak_log
fill 353 70 -436 354 70 -436 minecraft:oak_leaves[persistent=true]
fill 360 70 -436 361 70 -436 minecraft:oak_leaves[persistent=true]
setblock 362 70 -436 minecraft:oak_log
fill 363 70 -436 364 70 -436 minecraft:oak_leaves[persistent=true]
fill 370 70 -436 371 70 -436 minecraft:oak_leaves[persistent=true]
setblock 372 70 -436 minecraft:oak_log
fill 373 70 -436 374 70 -436 minecraft:oak_leaves[persistent=true]
fill 380 70 -436 381 70 -436 minecraft:oak_leaves[persistent=true]
setblock 382 70 -436 minecraft:oak_log
fill 383 70 -436 384 70 -436 minecraft:oak_leaves[persistent=true]
fill 330 70 -435 334 70 -435 minecraft:oak_leaves[persistent=true]
fill 340 70 -435 344 70 -435 minecraft:oak_leaves[persistent=true]
fill 350 70 -435 354 70 -435 minecraft:oak_leaves[persistent=true]
fill 360 70 -435 364 70 -435 minecraft:oak_leaves[persistent=true]
fill 370 70 -435 374 70 -435 minecraft:oak_leaves[persistent=true]
fill 380 70 -435 384 70 -435 minecraft:oak_leaves[persistent=true]
fill 331 70 -434 333 70 -434 minecraft:oak_leaves[persistent=true]
fill 341 70 -434 343 70 -434 minecraft:oak_leaves[persistent=true]
fill 351 70 -434 353 70 -434 minecraft:oak_leaves[persistent=true]
fill 361 70 -434 363 70 -434 minecraft:oak_leaves[persistent=true]
fill 371 70 -434 373 70 -434 minecraft:oak_leaves[persistent=true]
fill 381 70 -434 383 70 -434 minecraft:oak_leaves[persistent=true]
setblock 337 70 -432 minecraft:air
setblock 385 70 -432 minecraft:air
setblock 342 70 -431 minecraft:air
setblock 388 70 -429 minecraft:air
setblock 383 70 -428 minecraft:air
setblock 347 70 -427 minecraft:air
setblock 372 70 -426 minecraft:air
setblock 330 71 -439 minecraft:air
setblock 332 71 -438 minecraft:oak_leaves[persistent=true]
setblock 342 71 -438 minecraft:oak_leaves[persistent=true]
setblock 352 71 -438 minecraft:oak_leaves[persistent=true]
setblock 362 71 -438 minecraft:oak_leaves[persistent=true]
setblock 372 71 -438 minecraft:oak_leaves[persistent=true]
setblock 382 71 -438 minecraft:oak_leaves[persistent=true]
fill 331 71 -437 333 71 -437 minecraft:oak_leaves[persistent=true]
setblock 336 71 -437 minecraft:air
fill 341 71 -437 343 71 -437 minecraft:oak_leaves[persistent=true]
fill 351 71 -437 353 71 -437 minecraft:oak_leaves[persistent=true]
fill 361 71 -437 363 71 -437 minecraft:oak_leaves[persistent=true]
fill 371 71 -437 373 71 -437 minecraft:oak_leaves[persistent=true]
fill 381 71 -437 383 71 -437 minecraft:oak_leaves[persistent=true]
fill 330 71 -436 334 71 -436 minecraft:oak_leaves[persistent=true]
fill 340 71 -436 344 71 -436 minecraft:oak_leaves[persistent=true]
fill 350 71 -436 354 71 -436 minecraft:oak_leaves[persistent=true]
fill 360 71 -436 364 71 -436 minecraft:oak_leaves[persistent=true]
fill 370 71 -436 374 71 -436 minecraft:oak_leaves[persistent=true]
fill 380 71 -436 384 71 -436 minecraft:oak_leaves[persistent=true]
fill 331 71 -435 333 71 -435 minecraft:oak_leaves[persistent=true]
fill 341 71 -435 343 71 -435 minecraft:oak_leaves[persistent=true]
fill 351 71 -435 353 71 -435 minecraft:oak_leaves[persistent=true]
fill 361 71 -435 363 71 -435 minecraft:oak_leaves[persistent=true]
fill 371 71 -435 373 71 -435 minecraft:oak_leaves[persistent=true]
fill 381 71 -435 383 71 -435 minecraft:oak_leaves[persistent=true]
setblock 332 71 -434 minecraft:oak_leaves[persistent=true]
setblock 333 71 -434 minecraft:air
setblock 342 71 -434 minecraft:oak_leaves[persistent=true]
setblock 352 71 -434 minecraft:oak_leaves[persistent=true]
setblock 362 71 -434 minecraft:oak_leaves[persistent=true]
setblock 372 71 -434 minecraft:oak_leaves[persistent=true]
setblock 382 71 -434 minecraft:oak_leaves[persistent=true]
setblock 374 71 -429 minecraft:air
setblock 334 71 -428 minecraft:air
setblock 378 71 -427 minecraft:air
setblock 386 71 -426 minecraft:air
setblock 328 72 -444 minecraft:air
setblock 379 72 -441 minecraft:air
setblock 339 72 -439 minecraft:air
setblock 348 72 -438 minecraft:air
setblock 382 72 -438 minecraft:air
setblock 328 72 -436 minecraft:air
setblock 332 72 -436 minecraft:oak_leaves[persistent=true]
setblock 342 72 -436 minecraft:oak_leaves[persistent=true]
setblock 352 72 -436 minecraft:oak_leaves[persistent=true]
setblock 362 72 -436 minecraft:oak_leaves[persistent=true]
setblock 372 72 -436 minecraft:oak_leaves[persistent=true]
setblock 382 72 -436 minecraft:oak_leaves[persistent=true]
setblock 340 72 -433 minecraft:air
setblock 348 72 -432 minecraft:air
setblock 343 72 -426 minecraft:air
setblock 338 73 -427 minecraft:air
setblock 384 74 -440 minecraft:air
setblock 391 74 -438 minecraft:air
setblock 338 74 -436 minecraft:air
setblock 331 74 -432 minecraft:air
setblock 375 74 -432 minecraft:air
setblock 336 74 -431 minecraft:air
setblock 345 74 -428 minecraft:air
setblock 336 75 -441 minecraft:air
setblock 373 75 -440 minecraft:air
setblock 380 75 -439 minecraft:air
setblock 330 75 -437 minecraft:air
setblock 341 75 -431 minecraft:air
setblock 382 75 -430 minecraft:air
setblock 328 75 -427 minecraft:air
setblock 345 76 -432 minecraft:air
setblock 328 77 -444 minecraft:air
setblock 330 77 -441 minecraft:air
setblock 345 77 -441 minecraft:air
setblock 382 77 -441 minecraft:air
setblock 340 77 -437 minecraft:air
setblock 335 77 -435 minecraft:air
setblock 381 77 -433 minecraft:air
setblock 338 77 -430 minecraft:air
setblock 342 77 -426 minecraft:air
setblock 379 77 -426 minecraft:air
setblock 331 78 -445 minecraft:air
setblock 376 78 -441 minecraft:air
setblock 345 78 -436 minecraft:air
setblock 348 79 -440 minecraft:air
setblock 332 79 -437 minecraft:air
setblock 374 79 -431 minecraft:air
setblock 383 79 -431 minecraft:air
setblock 342 79 -430 minecraft:air
setblock 391 79 -428 minecraft:air
setblock 372 79 -427 minecraft:air
setblock 360 80 -442 minecraft:air
forceload remove 328 -446 391 -383
tellraw @a {"text":"Campus bau a06 fertig.","color":"green"}
