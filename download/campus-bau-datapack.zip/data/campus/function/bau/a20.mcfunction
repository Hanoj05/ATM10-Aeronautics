# Abschnitt a20: x 328..391, z -318..-255 (4397 Blöcke)
forceload add 328 -318 391 -255
tellraw @a {"text":"Campus bau a20: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a20_1 2s
