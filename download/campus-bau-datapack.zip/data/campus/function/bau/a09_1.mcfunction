fill 113 45 -360 114 45 -360 minecraft:stone
fill 113 45 -359 115 45 -359 minecraft:stone
fill 112 45 -358 115 45 -358 minecraft:stone
fill 113 45 -357 114 45 -357 minecraft:stone
fill 100 45 -327 101 45 -327 minecraft:stone
fill 99 45 -326 102 45 -326 minecraft:stone
fill 98 45 -325 103 45 -325 minecraft:stone
fill 98 45 -324 103 45 -324 minecraft:stone
fill 97 45 -323 102 45 -323 minecraft:stone
fill 96 45 -322 101 45 -322 minecraft:stone
fill 95 45 -321 98 45 -321 minecraft:stone
fill 95 45 -320 97 45 -320 minecraft:stone
fill 94 45 -319 97 45 -319 minecraft:stone
fill 113 46 -360 114 46 -360 minecraft:stone
fill 113 46 -359 115 46 -359 minecraft:stone
fill 113 46 -358 115 46 -358 minecraft:stone
setblock 116 47 -381 minecraft:stone
setblock 116 47 -380 minecraft:stone
setblock 116 47 -379 minecraft:stone
setblock 116 47 -378 minecraft:stone
setblock 116 47 -377 minecraft:stone
fill 115 47 -376 116 47 -376 minecraft:stone
fill 115 47 -375 116 47 -375 minecraft:stone
fill 115 47 -374 116 47 -374 minecraft:stone
fill 113 47 -373 116 47 -373 minecraft:stone
fill 112 47 -372 116 47 -372 minecraft:stone
fill 105 47 -366 106 47 -366 minecraft:stone
fill 105 47 -365 106 47 -365 minecraft:stone
setblock 114 47 -361 minecraft:stone
fill 113 47 -360 115 47 -360 minecraft:stone
fill 113 47 -359 115 47 -359 minecraft:stone
fill 113 47 -358 114 47 -358 minecraft:stone
setblock 74 47 -345 minecraft:stone
fill 73 47 -344 74 47 -344 minecraft:stone
fill 72 47 -343 74 47 -343 minecraft:stone
fill 72 47 -342 74 47 -342 minecraft:stone
fill 72 47 -341 73 47 -341 minecraft:stone
setblock 135 47 -340 minecraft:stone
fill 134 47 -339 135 47 -339 minecraft:stone
fill 133 47 -338 135 47 -338 minecraft:stone
fill 132 47 -337 135 47 -337 minecraft:stone
fill 132 47 -336 135 47 -336 minecraft:stone
fill 131 47 -335 135 47 -335 minecraft:stone
fill 131 47 -334 135 47 -334 minecraft:stone
fill 129 47 -333 135 47 -333 minecraft:stone
fill 128 47 -332 135 47 -332 minecraft:stone
fill 128 47 -331 135 47 -331 minecraft:stone
fill 128 47 -330 135 47 -330 minecraft:stone
fill 128 47 -329 134 47 -329 minecraft:stone
fill 128 47 -328 133 47 -328 minecraft:stone
fill 128 47 -327 132 47 -327 minecraft:stone
setblock 128 47 -326 minecraft:stone
fill 72 48 -382 80 48 -382 minecraft:stone
fill 94 48 -382 117 48 -382 minecraft:stone
fill 72 48 -381 81 48 -381 minecraft:stone
fill 94 48 -381 118 48 -381 minecraft:stone
fill 72 48 -380 81 48 -380 minecraft:stone
fill 95 48 -380 118 48 -380 minecraft:stone
fill 72 48 -379 81 48 -379 minecraft:stone
fill 95 48 -379 118 48 -379 minecraft:stone
fill 73 48 -378 81 48 -378 minecraft:stone
fill 95 48 -378 118 48 -378 minecraft:stone
fill 72 48 -377 73 48 -377 minecraft:stone
fill 76 48 -377 80 48 -377 minecraft:stone
fill 95 48 -377 118 48 -377 minecraft:stone
fill 72 48 -376 80 48 -376 minecraft:stone
fill 95 48 -376 118 48 -376 minecraft:stone
fill 72 48 -375 79 48 -375 minecraft:stone
fill 96 48 -375 118 48 -375 minecraft:stone
fill 72 48 -374 75 48 -374 minecraft:stone
setblock 79 48 -374 minecraft:stone
fill 97 48 -374 102 48 -374 minecraft:stone
fill 105 48 -374 117 48 -374 minecraft:stone
fill 72 48 -373 73 48 -373 minecraft:stone
setblock 75 48 -373 minecraft:stone
setblock 78 48 -373 minecraft:stone
fill 97 48 -373 102 48 -373 minecraft:stone
fill 105 48 -373 117 48 -373 minecraft:stone
fill 77 48 -372 78 48 -372 minecraft:stone
fill 98 48 -372 101 48 -372 minecraft:stone
fill 106 48 -372 117 48 -372 minecraft:stone
setblock 72 48 -371 minecraft:stone
fill 74 48 -371 78 48 -371 minecraft:stone
fill 98 48 -371 100 48 -371 minecraft:stone
fill 106 48 -371 116 48 -371 minecraft:stone
fill 72 48 -370 73 48 -370 minecraft:stone
setblock 75 48 -370 minecraft:stone
setblock 77 48 -370 minecraft:stone
fill 98 48 -370 100 48 -370 minecraft:stone
fill 106 48 -370 113 48 -370 minecraft:stone
fill 72 48 -369 73 48 -369 minecraft:stone
setblock 75 48 -369 minecraft:stone
fill 99 48 -369 100 48 -369 minecraft:stone
fill 107 48 -369 112 48 -369 minecraft:stone
setblock 72 48 -368 minecraft:stone
fill 75 48 -368 76 48 -368 minecraft:stone
fill 99 48 -368 100 48 -368 minecraft:stone
fill 107 48 -368 111 48 -368 minecraft:stone
fill 72 48 -367 73 48 -367 minecraft:stone
fill 75 48 -367 77 48 -367 minecraft:stone
fill 108 48 -367 109 48 -367 minecraft:stone
fill 72 48 -366 77 48 -366 minecraft:stone
fill 105 48 -366 106 48 -366 minecraft:stone
setblock 108 48 -366 minecraft:stone
fill 72 48 -365 77 48 -365 minecraft:stone
fill 105 48 -365 106 48 -365 minecraft:stone
fill 72 48 -364 77 48 -364 minecraft:stone
fill 72 48 -363 75 48 -363 minecraft:stone
fill 72 48 -362 74 48 -362 minecraft:stone
fill 72 48 -361 73 48 -361 minecraft:stone
fill 72 48 -360 73 48 -360 minecraft:stone
fill 113 48 -360 114 48 -360 minecraft:stone
setblock 72 48 -359 minecraft:stone
fill 113 48 -359 115 48 -359 minecraft:stone
fill 75 48 -352 76 48 -352 minecraft:stone
fill 74 48 -351 77 48 -351 minecraft:stone
fill 74 48 -350 76 48 -350 minecraft:stone
fill 73 48 -349 76 48 -349 minecraft:stone
fill 73 48 -348 76 48 -348 minecraft:stone
fill 72 48 -347 76 48 -347 minecraft:stone
fill 72 48 -346 76 48 -346 minecraft:stone
fill 72 48 -345 76 48 -345 minecraft:stone
fill 72 48 -344 76 48 -344 minecraft:stone
fill 72 48 -343 75 48 -343 minecraft:stone
fill 72 48 -342 75 48 -342 minecraft:stone
setblock 135 48 -342 minecraft:stone
fill 72 48 -341 75 48 -341 minecraft:stone
fill 134 48 -341 135 48 -341 minecraft:stone
fill 72 48 -340 74 48 -340 minecraft:stone
fill 133 48 -340 135 48 -340 minecraft:stone
setblock 72 48 -339 minecraft:stone
fill 132 48 -339 135 48 -339 minecraft:stone
fill 132 48 -338 135 48 -338 minecraft:stone
fill 131 48 -337 135 48 -337 minecraft:stone
fill 130 48 -336 135 48 -336 minecraft:stone
fill 130 48 -335 135 48 -335 minecraft:stone
fill 128 48 -334 135 48 -334 minecraft:stone
fill 128 48 -333 135 48 -333 minecraft:stone
fill 127 48 -332 135 48 -332 minecraft:stone
fill 127 48 -331 135 48 -331 minecraft:stone
fill 127 48 -330 135 48 -330 minecraft:stone
fill 127 48 -329 135 48 -329 minecraft:stone
fill 126 48 -328 135 48 -328 minecraft:stone
fill 126 48 -327 135 48 -327 minecraft:stone
fill 126 48 -326 134 48 -326 minecraft:stone
fill 125 48 -325 133 48 -325 minecraft:stone
fill 123 48 -324 131 48 -324 minecraft:stone
fill 72 49 -382 118 49 -382 minecraft:stone
fill 72 49 -381 118 49 -381 minecraft:stone
fill 72 49 -380 118 49 -380 minecraft:stone
fill 72 49 -379 118 49 -379 minecraft:stone
fill 72 49 -378 118 49 -378 minecraft:stone
fill 72 49 -377 118 49 -377 minecraft:stone
fill 72 49 -376 118 49 -376 minecraft:stone
fill 72 49 -375 118 49 -375 minecraft:stone
fill 72 49 -374 118 49 -374 minecraft:stone
fill 72 49 -373 118 49 -373 minecraft:stone
fill 72 49 -372 87 49 -372 minecraft:stone
fill 93 49 -372 118 49 -372 minecraft:stone
fill 72 49 -371 87 49 -371 minecraft:stone
fill 93 49 -371 102 49 -371 minecraft:stone
fill 105 49 -371 116 49 -371 minecraft:stone
fill 72 49 -370 86 49 -370 minecraft:stone
fill 93 49 -370 101 49 -370 minecraft:stone
fill 106 49 -370 114 49 -370 minecraft:stone
fill 72 49 -369 86 49 -369 minecraft:stone
fill 93 49 -369 101 49 -369 minecraft:stone
fill 106 49 -369 113 49 -369 minecraft:stone
fill 72 49 -368 85 49 -368 minecraft:stone
fill 93 49 -368 101 49 -368 minecraft:stone
fill 106 49 -368 112 49 -368 minecraft:stone
fill 72 49 -367 85 49 -367 minecraft:stone
fill 91 49 -367 100 49 -367 minecraft:stone
fill 107 49 -367 110 49 -367 minecraft:stone
fill 72 49 -366 86 49 -366 minecraft:stone
fill 90 49 -366 97 49 -366 minecraft:stone
fill 107 49 -366 108 49 -366 minecraft:stone
fill 72 49 -365 87 49 -365 minecraft:stone
fill 89 49 -365 96 49 -365 minecraft:stone
setblock 108 49 -365 minecraft:stone
fill 72 49 -364 96 49 -364 minecraft:stone
fill 72 49 -363 76 49 -363 minecraft:stone
setblock 96 49 -363 minecraft:stone
fill 72 49 -362 76 49 -362 minecraft:stone
setblock 96 49 -362 minecraft:stone
fill 113 49 -362 114 49 -362 minecraft:stone
fill 72 49 -361 76 49 -361 minecraft:stone
setblock 96 49 -361 minecraft:stone
fill 112 49 -361 114 49 -361 minecraft:stone
fill 72 49 -360 75 49 -360 minecraft:stone
fill 113 49 -360 114 49 -360 minecraft:stone
setblock 72 49 -359 minecraft:stone
setblock 72 49 -358 minecraft:stone
setblock 74 49 -357 minecraft:stone
fill 74 49 -356 75 49 -356 minecraft:stone
fill 74 49 -355 76 49 -355 minecraft:stone
fill 74 49 -354 77 49 -354 minecraft:stone
fill 74 49 -353 77 49 -353 minecraft:stone
fill 74 49 -352 77 49 -352 minecraft:stone
fill 74 49 -351 78 49 -351 minecraft:stone
fill 73 49 -350 77 49 -350 minecraft:stone
fill 72 49 -349 77 49 -349 minecraft:stone
fill 72 49 -348 77 49 -348 minecraft:stone
fill 72 49 -347 76 49 -347 minecraft:stone
fill 72 49 -346 76 49 -346 minecraft:stone
fill 72 49 -345 76 49 -345 minecraft:stone
fill 72 49 -344 76 49 -344 minecraft:stone
fill 72 49 -343 76 49 -343 minecraft:stone
fill 72 49 -342 75 49 -342 minecraft:stone
fill 72 49 -341 75 49 -341 minecraft:stone
fill 72 49 -340 74 49 -340 minecraft:stone
fill 72 49 -339 73 49 -339 minecraft:stone
fill 72 50 -382 119 50 -382 minecraft:stone
fill 72 50 -381 119 50 -381 minecraft:stone
fill 72 50 -380 119 50 -380 minecraft:stone
fill 72 50 -379 119 50 -379 minecraft:stone
fill 72 50 -378 119 50 -378 minecraft:stone
fill 72 50 -377 119 50 -377 minecraft:stone
fill 72 50 -376 119 50 -376 minecraft:stone
fill 72 50 -375 119 50 -375 minecraft:stone
fill 72 50 -374 118 50 -374 minecraft:stone
fill 72 50 -373 118 50 -373 minecraft:stone
fill 72 50 -372 118 50 -372 minecraft:stone
fill 72 50 -371 117 50 -371 minecraft:stone
fill 72 50 -370 103 50 -370 minecraft:stone
fill 105 50 -370 115 50 -370 minecraft:stone
fill 72 50 -369 102 50 -369 minecraft:stone
fill 105 50 -369 113 50 -369 minecraft:stone
fill 72 50 -368 102 50 -368 minecraft:stone
fill 105 50 -368 112 50 -368 minecraft:stone
fill 72 50 -367 101 50 -367 minecraft:stone
fill 106 50 -367 111 50 -367 minecraft:stone
fill 72 50 -366 100 50 -366 minecraft:stone
fill 106 50 -366 109 50 -366 minecraft:stone
fill 72 50 -365 99 50 -365 minecraft:stone
fill 106 50 -365 108 50 -365 minecraft:stone
fill 72 50 -364 98 50 -364 minecraft:stone
setblock 108 50 -364 minecraft:stone
fill 72 50 -363 77 50 -363 minecraft:stone
fill 92 50 -363 97 50 -363 minecraft:stone
fill 72 50 -362 76 50 -362 minecraft:stone
fill 94 50 -362 96 50 -362 minecraft:stone
fill 112 50 -362 114 50 -362 minecraft:stone
fill 72 50 -361 76 50 -361 minecraft:stone
fill 95 50 -361 96 50 -361 minecraft:stone
fill 112 50 -361 114 50 -361 minecraft:stone
fill 72 50 -360 76 50 -360 minecraft:stone
setblock 96 50 -360 minecraft:stone
fill 113 50 -360 114 50 -360 minecraft:stone
fill 72 50 -359 75 50 -359 minecraft:stone
fill 72 50 -358 75 50 -358 minecraft:stone
fill 72 50 -357 76 50 -357 minecraft:stone
fill 72 50 -356 76 50 -356 minecraft:stone
fill 73 50 -355 77 50 -355 minecraft:stone
fill 73 50 -354 77 50 -354 minecraft:stone
fill 73 50 -353 78 50 -353 minecraft:stone
fill 73 50 -352 78 50 -352 minecraft:stone
fill 73 50 -351 78 50 -351 minecraft:stone
fill 73 50 -350 78 50 -350 minecraft:stone
fill 73 50 -349 77 50 -349 minecraft:stone
fill 72 50 -348 76 50 -348 minecraft:stone
fill 72 50 -347 76 50 -347 minecraft:stone
fill 72 50 -346 76 50 -346 minecraft:stone
fill 72 50 -345 76 50 -345 minecraft:stone
fill 72 50 -344 76 50 -344 minecraft:stone
fill 72 50 -343 75 50 -343 minecraft:stone
fill 72 50 -342 75 50 -342 minecraft:stone
fill 72 50 -341 74 50 -341 minecraft:stone
fill 72 50 -340 73 50 -340 minecraft:stone
fill 72 51 -382 119 51 -382 minecraft:stone
fill 72 51 -381 119 51 -381 minecraft:stone
fill 72 51 -380 119 51 -380 minecraft:stone
fill 122 51 -380 124 51 -380 minecraft:stone
fill 72 51 -379 119 51 -379 minecraft:stone
fill 123 51 -379 124 51 -379 minecraft:stone
fill 72 51 -378 120 51 -378 minecraft:stone
fill 72 51 -377 121 51 -377 minecraft:stone
fill 72 51 -376 121 51 -376 minecraft:stone
fill 72 51 -375 119 51 -375 minecraft:stone
fill 72 51 -374 119 51 -374 minecraft:stone
fill 72 51 -373 119 51 -373 minecraft:stone
fill 72 51 -372 119 51 -372 minecraft:stone
fill 72 51 -371 117 51 -371 minecraft:stone
fill 72 51 -370 116 51 -370 minecraft:stone
fill 72 51 -369 114 51 -369 minecraft:stone
fill 72 51 -368 113 51 -368 minecraft:stone
fill 72 51 -367 112 51 -367 minecraft:stone
fill 72 51 -366 110 51 -366 minecraft:stone
fill 72 51 -365 109 51 -365 minecraft:stone
fill 72 51 -364 108 51 -364 minecraft:stone
fill 72 51 -363 77 51 -363 minecraft:stone
fill 90 51 -363 98 51 -363 minecraft:stone
fill 103 51 -363 108 51 -363 minecraft:stone
fill 112 51 -363 114 51 -363 minecraft:stone
fill 72 51 -362 76 51 -362 minecraft:stone
fill 92 51 -362 97 51 -362 minecraft:stone
fill 103 51 -362 107 51 -362 minecraft:stone
fill 112 51 -362 114 51 -362 minecraft:stone
fill 72 51 -361 76 51 -361 minecraft:stone
fill 94 51 -361 97 51 -361 minecraft:stone
fill 104 51 -361 106 51 -361 minecraft:stone
fill 112 51 -361 114 51 -361 minecraft:stone
fill 72 51 -360 76 51 -360 minecraft:stone
fill 95 51 -360 97 51 -360 minecraft:stone
fill 104 51 -360 105 51 -360 minecraft:stone
fill 113 51 -360 114 51 -360 minecraft:stone
fill 72 51 -359 75 51 -359 minecraft:stone
fill 72 51 -358 76 51 -358 minecraft:stone
fill 72 51 -357 76 51 -357 minecraft:stone
fill 72 51 -356 77 51 -356 minecraft:stone
fill 72 51 -355 77 51 -355 minecraft:stone
fill 73 51 -354 77 51 -354 minecraft:stone
fill 73 51 -353 77 51 -353 minecraft:stone
fill 74 51 -352 77 51 -352 minecraft:stone
fill 74 51 -351 77 51 -351 minecraft:stone
fill 74 51 -350 77 51 -350 minecraft:stone
fill 74 51 -349 76 51 -349 minecraft:stone
fill 74 51 -348 75 51 -348 minecraft:stone
fill 73 51 -347 75 51 -347 minecraft:stone
fill 73 51 -346 75 51 -346 minecraft:stone
fill 73 51 -345 74 51 -345 minecraft:stone
fill 73 51 -344 74 51 -344 minecraft:stone
fill 72 52 -382 123 52 -382 minecraft:stone
fill 72 52 -381 124 52 -381 minecraft:stone
fill 72 52 -380 125 52 -380 minecraft:stone
fill 72 52 -379 124 52 -379 minecraft:stone
fill 72 52 -378 124 52 -378 minecraft:stone
fill 72 52 -377 124 52 -377 minecraft:stone
fill 72 52 -376 124 52 -376 minecraft:stone
fill 72 52 -375 123 52 -375 minecraft:stone
fill 72 52 -374 121 52 -374 minecraft:stone
fill 72 52 -373 120 52 -373 minecraft:stone
fill 72 52 -372 120 52 -372 minecraft:stone
fill 72 52 -371 118 52 -371 minecraft:stone
fill 72 52 -370 116 52 -370 minecraft:stone
fill 72 52 -369 115 52 -369 minecraft:stone
fill 72 52 -368 114 52 -368 minecraft:stone
fill 72 52 -367 113 52 -367 minecraft:stone
fill 72 52 -366 112 52 -366 minecraft:stone
fill 72 52 -365 110 52 -365 minecraft:stone
fill 72 52 -364 109 52 -364 minecraft:stone
setblock 113 52 -364 minecraft:stone
fill 72 52 -363 79 52 -363 minecraft:stone
fill 88 52 -363 109 52 -363 minecraft:stone
fill 112 52 -363 114 52 -363 minecraft:stone
fill 72 52 -362 77 52 -362 minecraft:stone
fill 90 52 -362 99 52 -362 minecraft:stone
fill 101 52 -362 108 52 -362 minecraft:stone
fill 112 52 -362 114 52 -362 minecraft:stone
fill 72 52 -361 77 52 -361 minecraft:stone
fill 92 52 -361 98 52 -361 minecraft:stone
fill 102 52 -361 108 52 -361 minecraft:stone
fill 113 52 -361 114 52 -361 minecraft:stone
fill 72 52 -360 76 52 -360 minecraft:stone
fill 93 52 -360 97 52 -360 minecraft:stone
fill 103 52 -360 108 52 -360 minecraft:stone
fill 72 52 -359 75 52 -359 minecraft:stone
setblock 96 52 -359 minecraft:stone
fill 103 52 -359 106 52 -359 minecraft:stone
fill 72 52 -358 76 52 -358 minecraft:stone
setblock 104 52 -358 minecraft:stone
fill 72 52 -357 76 52 -357 minecraft:stone
fill 72 52 -356 76 52 -356 minecraft:stone
fill 72 52 -355 76 52 -355 minecraft:stone
fill 73 52 -354 77 52 -354 minecraft:stone
fill 74 52 -353 76 52 -353 minecraft:stone
fill 75 52 -352 76 52 -352 minecraft:stone
setblock 76 52 -351 minecraft:stone
fill 72 53 -382 125 53 -382 minecraft:stone
fill 72 53 -381 126 53 -381 minecraft:stone
fill 72 53 -380 127 53 -380 minecraft:stone
fill 72 53 -379 126 53 -379 minecraft:stone
fill 72 53 -378 125 53 -378 minecraft:stone
fill 72 53 -377 125 53 -377 minecraft:stone
fill 72 53 -376 125 53 -376 minecraft:stone
fill 72 53 -375 124 53 -375 minecraft:stone
fill 72 53 -374 123 53 -374 minecraft:stone
fill 72 53 -373 122 53 -373 minecraft:stone
fill 72 53 -372 121 53 -372 minecraft:stone
fill 72 53 -371 119 53 -371 minecraft:stone
fill 72 53 -370 117 53 -370 minecraft:stone
fill 72 53 -369 115 53 -369 minecraft:stone
fill 72 53 -368 114 53 -368 minecraft:stone
fill 72 53 -367 114 53 -367 minecraft:stone
fill 72 53 -366 113 53 -366 minecraft:stone
fill 72 53 -365 113 53 -365 minecraft:stone
fill 72 53 -364 114 53 -364 minecraft:stone
fill 72 53 -363 82 53 -363 minecraft:stone
fill 85 53 -363 110 53 -363 minecraft:stone
fill 112 53 -363 114 53 -363 minecraft:stone
fill 72 53 -362 78 53 -362 minecraft:stone
fill 88 53 -362 109 53 -362 minecraft:stone
fill 113 53 -362 114 53 -362 minecraft:stone
fill 72 53 -361 77 53 -361 minecraft:stone
fill 90 53 -361 109 53 -361 minecraft:stone
fill 72 53 -360 77 53 -360 minecraft:stone
fill 91 53 -360 99 53 -360 minecraft:stone
fill 101 53 -360 108 53 -360 minecraft:stone
fill 72 53 -359 76 53 -359 minecraft:stone
fill 93 53 -359 98 53 -359 minecraft:stone
fill 102 53 -359 108 53 -359 minecraft:stone
fill 72 53 -358 75 53 -358 minecraft:stone
fill 103 53 -358 108 53 -358 minecraft:stone
fill 72 53 -357 75 53 -357 minecraft:stone
fill 104 53 -357 106 53 -357 minecraft:stone
fill 72 53 -356 74 53 -356 minecraft:stone
setblock 72 53 -355 minecraft:stone
fill 72 54 -382 128 54 -382 minecraft:stone
fill 72 54 -381 129 54 -381 minecraft:stone
fill 72 54 -380 129 54 -380 minecraft:stone
fill 72 54 -379 127 54 -379 minecraft:stone
fill 72 54 -378 126 54 -378 minecraft:stone
fill 72 54 -377 126 54 -377 minecraft:stone
fill 72 54 -376 125 54 -376 minecraft:stone
fill 72 54 -375 125 54 -375 minecraft:stone
fill 72 54 -374 124 54 -374 minecraft:stone
fill 72 54 -373 124 54 -373 minecraft:stone
fill 72 54 -372 123 54 -372 minecraft:stone
fill 72 54 -371 121 54 -371 minecraft:stone
fill 72 54 -370 119 54 -370 minecraft:stone
fill 72 54 -369 116 54 -369 minecraft:stone
fill 72 54 -368 115 54 -368 minecraft:stone
fill 72 54 -367 114 54 -367 minecraft:stone
fill 72 54 -366 114 54 -366 minecraft:stone
fill 72 54 -365 114 54 -365 minecraft:stone
fill 72 54 -364 114 54 -364 minecraft:stone
fill 72 54 -363 111 54 -363 minecraft:stone
setblock 113 54 -363 minecraft:stone
fill 72 54 -362 79 54 -362 minecraft:stone
fill 87 54 -362 111 54 -362 minecraft:stone
fill 72 54 -361 78 54 -361 minecraft:stone
fill 88 54 -361 110 54 -361 minecraft:stone
fill 72 54 -360 77 54 -360 minecraft:stone
fill 89 54 -360 110 54 -360 minecraft:stone
fill 72 54 -359 76 54 -359 minecraft:stone
fill 91 54 -359 109 54 -359 minecraft:stone
fill 72 54 -358 75 54 -358 minecraft:stone
fill 92 54 -358 109 54 -358 minecraft:stone
fill 72 54 -357 75 54 -357 minecraft:stone
fill 96 54 -357 97 54 -357 minecraft:stone
fill 101 54 -357 108 54 -357 minecraft:stone
fill 72 54 -356 74 54 -356 minecraft:stone
fill 102 54 -356 108 54 -356 minecraft:stone
fill 72 54 -355 73 54 -355 minecraft:stone
fill 102 54 -355 108 54 -355 minecraft:stone
fill 103 54 -354 108 54 -354 minecraft:stone
fill 104 54 -353 108 54 -353 minecraft:stone
fill 105 54 -352 108 54 -352 minecraft:stone
fill 107 54 -351 108 54 -351 minecraft:stone
fill 72 55 -382 135 55 -382 minecraft:stone
fill 72 55 -381 135 55 -381 minecraft:stone
fill 72 55 -380 135 55 -380 minecraft:stone
fill 72 55 -379 135 55 -379 minecraft:stone
fill 72 55 -378 130 55 -378 minecraft:stone
fill 72 55 -377 127 55 -377 minecraft:stone
fill 72 55 -376 127 55 -376 minecraft:stone
fill 72 55 -375 126 55 -375 minecraft:stone
fill 72 55 -374 125 55 -374 minecraft:stone
fill 72 55 -373 125 55 -373 minecraft:stone
fill 72 55 -372 124 55 -372 minecraft:stone
fill 72 55 -371 123 55 -371 minecraft:stone
fill 72 55 -370 121 55 -370 minecraft:stone
fill 72 55 -369 119 55 -369 minecraft:stone
fill 72 55 -368 115 55 -368 minecraft:stone
fill 72 55 -367 115 55 -367 minecraft:stone
fill 72 55 -366 115 55 -366 minecraft:stone
fill 72 55 -365 115 55 -365 minecraft:stone
fill 72 55 -364 114 55 -364 minecraft:stone
fill 72 55 -363 113 55 -363 minecraft:stone
fill 72 55 -362 113 55 -362 minecraft:stone
fill 72 55 -361 79 55 -361 minecraft:stone
fill 86 55 -361 112 55 -361 minecraft:stone
fill 72 55 -360 78 55 -360 minecraft:stone
fill 87 55 -360 111 55 -360 minecraft:stone
fill 72 55 -359 78 55 -359 minecraft:stone
fill 88 55 -359 111 55 -359 minecraft:stone
fill 72 55 -358 78 55 -358 minecraft:stone
fill 89 55 -358 110 55 -358 minecraft:stone
fill 72 55 -357 77 55 -357 minecraft:stone
fill 90 55 -357 109 55 -357 minecraft:stone
fill 72 55 -356 76 55 -356 minecraft:stone
fill 92 55 -356 109 55 -356 minecraft:stone
fill 72 55 -355 75 55 -355 minecraft:stone
fill 92 55 -355 109 55 -355 minecraft:stone
fill 72 55 -354 73 55 -354 minecraft:stone
fill 92 55 -354 109 55 -354 minecraft:stone
fill 92 55 -353 109 55 -353 minecraft:stone
setblock 92 55 -352 minecraft:stone
fill 97 55 -352 109 55 -352 minecraft:stone
fill 91 55 -351 109 55 -351 minecraft:stone
fill 90 55 -350 109 55 -350 minecraft:stone
fill 90 55 -349 109 55 -349 minecraft:stone
fill 89 55 -348 109 55 -348 minecraft:stone
fill 91 55 -347 97 55 -347 minecraft:stone
fill 105 55 -347 109 55 -347 minecraft:stone
fill 107 55 -346 109 55 -346 minecraft:stone
setblock 108 55 -338 minecraft:stone
fill 107 55 -337 109 55 -337 minecraft:stone
fill 104 55 -336 110 55 -336 minecraft:stone
fill 104 55 -335 108 55 -335 minecraft:stone
fill 104 55 -334 106 55 -334 minecraft:stone
fill 104 55 -333 105 55 -333 minecraft:stone
fill 103 55 -332 105 55 -332 minecraft:stone
fill 103 55 -331 104 55 -331 minecraft:stone
fill 103 55 -330 104 55 -330 minecraft:stone
setblock 104 55 -329 minecraft:stone
setblock 100 55 -328 minecraft:stone
fill 100 55 -327 101 55 -327 minecraft:stone
fill 100 55 -326 101 55 -326 minecraft:stone
fill 100 55 -325 101 55 -325 minecraft:stone
fill 100 55 -324 101 55 -324 minecraft:stone
fill 100 55 -323 101 55 -323 minecraft:stone
fill 99 55 -322 101 55 -322 minecraft:stone
fill 99 55 -321 101 55 -321 minecraft:stone
fill 99 55 -320 101 55 -320 minecraft:stone
fill 99 55 -319 101 55 -319 minecraft:stone
fill 72 56 -382 135 56 -382 minecraft:stone
fill 72 56 -381 135 56 -381 minecraft:stone
fill 72 56 -380 135 56 -380 minecraft:stone
fill 72 56 -379 135 56 -379 minecraft:stone
fill 72 56 -378 135 56 -378 minecraft:stone
fill 72 56 -377 135 56 -377 minecraft:stone
fill 72 56 -376 135 56 -376 minecraft:stone
fill 72 56 -375 135 56 -375 minecraft:stone
fill 72 56 -374 127 56 -374 minecraft:stone
fill 134 56 -374 135 56 -374 minecraft:stone
fill 72 56 -373 127 56 -373 minecraft:stone
fill 72 56 -372 126 56 -372 minecraft:stone
fill 72 56 -371 125 56 -371 minecraft:stone
fill 72 56 -370 124 56 -370 minecraft:stone
fill 72 56 -369 122 56 -369 minecraft:stone
fill 72 56 -368 120 56 -368 minecraft:stone
fill 72 56 -367 118 56 -367 minecraft:stone
fill 72 56 -366 117 56 -366 minecraft:stone
fill 72 56 -365 117 56 -365 minecraft:stone
fill 72 56 -364 116 56 -364 minecraft:stone
fill 72 56 -363 115 56 -363 minecraft:stone
fill 72 56 -362 114 56 -362 minecraft:stone
fill 72 56 -361 114 56 -361 minecraft:stone
fill 72 56 -360 82 56 -360 minecraft:stone
fill 85 56 -360 113 56 -360 minecraft:stone
fill 72 56 -359 81 56 -359 minecraft:stone
fill 85 56 -359 112 56 -359 minecraft:stone
fill 72 56 -358 80 56 -358 minecraft:stone
fill 85 56 -358 112 56 -358 minecraft:stone
fill 72 56 -357 79 56 -357 minecraft:stone
fill 85 56 -357 111 56 -357 minecraft:stone
fill 72 56 -356 78 56 -356 minecraft:stone
fill 84 56 -356 110 56 -356 minecraft:stone
fill 72 56 -355 79 56 -355 minecraft:stone
fill 83 56 -355 110 56 -355 minecraft:stone
fill 72 56 -354 79 56 -354 minecraft:stone
fill 81 56 -354 110 56 -354 minecraft:stone
fill 74 56 -353 110 56 -353 minecraft:stone
fill 76 56 -352 111 56 -352 minecraft:stone
fill 77 56 -351 111 56 -351 minecraft:stone
fill 78 56 -350 111 56 -350 minecraft:stone
fill 79 56 -349 112 56 -349 minecraft:stone
fill 79 56 -348 112 56 -348 minecraft:stone
fill 83 56 -347 112 56 -347 minecraft:stone
fill 85 56 -346 112 56 -346 minecraft:stone
fill 86 56 -345 113 56 -345 minecraft:stone
fill 87 56 -344 98 56 -344 minecraft:stone
fill 102 56 -344 113 56 -344 minecraft:stone
fill 91 56 -343 97 56 -343 minecraft:stone
fill 103 56 -343 113 56 -343 minecraft:stone
fill 92 56 -342 96 56 -342 minecraft:stone
fill 104 56 -342 112 56 -342 minecraft:stone
fill 105 56 -341 112 56 -341 minecraft:stone
fill 106 56 -340 112 56 -340 minecraft:stone
fill 105 56 -339 112 56 -339 minecraft:stone
fill 104 56 -338 113 56 -338 minecraft:stone
fill 103 56 -337 113 56 -337 minecraft:stone
fill 102 56 -336 113 56 -336 minecraft:stone
fill 101 56 -335 113 56 -335 minecraft:stone
fill 100 56 -334 113 56 -334 minecraft:stone
fill 100 56 -333 113 56 -333 minecraft:stone
fill 99 56 -332 113 56 -332 minecraft:stone
fill 99 56 -331 112 56 -331 minecraft:stone
fill 98 56 -330 112 56 -330 minecraft:stone
fill 98 56 -329 112 56 -329 minecraft:stone
fill 98 56 -328 112 56 -328 minecraft:stone
fill 98 56 -327 110 56 -327 minecraft:stone
fill 97 56 -326 108 56 -326 minecraft:stone
fill 97 56 -325 107 56 -325 minecraft:stone
fill 97 56 -324 107 56 -324 minecraft:stone
fill 97 56 -323 106 56 -323 minecraft:stone
fill 97 56 -322 105 56 -322 minecraft:stone
fill 97 56 -321 105 56 -321 minecraft:stone
fill 97 56 -320 104 56 -320 minecraft:stone
fill 97 56 -319 104 56 -319 minecraft:stone
fill 72 57 -382 135 57 -382 minecraft:stone
fill 72 57 -381 135 57 -381 minecraft:stone
fill 72 57 -380 135 57 -380 minecraft:stone
fill 72 57 -379 135 57 -379 minecraft:stone
fill 72 57 -378 135 57 -378 minecraft:stone
fill 72 57 -377 135 57 -377 minecraft:stone
fill 72 57 -376 135 57 -376 minecraft:stone
fill 72 57 -375 135 57 -375 minecraft:stone
fill 72 57 -374 135 57 -374 minecraft:stone
fill 72 57 -373 135 57 -373 minecraft:stone
fill 72 57 -372 127 57 -372 minecraft:stone
fill 72 57 -371 126 57 -371 minecraft:stone
fill 72 57 -370 125 57 -370 minecraft:stone
fill 72 57 -369 123 57 -369 minecraft:stone
fill 72 57 -368 121 57 -368 minecraft:stone
fill 72 57 -367 120 57 -367 minecraft:stone
fill 72 57 -366 119 57 -366 minecraft:stone
fill 72 57 -365 118 57 -365 minecraft:stone
fill 72 57 -364 118 57 -364 minecraft:stone
fill 72 57 -363 116 57 -363 minecraft:stone
fill 72 57 -362 115 57 -362 minecraft:stone
fill 72 57 -361 114 57 -361 minecraft:stone
fill 72 57 -360 83 57 -360 minecraft:stone
fill 85 57 -360 114 57 -360 minecraft:stone
fill 72 57 -359 113 57 -359 minecraft:stone
fill 72 57 -358 112 57 -358 minecraft:stone
fill 72 57 -357 111 57 -357 minecraft:stone
fill 72 57 -356 79 57 -356 minecraft:stone
fill 81 57 -356 111 57 -356 minecraft:stone
fill 72 57 -355 111 57 -355 minecraft:stone
fill 72 57 -354 111 57 -354 minecraft:stone
fill 72 57 -353 111 57 -353 minecraft:stone
fill 75 57 -352 111 57 -352 minecraft:stone
fill 76 57 -351 111 57 -351 minecraft:stone
fill 76 57 -350 112 57 -350 minecraft:stone
fill 77 57 -349 112 57 -349 minecraft:stone
fill 77 57 -348 113 57 -348 minecraft:stone
fill 81 57 -347 113 57 -347 minecraft:stone
fill 84 57 -346 113 57 -346 minecraft:stone
fill 85 57 -345 113 57 -345 minecraft:stone
fill 86 57 -344 113 57 -344 minecraft:stone
fill 89 57 -343 98 57 -343 minecraft:stone
fill 102 57 -343 113 57 -343 minecraft:stone
fill 91 57 -342 97 57 -342 minecraft:stone
fill 103 57 -342 113 57 -342 minecraft:stone
fill 92 57 -341 96 57 -341 minecraft:stone
fill 104 57 -341 113 57 -341 minecraft:stone
fill 105 57 -340 113 57 -340 minecraft:stone
fill 104 57 -339 113 57 -339 minecraft:stone
fill 103 57 -338 113 57 -338 minecraft:stone
fill 102 57 -337 113 57 -337 minecraft:stone
fill 101 57 -336 114 57 -336 minecraft:stone
fill 100 57 -335 114 57 -335 minecraft:stone
fill 99 57 -334 114 57 -334 minecraft:stone
fill 99 57 -333 114 57 -333 minecraft:stone
fill 98 57 -332 115 57 -332 minecraft:stone
fill 97 57 -331 114 57 -331 minecraft:stone
fill 97 57 -330 114 57 -330 minecraft:stone
fill 97 57 -329 113 57 -329 minecraft:stone
fill 97 57 -328 113 57 -328 minecraft:stone
fill 97 57 -327 112 57 -327 minecraft:stone
fill 96 57 -326 112 57 -326 minecraft:stone
fill 96 57 -325 112 57 -325 minecraft:stone
fill 96 57 -324 112 57 -324 minecraft:stone
fill 96 57 -323 107 57 -323 minecraft:stone
fill 96 57 -322 106 57 -322 minecraft:stone
fill 96 57 -321 106 57 -321 minecraft:stone
fill 96 57 -320 105 57 -320 minecraft:stone
fill 96 57 -319 105 57 -319 minecraft:stone
fill 72 58 -382 135 58 -382 minecraft:stone
fill 72 58 -381 135 58 -381 minecraft:stone
fill 72 58 -380 135 58 -380 minecraft:stone
fill 72 58 -379 135 58 -379 minecraft:stone
fill 72 58 -378 135 58 -378 minecraft:stone
fill 72 58 -377 135 58 -377 minecraft:stone
fill 72 58 -376 135 58 -376 minecraft:stone
fill 72 58 -375 135 58 -375 minecraft:stone
fill 72 58 -374 135 58 -374 minecraft:stone
fill 72 58 -373 135 58 -373 minecraft:stone
fill 72 58 -372 135 58 -372 minecraft:stone
fill 72 58 -371 135 58 -371 minecraft:stone
fill 72 58 -370 127 58 -370 minecraft:stone
fill 134 58 -370 135 58 -370 minecraft:stone
fill 72 58 -369 126 58 -369 minecraft:stone
fill 72 58 -368 123 58 -368 minecraft:stone
fill 72 58 -367 122 58 -367 minecraft:stone
fill 72 58 -366 121 58 -366 minecraft:stone
fill 72 58 -365 120 58 -365 minecraft:stone
fill 72 58 -364 119 58 -364 minecraft:stone
fill 72 58 -363 118 58 -363 minecraft:stone
fill 72 58 -362 117 58 -362 minecraft:stone
fill 72 58 -361 115 58 -361 minecraft:stone
fill 72 58 -360 115 58 -360 minecraft:stone
fill 72 58 -359 114 58 -359 minecraft:stone
fill 72 58 -358 113 58 -358 minecraft:stone
fill 72 58 -357 112 58 -357 minecraft:stone
fill 72 58 -356 111 58 -356 minecraft:stone
fill 72 58 -355 111 58 -355 minecraft:stone
fill 72 58 -354 111 58 -354 minecraft:stone
fill 72 58 -353 111 58 -353 minecraft:stone
fill 74 58 -352 111 58 -352 minecraft:stone
fill 75 58 -351 112 58 -351 minecraft:stone
fill 75 58 -350 113 58 -350 minecraft:stone
fill 76 58 -349 113 58 -349 minecraft:stone
fill 76 58 -348 113 58 -348 minecraft:stone
fill 79 58 -347 113 58 -347 minecraft:stone
fill 82 58 -346 113 58 -346 minecraft:stone
fill 84 58 -345 113 58 -345 minecraft:stone
fill 85 58 -344 113 58 -344 minecraft:stone
fill 88 58 -343 113 58 -343 minecraft:stone
fill 90 58 -342 99 58 -342 minecraft:stone
fill 102 58 -342 113 58 -342 minecraft:stone
fill 91 58 -341 97 58 -341 minecraft:stone
fill 103 58 -341 113 58 -341 minecraft:stone
fill 92 58 -340 96 58 -340 minecraft:stone
fill 104 58 -340 113 58 -340 minecraft:stone
fill 103 58 -339 113 58 -339 minecraft:stone
fill 101 58 -338 114 58 -338 minecraft:stone
fill 100 58 -337 114 58 -337 minecraft:stone
fill 100 58 -336 114 58 -336 minecraft:stone
fill 99 58 -335 115 58 -335 minecraft:stone
fill 98 58 -334 115 58 -334 minecraft:stone
fill 98 58 -333 115 58 -333 minecraft:stone
fill 96 58 -332 116 58 -332 minecraft:stone
fill 96 58 -331 116 58 -331 minecraft:stone
fill 96 58 -330 115 58 -330 minecraft:stone
fill 96 58 -329 114 58 -329 minecraft:stone
fill 96 58 -328 114 58 -328 minecraft:stone
fill 96 58 -327 113 58 -327 minecraft:stone
fill 96 58 -326 113 58 -326 minecraft:stone
fill 96 58 -325 112 58 -325 minecraft:stone
fill 96 58 -324 112 58 -324 minecraft:stone
fill 96 58 -323 111 58 -323 minecraft:stone
fill 96 58 -322 107 58 -322 minecraft:stone
fill 96 58 -321 107 58 -321 minecraft:stone
fill 96 58 -320 106 58 -320 minecraft:stone
fill 96 58 -319 106 58 -319 minecraft:stone
fill 72 59 -382 135 59 -382 minecraft:stone
fill 72 59 -381 135 59 -381 minecraft:stone
fill 72 59 -380 135 59 -380 minecraft:stone
fill 72 59 -379 135 59 -379 minecraft:stone
fill 72 59 -378 135 59 -378 minecraft:stone
fill 72 59 -377 135 59 -377 minecraft:stone
fill 72 59 -376 135 59 -376 minecraft:stone
fill 72 59 -375 135 59 -375 minecraft:stone
fill 72 59 -374 135 59 -374 minecraft:stone
fill 72 59 -373 135 59 -373 minecraft:stone
fill 72 59 -372 135 59 -372 minecraft:stone
fill 72 59 -371 135 59 -371 minecraft:stone
fill 72 59 -370 135 59 -370 minecraft:stone
fill 72 59 -369 135 59 -369 minecraft:stone
fill 72 59 -368 126 59 -368 minecraft:stone
fill 133 59 -368 135 59 -368 minecraft:stone
fill 72 59 -367 125 59 -367 minecraft:stone
fill 72 59 -366 124 59 -366 minecraft:stone
fill 72 59 -365 123 59 -365 minecraft:stone
fill 72 59 -364 121 59 -364 minecraft:stone
fill 72 59 -363 120 59 -363 minecraft:stone
fill 72 59 -362 119 59 -362 minecraft:stone
fill 72 59 -361 118 59 -361 minecraft:stone
fill 72 59 -360 115 59 -360 minecraft:stone
fill 72 59 -359 115 59 -359 minecraft:stone
fill 72 59 -358 114 59 -358 minecraft:stone
fill 72 59 -357 114 59 -357 minecraft:stone
fill 72 59 -356 112 59 -356 minecraft:stone
fill 72 59 -355 112 59 -355 minecraft:stone
fill 72 59 -354 112 59 -354 minecraft:stone
fill 72 59 -353 112 59 -353 minecraft:stone
fill 72 59 -352 112 59 -352 minecraft:stone
fill 73 59 -351 113 59 -351 minecraft:stone
fill 74 59 -350 113 59 -350 minecraft:stone
fill 75 59 -349 114 59 -349 minecraft:stone
fill 75 59 -348 114 59 -348 minecraft:stone
fill 77 59 -347 114 59 -347 minecraft:stone
fill 80 59 -346 114 59 -346 minecraft:stone
fill 82 59 -345 114 59 -345 minecraft:stone
fill 84 59 -344 114 59 -344 minecraft:stone
fill 87 59 -343 114 59 -343 minecraft:stone
fill 89 59 -342 114 59 -342 minecraft:stone
fill 91 59 -341 99 59 -341 minecraft:stone
fill 101 59 -341 114 59 -341 minecraft:stone
fill 91 59 -340 98 59 -340 minecraft:stone
fill 103 59 -340 114 59 -340 minecraft:stone
fill 92 59 -339 97 59 -339 minecraft:stone
fill 101 59 -339 114 59 -339 minecraft:stone
fill 99 59 -338 114 59 -338 minecraft:stone
fill 99 59 -337 115 59 -337 minecraft:stone
fill 99 59 -336 115 59 -336 minecraft:stone
fill 98 59 -335 115 59 -335 minecraft:stone
fill 97 59 -334 116 59 -334 minecraft:stone
fill 96 59 -333 116 59 -333 minecraft:stone
fill 96 59 -332 116 59 -332 minecraft:stone
fill 96 59 -331 116 59 -331 minecraft:stone
fill 96 59 -330 116 59 -330 minecraft:stone
fill 96 59 -329 116 59 -329 minecraft:stone
fill 96 59 -328 115 59 -328 minecraft:stone
fill 96 59 -327 114 59 -327 minecraft:stone
fill 96 59 -326 114 59 -326 minecraft:stone
fill 95 59 -325 113 59 -325 minecraft:stone
fill 95 59 -324 113 59 -324 minecraft:stone
fill 95 59 -323 112 59 -323 minecraft:stone
fill 95 59 -322 111 59 -322 minecraft:stone
fill 95 59 -321 108 59 -321 minecraft:stone
fill 96 59 -320 107 59 -320 minecraft:stone
fill 95 59 -319 107 59 -319 minecraft:stone
fill 72 60 -382 135 60 -382 minecraft:stone
fill 72 60 -381 135 60 -381 minecraft:stone
fill 72 60 -380 135 60 -380 minecraft:stone
fill 72 60 -379 135 60 -379 minecraft:stone
fill 72 60 -378 135 60 -378 minecraft:stone
fill 72 60 -377 135 60 -377 minecraft:stone
fill 72 60 -376 135 60 -376 minecraft:stone
fill 72 60 -375 135 60 -375 minecraft:stone
fill 72 60 -374 135 60 -374 minecraft:stone
fill 72 60 -373 135 60 -373 minecraft:stone
fill 72 60 -372 135 60 -372 minecraft:stone
fill 72 60 -371 135 60 -371 minecraft:stone
fill 72 60 -370 135 60 -370 minecraft:stone
fill 72 60 -369 135 60 -369 minecraft:stone
fill 72 60 -368 135 60 -368 minecraft:stone
fill 72 60 -367 135 60 -367 minecraft:stone
fill 72 60 -366 135 60 -366 minecraft:stone
fill 72 60 -365 127 60 -365 minecraft:stone
fill 134 60 -365 135 60 -365 minecraft:stone
fill 72 60 -364 126 60 -364 minecraft:stone
fill 72 60 -363 124 60 -363 minecraft:stone
fill 72 60 -362 122 60 -362 minecraft:stone
fill 72 60 -361 121 60 -361 minecraft:stone
fill 72 60 -360 119 60 -360 minecraft:stone
fill 72 60 -359 118 60 -359 minecraft:stone
fill 72 60 -358 115 60 -358 minecraft:stone
fill 72 60 -357 115 60 -357 minecraft:stone
fill 72 60 -356 114 60 -356 minecraft:stone
fill 72 60 -355 113 60 -355 minecraft:stone
fill 72 60 -354 113 60 -354 minecraft:stone
fill 72 60 -353 113 60 -353 minecraft:stone
fill 72 60 -352 113 60 -352 minecraft:stone
fill 72 60 -351 114 60 -351 minecraft:stone
fill 73 60 -350 114 60 -350 minecraft:stone
fill 74 60 -349 114 60 -349 minecraft:stone
fill 74 60 -348 114 60 -348 minecraft:stone
fill 76 60 -347 114 60 -347 minecraft:stone
fill 78 60 -346 114 60 -346 minecraft:stone
fill 81 60 -345 114 60 -345 minecraft:stone
fill 82 60 -344 114 60 -344 minecraft:stone
fill 84 60 -343 114 60 -343 minecraft:stone
fill 89 60 -342 114 60 -342 minecraft:stone
fill 90 60 -341 114 60 -341 minecraft:stone
fill 91 60 -340 99 60 -340 minecraft:stone
fill 101 60 -340 114 60 -340 minecraft:stone
fill 91 60 -339 114 60 -339 minecraft:stone
fill 91 60 -338 115 60 -338 minecraft:stone
fill 98 60 -337 115 60 -337 minecraft:stone
fill 98 60 -336 116 60 -336 minecraft:stone
fill 97 60 -335 116 60 -335 minecraft:stone
fill 96 60 -334 117 60 -334 minecraft:stone
fill 96 60 -333 117 60 -333 minecraft:stone
fill 95 60 -332 117 60 -332 minecraft:stone
fill 95 60 -331 117 60 -331 minecraft:stone
fill 95 60 -330 116 60 -330 minecraft:stone
fill 95 60 -329 116 60 -329 minecraft:stone
fill 95 60 -328 116 60 -328 minecraft:stone
fill 95 60 -327 115 60 -327 minecraft:stone
fill 95 60 -326 114 60 -326 minecraft:stone
fill 95 60 -325 114 60 -325 minecraft:stone
fill 95 60 -324 113 60 -324 minecraft:stone
fill 95 60 -323 113 60 -323 minecraft:stone
fill 95 60 -322 112 60 -322 minecraft:stone
fill 95 60 -321 112 60 -321 minecraft:stone
fill 95 60 -320 109 60 -320 minecraft:stone
fill 95 60 -319 109 60 -319 minecraft:stone
fill 72 61 -382 135 61 -382 minecraft:stone
fill 72 61 -381 135 61 -381 minecraft:stone
fill 72 61 -380 135 61 -380 minecraft:stone
fill 72 61 -379 135 61 -379 minecraft:stone
fill 72 61 -378 135 61 -378 minecraft:stone
fill 72 61 -377 135 61 -377 minecraft:stone
fill 72 61 -376 135 61 -376 minecraft:stone
fill 72 61 -375 135 61 -375 minecraft:stone
fill 72 61 -374 135 61 -374 minecraft:stone
fill 72 61 -373 135 61 -373 minecraft:stone
fill 72 61 -372 135 61 -372 minecraft:stone
fill 72 61 -371 135 61 -371 minecraft:stone
fill 72 61 -370 135 61 -370 minecraft:stone
fill 72 61 -369 135 61 -369 minecraft:stone
fill 72 61 -368 135 61 -368 minecraft:stone
fill 72 61 -367 135 61 -367 minecraft:stone
fill 72 61 -366 135 61 -366 minecraft:stone
fill 72 61 -365 135 61 -365 minecraft:stone
fill 72 61 -364 135 61 -364 minecraft:stone
fill 72 61 -363 135 61 -363 minecraft:stone
fill 72 61 -362 127 61 -362 minecraft:stone
fill 72 61 -361 125 61 -361 minecraft:stone
fill 72 61 -360 124 61 -360 minecraft:stone
fill 72 61 -359 123 61 -359 minecraft:stone
fill 72 61 -358 122 61 -358 minecraft:stone
fill 72 61 -357 121 61 -357 minecraft:stone
fill 72 61 -356 115 61 -356 minecraft:stone
fill 119 61 -356 120 61 -356 minecraft:stone
fill 72 61 -355 115 61 -355 minecraft:stone
setblock 120 61 -355 minecraft:stone
fill 72 61 -354 115 61 -354 minecraft:stone
fill 72 61 -353 114 61 -353 minecraft:stone
fill 72 61 -352 114 61 -352 minecraft:stone
fill 72 61 -351 115 61 -351 minecraft:stone
fill 72 61 -350 115 61 -350 minecraft:stone
fill 72 61 -349 115 61 -349 minecraft:stone
fill 73 61 -348 115 61 -348 minecraft:stone
fill 74 61 -347 115 61 -347 minecraft:stone
fill 76 61 -346 115 61 -346 minecraft:stone
fill 79 61 -345 115 61 -345 minecraft:stone
fill 80 61 -344 115 61 -344 minecraft:stone
fill 82 61 -343 115 61 -343 minecraft:stone
fill 83 61 -342 115 61 -342 minecraft:stone
fill 89 61 -341 115 61 -341 minecraft:stone
fill 90 61 -340 115 61 -340 minecraft:stone
fill 90 61 -339 115 61 -339 minecraft:stone
fill 90 61 -338 115 61 -338 minecraft:stone
fill 89 61 -337 116 61 -337 minecraft:stone
fill 88 61 -336 92 61 -336 minecraft:stone
fill 97 61 -336 117 61 -336 minecraft:stone
fill 72 61 -335 74 61 -335 minecraft:stone
fill 88 61 -335 90 61 -335 minecraft:stone
fill 95 61 -335 117 61 -335 minecraft:stone
fill 72 61 -334 74 61 -334 minecraft:stone
fill 87 61 -334 89 61 -334 minecraft:stone
fill 94 61 -334 118 61 -334 minecraft:stone
fill 72 61 -333 73 61 -333 minecraft:stone
fill 87 61 -333 88 61 -333 minecraft:stone
fill 94 61 -333 118 61 -333 minecraft:stone
fill 87 61 -332 88 61 -332 minecraft:stone
fill 94 61 -332 118 61 -332 minecraft:stone
fill 94 61 -331 118 61 -331 minecraft:stone
fill 94 61 -330 117 61 -330 minecraft:stone
fill 94 61 -329 117 61 -329 minecraft:stone
fill 94 61 -328 116 61 -328 minecraft:stone
fill 94 61 -327 116 61 -327 minecraft:stone
fill 94 61 -326 115 61 -326 minecraft:stone
fill 94 61 -325 115 61 -325 minecraft:stone
fill 94 61 -324 114 61 -324 minecraft:stone
fill 94 61 -323 114 61 -323 minecraft:stone
fill 94 61 -322 113 61 -322 minecraft:stone
setblock 121 61 -322 minecraft:stone
fill 94 61 -321 112 61 -321 minecraft:stone
fill 120 61 -321 121 61 -321 minecraft:stone
fill 94 61 -320 112 61 -320 minecraft:stone
fill 120 61 -320 121 61 -320 minecraft:stone
fill 94 61 -319 111 61 -319 minecraft:stone
fill 119 61 -319 120 61 -319 minecraft:stone
fill 72 62 -382 135 62 -382 minecraft:dirt
fill 72 62 -381 135 62 -381 minecraft:dirt
fill 72 62 -380 135 62 -380 minecraft:dirt
fill 72 62 -379 135 62 -379 minecraft:dirt
fill 72 62 -378 135 62 -378 minecraft:dirt
fill 72 62 -377 135 62 -377 minecraft:dirt
fill 72 62 -376 135 62 -376 minecraft:dirt
fill 72 62 -375 135 62 -375 minecraft:dirt
fill 72 62 -374 135 62 -374 minecraft:dirt
fill 72 62 -373 135 62 -373 minecraft:dirt
fill 72 62 -372 135 62 -372 minecraft:dirt
fill 72 62 -371 135 62 -371 minecraft:dirt
fill 72 62 -370 135 62 -370 minecraft:dirt
fill 72 62 -369 135 62 -369 minecraft:dirt
fill 72 62 -368 135 62 -368 minecraft:dirt
fill 72 62 -367 135 62 -367 minecraft:dirt
fill 72 62 -366 135 62 -366 minecraft:dirt
fill 72 62 -365 135 62 -365 minecraft:dirt
fill 72 62 -364 135 62 -364 minecraft:dirt
fill 72 62 -363 135 62 -363 minecraft:dirt
fill 72 62 -362 128 62 -362 minecraft:dirt
fill 130 62 -362 135 62 -362 minecraft:dirt
fill 72 62 -361 126 62 -361 minecraft:dirt
fill 129 62 -361 135 62 -361 minecraft:dirt
fill 72 62 -360 125 62 -360 minecraft:dirt
fill 128 62 -360 135 62 -360 minecraft:dirt
fill 72 62 -359 123 62 -359 minecraft:dirt
setblock 125 62 -359 minecraft:dirt
setblock 127 62 -359 minecraft:dirt
fill 72 62 -358 124 62 -358 minecraft:dirt
fill 72 62 -357 123 62 -357 minecraft:dirt
setblock 125 62 -357 minecraft:dirt
fill 72 62 -356 123 62 -356 minecraft:dirt
fill 72 62 -355 122 62 -355 minecraft:dirt
setblock 124 62 -355 minecraft:dirt
fill 72 62 -354 124 62 -354 minecraft:dirt
fill 72 62 -353 120 62 -353 minecraft:dirt
setblock 122 62 -353 minecraft:dirt
fill 72 62 -352 124 62 -352 minecraft:dirt
fill 72 62 -351 121 62 -351 minecraft:dirt
fill 123 62 -351 124 62 -351 minecraft:dirt
fill 72 62 -350 125 62 -350 minecraft:dirt
fill 72 62 -349 122 62 -349 minecraft:dirt
fill 124 62 -349 125 62 -349 minecraft:dirt
fill 72 62 -348 123 62 -348 minecraft:dirt
fill 126 62 -348 127 62 -348 minecraft:dirt
fill 72 62 -347 126 62 -347 minecraft:dirt
fill 73 62 -346 126 62 -346 minecraft:dirt
fill 77 62 -345 115 62 -345 minecraft:dirt
fill 122 62 -345 125 62 -345 minecraft:dirt
fill 79 62 -344 115 62 -344 minecraft:dirt
fill 123 62 -344 125 62 -344 minecraft:dirt
fill 79 62 -343 115 62 -343 minecraft:dirt
fill 80 62 -342 115 62 -342 minecraft:dirt
fill 81 62 -341 87 62 -341 minecraft:dirt
fill 89 62 -341 115 62 -341 minecraft:dirt
fill 83 62 -340 85 62 -340 minecraft:dirt
fill 89 62 -340 115 62 -340 minecraft:dirt
fill 83 62 -339 85 62 -339 minecraft:dirt
fill 89 62 -339 117 62 -339 minecraft:dirt
setblock 76 62 -338 minecraft:dirt
fill 84 62 -338 117 62 -338 minecraft:dirt
fill 75 62 -337 77 62 -337 minecraft:dirt
fill 84 62 -337 118 62 -337 minecraft:dirt
fill 72 62 -336 75 62 -336 minecraft:dirt
setblock 77 62 -336 minecraft:dirt
fill 84 62 -336 118 62 -336 minecraft:dirt
fill 72 62 -335 74 62 -335 minecraft:dirt
setblock 76 62 -335 minecraft:dirt
fill 84 62 -335 118 62 -335 minecraft:dirt
fill 72 62 -334 74 62 -334 minecraft:dirt
setblock 76 62 -334 minecraft:dirt
fill 83 62 -334 119 62 -334 minecraft:dirt
fill 72 62 -333 74 62 -333 minecraft:dirt
fill 83 62 -333 119 62 -333 minecraft:dirt
setblock 72 62 -332 minecraft:dirt
fill 83 62 -332 91 62 -332 minecraft:dirt
fill 93 62 -332 118 62 -332 minecraft:dirt
fill 84 62 -331 91 62 -331 minecraft:dirt
fill 93 62 -331 118 62 -331 minecraft:dirt
fill 72 62 -330 74 62 -330 minecraft:dirt
fill 84 62 -330 88 62 -330 minecraft:dirt
fill 93 62 -330 117 62 -330 minecraft:dirt
fill 72 62 -329 74 62 -329 minecraft:dirt
fill 93 62 -329 118 62 -329 minecraft:dirt
fill 72 62 -328 74 62 -328 minecraft:dirt
fill 93 62 -328 116 62 -328 minecraft:dirt
fill 72 62 -327 73 62 -327 minecraft:dirt
fill 93 62 -327 117 62 -327 minecraft:dirt
setblock 72 62 -326 minecraft:dirt
fill 93 62 -326 116 62 -326 minecraft:dirt
fill 93 62 -325 115 62 -325 minecraft:dirt
fill 92 62 -324 115 62 -324 minecraft:dirt
fill 120 62 -324 121 62 -324 minecraft:dirt
fill 92 62 -323 115 62 -323 minecraft:dirt
fill 120 62 -323 121 62 -323 minecraft:dirt
fill 93 62 -322 114 62 -322 minecraft:dirt
fill 119 62 -322 121 62 -322 minecraft:dirt
fill 93 62 -321 114 62 -321 minecraft:dirt
fill 119 62 -321 121 62 -321 minecraft:dirt
fill 93 62 -320 113 62 -320 minecraft:dirt
fill 119 62 -320 121 62 -320 minecraft:dirt
fill 93 62 -319 112 62 -319 minecraft:dirt
fill 119 62 -319 121 62 -319 minecraft:dirt
fill 72 63 -382 135 63 -382 minecraft:dirt
fill 72 63 -381 135 63 -381 minecraft:dirt
fill 72 63 -380 135 63 -380 minecraft:dirt
fill 72 63 -379 135 63 -379 minecraft:dirt
fill 72 63 -378 135 63 -378 minecraft:dirt
fill 72 63 -377 135 63 -377 minecraft:dirt
fill 72 63 -376 135 63 -376 minecraft:dirt
fill 72 63 -375 135 63 -375 minecraft:dirt
fill 72 63 -374 135 63 -374 minecraft:dirt
fill 72 63 -373 135 63 -373 minecraft:dirt
fill 72 63 -372 135 63 -372 minecraft:dirt
fill 72 63 -371 135 63 -371 minecraft:dirt
fill 72 63 -370 135 63 -370 minecraft:dirt
fill 72 63 -369 135 63 -369 minecraft:dirt
fill 72 63 -368 135 63 -368 minecraft:dirt
fill 72 63 -367 135 63 -367 minecraft:dirt
fill 72 63 -366 135 63 -366 minecraft:dirt
fill 72 63 -365 135 63 -365 minecraft:dirt
fill 72 63 -364 135 63 -364 minecraft:dirt
fill 72 63 -363 135 63 -363 minecraft:dirt
fill 72 63 -362 128 63 -362 minecraft:dirt
fill 130 63 -362 135 63 -362 minecraft:dirt
fill 72 63 -361 126 63 -361 minecraft:dirt
fill 129 63 -361 135 63 -361 minecraft:dirt
fill 72 63 -360 125 63 -360 minecraft:dirt
fill 128 63 -360 135 63 -360 minecraft:dirt
fill 72 63 -359 123 63 -359 minecraft:dirt
setblock 125 63 -359 minecraft:dirt
fill 127 63 -359 135 63 -359 minecraft:dirt
fill 72 63 -358 124 63 -358 minecraft:dirt
fill 127 63 -358 135 63 -358 minecraft:dirt
fill 72 63 -357 123 63 -357 minecraft:dirt
setblock 125 63 -357 minecraft:dirt
fill 127 63 -357 129 63 -357 minecraft:dirt
setblock 135 63 -357 minecraft:dirt
fill 72 63 -356 123 63 -356 minecraft:dirt
fill 126 63 -356 127 63 -356 minecraft:dirt
fill 72 63 -355 122 63 -355 minecraft:dirt
setblock 124 63 -355 minecraft:dirt
setblock 126 63 -355 minecraft:dirt
fill 72 63 -354 127 63 -354 minecraft:dirt
fill 72 63 -353 120 63 -353 minecraft:dirt
setblock 122 63 -353 minecraft:dirt
fill 126 63 -353 127 63 -353 minecraft:dirt
fill 72 63 -352 124 63 -352 minecraft:dirt
fill 126 63 -352 127 63 -352 minecraft:dirt
fill 72 63 -351 121 63 -351 minecraft:dirt
fill 123 63 -351 124 63 -351 minecraft:dirt
fill 128 63 -351 130 63 -351 minecraft:dirt
fill 72 63 -350 125 63 -350 minecraft:dirt
fill 128 63 -350 130 63 -350 minecraft:dirt
setblock 132 63 -350 minecraft:dirt
fill 72 63 -349 122 63 -349 minecraft:dirt
fill 124 63 -349 125 63 -349 minecraft:dirt
setblock 129 63 -349 minecraft:dirt
setblock 132 63 -349 minecraft:dirt
fill 72 63 -348 123 63 -348 minecraft:dirt
fill 126 63 -348 128 63 -348 minecraft:dirt
fill 130 63 -348 131 63 -348 minecraft:dirt
setblock 133 63 -348 minecraft:dirt
fill 72 63 -347 126 63 -347 minecraft:dirt
setblock 129 63 -347 minecraft:dirt
setblock 131 63 -347 minecraft:dirt
fill 73 63 -346 128 63 -346 minecraft:dirt
setblock 130 63 -346 minecraft:dirt
fill 72 63 -345 126 63 -345 minecraft:dirt
fill 72 63 -344 75 63 -344 minecraft:dirt
fill 77 63 -344 115 63 -344 minecraft:dirt
fill 117 63 -344 125 63 -344 minecraft:dirt
fill 127 63 -344 129 63 -344 minecraft:dirt
fill 72 63 -343 127 63 -343 minecraft:dirt
fill 72 63 -342 124 63 -342 minecraft:dirt
fill 72 63 -341 125 63 -341 minecraft:dirt
fill 72 63 -340 87 63 -340 minecraft:dirt
fill 89 63 -340 124 63 -340 minecraft:dirt
fill 74 63 -339 121 63 -339 minecraft:dirt
fill 75 63 -338 120 63 -338 minecraft:dirt
fill 74 63 -337 119 63 -337 minecraft:dirt
fill 72 63 -336 75 63 -336 minecraft:dirt
fill 77 63 -336 119 63 -336 minecraft:dirt
fill 72 63 -335 74 63 -335 minecraft:dirt
fill 76 63 -335 77 63 -335 minecraft:dirt
fill 79 63 -335 119 63 -335 minecraft:dirt
fill 72 63 -334 74 63 -334 minecraft:dirt
setblock 76 63 -334 minecraft:dirt
fill 79 63 -334 120 63 -334 minecraft:dirt
fill 72 63 -333 75 63 -333 minecraft:dirt
fill 80 63 -333 120 63 -333 minecraft:dirt
setblock 72 63 -332 minecraft:dirt
fill 80 63 -332 118 63 -332 minecraft:dirt
fill 120 63 -332 121 63 -332 minecraft:dirt
fill 72 63 -331 74 63 -331 minecraft:dirt
fill 80 63 -331 120 63 -331 minecraft:dirt
fill 72 63 -330 75 63 -330 minecraft:dirt
fill 81 63 -330 117 63 -330 minecraft:dirt
fill 72 63 -329 75 63 -329 minecraft:dirt
fill 81 63 -329 118 63 -329 minecraft:dirt
fill 72 63 -328 74 63 -328 minecraft:dirt
fill 82 63 -328 116 63 -328 minecraft:dirt
fill 72 63 -327 74 63 -327 minecraft:dirt
fill 83 63 -327 118 63 -327 minecraft:dirt
setblock 72 63 -326 minecraft:dirt
fill 84 63 -326 117 63 -326 minecraft:dirt
fill 86 63 -325 116 63 -325 minecraft:dirt
fill 120 63 -325 121 63 -325 minecraft:dirt
fill 88 63 -324 115 63 -324 minecraft:dirt
fill 119 63 -324 121 63 -324 minecraft:dirt
fill 88 63 -323 116 63 -323 minecraft:dirt
fill 120 63 -323 121 63 -323 minecraft:dirt
fill 72 63 -322 73 63 -322 minecraft:dirt
fill 88 63 -322 115 63 -322 minecraft:dirt
fill 119 63 -322 121 63 -322 minecraft:dirt
fill 88 63 -321 115 63 -321 minecraft:dirt
fill 119 63 -321 121 63 -321 minecraft:dirt
fill 87 63 -320 114 63 -320 minecraft:dirt
fill 119 63 -320 121 63 -320 minecraft:dirt
fill 88 63 -319 114 63 -319 minecraft:dirt
fill 119 63 -319 121 63 -319 minecraft:dirt
fill 72 64 -382 135 64 -382 minecraft:dirt
fill 72 64 -381 135 64 -381 minecraft:dirt
fill 72 64 -380 135 64 -380 minecraft:dirt
fill 72 64 -379 135 64 -379 minecraft:dirt
fill 72 64 -378 135 64 -378 minecraft:dirt
fill 72 64 -377 135 64 -377 minecraft:dirt
fill 72 64 -376 135 64 -376 minecraft:dirt
fill 72 64 -375 135 64 -375 minecraft:dirt
fill 72 64 -374 135 64 -374 minecraft:dirt
fill 72 64 -373 135 64 -373 minecraft:dirt
fill 72 64 -372 135 64 -372 minecraft:dirt
fill 72 64 -371 135 64 -371 minecraft:dirt
fill 72 64 -370 135 64 -370 minecraft:dirt
fill 72 64 -369 135 64 -369 minecraft:dirt
fill 72 64 -368 135 64 -368 minecraft:dirt
fill 72 64 -367 135 64 -367 minecraft:dirt
fill 72 64 -366 135 64 -366 minecraft:dirt
fill 72 64 -365 135 64 -365 minecraft:dirt
fill 72 64 -364 135 64 -364 minecraft:dirt
fill 72 64 -363 135 64 -363 minecraft:dirt
fill 72 64 -362 135 64 -362 minecraft:dirt
fill 72 64 -361 135 64 -361 minecraft:dirt
fill 72 64 -360 135 64 -360 minecraft:dirt
fill 72 64 -359 135 64 -359 minecraft:dirt
fill 72 64 -358 135 64 -358 minecraft:dirt
fill 72 64 -357 125 64 -357 minecraft:dirt
fill 127 64 -357 135 64 -357 minecraft:dirt
fill 72 64 -356 124 64 -356 minecraft:dirt
fill 126 64 -356 135 64 -356 minecraft:dirt
fill 72 64 -355 124 64 -355 minecraft:dirt
setblock 126 64 -355 minecraft:dirt
fill 128 64 -355 135 64 -355 minecraft:dirt
fill 72 64 -354 135 64 -354 minecraft:dirt
fill 72 64 -353 124 64 -353 minecraft:dirt
fill 126 64 -353 135 64 -353 minecraft:dirt
fill 72 64 -352 124 64 -352 minecraft:dirt
fill 126 64 -352 135 64 -352 minecraft:dirt
fill 72 64 -351 124 64 -351 minecraft:dirt
fill 128 64 -351 135 64 -351 minecraft:dirt
fill 72 64 -350 125 64 -350 minecraft:dirt
fill 128 64 -350 130 64 -350 minecraft:dirt
fill 132 64 -350 135 64 -350 minecraft:dirt
fill 72 64 -349 126 64 -349 minecraft:dirt
setblock 129 64 -349 minecraft:dirt
fill 132 64 -349 135 64 -349 minecraft:dirt
fill 72 64 -348 128 64 -348 minecraft:dirt
fill 130 64 -348 131 64 -348 minecraft:dirt
fill 133 64 -348 135 64 -348 minecraft:dirt
fill 72 64 -347 127 64 -347 minecraft:dirt
setblock 129 64 -347 minecraft:dirt
setblock 131 64 -347 minecraft:dirt
fill 133 64 -347 135 64 -347 minecraft:dirt
fill 72 64 -346 128 64 -346 minecraft:dirt
fill 130 64 -346 134 64 -346 minecraft:dirt
fill 72 64 -345 126 64 -345 minecraft:dirt
fill 130 64 -345 133 64 -345 minecraft:dirt
fill 72 64 -344 115 64 -344 minecraft:dirt
fill 117 64 -344 125 64 -344 minecraft:dirt
fill 127 64 -344 132 64 -344 minecraft:dirt
fill 72 64 -343 127 64 -343 minecraft:dirt
fill 129 64 -343 131 64 -343 minecraft:dirt
fill 72 64 -342 124 64 -342 minecraft:dirt
fill 127 64 -342 130 64 -342 minecraft:dirt
fill 72 64 -341 129 64 -341 minecraft:dirt
fill 72 64 -340 127 64 -340 minecraft:dirt
fill 72 64 -339 127 64 -339 minecraft:dirt
fill 72 64 -338 126 64 -338 minecraft:dirt
fill 72 64 -337 125 64 -337 minecraft:dirt
fill 72 64 -336 125 64 -336 minecraft:dirt
fill 72 64 -335 125 64 -335 minecraft:dirt
fill 72 64 -334 125 64 -334 minecraft:dirt
fill 72 64 -333 125 64 -333 minecraft:dirt
fill 72 64 -332 125 64 -332 minecraft:dirt
fill 72 64 -331 124 64 -331 minecraft:dirt
fill 72 64 -330 118 64 -330 minecraft:dirt
fill 120 64 -330 124 64 -330 minecraft:dirt
fill 72 64 -329 118 64 -329 minecraft:dirt
fill 120 64 -329 124 64 -329 minecraft:dirt
fill 72 64 -328 117 64 -328 minecraft:dirt
fill 119 64 -328 123 64 -328 minecraft:dirt
fill 72 64 -327 121 64 -327 minecraft:dirt
fill 72 64 -326 119 64 -326 minecraft:dirt
setblock 121 64 -326 minecraft:dirt
fill 72 64 -325 116 64 -325 minecraft:dirt
fill 118 64 -325 121 64 -325 minecraft:dirt
fill 72 64 -324 115 64 -324 minecraft:dirt
fill 117 64 -324 121 64 -324 minecraft:dirt
fill 72 64 -323 118 64 -323 minecraft:dirt
fill 120 64 -323 121 64 -323 minecraft:dirt
fill 72 64 -322 74 64 -322 minecraft:dirt
fill 76 64 -322 121 64 -322 minecraft:dirt
fill 72 64 -321 74 64 -321 minecraft:dirt
fill 76 64 -321 84 64 -321 minecraft:dirt
fill 86 64 -321 120 64 -321 minecraft:dirt
fill 72 64 -320 74 64 -320 minecraft:dirt
fill 76 64 -320 117 64 -320 minecraft:dirt
setblock 119 64 -320 minecraft:dirt
fill 72 64 -319 74 64 -319 minecraft:dirt
fill 76 64 -319 86 64 -319 minecraft:dirt
fill 88 64 -319 117 64 -319 minecraft:dirt
fill 72 65 -382 135 65 -382 minecraft:grass_block
fill 72 65 -381 135 65 -381 minecraft:grass_block
fill 72 65 -380 135 65 -380 minecraft:grass_block
fill 72 65 -379 135 65 -379 minecraft:grass_block
fill 72 65 -378 135 65 -378 minecraft:grass_block
fill 72 65 -377 135 65 -377 minecraft:grass_block
fill 72 65 -376 135 65 -376 minecraft:grass_block
fill 72 65 -375 135 65 -375 minecraft:grass_block
fill 72 65 -374 135 65 -374 minecraft:grass_block
fill 72 65 -373 135 65 -373 minecraft:grass_block
fill 72 65 -372 135 65 -372 minecraft:grass_block
fill 72 65 -371 135 65 -371 minecraft:grass_block
fill 72 65 -370 135 65 -370 minecraft:grass_block
fill 72 65 -369 135 65 -369 minecraft:grass_block
fill 72 65 -368 135 65 -368 minecraft:grass_block
fill 72 65 -367 135 65 -367 minecraft:grass_block
fill 72 65 -366 135 65 -366 minecraft:grass_block
fill 72 65 -365 135 65 -365 minecraft:grass_block
fill 72 65 -364 135 65 -364 minecraft:grass_block
fill 72 65 -363 135 65 -363 minecraft:grass_block
fill 72 65 -362 135 65 -362 minecraft:grass_block
fill 72 65 -361 135 65 -361 minecraft:grass_block
fill 72 65 -360 135 65 -360 minecraft:grass_block
fill 72 65 -359 135 65 -359 minecraft:grass_block
fill 72 65 -358 135 65 -358 minecraft:grass_block
fill 72 65 -357 135 65 -357 minecraft:grass_block
fill 72 65 -356 135 65 -356 minecraft:grass_block
fill 72 65 -355 135 65 -355 minecraft:grass_block
fill 72 65 -354 135 65 -354 minecraft:grass_block
fill 72 65 -353 135 65 -353 minecraft:grass_block
fill 72 65 -352 135 65 -352 minecraft:grass_block
fill 72 65 -351 135 65 -351 minecraft:grass_block
fill 72 65 -350 135 65 -350 minecraft:grass_block
fill 72 65 -349 135 65 -349 minecraft:grass_block
fill 72 65 -348 135 65 -348 minecraft:grass_block
fill 72 65 -347 135 65 -347 minecraft:grass_block
fill 72 65 -346 135 65 -346 minecraft:grass_block
fill 72 65 -345 135 65 -345 minecraft:grass_block
fill 72 65 -344 135 65 -344 minecraft:grass_block
fill 72 65 -343 135 65 -343 minecraft:grass_block
fill 72 65 -342 135 65 -342 minecraft:grass_block
fill 72 65 -341 135 65 -341 minecraft:grass_block
fill 72 65 -340 135 65 -340 minecraft:grass_block
fill 72 65 -339 135 65 -339 minecraft:grass_block
fill 72 65 -338 135 65 -338 minecraft:grass_block
fill 72 65 -337 135 65 -337 minecraft:grass_block
fill 72 65 -336 135 65 -336 minecraft:grass_block
fill 72 65 -335 135 65 -335 minecraft:grass_block
fill 72 65 -334 135 65 -334 minecraft:grass_block
fill 72 65 -333 135 65 -333 minecraft:grass_block
fill 72 65 -332 128 65 -332 minecraft:grass_block
fill 130 65 -332 135 65 -332 minecraft:grass_block
fill 72 65 -331 128 65 -331 minecraft:grass_block
fill 130 65 -331 135 65 -331 minecraft:grass_block
fill 72 65 -330 127 65 -330 minecraft:grass_block
fill 129 65 -330 135 65 -330 minecraft:grass_block
fill 72 65 -329 127 65 -329 minecraft:grass_block
fill 129 65 -329 135 65 -329 minecraft:grass_block
fill 72 65 -328 135 65 -328 minecraft:grass_block
fill 72 65 -327 135 65 -327 minecraft:grass_block
fill 72 65 -326 135 65 -326 minecraft:grass_block
fill 72 65 -325 135 65 -325 minecraft:grass_block
fill 72 65 -324 124 65 -324 minecraft:grass_block
fill 127 65 -324 135 65 -324 minecraft:grass_block
fill 72 65 -323 122 65 -323 minecraft:grass_block
fill 127 65 -323 135 65 -323 minecraft:grass_block
fill 72 65 -322 121 65 -322 minecraft:grass_block
fill 128 65 -322 135 65 -322 minecraft:grass_block
fill 72 65 -321 121 65 -321 minecraft:grass_block
fill 128 65 -321 135 65 -321 minecraft:grass_block
fill 72 65 -320 121 65 -320 minecraft:grass_block
fill 128 65 -320 135 65 -320 minecraft:grass_block
fill 72 65 -319 123 65 -319 minecraft:grass_block
setblock 126 65 -319 minecraft:grass_block
fill 128 65 -319 135 65 -319 minecraft:grass_block
setblock 134 66 -344 minecraft:air
setblock 126 66 -342 minecraft:air
setblock 133 66 -341 minecraft:air
setblock 135 66 -341 minecraft:air
setblock 135 66 -340 minecraft:air
fill 134 66 -339 135 66 -339 minecraft:air
fill 133 66 -338 135 66 -338 minecraft:air
fill 133 66 -337 135 66 -337 minecraft:air
fill 132 66 -336 135 66 -336 minecraft:air
fill 131 66 -335 135 66 -335 minecraft:air
fill 128 66 -334 129 66 -334 minecraft:air
fill 131 66 -334 135 66 -334 minecraft:air
fill 129 66 -333 135 66 -333 minecraft:air
fill 130 66 -332 135 66 -332 minecraft:air
fill 130 66 -331 135 66 -331 minecraft:air
fill 129 66 -330 135 66 -330 minecraft:air
fill 129 66 -329 135 66 -329 minecraft:air
fill 129 66 -328 135 66 -328 minecraft:air
fill 127 66 -327 135 66 -327 minecraft:air
fill 125 66 -326 126 66 -326 minecraft:air
fill 129 66 -326 135 66 -326 minecraft:air
setblock 123 66 -325 minecraft:air
setblock 126 66 -325 minecraft:air
fill 128 66 -325 135 66 -325 minecraft:air
fill 128 66 -324 135 66 -324 minecraft:air
setblock 123 66 -323 minecraft:air
fill 125 66 -323 135 66 -323 minecraft:air
setblock 124 66 -322 minecraft:air
fill 128 66 -322 135 66 -322 minecraft:air
setblock 85 66 -321 minecraft:air
setblock 126 66 -321 minecraft:air
fill 128 66 -321 135 66 -321 minecraft:air
setblock 123 66 -320 minecraft:air
fill 128 66 -320 135 66 -320 minecraft:air
setblock 120 66 -319 minecraft:air
setblock 126 66 -319 minecraft:air
fill 128 66 -319 135 66 -319 minecraft:air
setblock 126 67 -343 minecraft:air
fill 125 67 -342 127 67 -342 minecraft:air
setblock 126 67 -341 minecraft:air
setblock 135 67 -337 minecraft:air
setblock 135 67 -336 minecraft:air
setblock 132 67 -335 minecraft:air
setblock 135 67 -335 minecraft:air
setblock 129 67 -334 minecraft:air
fill 134 67 -334 135 67 -334 minecraft:air
setblock 129 67 -333 minecraft:air
fill 133 67 -333 135 67 -333 minecraft:air
fill 132 67 -332 135 67 -332 minecraft:air
fill 132 67 -331 135 67 -331 minecraft:air
fill 132 67 -330 135 67 -330 minecraft:air
fill 132 67 -329 135 67 -329 minecraft:air
fill 132 67 -328 135 67 -328 minecraft:air
setblock 130 67 -327 minecraft:air
fill 132 67 -327 135 67 -327 minecraft:air
setblock 129 67 -326 minecraft:air
fill 133 67 -326 135 67 -326 minecraft:air
fill 129 67 -325 131 67 -325 minecraft:air
fill 133 67 -325 135 67 -325 minecraft:air
fill 133 67 -324 135 67 -324 minecraft:air
fill 127 67 -323 128 67 -323 minecraft:air
fill 133 67 -323 135 67 -323 minecraft:air
fill 132 67 -322 135 67 -322 minecraft:air
setblock 85 67 -321 minecraft:air
fill 132 67 -321 135 67 -321 minecraft:air
fill 132 67 -320 135 67 -320 minecraft:air
setblock 120 67 -319 minecraft:air
setblock 126 67 -319 minecraft:air
fill 131 67 -319 135 67 -319 minecraft:air
fill 125 68 -344 127 68 -344 minecraft:air
fill 124 68 -343 128 68 -343 minecraft:air
fill 124 68 -342 128 68 -342 minecraft:air
fill 124 68 -341 128 68 -341 minecraft:air
fill 125 68 -340 127 68 -340 minecraft:air
setblock 135 68 -330 minecraft:air
setblock 133 68 -329 minecraft:air
setblock 134 68 -328 minecraft:air
setblock 134 68 -327 minecraft:air
setblock 127 68 -323 minecraft:air
setblock 135 68 -322 minecraft:air
fill 84 68 -321 85 68 -321 minecraft:air
setblock 135 68 -321 minecraft:air
fill 134 68 -320 135 68 -320 minecraft:air
setblock 120 68 -319 minecraft:air
setblock 126 68 -319 minecraft:air
fill 134 68 -319 135 68 -319 minecraft:air
fill 125 69 -344 127 69 -344 minecraft:air
fill 124 69 -343 128 69 -343 minecraft:air
fill 124 69 -342 128 69 -342 minecraft:air
fill 124 69 -341 128 69 -341 minecraft:air
fill 125 69 -340 127 69 -340 minecraft:air
setblock 127 69 -323 minecraft:air
setblock 85 69 -321 minecraft:air
setblock 134 69 -320 minecraft:air
setblock 120 69 -319 minecraft:air
setblock 126 69 -319 minecraft:air
fill 125 70 -344 127 70 -344 minecraft:air
fill 124 70 -343 128 70 -343 minecraft:air
fill 124 70 -342 128 70 -342 minecraft:air
fill 124 70 -341 128 70 -341 minecraft:air
fill 125 70 -340 127 70 -340 minecraft:air
setblock 127 70 -323 minecraft:air
setblock 73 70 -321 minecraft:air
setblock 85 70 -321 minecraft:air
fill 72 70 -320 74 70 -320 minecraft:air
setblock 134 70 -320 minecraft:air
fill 72 70 -319 75 70 -319 minecraft:air
setblock 120 70 -319 minecraft:air
setblock 126 70 -319 minecraft:air
setblock 126 71 -343 minecraft:air
fill 125 71 -342 127 71 -342 minecraft:air
setblock 126 71 -341 minecraft:air
setblock 127 71 -325 minecraft:air
fill 126 71 -324 128 71 -324 minecraft:air
fill 125 71 -323 129 71 -323 minecraft:air
fill 126 71 -322 128 71 -322 minecraft:air
setblock 120 71 -321 minecraft:air
setblock 127 71 -321 minecraft:air
fill 72 71 -320 74 71 -320 minecraft:air
setblock 85 71 -320 minecraft:air
fill 119 71 -320 121 71 -320 minecraft:air
setblock 134 71 -320 minecraft:air
fill 72 71 -319 74 71 -319 minecraft:air
setblock 76 71 -319 minecraft:air
fill 118 71 -319 122 71 -319 minecraft:air
setblock 126 71 -319 minecraft:air
fill 126 72 -324 128 72 -324 minecraft:air
fill 126 72 -323 128 72 -323 minecraft:air
setblock 85 72 -322 minecraft:air
fill 126 72 -322 128 72 -322 minecraft:air
fill 84 72 -321 86 72 -321 minecraft:air
setblock 126 72 -321 minecraft:air
setblock 73 72 -320 minecraft:air
fill 83 72 -320 87 72 -320 minecraft:air
fill 119 72 -320 121 72 -320 minecraft:air
fill 125 72 -320 127 72 -320 minecraft:air
setblock 134 72 -320 minecraft:air
fill 72 72 -319 74 72 -319 minecraft:air
fill 84 72 -319 86 72 -319 minecraft:air
fill 119 72 -319 121 72 -319 minecraft:air
fill 124 72 -319 128 72 -319 minecraft:air
setblock 127 73 -324 minecraft:air
fill 126 73 -323 128 73 -323 minecraft:air
setblock 127 73 -322 minecraft:air
fill 84 73 -321 86 73 -321 minecraft:air
fill 84 73 -320 86 73 -320 minecraft:air
setblock 120 73 -320 minecraft:air
fill 125 73 -320 127 73 -320 minecraft:air
setblock 134 73 -320 minecraft:air
fill 72 73 -319 73 73 -319 minecraft:air
fill 84 73 -319 86 73 -319 minecraft:air
fill 119 73 -319 121 73 -319 minecraft:air
fill 125 73 -319 127 73 -319 minecraft:air
setblock 127 74 -324 minecraft:air
fill 127 74 -323 128 74 -323 minecraft:air
setblock 127 74 -322 minecraft:air
setblock 85 74 -321 minecraft:air
fill 84 74 -320 86 74 -320 minecraft:air
setblock 126 74 -320 minecraft:air
setblock 134 74 -320 minecraft:air
setblock 85 74 -319 minecraft:air
fill 119 74 -319 120 74 -319 minecraft:air
fill 125 74 -319 127 74 -319 minecraft:air
setblock 134 75 -322 minecraft:air
setblock 85 75 -321 minecraft:air
fill 133 75 -321 135 75 -321 minecraft:air
fill 85 75 -320 86 75 -320 minecraft:air
fill 132 75 -320 135 75 -320 minecraft:air
fill 125 75 -319 127 75 -319 minecraft:air
fill 133 75 -319 135 75 -319 minecraft:air
setblock 135 76 -326 minecraft:air
fill 134 76 -325 135 76 -325 minecraft:air
setblock 135 76 -324 minecraft:air
fill 133 76 -321 135 76 -321 minecraft:air
fill 133 76 -320 135 76 -320 minecraft:air
fill 133 76 -319 135 76 -319 minecraft:air
setblock 135 77 -326 minecraft:air
setblock 135 77 -325 minecraft:air
setblock 135 77 -324 minecraft:air
setblock 134 77 -321 minecraft:air
fill 133 77 -320 135 77 -320 minecraft:air
setblock 134 77 -319 minecraft:air
setblock 135 78 -325 minecraft:air
setblock 134 78 -321 minecraft:air
fill 134 78 -320 135 78 -320 minecraft:air
setblock 135 79 -325 minecraft:air
forceload remove 72 -382 135 -319
tellraw @a {"text":"Campus bau a09 fertig.","color":"green"}
