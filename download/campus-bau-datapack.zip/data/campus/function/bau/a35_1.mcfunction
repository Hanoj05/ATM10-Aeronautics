fill 393 45 -187 395 45 -187 minecraft:stone
fill 393 45 -186 395 45 -186 minecraft:stone
setblock 394 45 -185 minecraft:stone
fill 414 45 -146 417 45 -146 minecraft:stone
fill 412 45 -145 417 45 -145 minecraft:stone
fill 410 45 -144 414 45 -144 minecraft:stone
fill 408 45 -143 412 45 -143 minecraft:stone
fill 406 45 -142 411 45 -142 minecraft:stone
fill 405 45 -141 410 45 -141 minecraft:stone
fill 404 45 -140 408 45 -140 minecraft:stone
fill 403 45 -139 408 45 -139 minecraft:stone
fill 403 45 -138 405 45 -138 minecraft:stone
setblock 402 45 -137 minecraft:stone
setblock 392 45 -135 minecraft:stone
setblock 408 46 -142 minecraft:stone
fill 406 46 -141 407 46 -141 minecraft:stone
fill 404 46 -140 407 46 -140 minecraft:stone
fill 402 46 -139 406 46 -139 minecraft:stone
fill 401 46 -138 406 46 -138 minecraft:stone
fill 400 46 -137 404 46 -137 minecraft:stone
setblock 392 46 -136 minecraft:stone
fill 398 46 -136 400 46 -136 minecraft:stone
fill 392 46 -135 394 46 -135 minecraft:stone
setblock 404 46 -131 minecraft:stone
fill 403 46 -130 404 46 -130 minecraft:stone
fill 403 46 -129 404 46 -129 minecraft:stone
fill 402 46 -128 405 46 -128 minecraft:stone
fill 402 46 -127 405 46 -127 minecraft:stone
fill 403 47 -139 404 47 -139 minecraft:stone
fill 400 47 -138 404 47 -138 minecraft:stone
fill 398 47 -137 403 47 -137 minecraft:stone
fill 392 47 -136 402 47 -136 minecraft:stone
fill 392 47 -135 397 47 -135 minecraft:stone
setblock 404 47 -135 minecraft:stone
fill 403 47 -134 404 47 -134 minecraft:stone
fill 402 47 -133 405 47 -133 minecraft:stone
fill 402 47 -132 405 47 -132 minecraft:stone
fill 401 47 -131 405 47 -131 minecraft:stone
fill 400 47 -130 405 47 -130 minecraft:stone
fill 400 47 -129 406 47 -129 minecraft:stone
fill 399 47 -128 406 47 -128 minecraft:stone
fill 399 47 -127 406 47 -127 minecraft:stone
fill 392 48 -190 396 48 -190 minecraft:stone
fill 395 48 -189 396 48 -189 minecraft:stone
setblock 422 48 -160 minecraft:stone
setblock 422 48 -159 minecraft:stone
setblock 396 48 -158 minecraft:stone
setblock 422 48 -158 minecraft:stone
setblock 396 48 -157 minecraft:stone
setblock 422 48 -157 minecraft:stone
setblock 396 48 -156 minecraft:stone
setblock 421 48 -156 minecraft:stone
setblock 396 48 -155 minecraft:stone
setblock 396 48 -154 minecraft:stone
setblock 396 48 -153 minecraft:stone
setblock 396 48 -152 minecraft:stone
fill 420 48 -152 422 48 -152 minecraft:stone
setblock 396 48 -151 minecraft:stone
setblock 420 48 -151 minecraft:stone
setblock 421 48 -150 minecraft:stone
setblock 421 48 -149 minecraft:stone
setblock 421 48 -147 minecraft:stone
setblock 404 48 -141 minecraft:stone
fill 403 48 -140 405 48 -140 minecraft:stone
fill 402 48 -139 405 48 -139 minecraft:stone
fill 401 48 -138 405 48 -138 minecraft:stone
fill 398 48 -137 406 48 -137 minecraft:stone
fill 392 48 -136 406 48 -136 minecraft:stone
fill 392 48 -135 406 48 -135 minecraft:stone
fill 398 48 -134 406 48 -134 minecraft:stone
fill 398 48 -133 406 48 -133 minecraft:stone
fill 397 48 -132 406 48 -132 minecraft:stone
fill 397 48 -131 406 48 -131 minecraft:stone
fill 396 48 -130 406 48 -130 minecraft:stone
fill 395 48 -129 406 48 -129 minecraft:stone
fill 393 48 -128 406 48 -128 minecraft:stone
fill 392 48 -127 406 48 -127 minecraft:stone
fill 392 49 -190 396 49 -190 minecraft:stone
fill 392 49 -189 396 49 -189 minecraft:stone
fill 392 49 -188 396 49 -188 minecraft:stone
setblock 396 49 -164 minecraft:stone
setblock 422 49 -164 minecraft:stone
setblock 396 49 -163 minecraft:stone
fill 421 49 -163 422 49 -163 minecraft:stone
setblock 396 49 -162 minecraft:stone
fill 420 49 -162 422 49 -162 minecraft:stone
fill 396 49 -161 397 49 -161 minecraft:stone
setblock 422 49 -161 minecraft:stone
fill 395 49 -160 397 49 -160 minecraft:stone
fill 420 49 -160 422 49 -160 minecraft:stone
fill 395 49 -159 397 49 -159 minecraft:stone
fill 419 49 -159 422 49 -159 minecraft:stone
fill 395 49 -158 397 49 -158 minecraft:stone
fill 419 49 -158 422 49 -158 minecraft:stone
fill 395 49 -157 398 49 -157 minecraft:stone
fill 419 49 -157 422 49 -157 minecraft:stone
fill 395 49 -156 398 49 -156 minecraft:stone
fill 419 49 -156 422 49 -156 minecraft:stone
fill 395 49 -155 398 49 -155 minecraft:stone
fill 418 49 -155 421 49 -155 minecraft:stone
fill 395 49 -154 398 49 -154 minecraft:stone
fill 418 49 -154 422 49 -154 minecraft:stone
fill 395 49 -153 399 49 -153 minecraft:stone
fill 417 49 -153 422 49 -153 minecraft:stone
fill 395 49 -152 399 49 -152 minecraft:stone
fill 416 49 -152 421 49 -152 minecraft:stone
fill 395 49 -151 399 49 -151 minecraft:stone
fill 416 49 -151 421 49 -151 minecraft:stone
fill 395 49 -150 399 49 -150 minecraft:stone
fill 415 49 -150 421 49 -150 minecraft:stone
fill 396 49 -149 399 49 -149 minecraft:stone
fill 415 49 -149 421 49 -149 minecraft:stone
fill 396 49 -148 399 49 -148 minecraft:stone
fill 414 49 -148 421 49 -148 minecraft:stone
fill 396 49 -147 399 49 -147 minecraft:stone
setblock 401 49 -147 minecraft:stone
fill 414 49 -147 421 49 -147 minecraft:stone
fill 396 49 -146 399 49 -146 minecraft:stone
fill 401 49 -146 403 49 -146 minecraft:stone
fill 414 49 -146 421 49 -146 minecraft:stone
fill 396 49 -145 399 49 -145 minecraft:stone
setblock 401 49 -145 minecraft:stone
fill 407 49 -145 409 49 -145 minecraft:stone
fill 414 49 -145 421 49 -145 minecraft:stone
fill 396 49 -144 397 49 -144 minecraft:stone
fill 400 49 -144 402 49 -144 minecraft:stone
fill 406 49 -144 410 49 -144 minecraft:stone
fill 415 49 -144 421 49 -144 minecraft:stone
fill 396 49 -143 399 49 -143 minecraft:stone
fill 401 49 -143 402 49 -143 minecraft:stone
setblock 404 49 -143 minecraft:stone
fill 406 49 -143 410 49 -143 minecraft:stone
fill 415 49 -143 418 49 -143 minecraft:stone
fill 396 49 -142 399 49 -142 minecraft:stone
fill 401 49 -142 404 49 -142 minecraft:stone
fill 406 49 -142 410 49 -142 minecraft:stone
fill 415 49 -142 420 49 -142 minecraft:stone
fill 396 49 -141 397 49 -141 minecraft:stone
fill 400 49 -141 401 49 -141 minecraft:stone
setblock 404 49 -141 minecraft:stone
fill 407 49 -141 410 49 -141 minecraft:stone
fill 415 49 -141 420 49 -141 minecraft:stone
fill 396 49 -140 410 49 -140 minecraft:stone
fill 415 49 -140 419 49 -140 minecraft:stone
fill 396 49 -139 409 49 -139 minecraft:stone
fill 416 49 -139 419 49 -139 minecraft:stone
fill 396 49 -138 409 49 -138 minecraft:stone
fill 417 49 -138 419 49 -138 minecraft:stone
fill 396 49 -137 408 49 -137 minecraft:stone
fill 393 49 -136 407 49 -136 minecraft:stone
fill 392 49 -135 407 49 -135 minecraft:stone
fill 395 49 -134 407 49 -134 minecraft:stone
fill 394 49 -133 407 49 -133 minecraft:stone
fill 392 49 -132 407 49 -132 minecraft:stone
fill 392 49 -131 407 49 -131 minecraft:stone
fill 392 49 -130 407 49 -130 minecraft:stone
fill 392 49 -129 407 49 -129 minecraft:stone
fill 392 49 -128 407 49 -128 minecraft:stone
fill 392 49 -127 407 49 -127 minecraft:stone
fill 392 50 -190 397 50 -190 minecraft:stone
fill 392 50 -189 397 50 -189 minecraft:stone
fill 392 50 -188 396 50 -188 minecraft:stone
fill 392 50 -187 396 50 -187 minecraft:stone
fill 392 50 -186 396 50 -186 minecraft:stone
fill 392 50 -185 395 50 -185 minecraft:stone
fill 421 50 -177 422 50 -177 minecraft:stone
setblock 420 50 -176 minecraft:stone
fill 421 50 -169 422 50 -169 minecraft:stone
setblock 421 50 -168 minecraft:stone
setblock 396 50 -167 minecraft:stone
setblock 421 50 -167 minecraft:stone
fill 395 50 -166 396 50 -166 minecraft:stone
fill 394 50 -165 397 50 -165 minecraft:stone
fill 421 50 -165 422 50 -165 minecraft:stone
fill 394 50 -164 397 50 -164 minecraft:stone
fill 419 50 -164 422 50 -164 minecraft:stone
fill 394 50 -163 397 50 -163 minecraft:stone
fill 419 50 -163 422 50 -163 minecraft:stone
fill 393 50 -162 398 50 -162 minecraft:stone
fill 419 50 -162 422 50 -162 minecraft:stone
fill 393 50 -161 398 50 -161 minecraft:stone
fill 418 50 -161 422 50 -161 minecraft:stone
fill 393 50 -160 398 50 -160 minecraft:stone
fill 418 50 -160 422 50 -160 minecraft:stone
fill 393 50 -159 399 50 -159 minecraft:stone
fill 417 50 -159 422 50 -159 minecraft:stone
fill 393 50 -158 399 50 -158 minecraft:stone
fill 417 50 -158 422 50 -158 minecraft:stone
fill 393 50 -157 399 50 -157 minecraft:stone
fill 416 50 -157 422 50 -157 minecraft:stone
fill 393 50 -156 400 50 -156 minecraft:stone
fill 416 50 -156 422 50 -156 minecraft:stone
fill 393 50 -155 400 50 -155 minecraft:stone
fill 415 50 -155 421 50 -155 minecraft:stone
fill 394 50 -154 401 50 -154 minecraft:stone
fill 414 50 -154 422 50 -154 minecraft:stone
fill 394 50 -153 402 50 -153 minecraft:stone
fill 413 50 -153 421 50 -153 minecraft:stone
fill 394 50 -152 403 50 -152 minecraft:stone
fill 411 50 -152 422 50 -152 minecraft:stone
fill 394 50 -151 404 50 -151 minecraft:stone
fill 410 50 -151 421 50 -151 minecraft:stone
fill 394 50 -150 400 50 -150 minecraft:stone
fill 402 50 -150 421 50 -150 minecraft:stone
fill 394 50 -149 400 50 -149 minecraft:stone
fill 402 50 -149 421 50 -149 minecraft:stone
fill 394 50 -148 421 50 -148 minecraft:stone
fill 394 50 -147 421 50 -147 minecraft:stone
fill 394 50 -146 421 50 -146 minecraft:stone
fill 395 50 -145 421 50 -145 minecraft:stone
fill 395 50 -144 421 50 -144 minecraft:stone
fill 395 50 -143 420 50 -143 minecraft:stone
fill 394 50 -142 420 50 -142 minecraft:stone
fill 394 50 -141 420 50 -141 minecraft:stone
fill 394 50 -140 419 50 -140 minecraft:stone
fill 394 50 -139 419 50 -139 minecraft:stone
fill 393 50 -138 419 50 -138 minecraft:stone
fill 393 50 -137 418 50 -137 minecraft:stone
fill 393 50 -136 418 50 -136 minecraft:stone
fill 392 50 -135 417 50 -135 minecraft:stone
fill 392 50 -134 417 50 -134 minecraft:stone
fill 392 50 -133 416 50 -133 minecraft:stone
fill 392 50 -132 415 50 -132 minecraft:stone
fill 392 50 -131 415 50 -131 minecraft:stone
fill 392 50 -130 414 50 -130 minecraft:stone
fill 392 50 -129 413 50 -129 minecraft:stone
fill 392 50 -128 412 50 -128 minecraft:stone
fill 392 50 -127 411 50 -127 minecraft:stone
fill 392 51 -190 398 51 -190 minecraft:stone
fill 392 51 -189 398 51 -189 minecraft:stone
fill 392 51 -188 397 51 -188 minecraft:stone
fill 392 51 -187 397 51 -187 minecraft:stone
fill 392 51 -186 397 51 -186 minecraft:stone
fill 392 51 -185 396 51 -185 minecraft:stone
fill 392 51 -184 396 51 -184 minecraft:stone
fill 392 51 -183 396 51 -183 minecraft:stone
fill 392 51 -182 395 51 -182 minecraft:stone
fill 392 51 -181 394 51 -181 minecraft:stone
setblock 392 51 -180 minecraft:stone
fill 418 51 -180 421 51 -180 minecraft:stone
fill 418 51 -179 422 51 -179 minecraft:stone
fill 418 51 -178 422 51 -178 minecraft:stone
fill 418 51 -177 422 51 -177 minecraft:stone
setblock 418 51 -176 minecraft:stone
fill 420 51 -176 422 51 -176 minecraft:stone
setblock 418 51 -175 minecraft:stone
fill 420 51 -175 422 51 -175 minecraft:stone
setblock 419 51 -174 minecraft:stone
fill 419 51 -173 420 51 -173 minecraft:stone
setblock 422 51 -172 minecraft:stone
fill 394 51 -171 396 51 -171 minecraft:stone
setblock 422 51 -171 minecraft:stone
fill 392 51 -170 396 51 -170 minecraft:stone
fill 421 51 -170 422 51 -170 minecraft:stone
fill 392 51 -169 396 51 -169 minecraft:stone
setblock 418 51 -169 minecraft:stone
fill 421 51 -169 422 51 -169 minecraft:stone
fill 392 51 -168 397 51 -168 minecraft:stone
fill 420 51 -168 422 51 -168 minecraft:stone
fill 392 51 -167 397 51 -167 minecraft:stone
fill 420 51 -167 422 51 -167 minecraft:stone
fill 392 51 -166 397 51 -166 minecraft:stone
setblock 418 51 -166 minecraft:stone
fill 420 51 -166 422 51 -166 minecraft:stone
fill 392 51 -165 398 51 -165 minecraft:stone
setblock 418 51 -165 minecraft:stone
fill 420 51 -165 422 51 -165 minecraft:stone
fill 392 51 -164 398 51 -164 minecraft:stone
fill 417 51 -164 422 51 -164 minecraft:stone
fill 392 51 -163 398 51 -163 minecraft:stone
fill 417 51 -163 422 51 -163 minecraft:stone
fill 392 51 -162 399 51 -162 minecraft:stone
fill 417 51 -162 422 51 -162 minecraft:stone
fill 392 51 -161 399 51 -161 minecraft:stone
fill 416 51 -161 422 51 -161 minecraft:stone
fill 392 51 -160 400 51 -160 minecraft:stone
fill 416 51 -160 422 51 -160 minecraft:stone
fill 392 51 -159 400 51 -159 minecraft:stone
fill 415 51 -159 422 51 -159 minecraft:stone
fill 392 51 -158 401 51 -158 minecraft:stone
fill 414 51 -158 422 51 -158 minecraft:stone
fill 392 51 -157 403 51 -157 minecraft:stone
fill 414 51 -157 422 51 -157 minecraft:stone
fill 392 51 -156 404 51 -156 minecraft:stone
fill 413 51 -156 422 51 -156 minecraft:stone
fill 392 51 -155 405 51 -155 minecraft:stone
fill 411 51 -155 422 51 -155 minecraft:stone
fill 392 51 -154 422 51 -154 minecraft:stone
fill 392 51 -153 422 51 -153 minecraft:stone
fill 392 51 -152 422 51 -152 minecraft:stone
fill 392 51 -151 421 51 -151 minecraft:stone
fill 392 51 -150 421 51 -150 minecraft:stone
fill 392 51 -149 421 51 -149 minecraft:stone
fill 392 51 -148 421 51 -148 minecraft:stone
fill 392 51 -147 421 51 -147 minecraft:stone
fill 392 51 -146 421 51 -146 minecraft:stone
fill 392 51 -145 421 51 -145 minecraft:stone
fill 393 51 -144 421 51 -144 minecraft:stone
fill 392 51 -143 420 51 -143 minecraft:stone
fill 392 51 -142 420 51 -142 minecraft:stone
fill 392 51 -141 420 51 -141 minecraft:stone
fill 392 51 -140 419 51 -140 minecraft:stone
fill 392 51 -139 419 51 -139 minecraft:stone
fill 392 51 -138 419 51 -138 minecraft:stone
fill 392 51 -137 418 51 -137 minecraft:stone
fill 392 51 -136 418 51 -136 minecraft:stone
fill 392 51 -135 417 51 -135 minecraft:stone
fill 392 51 -134 417 51 -134 minecraft:stone
fill 392 51 -133 416 51 -133 minecraft:stone
fill 392 51 -132 415 51 -132 minecraft:stone
fill 392 51 -131 415 51 -131 minecraft:stone
fill 392 51 -130 414 51 -130 minecraft:stone
fill 392 51 -129 413 51 -129 minecraft:stone
fill 392 51 -128 412 51 -128 minecraft:stone
fill 392 51 -127 411 51 -127 minecraft:stone
fill 392 52 -190 399 52 -190 minecraft:stone
setblock 420 52 -190 minecraft:stone
setblock 422 52 -190 minecraft:stone
fill 392 52 -189 399 52 -189 minecraft:stone
setblock 422 52 -189 minecraft:stone
fill 392 52 -188 398 52 -188 minecraft:stone
fill 421 52 -188 422 52 -188 minecraft:stone
fill 392 52 -187 398 52 -187 minecraft:stone
setblock 421 52 -187 minecraft:stone
fill 392 52 -186 398 52 -186 minecraft:stone
setblock 422 52 -186 minecraft:stone
fill 392 52 -185 398 52 -185 minecraft:stone
setblock 422 52 -185 minecraft:stone
fill 392 52 -184 398 52 -184 minecraft:stone
fill 392 52 -183 398 52 -183 minecraft:stone
fill 420 52 -183 422 52 -183 minecraft:stone
fill 392 52 -182 397 52 -182 minecraft:stone
fill 417 52 -182 422 52 -182 minecraft:stone
fill 392 52 -181 397 52 -181 minecraft:stone
fill 414 52 -181 422 52 -181 minecraft:stone
fill 392 52 -180 397 52 -180 minecraft:stone
fill 413 52 -180 422 52 -180 minecraft:stone
fill 392 52 -179 396 52 -179 minecraft:stone
fill 414 52 -179 422 52 -179 minecraft:stone
fill 392 52 -178 396 52 -178 minecraft:stone
fill 415 52 -178 422 52 -178 minecraft:stone
fill 392 52 -177 396 52 -177 minecraft:stone
fill 415 52 -177 422 52 -177 minecraft:stone
fill 392 52 -176 396 52 -176 minecraft:stone
fill 415 52 -176 422 52 -176 minecraft:stone
fill 392 52 -175 396 52 -175 minecraft:stone
fill 415 52 -175 422 52 -175 minecraft:stone
fill 392 52 -174 396 52 -174 minecraft:stone
setblock 416 52 -174 minecraft:stone
fill 418 52 -174 419 52 -174 minecraft:stone
fill 392 52 -173 396 52 -173 minecraft:stone
setblock 416 52 -173 minecraft:stone
fill 419 52 -173 421 52 -173 minecraft:stone
fill 392 52 -172 397 52 -172 minecraft:stone
setblock 422 52 -172 minecraft:stone
fill 392 52 -171 397 52 -171 minecraft:stone
setblock 417 52 -171 minecraft:stone
setblock 419 52 -171 minecraft:stone
setblock 422 52 -171 minecraft:stone
fill 392 52 -170 397 52 -170 minecraft:stone
setblock 417 52 -170 minecraft:stone
fill 420 52 -170 422 52 -170 minecraft:stone
fill 392 52 -169 397 52 -169 minecraft:stone
fill 416 52 -169 418 52 -169 minecraft:stone
fill 420 52 -169 422 52 -169 minecraft:stone
fill 392 52 -168 398 52 -168 minecraft:stone
fill 416 52 -168 422 52 -168 minecraft:stone
fill 392 52 -167 398 52 -167 minecraft:stone
setblock 416 52 -167 minecraft:stone
fill 418 52 -167 422 52 -167 minecraft:stone
fill 392 52 -166 398 52 -166 minecraft:stone
fill 418 52 -166 422 52 -166 minecraft:stone
fill 392 52 -165 399 52 -165 minecraft:stone
fill 416 52 -165 422 52 -165 minecraft:stone
fill 392 52 -164 399 52 -164 minecraft:stone
fill 416 52 -164 422 52 -164 minecraft:stone
fill 392 52 -163 399 52 -163 minecraft:stone
fill 416 52 -163 422 52 -163 minecraft:stone
fill 392 52 -162 400 52 -162 minecraft:stone
fill 415 52 -162 422 52 -162 minecraft:stone
fill 392 52 -161 401 52 -161 minecraft:stone
fill 414 52 -161 422 52 -161 minecraft:stone
fill 392 52 -160 403 52 -160 minecraft:stone
fill 413 52 -160 422 52 -160 minecraft:stone
fill 392 52 -159 405 52 -159 minecraft:stone
fill 412 52 -159 422 52 -159 minecraft:stone
fill 392 52 -158 406 52 -158 minecraft:stone
fill 410 52 -158 422 52 -158 minecraft:stone
fill 392 52 -157 422 52 -157 minecraft:stone
fill 392 52 -156 422 52 -156 minecraft:stone
fill 392 52 -155 422 52 -155 minecraft:stone
fill 392 52 -154 422 52 -154 minecraft:stone
fill 392 52 -153 422 52 -153 minecraft:stone
fill 392 52 -152 422 52 -152 minecraft:stone
fill 392 52 -151 421 52 -151 minecraft:stone
fill 392 52 -150 421 52 -150 minecraft:stone
fill 392 52 -149 421 52 -149 minecraft:stone
fill 392 52 -148 421 52 -148 minecraft:stone
fill 392 52 -147 421 52 -147 minecraft:stone
fill 392 52 -146 421 52 -146 minecraft:stone
fill 392 52 -145 421 52 -145 minecraft:stone
fill 392 52 -144 421 52 -144 minecraft:stone
fill 392 52 -143 420 52 -143 minecraft:stone
fill 392 52 -142 420 52 -142 minecraft:stone
fill 392 52 -141 420 52 -141 minecraft:stone
fill 392 52 -140 419 52 -140 minecraft:stone
fill 392 52 -139 419 52 -139 minecraft:stone
fill 392 52 -138 419 52 -138 minecraft:stone
fill 392 52 -137 418 52 -137 minecraft:stone
fill 392 52 -136 418 52 -136 minecraft:stone
fill 392 52 -135 417 52 -135 minecraft:stone
fill 392 52 -134 417 52 -134 minecraft:stone
fill 392 52 -133 416 52 -133 minecraft:stone
fill 392 52 -132 415 52 -132 minecraft:stone
fill 392 52 -131 415 52 -131 minecraft:stone
fill 392 52 -130 414 52 -130 minecraft:stone
fill 392 52 -129 413 52 -129 minecraft:stone
fill 392 52 -128 412 52 -128 minecraft:stone
fill 392 52 -127 411 52 -127 minecraft:stone
fill 392 53 -190 399 53 -190 minecraft:stone
fill 401 53 -190 402 53 -190 minecraft:stone
fill 408 53 -190 409 53 -190 minecraft:stone
fill 411 53 -190 418 53 -190 minecraft:stone
setblock 420 53 -190 minecraft:stone
setblock 422 53 -190 minecraft:stone
fill 392 53 -189 399 53 -189 minecraft:stone
fill 401 53 -189 403 53 -189 minecraft:stone
setblock 407 53 -189 minecraft:stone
fill 409 53 -189 414 53 -189 minecraft:stone
fill 420 53 -189 422 53 -189 minecraft:stone
fill 392 53 -188 399 53 -188 minecraft:stone
fill 401 53 -188 403 53 -188 minecraft:stone
fill 411 53 -188 416 53 -188 minecraft:stone
setblock 418 53 -188 minecraft:stone
setblock 422 53 -188 minecraft:stone
fill 392 53 -187 402 53 -187 minecraft:stone
setblock 407 53 -187 minecraft:stone
fill 411 53 -187 416 53 -187 minecraft:stone
fill 421 53 -187 422 53 -187 minecraft:stone
fill 392 53 -186 416 53 -186 minecraft:stone
setblock 420 53 -186 minecraft:stone
fill 392 53 -185 416 53 -185 minecraft:stone
setblock 419 53 -185 minecraft:stone
setblock 422 53 -185 minecraft:stone
fill 392 53 -184 399 53 -184 minecraft:stone
fill 402 53 -184 422 53 -184 minecraft:stone
fill 392 53 -183 422 53 -183 minecraft:stone
fill 392 53 -182 422 53 -182 minecraft:stone
fill 392 53 -181 422 53 -181 minecraft:stone
fill 392 53 -180 422 53 -180 minecraft:stone
fill 392 53 -179 422 53 -179 minecraft:stone
fill 392 53 -178 422 53 -178 minecraft:stone
fill 392 53 -177 399 53 -177 minecraft:stone
fill 402 53 -177 422 53 -177 minecraft:stone
fill 392 53 -176 399 53 -176 minecraft:stone
setblock 405 53 -176 minecraft:stone
setblock 407 53 -176 minecraft:stone
setblock 409 53 -176 minecraft:stone
fill 414 53 -176 422 53 -176 minecraft:stone
fill 392 53 -175 398 53 -175 minecraft:stone
setblock 413 53 -175 minecraft:stone
fill 415 53 -175 422 53 -175 minecraft:stone
fill 392 53 -174 398 53 -174 minecraft:stone
fill 413 53 -174 414 53 -174 minecraft:stone
fill 416 53 -174 417 53 -174 minecraft:stone
setblock 419 53 -174 minecraft:stone
setblock 422 53 -174 minecraft:stone
fill 392 53 -173 398 53 -173 minecraft:stone
fill 416 53 -173 420 53 -173 minecraft:stone
setblock 422 53 -173 minecraft:stone
fill 392 53 -172 398 53 -172 minecraft:stone
fill 416 53 -172 417 53 -172 minecraft:stone
setblock 422 53 -172 minecraft:stone
fill 392 53 -171 398 53 -171 minecraft:stone
setblock 414 53 -171 minecraft:stone
fill 416 53 -171 418 53 -171 minecraft:stone
fill 421 53 -171 422 53 -171 minecraft:stone
fill 392 53 -170 398 53 -170 minecraft:stone
setblock 414 53 -170 minecraft:stone
fill 416 53 -170 422 53 -170 minecraft:stone
fill 392 53 -169 399 53 -169 minecraft:stone
fill 416 53 -169 422 53 -169 minecraft:stone
fill 392 53 -168 399 53 -168 minecraft:stone
fill 415 53 -168 422 53 -168 minecraft:stone
fill 392 53 -167 399 53 -167 minecraft:stone
fill 414 53 -167 422 53 -167 minecraft:stone
fill 392 53 -166 399 53 -166 minecraft:stone
fill 416 53 -166 422 53 -166 minecraft:stone
fill 392 53 -165 400 53 -165 minecraft:stone
fill 416 53 -165 422 53 -165 minecraft:stone
fill 392 53 -164 399 53 -164 minecraft:stone
setblock 401 53 -164 minecraft:stone
setblock 414 53 -164 minecraft:stone
fill 416 53 -164 422 53 -164 minecraft:stone
fill 392 53 -163 400 53 -163 minecraft:stone
fill 412 53 -163 422 53 -163 minecraft:stone
fill 392 53 -162 400 53 -162 minecraft:stone
fill 413 53 -162 422 53 -162 minecraft:stone
fill 392 53 -161 402 53 -161 minecraft:stone
fill 406 53 -161 407 53 -161 minecraft:stone
fill 414 53 -161 422 53 -161 minecraft:stone
fill 392 53 -160 422 53 -160 minecraft:stone
fill 392 53 -159 422 53 -159 minecraft:stone
fill 392 53 -158 422 53 -158 minecraft:stone
fill 392 53 -157 422 53 -157 minecraft:stone
fill 392 53 -156 422 53 -156 minecraft:stone
fill 392 53 -155 422 53 -155 minecraft:stone
fill 392 53 -154 422 53 -154 minecraft:stone
fill 392 53 -153 422 53 -153 minecraft:stone
fill 392 53 -152 422 53 -152 minecraft:stone
fill 392 53 -151 421 53 -151 minecraft:stone
fill 392 53 -150 421 53 -150 minecraft:stone
fill 392 53 -149 421 53 -149 minecraft:stone
fill 392 53 -148 421 53 -148 minecraft:stone
fill 392 53 -147 421 53 -147 minecraft:stone
fill 392 53 -146 421 53 -146 minecraft:stone
fill 392 53 -145 421 53 -145 minecraft:stone
fill 392 53 -144 421 53 -144 minecraft:stone
fill 392 53 -143 420 53 -143 minecraft:stone
fill 392 53 -142 420 53 -142 minecraft:stone
fill 392 53 -141 420 53 -141 minecraft:stone
fill 392 53 -140 419 53 -140 minecraft:stone
fill 392 53 -139 419 53 -139 minecraft:stone
fill 392 53 -138 419 53 -138 minecraft:stone
fill 392 53 -137 418 53 -137 minecraft:stone
fill 392 53 -136 418 53 -136 minecraft:stone
fill 392 53 -135 417 53 -135 minecraft:stone
fill 392 53 -134 417 53 -134 minecraft:stone
fill 392 53 -133 416 53 -133 minecraft:stone
fill 392 53 -132 415 53 -132 minecraft:stone
fill 392 53 -131 415 53 -131 minecraft:stone
fill 392 53 -130 414 53 -130 minecraft:stone
fill 392 53 -129 413 53 -129 minecraft:stone
fill 392 53 -128 412 53 -128 minecraft:stone
fill 392 53 -127 411 53 -127 minecraft:stone
fill 392 54 -190 404 54 -190 minecraft:stone
fill 407 54 -190 408 54 -190 minecraft:stone
fill 411 54 -190 422 54 -190 minecraft:stone
fill 392 54 -189 402 54 -189 minecraft:stone
fill 405 54 -189 408 54 -189 minecraft:stone
fill 410 54 -189 418 54 -189 minecraft:stone
fill 420 54 -189 421 54 -189 minecraft:stone
fill 392 54 -188 403 54 -188 minecraft:stone
fill 406 54 -188 409 54 -188 minecraft:stone
fill 411 54 -188 416 54 -188 minecraft:stone
fill 418 54 -188 419 54 -188 minecraft:stone
fill 421 54 -188 422 54 -188 minecraft:stone
fill 392 54 -187 405 54 -187 minecraft:stone
fill 410 54 -187 417 54 -187 minecraft:stone
setblock 420 54 -187 minecraft:stone
setblock 422 54 -187 minecraft:stone
fill 392 54 -186 418 54 -186 minecraft:stone
fill 420 54 -186 422 54 -186 minecraft:stone
fill 392 54 -185 422 54 -185 minecraft:stone
fill 392 54 -184 422 54 -184 minecraft:stone
fill 392 54 -183 422 54 -183 minecraft:stone
fill 392 54 -182 422 54 -182 minecraft:stone
fill 392 54 -181 422 54 -181 minecraft:stone
fill 392 54 -180 422 54 -180 minecraft:stone
fill 392 54 -179 422 54 -179 minecraft:stone
fill 392 54 -178 422 54 -178 minecraft:stone
fill 392 54 -177 422 54 -177 minecraft:stone
fill 392 54 -176 409 54 -176 minecraft:stone
fill 413 54 -176 422 54 -176 minecraft:stone
fill 392 54 -175 400 54 -175 minecraft:stone
setblock 402 54 -175 minecraft:stone
fill 414 54 -175 422 54 -175 minecraft:stone
fill 392 54 -174 399 54 -174 minecraft:stone
setblock 401 54 -174 minecraft:stone
setblock 411 54 -174 minecraft:stone
fill 415 54 -174 417 54 -174 minecraft:stone
setblock 422 54 -174 minecraft:stone
fill 392 54 -173 399 54 -173 minecraft:stone
fill 413 54 -173 417 54 -173 minecraft:stone
fill 419 54 -173 420 54 -173 minecraft:stone
setblock 422 54 -173 minecraft:stone
fill 392 54 -172 399 54 -172 minecraft:stone
setblock 413 54 -172 minecraft:stone
fill 415 54 -172 417 54 -172 minecraft:stone
setblock 419 54 -172 minecraft:stone
setblock 422 54 -172 minecraft:stone
fill 392 54 -171 399 54 -171 minecraft:stone
setblock 412 54 -171 minecraft:stone
fill 414 54 -171 417 54 -171 minecraft:stone
setblock 422 54 -171 minecraft:stone
fill 392 54 -170 400 54 -170 minecraft:stone
setblock 405 54 -170 minecraft:stone
setblock 408 54 -170 minecraft:stone
fill 415 54 -170 422 54 -170 minecraft:stone
fill 392 54 -169 400 54 -169 minecraft:stone
setblock 402 54 -169 minecraft:stone
fill 414 54 -169 422 54 -169 minecraft:stone
fill 392 54 -168 399 54 -168 minecraft:stone
setblock 412 54 -168 minecraft:stone
fill 414 54 -168 422 54 -168 minecraft:stone
fill 392 54 -167 399 54 -167 minecraft:stone
setblock 409 54 -167 minecraft:stone
fill 414 54 -167 422 54 -167 minecraft:stone
fill 392 54 -166 400 54 -166 minecraft:stone
fill 414 54 -166 422 54 -166 minecraft:stone
fill 392 54 -165 400 54 -165 minecraft:stone
setblock 413 54 -165 minecraft:stone
fill 415 54 -165 422 54 -165 minecraft:stone
fill 392 54 -164 401 54 -164 minecraft:stone
fill 414 54 -164 422 54 -164 minecraft:stone
fill 392 54 -163 403 54 -163 minecraft:stone
fill 414 54 -163 422 54 -163 minecraft:stone
fill 392 54 -162 402 54 -162 minecraft:stone
setblock 405 54 -162 minecraft:stone
setblock 408 54 -162 minecraft:stone
fill 411 54 -162 412 54 -162 minecraft:stone
fill 414 54 -162 422 54 -162 minecraft:stone
fill 392 54 -161 407 54 -161 minecraft:stone
fill 409 54 -161 411 54 -161 minecraft:stone
fill 413 54 -161 422 54 -161 minecraft:stone
fill 392 54 -160 422 54 -160 minecraft:stone
fill 392 54 -159 422 54 -159 minecraft:stone
fill 392 54 -158 422 54 -158 minecraft:stone
fill 392 54 -157 422 54 -157 minecraft:stone
fill 392 54 -156 422 54 -156 minecraft:stone
fill 392 54 -155 422 54 -155 minecraft:stone
fill 392 54 -154 422 54 -154 minecraft:stone
fill 392 54 -153 422 54 -153 minecraft:stone
fill 392 54 -152 422 54 -152 minecraft:stone
fill 392 54 -151 421 54 -151 minecraft:stone
fill 392 54 -150 421 54 -150 minecraft:stone
fill 392 54 -149 421 54 -149 minecraft:stone
fill 392 54 -148 421 54 -148 minecraft:stone
fill 392 54 -147 421 54 -147 minecraft:stone
fill 392 54 -146 421 54 -146 minecraft:stone
fill 392 54 -145 421 54 -145 minecraft:stone
fill 392 54 -144 421 54 -144 minecraft:stone
fill 392 54 -143 420 54 -143 minecraft:stone
fill 392 54 -142 420 54 -142 minecraft:stone
fill 392 54 -141 420 54 -141 minecraft:stone
fill 392 54 -140 419 54 -140 minecraft:stone
fill 392 54 -139 419 54 -139 minecraft:stone
fill 392 54 -138 419 54 -138 minecraft:stone
fill 392 54 -137 418 54 -137 minecraft:stone
fill 392 54 -136 418 54 -136 minecraft:stone
fill 392 54 -135 417 54 -135 minecraft:stone
fill 392 54 -134 417 54 -134 minecraft:stone
fill 392 54 -133 416 54 -133 minecraft:stone
fill 392 54 -132 415 54 -132 minecraft:stone
fill 392 54 -131 415 54 -131 minecraft:stone
fill 392 54 -130 414 54 -130 minecraft:stone
fill 392 54 -129 413 54 -129 minecraft:stone
fill 392 54 -128 412 54 -128 minecraft:stone
fill 392 54 -127 411 54 -127 minecraft:stone
fill 392 55 -190 409 55 -190 minecraft:stone
fill 411 55 -190 422 55 -190 minecraft:stone
fill 392 55 -189 403 55 -189 minecraft:stone
fill 405 55 -189 418 55 -189 minecraft:stone
fill 420 55 -189 422 55 -189 minecraft:stone
fill 392 55 -188 403 55 -188 minecraft:stone
fill 406 55 -188 409 55 -188 minecraft:stone
fill 411 55 -188 422 55 -188 minecraft:stone
fill 392 55 -187 406 55 -187 minecraft:stone
fill 408 55 -187 418 55 -187 minecraft:stone
fill 420 55 -187 422 55 -187 minecraft:stone
fill 392 55 -186 418 55 -186 minecraft:stone
fill 420 55 -186 422 55 -186 minecraft:stone
fill 392 55 -185 422 55 -185 minecraft:stone
fill 392 55 -184 422 55 -184 minecraft:stone
fill 392 55 -183 422 55 -183 minecraft:stone
fill 392 55 -182 422 55 -182 minecraft:stone
fill 392 55 -181 422 55 -181 minecraft:stone
fill 392 55 -180 422 55 -180 minecraft:stone
fill 392 55 -179 422 55 -179 minecraft:stone
fill 392 55 -178 422 55 -178 minecraft:stone
fill 392 55 -177 422 55 -177 minecraft:stone
fill 392 55 -176 410 55 -176 minecraft:stone
fill 412 55 -176 422 55 -176 minecraft:stone
fill 392 55 -175 401 55 -175 minecraft:stone
setblock 403 55 -175 minecraft:stone
setblock 405 55 -175 minecraft:stone
setblock 407 55 -175 minecraft:stone
fill 410 55 -175 411 55 -175 minecraft:stone
fill 414 55 -175 422 55 -175 minecraft:stone
fill 392 55 -174 401 55 -174 minecraft:stone
fill 407 55 -174 412 55 -174 minecraft:stone
fill 415 55 -174 417 55 -174 minecraft:stone
fill 421 55 -174 422 55 -174 minecraft:stone
fill 392 55 -173 400 55 -173 minecraft:stone
fill 402 55 -173 403 55 -173 minecraft:stone
fill 406 55 -173 417 55 -173 minecraft:stone
fill 419 55 -173 420 55 -173 minecraft:stone
setblock 422 55 -173 minecraft:stone
fill 392 55 -172 400 55 -172 minecraft:stone
setblock 403 55 -172 minecraft:stone
setblock 406 55 -172 minecraft:stone
fill 408 55 -172 409 55 -172 minecraft:stone
fill 411 55 -172 417 55 -172 minecraft:stone
fill 419 55 -172 420 55 -172 minecraft:stone
setblock 422 55 -172 minecraft:stone
fill 392 55 -171 402 55 -171 minecraft:stone
setblock 405 55 -171 minecraft:stone
setblock 407 55 -171 minecraft:stone
fill 409 55 -171 417 55 -171 minecraft:stone
setblock 422 55 -171 minecraft:stone
fill 392 55 -170 400 55 -170 minecraft:stone
setblock 403 55 -170 minecraft:stone
fill 405 55 -170 410 55 -170 minecraft:stone
fill 415 55 -170 422 55 -170 minecraft:stone
fill 392 55 -169 408 55 -169 minecraft:stone
fill 411 55 -169 422 55 -169 minecraft:stone
fill 392 55 -168 406 55 -168 minecraft:stone
setblock 408 55 -168 minecraft:stone
fill 411 55 -168 422 55 -168 minecraft:stone
fill 392 55 -167 400 55 -167 minecraft:stone
fill 403 55 -167 407 55 -167 minecraft:stone
fill 409 55 -167 412 55 -167 minecraft:stone
fill 415 55 -167 422 55 -167 minecraft:stone
fill 392 55 -166 403 55 -166 minecraft:stone
fill 405 55 -166 422 55 -166 minecraft:stone
fill 392 55 -165 403 55 -165 minecraft:stone
fill 406 55 -165 408 55 -165 minecraft:stone
setblock 410 55 -165 minecraft:stone
fill 412 55 -165 422 55 -165 minecraft:stone
fill 392 55 -164 405 55 -164 minecraft:stone
fill 407 55 -164 411 55 -164 minecraft:stone
fill 413 55 -164 422 55 -164 minecraft:stone
fill 392 55 -163 400 55 -163 minecraft:stone
fill 403 55 -163 404 55 -163 minecraft:stone
fill 407 55 -163 408 55 -163 minecraft:stone
setblock 412 55 -163 minecraft:stone
fill 415 55 -163 422 55 -163 minecraft:stone
fill 392 55 -162 401 55 -162 minecraft:stone
setblock 403 55 -162 minecraft:stone
setblock 405 55 -162 minecraft:stone
fill 407 55 -162 408 55 -162 minecraft:stone
fill 411 55 -162 412 55 -162 minecraft:stone
fill 414 55 -162 422 55 -162 minecraft:stone
fill 392 55 -161 422 55 -161 minecraft:stone
fill 392 55 -160 422 55 -160 minecraft:stone
fill 392 55 -159 422 55 -159 minecraft:stone
fill 392 55 -158 422 55 -158 minecraft:stone
fill 392 55 -157 422 55 -157 minecraft:stone
fill 392 55 -156 422 55 -156 minecraft:stone
fill 392 55 -155 422 55 -155 minecraft:stone
fill 392 55 -154 422 55 -154 minecraft:stone
fill 392 55 -153 422 55 -153 minecraft:stone
fill 392 55 -152 422 55 -152 minecraft:stone
fill 392 55 -151 421 55 -151 minecraft:stone
fill 392 55 -150 421 55 -150 minecraft:stone
fill 392 55 -149 421 55 -149 minecraft:stone
fill 392 55 -148 421 55 -148 minecraft:stone
fill 392 55 -147 421 55 -147 minecraft:stone
fill 392 55 -146 421 55 -146 minecraft:stone
fill 392 55 -145 421 55 -145 minecraft:stone
fill 392 55 -144 421 55 -144 minecraft:stone
fill 392 55 -143 420 55 -143 minecraft:stone
fill 392 55 -142 420 55 -142 minecraft:stone
fill 392 55 -141 420 55 -141 minecraft:stone
fill 392 55 -140 419 55 -140 minecraft:stone
fill 392 55 -139 419 55 -139 minecraft:stone
fill 392 55 -138 419 55 -138 minecraft:stone
fill 392 55 -137 418 55 -137 minecraft:stone
fill 392 55 -136 418 55 -136 minecraft:stone
fill 392 55 -135 417 55 -135 minecraft:stone
fill 392 55 -134 417 55 -134 minecraft:stone
fill 392 55 -133 416 55 -133 minecraft:stone
fill 392 55 -132 415 55 -132 minecraft:stone
fill 392 55 -131 415 55 -131 minecraft:stone
fill 392 55 -130 414 55 -130 minecraft:stone
fill 392 55 -129 413 55 -129 minecraft:stone
fill 392 55 -128 412 55 -128 minecraft:stone
fill 392 55 -127 411 55 -127 minecraft:stone
fill 392 56 -190 403 56 -190 minecraft:stone
fill 405 56 -190 409 56 -190 minecraft:stone
fill 411 56 -190 422 56 -190 minecraft:stone
fill 392 56 -189 403 56 -189 minecraft:stone
fill 405 56 -189 418 56 -189 minecraft:stone
fill 420 56 -189 422 56 -189 minecraft:stone
fill 392 56 -188 404 56 -188 minecraft:stone
fill 406 56 -188 409 56 -188 minecraft:stone
fill 411 56 -188 422 56 -188 minecraft:stone
fill 392 56 -187 404 56 -187 minecraft:stone
fill 409 56 -187 422 56 -187 minecraft:stone
fill 392 56 -186 418 56 -186 minecraft:stone
fill 420 56 -186 422 56 -186 minecraft:stone
fill 392 56 -185 422 56 -185 minecraft:stone
fill 392 56 -184 422 56 -184 minecraft:stone
fill 392 56 -183 422 56 -183 minecraft:stone
fill 392 56 -182 422 56 -182 minecraft:stone
fill 392 56 -181 422 56 -181 minecraft:stone
fill 392 56 -180 422 56 -180 minecraft:stone
fill 392 56 -179 422 56 -179 minecraft:stone
fill 392 56 -178 422 56 -178 minecraft:stone
fill 392 56 -177 422 56 -177 minecraft:stone
fill 392 56 -176 422 56 -176 minecraft:stone
fill 392 56 -175 411 56 -175 minecraft:stone
fill 413 56 -175 422 56 -175 minecraft:stone
fill 392 56 -174 401 56 -174 minecraft:stone
fill 403 56 -174 405 56 -174 minecraft:stone
fill 407 56 -174 408 56 -174 minecraft:stone
fill 410 56 -174 412 56 -174 minecraft:stone
fill 414 56 -174 417 56 -174 minecraft:stone
setblock 422 56 -174 minecraft:stone
fill 392 56 -173 417 56 -173 minecraft:stone
setblock 422 56 -173 minecraft:stone
fill 392 56 -172 401 56 -172 minecraft:stone
setblock 403 56 -172 minecraft:stone
fill 405 56 -172 417 56 -172 minecraft:stone
setblock 419 56 -172 minecraft:stone
setblock 422 56 -172 minecraft:stone
fill 392 56 -171 402 56 -171 minecraft:stone
fill 404 56 -171 417 56 -171 minecraft:stone
setblock 422 56 -171 minecraft:stone
fill 392 56 -170 412 56 -170 minecraft:stone
fill 414 56 -170 422 56 -170 minecraft:stone
fill 392 56 -169 422 56 -169 minecraft:stone
fill 392 56 -168 422 56 -168 minecraft:stone
fill 392 56 -167 412 56 -167 minecraft:stone
fill 414 56 -167 422 56 -167 minecraft:stone
fill 392 56 -166 403 56 -166 minecraft:stone
fill 405 56 -166 422 56 -166 minecraft:stone
fill 392 56 -165 403 56 -165 minecraft:stone
fill 405 56 -165 410 56 -165 minecraft:stone
fill 412 56 -165 422 56 -165 minecraft:stone
fill 392 56 -164 422 56 -164 minecraft:stone
fill 392 56 -163 401 56 -163 minecraft:stone
fill 403 56 -163 405 56 -163 minecraft:stone
fill 407 56 -163 408 56 -163 minecraft:stone
setblock 410 56 -163 minecraft:stone
setblock 412 56 -163 minecraft:stone
fill 414 56 -163 422 56 -163 minecraft:stone
fill 392 56 -162 422 56 -162 minecraft:stone
fill 392 56 -161 422 56 -161 minecraft:stone
fill 392 56 -160 422 56 -160 minecraft:stone
fill 392 56 -159 422 56 -159 minecraft:stone
fill 392 56 -158 422 56 -158 minecraft:stone
fill 392 56 -157 422 56 -157 minecraft:stone
fill 392 56 -156 422 56 -156 minecraft:stone
fill 392 56 -155 422 56 -155 minecraft:stone
fill 392 56 -154 422 56 -154 minecraft:stone
fill 392 56 -153 422 56 -153 minecraft:stone
fill 392 56 -152 422 56 -152 minecraft:stone
fill 392 56 -151 421 56 -151 minecraft:stone
fill 392 56 -150 421 56 -150 minecraft:stone
fill 392 56 -149 421 56 -149 minecraft:stone
fill 392 56 -148 421 56 -148 minecraft:stone
fill 392 56 -147 421 56 -147 minecraft:stone
fill 392 56 -146 421 56 -146 minecraft:stone
fill 392 56 -145 421 56 -145 minecraft:stone
fill 392 56 -144 421 56 -144 minecraft:stone
fill 392 56 -143 420 56 -143 minecraft:stone
fill 392 56 -142 420 56 -142 minecraft:stone
fill 392 56 -141 420 56 -141 minecraft:stone
fill 392 56 -140 419 56 -140 minecraft:stone
fill 392 56 -139 419 56 -139 minecraft:stone
fill 392 56 -138 419 56 -138 minecraft:stone
fill 392 56 -137 418 56 -137 minecraft:stone
fill 392 56 -136 418 56 -136 minecraft:stone
fill 392 56 -135 417 56 -135 minecraft:stone
fill 392 56 -134 417 56 -134 minecraft:stone
fill 392 56 -133 416 56 -133 minecraft:stone
fill 392 56 -132 415 56 -132 minecraft:stone
fill 392 56 -131 415 56 -131 minecraft:stone
fill 392 56 -130 414 56 -130 minecraft:stone
fill 392 56 -129 413 56 -129 minecraft:stone
fill 392 56 -128 412 56 -128 minecraft:stone
fill 392 56 -127 411 56 -127 minecraft:stone
fill 392 57 -190 418 57 -190 minecraft:stone
fill 420 57 -190 422 57 -190 minecraft:stone
fill 392 57 -189 403 57 -189 minecraft:stone
fill 406 57 -189 422 57 -189 minecraft:stone
fill 392 57 -188 404 57 -188 minecraft:stone
fill 407 57 -188 418 57 -188 minecraft:stone
fill 420 57 -188 422 57 -188 minecraft:stone
fill 392 57 -187 405 57 -187 minecraft:stone
fill 407 57 -187 418 57 -187 minecraft:stone
fill 420 57 -187 422 57 -187 minecraft:stone
fill 392 57 -186 418 57 -186 minecraft:stone
fill 420 57 -186 422 57 -186 minecraft:stone
fill 392 57 -185 418 57 -185 minecraft:stone
fill 420 57 -185 422 57 -185 minecraft:stone
fill 392 57 -184 422 57 -184 minecraft:stone
fill 392 57 -183 422 57 -183 minecraft:stone
fill 392 57 -182 422 57 -182 minecraft:stone
fill 392 57 -181 422 57 -181 minecraft:stone
fill 392 57 -180 422 57 -180 minecraft:stone
fill 392 57 -179 422 57 -179 minecraft:stone
fill 392 57 -178 422 57 -178 minecraft:stone
fill 392 57 -177 422 57 -177 minecraft:stone
fill 392 57 -176 422 57 -176 minecraft:stone
fill 392 57 -175 412 57 -175 minecraft:stone
fill 414 57 -175 422 57 -175 minecraft:stone
fill 392 57 -174 401 57 -174 minecraft:stone
fill 403 57 -174 405 57 -174 minecraft:stone
fill 407 57 -174 408 57 -174 minecraft:stone
fill 410 57 -174 411 57 -174 minecraft:stone
fill 415 57 -174 422 57 -174 minecraft:stone
fill 392 57 -173 410 57 -173 minecraft:stone
fill 412 57 -173 422 57 -173 minecraft:stone
fill 392 57 -172 409 57 -172 minecraft:stone
fill 413 57 -172 422 57 -172 minecraft:stone
fill 392 57 -171 422 57 -171 minecraft:stone
fill 392 57 -170 401 57 -170 minecraft:stone
fill 403 57 -170 411 57 -170 minecraft:stone
fill 414 57 -170 422 57 -170 minecraft:stone
fill 392 57 -169 422 57 -169 minecraft:stone
fill 392 57 -168 412 57 -168 minecraft:stone
fill 414 57 -168 422 57 -168 minecraft:stone
fill 392 57 -167 401 57 -167 minecraft:stone
fill 403 57 -167 412 57 -167 minecraft:stone
fill 414 57 -167 422 57 -167 minecraft:stone
fill 392 57 -166 422 57 -166 minecraft:stone
fill 392 57 -165 403 57 -165 minecraft:stone
fill 405 57 -165 410 57 -165 minecraft:stone
fill 412 57 -165 422 57 -165 minecraft:stone
fill 392 57 -164 422 57 -164 minecraft:stone
fill 392 57 -163 401 57 -163 minecraft:stone
fill 403 57 -163 405 57 -163 minecraft:stone
fill 407 57 -163 408 57 -163 minecraft:stone
fill 410 57 -163 412 57 -163 minecraft:stone
fill 414 57 -163 422 57 -163 minecraft:stone
fill 392 57 -162 422 57 -162 minecraft:stone
fill 392 57 -161 422 57 -161 minecraft:stone
fill 392 57 -160 422 57 -160 minecraft:stone
fill 392 57 -159 422 57 -159 minecraft:stone
fill 392 57 -158 422 57 -158 minecraft:stone
fill 392 57 -157 422 57 -157 minecraft:stone
fill 392 57 -156 422 57 -156 minecraft:stone
fill 392 57 -155 422 57 -155 minecraft:stone
fill 392 57 -154 422 57 -154 minecraft:stone
fill 392 57 -153 422 57 -153 minecraft:stone
fill 392 57 -152 422 57 -152 minecraft:stone
fill 392 57 -151 421 57 -151 minecraft:stone
fill 392 57 -150 421 57 -150 minecraft:stone
fill 392 57 -149 421 57 -149 minecraft:stone
fill 392 57 -148 421 57 -148 minecraft:stone
fill 392 57 -147 421 57 -147 minecraft:stone
fill 392 57 -146 421 57 -146 minecraft:stone
fill 392 57 -145 421 57 -145 minecraft:stone
fill 392 57 -144 421 57 -144 minecraft:stone
fill 392 57 -143 420 57 -143 minecraft:stone
fill 392 57 -142 420 57 -142 minecraft:stone
fill 392 57 -141 420 57 -141 minecraft:stone
fill 392 57 -140 419 57 -140 minecraft:stone
fill 392 57 -139 419 57 -139 minecraft:stone
fill 392 57 -138 419 57 -138 minecraft:stone
fill 392 57 -137 418 57 -137 minecraft:stone
fill 392 57 -136 418 57 -136 minecraft:stone
fill 392 57 -135 417 57 -135 minecraft:stone
fill 392 57 -134 417 57 -134 minecraft:stone
fill 392 57 -133 416 57 -133 minecraft:stone
fill 392 57 -132 415 57 -132 minecraft:stone
fill 392 57 -131 415 57 -131 minecraft:stone
fill 392 57 -130 414 57 -130 minecraft:stone
fill 392 57 -129 413 57 -129 minecraft:stone
fill 392 57 -128 412 57 -128 minecraft:stone
fill 392 57 -127 411 57 -127 minecraft:stone
fill 392 58 -190 422 58 -190 minecraft:stone
fill 392 58 -189 404 58 -189 minecraft:stone
fill 406 58 -189 422 58 -189 minecraft:stone
fill 392 58 -188 404 58 -188 minecraft:stone
fill 406 58 -188 418 58 -188 minecraft:stone
fill 420 58 -188 422 58 -188 minecraft:stone
fill 392 58 -187 422 58 -187 minecraft:stone
fill 392 58 -186 422 58 -186 minecraft:stone
fill 392 58 -185 422 58 -185 minecraft:stone
fill 392 58 -184 422 58 -184 minecraft:stone
fill 392 58 -183 422 58 -183 minecraft:stone
fill 392 58 -182 422 58 -182 minecraft:stone
fill 392 58 -181 422 58 -181 minecraft:stone
fill 392 58 -180 422 58 -180 minecraft:stone
fill 392 58 -179 422 58 -179 minecraft:stone
fill 392 58 -178 422 58 -178 minecraft:stone
fill 392 58 -177 422 58 -177 minecraft:stone
fill 392 58 -176 422 58 -176 minecraft:stone
fill 392 58 -175 422 58 -175 minecraft:stone
fill 392 58 -174 401 58 -174 minecraft:stone
fill 403 58 -174 412 58 -174 minecraft:stone
fill 414 58 -174 422 58 -174 minecraft:stone
fill 392 58 -173 422 58 -173 minecraft:stone
fill 392 58 -172 410 58 -172 minecraft:stone
fill 412 58 -172 422 58 -172 minecraft:stone
fill 392 58 -171 404 58 -171 minecraft:stone
fill 406 58 -171 408 58 -171 minecraft:stone
fill 410 58 -171 422 58 -171 minecraft:stone
fill 392 58 -170 405 58 -170 minecraft:stone
setblock 407 58 -170 minecraft:stone
fill 411 58 -170 412 58 -170 minecraft:stone
fill 414 58 -170 422 58 -170 minecraft:stone
fill 392 58 -169 408 58 -169 minecraft:stone
fill 410 58 -169 422 58 -169 minecraft:stone
fill 392 58 -168 422 58 -168 minecraft:stone
fill 392 58 -167 405 58 -167 minecraft:stone
fill 407 58 -167 408 58 -167 minecraft:stone
fill 410 58 -167 412 58 -167 minecraft:stone
fill 414 58 -167 422 58 -167 minecraft:stone
fill 392 58 -166 404 58 -166 minecraft:stone
fill 406 58 -166 409 58 -166 minecraft:stone
fill 411 58 -166 422 58 -166 minecraft:stone
fill 392 58 -165 422 58 -165 minecraft:stone
fill 392 58 -164 422 58 -164 minecraft:stone
fill 392 58 -163 422 58 -163 minecraft:stone
fill 392 58 -162 422 58 -162 minecraft:stone
fill 392 58 -161 422 58 -161 minecraft:stone
fill 392 58 -160 422 58 -160 minecraft:stone
fill 392 58 -159 422 58 -159 minecraft:stone
fill 392 58 -158 422 58 -158 minecraft:stone
fill 392 58 -157 422 58 -157 minecraft:stone
fill 392 58 -156 422 58 -156 minecraft:stone
fill 392 58 -155 422 58 -155 minecraft:stone
fill 392 58 -154 422 58 -154 minecraft:stone
fill 392 58 -153 422 58 -153 minecraft:stone
fill 392 58 -152 422 58 -152 minecraft:stone
fill 392 58 -151 421 58 -151 minecraft:stone
fill 392 58 -150 421 58 -150 minecraft:stone
fill 392 58 -149 421 58 -149 minecraft:stone
fill 392 58 -148 421 58 -148 minecraft:stone
fill 392 58 -147 421 58 -147 minecraft:stone
fill 392 58 -146 421 58 -146 minecraft:stone
fill 392 58 -145 421 58 -145 minecraft:stone
fill 392 58 -144 421 58 -144 minecraft:stone
fill 392 58 -143 420 58 -143 minecraft:stone
fill 392 58 -142 420 58 -142 minecraft:stone
fill 392 58 -141 420 58 -141 minecraft:stone
fill 392 58 -140 419 58 -140 minecraft:stone
fill 392 58 -139 419 58 -139 minecraft:stone
fill 392 58 -138 419 58 -138 minecraft:stone
fill 392 58 -137 418 58 -137 minecraft:stone
fill 392 58 -136 418 58 -136 minecraft:stone
fill 392 58 -135 417 58 -135 minecraft:stone
fill 392 58 -134 417 58 -134 minecraft:stone
fill 392 58 -133 416 58 -133 minecraft:stone
fill 392 58 -132 415 58 -132 minecraft:stone
fill 392 58 -131 415 58 -131 minecraft:stone
fill 392 58 -130 414 58 -130 minecraft:stone
fill 392 58 -129 413 58 -129 minecraft:stone
fill 392 58 -128 412 58 -128 minecraft:stone
fill 392 58 -127 411 58 -127 minecraft:stone
fill 392 59 -190 422 59 -190 minecraft:stone
fill 392 59 -189 422 59 -189 minecraft:stone
fill 392 59 -188 404 59 -188 minecraft:stone
fill 406 59 -188 422 59 -188 minecraft:stone
fill 392 59 -187 422 59 -187 minecraft:stone
fill 392 59 -186 422 59 -186 minecraft:stone
fill 392 59 -185 422 59 -185 minecraft:stone
fill 392 59 -184 422 59 -184 minecraft:stone
fill 392 59 -183 422 59 -183 minecraft:stone
fill 392 59 -182 422 59 -182 minecraft:stone
fill 392 59 -181 422 59 -181 minecraft:stone
fill 392 59 -180 422 59 -180 minecraft:stone
fill 392 59 -179 422 59 -179 minecraft:stone
fill 392 59 -178 422 59 -178 minecraft:stone
fill 392 59 -177 422 59 -177 minecraft:stone
fill 392 59 -176 422 59 -176 minecraft:stone
fill 392 59 -175 422 59 -175 minecraft:stone
fill 392 59 -174 401 59 -174 minecraft:stone
fill 403 59 -174 422 59 -174 minecraft:stone
fill 392 59 -173 422 59 -173 minecraft:stone
fill 392 59 -172 422 59 -172 minecraft:stone
fill 392 59 -171 408 59 -171 minecraft:stone
fill 410 59 -171 422 59 -171 minecraft:stone
fill 392 59 -170 405 59 -170 minecraft:stone
fill 407 59 -170 408 59 -170 minecraft:stone
fill 411 59 -170 412 59 -170 minecraft:stone
fill 414 59 -170 422 59 -170 minecraft:stone
fill 392 59 -169 422 59 -169 minecraft:stone
fill 392 59 -168 422 59 -168 minecraft:stone
fill 392 59 -167 405 59 -167 minecraft:stone
fill 407 59 -167 408 59 -167 minecraft:stone
fill 410 59 -167 422 59 -167 minecraft:stone
fill 392 59 -166 422 59 -166 minecraft:stone
fill 392 59 -165 422 59 -165 minecraft:stone
fill 392 59 -164 422 59 -164 minecraft:stone
fill 392 59 -163 422 59 -163 minecraft:stone
fill 392 59 -162 422 59 -162 minecraft:stone
fill 392 59 -161 422 59 -161 minecraft:stone
fill 392 59 -160 422 59 -160 minecraft:stone
fill 392 59 -159 422 59 -159 minecraft:stone
fill 392 59 -158 422 59 -158 minecraft:stone
fill 392 59 -157 422 59 -157 minecraft:stone
fill 392 59 -156 422 59 -156 minecraft:stone
fill 392 59 -155 422 59 -155 minecraft:stone
fill 392 59 -154 422 59 -154 minecraft:stone
fill 392 59 -153 422 59 -153 minecraft:stone
fill 392 59 -152 422 59 -152 minecraft:stone
fill 392 59 -151 421 59 -151 minecraft:stone
fill 392 59 -150 421 59 -150 minecraft:stone
fill 392 59 -149 421 59 -149 minecraft:stone
fill 392 59 -148 421 59 -148 minecraft:stone
fill 392 59 -147 421 59 -147 minecraft:stone
fill 392 59 -146 421 59 -146 minecraft:stone
fill 392 59 -145 421 59 -145 minecraft:stone
fill 392 59 -144 421 59 -144 minecraft:stone
fill 392 59 -143 420 59 -143 minecraft:stone
fill 392 59 -142 420 59 -142 minecraft:stone
fill 392 59 -141 420 59 -141 minecraft:stone
fill 392 59 -140 419 59 -140 minecraft:stone
fill 392 59 -139 419 59 -139 minecraft:stone
fill 392 59 -138 419 59 -138 minecraft:stone
fill 392 59 -137 418 59 -137 minecraft:stone
fill 392 59 -136 418 59 -136 minecraft:stone
fill 392 59 -135 417 59 -135 minecraft:stone
fill 392 59 -134 417 59 -134 minecraft:stone
fill 392 59 -133 416 59 -133 minecraft:stone
fill 392 59 -132 415 59 -132 minecraft:stone
fill 392 59 -131 415 59 -131 minecraft:stone
fill 392 59 -130 414 59 -130 minecraft:stone
fill 392 59 -129 413 59 -129 minecraft:stone
fill 392 59 -128 412 59 -128 minecraft:stone
fill 392 59 -127 411 59 -127 minecraft:stone
fill 392 60 -190 422 60 -190 minecraft:stone
fill 392 60 -189 422 60 -189 minecraft:stone
fill 392 60 -188 404 60 -188 minecraft:stone
fill 406 60 -188 422 60 -188 minecraft:stone
fill 392 60 -187 422 60 -187 minecraft:stone
fill 392 60 -186 422 60 -186 minecraft:stone
fill 392 60 -185 422 60 -185 minecraft:stone
fill 392 60 -184 422 60 -184 minecraft:stone
fill 392 60 -183 422 60 -183 minecraft:stone
fill 392 60 -182 422 60 -182 minecraft:stone
fill 392 60 -181 422 60 -181 minecraft:stone
fill 392 60 -180 422 60 -180 minecraft:stone
fill 392 60 -179 422 60 -179 minecraft:stone
fill 392 60 -178 422 60 -178 minecraft:stone
fill 392 60 -177 422 60 -177 minecraft:stone
fill 392 60 -176 422 60 -176 minecraft:stone
fill 392 60 -175 422 60 -175 minecraft:stone
fill 392 60 -174 401 60 -174 minecraft:stone
fill 403 60 -174 422 60 -174 minecraft:stone
fill 392 60 -173 422 60 -173 minecraft:stone
fill 392 60 -172 422 60 -172 minecraft:stone
fill 392 60 -171 406 60 -171 minecraft:stone
fill 408 60 -171 422 60 -171 minecraft:stone
fill 392 60 -170 405 60 -170 minecraft:stone
fill 410 60 -170 412 60 -170 minecraft:stone
fill 414 60 -170 422 60 -170 minecraft:stone
fill 392 60 -169 405 60 -169 minecraft:stone
setblock 407 60 -169 minecraft:stone
fill 411 60 -169 422 60 -169 minecraft:stone
fill 392 60 -168 405 60 -168 minecraft:stone
setblock 407 60 -168 minecraft:stone
fill 410 60 -168 422 60 -168 minecraft:stone
fill 392 60 -167 406 60 -167 minecraft:stone
fill 409 60 -167 422 60 -167 minecraft:stone
fill 392 60 -166 422 60 -166 minecraft:stone
fill 392 60 -165 422 60 -165 minecraft:stone
fill 392 60 -164 422 60 -164 minecraft:stone
fill 392 60 -163 422 60 -163 minecraft:stone
fill 392 60 -162 422 60 -162 minecraft:stone
fill 392 60 -161 422 60 -161 minecraft:stone
fill 392 60 -160 422 60 -160 minecraft:stone
fill 392 60 -159 422 60 -159 minecraft:stone
fill 392 60 -158 422 60 -158 minecraft:stone
fill 392 60 -157 422 60 -157 minecraft:stone
fill 392 60 -156 422 60 -156 minecraft:stone
fill 392 60 -155 422 60 -155 minecraft:stone
fill 392 60 -154 422 60 -154 minecraft:stone
fill 392 60 -153 422 60 -153 minecraft:stone
fill 392 60 -152 422 60 -152 minecraft:stone
fill 392 60 -151 421 60 -151 minecraft:stone
fill 392 60 -150 421 60 -150 minecraft:stone
fill 392 60 -149 421 60 -149 minecraft:stone
fill 392 60 -148 421 60 -148 minecraft:stone
fill 392 60 -147 421 60 -147 minecraft:stone
fill 392 60 -146 421 60 -146 minecraft:stone
fill 392 60 -145 421 60 -145 minecraft:stone
fill 392 60 -144 421 60 -144 minecraft:stone
fill 392 60 -143 420 60 -143 minecraft:stone
fill 392 60 -142 420 60 -142 minecraft:stone
fill 392 60 -141 420 60 -141 minecraft:stone
fill 392 60 -140 419 60 -140 minecraft:stone
fill 392 60 -139 419 60 -139 minecraft:stone
fill 392 60 -138 419 60 -138 minecraft:stone
fill 392 60 -137 418 60 -137 minecraft:stone
fill 392 60 -136 418 60 -136 minecraft:stone
fill 392 60 -135 417 60 -135 minecraft:stone
fill 392 60 -134 417 60 -134 minecraft:stone
fill 392 60 -133 416 60 -133 minecraft:stone
fill 392 60 -132 415 60 -132 minecraft:stone
fill 392 60 -131 415 60 -131 minecraft:stone
fill 392 60 -130 414 60 -130 minecraft:stone
fill 392 60 -129 413 60 -129 minecraft:stone
fill 392 60 -128 412 60 -128 minecraft:stone
fill 392 60 -127 411 60 -127 minecraft:stone
fill 392 61 -190 422 61 -190 minecraft:stone
fill 392 61 -189 422 61 -189 minecraft:stone
fill 392 61 -188 404 61 -188 minecraft:stone
fill 406 61 -188 422 61 -188 minecraft:stone
fill 392 61 -187 422 61 -187 minecraft:stone
fill 392 61 -186 422 61 -186 minecraft:stone
fill 392 61 -185 422 61 -185 minecraft:stone
fill 392 61 -184 422 61 -184 minecraft:stone
fill 392 61 -183 422 61 -183 minecraft:stone
fill 392 61 -182 422 61 -182 minecraft:stone
fill 392 61 -181 422 61 -181 minecraft:stone
fill 392 61 -180 422 61 -180 minecraft:stone
fill 392 61 -179 422 61 -179 minecraft:stone
fill 392 61 -178 422 61 -178 minecraft:stone
fill 392 61 -177 422 61 -177 minecraft:stone
fill 392 61 -176 422 61 -176 minecraft:stone
fill 392 61 -175 422 61 -175 minecraft:stone
fill 392 61 -174 401 61 -174 minecraft:stone
fill 403 61 -174 422 61 -174 minecraft:stone
fill 392 61 -173 422 61 -173 minecraft:stone
fill 392 61 -172 422 61 -172 minecraft:stone
fill 392 61 -171 422 61 -171 minecraft:stone
fill 392 61 -170 406 61 -170 minecraft:stone
fill 408 61 -170 412 61 -170 minecraft:stone
fill 414 61 -170 422 61 -170 minecraft:stone
fill 392 61 -169 408 61 -169 minecraft:stone
fill 410 61 -169 422 61 -169 minecraft:stone
fill 392 61 -168 422 61 -168 minecraft:stone
fill 392 61 -167 422 61 -167 minecraft:stone
fill 392 61 -166 422 61 -166 minecraft:stone
fill 392 61 -165 422 61 -165 minecraft:stone
fill 392 61 -164 422 61 -164 minecraft:stone
fill 392 61 -163 422 61 -163 minecraft:stone
fill 392 61 -162 422 61 -162 minecraft:stone
fill 392 61 -161 422 61 -161 minecraft:stone
fill 392 61 -160 422 61 -160 minecraft:stone
fill 392 61 -159 422 61 -159 minecraft:stone
fill 392 61 -158 422 61 -158 minecraft:stone
fill 392 61 -157 422 61 -157 minecraft:stone
fill 392 61 -156 422 61 -156 minecraft:stone
fill 392 61 -155 422 61 -155 minecraft:stone
fill 392 61 -154 422 61 -154 minecraft:stone
fill 392 61 -153 422 61 -153 minecraft:stone
fill 392 61 -152 422 61 -152 minecraft:stone
fill 392 61 -151 421 61 -151 minecraft:stone
fill 392 61 -150 421 61 -150 minecraft:stone
fill 392 61 -149 421 61 -149 minecraft:stone
fill 392 61 -148 421 61 -148 minecraft:stone
fill 392 61 -147 421 61 -147 minecraft:stone
fill 392 61 -146 421 61 -146 minecraft:stone
fill 392 61 -145 421 61 -145 minecraft:stone
fill 392 61 -144 421 61 -144 minecraft:stone
fill 392 61 -143 420 61 -143 minecraft:stone
fill 392 61 -142 420 61 -142 minecraft:stone
fill 392 61 -141 420 61 -141 minecraft:stone
fill 392 61 -140 419 61 -140 minecraft:stone
fill 392 61 -139 419 61 -139 minecraft:stone
fill 392 61 -138 419 61 -138 minecraft:stone
fill 392 61 -137 418 61 -137 minecraft:stone
fill 392 61 -136 418 61 -136 minecraft:stone
fill 392 61 -135 417 61 -135 minecraft:stone
fill 392 61 -134 417 61 -134 minecraft:stone
fill 392 61 -133 416 61 -133 minecraft:stone
fill 392 61 -132 415 61 -132 minecraft:stone
fill 392 61 -131 415 61 -131 minecraft:stone
fill 392 61 -130 414 61 -130 minecraft:stone
fill 392 61 -129 413 61 -129 minecraft:stone
fill 392 61 -128 412 61 -128 minecraft:stone
fill 392 61 -127 411 61 -127 minecraft:stone
fill 392 62 -190 422 62 -190 minecraft:dirt
fill 392 62 -189 422 62 -189 minecraft:dirt
fill 392 62 -188 404 62 -188 minecraft:dirt
fill 406 62 -188 422 62 -188 minecraft:dirt
fill 392 62 -187 422 62 -187 minecraft:dirt
fill 392 62 -186 422 62 -186 minecraft:dirt
fill 392 62 -185 422 62 -185 minecraft:dirt
fill 392 62 -184 422 62 -184 minecraft:dirt
fill 392 62 -183 422 62 -183 minecraft:dirt
fill 392 62 -182 422 62 -182 minecraft:dirt
fill 392 62 -181 422 62 -181 minecraft:dirt
fill 392 62 -180 422 62 -180 minecraft:dirt
fill 392 62 -179 422 62 -179 minecraft:dirt
fill 392 62 -178 422 62 -178 minecraft:dirt
fill 392 62 -177 422 62 -177 minecraft:dirt
fill 392 62 -176 422 62 -176 minecraft:dirt
fill 392 62 -175 422 62 -175 minecraft:dirt
fill 392 62 -174 401 62 -174 minecraft:dirt
fill 403 62 -174 422 62 -174 minecraft:dirt
fill 392 62 -173 422 62 -173 minecraft:dirt
fill 392 62 -172 422 62 -172 minecraft:dirt
fill 392 62 -171 422 62 -171 minecraft:dirt
fill 392 62 -170 412 62 -170 minecraft:dirt
fill 414 62 -170 422 62 -170 minecraft:dirt
fill 392 62 -169 422 62 -169 minecraft:dirt
fill 392 62 -168 422 62 -168 minecraft:dirt
fill 392 62 -167 422 62 -167 minecraft:dirt
fill 392 62 -166 422 62 -166 minecraft:dirt
fill 392 62 -165 422 62 -165 minecraft:dirt
fill 392 62 -164 422 62 -164 minecraft:dirt
fill 392 62 -163 422 62 -163 minecraft:dirt
fill 392 62 -162 422 62 -162 minecraft:dirt
fill 392 62 -161 422 62 -161 minecraft:dirt
fill 392 62 -160 422 62 -160 minecraft:dirt
fill 392 62 -159 422 62 -159 minecraft:dirt
fill 392 62 -158 422 62 -158 minecraft:dirt
fill 392 62 -157 422 62 -157 minecraft:dirt
fill 392 62 -156 422 62 -156 minecraft:dirt
fill 392 62 -155 422 62 -155 minecraft:dirt
fill 392 62 -154 422 62 -154 minecraft:dirt
fill 392 62 -153 422 62 -153 minecraft:dirt
fill 392 62 -152 422 62 -152 minecraft:dirt
fill 392 62 -151 421 62 -151 minecraft:dirt
fill 392 62 -150 421 62 -150 minecraft:dirt
fill 392 62 -149 421 62 -149 minecraft:dirt
fill 392 62 -148 421 62 -148 minecraft:dirt
fill 392 62 -147 421 62 -147 minecraft:dirt
fill 392 62 -146 421 62 -146 minecraft:dirt
fill 392 62 -145 421 62 -145 minecraft:dirt
fill 392 62 -144 421 62 -144 minecraft:dirt
fill 392 62 -143 420 62 -143 minecraft:dirt
fill 392 62 -142 420 62 -142 minecraft:dirt
fill 392 62 -141 420 62 -141 minecraft:dirt
fill 392 62 -140 419 62 -140 minecraft:dirt
fill 392 62 -139 419 62 -139 minecraft:dirt
fill 392 62 -138 419 62 -138 minecraft:dirt
fill 392 62 -137 418 62 -137 minecraft:dirt
fill 392 62 -136 418 62 -136 minecraft:dirt
fill 392 62 -135 417 62 -135 minecraft:dirt
fill 392 62 -134 417 62 -134 minecraft:dirt
fill 392 62 -133 416 62 -133 minecraft:dirt
fill 392 62 -132 415 62 -132 minecraft:dirt
fill 392 62 -131 415 62 -131 minecraft:dirt
fill 392 62 -130 414 62 -130 minecraft:dirt
fill 392 62 -129 413 62 -129 minecraft:dirt
fill 392 62 -128 412 62 -128 minecraft:dirt
fill 392 62 -127 411 62 -127 minecraft:dirt
fill 392 63 -190 422 63 -190 minecraft:dirt
fill 392 63 -189 422 63 -189 minecraft:dirt
fill 392 63 -188 404 63 -188 minecraft:dirt
fill 406 63 -188 422 63 -188 minecraft:dirt
fill 392 63 -187 422 63 -187 minecraft:dirt
fill 392 63 -186 422 63 -186 minecraft:dirt
fill 392 63 -185 422 63 -185 minecraft:dirt
fill 392 63 -184 422 63 -184 minecraft:dirt
fill 392 63 -183 422 63 -183 minecraft:dirt
fill 392 63 -182 422 63 -182 minecraft:dirt
fill 392 63 -181 422 63 -181 minecraft:dirt
fill 392 63 -180 422 63 -180 minecraft:dirt
fill 392 63 -179 422 63 -179 minecraft:dirt
fill 392 63 -178 422 63 -178 minecraft:dirt
fill 392 63 -177 422 63 -177 minecraft:dirt
fill 392 63 -176 422 63 -176 minecraft:dirt
fill 392 63 -175 422 63 -175 minecraft:dirt
fill 392 63 -174 401 63 -174 minecraft:dirt
fill 403 63 -174 422 63 -174 minecraft:dirt
fill 392 63 -173 422 63 -173 minecraft:dirt
fill 392 63 -172 422 63 -172 minecraft:dirt
fill 392 63 -171 422 63 -171 minecraft:dirt
fill 392 63 -170 412 63 -170 minecraft:dirt
fill 414 63 -170 422 63 -170 minecraft:dirt
fill 392 63 -169 422 63 -169 minecraft:dirt
fill 392 63 -168 422 63 -168 minecraft:dirt
fill 392 63 -167 422 63 -167 minecraft:dirt
fill 392 63 -166 422 63 -166 minecraft:dirt
fill 392 63 -165 422 63 -165 minecraft:dirt
fill 392 63 -164 422 63 -164 minecraft:dirt
fill 392 63 -163 422 63 -163 minecraft:dirt
fill 392 63 -162 422 63 -162 minecraft:dirt
fill 392 63 -161 422 63 -161 minecraft:dirt
fill 392 63 -160 422 63 -160 minecraft:dirt
fill 392 63 -159 422 63 -159 minecraft:dirt
fill 392 63 -158 422 63 -158 minecraft:dirt
fill 392 63 -157 422 63 -157 minecraft:dirt
fill 392 63 -156 422 63 -156 minecraft:dirt
fill 392 63 -155 422 63 -155 minecraft:dirt
fill 392 63 -154 422 63 -154 minecraft:dirt
fill 392 63 -153 422 63 -153 minecraft:dirt
fill 392 63 -152 422 63 -152 minecraft:dirt
fill 392 63 -151 421 63 -151 minecraft:dirt
fill 392 63 -150 421 63 -150 minecraft:dirt
fill 392 63 -149 421 63 -149 minecraft:dirt
fill 392 63 -148 421 63 -148 minecraft:dirt
fill 392 63 -147 421 63 -147 minecraft:dirt
fill 392 63 -146 421 63 -146 minecraft:dirt
fill 392 63 -145 421 63 -145 minecraft:dirt
fill 392 63 -144 421 63 -144 minecraft:dirt
fill 392 63 -143 420 63 -143 minecraft:dirt
fill 392 63 -142 420 63 -142 minecraft:dirt
fill 392 63 -141 420 63 -141 minecraft:dirt
fill 392 63 -140 419 63 -140 minecraft:dirt
fill 392 63 -139 419 63 -139 minecraft:dirt
fill 392 63 -138 419 63 -138 minecraft:dirt
fill 392 63 -137 418 63 -137 minecraft:dirt
fill 392 63 -136 418 63 -136 minecraft:dirt
fill 392 63 -135 417 63 -135 minecraft:dirt
fill 392 63 -134 417 63 -134 minecraft:dirt
fill 392 63 -133 416 63 -133 minecraft:dirt
fill 392 63 -132 415 63 -132 minecraft:dirt
fill 392 63 -131 415 63 -131 minecraft:dirt
fill 392 63 -130 414 63 -130 minecraft:dirt
fill 392 63 -129 413 63 -129 minecraft:dirt
fill 392 63 -128 412 63 -128 minecraft:dirt
fill 392 63 -127 411 63 -127 minecraft:dirt
fill 392 64 -190 422 64 -190 minecraft:dirt
fill 392 64 -189 422 64 -189 minecraft:dirt
fill 392 64 -188 404 64 -188 minecraft:dirt
fill 406 64 -188 422 64 -188 minecraft:dirt
fill 392 64 -187 422 64 -187 minecraft:dirt
fill 392 64 -186 422 64 -186 minecraft:dirt
fill 392 64 -185 422 64 -185 minecraft:dirt
fill 392 64 -184 422 64 -184 minecraft:dirt
fill 392 64 -183 422 64 -183 minecraft:dirt
fill 392 64 -182 422 64 -182 minecraft:dirt
fill 392 64 -181 422 64 -181 minecraft:dirt
fill 392 64 -180 422 64 -180 minecraft:dirt
fill 392 64 -179 422 64 -179 minecraft:dirt
fill 392 64 -178 422 64 -178 minecraft:dirt
fill 392 64 -177 422 64 -177 minecraft:dirt
fill 392 64 -176 422 64 -176 minecraft:dirt
fill 392 64 -175 422 64 -175 minecraft:dirt
fill 392 64 -174 401 64 -174 minecraft:dirt
fill 403 64 -174 422 64 -174 minecraft:dirt
fill 392 64 -173 422 64 -173 minecraft:dirt
fill 392 64 -172 422 64 -172 minecraft:dirt
fill 392 64 -171 422 64 -171 minecraft:dirt
fill 392 64 -170 412 64 -170 minecraft:dirt
fill 414 64 -170 422 64 -170 minecraft:dirt
fill 392 64 -169 422 64 -169 minecraft:dirt
fill 392 64 -168 422 64 -168 minecraft:dirt
fill 392 64 -167 422 64 -167 minecraft:dirt
fill 392 64 -166 422 64 -166 minecraft:dirt
fill 392 64 -165 422 64 -165 minecraft:dirt
fill 392 64 -164 422 64 -164 minecraft:dirt
fill 392 64 -163 422 64 -163 minecraft:dirt
fill 392 64 -162 422 64 -162 minecraft:dirt
fill 392 64 -161 422 64 -161 minecraft:dirt
fill 392 64 -160 422 64 -160 minecraft:dirt
fill 392 64 -159 422 64 -159 minecraft:dirt
fill 392 64 -158 422 64 -158 minecraft:dirt
fill 392 64 -157 422 64 -157 minecraft:dirt
fill 392 64 -156 422 64 -156 minecraft:dirt
fill 392 64 -155 422 64 -155 minecraft:dirt
fill 392 64 -154 422 64 -154 minecraft:dirt
fill 392 64 -153 422 64 -153 minecraft:dirt
fill 392 64 -152 422 64 -152 minecraft:dirt
fill 392 64 -151 421 64 -151 minecraft:dirt
fill 392 64 -150 421 64 -150 minecraft:dirt
fill 392 64 -149 421 64 -149 minecraft:dirt
fill 392 64 -148 421 64 -148 minecraft:dirt
fill 392 64 -147 421 64 -147 minecraft:dirt
fill 392 64 -146 421 64 -146 minecraft:dirt
fill 392 64 -145 421 64 -145 minecraft:dirt
fill 392 64 -144 421 64 -144 minecraft:dirt
fill 392 64 -143 420 64 -143 minecraft:dirt
fill 392 64 -142 420 64 -142 minecraft:dirt
fill 392 64 -141 420 64 -141 minecraft:dirt
fill 392 64 -140 419 64 -140 minecraft:dirt
fill 392 64 -139 419 64 -139 minecraft:dirt
fill 392 64 -138 419 64 -138 minecraft:dirt
fill 392 64 -137 418 64 -137 minecraft:dirt
fill 392 64 -136 418 64 -136 minecraft:dirt
fill 392 64 -135 417 64 -135 minecraft:dirt
fill 392 64 -134 417 64 -134 minecraft:dirt
fill 392 64 -133 416 64 -133 minecraft:dirt
fill 392 64 -132 415 64 -132 minecraft:dirt
fill 392 64 -131 415 64 -131 minecraft:dirt
fill 392 64 -130 414 64 -130 minecraft:dirt
fill 392 64 -129 413 64 -129 minecraft:dirt
fill 392 64 -128 412 64 -128 minecraft:dirt
fill 392 64 -127 411 64 -127 minecraft:dirt
fill 392 65 -190 416 65 -190 minecraft:grass_block
setblock 417 65 -190 minecraft:smooth_quartz
fill 418 65 -190 422 65 -190 minecraft:light_gray_concrete
fill 392 65 -189 416 65 -189 minecraft:grass_block
setblock 417 65 -189 minecraft:smooth_quartz
fill 418 65 -189 422 65 -189 minecraft:light_gray_concrete
fill 392 65 -188 404 65 -188 minecraft:grass_block
fill 406 65 -188 416 65 -188 minecraft:grass_block
setblock 417 65 -188 minecraft:smooth_quartz
fill 418 65 -188 422 65 -188 minecraft:light_gray_concrete
fill 392 65 -187 416 65 -187 minecraft:grass_block
setblock 417 65 -187 minecraft:smooth_quartz
fill 418 65 -187 420 65 -187 minecraft:light_gray_concrete
setblock 421 65 -187 minecraft:sea_lantern
setblock 422 65 -187 minecraft:light_gray_concrete
fill 392 65 -186 416 65 -186 minecraft:grass_block
setblock 417 65 -186 minecraft:smooth_quartz
fill 418 65 -186 419 65 -186 minecraft:light_gray_concrete
setblock 420 65 -186 minecraft:sea_lantern
fill 421 65 -186 422 65 -186 minecraft:light_gray_concrete
fill 392 65 -185 416 65 -185 minecraft:grass_block
setblock 417 65 -185 minecraft:smooth_quartz
setblock 418 65 -185 minecraft:light_gray_concrete
setblock 419 65 -185 minecraft:sea_lantern
fill 420 65 -185 422 65 -185 minecraft:light_gray_concrete
fill 392 65 -184 416 65 -184 minecraft:grass_block
setblock 417 65 -184 minecraft:smooth_quartz
setblock 418 65 -184 minecraft:sea_lantern
fill 419 65 -184 422 65 -184 minecraft:light_gray_concrete
fill 392 65 -183 416 65 -183 minecraft:grass_block
setblock 417 65 -183 minecraft:smooth_quartz
fill 418 65 -183 422 65 -183 minecraft:light_gray_concrete
fill 392 65 -182 416 65 -182 minecraft:grass_block
setblock 417 65 -182 minecraft:smooth_quartz
fill 418 65 -182 422 65 -182 minecraft:light_gray_concrete
fill 392 65 -181 416 65 -181 minecraft:grass_block
setblock 417 65 -181 minecraft:smooth_quartz
fill 418 65 -181 422 65 -181 minecraft:light_gray_concrete
fill 392 65 -180 416 65 -180 minecraft:grass_block
setblock 417 65 -180 minecraft:smooth_quartz
fill 418 65 -180 422 65 -180 minecraft:light_gray_concrete
fill 392 65 -179 416 65 -179 minecraft:grass_block
setblock 417 65 -179 minecraft:smooth_quartz
fill 418 65 -179 422 65 -179 minecraft:light_gray_concrete
fill 392 65 -178 416 65 -178 minecraft:grass_block
setblock 417 65 -178 minecraft:smooth_quartz
fill 418 65 -178 420 65 -178 minecraft:light_gray_concrete
setblock 421 65 -178 minecraft:sea_lantern
setblock 422 65 -178 minecraft:light_gray_concrete
fill 392 65 -177 416 65 -177 minecraft:grass_block
setblock 417 65 -177 minecraft:smooth_quartz
fill 418 65 -177 419 65 -177 minecraft:light_gray_concrete
setblock 420 65 -177 minecraft:sea_lantern
fill 421 65 -177 422 65 -177 minecraft:light_gray_concrete
fill 392 65 -176 416 65 -176 minecraft:grass_block
setblock 417 65 -176 minecraft:smooth_quartz
setblock 418 65 -176 minecraft:light_gray_concrete
setblock 419 65 -176 minecraft:sea_lantern
fill 420 65 -176 422 65 -176 minecraft:light_gray_concrete
fill 392 65 -175 416 65 -175 minecraft:grass_block
setblock 417 65 -175 minecraft:smooth_quartz
setblock 418 65 -175 minecraft:sea_lantern
fill 419 65 -175 422 65 -175 minecraft:light_gray_concrete
fill 392 65 -174 401 65 -174 minecraft:grass_block
fill 403 65 -174 416 65 -174 minecraft:grass_block
setblock 417 65 -174 minecraft:smooth_quartz
fill 418 65 -174 422 65 -174 minecraft:light_gray_concrete
fill 392 65 -173 416 65 -173 minecraft:grass_block
setblock 417 65 -173 minecraft:smooth_quartz
fill 418 65 -173 422 65 -173 minecraft:light_gray_concrete
fill 392 65 -172 416 65 -172 minecraft:grass_block
setblock 417 65 -172 minecraft:smooth_quartz
fill 418 65 -172 422 65 -172 minecraft:light_gray_concrete
fill 392 65 -171 416 65 -171 minecraft:grass_block
setblock 417 65 -171 minecraft:smooth_quartz
fill 418 65 -171 422 65 -171 minecraft:light_gray_concrete
fill 392 65 -170 412 65 -170 minecraft:grass_block
fill 414 65 -170 416 65 -170 minecraft:grass_block
setblock 417 65 -170 minecraft:smooth_quartz
fill 418 65 -170 422 65 -170 minecraft:light_gray_concrete
fill 392 65 -169 416 65 -169 minecraft:grass_block
setblock 417 65 -169 minecraft:smooth_quartz
fill 418 65 -169 420 65 -169 minecraft:light_gray_concrete
setblock 421 65 -169 minecraft:sea_lantern
setblock 422 65 -169 minecraft:light_gray_concrete
fill 392 65 -168 416 65 -168 minecraft:grass_block
setblock 417 65 -168 minecraft:smooth_quartz
fill 418 65 -168 419 65 -168 minecraft:light_gray_concrete
setblock 420 65 -168 minecraft:sea_lantern
fill 421 65 -168 422 65 -168 minecraft:light_gray_concrete
fill 392 65 -167 416 65 -167 minecraft:grass_block
setblock 417 65 -167 minecraft:smooth_quartz
setblock 418 65 -167 minecraft:light_gray_concrete
setblock 419 65 -167 minecraft:sea_lantern
fill 420 65 -167 422 65 -167 minecraft:light_gray_concrete
fill 392 65 -166 416 65 -166 minecraft:grass_block
setblock 417 65 -166 minecraft:smooth_quartz
setblock 418 65 -166 minecraft:sea_lantern
fill 419 65 -166 422 65 -166 minecraft:light_gray_concrete
fill 392 65 -165 416 65 -165 minecraft:grass_block
setblock 417 65 -165 minecraft:smooth_quartz
fill 418 65 -165 422 65 -165 minecraft:light_gray_concrete
fill 392 65 -164 416 65 -164 minecraft:grass_block
setblock 417 65 -164 minecraft:smooth_quartz
fill 418 65 -164 422 65 -164 minecraft:light_gray_concrete
fill 392 65 -163 416 65 -163 minecraft:grass_block
setblock 417 65 -163 minecraft:smooth_quartz
fill 418 65 -163 422 65 -163 minecraft:light_gray_concrete
fill 392 65 -162 416 65 -162 minecraft:grass_block
setblock 417 65 -162 minecraft:smooth_quartz
fill 418 65 -162 422 65 -162 minecraft:light_gray_concrete
fill 392 65 -161 416 65 -161 minecraft:grass_block
setblock 417 65 -161 minecraft:smooth_quartz
fill 418 65 -161 422 65 -161 minecraft:light_gray_concrete
fill 392 65 -160 416 65 -160 minecraft:grass_block
setblock 417 65 -160 minecraft:smooth_quartz
fill 418 65 -160 420 65 -160 minecraft:light_gray_concrete
setblock 421 65 -160 minecraft:sea_lantern
setblock 422 65 -160 minecraft:light_gray_concrete
fill 392 65 -159 416 65 -159 minecraft:grass_block
setblock 417 65 -159 minecraft:smooth_quartz
fill 418 65 -159 419 65 -159 minecraft:light_gray_concrete
setblock 420 65 -159 minecraft:sea_lantern
fill 421 65 -159 422 65 -159 minecraft:light_gray_concrete
fill 392 65 -158 416 65 -158 minecraft:grass_block
setblock 417 65 -158 minecraft:smooth_quartz
setblock 418 65 -158 minecraft:light_gray_concrete
setblock 419 65 -158 minecraft:sea_lantern
fill 420 65 -158 422 65 -158 minecraft:light_gray_concrete
fill 392 65 -157 416 65 -157 minecraft:grass_block
setblock 417 65 -157 minecraft:smooth_quartz
setblock 418 65 -157 minecraft:sea_lantern
fill 419 65 -157 422 65 -157 minecraft:light_gray_concrete
fill 392 65 -156 416 65 -156 minecraft:grass_block
setblock 417 65 -156 minecraft:smooth_quartz
fill 418 65 -156 422 65 -156 minecraft:light_gray_concrete
fill 392 65 -155 416 65 -155 minecraft:grass_block
setblock 417 65 -155 minecraft:smooth_quartz
fill 418 65 -155 422 65 -155 minecraft:light_gray_concrete
fill 392 65 -154 416 65 -154 minecraft:grass_block
setblock 417 65 -154 minecraft:smooth_quartz
fill 418 65 -154 422 65 -154 minecraft:light_gray_concrete
fill 392 65 -153 416 65 -153 minecraft:grass_block
setblock 417 65 -153 minecraft:smooth_quartz
fill 418 65 -153 422 65 -153 minecraft:light_gray_concrete
fill 392 65 -152 416 65 -152 minecraft:grass_block
setblock 417 65 -152 minecraft:smooth_quartz
fill 418 65 -152 422 65 -152 minecraft:light_gray_concrete
fill 392 65 -151 415 65 -151 minecraft:grass_block
setblock 416 65 -151 minecraft:smooth_quartz
fill 417 65 -151 421 65 -151 minecraft:light_gray_concrete
fill 392 65 -150 415 65 -150 minecraft:grass_block
setblock 416 65 -150 minecraft:smooth_quartz
fill 417 65 -150 419 65 -150 minecraft:light_gray_concrete
setblock 420 65 -150 minecraft:sea_lantern
setblock 421 65 -150 minecraft:light_gray_concrete
fill 392 65 -149 415 65 -149 minecraft:grass_block
setblock 416 65 -149 minecraft:smooth_quartz
fill 417 65 -149 418 65 -149 minecraft:light_gray_concrete
setblock 419 65 -149 minecraft:sea_lantern
fill 420 65 -149 421 65 -149 minecraft:light_gray_concrete
fill 392 65 -148 415 65 -148 minecraft:grass_block
setblock 416 65 -148 minecraft:smooth_quartz
setblock 417 65 -148 minecraft:light_gray_concrete
setblock 418 65 -148 minecraft:sea_lantern
fill 419 65 -148 421 65 -148 minecraft:light_gray_concrete
fill 392 65 -147 415 65 -147 minecraft:grass_block
setblock 416 65 -147 minecraft:smooth_quartz
setblock 417 65 -147 minecraft:sea_lantern
fill 418 65 -147 421 65 -147 minecraft:light_gray_concrete
fill 392 65 -146 415 65 -146 minecraft:grass_block
setblock 416 65 -146 minecraft:smooth_quartz
fill 417 65 -146 421 65 -146 minecraft:light_gray_concrete
fill 392 65 -145 415 65 -145 minecraft:grass_block
setblock 416 65 -145 minecraft:smooth_quartz
fill 417 65 -145 421 65 -145 minecraft:light_gray_concrete
fill 392 65 -144 414 65 -144 minecraft:grass_block
setblock 415 65 -144 minecraft:smooth_quartz
fill 416 65 -144 421 65 -144 minecraft:light_gray_concrete
fill 392 65 -143 414 65 -143 minecraft:grass_block
setblock 415 65 -143 minecraft:smooth_quartz
fill 416 65 -143 420 65 -143 minecraft:light_gray_concrete
fill 392 65 -142 414 65 -142 minecraft:grass_block
setblock 415 65 -142 minecraft:smooth_quartz
fill 416 65 -142 420 65 -142 minecraft:light_gray_concrete
fill 392 65 -141 413 65 -141 minecraft:grass_block
setblock 414 65 -141 minecraft:smooth_quartz
fill 415 65 -141 420 65 -141 minecraft:light_gray_concrete
fill 392 65 -140 413 65 -140 minecraft:grass_block
setblock 414 65 -140 minecraft:smooth_quartz
fill 415 65 -140 419 65 -140 minecraft:light_gray_concrete
fill 392 65 -139 413 65 -139 minecraft:grass_block
setblock 414 65 -139 minecraft:smooth_quartz
fill 415 65 -139 417 65 -139 minecraft:light_gray_concrete
setblock 418 65 -139 minecraft:sea_lantern
setblock 419 65 -139 minecraft:light_gray_concrete
fill 392 65 -138 412 65 -138 minecraft:grass_block
setblock 413 65 -138 minecraft:smooth_quartz
fill 414 65 -138 416 65 -138 minecraft:light_gray_concrete
setblock 417 65 -138 minecraft:sea_lantern
fill 418 65 -138 419 65 -138 minecraft:light_gray_concrete
fill 392 65 -137 411 65 -137 minecraft:grass_block
fill 412 65 -137 413 65 -137 minecraft:smooth_quartz
fill 414 65 -137 415 65 -137 minecraft:light_gray_concrete
setblock 416 65 -137 minecraft:sea_lantern
fill 417 65 -137 418 65 -137 minecraft:light_gray_concrete
fill 392 65 -136 411 65 -136 minecraft:grass_block
setblock 412 65 -136 minecraft:smooth_quartz
fill 413 65 -136 414 65 -136 minecraft:light_gray_concrete
setblock 415 65 -136 minecraft:sea_lantern
fill 416 65 -136 418 65 -136 minecraft:light_gray_concrete
fill 392 65 -135 410 65 -135 minecraft:grass_block
setblock 411 65 -135 minecraft:smooth_quartz
fill 412 65 -135 413 65 -135 minecraft:light_gray_concrete
setblock 414 65 -135 minecraft:sea_lantern
fill 415 65 -135 417 65 -135 minecraft:light_gray_concrete
fill 392 65 -134 410 65 -134 minecraft:grass_block
setblock 411 65 -134 minecraft:smooth_quartz
setblock 412 65 -134 minecraft:light_gray_concrete
setblock 413 65 -134 minecraft:sea_lantern
fill 414 65 -134 417 65 -134 minecraft:light_gray_concrete
fill 392 65 -133 409 65 -133 minecraft:grass_block
setblock 410 65 -133 minecraft:smooth_quartz
setblock 411 65 -133 minecraft:light_gray_concrete
setblock 412 65 -133 minecraft:sea_lantern
fill 413 65 -133 416 65 -133 minecraft:light_gray_concrete
fill 392 65 -132 408 65 -132 minecraft:grass_block
setblock 409 65 -132 minecraft:smooth_quartz
setblock 410 65 -132 minecraft:light_gray_concrete
setblock 411 65 -132 minecraft:sea_lantern
fill 412 65 -132 415 65 -132 minecraft:light_gray_concrete
fill 392 65 -131 407 65 -131 minecraft:grass_block
setblock 408 65 -131 minecraft:smooth_quartz
setblock 409 65 -131 minecraft:light_gray_concrete
setblock 410 65 -131 minecraft:sea_lantern
fill 411 65 -131 415 65 -131 minecraft:light_gray_concrete
fill 392 65 -130 406 65 -130 minecraft:grass_block
setblock 407 65 -130 minecraft:smooth_quartz
setblock 408 65 -130 minecraft:light_gray_concrete
setblock 409 65 -130 minecraft:sea_lantern
fill 410 65 -130 414 65 -130 minecraft:light_gray_concrete
fill 392 65 -129 405 65 -129 minecraft:grass_block
setblock 406 65 -129 minecraft:smooth_quartz
setblock 407 65 -129 minecraft:light_gray_concrete
setblock 408 65 -129 minecraft:sea_lantern
fill 409 65 -129 413 65 -129 minecraft:light_gray_concrete
fill 392 65 -128 404 65 -128 minecraft:grass_block
setblock 405 65 -128 minecraft:smooth_quartz
setblock 406 65 -128 minecraft:light_gray_concrete
setblock 407 65 -128 minecraft:sea_lantern
fill 408 65 -128 412 65 -128 minecraft:light_gray_concrete
fill 392 65 -127 402 65 -127 minecraft:grass_block
fill 403 65 -127 404 65 -127 minecraft:smooth_quartz
setblock 405 65 -127 minecraft:light_gray_concrete
setblock 406 65 -127 minecraft:sea_lantern
fill 407 65 -127 411 65 -127 minecraft:light_gray_concrete
setblock 392 66 -190 minecraft:oxeye_daisy
setblock 394 66 -190 minecraft:oxeye_daisy
setblock 396 66 -190 minecraft:azure_bluet
fill 402 66 -190 403 66 -190 minecraft:orange_tulip
setblock 404 66 -190 minecraft:allium
setblock 407 66 -190 minecraft:allium
setblock 410 66 -190 minecraft:dandelion
setblock 413 66 -190 minecraft:cornflower
setblock 393 66 -189 minecraft:oxeye_daisy
setblock 396 66 -189 minecraft:azure_bluet
fill 398 66 -189 399 66 -189 minecraft:azure_bluet
setblock 400 66 -189 minecraft:orange_tulip
setblock 404 66 -189 minecraft:allium
setblock 408 66 -189 minecraft:dandelion
setblock 411 66 -189 minecraft:dandelion
fill 412 66 -189 414 66 -189 minecraft:cornflower
setblock 392 66 -188 minecraft:oxeye_daisy
setblock 395 66 -188 minecraft:oxeye_daisy
setblock 396 66 -188 minecraft:azure_bluet
setblock 400 66 -188 minecraft:orange_tulip
setblock 403 66 -188 minecraft:orange_tulip
fill 406 66 -188 407 66 -188 minecraft:allium
setblock 411 66 -188 minecraft:dandelion
fill 412 66 -188 414 66 -188 minecraft:cornflower
fill 393 66 -187 395 66 -187 minecraft:oxeye_daisy
setblock 396 66 -187 minecraft:azure_bluet
fill 398 66 -187 399 66 -187 minecraft:azure_bluet
setblock 403 66 -187 minecraft:orange_tulip
fill 406 66 -187 407 66 -187 minecraft:allium
setblock 409 66 -187 minecraft:dandelion
fill 412 66 -187 413 66 -187 minecraft:cornflower
setblock 415 66 -187 minecraft:cornflower
setblock 392 66 -186 minecraft:oxeye_daisy
setblock 395 66 -186 minecraft:oxeye_daisy
fill 396 66 -186 397 66 -186 minecraft:azure_bluet
setblock 399 66 -186 minecraft:azure_bluet
setblock 400 66 -186 minecraft:orange_tulip
fill 402 66 -186 403 66 -186 minecraft:orange_tulip
setblock 405 66 -186 minecraft:allium
setblock 407 66 -186 minecraft:allium
setblock 408 66 -186 minecraft:dandelion
setblock 411 66 -186 minecraft:dandelion
setblock 413 66 -186 minecraft:cornflower
setblock 415 66 -186 minecraft:cornflower
setblock 392 66 -185 minecraft:oxeye_daisy
fill 394 66 -185 395 66 -185 minecraft:oxeye_daisy
setblock 399 66 -185 minecraft:azure_bluet
fill 400 66 -185 402 66 -185 minecraft:orange_tulip
fill 404 66 -185 405 66 -185 minecraft:allium
fill 408 66 -185 409 66 -185 minecraft:dandelion
setblock 412 66 -185 minecraft:cornflower
setblock 414 66 -185 minecraft:cornflower
setblock 392 66 -184 minecraft:oxeye_daisy
setblock 397 66 -184 minecraft:azure_bluet
fill 401 66 -184 402 66 -184 minecraft:orange_tulip
setblock 404 66 -184 minecraft:allium
setblock 408 66 -184 minecraft:dandelion
setblock 410 66 -184 minecraft:dandelion
fill 412 66 -184 415 66 -184 minecraft:cornflower
setblock 392 66 -183 minecraft:oxeye_daisy
setblock 395 66 -183 minecraft:oxeye_daisy
setblock 396 66 -183 minecraft:azure_bluet
fill 398 66 -183 399 66 -183 minecraft:azure_bluet
setblock 403 66 -183 minecraft:orange_tulip
setblock 404 66 -183 minecraft:allium
fill 408 66 -183 411 66 -183 minecraft:dandelion
setblock 413 66 -183 minecraft:cornflower
setblock 415 66 -183 minecraft:cornflower
fill 393 66 -182 394 66 -182 minecraft:oxeye_daisy
setblock 396 66 -182 minecraft:azure_bluet
setblock 398 66 -182 minecraft:azure_bluet
setblock 400 66 -182 minecraft:orange_tulip
fill 404 66 -182 407 66 -182 minecraft:allium
fill 408 66 -182 410 66 -182 minecraft:dandelion
setblock 415 66 -182 minecraft:cornflower
setblock 392 66 -181 minecraft:oxeye_daisy
fill 394 66 -181 395 66 -181 minecraft:oxeye_daisy
fill 396 66 -181 397 66 -181 minecraft:azure_bluet
fill 401 66 -181 403 66 -181 minecraft:orange_tulip
fill 404 66 -181 405 66 -181 minecraft:allium
fill 408 66 -181 411 66 -181 minecraft:dandelion
fill 414 66 -181 415 66 -181 minecraft:cornflower
fill 393 66 -180 395 66 -180 minecraft:oxeye_daisy
setblock 396 66 -180 minecraft:azure_bluet
fill 398 66 -180 399 66 -180 minecraft:azure_bluet
setblock 401 66 -180 minecraft:orange_tulip
fill 404 66 -180 406 66 -180 minecraft:allium
setblock 410 66 -180 minecraft:dandelion
setblock 412 66 -180 minecraft:cornflower
fill 414 66 -180 415 66 -180 minecraft:cornflower
fill 392 66 -179 393 66 -179 minecraft:oxeye_daisy
setblock 395 66 -179 minecraft:oxeye_daisy
setblock 396 66 -179 minecraft:azure_bluet
setblock 399 66 -179 minecraft:azure_bluet
setblock 400 66 -179 minecraft:orange_tulip
setblock 405 66 -179 minecraft:allium
fill 410 66 -179 411 66 -179 minecraft:dandelion
fill 413 66 -179 414 66 -179 minecraft:cornflower
setblock 394 66 -178 minecraft:oxeye_daisy
fill 396 66 -178 398 66 -178 minecraft:azure_bluet
setblock 403 66 -178 minecraft:orange_tulip
fill 404 66 -178 406 66 -178 minecraft:allium
setblock 408 66 -178 minecraft:dandelion
fill 410 66 -178 411 66 -178 minecraft:dandelion
fill 412 66 -178 414 66 -178 minecraft:cornflower
fill 392 66 -177 393 66 -177 minecraft:oxeye_daisy
fill 397 66 -177 398 66 -177 minecraft:azure_bluet
setblock 402 66 -177 minecraft:orange_tulip
setblock 407 66 -177 minecraft:allium
fill 412 66 -177 413 66 -177 minecraft:cornflower
setblock 415 66 -177 minecraft:cornflower
setblock 394 66 -176 minecraft:oxeye_daisy
fill 396 66 -176 399 66 -176 minecraft:azure_bluet
setblock 400 66 -176 minecraft:orange_tulip
setblock 407 66 -176 minecraft:allium
fill 412 66 -176 413 66 -176 minecraft:cornflower
setblock 392 66 -175 minecraft:oxeye_daisy
setblock 394 66 -175 minecraft:oxeye_daisy
fill 396 66 -175 397 66 -175 minecraft:azure_bluet
setblock 399 66 -175 minecraft:azure_bluet
setblock 400 66 -175 minecraft:orange_tulip
fill 405 66 -175 406 66 -175 minecraft:allium
setblock 408 66 -175 minecraft:dandelion
setblock 411 66 -175 minecraft:dandelion
setblock 412 66 -175 minecraft:cornflower
fill 393 66 -174 394 66 -174 minecraft:oxeye_daisy
setblock 396 66 -174 minecraft:azure_bluet
setblock 398 66 -174 minecraft:azure_bluet
setblock 401 66 -174 minecraft:orange_tulip
setblock 403 66 -174 minecraft:orange_tulip
setblock 406 66 -174 minecraft:allium
fill 408 66 -174 411 66 -174 minecraft:dandelion
setblock 412 66 -174 minecraft:cornflower
fill 414 66 -174 415 66 -174 minecraft:cornflower
fill 392 66 -173 395 66 -173 minecraft:oxeye_daisy
setblock 396 66 -173 minecraft:azure_bluet
fill 398 66 -173 399 66 -173 minecraft:azure_bluet
fill 401 66 -173 402 66 -173 minecraft:orange_tulip
fill 404 66 -173 407 66 -173 minecraft:allium
setblock 408 66 -173 minecraft:dandelion
fill 414 66 -173 415 66 -173 minecraft:cornflower
fill 392 66 -172 393 66 -172 minecraft:oxeye_daisy
setblock 395 66 -172 minecraft:oxeye_daisy
fill 396 66 -172 399 66 -172 minecraft:azure_bluet
fill 401 66 -172 402 66 -172 minecraft:orange_tulip
setblock 404 66 -172 minecraft:allium
fill 408 66 -172 409 66 -172 minecraft:dandelion
setblock 411 66 -172 minecraft:dandelion
setblock 412 66 -172 minecraft:cornflower
setblock 395 66 -171 minecraft:oxeye_daisy
fill 398 66 -171 399 66 -171 minecraft:azure_bluet
fill 401 66 -171 402 66 -171 minecraft:orange_tulip
setblock 407 66 -171 minecraft:allium
setblock 411 66 -171 minecraft:dandelion
fill 412 66 -171 415 66 -171 minecraft:cornflower
setblock 392 66 -170 minecraft:oxeye_daisy
setblock 394 66 -170 minecraft:oxeye_daisy
setblock 397 66 -170 minecraft:azure_bluet
fill 400 66 -170 402 66 -170 minecraft:orange_tulip
fill 404 66 -170 407 66 -170 minecraft:allium
setblock 409 66 -170 minecraft:dandelion
fill 414 66 -170 415 66 -170 minecraft:cornflower
fill 394 66 -169 395 66 -169 minecraft:oxeye_daisy
fill 396 66 -169 399 66 -169 minecraft:azure_bluet
fill 400 66 -169 402 66 -169 minecraft:orange_tulip
setblock 404 66 -169 minecraft:allium
fill 406 66 -169 407 66 -169 minecraft:allium
fill 410 66 -169 411 66 -169 minecraft:dandelion
setblock 412 66 -169 minecraft:cornflower
fill 414 66 -169 415 66 -169 minecraft:cornflower
setblock 392 66 -168 minecraft:oxeye_daisy
setblock 395 66 -168 minecraft:oxeye_daisy
fill 396 66 -168 398 66 -168 minecraft:azure_bluet
fill 401 66 -168 403 66 -168 minecraft:orange_tulip
fill 404 66 -168 405 66 -168 minecraft:allium
fill 409 66 -168 411 66 -168 minecraft:dandelion
fill 412 66 -168 413 66 -168 minecraft:cornflower
setblock 415 66 -168 minecraft:cornflower
setblock 395 66 -167 minecraft:oxeye_daisy
fill 396 66 -167 398 66 -167 minecraft:azure_bluet
fill 400 66 -167 402 66 -167 minecraft:orange_tulip
setblock 408 66 -167 minecraft:dandelion
setblock 410 66 -167 minecraft:dandelion
fill 412 66 -167 415 66 -167 minecraft:cornflower
setblock 392 66 -166 minecraft:oxeye_daisy
setblock 395 66 -166 minecraft:oxeye_daisy
setblock 396 66 -166 minecraft:azure_bluet
fill 401 66 -166 403 66 -166 minecraft:orange_tulip
fill 404 66 -166 407 66 -166 minecraft:allium
fill 409 66 -166 410 66 -166 minecraft:dandelion
fill 412 66 -166 413 66 -166 minecraft:cornflower
fill 394 66 -165 395 66 -165 minecraft:oxeye_daisy
fill 397 66 -165 398 66 -165 minecraft:azure_bluet
fill 400 66 -165 401 66 -165 minecraft:orange_tulip
setblock 403 66 -165 minecraft:orange_tulip
fill 405 66 -165 406 66 -165 minecraft:allium
fill 408 66 -165 411 66 -165 minecraft:dandelion
setblock 413 66 -165 minecraft:cornflower
setblock 415 66 -165 minecraft:cornflower
fill 393 66 -164 394 66 -164 minecraft:oxeye_daisy
setblock 396 66 -164 minecraft:azure_bluet
fill 398 66 -164 399 66 -164 minecraft:azure_bluet
setblock 400 66 -164 minecraft:orange_tulip
setblock 402 66 -164 minecraft:orange_tulip
fill 404 66 -164 406 66 -164 minecraft:allium
fill 408 66 -164 410 66 -164 minecraft:dandelion
fill 412 66 -164 413 66 -164 minecraft:cornflower
setblock 415 66 -164 minecraft:cornflower
fill 392 66 -163 393 66 -163 minecraft:oxeye_daisy
setblock 395 66 -163 minecraft:oxeye_daisy
setblock 398 66 -163 minecraft:azure_bluet
setblock 401 66 -163 minecraft:orange_tulip
setblock 403 66 -163 minecraft:orange_tulip
fill 404 66 -163 406 66 -163 minecraft:allium
fill 408 66 -163 409 66 -163 minecraft:dandelion
setblock 411 66 -163 minecraft:dandelion
fill 413 66 -163 415 66 -163 minecraft:cornflower
fill 392 66 -162 395 66 -162 minecraft:oxeye_daisy
fill 400 66 -162 403 66 -162 minecraft:orange_tulip
setblock 404 66 -162 minecraft:allium
setblock 406 66 -162 minecraft:allium
fill 409 66 -162 410 66 -162 minecraft:dandelion
fill 412 66 -162 415 66 -162 minecraft:cornflower
setblock 392 66 -161 minecraft:oxeye_daisy
setblock 395 66 -161 minecraft:oxeye_daisy
fill 396 66 -161 397 66 -161 minecraft:azure_bluet
fill 402 66 -161 403 66 -161 minecraft:orange_tulip
setblock 406 66 -161 minecraft:allium
fill 408 66 -161 411 66 -161 minecraft:dandelion
setblock 415 66 -161 minecraft:cornflower
fill 394 66 -160 395 66 -160 minecraft:oxeye_daisy
fill 396 66 -160 397 66 -160 minecraft:azure_bluet
fill 402 66 -160 403 66 -160 minecraft:orange_tulip
fill 404 66 -160 405 66 -160 minecraft:allium
setblock 411 66 -160 minecraft:dandelion
setblock 412 66 -160 minecraft:cornflower
fill 414 66 -160 415 66 -160 minecraft:cornflower
fill 396 66 -159 397 66 -159 minecraft:azure_bluet
setblock 400 66 -159 minecraft:orange_tulip
setblock 402 66 -159 minecraft:orange_tulip
fill 404 66 -159 406 66 -159 minecraft:allium
fill 410 66 -159 411 66 -159 minecraft:dandelion
fill 412 66 -159 415 66 -159 minecraft:cornflower
setblock 392 66 -158 minecraft:oxeye_daisy
setblock 394 66 -158 minecraft:oxeye_daisy
setblock 396 66 -158 minecraft:azure_bluet
setblock 402 66 -158 minecraft:orange_tulip
fill 404 66 -158 405 66 -158 minecraft:allium
fill 409 66 -158 411 66 -158 minecraft:dandelion
setblock 413 66 -158 minecraft:cornflower
setblock 415 66 -158 minecraft:cornflower
fill 392 66 -157 395 66 -157 minecraft:oxeye_daisy
setblock 396 66 -157 minecraft:azure_bluet
setblock 399 66 -157 minecraft:azure_bluet
setblock 403 66 -157 minecraft:orange_tulip
fill 404 66 -157 405 66 -157 minecraft:allium
setblock 407 66 -157 minecraft:allium
fill 414 66 -157 415 66 -157 minecraft:cornflower
setblock 392 66 -156 minecraft:oxeye_daisy
setblock 394 66 -156 minecraft:oxeye_daisy
fill 396 66 -156 397 66 -156 minecraft:azure_bluet
fill 400 66 -156 401 66 -156 minecraft:orange_tulip
setblock 405 66 -156 minecraft:allium
setblock 408 66 -156 minecraft:dandelion
fill 410 66 -156 411 66 -156 minecraft:dandelion
fill 412 66 -156 414 66 -156 minecraft:cornflower
fill 392 66 -155 393 66 -155 minecraft:oxeye_daisy
setblock 399 66 -155 minecraft:azure_bluet
setblock 402 66 -155 minecraft:orange_tulip
setblock 405 66 -155 minecraft:allium
fill 410 66 -155 411 66 -155 minecraft:dandelion
setblock 412 66 -155 minecraft:cornflower
setblock 414 66 -155 minecraft:cornflower
setblock 392 66 -154 minecraft:oxeye_daisy
setblock 394 66 -154 minecraft:oxeye_daisy
setblock 396 66 -154 minecraft:azure_bluet
setblock 400 66 -154 minecraft:orange_tulip
setblock 403 66 -154 minecraft:orange_tulip
fill 404 66 -154 407 66 -154 minecraft:allium
fill 408 66 -154 411 66 -154 minecraft:dandelion
setblock 412 66 -154 minecraft:cornflower
fill 414 66 -154 415 66 -154 minecraft:cornflower
setblock 392 66 -153 minecraft:oxeye_daisy
setblock 395 66 -153 minecraft:oxeye_daisy
fill 396 66 -153 397 66 -153 minecraft:azure_bluet
setblock 399 66 -153 minecraft:azure_bluet
fill 401 66 -153 403 66 -153 minecraft:orange_tulip
fill 404 66 -153 405 66 -153 minecraft:allium
setblock 407 66 -153 minecraft:allium
fill 412 66 -153 414 66 -153 minecraft:cornflower
setblock 392 66 -152 minecraft:oxeye_daisy
setblock 395 66 -152 minecraft:oxeye_daisy
setblock 396 66 -152 minecraft:azure_bluet
setblock 399 66 -152 minecraft:azure_bluet
fill 406 66 -152 407 66 -152 minecraft:allium
fill 409 66 -152 411 66 -152 minecraft:dandelion
setblock 413 66 -152 minecraft:cornflower
setblock 415 66 -152 minecraft:cornflower
setblock 395 66 -151 minecraft:oxeye_daisy
fill 397 66 -151 398 66 -151 minecraft:azure_bluet
setblock 400 66 -151 minecraft:orange_tulip
setblock 402 66 -151 minecraft:orange_tulip
setblock 406 66 -151 minecraft:allium
fill 409 66 -151 411 66 -151 minecraft:dandelion
setblock 413 66 -151 minecraft:cornflower
fill 396 66 -150 398 66 -150 minecraft:azure_bluet
setblock 405 66 -150 minecraft:allium
setblock 408 66 -150 minecraft:dandelion
fill 412 66 -150 413 66 -150 minecraft:cornflower
setblock 393 66 -149 minecraft:oxeye_daisy
setblock 395 66 -149 minecraft:oxeye_daisy
setblock 397 66 -149 minecraft:azure_bluet
setblock 401 66 -149 minecraft:orange_tulip
setblock 403 66 -149 minecraft:orange_tulip
setblock 405 66 -149 minecraft:allium
setblock 408 66 -149 minecraft:dandelion
setblock 392 66 -148 minecraft:oxeye_daisy
setblock 396 66 -148 minecraft:azure_bluet
setblock 399 66 -148 minecraft:azure_bluet
setblock 401 66 -148 minecraft:orange_tulip
setblock 403 66 -148 minecraft:orange_tulip
fill 405 66 -148 406 66 -148 minecraft:allium
fill 408 66 -148 409 66 -148 minecraft:dandelion
setblock 411 66 -148 minecraft:dandelion
fill 412 66 -148 414 66 -148 minecraft:cornflower
fill 392 66 -147 395 66 -147 minecraft:oxeye_daisy
setblock 396 66 -147 minecraft:azure_bluet
setblock 401 66 -147 minecraft:orange_tulip
setblock 403 66 -147 minecraft:orange_tulip
fill 404 66 -147 405 66 -147 minecraft:allium
setblock 408 66 -147 minecraft:dandelion
setblock 410 66 -147 minecraft:dandelion
fill 412 66 -147 414 66 -147 minecraft:cornflower
fill 392 66 -146 394 66 -146 minecraft:oxeye_daisy
fill 396 66 -146 398 66 -146 minecraft:azure_bluet
setblock 400 66 -146 minecraft:orange_tulip
setblock 402 66 -146 minecraft:orange_tulip
fill 405 66 -146 406 66 -146 minecraft:allium
setblock 409 66 -146 minecraft:dandelion
fill 412 66 -146 413 66 -146 minecraft:cornflower
setblock 393 66 -145 minecraft:oxeye_daisy
setblock 395 66 -145 minecraft:oxeye_daisy
setblock 399 66 -145 minecraft:azure_bluet
setblock 401 66 -145 minecraft:orange_tulip
setblock 405 66 -145 minecraft:allium
setblock 407 66 -145 minecraft:allium
fill 409 66 -145 410 66 -145 minecraft:dandelion
fill 412 66 -145 414 66 -145 minecraft:cornflower
setblock 394 66 -144 minecraft:oxeye_daisy
fill 396 66 -144 399 66 -144 minecraft:azure_bluet
setblock 400 66 -144 minecraft:orange_tulip
setblock 402 66 -144 minecraft:orange_tulip
setblock 405 66 -144 minecraft:allium
setblock 407 66 -144 minecraft:allium
setblock 408 66 -144 minecraft:dandelion
setblock 410 66 -144 minecraft:dandelion
setblock 412 66 -144 minecraft:cornflower
setblock 395 66 -143 minecraft:oxeye_daisy
fill 396 66 -143 399 66 -143 minecraft:azure_bluet
fill 400 66 -143 402 66 -143 minecraft:orange_tulip
setblock 405 66 -143 minecraft:allium
setblock 407 66 -143 minecraft:allium
setblock 413 66 -143 minecraft:cornflower
fill 393 66 -142 395 66 -142 minecraft:oxeye_daisy
fill 396 66 -142 397 66 -142 minecraft:azure_bluet
setblock 399 66 -142 minecraft:azure_bluet
fill 400 66 -142 403 66 -142 minecraft:orange_tulip
setblock 407 66 -142 minecraft:allium
setblock 410 66 -142 minecraft:dandelion
setblock 412 66 -142 minecraft:cornflower
setblock 395 66 -141 minecraft:oxeye_daisy
fill 400 66 -141 401 66 -141 minecraft:orange_tulip
fill 404 66 -141 405 66 -141 minecraft:allium
setblock 410 66 -141 minecraft:dandelion
setblock 392 66 -140 minecraft:oxeye_daisy
setblock 395 66 -140 minecraft:oxeye_daisy
fill 398 66 -140 399 66 -140 minecraft:azure_bluet
setblock 400 66 -140 minecraft:orange_tulip
fill 402 66 -140 403 66 -140 minecraft:orange_tulip
fill 404 66 -140 407 66 -140 minecraft:allium
fill 409 66 -140 411 66 -140 minecraft:dandelion
setblock 393 66 -139 minecraft:oxeye_daisy
setblock 395 66 -139 minecraft:oxeye_daisy
setblock 396 66 -139 minecraft:azure_bluet
setblock 399 66 -139 minecraft:azure_bluet
setblock 403 66 -139 minecraft:orange_tulip
fill 405 66 -139 407 66 -139 minecraft:allium
fill 409 66 -139 410 66 -139 minecraft:dandelion
setblock 394 66 -138 minecraft:oxeye_daisy
fill 396 66 -138 397 66 -138 minecraft:azure_bluet
setblock 400 66 -138 minecraft:orange_tulip
fill 402 66 -138 403 66 -138 minecraft:orange_tulip
setblock 404 66 -138 minecraft:allium
fill 406 66 -138 407 66 -138 minecraft:allium
setblock 408 66 -138 minecraft:dandelion
fill 410 66 -138 411 66 -138 minecraft:dandelion
setblock 392 66 -137 minecraft:oxeye_daisy
fill 394 66 -137 395 66 -137 minecraft:oxeye_daisy
fill 396 66 -137 397 66 -137 minecraft:azure_bluet
setblock 399 66 -137 minecraft:azure_bluet
setblock 402 66 -137 minecraft:orange_tulip
setblock 406 66 -137 minecraft:allium
setblock 408 66 -137 minecraft:dandelion
fill 392 66 -136 394 66 -136 minecraft:oxeye_daisy
fill 397 66 -136 398 66 -136 minecraft:azure_bluet
fill 401 66 -136 403 66 -136 minecraft:orange_tulip
setblock 404 66 -136 minecraft:allium
setblock 407 66 -136 minecraft:allium
fill 409 66 -136 410 66 -136 minecraft:dandelion
setblock 393 66 -135 minecraft:oxeye_daisy
setblock 395 66 -135 minecraft:oxeye_daisy
fill 398 66 -135 399 66 -135 minecraft:azure_bluet
setblock 400 66 -135 minecraft:orange_tulip
fill 406 66 -135 407 66 -135 minecraft:allium
setblock 409 66 -135 minecraft:dandelion
fill 393 66 -134 394 66 -134 minecraft:oxeye_daisy
fill 397 66 -134 398 66 -134 minecraft:azure_bluet
fill 400 66 -134 401 66 -134 minecraft:orange_tulip
setblock 403 66 -134 minecraft:orange_tulip
setblock 393 66 -133 minecraft:oxeye_daisy
setblock 395 66 -133 minecraft:oxeye_daisy
fill 397 66 -133 399 66 -133 minecraft:azure_bluet
fill 400 66 -133 402 66 -133 minecraft:orange_tulip
fill 405 66 -133 407 66 -133 minecraft:allium
fill 392 66 -132 395 66 -132 minecraft:oxeye_daisy
setblock 396 66 -132 minecraft:azure_bluet
setblock 399 66 -132 minecraft:azure_bluet
setblock 400 66 -132 minecraft:orange_tulip
setblock 402 66 -132 minecraft:orange_tulip
setblock 404 66 -132 minecraft:allium
setblock 407 66 -132 minecraft:allium
setblock 392 66 -131 minecraft:oxeye_daisy
fill 394 66 -131 395 66 -131 minecraft:oxeye_daisy
setblock 397 66 -131 minecraft:azure_bluet
setblock 399 66 -131 minecraft:azure_bluet
fill 400 66 -131 403 66 -131 minecraft:orange_tulip
fill 405 66 -131 406 66 -131 minecraft:allium
fill 392 66 -130 395 66 -130 minecraft:oxeye_daisy
setblock 396 66 -130 minecraft:azure_bluet
setblock 398 66 -130 minecraft:azure_bluet
setblock 400 66 -130 minecraft:orange_tulip
setblock 404 66 -130 minecraft:allium
setblock 392 66 -129 minecraft:oxeye_daisy
setblock 395 66 -129 minecraft:oxeye_daisy
setblock 400 66 -129 minecraft:orange_tulip
setblock 393 66 -128 minecraft:oxeye_daisy
setblock 395 66 -128 minecraft:oxeye_daisy
fill 396 66 -128 399 66 -128 minecraft:azure_bluet
setblock 402 66 -128 minecraft:orange_tulip
setblock 393 66 -127 minecraft:oxeye_daisy
setblock 395 66 -127 minecraft:oxeye_daisy
setblock 396 66 -127 minecraft:azure_bluet
fill 398 66 -127 399 66 -127 minecraft:azure_bluet
setblock 400 66 -127 minecraft:orange_tulip
forceload remove 392 -190 455 -127
tellraw @a {"text":"Campus bau a35 fertig.","color":"green"}
