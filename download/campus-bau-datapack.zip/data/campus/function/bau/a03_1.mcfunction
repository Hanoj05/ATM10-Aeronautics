fill 180 45 -441 181 45 -441 minecraft:stone
fill 180 45 -440 181 45 -440 minecraft:stone
setblock 181 45 -439 minecraft:stone
setblock 199 45 -436 minecraft:stone
setblock 199 45 -435 minecraft:stone
setblock 199 45 -434 minecraft:stone
setblock 199 45 -433 minecraft:stone
fill 183 45 -432 184 45 -432 minecraft:stone
fill 198 45 -432 199 45 -432 minecraft:stone
fill 180 45 -431 186 45 -431 minecraft:stone
fill 198 45 -431 199 45 -431 minecraft:stone
fill 176 45 -430 186 45 -430 minecraft:stone
fill 198 45 -430 199 45 -430 minecraft:stone
fill 172 45 -429 185 45 -429 minecraft:stone
setblock 199 45 -429 minecraft:stone
fill 171 45 -428 183 45 -428 minecraft:stone
fill 172 45 -427 182 45 -427 minecraft:stone
fill 173 45 -426 180 45 -426 minecraft:stone
fill 196 45 -426 197 45 -426 minecraft:stone
fill 196 45 -425 198 45 -425 minecraft:stone
fill 195 45 -424 198 45 -424 minecraft:stone
fill 195 45 -423 198 45 -423 minecraft:stone
fill 195 45 -422 199 45 -422 minecraft:stone
fill 195 45 -421 199 45 -421 minecraft:stone
fill 189 45 -420 192 45 -420 minecraft:stone
fill 195 45 -420 199 45 -420 minecraft:stone
fill 188 45 -419 199 45 -419 minecraft:stone
fill 188 45 -418 199 45 -418 minecraft:stone
fill 188 45 -417 199 45 -417 minecraft:stone
fill 188 45 -416 199 45 -416 minecraft:stone
fill 188 45 -415 199 45 -415 minecraft:stone
fill 188 45 -414 198 45 -414 minecraft:stone
fill 188 45 -413 198 45 -413 minecraft:stone
fill 189 45 -412 198 45 -412 minecraft:stone
fill 189 45 -411 197 45 -411 minecraft:stone
fill 190 45 -410 197 45 -410 minecraft:stone
fill 191 45 -409 197 45 -409 minecraft:stone
fill 189 45 -408 196 45 -408 minecraft:stone
fill 180 45 -407 196 45 -407 minecraft:stone
fill 180 45 -406 195 45 -406 minecraft:stone
fill 180 45 -405 195 45 -405 minecraft:stone
fill 181 45 -404 194 45 -404 minecraft:stone
fill 139 45 -403 149 45 -403 minecraft:stone
fill 183 45 -403 192 45 -403 minecraft:stone
fill 137 45 -402 145 45 -402 minecraft:stone
fill 149 45 -402 151 45 -402 minecraft:stone
fill 184 45 -402 190 45 -402 minecraft:stone
setblock 159 45 -396 minecraft:stone
setblock 160 45 -395 minecraft:stone
fill 160 45 -394 162 45 -394 minecraft:stone
fill 160 45 -393 163 45 -393 minecraft:stone
fill 161 45 -392 163 45 -392 minecraft:stone
fill 161 45 -391 163 45 -391 minecraft:stone
fill 162 45 -390 163 45 -390 minecraft:stone
setblock 163 45 -389 minecraft:stone
fill 170 46 -430 175 46 -430 minecraft:stone
fill 179 46 -430 182 46 -430 minecraft:stone
fill 170 46 -429 182 46 -429 minecraft:stone
fill 170 46 -428 182 46 -428 minecraft:stone
fill 170 46 -427 180 46 -427 minecraft:stone
fill 172 46 -426 178 46 -426 minecraft:stone
fill 196 46 -423 197 46 -423 minecraft:stone
fill 196 46 -422 198 46 -422 minecraft:stone
fill 195 46 -421 198 46 -421 minecraft:stone
fill 195 46 -420 199 46 -420 minecraft:stone
fill 190 46 -419 192 46 -419 minecraft:stone
fill 195 46 -419 199 46 -419 minecraft:stone
fill 189 46 -418 199 46 -418 minecraft:stone
fill 188 46 -417 199 46 -417 minecraft:stone
fill 188 46 -416 199 46 -416 minecraft:stone
fill 172 46 -415 173 46 -415 minecraft:stone
fill 188 46 -415 199 46 -415 minecraft:stone
fill 171 46 -414 174 46 -414 minecraft:stone
fill 188 46 -414 198 46 -414 minecraft:stone
fill 171 46 -413 175 46 -413 minecraft:stone
fill 188 46 -413 198 46 -413 minecraft:stone
fill 172 46 -412 176 46 -412 minecraft:stone
fill 189 46 -412 198 46 -412 minecraft:stone
fill 172 46 -411 178 46 -411 minecraft:stone
fill 189 46 -411 197 46 -411 minecraft:stone
fill 173 46 -410 179 46 -410 minecraft:stone
fill 190 46 -410 197 46 -410 minecraft:stone
fill 174 46 -409 181 46 -409 minecraft:stone
fill 190 46 -409 197 46 -409 minecraft:stone
fill 175 46 -408 184 46 -408 minecraft:stone
fill 188 46 -408 196 46 -408 minecraft:stone
fill 176 46 -407 196 46 -407 minecraft:stone
fill 176 46 -406 195 46 -406 minecraft:stone
fill 178 46 -405 195 46 -405 minecraft:stone
setblock 144 46 -404 minecraft:stone
fill 179 46 -404 194 46 -404 minecraft:stone
fill 139 46 -403 149 46 -403 minecraft:stone
fill 181 46 -403 192 46 -403 minecraft:stone
fill 151 46 -402 152 46 -402 minecraft:stone
fill 183 46 -402 191 46 -402 minecraft:stone
setblock 157 46 -398 minecraft:stone
setblock 158 46 -397 minecraft:stone
fill 159 46 -396 160 46 -396 minecraft:stone
fill 159 46 -395 161 46 -395 minecraft:stone
fill 159 46 -394 162 46 -394 minecraft:stone
fill 159 46 -393 163 46 -393 minecraft:stone
fill 161 46 -392 163 46 -392 minecraft:stone
setblock 162 46 -391 minecraft:stone
fill 176 47 -440 177 47 -440 minecraft:stone
fill 176 47 -439 177 47 -439 minecraft:stone
fill 177 47 -438 178 47 -438 minecraft:stone
fill 169 47 -432 171 47 -432 minecraft:stone
fill 169 47 -431 172 47 -431 minecraft:stone
fill 169 47 -430 174 47 -430 minecraft:stone
fill 169 47 -429 176 47 -429 minecraft:stone
fill 169 47 -428 177 47 -428 minecraft:stone
fill 170 47 -427 177 47 -427 minecraft:stone
fill 172 47 -426 176 47 -426 minecraft:stone
setblock 197 47 -418 minecraft:stone
fill 168 47 -417 172 47 -417 minecraft:stone
fill 190 47 -417 194 47 -417 minecraft:stone
fill 196 47 -417 198 47 -417 minecraft:stone
fill 168 47 -416 173 47 -416 minecraft:stone
fill 189 47 -416 198 47 -416 minecraft:stone
fill 169 47 -415 174 47 -415 minecraft:stone
fill 189 47 -415 198 47 -415 minecraft:stone
fill 169 47 -414 176 47 -414 minecraft:stone
fill 189 47 -414 198 47 -414 minecraft:stone
fill 170 47 -413 177 47 -413 minecraft:stone
fill 189 47 -413 197 47 -413 minecraft:stone
fill 170 47 -412 178 47 -412 minecraft:stone
fill 189 47 -412 197 47 -412 minecraft:stone
fill 171 47 -411 179 47 -411 minecraft:stone
fill 190 47 -411 196 47 -411 minecraft:stone
fill 172 47 -410 180 47 -410 minecraft:stone
fill 191 47 -410 197 47 -410 minecraft:stone
fill 173 47 -409 182 47 -409 minecraft:stone
fill 191 47 -409 196 47 -409 minecraft:stone
fill 174 47 -408 185 47 -408 minecraft:stone
fill 189 47 -408 196 47 -408 minecraft:stone
fill 174 47 -407 195 47 -407 minecraft:stone
fill 176 47 -406 195 47 -406 minecraft:stone
fill 177 47 -405 194 47 -405 minecraft:stone
fill 143 47 -404 146 47 -404 minecraft:stone
fill 178 47 -404 193 47 -404 minecraft:stone
fill 149 47 -403 150 47 -403 minecraft:stone
fill 180 47 -403 192 47 -403 minecraft:stone
setblock 152 47 -402 minecraft:stone
fill 183 47 -402 190 47 -402 minecraft:stone
setblock 155 47 -400 minecraft:stone
setblock 156 47 -399 minecraft:stone
setblock 157 47 -398 minecraft:stone
fill 158 47 -397 159 47 -397 minecraft:stone
fill 158 47 -396 160 47 -396 minecraft:stone
fill 158 47 -395 161 47 -395 minecraft:stone
fill 159 47 -394 162 47 -394 minecraft:stone
fill 160 47 -393 162 47 -393 minecraft:stone
fill 161 47 -392 162 47 -392 minecraft:stone
setblock 162 47 -391 minecraft:stone
fill 176 48 -441 179 48 -441 minecraft:stone
fill 175 48 -440 179 48 -440 minecraft:stone
fill 174 48 -439 180 48 -439 minecraft:stone
fill 175 48 -438 179 48 -438 minecraft:stone
fill 171 48 -436 172 48 -436 minecraft:stone
fill 170 48 -435 173 48 -435 minecraft:stone
fill 170 48 -434 172 48 -434 minecraft:stone
fill 169 48 -433 172 48 -433 minecraft:stone
fill 169 48 -432 172 48 -432 minecraft:stone
fill 169 48 -431 172 48 -431 minecraft:stone
fill 169 48 -430 173 48 -430 minecraft:stone
fill 169 48 -429 173 48 -429 minecraft:stone
fill 169 48 -428 174 48 -428 minecraft:stone
fill 171 48 -427 173 48 -427 minecraft:stone
fill 165 48 -421 168 48 -421 minecraft:stone
fill 165 48 -420 169 48 -420 minecraft:stone
fill 166 48 -419 170 48 -419 minecraft:stone
fill 166 48 -418 172 48 -418 minecraft:stone
fill 166 48 -417 173 48 -417 minecraft:stone
fill 167 48 -416 174 48 -416 minecraft:stone
setblock 192 48 -416 minecraft:stone
fill 167 48 -415 175 48 -415 minecraft:stone
fill 191 48 -415 194 48 -415 minecraft:stone
fill 168 48 -414 176 48 -414 minecraft:stone
fill 190 48 -414 195 48 -414 minecraft:stone
fill 169 48 -413 177 48 -413 minecraft:stone
fill 190 48 -413 195 48 -413 minecraft:stone
fill 170 48 -412 178 48 -412 minecraft:stone
fill 191 48 -412 195 48 -412 minecraft:stone
fill 171 48 -411 179 48 -411 minecraft:stone
fill 191 48 -411 194 48 -411 minecraft:stone
fill 172 48 -410 180 48 -410 minecraft:stone
setblock 194 48 -410 minecraft:stone
fill 173 48 -409 182 48 -409 minecraft:stone
setblock 193 48 -409 minecraft:stone
fill 173 48 -408 184 48 -408 minecraft:stone
fill 193 48 -408 194 48 -408 minecraft:stone
fill 174 48 -407 186 48 -407 minecraft:stone
fill 191 48 -407 193 48 -407 minecraft:stone
fill 176 48 -406 192 48 -406 minecraft:stone
setblock 144 48 -405 minecraft:stone
fill 177 48 -405 192 48 -405 minecraft:stone
setblock 148 48 -404 minecraft:stone
fill 179 48 -404 191 48 -404 minecraft:stone
fill 181 48 -403 189 48 -403 minecraft:stone
fill 184 48 -402 185 48 -402 minecraft:stone
setblock 154 48 -401 minecraft:stone
setblock 155 48 -400 minecraft:stone
setblock 156 48 -399 minecraft:stone
fill 157 48 -398 158 48 -398 minecraft:stone
fill 157 48 -397 159 48 -397 minecraft:stone
fill 158 48 -396 160 48 -396 minecraft:stone
fill 158 48 -395 161 48 -395 minecraft:stone
fill 159 48 -394 161 48 -394 minecraft:stone
fill 160 48 -393 161 48 -393 minecraft:stone
setblock 161 48 -392 minecraft:stone
fill 175 49 -441 177 49 -441 minecraft:stone
fill 173 49 -440 178 49 -440 minecraft:stone
fill 173 49 -439 179 49 -439 minecraft:stone
fill 172 49 -438 178 49 -438 minecraft:stone
fill 171 49 -437 176 49 -437 minecraft:stone
fill 170 49 -436 174 49 -436 minecraft:stone
fill 170 49 -435 174 49 -435 minecraft:stone
fill 169 49 -434 173 49 -434 minecraft:stone
fill 169 49 -433 173 49 -433 minecraft:stone
fill 169 49 -432 173 49 -432 minecraft:stone
fill 169 49 -431 172 49 -431 minecraft:stone
fill 169 49 -430 172 49 -430 minecraft:stone
fill 169 49 -429 172 49 -429 minecraft:stone
setblock 171 49 -428 minecraft:stone
fill 163 49 -424 165 49 -424 minecraft:stone
fill 163 49 -423 167 49 -423 minecraft:stone
fill 163 49 -422 168 49 -422 minecraft:stone
fill 163 49 -421 169 49 -421 minecraft:stone
fill 164 49 -420 170 49 -420 minecraft:stone
fill 165 49 -419 171 49 -419 minecraft:stone
fill 165 49 -418 172 49 -418 minecraft:stone
fill 166 49 -417 173 49 -417 minecraft:stone
fill 166 49 -416 173 49 -416 minecraft:stone
fill 167 49 -415 174 49 -415 minecraft:stone
fill 168 49 -414 175 49 -414 minecraft:stone
fill 169 49 -413 176 49 -413 minecraft:stone
fill 170 49 -412 177 49 -412 minecraft:stone
setblock 138 49 -411 minecraft:stone
fill 171 49 -411 178 49 -411 minecraft:stone
fill 140 49 -410 145 49 -410 minecraft:stone
fill 172 49 -410 179 49 -410 minecraft:stone
fill 173 49 -409 180 49 -409 minecraft:stone
fill 174 49 -408 182 49 -408 minecraft:stone
fill 175 49 -407 183 49 -407 minecraft:stone
fill 143 49 -406 145 49 -406 minecraft:stone
fill 177 49 -406 184 49 -406 minecraft:stone
fill 146 49 -405 148 49 -405 minecraft:stone
fill 178 49 -405 185 49 -405 minecraft:stone
setblock 149 49 -404 minecraft:stone
fill 181 49 -404 184 49 -404 minecraft:stone
setblock 151 49 -403 minecraft:stone
setblock 153 49 -402 minecraft:stone
setblock 154 49 -401 minecraft:stone
setblock 155 49 -400 minecraft:stone
setblock 156 49 -399 minecraft:stone
fill 156 49 -398 158 49 -398 minecraft:stone
fill 157 49 -397 159 49 -397 minecraft:stone
fill 157 49 -396 160 49 -396 minecraft:stone
fill 158 49 -395 161 49 -395 minecraft:stone
fill 158 49 -394 161 49 -394 minecraft:stone
fill 160 49 -393 161 49 -393 minecraft:stone
setblock 161 49 -392 minecraft:stone
fill 173 50 -440 177 50 -440 minecraft:stone
fill 172 50 -439 177 50 -439 minecraft:stone
fill 171 50 -438 177 50 -438 minecraft:stone
fill 171 50 -437 176 50 -437 minecraft:stone
fill 170 50 -436 174 50 -436 minecraft:stone
fill 170 50 -435 174 50 -435 minecraft:stone
fill 170 50 -434 173 50 -434 minecraft:stone
fill 169 50 -433 173 50 -433 minecraft:stone
fill 170 50 -432 172 50 -432 minecraft:stone
fill 170 50 -431 171 50 -431 minecraft:stone
setblock 163 50 -427 minecraft:stone
fill 161 50 -426 165 50 -426 minecraft:stone
fill 161 50 -425 165 50 -425 minecraft:stone
fill 161 50 -424 166 50 -424 minecraft:stone
fill 161 50 -423 167 50 -423 minecraft:stone
fill 162 50 -422 168 50 -422 minecraft:stone
fill 162 50 -421 169 50 -421 minecraft:stone
fill 163 50 -420 170 50 -420 minecraft:stone
fill 164 50 -419 171 50 -419 minecraft:stone
fill 165 50 -418 171 50 -418 minecraft:stone
fill 166 50 -417 172 50 -417 minecraft:stone
fill 167 50 -416 173 50 -416 minecraft:stone
fill 167 50 -415 173 50 -415 minecraft:stone
fill 168 50 -414 174 50 -414 minecraft:stone
fill 170 50 -413 174 50 -413 minecraft:stone
fill 136 50 -412 139 50 -412 minecraft:stone
fill 171 50 -412 175 50 -412 minecraft:stone
fill 136 50 -411 145 50 -411 minecraft:stone
fill 173 50 -411 176 50 -411 minecraft:stone
fill 138 50 -410 147 50 -410 minecraft:stone
fill 174 50 -410 177 50 -410 minecraft:stone
fill 140 50 -409 146 50 -409 minecraft:stone
fill 175 50 -409 177 50 -409 minecraft:stone
fill 143 50 -408 145 50 -408 minecraft:stone
fill 142 50 -407 146 50 -407 minecraft:stone
setblock 199 50 -407 minecraft:stone
fill 145 50 -406 148 50 -406 minecraft:stone
setblock 199 50 -406 minecraft:stone
fill 148 50 -405 149 50 -405 minecraft:stone
fill 198 50 -405 199 50 -405 minecraft:stone
setblock 150 50 -404 minecraft:stone
fill 198 50 -404 199 50 -404 minecraft:stone
setblock 152 50 -403 minecraft:stone
fill 198 50 -403 199 50 -403 minecraft:stone
setblock 153 50 -402 minecraft:stone
setblock 199 50 -402 minecraft:stone
setblock 154 50 -401 minecraft:stone
setblock 155 50 -400 minecraft:stone
fill 156 50 -399 157 50 -399 minecraft:stone
fill 156 50 -398 158 50 -398 minecraft:stone
fill 157 50 -397 159 50 -397 minecraft:stone
fill 157 50 -396 160 50 -396 minecraft:stone
fill 157 50 -395 160 50 -395 minecraft:stone
fill 158 50 -394 160 50 -394 minecraft:stone
fill 159 50 -393 160 50 -393 minecraft:stone
setblock 161 50 -392 minecraft:stone
fill 174 51 -439 175 51 -439 minecraft:stone
fill 172 51 -438 175 51 -438 minecraft:stone
fill 172 51 -437 174 51 -437 minecraft:stone
fill 171 51 -436 174 51 -436 minecraft:stone
fill 171 51 -435 173 51 -435 minecraft:stone
setblock 172 51 -434 minecraft:stone
fill 163 51 -430 165 51 -430 minecraft:stone
fill 162 51 -429 165 51 -429 minecraft:stone
fill 162 51 -428 166 51 -428 minecraft:stone
fill 162 51 -427 165 51 -427 minecraft:stone
fill 161 51 -426 165 51 -426 minecraft:stone
fill 161 51 -425 165 51 -425 minecraft:stone
fill 161 51 -424 166 51 -424 minecraft:stone
fill 161 51 -423 167 51 -423 minecraft:stone
fill 162 51 -422 168 51 -422 minecraft:stone
fill 162 51 -421 169 51 -421 minecraft:stone
fill 163 51 -420 169 51 -420 minecraft:stone
fill 165 51 -419 170 51 -419 minecraft:stone
fill 166 51 -418 170 51 -418 minecraft:stone
fill 167 51 -417 171 51 -417 minecraft:stone
fill 168 51 -416 171 51 -416 minecraft:stone
fill 169 51 -415 171 51 -415 minecraft:stone
fill 136 51 -413 140 51 -413 minecraft:stone
fill 136 51 -412 144 51 -412 minecraft:stone
fill 136 51 -411 147 51 -411 minecraft:stone
fill 136 51 -410 148 51 -410 minecraft:stone
fill 138 51 -409 148 51 -409 minecraft:stone
fill 140 51 -408 148 51 -408 minecraft:stone
fill 144 51 -407 148 51 -407 minecraft:stone
fill 147 51 -406 149 51 -406 minecraft:stone
setblock 199 51 -406 minecraft:stone
fill 149 51 -405 150 51 -405 minecraft:stone
fill 198 51 -405 199 51 -405 minecraft:stone
setblock 151 51 -404 minecraft:stone
fill 198 51 -404 199 51 -404 minecraft:stone
setblock 152 51 -403 minecraft:stone
fill 198 51 -403 199 51 -403 minecraft:stone
setblock 153 51 -402 minecraft:stone
fill 198 51 -402 199 51 -402 minecraft:stone
fill 154 51 -401 155 51 -401 minecraft:stone
fill 198 51 -401 199 51 -401 minecraft:stone
fill 155 51 -400 156 51 -400 minecraft:stone
fill 189 51 -400 192 51 -400 minecraft:stone
fill 198 51 -400 199 51 -400 minecraft:stone
fill 155 51 -399 157 51 -399 minecraft:stone
fill 189 51 -399 195 51 -399 minecraft:stone
fill 198 51 -399 199 51 -399 minecraft:stone
fill 156 51 -398 158 51 -398 minecraft:stone
fill 188 51 -398 196 51 -398 minecraft:stone
fill 157 51 -397 159 51 -397 minecraft:stone
fill 189 51 -397 198 51 -397 minecraft:stone
fill 157 51 -396 160 51 -396 minecraft:stone
fill 190 51 -396 199 51 -396 minecraft:stone
fill 157 51 -395 160 51 -395 minecraft:stone
fill 191 51 -395 199 51 -395 minecraft:stone
fill 158 51 -394 160 51 -394 minecraft:stone
fill 193 51 -394 199 51 -394 minecraft:stone
fill 159 51 -393 160 51 -393 minecraft:stone
fill 195 51 -393 199 51 -393 minecraft:stone
setblock 160 51 -392 minecraft:stone
fill 196 51 -392 198 51 -392 minecraft:stone
fill 163 52 -432 164 52 -432 minecraft:stone
fill 162 52 -431 165 52 -431 minecraft:stone
fill 162 52 -430 166 52 -430 minecraft:stone
fill 162 52 -429 166 52 -429 minecraft:stone
fill 162 52 -428 166 52 -428 minecraft:stone
fill 162 52 -427 166 52 -427 minecraft:stone
fill 161 52 -426 166 52 -426 minecraft:stone
fill 161 52 -425 165 52 -425 minecraft:stone
fill 161 52 -424 165 52 -424 minecraft:stone
fill 161 52 -423 166 52 -423 minecraft:stone
fill 162 52 -422 166 52 -422 minecraft:stone
fill 163 52 -421 167 52 -421 minecraft:stone
fill 166 52 -420 167 52 -420 minecraft:stone
fill 136 52 -414 141 52 -414 minecraft:stone
fill 136 52 -413 144 52 -413 minecraft:stone
fill 136 52 -412 146 52 -412 minecraft:stone
fill 136 52 -411 148 52 -411 minecraft:stone
fill 136 52 -410 149 52 -410 minecraft:stone
fill 138 52 -409 149 52 -409 minecraft:stone
fill 143 52 -408 149 52 -408 minecraft:stone
fill 146 52 -407 150 52 -407 minecraft:stone
fill 148 52 -406 150 52 -406 minecraft:stone
fill 150 52 -405 151 52 -405 minecraft:stone
setblock 199 52 -405 minecraft:stone
fill 151 52 -404 152 52 -404 minecraft:stone
fill 198 52 -404 199 52 -404 minecraft:stone
fill 152 52 -403 153 52 -403 minecraft:stone
fill 198 52 -403 199 52 -403 minecraft:stone
fill 153 52 -402 154 52 -402 minecraft:stone
fill 189 52 -402 190 52 -402 minecraft:stone
fill 198 52 -402 199 52 -402 minecraft:stone
fill 154 52 -401 155 52 -401 minecraft:stone
fill 187 52 -401 191 52 -401 minecraft:stone
fill 197 52 -401 199 52 -401 minecraft:stone
fill 155 52 -400 156 52 -400 minecraft:stone
fill 187 52 -400 193 52 -400 minecraft:stone
fill 197 52 -400 199 52 -400 minecraft:stone
fill 155 52 -399 157 52 -399 minecraft:stone
fill 187 52 -399 196 52 -399 minecraft:stone
fill 198 52 -399 199 52 -399 minecraft:stone
fill 156 52 -398 158 52 -398 minecraft:stone
fill 187 52 -398 199 52 -398 minecraft:stone
fill 156 52 -397 159 52 -397 minecraft:stone
fill 188 52 -397 199 52 -397 minecraft:stone
fill 157 52 -396 159 52 -396 minecraft:stone
fill 189 52 -396 199 52 -396 minecraft:stone
fill 157 52 -395 159 52 -395 minecraft:stone
fill 190 52 -395 199 52 -395 minecraft:stone
fill 158 52 -394 160 52 -394 minecraft:stone
fill 192 52 -394 199 52 -394 minecraft:stone
fill 159 52 -393 160 52 -393 minecraft:stone
fill 194 52 -393 199 52 -393 minecraft:stone
setblock 160 52 -392 minecraft:stone
fill 195 52 -392 199 52 -392 minecraft:stone
fill 196 52 -391 199 52 -391 minecraft:stone
fill 161 53 -433 163 53 -433 minecraft:stone
fill 160 53 -432 165 53 -432 minecraft:stone
fill 159 53 -431 166 53 -431 minecraft:stone
fill 160 53 -430 166 53 -430 minecraft:stone
fill 185 53 -430 186 53 -430 minecraft:stone
fill 162 53 -429 166 53 -429 minecraft:stone
fill 185 53 -429 187 53 -429 minecraft:stone
fill 162 53 -428 166 53 -428 minecraft:stone
fill 185 53 -428 187 53 -428 minecraft:stone
fill 162 53 -427 166 53 -427 minecraft:stone
fill 186 53 -427 188 53 -427 minecraft:stone
fill 162 53 -426 165 53 -426 minecraft:stone
fill 185 53 -426 188 53 -426 minecraft:stone
fill 162 53 -425 164 53 -425 minecraft:stone
fill 185 53 -425 188 53 -425 minecraft:stone
fill 162 53 -424 164 53 -424 minecraft:stone
fill 186 53 -424 189 53 -424 minecraft:stone
fill 186 53 -423 188 53 -423 minecraft:stone
fill 187 53 -422 189 53 -422 minecraft:stone
setblock 188 53 -421 minecraft:stone
fill 142 53 -414 144 53 -414 minecraft:stone
fill 136 53 -413 145 53 -413 minecraft:stone
fill 136 53 -412 147 53 -412 minecraft:stone
fill 136 53 -411 148 53 -411 minecraft:stone
fill 139 53 -410 149 53 -410 minecraft:stone
fill 142 53 -409 151 53 -409 minecraft:stone
fill 145 53 -408 150 53 -408 minecraft:stone
fill 147 53 -407 151 53 -407 minecraft:stone
fill 149 53 -406 151 53 -406 minecraft:stone
fill 150 53 -405 152 53 -405 minecraft:stone
fill 151 53 -404 152 53 -404 minecraft:stone
fill 189 53 -404 190 53 -404 minecraft:stone
setblock 199 53 -404 minecraft:stone
fill 152 53 -403 153 53 -403 minecraft:stone
fill 187 53 -403 191 53 -403 minecraft:stone
setblock 199 53 -403 minecraft:stone
fill 153 53 -402 154 53 -402 minecraft:stone
fill 187 53 -402 191 53 -402 minecraft:stone
fill 198 53 -402 199 53 -402 minecraft:stone
fill 154 53 -401 155 53 -401 minecraft:stone
fill 187 53 -401 191 53 -401 minecraft:stone
fill 198 53 -401 199 53 -401 minecraft:stone
fill 155 53 -400 156 53 -400 minecraft:stone
fill 187 53 -400 193 53 -400 minecraft:stone
fill 198 53 -400 199 53 -400 minecraft:stone
fill 155 53 -399 157 53 -399 minecraft:stone
fill 187 53 -399 195 53 -399 minecraft:stone
fill 198 53 -399 199 53 -399 minecraft:stone
fill 156 53 -398 158 53 -398 minecraft:stone
fill 187 53 -398 199 53 -398 minecraft:stone
fill 156 53 -397 159 53 -397 minecraft:stone
fill 187 53 -397 199 53 -397 minecraft:stone
fill 157 53 -396 159 53 -396 minecraft:stone
fill 189 53 -396 199 53 -396 minecraft:stone
fill 157 53 -395 159 53 -395 minecraft:stone
fill 190 53 -395 199 53 -395 minecraft:stone
fill 158 53 -394 159 53 -394 minecraft:stone
fill 193 53 -394 199 53 -394 minecraft:stone
setblock 159 53 -393 minecraft:stone
fill 194 53 -393 199 53 -393 minecraft:stone
fill 195 53 -392 199 53 -392 minecraft:stone
fill 195 53 -391 199 53 -391 minecraft:stone
fill 194 53 -390 198 53 -390 minecraft:stone
fill 194 53 -389 197 53 -389 minecraft:stone
fill 195 53 -388 196 53 -388 minecraft:stone
fill 160 54 -433 164 54 -433 minecraft:stone
setblock 186 54 -433 minecraft:stone
fill 159 54 -432 165 54 -432 minecraft:stone
fill 185 54 -432 187 54 -432 minecraft:stone
fill 158 54 -431 165 54 -431 minecraft:stone
fill 184 54 -431 187 54 -431 minecraft:stone
fill 158 54 -430 166 54 -430 minecraft:stone
fill 184 54 -430 187 54 -430 minecraft:stone
fill 159 54 -429 166 54 -429 minecraft:stone
fill 184 54 -429 187 54 -429 minecraft:stone
fill 163 54 -428 165 54 -428 minecraft:stone
fill 184 54 -428 187 54 -428 minecraft:stone
fill 163 54 -427 165 54 -427 minecraft:stone
fill 185 54 -427 187 54 -427 minecraft:stone
fill 185 54 -426 188 54 -426 minecraft:stone
fill 186 54 -425 188 54 -425 minecraft:stone
fill 186 54 -424 189 54 -424 minecraft:stone
fill 186 54 -423 189 54 -423 minecraft:stone
fill 186 54 -422 189 54 -422 minecraft:stone
fill 187 54 -421 189 54 -421 minecraft:stone
fill 187 54 -420 189 54 -420 minecraft:stone
setblock 188 54 -419 minecraft:stone
setblock 172 54 -417 minecraft:stone
fill 168 54 -416 177 54 -416 minecraft:stone
fill 169 54 -415 175 54 -415 minecraft:stone
fill 144 54 -414 145 54 -414 minecraft:stone
fill 171 54 -414 173 54 -414 minecraft:stone
fill 136 54 -413 146 54 -413 minecraft:stone
setblock 172 54 -413 minecraft:stone
fill 136 54 -412 148 54 -412 minecraft:stone
fill 139 54 -411 149 54 -411 minecraft:stone
fill 142 54 -410 150 54 -410 minecraft:stone
fill 145 54 -409 151 54 -409 minecraft:stone
fill 146 54 -408 151 54 -408 minecraft:stone
fill 148 54 -407 152 54 -407 minecraft:stone
fill 149 54 -406 152 54 -406 minecraft:stone
fill 150 54 -405 152 54 -405 minecraft:stone
fill 189 54 -405 191 54 -405 minecraft:stone
fill 152 54 -404 153 54 -404 minecraft:stone
fill 187 54 -404 192 54 -404 minecraft:stone
fill 153 54 -403 154 54 -403 minecraft:stone
fill 187 54 -403 192 54 -403 minecraft:stone
fill 153 54 -402 155 54 -402 minecraft:stone
fill 186 54 -402 191 54 -402 minecraft:stone
fill 154 54 -401 155 54 -401 minecraft:stone
fill 186 54 -401 191 54 -401 minecraft:stone
fill 155 54 -400 156 54 -400 minecraft:stone
fill 187 54 -400 192 54 -400 minecraft:stone
setblock 199 54 -400 minecraft:stone
fill 155 54 -399 157 54 -399 minecraft:stone
fill 187 54 -399 193 54 -399 minecraft:stone
setblock 199 54 -399 minecraft:stone
fill 155 54 -398 158 54 -398 minecraft:stone
fill 187 54 -398 195 54 -398 minecraft:stone
fill 198 54 -398 199 54 -398 minecraft:stone
fill 156 54 -397 158 54 -397 minecraft:stone
fill 188 54 -397 199 54 -397 minecraft:stone
fill 156 54 -396 159 54 -396 minecraft:stone
fill 189 54 -396 199 54 -396 minecraft:stone
fill 157 54 -395 159 54 -395 minecraft:stone
fill 192 54 -395 199 54 -395 minecraft:stone
fill 158 54 -394 159 54 -394 minecraft:stone
fill 194 54 -394 199 54 -394 minecraft:stone
setblock 159 54 -393 minecraft:stone
fill 195 54 -393 199 54 -393 minecraft:stone
fill 195 54 -392 199 54 -392 minecraft:stone
fill 194 54 -391 198 54 -391 minecraft:stone
fill 194 54 -390 198 54 -390 minecraft:stone
fill 194 54 -389 197 54 -389 minecraft:stone
fill 194 54 -388 197 54 -388 minecraft:stone
fill 159 55 -433 163 55 -433 minecraft:stone
fill 185 55 -433 187 55 -433 minecraft:stone
fill 158 55 -432 164 55 -432 minecraft:stone
fill 184 55 -432 187 55 -432 minecraft:stone
fill 158 55 -431 164 55 -431 minecraft:stone
fill 184 55 -431 187 55 -431 minecraft:stone
fill 157 55 -430 164 55 -430 minecraft:stone
fill 184 55 -430 187 55 -430 minecraft:stone
fill 157 55 -429 161 55 -429 minecraft:stone
fill 185 55 -429 187 55 -429 minecraft:stone
fill 185 55 -428 187 55 -428 minecraft:stone
setblock 199 55 -428 minecraft:stone
setblock 199 55 -427 minecraft:stone
fill 198 55 -426 199 55 -426 minecraft:stone
fill 167 55 -425 168 55 -425 minecraft:stone
fill 196 55 -425 199 55 -425 minecraft:stone
fill 163 55 -424 170 55 -424 minecraft:stone
fill 194 55 -424 199 55 -424 minecraft:stone
fill 164 55 -423 171 55 -423 minecraft:stone
fill 187 55 -423 188 55 -423 minecraft:stone
fill 192 55 -423 199 55 -423 minecraft:stone
fill 165 55 -422 172 55 -422 minecraft:stone
fill 187 55 -422 189 55 -422 minecraft:stone
fill 192 55 -422 199 55 -422 minecraft:stone
fill 165 55 -421 173 55 -421 minecraft:stone
fill 184 55 -421 189 55 -421 minecraft:stone
fill 191 55 -421 199 55 -421 minecraft:stone
fill 166 55 -420 173 55 -420 minecraft:stone
fill 182 55 -420 199 55 -420 minecraft:stone
fill 165 55 -419 175 55 -419 minecraft:stone
fill 180 55 -419 199 55 -419 minecraft:stone
fill 163 55 -418 189 55 -418 minecraft:stone
fill 191 55 -418 199 55 -418 minecraft:stone
fill 162 55 -417 189 55 -417 minecraft:stone
fill 191 55 -417 199 55 -417 minecraft:stone
fill 162 55 -416 189 55 -416 minecraft:stone
fill 191 55 -416 199 55 -416 minecraft:stone
fill 162 55 -415 189 55 -415 minecraft:stone
fill 192 55 -415 199 55 -415 minecraft:stone
setblock 146 55 -414 minecraft:stone
fill 161 55 -414 188 55 -414 minecraft:stone
fill 192 55 -414 199 55 -414 minecraft:stone
fill 144 55 -413 147 55 -413 minecraft:stone
fill 161 55 -413 187 55 -413 minecraft:stone
fill 194 55 -413 199 55 -413 minecraft:stone
fill 139 55 -412 148 55 -412 minecraft:stone
fill 160 55 -412 179 55 -412 minecraft:stone
fill 181 55 -412 185 55 -412 minecraft:stone
setblock 196 55 -412 minecraft:stone
fill 142 55 -411 149 55 -411 minecraft:stone
fill 160 55 -411 178 55 -411 minecraft:stone
setblock 184 55 -411 minecraft:stone
fill 144 55 -410 150 55 -410 minecraft:stone
fill 160 55 -410 161 55 -410 minecraft:stone
fill 166 55 -410 176 55 -410 minecraft:stone
fill 146 55 -409 151 55 -409 minecraft:stone
fill 160 55 -409 161 55 -409 minecraft:stone
fill 147 55 -408 152 55 -408 minecraft:stone
fill 160 55 -408 161 55 -408 minecraft:stone
fill 149 55 -407 153 55 -407 minecraft:stone
setblock 160 55 -407 minecraft:stone
fill 192 55 -407 193 55 -407 minecraft:stone
fill 150 55 -406 153 55 -406 minecraft:stone
fill 189 55 -406 194 55 -406 minecraft:stone
fill 151 55 -405 153 55 -405 minecraft:stone
fill 188 55 -405 194 55 -405 minecraft:stone
fill 152 55 -404 153 55 -404 minecraft:stone
fill 187 55 -404 194 55 -404 minecraft:stone
fill 153 55 -403 154 55 -403 minecraft:stone
fill 187 55 -403 193 55 -403 minecraft:stone
fill 153 55 -402 155 55 -402 minecraft:stone
fill 187 55 -402 192 55 -402 minecraft:stone
fill 154 55 -401 156 55 -401 minecraft:stone
fill 187 55 -401 191 55 -401 minecraft:stone
fill 154 55 -400 156 55 -400 minecraft:stone
fill 187 55 -400 191 55 -400 minecraft:stone
fill 155 55 -399 157 55 -399 minecraft:stone
fill 187 55 -399 191 55 -399 minecraft:stone
fill 149 55 -398 152 55 -398 minecraft:stone
fill 155 55 -398 158 55 -398 minecraft:stone
fill 188 55 -398 191 55 -398 minecraft:stone
fill 146 55 -397 153 55 -397 minecraft:stone
fill 156 55 -397 158 55 -397 minecraft:stone
fill 143 55 -396 153 55 -396 minecraft:stone
fill 156 55 -396 158 55 -396 minecraft:stone
fill 142 55 -395 153 55 -395 minecraft:stone
fill 157 55 -395 158 55 -395 minecraft:stone
fill 196 55 -395 198 55 -395 minecraft:stone
fill 141 55 -394 153 55 -394 minecraft:stone
setblock 158 55 -394 minecraft:stone
fill 197 55 -394 198 55 -394 minecraft:stone
fill 138 55 -393 152 55 -393 minecraft:stone
fill 136 55 -392 152 55 -392 minecraft:stone
fill 136 55 -391 152 55 -391 minecraft:stone
fill 195 55 -391 196 55 -391 minecraft:stone
fill 136 55 -390 152 55 -390 minecraft:stone
fill 193 55 -390 197 55 -390 minecraft:stone
fill 136 55 -389 151 55 -389 minecraft:stone
fill 192 55 -389 197 55 -389 minecraft:stone
fill 136 55 -388 151 55 -388 minecraft:stone
fill 192 55 -388 196 55 -388 minecraft:stone
fill 136 55 -387 150 55 -387 minecraft:stone
fill 193 55 -387 195 55 -387 minecraft:stone
fill 136 55 -386 150 55 -386 minecraft:stone
fill 136 55 -385 150 55 -385 minecraft:stone
fill 136 55 -384 150 55 -384 minecraft:stone
fill 136 55 -383 149 55 -383 minecraft:stone
setblock 148 56 -436 minecraft:stone
fill 185 56 -436 187 56 -436 minecraft:stone
fill 147 56 -435 148 56 -435 minecraft:stone
fill 185 56 -435 188 56 -435 minecraft:stone
fill 144 56 -434 148 56 -434 minecraft:stone
fill 185 56 -434 187 56 -434 minecraft:stone
fill 142 56 -433 149 56 -433 minecraft:stone
fill 136 56 -432 151 56 -432 minecraft:stone
fill 153 56 -432 161 56 -432 minecraft:stone
fill 185 56 -432 187 56 -432 minecraft:stone
setblock 199 56 -432 minecraft:stone
fill 136 56 -431 151 56 -431 minecraft:stone
fill 153 56 -431 162 56 -431 minecraft:stone
fill 185 56 -431 187 56 -431 minecraft:stone
fill 198 56 -431 199 56 -431 minecraft:stone
fill 136 56 -430 139 56 -430 minecraft:stone
fill 141 56 -430 161 56 -430 minecraft:stone
fill 197 56 -430 199 56 -430 minecraft:stone
fill 136 56 -429 139 56 -429 minecraft:stone
fill 141 56 -429 160 56 -429 minecraft:stone
fill 196 56 -429 199 56 -429 minecraft:stone
fill 136 56 -428 139 56 -428 minecraft:stone
fill 141 56 -428 168 56 -428 minecraft:stone
fill 195 56 -428 199 56 -428 minecraft:stone
fill 136 56 -427 138 56 -427 minecraft:stone
fill 143 56 -427 149 56 -427 minecraft:stone
fill 153 56 -427 170 56 -427 minecraft:stone
fill 194 56 -427 199 56 -427 minecraft:stone
fill 136 56 -426 137 56 -426 minecraft:stone
fill 154 56 -426 172 56 -426 minecraft:stone
fill 193 56 -426 199 56 -426 minecraft:stone
setblock 136 56 -425 minecraft:stone
fill 154 56 -425 173 56 -425 minecraft:stone
fill 190 56 -425 199 56 -425 minecraft:stone
setblock 136 56 -424 minecraft:stone
fill 155 56 -424 175 56 -424 minecraft:stone
fill 182 56 -424 199 56 -424 minecraft:stone
setblock 136 56 -423 minecraft:stone
fill 155 56 -423 199 56 -423 minecraft:stone
setblock 136 56 -422 minecraft:stone
fill 154 56 -422 199 56 -422 minecraft:stone
setblock 136 56 -421 minecraft:stone
fill 154 56 -421 199 56 -421 minecraft:stone
setblock 136 56 -420 minecraft:stone
fill 154 56 -420 199 56 -420 minecraft:stone
setblock 136 56 -419 minecraft:stone
fill 154 56 -419 199 56 -419 minecraft:stone
setblock 136 56 -418 minecraft:stone
fill 155 56 -418 199 56 -418 minecraft:stone
setblock 136 56 -417 minecraft:stone
fill 156 56 -417 199 56 -417 minecraft:stone
fill 157 56 -416 199 56 -416 minecraft:stone
setblock 136 56 -415 minecraft:stone
fill 157 56 -415 199 56 -415 minecraft:stone
fill 136 56 -414 137 56 -414 minecraft:stone
setblock 147 56 -414 minecraft:stone
fill 157 56 -414 199 56 -414 minecraft:stone
fill 136 56 -413 138 56 -413 minecraft:stone
fill 146 56 -413 148 56 -413 minecraft:stone
fill 157 56 -413 199 56 -413 minecraft:stone
fill 136 56 -412 139 56 -412 minecraft:stone
fill 143 56 -412 149 56 -412 minecraft:stone
fill 156 56 -412 198 56 -412 minecraft:stone
fill 136 56 -411 139 56 -411 minecraft:stone
fill 144 56 -411 149 56 -411 minecraft:stone
fill 156 56 -411 193 56 -411 minecraft:stone
fill 195 56 -411 198 56 -411 minecraft:stone
fill 136 56 -410 139 56 -410 minecraft:stone
fill 145 56 -410 150 56 -410 minecraft:stone
fill 155 56 -410 192 56 -410 minecraft:stone
fill 195 56 -410 198 56 -410 minecraft:stone
fill 136 56 -409 139 56 -409 minecraft:stone
fill 147 56 -409 151 56 -409 minecraft:stone
fill 154 56 -409 191 56 -409 minecraft:stone
fill 195 56 -409 199 56 -409 minecraft:stone
fill 136 56 -408 139 56 -408 minecraft:stone
fill 148 56 -408 152 56 -408 minecraft:stone
fill 154 56 -408 190 56 -408 minecraft:stone
fill 193 56 -408 199 56 -408 minecraft:stone
fill 136 56 -407 139 56 -407 minecraft:stone
fill 149 56 -407 189 56 -407 minecraft:stone
fill 191 56 -407 199 56 -407 minecraft:stone
fill 136 56 -406 140 56 -406 minecraft:stone
fill 150 56 -406 199 56 -406 minecraft:stone
fill 136 56 -405 142 56 -405 minecraft:stone
fill 149 56 -405 198 56 -405 minecraft:stone
fill 136 56 -404 195 56 -404 minecraft:stone
fill 136 56 -403 184 56 -403 minecraft:stone
fill 187 56 -403 194 56 -403 minecraft:stone
fill 136 56 -402 163 56 -402 minecraft:stone
fill 165 56 -402 183 56 -402 minecraft:stone
fill 187 56 -402 192 56 -402 minecraft:stone
fill 136 56 -401 163 56 -401 minecraft:stone
fill 165 56 -401 181 56 -401 minecraft:stone
fill 187 56 -401 191 56 -401 minecraft:stone
fill 136 56 -400 162 56 -400 minecraft:stone
fill 165 56 -400 180 56 -400 minecraft:stone
fill 188 56 -400 190 56 -400 minecraft:stone
fill 136 56 -399 178 56 -399 minecraft:stone
fill 136 56 -398 177 56 -398 minecraft:stone
fill 136 56 -397 176 56 -397 minecraft:stone
fill 136 56 -396 176 56 -396 minecraft:stone
fill 136 56 -395 175 56 -395 minecraft:stone
fill 136 56 -394 174 56 -394 minecraft:stone
fill 136 56 -393 174 56 -393 minecraft:stone
fill 136 56 -392 173 56 -392 minecraft:stone
fill 136 56 -391 162 56 -391 minecraft:stone
fill 165 56 -391 172 56 -391 minecraft:stone
fill 136 56 -390 160 56 -390 minecraft:stone
fill 166 56 -390 172 56 -390 minecraft:stone
fill 193 56 -390 195 56 -390 minecraft:stone
fill 136 56 -389 159 56 -389 minecraft:stone
fill 167 56 -389 171 56 -389 minecraft:stone
fill 192 56 -389 196 56 -389 minecraft:stone
fill 136 56 -388 158 56 -388 minecraft:stone
fill 168 56 -388 170 56 -388 minecraft:stone
fill 192 56 -388 196 56 -388 minecraft:stone
fill 136 56 -387 158 56 -387 minecraft:stone
fill 192 56 -387 195 56 -387 minecraft:stone
fill 136 56 -386 157 56 -386 minecraft:stone
fill 136 56 -385 156 56 -385 minecraft:stone
fill 136 56 -384 155 56 -384 minecraft:stone
fill 136 56 -383 155 56 -383 minecraft:stone
fill 185 57 -438 187 57 -438 minecraft:stone
fill 185 57 -437 187 57 -437 minecraft:stone
setblock 136 57 -436 minecraft:stone
fill 144 57 -436 149 57 -436 minecraft:stone
fill 185 57 -436 188 57 -436 minecraft:stone
fill 136 57 -435 137 57 -435 minecraft:stone
fill 143 57 -435 149 57 -435 minecraft:stone
fill 185 57 -435 188 57 -435 minecraft:stone
fill 136 57 -434 138 57 -434 minecraft:stone
fill 141 57 -434 150 57 -434 minecraft:stone
fill 185 57 -434 187 57 -434 minecraft:stone
fill 136 57 -433 151 57 -433 minecraft:stone
fill 154 57 -433 156 57 -433 minecraft:stone
fill 136 57 -432 158 57 -432 minecraft:stone
fill 197 57 -432 199 57 -432 minecraft:stone
fill 136 57 -431 160 57 -431 minecraft:stone
fill 196 57 -431 199 57 -431 minecraft:stone
fill 136 57 -430 161 57 -430 minecraft:stone
fill 194 57 -430 199 57 -430 minecraft:stone
fill 136 57 -429 168 57 -429 minecraft:stone
fill 193 57 -429 199 57 -429 minecraft:stone
fill 136 57 -428 170 57 -428 minecraft:stone
fill 193 57 -428 199 57 -428 minecraft:stone
fill 136 57 -427 139 57 -427 minecraft:stone
fill 141 57 -427 172 57 -427 minecraft:stone
fill 193 57 -427 199 57 -427 minecraft:stone
fill 136 57 -426 138 57 -426 minecraft:stone
fill 143 57 -426 173 57 -426 minecraft:stone
fill 184 57 -426 199 57 -426 minecraft:stone
fill 136 57 -425 137 57 -425 minecraft:stone
fill 150 57 -425 174 57 -425 minecraft:stone
fill 183 57 -425 199 57 -425 minecraft:stone
fill 136 57 -424 137 57 -424 minecraft:stone
fill 153 57 -424 199 57 -424 minecraft:stone
fill 136 57 -423 137 57 -423 minecraft:stone
fill 152 57 -423 199 57 -423 minecraft:stone
fill 136 57 -422 137 57 -422 minecraft:stone
fill 152 57 -422 199 57 -422 minecraft:stone
fill 136 57 -421 138 57 -421 minecraft:stone
fill 152 57 -421 199 57 -421 minecraft:stone
fill 136 57 -420 139 57 -420 minecraft:stone
fill 152 57 -420 199 57 -420 minecraft:stone
fill 136 57 -419 139 57 -419 minecraft:stone
fill 153 57 -419 199 57 -419 minecraft:stone
fill 136 57 -418 139 57 -418 minecraft:stone
fill 153 57 -418 199 57 -418 minecraft:stone
fill 136 57 -417 138 57 -417 minecraft:stone
fill 154 57 -417 199 57 -417 minecraft:stone
fill 136 57 -416 138 57 -416 minecraft:stone
fill 156 57 -416 199 57 -416 minecraft:stone
fill 136 57 -415 139 57 -415 minecraft:stone
fill 155 57 -415 198 57 -415 minecraft:stone
fill 136 57 -414 144 57 -414 minecraft:stone
setblock 147 57 -414 minecraft:stone
fill 155 57 -414 198 57 -414 minecraft:stone
fill 136 57 -413 148 57 -413 minecraft:stone
fill 154 57 -413 197 57 -413 minecraft:stone
fill 136 57 -412 149 57 -412 minecraft:stone
fill 154 57 -412 198 57 -412 minecraft:stone
fill 136 57 -411 150 57 -411 minecraft:stone
fill 153 57 -411 198 57 -411 minecraft:stone
fill 136 57 -410 151 57 -410 minecraft:stone
fill 153 57 -410 199 57 -410 minecraft:stone
fill 136 57 -409 199 57 -409 minecraft:stone
fill 136 57 -408 199 57 -408 minecraft:stone
fill 136 57 -407 199 57 -407 minecraft:stone
fill 136 57 -406 199 57 -406 minecraft:stone
fill 136 57 -405 199 57 -405 minecraft:stone
fill 136 57 -404 196 57 -404 minecraft:stone
fill 136 57 -403 194 57 -403 minecraft:stone
fill 136 57 -402 185 57 -402 minecraft:stone
fill 189 57 -402 192 57 -402 minecraft:stone
fill 136 57 -401 184 57 -401 minecraft:stone
fill 136 57 -400 184 57 -400 minecraft:stone
fill 136 57 -399 181 57 -399 minecraft:stone
fill 136 57 -398 180 57 -398 minecraft:stone
fill 136 57 -397 178 57 -397 minecraft:stone
fill 136 57 -396 178 57 -396 minecraft:stone
fill 136 57 -395 177 57 -395 minecraft:stone
fill 136 57 -394 176 57 -394 minecraft:stone
fill 136 57 -393 176 57 -393 minecraft:stone
fill 136 57 -392 176 57 -392 minecraft:stone
fill 136 57 -391 174 57 -391 minecraft:stone
fill 136 57 -390 173 57 -390 minecraft:stone
fill 193 57 -390 194 57 -390 minecraft:stone
fill 136 57 -389 163 57 -389 minecraft:stone
fill 165 57 -389 173 57 -389 minecraft:stone
fill 192 57 -389 195 57 -389 minecraft:stone
fill 136 57 -388 161 57 -388 minecraft:stone
fill 166 57 -388 172 57 -388 minecraft:stone
fill 192 57 -388 195 57 -388 minecraft:stone
fill 136 57 -387 160 57 -387 minecraft:stone
fill 167 57 -387 170 57 -387 minecraft:stone
fill 192 57 -387 195 57 -387 minecraft:stone
fill 136 57 -386 160 57 -386 minecraft:stone
fill 136 57 -385 159 57 -385 minecraft:stone
fill 136 57 -384 158 57 -384 minecraft:stone
fill 136 57 -383 157 57 -383 minecraft:stone
fill 185 58 -440 187 58 -440 minecraft:stone
fill 185 58 -439 187 58 -439 minecraft:stone
fill 185 58 -438 188 58 -438 minecraft:stone
fill 185 58 -437 188 58 -437 minecraft:stone
fill 136 58 -436 138 58 -436 minecraft:stone
fill 141 58 -436 150 58 -436 minecraft:stone
fill 185 58 -436 188 58 -436 minecraft:stone
fill 136 58 -435 150 58 -435 minecraft:stone
fill 185 58 -435 187 58 -435 minecraft:stone
fill 136 58 -434 151 58 -434 minecraft:stone
fill 153 58 -434 156 58 -434 minecraft:stone
setblock 186 58 -434 minecraft:stone
fill 136 58 -433 157 58 -433 minecraft:stone
setblock 199 58 -433 minecraft:stone
fill 136 58 -432 159 58 -432 minecraft:stone
fill 196 58 -432 199 58 -432 minecraft:stone
fill 136 58 -431 163 58 -431 minecraft:stone
fill 195 58 -431 199 58 -431 minecraft:stone
fill 136 58 -430 168 58 -430 minecraft:stone
fill 191 58 -430 199 58 -430 minecraft:stone
fill 136 58 -429 170 58 -429 minecraft:stone
fill 189 58 -429 199 58 -429 minecraft:stone
fill 136 58 -428 172 58 -428 minecraft:stone
fill 187 58 -428 199 58 -428 minecraft:stone
fill 136 58 -427 173 58 -427 minecraft:stone
fill 184 58 -427 199 58 -427 minecraft:stone
fill 136 58 -426 174 58 -426 minecraft:stone
fill 183 58 -426 199 58 -426 minecraft:stone
fill 136 58 -425 139 58 -425 minecraft:stone
fill 142 58 -425 175 58 -425 minecraft:stone
fill 181 58 -425 199 58 -425 minecraft:stone
fill 136 58 -424 138 58 -424 minecraft:stone
fill 144 58 -424 199 58 -424 minecraft:stone
fill 136 58 -423 138 58 -423 minecraft:stone
fill 146 58 -423 199 58 -423 minecraft:stone
fill 136 58 -422 139 58 -422 minecraft:stone
fill 149 58 -422 199 58 -422 minecraft:stone
fill 136 58 -421 142 58 -421 minecraft:stone
fill 150 58 -421 199 58 -421 minecraft:stone
fill 136 58 -420 142 58 -420 minecraft:stone
fill 150 58 -420 199 58 -420 minecraft:stone
fill 136 58 -419 143 58 -419 minecraft:stone
fill 150 58 -419 199 58 -419 minecraft:stone
fill 136 58 -418 145 58 -418 minecraft:stone
fill 150 58 -418 199 58 -418 minecraft:stone
fill 136 58 -417 146 58 -417 minecraft:stone
fill 152 58 -417 199 58 -417 minecraft:stone
fill 136 58 -416 147 58 -416 minecraft:stone
fill 153 58 -416 199 58 -416 minecraft:stone
fill 136 58 -415 149 58 -415 minecraft:stone
fill 153 58 -415 199 58 -415 minecraft:stone
fill 136 58 -414 151 58 -414 minecraft:stone
fill 153 58 -414 199 58 -414 minecraft:stone
fill 136 58 -413 199 58 -413 minecraft:stone
fill 136 58 -412 198 58 -412 minecraft:stone
fill 136 58 -411 198 58 -411 minecraft:stone
fill 136 58 -410 198 58 -410 minecraft:stone
fill 136 58 -409 199 58 -409 minecraft:stone
fill 136 58 -408 199 58 -408 minecraft:stone
fill 136 58 -407 199 58 -407 minecraft:stone
fill 136 58 -406 199 58 -406 minecraft:stone
fill 136 58 -405 198 58 -405 minecraft:stone
fill 136 58 -404 195 58 -404 minecraft:stone
fill 136 58 -403 188 58 -403 minecraft:stone
setblock 192 58 -403 minecraft:stone
fill 136 58 -402 187 58 -402 minecraft:stone
fill 136 58 -401 186 58 -401 minecraft:stone
fill 136 58 -400 185 58 -400 minecraft:stone
fill 136 58 -399 183 58 -399 minecraft:stone
fill 136 58 -398 181 58 -398 minecraft:stone
fill 136 58 -397 180 58 -397 minecraft:stone
fill 136 58 -396 180 58 -396 minecraft:stone
fill 136 58 -395 178 58 -395 minecraft:stone
fill 136 58 -394 178 58 -394 minecraft:stone
fill 136 58 -393 177 58 -393 minecraft:stone
fill 136 58 -392 176 58 -392 minecraft:stone
fill 136 58 -391 176 58 -391 minecraft:stone
fill 136 58 -390 175 58 -390 minecraft:stone
fill 136 58 -389 174 58 -389 minecraft:stone
fill 192 58 -389 194 58 -389 minecraft:stone
fill 136 58 -388 173 58 -388 minecraft:stone
fill 191 58 -388 194 58 -388 minecraft:stone
fill 136 58 -387 172 58 -387 minecraft:stone
fill 192 58 -387 193 58 -387 minecraft:stone
fill 136 58 -386 163 58 -386 minecraft:stone
fill 165 58 -386 171 58 -386 minecraft:stone
fill 136 58 -385 162 58 -385 minecraft:stone
fill 167 58 -385 168 58 -385 minecraft:stone
fill 136 58 -384 161 58 -384 minecraft:stone
fill 136 58 -383 160 58 -383 minecraft:stone
fill 186 59 -444 188 59 -444 minecraft:stone
fill 186 59 -443 188 59 -443 minecraft:stone
fill 185 59 -442 188 59 -442 minecraft:stone
fill 185 59 -441 188 59 -441 minecraft:stone
fill 185 59 -440 188 59 -440 minecraft:stone
fill 185 59 -439 188 59 -439 minecraft:stone
fill 185 59 -438 188 59 -438 minecraft:stone
fill 136 59 -437 149 59 -437 minecraft:stone
fill 185 59 -437 187 59 -437 minecraft:stone
fill 136 59 -436 151 59 -436 minecraft:stone
fill 185 59 -436 187 59 -436 minecraft:stone
fill 136 59 -435 156 59 -435 minecraft:stone
fill 136 59 -434 157 59 -434 minecraft:stone
fill 136 59 -433 159 59 -433 minecraft:stone
fill 197 59 -433 199 59 -433 minecraft:stone
fill 136 59 -432 167 59 -432 minecraft:stone
fill 195 59 -432 199 59 -432 minecraft:stone
fill 136 59 -431 169 59 -431 minecraft:stone
fill 194 59 -431 199 59 -431 minecraft:stone
fill 136 59 -430 171 59 -430 minecraft:stone
fill 190 59 -430 199 59 -430 minecraft:stone
fill 136 59 -429 172 59 -429 minecraft:stone
fill 188 59 -429 199 59 -429 minecraft:stone
fill 136 59 -428 172 59 -428 minecraft:stone
fill 184 59 -428 199 59 -428 minecraft:stone
fill 136 59 -427 173 59 -427 minecraft:stone
fill 183 59 -427 199 59 -427 minecraft:stone
fill 136 59 -426 175 59 -426 minecraft:stone
fill 181 59 -426 199 59 -426 minecraft:stone
fill 136 59 -425 199 59 -425 minecraft:stone
fill 136 59 -424 199 59 -424 minecraft:stone
fill 136 59 -423 199 59 -423 minecraft:stone
fill 136 59 -422 199 59 -422 minecraft:stone
fill 136 59 -421 199 59 -421 minecraft:stone
fill 136 59 -420 199 59 -420 minecraft:stone
fill 136 59 -419 199 59 -419 minecraft:stone
fill 136 59 -418 199 59 -418 minecraft:stone
fill 136 59 -417 199 59 -417 minecraft:stone
fill 136 59 -416 199 59 -416 minecraft:stone
fill 136 59 -415 199 59 -415 minecraft:stone
fill 136 59 -414 199 59 -414 minecraft:stone
fill 136 59 -413 199 59 -413 minecraft:stone
fill 136 59 -412 199 59 -412 minecraft:stone
fill 136 59 -411 199 59 -411 minecraft:stone
fill 136 59 -410 198 59 -410 minecraft:stone
fill 136 59 -409 198 59 -409 minecraft:stone
fill 136 59 -408 199 59 -408 minecraft:stone
fill 136 59 -407 199 59 -407 minecraft:stone
fill 136 59 -406 198 59 -406 minecraft:stone
fill 136 59 -405 192 59 -405 minecraft:stone
fill 136 59 -404 191 59 -404 minecraft:stone
fill 136 59 -403 190 59 -403 minecraft:stone
fill 136 59 -402 188 59 -402 minecraft:stone
fill 136 59 -401 187 59 -401 minecraft:stone
fill 136 59 -400 186 59 -400 minecraft:stone
fill 136 59 -399 185 59 -399 minecraft:stone
fill 136 59 -398 183 59 -398 minecraft:stone
fill 136 59 -397 182 59 -397 minecraft:stone
fill 136 59 -396 181 59 -396 minecraft:stone
fill 136 59 -395 180 59 -395 minecraft:stone
fill 136 59 -394 179 59 -394 minecraft:stone
fill 136 59 -393 178 59 -393 minecraft:stone
fill 136 59 -392 178 59 -392 minecraft:stone
fill 136 59 -391 177 59 -391 minecraft:stone
fill 136 59 -390 176 59 -390 minecraft:stone
fill 192 59 -390 193 59 -390 minecraft:stone
fill 136 59 -389 176 59 -389 minecraft:stone
fill 191 59 -389 194 59 -389 minecraft:stone
fill 136 59 -388 175 59 -388 minecraft:stone
fill 191 59 -388 194 59 -388 minecraft:stone
fill 136 59 -387 174 59 -387 minecraft:stone
fill 191 59 -387 194 59 -387 minecraft:stone
fill 136 59 -386 173 59 -386 minecraft:stone
fill 136 59 -385 172 59 -385 minecraft:stone
fill 136 59 -384 170 59 -384 minecraft:stone
fill 136 59 -383 168 59 -383 minecraft:stone
fill 185 60 -446 188 60 -446 minecraft:stone
fill 196 60 -446 199 60 -446 minecraft:stone
fill 185 60 -445 188 60 -445 minecraft:stone
fill 196 60 -445 197 60 -445 minecraft:stone
setblock 199 60 -445 minecraft:stone
fill 185 60 -444 188 60 -444 minecraft:stone
fill 196 60 -444 197 60 -444 minecraft:stone
fill 185 60 -443 188 60 -443 minecraft:stone
fill 196 60 -443 198 60 -443 minecraft:stone
fill 185 60 -442 188 60 -442 minecraft:stone
fill 197 60 -442 198 60 -442 minecraft:stone
fill 185 60 -441 188 60 -441 minecraft:stone
fill 185 60 -440 188 60 -440 minecraft:stone
fill 185 60 -439 188 60 -439 minecraft:stone
fill 136 60 -438 149 60 -438 minecraft:stone
fill 186 60 -438 187 60 -438 minecraft:stone
fill 136 60 -437 152 60 -437 minecraft:stone
fill 136 60 -436 156 60 -436 minecraft:stone
fill 136 60 -435 157 60 -435 minecraft:stone
fill 136 60 -434 159 60 -434 minecraft:stone
fill 195 60 -434 199 60 -434 minecraft:stone
fill 136 60 -433 162 60 -433 minecraft:stone
fill 194 60 -433 199 60 -433 minecraft:stone
fill 136 60 -432 170 60 -432 minecraft:stone
fill 194 60 -432 199 60 -432 minecraft:stone
fill 136 60 -431 172 60 -431 minecraft:stone
fill 193 60 -431 199 60 -431 minecraft:stone
fill 136 60 -430 172 60 -430 minecraft:stone
fill 191 60 -430 199 60 -430 minecraft:stone
fill 136 60 -429 173 60 -429 minecraft:stone
fill 188 60 -429 199 60 -429 minecraft:stone
fill 136 60 -428 173 60 -428 minecraft:stone
fill 183 60 -428 199 60 -428 minecraft:stone
fill 136 60 -427 175 60 -427 minecraft:stone
fill 181 60 -427 199 60 -427 minecraft:stone
fill 136 60 -426 199 60 -426 minecraft:stone
fill 136 60 -425 199 60 -425 minecraft:stone
fill 136 60 -424 199 60 -424 minecraft:stone
fill 136 60 -423 199 60 -423 minecraft:stone
fill 136 60 -422 199 60 -422 minecraft:stone
fill 136 60 -421 199 60 -421 minecraft:stone
fill 136 60 -420 199 60 -420 minecraft:stone
fill 136 60 -419 199 60 -419 minecraft:stone
fill 136 60 -418 199 60 -418 minecraft:stone
fill 136 60 -417 199 60 -417 minecraft:stone
fill 136 60 -416 199 60 -416 minecraft:stone
fill 136 60 -415 199 60 -415 minecraft:stone
fill 136 60 -414 199 60 -414 minecraft:stone
fill 136 60 -413 199 60 -413 minecraft:stone
fill 136 60 -412 199 60 -412 minecraft:stone
fill 136 60 -411 199 60 -411 minecraft:stone
fill 136 60 -410 199 60 -410 minecraft:stone
fill 136 60 -409 199 60 -409 minecraft:stone
fill 136 60 -408 198 60 -408 minecraft:stone
fill 136 60 -407 199 60 -407 minecraft:stone
fill 136 60 -406 199 60 -406 minecraft:stone
fill 136 60 -405 198 60 -405 minecraft:stone
fill 136 60 -404 193 60 -404 minecraft:stone
fill 136 60 -403 191 60 -403 minecraft:stone
fill 136 60 -402 190 60 -402 minecraft:stone
fill 136 60 -401 189 60 -401 minecraft:stone
fill 136 60 -400 188 60 -400 minecraft:stone
fill 136 60 -399 186 60 -399 minecraft:stone
fill 136 60 -398 185 60 -398 minecraft:stone
fill 136 60 -397 184 60 -397 minecraft:stone
fill 136 60 -396 182 60 -396 minecraft:stone
fill 136 60 -395 182 60 -395 minecraft:stone
fill 136 60 -394 181 60 -394 minecraft:stone
fill 136 60 -393 180 60 -393 minecraft:stone
fill 136 60 -392 179 60 -392 minecraft:stone
fill 136 60 -391 179 60 -391 minecraft:stone
fill 136 60 -390 178 60 -390 minecraft:stone
fill 192 60 -390 193 60 -390 minecraft:stone
fill 136 60 -389 178 60 -389 minecraft:stone
fill 191 60 -389 194 60 -389 minecraft:stone
fill 136 60 -388 177 60 -388 minecraft:stone
fill 191 60 -388 194 60 -388 minecraft:stone
fill 136 60 -387 176 60 -387 minecraft:stone
fill 191 60 -387 193 60 -387 minecraft:stone
fill 136 60 -386 175 60 -386 minecraft:stone
fill 136 60 -385 174 60 -385 minecraft:stone
fill 136 60 -384 173 60 -384 minecraft:stone
fill 136 60 -383 172 60 -383 minecraft:stone
fill 185 61 -446 188 61 -446 minecraft:stone
fill 196 61 -446 199 61 -446 minecraft:stone
fill 185 61 -445 188 61 -445 minecraft:stone
fill 196 61 -445 199 61 -445 minecraft:stone
fill 186 61 -444 188 61 -444 minecraft:stone
fill 196 61 -444 199 61 -444 minecraft:stone
fill 186 61 -443 188 61 -443 minecraft:stone
fill 195 61 -443 199 61 -443 minecraft:stone
fill 186 61 -442 188 61 -442 minecraft:stone
fill 195 61 -442 198 61 -442 minecraft:stone
setblock 140 61 -441 minecraft:stone
fill 186 61 -441 187 61 -441 minecraft:stone
fill 195 61 -441 198 61 -441 minecraft:stone
fill 136 61 -440 142 61 -440 minecraft:stone
fill 195 61 -440 198 61 -440 minecraft:stone
fill 136 61 -439 156 61 -439 minecraft:stone
fill 195 61 -439 198 61 -439 minecraft:stone
fill 136 61 -438 156 61 -438 minecraft:stone
fill 194 61 -438 197 61 -438 minecraft:stone
fill 136 61 -437 157 61 -437 minecraft:stone
fill 194 61 -437 197 61 -437 minecraft:stone
fill 136 61 -436 158 61 -436 minecraft:stone
fill 194 61 -436 196 61 -436 minecraft:stone
fill 136 61 -435 159 61 -435 minecraft:stone
fill 194 61 -435 199 61 -435 minecraft:stone
fill 136 61 -434 162 61 -434 minecraft:stone
fill 194 61 -434 199 61 -434 minecraft:stone
fill 136 61 -433 170 61 -433 minecraft:stone
fill 194 61 -433 199 61 -433 minecraft:stone
fill 136 61 -432 172 61 -432 minecraft:stone
fill 193 61 -432 199 61 -432 minecraft:stone
fill 136 61 -431 173 61 -431 minecraft:stone
fill 191 61 -431 199 61 -431 minecraft:stone
fill 136 61 -430 173 61 -430 minecraft:stone
fill 189 61 -430 199 61 -430 minecraft:stone
fill 136 61 -429 174 61 -429 minecraft:stone
fill 184 61 -429 199 61 -429 minecraft:stone
fill 136 61 -428 175 61 -428 minecraft:stone
fill 181 61 -428 199 61 -428 minecraft:stone
fill 136 61 -427 199 61 -427 minecraft:stone
fill 136 61 -426 199 61 -426 minecraft:stone
fill 136 61 -425 199 61 -425 minecraft:stone
fill 136 61 -424 199 61 -424 minecraft:stone
fill 136 61 -423 199 61 -423 minecraft:stone
fill 136 61 -422 199 61 -422 minecraft:stone
fill 136 61 -421 199 61 -421 minecraft:stone
fill 136 61 -420 199 61 -420 minecraft:stone
fill 136 61 -419 199 61 -419 minecraft:stone
fill 136 61 -418 199 61 -418 minecraft:stone
fill 136 61 -417 199 61 -417 minecraft:stone
fill 136 61 -416 199 61 -416 minecraft:stone
fill 136 61 -415 199 61 -415 minecraft:stone
fill 136 61 -414 199 61 -414 minecraft:stone
fill 136 61 -413 199 61 -413 minecraft:stone
fill 136 61 -412 199 61 -412 minecraft:stone
fill 136 61 -411 199 61 -411 minecraft:stone
fill 136 61 -410 199 61 -410 minecraft:stone
fill 136 61 -409 199 61 -409 minecraft:stone
fill 136 61 -408 199 61 -408 minecraft:stone
fill 136 61 -407 199 61 -407 minecraft:stone
fill 136 61 -406 199 61 -406 minecraft:stone
fill 136 61 -405 199 61 -405 minecraft:stone
fill 136 61 -404 198 61 -404 minecraft:stone
fill 136 61 -403 194 61 -403 minecraft:stone
fill 136 61 -402 192 61 -402 minecraft:stone
fill 136 61 -401 190 61 -401 minecraft:stone
fill 136 61 -400 189 61 -400 minecraft:stone
fill 136 61 -399 188 61 -399 minecraft:stone
fill 136 61 -398 187 61 -398 minecraft:stone
fill 136 61 -397 186 61 -397 minecraft:stone
fill 136 61 -396 184 61 -396 minecraft:stone
fill 136 61 -395 184 61 -395 minecraft:stone
fill 136 61 -394 183 61 -394 minecraft:stone
fill 136 61 -393 182 61 -393 minecraft:stone
fill 136 61 -392 181 61 -392 minecraft:stone
fill 136 61 -391 181 61 -391 minecraft:stone
fill 136 61 -390 180 61 -390 minecraft:stone
fill 191 61 -390 193 61 -390 minecraft:stone
fill 136 61 -389 180 61 -389 minecraft:stone
fill 190 61 -389 193 61 -389 minecraft:stone
fill 136 61 -388 180 61 -388 minecraft:stone
fill 190 61 -388 194 61 -388 minecraft:stone
fill 136 61 -387 179 61 -387 minecraft:stone
fill 190 61 -387 193 61 -387 minecraft:stone
fill 136 61 -386 177 61 -386 minecraft:stone
fill 136 61 -385 176 61 -385 minecraft:stone
fill 136 61 -384 175 61 -384 minecraft:stone
fill 136 61 -383 174 61 -383 minecraft:stone
fill 186 62 -446 187 62 -446 minecraft:dirt
fill 196 62 -446 199 62 -446 minecraft:dirt
fill 186 62 -445 187 62 -445 minecraft:dirt
fill 196 62 -445 199 62 -445 minecraft:dirt
setblock 140 62 -444 minecraft:dirt
fill 196 62 -444 199 62 -444 minecraft:dirt
fill 136 62 -443 142 62 -443 minecraft:dirt
fill 195 62 -443 199 62 -443 minecraft:dirt
fill 136 62 -442 145 62 -442 minecraft:dirt
fill 195 62 -442 199 62 -442 minecraft:dirt
fill 136 62 -441 156 62 -441 minecraft:dirt
fill 195 62 -441 198 62 -441 minecraft:dirt
fill 136 62 -440 157 62 -440 minecraft:dirt
fill 195 62 -440 198 62 -440 minecraft:dirt
fill 136 62 -439 158 62 -439 minecraft:dirt
fill 194 62 -439 198 62 -439 minecraft:dirt
fill 136 62 -438 158 62 -438 minecraft:dirt
fill 194 62 -438 197 62 -438 minecraft:dirt
fill 136 62 -437 158 62 -437 minecraft:dirt
fill 194 62 -437 197 62 -437 minecraft:dirt
fill 136 62 -436 159 62 -436 minecraft:dirt
fill 194 62 -436 199 62 -436 minecraft:dirt
fill 136 62 -435 163 62 -435 minecraft:dirt
fill 194 62 -435 199 62 -435 minecraft:dirt
fill 136 62 -434 166 62 -434 minecraft:dirt
fill 168 62 -434 172 62 -434 minecraft:dirt
fill 194 62 -434 199 62 -434 minecraft:dirt
fill 136 62 -433 173 62 -433 minecraft:dirt
fill 193 62 -433 199 62 -433 minecraft:dirt
fill 136 62 -432 173 62 -432 minecraft:dirt
fill 190 62 -432 199 62 -432 minecraft:dirt
fill 136 62 -431 174 62 -431 minecraft:dirt
fill 188 62 -431 199 62 -431 minecraft:dirt
fill 136 62 -430 175 62 -430 minecraft:dirt
fill 184 62 -430 199 62 -430 minecraft:dirt
fill 136 62 -429 176 62 -429 minecraft:dirt
fill 181 62 -429 199 62 -429 minecraft:dirt
fill 136 62 -428 199 62 -428 minecraft:dirt
fill 136 62 -427 199 62 -427 minecraft:dirt
fill 136 62 -426 199 62 -426 minecraft:dirt
fill 136 62 -425 199 62 -425 minecraft:dirt
fill 136 62 -424 199 62 -424 minecraft:dirt
fill 136 62 -423 199 62 -423 minecraft:dirt
fill 136 62 -422 199 62 -422 minecraft:dirt
fill 136 62 -421 199 62 -421 minecraft:dirt
fill 136 62 -420 199 62 -420 minecraft:dirt
fill 136 62 -419 199 62 -419 minecraft:dirt
fill 136 62 -418 199 62 -418 minecraft:dirt
fill 136 62 -417 199 62 -417 minecraft:dirt
fill 136 62 -416 199 62 -416 minecraft:dirt
fill 136 62 -415 199 62 -415 minecraft:dirt
fill 136 62 -414 199 62 -414 minecraft:dirt
fill 136 62 -413 199 62 -413 minecraft:dirt
fill 136 62 -412 199 62 -412 minecraft:dirt
fill 136 62 -411 199 62 -411 minecraft:dirt
fill 136 62 -410 199 62 -410 minecraft:dirt
fill 136 62 -409 199 62 -409 minecraft:dirt
fill 136 62 -408 199 62 -408 minecraft:dirt
fill 136 62 -407 199 62 -407 minecraft:dirt
fill 136 62 -406 199 62 -406 minecraft:dirt
fill 136 62 -405 199 62 -405 minecraft:dirt
fill 136 62 -404 199 62 -404 minecraft:dirt
fill 136 62 -403 197 62 -403 minecraft:dirt
fill 136 62 -402 195 62 -402 minecraft:dirt
fill 136 62 -401 193 62 -401 minecraft:dirt
fill 136 62 -400 191 62 -400 minecraft:dirt
fill 136 62 -399 190 62 -399 minecraft:dirt
fill 136 62 -398 187 62 -398 minecraft:dirt
setblock 189 62 -398 minecraft:dirt
fill 136 62 -397 187 62 -397 minecraft:dirt
fill 136 62 -396 187 62 -396 minecraft:dirt
fill 136 62 -395 186 62 -395 minecraft:dirt
fill 136 62 -394 185 62 -394 minecraft:dirt
fill 136 62 -393 184 62 -393 minecraft:dirt
fill 136 62 -392 184 62 -392 minecraft:dirt
fill 136 62 -391 183 62 -391 minecraft:dirt
fill 136 62 -390 183 62 -390 minecraft:dirt
fill 191 62 -390 192 62 -390 minecraft:dirt
fill 136 62 -389 183 62 -389 minecraft:dirt
fill 190 62 -389 193 62 -389 minecraft:dirt
fill 136 62 -388 182 62 -388 minecraft:dirt
fill 190 62 -388 193 62 -388 minecraft:dirt
fill 136 62 -387 181 62 -387 minecraft:dirt
fill 190 62 -387 193 62 -387 minecraft:dirt
fill 136 62 -386 181 62 -386 minecraft:dirt
fill 136 62 -385 180 62 -385 minecraft:dirt
fill 136 62 -384 179 62 -384 minecraft:dirt
fill 136 62 -383 178 62 -383 minecraft:dirt
fill 136 63 -446 146 63 -446 minecraft:dirt
fill 151 63 -446 152 63 -446 minecraft:dirt
fill 136 63 -445 152 63 -445 minecraft:dirt
setblock 198 63 -445 minecraft:dirt
fill 136 63 -444 153 63 -444 minecraft:dirt
fill 198 63 -444 199 63 -444 minecraft:dirt
fill 136 63 -443 155 63 -443 minecraft:dirt
fill 197 63 -443 199 63 -443 minecraft:dirt
fill 136 63 -442 157 63 -442 minecraft:dirt
fill 196 63 -442 199 63 -442 minecraft:dirt
fill 136 63 -441 158 63 -441 minecraft:dirt
fill 196 63 -441 199 63 -441 minecraft:dirt
fill 136 63 -440 159 63 -440 minecraft:dirt
fill 194 63 -440 197 63 -440 minecraft:dirt
fill 136 63 -439 160 63 -439 minecraft:dirt
fill 194 63 -439 197 63 -439 minecraft:dirt
fill 136 63 -438 158 63 -438 minecraft:dirt
fill 160 63 -438 161 63 -438 minecraft:dirt
fill 194 63 -438 199 63 -438 minecraft:dirt
fill 136 63 -437 158 63 -437 minecraft:dirt
fill 161 63 -437 162 63 -437 minecraft:dirt
fill 194 63 -437 199 63 -437 minecraft:dirt
fill 136 63 -436 159 63 -436 minecraft:dirt
fill 161 63 -436 170 63 -436 minecraft:dirt
fill 195 63 -436 199 63 -436 minecraft:dirt
fill 136 63 -435 170 63 -435 minecraft:dirt
setblock 173 63 -435 minecraft:dirt
fill 194 63 -435 199 63 -435 minecraft:dirt
fill 136 63 -434 166 63 -434 minecraft:dirt
fill 168 63 -434 174 63 -434 minecraft:dirt
fill 191 63 -434 199 63 -434 minecraft:dirt
fill 136 63 -433 175 63 -433 minecraft:dirt
fill 188 63 -433 191 63 -433 minecraft:dirt
fill 193 63 -433 199 63 -433 minecraft:dirt
fill 136 63 -432 175 63 -432 minecraft:dirt
fill 185 63 -432 199 63 -432 minecraft:dirt
fill 136 63 -431 177 63 -431 minecraft:dirt
fill 182 63 -431 199 63 -431 minecraft:dirt
fill 136 63 -430 199 63 -430 minecraft:dirt
fill 136 63 -429 199 63 -429 minecraft:dirt
fill 136 63 -428 199 63 -428 minecraft:dirt
fill 136 63 -427 199 63 -427 minecraft:dirt
fill 136 63 -426 199 63 -426 minecraft:dirt
fill 136 63 -425 199 63 -425 minecraft:dirt
fill 136 63 -424 199 63 -424 minecraft:dirt
fill 136 63 -423 199 63 -423 minecraft:dirt
fill 136 63 -422 199 63 -422 minecraft:dirt
fill 136 63 -421 199 63 -421 minecraft:dirt
fill 136 63 -420 199 63 -420 minecraft:dirt
fill 136 63 -419 199 63 -419 minecraft:dirt
fill 136 63 -418 199 63 -418 minecraft:dirt
fill 136 63 -417 199 63 -417 minecraft:dirt
fill 136 63 -416 199 63 -416 minecraft:dirt
fill 136 63 -415 199 63 -415 minecraft:dirt
fill 136 63 -414 199 63 -414 minecraft:dirt
fill 136 63 -413 199 63 -413 minecraft:dirt
fill 136 63 -412 199 63 -412 minecraft:dirt
fill 136 63 -411 199 63 -411 minecraft:dirt
fill 136 63 -410 199 63 -410 minecraft:dirt
fill 136 63 -409 199 63 -409 minecraft:dirt
fill 136 63 -408 199 63 -408 minecraft:dirt
fill 136 63 -407 199 63 -407 minecraft:dirt
fill 136 63 -406 199 63 -406 minecraft:dirt
fill 136 63 -405 199 63 -405 minecraft:dirt
fill 136 63 -404 199 63 -404 minecraft:dirt
fill 136 63 -403 199 63 -403 minecraft:dirt
fill 136 63 -402 199 63 -402 minecraft:dirt
fill 136 63 -401 199 63 -401 minecraft:dirt
fill 136 63 -400 199 63 -400 minecraft:dirt
fill 136 63 -399 199 63 -399 minecraft:dirt
fill 136 63 -398 187 63 -398 minecraft:dirt
fill 189 63 -398 195 63 -398 minecraft:dirt
fill 136 63 -397 187 63 -397 minecraft:dirt
fill 189 63 -397 192 63 -397 minecraft:dirt
fill 136 63 -396 191 63 -396 minecraft:dirt
fill 136 63 -395 190 63 -395 minecraft:dirt
fill 136 63 -394 189 63 -394 minecraft:dirt
fill 136 63 -393 188 63 -393 minecraft:dirt
fill 136 63 -392 187 63 -392 minecraft:dirt
fill 136 63 -391 187 63 -391 minecraft:dirt
fill 136 63 -390 185 63 -390 minecraft:dirt
fill 190 63 -390 192 63 -390 minecraft:dirt
fill 136 63 -389 183 63 -389 minecraft:dirt
fill 185 63 -389 186 63 -389 minecraft:dirt
fill 189 63 -389 193 63 -389 minecraft:dirt
fill 136 63 -388 185 63 -388 minecraft:dirt
fill 190 63 -388 193 63 -388 minecraft:dirt
fill 136 63 -387 185 63 -387 minecraft:dirt
fill 190 63 -387 192 63 -387 minecraft:dirt
fill 136 63 -386 183 63 -386 minecraft:dirt
fill 136 63 -385 184 63 -385 minecraft:dirt
fill 136 63 -384 181 63 -384 minecraft:dirt
setblock 183 63 -384 minecraft:dirt
fill 136 63 -383 178 63 -383 minecraft:dirt
fill 182 63 -383 183 63 -383 minecraft:dirt
fill 136 64 -446 157 64 -446 minecraft:dirt
setblock 160 64 -446 minecraft:dirt
fill 136 64 -445 158 64 -445 minecraft:dirt
fill 136 64 -444 157 64 -444 minecraft:dirt
fill 136 64 -443 159 64 -443 minecraft:dirt
fill 136 64 -442 160 64 -442 minecraft:dirt
fill 136 64 -441 159 64 -441 minecraft:dirt
fill 198 64 -441 199 64 -441 minecraft:dirt
fill 136 64 -440 159 64 -440 minecraft:dirt
setblock 162 64 -440 minecraft:dirt
fill 196 64 -440 199 64 -440 minecraft:dirt
fill 136 64 -439 165 64 -439 minecraft:dirt
fill 195 64 -439 199 64 -439 minecraft:dirt
fill 136 64 -438 173 64 -438 minecraft:dirt
fill 193 64 -438 199 64 -438 minecraft:dirt
fill 136 64 -437 176 64 -437 minecraft:dirt
fill 192 64 -437 199 64 -437 minecraft:dirt
fill 136 64 -436 170 64 -436 minecraft:dirt
fill 173 64 -436 178 64 -436 minecraft:dirt
fill 186 64 -436 199 64 -436 minecraft:dirt
fill 136 64 -435 170 64 -435 minecraft:dirt
fill 173 64 -435 174 64 -435 minecraft:dirt
fill 176 64 -435 179 64 -435 minecraft:dirt
fill 182 64 -435 183 64 -435 minecraft:dirt
fill 186 64 -435 199 64 -435 minecraft:dirt
fill 136 64 -434 166 64 -434 minecraft:dirt
fill 168 64 -434 199 64 -434 minecraft:dirt
fill 136 64 -433 176 64 -433 minecraft:dirt
fill 179 64 -433 191 64 -433 minecraft:dirt
fill 193 64 -433 199 64 -433 minecraft:dirt
fill 136 64 -432 175 64 -432 minecraft:dirt
fill 179 64 -432 181 64 -432 minecraft:dirt
fill 183 64 -432 199 64 -432 minecraft:dirt
fill 136 64 -431 199 64 -431 minecraft:dirt
fill 136 64 -430 199 64 -430 minecraft:dirt
fill 136 64 -429 199 64 -429 minecraft:dirt
fill 136 64 -428 199 64 -428 minecraft:dirt
fill 136 64 -427 199 64 -427 minecraft:dirt
fill 136 64 -426 199 64 -426 minecraft:dirt
fill 136 64 -425 199 64 -425 minecraft:dirt
fill 136 64 -424 199 64 -424 minecraft:dirt
fill 136 64 -423 199 64 -423 minecraft:dirt
fill 136 64 -422 199 64 -422 minecraft:dirt
fill 136 64 -421 199 64 -421 minecraft:dirt
fill 136 64 -420 199 64 -420 minecraft:dirt
fill 136 64 -419 199 64 -419 minecraft:dirt
fill 136 64 -418 199 64 -418 minecraft:dirt
fill 136 64 -417 199 64 -417 minecraft:dirt
fill 136 64 -416 199 64 -416 minecraft:dirt
fill 136 64 -415 199 64 -415 minecraft:dirt
fill 136 64 -414 199 64 -414 minecraft:dirt
fill 136 64 -413 199 64 -413 minecraft:dirt
fill 136 64 -412 199 64 -412 minecraft:dirt
fill 136 64 -411 199 64 -411 minecraft:dirt
fill 136 64 -410 199 64 -410 minecraft:dirt
fill 136 64 -409 199 64 -409 minecraft:dirt
fill 136 64 -408 199 64 -408 minecraft:dirt
fill 136 64 -407 199 64 -407 minecraft:dirt
fill 136 64 -406 199 64 -406 minecraft:dirt
fill 136 64 -405 199 64 -405 minecraft:dirt
fill 136 64 -404 199 64 -404 minecraft:dirt
fill 136 64 -403 199 64 -403 minecraft:dirt
fill 136 64 -402 199 64 -402 minecraft:dirt
fill 136 64 -401 199 64 -401 minecraft:dirt
fill 136 64 -400 199 64 -400 minecraft:dirt
fill 136 64 -399 199 64 -399 minecraft:dirt
fill 136 64 -398 199 64 -398 minecraft:dirt
fill 136 64 -397 199 64 -397 minecraft:dirt
fill 136 64 -396 199 64 -396 minecraft:dirt
fill 136 64 -395 199 64 -395 minecraft:dirt
fill 136 64 -394 199 64 -394 minecraft:dirt
fill 136 64 -393 199 64 -393 minecraft:dirt
fill 136 64 -392 196 64 -392 minecraft:dirt
fill 198 64 -392 199 64 -392 minecraft:dirt
fill 136 64 -391 199 64 -391 minecraft:dirt
fill 136 64 -390 185 64 -390 minecraft:dirt
fill 187 64 -390 199 64 -390 minecraft:dirt
fill 136 64 -389 183 64 -389 minecraft:dirt
fill 185 64 -389 195 64 -389 minecraft:dirt
fill 197 64 -389 199 64 -389 minecraft:dirt
fill 136 64 -388 188 64 -388 minecraft:dirt
fill 190 64 -388 199 64 -388 minecraft:dirt
fill 136 64 -387 199 64 -387 minecraft:dirt
fill 136 64 -386 183 64 -386 minecraft:dirt
fill 186 64 -386 190 64 -386 minecraft:dirt
fill 194 64 -386 197 64 -386 minecraft:dirt
setblock 199 64 -386 minecraft:dirt
fill 136 64 -385 186 64 -385 minecraft:dirt
fill 188 64 -385 189 64 -385 minecraft:dirt
fill 194 64 -385 199 64 -385 minecraft:dirt
fill 136 64 -384 181 64 -384 minecraft:dirt
fill 183 64 -384 188 64 -384 minecraft:dirt
fill 195 64 -384 199 64 -384 minecraft:dirt
fill 136 64 -383 178 64 -383 minecraft:dirt
fill 182 64 -383 189 64 -383 minecraft:dirt
fill 194 64 -383 199 64 -383 minecraft:dirt
fill 136 65 -446 199 65 -446 minecraft:light_gray_concrete
fill 136 65 -445 138 65 -445 minecraft:light_gray_concrete
setblock 139 65 -445 minecraft:sea_lantern
fill 140 65 -445 147 65 -445 minecraft:light_gray_concrete
setblock 148 65 -445 minecraft:sea_lantern
fill 149 65 -445 156 65 -445 minecraft:light_gray_concrete
setblock 157 65 -445 minecraft:sea_lantern
fill 158 65 -445 165 65 -445 minecraft:light_gray_concrete
setblock 166 65 -445 minecraft:sea_lantern
fill 167 65 -445 174 65 -445 minecraft:light_gray_concrete
setblock 175 65 -445 minecraft:sea_lantern
fill 176 65 -445 183 65 -445 minecraft:light_gray_concrete
setblock 184 65 -445 minecraft:sea_lantern
fill 185 65 -445 192 65 -445 minecraft:light_gray_concrete
setblock 193 65 -445 minecraft:sea_lantern
fill 194 65 -445 199 65 -445 minecraft:light_gray_concrete
fill 136 65 -444 137 65 -444 minecraft:light_gray_concrete
setblock 138 65 -444 minecraft:sea_lantern
fill 139 65 -444 146 65 -444 minecraft:light_gray_concrete
setblock 147 65 -444 minecraft:sea_lantern
fill 148 65 -444 155 65 -444 minecraft:light_gray_concrete
setblock 156 65 -444 minecraft:sea_lantern
fill 157 65 -444 164 65 -444 minecraft:light_gray_concrete
setblock 165 65 -444 minecraft:sea_lantern
fill 166 65 -444 173 65 -444 minecraft:light_gray_concrete
setblock 174 65 -444 minecraft:sea_lantern
fill 175 65 -444 182 65 -444 minecraft:light_gray_concrete
setblock 183 65 -444 minecraft:sea_lantern
fill 184 65 -444 191 65 -444 minecraft:light_gray_concrete
setblock 192 65 -444 minecraft:sea_lantern
fill 193 65 -444 199 65 -444 minecraft:light_gray_concrete
setblock 136 65 -443 minecraft:light_gray_concrete
setblock 137 65 -443 minecraft:sea_lantern
fill 138 65 -443 145 65 -443 minecraft:light_gray_concrete
setblock 146 65 -443 minecraft:sea_lantern
fill 147 65 -443 154 65 -443 minecraft:light_gray_concrete
setblock 155 65 -443 minecraft:sea_lantern
fill 156 65 -443 163 65 -443 minecraft:light_gray_concrete
setblock 164 65 -443 minecraft:sea_lantern
fill 165 65 -443 172 65 -443 minecraft:light_gray_concrete
setblock 173 65 -443 minecraft:sea_lantern
fill 174 65 -443 181 65 -443 minecraft:light_gray_concrete
setblock 182 65 -443 minecraft:sea_lantern
fill 183 65 -443 190 65 -443 minecraft:light_gray_concrete
setblock 191 65 -443 minecraft:sea_lantern
fill 192 65 -443 199 65 -443 minecraft:light_gray_concrete
setblock 136 65 -442 minecraft:sea_lantern
fill 137 65 -442 144 65 -442 minecraft:light_gray_concrete
setblock 145 65 -442 minecraft:sea_lantern
fill 146 65 -442 153 65 -442 minecraft:light_gray_concrete
setblock 154 65 -442 minecraft:sea_lantern
fill 155 65 -442 162 65 -442 minecraft:light_gray_concrete
setblock 163 65 -442 minecraft:sea_lantern
fill 164 65 -442 171 65 -442 minecraft:light_gray_concrete
setblock 172 65 -442 minecraft:sea_lantern
fill 173 65 -442 180 65 -442 minecraft:light_gray_concrete
setblock 181 65 -442 minecraft:sea_lantern
fill 182 65 -442 189 65 -442 minecraft:light_gray_concrete
setblock 190 65 -442 minecraft:sea_lantern
fill 191 65 -442 198 65 -442 minecraft:light_gray_concrete
setblock 199 65 -442 minecraft:sea_lantern
fill 136 65 -441 199 65 -441 minecraft:smooth_quartz
fill 136 65 -440 166 65 -440 minecraft:grass_block
fill 175 65 -440 187 65 -440 minecraft:grass_block
fill 190 65 -440 199 65 -440 minecraft:grass_block
fill 136 65 -439 173 65 -439 minecraft:grass_block
setblock 180 65 -439 minecraft:grass_block
fill 184 65 -439 185 65 -439 minecraft:grass_block
fill 190 65 -439 199 65 -439 minecraft:grass_block
fill 136 65 -438 177 65 -438 minecraft:grass_block
fill 184 65 -438 199 65 -438 minecraft:grass_block
fill 136 65 -437 179 65 -437 minecraft:grass_block
fill 182 65 -437 199 65 -437 minecraft:grass_block
fill 136 65 -436 199 65 -436 minecraft:grass_block
fill 136 65 -435 199 65 -435 minecraft:grass_block
fill 136 65 -434 199 65 -434 minecraft:grass_block
fill 136 65 -433 199 65 -433 minecraft:grass_block
fill 136 65 -432 199 65 -432 minecraft:grass_block
fill 136 65 -431 199 65 -431 minecraft:grass_block
fill 136 65 -430 199 65 -430 minecraft:grass_block
fill 136 65 -429 199 65 -429 minecraft:grass_block
fill 136 65 -428 199 65 -428 minecraft:grass_block
fill 136 65 -427 199 65 -427 minecraft:grass_block
fill 136 65 -426 199 65 -426 minecraft:grass_block
fill 136 65 -425 199 65 -425 minecraft:grass_block
fill 136 65 -424 199 65 -424 minecraft:grass_block
fill 136 65 -423 199 65 -423 minecraft:grass_block
fill 136 65 -422 199 65 -422 minecraft:grass_block
fill 136 65 -421 199 65 -421 minecraft:grass_block
fill 136 65 -420 199 65 -420 minecraft:grass_block
fill 136 65 -419 199 65 -419 minecraft:grass_block
fill 136 65 -418 199 65 -418 minecraft:grass_block
fill 136 65 -417 199 65 -417 minecraft:grass_block
fill 136 65 -416 199 65 -416 minecraft:grass_block
fill 136 65 -415 199 65 -415 minecraft:grass_block
fill 136 65 -414 199 65 -414 minecraft:grass_block
fill 136 65 -413 199 65 -413 minecraft:grass_block
fill 136 65 -412 199 65 -412 minecraft:grass_block
fill 136 65 -411 199 65 -411 minecraft:grass_block
fill 136 65 -410 199 65 -410 minecraft:grass_block
fill 136 65 -409 199 65 -409 minecraft:grass_block
fill 136 65 -408 199 65 -408 minecraft:grass_block
fill 136 65 -407 199 65 -407 minecraft:grass_block
fill 136 65 -406 199 65 -406 minecraft:grass_block
fill 136 65 -405 199 65 -405 minecraft:grass_block
fill 136 65 -404 199 65 -404 minecraft:grass_block
fill 136 65 -403 199 65 -403 minecraft:grass_block
fill 136 65 -402 199 65 -402 minecraft:grass_block
fill 136 65 -401 199 65 -401 minecraft:grass_block
fill 136 65 -400 199 65 -400 minecraft:grass_block
fill 136 65 -399 199 65 -399 minecraft:grass_block
fill 136 65 -398 199 65 -398 minecraft:grass_block
fill 136 65 -397 199 65 -397 minecraft:grass_block
fill 136 65 -396 199 65 -396 minecraft:grass_block
fill 136 65 -395 199 65 -395 minecraft:grass_block
fill 136 65 -394 199 65 -394 minecraft:grass_block
fill 136 65 -393 199 65 -393 minecraft:grass_block
fill 136 65 -392 199 65 -392 minecraft:grass_block
fill 136 65 -391 199 65 -391 minecraft:grass_block
fill 136 65 -390 199 65 -390 minecraft:grass_block
fill 136 65 -389 199 65 -389 minecraft:grass_block
fill 136 65 -388 199 65 -388 minecraft:grass_block
fill 136 65 -387 199 65 -387 minecraft:grass_block
fill 136 65 -386 199 65 -386 minecraft:grass_block
fill 136 65 -385 199 65 -385 minecraft:grass_block
fill 136 65 -384 199 65 -384 minecraft:grass_block
fill 136 65 -383 199 65 -383 minecraft:grass_block
fill 158 66 -446 159 66 -446 minecraft:air
fill 163 66 -446 199 66 -446 minecraft:air
fill 163 66 -445 199 66 -445 minecraft:air
fill 164 66 -444 197 66 -444 minecraft:air
fill 164 66 -443 197 66 -443 minecraft:air
fill 167 66 -442 193 66 -442 minecraft:air
setblock 195 66 -442 minecraft:air
fill 160 66 -441 161 66 -441 minecraft:air
setblock 163 66 -441 minecraft:air
fill 169 66 -441 192 66 -441 minecraft:air
fill 160 66 -440 161 66 -440 minecraft:air
fill 175 66 -440 187 66 -440 minecraft:air
fill 190 66 -440 191 66 -440 minecraft:air
setblock 162 66 -439 minecraft:air
setblock 177 66 -439 minecraft:air
setblock 180 66 -439 minecraft:air
fill 184 66 -439 185 66 -439 minecraft:air
fill 190 66 -439 191 66 -439 minecraft:air
setblock 182 66 -438 minecraft:air
setblock 173 66 -437 minecraft:air
setblock 183 66 -437 minecraft:air
setblock 142 66 -436 minecraft:oak_log
setblock 152 66 -436 minecraft:oak_log
setblock 162 66 -436 minecraft:oak_log
setblock 165 66 -436 minecraft:air
setblock 167 66 -436 minecraft:air
fill 169 66 -436 171 66 -436 minecraft:air
setblock 172 66 -436 minecraft:oak_log
setblock 182 66 -436 minecraft:oak_log
fill 184 66 -436 185 66 -436 minecraft:air
setblock 192 66 -436 minecraft:oak_log
fill 165 66 -435 166 66 -435 minecraft:air
fill 168 66 -435 172 66 -435 minecraft:air
fill 184 66 -435 185 66 -435 minecraft:air
fill 165 66 -434 169 66 -434 minecraft:air
setblock 171 66 -434 minecraft:air
setblock 173 66 -434 minecraft:air
setblock 176 66 -434 minecraft:air
setblock 185 66 -434 minecraft:air
setblock 165 66 -433 minecraft:air
fill 167 66 -433 169 66 -433 minecraft:air
fill 176 66 -433 178 66 -433 minecraft:air
fill 166 66 -432 169 66 -432 minecraft:air
fill 177 66 -432 178 66 -432 minecraft:air
setblock 182 66 -432 minecraft:air
setblock 179 66 -431 minecraft:air
setblock 197 66 -392 minecraft:air
setblock 196 66 -389 minecraft:air
setblock 189 66 -388 minecraft:air
setblock 185 66 -386 minecraft:air
setblock 198 66 -386 minecraft:air
setblock 187 66 -385 minecraft:air
setblock 191 66 -384 minecraft:air
setblock 181 66 -383 minecraft:air
fill 158 67 -446 159 67 -446 minecraft:air
fill 164 67 -446 196 67 -446 minecraft:air
fill 198 67 -446 199 67 -446 minecraft:air
fill 165 67 -445 199 67 -445 minecraft:air
setblock 166 67 -444 minecraft:air
fill 168 67 -444 193 67 -444 minecraft:air
setblock 195 67 -444 minecraft:air
setblock 197 67 -444 minecraft:air
fill 170 67 -443 192 67 -443 minecraft:air
setblock 197 67 -443 minecraft:air
fill 169 67 -442 170 67 -442 minecraft:air
fill 173 67 -442 190 67 -442 minecraft:air
fill 160 67 -441 161 67 -441 minecraft:air
setblock 163 67 -441 minecraft:air
fill 169 67 -441 170 67 -441 minecraft:air
fill 176 67 -441 183 67 -441 minecraft:air
fill 160 67 -440 161 67 -440 minecraft:air
fill 179 67 -440 180 67 -440 minecraft:air
fill 184 67 -440 185 67 -440 minecraft:air
fill 190 67 -440 191 67 -440 minecraft:air
setblock 162 67 -439 minecraft:air
fill 184 67 -439 185 67 -439 minecraft:air
fill 190 67 -439 191 67 -439 minecraft:air
setblock 171 67 -437 minecraft:air
setblock 173 67 -437 minecraft:air
setblock 183 67 -437 minecraft:air
setblock 142 67 -436 minecraft:oak_log
setblock 152 67 -436 minecraft:oak_log
setblock 162 67 -436 minecraft:oak_log
fill 167 67 -436 169 67 -436 minecraft:air
setblock 171 67 -436 minecraft:air
setblock 172 67 -436 minecraft:oak_log
setblock 182 67 -436 minecraft:oak_log
fill 184 67 -436 186 67 -436 minecraft:air
setblock 192 67 -436 minecraft:oak_log
fill 166 67 -435 172 67 -435 minecraft:air
fill 184 67 -435 185 67 -435 minecraft:air
fill 166 67 -434 171 67 -434 minecraft:air
setblock 173 67 -434 minecraft:air
fill 176 67 -434 177 67 -434 minecraft:air
fill 181 67 -434 183 67 -434 minecraft:air
setblock 185 67 -434 minecraft:air
setblock 165 67 -433 minecraft:air
fill 167 67 -433 170 67 -433 minecraft:air
setblock 176 67 -433 minecraft:air
fill 180 67 -433 184 67 -433 minecraft:air
setblock 166 67 -432 minecraft:air
fill 168 67 -432 170 67 -432 minecraft:air
fill 177 67 -432 184 67 -432 minecraft:air
fill 176 67 -431 184 67 -431 minecraft:air
fill 181 67 -430 184 67 -430 minecraft:air
setblock 197 67 -392 minecraft:air
setblock 196 67 -389 minecraft:air
setblock 189 67 -388 minecraft:air
setblock 185 67 -386 minecraft:air
setblock 198 67 -386 minecraft:air
setblock 187 67 -385 minecraft:air
setblock 191 67 -384 minecraft:air
setblock 181 67 -383 minecraft:air
fill 158 68 -446 160 68 -446 minecraft:air
setblock 165 68 -446 minecraft:air
setblock 167 68 -446 minecraft:air
fill 169 68 -446 194 68 -446 minecraft:air
setblock 196 68 -446 minecraft:air
setblock 159 68 -445 minecraft:air
setblock 167 68 -445 minecraft:air
fill 170 68 -445 192 68 -445 minecraft:air
setblock 195 68 -445 minecraft:air
fill 171 68 -444 190 68 -444 minecraft:air
fill 175 68 -443 187 68 -443 minecraft:air
setblock 197 68 -443 minecraft:air
setblock 159 68 -442 minecraft:air
fill 169 68 -442 170 68 -442 minecraft:air
fill 161 68 -441 163 68 -441 minecraft:air
fill 169 68 -441 170 68 -441 minecraft:air
fill 179 68 -441 180 68 -441 minecraft:air
fill 161 68 -440 162 68 -440 minecraft:air
fill 179 68 -440 180 68 -440 minecraft:air
fill 184 68 -440 185 68 -440 minecraft:air
fill 190 68 -440 191 68 -440 minecraft:air
fill 161 68 -439 162 68 -439 minecraft:air
fill 170 68 -439 174 68 -439 minecraft:air
fill 182 68 -439 185 68 -439 minecraft:air
fill 190 68 -439 191 68 -439 minecraft:air
fill 169 68 -438 175 68 -438 minecraft:air
fill 181 68 -438 187 68 -438 minecraft:air
fill 169 68 -437 175 68 -437 minecraft:air
fill 181 68 -437 188 68 -437 minecraft:air
setblock 142 68 -436 minecraft:oak_log
setblock 152 68 -436 minecraft:oak_log
setblock 162 68 -436 minecraft:oak_log
fill 167 68 -436 171 68 -436 minecraft:air
setblock 172 68 -436 minecraft:oak_log
fill 173 68 -436 175 68 -436 minecraft:air
setblock 181 68 -436 minecraft:air
setblock 182 68 -436 minecraft:oak_log
fill 183 68 -436 188 68 -436 minecraft:air
setblock 192 68 -436 minecraft:oak_log
fill 167 68 -435 178 68 -435 minecraft:air
fill 182 68 -435 188 68 -435 minecraft:air
fill 166 68 -434 187 68 -434 minecraft:air
fill 166 68 -433 187 68 -433 minecraft:air
fill 166 68 -432 186 68 -432 minecraft:air
fill 174 68 -431 184 68 -431 minecraft:air
fill 174 68 -430 183 68 -430 minecraft:air
fill 174 68 -429 181 68 -429 minecraft:air
fill 175 68 -428 180 68 -428 minecraft:air
setblock 197 68 -392 minecraft:air
setblock 196 68 -389 minecraft:air
setblock 189 68 -388 minecraft:air
setblock 185 68 -386 minecraft:air
setblock 198 68 -386 minecraft:air
setblock 187 68 -385 minecraft:air
setblock 191 68 -384 minecraft:air
setblock 181 68 -383 minecraft:air
fill 157 69 -446 160 69 -446 minecraft:air
setblock 169 69 -446 minecraft:air
fill 174 69 -446 178 69 -446 minecraft:air
setblock 184 69 -446 minecraft:air
setblock 159 69 -445 minecraft:air
fill 187 69 -445 188 69 -445 minecraft:air
fill 160 69 -444 162 69 -444 minecraft:air
fill 187 69 -444 188 69 -444 minecraft:air
setblock 198 69 -444 minecraft:air
fill 159 69 -443 165 69 -443 minecraft:air
setblock 171 69 -443 minecraft:air
fill 197 69 -443 199 69 -443 minecraft:air
fill 159 69 -442 165 69 -442 minecraft:air
fill 169 69 -442 170 69 -442 minecraft:air
setblock 178 69 -442 minecraft:air
fill 180 69 -442 181 69 -442 minecraft:air
setblock 198 69 -442 minecraft:air
fill 159 69 -441 165 69 -441 minecraft:air
fill 169 69 -441 170 69 -441 minecraft:air
fill 179 69 -441 180 69 -441 minecraft:air
fill 160 69 -440 166 69 -440 minecraft:air
fill 179 69 -440 180 69 -440 minecraft:air
fill 183 69 -440 185 69 -440 minecraft:air
fill 190 69 -440 191 69 -440 minecraft:air
fill 160 69 -439 166 69 -439 minecraft:air
fill 169 69 -439 173 69 -439 minecraft:air
setblock 179 69 -439 minecraft:air
fill 182 69 -439 186 69 -439 minecraft:air
fill 189 69 -439 192 69 -439 minecraft:air
setblock 142 69 -438 minecraft:oak_leaves[persistent=true]
setblock 152 69 -438 minecraft:oak_leaves[persistent=true]
fill 160 69 -438 161 69 -438 minecraft:air
setblock 162 69 -438 minecraft:oak_leaves[persistent=true]
fill 163 69 -438 166 69 -438 minecraft:air
fill 168 69 -438 171 69 -438 minecraft:air
setblock 172 69 -438 minecraft:oak_leaves[persistent=true]
fill 173 69 -438 175 69 -438 minecraft:air
setblock 181 69 -438 minecraft:air
setblock 182 69 -438 minecraft:oak_leaves[persistent=true]
fill 183 69 -438 188 69 -438 minecraft:air
setblock 192 69 -438 minecraft:oak_leaves[persistent=true]
fill 141 69 -437 143 69 -437 minecraft:oak_leaves[persistent=true]
fill 151 69 -437 153 69 -437 minecraft:oak_leaves[persistent=true]
fill 161 69 -437 163 69 -437 minecraft:oak_leaves[persistent=true]
fill 164 69 -437 165 69 -437 minecraft:air
fill 168 69 -437 170 69 -437 minecraft:air
fill 171 69 -437 173 69 -437 minecraft:oak_leaves[persistent=true]
fill 174 69 -437 175 69 -437 minecraft:air
fill 181 69 -437 183 69 -437 minecraft:oak_leaves[persistent=true]
fill 184 69 -437 188 69 -437 minecraft:air
fill 191 69 -437 193 69 -437 minecraft:oak_leaves[persistent=true]
fill 140 69 -436 141 69 -436 minecraft:oak_leaves[persistent=true]
setblock 142 69 -436 minecraft:oak_log
fill 143 69 -436 144 69 -436 minecraft:oak_leaves[persistent=true]
fill 150 69 -436 151 69 -436 minecraft:oak_leaves[persistent=true]
setblock 152 69 -436 minecraft:oak_log
fill 153 69 -436 154 69 -436 minecraft:oak_leaves[persistent=true]
fill 160 69 -436 161 69 -436 minecraft:oak_leaves[persistent=true]
setblock 162 69 -436 minecraft:oak_log
fill 163 69 -436 164 69 -436 minecraft:oak_leaves[persistent=true]
fill 168 69 -436 169 69 -436 minecraft:air
fill 170 69 -436 171 69 -436 minecraft:oak_leaves[persistent=true]
setblock 172 69 -436 minecraft:oak_log
fill 173 69 -436 174 69 -436 minecraft:oak_leaves[persistent=true]
setblock 175 69 -436 minecraft:air
fill 180 69 -436 181 69 -436 minecraft:oak_leaves[persistent=true]
setblock 182 69 -436 minecraft:oak_log
fill 183 69 -436 184 69 -436 minecraft:oak_leaves[persistent=true]
fill 185 69 -436 188 69 -436 minecraft:air
fill 190 69 -436 191 69 -436 minecraft:oak_leaves[persistent=true]
setblock 192 69 -436 minecraft:oak_log
fill 193 69 -436 194 69 -436 minecraft:oak_leaves[persistent=true]
fill 141 69 -435 143 69 -435 minecraft:oak_leaves[persistent=true]
fill 151 69 -435 153 69 -435 minecraft:oak_leaves[persistent=true]
fill 161 69 -435 163 69 -435 minecraft:oak_leaves[persistent=true]
fill 166 69 -435 170 69 -435 minecraft:air
fill 171 69 -435 173 69 -435 minecraft:oak_leaves[persistent=true]
fill 174 69 -435 179 69 -435 minecraft:air
fill 181 69 -435 183 69 -435 minecraft:oak_leaves[persistent=true]
fill 184 69 -435 188 69 -435 minecraft:air
fill 191 69 -435 193 69 -435 minecraft:oak_leaves[persistent=true]
setblock 142 69 -434 minecraft:oak_leaves[persistent=true]
setblock 152 69 -434 minecraft:oak_leaves[persistent=true]
setblock 162 69 -434 minecraft:oak_leaves[persistent=true]
fill 166 69 -434 171 69 -434 minecraft:air
setblock 172 69 -434 minecraft:oak_leaves[persistent=true]
fill 173 69 -434 181 69 -434 minecraft:air
setblock 182 69 -434 minecraft:oak_leaves[persistent=true]
fill 183 69 -434 188 69 -434 minecraft:air
setblock 192 69 -434 minecraft:oak_leaves[persistent=true]
setblock 167 69 -433 minecraft:air
fill 169 69 -433 186 69 -433 minecraft:air
fill 168 69 -432 186 69 -432 minecraft:air
fill 174 69 -431 183 69 -431 minecraft:air
fill 174 69 -430 181 69 -430 minecraft:air
fill 175 69 -429 180 69 -429 minecraft:air
fill 175 69 -428 179 69 -428 minecraft:air
setblock 199 69 -400 minecraft:air
fill 198 69 -399 199 69 -399 minecraft:air
setblock 199 69 -398 minecraft:air
setblock 197 69 -392 minecraft:air
setblock 189 69 -390 minecraft:air
fill 188 69 -389 190 69 -389 minecraft:air
setblock 196 69 -389 minecraft:air
setblock 185 69 -388 minecraft:air
fill 187 69 -388 191 69 -388 minecraft:air
fill 184 69 -387 186 69 -387 minecraft:air
fill 188 69 -387 190 69 -387 minecraft:air
fill 183 69 -386 187 69 -386 minecraft:air
setblock 189 69 -386 minecraft:air
setblock 198 69 -386 minecraft:air
fill 184 69 -385 187 69 -385 minecraft:air
setblock 185 69 -384 minecraft:air
setblock 191 69 -384 minecraft:air
setblock 181 69 -383 minecraft:air
fill 157 70 -446 160 70 -446 minecraft:air
setblock 169 70 -446 minecraft:air
setblock 175 70 -446 minecraft:air
fill 159 70 -445 160 70 -445 minecraft:air
fill 187 70 -445 188 70 -445 minecraft:air
fill 160 70 -444 164 70 -444 minecraft:air
fill 187 70 -444 188 70 -444 minecraft:air
fill 159 70 -443 166 70 -443 minecraft:air
setblock 171 70 -443 minecraft:air
fill 197 70 -443 198 70 -443 minecraft:air
fill 159 70 -442 166 70 -442 minecraft:air
fill 169 70 -442 170 70 -442 minecraft:air
setblock 178 70 -442 minecraft:air
fill 180 70 -442 181 70 -442 minecraft:air
fill 159 70 -441 166 70 -441 minecraft:air
fill 169 70 -441 170 70 -441 minecraft:air
fill 179 70 -441 181 70 -441 minecraft:air
fill 159 70 -440 166 70 -440 minecraft:air
fill 179 70 -440 180 70 -440 minecraft:air
fill 183 70 -440 185 70 -440 minecraft:air
fill 190 70 -440 191 70 -440 minecraft:air
fill 159 70 -439 166 70 -439 minecraft:air
setblock 179 70 -439 minecraft:air
fill 184 70 -439 185 70 -439 minecraft:air
fill 189 70 -439 192 70 -439 minecraft:air
fill 141 70 -438 143 70 -438 minecraft:oak_leaves[persistent=true]
fill 151 70 -438 153 70 -438 minecraft:oak_leaves[persistent=true]
setblock 160 70 -438 minecraft:air
fill 161 70 -438 163 70 -438 minecraft:oak_leaves[persistent=true]
fill 164 70 -438 165 70 -438 minecraft:air
fill 171 70 -438 173 70 -438 minecraft:oak_leaves[persistent=true]
fill 181 70 -438 183 70 -438 minecraft:oak_leaves[persistent=true]
fill 184 70 -438 186 70 -438 minecraft:air
fill 191 70 -438 193 70 -438 minecraft:oak_leaves[persistent=true]
fill 140 70 -437 144 70 -437 minecraft:oak_leaves[persistent=true]
fill 150 70 -437 154 70 -437 minecraft:oak_leaves[persistent=true]
fill 160 70 -437 164 70 -437 minecraft:oak_leaves[persistent=true]
fill 170 70 -437 174 70 -437 minecraft:oak_leaves[persistent=true]
fill 180 70 -437 184 70 -437 minecraft:oak_leaves[persistent=true]
fill 185 70 -437 186 70 -437 minecraft:air
fill 190 70 -437 194 70 -437 minecraft:oak_leaves[persistent=true]
fill 140 70 -436 141 70 -436 minecraft:oak_leaves[persistent=true]
setblock 142 70 -436 minecraft:oak_log
fill 143 70 -436 144 70 -436 minecraft:oak_leaves[persistent=true]
fill 150 70 -436 151 70 -436 minecraft:oak_leaves[persistent=true]
setblock 152 70 -436 minecraft:oak_log
fill 153 70 -436 154 70 -436 minecraft:oak_leaves[persistent=true]
fill 160 70 -436 161 70 -436 minecraft:oak_leaves[persistent=true]
setblock 162 70 -436 minecraft:oak_log
fill 163 70 -436 164 70 -436 minecraft:oak_leaves[persistent=true]
setblock 169 70 -436 minecraft:air
fill 170 70 -436 171 70 -436 minecraft:oak_leaves[persistent=true]
setblock 172 70 -436 minecraft:oak_log
fill 173 70 -436 174 70 -436 minecraft:oak_leaves[persistent=true]
fill 180 70 -436 181 70 -436 minecraft:oak_leaves[persistent=true]
setblock 182 70 -436 minecraft:oak_log
fill 183 70 -436 184 70 -436 minecraft:oak_leaves[persistent=true]
fill 185 70 -436 187 70 -436 minecraft:air
fill 190 70 -436 191 70 -436 minecraft:oak_leaves[persistent=true]
setblock 192 70 -436 minecraft:oak_log
fill 193 70 -436 194 70 -436 minecraft:oak_leaves[persistent=true]
fill 140 70 -435 144 70 -435 minecraft:oak_leaves[persistent=true]
fill 150 70 -435 154 70 -435 minecraft:oak_leaves[persistent=true]
fill 160 70 -435 164 70 -435 minecraft:oak_leaves[persistent=true]
setblock 169 70 -435 minecraft:air
fill 170 70 -435 174 70 -435 minecraft:oak_leaves[persistent=true]
fill 180 70 -435 184 70 -435 minecraft:oak_leaves[persistent=true]
fill 185 70 -435 187 70 -435 minecraft:air
fill 190 70 -435 194 70 -435 minecraft:oak_leaves[persistent=true]
fill 141 70 -434 143 70 -434 minecraft:oak_leaves[persistent=true]
fill 151 70 -434 153 70 -434 minecraft:oak_leaves[persistent=true]
fill 161 70 -434 163 70 -434 minecraft:oak_leaves[persistent=true]
setblock 170 70 -434 minecraft:air
fill 171 70 -434 173 70 -434 minecraft:oak_leaves[persistent=true]
fill 177 70 -434 178 70 -434 minecraft:air
fill 181 70 -434 183 70 -434 minecraft:oak_leaves[persistent=true]
fill 184 70 -434 186 70 -434 minecraft:air
fill 191 70 -434 193 70 -434 minecraft:oak_leaves[persistent=true]
fill 171 70 -433 172 70 -433 minecraft:air
fill 176 70 -433 179 70 -433 minecraft:air
setblock 182 70 -433 minecraft:air
fill 184 70 -433 185 70 -433 minecraft:air
fill 175 70 -432 183 70 -432 minecraft:air
fill 175 70 -431 180 70 -431 minecraft:air
setblock 182 70 -431 minecraft:air
fill 176 70 -430 179 70 -430 minecraft:air
fill 177 70 -429 178 70 -429 minecraft:air
setblock 199 70 -400 minecraft:air
setblock 199 70 -399 minecraft:air
setblock 199 70 -398 minecraft:air
setblock 197 70 -392 minecraft:air
fill 188 70 -389 190 70 -389 minecraft:air
setblock 196 70 -389 minecraft:air
fill 188 70 -388 190 70 -388 minecraft:air
setblock 198 70 -388 minecraft:air
fill 184 70 -387 186 70 -387 minecraft:air
fill 188 70 -387 190 70 -387 minecraft:air
fill 197 70 -387 199 70 -387 minecraft:air
fill 184 70 -386 186 70 -386 minecraft:air
fill 196 70 -386 199 70 -386 minecraft:air
setblock 181 70 -385 minecraft:air
fill 184 70 -385 187 70 -385 minecraft:air
fill 197 70 -385 199 70 -385 minecraft:air
fill 180 70 -384 182 70 -384 minecraft:air
setblock 191 70 -384 minecraft:air
setblock 198 70 -384 minecraft:air
fill 179 70 -383 183 70 -383 minecraft:air
fill 155 71 -446 162 71 -446 minecraft:air
setblock 169 71 -446 minecraft:air
setblock 175 71 -446 minecraft:air
setblock 199 71 -446 minecraft:air
fill 155 71 -445 162 71 -445 minecraft:air
fill 187 71 -445 188 71 -445 minecraft:air
fill 156 71 -444 162 71 -444 minecraft:air
fill 187 71 -444 188 71 -444 minecraft:air
setblock 197 71 -444 minecraft:air
fill 158 71 -443 163 71 -443 minecraft:air
setblock 171 71 -443 minecraft:air
fill 196 71 -443 198 71 -443 minecraft:air
fill 161 71 -442 164 71 -442 minecraft:air
fill 169 71 -442 170 71 -442 minecraft:air
setblock 178 71 -442 minecraft:air
fill 180 71 -442 181 71 -442 minecraft:air
fill 195 71 -442 199 71 -442 minecraft:air
fill 160 71 -441 165 71 -441 minecraft:air
fill 169 71 -441 170 71 -441 minecraft:air
fill 179 71 -441 181 71 -441 minecraft:air
setblock 192 71 -441 minecraft:air
fill 196 71 -441 198 71 -441 minecraft:air
fill 160 71 -440 165 71 -440 minecraft:air
fill 179 71 -440 180 71 -440 minecraft:air
fill 183 71 -440 185 71 -440 minecraft:air
fill 190 71 -440 191 71 -440 minecraft:air
setblock 197 71 -440 minecraft:air
fill 161 71 -439 164 71 -439 minecraft:air
setblock 179 71 -439 minecraft:air
fill 184 71 -439 185 71 -439 minecraft:air
fill 189 71 -439 192 71 -439 minecraft:air
setblock 142 71 -438 minecraft:oak_leaves[persistent=true]
setblock 152 71 -438 minecraft:oak_leaves[persistent=true]
setblock 162 71 -438 minecraft:oak_leaves[persistent=true]
setblock 163 71 -438 minecraft:air
setblock 172 71 -438 minecraft:oak_leaves[persistent=true]
setblock 182 71 -438 minecraft:oak_leaves[persistent=true]
setblock 183 71 -438 minecraft:air
setblock 186 71 -438 minecraft:air
setblock 190 71 -438 minecraft:air
setblock 192 71 -438 minecraft:oak_leaves[persistent=true]
fill 141 71 -437 143 71 -437 minecraft:oak_leaves[persistent=true]
fill 151 71 -437 153 71 -437 minecraft:oak_leaves[persistent=true]
fill 161 71 -437 163 71 -437 minecraft:oak_leaves[persistent=true]
fill 171 71 -437 173 71 -437 minecraft:oak_leaves[persistent=true]
fill 181 71 -437 183 71 -437 minecraft:oak_leaves[persistent=true]
fill 191 71 -437 193 71 -437 minecraft:oak_leaves[persistent=true]
fill 140 71 -436 144 71 -436 minecraft:oak_leaves[persistent=true]
fill 150 71 -436 154 71 -436 minecraft:oak_leaves[persistent=true]
fill 160 71 -436 164 71 -436 minecraft:oak_leaves[persistent=true]
fill 170 71 -436 174 71 -436 minecraft:oak_leaves[persistent=true]
fill 180 71 -436 184 71 -436 minecraft:oak_leaves[persistent=true]
fill 190 71 -436 194 71 -436 minecraft:oak_leaves[persistent=true]
fill 141 71 -435 143 71 -435 minecraft:oak_leaves[persistent=true]
fill 151 71 -435 153 71 -435 minecraft:oak_leaves[persistent=true]
fill 161 71 -435 163 71 -435 minecraft:oak_leaves[persistent=true]
fill 171 71 -435 173 71 -435 minecraft:oak_leaves[persistent=true]
fill 181 71 -435 183 71 -435 minecraft:oak_leaves[persistent=true]
fill 191 71 -435 193 71 -435 minecraft:oak_leaves[persistent=true]
setblock 142 71 -434 minecraft:oak_leaves[persistent=true]
setblock 152 71 -434 minecraft:oak_leaves[persistent=true]
setblock 162 71 -434 minecraft:oak_leaves[persistent=true]
setblock 172 71 -434 minecraft:oak_leaves[persistent=true]
setblock 182 71 -434 minecraft:oak_leaves[persistent=true]
setblock 192 71 -434 minecraft:oak_leaves[persistent=true]
fill 177 71 -432 178 71 -432 minecraft:air
fill 177 71 -431 178 71 -431 minecraft:air
setblock 199 71 -399 minecraft:air
setblock 197 71 -394 minecraft:air
fill 196 71 -393 198 71 -393 minecraft:air
fill 195 71 -392 199 71 -392 minecraft:air
fill 196 71 -391 198 71 -391 minecraft:air
fill 195 71 -390 197 71 -390 minecraft:air
setblock 189 71 -389 minecraft:air
fill 194 71 -389 198 71 -389 minecraft:air
fill 188 71 -388 190 71 -388 minecraft:air
fill 195 71 -388 197 71 -388 minecraft:air
setblock 185 71 -387 minecraft:air
setblock 187 71 -387 minecraft:air
setblock 189 71 -387 minecraft:air
fill 196 71 -387 199 71 -387 minecraft:air
fill 184 71 -386 188 71 -386 minecraft:air
setblock 191 71 -386 minecraft:air
fill 197 71 -386 199 71 -386 minecraft:air
fill 185 71 -385 192 71 -385 minecraft:air
fill 197 71 -385 199 71 -385 minecraft:air
fill 180 71 -384 182 71 -384 minecraft:air
fill 186 71 -384 193 71 -384 minecraft:air
fill 180 71 -383 182 71 -383 minecraft:air
setblock 187 71 -383 minecraft:air
fill 190 71 -383 192 71 -383 minecraft:air
fill 155 72 -446 162 72 -446 minecraft:air
setblock 169 72 -446 minecraft:air
setblock 175 72 -446 minecraft:air
setblock 199 72 -446 minecraft:air
fill 155 72 -445 162 72 -445 minecraft:air
fill 170 72 -445 172 72 -445 minecraft:air
fill 187 72 -445 189 72 -445 minecraft:air
fill 156 72 -444 161 72 -444 minecraft:air
fill 167 72 -444 173 72 -444 minecraft:air
fill 177 72 -444 182 72 -444 minecraft:air
fill 187 72 -444 188 72 -444 minecraft:air
setblock 197 72 -444 minecraft:air
fill 156 72 -443 160 72 -443 minecraft:air
fill 167 72 -443 173 72 -443 minecraft:air
fill 176 72 -443 183 72 -443 minecraft:air
fill 191 72 -443 193 72 -443 minecraft:air
fill 196 72 -443 198 72 -443 minecraft:air
fill 162 72 -442 164 72 -442 minecraft:air
fill 167 72 -442 173 72 -442 minecraft:air
fill 176 72 -442 194 72 -442 minecraft:air
fill 196 72 -442 198 72 -442 minecraft:air
fill 162 72 -441 164 72 -441 minecraft:air
fill 167 72 -441 172 72 -441 minecraft:air
fill 176 72 -441 194 72 -441 minecraft:air
fill 196 72 -441 198 72 -441 minecraft:air
fill 162 72 -440 164 72 -440 minecraft:air
fill 167 72 -440 172 72 -440 minecraft:air
fill 177 72 -440 194 72 -440 minecraft:air
fill 167 72 -439 172 72 -439 minecraft:air
fill 177 72 -439 194 72 -439 minecraft:air
fill 177 72 -438 194 72 -438 minecraft:air
fill 178 72 -437 193 72 -437 minecraft:air
setblock 142 72 -436 minecraft:oak_leaves[persistent=true]
setblock 152 72 -436 minecraft:oak_leaves[persistent=true]
setblock 162 72 -436 minecraft:oak_leaves[persistent=true]
setblock 172 72 -436 minecraft:oak_leaves[persistent=true]
setblock 182 72 -436 minecraft:oak_leaves[persistent=true]
fill 183 72 -436 187 72 -436 minecraft:air
fill 189 72 -436 191 72 -436 minecraft:air
setblock 192 72 -436 minecraft:oak_leaves[persistent=true]
fill 196 72 -393 198 72 -393 minecraft:air
fill 196 72 -392 198 72 -392 minecraft:air
fill 196 72 -391 198 72 -391 minecraft:air
fill 195 72 -390 197 72 -390 minecraft:air
fill 195 72 -389 197 72 -389 minecraft:air
fill 189 72 -388 190 72 -388 minecraft:air
fill 195 72 -388 197 72 -388 minecraft:air
setblock 185 72 -387 minecraft:air
setblock 198 72 -387 minecraft:air
fill 184 72 -386 188 72 -386 minecraft:air
fill 197 72 -386 199 72 -386 minecraft:air
fill 186 72 -385 188 72 -385 minecraft:air
fill 190 72 -385 192 72 -385 minecraft:air
setblock 198 72 -385 minecraft:air
setblock 181 72 -384 minecraft:air
fill 186 72 -384 188 72 -384 minecraft:air
fill 190 72 -384 192 72 -384 minecraft:air
fill 180 72 -383 182 72 -383 minecraft:air
fill 190 72 -383 192 72 -383 minecraft:air
fill 156 73 -446 161 73 -446 minecraft:air
fill 167 73 -446 171 73 -446 minecraft:air
setblock 175 73 -446 minecraft:air
setblock 188 73 -446 minecraft:air
fill 157 73 -445 160 73 -445 minecraft:air
fill 167 73 -445 171 73 -445 minecraft:air
fill 186 73 -445 189 73 -445 minecraft:air
fill 158 73 -444 159 73 -444 minecraft:air
fill 166 73 -444 173 73 -444 minecraft:air
fill 177 73 -444 181 73 -444 minecraft:air
fill 187 73 -444 188 73 -444 minecraft:air
setblock 197 73 -444 minecraft:air
fill 166 73 -443 173 73 -443 minecraft:air
fill 176 73 -443 192 73 -443 minecraft:air
setblock 197 73 -443 minecraft:air
setblock 163 73 -442 minecraft:air
fill 166 73 -442 173 73 -442 minecraft:air
fill 176 73 -442 194 73 -442 minecraft:air
fill 196 73 -442 198 73 -442 minecraft:air
fill 162 73 -441 164 73 -441 minecraft:air
fill 166 73 -441 173 73 -441 minecraft:air
fill 176 73 -441 194 73 -441 minecraft:air
setblock 197 73 -441 minecraft:air
setblock 163 73 -440 minecraft:air
fill 166 73 -440 173 73 -440 minecraft:air
fill 176 73 -440 194 73 -440 minecraft:air
fill 167 73 -439 171 73 -439 minecraft:air
fill 176 73 -439 194 73 -439 minecraft:air
fill 167 73 -438 171 73 -438 minecraft:air
fill 177 73 -438 194 73 -438 minecraft:air
fill 177 73 -437 192 73 -437 minecraft:air
fill 182 73 -436 186 73 -436 minecraft:air
fill 188 73 -436 192 73 -436 minecraft:air
setblock 197 73 -393 minecraft:air
fill 196 73 -392 198 73 -392 minecraft:air
setblock 197 73 -391 minecraft:air
setblock 196 73 -390 minecraft:air
fill 195 73 -389 197 73 -389 minecraft:air
setblock 196 73 -388 minecraft:air
setblock 198 73 -387 minecraft:air
setblock 187 73 -386 minecraft:air
fill 198 73 -386 199 73 -386 minecraft:air
fill 186 73 -385 188 73 -385 minecraft:air
setblock 191 73 -385 minecraft:air
setblock 181 73 -384 minecraft:air
setblock 187 73 -384 minecraft:air
fill 190 73 -384 192 73 -384 minecraft:air
setblock 181 73 -383 minecraft:air
setblock 191 73 -383 minecraft:air
fill 158 74 -446 159 74 -446 minecraft:air
fill 167 74 -446 171 74 -446 minecraft:air
fill 173 74 -446 177 74 -446 minecraft:air
setblock 186 74 -446 minecraft:air
setblock 188 74 -446 minecraft:air
fill 194 74 -446 199 74 -446 minecraft:air
fill 167 74 -445 171 74 -445 minecraft:air
fill 173 74 -445 177 74 -445 minecraft:air
fill 186 74 -445 189 74 -445 minecraft:air
fill 195 74 -445 199 74 -445 minecraft:air
fill 168 74 -444 171 74 -444 minecraft:air
fill 174 74 -444 176 74 -444 minecraft:air
fill 187 74 -444 188 74 -444 minecraft:air
fill 195 74 -444 199 74 -444 minecraft:air
fill 168 74 -443 171 74 -443 minecraft:air
fill 179 74 -443 180 74 -443 minecraft:air
setblock 187 74 -443 minecraft:air
setblock 189 74 -443 minecraft:air
fill 196 74 -443 198 74 -443 minecraft:air
fill 167 74 -442 172 74 -442 minecraft:air
fill 178 74 -442 181 74 -442 minecraft:air
fill 184 74 -442 185 74 -442 minecraft:air
fill 190 74 -442 191 74 -442 minecraft:air
setblock 197 74 -442 minecraft:air
fill 162 74 -441 163 74 -441 minecraft:air
fill 167 74 -441 172 74 -441 minecraft:air
fill 177 74 -441 186 74 -441 minecraft:air
fill 189 74 -441 192 74 -441 minecraft:air
setblock 197 74 -441 minecraft:air
setblock 163 74 -440 minecraft:air
fill 168 74 -440 171 74 -440 minecraft:air
fill 177 74 -440 193 74 -440 minecraft:air
fill 169 74 -439 170 74 -439 minecraft:air
fill 178 74 -439 193 74 -439 minecraft:air
fill 179 74 -438 180 74 -438 minecraft:air
fill 183 74 -438 186 74 -438 minecraft:air
fill 189 74 -438 192 74 -438 minecraft:air
fill 184 74 -437 185 74 -437 minecraft:air
fill 190 74 -437 191 74 -437 minecraft:air
setblock 197 74 -393 minecraft:air
fill 197 74 -392 198 74 -392 minecraft:air
fill 195 74 -389 196 74 -389 minecraft:air
setblock 196 74 -388 minecraft:air
setblock 187 74 -386 minecraft:air
fill 186 74 -385 187 74 -385 minecraft:air
setblock 191 74 -384 minecraft:air
setblock 191 74 -383 minecraft:air
fill 168 75 -446 170 75 -446 minecraft:air
fill 173 75 -446 177 75 -446 minecraft:air
fill 184 75 -446 191 75 -446 minecraft:air
fill 195 75 -446 199 75 -446 minecraft:air
fill 168 75 -445 169 75 -445 minecraft:air
fill 173 75 -445 177 75 -445 minecraft:air
fill 184 75 -445 191 75 -445 minecraft:air
fill 195 75 -445 199 75 -445 minecraft:air
fill 174 75 -444 177 75 -444 minecraft:air
fill 184 75 -444 191 75 -444 minecraft:air
fill 196 75 -444 198 75 -444 minecraft:air
fill 185 75 -443 191 75 -443 minecraft:air
fill 196 75 -443 198 75 -443 minecraft:air
fill 185 75 -442 191 75 -442 minecraft:air
fill 179 75 -441 180 75 -441 minecraft:air
fill 186 75 -441 190 75 -441 minecraft:air
fill 179 75 -440 180 75 -440 minecraft:air
fill 184 75 -440 185 75 -440 minecraft:air
fill 190 75 -440 191 75 -440 minecraft:air
fill 184 75 -439 185 75 -439 minecraft:air
fill 190 75 -439 191 75 -439 minecraft:air
fill 168 76 -446 170 76 -446 minecraft:air
fill 174 76 -446 176 76 -446 minecraft:air
fill 184 76 -446 191 76 -446 minecraft:air
fill 197 76 -446 198 76 -446 minecraft:air
setblock 169 76 -445 minecraft:air
fill 174 76 -445 176 76 -445 minecraft:air
fill 184 76 -445 191 76 -445 minecraft:air
setblock 197 76 -445 minecraft:air
fill 184 76 -444 191 76 -444 minecraft:air
fill 196 76 -444 198 76 -444 minecraft:air
fill 184 76 -443 191 76 -443 minecraft:air
setblock 197 76 -443 minecraft:air
fill 185 76 -442 190 76 -442 minecraft:air
fill 185 76 -441 189 76 -441 minecraft:air
fill 174 77 -446 176 77 -446 minecraft:air
fill 186 77 -446 189 77 -446 minecraft:air
setblock 175 77 -445 minecraft:air
fill 185 77 -445 190 77 -445 minecraft:air
setblock 197 77 -445 minecraft:air
fill 185 77 -444 190 77 -444 minecraft:air
fill 197 77 -444 198 77 -444 minecraft:air
fill 186 77 -443 189 77 -443 minecraft:air
fill 187 77 -442 188 77 -442 minecraft:air
fill 187 78 -445 188 78 -445 minecraft:air
fill 187 78 -444 188 78 -444 minecraft:air
forceload remove 136 -446 199 -383
tellraw @a {"text":"Campus bau a03 fertig.","color":"green"}
