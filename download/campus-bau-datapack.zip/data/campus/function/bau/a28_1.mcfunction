setblock 409 45 -252 minecraft:stone
setblock 416 45 -248 minecraft:stone
fill 412 45 -247 413 45 -247 minecraft:stone
setblock 406 45 -246 minecraft:stone
fill 410 45 -246 413 45 -246 minecraft:stone
setblock 406 45 -245 minecraft:stone
fill 409 45 -245 413 45 -245 minecraft:stone
setblock 406 45 -244 minecraft:stone
fill 408 45 -244 413 45 -244 minecraft:stone
fill 405 45 -243 413 45 -243 minecraft:stone
fill 405 45 -242 412 45 -242 minecraft:stone
fill 405 45 -241 412 45 -241 minecraft:stone
fill 404 45 -240 411 45 -240 minecraft:stone
fill 406 45 -239 410 45 -239 minecraft:stone
setblock 402 45 -238 minecraft:stone
fill 407 45 -238 409 45 -238 minecraft:stone
fill 401 45 -237 403 45 -237 minecraft:stone
fill 400 45 -236 405 45 -236 minecraft:stone
fill 400 45 -235 406 45 -235 minecraft:stone
fill 399 45 -234 407 45 -234 minecraft:stone
fill 399 45 -233 407 45 -233 minecraft:stone
fill 398 45 -232 407 45 -232 minecraft:stone
fill 399 45 -231 406 45 -231 minecraft:stone
fill 399 45 -230 406 45 -230 minecraft:stone
fill 399 45 -229 405 45 -229 minecraft:stone
fill 399 45 -228 405 45 -228 minecraft:stone
fill 399 45 -227 405 45 -227 minecraft:stone
fill 399 45 -226 404 45 -226 minecraft:stone
fill 397 45 -225 404 45 -225 minecraft:stone
fill 394 45 -224 404 45 -224 minecraft:stone
fill 393 45 -223 403 45 -223 minecraft:stone
fill 392 45 -222 403 45 -222 minecraft:stone
fill 392 45 -221 403 45 -221 minecraft:stone
fill 392 45 -220 402 45 -220 minecraft:stone
fill 392 45 -219 402 45 -219 minecraft:stone
fill 393 45 -218 402 45 -218 minecraft:stone
fill 393 45 -217 402 45 -217 minecraft:stone
fill 393 45 -216 401 45 -216 minecraft:stone
fill 393 45 -215 401 45 -215 minecraft:stone
fill 393 45 -214 401 45 -214 minecraft:stone
fill 394 45 -213 400 45 -213 minecraft:stone
fill 394 45 -212 400 45 -212 minecraft:stone
fill 394 45 -211 399 45 -211 minecraft:stone
fill 394 45 -210 399 45 -210 minecraft:stone
fill 394 45 -209 398 45 -209 minecraft:stone
fill 394 45 -208 398 45 -208 minecraft:stone
fill 394 45 -207 398 45 -207 minecraft:stone
fill 394 45 -206 397 45 -206 minecraft:stone
fill 394 45 -205 397 45 -205 minecraft:stone
fill 394 45 -204 397 45 -204 minecraft:stone
setblock 392 45 -203 minecraft:stone
fill 394 45 -203 397 45 -203 minecraft:stone
fill 392 45 -202 393 45 -202 minecraft:stone
fill 395 45 -202 396 45 -202 minecraft:stone
fill 392 45 -201 393 45 -201 minecraft:stone
fill 395 45 -201 396 45 -201 minecraft:stone
fill 392 45 -200 393 45 -200 minecraft:stone
fill 395 45 -200 396 45 -200 minecraft:stone
fill 392 45 -199 394 45 -199 minecraft:stone
setblock 396 45 -199 minecraft:stone
fill 392 45 -198 394 45 -198 minecraft:stone
fill 392 45 -197 394 45 -197 minecraft:stone
fill 392 45 -196 394 45 -196 minecraft:stone
fill 392 45 -195 394 45 -195 minecraft:stone
fill 392 45 -194 395 45 -194 minecraft:stone
fill 392 45 -193 395 45 -193 minecraft:stone
fill 392 45 -192 394 45 -192 minecraft:stone
fill 408 46 -253 409 46 -253 minecraft:stone
fill 408 46 -252 409 46 -252 minecraft:stone
setblock 407 46 -249 minecraft:stone
setblock 407 46 -248 minecraft:stone
fill 406 46 -247 407 46 -247 minecraft:stone
fill 406 46 -246 407 46 -246 minecraft:stone
setblock 412 46 -246 minecraft:stone
fill 406 46 -245 407 46 -245 minecraft:stone
fill 411 46 -245 412 46 -245 minecraft:stone
fill 405 46 -244 407 46 -244 minecraft:stone
fill 409 46 -244 413 46 -244 minecraft:stone
fill 405 46 -243 406 46 -243 minecraft:stone
fill 408 46 -243 412 46 -243 minecraft:stone
fill 405 46 -242 412 46 -242 minecraft:stone
fill 405 46 -241 411 46 -241 minecraft:stone
fill 407 46 -240 410 46 -240 minecraft:stone
setblock 403 46 -239 minecraft:stone
setblock 409 46 -239 minecraft:stone
fill 402 46 -238 404 46 -238 minecraft:stone
fill 401 46 -237 406 46 -237 minecraft:stone
fill 400 46 -236 408 46 -236 minecraft:stone
fill 399 46 -235 408 46 -235 minecraft:stone
fill 399 46 -234 408 46 -234 minecraft:stone
fill 398 46 -233 407 46 -233 minecraft:stone
fill 397 46 -232 407 46 -232 minecraft:stone
fill 399 46 -231 406 46 -231 minecraft:stone
fill 399 46 -230 406 46 -230 minecraft:stone
fill 399 46 -229 405 46 -229 minecraft:stone
fill 399 46 -228 405 46 -228 minecraft:stone
fill 399 46 -227 405 46 -227 minecraft:stone
fill 398 46 -226 404 46 -226 minecraft:stone
fill 397 46 -225 404 46 -225 minecraft:stone
fill 393 46 -224 404 46 -224 minecraft:stone
fill 392 46 -223 404 46 -223 minecraft:stone
fill 392 46 -222 403 46 -222 minecraft:stone
fill 392 46 -221 403 46 -221 minecraft:stone
fill 392 46 -220 403 46 -220 minecraft:stone
fill 392 46 -219 403 46 -219 minecraft:stone
fill 392 46 -218 403 46 -218 minecraft:stone
fill 392 46 -217 402 46 -217 minecraft:stone
fill 392 46 -216 402 46 -216 minecraft:stone
fill 393 46 -215 402 46 -215 minecraft:stone
fill 393 46 -214 402 46 -214 minecraft:stone
fill 393 46 -213 402 46 -213 minecraft:stone
fill 393 46 -212 402 46 -212 minecraft:stone
fill 393 46 -211 401 46 -211 minecraft:stone
fill 393 46 -210 400 46 -210 minecraft:stone
fill 392 46 -209 399 46 -209 minecraft:stone
fill 392 46 -208 399 46 -208 minecraft:stone
fill 392 46 -207 398 46 -207 minecraft:stone
fill 392 46 -206 398 46 -206 minecraft:stone
fill 392 46 -205 398 46 -205 minecraft:stone
fill 392 46 -204 398 46 -204 minecraft:stone
fill 392 46 -203 397 46 -203 minecraft:stone
fill 392 46 -202 397 46 -202 minecraft:stone
fill 392 46 -201 397 46 -201 minecraft:stone
fill 392 46 -200 397 46 -200 minecraft:stone
fill 393 46 -199 397 46 -199 minecraft:stone
fill 394 46 -198 396 46 -198 minecraft:stone
fill 394 46 -197 396 46 -197 minecraft:stone
fill 395 46 -196 396 46 -196 minecraft:stone
setblock 396 46 -195 minecraft:stone
fill 408 47 -253 409 47 -253 minecraft:stone
fill 408 47 -252 409 47 -252 minecraft:stone
setblock 407 47 -250 minecraft:stone
setblock 407 47 -249 minecraft:stone
fill 407 47 -248 408 47 -248 minecraft:stone
fill 406 47 -247 408 47 -247 minecraft:stone
fill 406 47 -246 407 47 -246 minecraft:stone
fill 406 47 -245 407 47 -245 minecraft:stone
setblock 406 47 -244 minecraft:stone
fill 411 47 -244 412 47 -244 minecraft:stone
setblock 406 47 -243 minecraft:stone
fill 411 47 -243 412 47 -243 minecraft:stone
fill 408 47 -242 410 47 -242 minecraft:stone
fill 408 47 -241 410 47 -241 minecraft:stone
setblock 404 47 -240 minecraft:stone
fill 403 47 -239 406 47 -239 minecraft:stone
fill 402 47 -238 407 47 -238 minecraft:stone
fill 401 47 -237 408 47 -237 minecraft:stone
fill 400 47 -236 408 47 -236 minecraft:stone
fill 399 47 -235 408 47 -235 minecraft:stone
fill 398 47 -234 407 47 -234 minecraft:stone
fill 397 47 -233 407 47 -233 minecraft:stone
fill 396 47 -232 406 47 -232 minecraft:stone
fill 398 47 -231 406 47 -231 minecraft:stone
fill 399 47 -230 406 47 -230 minecraft:stone
fill 399 47 -229 405 47 -229 minecraft:stone
fill 399 47 -228 405 47 -228 minecraft:stone
fill 399 47 -227 405 47 -227 minecraft:stone
fill 398 47 -226 405 47 -226 minecraft:stone
fill 395 47 -225 404 47 -225 minecraft:stone
fill 393 47 -224 404 47 -224 minecraft:stone
fill 392 47 -223 404 47 -223 minecraft:stone
fill 392 47 -222 404 47 -222 minecraft:stone
fill 392 47 -221 404 47 -221 minecraft:stone
fill 392 47 -220 403 47 -220 minecraft:stone
fill 392 47 -219 403 47 -219 minecraft:stone
fill 392 47 -218 403 47 -218 minecraft:stone
fill 392 47 -217 403 47 -217 minecraft:stone
fill 392 47 -216 403 47 -216 minecraft:stone
fill 392 47 -215 403 47 -215 minecraft:stone
fill 392 47 -214 403 47 -214 minecraft:stone
fill 392 47 -213 402 47 -213 minecraft:stone
fill 392 47 -212 402 47 -212 minecraft:stone
fill 392 47 -211 402 47 -211 minecraft:stone
fill 392 47 -210 401 47 -210 minecraft:stone
fill 392 47 -209 401 47 -209 minecraft:stone
fill 392 47 -208 400 47 -208 minecraft:stone
fill 392 47 -207 399 47 -207 minecraft:stone
fill 392 47 -206 399 47 -206 minecraft:stone
fill 392 47 -205 399 47 -205 minecraft:stone
fill 392 47 -204 398 47 -204 minecraft:stone
fill 392 47 -203 398 47 -203 minecraft:stone
fill 392 47 -202 398 47 -202 minecraft:stone
fill 392 47 -201 398 47 -201 minecraft:stone
fill 392 47 -200 398 47 -200 minecraft:stone
fill 392 47 -199 397 47 -199 minecraft:stone
fill 392 47 -198 397 47 -198 minecraft:stone
fill 392 47 -197 397 47 -197 minecraft:stone
fill 392 47 -196 397 47 -196 minecraft:stone
fill 392 47 -195 396 47 -195 minecraft:stone
fill 392 47 -194 396 47 -194 minecraft:stone
fill 394 47 -193 396 47 -193 minecraft:stone
setblock 396 47 -192 minecraft:stone
fill 407 48 -250 408 48 -250 minecraft:stone
fill 407 48 -249 408 48 -249 minecraft:stone
fill 407 48 -248 408 48 -248 minecraft:stone
fill 406 48 -247 407 48 -247 minecraft:stone
setblock 407 48 -246 minecraft:stone
setblock 407 48 -245 minecraft:stone
fill 405 48 -240 407 48 -240 minecraft:stone
fill 404 48 -239 408 48 -239 minecraft:stone
fill 402 48 -238 409 48 -238 minecraft:stone
fill 401 48 -237 408 48 -237 minecraft:stone
fill 399 48 -236 408 48 -236 minecraft:stone
fill 398 48 -235 408 48 -235 minecraft:stone
fill 397 48 -234 407 48 -234 minecraft:stone
fill 396 48 -233 407 48 -233 minecraft:stone
fill 396 48 -232 406 48 -232 minecraft:stone
fill 398 48 -231 406 48 -231 minecraft:stone
fill 399 48 -230 406 48 -230 minecraft:stone
fill 399 48 -229 405 48 -229 minecraft:stone
fill 399 48 -228 405 48 -228 minecraft:stone
fill 399 48 -227 405 48 -227 minecraft:stone
fill 398 48 -226 405 48 -226 minecraft:stone
fill 392 48 -225 405 48 -225 minecraft:stone
fill 392 48 -224 404 48 -224 minecraft:stone
fill 392 48 -223 404 48 -223 minecraft:stone
fill 392 48 -222 404 48 -222 minecraft:stone
fill 392 48 -221 404 48 -221 minecraft:stone
fill 392 48 -220 404 48 -220 minecraft:stone
fill 392 48 -219 404 48 -219 minecraft:stone
fill 392 48 -218 404 48 -218 minecraft:stone
fill 392 48 -217 404 48 -217 minecraft:stone
fill 392 48 -216 403 48 -216 minecraft:stone
fill 392 48 -215 403 48 -215 minecraft:stone
fill 392 48 -214 403 48 -214 minecraft:stone
fill 392 48 -213 403 48 -213 minecraft:stone
fill 392 48 -212 403 48 -212 minecraft:stone
fill 392 48 -211 403 48 -211 minecraft:stone
fill 392 48 -210 402 48 -210 minecraft:stone
fill 392 48 -209 402 48 -209 minecraft:stone
fill 392 48 -208 401 48 -208 minecraft:stone
fill 392 48 -207 401 48 -207 minecraft:stone
fill 392 48 -206 400 48 -206 minecraft:stone
fill 392 48 -205 399 48 -205 minecraft:stone
fill 392 48 -204 399 48 -204 minecraft:stone
fill 392 48 -203 399 48 -203 minecraft:stone
fill 392 48 -202 399 48 -202 minecraft:stone
fill 392 48 -201 399 48 -201 minecraft:stone
fill 392 48 -200 398 48 -200 minecraft:stone
fill 392 48 -199 398 48 -199 minecraft:stone
fill 392 48 -198 398 48 -198 minecraft:stone
fill 392 48 -197 398 48 -197 minecraft:stone
fill 392 48 -196 398 48 -196 minecraft:stone
fill 392 48 -195 397 48 -195 minecraft:stone
fill 392 48 -194 397 48 -194 minecraft:stone
fill 392 48 -193 397 48 -193 minecraft:stone
fill 392 48 -192 397 48 -192 minecraft:stone
fill 392 48 -191 396 48 -191 minecraft:stone
setblock 408 49 -252 minecraft:stone
setblock 408 49 -251 minecraft:stone
setblock 408 49 -250 minecraft:stone
fill 407 49 -249 409 49 -249 minecraft:stone
fill 407 49 -248 408 49 -248 minecraft:stone
setblock 408 49 -247 minecraft:stone
fill 407 49 -240 408 49 -240 minecraft:stone
fill 407 49 -239 408 49 -239 minecraft:stone
fill 404 49 -238 408 49 -238 minecraft:stone
fill 402 49 -237 408 49 -237 minecraft:stone
fill 401 49 -236 408 49 -236 minecraft:stone
fill 400 49 -235 407 49 -235 minecraft:stone
fill 399 49 -234 406 49 -234 minecraft:stone
fill 398 49 -233 406 49 -233 minecraft:stone
fill 397 49 -232 406 49 -232 minecraft:stone
fill 399 49 -231 405 49 -231 minecraft:stone
fill 399 49 -230 405 49 -230 minecraft:stone
fill 399 49 -229 405 49 -229 minecraft:stone
fill 399 49 -228 404 49 -228 minecraft:stone
fill 399 49 -227 404 49 -227 minecraft:stone
fill 398 49 -226 404 49 -226 minecraft:stone
fill 397 49 -225 404 49 -225 minecraft:stone
fill 394 49 -224 404 49 -224 minecraft:stone
fill 392 49 -223 404 49 -223 minecraft:stone
fill 392 49 -222 403 49 -222 minecraft:stone
fill 392 49 -221 403 49 -221 minecraft:stone
fill 392 49 -220 403 49 -220 minecraft:stone
fill 392 49 -219 403 49 -219 minecraft:stone
fill 392 49 -218 402 49 -218 minecraft:stone
fill 392 49 -217 402 49 -217 minecraft:stone
fill 392 49 -216 401 49 -216 minecraft:stone
fill 392 49 -215 402 49 -215 minecraft:stone
fill 392 49 -214 402 49 -214 minecraft:stone
fill 392 49 -213 402 49 -213 minecraft:stone
fill 392 49 -212 403 49 -212 minecraft:stone
fill 392 49 -211 402 49 -211 minecraft:stone
fill 392 49 -210 402 49 -210 minecraft:stone
fill 392 49 -209 402 49 -209 minecraft:stone
fill 392 49 -208 402 49 -208 minecraft:stone
fill 392 49 -207 401 49 -207 minecraft:stone
fill 392 49 -206 401 49 -206 minecraft:stone
fill 392 49 -205 400 49 -205 minecraft:stone
fill 392 49 -204 399 49 -204 minecraft:stone
fill 392 49 -203 399 49 -203 minecraft:stone
fill 392 49 -202 399 49 -202 minecraft:stone
fill 392 49 -201 399 49 -201 minecraft:stone
fill 392 49 -200 399 49 -200 minecraft:stone
fill 392 49 -199 398 49 -199 minecraft:stone
fill 392 49 -198 398 49 -198 minecraft:stone
fill 392 49 -197 398 49 -197 minecraft:stone
fill 392 49 -196 398 49 -196 minecraft:stone
fill 392 49 -195 398 49 -195 minecraft:stone
fill 392 49 -194 397 49 -194 minecraft:stone
fill 392 49 -193 397 49 -193 minecraft:stone
fill 392 49 -192 397 49 -192 minecraft:stone
fill 392 49 -191 397 49 -191 minecraft:stone
setblock 409 50 -252 minecraft:stone
fill 408 50 -251 409 50 -251 minecraft:stone
fill 408 50 -250 409 50 -250 minecraft:stone
fill 408 50 -249 409 50 -249 minecraft:stone
setblock 408 50 -248 minecraft:stone
setblock 404 50 -237 minecraft:stone
fill 403 50 -236 406 50 -236 minecraft:stone
fill 402 50 -235 405 50 -235 minecraft:stone
fill 400 50 -234 405 50 -234 minecraft:stone
fill 399 50 -233 405 50 -233 minecraft:stone
fill 398 50 -232 405 50 -232 minecraft:stone
fill 399 50 -231 405 50 -231 minecraft:stone
fill 400 50 -230 404 50 -230 minecraft:stone
fill 400 50 -229 404 50 -229 minecraft:stone
fill 400 50 -228 404 50 -228 minecraft:stone
fill 399 50 -227 403 50 -227 minecraft:stone
fill 399 50 -226 403 50 -226 minecraft:stone
fill 398 50 -225 403 50 -225 minecraft:stone
fill 396 50 -224 403 50 -224 minecraft:stone
fill 393 50 -223 403 50 -223 minecraft:stone
fill 392 50 -222 403 50 -222 minecraft:stone
fill 392 50 -221 402 50 -221 minecraft:stone
fill 392 50 -220 402 50 -220 minecraft:stone
fill 392 50 -219 401 50 -219 minecraft:stone
fill 392 50 -218 401 50 -218 minecraft:stone
fill 392 50 -217 400 50 -217 minecraft:stone
fill 392 50 -216 400 50 -216 minecraft:stone
fill 392 50 -215 401 50 -215 minecraft:stone
fill 392 50 -214 402 50 -214 minecraft:stone
fill 392 50 -213 402 50 -213 minecraft:stone
fill 392 50 -212 402 50 -212 minecraft:stone
fill 392 50 -211 402 50 -211 minecraft:stone
fill 392 50 -210 402 50 -210 minecraft:stone
fill 392 50 -209 403 50 -209 minecraft:stone
fill 392 50 -208 403 50 -208 minecraft:stone
fill 392 50 -207 403 50 -207 minecraft:stone
fill 392 50 -206 402 50 -206 minecraft:stone
fill 392 50 -205 402 50 -205 minecraft:stone
fill 392 50 -204 401 50 -204 minecraft:stone
fill 392 50 -203 400 50 -203 minecraft:stone
fill 392 50 -202 399 50 -202 minecraft:stone
fill 392 50 -201 399 50 -201 minecraft:stone
fill 392 50 -200 399 50 -200 minecraft:stone
fill 392 50 -199 399 50 -199 minecraft:stone
fill 392 50 -198 399 50 -198 minecraft:stone
fill 392 50 -197 398 50 -197 minecraft:stone
fill 392 50 -196 398 50 -196 minecraft:stone
fill 392 50 -195 398 50 -195 minecraft:stone
fill 392 50 -194 397 50 -194 minecraft:stone
fill 392 50 -193 398 50 -193 minecraft:stone
fill 392 50 -192 397 50 -192 minecraft:stone
fill 392 50 -191 397 50 -191 minecraft:stone
setblock 409 51 -253 minecraft:stone
fill 409 51 -252 410 51 -252 minecraft:stone
fill 408 51 -251 410 51 -251 minecraft:stone
fill 408 51 -250 410 51 -250 minecraft:stone
setblock 409 51 -249 minecraft:stone
setblock 404 51 -235 minecraft:stone
fill 403 51 -234 404 51 -234 minecraft:stone
fill 401 51 -233 405 51 -233 minecraft:stone
fill 400 51 -232 405 51 -232 minecraft:stone
fill 400 51 -231 404 51 -231 minecraft:stone
fill 400 51 -230 404 51 -230 minecraft:stone
fill 400 51 -229 403 51 -229 minecraft:stone
fill 400 51 -228 403 51 -228 minecraft:stone
fill 400 51 -227 402 51 -227 minecraft:stone
fill 400 51 -226 402 51 -226 minecraft:stone
fill 399 51 -225 402 51 -225 minecraft:stone
fill 397 51 -224 402 51 -224 minecraft:stone
fill 394 51 -223 402 51 -223 minecraft:stone
fill 393 51 -222 401 51 -222 minecraft:stone
fill 392 51 -221 401 51 -221 minecraft:stone
fill 392 51 -220 401 51 -220 minecraft:stone
fill 392 51 -219 400 51 -219 minecraft:stone
fill 392 51 -218 400 51 -218 minecraft:stone
fill 392 51 -217 400 51 -217 minecraft:stone
fill 392 51 -216 399 51 -216 minecraft:stone
fill 392 51 -215 400 51 -215 minecraft:stone
fill 392 51 -214 401 51 -214 minecraft:stone
fill 392 51 -213 402 51 -213 minecraft:stone
fill 392 51 -212 402 51 -212 minecraft:stone
fill 392 51 -211 402 51 -211 minecraft:stone
fill 392 51 -210 403 51 -210 minecraft:stone
fill 392 51 -209 403 51 -209 minecraft:stone
fill 392 51 -208 404 51 -208 minecraft:stone
fill 392 51 -207 404 51 -207 minecraft:stone
fill 392 51 -206 404 51 -206 minecraft:stone
fill 392 51 -205 404 51 -205 minecraft:stone
fill 392 51 -204 413 51 -204 minecraft:stone
fill 392 51 -203 412 51 -203 minecraft:stone
fill 392 51 -202 412 51 -202 minecraft:stone
fill 392 51 -201 411 51 -201 minecraft:stone
fill 392 51 -200 399 51 -200 minecraft:stone
fill 403 51 -200 411 51 -200 minecraft:stone
fill 392 51 -199 399 51 -199 minecraft:stone
fill 405 51 -199 410 51 -199 minecraft:stone
fill 392 51 -198 399 51 -198 minecraft:stone
fill 406 51 -198 409 51 -198 minecraft:stone
fill 392 51 -197 399 51 -197 minecraft:stone
fill 407 51 -197 408 51 -197 minecraft:stone
fill 392 51 -196 399 51 -196 minecraft:stone
fill 392 51 -195 399 51 -195 minecraft:stone
fill 392 51 -194 398 51 -194 minecraft:stone
fill 392 51 -193 398 51 -193 minecraft:stone
fill 392 51 -192 397 51 -192 minecraft:stone
fill 392 51 -191 397 51 -191 minecraft:stone
setblock 410 52 -254 minecraft:stone
setblock 410 52 -253 minecraft:stone
fill 409 52 -252 411 52 -252 minecraft:stone
fill 409 52 -251 410 52 -251 minecraft:stone
setblock 410 52 -250 minecraft:stone
fill 403 52 -233 404 52 -233 minecraft:stone
fill 402 52 -232 404 52 -232 minecraft:stone
fill 400 52 -231 404 52 -231 minecraft:stone
fill 400 52 -230 403 52 -230 minecraft:stone
fill 400 52 -229 402 52 -229 minecraft:stone
fill 400 52 -228 401 52 -228 minecraft:stone
fill 400 52 -227 401 52 -227 minecraft:stone
fill 400 52 -226 401 52 -226 minecraft:stone
fill 400 52 -225 401 52 -225 minecraft:stone
setblock 400 52 -224 minecraft:stone
fill 395 52 -223 400 52 -223 minecraft:stone
fill 393 52 -222 400 52 -222 minecraft:stone
fill 392 52 -221 400 52 -221 minecraft:stone
fill 392 52 -220 399 52 -220 minecraft:stone
fill 392 52 -219 399 52 -219 minecraft:stone
fill 392 52 -218 399 52 -218 minecraft:stone
fill 392 52 -217 399 52 -217 minecraft:stone
fill 392 52 -216 399 52 -216 minecraft:stone
fill 392 52 -215 400 52 -215 minecraft:stone
fill 392 52 -214 401 52 -214 minecraft:stone
fill 392 52 -213 401 52 -213 minecraft:stone
fill 392 52 -212 402 52 -212 minecraft:stone
fill 392 52 -211 402 52 -211 minecraft:stone
fill 392 52 -210 403 52 -210 minecraft:stone
fill 392 52 -209 404 52 -209 minecraft:stone
fill 392 52 -208 405 52 -208 minecraft:stone
fill 392 52 -207 405 52 -207 minecraft:stone
fill 392 52 -206 406 52 -206 minecraft:stone
fill 392 52 -205 408 52 -205 minecraft:stone
fill 392 52 -204 422 52 -204 minecraft:stone
fill 392 52 -203 422 52 -203 minecraft:stone
fill 392 52 -202 422 52 -202 minecraft:stone
fill 392 52 -201 422 52 -201 minecraft:stone
fill 392 52 -200 422 52 -200 minecraft:stone
fill 392 52 -199 414 52 -199 minecraft:stone
fill 416 52 -199 422 52 -199 minecraft:stone
fill 392 52 -198 414 52 -198 minecraft:stone
fill 416 52 -198 422 52 -198 minecraft:stone
fill 392 52 -197 415 52 -197 minecraft:stone
fill 418 52 -197 422 52 -197 minecraft:stone
fill 392 52 -196 417 52 -196 minecraft:stone
fill 420 52 -196 422 52 -196 minecraft:stone
fill 392 52 -195 413 52 -195 minecraft:stone
fill 415 52 -195 420 52 -195 minecraft:stone
fill 392 52 -194 400 52 -194 minecraft:stone
fill 402 52 -194 413 52 -194 minecraft:stone
fill 415 52 -194 421 52 -194 minecraft:stone
fill 392 52 -193 400 52 -193 minecraft:stone
fill 402 52 -193 414 52 -193 minecraft:stone
setblock 417 52 -193 minecraft:stone
fill 392 52 -192 400 52 -192 minecraft:stone
fill 402 52 -192 405 52 -192 minecraft:stone
setblock 418 52 -192 minecraft:stone
setblock 421 52 -192 minecraft:stone
fill 392 52 -191 398 52 -191 minecraft:stone
fill 403 52 -191 405 52 -191 minecraft:stone
fill 419 52 -191 422 52 -191 minecraft:stone
fill 410 53 -254 411 53 -254 minecraft:stone
fill 410 53 -253 411 53 -253 minecraft:stone
fill 409 53 -252 411 53 -252 minecraft:stone
fill 410 53 -251 411 53 -251 minecraft:stone
setblock 404 53 -232 minecraft:stone
fill 401 53 -230 402 53 -230 minecraft:stone
fill 400 53 -229 402 53 -229 minecraft:stone
fill 400 53 -228 401 53 -228 minecraft:stone
setblock 400 53 -227 minecraft:stone
fill 396 53 -223 398 53 -223 minecraft:stone
fill 394 53 -222 399 53 -222 minecraft:stone
fill 392 53 -221 399 53 -221 minecraft:stone
fill 392 53 -220 399 53 -220 minecraft:stone
fill 392 53 -219 399 53 -219 minecraft:stone
fill 392 53 -218 399 53 -218 minecraft:stone
fill 392 53 -217 399 53 -217 minecraft:stone
fill 392 53 -216 399 53 -216 minecraft:stone
fill 392 53 -215 400 53 -215 minecraft:stone
fill 392 53 -214 400 53 -214 minecraft:stone
fill 392 53 -213 401 53 -213 minecraft:stone
fill 392 53 -212 402 53 -212 minecraft:stone
fill 392 53 -211 402 53 -211 minecraft:stone
fill 392 53 -210 403 53 -210 minecraft:stone
fill 392 53 -209 404 53 -209 minecraft:stone
fill 392 53 -208 406 53 -208 minecraft:stone
fill 392 53 -207 406 53 -207 minecraft:stone
fill 392 53 -206 408 53 -206 minecraft:stone
fill 392 53 -205 410 53 -205 minecraft:stone
fill 392 53 -204 422 53 -204 minecraft:stone
fill 392 53 -203 422 53 -203 minecraft:stone
fill 392 53 -202 422 53 -202 minecraft:stone
fill 392 53 -201 422 53 -201 minecraft:stone
fill 392 53 -200 422 53 -200 minecraft:stone
fill 392 53 -199 422 53 -199 minecraft:stone
fill 392 53 -198 422 53 -198 minecraft:stone
fill 392 53 -197 422 53 -197 minecraft:stone
fill 392 53 -196 422 53 -196 minecraft:stone
fill 392 53 -195 422 53 -195 minecraft:stone
fill 392 53 -194 422 53 -194 minecraft:stone
fill 392 53 -193 414 53 -193 minecraft:stone
fill 416 53 -193 422 53 -193 minecraft:stone
fill 392 53 -192 403 53 -192 minecraft:stone
fill 405 53 -192 406 53 -192 minecraft:stone
fill 408 53 -192 414 53 -192 minecraft:stone
fill 418 53 -192 422 53 -192 minecraft:stone
fill 392 53 -191 399 53 -191 minecraft:stone
fill 402 53 -191 405 53 -191 minecraft:stone
setblock 407 53 -191 minecraft:stone
fill 411 53 -191 412 53 -191 minecraft:stone
setblock 415 53 -191 minecraft:stone
fill 418 53 -191 422 53 -191 minecraft:stone
fill 411 54 -254 412 54 -254 minecraft:stone
fill 410 54 -253 412 54 -253 minecraft:stone
fill 410 54 -252 412 54 -252 minecraft:stone
setblock 411 54 -251 minecraft:stone
fill 401 54 -229 402 54 -229 minecraft:stone
fill 401 54 -228 402 54 -228 minecraft:stone
setblock 401 54 -227 minecraft:stone
fill 395 54 -222 398 54 -222 minecraft:stone
fill 393 54 -221 399 54 -221 minecraft:stone
fill 392 54 -220 399 54 -220 minecraft:stone
fill 392 54 -219 399 54 -219 minecraft:stone
fill 392 54 -218 399 54 -218 minecraft:stone
fill 392 54 -217 399 54 -217 minecraft:stone
fill 392 54 -216 399 54 -216 minecraft:stone
fill 392 54 -215 399 54 -215 minecraft:stone
fill 392 54 -214 400 54 -214 minecraft:stone
fill 392 54 -213 401 54 -213 minecraft:stone
fill 392 54 -212 402 54 -212 minecraft:stone
fill 392 54 -211 402 54 -211 minecraft:stone
fill 392 54 -210 403 54 -210 minecraft:stone
fill 392 54 -209 404 54 -209 minecraft:stone
fill 392 54 -208 407 54 -208 minecraft:stone
fill 392 54 -207 408 54 -207 minecraft:stone
fill 392 54 -206 409 54 -206 minecraft:stone
fill 392 54 -205 418 54 -205 minecraft:stone
fill 392 54 -204 422 54 -204 minecraft:stone
fill 392 54 -203 422 54 -203 minecraft:stone
fill 392 54 -202 422 54 -202 minecraft:stone
fill 392 54 -201 422 54 -201 minecraft:stone
fill 392 54 -200 422 54 -200 minecraft:stone
fill 392 54 -199 422 54 -199 minecraft:stone
fill 392 54 -198 422 54 -198 minecraft:stone
fill 392 54 -197 422 54 -197 minecraft:stone
fill 392 54 -196 422 54 -196 minecraft:stone
fill 392 54 -195 422 54 -195 minecraft:stone
fill 392 54 -194 422 54 -194 minecraft:stone
fill 392 54 -193 403 54 -193 minecraft:stone
fill 405 54 -193 422 54 -193 minecraft:stone
fill 392 54 -192 402 54 -192 minecraft:stone
fill 405 54 -192 422 54 -192 minecraft:stone
fill 392 54 -191 403 54 -191 minecraft:stone
setblock 406 54 -191 minecraft:stone
setblock 408 54 -191 minecraft:stone
fill 411 54 -191 422 54 -191 minecraft:stone
fill 411 55 -254 413 55 -254 minecraft:stone
fill 411 55 -253 413 55 -253 minecraft:stone
setblock 412 55 -252 minecraft:stone
fill 401 55 -228 402 55 -228 minecraft:stone
fill 401 55 -227 402 55 -227 minecraft:stone
setblock 401 55 -226 minecraft:stone
setblock 396 55 -222 minecraft:stone
fill 393 55 -221 398 55 -221 minecraft:stone
fill 392 55 -220 398 55 -220 minecraft:stone
fill 392 55 -219 398 55 -219 minecraft:stone
fill 392 55 -218 398 55 -218 minecraft:stone
fill 392 55 -217 398 55 -217 minecraft:stone
fill 392 55 -216 398 55 -216 minecraft:stone
fill 392 55 -215 399 55 -215 minecraft:stone
fill 392 55 -214 400 55 -214 minecraft:stone
fill 392 55 -213 401 55 -213 minecraft:stone
fill 392 55 -212 401 55 -212 minecraft:stone
fill 392 55 -211 402 55 -211 minecraft:stone
fill 392 55 -210 404 55 -210 minecraft:stone
fill 392 55 -209 405 55 -209 minecraft:stone
fill 392 55 -208 408 55 -208 minecraft:stone
fill 392 55 -207 409 55 -207 minecraft:stone
fill 392 55 -206 410 55 -206 minecraft:stone
setblock 416 55 -206 minecraft:stone
fill 392 55 -205 421 55 -205 minecraft:stone
fill 392 55 -204 422 55 -204 minecraft:stone
fill 392 55 -203 422 55 -203 minecraft:stone
fill 392 55 -202 422 55 -202 minecraft:stone
fill 392 55 -201 422 55 -201 minecraft:stone
fill 392 55 -200 422 55 -200 minecraft:stone
fill 392 55 -199 422 55 -199 minecraft:stone
fill 392 55 -198 422 55 -198 minecraft:stone
fill 392 55 -197 422 55 -197 minecraft:stone
fill 392 55 -196 422 55 -196 minecraft:stone
fill 392 55 -195 422 55 -195 minecraft:stone
fill 392 55 -194 422 55 -194 minecraft:stone
fill 392 55 -193 422 55 -193 minecraft:stone
fill 392 55 -192 422 55 -192 minecraft:stone
fill 392 55 -191 403 55 -191 minecraft:stone
setblock 406 55 -191 minecraft:stone
setblock 408 55 -191 minecraft:stone
fill 410 55 -191 422 55 -191 minecraft:stone
fill 411 56 -254 414 56 -254 minecraft:stone
fill 412 56 -253 413 56 -253 minecraft:stone
setblock 413 56 -252 minecraft:stone
fill 401 56 -227 402 56 -227 minecraft:stone
fill 401 56 -226 402 56 -226 minecraft:stone
fill 394 56 -221 397 56 -221 minecraft:stone
fill 392 56 -220 398 56 -220 minecraft:stone
fill 392 56 -219 398 56 -219 minecraft:stone
fill 392 56 -218 398 56 -218 minecraft:stone
fill 392 56 -217 398 56 -217 minecraft:stone
fill 392 56 -216 398 56 -216 minecraft:stone
fill 392 56 -215 399 56 -215 minecraft:stone
fill 392 56 -214 400 56 -214 minecraft:stone
fill 392 56 -213 400 56 -213 minecraft:stone
fill 392 56 -212 401 56 -212 minecraft:stone
fill 392 56 -211 402 56 -211 minecraft:stone
fill 392 56 -210 404 56 -210 minecraft:stone
fill 392 56 -209 405 56 -209 minecraft:stone
fill 392 56 -208 408 56 -208 minecraft:stone
fill 392 56 -207 409 56 -207 minecraft:stone
setblock 416 56 -207 minecraft:stone
fill 392 56 -206 411 56 -206 minecraft:stone
fill 413 56 -206 420 56 -206 minecraft:stone
fill 392 56 -205 422 56 -205 minecraft:stone
fill 392 56 -204 422 56 -204 minecraft:stone
fill 392 56 -203 422 56 -203 minecraft:stone
fill 392 56 -202 422 56 -202 minecraft:stone
fill 392 56 -201 422 56 -201 minecraft:stone
fill 392 56 -200 422 56 -200 minecraft:stone
fill 392 56 -199 422 56 -199 minecraft:stone
fill 392 56 -198 422 56 -198 minecraft:stone
fill 392 56 -197 422 56 -197 minecraft:stone
fill 392 56 -196 422 56 -196 minecraft:stone
fill 392 56 -195 422 56 -195 minecraft:stone
fill 392 56 -194 422 56 -194 minecraft:stone
fill 392 56 -193 422 56 -193 minecraft:stone
fill 392 56 -192 422 56 -192 minecraft:stone
fill 392 56 -191 404 56 -191 minecraft:stone
fill 407 56 -191 408 56 -191 minecraft:stone
fill 410 56 -191 422 56 -191 minecraft:stone
fill 412 57 -254 415 57 -254 minecraft:stone
fill 413 57 -253 414 57 -253 minecraft:stone
fill 401 57 -227 402 57 -227 minecraft:stone
fill 401 57 -226 402 57 -226 minecraft:stone
setblock 401 57 -225 minecraft:stone
setblock 396 57 -222 minecraft:stone
fill 392 57 -221 397 57 -221 minecraft:stone
fill 392 57 -220 398 57 -220 minecraft:stone
fill 392 57 -219 398 57 -219 minecraft:stone
fill 392 57 -218 398 57 -218 minecraft:stone
fill 392 57 -217 398 57 -217 minecraft:stone
fill 392 57 -216 399 57 -216 minecraft:stone
fill 392 57 -215 399 57 -215 minecraft:stone
fill 392 57 -214 400 57 -214 minecraft:stone
fill 392 57 -213 401 57 -213 minecraft:stone
fill 392 57 -212 402 57 -212 minecraft:stone
fill 392 57 -211 403 57 -211 minecraft:stone
fill 392 57 -210 404 57 -210 minecraft:stone
fill 392 57 -209 406 57 -209 minecraft:stone
fill 392 57 -208 409 57 -208 minecraft:stone
fill 392 57 -207 410 57 -207 minecraft:stone
fill 415 57 -207 418 57 -207 minecraft:stone
fill 392 57 -206 420 57 -206 minecraft:stone
fill 392 57 -205 422 57 -205 minecraft:stone
fill 392 57 -204 422 57 -204 minecraft:stone
fill 392 57 -203 422 57 -203 minecraft:stone
fill 392 57 -202 422 57 -202 minecraft:stone
fill 392 57 -201 422 57 -201 minecraft:stone
fill 392 57 -200 422 57 -200 minecraft:stone
fill 392 57 -199 422 57 -199 minecraft:stone
fill 392 57 -198 422 57 -198 minecraft:stone
fill 392 57 -197 422 57 -197 minecraft:stone
fill 392 57 -196 422 57 -196 minecraft:stone
fill 392 57 -195 422 57 -195 minecraft:stone
fill 392 57 -194 422 57 -194 minecraft:stone
fill 392 57 -193 422 57 -193 minecraft:stone
fill 392 57 -192 422 57 -192 minecraft:stone
fill 392 57 -191 405 57 -191 minecraft:stone
fill 407 57 -191 422 57 -191 minecraft:stone
fill 413 58 -254 415 58 -254 minecraft:stone
setblock 415 58 -253 minecraft:stone
fill 401 58 -226 402 58 -226 minecraft:stone
fill 401 58 -225 402 58 -225 minecraft:stone
setblock 396 58 -222 minecraft:stone
fill 392 58 -221 393 58 -221 minecraft:stone
fill 395 58 -221 398 58 -221 minecraft:stone
fill 392 58 -220 398 58 -220 minecraft:stone
fill 392 58 -219 398 58 -219 minecraft:stone
fill 392 58 -218 399 58 -218 minecraft:stone
fill 392 58 -217 399 58 -217 minecraft:stone
fill 392 58 -216 399 58 -216 minecraft:stone
fill 392 58 -215 400 58 -215 minecraft:stone
fill 392 58 -214 401 58 -214 minecraft:stone
fill 392 58 -213 402 58 -213 minecraft:stone
fill 392 58 -212 403 58 -212 minecraft:stone
fill 392 58 -211 404 58 -211 minecraft:stone
fill 392 58 -210 405 58 -210 minecraft:stone
fill 392 58 -209 407 58 -209 minecraft:stone
fill 392 58 -208 410 58 -208 minecraft:stone
fill 415 58 -208 417 58 -208 minecraft:stone
fill 392 58 -207 411 58 -207 minecraft:stone
fill 413 58 -207 420 58 -207 minecraft:stone
fill 392 58 -206 421 58 -206 minecraft:stone
fill 392 58 -205 422 58 -205 minecraft:stone
fill 392 58 -204 422 58 -204 minecraft:stone
fill 392 58 -203 422 58 -203 minecraft:stone
fill 392 58 -202 422 58 -202 minecraft:stone
fill 392 58 -201 422 58 -201 minecraft:stone
fill 392 58 -200 422 58 -200 minecraft:stone
fill 392 58 -199 422 58 -199 minecraft:stone
fill 392 58 -198 422 58 -198 minecraft:stone
fill 392 58 -197 422 58 -197 minecraft:stone
fill 392 58 -196 422 58 -196 minecraft:stone
fill 392 58 -195 422 58 -195 minecraft:stone
fill 392 58 -194 422 58 -194 minecraft:stone
fill 392 58 -193 422 58 -193 minecraft:stone
fill 392 58 -192 422 58 -192 minecraft:stone
fill 392 58 -191 422 58 -191 minecraft:stone
fill 415 59 -254 416 59 -254 minecraft:stone
fill 401 59 -226 402 59 -226 minecraft:stone
fill 401 59 -225 402 59 -225 minecraft:stone
setblock 397 59 -223 minecraft:stone
fill 395 59 -222 396 59 -222 minecraft:stone
fill 392 59 -221 398 59 -221 minecraft:stone
fill 392 59 -220 397 59 -220 minecraft:stone
fill 392 59 -219 398 59 -219 minecraft:stone
fill 392 59 -218 399 59 -218 minecraft:stone
fill 392 59 -217 399 59 -217 minecraft:stone
fill 392 59 -216 399 59 -216 minecraft:stone
fill 392 59 -215 400 59 -215 minecraft:stone
fill 392 59 -214 402 59 -214 minecraft:stone
fill 392 59 -213 403 59 -213 minecraft:stone
fill 392 59 -212 404 59 -212 minecraft:stone
fill 392 59 -211 404 59 -211 minecraft:stone
fill 392 59 -210 406 59 -210 minecraft:stone
fill 392 59 -209 408 59 -209 minecraft:stone
fill 392 59 -208 411 59 -208 minecraft:stone
setblock 414 59 -208 minecraft:stone
fill 417 59 -208 419 59 -208 minecraft:stone
fill 392 59 -207 420 59 -207 minecraft:stone
fill 392 59 -206 422 59 -206 minecraft:stone
fill 392 59 -205 422 59 -205 minecraft:stone
fill 392 59 -204 422 59 -204 minecraft:stone
fill 392 59 -203 422 59 -203 minecraft:stone
fill 392 59 -202 422 59 -202 minecraft:stone
fill 392 59 -201 422 59 -201 minecraft:stone
fill 392 59 -200 422 59 -200 minecraft:stone
fill 392 59 -199 422 59 -199 minecraft:stone
fill 392 59 -198 422 59 -198 minecraft:stone
fill 392 59 -197 422 59 -197 minecraft:stone
fill 392 59 -196 422 59 -196 minecraft:stone
fill 392 59 -195 422 59 -195 minecraft:stone
fill 392 59 -194 422 59 -194 minecraft:stone
fill 392 59 -193 422 59 -193 minecraft:stone
fill 392 59 -192 422 59 -192 minecraft:stone
fill 392 59 -191 422 59 -191 minecraft:stone
setblock 417 60 -254 minecraft:stone
setblock 402 60 -226 minecraft:stone
fill 401 60 -225 402 60 -225 minecraft:stone
fill 395 60 -223 396 60 -223 minecraft:stone
fill 392 60 -222 397 60 -222 minecraft:stone
fill 392 60 -221 397 60 -221 minecraft:stone
fill 392 60 -220 397 60 -220 minecraft:stone
fill 392 60 -219 399 60 -219 minecraft:stone
fill 392 60 -218 398 60 -218 minecraft:stone
fill 392 60 -217 398 60 -217 minecraft:stone
fill 392 60 -216 400 60 -216 minecraft:stone
fill 392 60 -215 401 60 -215 minecraft:stone
fill 392 60 -214 402 60 -214 minecraft:stone
fill 392 60 -213 404 60 -213 minecraft:stone
fill 392 60 -212 404 60 -212 minecraft:stone
fill 392 60 -211 405 60 -211 minecraft:stone
fill 392 60 -210 407 60 -210 minecraft:stone
fill 392 60 -209 409 60 -209 minecraft:stone
fill 392 60 -208 415 60 -208 minecraft:stone
fill 417 60 -208 420 60 -208 minecraft:stone
fill 392 60 -207 421 60 -207 minecraft:stone
fill 392 60 -206 422 60 -206 minecraft:stone
fill 392 60 -205 422 60 -205 minecraft:stone
fill 392 60 -204 422 60 -204 minecraft:stone
fill 392 60 -203 422 60 -203 minecraft:stone
fill 392 60 -202 422 60 -202 minecraft:stone
fill 392 60 -201 422 60 -201 minecraft:stone
fill 392 60 -200 422 60 -200 minecraft:stone
fill 392 60 -199 422 60 -199 minecraft:stone
fill 392 60 -198 422 60 -198 minecraft:stone
fill 392 60 -197 422 60 -197 minecraft:stone
fill 392 60 -196 422 60 -196 minecraft:stone
fill 392 60 -195 422 60 -195 minecraft:stone
fill 392 60 -194 422 60 -194 minecraft:stone
fill 392 60 -193 422 60 -193 minecraft:stone
fill 392 60 -192 422 60 -192 minecraft:stone
fill 392 60 -191 422 60 -191 minecraft:stone
setblock 396 61 -225 minecraft:stone
fill 401 61 -225 402 61 -225 minecraft:stone
setblock 396 61 -224 minecraft:stone
fill 401 61 -224 402 61 -224 minecraft:stone
fill 394 61 -223 398 61 -223 minecraft:stone
fill 392 61 -222 397 61 -222 minecraft:stone
fill 392 61 -221 397 61 -221 minecraft:stone
fill 392 61 -220 397 61 -220 minecraft:stone
fill 392 61 -219 398 61 -219 minecraft:stone
fill 392 61 -218 398 61 -218 minecraft:stone
fill 392 61 -217 399 61 -217 minecraft:stone
fill 392 61 -216 401 61 -216 minecraft:stone
fill 392 61 -215 402 61 -215 minecraft:stone
fill 392 61 -214 403 61 -214 minecraft:stone
fill 392 61 -213 404 61 -213 minecraft:stone
fill 392 61 -212 405 61 -212 minecraft:stone
fill 392 61 -211 406 61 -211 minecraft:stone
fill 392 61 -210 408 61 -210 minecraft:stone
fill 392 61 -209 411 61 -209 minecraft:stone
setblock 415 61 -209 minecraft:stone
setblock 417 61 -209 minecraft:stone
setblock 419 61 -209 minecraft:stone
fill 392 61 -208 412 61 -208 minecraft:stone
fill 414 61 -208 420 61 -208 minecraft:stone
fill 392 61 -207 422 61 -207 minecraft:stone
fill 392 61 -206 422 61 -206 minecraft:stone
fill 392 61 -205 422 61 -205 minecraft:stone
fill 392 61 -204 422 61 -204 minecraft:stone
fill 392 61 -203 422 61 -203 minecraft:stone
fill 392 61 -202 422 61 -202 minecraft:stone
fill 392 61 -201 422 61 -201 minecraft:stone
fill 392 61 -200 422 61 -200 minecraft:stone
fill 392 61 -199 422 61 -199 minecraft:stone
fill 392 61 -198 422 61 -198 minecraft:stone
fill 392 61 -197 422 61 -197 minecraft:stone
fill 392 61 -196 422 61 -196 minecraft:stone
fill 392 61 -195 422 61 -195 minecraft:stone
fill 392 61 -194 422 61 -194 minecraft:stone
fill 392 61 -193 422 61 -193 minecraft:stone
fill 392 61 -192 422 61 -192 minecraft:stone
fill 392 61 -191 422 61 -191 minecraft:stone
fill 396 62 -225 397 62 -225 minecraft:dirt
setblock 402 62 -225 minecraft:dirt
fill 395 62 -224 398 62 -224 minecraft:dirt
fill 401 62 -224 402 62 -224 minecraft:dirt
fill 394 62 -223 398 62 -223 minecraft:dirt
setblock 402 62 -223 minecraft:dirt
fill 392 62 -222 398 62 -222 minecraft:dirt
fill 392 62 -221 398 62 -221 minecraft:dirt
fill 392 62 -220 398 62 -220 minecraft:dirt
fill 392 62 -219 398 62 -219 minecraft:dirt
fill 392 62 -218 399 62 -218 minecraft:dirt
fill 392 62 -217 399 62 -217 minecraft:dirt
setblock 401 62 -217 minecraft:dirt
fill 392 62 -216 402 62 -216 minecraft:dirt
fill 392 62 -215 403 62 -215 minecraft:dirt
fill 392 62 -214 404 62 -214 minecraft:dirt
fill 392 62 -213 405 62 -213 minecraft:dirt
fill 392 62 -212 405 62 -212 minecraft:dirt
fill 392 62 -211 406 62 -211 minecraft:dirt
fill 392 62 -210 410 62 -210 minecraft:dirt
fill 392 62 -209 411 62 -209 minecraft:dirt
setblock 414 62 -209 minecraft:dirt
fill 416 62 -209 420 62 -209 minecraft:dirt
fill 392 62 -208 421 62 -208 minecraft:dirt
fill 392 62 -207 422 62 -207 minecraft:dirt
fill 392 62 -206 422 62 -206 minecraft:dirt
fill 392 62 -205 422 62 -205 minecraft:dirt
fill 392 62 -204 422 62 -204 minecraft:dirt
fill 392 62 -203 422 62 -203 minecraft:dirt
fill 392 62 -202 422 62 -202 minecraft:dirt
fill 392 62 -201 422 62 -201 minecraft:dirt
fill 392 62 -200 422 62 -200 minecraft:dirt
fill 392 62 -199 422 62 -199 minecraft:dirt
fill 392 62 -198 422 62 -198 minecraft:dirt
fill 392 62 -197 422 62 -197 minecraft:dirt
fill 392 62 -196 422 62 -196 minecraft:dirt
fill 392 62 -195 422 62 -195 minecraft:dirt
fill 392 62 -194 422 62 -194 minecraft:dirt
fill 392 62 -193 422 62 -193 minecraft:dirt
fill 392 62 -192 422 62 -192 minecraft:dirt
fill 392 62 -191 422 62 -191 minecraft:dirt
fill 395 63 -225 397 63 -225 minecraft:dirt
fill 395 63 -224 398 63 -224 minecraft:dirt
fill 401 63 -224 403 63 -224 minecraft:dirt
fill 393 63 -223 398 63 -223 minecraft:dirt
fill 402 63 -223 403 63 -223 minecraft:dirt
fill 392 63 -222 398 63 -222 minecraft:dirt
fill 392 63 -221 398 63 -221 minecraft:dirt
fill 392 63 -220 398 63 -220 minecraft:dirt
fill 392 63 -219 399 63 -219 minecraft:dirt
fill 392 63 -218 399 63 -218 minecraft:dirt
fill 392 63 -217 402 63 -217 minecraft:dirt
fill 392 63 -216 403 63 -216 minecraft:dirt
fill 392 63 -215 405 63 -215 minecraft:dirt
fill 392 63 -214 405 63 -214 minecraft:dirt
fill 392 63 -213 406 63 -213 minecraft:dirt
fill 392 63 -212 406 63 -212 minecraft:dirt
fill 392 63 -211 407 63 -211 minecraft:dirt
fill 392 63 -210 414 63 -210 minecraft:dirt
fill 416 63 -210 421 63 -210 minecraft:dirt
fill 392 63 -209 422 63 -209 minecraft:dirt
fill 392 63 -208 422 63 -208 minecraft:dirt
fill 392 63 -207 422 63 -207 minecraft:dirt
fill 392 63 -206 422 63 -206 minecraft:dirt
fill 392 63 -205 422 63 -205 minecraft:dirt
fill 392 63 -204 422 63 -204 minecraft:dirt
fill 392 63 -203 422 63 -203 minecraft:dirt
fill 392 63 -202 422 63 -202 minecraft:dirt
fill 392 63 -201 422 63 -201 minecraft:dirt
fill 392 63 -200 422 63 -200 minecraft:dirt
fill 392 63 -199 422 63 -199 minecraft:dirt
fill 392 63 -198 422 63 -198 minecraft:dirt
fill 392 63 -197 422 63 -197 minecraft:dirt
fill 392 63 -196 422 63 -196 minecraft:dirt
fill 392 63 -195 422 63 -195 minecraft:dirt
fill 392 63 -194 422 63 -194 minecraft:dirt
fill 392 63 -193 422 63 -193 minecraft:dirt
fill 392 63 -192 422 63 -192 minecraft:dirt
fill 392 63 -191 422 63 -191 minecraft:dirt
setblock 392 64 -254 minecraft:dirt
setblock 396 64 -226 minecraft:dirt
fill 395 64 -225 398 64 -225 minecraft:dirt
fill 394 64 -224 398 64 -224 minecraft:dirt
fill 401 64 -224 403 64 -224 minecraft:dirt
fill 393 64 -223 398 64 -223 minecraft:dirt
fill 402 64 -223 403 64 -223 minecraft:dirt
fill 392 64 -222 398 64 -222 minecraft:dirt
fill 392 64 -221 398 64 -221 minecraft:dirt
fill 392 64 -220 398 64 -220 minecraft:dirt
fill 392 64 -219 399 64 -219 minecraft:dirt
fill 392 64 -218 400 64 -218 minecraft:dirt
fill 392 64 -217 403 64 -217 minecraft:dirt
fill 416 64 -217 417 64 -217 minecraft:dirt
fill 392 64 -216 405 64 -216 minecraft:dirt
fill 415 64 -216 419 64 -216 minecraft:dirt
fill 392 64 -215 406 64 -215 minecraft:dirt
fill 415 64 -215 419 64 -215 minecraft:dirt
fill 392 64 -214 406 64 -214 minecraft:dirt
fill 415 64 -214 419 64 -214 minecraft:dirt
fill 392 64 -213 406 64 -213 minecraft:dirt
fill 416 64 -213 418 64 -213 minecraft:dirt
fill 392 64 -212 407 64 -212 minecraft:dirt
fill 416 64 -212 417 64 -212 minecraft:dirt
fill 392 64 -211 422 64 -211 minecraft:dirt
fill 392 64 -210 422 64 -210 minecraft:dirt
fill 392 64 -209 422 64 -209 minecraft:dirt
fill 392 64 -208 422 64 -208 minecraft:dirt
fill 392 64 -207 422 64 -207 minecraft:dirt
fill 392 64 -206 422 64 -206 minecraft:dirt
fill 392 64 -205 422 64 -205 minecraft:dirt
fill 392 64 -204 422 64 -204 minecraft:dirt
fill 392 64 -203 422 64 -203 minecraft:dirt
fill 392 64 -202 422 64 -202 minecraft:dirt
fill 392 64 -201 422 64 -201 minecraft:dirt
fill 392 64 -200 422 64 -200 minecraft:dirt
fill 392 64 -199 422 64 -199 minecraft:dirt
fill 392 64 -198 422 64 -198 minecraft:dirt
fill 392 64 -197 422 64 -197 minecraft:dirt
fill 392 64 -196 422 64 -196 minecraft:dirt
fill 392 64 -195 422 64 -195 minecraft:dirt
fill 392 64 -194 422 64 -194 minecraft:dirt
fill 392 64 -193 422 64 -193 minecraft:dirt
fill 392 64 -192 422 64 -192 minecraft:dirt
fill 392 64 -191 422 64 -191 minecraft:dirt
setblock 417 65 -254 minecraft:smooth_quartz
fill 418 65 -254 422 65 -254 minecraft:light_gray_concrete
setblock 417 65 -253 minecraft:smooth_quartz
fill 418 65 -253 422 65 -253 minecraft:light_gray_concrete
setblock 417 65 -252 minecraft:smooth_quartz
fill 418 65 -252 422 65 -252 minecraft:light_gray_concrete
setblock 417 65 -251 minecraft:smooth_quartz
fill 418 65 -251 422 65 -251 minecraft:light_gray_concrete
setblock 417 65 -250 minecraft:smooth_quartz
fill 418 65 -250 420 65 -250 minecraft:light_gray_concrete
setblock 421 65 -250 minecraft:sea_lantern
setblock 422 65 -250 minecraft:light_gray_concrete
setblock 417 65 -249 minecraft:smooth_quartz
fill 418 65 -249 419 65 -249 minecraft:light_gray_concrete
setblock 420 65 -249 minecraft:sea_lantern
fill 421 65 -249 422 65 -249 minecraft:light_gray_concrete
setblock 417 65 -248 minecraft:smooth_quartz
setblock 418 65 -248 minecraft:light_gray_concrete
setblock 419 65 -248 minecraft:sea_lantern
fill 420 65 -248 422 65 -248 minecraft:light_gray_concrete
setblock 417 65 -247 minecraft:smooth_quartz
setblock 418 65 -247 minecraft:sea_lantern
fill 419 65 -247 422 65 -247 minecraft:light_gray_concrete
setblock 417 65 -246 minecraft:smooth_quartz
fill 418 65 -246 422 65 -246 minecraft:light_gray_concrete
setblock 417 65 -245 minecraft:smooth_quartz
fill 418 65 -245 422 65 -245 minecraft:light_gray_concrete
setblock 417 65 -244 minecraft:smooth_quartz
fill 418 65 -244 422 65 -244 minecraft:light_gray_concrete
setblock 417 65 -243 minecraft:smooth_quartz
fill 418 65 -243 422 65 -243 minecraft:light_gray_concrete
setblock 417 65 -242 minecraft:smooth_quartz
fill 418 65 -242 422 65 -242 minecraft:light_gray_concrete
setblock 417 65 -241 minecraft:smooth_quartz
fill 418 65 -241 420 65 -241 minecraft:light_gray_concrete
setblock 421 65 -241 minecraft:sea_lantern
setblock 422 65 -241 minecraft:light_gray_concrete
setblock 417 65 -240 minecraft:smooth_quartz
fill 418 65 -240 419 65 -240 minecraft:light_gray_concrete
setblock 420 65 -240 minecraft:sea_lantern
fill 421 65 -240 422 65 -240 minecraft:light_gray_concrete
setblock 417 65 -239 minecraft:smooth_quartz
setblock 418 65 -239 minecraft:light_gray_concrete
setblock 419 65 -239 minecraft:sea_lantern
fill 420 65 -239 422 65 -239 minecraft:light_gray_concrete
setblock 417 65 -238 minecraft:smooth_quartz
setblock 418 65 -238 minecraft:sea_lantern
fill 419 65 -238 422 65 -238 minecraft:light_gray_concrete
setblock 417 65 -237 minecraft:smooth_quartz
fill 418 65 -237 422 65 -237 minecraft:light_gray_concrete
setblock 417 65 -236 minecraft:smooth_quartz
fill 418 65 -236 422 65 -236 minecraft:light_gray_concrete
setblock 417 65 -235 minecraft:smooth_quartz
fill 418 65 -235 422 65 -235 minecraft:light_gray_concrete
setblock 417 65 -234 minecraft:smooth_quartz
fill 418 65 -234 422 65 -234 minecraft:light_gray_concrete
setblock 417 65 -233 minecraft:smooth_quartz
fill 418 65 -233 422 65 -233 minecraft:light_gray_concrete
setblock 417 65 -232 minecraft:smooth_quartz
fill 418 65 -232 420 65 -232 minecraft:light_gray_concrete
setblock 421 65 -232 minecraft:sea_lantern
setblock 422 65 -232 minecraft:light_gray_concrete
setblock 417 65 -231 minecraft:smooth_quartz
fill 418 65 -231 419 65 -231 minecraft:light_gray_concrete
setblock 420 65 -231 minecraft:sea_lantern
fill 421 65 -231 422 65 -231 minecraft:light_gray_concrete
setblock 417 65 -230 minecraft:smooth_quartz
setblock 418 65 -230 minecraft:light_gray_concrete
setblock 419 65 -230 minecraft:sea_lantern
fill 420 65 -230 422 65 -230 minecraft:light_gray_concrete
setblock 417 65 -229 minecraft:smooth_quartz
setblock 418 65 -229 minecraft:sea_lantern
fill 419 65 -229 422 65 -229 minecraft:light_gray_concrete
setblock 417 65 -228 minecraft:smooth_quartz
fill 418 65 -228 422 65 -228 minecraft:light_gray_concrete
setblock 417 65 -227 minecraft:smooth_quartz
fill 418 65 -227 422 65 -227 minecraft:light_gray_concrete
setblock 396 65 -226 minecraft:grass_block
setblock 417 65 -226 minecraft:smooth_quartz
fill 418 65 -226 422 65 -226 minecraft:light_gray_concrete
fill 395 65 -225 399 65 -225 minecraft:grass_block
setblock 417 65 -225 minecraft:smooth_quartz
fill 418 65 -225 422 65 -225 minecraft:light_gray_concrete
fill 394 65 -224 398 65 -224 minecraft:grass_block
setblock 417 65 -224 minecraft:smooth_quartz
fill 418 65 -224 422 65 -224 minecraft:light_gray_concrete
fill 393 65 -223 398 65 -223 minecraft:grass_block
setblock 417 65 -223 minecraft:smooth_quartz
fill 418 65 -223 420 65 -223 minecraft:light_gray_concrete
setblock 421 65 -223 minecraft:sea_lantern
setblock 422 65 -223 minecraft:light_gray_concrete
fill 392 65 -222 398 65 -222 minecraft:grass_block
setblock 417 65 -222 minecraft:smooth_quartz
fill 418 65 -222 419 65 -222 minecraft:light_gray_concrete
setblock 420 65 -222 minecraft:sea_lantern
fill 421 65 -222 422 65 -222 minecraft:light_gray_concrete
fill 392 65 -221 398 65 -221 minecraft:grass_block
setblock 417 65 -221 minecraft:smooth_quartz
setblock 418 65 -221 minecraft:light_gray_concrete
setblock 419 65 -221 minecraft:sea_lantern
fill 420 65 -221 422 65 -221 minecraft:light_gray_concrete
fill 392 65 -220 398 65 -220 minecraft:grass_block
fill 414 65 -220 416 65 -220 minecraft:grass_block
setblock 417 65 -220 minecraft:smooth_quartz
setblock 418 65 -220 minecraft:sea_lantern
fill 419 65 -220 422 65 -220 minecraft:light_gray_concrete
fill 392 65 -219 401 65 -219 minecraft:grass_block
fill 412 65 -219 416 65 -219 minecraft:grass_block
setblock 417 65 -219 minecraft:smooth_quartz
fill 418 65 -219 422 65 -219 minecraft:light_gray_concrete
fill 392 65 -218 405 65 -218 minecraft:grass_block
fill 412 65 -218 416 65 -218 minecraft:grass_block
setblock 417 65 -218 minecraft:smooth_quartz
fill 418 65 -218 422 65 -218 minecraft:light_gray_concrete
fill 392 65 -217 406 65 -217 minecraft:grass_block
fill 411 65 -217 416 65 -217 minecraft:grass_block
setblock 417 65 -217 minecraft:smooth_quartz
fill 418 65 -217 422 65 -217 minecraft:light_gray_concrete
fill 392 65 -216 416 65 -216 minecraft:grass_block
setblock 417 65 -216 minecraft:smooth_quartz
fill 418 65 -216 422 65 -216 minecraft:light_gray_concrete
fill 392 65 -215 416 65 -215 minecraft:grass_block
setblock 417 65 -215 minecraft:smooth_quartz
fill 418 65 -215 422 65 -215 minecraft:light_gray_concrete
fill 392 65 -214 416 65 -214 minecraft:grass_block
setblock 417 65 -214 minecraft:smooth_quartz
fill 418 65 -214 420 65 -214 minecraft:light_gray_concrete
setblock 421 65 -214 minecraft:sea_lantern
setblock 422 65 -214 minecraft:light_gray_concrete
fill 392 65 -213 416 65 -213 minecraft:grass_block
setblock 417 65 -213 minecraft:smooth_quartz
fill 418 65 -213 419 65 -213 minecraft:light_gray_concrete
setblock 420 65 -213 minecraft:sea_lantern
fill 421 65 -213 422 65 -213 minecraft:light_gray_concrete
fill 392 65 -212 416 65 -212 minecraft:grass_block
setblock 417 65 -212 minecraft:smooth_quartz
setblock 418 65 -212 minecraft:light_gray_concrete
setblock 419 65 -212 minecraft:sea_lantern
fill 420 65 -212 422 65 -212 minecraft:light_gray_concrete
fill 392 65 -211 416 65 -211 minecraft:grass_block
setblock 417 65 -211 minecraft:smooth_quartz
setblock 418 65 -211 minecraft:sea_lantern
fill 419 65 -211 422 65 -211 minecraft:light_gray_concrete
fill 392 65 -210 416 65 -210 minecraft:grass_block
setblock 417 65 -210 minecraft:smooth_quartz
fill 418 65 -210 422 65 -210 minecraft:light_gray_concrete
fill 392 65 -209 416 65 -209 minecraft:grass_block
setblock 417 65 -209 minecraft:smooth_quartz
fill 418 65 -209 422 65 -209 minecraft:light_gray_concrete
fill 392 65 -208 416 65 -208 minecraft:grass_block
setblock 417 65 -208 minecraft:smooth_quartz
fill 418 65 -208 422 65 -208 minecraft:light_gray_concrete
fill 392 65 -207 416 65 -207 minecraft:grass_block
setblock 417 65 -207 minecraft:smooth_quartz
fill 418 65 -207 422 65 -207 minecraft:light_gray_concrete
fill 392 65 -206 416 65 -206 minecraft:grass_block
setblock 417 65 -206 minecraft:smooth_quartz
fill 418 65 -206 422 65 -206 minecraft:light_gray_concrete
fill 392 65 -205 416 65 -205 minecraft:grass_block
setblock 417 65 -205 minecraft:smooth_quartz
fill 418 65 -205 420 65 -205 minecraft:light_gray_concrete
setblock 421 65 -205 minecraft:sea_lantern
setblock 422 65 -205 minecraft:light_gray_concrete
fill 392 65 -204 416 65 -204 minecraft:grass_block
setblock 417 65 -204 minecraft:smooth_quartz
fill 418 65 -204 419 65 -204 minecraft:light_gray_concrete
setblock 420 65 -204 minecraft:sea_lantern
fill 421 65 -204 422 65 -204 minecraft:light_gray_concrete
fill 392 65 -203 416 65 -203 minecraft:grass_block
setblock 417 65 -203 minecraft:smooth_quartz
setblock 418 65 -203 minecraft:light_gray_concrete
setblock 419 65 -203 minecraft:sea_lantern
fill 420 65 -203 422 65 -203 minecraft:light_gray_concrete
fill 392 65 -202 416 65 -202 minecraft:grass_block
setblock 417 65 -202 minecraft:smooth_quartz
setblock 418 65 -202 minecraft:sea_lantern
fill 419 65 -202 422 65 -202 minecraft:light_gray_concrete
fill 392 65 -201 416 65 -201 minecraft:grass_block
setblock 417 65 -201 minecraft:smooth_quartz
fill 418 65 -201 422 65 -201 minecraft:light_gray_concrete
fill 392 65 -200 416 65 -200 minecraft:grass_block
setblock 417 65 -200 minecraft:smooth_quartz
fill 418 65 -200 422 65 -200 minecraft:light_gray_concrete
fill 392 65 -199 416 65 -199 minecraft:grass_block
setblock 417 65 -199 minecraft:smooth_quartz
fill 418 65 -199 422 65 -199 minecraft:light_gray_concrete
fill 392 65 -198 416 65 -198 minecraft:grass_block
setblock 417 65 -198 minecraft:smooth_quartz
fill 418 65 -198 422 65 -198 minecraft:light_gray_concrete
fill 392 65 -197 416 65 -197 minecraft:grass_block
setblock 417 65 -197 minecraft:smooth_quartz
fill 418 65 -197 422 65 -197 minecraft:light_gray_concrete
fill 392 65 -196 416 65 -196 minecraft:grass_block
setblock 417 65 -196 minecraft:smooth_quartz
fill 418 65 -196 420 65 -196 minecraft:light_gray_concrete
setblock 421 65 -196 minecraft:sea_lantern
setblock 422 65 -196 minecraft:light_gray_concrete
fill 392 65 -195 416 65 -195 minecraft:grass_block
setblock 417 65 -195 minecraft:smooth_quartz
fill 418 65 -195 419 65 -195 minecraft:light_gray_concrete
setblock 420 65 -195 minecraft:sea_lantern
fill 421 65 -195 422 65 -195 minecraft:light_gray_concrete
fill 392 65 -194 416 65 -194 minecraft:grass_block
setblock 417 65 -194 minecraft:smooth_quartz
setblock 418 65 -194 minecraft:light_gray_concrete
setblock 419 65 -194 minecraft:sea_lantern
fill 420 65 -194 422 65 -194 minecraft:light_gray_concrete
fill 392 65 -193 416 65 -193 minecraft:grass_block
setblock 417 65 -193 minecraft:smooth_quartz
setblock 418 65 -193 minecraft:sea_lantern
fill 419 65 -193 422 65 -193 minecraft:light_gray_concrete
fill 392 65 -192 416 65 -192 minecraft:grass_block
setblock 417 65 -192 minecraft:smooth_quartz
fill 418 65 -192 422 65 -192 minecraft:light_gray_concrete
fill 392 65 -191 416 65 -191 minecraft:grass_block
setblock 417 65 -191 minecraft:smooth_quartz
fill 418 65 -191 422 65 -191 minecraft:light_gray_concrete
setblock 412 66 -246 minecraft:oak_log
setblock 392 66 -234 minecraft:oxeye_daisy
setblock 399 66 -234 minecraft:azure_bluet
fill 401 66 -234 402 66 -234 minecraft:orange_tulip
setblock 404 66 -234 minecraft:allium
setblock 406 66 -234 minecraft:allium
fill 408 66 -234 409 66 -234 minecraft:dandelion
setblock 411 66 -234 minecraft:dandelion
setblock 413 66 -234 minecraft:cornflower
setblock 415 66 -234 minecraft:cornflower
fill 392 66 -233 393 66 -233 minecraft:oxeye_daisy
setblock 395 66 -233 minecraft:oxeye_daisy
fill 397 66 -233 398 66 -233 minecraft:azure_bluet
fill 400 66 -233 401 66 -233 minecraft:orange_tulip
setblock 403 66 -233 minecraft:orange_tulip
fill 405 66 -233 406 66 -233 minecraft:allium
fill 414 66 -233 415 66 -233 minecraft:cornflower
fill 392 66 -232 393 66 -232 minecraft:oxeye_daisy
fill 396 66 -232 399 66 -232 minecraft:azure_bluet
fill 400 66 -232 401 66 -232 minecraft:orange_tulip
setblock 404 66 -232 minecraft:allium
setblock 407 66 -232 minecraft:allium
fill 409 66 -232 410 66 -232 minecraft:dandelion
fill 412 66 -232 413 66 -232 minecraft:cornflower
setblock 392 66 -231 minecraft:oxeye_daisy
fill 394 66 -231 395 66 -231 minecraft:oxeye_daisy
fill 396 66 -231 397 66 -231 minecraft:azure_bluet
setblock 399 66 -231 minecraft:azure_bluet
fill 400 66 -231 401 66 -231 minecraft:orange_tulip
setblock 404 66 -231 minecraft:allium
fill 406 66 -231 407 66 -231 minecraft:allium
setblock 408 66 -231 minecraft:dandelion
setblock 411 66 -231 minecraft:dandelion
setblock 412 66 -231 minecraft:cornflower
setblock 392 66 -230 minecraft:oxeye_daisy
fill 394 66 -230 395 66 -230 minecraft:oxeye_daisy
fill 396 66 -230 397 66 -230 minecraft:azure_bluet
setblock 399 66 -230 minecraft:azure_bluet
fill 400 66 -230 403 66 -230 minecraft:orange_tulip
fill 404 66 -230 406 66 -230 minecraft:allium
fill 408 66 -230 410 66 -230 minecraft:dandelion
fill 414 66 -230 415 66 -230 minecraft:cornflower
setblock 393 66 -229 minecraft:oxeye_daisy
setblock 395 66 -229 minecraft:oxeye_daisy
fill 397 66 -229 399 66 -229 minecraft:azure_bluet
fill 401 66 -229 402 66 -229 minecraft:orange_tulip
setblock 404 66 -229 minecraft:allium
fill 406 66 -229 407 66 -229 minecraft:allium
fill 408 66 -229 409 66 -229 minecraft:dandelion
setblock 411 66 -229 minecraft:dandelion
setblock 412 66 -229 minecraft:cornflower
setblock 414 66 -229 minecraft:cornflower
fill 393 66 -228 394 66 -228 minecraft:oxeye_daisy
setblock 400 66 -228 minecraft:orange_tulip
setblock 403 66 -228 minecraft:orange_tulip
fill 404 66 -228 405 66 -228 minecraft:allium
setblock 408 66 -228 minecraft:dandelion
setblock 410 66 -228 minecraft:dandelion
setblock 412 66 -228 minecraft:cornflower
setblock 392 66 -227 minecraft:oxeye_daisy
fill 398 66 -227 399 66 -227 minecraft:azure_bluet
fill 405 66 -227 407 66 -227 minecraft:allium
setblock 411 66 -227 minecraft:dandelion
setblock 414 66 -227 minecraft:cornflower
setblock 394 66 -226 minecraft:oxeye_daisy
setblock 396 66 -226 minecraft:azure_bluet
fill 398 66 -226 399 66 -226 minecraft:azure_bluet
fill 401 66 -226 402 66 -226 minecraft:orange_tulip
setblock 407 66 -226 minecraft:allium
fill 410 66 -226 411 66 -226 minecraft:dandelion
setblock 412 66 -226 minecraft:cornflower
setblock 414 66 -226 minecraft:cornflower
setblock 395 66 -225 minecraft:oxeye_daisy
setblock 399 66 -225 minecraft:azure_bluet
setblock 400 66 -225 minecraft:orange_tulip
setblock 402 66 -225 minecraft:orange_tulip
fill 404 66 -225 407 66 -225 minecraft:allium
fill 410 66 -225 411 66 -225 minecraft:dandelion
fill 393 66 -224 395 66 -224 minecraft:oxeye_daisy
setblock 397 66 -224 minecraft:azure_bluet
setblock 399 66 -224 minecraft:azure_bluet
fill 400 66 -224 402 66 -224 minecraft:orange_tulip
fill 404 66 -224 405 66 -224 minecraft:allium
setblock 407 66 -224 minecraft:allium
setblock 410 66 -224 minecraft:dandelion
fill 412 66 -224 413 66 -224 minecraft:cornflower
setblock 395 66 -223 minecraft:oxeye_daisy
setblock 399 66 -223 minecraft:azure_bluet
setblock 400 66 -223 minecraft:orange_tulip
fill 402 66 -223 403 66 -223 minecraft:orange_tulip
setblock 408 66 -223 minecraft:dandelion
setblock 411 66 -223 minecraft:dandelion
setblock 412 66 -223 minecraft:cornflower
setblock 414 66 -223 minecraft:cornflower
setblock 392 66 -222 minecraft:oxeye_daisy
setblock 394 66 -222 minecraft:oxeye_daisy
fill 397 66 -222 398 66 -222 minecraft:azure_bluet
setblock 400 66 -222 minecraft:orange_tulip
setblock 403 66 -222 minecraft:orange_tulip
setblock 408 66 -222 minecraft:dandelion
fill 410 66 -222 411 66 -222 minecraft:dandelion
fill 412 66 -222 415 66 -222 minecraft:cornflower
fill 393 66 -221 395 66 -221 minecraft:oxeye_daisy
fill 396 66 -221 399 66 -221 minecraft:azure_bluet
fill 405 66 -221 407 66 -221 minecraft:allium
setblock 410 66 -221 minecraft:dandelion
setblock 412 66 -221 minecraft:cornflower
fill 414 66 -221 415 66 -221 minecraft:cornflower
fill 392 66 -220 395 66 -220 minecraft:oxeye_daisy
fill 396 66 -220 398 66 -220 minecraft:azure_bluet
setblock 402 66 -220 minecraft:orange_tulip
setblock 404 66 -220 minecraft:allium
setblock 410 66 -220 minecraft:dandelion
setblock 412 66 -220 minecraft:cornflower
fill 414 66 -220 415 66 -220 minecraft:cornflower
fill 392 66 -219 395 66 -219 minecraft:oxeye_daisy
setblock 396 66 -219 minecraft:azure_bluet
setblock 398 66 -219 minecraft:azure_bluet
fill 400 66 -219 403 66 -219 minecraft:orange_tulip
setblock 405 66 -219 minecraft:allium
fill 409 66 -219 411 66 -219 minecraft:dandelion
fill 414 66 -219 415 66 -219 minecraft:cornflower
fill 392 66 -218 393 66 -218 minecraft:oxeye_daisy
fill 396 66 -218 397 66 -218 minecraft:azure_bluet
fill 402 66 -218 403 66 -218 minecraft:orange_tulip
fill 405 66 -218 406 66 -218 minecraft:allium
fill 412 66 -218 413 66 -218 minecraft:cornflower
setblock 415 66 -218 minecraft:cornflower
setblock 392 66 -217 minecraft:oxeye_daisy
fill 394 66 -217 395 66 -217 minecraft:oxeye_daisy
fill 396 66 -217 397 66 -217 minecraft:azure_bluet
setblock 400 66 -217 minecraft:orange_tulip
fill 402 66 -217 403 66 -217 minecraft:orange_tulip
setblock 405 66 -217 minecraft:allium
setblock 408 66 -217 minecraft:dandelion
setblock 410 66 -217 minecraft:dandelion
fill 413 66 -217 415 66 -217 minecraft:cornflower
setblock 395 66 -216 minecraft:oxeye_daisy
fill 396 66 -216 399 66 -216 minecraft:azure_bluet
setblock 400 66 -216 minecraft:orange_tulip
fill 402 66 -216 403 66 -216 minecraft:orange_tulip
setblock 406 66 -216 minecraft:allium
fill 410 66 -216 411 66 -216 minecraft:dandelion
setblock 412 66 -216 minecraft:cornflower
fill 414 66 -216 415 66 -216 minecraft:cornflower
fill 393 66 -215 394 66 -215 minecraft:oxeye_daisy
setblock 397 66 -215 minecraft:azure_bluet
setblock 399 66 -215 minecraft:azure_bluet
setblock 406 66 -215 minecraft:allium
fill 408 66 -215 411 66 -215 minecraft:dandelion
fill 413 66 -215 414 66 -215 minecraft:cornflower
setblock 392 66 -214 minecraft:oxeye_daisy
setblock 395 66 -214 minecraft:oxeye_daisy
setblock 396 66 -214 minecraft:azure_bluet
setblock 400 66 -214 minecraft:orange_tulip
fill 402 66 -214 403 66 -214 minecraft:orange_tulip
setblock 405 66 -214 minecraft:allium
setblock 408 66 -214 minecraft:dandelion
fill 410 66 -214 411 66 -214 minecraft:dandelion
fill 412 66 -214 415 66 -214 minecraft:cornflower
fill 394 66 -213 395 66 -213 minecraft:oxeye_daisy
fill 401 66 -213 402 66 -213 minecraft:orange_tulip
fill 404 66 -213 406 66 -213 minecraft:allium
setblock 408 66 -213 minecraft:dandelion
fill 410 66 -213 411 66 -213 minecraft:dandelion
fill 413 66 -213 415 66 -213 minecraft:cornflower
setblock 393 66 -212 minecraft:oxeye_daisy
fill 396 66 -212 399 66 -212 minecraft:azure_bluet
setblock 402 66 -212 minecraft:orange_tulip
fill 404 66 -212 406 66 -212 minecraft:allium
setblock 410 66 -212 minecraft:dandelion
setblock 412 66 -212 minecraft:cornflower
fill 414 66 -212 415 66 -212 minecraft:cornflower
fill 392 66 -211 394 66 -211 minecraft:oxeye_daisy
fill 396 66 -211 398 66 -211 minecraft:azure_bluet
fill 400 66 -211 403 66 -211 minecraft:orange_tulip
fill 405 66 -211 407 66 -211 minecraft:allium
fill 408 66 -211 410 66 -211 minecraft:dandelion
fill 413 66 -211 415 66 -211 minecraft:cornflower
fill 392 66 -210 394 66 -210 minecraft:oxeye_daisy
setblock 397 66 -210 minecraft:azure_bluet
setblock 399 66 -210 minecraft:azure_bluet
setblock 403 66 -210 minecraft:orange_tulip
setblock 404 66 -210 minecraft:allium
setblock 406 66 -210 minecraft:allium
setblock 408 66 -210 minecraft:dandelion
setblock 410 66 -210 minecraft:dandelion
fill 413 66 -210 415 66 -210 minecraft:cornflower
fill 393 66 -209 395 66 -209 minecraft:oxeye_daisy
fill 397 66 -209 399 66 -209 minecraft:azure_bluet
fill 400 66 -209 403 66 -209 minecraft:orange_tulip
fill 404 66 -209 406 66 -209 minecraft:allium
fill 408 66 -209 409 66 -209 minecraft:dandelion
setblock 414 66 -209 minecraft:cornflower
fill 392 66 -208 395 66 -208 minecraft:oxeye_daisy
fill 397 66 -208 399 66 -208 minecraft:azure_bluet
fill 400 66 -208 401 66 -208 minecraft:orange_tulip
setblock 403 66 -208 minecraft:orange_tulip
fill 405 66 -208 406 66 -208 minecraft:allium
fill 408 66 -208 410 66 -208 minecraft:dandelion
setblock 412 66 -208 minecraft:cornflower
setblock 414 66 -208 minecraft:cornflower
fill 392 66 -207 395 66 -207 minecraft:oxeye_daisy
fill 398 66 -207 399 66 -207 minecraft:azure_bluet
fill 402 66 -207 403 66 -207 minecraft:orange_tulip
fill 404 66 -207 405 66 -207 minecraft:allium
setblock 407 66 -207 minecraft:allium
setblock 408 66 -207 minecraft:dandelion
setblock 410 66 -207 minecraft:dandelion
fill 412 66 -207 415 66 -207 minecraft:cornflower
fill 392 66 -206 395 66 -206 minecraft:oxeye_daisy
fill 397 66 -206 399 66 -206 minecraft:azure_bluet
setblock 401 66 -206 minecraft:orange_tulip
fill 406 66 -206 407 66 -206 minecraft:allium
setblock 409 66 -206 minecraft:dandelion
fill 413 66 -206 415 66 -206 minecraft:cornflower
setblock 392 66 -205 minecraft:oxeye_daisy
setblock 394 66 -205 minecraft:oxeye_daisy
fill 396 66 -205 397 66 -205 minecraft:azure_bluet
setblock 399 66 -205 minecraft:azure_bluet
setblock 403 66 -205 minecraft:orange_tulip
setblock 404 66 -205 minecraft:allium
setblock 407 66 -205 minecraft:allium
setblock 408 66 -205 minecraft:dandelion
fill 412 66 -205 413 66 -205 minecraft:cornflower
setblock 395 66 -204 minecraft:oxeye_daisy
fill 396 66 -204 399 66 -204 minecraft:azure_bluet
fill 400 66 -204 401 66 -204 minecraft:orange_tulip
fill 404 66 -204 405 66 -204 minecraft:allium
fill 409 66 -204 411 66 -204 minecraft:dandelion
setblock 412 66 -204 minecraft:cornflower
setblock 392 66 -203 minecraft:oxeye_daisy
fill 394 66 -203 395 66 -203 minecraft:oxeye_daisy
setblock 396 66 -203 minecraft:azure_bluet
setblock 401 66 -203 minecraft:orange_tulip
setblock 403 66 -203 minecraft:orange_tulip
fill 405 66 -203 406 66 -203 minecraft:allium
setblock 409 66 -203 minecraft:dandelion
fill 413 66 -203 415 66 -203 minecraft:cornflower
setblock 392 66 -202 minecraft:oxeye_daisy
setblock 394 66 -202 minecraft:oxeye_daisy
fill 398 66 -202 399 66 -202 minecraft:azure_bluet
fill 401 66 -202 403 66 -202 minecraft:orange_tulip
setblock 404 66 -202 minecraft:allium
setblock 406 66 -202 minecraft:allium
setblock 408 66 -202 minecraft:dandelion
setblock 411 66 -202 minecraft:dandelion
fill 412 66 -202 414 66 -202 minecraft:cornflower
fill 392 66 -201 395 66 -201 minecraft:oxeye_daisy
fill 397 66 -201 399 66 -201 minecraft:azure_bluet
setblock 400 66 -201 minecraft:orange_tulip
setblock 402 66 -201 minecraft:orange_tulip
setblock 404 66 -201 minecraft:allium
fill 406 66 -201 407 66 -201 minecraft:allium
fill 408 66 -201 411 66 -201 minecraft:dandelion
setblock 415 66 -201 minecraft:cornflower
setblock 392 66 -200 minecraft:oxeye_daisy
fill 394 66 -200 395 66 -200 minecraft:oxeye_daisy
fill 397 66 -200 398 66 -200 minecraft:azure_bluet
fill 400 66 -200 401 66 -200 minecraft:orange_tulip
setblock 403 66 -200 minecraft:orange_tulip
setblock 404 66 -200 minecraft:allium
fill 406 66 -200 407 66 -200 minecraft:allium
setblock 408 66 -200 minecraft:dandelion
setblock 411 66 -200 minecraft:dandelion
setblock 412 66 -200 minecraft:cornflower
fill 414 66 -200 415 66 -200 minecraft:cornflower
setblock 393 66 -199 minecraft:oxeye_daisy
setblock 395 66 -199 minecraft:oxeye_daisy
fill 396 66 -199 399 66 -199 minecraft:azure_bluet
setblock 401 66 -199 minecraft:orange_tulip
setblock 409 66 -199 minecraft:dandelion
setblock 411 66 -199 minecraft:dandelion
fill 412 66 -199 413 66 -199 minecraft:cornflower
fill 393 66 -198 394 66 -198 minecraft:oxeye_daisy
fill 396 66 -198 398 66 -198 minecraft:azure_bluet
setblock 401 66 -198 minecraft:orange_tulip
setblock 404 66 -198 minecraft:allium
fill 406 66 -198 407 66 -198 minecraft:allium
fill 410 66 -198 411 66 -198 minecraft:dandelion
setblock 412 66 -198 minecraft:cornflower
setblock 414 66 -198 minecraft:cornflower
setblock 393 66 -197 minecraft:oxeye_daisy
setblock 395 66 -197 minecraft:oxeye_daisy
fill 396 66 -197 398 66 -197 minecraft:azure_bluet
setblock 400 66 -197 minecraft:orange_tulip
setblock 403 66 -197 minecraft:orange_tulip
fill 405 66 -197 406 66 -197 minecraft:allium
setblock 409 66 -197 minecraft:dandelion
setblock 411 66 -197 minecraft:dandelion
fill 412 66 -197 413 66 -197 minecraft:cornflower
setblock 415 66 -197 minecraft:cornflower
fill 392 66 -196 394 66 -196 minecraft:oxeye_daisy
fill 396 66 -196 397 66 -196 minecraft:azure_bluet
setblock 399 66 -196 minecraft:azure_bluet
setblock 400 66 -196 minecraft:orange_tulip
setblock 404 66 -196 minecraft:allium
setblock 406 66 -196 minecraft:allium
fill 408 66 -196 409 66 -196 minecraft:dandelion
fill 413 66 -196 414 66 -196 minecraft:cornflower
fill 392 66 -195 395 66 -195 minecraft:oxeye_daisy
setblock 396 66 -195 minecraft:azure_bluet
setblock 399 66 -195 minecraft:azure_bluet
fill 400 66 -195 401 66 -195 minecraft:orange_tulip
setblock 403 66 -195 minecraft:orange_tulip
fill 406 66 -195 407 66 -195 minecraft:allium
setblock 410 66 -195 minecraft:dandelion
setblock 412 66 -195 minecraft:cornflower
setblock 414 66 -195 minecraft:cornflower
fill 392 66 -194 393 66 -194 minecraft:oxeye_daisy
fill 397 66 -194 399 66 -194 minecraft:azure_bluet
setblock 403 66 -194 minecraft:orange_tulip
fill 404 66 -194 405 66 -194 minecraft:allium
setblock 407 66 -194 minecraft:allium
fill 410 66 -194 411 66 -194 minecraft:dandelion
setblock 414 66 -194 minecraft:cornflower
setblock 394 66 -193 minecraft:oxeye_daisy
fill 396 66 -193 399 66 -193 minecraft:azure_bluet
fill 401 66 -193 403 66 -193 minecraft:orange_tulip
fill 406 66 -193 407 66 -193 minecraft:allium
setblock 408 66 -193 minecraft:dandelion
fill 410 66 -193 411 66 -193 minecraft:dandelion
setblock 413 66 -193 minecraft:cornflower
setblock 395 66 -192 minecraft:oxeye_daisy
setblock 400 66 -192 minecraft:orange_tulip
setblock 403 66 -192 minecraft:orange_tulip
fill 404 66 -192 407 66 -192 minecraft:allium
fill 409 66 -192 411 66 -192 minecraft:dandelion
fill 413 66 -192 414 66 -192 minecraft:cornflower
setblock 392 66 -191 minecraft:oxeye_daisy
fill 396 66 -191 399 66 -191 minecraft:azure_bluet
setblock 402 66 -191 minecraft:orange_tulip
setblock 407 66 -191 minecraft:allium
fill 409 66 -191 411 66 -191 minecraft:dandelion
fill 413 66 -191 414 66 -191 minecraft:cornflower
setblock 412 67 -246 minecraft:oak_log
setblock 412 68 -246 minecraft:oak_log
setblock 412 69 -254 minecraft:oak_leaves[persistent=true]
setblock 412 69 -248 minecraft:oak_leaves[persistent=true]
fill 411 69 -247 413 69 -247 minecraft:oak_leaves[persistent=true]
fill 410 69 -246 411 69 -246 minecraft:oak_leaves[persistent=true]
setblock 412 69 -246 minecraft:oak_log
fill 413 69 -246 414 69 -246 minecraft:oak_leaves[persistent=true]
fill 411 69 -245 413 69 -245 minecraft:oak_leaves[persistent=true]
setblock 412 69 -244 minecraft:oak_leaves[persistent=true]
fill 411 70 -254 413 70 -254 minecraft:oak_leaves[persistent=true]
fill 411 70 -248 413 70 -248 minecraft:oak_leaves[persistent=true]
fill 410 70 -247 414 70 -247 minecraft:oak_leaves[persistent=true]
fill 410 70 -246 411 70 -246 minecraft:oak_leaves[persistent=true]
setblock 412 70 -246 minecraft:oak_log
fill 413 70 -246 414 70 -246 minecraft:oak_leaves[persistent=true]
fill 410 70 -245 414 70 -245 minecraft:oak_leaves[persistent=true]
fill 411 70 -244 413 70 -244 minecraft:oak_leaves[persistent=true]
setblock 412 71 -254 minecraft:oak_leaves[persistent=true]
setblock 412 71 -248 minecraft:oak_leaves[persistent=true]
fill 411 71 -247 413 71 -247 minecraft:oak_leaves[persistent=true]
fill 410 71 -246 414 71 -246 minecraft:oak_leaves[persistent=true]
fill 411 71 -245 413 71 -245 minecraft:oak_leaves[persistent=true]
setblock 412 71 -244 minecraft:oak_leaves[persistent=true]
setblock 412 72 -246 minecraft:oak_leaves[persistent=true]
forceload remove 392 -254 455 -191
tellraw @a {"text":"Campus bau a28 fertig.","color":"green"}
