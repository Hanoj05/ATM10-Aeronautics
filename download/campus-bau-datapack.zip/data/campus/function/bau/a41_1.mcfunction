setblock 386 45 -126 minecraft:stone
fill 383 45 -124 384 45 -124 minecraft:stone
fill 383 45 -123 384 45 -123 minecraft:stone
setblock 383 45 -122 minecraft:stone
fill 373 47 -120 375 47 -120 minecraft:stone
fill 373 47 -119 375 47 -119 minecraft:stone
fill 373 47 -118 375 47 -118 minecraft:stone
fill 372 47 -117 375 47 -117 minecraft:stone
fill 372 47 -116 375 47 -116 minecraft:stone
setblock 391 48 -124 minecraft:stone
setblock 391 48 -123 minecraft:stone
fill 375 48 -122 378 48 -122 minecraft:stone
setblock 391 48 -122 minecraft:stone
fill 374 48 -121 378 48 -121 minecraft:stone
setblock 391 48 -121 minecraft:stone
fill 373 48 -120 378 48 -120 minecraft:stone
setblock 391 48 -120 minecraft:stone
fill 372 48 -119 377 48 -119 minecraft:stone
setblock 391 48 -119 minecraft:stone
fill 372 48 -118 376 48 -118 minecraft:stone
fill 390 48 -118 391 48 -118 minecraft:stone
fill 372 48 -117 375 48 -117 minecraft:stone
fill 389 48 -117 391 48 -117 minecraft:stone
fill 371 48 -116 375 48 -116 minecraft:stone
fill 389 49 -126 391 49 -126 minecraft:stone
fill 379 49 -125 382 49 -125 minecraft:stone
fill 389 49 -125 391 49 -125 minecraft:stone
fill 379 49 -124 382 49 -124 minecraft:stone
fill 389 49 -124 391 49 -124 minecraft:stone
fill 376 49 -123 382 49 -123 minecraft:stone
fill 389 49 -123 391 49 -123 minecraft:stone
fill 375 49 -122 381 49 -122 minecraft:stone
fill 389 49 -122 391 49 -122 minecraft:stone
setblock 340 49 -121 minecraft:stone
fill 374 49 -121 379 49 -121 minecraft:stone
fill 389 49 -121 391 49 -121 minecraft:stone
setblock 340 49 -120 minecraft:stone
fill 373 49 -120 379 49 -120 minecraft:stone
fill 389 49 -120 391 49 -120 minecraft:stone
fill 372 49 -119 378 49 -119 minecraft:stone
fill 388 49 -119 391 49 -119 minecraft:stone
fill 372 49 -118 376 49 -118 minecraft:stone
fill 387 49 -118 391 49 -118 minecraft:stone
fill 372 49 -117 375 49 -117 minecraft:stone
fill 387 49 -117 391 49 -117 minecraft:stone
fill 371 49 -116 375 49 -116 minecraft:stone
fill 377 50 -126 391 50 -126 minecraft:stone
fill 378 50 -125 391 50 -125 minecraft:stone
setblock 340 50 -124 minecraft:stone
fill 378 50 -124 391 50 -124 minecraft:stone
setblock 340 50 -123 minecraft:stone
fill 376 50 -123 391 50 -123 minecraft:stone
fill 339 50 -122 341 50 -122 minecraft:stone
fill 375 50 -122 391 50 -122 minecraft:stone
fill 339 50 -121 342 50 -121 minecraft:stone
fill 374 50 -121 381 50 -121 minecraft:stone
fill 383 50 -121 391 50 -121 minecraft:stone
fill 338 50 -120 343 50 -120 minecraft:stone
fill 374 50 -120 379 50 -120 minecraft:stone
fill 384 50 -120 391 50 -120 minecraft:stone
fill 338 50 -119 344 50 -119 minecraft:stone
fill 373 50 -119 378 50 -119 minecraft:stone
fill 384 50 -119 391 50 -119 minecraft:stone
fill 338 50 -118 344 50 -118 minecraft:stone
fill 373 50 -118 376 50 -118 minecraft:stone
fill 385 50 -118 391 50 -118 minecraft:stone
fill 338 50 -117 344 50 -117 minecraft:stone
fill 372 50 -117 374 50 -117 minecraft:stone
fill 385 50 -117 391 50 -117 minecraft:stone
fill 328 50 -116 335 50 -116 minecraft:stone
fill 338 50 -116 344 50 -116 minecraft:stone
fill 372 50 -116 374 50 -116 minecraft:stone
fill 385 50 -116 386 50 -116 minecraft:stone
fill 371 51 -126 391 51 -126 minecraft:stone
setblock 340 51 -125 minecraft:stone
fill 371 51 -125 391 51 -125 minecraft:stone
fill 339 51 -124 341 51 -124 minecraft:stone
fill 371 51 -124 391 51 -124 minecraft:stone
fill 338 51 -123 341 51 -123 minecraft:stone
fill 372 51 -123 391 51 -123 minecraft:stone
fill 338 51 -122 342 51 -122 minecraft:stone
fill 373 51 -122 391 51 -122 minecraft:stone
fill 336 51 -121 343 51 -121 minecraft:stone
fill 374 51 -121 391 51 -121 minecraft:stone
fill 335 51 -120 345 51 -120 minecraft:stone
fill 374 51 -120 391 51 -120 minecraft:stone
fill 328 51 -119 329 51 -119 minecraft:stone
fill 334 51 -119 345 51 -119 minecraft:stone
fill 375 51 -119 391 51 -119 minecraft:stone
fill 328 51 -118 345 51 -118 minecraft:stone
fill 375 51 -118 391 51 -118 minecraft:stone
fill 328 51 -117 346 51 -117 minecraft:stone
fill 375 51 -117 391 51 -117 minecraft:stone
fill 328 51 -116 346 51 -116 minecraft:stone
fill 376 51 -116 386 51 -116 minecraft:stone
setblock 340 52 -126 minecraft:stone
fill 366 52 -126 391 52 -126 minecraft:stone
fill 338 52 -125 341 52 -125 minecraft:stone
fill 366 52 -125 391 52 -125 minecraft:stone
fill 337 52 -124 341 52 -124 minecraft:stone
fill 366 52 -124 391 52 -124 minecraft:stone
fill 336 52 -123 342 52 -123 minecraft:stone
fill 365 52 -123 391 52 -123 minecraft:stone
fill 335 52 -122 343 52 -122 minecraft:stone
fill 365 52 -122 391 52 -122 minecraft:stone
fill 328 52 -121 331 52 -121 minecraft:stone
fill 333 52 -121 345 52 -121 minecraft:stone
fill 365 52 -121 391 52 -121 minecraft:stone
fill 328 52 -120 346 52 -120 minecraft:stone
fill 352 52 -120 391 52 -120 minecraft:stone
fill 328 52 -119 347 52 -119 minecraft:stone
fill 351 52 -119 391 52 -119 minecraft:stone
fill 328 52 -118 347 52 -118 minecraft:stone
fill 349 52 -118 391 52 -118 minecraft:stone
fill 328 52 -117 391 52 -117 minecraft:stone
fill 328 52 -116 386 52 -116 minecraft:stone
fill 338 53 -126 341 53 -126 minecraft:stone
fill 350 53 -126 391 53 -126 minecraft:stone
fill 336 53 -125 342 53 -125 minecraft:stone
fill 350 53 -125 391 53 -125 minecraft:stone
fill 335 53 -124 342 53 -124 minecraft:stone
fill 349 53 -124 391 53 -124 minecraft:stone
fill 334 53 -123 343 53 -123 minecraft:stone
fill 348 53 -123 391 53 -123 minecraft:stone
fill 328 53 -122 391 53 -122 minecraft:stone
fill 328 53 -121 391 53 -121 minecraft:stone
fill 328 53 -120 391 53 -120 minecraft:stone
fill 328 53 -119 391 53 -119 minecraft:stone
fill 328 53 -118 391 53 -118 minecraft:stone
fill 328 53 -117 391 53 -117 minecraft:stone
fill 328 53 -116 386 53 -116 minecraft:stone
fill 335 54 -126 342 54 -126 minecraft:stone
fill 346 54 -126 391 54 -126 minecraft:stone
fill 334 54 -125 343 54 -125 minecraft:stone
fill 346 54 -125 391 54 -125 minecraft:stone
fill 333 54 -124 343 54 -124 minecraft:stone
fill 345 54 -124 391 54 -124 minecraft:stone
fill 328 54 -123 391 54 -123 minecraft:stone
fill 328 54 -122 391 54 -122 minecraft:stone
fill 328 54 -121 391 54 -121 minecraft:stone
fill 328 54 -120 391 54 -120 minecraft:stone
fill 328 54 -119 391 54 -119 minecraft:stone
fill 328 54 -118 391 54 -118 minecraft:stone
fill 328 54 -117 391 54 -117 minecraft:stone
fill 328 54 -116 386 54 -116 minecraft:stone
fill 328 55 -126 391 55 -126 minecraft:stone
fill 328 55 -125 391 55 -125 minecraft:stone
fill 328 55 -124 391 55 -124 minecraft:stone
fill 328 55 -123 391 55 -123 minecraft:stone
fill 328 55 -122 391 55 -122 minecraft:stone
fill 328 55 -121 391 55 -121 minecraft:stone
fill 328 55 -120 391 55 -120 minecraft:stone
fill 328 55 -119 391 55 -119 minecraft:stone
fill 328 55 -118 391 55 -118 minecraft:stone
fill 328 55 -117 391 55 -117 minecraft:stone
fill 328 55 -116 386 55 -116 minecraft:stone
fill 328 56 -126 391 56 -126 minecraft:stone
fill 328 56 -125 391 56 -125 minecraft:stone
fill 328 56 -124 391 56 -124 minecraft:stone
fill 328 56 -123 391 56 -123 minecraft:stone
fill 328 56 -122 391 56 -122 minecraft:stone
fill 328 56 -121 391 56 -121 minecraft:stone
fill 328 56 -120 391 56 -120 minecraft:stone
fill 328 56 -119 391 56 -119 minecraft:stone
fill 328 56 -118 391 56 -118 minecraft:stone
fill 328 56 -117 391 56 -117 minecraft:stone
fill 328 56 -116 386 56 -116 minecraft:stone
fill 328 57 -126 391 57 -126 minecraft:stone
fill 328 57 -125 391 57 -125 minecraft:stone
fill 328 57 -124 391 57 -124 minecraft:stone
fill 328 57 -123 391 57 -123 minecraft:stone
fill 328 57 -122 391 57 -122 minecraft:stone
fill 328 57 -121 391 57 -121 minecraft:stone
fill 328 57 -120 391 57 -120 minecraft:stone
fill 328 57 -119 391 57 -119 minecraft:stone
fill 328 57 -118 391 57 -118 minecraft:stone
fill 328 57 -117 391 57 -117 minecraft:stone
fill 328 57 -116 386 57 -116 minecraft:stone
fill 328 58 -126 391 58 -126 minecraft:stone
fill 328 58 -125 391 58 -125 minecraft:stone
fill 328 58 -124 391 58 -124 minecraft:stone
fill 328 58 -123 391 58 -123 minecraft:stone
fill 328 58 -122 391 58 -122 minecraft:stone
fill 328 58 -121 391 58 -121 minecraft:stone
fill 328 58 -120 391 58 -120 minecraft:stone
fill 328 58 -119 391 58 -119 minecraft:stone
fill 328 58 -118 391 58 -118 minecraft:stone
fill 328 58 -117 391 58 -117 minecraft:stone
fill 328 58 -116 386 58 -116 minecraft:stone
fill 328 59 -126 391 59 -126 minecraft:stone
fill 328 59 -125 391 59 -125 minecraft:stone
fill 328 59 -124 391 59 -124 minecraft:stone
fill 328 59 -123 391 59 -123 minecraft:stone
fill 328 59 -122 391 59 -122 minecraft:stone
fill 328 59 -121 391 59 -121 minecraft:stone
fill 328 59 -120 391 59 -120 minecraft:stone
fill 328 59 -119 391 59 -119 minecraft:stone
fill 328 59 -118 391 59 -118 minecraft:stone
fill 328 59 -117 391 59 -117 minecraft:stone
fill 328 59 -116 386 59 -116 minecraft:stone
fill 328 60 -126 391 60 -126 minecraft:stone
fill 328 60 -125 391 60 -125 minecraft:stone
fill 328 60 -124 391 60 -124 minecraft:stone
fill 328 60 -123 391 60 -123 minecraft:stone
fill 328 60 -122 391 60 -122 minecraft:stone
fill 328 60 -121 391 60 -121 minecraft:stone
fill 328 60 -120 391 60 -120 minecraft:stone
fill 328 60 -119 391 60 -119 minecraft:stone
fill 328 60 -118 391 60 -118 minecraft:stone
fill 328 60 -117 391 60 -117 minecraft:stone
fill 328 60 -116 386 60 -116 minecraft:stone
fill 328 61 -126 391 61 -126 minecraft:stone
fill 328 61 -125 391 61 -125 minecraft:stone
fill 328 61 -124 391 61 -124 minecraft:stone
fill 328 61 -123 391 61 -123 minecraft:stone
fill 328 61 -122 391 61 -122 minecraft:stone
fill 328 61 -121 391 61 -121 minecraft:stone
fill 328 61 -120 391 61 -120 minecraft:stone
fill 328 61 -119 391 61 -119 minecraft:stone
fill 328 61 -118 391 61 -118 minecraft:stone
fill 328 61 -117 391 61 -117 minecraft:stone
fill 328 61 -116 386 61 -116 minecraft:stone
fill 328 62 -126 391 62 -126 minecraft:dirt
fill 328 62 -125 391 62 -125 minecraft:dirt
fill 328 62 -124 391 62 -124 minecraft:dirt
fill 328 62 -123 391 62 -123 minecraft:dirt
fill 328 62 -122 391 62 -122 minecraft:dirt
fill 328 62 -121 391 62 -121 minecraft:dirt
fill 328 62 -120 391 62 -120 minecraft:dirt
fill 328 62 -119 391 62 -119 minecraft:dirt
fill 328 62 -118 391 62 -118 minecraft:dirt
fill 328 62 -117 391 62 -117 minecraft:dirt
fill 328 62 -116 386 62 -116 minecraft:dirt
fill 328 63 -126 391 63 -126 minecraft:dirt
fill 328 63 -125 391 63 -125 minecraft:dirt
fill 328 63 -124 391 63 -124 minecraft:dirt
fill 328 63 -123 391 63 -123 minecraft:dirt
fill 328 63 -122 391 63 -122 minecraft:dirt
fill 328 63 -121 391 63 -121 minecraft:dirt
fill 328 63 -120 391 63 -120 minecraft:dirt
fill 328 63 -119 391 63 -119 minecraft:dirt
fill 328 63 -118 391 63 -118 minecraft:dirt
fill 328 63 -117 391 63 -117 minecraft:dirt
fill 328 63 -116 386 63 -116 minecraft:dirt
fill 328 64 -126 391 64 -126 minecraft:dirt
fill 328 64 -125 391 64 -125 minecraft:dirt
fill 328 64 -124 391 64 -124 minecraft:dirt
fill 328 64 -123 391 64 -123 minecraft:dirt
fill 328 64 -122 391 64 -122 minecraft:dirt
fill 328 64 -121 391 64 -121 minecraft:dirt
fill 328 64 -120 391 64 -120 minecraft:dirt
fill 328 64 -119 391 64 -119 minecraft:dirt
fill 328 64 -118 391 64 -118 minecraft:dirt
fill 328 64 -117 391 64 -117 minecraft:dirt
fill 328 64 -116 386 64 -116 minecraft:dirt
fill 328 65 -126 378 65 -126 minecraft:grass_block
setblock 379 65 -126 minecraft:light_gray_concrete
fill 380 65 -126 382 65 -126 minecraft:smooth_quartz
setblock 383 65 -126 minecraft:light_gray_concrete
fill 384 65 -126 391 65 -126 minecraft:grass_block
fill 328 65 -125 378 65 -125 minecraft:grass_block
setblock 379 65 -125 minecraft:light_gray_concrete
fill 380 65 -125 382 65 -125 minecraft:smooth_quartz
setblock 383 65 -125 minecraft:light_gray_concrete
fill 384 65 -125 391 65 -125 minecraft:grass_block
fill 328 65 -124 378 65 -124 minecraft:grass_block
setblock 379 65 -124 minecraft:light_gray_concrete
fill 380 65 -124 382 65 -124 minecraft:smooth_quartz
setblock 383 65 -124 minecraft:light_gray_concrete
fill 384 65 -124 391 65 -124 minecraft:grass_block
fill 328 65 -123 378 65 -123 minecraft:grass_block
setblock 379 65 -123 minecraft:light_gray_concrete
fill 380 65 -123 382 65 -123 minecraft:smooth_quartz
setblock 383 65 -123 minecraft:light_gray_concrete
fill 384 65 -123 391 65 -123 minecraft:grass_block
fill 328 65 -122 378 65 -122 minecraft:grass_block
setblock 379 65 -122 minecraft:light_gray_concrete
fill 380 65 -122 382 65 -122 minecraft:smooth_quartz
setblock 383 65 -122 minecraft:light_gray_concrete
fill 384 65 -122 386 65 -122 minecraft:grass_block
fill 387 65 -122 391 65 -122 minecraft:smooth_quartz
fill 328 65 -121 378 65 -121 minecraft:smooth_quartz
setblock 379 65 -121 minecraft:sea_lantern
fill 380 65 -121 382 65 -121 minecraft:smooth_quartz
setblock 383 65 -121 minecraft:sea_lantern
fill 384 65 -121 386 65 -121 minecraft:smooth_quartz
fill 387 65 -121 390 65 -121 minecraft:light_gray_concrete
setblock 391 65 -121 minecraft:sea_lantern
fill 328 65 -120 335 65 -120 minecraft:light_gray_concrete
setblock 336 65 -120 minecraft:sea_lantern
fill 337 65 -120 344 65 -120 minecraft:light_gray_concrete
setblock 345 65 -120 minecraft:sea_lantern
fill 346 65 -120 353 65 -120 minecraft:light_gray_concrete
setblock 354 65 -120 minecraft:sea_lantern
fill 355 65 -120 362 65 -120 minecraft:light_gray_concrete
setblock 363 65 -120 minecraft:sea_lantern
fill 364 65 -120 371 65 -120 minecraft:light_gray_concrete
setblock 372 65 -120 minecraft:sea_lantern
fill 373 65 -120 379 65 -120 minecraft:light_gray_concrete
fill 380 65 -120 382 65 -120 minecraft:smooth_quartz
fill 383 65 -120 389 65 -120 minecraft:light_gray_concrete
setblock 390 65 -120 minecraft:sea_lantern
setblock 391 65 -120 minecraft:light_gray_concrete
fill 328 65 -119 334 65 -119 minecraft:light_gray_concrete
setblock 335 65 -119 minecraft:sea_lantern
fill 336 65 -119 343 65 -119 minecraft:light_gray_concrete
setblock 344 65 -119 minecraft:sea_lantern
fill 345 65 -119 352 65 -119 minecraft:light_gray_concrete
setblock 353 65 -119 minecraft:sea_lantern
fill 354 65 -119 361 65 -119 minecraft:light_gray_concrete
setblock 362 65 -119 minecraft:sea_lantern
fill 363 65 -119 370 65 -119 minecraft:light_gray_concrete
setblock 371 65 -119 minecraft:sea_lantern
fill 372 65 -119 379 65 -119 minecraft:light_gray_concrete
fill 380 65 -119 382 65 -119 minecraft:smooth_quartz
fill 383 65 -119 388 65 -119 minecraft:light_gray_concrete
setblock 389 65 -119 minecraft:sea_lantern
fill 390 65 -119 391 65 -119 minecraft:light_gray_concrete
fill 328 65 -118 333 65 -118 minecraft:light_gray_concrete
setblock 334 65 -118 minecraft:sea_lantern
fill 335 65 -118 342 65 -118 minecraft:light_gray_concrete
setblock 343 65 -118 minecraft:sea_lantern
fill 344 65 -118 351 65 -118 minecraft:light_gray_concrete
setblock 352 65 -118 minecraft:sea_lantern
fill 353 65 -118 360 65 -118 minecraft:light_gray_concrete
setblock 361 65 -118 minecraft:sea_lantern
fill 362 65 -118 369 65 -118 minecraft:light_gray_concrete
setblock 370 65 -118 minecraft:sea_lantern
fill 371 65 -118 378 65 -118 minecraft:light_gray_concrete
setblock 379 65 -118 minecraft:sea_lantern
fill 380 65 -118 387 65 -118 minecraft:light_gray_concrete
setblock 388 65 -118 minecraft:sea_lantern
fill 389 65 -118 391 65 -118 minecraft:light_gray_concrete
fill 328 65 -117 332 65 -117 minecraft:light_gray_concrete
setblock 333 65 -117 minecraft:sea_lantern
fill 334 65 -117 341 65 -117 minecraft:light_gray_concrete
setblock 342 65 -117 minecraft:sea_lantern
fill 343 65 -117 350 65 -117 minecraft:light_gray_concrete
setblock 351 65 -117 minecraft:sea_lantern
fill 352 65 -117 359 65 -117 minecraft:light_gray_concrete
setblock 360 65 -117 minecraft:sea_lantern
fill 361 65 -117 368 65 -117 minecraft:light_gray_concrete
setblock 369 65 -117 minecraft:sea_lantern
fill 370 65 -117 377 65 -117 minecraft:light_gray_concrete
setblock 378 65 -117 minecraft:sea_lantern
fill 379 65 -117 391 65 -117 minecraft:light_gray_concrete
fill 328 65 -116 386 65 -116 minecraft:light_gray_concrete
setblock 332 66 -126 minecraft:oak_log
setblock 342 66 -126 minecraft:oak_log
setblock 349 66 -126 minecraft:allium
fill 356 66 -126 359 66 -126 minecraft:cornflower
fill 362 66 -126 363 66 -126 minecraft:poppy
setblock 366 66 -126 minecraft:oxeye_daisy
fill 368 66 -126 370 66 -126 minecraft:azure_bluet
fill 372 66 -126 375 66 -126 minecraft:orange_tulip
setblock 385 66 -126 minecraft:cornflower
setblock 388 66 -126 minecraft:poppy
setblock 390 66 -126 minecraft:poppy
setblock 332 67 -126 minecraft:oak_log
setblock 342 67 -126 minecraft:oak_log
setblock 332 68 -126 minecraft:oak_log
setblock 342 68 -126 minecraft:oak_log
fill 330 69 -126 331 69 -126 minecraft:oak_leaves[persistent=true]
setblock 332 69 -126 minecraft:oak_log
fill 333 69 -126 334 69 -126 minecraft:oak_leaves[persistent=true]
fill 340 69 -126 341 69 -126 minecraft:oak_leaves[persistent=true]
setblock 342 69 -126 minecraft:oak_log
fill 343 69 -126 344 69 -126 minecraft:oak_leaves[persistent=true]
fill 331 69 -125 333 69 -125 minecraft:oak_leaves[persistent=true]
fill 341 69 -125 343 69 -125 minecraft:oak_leaves[persistent=true]
setblock 332 69 -124 minecraft:oak_leaves[persistent=true]
setblock 342 69 -124 minecraft:oak_leaves[persistent=true]
fill 330 70 -126 331 70 -126 minecraft:oak_leaves[persistent=true]
setblock 332 70 -126 minecraft:oak_log
fill 333 70 -126 334 70 -126 minecraft:oak_leaves[persistent=true]
fill 340 70 -126 341 70 -126 minecraft:oak_leaves[persistent=true]
setblock 342 70 -126 minecraft:oak_log
fill 343 70 -126 344 70 -126 minecraft:oak_leaves[persistent=true]
fill 330 70 -125 334 70 -125 minecraft:oak_leaves[persistent=true]
fill 340 70 -125 344 70 -125 minecraft:oak_leaves[persistent=true]
fill 331 70 -124 333 70 -124 minecraft:oak_leaves[persistent=true]
fill 341 70 -124 343 70 -124 minecraft:oak_leaves[persistent=true]
fill 330 71 -126 334 71 -126 minecraft:oak_leaves[persistent=true]
fill 340 71 -126 344 71 -126 minecraft:oak_leaves[persistent=true]
fill 331 71 -125 333 71 -125 minecraft:oak_leaves[persistent=true]
fill 341 71 -125 343 71 -125 minecraft:oak_leaves[persistent=true]
setblock 332 71 -124 minecraft:oak_leaves[persistent=true]
setblock 342 71 -124 minecraft:oak_leaves[persistent=true]
setblock 332 72 -126 minecraft:oak_leaves[persistent=true]
setblock 342 72 -126 minecraft:oak_leaves[persistent=true]
forceload remove 328 -126 391 -63
tellraw @a {"text":"Campus bau a41 fertig.","color":"green"}
