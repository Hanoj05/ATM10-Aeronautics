fill 375 45 -368 376 45 -368 minecraft:stone
fill 374 45 -367 377 45 -367 minecraft:stone
fill 373 45 -366 376 45 -366 minecraft:stone
fill 374 45 -365 375 45 -365 minecraft:stone
fill 343 45 -354 344 45 -354 minecraft:stone
fill 343 45 -353 346 45 -353 minecraft:stone
fill 343 45 -352 346 45 -352 minecraft:stone
fill 343 45 -351 345 45 -351 minecraft:stone
setblock 344 45 -350 minecraft:stone
fill 387 45 -344 389 45 -344 minecraft:stone
fill 387 45 -343 390 45 -343 minecraft:stone
fill 387 45 -342 390 45 -342 minecraft:stone
fill 387 45 -341 390 45 -341 minecraft:stone
setblock 390 45 -340 minecraft:stone
setblock 391 45 -339 minecraft:stone
setblock 381 45 -333 minecraft:stone
fill 381 45 -332 382 45 -332 minecraft:stone
setblock 350 45 -329 minecraft:stone
fill 350 45 -328 352 45 -328 minecraft:stone
fill 350 45 -327 352 45 -327 minecraft:stone
fill 349 45 -326 352 45 -326 minecraft:stone
fill 350 45 -325 352 45 -325 minecraft:stone
setblock 384 45 -319 minecraft:stone
fill 376 46 -368 378 46 -368 minecraft:stone
fill 375 46 -367 378 46 -367 minecraft:stone
fill 374 46 -366 377 46 -366 minecraft:stone
fill 340 46 -356 342 46 -356 minecraft:stone
fill 340 46 -355 343 46 -355 minecraft:stone
fill 340 46 -354 345 46 -354 minecraft:stone
fill 341 46 -353 347 46 -353 minecraft:stone
fill 342 46 -352 349 46 -352 minecraft:stone
fill 344 46 -351 349 46 -351 minecraft:stone
fill 345 46 -350 348 46 -350 minecraft:stone
fill 346 46 -349 348 46 -349 minecraft:stone
fill 387 46 -344 389 46 -344 minecraft:stone
fill 387 46 -343 389 46 -343 minecraft:stone
fill 387 46 -342 389 46 -342 minecraft:stone
fill 387 46 -341 390 46 -341 minecraft:stone
setblock 390 46 -340 minecraft:stone
setblock 382 46 -333 minecraft:stone
setblock 381 46 -332 minecraft:stone
fill 350 46 -329 351 46 -329 minecraft:stone
fill 350 46 -328 352 46 -328 minecraft:stone
fill 350 46 -327 353 46 -327 minecraft:stone
fill 350 46 -326 352 46 -326 minecraft:stone
fill 351 46 -325 352 46 -325 minecraft:stone
fill 381 46 -325 385 46 -325 minecraft:stone
setblock 352 46 -324 minecraft:stone
fill 381 46 -324 386 46 -324 minecraft:stone
fill 380 46 -323 386 46 -323 minecraft:stone
fill 380 46 -322 384 46 -322 minecraft:stone
fill 381 46 -321 382 46 -321 minecraft:stone
fill 381 46 -320 386 46 -320 minecraft:stone
fill 381 46 -319 386 46 -319 minecraft:stone
fill 377 47 -369 378 47 -369 minecraft:stone
fill 376 47 -368 379 47 -368 minecraft:stone
fill 375 47 -367 378 47 -367 minecraft:stone
setblock 377 47 -366 minecraft:stone
fill 339 47 -357 341 47 -357 minecraft:stone
fill 339 47 -356 343 47 -356 minecraft:stone
fill 338 47 -355 345 47 -355 minecraft:stone
fill 340 47 -354 347 47 -354 minecraft:stone
fill 342 47 -353 350 47 -353 minecraft:stone
fill 344 47 -352 351 47 -352 minecraft:stone
fill 345 47 -351 351 47 -351 minecraft:stone
fill 346 47 -350 350 47 -350 minecraft:stone
fill 348 47 -349 350 47 -349 minecraft:stone
setblock 349 47 -348 minecraft:stone
fill 386 47 -345 387 47 -345 minecraft:stone
fill 386 47 -344 389 47 -344 minecraft:stone
fill 386 47 -343 389 47 -343 minecraft:stone
fill 386 47 -342 389 47 -342 minecraft:stone
fill 387 47 -341 389 47 -341 minecraft:stone
fill 384 47 -339 387 47 -339 minecraft:stone
fill 383 47 -338 388 47 -338 minecraft:stone
fill 383 47 -337 388 47 -337 minecraft:stone
fill 383 47 -336 388 47 -336 minecraft:stone
fill 384 47 -335 387 47 -335 minecraft:stone
fill 385 47 -334 386 47 -334 minecraft:stone
fill 382 47 -333 384 47 -333 minecraft:stone
fill 381 47 -332 385 47 -332 minecraft:stone
fill 381 47 -331 386 47 -331 minecraft:stone
setblock 351 47 -330 minecraft:stone
fill 381 47 -330 386 47 -330 minecraft:stone
fill 351 47 -329 352 47 -329 minecraft:stone
fill 381 47 -329 385 47 -329 minecraft:stone
fill 351 47 -328 353 47 -328 minecraft:stone
fill 381 47 -328 385 47 -328 minecraft:stone
fill 351 47 -327 353 47 -327 minecraft:stone
fill 381 47 -327 386 47 -327 minecraft:stone
fill 350 47 -326 353 47 -326 minecraft:stone
fill 380 47 -326 386 47 -326 minecraft:stone
fill 351 47 -325 352 47 -325 minecraft:stone
fill 380 47 -325 386 47 -325 minecraft:stone
setblock 352 47 -324 minecraft:stone
fill 380 47 -324 386 47 -324 minecraft:stone
fill 380 47 -323 386 47 -323 minecraft:stone
fill 380 47 -322 384 47 -322 minecraft:stone
fill 381 47 -321 382 47 -321 minecraft:stone
fill 381 47 -320 382 47 -320 minecraft:stone
setblock 381 47 -319 minecraft:stone
fill 378 48 -369 380 48 -369 minecraft:stone
fill 377 48 -368 380 48 -368 minecraft:stone
fill 376 48 -367 379 48 -367 minecraft:stone
setblock 384 48 -363 minecraft:stone
fill 384 48 -362 388 48 -362 minecraft:stone
fill 383 48 -361 388 48 -361 minecraft:stone
fill 382 48 -360 388 48 -360 minecraft:stone
fill 381 48 -359 388 48 -359 minecraft:stone
fill 338 48 -358 340 48 -358 minecraft:stone
fill 380 48 -358 388 48 -358 minecraft:stone
fill 338 48 -357 342 48 -357 minecraft:stone
fill 379 48 -357 387 48 -357 minecraft:stone
fill 337 48 -356 344 48 -356 minecraft:stone
fill 379 48 -356 386 48 -356 minecraft:stone
fill 339 48 -355 346 48 -355 minecraft:stone
fill 380 48 -355 386 48 -355 minecraft:stone
setblock 391 48 -355 minecraft:stone
fill 341 48 -354 349 48 -354 minecraft:stone
fill 380 48 -354 387 48 -354 minecraft:stone
fill 390 48 -354 391 48 -354 minecraft:stone
fill 343 48 -353 353 48 -353 minecraft:stone
fill 381 48 -353 387 48 -353 minecraft:stone
fill 389 48 -353 391 48 -353 minecraft:stone
fill 345 48 -352 352 48 -352 minecraft:stone
fill 382 48 -352 387 48 -352 minecraft:stone
fill 389 48 -352 391 48 -352 minecraft:stone
fill 346 48 -351 352 48 -351 minecraft:stone
fill 382 48 -351 387 48 -351 minecraft:stone
fill 389 48 -351 391 48 -351 minecraft:stone
fill 348 48 -350 352 48 -350 minecraft:stone
fill 383 48 -350 391 48 -350 minecraft:stone
fill 350 48 -349 351 48 -349 minecraft:stone
fill 384 48 -349 391 48 -349 minecraft:stone
fill 384 48 -348 391 48 -348 minecraft:stone
fill 386 48 -345 388 48 -345 minecraft:stone
fill 386 48 -344 388 48 -344 minecraft:stone
setblock 391 48 -344 minecraft:stone
fill 386 48 -343 388 48 -343 minecraft:stone
fill 386 48 -342 389 48 -342 minecraft:stone
fill 386 48 -341 389 48 -341 minecraft:stone
fill 386 48 -340 389 48 -340 minecraft:stone
fill 384 48 -339 389 48 -339 minecraft:stone
fill 383 48 -338 387 48 -338 minecraft:stone
fill 383 48 -337 388 48 -337 minecraft:stone
fill 383 48 -336 388 48 -336 minecraft:stone
fill 383 48 -335 387 48 -335 minecraft:stone
fill 382 48 -334 387 48 -334 minecraft:stone
fill 381 48 -333 385 48 -333 minecraft:stone
fill 381 48 -332 386 48 -332 minecraft:stone
fill 381 48 -331 386 48 -331 minecraft:stone
setblock 352 48 -330 minecraft:stone
fill 381 48 -330 385 48 -330 minecraft:stone
fill 351 48 -329 352 48 -329 minecraft:stone
fill 381 48 -329 385 48 -329 minecraft:stone
fill 351 48 -328 353 48 -328 minecraft:stone
fill 382 48 -328 384 48 -328 minecraft:stone
fill 351 48 -327 353 48 -327 minecraft:stone
fill 381 48 -327 385 48 -327 minecraft:stone
fill 351 48 -326 353 48 -326 minecraft:stone
fill 381 48 -326 386 48 -326 minecraft:stone
fill 351 48 -325 353 48 -325 minecraft:stone
fill 381 48 -325 386 48 -325 minecraft:stone
setblock 352 48 -324 minecraft:stone
fill 381 48 -324 386 48 -324 minecraft:stone
fill 381 48 -323 386 48 -323 minecraft:stone
fill 381 48 -322 384 48 -322 minecraft:stone
fill 381 48 -321 386 48 -321 minecraft:stone
setblock 381 48 -320 minecraft:stone
setblock 381 48 -319 minecraft:stone
fill 379 49 -370 380 49 -370 minecraft:stone
fill 378 49 -369 381 49 -369 minecraft:stone
fill 377 49 -368 380 49 -368 minecraft:stone
fill 377 49 -367 379 49 -367 minecraft:stone
setblock 388 49 -365 minecraft:stone
fill 380 49 -364 388 49 -364 minecraft:stone
fill 380 49 -363 389 49 -363 minecraft:stone
fill 379 49 -362 389 49 -362 minecraft:stone
fill 377 49 -361 390 49 -361 minecraft:stone
fill 373 49 -360 391 49 -360 minecraft:stone
fill 337 49 -359 339 49 -359 minecraft:stone
fill 373 49 -359 391 49 -359 minecraft:stone
fill 337 49 -358 341 49 -358 minecraft:stone
fill 374 49 -358 391 49 -358 minecraft:stone
fill 336 49 -357 343 49 -357 minecraft:stone
fill 374 49 -357 391 49 -357 minecraft:stone
fill 338 49 -356 343 49 -356 minecraft:stone
fill 375 49 -356 391 49 -356 minecraft:stone
fill 340 49 -355 343 49 -355 minecraft:stone
setblock 349 49 -355 minecraft:stone
fill 375 49 -355 391 49 -355 minecraft:stone
fill 342 49 -354 343 49 -354 minecraft:stone
fill 349 49 -354 355 49 -354 minecraft:stone
fill 375 49 -354 391 49 -354 minecraft:stone
fill 347 49 -353 354 49 -353 minecraft:stone
fill 376 49 -353 391 49 -353 minecraft:stone
fill 346 49 -352 354 49 -352 minecraft:stone
fill 376 49 -352 391 49 -352 minecraft:stone
fill 348 49 -351 353 49 -351 minecraft:stone
fill 377 49 -351 391 49 -351 minecraft:stone
fill 350 49 -350 353 49 -350 minecraft:stone
fill 377 49 -350 391 49 -350 minecraft:stone
fill 352 49 -349 353 49 -349 minecraft:stone
fill 378 49 -349 391 49 -349 minecraft:stone
fill 378 49 -348 391 49 -348 minecraft:stone
fill 379 49 -347 389 49 -347 minecraft:stone
fill 380 49 -346 387 49 -346 minecraft:stone
setblock 391 49 -346 minecraft:stone
fill 381 49 -345 387 49 -345 minecraft:stone
fill 390 49 -345 391 49 -345 minecraft:stone
fill 382 49 -344 391 49 -344 minecraft:stone
fill 386 49 -343 391 49 -343 minecraft:stone
fill 386 49 -342 391 49 -342 minecraft:stone
fill 386 49 -341 390 49 -341 minecraft:stone
fill 386 49 -340 389 49 -340 minecraft:stone
fill 384 49 -339 389 49 -339 minecraft:stone
fill 383 49 -338 387 49 -338 minecraft:stone
fill 383 49 -337 388 49 -337 minecraft:stone
fill 383 49 -336 388 49 -336 minecraft:stone
fill 383 49 -335 387 49 -335 minecraft:stone
fill 382 49 -334 387 49 -334 minecraft:stone
fill 381 49 -333 385 49 -333 minecraft:stone
fill 381 49 -332 386 49 -332 minecraft:stone
fill 381 49 -331 386 49 -331 minecraft:stone
setblock 352 49 -330 minecraft:stone
fill 381 49 -330 385 49 -330 minecraft:stone
fill 352 49 -329 353 49 -329 minecraft:stone
fill 381 49 -329 385 49 -329 minecraft:stone
fill 352 49 -328 353 49 -328 minecraft:stone
fill 382 49 -328 384 49 -328 minecraft:stone
fill 351 49 -327 354 49 -327 minecraft:stone
fill 381 49 -327 385 49 -327 minecraft:stone
fill 351 49 -326 354 49 -326 minecraft:stone
fill 381 49 -326 386 49 -326 minecraft:stone
fill 352 49 -325 353 49 -325 minecraft:stone
fill 381 49 -325 386 49 -325 minecraft:stone
fill 352 49 -324 353 49 -324 minecraft:stone
fill 381 49 -324 386 49 -324 minecraft:stone
setblock 353 49 -323 minecraft:stone
fill 381 49 -323 386 49 -323 minecraft:stone
fill 381 49 -322 386 49 -322 minecraft:stone
fill 381 49 -321 386 49 -321 minecraft:stone
fill 381 49 -320 386 49 -320 minecraft:stone
fill 381 49 -319 382 49 -319 minecraft:stone
fill 384 49 -319 386 49 -319 minecraft:stone
fill 379 50 -370 381 50 -370 minecraft:stone
fill 378 50 -369 382 50 -369 minecraft:stone
fill 377 50 -368 381 50 -368 minecraft:stone
setblock 380 50 -367 minecraft:stone
fill 384 50 -366 388 50 -366 minecraft:stone
fill 380 50 -365 389 50 -365 minecraft:stone
fill 379 50 -364 390 50 -364 minecraft:stone
fill 378 50 -363 390 50 -363 minecraft:stone
fill 377 50 -362 391 50 -362 minecraft:stone
fill 374 50 -361 391 50 -361 minecraft:stone
fill 336 50 -360 337 50 -360 minecraft:stone
fill 372 50 -360 391 50 -360 minecraft:stone
fill 336 50 -359 339 50 -359 minecraft:stone
fill 372 50 -359 391 50 -359 minecraft:stone
fill 335 50 -358 341 50 -358 minecraft:stone
fill 372 50 -358 391 50 -358 minecraft:stone
fill 335 50 -357 340 50 -357 minecraft:stone
fill 372 50 -357 391 50 -357 minecraft:stone
fill 338 50 -356 340 50 -356 minecraft:stone
fill 371 50 -356 391 50 -356 minecraft:stone
fill 352 50 -355 357 50 -355 minecraft:stone
fill 371 50 -355 391 50 -355 minecraft:stone
fill 351 50 -354 356 50 -354 minecraft:stone
fill 370 50 -354 391 50 -354 minecraft:stone
fill 351 50 -353 356 50 -353 minecraft:stone
fill 368 50 -353 391 50 -353 minecraft:stone
fill 350 50 -352 355 50 -352 minecraft:stone
fill 366 50 -352 391 50 -352 minecraft:stone
fill 351 50 -351 355 50 -351 minecraft:stone
fill 366 50 -351 391 50 -351 minecraft:stone
setblock 354 50 -350 minecraft:stone
fill 366 50 -350 391 50 -350 minecraft:stone
fill 365 50 -349 391 50 -349 minecraft:stone
fill 365 50 -348 391 50 -348 minecraft:stone
fill 368 50 -347 391 50 -347 minecraft:stone
fill 371 50 -346 391 50 -346 minecraft:stone
fill 372 50 -345 391 50 -345 minecraft:stone
fill 372 50 -344 391 50 -344 minecraft:stone
fill 385 50 -343 391 50 -343 minecraft:stone
fill 385 50 -342 391 50 -342 minecraft:stone
fill 385 50 -341 390 50 -341 minecraft:stone
fill 385 50 -340 389 50 -340 minecraft:stone
fill 384 50 -339 389 50 -339 minecraft:stone
fill 383 50 -338 388 50 -338 minecraft:stone
fill 383 50 -337 388 50 -337 minecraft:stone
fill 382 50 -336 388 50 -336 minecraft:stone
fill 383 50 -335 387 50 -335 minecraft:stone
fill 382 50 -334 387 50 -334 minecraft:stone
fill 381 50 -333 385 50 -333 minecraft:stone
fill 381 50 -332 386 50 -332 minecraft:stone
fill 381 50 -331 386 50 -331 minecraft:stone
setblock 353 50 -330 minecraft:stone
fill 381 50 -330 385 50 -330 minecraft:stone
setblock 353 50 -329 minecraft:stone
fill 381 50 -329 385 50 -329 minecraft:stone
fill 352 50 -328 354 50 -328 minecraft:stone
fill 382 50 -328 384 50 -328 minecraft:stone
fill 352 50 -327 355 50 -327 minecraft:stone
fill 381 50 -327 385 50 -327 minecraft:stone
fill 352 50 -326 354 50 -326 minecraft:stone
fill 381 50 -326 386 50 -326 minecraft:stone
fill 352 50 -325 354 50 -325 minecraft:stone
fill 381 50 -325 386 50 -325 minecraft:stone
setblock 353 50 -324 minecraft:stone
fill 381 50 -324 386 50 -324 minecraft:stone
setblock 353 50 -323 minecraft:stone
fill 381 50 -323 386 50 -323 minecraft:stone
setblock 353 50 -322 minecraft:stone
fill 381 50 -322 386 50 -322 minecraft:stone
fill 381 50 -321 386 50 -321 minecraft:stone
fill 381 50 -320 386 50 -320 minecraft:stone
fill 381 50 -319 386 50 -319 minecraft:stone
setblock 381 51 -371 minecraft:stone
fill 380 51 -370 383 51 -370 minecraft:stone
fill 379 51 -369 383 51 -369 minecraft:stone
fill 379 51 -368 382 51 -368 minecraft:stone
fill 384 51 -368 388 51 -368 minecraft:stone
fill 381 51 -367 388 51 -367 minecraft:stone
fill 380 51 -366 389 51 -366 minecraft:stone
fill 378 51 -365 390 51 -365 minecraft:stone
fill 377 51 -364 391 51 -364 minecraft:stone
fill 376 51 -363 391 51 -363 minecraft:stone
fill 374 51 -362 391 51 -362 minecraft:stone
fill 372 51 -361 391 51 -361 minecraft:stone
fill 335 51 -360 337 51 -360 minecraft:stone
fill 371 51 -360 391 51 -360 minecraft:stone
fill 335 51 -359 339 51 -359 minecraft:stone
fill 371 51 -359 391 51 -359 minecraft:stone
fill 334 51 -358 339 51 -358 minecraft:stone
fill 371 51 -358 391 51 -358 minecraft:stone
fill 335 51 -357 338 51 -357 minecraft:stone
fill 370 51 -357 391 51 -357 minecraft:stone
fill 354 51 -356 358 51 -356 minecraft:stone
fill 368 51 -356 391 51 -356 minecraft:stone
fill 354 51 -355 358 51 -355 minecraft:stone
fill 368 51 -355 391 51 -355 minecraft:stone
fill 353 51 -354 357 51 -354 minecraft:stone
fill 367 51 -354 391 51 -354 minecraft:stone
fill 353 51 -353 357 51 -353 minecraft:stone
fill 366 51 -353 391 51 -353 minecraft:stone
fill 352 51 -352 356 51 -352 minecraft:stone
fill 364 51 -352 391 51 -352 minecraft:stone
setblock 356 51 -351 minecraft:stone
fill 364 51 -351 391 51 -351 minecraft:stone
fill 364 51 -350 391 51 -350 minecraft:stone
fill 364 51 -349 391 51 -349 minecraft:stone
fill 364 51 -348 391 51 -348 minecraft:stone
fill 366 51 -347 391 51 -347 minecraft:stone
fill 368 51 -346 391 51 -346 minecraft:stone
fill 369 51 -345 391 51 -345 minecraft:stone
fill 370 51 -344 391 51 -344 minecraft:stone
fill 371 51 -343 391 51 -343 minecraft:stone
fill 372 51 -342 374 51 -342 minecraft:stone
fill 385 51 -342 391 51 -342 minecraft:stone
setblock 372 51 -341 minecraft:stone
fill 384 51 -341 391 51 -341 minecraft:stone
setblock 372 51 -340 minecraft:stone
fill 384 51 -340 390 51 -340 minecraft:stone
fill 383 51 -339 390 51 -339 minecraft:stone
fill 382 51 -338 389 51 -338 minecraft:stone
fill 382 51 -337 389 51 -337 minecraft:stone
fill 382 51 -336 389 51 -336 minecraft:stone
fill 382 51 -335 388 51 -335 minecraft:stone
fill 381 51 -334 388 51 -334 minecraft:stone
fill 380 51 -333 387 51 -333 minecraft:stone
fill 380 51 -332 387 51 -332 minecraft:stone
fill 380 51 -331 387 51 -331 minecraft:stone
fill 380 51 -330 386 51 -330 minecraft:stone
fill 353 51 -329 354 51 -329 minecraft:stone
fill 380 51 -329 386 51 -329 minecraft:stone
fill 353 51 -328 354 51 -328 minecraft:stone
fill 381 51 -328 386 51 -328 minecraft:stone
fill 353 51 -327 355 51 -327 minecraft:stone
fill 380 51 -327 386 51 -327 minecraft:stone
fill 352 51 -326 355 51 -326 minecraft:stone
fill 380 51 -326 387 51 -326 minecraft:stone
fill 352 51 -325 354 51 -325 minecraft:stone
fill 380 51 -325 387 51 -325 minecraft:stone
fill 353 51 -324 354 51 -324 minecraft:stone
fill 380 51 -324 387 51 -324 minecraft:stone
fill 353 51 -323 354 51 -323 minecraft:stone
fill 380 51 -323 387 51 -323 minecraft:stone
setblock 353 51 -322 minecraft:stone
fill 380 51 -322 387 51 -322 minecraft:stone
setblock 353 51 -321 minecraft:stone
fill 380 51 -321 387 51 -321 minecraft:stone
fill 380 51 -320 387 51 -320 minecraft:stone
setblock 353 51 -319 minecraft:stone
fill 380 51 -319 387 51 -319 minecraft:stone
fill 382 52 -372 384 52 -372 minecraft:stone
fill 381 52 -371 385 52 -371 minecraft:stone
fill 380 52 -370 386 52 -370 minecraft:stone
fill 379 52 -369 388 52 -369 minecraft:stone
fill 379 52 -368 389 52 -368 minecraft:stone
fill 378 52 -367 390 52 -367 minecraft:stone
fill 377 52 -366 391 52 -366 minecraft:stone
fill 376 52 -365 391 52 -365 minecraft:stone
fill 375 52 -364 391 52 -364 minecraft:stone
fill 373 52 -363 391 52 -363 minecraft:stone
fill 372 52 -362 391 52 -362 minecraft:stone
fill 371 52 -361 391 52 -361 minecraft:stone
fill 334 52 -360 338 52 -360 minecraft:stone
fill 370 52 -360 391 52 -360 minecraft:stone
fill 334 52 -359 338 52 -359 minecraft:stone
fill 370 52 -359 391 52 -359 minecraft:stone
fill 333 52 -358 337 52 -358 minecraft:stone
fill 369 52 -358 391 52 -358 minecraft:stone
fill 334 52 -357 336 52 -357 minecraft:stone
fill 356 52 -357 359 52 -357 minecraft:stone
fill 368 52 -357 391 52 -357 minecraft:stone
fill 355 52 -356 359 52 -356 minecraft:stone
fill 367 52 -356 391 52 -356 minecraft:stone
fill 355 52 -355 358 52 -355 minecraft:stone
fill 366 52 -355 391 52 -355 minecraft:stone
fill 354 52 -354 358 52 -354 minecraft:stone
fill 365 52 -354 391 52 -354 minecraft:stone
fill 354 52 -353 357 52 -353 minecraft:stone
fill 364 52 -353 391 52 -353 minecraft:stone
fill 363 52 -352 391 52 -352 minecraft:stone
fill 363 52 -351 391 52 -351 minecraft:stone
fill 363 52 -350 391 52 -350 minecraft:stone
fill 363 52 -349 391 52 -349 minecraft:stone
fill 363 52 -348 391 52 -348 minecraft:stone
fill 364 52 -347 391 52 -347 minecraft:stone
fill 366 52 -346 391 52 -346 minecraft:stone
fill 367 52 -345 391 52 -345 minecraft:stone
fill 368 52 -344 391 52 -344 minecraft:stone
fill 369 52 -343 391 52 -343 minecraft:stone
fill 370 52 -342 391 52 -342 minecraft:stone
fill 371 52 -341 376 52 -341 minecraft:stone
fill 384 52 -341 391 52 -341 minecraft:stone
fill 371 52 -340 374 52 -340 minecraft:stone
fill 384 52 -340 390 52 -340 minecraft:stone
fill 383 52 -339 390 52 -339 minecraft:stone
fill 382 52 -338 389 52 -338 minecraft:stone
fill 382 52 -337 389 52 -337 minecraft:stone
fill 382 52 -336 389 52 -336 minecraft:stone
fill 382 52 -335 388 52 -335 minecraft:stone
fill 381 52 -334 388 52 -334 minecraft:stone
fill 380 52 -333 387 52 -333 minecraft:stone
fill 380 52 -332 387 52 -332 minecraft:stone
fill 380 52 -331 387 52 -331 minecraft:stone
fill 380 52 -330 386 52 -330 minecraft:stone
setblock 354 52 -329 minecraft:stone
fill 380 52 -329 386 52 -329 minecraft:stone
fill 354 52 -328 355 52 -328 minecraft:stone
fill 380 52 -328 386 52 -328 minecraft:stone
fill 353 52 -327 355 52 -327 minecraft:stone
fill 380 52 -327 386 52 -327 minecraft:stone
fill 353 52 -326 356 52 -326 minecraft:stone
fill 380 52 -326 387 52 -326 minecraft:stone
fill 352 52 -325 355 52 -325 minecraft:stone
fill 380 52 -325 387 52 -325 minecraft:stone
fill 353 52 -324 355 52 -324 minecraft:stone
fill 380 52 -324 387 52 -324 minecraft:stone
fill 353 52 -323 354 52 -323 minecraft:stone
fill 380 52 -323 387 52 -323 minecraft:stone
fill 353 52 -322 354 52 -322 minecraft:stone
fill 380 52 -322 387 52 -322 minecraft:stone
setblock 353 52 -321 minecraft:stone
fill 380 52 -321 387 52 -321 minecraft:stone
setblock 353 52 -320 minecraft:stone
fill 380 52 -320 387 52 -320 minecraft:stone
setblock 353 52 -319 minecraft:stone
fill 380 52 -319 387 52 -319 minecraft:stone
setblock 384 53 -375 minecraft:stone
fill 382 53 -374 385 53 -374 minecraft:stone
fill 376 53 -373 386 53 -373 minecraft:stone
fill 373 53 -372 387 53 -372 minecraft:stone
fill 373 53 -371 388 53 -371 minecraft:stone
fill 373 53 -370 389 53 -370 minecraft:stone
fill 373 53 -369 390 53 -369 minecraft:stone
fill 373 53 -368 391 53 -368 minecraft:stone
fill 373 53 -367 391 53 -367 minecraft:stone
fill 372 53 -366 391 53 -366 minecraft:stone
fill 372 53 -365 391 53 -365 minecraft:stone
fill 371 53 -364 391 53 -364 minecraft:stone
fill 370 53 -363 391 53 -363 minecraft:stone
fill 370 53 -362 391 53 -362 minecraft:stone
fill 369 53 -361 391 53 -361 minecraft:stone
fill 333 53 -360 337 53 -360 minecraft:stone
fill 369 53 -360 391 53 -360 minecraft:stone
fill 333 53 -359 336 53 -359 minecraft:stone
fill 368 53 -359 391 53 -359 minecraft:stone
fill 332 53 -358 335 53 -358 minecraft:stone
fill 357 53 -358 361 53 -358 minecraft:stone
fill 368 53 -358 391 53 -358 minecraft:stone
fill 331 53 -357 335 53 -357 minecraft:stone
fill 357 53 -357 360 53 -357 minecraft:stone
fill 367 53 -357 391 53 -357 minecraft:stone
fill 356 53 -356 360 53 -356 minecraft:stone
fill 366 53 -356 391 53 -356 minecraft:stone
fill 356 53 -355 359 53 -355 minecraft:stone
fill 365 53 -355 391 53 -355 minecraft:stone
fill 356 53 -354 359 53 -354 minecraft:stone
fill 364 53 -354 391 53 -354 minecraft:stone
fill 363 53 -353 391 53 -353 minecraft:stone
fill 362 53 -352 391 53 -352 minecraft:stone
fill 362 53 -351 391 53 -351 minecraft:stone
fill 362 53 -350 391 53 -350 minecraft:stone
fill 363 53 -349 391 53 -349 minecraft:stone
fill 363 53 -348 391 53 -348 minecraft:stone
setblock 344 53 -347 minecraft:stone
fill 363 53 -347 391 53 -347 minecraft:stone
setblock 344 53 -346 minecraft:stone
fill 364 53 -346 391 53 -346 minecraft:stone
fill 346 53 -345 349 53 -345 minecraft:stone
fill 365 53 -345 391 53 -345 minecraft:stone
fill 345 53 -344 350 53 -344 minecraft:stone
fill 367 53 -344 391 53 -344 minecraft:stone
fill 346 53 -343 349 53 -343 minecraft:stone
fill 368 53 -343 391 53 -343 minecraft:stone
fill 368 53 -342 391 53 -342 minecraft:stone
fill 369 53 -341 381 53 -341 minecraft:stone
fill 383 53 -341 391 53 -341 minecraft:stone
fill 370 53 -340 377 53 -340 minecraft:stone
fill 382 53 -340 390 53 -340 minecraft:stone
fill 372 53 -339 373 53 -339 minecraft:stone
fill 383 53 -339 390 53 -339 minecraft:stone
fill 382 53 -338 389 53 -338 minecraft:stone
fill 382 53 -337 389 53 -337 minecraft:stone
fill 381 53 -336 389 53 -336 minecraft:stone
fill 382 53 -335 388 53 -335 minecraft:stone
fill 381 53 -334 388 53 -334 minecraft:stone
fill 380 53 -333 387 53 -333 minecraft:stone
fill 380 53 -332 387 53 -332 minecraft:stone
fill 380 53 -331 387 53 -331 minecraft:stone
fill 380 53 -330 386 53 -330 minecraft:stone
setblock 355 53 -329 minecraft:stone
fill 380 53 -329 386 53 -329 minecraft:stone
fill 354 53 -328 355 53 -328 minecraft:stone
fill 380 53 -328 386 53 -328 minecraft:stone
fill 354 53 -327 356 53 -327 minecraft:stone
fill 380 53 -327 387 53 -327 minecraft:stone
fill 353 53 -326 356 53 -326 minecraft:stone
fill 380 53 -326 387 53 -326 minecraft:stone
fill 353 53 -325 356 53 -325 minecraft:stone
fill 380 53 -325 387 53 -325 minecraft:stone
fill 353 53 -324 355 53 -324 minecraft:stone
fill 380 53 -324 387 53 -324 minecraft:stone
fill 353 53 -323 355 53 -323 minecraft:stone
fill 380 53 -323 387 53 -323 minecraft:stone
fill 353 53 -322 354 53 -322 minecraft:stone
fill 380 53 -322 387 53 -322 minecraft:stone
fill 353 53 -321 354 53 -321 minecraft:stone
fill 380 53 -321 387 53 -321 minecraft:stone
fill 353 53 -320 354 53 -320 minecraft:stone
fill 380 53 -320 387 53 -320 minecraft:stone
fill 352 53 -319 353 53 -319 minecraft:stone
fill 380 53 -319 387 53 -319 minecraft:stone
fill 381 54 -377 386 54 -377 minecraft:stone
fill 379 54 -376 388 54 -376 minecraft:stone
fill 376 54 -375 389 54 -375 minecraft:stone
fill 374 54 -374 389 54 -374 minecraft:stone
fill 372 54 -373 389 54 -373 minecraft:stone
fill 371 54 -372 390 54 -372 minecraft:stone
fill 371 54 -371 391 54 -371 minecraft:stone
fill 371 54 -370 391 54 -370 minecraft:stone
fill 371 54 -369 391 54 -369 minecraft:stone
fill 370 54 -368 391 54 -368 minecraft:stone
fill 370 54 -367 391 54 -367 minecraft:stone
fill 369 54 -366 391 54 -366 minecraft:stone
fill 368 54 -365 391 54 -365 minecraft:stone
fill 368 54 -364 391 54 -364 minecraft:stone
fill 368 54 -363 391 54 -363 minecraft:stone
fill 368 54 -362 391 54 -362 minecraft:stone
fill 368 54 -361 391 54 -361 minecraft:stone
fill 332 54 -360 336 54 -360 minecraft:stone
fill 368 54 -360 391 54 -360 minecraft:stone
fill 332 54 -359 335 54 -359 minecraft:stone
fill 359 54 -359 362 54 -359 minecraft:stone
fill 367 54 -359 391 54 -359 minecraft:stone
fill 331 54 -358 334 54 -358 minecraft:stone
fill 358 54 -358 361 54 -358 minecraft:stone
fill 366 54 -358 391 54 -358 minecraft:stone
fill 330 54 -357 333 54 -357 minecraft:stone
fill 358 54 -357 361 54 -357 minecraft:stone
fill 365 54 -357 391 54 -357 minecraft:stone
fill 357 54 -356 360 54 -356 minecraft:stone
fill 364 54 -356 391 54 -356 minecraft:stone
fill 357 54 -355 360 54 -355 minecraft:stone
fill 363 54 -355 391 54 -355 minecraft:stone
fill 362 54 -354 391 54 -354 minecraft:stone
fill 345 54 -353 346 54 -353 minecraft:stone
fill 361 54 -353 391 54 -353 minecraft:stone
fill 343 54 -352 348 54 -352 minecraft:stone
fill 360 54 -352 391 54 -352 minecraft:stone
fill 343 54 -351 348 54 -351 minecraft:stone
fill 361 54 -351 391 54 -351 minecraft:stone
fill 343 54 -350 348 54 -350 minecraft:stone
fill 361 54 -350 391 54 -350 minecraft:stone
fill 343 54 -349 348 54 -349 minecraft:stone
fill 362 54 -349 391 54 -349 minecraft:stone
fill 343 54 -348 348 54 -348 minecraft:stone
fill 362 54 -348 391 54 -348 minecraft:stone
fill 342 54 -347 348 54 -347 minecraft:stone
fill 363 54 -347 391 54 -347 minecraft:stone
fill 343 54 -346 349 54 -346 minecraft:stone
fill 363 54 -346 391 54 -346 minecraft:stone
fill 343 54 -345 350 54 -345 minecraft:stone
fill 364 54 -345 391 54 -345 minecraft:stone
fill 345 54 -344 350 54 -344 minecraft:stone
fill 364 54 -344 391 54 -344 minecraft:stone
fill 345 54 -343 350 54 -343 minecraft:stone
fill 366 54 -343 391 54 -343 minecraft:stone
fill 346 54 -342 349 54 -342 minecraft:stone
fill 367 54 -342 391 54 -342 minecraft:stone
fill 368 54 -341 389 54 -341 minecraft:stone
fill 368 54 -340 389 54 -340 minecraft:stone
fill 370 54 -339 376 54 -339 minecraft:stone
fill 384 54 -339 389 54 -339 minecraft:stone
setblock 372 54 -338 minecraft:stone
fill 384 54 -338 388 54 -338 minecraft:stone
fill 383 54 -337 388 54 -337 minecraft:stone
fill 383 54 -336 387 54 -336 minecraft:stone
fill 383 54 -335 387 54 -335 minecraft:stone
fill 383 54 -334 386 54 -334 minecraft:stone
fill 381 54 -333 385 54 -333 minecraft:stone
fill 381 54 -332 385 54 -332 minecraft:stone
fill 381 54 -331 385 54 -331 minecraft:stone
fill 381 54 -330 385 54 -330 minecraft:stone
fill 382 54 -329 385 54 -329 minecraft:stone
fill 355 54 -328 356 54 -328 minecraft:stone
fill 382 54 -328 384 54 -328 minecraft:stone
fill 355 54 -327 356 54 -327 minecraft:stone
fill 381 54 -327 385 54 -327 minecraft:stone
fill 354 54 -326 356 54 -326 minecraft:stone
fill 381 54 -326 385 54 -326 minecraft:stone
fill 354 54 -325 356 54 -325 minecraft:stone
fill 381 54 -325 386 54 -325 minecraft:stone
fill 353 54 -324 356 54 -324 minecraft:stone
fill 381 54 -324 386 54 -324 minecraft:stone
fill 353 54 -323 355 54 -323 minecraft:stone
fill 381 54 -323 386 54 -323 minecraft:stone
fill 353 54 -322 355 54 -322 minecraft:stone
fill 381 54 -322 386 54 -322 minecraft:stone
fill 353 54 -321 354 54 -321 minecraft:stone
fill 381 54 -321 386 54 -321 minecraft:stone
fill 353 54 -320 354 54 -320 minecraft:stone
fill 381 54 -320 386 54 -320 minecraft:stone
fill 352 54 -319 354 54 -319 minecraft:stone
fill 381 54 -319 386 54 -319 minecraft:stone
fill 383 55 -379 391 55 -379 minecraft:stone
fill 380 55 -378 391 55 -378 minecraft:stone
fill 376 55 -377 391 55 -377 minecraft:stone
fill 374 55 -376 391 55 -376 minecraft:stone
fill 372 55 -375 391 55 -375 minecraft:stone
fill 370 55 -374 391 55 -374 minecraft:stone
fill 370 55 -373 391 55 -373 minecraft:stone
fill 369 55 -372 391 55 -372 minecraft:stone
fill 368 55 -371 391 55 -371 minecraft:stone
fill 368 55 -370 391 55 -370 minecraft:stone
fill 368 55 -369 391 55 -369 minecraft:stone
fill 367 55 -368 391 55 -368 minecraft:stone
fill 367 55 -367 391 55 -367 minecraft:stone
fill 366 55 -366 391 55 -366 minecraft:stone
fill 366 55 -365 391 55 -365 minecraft:stone
fill 365 55 -364 391 55 -364 minecraft:stone
fill 365 55 -363 391 55 -363 minecraft:stone
fill 365 55 -362 391 55 -362 minecraft:stone
fill 365 55 -361 391 55 -361 minecraft:stone
fill 333 55 -360 334 55 -360 minecraft:stone
fill 361 55 -360 362 55 -360 minecraft:stone
fill 365 55 -360 391 55 -360 minecraft:stone
fill 331 55 -359 334 55 -359 minecraft:stone
fill 359 55 -359 362 55 -359 minecraft:stone
fill 364 55 -359 391 55 -359 minecraft:stone
fill 330 55 -358 333 55 -358 minecraft:stone
fill 359 55 -358 391 55 -358 minecraft:stone
fill 329 55 -357 332 55 -357 minecraft:stone
fill 358 55 -357 391 55 -357 minecraft:stone
fill 328 55 -356 329 55 -356 minecraft:stone
fill 358 55 -356 391 55 -356 minecraft:stone
fill 360 55 -355 391 55 -355 minecraft:stone
fill 359 55 -354 391 55 -354 minecraft:stone
fill 344 55 -353 347 55 -353 minecraft:stone
fill 359 55 -353 391 55 -353 minecraft:stone
fill 343 55 -352 348 55 -352 minecraft:stone
fill 359 55 -352 391 55 -352 minecraft:stone
fill 342 55 -351 348 55 -351 minecraft:stone
fill 359 55 -351 391 55 -351 minecraft:stone
fill 343 55 -350 348 55 -350 minecraft:stone
fill 360 55 -350 391 55 -350 minecraft:stone
fill 343 55 -349 348 55 -349 minecraft:stone
fill 360 55 -349 391 55 -349 minecraft:stone
fill 342 55 -348 348 55 -348 minecraft:stone
fill 361 55 -348 391 55 -348 minecraft:stone
fill 342 55 -347 348 55 -347 minecraft:stone
fill 362 55 -347 391 55 -347 minecraft:stone
fill 342 55 -346 349 55 -346 minecraft:stone
fill 362 55 -346 391 55 -346 minecraft:stone
fill 342 55 -345 350 55 -345 minecraft:stone
fill 363 55 -345 391 55 -345 minecraft:stone
fill 343 55 -344 350 55 -344 minecraft:stone
fill 363 55 -344 391 55 -344 minecraft:stone
fill 345 55 -343 350 55 -343 minecraft:stone
fill 364 55 -343 391 55 -343 minecraft:stone
fill 346 55 -342 349 55 -342 minecraft:stone
fill 364 55 -342 391 55 -342 minecraft:stone
fill 365 55 -341 390 55 -341 minecraft:stone
fill 366 55 -340 389 55 -340 minecraft:stone
fill 368 55 -339 389 55 -339 minecraft:stone
fill 370 55 -338 377 55 -338 minecraft:stone
fill 383 55 -338 389 55 -338 minecraft:stone
fill 372 55 -337 374 55 -337 minecraft:stone
fill 382 55 -337 388 55 -337 minecraft:stone
fill 382 55 -336 388 55 -336 minecraft:stone
fill 382 55 -335 388 55 -335 minecraft:stone
fill 381 55 -334 387 55 -334 minecraft:stone
fill 381 55 -333 386 55 -333 minecraft:stone
fill 380 55 -332 386 55 -332 minecraft:stone
fill 380 55 -331 386 55 -331 minecraft:stone
setblock 391 55 -331 minecraft:stone
fill 381 55 -330 386 55 -330 minecraft:stone
setblock 391 55 -330 minecraft:stone
fill 381 55 -329 385 55 -329 minecraft:stone
setblock 356 55 -328 minecraft:stone
fill 381 55 -328 385 55 -328 minecraft:stone
fill 355 55 -327 356 55 -327 minecraft:stone
fill 381 55 -327 386 55 -327 minecraft:stone
fill 355 55 -326 357 55 -326 minecraft:stone
fill 380 55 -326 386 55 -326 minecraft:stone
fill 354 55 -325 357 55 -325 minecraft:stone
fill 380 55 -325 386 55 -325 minecraft:stone
fill 354 55 -324 356 55 -324 minecraft:stone
fill 380 55 -324 386 55 -324 minecraft:stone
fill 353 55 -323 356 55 -323 minecraft:stone
fill 380 55 -323 386 55 -323 minecraft:stone
fill 353 55 -322 355 55 -322 minecraft:stone
fill 380 55 -322 386 55 -322 minecraft:stone
fill 353 55 -321 355 55 -321 minecraft:stone
fill 380 55 -321 387 55 -321 minecraft:stone
fill 352 55 -320 355 55 -320 minecraft:stone
fill 380 55 -320 387 55 -320 minecraft:stone
fill 352 55 -319 354 55 -319 minecraft:stone
fill 381 55 -319 386 55 -319 minecraft:stone
fill 380 56 -382 391 56 -382 minecraft:stone
fill 379 56 -381 391 56 -381 minecraft:stone
fill 378 56 -380 391 56 -380 minecraft:stone
fill 375 56 -379 391 56 -379 minecraft:stone
fill 372 56 -378 391 56 -378 minecraft:stone
fill 370 56 -377 391 56 -377 minecraft:stone
fill 369 56 -376 391 56 -376 minecraft:stone
fill 368 56 -375 391 56 -375 minecraft:stone
fill 367 56 -374 391 56 -374 minecraft:stone
fill 366 56 -373 391 56 -373 minecraft:stone
fill 365 56 -372 391 56 -372 minecraft:stone
fill 365 56 -371 391 56 -371 minecraft:stone
fill 364 56 -370 391 56 -370 minecraft:stone
fill 362 56 -369 391 56 -369 minecraft:stone
fill 360 56 -368 391 56 -368 minecraft:stone
fill 360 56 -367 391 56 -367 minecraft:stone
fill 360 56 -366 391 56 -366 minecraft:stone
fill 360 56 -365 391 56 -365 minecraft:stone
fill 360 56 -364 391 56 -364 minecraft:stone
fill 359 56 -363 391 56 -363 minecraft:stone
fill 359 56 -362 391 56 -362 minecraft:stone
fill 358 56 -361 391 56 -361 minecraft:stone
fill 357 56 -360 391 56 -360 minecraft:stone
fill 330 56 -359 333 56 -359 minecraft:stone
fill 357 56 -359 391 56 -359 minecraft:stone
fill 329 56 -358 332 56 -358 minecraft:stone
fill 356 56 -358 391 56 -358 minecraft:stone
fill 328 56 -357 331 56 -357 minecraft:stone
fill 356 56 -357 391 56 -357 minecraft:stone
fill 328 56 -356 330 56 -356 minecraft:stone
fill 356 56 -356 391 56 -356 minecraft:stone
fill 356 56 -355 391 56 -355 minecraft:stone
fill 357 56 -354 391 56 -354 minecraft:stone
fill 357 56 -353 391 56 -353 minecraft:stone
fill 357 56 -352 391 56 -352 minecraft:stone
fill 358 56 -351 391 56 -351 minecraft:stone
fill 343 56 -350 345 56 -350 minecraft:stone
setblock 347 56 -350 minecraft:stone
fill 358 56 -350 391 56 -350 minecraft:stone
fill 342 56 -349 348 56 -349 minecraft:stone
fill 359 56 -349 391 56 -349 minecraft:stone
fill 342 56 -348 348 56 -348 minecraft:stone
fill 359 56 -348 391 56 -348 minecraft:stone
fill 342 56 -347 348 56 -347 minecraft:stone
fill 360 56 -347 391 56 -347 minecraft:stone
fill 342 56 -346 349 56 -346 minecraft:stone
fill 361 56 -346 391 56 -346 minecraft:stone
fill 342 56 -345 350 56 -345 minecraft:stone
fill 361 56 -345 391 56 -345 minecraft:stone
fill 343 56 -344 350 56 -344 minecraft:stone
fill 362 56 -344 391 56 -344 minecraft:stone
fill 345 56 -343 350 56 -343 minecraft:stone
fill 362 56 -343 391 56 -343 minecraft:stone
fill 347 56 -342 348 56 -342 minecraft:stone
fill 362 56 -342 391 56 -342 minecraft:stone
fill 362 56 -341 390 56 -341 minecraft:stone
fill 362 56 -340 389 56 -340 minecraft:stone
fill 363 56 -339 389 56 -339 minecraft:stone
fill 366 56 -338 389 56 -338 minecraft:stone
fill 368 56 -337 379 56 -337 minecraft:stone
fill 382 56 -337 388 56 -337 minecraft:stone
fill 370 56 -336 377 56 -336 minecraft:stone
fill 382 56 -336 388 56 -336 minecraft:stone
setblock 372 56 -335 minecraft:stone
fill 382 56 -335 388 56 -335 minecraft:stone
fill 381 56 -334 387 56 -334 minecraft:stone
fill 381 56 -333 386 56 -333 minecraft:stone
fill 380 56 -332 386 56 -332 minecraft:stone
fill 380 56 -331 386 56 -331 minecraft:stone
setblock 390 56 -331 minecraft:stone
fill 381 56 -330 386 56 -330 minecraft:stone
fill 390 56 -330 391 56 -330 minecraft:stone
fill 381 56 -329 385 56 -329 minecraft:stone
setblock 391 56 -329 minecraft:stone
setblock 357 56 -328 minecraft:stone
fill 381 56 -328 385 56 -328 minecraft:stone
setblock 391 56 -328 minecraft:stone
fill 356 56 -327 357 56 -327 minecraft:stone
fill 381 56 -327 386 56 -327 minecraft:stone
fill 355 56 -326 357 56 -326 minecraft:stone
fill 380 56 -326 386 56 -326 minecraft:stone
fill 355 56 -325 357 56 -325 minecraft:stone
fill 380 56 -325 386 56 -325 minecraft:stone
fill 354 56 -324 357 56 -324 minecraft:stone
fill 380 56 -324 386 56 -324 minecraft:stone
fill 354 56 -323 357 56 -323 minecraft:stone
fill 380 56 -323 386 56 -323 minecraft:stone
fill 354 56 -322 356 56 -322 minecraft:stone
fill 380 56 -322 386 56 -322 minecraft:stone
fill 353 56 -321 356 56 -321 minecraft:stone
fill 380 56 -321 387 56 -321 minecraft:stone
fill 353 56 -320 355 56 -320 minecraft:stone
fill 380 56 -320 387 56 -320 minecraft:stone
fill 353 56 -319 355 56 -319 minecraft:stone
fill 380 56 -319 387 56 -319 minecraft:stone
fill 368 57 -382 369 57 -382 minecraft:stone
fill 378 57 -382 391 57 -382 minecraft:stone
fill 377 57 -381 391 57 -381 minecraft:stone
fill 375 57 -380 391 57 -380 minecraft:stone
fill 373 57 -379 391 57 -379 minecraft:stone
fill 370 57 -378 391 57 -378 minecraft:stone
fill 368 57 -377 391 57 -377 minecraft:stone
fill 367 57 -376 391 57 -376 minecraft:stone
fill 366 57 -375 391 57 -375 minecraft:stone
fill 366 57 -374 391 57 -374 minecraft:stone
fill 365 57 -373 391 57 -373 minecraft:stone
fill 364 57 -372 391 57 -372 minecraft:stone
fill 363 57 -371 391 57 -371 minecraft:stone
fill 361 57 -370 391 57 -370 minecraft:stone
fill 360 57 -369 391 57 -369 minecraft:stone
fill 359 57 -368 391 57 -368 minecraft:stone
fill 359 57 -367 391 57 -367 minecraft:stone
fill 358 57 -366 391 57 -366 minecraft:stone
fill 358 57 -365 391 57 -365 minecraft:stone
fill 358 57 -364 391 57 -364 minecraft:stone
fill 357 57 -363 391 57 -363 minecraft:stone
fill 356 57 -362 391 57 -362 minecraft:stone
fill 356 57 -361 391 57 -361 minecraft:stone
fill 356 57 -360 391 57 -360 minecraft:stone
fill 331 57 -359 332 57 -359 minecraft:stone
fill 356 57 -359 391 57 -359 minecraft:stone
fill 328 57 -358 331 57 -358 minecraft:stone
fill 355 57 -358 391 57 -358 minecraft:stone
fill 328 57 -357 330 57 -357 minecraft:stone
fill 355 57 -357 391 57 -357 minecraft:stone
fill 328 57 -356 329 57 -356 minecraft:stone
fill 355 57 -356 391 57 -356 minecraft:stone
fill 355 57 -355 391 57 -355 minecraft:stone
fill 355 57 -354 391 57 -354 minecraft:stone
fill 356 57 -353 391 57 -353 minecraft:stone
fill 356 57 -352 391 57 -352 minecraft:stone
fill 357 57 -351 391 57 -351 minecraft:stone
setblock 344 57 -350 minecraft:stone
fill 357 57 -350 391 57 -350 minecraft:stone
fill 343 57 -349 345 57 -349 minecraft:stone
fill 358 57 -349 391 57 -349 minecraft:stone
fill 342 57 -348 346 57 -348 minecraft:stone
fill 359 57 -348 391 57 -348 minecraft:stone
fill 342 57 -347 346 57 -347 minecraft:stone
fill 359 57 -347 391 57 -347 minecraft:stone
fill 342 57 -346 346 57 -346 minecraft:stone
fill 360 57 -346 391 57 -346 minecraft:stone
fill 343 57 -345 349 57 -345 minecraft:stone
fill 361 57 -345 391 57 -345 minecraft:stone
setblock 344 57 -344 minecraft:stone
fill 346 57 -344 349 57 -344 minecraft:stone
fill 361 57 -344 391 57 -344 minecraft:stone
fill 346 57 -343 349 57 -343 minecraft:stone
fill 361 57 -343 391 57 -343 minecraft:stone
fill 361 57 -342 391 57 -342 minecraft:stone
fill 361 57 -341 391 57 -341 minecraft:stone
fill 360 57 -340 390 57 -340 minecraft:stone
fill 361 57 -339 389 57 -339 minecraft:stone
fill 363 57 -338 389 57 -338 minecraft:stone
fill 366 57 -337 388 57 -337 minecraft:stone
fill 369 57 -336 378 57 -336 minecraft:stone
fill 382 57 -336 388 57 -336 minecraft:stone
fill 371 57 -335 377 57 -335 minecraft:stone
fill 382 57 -335 388 57 -335 minecraft:stone
fill 381 57 -334 387 57 -334 minecraft:stone
fill 381 57 -333 386 57 -333 minecraft:stone
fill 380 57 -332 386 57 -332 minecraft:stone
fill 380 57 -331 386 57 -331 minecraft:stone
fill 381 57 -330 386 57 -330 minecraft:stone
fill 389 57 -330 391 57 -330 minecraft:stone
fill 381 57 -329 385 57 -329 minecraft:stone
fill 389 57 -329 391 57 -329 minecraft:stone
setblock 357 57 -328 minecraft:stone
fill 381 57 -328 385 57 -328 minecraft:stone
fill 390 57 -328 391 57 -328 minecraft:stone
setblock 357 57 -327 minecraft:stone
fill 380 57 -327 386 57 -327 minecraft:stone
fill 390 57 -327 391 57 -327 minecraft:stone
fill 356 57 -326 358 57 -326 minecraft:stone
fill 380 57 -326 386 57 -326 minecraft:stone
fill 356 57 -325 358 57 -325 minecraft:stone
fill 380 57 -325 386 57 -325 minecraft:stone
fill 355 57 -324 358 57 -324 minecraft:stone
fill 380 57 -324 386 57 -324 minecraft:stone
fill 355 57 -323 357 57 -323 minecraft:stone
fill 380 57 -323 386 57 -323 minecraft:stone
fill 354 57 -322 357 57 -322 minecraft:stone
fill 380 57 -322 386 57 -322 minecraft:stone
fill 354 57 -321 356 57 -321 minecraft:stone
fill 380 57 -321 387 57 -321 minecraft:stone
fill 353 57 -320 356 57 -320 minecraft:stone
fill 380 57 -320 387 57 -320 minecraft:stone
fill 353 57 -319 355 57 -319 minecraft:stone
fill 380 57 -319 387 57 -319 minecraft:stone
fill 367 58 -382 370 58 -382 minecraft:stone
fill 376 58 -382 391 58 -382 minecraft:stone
setblock 368 58 -381 minecraft:stone
setblock 371 58 -381 minecraft:stone
fill 375 58 -381 391 58 -381 minecraft:stone
fill 369 58 -380 371 58 -380 minecraft:stone
fill 373 58 -380 391 58 -380 minecraft:stone
fill 369 58 -379 391 58 -379 minecraft:stone
fill 368 58 -378 391 58 -378 minecraft:stone
fill 367 58 -377 391 58 -377 minecraft:stone
fill 366 58 -376 391 58 -376 minecraft:stone
fill 365 58 -375 391 58 -375 minecraft:stone
fill 364 58 -374 391 58 -374 minecraft:stone
fill 364 58 -373 391 58 -373 minecraft:stone
fill 362 58 -372 391 58 -372 minecraft:stone
fill 360 58 -371 391 58 -371 minecraft:stone
fill 359 58 -370 391 58 -370 minecraft:stone
fill 358 58 -369 391 58 -369 minecraft:stone
fill 357 58 -368 391 58 -368 minecraft:stone
fill 357 58 -367 391 58 -367 minecraft:stone
fill 357 58 -366 391 58 -366 minecraft:stone
fill 356 58 -365 391 58 -365 minecraft:stone
fill 356 58 -364 391 58 -364 minecraft:stone
fill 356 58 -363 391 58 -363 minecraft:stone
fill 356 58 -362 391 58 -362 minecraft:stone
fill 355 58 -361 391 58 -361 minecraft:stone
fill 355 58 -360 391 58 -360 minecraft:stone
setblock 331 58 -359 minecraft:stone
fill 355 58 -359 391 58 -359 minecraft:stone
fill 328 58 -358 330 58 -358 minecraft:stone
fill 354 58 -358 391 58 -358 minecraft:stone
fill 328 58 -357 329 58 -357 minecraft:stone
fill 354 58 -357 391 58 -357 minecraft:stone
setblock 328 58 -356 minecraft:stone
fill 354 58 -356 391 58 -356 minecraft:stone
fill 354 58 -355 391 58 -355 minecraft:stone
fill 354 58 -354 391 58 -354 minecraft:stone
fill 354 58 -353 391 58 -353 minecraft:stone
fill 354 58 -352 391 58 -352 minecraft:stone
fill 355 58 -351 391 58 -351 minecraft:stone
fill 356 58 -350 391 58 -350 minecraft:stone
fill 357 58 -349 391 58 -349 minecraft:stone
fill 358 58 -348 391 58 -348 minecraft:stone
fill 358 58 -347 391 58 -347 minecraft:stone
fill 359 58 -346 391 58 -346 minecraft:stone
fill 360 58 -345 391 58 -345 minecraft:stone
fill 360 58 -344 391 58 -344 minecraft:stone
fill 360 58 -343 391 58 -343 minecraft:stone
fill 360 58 -342 391 58 -342 minecraft:stone
fill 360 58 -341 391 58 -341 minecraft:stone
fill 360 58 -340 391 58 -340 minecraft:stone
fill 360 58 -339 389 58 -339 minecraft:stone
fill 360 58 -338 389 58 -338 minecraft:stone
fill 361 58 -337 388 58 -337 minecraft:stone
fill 366 58 -336 388 58 -336 minecraft:stone
fill 369 58 -335 379 58 -335 minecraft:stone
fill 381 58 -335 388 58 -335 minecraft:stone
fill 372 58 -334 377 58 -334 minecraft:stone
fill 381 58 -334 387 58 -334 minecraft:stone
fill 381 58 -333 386 58 -333 minecraft:stone
fill 380 58 -332 386 58 -332 minecraft:stone
fill 380 58 -331 386 58 -331 minecraft:stone
setblock 391 58 -331 minecraft:stone
fill 381 58 -330 391 58 -330 minecraft:stone
fill 381 58 -329 385 58 -329 minecraft:stone
fill 388 58 -329 391 58 -329 minecraft:stone
setblock 358 58 -328 minecraft:stone
fill 381 58 -328 385 58 -328 minecraft:stone
fill 389 58 -328 391 58 -328 minecraft:stone
setblock 358 58 -327 minecraft:stone
fill 380 58 -327 386 58 -327 minecraft:stone
fill 389 58 -327 391 58 -327 minecraft:stone
fill 357 58 -326 358 58 -326 minecraft:stone
fill 380 58 -326 386 58 -326 minecraft:stone
fill 356 58 -325 358 58 -325 minecraft:stone
fill 380 58 -325 386 58 -325 minecraft:stone
fill 356 58 -324 358 58 -324 minecraft:stone
fill 380 58 -324 386 58 -324 minecraft:stone
fill 355 58 -323 358 58 -323 minecraft:stone
fill 380 58 -323 386 58 -323 minecraft:stone
fill 355 58 -322 357 58 -322 minecraft:stone
fill 380 58 -322 386 58 -322 minecraft:stone
fill 354 58 -321 357 58 -321 minecraft:stone
fill 380 58 -321 387 58 -321 minecraft:stone
fill 354 58 -320 356 58 -320 minecraft:stone
fill 380 58 -320 387 58 -320 minecraft:stone
fill 354 58 -319 355 58 -319 minecraft:stone
fill 380 58 -319 387 58 -319 minecraft:stone
fill 366 59 -382 371 59 -382 minecraft:stone
fill 375 59 -382 391 59 -382 minecraft:stone
fill 367 59 -381 391 59 -381 minecraft:stone
fill 368 59 -380 391 59 -380 minecraft:stone
fill 368 59 -379 391 59 -379 minecraft:stone
fill 367 59 -378 391 59 -378 minecraft:stone
fill 366 59 -377 391 59 -377 minecraft:stone
fill 365 59 -376 391 59 -376 minecraft:stone
fill 364 59 -375 391 59 -375 minecraft:stone
fill 363 59 -374 391 59 -374 minecraft:stone
fill 362 59 -373 391 59 -373 minecraft:stone
fill 360 59 -372 391 59 -372 minecraft:stone
fill 359 59 -371 391 59 -371 minecraft:stone
fill 358 59 -370 391 59 -370 minecraft:stone
fill 357 59 -369 391 59 -369 minecraft:stone
fill 356 59 -368 391 59 -368 minecraft:stone
fill 356 59 -367 391 59 -367 minecraft:stone
fill 356 59 -366 391 59 -366 minecraft:stone
fill 355 59 -365 391 59 -365 minecraft:stone
fill 355 59 -364 391 59 -364 minecraft:stone
fill 355 59 -363 391 59 -363 minecraft:stone
fill 355 59 -362 391 59 -362 minecraft:stone
fill 354 59 -361 391 59 -361 minecraft:stone
fill 354 59 -360 391 59 -360 minecraft:stone
fill 354 59 -359 391 59 -359 minecraft:stone
fill 329 59 -358 330 59 -358 minecraft:stone
fill 347 59 -358 348 59 -358 minecraft:stone
fill 353 59 -358 391 59 -358 minecraft:stone
fill 328 59 -357 329 59 -357 minecraft:stone
fill 346 59 -357 350 59 -357 minecraft:stone
fill 353 59 -357 391 59 -357 minecraft:stone
fill 345 59 -356 391 59 -356 minecraft:stone
fill 347 59 -355 391 59 -355 minecraft:stone
fill 349 59 -354 391 59 -354 minecraft:stone
fill 351 59 -353 391 59 -353 minecraft:stone
fill 352 59 -352 391 59 -352 minecraft:stone
fill 353 59 -351 391 59 -351 minecraft:stone
fill 355 59 -350 391 59 -350 minecraft:stone
fill 356 59 -349 391 59 -349 minecraft:stone
fill 357 59 -348 391 59 -348 minecraft:stone
fill 357 59 -347 391 59 -347 minecraft:stone
fill 358 59 -346 391 59 -346 minecraft:stone
fill 359 59 -345 391 59 -345 minecraft:stone
fill 359 59 -344 391 59 -344 minecraft:stone
fill 359 59 -343 391 59 -343 minecraft:stone
fill 359 59 -342 391 59 -342 minecraft:stone
fill 359 59 -341 391 59 -341 minecraft:stone
fill 359 59 -340 391 59 -340 minecraft:stone
fill 359 59 -339 391 59 -339 minecraft:stone
fill 359 59 -338 391 59 -338 minecraft:stone
fill 358 59 -337 388 59 -337 minecraft:stone
fill 390 59 -337 391 59 -337 minecraft:stone
fill 356 59 -336 388 59 -336 minecraft:stone
setblock 391 59 -336 minecraft:stone
fill 367 59 -335 380 59 -335 minecraft:stone
fill 382 59 -335 388 59 -335 minecraft:stone
fill 370 59 -334 387 59 -334 minecraft:stone
fill 372 59 -333 377 59 -333 minecraft:stone
fill 381 59 -333 386 59 -333 minecraft:stone
fill 380 59 -332 386 59 -332 minecraft:stone
fill 380 59 -331 386 59 -331 minecraft:stone
fill 381 59 -330 390 59 -330 minecraft:stone
fill 381 59 -329 390 59 -329 minecraft:stone
setblock 359 59 -328 minecraft:stone
fill 381 59 -328 385 59 -328 minecraft:stone
fill 387 59 -328 391 59 -328 minecraft:stone
setblock 359 59 -327 minecraft:stone
fill 380 59 -327 386 59 -327 minecraft:stone
fill 388 59 -327 391 59 -327 minecraft:stone
fill 358 59 -326 359 59 -326 minecraft:stone
fill 380 59 -326 386 59 -326 minecraft:stone
fill 388 59 -326 389 59 -326 minecraft:stone
fill 357 59 -325 359 59 -325 minecraft:stone
fill 380 59 -325 386 59 -325 minecraft:stone
fill 356 59 -324 359 59 -324 minecraft:stone
fill 380 59 -324 386 59 -324 minecraft:stone
fill 356 59 -323 358 59 -323 minecraft:stone
fill 380 59 -323 386 59 -323 minecraft:stone
fill 355 59 -322 357 59 -322 minecraft:stone
fill 380 59 -322 386 59 -322 minecraft:stone
fill 355 59 -321 357 59 -321 minecraft:stone
fill 380 59 -321 387 59 -321 minecraft:stone
fill 354 59 -320 356 59 -320 minecraft:stone
fill 380 59 -320 387 59 -320 minecraft:stone
fill 354 59 -319 355 59 -319 minecraft:stone
fill 380 59 -319 387 59 -319 minecraft:stone
fill 366 60 -382 371 60 -382 minecraft:stone
fill 373 60 -382 391 60 -382 minecraft:stone
fill 367 60 -381 391 60 -381 minecraft:stone
fill 368 60 -380 391 60 -380 minecraft:stone
fill 367 60 -379 391 60 -379 minecraft:stone
fill 366 60 -378 391 60 -378 minecraft:stone
fill 365 60 -377 391 60 -377 minecraft:stone
fill 364 60 -376 391 60 -376 minecraft:stone
fill 363 60 -375 391 60 -375 minecraft:stone
fill 362 60 -374 391 60 -374 minecraft:stone
fill 360 60 -373 391 60 -373 minecraft:stone
fill 358 60 -372 391 60 -372 minecraft:stone
fill 357 60 -371 391 60 -371 minecraft:stone
fill 356 60 -370 391 60 -370 minecraft:stone
fill 355 60 -369 391 60 -369 minecraft:stone
fill 355 60 -368 391 60 -368 minecraft:stone
fill 355 60 -367 391 60 -367 minecraft:stone
fill 354 60 -366 391 60 -366 minecraft:stone
fill 354 60 -365 391 60 -365 minecraft:stone
fill 354 60 -364 391 60 -364 minecraft:stone
fill 354 60 -363 391 60 -363 minecraft:stone
fill 354 60 -362 391 60 -362 minecraft:stone
fill 353 60 -361 391 60 -361 minecraft:stone
fill 344 60 -360 349 60 -360 minecraft:stone
fill 353 60 -360 391 60 -360 minecraft:stone
fill 344 60 -359 350 60 -359 minecraft:stone
fill 353 60 -359 391 60 -359 minecraft:stone
setblock 329 60 -358 minecraft:stone
fill 343 60 -358 391 60 -358 minecraft:stone
setblock 328 60 -357 minecraft:stone
fill 342 60 -357 391 60 -357 minecraft:stone
fill 341 60 -356 391 60 -356 minecraft:stone
fill 341 60 -355 391 60 -355 minecraft:stone
fill 340 60 -354 391 60 -354 minecraft:stone
fill 340 60 -353 391 60 -353 minecraft:stone
fill 340 60 -352 391 60 -352 minecraft:stone
fill 340 60 -351 342 60 -351 minecraft:stone
fill 350 60 -351 391 60 -351 minecraft:stone
fill 340 60 -350 341 60 -350 minecraft:stone
fill 353 60 -350 391 60 -350 minecraft:stone
fill 354 60 -349 391 60 -349 minecraft:stone
fill 355 60 -348 391 60 -348 minecraft:stone
fill 357 60 -347 391 60 -347 minecraft:stone
fill 357 60 -346 391 60 -346 minecraft:stone
fill 358 60 -345 391 60 -345 minecraft:stone
fill 358 60 -344 391 60 -344 minecraft:stone
fill 358 60 -343 391 60 -343 minecraft:stone
fill 358 60 -342 391 60 -342 minecraft:stone
fill 358 60 -341 391 60 -341 minecraft:stone
fill 358 60 -340 391 60 -340 minecraft:stone
fill 358 60 -339 391 60 -339 minecraft:stone
fill 358 60 -338 391 60 -338 minecraft:stone
fill 356 60 -337 391 60 -337 minecraft:stone
fill 356 60 -336 391 60 -336 minecraft:stone
fill 365 60 -335 388 60 -335 minecraft:stone
fill 368 60 -334 387 60 -334 minecraft:stone
fill 370 60 -333 386 60 -333 minecraft:stone
fill 370 60 -332 378 60 -332 minecraft:stone
fill 380 60 -332 386 60 -332 minecraft:stone
fill 370 60 -331 371 60 -331 minecraft:stone
fill 380 60 -331 386 60 -331 minecraft:stone
fill 381 60 -330 388 60 -330 minecraft:stone
fill 381 60 -329 389 60 -329 minecraft:stone
fill 381 60 -328 389 60 -328 minecraft:stone
fill 380 60 -327 390 60 -327 minecraft:stone
setblock 359 60 -326 minecraft:stone
fill 380 60 -326 389 60 -326 minecraft:stone
fill 358 60 -325 359 60 -325 minecraft:stone
fill 380 60 -325 387 60 -325 minecraft:stone
fill 357 60 -324 359 60 -324 minecraft:stone
fill 380 60 -324 386 60 -324 minecraft:stone
fill 357 60 -323 358 60 -323 minecraft:stone
fill 380 60 -323 386 60 -323 minecraft:stone
fill 356 60 -322 358 60 -322 minecraft:stone
fill 380 60 -322 386 60 -322 minecraft:stone
fill 355 60 -321 357 60 -321 minecraft:stone
fill 380 60 -321 387 60 -321 minecraft:stone
fill 355 60 -320 356 60 -320 minecraft:stone
fill 380 60 -320 387 60 -320 minecraft:stone
setblock 355 60 -319 minecraft:stone
fill 380 60 -319 387 60 -319 minecraft:stone
fill 367 61 -382 391 61 -382 minecraft:stone
fill 367 61 -381 391 61 -381 minecraft:stone
fill 366 61 -380 391 61 -380 minecraft:stone
fill 365 61 -379 391 61 -379 minecraft:stone
fill 364 61 -378 391 61 -378 minecraft:stone
fill 363 61 -377 391 61 -377 minecraft:stone
fill 362 61 -376 391 61 -376 minecraft:stone
fill 361 61 -375 391 61 -375 minecraft:stone
fill 360 61 -374 391 61 -374 minecraft:stone
fill 358 61 -373 391 61 -373 minecraft:stone
fill 353 61 -372 391 61 -372 minecraft:stone
fill 353 61 -371 391 61 -371 minecraft:stone
fill 353 61 -370 391 61 -370 minecraft:stone
fill 352 61 -369 391 61 -369 minecraft:stone
fill 351 61 -368 391 61 -368 minecraft:stone
fill 351 61 -367 391 61 -367 minecraft:stone
fill 350 61 -366 391 61 -366 minecraft:stone
fill 350 61 -365 391 61 -365 minecraft:stone
fill 351 61 -364 391 61 -364 minecraft:stone
fill 351 61 -363 391 61 -363 minecraft:stone
fill 346 61 -362 391 61 -362 minecraft:stone
fill 343 61 -361 391 61 -361 minecraft:stone
fill 342 61 -360 391 61 -360 minecraft:stone
fill 341 61 -359 391 61 -359 minecraft:stone
fill 340 61 -358 391 61 -358 minecraft:stone
fill 340 61 -357 391 61 -357 minecraft:stone
fill 340 61 -356 391 61 -356 minecraft:stone
fill 339 61 -355 391 61 -355 minecraft:stone
fill 339 61 -354 391 61 -354 minecraft:stone
fill 339 61 -353 391 61 -353 minecraft:stone
fill 338 61 -352 391 61 -352 minecraft:stone
fill 338 61 -351 391 61 -351 minecraft:stone
fill 338 61 -350 391 61 -350 minecraft:stone
fill 337 61 -349 345 61 -349 minecraft:stone
fill 353 61 -349 391 61 -349 minecraft:stone
fill 332 61 -348 344 61 -348 minecraft:stone
fill 354 61 -348 391 61 -348 minecraft:stone
fill 332 61 -347 341 61 -347 minecraft:stone
fill 355 61 -347 391 61 -347 minecraft:stone
setblock 336 61 -346 minecraft:stone
fill 356 61 -346 391 61 -346 minecraft:stone
fill 357 61 -345 391 61 -345 minecraft:stone
setblock 328 61 -344 minecraft:stone
fill 357 61 -344 391 61 -344 minecraft:stone
fill 357 61 -343 391 61 -343 minecraft:stone
fill 358 61 -342 391 61 -342 minecraft:stone
fill 358 61 -341 391 61 -341 minecraft:stone
fill 358 61 -340 391 61 -340 minecraft:stone
fill 357 61 -339 391 61 -339 minecraft:stone
fill 357 61 -338 391 61 -338 minecraft:stone
fill 356 61 -337 391 61 -337 minecraft:stone
fill 355 61 -336 391 61 -336 minecraft:stone
fill 356 61 -335 391 61 -335 minecraft:stone
fill 366 61 -334 387 61 -334 minecraft:stone
setblock 391 61 -334 minecraft:stone
fill 368 61 -333 386 61 -333 minecraft:stone
fill 368 61 -332 386 61 -332 minecraft:stone
fill 368 61 -331 386 61 -331 minecraft:stone
fill 368 61 -330 373 61 -330 minecraft:stone
fill 381 61 -330 386 61 -330 minecraft:stone
fill 367 61 -329 370 61 -329 minecraft:stone
fill 381 61 -329 387 61 -329 minecraft:stone
fill 367 61 -328 368 61 -328 minecraft:stone
fill 381 61 -328 388 61 -328 minecraft:stone
setblock 361 61 -327 minecraft:stone
fill 380 61 -327 388 61 -327 minecraft:stone
setblock 360 61 -326 minecraft:stone
fill 380 61 -326 389 61 -326 minecraft:stone
fill 359 61 -325 360 61 -325 minecraft:stone
fill 380 61 -325 387 61 -325 minecraft:stone
fill 358 61 -324 359 61 -324 minecraft:stone
fill 380 61 -324 386 61 -324 minecraft:stone
fill 357 61 -323 359 61 -323 minecraft:stone
fill 380 61 -323 386 61 -323 minecraft:stone
fill 357 61 -322 358 61 -322 minecraft:stone
fill 380 61 -322 386 61 -322 minecraft:stone
fill 356 61 -321 357 61 -321 minecraft:stone
fill 380 61 -321 387 61 -321 minecraft:stone
setblock 356 61 -320 minecraft:stone
fill 380 61 -320 387 61 -320 minecraft:stone
setblock 355 61 -319 minecraft:stone
fill 380 61 -319 387 61 -319 minecraft:stone
fill 368 62 -382 391 62 -382 minecraft:dirt
fill 366 62 -381 391 62 -381 minecraft:dirt
fill 365 62 -380 391 62 -380 minecraft:dirt
fill 364 62 -379 391 62 -379 minecraft:dirt
fill 363 62 -378 391 62 -378 minecraft:dirt
fill 362 62 -377 391 62 -377 minecraft:dirt
fill 361 62 -376 391 62 -376 minecraft:dirt
fill 359 62 -375 391 62 -375 minecraft:dirt
fill 356 62 -374 391 62 -374 minecraft:dirt
fill 351 62 -373 391 62 -373 minecraft:dirt
fill 349 62 -372 391 62 -372 minecraft:dirt
fill 349 62 -371 391 62 -371 minecraft:dirt
fill 349 62 -370 391 62 -370 minecraft:dirt
fill 349 62 -369 391 62 -369 minecraft:dirt
fill 350 62 -368 391 62 -368 minecraft:dirt
fill 351 62 -367 391 62 -367 minecraft:dirt
fill 350 62 -366 391 62 -366 minecraft:dirt
fill 348 62 -365 391 62 -365 minecraft:dirt
fill 347 62 -364 348 62 -364 minecraft:dirt
fill 350 62 -364 391 62 -364 minecraft:dirt
setblock 345 62 -363 minecraft:dirt
fill 348 62 -363 349 62 -363 minecraft:dirt
fill 351 62 -363 391 62 -363 minecraft:dirt
fill 343 62 -362 391 62 -362 minecraft:dirt
fill 341 62 -361 391 62 -361 minecraft:dirt
fill 340 62 -360 391 62 -360 minecraft:dirt
fill 340 62 -359 391 62 -359 minecraft:dirt
fill 339 62 -358 391 62 -358 minecraft:dirt
fill 339 62 -357 391 62 -357 minecraft:dirt
fill 338 62 -356 391 62 -356 minecraft:dirt
fill 338 62 -355 391 62 -355 minecraft:dirt
fill 338 62 -354 378 62 -354 minecraft:dirt
fill 380 62 -354 391 62 -354 minecraft:dirt
fill 337 62 -353 378 62 -353 minecraft:dirt
fill 380 62 -353 391 62 -353 minecraft:dirt
fill 337 62 -352 391 62 -352 minecraft:dirt
fill 336 62 -351 391 62 -351 minecraft:dirt
fill 334 62 -350 391 62 -350 minecraft:dirt
fill 331 62 -349 391 62 -349 minecraft:dirt
fill 329 62 -348 391 62 -348 minecraft:dirt
fill 328 62 -347 347 62 -347 minecraft:dirt
fill 353 62 -347 391 62 -347 minecraft:dirt
fill 328 62 -346 345 62 -346 minecraft:dirt
fill 354 62 -346 391 62 -346 minecraft:dirt
fill 328 62 -345 342 62 -345 minecraft:dirt
fill 355 62 -345 391 62 -345 minecraft:dirt
fill 328 62 -344 339 62 -344 minecraft:dirt
fill 357 62 -344 391 62 -344 minecraft:dirt
fill 328 62 -343 330 62 -343 minecraft:dirt
fill 357 62 -343 391 62 -343 minecraft:dirt
fill 357 62 -342 391 62 -342 minecraft:dirt
fill 357 62 -341 391 62 -341 minecraft:dirt
fill 357 62 -340 391 62 -340 minecraft:dirt
fill 356 62 -339 391 62 -339 minecraft:dirt
fill 356 62 -338 391 62 -338 minecraft:dirt
fill 355 62 -337 391 62 -337 minecraft:dirt
fill 355 62 -336 391 62 -336 minecraft:dirt
fill 355 62 -335 391 62 -335 minecraft:dirt
fill 356 62 -334 359 62 -334 minecraft:dirt
setblock 361 62 -334 minecraft:dirt
fill 363 62 -334 387 62 -334 minecraft:dirt
fill 390 62 -334 391 62 -334 minecraft:dirt
fill 367 62 -333 387 62 -333 minecraft:dirt
setblock 391 62 -333 minecraft:dirt
fill 370 62 -332 386 62 -332 minecraft:dirt
setblock 368 62 -331 minecraft:dirt
fill 376 62 -331 385 62 -331 minecraft:dirt
fill 366 62 -330 373 62 -330 minecraft:dirt
setblock 387 62 -330 minecraft:dirt
fill 365 62 -329 380 62 -329 minecraft:dirt
fill 363 62 -328 371 62 -328 minecraft:dirt
fill 380 62 -328 386 62 -328 minecraft:dirt
fill 362 62 -327 363 62 -327 minecraft:dirt
setblock 365 62 -327 minecraft:dirt
fill 367 62 -327 369 62 -327 minecraft:dirt
fill 380 62 -327 387 62 -327 minecraft:dirt
fill 361 62 -326 362 62 -326 minecraft:dirt
fill 366 62 -326 367 62 -326 minecraft:dirt
fill 380 62 -326 387 62 -326 minecraft:dirt
fill 360 62 -325 361 62 -325 minecraft:dirt
fill 379 62 -325 387 62 -325 minecraft:dirt
fill 359 62 -324 360 62 -324 minecraft:dirt
fill 379 62 -324 387 62 -324 minecraft:dirt
fill 358 62 -323 359 62 -323 minecraft:dirt
fill 380 62 -323 387 62 -323 minecraft:dirt
setblock 358 62 -322 minecraft:dirt
fill 380 62 -322 387 62 -322 minecraft:dirt
setblock 357 62 -321 minecraft:dirt
fill 379 62 -321 387 62 -321 minecraft:dirt
setblock 356 62 -320 minecraft:dirt
fill 379 62 -320 387 62 -320 minecraft:dirt
fill 380 62 -319 387 62 -319 minecraft:dirt
fill 365 63 -382 378 63 -382 minecraft:dirt
fill 385 63 -382 391 63 -382 minecraft:dirt
fill 363 63 -381 378 63 -381 minecraft:dirt
fill 385 63 -381 391 63 -381 minecraft:dirt
fill 361 63 -380 377 63 -380 minecraft:dirt
fill 385 63 -380 391 63 -380 minecraft:dirt
fill 360 63 -379 377 63 -379 minecraft:dirt
fill 384 63 -379 391 63 -379 minecraft:dirt
fill 359 63 -378 377 63 -378 minecraft:dirt
fill 384 63 -378 391 63 -378 minecraft:dirt
fill 357 63 -377 377 63 -377 minecraft:dirt
fill 384 63 -377 391 63 -377 minecraft:dirt
fill 353 63 -376 376 63 -376 minecraft:dirt
fill 384 63 -376 391 63 -376 minecraft:dirt
fill 350 63 -375 376 63 -375 minecraft:dirt
fill 384 63 -375 391 63 -375 minecraft:dirt
fill 348 63 -374 352 63 -374 minecraft:dirt
fill 354 63 -374 376 63 -374 minecraft:dirt
fill 384 63 -374 391 63 -374 minecraft:dirt
fill 347 63 -373 349 63 -373 minecraft:dirt
fill 351 63 -373 376 63 -373 minecraft:dirt
fill 383 63 -373 391 63 -373 minecraft:dirt
fill 346 63 -372 376 63 -372 minecraft:dirt
fill 383 63 -372 391 63 -372 minecraft:dirt
fill 346 63 -371 347 63 -371 minecraft:dirt
fill 349 63 -371 376 63 -371 minecraft:dirt
fill 383 63 -371 391 63 -371 minecraft:dirt
fill 345 63 -370 376 63 -370 minecraft:dirt
fill 383 63 -370 391 63 -370 minecraft:dirt
fill 344 63 -369 376 63 -369 minecraft:dirt
fill 383 63 -369 391 63 -369 minecraft:dirt
fill 343 63 -368 375 63 -368 minecraft:dirt
fill 383 63 -368 391 63 -368 minecraft:dirt
fill 343 63 -367 348 63 -367 minecraft:dirt
fill 351 63 -367 375 63 -367 minecraft:dirt
fill 383 63 -367 391 63 -367 minecraft:dirt
fill 343 63 -366 348 63 -366 minecraft:dirt
fill 350 63 -366 375 63 -366 minecraft:dirt
fill 383 63 -366 391 63 -366 minecraft:dirt
fill 343 63 -365 375 63 -365 minecraft:dirt
fill 382 63 -365 391 63 -365 minecraft:dirt
fill 344 63 -364 348 63 -364 minecraft:dirt
fill 350 63 -364 374 63 -364 minecraft:dirt
fill 382 63 -364 391 63 -364 minecraft:dirt
fill 342 63 -363 345 63 -363 minecraft:dirt
fill 348 63 -363 349 63 -363 minecraft:dirt
fill 351 63 -363 374 63 -363 minecraft:dirt
fill 382 63 -363 391 63 -363 minecraft:dirt
fill 340 63 -362 374 63 -362 minecraft:dirt
fill 381 63 -362 391 63 -362 minecraft:dirt
fill 339 63 -361 374 63 -361 minecraft:dirt
fill 381 63 -361 391 63 -361 minecraft:dirt
fill 340 63 -360 373 63 -360 minecraft:dirt
fill 381 63 -360 391 63 -360 minecraft:dirt
fill 339 63 -359 373 63 -359 minecraft:dirt
fill 380 63 -359 391 63 -359 minecraft:dirt
fill 339 63 -358 373 63 -358 minecraft:dirt
fill 380 63 -358 391 63 -358 minecraft:dirt
fill 337 63 -357 373 63 -357 minecraft:dirt
fill 380 63 -357 391 63 -357 minecraft:dirt
fill 337 63 -356 373 63 -356 minecraft:dirt
fill 380 63 -356 391 63 -356 minecraft:dirt
fill 337 63 -355 373 63 -355 minecraft:dirt
fill 380 63 -355 391 63 -355 minecraft:dirt
fill 336 63 -354 373 63 -354 minecraft:dirt
fill 380 63 -354 391 63 -354 minecraft:dirt
fill 337 63 -353 373 63 -353 minecraft:dirt
fill 381 63 -353 391 63 -353 minecraft:dirt
fill 335 63 -352 373 63 -352 minecraft:dirt
fill 381 63 -352 391 63 -352 minecraft:dirt
fill 333 63 -351 373 63 -351 minecraft:dirt
fill 381 63 -351 391 63 -351 minecraft:dirt
setblock 330 63 -350 minecraft:dirt
fill 333 63 -350 378 63 -350 minecraft:dirt
fill 381 63 -350 391 63 -350 minecraft:dirt
fill 328 63 -349 329 63 -349 minecraft:dirt
fill 331 63 -349 378 63 -349 minecraft:dirt
fill 381 63 -349 391 63 -349 minecraft:dirt
fill 328 63 -348 378 63 -348 minecraft:dirt
fill 381 63 -348 391 63 -348 minecraft:dirt
fill 328 63 -347 378 63 -347 minecraft:dirt
fill 381 63 -347 391 63 -347 minecraft:dirt
fill 328 63 -346 378 63 -346 minecraft:dirt
fill 381 63 -346 391 63 -346 minecraft:dirt
fill 328 63 -345 342 63 -345 minecraft:dirt
fill 345 63 -345 376 63 -345 minecraft:dirt
fill 382 63 -345 391 63 -345 minecraft:dirt
fill 328 63 -344 339 63 -344 minecraft:dirt
fill 341 63 -344 344 63 -344 minecraft:dirt
fill 346 63 -344 376 63 -344 minecraft:dirt
fill 382 63 -344 391 63 -344 minecraft:dirt
fill 328 63 -343 333 63 -343 minecraft:dirt
fill 335 63 -343 337 63 -343 minecraft:dirt
fill 339 63 -343 340 63 -343 minecraft:dirt
fill 353 63 -343 376 63 -343 minecraft:dirt
fill 382 63 -343 391 63 -343 minecraft:dirt
fill 328 63 -342 332 63 -342 minecraft:dirt
setblock 335 63 -342 minecraft:dirt
fill 353 63 -342 376 63 -342 minecraft:dirt
fill 383 63 -342 391 63 -342 minecraft:dirt
fill 353 63 -341 376 63 -341 minecraft:dirt
fill 383 63 -341 391 63 -341 minecraft:dirt
fill 354 63 -340 376 63 -340 minecraft:dirt
fill 383 63 -340 391 63 -340 minecraft:dirt
fill 353 63 -339 376 63 -339 minecraft:dirt
fill 384 63 -339 391 63 -339 minecraft:dirt
fill 353 63 -338 354 63 -338 minecraft:dirt
fill 356 63 -338 376 63 -338 minecraft:dirt
fill 384 63 -338 391 63 -338 minecraft:dirt
fill 353 63 -337 376 63 -337 minecraft:dirt
fill 385 63 -337 391 63 -337 minecraft:dirt
setblock 353 63 -336 minecraft:dirt
fill 355 63 -336 376 63 -336 minecraft:dirt
fill 385 63 -336 391 63 -336 minecraft:dirt
fill 353 63 -335 376 63 -335 minecraft:dirt
fill 385 63 -335 391 63 -335 minecraft:dirt
fill 354 63 -334 359 63 -334 minecraft:dirt
setblock 361 63 -334 minecraft:dirt
fill 363 63 -334 376 63 -334 minecraft:dirt
fill 386 63 -334 387 63 -334 minecraft:dirt
fill 390 63 -334 391 63 -334 minecraft:dirt
fill 356 63 -333 357 63 -333 minecraft:dirt
setblock 365 63 -333 minecraft:dirt
fill 367 63 -333 376 63 -333 minecraft:dirt
fill 387 63 -333 391 63 -333 minecraft:dirt
fill 367 63 -332 376 63 -332 minecraft:dirt
fill 388 63 -332 391 63 -332 minecraft:dirt
fill 369 63 -331 376 63 -331 minecraft:dirt
fill 390 63 -331 391 63 -331 minecraft:dirt
fill 374 63 -330 381 63 -330 minecraft:dirt
setblock 391 63 -330 minecraft:dirt
fill 367 63 -329 372 63 -329 minecraft:dirt
setblock 381 63 -329 minecraft:dirt
fill 365 63 -328 378 63 -328 minecraft:dirt
fill 364 63 -327 365 63 -327 minecraft:dirt
fill 367 63 -327 386 63 -327 minecraft:dirt
fill 363 63 -326 371 63 -326 minecraft:dirt
fill 377 63 -326 387 63 -326 minecraft:dirt
fill 361 63 -325 362 63 -325 minecraft:dirt
setblock 366 63 -325 minecraft:dirt
setblock 368 63 -325 minecraft:dirt
fill 379 63 -325 387 63 -325 minecraft:dirt
fill 360 63 -324 361 63 -324 minecraft:dirt
fill 380 63 -324 387 63 -324 minecraft:dirt
setblock 359 63 -323 minecraft:dirt
fill 380 63 -323 387 63 -323 minecraft:dirt
fill 380 63 -322 387 63 -322 minecraft:dirt
fill 380 63 -321 387 63 -321 minecraft:dirt
fill 380 63 -320 387 63 -320 minecraft:dirt
fill 380 63 -319 387 63 -319 minecraft:dirt
fill 353 64 -382 364 64 -382 minecraft:dirt
fill 366 64 -382 375 64 -382 minecraft:dirt
fill 383 64 -382 391 64 -382 minecraft:dirt
fill 351 64 -381 354 64 -381 minecraft:dirt
fill 356 64 -381 375 64 -381 minecraft:dirt
fill 382 64 -381 391 64 -381 minecraft:dirt
fill 350 64 -380 375 64 -380 minecraft:dirt
fill 382 64 -380 391 64 -380 minecraft:dirt
fill 349 64 -379 375 64 -379 minecraft:dirt
fill 382 64 -379 391 64 -379 minecraft:dirt
setblock 347 64 -378 minecraft:dirt
fill 349 64 -378 376 64 -378 minecraft:dirt
fill 382 64 -378 391 64 -378 minecraft:dirt
fill 346 64 -377 349 64 -377 minecraft:dirt
fill 351 64 -377 373 64 -377 minecraft:dirt
fill 381 64 -377 391 64 -377 minecraft:dirt
fill 345 64 -376 373 64 -376 minecraft:dirt
fill 381 64 -376 391 64 -376 minecraft:dirt
fill 343 64 -375 373 64 -375 minecraft:dirt
fill 381 64 -375 391 64 -375 minecraft:dirt
fill 343 64 -374 352 64 -374 minecraft:dirt
fill 354 64 -374 373 64 -374 minecraft:dirt
fill 380 64 -374 391 64 -374 minecraft:dirt
fill 342 64 -373 373 64 -373 minecraft:dirt
fill 380 64 -373 391 64 -373 minecraft:dirt
fill 342 64 -372 373 64 -372 minecraft:dirt
fill 380 64 -372 391 64 -372 minecraft:dirt
fill 341 64 -371 373 64 -371 minecraft:dirt
fill 380 64 -371 391 64 -371 minecraft:dirt
fill 335 64 -370 373 64 -370 minecraft:dirt
fill 380 64 -370 391 64 -370 minecraft:dirt
fill 335 64 -369 373 64 -369 minecraft:dirt
fill 380 64 -369 391 64 -369 minecraft:dirt
fill 336 64 -368 372 64 -368 minecraft:dirt
fill 380 64 -368 391 64 -368 minecraft:dirt
fill 335 64 -367 372 64 -367 minecraft:dirt
fill 380 64 -367 391 64 -367 minecraft:dirt
fill 336 64 -366 372 64 -366 minecraft:dirt
fill 379 64 -366 391 64 -366 minecraft:dirt
fill 337 64 -365 372 64 -365 minecraft:dirt
fill 379 64 -365 391 64 -365 minecraft:dirt
fill 339 64 -364 370 64 -364 minecraft:dirt
fill 379 64 -364 391 64 -364 minecraft:dirt
fill 338 64 -363 340 64 -363 minecraft:dirt
fill 342 64 -363 370 64 -363 minecraft:dirt
fill 378 64 -363 391 64 -363 minecraft:dirt
fill 337 64 -362 370 64 -362 minecraft:dirt
fill 377 64 -362 391 64 -362 minecraft:dirt
fill 337 64 -361 370 64 -361 minecraft:dirt
fill 377 64 -361 391 64 -361 minecraft:dirt
fill 337 64 -360 338 64 -360 minecraft:dirt
fill 340 64 -360 370 64 -360 minecraft:dirt
fill 377 64 -360 391 64 -360 minecraft:dirt
setblock 337 64 -359 minecraft:dirt
fill 339 64 -359 370 64 -359 minecraft:dirt
fill 377 64 -359 391 64 -359 minecraft:dirt
fill 336 64 -358 370 64 -358 minecraft:dirt
fill 377 64 -358 391 64 -358 minecraft:dirt
fill 336 64 -357 370 64 -357 minecraft:dirt
fill 377 64 -357 391 64 -357 minecraft:dirt
fill 336 64 -356 370 64 -356 minecraft:dirt
fill 377 64 -356 391 64 -356 minecraft:dirt
fill 335 64 -355 370 64 -355 minecraft:dirt
fill 377 64 -355 391 64 -355 minecraft:dirt
fill 334 64 -354 371 64 -354 minecraft:dirt
fill 378 64 -354 391 64 -354 minecraft:dirt
fill 334 64 -353 371 64 -353 minecraft:dirt
fill 378 64 -353 391 64 -353 minecraft:dirt
fill 333 64 -352 371 64 -352 minecraft:dirt
fill 378 64 -352 391 64 -352 minecraft:dirt
fill 329 64 -351 371 64 -351 minecraft:dirt
fill 379 64 -351 391 64 -351 minecraft:dirt
fill 328 64 -350 330 64 -350 minecraft:dirt
fill 333 64 -350 371 64 -350 minecraft:dirt
fill 379 64 -350 391 64 -350 minecraft:dirt
fill 328 64 -349 329 64 -349 minecraft:dirt
fill 331 64 -349 372 64 -349 minecraft:dirt
fill 379 64 -349 391 64 -349 minecraft:dirt
fill 328 64 -348 372 64 -348 minecraft:dirt
fill 379 64 -348 391 64 -348 minecraft:dirt
fill 328 64 -347 372 64 -347 minecraft:dirt
fill 379 64 -347 391 64 -347 minecraft:dirt
fill 328 64 -346 372 64 -346 minecraft:dirt
fill 379 64 -346 391 64 -346 minecraft:dirt
fill 328 64 -345 342 64 -345 minecraft:dirt
fill 345 64 -345 372 64 -345 minecraft:dirt
fill 380 64 -345 391 64 -345 minecraft:dirt
fill 328 64 -344 339 64 -344 minecraft:dirt
fill 341 64 -344 344 64 -344 minecraft:dirt
fill 346 64 -344 373 64 -344 minecraft:dirt
fill 380 64 -344 391 64 -344 minecraft:dirt
fill 328 64 -343 333 64 -343 minecraft:dirt
fill 335 64 -343 337 64 -343 minecraft:dirt
fill 339 64 -343 340 64 -343 minecraft:dirt
fill 342 64 -343 373 64 -343 minecraft:dirt
fill 380 64 -343 391 64 -343 minecraft:dirt
fill 328 64 -342 332 64 -342 minecraft:dirt
setblock 335 64 -342 minecraft:dirt
fill 337 64 -342 373 64 -342 minecraft:dirt
fill 380 64 -342 391 64 -342 minecraft:dirt
fill 328 64 -341 338 64 -341 minecraft:dirt
fill 347 64 -341 373 64 -341 minecraft:dirt
fill 380 64 -341 391 64 -341 minecraft:dirt
fill 328 64 -340 333 64 -340 minecraft:dirt
fill 349 64 -340 373 64 -340 minecraft:dirt
fill 380 64 -340 391 64 -340 minecraft:dirt
fill 349 64 -339 373 64 -339 minecraft:dirt
fill 380 64 -339 391 64 -339 minecraft:dirt
fill 349 64 -338 373 64 -338 minecraft:dirt
fill 381 64 -338 391 64 -338 minecraft:dirt
fill 350 64 -337 373 64 -337 minecraft:dirt
fill 381 64 -337 391 64 -337 minecraft:dirt
fill 350 64 -336 373 64 -336 minecraft:dirt
fill 381 64 -336 391 64 -336 minecraft:dirt
fill 350 64 -335 373 64 -335 minecraft:dirt
fill 381 64 -335 391 64 -335 minecraft:dirt
fill 351 64 -334 378 64 -334 minecraft:dirt
fill 382 64 -334 391 64 -334 minecraft:dirt
fill 351 64 -333 365 64 -333 minecraft:dirt
fill 367 64 -333 378 64 -333 minecraft:dirt
fill 382 64 -333 391 64 -333 minecraft:dirt
fill 351 64 -332 357 64 -332 minecraft:dirt
fill 365 64 -332 378 64 -332 minecraft:dirt
fill 383 64 -332 391 64 -332 minecraft:dirt
setblock 353 64 -331 minecraft:dirt
fill 367 64 -331 378 64 -331 minecraft:dirt
fill 384 64 -331 391 64 -331 minecraft:dirt
fill 368 64 -330 378 64 -330 minecraft:dirt
fill 384 64 -330 391 64 -330 minecraft:dirt
fill 373 64 -329 378 64 -329 minecraft:dirt
fill 385 64 -329 391 64 -329 minecraft:dirt
fill 368 64 -328 370 64 -328 minecraft:dirt
fill 386 64 -328 391 64 -328 minecraft:dirt
fill 366 64 -327 377 64 -327 minecraft:dirt
fill 387 64 -327 391 64 -327 minecraft:dirt
fill 364 64 -326 376 64 -326 minecraft:dirt
fill 378 64 -326 379 64 -326 minecraft:dirt
fill 390 64 -326 391 64 -326 minecraft:dirt
fill 363 64 -325 366 64 -325 minecraft:dirt
fill 368 64 -325 386 64 -325 minecraft:dirt
setblock 362 64 -324 minecraft:dirt
fill 365 64 -324 370 64 -324 minecraft:dirt
fill 374 64 -324 388 64 -324 minecraft:dirt
fill 375 64 -323 391 64 -323 minecraft:dirt
fill 376 64 -322 387 64 -322 minecraft:dirt
fill 390 64 -322 391 64 -322 minecraft:dirt
fill 377 64 -321 386 64 -321 minecraft:dirt
fill 378 64 -320 386 64 -320 minecraft:dirt
fill 378 64 -319 386 64 -319 minecraft:dirt
fill 328 65 -382 352 65 -382 minecraft:grass_block
fill 378 65 -382 391 65 -382 minecraft:grass_block
fill 328 65 -381 352 65 -381 minecraft:grass_block
setblock 355 65 -381 minecraft:grass_block
fill 378 65 -381 391 65 -381 minecraft:grass_block
fill 328 65 -380 363 65 -380 minecraft:grass_block
fill 377 65 -380 391 65 -380 minecraft:grass_block
fill 328 65 -379 363 65 -379 minecraft:grass_block
fill 377 65 -379 391 65 -379 minecraft:grass_block
fill 328 65 -378 363 65 -378 minecraft:grass_block
fill 377 65 -378 391 65 -378 minecraft:grass_block
fill 328 65 -377 363 65 -377 minecraft:grass_block
fill 377 65 -377 391 65 -377 minecraft:grass_block
fill 328 65 -376 363 65 -376 minecraft:grass_block
fill 377 65 -376 391 65 -376 minecraft:grass_block
fill 328 65 -375 363 65 -375 minecraft:grass_block
fill 377 65 -375 391 65 -375 minecraft:grass_block
fill 328 65 -374 363 65 -374 minecraft:grass_block
fill 377 65 -374 391 65 -374 minecraft:grass_block
fill 328 65 -373 363 65 -373 minecraft:grass_block
fill 376 65 -373 391 65 -373 minecraft:grass_block
fill 328 65 -372 363 65 -372 minecraft:grass_block
fill 375 65 -372 391 65 -372 minecraft:grass_block
fill 328 65 -371 363 65 -371 minecraft:grass_block
fill 375 65 -371 391 65 -371 minecraft:grass_block
fill 328 65 -370 363 65 -370 minecraft:grass_block
fill 374 65 -370 391 65 -370 minecraft:grass_block
fill 328 65 -369 363 65 -369 minecraft:grass_block
fill 374 65 -369 391 65 -369 minecraft:grass_block
fill 328 65 -368 363 65 -368 minecraft:grass_block
fill 374 65 -368 391 65 -368 minecraft:grass_block
fill 328 65 -367 363 65 -367 minecraft:grass_block
fill 374 65 -367 391 65 -367 minecraft:grass_block
fill 328 65 -366 363 65 -366 minecraft:grass_block
fill 374 65 -366 391 65 -366 minecraft:grass_block
fill 328 65 -365 363 65 -365 minecraft:grass_block
fill 374 65 -365 391 65 -365 minecraft:grass_block
fill 328 65 -364 363 65 -364 minecraft:grass_block
fill 374 65 -364 391 65 -364 minecraft:grass_block
fill 328 65 -363 363 65 -363 minecraft:grass_block
fill 373 65 -363 391 65 -363 minecraft:grass_block
fill 328 65 -362 363 65 -362 minecraft:grass_block
fill 373 65 -362 391 65 -362 minecraft:grass_block
fill 328 65 -361 363 65 -361 minecraft:grass_block
fill 373 65 -361 391 65 -361 minecraft:grass_block
fill 328 65 -360 363 65 -360 minecraft:grass_block
fill 373 65 -360 391 65 -360 minecraft:grass_block
fill 328 65 -359 363 65 -359 minecraft:grass_block
fill 372 65 -359 391 65 -359 minecraft:grass_block
fill 328 65 -358 363 65 -358 minecraft:grass_block
fill 372 65 -358 391 65 -358 minecraft:grass_block
fill 328 65 -357 363 65 -357 minecraft:grass_block
fill 373 65 -357 391 65 -357 minecraft:grass_block
fill 328 65 -356 363 65 -356 minecraft:grass_block
fill 373 65 -356 391 65 -356 minecraft:grass_block
fill 328 65 -355 364 65 -355 minecraft:grass_block
fill 373 65 -355 391 65 -355 minecraft:grass_block
fill 328 65 -354 364 65 -354 minecraft:grass_block
fill 373 65 -354 391 65 -354 minecraft:grass_block
fill 328 65 -353 364 65 -353 minecraft:grass_block
fill 374 65 -353 391 65 -353 minecraft:grass_block
fill 328 65 -352 364 65 -352 minecraft:grass_block
fill 375 65 -352 391 65 -352 minecraft:grass_block
fill 328 65 -351 364 65 -351 minecraft:grass_block
fill 376 65 -351 391 65 -351 minecraft:grass_block
fill 328 65 -350 364 65 -350 minecraft:grass_block
fill 376 65 -350 391 65 -350 minecraft:grass_block
fill 328 65 -349 364 65 -349 minecraft:grass_block
fill 376 65 -349 391 65 -349 minecraft:grass_block
fill 328 65 -348 364 65 -348 minecraft:grass_block
fill 376 65 -348 391 65 -348 minecraft:grass_block
fill 328 65 -347 364 65 -347 minecraft:grass_block
fill 376 65 -347 391 65 -347 minecraft:grass_block
fill 328 65 -346 364 65 -346 minecraft:grass_block
fill 376 65 -346 391 65 -346 minecraft:grass_block
fill 328 65 -345 364 65 -345 minecraft:grass_block
fill 376 65 -345 391 65 -345 minecraft:grass_block
fill 328 65 -344 364 65 -344 minecraft:grass_block
fill 377 65 -344 391 65 -344 minecraft:grass_block
fill 328 65 -343 364 65 -343 minecraft:grass_block
fill 377 65 -343 391 65 -343 minecraft:grass_block
fill 328 65 -342 364 65 -342 minecraft:grass_block
fill 377 65 -342 391 65 -342 minecraft:grass_block
fill 328 65 -341 364 65 -341 minecraft:grass_block
fill 377 65 -341 391 65 -341 minecraft:grass_block
fill 328 65 -340 363 65 -340 minecraft:grass_block
fill 377 65 -340 391 65 -340 minecraft:grass_block
fill 328 65 -339 363 65 -339 minecraft:grass_block
fill 378 65 -339 391 65 -339 minecraft:grass_block
fill 328 65 -338 363 65 -338 minecraft:grass_block
fill 378 65 -338 391 65 -338 minecraft:grass_block
fill 328 65 -337 363 65 -337 minecraft:grass_block
fill 378 65 -337 391 65 -337 minecraft:grass_block
fill 328 65 -336 363 65 -336 minecraft:grass_block
fill 378 65 -336 391 65 -336 minecraft:grass_block
fill 328 65 -335 363 65 -335 minecraft:grass_block
fill 378 65 -335 391 65 -335 minecraft:grass_block
fill 328 65 -334 363 65 -334 minecraft:grass_block
fill 379 65 -334 391 65 -334 minecraft:grass_block
fill 328 65 -333 363 65 -333 minecraft:grass_block
fill 379 65 -333 391 65 -333 minecraft:grass_block
setblock 328 65 -332 minecraft:grass_block
fill 329 65 -332 334 65 -332 minecraft:light_gray_concrete
setblock 335 65 -332 minecraft:sea_lantern
fill 336 65 -332 342 65 -332 minecraft:light_gray_concrete
setblock 343 65 -332 minecraft:sea_lantern
fill 344 65 -332 350 65 -332 minecraft:light_gray_concrete
setblock 351 65 -332 minecraft:sea_lantern
fill 352 65 -332 358 65 -332 minecraft:light_gray_concrete
setblock 359 65 -332 minecraft:sea_lantern
fill 360 65 -332 366 65 -332 minecraft:light_gray_concrete
setblock 367 65 -332 minecraft:sea_lantern
fill 368 65 -332 374 65 -332 minecraft:light_gray_concrete
setblock 375 65 -332 minecraft:sea_lantern
fill 376 65 -332 382 65 -332 minecraft:light_gray_concrete
fill 383 65 -332 391 65 -332 minecraft:grass_block
setblock 328 65 -331 minecraft:light_gray_concrete
fill 329 65 -331 382 65 -331 minecraft:smooth_quartz
setblock 383 65 -331 minecraft:light_gray_concrete
fill 384 65 -331 391 65 -331 minecraft:grass_block
setblock 328 65 -330 minecraft:light_gray_concrete
fill 329 65 -330 382 65 -330 minecraft:smooth_quartz
setblock 383 65 -330 minecraft:light_gray_concrete
fill 384 65 -330 391 65 -330 minecraft:grass_block
setblock 328 65 -329 minecraft:light_gray_concrete
fill 329 65 -329 382 65 -329 minecraft:smooth_quartz
setblock 383 65 -329 minecraft:light_gray_concrete
fill 384 65 -329 391 65 -329 minecraft:grass_block
setblock 328 65 -328 minecraft:grass_block
fill 329 65 -328 334 65 -328 minecraft:light_gray_concrete
setblock 335 65 -328 minecraft:sea_lantern
fill 336 65 -328 342 65 -328 minecraft:light_gray_concrete
setblock 343 65 -328 minecraft:sea_lantern
fill 344 65 -328 350 65 -328 minecraft:light_gray_concrete
setblock 351 65 -328 minecraft:sea_lantern
fill 352 65 -328 358 65 -328 minecraft:light_gray_concrete
setblock 359 65 -328 minecraft:sea_lantern
fill 360 65 -328 366 65 -328 minecraft:light_gray_concrete
setblock 367 65 -328 minecraft:sea_lantern
fill 368 65 -328 374 65 -328 minecraft:light_gray_concrete
setblock 375 65 -328 minecraft:sea_lantern
fill 376 65 -328 378 65 -328 minecraft:light_gray_concrete
setblock 379 65 -328 minecraft:sea_lantern
fill 380 65 -328 382 65 -328 minecraft:smooth_quartz
setblock 383 65 -328 minecraft:sea_lantern
fill 384 65 -328 391 65 -328 minecraft:grass_block
fill 328 65 -327 337 65 -327 minecraft:grass_block
setblock 365 65 -327 minecraft:grass_block
setblock 379 65 -327 minecraft:light_gray_concrete
fill 380 65 -327 382 65 -327 minecraft:smooth_quartz
setblock 383 65 -327 minecraft:light_gray_concrete
fill 384 65 -327 391 65 -327 minecraft:grass_block
fill 328 65 -326 337 65 -326 minecraft:grass_block
setblock 379 65 -326 minecraft:light_gray_concrete
fill 380 65 -326 382 65 -326 minecraft:smooth_quartz
setblock 383 65 -326 minecraft:light_gray_concrete
fill 384 65 -326 391 65 -326 minecraft:grass_block
fill 328 65 -325 337 65 -325 minecraft:grass_block
setblock 379 65 -325 minecraft:light_gray_concrete
fill 380 65 -325 382 65 -325 minecraft:smooth_quartz
setblock 383 65 -325 minecraft:light_gray_concrete
fill 387 65 -325 391 65 -325 minecraft:grass_block
fill 328 65 -324 337 65 -324 minecraft:grass_block
setblock 379 65 -324 minecraft:light_gray_concrete
fill 380 65 -324 382 65 -324 minecraft:smooth_quartz
setblock 383 65 -324 minecraft:light_gray_concrete
fill 389 65 -324 391 65 -324 minecraft:grass_block
fill 328 65 -323 337 65 -323 minecraft:grass_block
setblock 379 65 -323 minecraft:light_gray_concrete
fill 380 65 -323 382 65 -323 minecraft:smooth_quartz
setblock 383 65 -323 minecraft:light_gray_concrete
fill 328 65 -322 337 65 -322 minecraft:grass_block
setblock 379 65 -322 minecraft:light_gray_concrete
fill 380 65 -322 382 65 -322 minecraft:smooth_quartz
setblock 383 65 -322 minecraft:light_gray_concrete
fill 328 65 -321 337 65 -321 minecraft:grass_block
setblock 379 65 -321 minecraft:light_gray_concrete
fill 380 65 -321 382 65 -321 minecraft:smooth_quartz
setblock 383 65 -321 minecraft:light_gray_concrete
fill 328 65 -320 337 65 -320 minecraft:grass_block
setblock 379 65 -320 minecraft:sea_lantern
fill 380 65 -320 382 65 -320 minecraft:smooth_quartz
setblock 383 65 -320 minecraft:sea_lantern
fill 328 65 -319 337 65 -319 minecraft:grass_block
setblock 379 65 -319 minecraft:light_gray_concrete
fill 380 65 -319 382 65 -319 minecraft:smooth_quartz
setblock 383 65 -319 minecraft:light_gray_concrete
setblock 347 66 -381 minecraft:air
setblock 375 66 -376 minecraft:air
setblock 336 66 -374 minecraft:air
setblock 356 66 -372 minecraft:air
setblock 330 66 -367 minecraft:air
setblock 348 66 -365 minecraft:air
setblock 368 66 -363 minecraft:air
setblock 343 66 -356 minecraft:air
setblock 360 66 -354 minecraft:air
setblock 375 66 -353 minecraft:air
setblock 333 66 -345 minecraft:air
setblock 351 66 -344 minecraft:air
setblock 367 66 -341 minecraft:air
setblock 336 66 -336 minecraft:birch_log
setblock 346 66 -336 minecraft:birch_log
setblock 356 66 -336 minecraft:birch_log
setblock 366 66 -336 minecraft:birch_log
setblock 376 66 -336 minecraft:birch_log
setblock 343 66 -335 minecraft:air
setblock 388 66 -329 minecraft:birch_log
setblock 356 66 -328 minecraft:air
setblock 331 66 -327 minecraft:air
setblock 336 66 -324 minecraft:birch_log
setblock 346 66 -324 minecraft:birch_log
setblock 356 66 -324 minecraft:birch_log
setblock 366 66 -324 minecraft:birch_log
setblock 374 66 -319 minecraft:birch_log
setblock 388 66 -319 minecraft:birch_log
setblock 336 67 -336 minecraft:birch_log
setblock 346 67 -336 minecraft:birch_log
setblock 356 67 -336 minecraft:birch_log
setblock 366 67 -336 minecraft:birch_log
setblock 376 67 -336 minecraft:birch_log
setblock 388 67 -329 minecraft:birch_log
setblock 336 67 -324 minecraft:birch_log
setblock 346 67 -324 minecraft:birch_log
setblock 356 67 -324 minecraft:birch_log
setblock 366 67 -324 minecraft:birch_log
setblock 374 67 -319 minecraft:birch_log
setblock 388 67 -319 minecraft:birch_log
setblock 336 68 -336 minecraft:birch_log
setblock 346 68 -336 minecraft:birch_log
setblock 356 68 -336 minecraft:birch_log
setblock 366 68 -336 minecraft:birch_log
setblock 376 68 -336 minecraft:birch_log
setblock 388 68 -329 minecraft:birch_log
setblock 336 68 -324 minecraft:birch_log
setblock 346 68 -324 minecraft:birch_log
setblock 356 68 -324 minecraft:birch_log
setblock 366 68 -324 minecraft:birch_log
setblock 374 68 -319 minecraft:birch_log
setblock 388 68 -319 minecraft:birch_log
setblock 336 69 -338 minecraft:birch_leaves[persistent=true]
setblock 346 69 -338 minecraft:birch_leaves[persistent=true]
setblock 356 69 -338 minecraft:birch_leaves[persistent=true]
setblock 366 69 -338 minecraft:birch_leaves[persistent=true]
setblock 376 69 -338 minecraft:birch_leaves[persistent=true]
fill 335 69 -337 337 69 -337 minecraft:birch_leaves[persistent=true]
fill 345 69 -337 347 69 -337 minecraft:birch_leaves[persistent=true]
fill 355 69 -337 357 69 -337 minecraft:birch_leaves[persistent=true]
fill 365 69 -337 367 69 -337 minecraft:birch_leaves[persistent=true]
fill 375 69 -337 377 69 -337 minecraft:birch_leaves[persistent=true]
fill 334 69 -336 335 69 -336 minecraft:birch_leaves[persistent=true]
setblock 336 69 -336 minecraft:birch_log
fill 337 69 -336 338 69 -336 minecraft:birch_leaves[persistent=true]
fill 344 69 -336 345 69 -336 minecraft:birch_leaves[persistent=true]
setblock 346 69 -336 minecraft:birch_log
fill 347 69 -336 348 69 -336 minecraft:birch_leaves[persistent=true]
fill 354 69 -336 355 69 -336 minecraft:birch_leaves[persistent=true]
setblock 356 69 -336 minecraft:birch_log
fill 357 69 -336 358 69 -336 minecraft:birch_leaves[persistent=true]
fill 364 69 -336 365 69 -336 minecraft:birch_leaves[persistent=true]
setblock 366 69 -336 minecraft:birch_log
fill 367 69 -336 368 69 -336 minecraft:birch_leaves[persistent=true]
fill 374 69 -336 375 69 -336 minecraft:birch_leaves[persistent=true]
setblock 376 69 -336 minecraft:birch_log
fill 377 69 -336 378 69 -336 minecraft:birch_leaves[persistent=true]
fill 335 69 -335 337 69 -335 minecraft:birch_leaves[persistent=true]
fill 345 69 -335 347 69 -335 minecraft:birch_leaves[persistent=true]
fill 355 69 -335 357 69 -335 minecraft:birch_leaves[persistent=true]
fill 365 69 -335 367 69 -335 minecraft:birch_leaves[persistent=true]
fill 375 69 -335 377 69 -335 minecraft:birch_leaves[persistent=true]
setblock 336 69 -334 minecraft:birch_leaves[persistent=true]
setblock 346 69 -334 minecraft:birch_leaves[persistent=true]
setblock 356 69 -334 minecraft:birch_leaves[persistent=true]
setblock 366 69 -334 minecraft:birch_leaves[persistent=true]
setblock 376 69 -334 minecraft:birch_leaves[persistent=true]
setblock 388 69 -331 minecraft:birch_leaves[persistent=true]
fill 387 69 -330 389 69 -330 minecraft:birch_leaves[persistent=true]
fill 386 69 -329 387 69 -329 minecraft:birch_leaves[persistent=true]
setblock 388 69 -329 minecraft:birch_log
fill 389 69 -329 390 69 -329 minecraft:birch_leaves[persistent=true]
fill 387 69 -328 389 69 -328 minecraft:birch_leaves[persistent=true]
setblock 388 69 -327 minecraft:birch_leaves[persistent=true]
setblock 336 69 -326 minecraft:birch_leaves[persistent=true]
setblock 346 69 -326 minecraft:birch_leaves[persistent=true]
setblock 356 69 -326 minecraft:birch_leaves[persistent=true]
setblock 366 69 -326 minecraft:birch_leaves[persistent=true]
fill 335 69 -325 337 69 -325 minecraft:birch_leaves[persistent=true]
fill 345 69 -325 347 69 -325 minecraft:birch_leaves[persistent=true]
fill 355 69 -325 357 69 -325 minecraft:birch_leaves[persistent=true]
fill 365 69 -325 367 69 -325 minecraft:birch_leaves[persistent=true]
fill 334 69 -324 335 69 -324 minecraft:birch_leaves[persistent=true]
setblock 336 69 -324 minecraft:birch_log
fill 337 69 -324 338 69 -324 minecraft:birch_leaves[persistent=true]
fill 344 69 -324 345 69 -324 minecraft:birch_leaves[persistent=true]
setblock 346 69 -324 minecraft:birch_log
fill 347 69 -324 348 69 -324 minecraft:birch_leaves[persistent=true]
fill 354 69 -324 355 69 -324 minecraft:birch_leaves[persistent=true]
setblock 356 69 -324 minecraft:birch_log
fill 357 69 -324 358 69 -324 minecraft:birch_leaves[persistent=true]
fill 364 69 -324 365 69 -324 minecraft:birch_leaves[persistent=true]
setblock 366 69 -324 minecraft:birch_log
fill 367 69 -324 368 69 -324 minecraft:birch_leaves[persistent=true]
fill 335 69 -323 337 69 -323 minecraft:birch_leaves[persistent=true]
fill 345 69 -323 347 69 -323 minecraft:birch_leaves[persistent=true]
fill 355 69 -323 357 69 -323 minecraft:birch_leaves[persistent=true]
fill 365 69 -323 367 69 -323 minecraft:birch_leaves[persistent=true]
setblock 336 69 -322 minecraft:birch_leaves[persistent=true]
setblock 346 69 -322 minecraft:birch_leaves[persistent=true]
setblock 356 69 -322 minecraft:birch_leaves[persistent=true]
setblock 366 69 -322 minecraft:birch_leaves[persistent=true]
setblock 374 69 -321 minecraft:birch_leaves[persistent=true]
setblock 388 69 -321 minecraft:birch_leaves[persistent=true]
fill 373 69 -320 375 69 -320 minecraft:birch_leaves[persistent=true]
fill 387 69 -320 389 69 -320 minecraft:birch_leaves[persistent=true]
fill 372 69 -319 373 69 -319 minecraft:birch_leaves[persistent=true]
setblock 374 69 -319 minecraft:birch_log
fill 375 69 -319 376 69 -319 minecraft:birch_leaves[persistent=true]
fill 386 69 -319 387 69 -319 minecraft:birch_leaves[persistent=true]
setblock 388 69 -319 minecraft:birch_log
fill 389 69 -319 390 69 -319 minecraft:birch_leaves[persistent=true]
fill 335 70 -338 337 70 -338 minecraft:birch_leaves[persistent=true]
fill 345 70 -338 347 70 -338 minecraft:birch_leaves[persistent=true]
fill 355 70 -338 357 70 -338 minecraft:birch_leaves[persistent=true]
fill 365 70 -338 367 70 -338 minecraft:birch_leaves[persistent=true]
fill 375 70 -338 377 70 -338 minecraft:birch_leaves[persistent=true]
fill 334 70 -337 338 70 -337 minecraft:birch_leaves[persistent=true]
fill 344 70 -337 348 70 -337 minecraft:birch_leaves[persistent=true]
fill 354 70 -337 358 70 -337 minecraft:birch_leaves[persistent=true]
fill 364 70 -337 368 70 -337 minecraft:birch_leaves[persistent=true]
fill 374 70 -337 378 70 -337 minecraft:birch_leaves[persistent=true]
fill 334 70 -336 335 70 -336 minecraft:birch_leaves[persistent=true]
setblock 336 70 -336 minecraft:birch_log
fill 337 70 -336 338 70 -336 minecraft:birch_leaves[persistent=true]
fill 344 70 -336 345 70 -336 minecraft:birch_leaves[persistent=true]
setblock 346 70 -336 minecraft:birch_log
fill 347 70 -336 348 70 -336 minecraft:birch_leaves[persistent=true]
fill 354 70 -336 355 70 -336 minecraft:birch_leaves[persistent=true]
setblock 356 70 -336 minecraft:birch_log
fill 357 70 -336 358 70 -336 minecraft:birch_leaves[persistent=true]
fill 364 70 -336 365 70 -336 minecraft:birch_leaves[persistent=true]
setblock 366 70 -336 minecraft:birch_log
fill 367 70 -336 368 70 -336 minecraft:birch_leaves[persistent=true]
fill 374 70 -336 375 70 -336 minecraft:birch_leaves[persistent=true]
setblock 376 70 -336 minecraft:birch_log
fill 377 70 -336 378 70 -336 minecraft:birch_leaves[persistent=true]
fill 334 70 -335 338 70 -335 minecraft:birch_leaves[persistent=true]
fill 344 70 -335 348 70 -335 minecraft:birch_leaves[persistent=true]
fill 354 70 -335 358 70 -335 minecraft:birch_leaves[persistent=true]
fill 364 70 -335 368 70 -335 minecraft:birch_leaves[persistent=true]
fill 374 70 -335 378 70 -335 minecraft:birch_leaves[persistent=true]
fill 335 70 -334 337 70 -334 minecraft:birch_leaves[persistent=true]
fill 345 70 -334 347 70 -334 minecraft:birch_leaves[persistent=true]
fill 355 70 -334 357 70 -334 minecraft:birch_leaves[persistent=true]
fill 365 70 -334 367 70 -334 minecraft:birch_leaves[persistent=true]
fill 375 70 -334 377 70 -334 minecraft:birch_leaves[persistent=true]
fill 387 70 -331 389 70 -331 minecraft:birch_leaves[persistent=true]
fill 386 70 -330 390 70 -330 minecraft:birch_leaves[persistent=true]
fill 386 70 -329 387 70 -329 minecraft:birch_leaves[persistent=true]
setblock 388 70 -329 minecraft:birch_log
fill 389 70 -329 390 70 -329 minecraft:birch_leaves[persistent=true]
fill 386 70 -328 390 70 -328 minecraft:birch_leaves[persistent=true]
fill 387 70 -327 389 70 -327 minecraft:birch_leaves[persistent=true]
fill 335 70 -326 337 70 -326 minecraft:birch_leaves[persistent=true]
fill 345 70 -326 347 70 -326 minecraft:birch_leaves[persistent=true]
fill 355 70 -326 357 70 -326 minecraft:birch_leaves[persistent=true]
fill 365 70 -326 367 70 -326 minecraft:birch_leaves[persistent=true]
fill 334 70 -325 338 70 -325 minecraft:birch_leaves[persistent=true]
fill 344 70 -325 348 70 -325 minecraft:birch_leaves[persistent=true]
fill 354 70 -325 358 70 -325 minecraft:birch_leaves[persistent=true]
fill 364 70 -325 368 70 -325 minecraft:birch_leaves[persistent=true]
fill 334 70 -324 335 70 -324 minecraft:birch_leaves[persistent=true]
setblock 336 70 -324 minecraft:birch_log
fill 337 70 -324 338 70 -324 minecraft:birch_leaves[persistent=true]
fill 344 70 -324 345 70 -324 minecraft:birch_leaves[persistent=true]
setblock 346 70 -324 minecraft:birch_log
fill 347 70 -324 348 70 -324 minecraft:birch_leaves[persistent=true]
fill 354 70 -324 355 70 -324 minecraft:birch_leaves[persistent=true]
setblock 356 70 -324 minecraft:birch_log
fill 357 70 -324 358 70 -324 minecraft:birch_leaves[persistent=true]
fill 364 70 -324 365 70 -324 minecraft:birch_leaves[persistent=true]
setblock 366 70 -324 minecraft:birch_log
fill 367 70 -324 368 70 -324 minecraft:birch_leaves[persistent=true]
fill 334 70 -323 338 70 -323 minecraft:birch_leaves[persistent=true]
fill 344 70 -323 348 70 -323 minecraft:birch_leaves[persistent=true]
fill 354 70 -323 358 70 -323 minecraft:birch_leaves[persistent=true]
fill 364 70 -323 368 70 -323 minecraft:birch_leaves[persistent=true]
fill 335 70 -322 337 70 -322 minecraft:birch_leaves[persistent=true]
fill 345 70 -322 347 70 -322 minecraft:birch_leaves[persistent=true]
fill 355 70 -322 357 70 -322 minecraft:birch_leaves[persistent=true]
fill 365 70 -322 367 70 -322 minecraft:birch_leaves[persistent=true]
fill 373 70 -321 375 70 -321 minecraft:birch_leaves[persistent=true]
fill 387 70 -321 389 70 -321 minecraft:birch_leaves[persistent=true]
fill 372 70 -320 376 70 -320 minecraft:birch_leaves[persistent=true]
fill 386 70 -320 390 70 -320 minecraft:birch_leaves[persistent=true]
fill 372 70 -319 373 70 -319 minecraft:birch_leaves[persistent=true]
setblock 374 70 -319 minecraft:birch_log
fill 375 70 -319 376 70 -319 minecraft:birch_leaves[persistent=true]
fill 386 70 -319 387 70 -319 minecraft:birch_leaves[persistent=true]
setblock 388 70 -319 minecraft:birch_log
fill 389 70 -319 390 70 -319 minecraft:birch_leaves[persistent=true]
setblock 336 71 -338 minecraft:birch_leaves[persistent=true]
setblock 346 71 -338 minecraft:birch_leaves[persistent=true]
setblock 356 71 -338 minecraft:birch_leaves[persistent=true]
setblock 366 71 -338 minecraft:birch_leaves[persistent=true]
setblock 376 71 -338 minecraft:birch_leaves[persistent=true]
fill 335 71 -337 337 71 -337 minecraft:birch_leaves[persistent=true]
fill 345 71 -337 347 71 -337 minecraft:birch_leaves[persistent=true]
fill 355 71 -337 357 71 -337 minecraft:birch_leaves[persistent=true]
fill 365 71 -337 367 71 -337 minecraft:birch_leaves[persistent=true]
fill 375 71 -337 377 71 -337 minecraft:birch_leaves[persistent=true]
fill 334 71 -336 338 71 -336 minecraft:birch_leaves[persistent=true]
fill 344 71 -336 348 71 -336 minecraft:birch_leaves[persistent=true]
fill 354 71 -336 358 71 -336 minecraft:birch_leaves[persistent=true]
fill 364 71 -336 368 71 -336 minecraft:birch_leaves[persistent=true]
fill 374 71 -336 378 71 -336 minecraft:birch_leaves[persistent=true]
fill 335 71 -335 337 71 -335 minecraft:birch_leaves[persistent=true]
fill 345 71 -335 347 71 -335 minecraft:birch_leaves[persistent=true]
fill 355 71 -335 357 71 -335 minecraft:birch_leaves[persistent=true]
fill 365 71 -335 367 71 -335 minecraft:birch_leaves[persistent=true]
fill 375 71 -335 377 71 -335 minecraft:birch_leaves[persistent=true]
setblock 336 71 -334 minecraft:birch_leaves[persistent=true]
setblock 346 71 -334 minecraft:birch_leaves[persistent=true]
setblock 356 71 -334 minecraft:birch_leaves[persistent=true]
setblock 366 71 -334 minecraft:birch_leaves[persistent=true]
setblock 376 71 -334 minecraft:birch_leaves[persistent=true]
setblock 388 71 -331 minecraft:birch_leaves[persistent=true]
fill 387 71 -330 389 71 -330 minecraft:birch_leaves[persistent=true]
fill 386 71 -329 390 71 -329 minecraft:birch_leaves[persistent=true]
fill 387 71 -328 389 71 -328 minecraft:birch_leaves[persistent=true]
setblock 388 71 -327 minecraft:birch_leaves[persistent=true]
setblock 336 71 -326 minecraft:birch_leaves[persistent=true]
setblock 346 71 -326 minecraft:birch_leaves[persistent=true]
setblock 356 71 -326 minecraft:birch_leaves[persistent=true]
setblock 366 71 -326 minecraft:birch_leaves[persistent=true]
fill 335 71 -325 337 71 -325 minecraft:birch_leaves[persistent=true]
fill 345 71 -325 347 71 -325 minecraft:birch_leaves[persistent=true]
fill 355 71 -325 357 71 -325 minecraft:birch_leaves[persistent=true]
fill 365 71 -325 367 71 -325 minecraft:birch_leaves[persistent=true]
fill 334 71 -324 338 71 -324 minecraft:birch_leaves[persistent=true]
fill 344 71 -324 348 71 -324 minecraft:birch_leaves[persistent=true]
fill 354 71 -324 358 71 -324 minecraft:birch_leaves[persistent=true]
fill 364 71 -324 368 71 -324 minecraft:birch_leaves[persistent=true]
fill 335 71 -323 337 71 -323 minecraft:birch_leaves[persistent=true]
fill 345 71 -323 347 71 -323 minecraft:birch_leaves[persistent=true]
fill 355 71 -323 357 71 -323 minecraft:birch_leaves[persistent=true]
fill 365 71 -323 367 71 -323 minecraft:birch_leaves[persistent=true]
setblock 336 71 -322 minecraft:birch_leaves[persistent=true]
setblock 346 71 -322 minecraft:birch_leaves[persistent=true]
setblock 356 71 -322 minecraft:birch_leaves[persistent=true]
setblock 366 71 -322 minecraft:birch_leaves[persistent=true]
setblock 374 71 -321 minecraft:birch_leaves[persistent=true]
setblock 388 71 -321 minecraft:birch_leaves[persistent=true]
fill 373 71 -320 375 71 -320 minecraft:birch_leaves[persistent=true]
fill 387 71 -320 389 71 -320 minecraft:birch_leaves[persistent=true]
fill 372 71 -319 376 71 -319 minecraft:birch_leaves[persistent=true]
fill 386 71 -319 390 71 -319 minecraft:birch_leaves[persistent=true]
setblock 336 72 -336 minecraft:birch_leaves[persistent=true]
setblock 346 72 -336 minecraft:birch_leaves[persistent=true]
setblock 356 72 -336 minecraft:birch_leaves[persistent=true]
setblock 366 72 -336 minecraft:birch_leaves[persistent=true]
setblock 376 72 -336 minecraft:birch_leaves[persistent=true]
setblock 388 72 -329 minecraft:birch_leaves[persistent=true]
setblock 336 72 -324 minecraft:birch_leaves[persistent=true]
setblock 346 72 -324 minecraft:birch_leaves[persistent=true]
setblock 356 72 -324 minecraft:birch_leaves[persistent=true]
setblock 366 72 -324 minecraft:birch_leaves[persistent=true]
setblock 374 72 -319 minecraft:birch_leaves[persistent=true]
setblock 388 72 -319 minecraft:birch_leaves[persistent=true]
forceload remove 328 -382 391 -319
tellraw @a {"text":"Campus bau a13 fertig.","color":"green"}
