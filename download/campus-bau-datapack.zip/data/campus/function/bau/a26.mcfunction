# Abschnitt a26: x 264..327, z -254..-191 (2336 Blöcke)
forceload add 264 -254 327 -191
tellraw @a {"text":"Campus bau a26: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a26_1 2s
