fill 93 45 -126 96 45 -126 minecraft:stone
fill 93 45 -125 96 45 -125 minecraft:stone
fill 93 45 -124 95 45 -124 minecraft:stone
fill 93 45 -123 95 45 -123 minecraft:stone
fill 94 45 -122 95 45 -122 minecraft:stone
fill 94 45 -121 95 45 -121 minecraft:stone
fill 94 45 -120 95 45 -120 minecraft:stone
fill 108 45 -116 111 45 -116 minecraft:stone
fill 94 46 -126 96 46 -126 minecraft:stone
fill 93 46 -125 95 46 -125 minecraft:stone
fill 93 46 -124 95 46 -124 minecraft:stone
fill 93 46 -123 95 46 -123 minecraft:stone
fill 93 46 -122 95 46 -122 minecraft:stone
fill 93 46 -121 96 46 -121 minecraft:stone
fill 94 46 -120 96 46 -120 minecraft:stone
fill 94 46 -119 96 46 -119 minecraft:stone
fill 109 46 -119 111 46 -119 minecraft:stone
fill 94 46 -118 95 46 -118 minecraft:stone
fill 108 46 -118 113 46 -118 minecraft:stone
fill 108 46 -117 113 46 -117 minecraft:stone
fill 107 46 -116 113 46 -116 minecraft:stone
setblock 94 47 -124 minecraft:stone
fill 94 47 -122 95 47 -122 minecraft:stone
fill 121 47 -122 122 47 -122 minecraft:stone
fill 93 47 -121 95 47 -121 minecraft:stone
fill 94 47 -120 96 47 -120 minecraft:stone
fill 109 47 -120 110 47 -120 minecraft:stone
setblock 112 47 -120 minecraft:stone
fill 94 47 -119 96 47 -119 minecraft:stone
fill 108 47 -119 113 47 -119 minecraft:stone
fill 94 47 -118 95 47 -118 minecraft:stone
fill 108 47 -118 114 47 -118 minecraft:stone
fill 94 47 -117 95 47 -117 minecraft:stone
fill 107 47 -117 114 47 -117 minecraft:stone
fill 94 47 -116 96 47 -116 minecraft:stone
fill 107 47 -116 114 47 -116 minecraft:stone
setblock 109 48 -121 minecraft:stone
setblock 111 48 -121 minecraft:stone
fill 121 48 -121 122 48 -121 minecraft:stone
setblock 95 48 -120 minecraft:stone
fill 108 48 -120 113 48 -120 minecraft:stone
fill 94 48 -119 95 48 -119 minecraft:stone
fill 108 48 -119 114 48 -119 minecraft:stone
fill 108 48 -118 114 48 -118 minecraft:stone
fill 94 48 -117 96 48 -117 minecraft:stone
fill 107 48 -117 114 48 -117 minecraft:stone
fill 94 48 -116 96 48 -116 minecraft:stone
fill 107 48 -116 114 48 -116 minecraft:stone
fill 109 49 -121 112 49 -121 minecraft:stone
fill 108 49 -120 113 49 -120 minecraft:stone
fill 107 49 -119 114 49 -119 minecraft:stone
fill 107 49 -118 114 49 -118 minecraft:stone
setblock 95 49 -117 minecraft:stone
fill 107 49 -117 114 49 -117 minecraft:stone
fill 94 49 -116 95 49 -116 minecraft:stone
fill 107 49 -116 114 49 -116 minecraft:stone
fill 109 50 -122 111 50 -122 minecraft:stone
fill 108 50 -121 113 50 -121 minecraft:stone
fill 107 50 -120 113 50 -120 minecraft:stone
fill 107 50 -119 114 50 -119 minecraft:stone
fill 107 50 -118 114 50 -118 minecraft:stone
fill 107 50 -117 114 50 -117 minecraft:stone
fill 108 50 -116 114 50 -116 minecraft:stone
fill 108 51 -122 112 51 -122 minecraft:stone
fill 107 51 -121 113 51 -121 minecraft:stone
fill 107 51 -120 113 51 -120 minecraft:stone
fill 107 51 -119 114 51 -119 minecraft:stone
fill 107 51 -118 114 51 -118 minecraft:stone
fill 107 51 -117 114 51 -117 minecraft:stone
fill 108 51 -116 113 51 -116 minecraft:stone
fill 109 52 -123 111 52 -123 minecraft:stone
fill 108 52 -122 112 52 -122 minecraft:stone
fill 107 52 -121 113 52 -121 minecraft:stone
fill 107 52 -120 113 52 -120 minecraft:stone
fill 107 52 -119 113 52 -119 minecraft:stone
fill 107 52 -118 113 52 -118 minecraft:stone
fill 108 52 -117 113 52 -117 minecraft:stone
fill 108 52 -116 112 52 -116 minecraft:stone
fill 109 53 -124 111 53 -124 minecraft:stone
fill 108 53 -123 111 53 -123 minecraft:stone
fill 107 53 -122 113 53 -122 minecraft:stone
fill 107 53 -121 113 53 -121 minecraft:stone
fill 119 53 -121 120 53 -121 minecraft:stone
fill 107 53 -120 113 53 -120 minecraft:stone
fill 119 53 -120 120 53 -120 minecraft:stone
fill 107 53 -119 113 53 -119 minecraft:stone
fill 107 53 -118 113 53 -118 minecraft:stone
fill 108 53 -117 113 53 -117 minecraft:stone
fill 109 53 -116 111 53 -116 minecraft:stone
fill 108 54 -124 111 54 -124 minecraft:stone
fill 107 54 -123 112 54 -123 minecraft:stone
fill 107 54 -122 113 54 -122 minecraft:stone
fill 107 54 -121 113 54 -121 minecraft:stone
fill 119 54 -121 120 54 -121 minecraft:stone
fill 107 54 -120 113 54 -120 minecraft:stone
fill 119 54 -120 120 54 -120 minecraft:stone
fill 107 54 -119 113 54 -119 minecraft:stone
fill 108 54 -118 113 54 -118 minecraft:stone
fill 108 54 -117 112 54 -117 minecraft:stone
fill 109 55 -125 110 55 -125 minecraft:stone
fill 108 55 -124 111 55 -124 minecraft:stone
fill 107 55 -123 112 55 -123 minecraft:stone
fill 107 55 -122 113 55 -122 minecraft:stone
fill 107 55 -121 113 55 -121 minecraft:stone
fill 107 55 -120 113 55 -120 minecraft:stone
fill 107 55 -119 113 55 -119 minecraft:stone
fill 108 55 -118 112 55 -118 minecraft:stone
fill 109 55 -117 111 55 -117 minecraft:stone
setblock 109 55 -116 minecraft:stone
fill 108 56 -125 111 56 -125 minecraft:stone
fill 107 56 -124 112 56 -124 minecraft:stone
fill 107 56 -123 113 56 -123 minecraft:stone
fill 107 56 -122 113 56 -122 minecraft:stone
fill 107 56 -121 113 56 -121 minecraft:stone
fill 107 56 -120 113 56 -120 minecraft:stone
fill 108 56 -119 112 56 -119 minecraft:stone
fill 109 56 -118 111 56 -118 minecraft:stone
fill 108 57 -125 111 57 -125 minecraft:stone
fill 107 57 -124 112 57 -124 minecraft:stone
fill 107 57 -123 112 57 -123 minecraft:stone
fill 107 57 -122 113 57 -122 minecraft:stone
fill 107 57 -121 113 57 -121 minecraft:stone
fill 107 57 -120 112 57 -120 minecraft:stone
fill 108 57 -119 111 57 -119 minecraft:stone
fill 109 58 -126 110 58 -126 minecraft:stone
fill 107 58 -125 111 58 -125 minecraft:stone
fill 106 58 -124 112 58 -124 minecraft:stone
fill 106 58 -123 112 58 -123 minecraft:stone
fill 106 58 -122 112 58 -122 minecraft:stone
fill 107 58 -121 112 58 -121 minecraft:stone
fill 107 58 -120 112 58 -120 minecraft:stone
fill 109 58 -119 110 58 -119 minecraft:stone
fill 108 59 -126 110 59 -126 minecraft:stone
fill 106 59 -125 111 59 -125 minecraft:stone
fill 106 59 -124 112 59 -124 minecraft:stone
fill 106 59 -123 112 59 -123 minecraft:stone
fill 106 59 -122 112 59 -122 minecraft:stone
fill 107 59 -121 112 59 -121 minecraft:stone
fill 108 59 -120 111 59 -120 minecraft:stone
fill 107 60 -126 110 60 -126 minecraft:stone
fill 106 60 -125 111 60 -125 minecraft:stone
fill 105 60 -124 112 60 -124 minecraft:stone
fill 105 60 -123 112 60 -123 minecraft:stone
fill 106 60 -122 112 60 -122 minecraft:stone
fill 106 60 -121 112 60 -121 minecraft:stone
fill 108 60 -120 111 60 -120 minecraft:stone
fill 106 61 -126 110 61 -126 minecraft:stone
fill 105 61 -125 111 61 -125 minecraft:stone
fill 104 61 -124 112 61 -124 minecraft:stone
fill 104 61 -123 112 61 -123 minecraft:stone
fill 105 61 -122 111 61 -122 minecraft:stone
fill 106 61 -121 111 61 -121 minecraft:stone
fill 108 61 -120 109 61 -120 minecraft:stone
fill 105 62 -126 109 62 -126 minecraft:dirt
fill 113 62 -126 116 62 -126 minecraft:dirt
fill 104 62 -125 112 62 -125 minecraft:dirt
fill 114 62 -125 115 62 -125 minecraft:dirt
fill 104 62 -124 112 62 -124 minecraft:dirt
fill 104 62 -123 112 62 -123 minecraft:dirt
fill 104 62 -122 112 62 -122 minecraft:dirt
fill 103 62 -121 112 62 -121 minecraft:dirt
fill 103 62 -120 112 62 -120 minecraft:dirt
fill 102 62 -119 111 62 -119 minecraft:dirt
fill 100 62 -118 110 62 -118 minecraft:dirt
fill 99 62 -117 109 62 -117 minecraft:dirt
fill 99 62 -116 108 62 -116 minecraft:dirt
fill 105 63 -126 117 63 -126 minecraft:dirt
fill 104 63 -125 116 63 -125 minecraft:dirt
fill 103 63 -124 116 63 -124 minecraft:dirt
fill 103 63 -123 115 63 -123 minecraft:dirt
fill 103 63 -122 114 63 -122 minecraft:dirt
fill 103 63 -121 113 63 -121 minecraft:dirt
fill 103 63 -120 112 63 -120 minecraft:dirt
fill 102 63 -119 111 63 -119 minecraft:dirt
fill 100 63 -118 110 63 -118 minecraft:dirt
fill 99 63 -117 109 63 -117 minecraft:dirt
fill 99 63 -116 108 63 -116 minecraft:dirt
fill 105 64 -126 127 64 -126 minecraft:dirt
fill 90 64 -125 92 64 -125 minecraft:dirt
fill 104 64 -125 117 64 -125 minecraft:dirt
fill 85 64 -124 93 64 -124 minecraft:dirt
fill 103 64 -124 116 64 -124 minecraft:dirt
fill 87 64 -123 93 64 -123 minecraft:dirt
fill 102 64 -123 115 64 -123 minecraft:dirt
fill 89 64 -122 93 64 -122 minecraft:dirt
fill 102 64 -122 114 64 -122 minecraft:dirt
fill 90 64 -121 93 64 -121 minecraft:dirt
fill 102 64 -121 113 64 -121 minecraft:dirt
fill 91 64 -120 92 64 -120 minecraft:dirt
fill 102 64 -120 112 64 -120 minecraft:dirt
fill 102 64 -119 111 64 -119 minecraft:dirt
fill 100 64 -118 110 64 -118 minecraft:dirt
fill 99 64 -117 109 64 -117 minecraft:dirt
setblock 112 64 -117 minecraft:dirt
fill 99 64 -116 108 64 -116 minecraft:dirt
fill 111 64 -116 115 64 -116 minecraft:dirt
fill 82 65 -126 85 65 -126 minecraft:grass_block
setblock 86 65 -126 minecraft:light_gray_concrete
fill 87 65 -126 89 65 -126 minecraft:smooth_quartz
setblock 90 65 -126 minecraft:light_gray_concrete
fill 91 65 -126 96 65 -126 minecraft:grass_block
fill 107 65 -126 130 65 -126 minecraft:grass_block
fill 133 65 -126 135 65 -126 minecraft:grass_block
setblock 73 65 -125 minecraft:grass_block
fill 80 65 -125 85 65 -125 minecraft:grass_block
setblock 86 65 -125 minecraft:light_gray_concrete
fill 87 65 -125 89 65 -125 minecraft:smooth_quartz
setblock 90 65 -125 minecraft:light_gray_concrete
fill 91 65 -125 96 65 -125 minecraft:grass_block
setblock 101 65 -125 minecraft:grass_block
fill 104 65 -125 129 65 -125 minecraft:grass_block
fill 134 65 -125 135 65 -125 minecraft:grass_block
fill 78 65 -124 85 65 -124 minecraft:grass_block
setblock 86 65 -124 minecraft:light_gray_concrete
fill 87 65 -124 89 65 -124 minecraft:smooth_quartz
setblock 90 65 -124 minecraft:light_gray_concrete
fill 91 65 -124 96 65 -124 minecraft:grass_block
fill 103 65 -124 116 65 -124 minecraft:grass_block
fill 134 65 -124 135 65 -124 minecraft:grass_block
fill 76 65 -123 85 65 -123 minecraft:grass_block
setblock 86 65 -123 minecraft:light_gray_concrete
fill 87 65 -123 89 65 -123 minecraft:smooth_quartz
setblock 90 65 -123 minecraft:light_gray_concrete
fill 91 65 -123 96 65 -123 minecraft:grass_block
setblock 100 65 -123 minecraft:grass_block
fill 102 65 -123 115 65 -123 minecraft:grass_block
fill 134 65 -123 135 65 -123 minecraft:grass_block
fill 74 65 -122 85 65 -122 minecraft:grass_block
setblock 86 65 -122 minecraft:light_gray_concrete
fill 87 65 -122 89 65 -122 minecraft:smooth_quartz
setblock 90 65 -122 minecraft:light_gray_concrete
fill 91 65 -122 95 65 -122 minecraft:grass_block
fill 101 65 -122 116 65 -122 minecraft:grass_block
setblock 123 65 -122 minecraft:grass_block
setblock 135 65 -122 minecraft:grass_block
fill 72 65 -121 85 65 -121 minecraft:smooth_quartz
setblock 86 65 -121 minecraft:light_gray_concrete
fill 87 65 -121 89 65 -121 minecraft:smooth_quartz
setblock 90 65 -121 minecraft:light_gray_concrete
fill 91 65 -121 135 65 -121 minecraft:smooth_quartz
fill 72 65 -120 74 65 -120 minecraft:light_gray_concrete
setblock 75 65 -120 minecraft:sea_lantern
fill 76 65 -120 83 65 -120 minecraft:light_gray_concrete
setblock 84 65 -120 minecraft:sea_lantern
setblock 85 65 -120 minecraft:light_gray_concrete
setblock 86 65 -120 minecraft:sea_lantern
fill 87 65 -120 89 65 -120 minecraft:smooth_quartz
setblock 90 65 -120 minecraft:sea_lantern
fill 91 65 -120 92 65 -120 minecraft:light_gray_concrete
setblock 93 65 -120 minecraft:sea_lantern
fill 94 65 -120 101 65 -120 minecraft:light_gray_concrete
setblock 102 65 -120 minecraft:sea_lantern
fill 103 65 -120 110 65 -120 minecraft:light_gray_concrete
setblock 111 65 -120 minecraft:sea_lantern
fill 112 65 -120 119 65 -120 minecraft:light_gray_concrete
setblock 120 65 -120 minecraft:sea_lantern
fill 121 65 -120 128 65 -120 minecraft:light_gray_concrete
setblock 129 65 -120 minecraft:sea_lantern
fill 130 65 -120 135 65 -120 minecraft:light_gray_concrete
fill 72 65 -119 73 65 -119 minecraft:light_gray_concrete
setblock 74 65 -119 minecraft:sea_lantern
fill 75 65 -119 82 65 -119 minecraft:light_gray_concrete
setblock 83 65 -119 minecraft:sea_lantern
fill 84 65 -119 85 65 -119 minecraft:light_gray_concrete
setblock 86 65 -119 minecraft:sea_lantern
fill 87 65 -119 89 65 -119 minecraft:smooth_quartz
setblock 90 65 -119 minecraft:sea_lantern
setblock 91 65 -119 minecraft:light_gray_concrete
setblock 92 65 -119 minecraft:sea_lantern
fill 93 65 -119 100 65 -119 minecraft:light_gray_concrete
setblock 101 65 -119 minecraft:sea_lantern
fill 102 65 -119 109 65 -119 minecraft:light_gray_concrete
setblock 110 65 -119 minecraft:sea_lantern
fill 111 65 -119 118 65 -119 minecraft:light_gray_concrete
setblock 119 65 -119 minecraft:sea_lantern
fill 120 65 -119 127 65 -119 minecraft:light_gray_concrete
setblock 128 65 -119 minecraft:sea_lantern
fill 129 65 -119 135 65 -119 minecraft:light_gray_concrete
setblock 72 65 -118 minecraft:light_gray_concrete
setblock 73 65 -118 minecraft:sea_lantern
fill 74 65 -118 81 65 -118 minecraft:light_gray_concrete
setblock 82 65 -118 minecraft:sea_lantern
fill 83 65 -118 86 65 -118 minecraft:light_gray_concrete
fill 87 65 -118 89 65 -118 minecraft:sea_lantern
setblock 90 65 -118 minecraft:light_gray_concrete
setblock 91 65 -118 minecraft:sea_lantern
fill 92 65 -118 99 65 -118 minecraft:light_gray_concrete
setblock 100 65 -118 minecraft:sea_lantern
fill 101 65 -118 108 65 -118 minecraft:light_gray_concrete
setblock 109 65 -118 minecraft:sea_lantern
fill 110 65 -118 117 65 -118 minecraft:light_gray_concrete
setblock 118 65 -118 minecraft:sea_lantern
fill 119 65 -118 126 65 -118 minecraft:light_gray_concrete
setblock 127 65 -118 minecraft:sea_lantern
fill 128 65 -118 135 65 -118 minecraft:light_gray_concrete
setblock 72 65 -117 minecraft:sea_lantern
fill 73 65 -117 80 65 -117 minecraft:light_gray_concrete
setblock 81 65 -117 minecraft:sea_lantern
fill 82 65 -117 89 65 -117 minecraft:light_gray_concrete
setblock 90 65 -117 minecraft:sea_lantern
fill 91 65 -117 98 65 -117 minecraft:light_gray_concrete
setblock 99 65 -117 minecraft:sea_lantern
fill 100 65 -117 107 65 -117 minecraft:light_gray_concrete
setblock 108 65 -117 minecraft:sea_lantern
fill 109 65 -117 116 65 -117 minecraft:light_gray_concrete
setblock 117 65 -117 minecraft:sea_lantern
fill 118 65 -117 125 65 -117 minecraft:light_gray_concrete
setblock 126 65 -117 minecraft:sea_lantern
fill 127 65 -117 134 65 -117 minecraft:light_gray_concrete
setblock 135 65 -117 minecraft:sea_lantern
fill 72 65 -116 135 65 -116 minecraft:light_gray_concrete
setblock 72 66 -126 minecraft:oak_log
setblock 95 66 -126 minecraft:air
setblock 112 66 -126 minecraft:oak_log
setblock 122 66 -126 minecraft:oak_log
setblock 132 66 -126 minecraft:oak_log
fill 133 66 -126 135 66 -126 minecraft:air
setblock 73 66 -125 minecraft:air
setblock 82 66 -125 minecraft:birch_log
setblock 94 66 -125 minecraft:birch_log
fill 96 66 -125 97 66 -125 minecraft:air
fill 100 66 -125 101 66 -125 minecraft:air
fill 134 66 -125 135 66 -125 minecraft:air
setblock 101 66 -124 minecraft:air
setblock 131 66 -124 minecraft:air
fill 134 66 -124 135 66 -124 minecraft:air
setblock 77 66 -123 minecraft:air
setblock 96 66 -123 minecraft:air
fill 99 66 -123 100 66 -123 minecraft:air
fill 134 66 -123 135 66 -123 minecraft:air
setblock 96 66 -122 minecraft:air
setblock 119 66 -122 minecraft:air
setblock 123 66 -122 minecraft:air
setblock 135 66 -122 minecraft:air
setblock 86 66 -121 minecraft:air
setblock 100 66 -121 minecraft:air
setblock 132 66 -121 minecraft:air
setblock 135 66 -121 minecraft:air
fill 86 66 -120 87 66 -120 minecraft:air
setblock 90 66 -120 minecraft:air
setblock 115 66 -120 minecraft:air
setblock 119 66 -120 minecraft:air
setblock 79 66 -119 minecraft:air
setblock 81 66 -119 minecraft:air
setblock 86 66 -119 minecraft:air
setblock 88 66 -119 minecraft:air
setblock 90 66 -119 minecraft:air
setblock 101 66 -119 minecraft:air
setblock 128 66 -119 minecraft:air
setblock 131 66 -119 minecraft:air
setblock 83 66 -118 minecraft:air
setblock 86 66 -118 minecraft:air
fill 88 66 -118 90 66 -118 minecraft:air
setblock 95 66 -118 minecraft:air
setblock 99 66 -118 minecraft:air
setblock 128 66 -118 minecraft:air
setblock 81 66 -117 minecraft:air
setblock 87 66 -117 minecraft:air
setblock 90 66 -117 minecraft:air
fill 109 66 -117 110 66 -117 minecraft:air
setblock 113 66 -117 minecraft:air
setblock 115 66 -117 minecraft:air
setblock 78 66 -116 minecraft:air
setblock 81 66 -116 minecraft:air
fill 85 66 -116 91 66 -116 minecraft:air
setblock 133 66 -116 minecraft:air
setblock 135 66 -116 minecraft:air
setblock 72 67 -126 minecraft:oak_log
setblock 95 67 -126 minecraft:air
setblock 111 67 -126 minecraft:air
setblock 112 67 -126 minecraft:oak_log
setblock 117 67 -126 minecraft:air
setblock 122 67 -126 minecraft:oak_log
setblock 132 67 -126 minecraft:oak_log
setblock 73 67 -125 minecraft:air
setblock 82 67 -125 minecraft:birch_log
setblock 94 67 -125 minecraft:birch_log
setblock 97 67 -125 minecraft:air
setblock 101 67 -125 minecraft:air
setblock 77 67 -123 minecraft:air
setblock 100 67 -123 minecraft:air
setblock 135 67 -123 minecraft:air
setblock 96 67 -122 minecraft:air
setblock 123 67 -122 minecraft:air
setblock 135 67 -122 minecraft:air
setblock 115 67 -120 minecraft:air
setblock 119 67 -120 minecraft:air
setblock 79 67 -119 minecraft:air
setblock 86 67 -119 minecraft:air
setblock 128 67 -119 minecraft:air
setblock 131 67 -119 minecraft:air
setblock 86 67 -118 minecraft:air
fill 89 67 -118 90 67 -118 minecraft:air
setblock 95 67 -118 minecraft:air
setblock 109 67 -117 minecraft:air
setblock 115 67 -117 minecraft:air
setblock 133 67 -116 minecraft:air
setblock 72 68 -126 minecraft:oak_log
setblock 95 68 -126 minecraft:air
setblock 111 68 -126 minecraft:air
setblock 112 68 -126 minecraft:oak_log
setblock 117 68 -126 minecraft:air
setblock 122 68 -126 minecraft:oak_log
setblock 132 68 -126 minecraft:oak_log
setblock 73 68 -125 minecraft:air
setblock 82 68 -125 minecraft:birch_log
setblock 94 68 -125 minecraft:birch_log
setblock 101 68 -125 minecraft:air
setblock 77 68 -123 minecraft:air
setblock 100 68 -123 minecraft:air
setblock 123 68 -122 minecraft:air
setblock 115 68 -120 minecraft:air
setblock 119 68 -120 minecraft:air
setblock 79 68 -119 minecraft:air
setblock 86 68 -119 minecraft:air
setblock 128 68 -119 minecraft:air
setblock 131 68 -119 minecraft:air
setblock 95 68 -118 minecraft:air
setblock 109 68 -117 minecraft:air
setblock 115 68 -117 minecraft:air
setblock 103 68 -116 minecraft:air
setblock 133 68 -116 minecraft:air
setblock 72 69 -126 minecraft:oak_log
fill 73 69 -126 74 69 -126 minecraft:oak_leaves[persistent=true]
fill 81 69 -126 83 69 -126 minecraft:birch_leaves[persistent=true]
fill 93 69 -126 95 69 -126 minecraft:birch_leaves[persistent=true]
fill 110 69 -126 111 69 -126 minecraft:oak_leaves[persistent=true]
setblock 112 69 -126 minecraft:oak_log
fill 113 69 -126 114 69 -126 minecraft:oak_leaves[persistent=true]
setblock 117 69 -126 minecraft:air
fill 120 69 -126 121 69 -126 minecraft:oak_leaves[persistent=true]
setblock 122 69 -126 minecraft:oak_log
fill 123 69 -126 124 69 -126 minecraft:oak_leaves[persistent=true]
fill 130 69 -126 131 69 -126 minecraft:oak_leaves[persistent=true]
setblock 132 69 -126 minecraft:oak_log
fill 133 69 -126 134 69 -126 minecraft:oak_leaves[persistent=true]
fill 72 69 -125 73 69 -125 minecraft:oak_leaves[persistent=true]
fill 80 69 -125 81 69 -125 minecraft:birch_leaves[persistent=true]
setblock 82 69 -125 minecraft:birch_log
fill 83 69 -125 84 69 -125 minecraft:birch_leaves[persistent=true]
fill 92 69 -125 93 69 -125 minecraft:birch_leaves[persistent=true]
setblock 94 69 -125 minecraft:birch_log
fill 95 69 -125 96 69 -125 minecraft:birch_leaves[persistent=true]
setblock 101 69 -125 minecraft:air
fill 111 69 -125 113 69 -125 minecraft:oak_leaves[persistent=true]
fill 121 69 -125 123 69 -125 minecraft:oak_leaves[persistent=true]
fill 131 69 -125 133 69 -125 minecraft:oak_leaves[persistent=true]
setblock 72 69 -124 minecraft:oak_leaves[persistent=true]
fill 81 69 -124 83 69 -124 minecraft:birch_leaves[persistent=true]
fill 93 69 -124 95 69 -124 minecraft:birch_leaves[persistent=true]
setblock 112 69 -124 minecraft:oak_leaves[persistent=true]
setblock 122 69 -124 minecraft:oak_leaves[persistent=true]
setblock 132 69 -124 minecraft:oak_leaves[persistent=true]
setblock 77 69 -123 minecraft:air
setblock 82 69 -123 minecraft:birch_leaves[persistent=true]
setblock 94 69 -123 minecraft:birch_leaves[persistent=true]
setblock 100 69 -123 minecraft:air
setblock 123 69 -122 minecraft:air
setblock 115 69 -120 minecraft:air
setblock 119 69 -120 minecraft:air
setblock 79 69 -119 minecraft:air
setblock 86 69 -119 minecraft:air
setblock 128 69 -119 minecraft:air
setblock 131 69 -119 minecraft:air
setblock 95 69 -118 minecraft:air
fill 101 69 -117 105 69 -117 minecraft:air
setblock 109 69 -117 minecraft:air
setblock 115 69 -117 minecraft:air
fill 101 69 -116 105 69 -116 minecraft:air
setblock 133 69 -116 minecraft:air
setblock 72 70 -126 minecraft:oak_log
fill 73 70 -126 74 70 -126 minecraft:oak_leaves[persistent=true]
fill 80 70 -126 84 70 -126 minecraft:birch_leaves[persistent=true]
fill 92 70 -126 96 70 -126 minecraft:birch_leaves[persistent=true]
fill 110 70 -126 111 70 -126 minecraft:oak_leaves[persistent=true]
setblock 112 70 -126 minecraft:oak_log
fill 113 70 -126 114 70 -126 minecraft:oak_leaves[persistent=true]
setblock 117 70 -126 minecraft:air
fill 120 70 -126 121 70 -126 minecraft:oak_leaves[persistent=true]
setblock 122 70 -126 minecraft:oak_log
fill 123 70 -126 124 70 -126 minecraft:oak_leaves[persistent=true]
fill 130 70 -126 131 70 -126 minecraft:oak_leaves[persistent=true]
setblock 132 70 -126 minecraft:oak_log
fill 133 70 -126 134 70 -126 minecraft:oak_leaves[persistent=true]
fill 72 70 -125 74 70 -125 minecraft:oak_leaves[persistent=true]
fill 80 70 -125 81 70 -125 minecraft:birch_leaves[persistent=true]
setblock 82 70 -125 minecraft:birch_log
fill 83 70 -125 84 70 -125 minecraft:birch_leaves[persistent=true]
fill 92 70 -125 93 70 -125 minecraft:birch_leaves[persistent=true]
setblock 94 70 -125 minecraft:birch_log
fill 95 70 -125 96 70 -125 minecraft:birch_leaves[persistent=true]
setblock 101 70 -125 minecraft:air
fill 110 70 -125 114 70 -125 minecraft:oak_leaves[persistent=true]
fill 120 70 -125 124 70 -125 minecraft:oak_leaves[persistent=true]
fill 130 70 -125 134 70 -125 minecraft:oak_leaves[persistent=true]
fill 72 70 -124 73 70 -124 minecraft:oak_leaves[persistent=true]
fill 80 70 -124 84 70 -124 minecraft:birch_leaves[persistent=true]
fill 92 70 -124 96 70 -124 minecraft:birch_leaves[persistent=true]
fill 111 70 -124 113 70 -124 minecraft:oak_leaves[persistent=true]
fill 121 70 -124 123 70 -124 minecraft:oak_leaves[persistent=true]
fill 131 70 -124 133 70 -124 minecraft:oak_leaves[persistent=true]
setblock 77 70 -123 minecraft:air
fill 81 70 -123 83 70 -123 minecraft:birch_leaves[persistent=true]
fill 93 70 -123 95 70 -123 minecraft:birch_leaves[persistent=true]
setblock 100 70 -123 minecraft:air
setblock 123 70 -122 minecraft:air
setblock 115 70 -120 minecraft:air
setblock 119 70 -120 minecraft:air
setblock 79 70 -119 minecraft:air
setblock 86 70 -119 minecraft:air
setblock 128 70 -119 minecraft:air
setblock 131 70 -119 minecraft:air
setblock 95 70 -118 minecraft:air
fill 101 70 -117 104 70 -117 minecraft:air
setblock 109 70 -117 minecraft:air
setblock 115 70 -117 minecraft:air
fill 101 70 -116 105 70 -116 minecraft:air
fill 114 70 -116 116 70 -116 minecraft:air
fill 132 70 -116 133 70 -116 minecraft:air
fill 72 71 -126 74 71 -126 minecraft:oak_leaves[persistent=true]
fill 81 71 -126 83 71 -126 minecraft:birch_leaves[persistent=true]
fill 93 71 -126 95 71 -126 minecraft:birch_leaves[persistent=true]
fill 96 71 -126 97 71 -126 minecraft:air
setblock 109 71 -126 minecraft:air
fill 110 71 -126 114 71 -126 minecraft:oak_leaves[persistent=true]
fill 115 71 -126 119 71 -126 minecraft:air
fill 120 71 -126 124 71 -126 minecraft:oak_leaves[persistent=true]
fill 130 71 -126 134 71 -126 minecraft:oak_leaves[persistent=true]
fill 72 71 -125 73 71 -125 minecraft:oak_leaves[persistent=true]
fill 80 71 -125 84 71 -125 minecraft:birch_leaves[persistent=true]
fill 92 71 -125 96 71 -125 minecraft:birch_leaves[persistent=true]
setblock 101 71 -125 minecraft:air
setblock 110 71 -125 minecraft:air
fill 111 71 -125 113 71 -125 minecraft:oak_leaves[persistent=true]
fill 116 71 -125 118 71 -125 minecraft:air
fill 121 71 -125 123 71 -125 minecraft:oak_leaves[persistent=true]
fill 131 71 -125 133 71 -125 minecraft:oak_leaves[persistent=true]
setblock 72 71 -124 minecraft:oak_leaves[persistent=true]
fill 81 71 -124 83 71 -124 minecraft:birch_leaves[persistent=true]
fill 93 71 -124 95 71 -124 minecraft:birch_leaves[persistent=true]
setblock 111 71 -124 minecraft:air
setblock 112 71 -124 minecraft:oak_leaves[persistent=true]
setblock 117 71 -124 minecraft:air
setblock 122 71 -124 minecraft:oak_leaves[persistent=true]
setblock 123 71 -124 minecraft:air
setblock 132 71 -124 minecraft:oak_leaves[persistent=true]
setblock 77 71 -123 minecraft:air
setblock 82 71 -123 minecraft:birch_leaves[persistent=true]
setblock 94 71 -123 minecraft:birch_leaves[persistent=true]
setblock 100 71 -123 minecraft:air
fill 122 71 -123 124 71 -123 minecraft:air
setblock 119 71 -122 minecraft:air
fill 121 71 -122 125 71 -122 minecraft:air
setblock 79 71 -121 minecraft:air
fill 118 71 -121 120 71 -121 minecraft:air
fill 122 71 -121 124 71 -121 minecraft:air
setblock 131 71 -121 minecraft:air
fill 78 71 -120 80 71 -120 minecraft:air
setblock 115 71 -120 minecraft:air
fill 117 71 -120 121 71 -120 minecraft:air
setblock 123 71 -120 minecraft:air
fill 130 71 -120 132 71 -120 minecraft:air
fill 77 71 -119 81 71 -119 minecraft:air
setblock 86 71 -119 minecraft:air
setblock 115 71 -119 minecraft:air
fill 118 71 -119 120 71 -119 minecraft:air
fill 128 71 -119 133 71 -119 minecraft:air
fill 78 71 -118 80 71 -118 minecraft:air
setblock 95 71 -118 minecraft:air
fill 114 71 -118 116 71 -118 minecraft:air
setblock 119 71 -118 minecraft:air
fill 130 71 -118 132 71 -118 minecraft:air
setblock 79 71 -117 minecraft:air
setblock 106 71 -117 minecraft:air
setblock 109 71 -117 minecraft:air
fill 113 71 -117 117 71 -117 minecraft:air
setblock 131 71 -117 minecraft:air
fill 102 71 -116 107 71 -116 minecraft:air
fill 114 71 -116 116 71 -116 minecraft:air
setblock 133 71 -116 minecraft:air
setblock 72 72 -126 minecraft:oak_leaves[persistent=true]
fill 94 72 -126 96 72 -126 minecraft:air
fill 110 72 -126 111 72 -126 minecraft:air
setblock 112 72 -126 minecraft:oak_leaves[persistent=true]
fill 116 72 -126 118 72 -126 minecraft:air
setblock 122 72 -126 minecraft:oak_leaves[persistent=true]
setblock 132 72 -126 minecraft:oak_leaves[persistent=true]
setblock 73 72 -125 minecraft:air
setblock 82 72 -125 minecraft:birch_leaves[persistent=true]
setblock 94 72 -125 minecraft:birch_leaves[persistent=true]
fill 95 72 -125 96 72 -125 minecraft:air
fill 100 72 -125 101 72 -125 minecraft:air
fill 110 72 -125 112 72 -125 minecraft:air
fill 116 72 -125 118 72 -125 minecraft:air
fill 99 72 -124 101 72 -124 minecraft:air
setblock 77 72 -123 minecraft:air
fill 98 72 -123 102 72 -123 minecraft:air
fill 122 72 -123 124 72 -123 minecraft:air
fill 99 72 -122 101 72 -122 minecraft:air
setblock 115 72 -122 minecraft:air
fill 122 72 -122 124 72 -122 minecraft:air
setblock 86 72 -121 minecraft:air
setblock 100 72 -121 minecraft:air
fill 114 72 -121 116 72 -121 minecraft:air
fill 118 72 -121 120 72 -121 minecraft:air
fill 122 72 -121 124 72 -121 minecraft:air
fill 78 72 -120 80 72 -120 minecraft:air
fill 85 72 -120 87 72 -120 minecraft:air
fill 113 72 -120 120 72 -120 minecraft:air
fill 130 72 -120 132 72 -120 minecraft:air
fill 78 72 -119 80 72 -119 minecraft:air
fill 84 72 -119 88 72 -119 minecraft:air
setblock 109 72 -119 minecraft:air
fill 114 72 -119 116 72 -119 minecraft:air
fill 118 72 -119 120 72 -119 minecraft:air
setblock 128 72 -119 minecraft:air
fill 130 72 -119 132 72 -119 minecraft:air
fill 78 72 -118 80 72 -118 minecraft:air
fill 85 72 -118 87 72 -118 minecraft:air
setblock 95 72 -118 minecraft:air
fill 108 72 -118 110 72 -118 minecraft:air
fill 114 72 -118 116 72 -118 minecraft:air
fill 130 72 -118 132 72 -118 minecraft:air
setblock 86 72 -117 minecraft:air
fill 107 72 -117 111 72 -117 minecraft:air
fill 114 72 -117 116 72 -117 minecraft:air
fill 103 72 -116 110 72 -116 minecraft:air
fill 114 72 -116 116 72 -116 minecraft:air
setblock 133 72 -116 minecraft:air
fill 72 73 -126 74 73 -126 minecraft:air
fill 94 73 -126 96 73 -126 minecraft:air
fill 100 73 -126 102 73 -126 minecraft:air
fill 110 73 -126 112 73 -126 minecraft:air
fill 116 73 -126 118 73 -126 minecraft:air
fill 72 73 -125 75 73 -125 minecraft:air
setblock 82 73 -125 minecraft:air
setblock 95 73 -125 minecraft:air
fill 99 73 -125 103 73 -125 minecraft:air
setblock 111 73 -125 minecraft:air
setblock 117 73 -125 minecraft:air
fill 72 73 -124 74 73 -124 minecraft:air
fill 99 73 -124 102 73 -124 minecraft:air
setblock 73 73 -123 minecraft:air
setblock 77 73 -123 minecraft:air
fill 99 73 -123 101 73 -123 minecraft:air
setblock 123 73 -123 minecraft:air
fill 99 73 -122 101 73 -122 minecraft:air
fill 122 73 -122 124 73 -122 minecraft:air
fill 114 73 -121 116 73 -121 minecraft:air
setblock 119 73 -121 minecraft:air
setblock 123 73 -121 minecraft:air
setblock 128 73 -121 minecraft:air
setblock 79 73 -120 minecraft:air
fill 85 73 -120 87 73 -120 minecraft:air
fill 114 73 -120 116 73 -120 minecraft:air
fill 118 73 -120 120 73 -120 minecraft:air
fill 127 73 -120 129 73 -120 minecraft:air
setblock 131 73 -120 minecraft:air
fill 78 73 -119 80 73 -119 minecraft:air
fill 85 73 -119 87 73 -119 minecraft:air
fill 114 73 -119 116 73 -119 minecraft:air
setblock 119 73 -119 minecraft:air
fill 126 73 -119 132 73 -119 minecraft:air
setblock 79 73 -118 minecraft:air
fill 85 73 -118 87 73 -118 minecraft:air
setblock 95 73 -118 minecraft:air
fill 108 73 -118 110 73 -118 minecraft:air
setblock 115 73 -118 minecraft:air
fill 127 73 -118 129 73 -118 minecraft:air
setblock 131 73 -118 minecraft:air
fill 108 73 -117 110 73 -117 minecraft:air
fill 114 73 -117 116 73 -117 minecraft:air
setblock 128 73 -117 minecraft:air
setblock 133 73 -117 minecraft:air
setblock 90 73 -116 minecraft:air
setblock 103 73 -116 minecraft:air
setblock 106 73 -116 minecraft:air
fill 108 73 -116 110 73 -116 minecraft:air
setblock 115 73 -116 minecraft:air
setblock 133 73 -116 minecraft:air
fill 72 74 -126 74 74 -126 minecraft:air
setblock 95 74 -126 minecraft:air
fill 100 74 -126 102 74 -126 minecraft:air
fill 110 74 -126 112 74 -126 minecraft:air
fill 117 74 -126 118 74 -126 minecraft:air
fill 72 74 -125 74 74 -125 minecraft:air
setblock 77 74 -125 minecraft:air
setblock 82 74 -125 minecraft:air
setblock 95 74 -125 minecraft:air
fill 100 74 -125 102 74 -125 minecraft:air
fill 72 74 -124 74 74 -124 minecraft:air
fill 76 74 -124 78 74 -124 minecraft:air
fill 100 74 -124 102 74 -124 minecraft:air
fill 75 74 -123 79 74 -123 minecraft:air
fill 99 74 -123 101 74 -123 minecraft:air
fill 76 74 -122 78 74 -122 minecraft:air
setblock 100 74 -122 minecraft:air
setblock 123 74 -122 minecraft:air
setblock 77 74 -121 minecraft:air
setblock 115 74 -121 minecraft:air
setblock 119 74 -121 minecraft:air
setblock 123 74 -121 minecraft:air
setblock 79 74 -120 minecraft:air
setblock 86 74 -120 minecraft:air
fill 114 74 -120 116 74 -120 minecraft:air
fill 119 74 -120 120 74 -120 minecraft:air
fill 127 74 -120 129 74 -120 minecraft:air
fill 78 74 -119 79 74 -119 minecraft:air
fill 85 74 -119 87 74 -119 minecraft:air
setblock 115 74 -119 minecraft:air
fill 127 74 -119 129 74 -119 minecraft:air
setblock 131 74 -119 minecraft:air
setblock 86 74 -118 minecraft:air
setblock 95 74 -118 minecraft:air
setblock 109 74 -118 minecraft:air
setblock 115 74 -118 minecraft:air
fill 127 74 -118 129 74 -118 minecraft:air
fill 108 74 -117 110 74 -117 minecraft:air
fill 115 74 -117 116 74 -117 minecraft:air
setblock 125 74 -117 minecraft:air
setblock 109 74 -116 minecraft:air
setblock 115 74 -116 minecraft:air
fill 124 74 -116 126 74 -116 minecraft:air
setblock 133 74 -116 minecraft:air
setblock 73 75 -126 minecraft:air
fill 81 75 -126 83 75 -126 minecraft:air
setblock 101 75 -126 minecraft:air
fill 72 75 -125 74 75 -125 minecraft:air
fill 80 75 -125 84 75 -125 minecraft:air
fill 100 75 -125 102 75 -125 minecraft:air
setblock 73 75 -124 minecraft:air
fill 76 75 -124 78 75 -124 minecraft:air
fill 81 75 -124 83 75 -124 minecraft:air
setblock 101 75 -124 minecraft:air
fill 76 75 -123 78 75 -123 minecraft:air
setblock 82 75 -123 minecraft:air
fill 100 75 -123 101 75 -123 minecraft:air
fill 76 75 -122 78 75 -122 minecraft:air
setblock 100 75 -122 minecraft:air
setblock 86 75 -120 minecraft:air
setblock 95 75 -120 minecraft:air
setblock 115 75 -120 minecraft:air
setblock 128 75 -120 minecraft:air
fill 85 75 -119 86 75 -119 minecraft:air
fill 94 75 -119 96 75 -119 minecraft:air
setblock 115 75 -119 minecraft:air
fill 127 75 -119 129 75 -119 minecraft:air
setblock 86 75 -118 minecraft:air
fill 93 75 -118 97 75 -118 minecraft:air
setblock 109 75 -118 minecraft:air
setblock 128 75 -118 minecraft:air
fill 94 75 -117 96 75 -117 minecraft:air
fill 108 75 -117 109 75 -117 minecraft:air
setblock 95 75 -116 minecraft:air
setblock 109 75 -116 minecraft:air
fill 124 75 -116 126 75 -116 minecraft:air
setblock 133 75 -116 minecraft:air
setblock 73 76 -126 minecraft:air
fill 81 76 -126 83 76 -126 minecraft:air
setblock 73 76 -125 minecraft:air
fill 81 76 -125 83 76 -125 minecraft:air
fill 100 76 -125 101 76 -125 minecraft:air
setblock 73 76 -124 minecraft:air
setblock 77 76 -124 minecraft:air
fill 81 76 -124 83 76 -124 minecraft:air
setblock 101 76 -124 minecraft:air
fill 76 76 -123 78 76 -123 minecraft:air
setblock 77 76 -122 minecraft:air
setblock 72 76 -120 minecraft:air
fill 72 76 -119 73 76 -119 minecraft:air
fill 94 76 -119 96 76 -119 minecraft:air
setblock 128 76 -119 minecraft:air
setblock 72 76 -118 minecraft:air
fill 94 76 -118 96 76 -118 minecraft:air
setblock 128 76 -118 minecraft:air
setblock 133 76 -118 minecraft:air
setblock 86 76 -117 minecraft:air
fill 94 76 -117 96 76 -117 minecraft:air
fill 132 76 -117 134 76 -117 minecraft:air
fill 85 76 -116 87 76 -116 minecraft:air
setblock 125 76 -116 minecraft:air
fill 131 76 -116 135 76 -116 minecraft:air
setblock 82 77 -126 minecraft:air
fill 81 77 -125 83 77 -125 minecraft:air
setblock 77 77 -124 minecraft:air
setblock 82 77 -124 minecraft:air
setblock 77 77 -123 minecraft:air
setblock 77 77 -122 minecraft:air
setblock 72 77 -120 minecraft:air
setblock 72 77 -119 minecraft:air
setblock 95 77 -119 minecraft:air
setblock 72 77 -118 minecraft:air
fill 94 77 -118 96 77 -118 minecraft:air
setblock 95 77 -117 minecraft:air
fill 132 77 -117 134 77 -117 minecraft:air
fill 85 77 -116 87 77 -116 minecraft:air
setblock 125 77 -116 minecraft:air
fill 132 77 -116 134 77 -116 minecraft:air
setblock 82 78 -126 minecraft:air
fill 82 78 -125 83 78 -125 minecraft:air
setblock 72 78 -119 minecraft:air
setblock 95 78 -119 minecraft:air
setblock 95 78 -118 minecraft:air
setblock 133 78 -117 minecraft:air
setblock 86 78 -116 minecraft:air
fill 132 78 -116 134 78 -116 minecraft:air
setblock 133 79 -117 minecraft:air
fill 133 79 -116 134 79 -116 minecraft:air
forceload remove 72 -126 135 -63
tellraw @a {"text":"Campus bau a37 fertig.","color":"green"}
