fill 328 45 -190 337 45 -190 minecraft:stone
fill 328 45 -189 329 45 -189 minecraft:stone
fill 332 45 -189 338 45 -189 minecraft:stone
fill 328 45 -188 329 45 -188 minecraft:stone
fill 336 45 -188 338 45 -188 minecraft:stone
fill 328 45 -187 329 45 -187 minecraft:stone
fill 336 45 -187 338 45 -187 minecraft:stone
setblock 328 45 -186 minecraft:stone
fill 336 45 -186 337 45 -186 minecraft:stone
setblock 359 45 -178 minecraft:stone
fill 358 45 -177 360 45 -177 minecraft:stone
fill 358 45 -176 360 45 -176 minecraft:stone
fill 358 45 -175 359 45 -175 minecraft:stone
fill 387 45 -136 391 45 -136 minecraft:stone
fill 387 45 -135 391 45 -135 minecraft:stone
fill 379 45 -134 384 45 -134 minecraft:stone
fill 379 45 -133 385 45 -133 minecraft:stone
fill 379 45 -132 386 45 -132 minecraft:stone
fill 383 45 -131 386 45 -131 minecraft:stone
fill 384 45 -130 386 45 -130 minecraft:stone
fill 385 45 -129 387 45 -129 minecraft:stone
fill 385 45 -128 386 45 -128 minecraft:stone
fill 385 45 -127 386 45 -127 minecraft:stone
fill 328 46 -190 329 46 -190 minecraft:stone
fill 332 46 -190 336 46 -190 minecraft:stone
fill 328 46 -189 329 46 -189 minecraft:stone
fill 334 46 -189 337 46 -189 minecraft:stone
fill 328 46 -188 329 46 -188 minecraft:stone
fill 336 46 -188 338 46 -188 minecraft:stone
fill 328 46 -187 329 46 -187 minecraft:stone
fill 336 46 -187 338 46 -187 minecraft:stone
fill 336 46 -186 337 46 -186 minecraft:stone
fill 359 46 -177 360 46 -177 minecraft:stone
fill 358 46 -176 360 46 -176 minecraft:stone
fill 358 46 -175 359 46 -175 minecraft:stone
fill 388 46 -136 391 46 -136 minecraft:stone
fill 387 46 -135 391 46 -135 minecraft:stone
setblock 387 46 -134 minecraft:stone
fill 380 46 -133 384 46 -133 minecraft:stone
fill 382 46 -132 384 46 -132 minecraft:stone
setblock 385 46 -131 minecraft:stone
fill 328 47 -190 329 47 -190 minecraft:stone
fill 336 47 -188 337 47 -188 minecraft:stone
setblock 337 47 -187 minecraft:stone
fill 359 47 -177 360 47 -177 minecraft:stone
fill 358 47 -176 360 47 -176 minecraft:stone
fill 358 47 -175 359 47 -175 minecraft:stone
fill 389 47 -136 391 47 -136 minecraft:stone
fill 387 47 -135 391 47 -135 minecraft:stone
setblock 387 47 -134 minecraft:stone
fill 359 48 -177 360 48 -177 minecraft:stone
fill 358 48 -176 360 48 -176 minecraft:stone
fill 358 48 -175 360 48 -175 minecraft:stone
setblock 391 48 -136 minecraft:stone
fill 387 48 -135 391 48 -135 minecraft:stone
setblock 388 48 -134 minecraft:stone
setblock 360 49 -178 minecraft:stone
fill 359 49 -177 360 49 -177 minecraft:stone
fill 358 49 -176 360 49 -176 minecraft:stone
fill 359 49 -175 360 49 -175 minecraft:stone
setblock 359 49 -174 minecraft:stone
setblock 343 49 -141 minecraft:stone
fill 341 49 -140 343 49 -140 minecraft:stone
fill 341 49 -139 342 49 -139 minecraft:stone
setblock 340 49 -138 minecraft:stone
setblock 332 49 -137 minecraft:stone
setblock 384 49 -137 minecraft:stone
fill 330 49 -136 333 49 -136 minecraft:stone
fill 381 49 -136 385 49 -136 minecraft:stone
fill 380 49 -135 391 49 -135 minecraft:stone
fill 380 49 -134 385 49 -134 minecraft:stone
fill 387 49 -134 388 49 -134 minecraft:stone
fill 380 49 -133 386 49 -133 minecraft:stone
fill 380 49 -132 386 49 -132 minecraft:stone
fill 380 49 -131 386 49 -131 minecraft:stone
setblock 391 49 -131 minecraft:stone
fill 381 49 -130 385 49 -130 minecraft:stone
fill 390 49 -130 391 49 -130 minecraft:stone
fill 382 49 -129 385 49 -129 minecraft:stone
fill 390 49 -129 391 49 -129 minecraft:stone
fill 383 49 -128 384 49 -128 minecraft:stone
fill 390 49 -128 391 49 -128 minecraft:stone
setblock 384 49 -127 minecraft:stone
fill 390 49 -127 391 49 -127 minecraft:stone
fill 336 50 -190 338 50 -190 minecraft:stone
setblock 391 50 -190 minecraft:stone
fill 336 50 -189 337 50 -189 minecraft:stone
setblock 391 50 -189 minecraft:stone
fill 332 50 -188 337 50 -188 minecraft:stone
setblock 391 50 -188 minecraft:stone
fill 334 50 -187 337 50 -187 minecraft:stone
setblock 336 50 -186 minecraft:stone
setblock 336 50 -185 minecraft:stone
setblock 360 50 -178 minecraft:stone
setblock 332 50 -177 minecraft:stone
fill 359 50 -177 360 50 -177 minecraft:stone
fill 332 50 -176 333 50 -176 minecraft:stone
fill 359 50 -176 361 50 -176 minecraft:stone
fill 359 50 -175 360 50 -175 minecraft:stone
setblock 359 50 -174 minecraft:stone
fill 342 50 -143 345 50 -143 minecraft:stone
fill 341 50 -142 345 50 -142 minecraft:stone
fill 340 50 -141 345 50 -141 minecraft:stone
fill 339 50 -140 345 50 -140 minecraft:stone
fill 381 50 -140 389 50 -140 minecraft:stone
fill 338 50 -139 344 50 -139 minecraft:stone
fill 380 50 -139 389 50 -139 minecraft:stone
setblock 332 50 -138 minecraft:stone
fill 338 50 -138 344 50 -138 minecraft:stone
fill 379 50 -138 390 50 -138 minecraft:stone
fill 330 50 -137 333 50 -137 minecraft:stone
fill 338 50 -137 339 50 -137 minecraft:stone
fill 341 50 -137 343 50 -137 minecraft:stone
fill 378 50 -137 390 50 -137 minecraft:stone
fill 329 50 -136 334 50 -136 minecraft:stone
fill 338 50 -136 339 50 -136 minecraft:stone
setblock 341 50 -136 minecraft:stone
fill 376 50 -136 391 50 -136 minecraft:stone
fill 330 50 -135 333 50 -135 minecraft:stone
fill 376 50 -135 391 50 -135 minecraft:stone
fill 376 50 -134 391 50 -134 minecraft:stone
fill 375 50 -133 391 50 -133 minecraft:stone
fill 375 50 -132 391 50 -132 minecraft:stone
fill 375 50 -131 391 50 -131 minecraft:stone
fill 375 50 -130 391 50 -130 minecraft:stone
fill 375 50 -129 391 50 -129 minecraft:stone
fill 375 50 -128 391 50 -128 minecraft:stone
fill 376 50 -127 391 50 -127 minecraft:stone
fill 336 51 -190 341 51 -190 minecraft:stone
fill 390 51 -190 391 51 -190 minecraft:stone
fill 335 51 -189 341 51 -189 minecraft:stone
fill 390 51 -189 391 51 -189 minecraft:stone
fill 332 51 -188 341 51 -188 minecraft:stone
fill 390 51 -188 391 51 -188 minecraft:stone
fill 332 51 -187 341 51 -187 minecraft:stone
fill 390 51 -187 391 51 -187 minecraft:stone
fill 332 51 -186 341 51 -186 minecraft:stone
setblock 391 51 -186 minecraft:stone
fill 332 51 -185 341 51 -185 minecraft:stone
setblock 391 51 -185 minecraft:stone
fill 334 51 -184 341 51 -184 minecraft:stone
setblock 391 51 -184 minecraft:stone
fill 333 51 -183 341 51 -183 minecraft:stone
fill 332 51 -182 342 51 -182 minecraft:stone
fill 332 51 -181 343 51 -181 minecraft:stone
fill 332 51 -180 345 51 -180 minecraft:stone
fill 332 51 -179 347 51 -179 minecraft:stone
fill 332 51 -178 349 51 -178 minecraft:stone
fill 360 51 -178 361 51 -178 minecraft:stone
fill 332 51 -177 350 51 -177 minecraft:stone
fill 359 51 -177 361 51 -177 minecraft:stone
fill 332 51 -176 351 51 -176 minecraft:stone
fill 359 51 -176 361 51 -176 minecraft:stone
fill 332 51 -175 352 51 -175 minecraft:stone
fill 359 51 -175 360 51 -175 minecraft:stone
fill 332 51 -174 335 51 -174 minecraft:stone
fill 337 51 -174 352 51 -174 minecraft:stone
setblock 359 51 -174 minecraft:stone
setblock 332 51 -173 minecraft:stone
fill 339 51 -173 352 51 -173 minecraft:stone
fill 339 51 -172 343 51 -172 minecraft:stone
fill 345 51 -172 352 51 -172 minecraft:stone
setblock 391 51 -168 minecraft:stone
setblock 391 51 -167 minecraft:stone
fill 390 51 -166 391 51 -166 minecraft:stone
fill 390 51 -165 391 51 -165 minecraft:stone
fill 389 51 -164 391 51 -164 minecraft:stone
fill 389 51 -163 391 51 -163 minecraft:stone
fill 389 51 -162 391 51 -162 minecraft:stone
fill 389 51 -161 391 51 -161 minecraft:stone
fill 390 51 -160 391 51 -160 minecraft:stone
fill 390 51 -159 391 51 -159 minecraft:stone
fill 390 51 -158 391 51 -158 minecraft:stone
fill 390 51 -157 391 51 -157 minecraft:stone
setblock 391 51 -156 minecraft:stone
setblock 391 51 -155 minecraft:stone
setblock 391 51 -154 minecraft:stone
setblock 391 51 -153 minecraft:stone
fill 343 51 -145 346 51 -145 minecraft:stone
fill 341 51 -144 347 51 -144 minecraft:stone
fill 341 51 -143 347 51 -143 minecraft:stone
fill 390 51 -143 391 51 -143 minecraft:stone
fill 340 51 -142 347 51 -142 minecraft:stone
fill 381 51 -142 391 51 -142 minecraft:stone
fill 339 51 -141 346 51 -141 minecraft:stone
fill 378 51 -141 391 51 -141 minecraft:stone
fill 337 51 -140 343 51 -140 minecraft:stone
fill 376 51 -140 391 51 -140 minecraft:stone
fill 336 51 -139 342 51 -139 minecraft:stone
fill 374 51 -139 391 51 -139 minecraft:stone
fill 329 51 -138 334 51 -138 minecraft:stone
fill 336 51 -138 342 51 -138 minecraft:stone
fill 368 51 -138 391 51 -138 minecraft:stone
fill 329 51 -137 339 51 -137 minecraft:stone
setblock 341 51 -137 minecraft:stone
fill 368 51 -137 391 51 -137 minecraft:stone
fill 328 51 -136 341 51 -136 minecraft:stone
fill 368 51 -136 391 51 -136 minecraft:stone
fill 329 51 -135 339 51 -135 minecraft:stone
fill 369 51 -135 391 51 -135 minecraft:stone
fill 330 51 -134 334 51 -134 minecraft:stone
setblock 339 51 -134 minecraft:stone
fill 370 51 -134 391 51 -134 minecraft:stone
fill 371 51 -133 391 51 -133 minecraft:stone
fill 371 51 -132 391 51 -132 minecraft:stone
fill 371 51 -131 391 51 -131 minecraft:stone
fill 371 51 -130 391 51 -130 minecraft:stone
fill 371 51 -129 391 51 -129 minecraft:stone
fill 371 51 -128 391 51 -128 minecraft:stone
fill 371 51 -127 391 51 -127 minecraft:stone
fill 335 52 -190 343 52 -190 minecraft:stone
fill 389 52 -190 391 52 -190 minecraft:stone
fill 334 52 -189 343 52 -189 minecraft:stone
fill 389 52 -189 391 52 -189 minecraft:stone
fill 332 52 -188 343 52 -188 minecraft:stone
fill 389 52 -188 391 52 -188 minecraft:stone
fill 332 52 -187 344 52 -187 minecraft:stone
fill 389 52 -187 391 52 -187 minecraft:stone
fill 332 52 -186 344 52 -186 minecraft:stone
fill 390 52 -186 391 52 -186 minecraft:stone
fill 332 52 -185 344 52 -185 minecraft:stone
fill 390 52 -185 391 52 -185 minecraft:stone
fill 332 52 -184 345 52 -184 minecraft:stone
fill 390 52 -184 391 52 -184 minecraft:stone
fill 332 52 -183 347 52 -183 minecraft:stone
fill 373 52 -183 376 52 -183 minecraft:stone
fill 390 52 -183 391 52 -183 minecraft:stone
fill 332 52 -182 349 52 -182 minecraft:stone
fill 373 52 -182 376 52 -182 minecraft:stone
fill 390 52 -182 391 52 -182 minecraft:stone
fill 332 52 -181 351 52 -181 minecraft:stone
fill 373 52 -181 376 52 -181 minecraft:stone
fill 390 52 -181 391 52 -181 minecraft:stone
fill 332 52 -180 352 52 -180 minecraft:stone
setblock 361 52 -180 minecraft:stone
setblock 391 52 -180 minecraft:stone
fill 332 52 -179 354 52 -179 minecraft:stone
setblock 361 52 -179 minecraft:stone
setblock 391 52 -179 minecraft:stone
fill 332 52 -178 355 52 -178 minecraft:stone
fill 360 52 -178 361 52 -178 minecraft:stone
setblock 391 52 -178 minecraft:stone
fill 332 52 -177 356 52 -177 minecraft:stone
fill 359 52 -177 361 52 -177 minecraft:stone
setblock 391 52 -177 minecraft:stone
fill 332 52 -176 356 52 -176 minecraft:stone
fill 359 52 -176 361 52 -176 minecraft:stone
setblock 391 52 -176 minecraft:stone
fill 332 52 -175 356 52 -175 minecraft:stone
setblock 360 52 -175 minecraft:stone
setblock 391 52 -175 minecraft:stone
fill 332 52 -174 356 52 -174 minecraft:stone
setblock 391 52 -174 minecraft:stone
fill 332 52 -173 355 52 -173 minecraft:stone
setblock 391 52 -173 minecraft:stone
fill 332 52 -172 355 52 -172 minecraft:stone
setblock 391 52 -172 minecraft:stone
fill 332 52 -171 333 52 -171 minecraft:stone
fill 337 52 -171 353 52 -171 minecraft:stone
fill 390 52 -171 391 52 -171 minecraft:stone
fill 390 52 -170 391 52 -170 minecraft:stone
fill 389 52 -169 391 52 -169 minecraft:stone
fill 389 52 -168 391 52 -168 minecraft:stone
fill 388 52 -167 391 52 -167 minecraft:stone
fill 387 52 -166 391 52 -166 minecraft:stone
fill 387 52 -165 391 52 -165 minecraft:stone
fill 386 52 -164 391 52 -164 minecraft:stone
fill 386 52 -163 391 52 -163 minecraft:stone
fill 386 52 -162 391 52 -162 minecraft:stone
fill 386 52 -161 391 52 -161 minecraft:stone
fill 386 52 -160 391 52 -160 minecraft:stone
fill 387 52 -159 391 52 -159 minecraft:stone
fill 388 52 -158 391 52 -158 minecraft:stone
fill 388 52 -157 391 52 -157 minecraft:stone
fill 389 52 -156 391 52 -156 minecraft:stone
fill 389 52 -155 391 52 -155 minecraft:stone
fill 389 52 -154 391 52 -154 minecraft:stone
fill 389 52 -153 391 52 -153 minecraft:stone
fill 390 52 -152 391 52 -152 minecraft:stone
fill 390 52 -151 391 52 -151 minecraft:stone
fill 390 52 -150 391 52 -150 minecraft:stone
fill 390 52 -149 391 52 -149 minecraft:stone
fill 390 52 -148 391 52 -148 minecraft:stone
fill 344 52 -147 346 52 -147 minecraft:stone
fill 389 52 -147 391 52 -147 minecraft:stone
fill 342 52 -146 347 52 -146 minecraft:stone
fill 370 52 -146 375 52 -146 minecraft:stone
fill 389 52 -146 391 52 -146 minecraft:stone
fill 342 52 -145 347 52 -145 minecraft:stone
fill 368 52 -145 379 52 -145 minecraft:stone
fill 385 52 -145 391 52 -145 minecraft:stone
fill 343 52 -144 348 52 -144 minecraft:stone
fill 366 52 -144 391 52 -144 minecraft:stone
fill 342 52 -143 347 52 -143 minecraft:stone
fill 365 52 -143 391 52 -143 minecraft:stone
fill 342 52 -142 343 52 -142 minecraft:stone
fill 365 52 -142 391 52 -142 minecraft:stone
setblock 342 52 -141 minecraft:stone
fill 364 52 -141 391 52 -141 minecraft:stone
fill 364 52 -140 391 52 -140 minecraft:stone
fill 328 52 -139 334 52 -139 minecraft:stone
setblock 340 52 -139 minecraft:stone
fill 363 52 -139 391 52 -139 minecraft:stone
fill 328 52 -138 339 52 -138 minecraft:stone
fill 363 52 -138 391 52 -138 minecraft:stone
fill 328 52 -137 340 52 -137 minecraft:stone
fill 363 52 -137 391 52 -137 minecraft:stone
fill 328 52 -136 340 52 -136 minecraft:stone
fill 363 52 -136 391 52 -136 minecraft:stone
fill 328 52 -135 339 52 -135 minecraft:stone
fill 364 52 -135 391 52 -135 minecraft:stone
fill 328 52 -134 339 52 -134 minecraft:stone
fill 364 52 -134 391 52 -134 minecraft:stone
fill 328 52 -133 334 52 -133 minecraft:stone
fill 336 52 -133 338 52 -133 minecraft:stone
fill 366 52 -133 391 52 -133 minecraft:stone
fill 328 52 -132 329 52 -132 minecraft:stone
fill 367 52 -132 391 52 -132 minecraft:stone
fill 367 52 -131 391 52 -131 minecraft:stone
fill 367 52 -130 391 52 -130 minecraft:stone
fill 367 52 -129 391 52 -129 minecraft:stone
fill 367 52 -128 391 52 -128 minecraft:stone
fill 367 52 -127 391 52 -127 minecraft:stone
fill 335 53 -190 348 53 -190 minecraft:stone
fill 387 53 -190 391 53 -190 minecraft:stone
fill 332 53 -189 348 53 -189 minecraft:stone
fill 387 53 -189 391 53 -189 minecraft:stone
fill 332 53 -188 349 53 -188 minecraft:stone
fill 388 53 -188 391 53 -188 minecraft:stone
fill 332 53 -187 349 53 -187 minecraft:stone
fill 388 53 -187 391 53 -187 minecraft:stone
fill 332 53 -186 350 53 -186 minecraft:stone
fill 388 53 -186 391 53 -186 minecraft:stone
fill 332 53 -185 351 53 -185 minecraft:stone
fill 388 53 -185 391 53 -185 minecraft:stone
fill 332 53 -184 352 53 -184 minecraft:stone
fill 375 53 -184 378 53 -184 minecraft:stone
fill 389 53 -184 391 53 -184 minecraft:stone
fill 332 53 -183 354 53 -183 minecraft:stone
fill 373 53 -183 378 53 -183 minecraft:stone
fill 389 53 -183 391 53 -183 minecraft:stone
fill 332 53 -182 356 53 -182 minecraft:stone
fill 373 53 -182 378 53 -182 minecraft:stone
fill 389 53 -182 391 53 -182 minecraft:stone
fill 332 53 -181 357 53 -181 minecraft:stone
fill 373 53 -181 376 53 -181 minecraft:stone
fill 389 53 -181 391 53 -181 minecraft:stone
fill 332 53 -180 358 53 -180 minecraft:stone
setblock 361 53 -180 minecraft:stone
fill 389 53 -180 391 53 -180 minecraft:stone
fill 332 53 -179 358 53 -179 minecraft:stone
setblock 361 53 -179 minecraft:stone
fill 389 53 -179 391 53 -179 minecraft:stone
fill 332 53 -178 361 53 -178 minecraft:stone
fill 389 53 -178 391 53 -178 minecraft:stone
fill 332 53 -177 362 53 -177 minecraft:stone
fill 389 53 -177 391 53 -177 minecraft:stone
fill 332 53 -176 361 53 -176 minecraft:stone
fill 389 53 -176 391 53 -176 minecraft:stone
fill 332 53 -175 362 53 -175 minecraft:stone
fill 389 53 -175 391 53 -175 minecraft:stone
fill 332 53 -174 362 53 -174 minecraft:stone
fill 389 53 -174 391 53 -174 minecraft:stone
fill 332 53 -173 363 53 -173 minecraft:stone
fill 389 53 -173 391 53 -173 minecraft:stone
fill 332 53 -172 364 53 -172 minecraft:stone
fill 389 53 -172 391 53 -172 minecraft:stone
fill 332 53 -171 365 53 -171 minecraft:stone
fill 388 53 -171 391 53 -171 minecraft:stone
fill 332 53 -170 355 53 -170 minecraft:stone
fill 358 53 -170 366 53 -170 minecraft:stone
fill 387 53 -170 391 53 -170 minecraft:stone
fill 339 53 -169 349 53 -169 minecraft:stone
fill 362 53 -169 367 53 -169 minecraft:stone
fill 387 53 -169 391 53 -169 minecraft:stone
fill 362 53 -168 368 53 -168 minecraft:stone
fill 386 53 -168 391 53 -168 minecraft:stone
fill 362 53 -167 370 53 -167 minecraft:stone
fill 386 53 -167 391 53 -167 minecraft:stone
fill 362 53 -166 372 53 -166 minecraft:stone
fill 385 53 -166 391 53 -166 minecraft:stone
fill 362 53 -165 372 53 -165 minecraft:stone
fill 385 53 -165 391 53 -165 minecraft:stone
fill 332 53 -164 339 53 -164 minecraft:stone
fill 343 53 -164 344 53 -164 minecraft:stone
fill 362 53 -164 373 53 -164 minecraft:stone
fill 385 53 -164 391 53 -164 minecraft:stone
fill 332 53 -163 344 53 -163 minecraft:stone
fill 362 53 -163 373 53 -163 minecraft:stone
fill 385 53 -163 391 53 -163 minecraft:stone
fill 334 53 -162 344 53 -162 minecraft:stone
fill 361 53 -162 373 53 -162 minecraft:stone
fill 385 53 -162 391 53 -162 minecraft:stone
fill 335 53 -161 345 53 -161 minecraft:stone
fill 361 53 -161 373 53 -161 minecraft:stone
fill 385 53 -161 391 53 -161 minecraft:stone
fill 336 53 -160 346 53 -160 minecraft:stone
fill 360 53 -160 373 53 -160 minecraft:stone
fill 384 53 -160 391 53 -160 minecraft:stone
fill 336 53 -159 343 53 -159 minecraft:stone
fill 360 53 -159 373 53 -159 minecraft:stone
fill 385 53 -159 391 53 -159 minecraft:stone
fill 337 53 -158 342 53 -158 minecraft:stone
fill 360 53 -158 373 53 -158 minecraft:stone
setblock 385 53 -158 minecraft:stone
fill 387 53 -158 391 53 -158 minecraft:stone
setblock 340 53 -157 minecraft:stone
fill 360 53 -157 372 53 -157 minecraft:stone
fill 387 53 -157 391 53 -157 minecraft:stone
fill 361 53 -156 372 53 -156 minecraft:stone
fill 386 53 -156 391 53 -156 minecraft:stone
fill 362 53 -155 372 53 -155 minecraft:stone
fill 386 53 -155 391 53 -155 minecraft:stone
fill 333 53 -154 336 53 -154 minecraft:stone
fill 365 53 -154 372 53 -154 minecraft:stone
fill 387 53 -154 391 53 -154 minecraft:stone
fill 332 53 -153 336 53 -153 minecraft:stone
fill 366 53 -153 373 53 -153 minecraft:stone
fill 387 53 -153 391 53 -153 minecraft:stone
fill 332 53 -152 337 53 -152 minecraft:stone
fill 367 53 -152 373 53 -152 minecraft:stone
fill 387 53 -152 391 53 -152 minecraft:stone
fill 332 53 -151 334 53 -151 minecraft:stone
fill 366 53 -151 376 53 -151 minecraft:stone
fill 387 53 -151 391 53 -151 minecraft:stone
fill 365 53 -150 378 53 -150 minecraft:stone
fill 386 53 -150 391 53 -150 minecraft:stone
fill 365 53 -149 380 53 -149 minecraft:stone
fill 386 53 -149 391 53 -149 minecraft:stone
fill 342 53 -148 347 53 -148 minecraft:stone
fill 365 53 -148 391 53 -148 minecraft:stone
fill 343 53 -147 347 53 -147 minecraft:stone
fill 363 53 -147 391 53 -147 minecraft:stone
fill 343 53 -146 348 53 -146 minecraft:stone
fill 363 53 -146 391 53 -146 minecraft:stone
fill 344 53 -145 348 53 -145 minecraft:stone
fill 362 53 -145 391 53 -145 minecraft:stone
fill 332 53 -144 333 53 -144 minecraft:stone
fill 362 53 -144 391 53 -144 minecraft:stone
fill 361 53 -143 391 53 -143 minecraft:stone
fill 361 53 -142 391 53 -142 minecraft:stone
setblock 328 53 -141 minecraft:stone
fill 360 53 -141 391 53 -141 minecraft:stone
setblock 328 53 -140 minecraft:stone
setblock 336 53 -140 minecraft:stone
fill 360 53 -140 391 53 -140 minecraft:stone
fill 328 53 -139 337 53 -139 minecraft:stone
fill 360 53 -139 391 53 -139 minecraft:stone
fill 328 53 -138 338 53 -138 minecraft:stone
fill 360 53 -138 391 53 -138 minecraft:stone
fill 328 53 -137 340 53 -137 minecraft:stone
fill 360 53 -137 391 53 -137 minecraft:stone
fill 328 53 -136 340 53 -136 minecraft:stone
fill 360 53 -136 391 53 -136 minecraft:stone
fill 328 53 -135 341 53 -135 minecraft:stone
fill 360 53 -135 391 53 -135 minecraft:stone
fill 328 53 -134 340 53 -134 minecraft:stone
fill 360 53 -134 391 53 -134 minecraft:stone
fill 328 53 -133 339 53 -133 minecraft:stone
fill 360 53 -133 391 53 -133 minecraft:stone
fill 328 53 -132 338 53 -132 minecraft:stone
fill 360 53 -132 391 53 -132 minecraft:stone
fill 328 53 -131 332 53 -131 minecraft:stone
setblock 338 53 -131 minecraft:stone
fill 359 53 -131 391 53 -131 minecraft:stone
fill 328 53 -130 329 53 -130 minecraft:stone
fill 358 53 -130 391 53 -130 minecraft:stone
fill 353 53 -129 391 53 -129 minecraft:stone
fill 351 53 -128 391 53 -128 minecraft:stone
fill 351 53 -127 391 53 -127 minecraft:stone
fill 333 54 -190 355 54 -190 minecraft:stone
fill 386 54 -190 391 54 -190 minecraft:stone
fill 332 54 -189 355 54 -189 minecraft:stone
fill 386 54 -189 391 54 -189 minecraft:stone
fill 332 54 -188 354 54 -188 minecraft:stone
fill 386 54 -188 391 54 -188 minecraft:stone
fill 332 54 -187 355 54 -187 minecraft:stone
fill 386 54 -187 391 54 -187 minecraft:stone
fill 332 54 -186 357 54 -186 minecraft:stone
fill 386 54 -186 391 54 -186 minecraft:stone
fill 332 54 -185 359 54 -185 minecraft:stone
fill 386 54 -185 391 54 -185 minecraft:stone
fill 332 54 -184 361 54 -184 minecraft:stone
fill 375 54 -184 379 54 -184 minecraft:stone
fill 386 54 -184 391 54 -184 minecraft:stone
fill 332 54 -183 363 54 -183 minecraft:stone
fill 375 54 -183 380 54 -183 minecraft:stone
fill 386 54 -183 391 54 -183 minecraft:stone
fill 332 54 -182 363 54 -182 minecraft:stone
fill 374 54 -182 380 54 -182 minecraft:stone
fill 386 54 -182 391 54 -182 minecraft:stone
fill 332 54 -181 363 54 -181 minecraft:stone
fill 376 54 -181 379 54 -181 minecraft:stone
fill 387 54 -181 391 54 -181 minecraft:stone
fill 332 54 -180 363 54 -180 minecraft:stone
fill 387 54 -180 391 54 -180 minecraft:stone
fill 332 54 -179 366 54 -179 minecraft:stone
fill 387 54 -179 391 54 -179 minecraft:stone
fill 332 54 -178 367 54 -178 minecraft:stone
fill 386 54 -178 391 54 -178 minecraft:stone
fill 332 54 -177 368 54 -177 minecraft:stone
fill 386 54 -177 391 54 -177 minecraft:stone
fill 332 54 -176 368 54 -176 minecraft:stone
fill 386 54 -176 391 54 -176 minecraft:stone
fill 332 54 -175 369 54 -175 minecraft:stone
fill 386 54 -175 391 54 -175 minecraft:stone
fill 332 54 -174 370 54 -174 minecraft:stone
fill 385 54 -174 391 54 -174 minecraft:stone
fill 332 54 -173 370 54 -173 minecraft:stone
fill 385 54 -173 391 54 -173 minecraft:stone
fill 332 54 -172 371 54 -172 minecraft:stone
fill 385 54 -172 391 54 -172 minecraft:stone
fill 332 54 -171 372 54 -171 minecraft:stone
fill 385 54 -171 391 54 -171 minecraft:stone
fill 332 54 -170 373 54 -170 minecraft:stone
fill 385 54 -170 391 54 -170 minecraft:stone
fill 332 54 -169 373 54 -169 minecraft:stone
fill 385 54 -169 391 54 -169 minecraft:stone
fill 337 54 -168 374 54 -168 minecraft:stone
fill 385 54 -168 391 54 -168 minecraft:stone
fill 335 54 -167 374 54 -167 minecraft:stone
fill 384 54 -167 391 54 -167 minecraft:stone
fill 332 54 -166 375 54 -166 minecraft:stone
fill 384 54 -166 391 54 -166 minecraft:stone
fill 332 54 -165 375 54 -165 minecraft:stone
fill 383 54 -165 391 54 -165 minecraft:stone
fill 332 54 -164 375 54 -164 minecraft:stone
fill 382 54 -164 391 54 -164 minecraft:stone
fill 332 54 -163 376 54 -163 minecraft:stone
fill 382 54 -163 391 54 -163 minecraft:stone
fill 332 54 -162 378 54 -162 minecraft:stone
fill 381 54 -162 391 54 -162 minecraft:stone
fill 332 54 -161 391 54 -161 minecraft:stone
fill 332 54 -160 391 54 -160 minecraft:stone
fill 332 54 -159 376 54 -159 minecraft:stone
setblock 379 54 -159 minecraft:stone
fill 381 54 -159 391 54 -159 minecraft:stone
fill 332 54 -158 378 54 -158 minecraft:stone
setblock 382 54 -158 minecraft:stone
fill 385 54 -158 391 54 -158 minecraft:stone
fill 332 54 -157 377 54 -157 minecraft:stone
fill 385 54 -157 391 54 -157 minecraft:stone
fill 329 54 -156 377 54 -156 minecraft:stone
fill 384 54 -156 391 54 -156 minecraft:stone
fill 329 54 -155 378 54 -155 minecraft:stone
setblock 383 54 -155 minecraft:stone
fill 386 54 -155 391 54 -155 minecraft:stone
fill 329 54 -154 379 54 -154 minecraft:stone
setblock 382 54 -154 minecraft:stone
fill 387 54 -154 391 54 -154 minecraft:stone
fill 329 54 -153 346 54 -153 minecraft:stone
fill 351 54 -153 391 54 -153 minecraft:stone
fill 329 54 -152 344 54 -152 minecraft:stone
fill 353 54 -152 380 54 -152 minecraft:stone
fill 382 54 -152 391 54 -152 minecraft:stone
fill 330 54 -151 344 54 -151 minecraft:stone
fill 354 54 -151 380 54 -151 minecraft:stone
fill 382 54 -151 391 54 -151 minecraft:stone
fill 330 54 -150 346 54 -150 minecraft:stone
fill 355 54 -150 391 54 -150 minecraft:stone
fill 331 54 -149 347 54 -149 minecraft:stone
fill 356 54 -149 391 54 -149 minecraft:stone
fill 332 54 -148 348 54 -148 minecraft:stone
fill 357 54 -148 391 54 -148 minecraft:stone
fill 331 54 -147 348 54 -147 minecraft:stone
fill 357 54 -147 391 54 -147 minecraft:stone
fill 330 54 -146 346 54 -146 minecraft:stone
fill 357 54 -146 391 54 -146 minecraft:stone
fill 328 54 -145 343 54 -145 minecraft:stone
fill 357 54 -145 391 54 -145 minecraft:stone
fill 328 54 -144 343 54 -144 minecraft:stone
fill 357 54 -144 391 54 -144 minecraft:stone
fill 328 54 -143 344 54 -143 minecraft:stone
fill 357 54 -143 391 54 -143 minecraft:stone
fill 328 54 -142 345 54 -142 minecraft:stone
fill 357 54 -142 391 54 -142 minecraft:stone
fill 328 54 -141 330 54 -141 minecraft:stone
fill 333 54 -141 346 54 -141 minecraft:stone
fill 357 54 -141 391 54 -141 minecraft:stone
fill 328 54 -140 330 54 -140 minecraft:stone
fill 334 54 -140 347 54 -140 minecraft:stone
fill 357 54 -140 391 54 -140 minecraft:stone
fill 328 54 -139 348 54 -139 minecraft:stone
fill 357 54 -139 391 54 -139 minecraft:stone
fill 328 54 -138 349 54 -138 minecraft:stone
fill 357 54 -138 391 54 -138 minecraft:stone
fill 328 54 -137 349 54 -137 minecraft:stone
fill 357 54 -137 391 54 -137 minecraft:stone
fill 328 54 -136 350 54 -136 minecraft:stone
fill 357 54 -136 391 54 -136 minecraft:stone
fill 328 54 -135 350 54 -135 minecraft:stone
fill 355 54 -135 391 54 -135 minecraft:stone
fill 328 54 -134 391 54 -134 minecraft:stone
fill 328 54 -133 391 54 -133 minecraft:stone
fill 328 54 -132 341 54 -132 minecraft:stone
fill 349 54 -132 391 54 -132 minecraft:stone
fill 328 54 -131 337 54 -131 minecraft:stone
fill 348 54 -131 391 54 -131 minecraft:stone
fill 328 54 -130 334 54 -130 minecraft:stone
fill 336 54 -130 337 54 -130 minecraft:stone
fill 348 54 -130 391 54 -130 minecraft:stone
fill 328 54 -129 330 54 -129 minecraft:stone
fill 347 54 -129 391 54 -129 minecraft:stone
fill 347 54 -128 391 54 -128 minecraft:stone
fill 338 54 -127 341 54 -127 minecraft:stone
fill 347 54 -127 391 54 -127 minecraft:stone
fill 332 55 -190 382 55 -190 minecraft:stone
fill 385 55 -190 391 55 -190 minecraft:stone
fill 332 55 -189 391 55 -189 minecraft:stone
fill 332 55 -188 391 55 -188 minecraft:stone
fill 332 55 -187 391 55 -187 minecraft:stone
fill 332 55 -186 391 55 -186 minecraft:stone
fill 332 55 -185 391 55 -185 minecraft:stone
fill 332 55 -184 391 55 -184 minecraft:stone
fill 332 55 -183 391 55 -183 minecraft:stone
fill 332 55 -182 391 55 -182 minecraft:stone
fill 332 55 -181 383 55 -181 minecraft:stone
fill 385 55 -181 391 55 -181 minecraft:stone
fill 332 55 -180 382 55 -180 minecraft:stone
fill 385 55 -180 391 55 -180 minecraft:stone
fill 332 55 -179 383 55 -179 minecraft:stone
fill 385 55 -179 391 55 -179 minecraft:stone
fill 332 55 -178 391 55 -178 minecraft:stone
fill 332 55 -177 391 55 -177 minecraft:stone
fill 332 55 -176 391 55 -176 minecraft:stone
fill 332 55 -175 391 55 -175 minecraft:stone
fill 332 55 -174 391 55 -174 minecraft:stone
fill 331 55 -173 391 55 -173 minecraft:stone
fill 331 55 -172 391 55 -172 minecraft:stone
fill 331 55 -171 391 55 -171 minecraft:stone
fill 332 55 -170 379 55 -170 minecraft:stone
fill 381 55 -170 391 55 -170 minecraft:stone
fill 332 55 -169 379 55 -169 minecraft:stone
fill 381 55 -169 391 55 -169 minecraft:stone
fill 332 55 -168 379 55 -168 minecraft:stone
fill 381 55 -168 391 55 -168 minecraft:stone
fill 332 55 -167 391 55 -167 minecraft:stone
fill 332 55 -166 391 55 -166 minecraft:stone
fill 332 55 -165 391 55 -165 minecraft:stone
fill 332 55 -164 391 55 -164 minecraft:stone
fill 332 55 -163 391 55 -163 minecraft:stone
fill 332 55 -162 391 55 -162 minecraft:stone
fill 332 55 -161 391 55 -161 minecraft:stone
fill 332 55 -160 391 55 -160 minecraft:stone
fill 332 55 -159 391 55 -159 minecraft:stone
fill 332 55 -158 391 55 -158 minecraft:stone
fill 331 55 -157 391 55 -157 minecraft:stone
fill 328 55 -156 378 55 -156 minecraft:stone
fill 381 55 -156 391 55 -156 minecraft:stone
fill 328 55 -155 391 55 -155 minecraft:stone
fill 328 55 -154 379 55 -154 minecraft:stone
fill 382 55 -154 391 55 -154 minecraft:stone
fill 328 55 -153 391 55 -153 minecraft:stone
fill 328 55 -152 391 55 -152 minecraft:stone
fill 328 55 -151 391 55 -151 minecraft:stone
fill 328 55 -150 391 55 -150 minecraft:stone
fill 328 55 -149 391 55 -149 minecraft:stone
fill 328 55 -148 391 55 -148 minecraft:stone
fill 328 55 -147 391 55 -147 minecraft:stone
fill 328 55 -146 391 55 -146 minecraft:stone
fill 328 55 -145 391 55 -145 minecraft:stone
fill 328 55 -144 391 55 -144 minecraft:stone
fill 328 55 -143 391 55 -143 minecraft:stone
fill 328 55 -142 391 55 -142 minecraft:stone
fill 328 55 -141 391 55 -141 minecraft:stone
fill 328 55 -140 391 55 -140 minecraft:stone
fill 328 55 -139 391 55 -139 minecraft:stone
fill 328 55 -138 391 55 -138 minecraft:stone
fill 328 55 -137 391 55 -137 minecraft:stone
fill 328 55 -136 391 55 -136 minecraft:stone
fill 328 55 -135 391 55 -135 minecraft:stone
fill 328 55 -134 391 55 -134 minecraft:stone
fill 328 55 -133 391 55 -133 minecraft:stone
fill 328 55 -132 391 55 -132 minecraft:stone
fill 328 55 -131 391 55 -131 minecraft:stone
fill 328 55 -130 391 55 -130 minecraft:stone
fill 328 55 -129 336 55 -129 minecraft:stone
fill 341 55 -129 391 55 -129 minecraft:stone
fill 328 55 -128 330 55 -128 minecraft:stone
setblock 337 55 -128 minecraft:stone
fill 344 55 -128 391 55 -128 minecraft:stone
fill 328 55 -127 331 55 -127 minecraft:stone
fill 333 55 -127 391 55 -127 minecraft:stone
fill 332 56 -190 391 56 -190 minecraft:stone
fill 332 56 -189 391 56 -189 minecraft:stone
fill 332 56 -188 391 56 -188 minecraft:stone
fill 332 56 -187 391 56 -187 minecraft:stone
fill 332 56 -186 391 56 -186 minecraft:stone
fill 332 56 -185 391 56 -185 minecraft:stone
fill 332 56 -184 391 56 -184 minecraft:stone
fill 332 56 -183 391 56 -183 minecraft:stone
fill 332 56 -182 391 56 -182 minecraft:stone
fill 332 56 -181 391 56 -181 minecraft:stone
fill 332 56 -180 391 56 -180 minecraft:stone
fill 332 56 -179 391 56 -179 minecraft:stone
fill 332 56 -178 391 56 -178 minecraft:stone
fill 332 56 -177 391 56 -177 minecraft:stone
fill 332 56 -176 391 56 -176 minecraft:stone
fill 332 56 -175 391 56 -175 minecraft:stone
fill 331 56 -174 391 56 -174 minecraft:stone
fill 331 56 -173 391 56 -173 minecraft:stone
fill 330 56 -172 391 56 -172 minecraft:stone
fill 330 56 -171 391 56 -171 minecraft:stone
fill 331 56 -170 391 56 -170 minecraft:stone
fill 331 56 -169 391 56 -169 minecraft:stone
fill 332 56 -168 391 56 -168 minecraft:stone
fill 332 56 -167 391 56 -167 minecraft:stone
fill 332 56 -166 391 56 -166 minecraft:stone
fill 332 56 -165 391 56 -165 minecraft:stone
fill 332 56 -164 391 56 -164 minecraft:stone
fill 332 56 -163 391 56 -163 minecraft:stone
fill 332 56 -162 391 56 -162 minecraft:stone
fill 332 56 -161 391 56 -161 minecraft:stone
fill 332 56 -160 391 56 -160 minecraft:stone
fill 331 56 -159 391 56 -159 minecraft:stone
fill 331 56 -158 391 56 -158 minecraft:stone
fill 329 56 -157 391 56 -157 minecraft:stone
fill 328 56 -156 391 56 -156 minecraft:stone
fill 328 56 -155 391 56 -155 minecraft:stone
fill 328 56 -154 391 56 -154 minecraft:stone
fill 328 56 -153 391 56 -153 minecraft:stone
fill 328 56 -152 391 56 -152 minecraft:stone
fill 328 56 -151 391 56 -151 minecraft:stone
fill 328 56 -150 391 56 -150 minecraft:stone
fill 328 56 -149 391 56 -149 minecraft:stone
fill 328 56 -148 391 56 -148 minecraft:stone
fill 328 56 -147 391 56 -147 minecraft:stone
fill 328 56 -146 391 56 -146 minecraft:stone
fill 328 56 -145 391 56 -145 minecraft:stone
fill 328 56 -144 391 56 -144 minecraft:stone
fill 328 56 -143 391 56 -143 minecraft:stone
fill 328 56 -142 391 56 -142 minecraft:stone
fill 328 56 -141 391 56 -141 minecraft:stone
fill 328 56 -140 391 56 -140 minecraft:stone
fill 328 56 -139 391 56 -139 minecraft:stone
fill 328 56 -138 391 56 -138 minecraft:stone
fill 328 56 -137 391 56 -137 minecraft:stone
fill 328 56 -136 391 56 -136 minecraft:stone
fill 328 56 -135 391 56 -135 minecraft:stone
fill 328 56 -134 391 56 -134 minecraft:stone
fill 328 56 -133 391 56 -133 minecraft:stone
fill 328 56 -132 391 56 -132 minecraft:stone
fill 328 56 -131 391 56 -131 minecraft:stone
fill 328 56 -130 391 56 -130 minecraft:stone
fill 328 56 -129 391 56 -129 minecraft:stone
fill 328 56 -128 391 56 -128 minecraft:stone
fill 328 56 -127 391 56 -127 minecraft:stone
fill 332 57 -190 391 57 -190 minecraft:stone
fill 332 57 -189 391 57 -189 minecraft:stone
fill 332 57 -188 391 57 -188 minecraft:stone
fill 332 57 -187 391 57 -187 minecraft:stone
fill 332 57 -186 391 57 -186 minecraft:stone
fill 332 57 -185 391 57 -185 minecraft:stone
fill 332 57 -184 391 57 -184 minecraft:stone
fill 332 57 -183 391 57 -183 minecraft:stone
fill 332 57 -182 391 57 -182 minecraft:stone
fill 332 57 -181 391 57 -181 minecraft:stone
fill 332 57 -180 391 57 -180 minecraft:stone
fill 332 57 -179 391 57 -179 minecraft:stone
fill 332 57 -178 391 57 -178 minecraft:stone
fill 332 57 -177 391 57 -177 minecraft:stone
fill 332 57 -176 391 57 -176 minecraft:stone
fill 331 57 -175 391 57 -175 minecraft:stone
fill 331 57 -174 391 57 -174 minecraft:stone
fill 331 57 -173 391 57 -173 minecraft:stone
fill 329 57 -172 391 57 -172 minecraft:stone
fill 330 57 -171 391 57 -171 minecraft:stone
fill 330 57 -170 391 57 -170 minecraft:stone
fill 331 57 -169 391 57 -169 minecraft:stone
fill 331 57 -168 391 57 -168 minecraft:stone
fill 332 57 -167 391 57 -167 minecraft:stone
fill 332 57 -166 391 57 -166 minecraft:stone
fill 332 57 -165 391 57 -165 minecraft:stone
fill 332 57 -164 391 57 -164 minecraft:stone
fill 332 57 -163 391 57 -163 minecraft:stone
fill 332 57 -162 391 57 -162 minecraft:stone
fill 332 57 -161 391 57 -161 minecraft:stone
fill 331 57 -160 391 57 -160 minecraft:stone
fill 331 57 -159 391 57 -159 minecraft:stone
fill 330 57 -158 391 57 -158 minecraft:stone
fill 328 57 -157 391 57 -157 minecraft:stone
fill 328 57 -156 391 57 -156 minecraft:stone
fill 328 57 -155 391 57 -155 minecraft:stone
fill 328 57 -154 391 57 -154 minecraft:stone
fill 328 57 -153 391 57 -153 minecraft:stone
fill 328 57 -152 391 57 -152 minecraft:stone
fill 328 57 -151 391 57 -151 minecraft:stone
fill 328 57 -150 391 57 -150 minecraft:stone
fill 328 57 -149 391 57 -149 minecraft:stone
fill 328 57 -148 391 57 -148 minecraft:stone
fill 328 57 -147 391 57 -147 minecraft:stone
fill 328 57 -146 391 57 -146 minecraft:stone
fill 328 57 -145 391 57 -145 minecraft:stone
fill 328 57 -144 391 57 -144 minecraft:stone
fill 328 57 -143 391 57 -143 minecraft:stone
fill 328 57 -142 391 57 -142 minecraft:stone
fill 328 57 -141 391 57 -141 minecraft:stone
fill 328 57 -140 391 57 -140 minecraft:stone
fill 328 57 -139 391 57 -139 minecraft:stone
fill 328 57 -138 391 57 -138 minecraft:stone
fill 328 57 -137 391 57 -137 minecraft:stone
fill 328 57 -136 391 57 -136 minecraft:stone
fill 328 57 -135 391 57 -135 minecraft:stone
fill 328 57 -134 391 57 -134 minecraft:stone
fill 328 57 -133 391 57 -133 minecraft:stone
fill 328 57 -132 391 57 -132 minecraft:stone
fill 328 57 -131 391 57 -131 minecraft:stone
fill 328 57 -130 391 57 -130 minecraft:stone
fill 328 57 -129 391 57 -129 minecraft:stone
fill 328 57 -128 391 57 -128 minecraft:stone
fill 328 57 -127 391 57 -127 minecraft:stone
fill 332 58 -190 391 58 -190 minecraft:stone
fill 332 58 -189 391 58 -189 minecraft:stone
fill 331 58 -188 391 58 -188 minecraft:stone
fill 331 58 -187 391 58 -187 minecraft:stone
fill 331 58 -186 391 58 -186 minecraft:stone
fill 331 58 -185 391 58 -185 minecraft:stone
fill 331 58 -184 391 58 -184 minecraft:stone
fill 331 58 -183 391 58 -183 minecraft:stone
fill 331 58 -182 391 58 -182 minecraft:stone
fill 331 58 -181 391 58 -181 minecraft:stone
fill 331 58 -180 391 58 -180 minecraft:stone
fill 331 58 -179 391 58 -179 minecraft:stone
fill 331 58 -178 391 58 -178 minecraft:stone
fill 331 58 -177 391 58 -177 minecraft:stone
fill 331 58 -176 391 58 -176 minecraft:stone
fill 331 58 -175 391 58 -175 minecraft:stone
fill 331 58 -174 391 58 -174 minecraft:stone
fill 330 58 -173 391 58 -173 minecraft:stone
fill 329 58 -172 391 58 -172 minecraft:stone
fill 329 58 -171 391 58 -171 minecraft:stone
fill 329 58 -170 391 58 -170 minecraft:stone
fill 330 58 -169 391 58 -169 minecraft:stone
fill 330 58 -168 391 58 -168 minecraft:stone
fill 331 58 -167 391 58 -167 minecraft:stone
fill 332 58 -166 391 58 -166 minecraft:stone
fill 332 58 -165 391 58 -165 minecraft:stone
fill 332 58 -164 391 58 -164 minecraft:stone
fill 332 58 -163 391 58 -163 minecraft:stone
fill 332 58 -162 391 58 -162 minecraft:stone
fill 331 58 -161 391 58 -161 minecraft:stone
fill 331 58 -160 391 58 -160 minecraft:stone
fill 330 58 -159 391 58 -159 minecraft:stone
fill 329 58 -158 391 58 -158 minecraft:stone
fill 328 58 -157 391 58 -157 minecraft:stone
fill 328 58 -156 391 58 -156 minecraft:stone
fill 328 58 -155 391 58 -155 minecraft:stone
fill 328 58 -154 391 58 -154 minecraft:stone
fill 328 58 -153 391 58 -153 minecraft:stone
fill 328 58 -152 391 58 -152 minecraft:stone
fill 328 58 -151 391 58 -151 minecraft:stone
fill 328 58 -150 391 58 -150 minecraft:stone
fill 328 58 -149 391 58 -149 minecraft:stone
fill 328 58 -148 391 58 -148 minecraft:stone
fill 328 58 -147 391 58 -147 minecraft:stone
fill 328 58 -146 391 58 -146 minecraft:stone
fill 328 58 -145 391 58 -145 minecraft:stone
fill 328 58 -144 391 58 -144 minecraft:stone
fill 328 58 -143 391 58 -143 minecraft:stone
fill 328 58 -142 391 58 -142 minecraft:stone
fill 328 58 -141 391 58 -141 minecraft:stone
fill 328 58 -140 391 58 -140 minecraft:stone
fill 328 58 -139 391 58 -139 minecraft:stone
fill 328 58 -138 391 58 -138 minecraft:stone
fill 328 58 -137 391 58 -137 minecraft:stone
fill 328 58 -136 391 58 -136 minecraft:stone
fill 328 58 -135 391 58 -135 minecraft:stone
fill 328 58 -134 391 58 -134 minecraft:stone
fill 328 58 -133 391 58 -133 minecraft:stone
fill 328 58 -132 391 58 -132 minecraft:stone
fill 328 58 -131 391 58 -131 minecraft:stone
fill 328 58 -130 391 58 -130 minecraft:stone
fill 328 58 -129 391 58 -129 minecraft:stone
fill 328 58 -128 391 58 -128 minecraft:stone
fill 328 58 -127 391 58 -127 minecraft:stone
fill 332 59 -190 391 59 -190 minecraft:stone
fill 331 59 -189 391 59 -189 minecraft:stone
fill 331 59 -188 391 59 -188 minecraft:stone
fill 331 59 -187 391 59 -187 minecraft:stone
fill 331 59 -186 391 59 -186 minecraft:stone
fill 331 59 -185 391 59 -185 minecraft:stone
fill 331 59 -184 391 59 -184 minecraft:stone
fill 331 59 -183 391 59 -183 minecraft:stone
fill 331 59 -182 391 59 -182 minecraft:stone
fill 331 59 -181 391 59 -181 minecraft:stone
fill 331 59 -180 391 59 -180 minecraft:stone
fill 331 59 -179 391 59 -179 minecraft:stone
fill 331 59 -178 391 59 -178 minecraft:stone
fill 331 59 -177 391 59 -177 minecraft:stone
fill 331 59 -176 391 59 -176 minecraft:stone
fill 331 59 -175 391 59 -175 minecraft:stone
fill 331 59 -174 391 59 -174 minecraft:stone
fill 330 59 -173 391 59 -173 minecraft:stone
fill 328 59 -172 391 59 -172 minecraft:stone
fill 328 59 -171 391 59 -171 minecraft:stone
fill 329 59 -170 391 59 -170 minecraft:stone
fill 329 59 -169 391 59 -169 minecraft:stone
fill 330 59 -168 391 59 -168 minecraft:stone
fill 331 59 -167 391 59 -167 minecraft:stone
fill 331 59 -166 391 59 -166 minecraft:stone
fill 332 59 -165 391 59 -165 minecraft:stone
fill 332 59 -164 391 59 -164 minecraft:stone
fill 332 59 -163 391 59 -163 minecraft:stone
fill 331 59 -162 391 59 -162 minecraft:stone
fill 331 59 -161 391 59 -161 minecraft:stone
fill 330 59 -160 391 59 -160 minecraft:stone
fill 329 59 -159 391 59 -159 minecraft:stone
fill 328 59 -158 391 59 -158 minecraft:stone
fill 328 59 -157 391 59 -157 minecraft:stone
fill 328 59 -156 391 59 -156 minecraft:stone
fill 328 59 -155 391 59 -155 minecraft:stone
fill 328 59 -154 391 59 -154 minecraft:stone
fill 328 59 -153 391 59 -153 minecraft:stone
fill 328 59 -152 391 59 -152 minecraft:stone
fill 328 59 -151 391 59 -151 minecraft:stone
fill 328 59 -150 391 59 -150 minecraft:stone
fill 328 59 -149 391 59 -149 minecraft:stone
fill 328 59 -148 391 59 -148 minecraft:stone
fill 328 59 -147 391 59 -147 minecraft:stone
fill 328 59 -146 391 59 -146 minecraft:stone
fill 328 59 -145 391 59 -145 minecraft:stone
fill 328 59 -144 391 59 -144 minecraft:stone
fill 328 59 -143 391 59 -143 minecraft:stone
fill 328 59 -142 391 59 -142 minecraft:stone
fill 328 59 -141 391 59 -141 minecraft:stone
fill 328 59 -140 391 59 -140 minecraft:stone
fill 328 59 -139 391 59 -139 minecraft:stone
fill 328 59 -138 391 59 -138 minecraft:stone
fill 328 59 -137 391 59 -137 minecraft:stone
fill 328 59 -136 391 59 -136 minecraft:stone
fill 328 59 -135 391 59 -135 minecraft:stone
fill 328 59 -134 391 59 -134 minecraft:stone
fill 328 59 -133 391 59 -133 minecraft:stone
fill 328 59 -132 391 59 -132 minecraft:stone
fill 328 59 -131 391 59 -131 minecraft:stone
fill 328 59 -130 391 59 -130 minecraft:stone
fill 328 59 -129 391 59 -129 minecraft:stone
fill 328 59 -128 391 59 -128 minecraft:stone
fill 328 59 -127 391 59 -127 minecraft:stone
fill 331 60 -190 391 60 -190 minecraft:stone
fill 331 60 -189 391 60 -189 minecraft:stone
fill 331 60 -188 391 60 -188 minecraft:stone
fill 331 60 -187 391 60 -187 minecraft:stone
fill 331 60 -186 391 60 -186 minecraft:stone
fill 331 60 -185 391 60 -185 minecraft:stone
fill 331 60 -184 391 60 -184 minecraft:stone
fill 331 60 -183 391 60 -183 minecraft:stone
fill 331 60 -182 391 60 -182 minecraft:stone
fill 331 60 -181 391 60 -181 minecraft:stone
fill 331 60 -180 391 60 -180 minecraft:stone
fill 331 60 -179 391 60 -179 minecraft:stone
fill 331 60 -178 391 60 -178 minecraft:stone
fill 331 60 -177 391 60 -177 minecraft:stone
fill 331 60 -176 391 60 -176 minecraft:stone
fill 331 60 -175 391 60 -175 minecraft:stone
fill 330 60 -174 391 60 -174 minecraft:stone
fill 329 60 -173 391 60 -173 minecraft:stone
fill 328 60 -172 391 60 -172 minecraft:stone
fill 328 60 -171 391 60 -171 minecraft:stone
fill 328 60 -170 391 60 -170 minecraft:stone
fill 328 60 -169 391 60 -169 minecraft:stone
fill 329 60 -168 391 60 -168 minecraft:stone
fill 330 60 -167 391 60 -167 minecraft:stone
fill 331 60 -166 391 60 -166 minecraft:stone
fill 331 60 -165 391 60 -165 minecraft:stone
fill 332 60 -164 391 60 -164 minecraft:stone
fill 331 60 -163 391 60 -163 minecraft:stone
fill 331 60 -162 391 60 -162 minecraft:stone
fill 331 60 -161 391 60 -161 minecraft:stone
fill 329 60 -160 391 60 -160 minecraft:stone
fill 328 60 -159 391 60 -159 minecraft:stone
fill 328 60 -158 391 60 -158 minecraft:stone
fill 328 60 -157 391 60 -157 minecraft:stone
fill 328 60 -156 391 60 -156 minecraft:stone
fill 328 60 -155 391 60 -155 minecraft:stone
fill 328 60 -154 391 60 -154 minecraft:stone
fill 328 60 -153 391 60 -153 minecraft:stone
fill 328 60 -152 391 60 -152 minecraft:stone
fill 328 60 -151 391 60 -151 minecraft:stone
fill 328 60 -150 391 60 -150 minecraft:stone
fill 328 60 -149 391 60 -149 minecraft:stone
fill 328 60 -148 391 60 -148 minecraft:stone
fill 328 60 -147 391 60 -147 minecraft:stone
fill 328 60 -146 391 60 -146 minecraft:stone
fill 328 60 -145 391 60 -145 minecraft:stone
fill 328 60 -144 391 60 -144 minecraft:stone
fill 328 60 -143 391 60 -143 minecraft:stone
fill 328 60 -142 391 60 -142 minecraft:stone
fill 328 60 -141 391 60 -141 minecraft:stone
fill 328 60 -140 391 60 -140 minecraft:stone
fill 328 60 -139 391 60 -139 minecraft:stone
fill 328 60 -138 391 60 -138 minecraft:stone
fill 328 60 -137 391 60 -137 minecraft:stone
fill 328 60 -136 391 60 -136 minecraft:stone
fill 328 60 -135 391 60 -135 minecraft:stone
fill 328 60 -134 391 60 -134 minecraft:stone
fill 328 60 -133 391 60 -133 minecraft:stone
fill 328 60 -132 391 60 -132 minecraft:stone
fill 328 60 -131 391 60 -131 minecraft:stone
fill 328 60 -130 391 60 -130 minecraft:stone
fill 328 60 -129 391 60 -129 minecraft:stone
fill 328 60 -128 391 60 -128 minecraft:stone
fill 328 60 -127 391 60 -127 minecraft:stone
fill 331 61 -190 391 61 -190 minecraft:stone
fill 331 61 -189 391 61 -189 minecraft:stone
fill 330 61 -188 391 61 -188 minecraft:stone
fill 331 61 -187 391 61 -187 minecraft:stone
fill 331 61 -186 391 61 -186 minecraft:stone
fill 331 61 -185 391 61 -185 minecraft:stone
fill 331 61 -184 391 61 -184 minecraft:stone
fill 331 61 -183 391 61 -183 minecraft:stone
fill 331 61 -182 391 61 -182 minecraft:stone
fill 331 61 -181 391 61 -181 minecraft:stone
fill 331 61 -180 391 61 -180 minecraft:stone
fill 331 61 -179 391 61 -179 minecraft:stone
fill 331 61 -178 391 61 -178 minecraft:stone
fill 331 61 -177 391 61 -177 minecraft:stone
fill 331 61 -176 391 61 -176 minecraft:stone
fill 330 61 -175 391 61 -175 minecraft:stone
fill 330 61 -174 391 61 -174 minecraft:stone
fill 328 61 -173 391 61 -173 minecraft:stone
fill 328 61 -172 391 61 -172 minecraft:stone
fill 328 61 -171 391 61 -171 minecraft:stone
fill 328 61 -170 391 61 -170 minecraft:stone
fill 328 61 -169 391 61 -169 minecraft:stone
fill 328 61 -168 391 61 -168 minecraft:stone
fill 330 61 -167 391 61 -167 minecraft:stone
fill 331 61 -166 391 61 -166 minecraft:stone
fill 331 61 -165 391 61 -165 minecraft:stone
fill 331 61 -164 391 61 -164 minecraft:stone
fill 331 61 -163 391 61 -163 minecraft:stone
fill 331 61 -162 391 61 -162 minecraft:stone
fill 330 61 -161 391 61 -161 minecraft:stone
fill 329 61 -160 391 61 -160 minecraft:stone
fill 328 61 -159 391 61 -159 minecraft:stone
fill 328 61 -158 391 61 -158 minecraft:stone
fill 328 61 -157 391 61 -157 minecraft:stone
fill 328 61 -156 391 61 -156 minecraft:stone
fill 328 61 -155 391 61 -155 minecraft:stone
fill 328 61 -154 391 61 -154 minecraft:stone
fill 328 61 -153 391 61 -153 minecraft:stone
fill 328 61 -152 391 61 -152 minecraft:stone
fill 328 61 -151 391 61 -151 minecraft:stone
fill 328 61 -150 391 61 -150 minecraft:stone
fill 328 61 -149 391 61 -149 minecraft:stone
fill 328 61 -148 391 61 -148 minecraft:stone
fill 328 61 -147 391 61 -147 minecraft:stone
fill 328 61 -146 391 61 -146 minecraft:stone
fill 328 61 -145 391 61 -145 minecraft:stone
fill 328 61 -144 391 61 -144 minecraft:stone
fill 328 61 -143 391 61 -143 minecraft:stone
fill 328 61 -142 391 61 -142 minecraft:stone
fill 328 61 -141 391 61 -141 minecraft:stone
fill 328 61 -140 391 61 -140 minecraft:stone
fill 328 61 -139 391 61 -139 minecraft:stone
fill 328 61 -138 391 61 -138 minecraft:stone
fill 328 61 -137 391 61 -137 minecraft:stone
fill 328 61 -136 391 61 -136 minecraft:stone
fill 328 61 -135 391 61 -135 minecraft:stone
fill 328 61 -134 391 61 -134 minecraft:stone
fill 328 61 -133 391 61 -133 minecraft:stone
fill 328 61 -132 391 61 -132 minecraft:stone
fill 328 61 -131 391 61 -131 minecraft:stone
fill 328 61 -130 391 61 -130 minecraft:stone
fill 328 61 -129 391 61 -129 minecraft:stone
fill 328 61 -128 391 61 -128 minecraft:stone
fill 328 61 -127 391 61 -127 minecraft:stone
fill 330 62 -190 391 62 -190 minecraft:dirt
fill 330 62 -189 391 62 -189 minecraft:dirt
fill 330 62 -188 391 62 -188 minecraft:dirt
fill 330 62 -187 391 62 -187 minecraft:dirt
fill 330 62 -186 391 62 -186 minecraft:dirt
fill 330 62 -185 391 62 -185 minecraft:dirt
fill 330 62 -184 391 62 -184 minecraft:dirt
fill 330 62 -183 391 62 -183 minecraft:dirt
fill 330 62 -182 391 62 -182 minecraft:dirt
fill 330 62 -181 391 62 -181 minecraft:dirt
fill 330 62 -180 391 62 -180 minecraft:dirt
fill 330 62 -179 391 62 -179 minecraft:dirt
fill 330 62 -178 391 62 -178 minecraft:dirt
fill 330 62 -177 391 62 -177 minecraft:dirt
fill 330 62 -176 391 62 -176 minecraft:dirt
fill 330 62 -175 391 62 -175 minecraft:dirt
fill 329 62 -174 391 62 -174 minecraft:dirt
fill 328 62 -173 391 62 -173 minecraft:dirt
fill 328 62 -172 391 62 -172 minecraft:dirt
fill 328 62 -171 391 62 -171 minecraft:dirt
fill 328 62 -170 391 62 -170 minecraft:dirt
fill 328 62 -169 391 62 -169 minecraft:dirt
fill 328 62 -168 391 62 -168 minecraft:dirt
fill 329 62 -167 391 62 -167 minecraft:dirt
fill 330 62 -166 391 62 -166 minecraft:dirt
fill 330 62 -165 391 62 -165 minecraft:dirt
fill 331 62 -164 391 62 -164 minecraft:dirt
fill 331 62 -163 391 62 -163 minecraft:dirt
fill 330 62 -162 391 62 -162 minecraft:dirt
fill 329 62 -161 391 62 -161 minecraft:dirt
fill 328 62 -160 391 62 -160 minecraft:dirt
fill 328 62 -159 391 62 -159 minecraft:dirt
fill 328 62 -158 391 62 -158 minecraft:dirt
fill 328 62 -157 391 62 -157 minecraft:dirt
fill 328 62 -156 391 62 -156 minecraft:dirt
fill 328 62 -155 391 62 -155 minecraft:dirt
fill 328 62 -154 391 62 -154 minecraft:dirt
fill 328 62 -153 391 62 -153 minecraft:dirt
fill 328 62 -152 391 62 -152 minecraft:dirt
fill 328 62 -151 391 62 -151 minecraft:dirt
fill 328 62 -150 391 62 -150 minecraft:dirt
fill 328 62 -149 391 62 -149 minecraft:dirt
fill 328 62 -148 391 62 -148 minecraft:dirt
fill 328 62 -147 391 62 -147 minecraft:dirt
fill 328 62 -146 391 62 -146 minecraft:dirt
fill 328 62 -145 391 62 -145 minecraft:dirt
fill 328 62 -144 391 62 -144 minecraft:dirt
fill 328 62 -143 391 62 -143 minecraft:dirt
fill 328 62 -142 391 62 -142 minecraft:dirt
fill 328 62 -141 391 62 -141 minecraft:dirt
fill 328 62 -140 391 62 -140 minecraft:dirt
fill 328 62 -139 391 62 -139 minecraft:dirt
fill 328 62 -138 391 62 -138 minecraft:dirt
fill 328 62 -137 391 62 -137 minecraft:dirt
fill 328 62 -136 391 62 -136 minecraft:dirt
fill 328 62 -135 391 62 -135 minecraft:dirt
fill 328 62 -134 391 62 -134 minecraft:dirt
fill 328 62 -133 391 62 -133 minecraft:dirt
fill 328 62 -132 391 62 -132 minecraft:dirt
fill 328 62 -131 391 62 -131 minecraft:dirt
fill 328 62 -130 391 62 -130 minecraft:dirt
fill 328 62 -129 391 62 -129 minecraft:dirt
fill 328 62 -128 391 62 -128 minecraft:dirt
fill 328 62 -127 391 62 -127 minecraft:dirt
fill 330 63 -190 391 63 -190 minecraft:dirt
fill 329 63 -189 391 63 -189 minecraft:dirt
fill 329 63 -188 391 63 -188 minecraft:dirt
fill 329 63 -187 391 63 -187 minecraft:dirt
fill 329 63 -186 391 63 -186 minecraft:dirt
fill 329 63 -185 391 63 -185 minecraft:dirt
fill 329 63 -184 391 63 -184 minecraft:dirt
fill 329 63 -183 391 63 -183 minecraft:dirt
fill 329 63 -182 391 63 -182 minecraft:dirt
fill 329 63 -181 391 63 -181 minecraft:dirt
fill 329 63 -180 391 63 -180 minecraft:dirt
fill 329 63 -179 391 63 -179 minecraft:dirt
fill 329 63 -178 391 63 -178 minecraft:dirt
fill 329 63 -177 391 63 -177 minecraft:dirt
fill 329 63 -176 391 63 -176 minecraft:dirt
fill 329 63 -175 391 63 -175 minecraft:dirt
fill 328 63 -174 391 63 -174 minecraft:dirt
fill 328 63 -173 391 63 -173 minecraft:dirt
fill 328 63 -172 391 63 -172 minecraft:dirt
fill 328 63 -171 391 63 -171 minecraft:dirt
fill 328 63 -170 391 63 -170 minecraft:dirt
fill 328 63 -169 391 63 -169 minecraft:dirt
fill 328 63 -168 391 63 -168 minecraft:dirt
fill 328 63 -167 391 63 -167 minecraft:dirt
fill 329 63 -166 391 63 -166 minecraft:dirt
fill 330 63 -165 391 63 -165 minecraft:dirt
fill 330 63 -164 391 63 -164 minecraft:dirt
fill 330 63 -163 391 63 -163 minecraft:dirt
fill 329 63 -162 391 63 -162 minecraft:dirt
fill 329 63 -161 391 63 -161 minecraft:dirt
fill 328 63 -160 391 63 -160 minecraft:dirt
fill 328 63 -159 391 63 -159 minecraft:dirt
fill 328 63 -158 391 63 -158 minecraft:dirt
fill 328 63 -157 391 63 -157 minecraft:dirt
fill 328 63 -156 391 63 -156 minecraft:dirt
fill 328 63 -155 391 63 -155 minecraft:dirt
fill 328 63 -154 391 63 -154 minecraft:dirt
fill 328 63 -153 391 63 -153 minecraft:dirt
fill 328 63 -152 391 63 -152 minecraft:dirt
fill 328 63 -151 391 63 -151 minecraft:dirt
fill 328 63 -150 391 63 -150 minecraft:dirt
fill 328 63 -149 391 63 -149 minecraft:dirt
fill 328 63 -148 391 63 -148 minecraft:dirt
fill 328 63 -147 391 63 -147 minecraft:dirt
fill 328 63 -146 391 63 -146 minecraft:dirt
fill 328 63 -145 391 63 -145 minecraft:dirt
fill 328 63 -144 391 63 -144 minecraft:dirt
fill 328 63 -143 391 63 -143 minecraft:dirt
fill 328 63 -142 391 63 -142 minecraft:dirt
fill 328 63 -141 391 63 -141 minecraft:dirt
fill 328 63 -140 391 63 -140 minecraft:dirt
fill 328 63 -139 391 63 -139 minecraft:dirt
fill 328 63 -138 391 63 -138 minecraft:dirt
fill 328 63 -137 391 63 -137 minecraft:dirt
fill 328 63 -136 391 63 -136 minecraft:dirt
fill 328 63 -135 391 63 -135 minecraft:dirt
fill 328 63 -134 391 63 -134 minecraft:dirt
fill 328 63 -133 391 63 -133 minecraft:dirt
fill 328 63 -132 391 63 -132 minecraft:dirt
fill 328 63 -131 391 63 -131 minecraft:dirt
fill 328 63 -130 391 63 -130 minecraft:dirt
fill 328 63 -129 391 63 -129 minecraft:dirt
fill 328 63 -128 391 63 -128 minecraft:dirt
fill 328 63 -127 391 63 -127 minecraft:dirt
fill 328 64 -190 391 64 -190 minecraft:dirt
fill 328 64 -189 391 64 -189 minecraft:dirt
fill 328 64 -188 391 64 -188 minecraft:dirt
fill 328 64 -187 391 64 -187 minecraft:dirt
fill 328 64 -186 391 64 -186 minecraft:dirt
fill 328 64 -185 391 64 -185 minecraft:dirt
fill 328 64 -184 391 64 -184 minecraft:dirt
fill 328 64 -183 391 64 -183 minecraft:dirt
fill 328 64 -182 391 64 -182 minecraft:dirt
fill 328 64 -181 391 64 -181 minecraft:dirt
fill 328 64 -180 391 64 -180 minecraft:dirt
fill 328 64 -179 391 64 -179 minecraft:dirt
fill 328 64 -178 391 64 -178 minecraft:dirt
fill 328 64 -177 391 64 -177 minecraft:dirt
fill 328 64 -176 391 64 -176 minecraft:dirt
fill 328 64 -175 391 64 -175 minecraft:dirt
fill 328 64 -174 391 64 -174 minecraft:dirt
fill 328 64 -173 391 64 -173 minecraft:dirt
fill 328 64 -172 391 64 -172 minecraft:dirt
fill 328 64 -171 391 64 -171 minecraft:dirt
fill 328 64 -170 391 64 -170 minecraft:dirt
fill 328 64 -169 391 64 -169 minecraft:dirt
fill 328 64 -168 391 64 -168 minecraft:dirt
fill 328 64 -167 391 64 -167 minecraft:dirt
fill 328 64 -166 391 64 -166 minecraft:dirt
fill 329 64 -165 391 64 -165 minecraft:dirt
fill 329 64 -164 391 64 -164 minecraft:dirt
fill 329 64 -163 391 64 -163 minecraft:dirt
fill 328 64 -162 391 64 -162 minecraft:dirt
fill 328 64 -161 391 64 -161 minecraft:dirt
fill 328 64 -160 391 64 -160 minecraft:dirt
fill 328 64 -159 391 64 -159 minecraft:dirt
fill 328 64 -158 391 64 -158 minecraft:dirt
fill 328 64 -157 391 64 -157 minecraft:dirt
fill 328 64 -156 391 64 -156 minecraft:dirt
fill 328 64 -155 391 64 -155 minecraft:dirt
fill 328 64 -154 391 64 -154 minecraft:dirt
fill 328 64 -153 391 64 -153 minecraft:dirt
fill 328 64 -152 391 64 -152 minecraft:dirt
fill 328 64 -151 391 64 -151 minecraft:dirt
fill 328 64 -150 391 64 -150 minecraft:dirt
fill 328 64 -149 391 64 -149 minecraft:dirt
fill 328 64 -148 391 64 -148 minecraft:dirt
fill 328 64 -147 391 64 -147 minecraft:dirt
fill 328 64 -146 391 64 -146 minecraft:dirt
fill 328 64 -145 391 64 -145 minecraft:dirt
fill 328 64 -144 391 64 -144 minecraft:dirt
fill 328 64 -143 391 64 -143 minecraft:dirt
fill 328 64 -142 391 64 -142 minecraft:dirt
fill 328 64 -141 391 64 -141 minecraft:dirt
fill 328 64 -140 391 64 -140 minecraft:dirt
fill 328 64 -139 391 64 -139 minecraft:dirt
fill 328 64 -138 391 64 -138 minecraft:dirt
fill 328 64 -137 391 64 -137 minecraft:dirt
fill 328 64 -136 391 64 -136 minecraft:dirt
fill 328 64 -135 391 64 -135 minecraft:dirt
fill 328 64 -134 391 64 -134 minecraft:dirt
fill 328 64 -133 391 64 -133 minecraft:dirt
fill 328 64 -132 391 64 -132 minecraft:dirt
fill 328 64 -131 391 64 -131 minecraft:dirt
fill 328 64 -130 391 64 -130 minecraft:dirt
fill 328 64 -129 391 64 -129 minecraft:dirt
fill 328 64 -128 391 64 -128 minecraft:dirt
fill 328 64 -127 391 64 -127 minecraft:dirt
fill 342 65 -190 378 65 -190 minecraft:grass_block
setblock 379 65 -190 minecraft:light_gray_concrete
fill 380 65 -190 382 65 -190 minecraft:smooth_quartz
setblock 383 65 -190 minecraft:light_gray_concrete
fill 384 65 -190 391 65 -190 minecraft:grass_block
fill 341 65 -189 378 65 -189 minecraft:grass_block
setblock 379 65 -189 minecraft:light_gray_concrete
fill 380 65 -189 382 65 -189 minecraft:smooth_quartz
setblock 383 65 -189 minecraft:light_gray_concrete
fill 384 65 -189 391 65 -189 minecraft:grass_block
fill 341 65 -188 378 65 -188 minecraft:grass_block
setblock 379 65 -188 minecraft:light_gray_concrete
fill 380 65 -188 382 65 -188 minecraft:smooth_quartz
setblock 383 65 -188 minecraft:light_gray_concrete
fill 384 65 -188 391 65 -188 minecraft:grass_block
fill 340 65 -187 378 65 -187 minecraft:grass_block
setblock 379 65 -187 minecraft:light_gray_concrete
fill 380 65 -187 382 65 -187 minecraft:smooth_quartz
setblock 383 65 -187 minecraft:light_gray_concrete
fill 384 65 -187 391 65 -187 minecraft:grass_block
fill 340 65 -186 378 65 -186 minecraft:grass_block
setblock 379 65 -186 minecraft:light_gray_concrete
fill 380 65 -186 382 65 -186 minecraft:smooth_quartz
setblock 383 65 -186 minecraft:light_gray_concrete
fill 384 65 -186 391 65 -186 minecraft:grass_block
fill 339 65 -185 378 65 -185 minecraft:grass_block
setblock 379 65 -185 minecraft:sea_lantern
fill 380 65 -185 382 65 -185 minecraft:smooth_quartz
setblock 383 65 -185 minecraft:sea_lantern
fill 384 65 -185 391 65 -185 minecraft:grass_block
fill 339 65 -184 378 65 -184 minecraft:grass_block
setblock 379 65 -184 minecraft:light_gray_concrete
fill 380 65 -184 382 65 -184 minecraft:smooth_quartz
setblock 383 65 -184 minecraft:light_gray_concrete
fill 384 65 -184 391 65 -184 minecraft:grass_block
fill 338 65 -183 378 65 -183 minecraft:grass_block
setblock 379 65 -183 minecraft:light_gray_concrete
fill 380 65 -183 382 65 -183 minecraft:smooth_quartz
setblock 383 65 -183 minecraft:light_gray_concrete
fill 384 65 -183 391 65 -183 minecraft:grass_block
fill 338 65 -182 378 65 -182 minecraft:grass_block
setblock 379 65 -182 minecraft:light_gray_concrete
fill 380 65 -182 382 65 -182 minecraft:smooth_quartz
setblock 383 65 -182 minecraft:light_gray_concrete
fill 384 65 -182 391 65 -182 minecraft:grass_block
fill 337 65 -181 378 65 -181 minecraft:grass_block
setblock 379 65 -181 minecraft:light_gray_concrete
fill 380 65 -181 382 65 -181 minecraft:smooth_quartz
setblock 383 65 -181 minecraft:light_gray_concrete
fill 384 65 -181 391 65 -181 minecraft:grass_block
fill 337 65 -180 378 65 -180 minecraft:grass_block
setblock 379 65 -180 minecraft:light_gray_concrete
fill 380 65 -180 382 65 -180 minecraft:smooth_quartz
setblock 383 65 -180 minecraft:light_gray_concrete
fill 384 65 -180 391 65 -180 minecraft:grass_block
fill 336 65 -179 378 65 -179 minecraft:grass_block
setblock 379 65 -179 minecraft:light_gray_concrete
fill 380 65 -179 382 65 -179 minecraft:smooth_quartz
setblock 383 65 -179 minecraft:light_gray_concrete
fill 384 65 -179 391 65 -179 minecraft:grass_block
fill 336 65 -178 378 65 -178 minecraft:grass_block
setblock 379 65 -178 minecraft:light_gray_concrete
fill 380 65 -178 382 65 -178 minecraft:smooth_quartz
setblock 383 65 -178 minecraft:light_gray_concrete
fill 384 65 -178 391 65 -178 minecraft:grass_block
fill 335 65 -177 378 65 -177 minecraft:grass_block
setblock 379 65 -177 minecraft:sea_lantern
fill 380 65 -177 382 65 -177 minecraft:smooth_quartz
setblock 383 65 -177 minecraft:sea_lantern
fill 384 65 -177 391 65 -177 minecraft:grass_block
fill 334 65 -176 378 65 -176 minecraft:grass_block
setblock 379 65 -176 minecraft:light_gray_concrete
fill 380 65 -176 382 65 -176 minecraft:smooth_quartz
setblock 383 65 -176 minecraft:light_gray_concrete
fill 384 65 -176 391 65 -176 minecraft:grass_block
fill 334 65 -175 378 65 -175 minecraft:grass_block
setblock 379 65 -175 minecraft:light_gray_concrete
fill 380 65 -175 382 65 -175 minecraft:smooth_quartz
setblock 383 65 -175 minecraft:light_gray_concrete
fill 384 65 -175 391 65 -175 minecraft:grass_block
fill 333 65 -174 378 65 -174 minecraft:grass_block
setblock 379 65 -174 minecraft:light_gray_concrete
fill 380 65 -174 382 65 -174 minecraft:smooth_quartz
setblock 383 65 -174 minecraft:light_gray_concrete
fill 384 65 -174 391 65 -174 minecraft:grass_block
fill 332 65 -173 378 65 -173 minecraft:grass_block
setblock 379 65 -173 minecraft:light_gray_concrete
fill 380 65 -173 382 65 -173 minecraft:smooth_quartz
setblock 383 65 -173 minecraft:light_gray_concrete
fill 384 65 -173 391 65 -173 minecraft:grass_block
fill 332 65 -172 378 65 -172 minecraft:grass_block
setblock 379 65 -172 minecraft:light_gray_concrete
fill 380 65 -172 382 65 -172 minecraft:smooth_quartz
setblock 383 65 -172 minecraft:light_gray_concrete
fill 384 65 -172 391 65 -172 minecraft:grass_block
fill 331 65 -171 378 65 -171 minecraft:grass_block
setblock 379 65 -171 minecraft:light_gray_concrete
fill 380 65 -171 382 65 -171 minecraft:smooth_quartz
setblock 383 65 -171 minecraft:light_gray_concrete
fill 384 65 -171 391 65 -171 minecraft:grass_block
fill 330 65 -170 378 65 -170 minecraft:grass_block
setblock 379 65 -170 minecraft:light_gray_concrete
fill 380 65 -170 382 65 -170 minecraft:smooth_quartz
setblock 383 65 -170 minecraft:light_gray_concrete
fill 384 65 -170 391 65 -170 minecraft:grass_block
fill 329 65 -169 378 65 -169 minecraft:grass_block
setblock 379 65 -169 minecraft:sea_lantern
fill 380 65 -169 382 65 -169 minecraft:smooth_quartz
setblock 383 65 -169 minecraft:sea_lantern
fill 384 65 -169 391 65 -169 minecraft:grass_block
fill 329 65 -168 378 65 -168 minecraft:grass_block
setblock 379 65 -168 minecraft:light_gray_concrete
fill 380 65 -168 382 65 -168 minecraft:smooth_quartz
setblock 383 65 -168 minecraft:light_gray_concrete
fill 384 65 -168 391 65 -168 minecraft:grass_block
fill 328 65 -167 378 65 -167 minecraft:grass_block
setblock 379 65 -167 minecraft:light_gray_concrete
fill 380 65 -167 382 65 -167 minecraft:smooth_quartz
setblock 383 65 -167 minecraft:light_gray_concrete
fill 384 65 -167 391 65 -167 minecraft:grass_block
fill 328 65 -166 378 65 -166 minecraft:grass_block
setblock 379 65 -166 minecraft:light_gray_concrete
fill 380 65 -166 382 65 -166 minecraft:smooth_quartz
setblock 383 65 -166 minecraft:light_gray_concrete
fill 384 65 -166 391 65 -166 minecraft:grass_block
fill 328 65 -165 378 65 -165 minecraft:grass_block
setblock 379 65 -165 minecraft:light_gray_concrete
fill 380 65 -165 382 65 -165 minecraft:smooth_quartz
setblock 383 65 -165 minecraft:light_gray_concrete
fill 384 65 -165 391 65 -165 minecraft:grass_block
fill 328 65 -164 378 65 -164 minecraft:grass_block
setblock 379 65 -164 minecraft:light_gray_concrete
fill 380 65 -164 382 65 -164 minecraft:smooth_quartz
setblock 383 65 -164 minecraft:light_gray_concrete
fill 384 65 -164 391 65 -164 minecraft:grass_block
fill 328 65 -163 378 65 -163 minecraft:grass_block
setblock 379 65 -163 minecraft:light_gray_concrete
fill 380 65 -163 382 65 -163 minecraft:smooth_quartz
setblock 383 65 -163 minecraft:light_gray_concrete
fill 384 65 -163 391 65 -163 minecraft:grass_block
fill 328 65 -162 378 65 -162 minecraft:grass_block
setblock 379 65 -162 minecraft:light_gray_concrete
fill 380 65 -162 382 65 -162 minecraft:smooth_quartz
setblock 383 65 -162 minecraft:light_gray_concrete
fill 384 65 -162 391 65 -162 minecraft:grass_block
fill 328 65 -161 378 65 -161 minecraft:grass_block
setblock 379 65 -161 minecraft:sea_lantern
fill 380 65 -161 382 65 -161 minecraft:smooth_quartz
setblock 383 65 -161 minecraft:sea_lantern
fill 384 65 -161 391 65 -161 minecraft:grass_block
fill 328 65 -160 378 65 -160 minecraft:grass_block
setblock 379 65 -160 minecraft:light_gray_concrete
fill 380 65 -160 382 65 -160 minecraft:smooth_quartz
setblock 383 65 -160 minecraft:light_gray_concrete
fill 384 65 -160 391 65 -160 minecraft:grass_block
fill 328 65 -159 378 65 -159 minecraft:grass_block
setblock 379 65 -159 minecraft:light_gray_concrete
fill 380 65 -159 382 65 -159 minecraft:smooth_quartz
setblock 383 65 -159 minecraft:light_gray_concrete
fill 384 65 -159 391 65 -159 minecraft:grass_block
fill 328 65 -158 378 65 -158 minecraft:grass_block
setblock 379 65 -158 minecraft:light_gray_concrete
fill 380 65 -158 382 65 -158 minecraft:smooth_quartz
setblock 383 65 -158 minecraft:light_gray_concrete
fill 384 65 -158 391 65 -158 minecraft:grass_block
fill 328 65 -157 378 65 -157 minecraft:grass_block
setblock 379 65 -157 minecraft:light_gray_concrete
fill 380 65 -157 382 65 -157 minecraft:smooth_quartz
setblock 383 65 -157 minecraft:light_gray_concrete
fill 384 65 -157 391 65 -157 minecraft:grass_block
fill 328 65 -156 378 65 -156 minecraft:grass_block
setblock 379 65 -156 minecraft:light_gray_concrete
fill 380 65 -156 382 65 -156 minecraft:smooth_quartz
setblock 383 65 -156 minecraft:light_gray_concrete
fill 384 65 -156 391 65 -156 minecraft:grass_block
fill 328 65 -155 378 65 -155 minecraft:grass_block
setblock 379 65 -155 minecraft:light_gray_concrete
fill 380 65 -155 382 65 -155 minecraft:smooth_quartz
setblock 383 65 -155 minecraft:light_gray_concrete
fill 384 65 -155 391 65 -155 minecraft:grass_block
fill 328 65 -154 378 65 -154 minecraft:grass_block
setblock 379 65 -154 minecraft:light_gray_concrete
fill 380 65 -154 382 65 -154 minecraft:smooth_quartz
setblock 383 65 -154 minecraft:light_gray_concrete
fill 384 65 -154 391 65 -154 minecraft:grass_block
fill 328 65 -153 378 65 -153 minecraft:grass_block
setblock 379 65 -153 minecraft:sea_lantern
fill 380 65 -153 382 65 -153 minecraft:smooth_quartz
setblock 383 65 -153 minecraft:sea_lantern
fill 384 65 -153 391 65 -153 minecraft:grass_block
fill 328 65 -152 378 65 -152 minecraft:grass_block
setblock 379 65 -152 minecraft:light_gray_concrete
fill 380 65 -152 382 65 -152 minecraft:smooth_quartz
setblock 383 65 -152 minecraft:light_gray_concrete
fill 384 65 -152 391 65 -152 minecraft:grass_block
fill 328 65 -151 378 65 -151 minecraft:grass_block
setblock 379 65 -151 minecraft:light_gray_concrete
fill 380 65 -151 382 65 -151 minecraft:smooth_quartz
setblock 383 65 -151 minecraft:light_gray_concrete
fill 384 65 -151 391 65 -151 minecraft:grass_block
fill 328 65 -150 378 65 -150 minecraft:grass_block
setblock 379 65 -150 minecraft:light_gray_concrete
fill 380 65 -150 382 65 -150 minecraft:smooth_quartz
setblock 383 65 -150 minecraft:light_gray_concrete
fill 384 65 -150 391 65 -150 minecraft:grass_block
fill 328 65 -149 378 65 -149 minecraft:grass_block
setblock 379 65 -149 minecraft:light_gray_concrete
fill 380 65 -149 382 65 -149 minecraft:smooth_quartz
setblock 383 65 -149 minecraft:light_gray_concrete
fill 384 65 -149 391 65 -149 minecraft:grass_block
fill 328 65 -148 378 65 -148 minecraft:grass_block
setblock 379 65 -148 minecraft:light_gray_concrete
fill 380 65 -148 382 65 -148 minecraft:smooth_quartz
setblock 383 65 -148 minecraft:light_gray_concrete
fill 384 65 -148 391 65 -148 minecraft:grass_block
fill 328 65 -147 378 65 -147 minecraft:grass_block
setblock 379 65 -147 minecraft:light_gray_concrete
fill 380 65 -147 382 65 -147 minecraft:smooth_quartz
setblock 383 65 -147 minecraft:light_gray_concrete
fill 384 65 -147 391 65 -147 minecraft:grass_block
fill 328 65 -146 378 65 -146 minecraft:grass_block
setblock 379 65 -146 minecraft:light_gray_concrete
fill 380 65 -146 382 65 -146 minecraft:smooth_quartz
setblock 383 65 -146 minecraft:light_gray_concrete
fill 384 65 -146 391 65 -146 minecraft:grass_block
fill 328 65 -145 378 65 -145 minecraft:grass_block
setblock 379 65 -145 minecraft:sea_lantern
fill 380 65 -145 382 65 -145 minecraft:smooth_quartz
setblock 383 65 -145 minecraft:sea_lantern
fill 384 65 -145 391 65 -145 minecraft:grass_block
fill 328 65 -144 378 65 -144 minecraft:grass_block
setblock 379 65 -144 minecraft:light_gray_concrete
fill 380 65 -144 382 65 -144 minecraft:smooth_quartz
setblock 383 65 -144 minecraft:light_gray_concrete
fill 384 65 -144 391 65 -144 minecraft:grass_block
fill 328 65 -143 378 65 -143 minecraft:grass_block
setblock 379 65 -143 minecraft:light_gray_concrete
fill 380 65 -143 382 65 -143 minecraft:smooth_quartz
setblock 383 65 -143 minecraft:light_gray_concrete
fill 384 65 -143 391 65 -143 minecraft:grass_block
fill 328 65 -142 378 65 -142 minecraft:grass_block
setblock 379 65 -142 minecraft:light_gray_concrete
fill 380 65 -142 382 65 -142 minecraft:smooth_quartz
setblock 383 65 -142 minecraft:light_gray_concrete
fill 384 65 -142 391 65 -142 minecraft:grass_block
fill 328 65 -141 378 65 -141 minecraft:grass_block
setblock 379 65 -141 minecraft:light_gray_concrete
fill 380 65 -141 382 65 -141 minecraft:smooth_quartz
setblock 383 65 -141 minecraft:light_gray_concrete
fill 384 65 -141 391 65 -141 minecraft:grass_block
fill 328 65 -140 378 65 -140 minecraft:grass_block
setblock 379 65 -140 minecraft:light_gray_concrete
fill 380 65 -140 382 65 -140 minecraft:smooth_quartz
setblock 383 65 -140 minecraft:light_gray_concrete
fill 384 65 -140 391 65 -140 minecraft:grass_block
fill 328 65 -139 378 65 -139 minecraft:grass_block
setblock 379 65 -139 minecraft:light_gray_concrete
fill 380 65 -139 382 65 -139 minecraft:smooth_quartz
setblock 383 65 -139 minecraft:light_gray_concrete
fill 384 65 -139 391 65 -139 minecraft:grass_block
fill 328 65 -138 378 65 -138 minecraft:grass_block
setblock 379 65 -138 minecraft:light_gray_concrete
fill 380 65 -138 382 65 -138 minecraft:smooth_quartz
setblock 383 65 -138 minecraft:light_gray_concrete
fill 384 65 -138 391 65 -138 minecraft:grass_block
fill 328 65 -137 378 65 -137 minecraft:grass_block
setblock 379 65 -137 minecraft:sea_lantern
fill 380 65 -137 382 65 -137 minecraft:smooth_quartz
setblock 383 65 -137 minecraft:sea_lantern
fill 384 65 -137 391 65 -137 minecraft:grass_block
fill 328 65 -136 378 65 -136 minecraft:grass_block
setblock 379 65 -136 minecraft:light_gray_concrete
fill 380 65 -136 382 65 -136 minecraft:smooth_quartz
setblock 383 65 -136 minecraft:light_gray_concrete
fill 384 65 -136 391 65 -136 minecraft:grass_block
fill 328 65 -135 378 65 -135 minecraft:grass_block
setblock 379 65 -135 minecraft:light_gray_concrete
fill 380 65 -135 382 65 -135 minecraft:smooth_quartz
setblock 383 65 -135 minecraft:light_gray_concrete
fill 384 65 -135 391 65 -135 minecraft:grass_block
fill 328 65 -134 378 65 -134 minecraft:grass_block
setblock 379 65 -134 minecraft:light_gray_concrete
fill 380 65 -134 382 65 -134 minecraft:smooth_quartz
setblock 383 65 -134 minecraft:light_gray_concrete
fill 384 65 -134 391 65 -134 minecraft:grass_block
fill 328 65 -133 378 65 -133 minecraft:grass_block
setblock 379 65 -133 minecraft:light_gray_concrete
fill 380 65 -133 382 65 -133 minecraft:smooth_quartz
setblock 383 65 -133 minecraft:light_gray_concrete
fill 384 65 -133 391 65 -133 minecraft:grass_block
fill 328 65 -132 378 65 -132 minecraft:grass_block
setblock 379 65 -132 minecraft:light_gray_concrete
fill 380 65 -132 382 65 -132 minecraft:smooth_quartz
setblock 383 65 -132 minecraft:light_gray_concrete
fill 384 65 -132 391 65 -132 minecraft:grass_block
fill 328 65 -131 378 65 -131 minecraft:grass_block
setblock 379 65 -131 minecraft:light_gray_concrete
fill 380 65 -131 382 65 -131 minecraft:smooth_quartz
setblock 383 65 -131 minecraft:light_gray_concrete
fill 384 65 -131 391 65 -131 minecraft:grass_block
fill 328 65 -130 378 65 -130 minecraft:grass_block
setblock 379 65 -130 minecraft:light_gray_concrete
fill 380 65 -130 382 65 -130 minecraft:smooth_quartz
setblock 383 65 -130 minecraft:light_gray_concrete
fill 384 65 -130 391 65 -130 minecraft:grass_block
fill 328 65 -129 378 65 -129 minecraft:grass_block
setblock 379 65 -129 minecraft:sea_lantern
fill 380 65 -129 382 65 -129 minecraft:smooth_quartz
setblock 383 65 -129 minecraft:sea_lantern
fill 384 65 -129 391 65 -129 minecraft:grass_block
fill 328 65 -128 378 65 -128 minecraft:grass_block
setblock 379 65 -128 minecraft:light_gray_concrete
fill 380 65 -128 382 65 -128 minecraft:smooth_quartz
setblock 383 65 -128 minecraft:light_gray_concrete
fill 384 65 -128 391 65 -128 minecraft:grass_block
fill 328 65 -127 378 65 -127 minecraft:grass_block
setblock 379 65 -127 minecraft:light_gray_concrete
fill 380 65 -127 382 65 -127 minecraft:smooth_quartz
setblock 383 65 -127 minecraft:light_gray_concrete
fill 384 65 -127 391 65 -127 minecraft:grass_block
fill 348 66 -190 350 66 -190 minecraft:allium
fill 352 66 -190 353 66 -190 minecraft:dandelion
setblock 355 66 -190 minecraft:dandelion
fill 358 66 -190 359 66 -190 minecraft:cornflower
setblock 361 66 -190 minecraft:poppy
setblock 363 66 -190 minecraft:poppy
fill 366 66 -190 367 66 -190 minecraft:oxeye_daisy
fill 370 66 -190 371 66 -190 minecraft:azure_bluet
fill 374 66 -190 375 66 -190 minecraft:orange_tulip
setblock 378 66 -190 minecraft:allium
setblock 384 66 -190 minecraft:cornflower
setblock 388 66 -190 minecraft:poppy
fill 390 66 -190 391 66 -190 minecraft:poppy
fill 352 66 -189 355 66 -189 minecraft:dandelion
fill 358 66 -189 359 66 -189 minecraft:cornflower
fill 360 66 -189 363 66 -189 minecraft:poppy
fill 365 66 -189 367 66 -189 minecraft:oxeye_daisy
fill 368 66 -189 369 66 -189 minecraft:azure_bluet
setblock 371 66 -189 minecraft:azure_bluet
fill 372 66 -189 375 66 -189 minecraft:orange_tulip
fill 377 66 -189 378 66 -189 minecraft:allium
setblock 385 66 -189 minecraft:cornflower
setblock 387 66 -189 minecraft:cornflower
setblock 388 66 -189 minecraft:poppy
setblock 390 66 -189 minecraft:poppy
setblock 348 66 -188 minecraft:allium
fill 350 66 -188 351 66 -188 minecraft:allium
fill 353 66 -188 354 66 -188 minecraft:dandelion
fill 356 66 -188 357 66 -188 minecraft:cornflower
setblock 359 66 -188 minecraft:cornflower
setblock 361 66 -188 minecraft:poppy
setblock 364 66 -188 minecraft:oxeye_daisy
setblock 367 66 -188 minecraft:oxeye_daisy
setblock 368 66 -188 minecraft:azure_bluet
fill 370 66 -188 371 66 -188 minecraft:azure_bluet
fill 372 66 -188 373 66 -188 minecraft:orange_tulip
setblock 375 66 -188 minecraft:orange_tulip
setblock 376 66 -188 minecraft:allium
setblock 384 66 -188 minecraft:cornflower
fill 386 66 -188 387 66 -188 minecraft:cornflower
setblock 389 66 -188 minecraft:poppy
setblock 391 66 -188 minecraft:poppy
fill 348 66 -187 350 66 -187 minecraft:allium
setblock 352 66 -187 minecraft:dandelion
fill 354 66 -187 355 66 -187 minecraft:dandelion
setblock 358 66 -187 minecraft:cornflower
setblock 360 66 -187 minecraft:poppy
setblock 362 66 -187 minecraft:poppy
fill 364 66 -187 367 66 -187 minecraft:oxeye_daisy
fill 369 66 -187 370 66 -187 minecraft:azure_bluet
setblock 372 66 -187 minecraft:orange_tulip
fill 376 66 -187 378 66 -187 minecraft:allium
setblock 388 66 -187 minecraft:poppy
fill 390 66 -187 391 66 -187 minecraft:poppy
setblock 350 66 -186 minecraft:allium
fill 353 66 -186 354 66 -186 minecraft:dandelion
fill 356 66 -186 357 66 -186 minecraft:cornflower
fill 360 66 -186 361 66 -186 minecraft:poppy
fill 364 66 -186 367 66 -186 minecraft:oxeye_daisy
setblock 371 66 -186 minecraft:azure_bluet
setblock 375 66 -186 minecraft:orange_tulip
setblock 378 66 -186 minecraft:allium
fill 384 66 -186 387 66 -186 minecraft:cornflower
fill 388 66 -186 391 66 -186 minecraft:poppy
setblock 348 66 -185 minecraft:allium
fill 350 66 -185 351 66 -185 minecraft:allium
setblock 352 66 -185 minecraft:dandelion
setblock 354 66 -185 minecraft:dandelion
setblock 356 66 -185 minecraft:cornflower
fill 358 66 -185 359 66 -185 minecraft:cornflower
setblock 360 66 -185 minecraft:poppy
setblock 364 66 -185 minecraft:oxeye_daisy
fill 366 66 -185 367 66 -185 minecraft:oxeye_daisy
fill 368 66 -185 369 66 -185 minecraft:azure_bluet
setblock 371 66 -185 minecraft:azure_bluet
setblock 372 66 -185 minecraft:orange_tulip
setblock 378 66 -185 minecraft:allium
fill 384 66 -185 385 66 -185 minecraft:cornflower
setblock 388 66 -185 minecraft:poppy
fill 390 66 -185 391 66 -185 minecraft:poppy
fill 348 66 -184 349 66 -184 minecraft:allium
fill 352 66 -184 355 66 -184 minecraft:dandelion
setblock 358 66 -184 minecraft:cornflower
setblock 361 66 -184 minecraft:poppy
setblock 364 66 -184 minecraft:oxeye_daisy
setblock 367 66 -184 minecraft:oxeye_daisy
setblock 369 66 -184 minecraft:azure_bluet
setblock 371 66 -184 minecraft:azure_bluet
setblock 373 66 -184 minecraft:orange_tulip
fill 384 66 -184 386 66 -184 minecraft:cornflower
setblock 388 66 -184 minecraft:poppy
fill 390 66 -184 391 66 -184 minecraft:poppy
fill 348 66 -183 349 66 -183 minecraft:allium
setblock 351 66 -183 minecraft:allium
fill 352 66 -183 355 66 -183 minecraft:dandelion
setblock 359 66 -183 minecraft:cornflower
fill 360 66 -183 361 66 -183 minecraft:poppy
fill 364 66 -183 366 66 -183 minecraft:oxeye_daisy
setblock 368 66 -183 minecraft:azure_bluet
setblock 371 66 -183 minecraft:azure_bluet
fill 372 66 -183 373 66 -183 minecraft:orange_tulip
fill 377 66 -183 378 66 -183 minecraft:allium
fill 384 66 -183 385 66 -183 minecraft:cornflower
setblock 387 66 -183 minecraft:cornflower
setblock 388 66 -183 minecraft:poppy
setblock 350 66 -182 minecraft:allium
setblock 353 66 -182 minecraft:dandelion
setblock 355 66 -182 minecraft:dandelion
fill 356 66 -182 359 66 -182 minecraft:cornflower
fill 360 66 -182 361 66 -182 minecraft:poppy
setblock 363 66 -182 minecraft:poppy
fill 364 66 -182 365 66 -182 minecraft:oxeye_daisy
fill 368 66 -182 369 66 -182 minecraft:azure_bluet
setblock 371 66 -182 minecraft:azure_bluet
setblock 372 66 -182 minecraft:orange_tulip
setblock 375 66 -182 minecraft:orange_tulip
fill 376 66 -182 377 66 -182 minecraft:allium
fill 386 66 -182 387 66 -182 minecraft:cornflower
fill 388 66 -182 389 66 -182 minecraft:poppy
fill 348 66 -181 350 66 -181 minecraft:allium
setblock 354 66 -181 minecraft:dandelion
setblock 357 66 -181 minecraft:cornflower
setblock 359 66 -181 minecraft:cornflower
fill 360 66 -181 361 66 -181 minecraft:poppy
fill 366 66 -181 367 66 -181 minecraft:oxeye_daisy
setblock 368 66 -181 minecraft:azure_bluet
fill 370 66 -181 371 66 -181 minecraft:azure_bluet
setblock 373 66 -181 minecraft:orange_tulip
setblock 376 66 -181 minecraft:allium
setblock 386 66 -181 minecraft:cornflower
fill 388 66 -181 390 66 -181 minecraft:poppy
setblock 348 66 -180 minecraft:allium
fill 350 66 -180 351 66 -180 minecraft:allium
fill 353 66 -180 355 66 -180 minecraft:dandelion
fill 356 66 -180 357 66 -180 minecraft:cornflower
setblock 360 66 -180 minecraft:poppy
fill 362 66 -180 363 66 -180 minecraft:poppy
fill 364 66 -180 365 66 -180 minecraft:oxeye_daisy
setblock 367 66 -180 minecraft:oxeye_daisy
setblock 368 66 -180 minecraft:azure_bluet
fill 372 66 -180 374 66 -180 minecraft:orange_tulip
fill 377 66 -180 378 66 -180 minecraft:allium
fill 385 66 -180 386 66 -180 minecraft:cornflower
setblock 388 66 -180 minecraft:poppy
fill 390 66 -180 391 66 -180 minecraft:poppy
setblock 348 66 -179 minecraft:allium
fill 352 66 -179 354 66 -179 minecraft:dandelion
setblock 357 66 -179 minecraft:cornflower
setblock 359 66 -179 minecraft:cornflower
setblock 360 66 -179 minecraft:poppy
setblock 363 66 -179 minecraft:poppy
setblock 364 66 -179 minecraft:oxeye_daisy
fill 368 66 -179 369 66 -179 minecraft:azure_bluet
setblock 372 66 -179 minecraft:orange_tulip
fill 374 66 -179 375 66 -179 minecraft:orange_tulip
fill 376 66 -179 378 66 -179 minecraft:allium
fill 384 66 -179 387 66 -179 minecraft:cornflower
setblock 390 66 -179 minecraft:poppy
setblock 348 66 -178 minecraft:allium
fill 350 66 -178 351 66 -178 minecraft:allium
fill 352 66 -178 355 66 -178 minecraft:dandelion
fill 357 66 -178 359 66 -178 minecraft:cornflower
setblock 361 66 -178 minecraft:poppy
setblock 364 66 -178 minecraft:oxeye_daisy
setblock 366 66 -178 minecraft:oxeye_daisy
fill 368 66 -178 369 66 -178 minecraft:azure_bluet
setblock 372 66 -178 minecraft:orange_tulip
fill 376 66 -178 377 66 -178 minecraft:allium
setblock 387 66 -178 minecraft:cornflower
fill 388 66 -178 389 66 -178 minecraft:poppy
setblock 391 66 -178 minecraft:poppy
fill 350 66 -177 351 66 -177 minecraft:allium
fill 353 66 -177 355 66 -177 minecraft:dandelion
fill 357 66 -177 358 66 -177 minecraft:cornflower
setblock 360 66 -177 minecraft:poppy
fill 362 66 -177 363 66 -177 minecraft:poppy
fill 365 66 -177 366 66 -177 minecraft:oxeye_daisy
setblock 372 66 -177 minecraft:orange_tulip
fill 374 66 -177 375 66 -177 minecraft:orange_tulip
fill 377 66 -177 378 66 -177 minecraft:allium
fill 384 66 -177 385 66 -177 minecraft:cornflower
fill 390 66 -177 391 66 -177 minecraft:poppy
fill 348 66 -176 349 66 -176 minecraft:allium
setblock 353 66 -176 minecraft:dandelion
setblock 355 66 -176 minecraft:dandelion
fill 356 66 -176 357 66 -176 minecraft:cornflower
setblock 360 66 -176 minecraft:poppy
setblock 362 66 -176 minecraft:poppy
fill 365 66 -176 367 66 -176 minecraft:oxeye_daisy
fill 368 66 -176 369 66 -176 minecraft:azure_bluet
setblock 371 66 -176 minecraft:azure_bluet
setblock 372 66 -176 minecraft:orange_tulip
setblock 375 66 -176 minecraft:orange_tulip
fill 377 66 -176 378 66 -176 minecraft:allium
setblock 384 66 -176 minecraft:cornflower
setblock 387 66 -176 minecraft:cornflower
setblock 389 66 -176 minecraft:poppy
setblock 391 66 -176 minecraft:poppy
setblock 348 66 -175 minecraft:allium
setblock 351 66 -175 minecraft:allium
setblock 353 66 -175 minecraft:dandelion
setblock 355 66 -175 minecraft:dandelion
fill 356 66 -175 358 66 -175 minecraft:cornflower
fill 360 66 -175 362 66 -175 minecraft:poppy
fill 365 66 -175 366 66 -175 minecraft:oxeye_daisy
setblock 369 66 -175 minecraft:azure_bluet
setblock 371 66 -175 minecraft:azure_bluet
setblock 374 66 -175 minecraft:orange_tulip
fill 384 66 -175 385 66 -175 minecraft:cornflower
fill 388 66 -175 389 66 -175 minecraft:poppy
setblock 391 66 -175 minecraft:poppy
fill 348 66 -174 351 66 -174 minecraft:allium
fill 352 66 -174 353 66 -174 minecraft:dandelion
setblock 356 66 -174 minecraft:cornflower
fill 358 66 -174 359 66 -174 minecraft:cornflower
setblock 363 66 -174 minecraft:poppy
fill 364 66 -174 366 66 -174 minecraft:oxeye_daisy
setblock 369 66 -174 minecraft:azure_bluet
setblock 371 66 -174 minecraft:azure_bluet
fill 373 66 -174 375 66 -174 minecraft:orange_tulip
fill 377 66 -174 378 66 -174 minecraft:allium
setblock 386 66 -174 minecraft:cornflower
fill 390 66 -174 391 66 -174 minecraft:poppy
fill 348 66 -173 349 66 -173 minecraft:allium
setblock 351 66 -173 minecraft:allium
fill 353 66 -173 354 66 -173 minecraft:dandelion
setblock 356 66 -173 minecraft:cornflower
setblock 359 66 -173 minecraft:cornflower
setblock 360 66 -173 minecraft:poppy
fill 364 66 -173 365 66 -173 minecraft:oxeye_daisy
setblock 367 66 -173 minecraft:oxeye_daisy
fill 369 66 -173 370 66 -173 minecraft:azure_bluet
setblock 372 66 -173 minecraft:orange_tulip
setblock 378 66 -173 minecraft:allium
setblock 384 66 -173 minecraft:cornflower
setblock 386 66 -173 minecraft:cornflower
fill 388 66 -173 389 66 -173 minecraft:poppy
setblock 349 66 -172 minecraft:allium
fill 356 66 -172 359 66 -172 minecraft:cornflower
setblock 360 66 -172 minecraft:poppy
setblock 363 66 -172 minecraft:poppy
setblock 364 66 -172 minecraft:oxeye_daisy
fill 366 66 -172 367 66 -172 minecraft:oxeye_daisy
setblock 370 66 -172 minecraft:azure_bluet
setblock 373 66 -172 minecraft:orange_tulip
setblock 378 66 -172 minecraft:allium
setblock 385 66 -172 minecraft:cornflower
setblock 388 66 -172 minecraft:poppy
setblock 348 66 -171 minecraft:allium
fill 350 66 -171 351 66 -171 minecraft:allium
fill 356 66 -171 357 66 -171 minecraft:cornflower
setblock 360 66 -171 minecraft:poppy
setblock 362 66 -171 minecraft:poppy
fill 364 66 -171 367 66 -171 minecraft:oxeye_daisy
fill 368 66 -171 369 66 -171 minecraft:azure_bluet
setblock 371 66 -171 minecraft:azure_bluet
fill 372 66 -171 373 66 -171 minecraft:orange_tulip
setblock 375 66 -171 minecraft:orange_tulip
setblock 378 66 -171 minecraft:allium
setblock 387 66 -171 minecraft:cornflower
fill 388 66 -171 390 66 -171 minecraft:poppy
fill 348 66 -170 350 66 -170 minecraft:allium
setblock 352 66 -170 minecraft:dandelion
fill 354 66 -170 355 66 -170 minecraft:dandelion
setblock 356 66 -170 minecraft:cornflower
setblock 358 66 -170 minecraft:cornflower
fill 360 66 -170 361 66 -170 minecraft:poppy
fill 366 66 -170 367 66 -170 minecraft:oxeye_daisy
setblock 369 66 -170 minecraft:azure_bluet
setblock 371 66 -170 minecraft:azure_bluet
fill 372 66 -170 373 66 -170 minecraft:orange_tulip
setblock 378 66 -170 minecraft:allium
setblock 386 66 -170 minecraft:cornflower
fill 388 66 -170 391 66 -170 minecraft:poppy
fill 348 66 -169 350 66 -169 minecraft:allium
setblock 359 66 -169 minecraft:cornflower
fill 360 66 -169 363 66 -169 minecraft:poppy
fill 364 66 -169 365 66 -169 minecraft:oxeye_daisy
setblock 367 66 -169 minecraft:oxeye_daisy
setblock 368 66 -169 minecraft:azure_bluet
fill 372 66 -169 374 66 -169 minecraft:orange_tulip
setblock 378 66 -169 minecraft:allium
fill 384 66 -169 386 66 -169 minecraft:cornflower
fill 388 66 -169 391 66 -169 minecraft:poppy
fill 352 66 -168 355 66 -168 minecraft:dandelion
fill 361 66 -168 363 66 -168 minecraft:poppy
fill 366 66 -168 367 66 -168 minecraft:oxeye_daisy
fill 368 66 -168 370 66 -168 minecraft:azure_bluet
fill 377 66 -168 378 66 -168 minecraft:allium
fill 384 66 -168 387 66 -168 minecraft:cornflower
fill 390 66 -168 391 66 -168 minecraft:poppy
fill 349 66 -167 350 66 -167 minecraft:allium
setblock 352 66 -167 minecraft:dandelion
setblock 354 66 -167 minecraft:dandelion
setblock 356 66 -167 minecraft:cornflower
setblock 359 66 -167 minecraft:cornflower
fill 360 66 -167 361 66 -167 minecraft:poppy
setblock 364 66 -167 minecraft:oxeye_daisy
setblock 366 66 -167 minecraft:oxeye_daisy
fill 369 66 -167 370 66 -167 minecraft:azure_bluet
setblock 373 66 -167 minecraft:orange_tulip
fill 376 66 -167 378 66 -167 minecraft:allium
fill 384 66 -167 386 66 -167 minecraft:cornflower
setblock 388 66 -167 minecraft:poppy
fill 390 66 -167 391 66 -167 minecraft:poppy
fill 348 66 -166 350 66 -166 minecraft:allium
fill 352 66 -166 353 66 -166 minecraft:dandelion
setblock 356 66 -166 minecraft:cornflower
setblock 359 66 -166 minecraft:cornflower
fill 361 66 -166 363 66 -166 minecraft:poppy
setblock 364 66 -166 minecraft:oxeye_daisy
fill 370 66 -166 371 66 -166 minecraft:azure_bluet
setblock 374 66 -166 minecraft:orange_tulip
setblock 378 66 -166 minecraft:allium
fill 386 66 -166 387 66 -166 minecraft:cornflower
fill 389 66 -166 391 66 -166 minecraft:poppy
fill 348 66 -165 349 66 -165 minecraft:allium
setblock 351 66 -165 minecraft:allium
setblock 352 66 -165 minecraft:dandelion
fill 354 66 -165 355 66 -165 minecraft:dandelion
fill 356 66 -165 359 66 -165 minecraft:cornflower
fill 360 66 -165 362 66 -165 minecraft:poppy
setblock 364 66 -165 minecraft:oxeye_daisy
fill 366 66 -165 367 66 -165 minecraft:oxeye_daisy
fill 368 66 -165 371 66 -165 minecraft:azure_bluet
setblock 373 66 -165 minecraft:orange_tulip
fill 384 66 -165 385 66 -165 minecraft:cornflower
setblock 389 66 -165 minecraft:poppy
setblock 350 66 -164 minecraft:allium
fill 353 66 -164 355 66 -164 minecraft:dandelion
setblock 359 66 -164 minecraft:cornflower
fill 360 66 -164 361 66 -164 minecraft:poppy
setblock 364 66 -164 minecraft:oxeye_daisy
fill 368 66 -164 369 66 -164 minecraft:azure_bluet
setblock 371 66 -164 minecraft:azure_bluet
fill 372 66 -164 374 66 -164 minecraft:orange_tulip
setblock 376 66 -164 minecraft:allium
setblock 378 66 -164 minecraft:allium
fill 384 66 -164 387 66 -164 minecraft:cornflower
setblock 349 66 -163 minecraft:allium
setblock 351 66 -163 minecraft:allium
setblock 352 66 -163 minecraft:dandelion
setblock 355 66 -163 minecraft:dandelion
setblock 356 66 -163 minecraft:cornflower
setblock 359 66 -163 minecraft:cornflower
setblock 360 66 -163 minecraft:poppy
setblock 364 66 -163 minecraft:oxeye_daisy
fill 366 66 -163 367 66 -163 minecraft:oxeye_daisy
setblock 373 66 -163 minecraft:orange_tulip
setblock 375 66 -163 minecraft:orange_tulip
setblock 377 66 -163 minecraft:allium
setblock 384 66 -163 minecraft:cornflower
fill 388 66 -163 391 66 -163 minecraft:poppy
setblock 348 66 -162 minecraft:allium
fill 350 66 -162 351 66 -162 minecraft:allium
fill 352 66 -162 353 66 -162 minecraft:dandelion
setblock 355 66 -162 minecraft:dandelion
setblock 357 66 -162 minecraft:cornflower
setblock 359 66 -162 minecraft:cornflower
setblock 360 66 -162 minecraft:poppy
setblock 363 66 -162 minecraft:poppy
setblock 364 66 -162 minecraft:oxeye_daisy
setblock 367 66 -162 minecraft:oxeye_daisy
fill 369 66 -162 371 66 -162 minecraft:azure_bluet
fill 372 66 -162 374 66 -162 minecraft:orange_tulip
fill 376 66 -162 377 66 -162 minecraft:allium
setblock 387 66 -162 minecraft:cornflower
fill 388 66 -162 389 66 -162 minecraft:poppy
setblock 391 66 -162 minecraft:poppy
setblock 350 66 -161 minecraft:allium
fill 354 66 -161 355 66 -161 minecraft:dandelion
fill 356 66 -161 357 66 -161 minecraft:cornflower
setblock 359 66 -161 minecraft:cornflower
fill 360 66 -161 363 66 -161 minecraft:poppy
fill 364 66 -161 366 66 -161 minecraft:oxeye_daisy
setblock 368 66 -161 minecraft:azure_bluet
setblock 384 66 -161 minecraft:cornflower
fill 389 66 -161 391 66 -161 minecraft:poppy
setblock 349 66 -160 minecraft:allium
setblock 351 66 -160 minecraft:allium
fill 352 66 -160 353 66 -160 minecraft:dandelion
setblock 358 66 -160 minecraft:cornflower
setblock 360 66 -160 minecraft:poppy
setblock 362 66 -160 minecraft:poppy
fill 364 66 -160 366 66 -160 minecraft:oxeye_daisy
fill 372 66 -160 373 66 -160 minecraft:orange_tulip
setblock 375 66 -160 minecraft:orange_tulip
setblock 376 66 -160 minecraft:allium
setblock 378 66 -160 minecraft:allium
fill 384 66 -160 387 66 -160 minecraft:cornflower
fill 388 66 -160 389 66 -160 minecraft:poppy
setblock 391 66 -160 minecraft:poppy
setblock 348 66 -159 minecraft:allium
setblock 350 66 -159 minecraft:allium
setblock 352 66 -159 minecraft:dandelion
fill 354 66 -159 355 66 -159 minecraft:dandelion
setblock 356 66 -159 minecraft:cornflower
setblock 358 66 -159 minecraft:cornflower
fill 360 66 -159 362 66 -159 minecraft:poppy
fill 364 66 -159 365 66 -159 minecraft:oxeye_daisy
setblock 367 66 -159 minecraft:oxeye_daisy
fill 369 66 -159 371 66 -159 minecraft:azure_bluet
fill 372 66 -159 373 66 -159 minecraft:orange_tulip
fill 376 66 -159 378 66 -159 minecraft:allium
setblock 384 66 -159 minecraft:cornflower
setblock 387 66 -159 minecraft:cornflower
fill 388 66 -159 391 66 -159 minecraft:poppy
fill 348 66 -158 349 66 -158 minecraft:allium
setblock 351 66 -158 minecraft:allium
setblock 353 66 -158 minecraft:dandelion
setblock 356 66 -158 minecraft:cornflower
fill 360 66 -158 363 66 -158 minecraft:poppy
setblock 364 66 -158 minecraft:oxeye_daisy
setblock 367 66 -158 minecraft:oxeye_daisy
setblock 368 66 -158 minecraft:azure_bluet
setblock 370 66 -158 minecraft:azure_bluet
fill 372 66 -158 375 66 -158 minecraft:orange_tulip
fill 376 66 -158 378 66 -158 minecraft:allium
fill 384 66 -158 387 66 -158 minecraft:cornflower
fill 350 66 -157 351 66 -157 minecraft:allium
setblock 355 66 -157 minecraft:dandelion
fill 356 66 -157 357 66 -157 minecraft:cornflower
setblock 359 66 -157 minecraft:cornflower
setblock 363 66 -157 minecraft:poppy
fill 364 66 -157 365 66 -157 minecraft:oxeye_daisy
setblock 367 66 -157 minecraft:oxeye_daisy
fill 368 66 -157 370 66 -157 minecraft:azure_bluet
fill 373 66 -157 374 66 -157 minecraft:orange_tulip
fill 376 66 -157 378 66 -157 minecraft:allium
fill 388 66 -157 391 66 -157 minecraft:poppy
setblock 351 66 -156 minecraft:allium
fill 352 66 -156 353 66 -156 minecraft:dandelion
setblock 355 66 -156 minecraft:dandelion
fill 356 66 -156 359 66 -156 minecraft:cornflower
fill 362 66 -156 363 66 -156 minecraft:poppy
fill 364 66 -156 366 66 -156 minecraft:oxeye_daisy
fill 368 66 -156 370 66 -156 minecraft:azure_bluet
setblock 372 66 -156 minecraft:orange_tulip
fill 385 66 -156 387 66 -156 minecraft:cornflower
setblock 389 66 -156 minecraft:poppy
setblock 391 66 -156 minecraft:poppy
setblock 348 66 -155 minecraft:allium
setblock 351 66 -155 minecraft:allium
fill 352 66 -155 355 66 -155 minecraft:dandelion
setblock 356 66 -155 minecraft:cornflower
fill 358 66 -155 359 66 -155 minecraft:cornflower
setblock 360 66 -155 minecraft:poppy
setblock 362 66 -155 minecraft:poppy
fill 364 66 -155 365 66 -155 minecraft:oxeye_daisy
setblock 368 66 -155 minecraft:azure_bluet
fill 370 66 -155 371 66 -155 minecraft:azure_bluet
setblock 372 66 -155 minecraft:orange_tulip
fill 374 66 -155 375 66 -155 minecraft:orange_tulip
setblock 378 66 -155 minecraft:allium
setblock 386 66 -155 minecraft:cornflower
setblock 388 66 -155 minecraft:poppy
setblock 348 66 -154 minecraft:allium
fill 350 66 -154 351 66 -154 minecraft:allium
fill 352 66 -154 353 66 -154 minecraft:dandelion
fill 358 66 -154 359 66 -154 minecraft:cornflower
setblock 361 66 -154 minecraft:poppy
setblock 363 66 -154 minecraft:poppy
fill 365 66 -154 366 66 -154 minecraft:oxeye_daisy
fill 370 66 -154 371 66 -154 minecraft:azure_bluet
fill 372 66 -154 375 66 -154 minecraft:orange_tulip
setblock 376 66 -154 minecraft:allium
setblock 378 66 -154 minecraft:allium
fill 384 66 -154 385 66 -154 minecraft:cornflower
setblock 387 66 -154 minecraft:cornflower
setblock 388 66 -154 minecraft:poppy
fill 348 66 -153 349 66 -153 minecraft:allium
setblock 352 66 -153 minecraft:dandelion
fill 354 66 -153 355 66 -153 minecraft:dandelion
fill 357 66 -153 358 66 -153 minecraft:cornflower
setblock 361 66 -153 minecraft:poppy
setblock 363 66 -153 minecraft:poppy
setblock 366 66 -153 minecraft:oxeye_daisy
setblock 371 66 -153 minecraft:azure_bluet
setblock 373 66 -153 minecraft:orange_tulip
setblock 375 66 -153 minecraft:orange_tulip
setblock 376 66 -153 minecraft:allium
setblock 378 66 -153 minecraft:allium
setblock 386 66 -153 minecraft:cornflower
setblock 388 66 -153 minecraft:poppy
fill 390 66 -153 391 66 -153 minecraft:poppy
setblock 349 66 -152 minecraft:allium
setblock 351 66 -152 minecraft:allium
setblock 354 66 -152 minecraft:dandelion
fill 356 66 -152 359 66 -152 minecraft:cornflower
fill 361 66 -152 363 66 -152 minecraft:poppy
setblock 365 66 -152 minecraft:oxeye_daisy
setblock 372 66 -152 minecraft:orange_tulip
setblock 376 66 -152 minecraft:allium
setblock 378 66 -152 minecraft:allium
fill 385 66 -152 387 66 -152 minecraft:cornflower
setblock 389 66 -152 minecraft:poppy
fill 348 66 -151 351 66 -151 minecraft:allium
fill 352 66 -151 355 66 -151 minecraft:dandelion
fill 356 66 -151 357 66 -151 minecraft:cornflower
setblock 362 66 -151 minecraft:poppy
setblock 364 66 -151 minecraft:oxeye_daisy
setblock 367 66 -151 minecraft:oxeye_daisy
fill 370 66 -151 371 66 -151 minecraft:azure_bluet
setblock 375 66 -151 minecraft:orange_tulip
setblock 376 66 -151 minecraft:allium
setblock 378 66 -151 minecraft:allium
fill 385 66 -151 386 66 -151 minecraft:cornflower
fill 389 66 -151 391 66 -151 minecraft:poppy
setblock 348 66 -150 minecraft:allium
setblock 351 66 -150 minecraft:allium
setblock 354 66 -150 minecraft:dandelion
fill 356 66 -150 359 66 -150 minecraft:cornflower
setblock 361 66 -150 minecraft:poppy
setblock 363 66 -150 minecraft:poppy
fill 364 66 -150 367 66 -150 minecraft:oxeye_daisy
setblock 370 66 -150 minecraft:azure_bluet
fill 372 66 -150 373 66 -150 minecraft:orange_tulip
setblock 375 66 -150 minecraft:orange_tulip
setblock 376 66 -150 minecraft:allium
setblock 378 66 -150 minecraft:allium
fill 384 66 -150 387 66 -150 minecraft:cornflower
fill 388 66 -150 389 66 -150 minecraft:poppy
fill 348 66 -149 350 66 -149 minecraft:allium
fill 352 66 -149 353 66 -149 minecraft:dandelion
setblock 355 66 -149 minecraft:dandelion
setblock 356 66 -149 minecraft:cornflower
setblock 358 66 -149 minecraft:cornflower
fill 360 66 -149 361 66 -149 minecraft:poppy
setblock 363 66 -149 minecraft:poppy
setblock 364 66 -149 minecraft:oxeye_daisy
fill 366 66 -149 367 66 -149 minecraft:oxeye_daisy
setblock 372 66 -149 minecraft:orange_tulip
fill 374 66 -149 375 66 -149 minecraft:orange_tulip
fill 376 66 -149 378 66 -149 minecraft:allium
fill 385 66 -149 386 66 -149 minecraft:cornflower
fill 390 66 -149 391 66 -149 minecraft:poppy
fill 348 66 -148 351 66 -148 minecraft:allium
fill 352 66 -148 354 66 -148 minecraft:dandelion
fill 358 66 -148 359 66 -148 minecraft:cornflower
setblock 360 66 -148 minecraft:poppy
setblock 365 66 -148 minecraft:oxeye_daisy
setblock 369 66 -148 minecraft:azure_bluet
setblock 371 66 -148 minecraft:azure_bluet
fill 373 66 -148 375 66 -148 minecraft:orange_tulip
fill 377 66 -148 378 66 -148 minecraft:allium
fill 385 66 -148 386 66 -148 minecraft:cornflower
fill 390 66 -148 391 66 -148 minecraft:poppy
setblock 348 66 -147 minecraft:allium
setblock 351 66 -147 minecraft:allium
fill 352 66 -147 353 66 -147 minecraft:dandelion
setblock 355 66 -147 minecraft:dandelion
setblock 356 66 -147 minecraft:cornflower
fill 358 66 -147 359 66 -147 minecraft:cornflower
setblock 360 66 -147 minecraft:poppy
setblock 362 66 -147 minecraft:poppy
fill 364 66 -147 367 66 -147 minecraft:oxeye_daisy
setblock 370 66 -147 minecraft:azure_bluet
setblock 373 66 -147 minecraft:orange_tulip
fill 377 66 -147 378 66 -147 minecraft:allium
setblock 387 66 -147 minecraft:cornflower
fill 388 66 -147 389 66 -147 minecraft:poppy
setblock 350 66 -146 minecraft:allium
fill 352 66 -146 353 66 -146 minecraft:dandelion
setblock 355 66 -146 minecraft:dandelion
fill 356 66 -146 359 66 -146 minecraft:cornflower
setblock 360 66 -146 minecraft:poppy
setblock 362 66 -146 minecraft:poppy
fill 364 66 -146 367 66 -146 minecraft:oxeye_daisy
setblock 368 66 -146 minecraft:azure_bluet
fill 370 66 -146 371 66 -146 minecraft:azure_bluet
fill 372 66 -146 375 66 -146 minecraft:orange_tulip
fill 377 66 -146 378 66 -146 minecraft:allium
setblock 384 66 -146 minecraft:cornflower
fill 386 66 -146 387 66 -146 minecraft:cornflower
fill 388 66 -146 389 66 -146 minecraft:poppy
fill 350 66 -145 351 66 -145 minecraft:allium
fill 353 66 -145 355 66 -145 minecraft:dandelion
setblock 356 66 -145 minecraft:cornflower
fill 358 66 -145 359 66 -145 minecraft:cornflower
setblock 360 66 -145 minecraft:poppy
setblock 362 66 -145 minecraft:poppy
setblock 364 66 -145 minecraft:oxeye_daisy
fill 369 66 -145 370 66 -145 minecraft:azure_bluet
setblock 374 66 -145 minecraft:orange_tulip
setblock 384 66 -145 minecraft:cornflower
setblock 387 66 -145 minecraft:cornflower
setblock 388 66 -145 minecraft:poppy
setblock 391 66 -145 minecraft:poppy
setblock 348 66 -144 minecraft:allium
fill 350 66 -144 351 66 -144 minecraft:allium
setblock 355 66 -144 minecraft:dandelion
setblock 356 66 -144 minecraft:cornflower
setblock 358 66 -144 minecraft:cornflower
fill 360 66 -144 363 66 -144 minecraft:poppy
setblock 365 66 -144 minecraft:oxeye_daisy
setblock 367 66 -144 minecraft:oxeye_daisy
setblock 370 66 -144 minecraft:azure_bluet
setblock 372 66 -144 minecraft:orange_tulip
setblock 375 66 -144 minecraft:orange_tulip
fill 376 66 -144 378 66 -144 minecraft:allium
setblock 384 66 -144 minecraft:cornflower
setblock 387 66 -144 minecraft:cornflower
setblock 388 66 -144 minecraft:poppy
setblock 390 66 -144 minecraft:poppy
setblock 349 66 -143 minecraft:allium
setblock 351 66 -143 minecraft:allium
setblock 353 66 -143 minecraft:dandelion
setblock 355 66 -143 minecraft:dandelion
fill 356 66 -143 358 66 -143 minecraft:cornflower
setblock 361 66 -143 minecraft:poppy
fill 365 66 -143 367 66 -143 minecraft:oxeye_daisy
fill 368 66 -143 369 66 -143 minecraft:azure_bluet
setblock 371 66 -143 minecraft:azure_bluet
setblock 372 66 -143 minecraft:orange_tulip
fill 377 66 -143 378 66 -143 minecraft:allium
fill 384 66 -143 385 66 -143 minecraft:cornflower
setblock 389 66 -143 minecraft:poppy
setblock 348 66 -142 minecraft:allium
setblock 351 66 -142 minecraft:allium
fill 354 66 -142 355 66 -142 minecraft:dandelion
fill 357 66 -142 359 66 -142 minecraft:cornflower
fill 360 66 -142 363 66 -142 minecraft:poppy
setblock 364 66 -142 minecraft:oxeye_daisy
setblock 367 66 -142 minecraft:oxeye_daisy
setblock 368 66 -142 minecraft:azure_bluet
fill 372 66 -142 373 66 -142 minecraft:orange_tulip
setblock 375 66 -142 minecraft:orange_tulip
setblock 376 66 -142 minecraft:allium
setblock 378 66 -142 minecraft:allium
fill 384 66 -142 386 66 -142 minecraft:cornflower
setblock 391 66 -142 minecraft:poppy
fill 348 66 -141 349 66 -141 minecraft:allium
setblock 352 66 -141 minecraft:dandelion
fill 356 66 -141 357 66 -141 minecraft:cornflower
setblock 359 66 -141 minecraft:cornflower
fill 360 66 -141 363 66 -141 minecraft:poppy
fill 365 66 -141 367 66 -141 minecraft:oxeye_daisy
fill 369 66 -141 371 66 -141 minecraft:azure_bluet
setblock 373 66 -141 minecraft:orange_tulip
setblock 375 66 -141 minecraft:orange_tulip
fill 377 66 -141 378 66 -141 minecraft:allium
setblock 386 66 -141 minecraft:cornflower
setblock 388 66 -141 minecraft:poppy
fill 390 66 -141 391 66 -141 minecraft:poppy
setblock 348 66 -140 minecraft:allium
fill 350 66 -140 351 66 -140 minecraft:allium
setblock 352 66 -140 minecraft:dandelion
setblock 354 66 -140 minecraft:dandelion
setblock 357 66 -140 minecraft:cornflower
setblock 360 66 -140 minecraft:poppy
setblock 362 66 -140 minecraft:poppy
fill 365 66 -140 367 66 -140 minecraft:oxeye_daisy
setblock 371 66 -140 minecraft:azure_bluet
fill 373 66 -140 374 66 -140 minecraft:orange_tulip
fill 376 66 -140 377 66 -140 minecraft:allium
setblock 384 66 -140 minecraft:cornflower
setblock 387 66 -140 minecraft:cornflower
fill 390 66 -140 391 66 -140 minecraft:poppy
fill 348 66 -139 349 66 -139 minecraft:allium
setblock 351 66 -139 minecraft:allium
setblock 352 66 -139 minecraft:dandelion
fill 354 66 -139 355 66 -139 minecraft:dandelion
fill 356 66 -139 358 66 -139 minecraft:cornflower
setblock 362 66 -139 minecraft:poppy
setblock 364 66 -139 minecraft:oxeye_daisy
setblock 366 66 -139 minecraft:oxeye_daisy
fill 368 66 -139 369 66 -139 minecraft:azure_bluet
setblock 371 66 -139 minecraft:azure_bluet
setblock 375 66 -139 minecraft:orange_tulip
setblock 377 66 -139 minecraft:allium
fill 384 66 -139 387 66 -139 minecraft:cornflower
fill 389 66 -139 391 66 -139 minecraft:poppy
fill 348 66 -138 350 66 -138 minecraft:allium
fill 352 66 -138 354 66 -138 minecraft:dandelion
fill 356 66 -138 357 66 -138 minecraft:cornflower
setblock 359 66 -138 minecraft:cornflower
fill 361 66 -138 362 66 -138 minecraft:poppy
fill 365 66 -138 367 66 -138 minecraft:oxeye_daisy
fill 368 66 -138 369 66 -138 minecraft:azure_bluet
setblock 371 66 -138 minecraft:azure_bluet
fill 372 66 -138 373 66 -138 minecraft:orange_tulip
setblock 375 66 -138 minecraft:orange_tulip
setblock 378 66 -138 minecraft:allium
fill 384 66 -138 387 66 -138 minecraft:cornflower
setblock 390 66 -138 minecraft:poppy
setblock 348 66 -137 minecraft:allium
setblock 352 66 -137 minecraft:dandelion
setblock 355 66 -137 minecraft:dandelion
setblock 356 66 -137 minecraft:cornflower
setblock 358 66 -137 minecraft:cornflower
fill 360 66 -137 362 66 -137 minecraft:poppy
setblock 367 66 -137 minecraft:oxeye_daisy
setblock 369 66 -137 minecraft:azure_bluet
fill 376 66 -137 378 66 -137 minecraft:allium
setblock 384 66 -137 minecraft:cornflower
setblock 386 66 -137 minecraft:cornflower
fill 388 66 -137 391 66 -137 minecraft:poppy
setblock 350 66 -136 minecraft:allium
fill 353 66 -136 355 66 -136 minecraft:dandelion
setblock 356 66 -136 minecraft:cornflower
fill 358 66 -136 359 66 -136 minecraft:cornflower
fill 360 66 -136 363 66 -136 minecraft:poppy
fill 366 66 -136 367 66 -136 minecraft:oxeye_daisy
fill 374 66 -136 375 66 -136 minecraft:orange_tulip
fill 376 66 -136 378 66 -136 minecraft:allium
fill 386 66 -136 387 66 -136 minecraft:cornflower
fill 389 66 -136 391 66 -136 minecraft:poppy
fill 348 66 -135 349 66 -135 minecraft:allium
setblock 351 66 -135 minecraft:allium
fill 352 66 -135 355 66 -135 minecraft:dandelion
setblock 357 66 -135 minecraft:cornflower
setblock 360 66 -135 minecraft:poppy
setblock 363 66 -135 minecraft:poppy
setblock 364 66 -135 minecraft:oxeye_daisy
setblock 366 66 -135 minecraft:oxeye_daisy
setblock 371 66 -135 minecraft:azure_bluet
setblock 373 66 -135 minecraft:orange_tulip
setblock 375 66 -135 minecraft:orange_tulip
fill 376 66 -135 378 66 -135 minecraft:allium
fill 384 66 -135 387 66 -135 minecraft:cornflower
setblock 388 66 -135 minecraft:poppy
setblock 390 66 -135 minecraft:poppy
setblock 348 66 -134 minecraft:allium
setblock 350 66 -134 minecraft:allium
fill 352 66 -134 354 66 -134 minecraft:dandelion
setblock 357 66 -134 minecraft:cornflower
setblock 360 66 -134 minecraft:poppy
setblock 362 66 -134 minecraft:poppy
fill 364 66 -134 367 66 -134 minecraft:oxeye_daisy
setblock 371 66 -134 minecraft:azure_bluet
setblock 372 66 -134 minecraft:orange_tulip
setblock 374 66 -134 minecraft:orange_tulip
fill 376 66 -134 378 66 -134 minecraft:allium
fill 385 66 -134 387 66 -134 minecraft:cornflower
setblock 391 66 -134 minecraft:poppy
setblock 350 66 -133 minecraft:allium
setblock 354 66 -133 minecraft:dandelion
setblock 357 66 -133 minecraft:cornflower
fill 364 66 -133 366 66 -133 minecraft:oxeye_daisy
setblock 369 66 -133 minecraft:azure_bluet
fill 372 66 -133 374 66 -133 minecraft:orange_tulip
fill 388 66 -133 389 66 -133 minecraft:poppy
setblock 391 66 -133 minecraft:poppy
fill 349 66 -132 350 66 -132 minecraft:allium
setblock 352 66 -132 minecraft:dandelion
setblock 355 66 -132 minecraft:dandelion
setblock 356 66 -132 minecraft:cornflower
setblock 358 66 -132 minecraft:cornflower
setblock 361 66 -132 minecraft:poppy
fill 364 66 -132 366 66 -132 minecraft:oxeye_daisy
setblock 369 66 -132 minecraft:azure_bluet
fill 372 66 -132 373 66 -132 minecraft:orange_tulip
setblock 375 66 -132 minecraft:orange_tulip
fill 376 66 -132 378 66 -132 minecraft:allium
fill 388 66 -132 389 66 -132 minecraft:poppy
fill 348 66 -131 350 66 -131 minecraft:allium
setblock 354 66 -131 minecraft:dandelion
fill 357 66 -131 359 66 -131 minecraft:cornflower
setblock 362 66 -131 minecraft:poppy
setblock 367 66 -131 minecraft:oxeye_daisy
setblock 368 66 -131 minecraft:azure_bluet
fill 370 66 -131 371 66 -131 minecraft:azure_bluet
fill 373 66 -131 374 66 -131 minecraft:orange_tulip
setblock 376 66 -131 minecraft:allium
setblock 378 66 -131 minecraft:allium
fill 384 66 -131 386 66 -131 minecraft:cornflower
fill 388 66 -131 391 66 -131 minecraft:poppy
fill 349 66 -130 351 66 -130 minecraft:allium
fill 353 66 -130 355 66 -130 minecraft:dandelion
setblock 356 66 -130 minecraft:cornflower
fill 358 66 -130 359 66 -130 minecraft:cornflower
setblock 360 66 -130 minecraft:poppy
setblock 362 66 -130 minecraft:poppy
fill 364 66 -130 365 66 -130 minecraft:oxeye_daisy
setblock 367 66 -130 minecraft:oxeye_daisy
setblock 370 66 -130 minecraft:azure_bluet
setblock 373 66 -130 minecraft:orange_tulip
fill 377 66 -130 378 66 -130 minecraft:allium
setblock 384 66 -130 minecraft:cornflower
fill 386 66 -130 387 66 -130 minecraft:cornflower
setblock 388 66 -130 minecraft:poppy
setblock 391 66 -130 minecraft:poppy
setblock 348 66 -129 minecraft:allium
setblock 351 66 -129 minecraft:allium
fill 353 66 -129 355 66 -129 minecraft:dandelion
setblock 356 66 -129 minecraft:cornflower
setblock 359 66 -129 minecraft:cornflower
fill 361 66 -129 362 66 -129 minecraft:poppy
fill 364 66 -129 366 66 -129 minecraft:oxeye_daisy
fill 368 66 -129 370 66 -129 minecraft:azure_bluet
fill 373 66 -129 374 66 -129 minecraft:orange_tulip
fill 376 66 -129 378 66 -129 minecraft:allium
setblock 384 66 -129 minecraft:cornflower
setblock 386 66 -129 minecraft:cornflower
fill 390 66 -129 391 66 -129 minecraft:poppy
setblock 349 66 -128 minecraft:allium
setblock 353 66 -128 minecraft:dandelion
fill 356 66 -128 357 66 -128 minecraft:cornflower
fill 364 66 -128 365 66 -128 minecraft:oxeye_daisy
setblock 367 66 -128 minecraft:oxeye_daisy
setblock 368 66 -128 minecraft:azure_bluet
setblock 372 66 -128 minecraft:orange_tulip
setblock 378 66 -128 minecraft:allium
fill 384 66 -128 385 66 -128 minecraft:cornflower
setblock 387 66 -128 minecraft:cornflower
fill 388 66 -128 391 66 -128 minecraft:poppy
fill 349 66 -127 351 66 -127 minecraft:allium
setblock 354 66 -127 minecraft:dandelion
setblock 356 66 -127 minecraft:cornflower
fill 358 66 -127 359 66 -127 minecraft:cornflower
fill 360 66 -127 362 66 -127 minecraft:poppy
fill 364 66 -127 365 66 -127 minecraft:oxeye_daisy
setblock 367 66 -127 minecraft:oxeye_daisy
fill 369 66 -127 371 66 -127 minecraft:azure_bluet
setblock 376 66 -127 minecraft:allium
setblock 378 66 -127 minecraft:allium
fill 384 66 -127 385 66 -127 minecraft:cornflower
setblock 388 66 -127 minecraft:poppy
setblock 332 69 -128 minecraft:oak_leaves[persistent=true]
setblock 342 69 -128 minecraft:oak_leaves[persistent=true]
fill 331 69 -127 333 69 -127 minecraft:oak_leaves[persistent=true]
fill 341 69 -127 343 69 -127 minecraft:oak_leaves[persistent=true]
fill 331 70 -128 333 70 -128 minecraft:oak_leaves[persistent=true]
fill 341 70 -128 343 70 -128 minecraft:oak_leaves[persistent=true]
fill 330 70 -127 334 70 -127 minecraft:oak_leaves[persistent=true]
fill 340 70 -127 344 70 -127 minecraft:oak_leaves[persistent=true]
setblock 332 71 -128 minecraft:oak_leaves[persistent=true]
setblock 342 71 -128 minecraft:oak_leaves[persistent=true]
fill 331 71 -127 333 71 -127 minecraft:oak_leaves[persistent=true]
fill 341 71 -127 343 71 -127 minecraft:oak_leaves[persistent=true]
setblock 331 85 -189 minecraft:sea_lantern
setblock 330 85 -186 minecraft:sea_lantern
setblock 329 85 -184 minecraft:sea_lantern
forceload remove 328 -190 391 -127
tellraw @a {"text":"Campus bau a34 fertig.","color":"green"}
