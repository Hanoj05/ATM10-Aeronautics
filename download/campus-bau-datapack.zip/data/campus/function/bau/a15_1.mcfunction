fill 24 45 -312 26 45 -312 minecraft:stone
fill 24 45 -311 27 45 -311 minecraft:stone
fill 25 45 -310 28 45 -310 minecraft:stone
fill 26 45 -309 28 45 -309 minecraft:stone
fill 69 45 -302 70 45 -302 minecraft:stone
fill 68 45 -301 71 45 -301 minecraft:stone
fill 68 45 -300 71 45 -300 minecraft:stone
fill 67 45 -299 71 45 -299 minecraft:stone
fill 67 45 -298 71 45 -298 minecraft:stone
fill 67 45 -297 71 45 -297 minecraft:stone
fill 69 45 -296 71 45 -296 minecraft:stone
fill 70 45 -295 71 45 -295 minecraft:stone
setblock 71 45 -294 minecraft:stone
setblock 71 45 -288 minecraft:stone
setblock 71 45 -287 minecraft:stone
setblock 25 46 -312 minecraft:stone
fill 23 46 -311 26 46 -311 minecraft:stone
fill 24 46 -310 27 46 -310 minecraft:stone
fill 25 46 -309 28 46 -309 minecraft:stone
fill 26 46 -308 27 46 -308 minecraft:stone
fill 68 46 -300 69 46 -300 minecraft:stone
fill 68 46 -299 71 46 -299 minecraft:stone
fill 67 46 -298 71 46 -298 minecraft:stone
fill 67 46 -297 71 46 -297 minecraft:stone
fill 67 46 -296 71 46 -296 minecraft:stone
fill 68 46 -295 71 46 -295 minecraft:stone
fill 69 46 -294 71 46 -294 minecraft:stone
setblock 70 46 -293 minecraft:stone
setblock 71 46 -288 minecraft:stone
setblock 71 46 -287 minecraft:stone
setblock 71 46 -286 minecraft:stone
fill 29 46 -265 30 46 -265 minecraft:stone
fill 29 46 -264 30 46 -264 minecraft:stone
setblock 49 46 -263 minecraft:stone
fill 48 46 -262 50 46 -262 minecraft:stone
setblock 50 46 -259 minecraft:stone
setblock 50 46 -258 minecraft:stone
fill 24 47 -311 25 47 -311 minecraft:stone
fill 23 47 -310 26 47 -310 minecraft:stone
fill 24 47 -309 27 47 -309 minecraft:stone
fill 25 47 -308 29 47 -308 minecraft:stone
setblock 26 47 -307 minecraft:stone
fill 68 47 -298 69 47 -298 minecraft:stone
fill 67 47 -297 71 47 -297 minecraft:stone
fill 67 47 -296 71 47 -296 minecraft:stone
fill 67 47 -295 71 47 -295 minecraft:stone
fill 67 47 -294 71 47 -294 minecraft:stone
fill 69 47 -293 71 47 -293 minecraft:stone
setblock 70 47 -292 minecraft:stone
setblock 69 47 -288 minecraft:stone
fill 52 47 -266 56 47 -266 minecraft:stone
fill 49 47 -265 57 47 -265 minecraft:stone
fill 48 47 -264 58 47 -264 minecraft:stone
fill 48 47 -263 59 47 -263 minecraft:stone
fill 47 47 -262 59 47 -262 minecraft:stone
fill 48 47 -261 59 47 -261 minecraft:stone
fill 49 47 -260 58 47 -260 minecraft:stone
fill 49 47 -259 55 47 -259 minecraft:stone
fill 49 47 -258 54 47 -258 minecraft:stone
fill 49 47 -257 51 47 -257 minecraft:stone
fill 49 47 -256 51 47 -256 minecraft:stone
fill 65 48 -318 66 48 -318 minecraft:stone
setblock 25 48 -311 minecraft:stone
fill 23 48 -310 26 48 -310 minecraft:stone
fill 24 48 -309 27 48 -309 minecraft:stone
fill 24 48 -308 28 48 -308 minecraft:stone
fill 25 48 -307 28 48 -307 minecraft:stone
setblock 26 48 -306 minecraft:stone
setblock 68 48 -297 minecraft:stone
fill 67 48 -296 70 48 -296 minecraft:stone
fill 67 48 -295 71 48 -295 minecraft:stone
fill 67 48 -294 71 48 -294 minecraft:stone
fill 67 48 -293 71 48 -293 minecraft:stone
fill 69 48 -292 71 48 -292 minecraft:stone
fill 70 48 -291 71 48 -291 minecraft:stone
fill 70 48 -290 71 48 -290 minecraft:stone
fill 68 48 -289 71 48 -289 minecraft:stone
fill 68 48 -288 71 48 -288 minecraft:stone
fill 69 48 -287 70 48 -287 minecraft:stone
setblock 70 48 -286 minecraft:stone
fill 52 48 -267 55 48 -267 minecraft:stone
fill 49 48 -266 57 48 -266 minecraft:stone
fill 48 48 -265 57 48 -265 minecraft:stone
fill 47 48 -264 59 48 -264 minecraft:stone
fill 47 48 -263 59 48 -263 minecraft:stone
fill 47 48 -262 59 48 -262 minecraft:stone
fill 47 48 -261 59 48 -261 minecraft:stone
fill 48 48 -260 59 48 -260 minecraft:stone
fill 48 48 -259 58 48 -259 minecraft:stone
fill 48 48 -258 55 48 -258 minecraft:stone
fill 48 48 -257 53 48 -257 minecraft:stone
fill 49 48 -256 51 48 -256 minecraft:stone
fill 49 48 -255 50 48 -255 minecraft:stone
fill 65 49 -318 66 49 -318 minecraft:stone
fill 57 49 -314 58 49 -314 minecraft:stone
fill 57 49 -313 58 49 -313 minecraft:stone
fill 24 49 -310 26 49 -310 minecraft:stone
fill 24 49 -309 27 49 -309 minecraft:stone
fill 24 49 -308 28 49 -308 minecraft:stone
fill 25 49 -307 29 49 -307 minecraft:stone
setblock 26 49 -306 minecraft:stone
fill 67 49 -296 68 49 -296 minecraft:stone
fill 67 49 -295 70 49 -295 minecraft:stone
fill 67 49 -294 71 49 -294 minecraft:stone
fill 67 49 -293 71 49 -293 minecraft:stone
fill 68 49 -292 71 49 -292 minecraft:stone
fill 69 49 -291 71 49 -291 minecraft:stone
fill 70 49 -290 71 49 -290 minecraft:stone
setblock 71 49 -289 minecraft:stone
fill 70 49 -288 71 49 -288 minecraft:stone
fill 52 49 -266 56 49 -266 minecraft:stone
fill 51 49 -265 56 49 -265 minecraft:stone
fill 50 49 -264 58 49 -264 minecraft:stone
fill 48 49 -263 59 49 -263 minecraft:stone
fill 47 49 -262 59 49 -262 minecraft:stone
fill 48 49 -261 59 49 -261 minecraft:stone
fill 48 49 -260 58 49 -260 minecraft:stone
fill 48 49 -259 55 49 -259 minecraft:stone
fill 48 49 -258 55 49 -258 minecraft:stone
fill 49 49 -257 51 49 -257 minecraft:stone
fill 49 49 -256 51 49 -256 minecraft:stone
setblock 50 49 -255 minecraft:stone
fill 25 50 -310 26 50 -310 minecraft:stone
fill 24 50 -309 27 50 -309 minecraft:stone
fill 24 50 -308 28 50 -308 minecraft:stone
fill 25 50 -307 29 50 -307 minecraft:stone
fill 26 50 -306 28 50 -306 minecraft:stone
setblock 71 50 -296 minecraft:stone
fill 68 50 -295 69 50 -295 minecraft:stone
setblock 71 50 -295 minecraft:stone
fill 67 50 -294 71 50 -294 minecraft:stone
fill 67 50 -293 71 50 -293 minecraft:stone
fill 66 50 -292 71 50 -292 minecraft:stone
fill 68 50 -291 71 50 -291 minecraft:stone
fill 69 50 -290 71 50 -290 minecraft:stone
fill 70 50 -289 71 50 -289 minecraft:stone
setblock 71 50 -288 minecraft:stone
setblock 71 50 -287 minecraft:stone
setblock 71 50 -269 minecraft:stone
setblock 49 50 -263 minecraft:stone
fill 48 50 -262 50 50 -262 minecraft:stone
setblock 50 50 -261 minecraft:stone
fill 49 50 -260 51 50 -260 minecraft:stone
fill 49 50 -259 51 50 -259 minecraft:stone
fill 49 50 -258 51 50 -258 minecraft:stone
fill 49 50 -257 50 50 -257 minecraft:stone
setblock 63 50 -257 minecraft:stone
setblock 62 50 -256 minecraft:stone
fill 61 50 -255 62 50 -255 minecraft:stone
setblock 26 51 -310 minecraft:stone
fill 24 51 -309 27 51 -309 minecraft:stone
fill 24 51 -308 28 51 -308 minecraft:stone
fill 25 51 -307 29 51 -307 minecraft:stone
fill 26 51 -306 29 51 -306 minecraft:stone
setblock 26 51 -305 minecraft:stone
setblock 71 51 -297 minecraft:stone
fill 70 51 -296 71 51 -296 minecraft:stone
fill 70 51 -295 71 51 -295 minecraft:stone
fill 67 51 -294 69 51 -294 minecraft:stone
setblock 71 51 -294 minecraft:stone
fill 67 51 -293 71 51 -293 minecraft:stone
fill 66 51 -292 71 51 -292 minecraft:stone
fill 67 51 -291 71 51 -291 minecraft:stone
fill 69 51 -290 71 51 -290 minecraft:stone
fill 70 51 -289 71 51 -289 minecraft:stone
setblock 71 51 -288 minecraft:stone
setblock 71 51 -287 minecraft:stone
setblock 71 51 -269 minecraft:stone
setblock 71 51 -268 minecraft:stone
setblock 70 51 -267 minecraft:stone
setblock 70 51 -266 minecraft:stone
setblock 69 51 -265 minecraft:stone
setblock 68 51 -263 minecraft:stone
setblock 67 51 -262 minecraft:stone
fill 66 51 -261 67 51 -261 minecraft:stone
setblock 66 51 -260 minecraft:stone
fill 65 51 -259 66 51 -259 minecraft:stone
fill 64 51 -258 65 51 -258 minecraft:stone
fill 63 51 -257 65 51 -257 minecraft:stone
fill 62 51 -256 64 51 -256 minecraft:stone
fill 61 51 -255 63 51 -255 minecraft:stone
fill 24 52 -309 27 52 -309 minecraft:stone
fill 24 52 -308 28 52 -308 minecraft:stone
fill 25 52 -307 29 52 -307 minecraft:stone
fill 26 52 -306 30 52 -306 minecraft:stone
fill 26 52 -305 27 52 -305 minecraft:stone
setblock 71 52 -298 minecraft:stone
setblock 71 52 -295 minecraft:stone
fill 67 52 -294 69 52 -294 minecraft:stone
fill 67 52 -293 71 52 -293 minecraft:stone
fill 67 52 -292 71 52 -292 minecraft:stone
fill 67 52 -291 71 52 -291 minecraft:stone
fill 68 52 -290 71 52 -290 minecraft:stone
fill 69 52 -289 71 52 -289 minecraft:stone
fill 70 52 -288 71 52 -288 minecraft:stone
setblock 71 52 -287 minecraft:stone
setblock 71 52 -286 minecraft:stone
setblock 71 52 -270 minecraft:stone
setblock 71 52 -269 minecraft:stone
fill 70 52 -268 71 52 -268 minecraft:stone
fill 70 52 -267 71 52 -267 minecraft:stone
fill 69 52 -266 70 52 -266 minecraft:stone
fill 69 52 -265 70 52 -265 minecraft:stone
fill 68 52 -264 69 52 -264 minecraft:stone
fill 67 52 -263 69 52 -263 minecraft:stone
fill 67 52 -262 68 52 -262 minecraft:stone
fill 66 52 -261 68 52 -261 minecraft:stone
fill 65 52 -260 67 52 -260 minecraft:stone
fill 64 52 -259 67 52 -259 minecraft:stone
fill 63 52 -258 66 52 -258 minecraft:stone
fill 62 52 -257 66 52 -257 minecraft:stone
fill 61 52 -256 65 52 -256 minecraft:stone
fill 61 52 -255 64 52 -255 minecraft:stone
fill 17 53 -318 20 53 -318 minecraft:stone
fill 23 53 -318 26 53 -318 minecraft:stone
fill 23 53 -317 26 53 -317 minecraft:stone
fill 23 53 -316 26 53 -316 minecraft:stone
fill 23 53 -315 25 53 -315 minecraft:stone
fill 23 53 -314 25 53 -314 minecraft:stone
fill 24 53 -313 25 53 -313 minecraft:stone
fill 26 53 -309 27 53 -309 minecraft:stone
fill 24 53 -308 28 53 -308 minecraft:stone
fill 25 53 -307 28 53 -307 minecraft:stone
fill 26 53 -306 29 53 -306 minecraft:stone
fill 26 53 -305 29 53 -305 minecraft:stone
fill 68 53 -296 69 53 -296 minecraft:stone
setblock 68 53 -295 minecraft:stone
fill 70 53 -295 71 53 -295 minecraft:stone
fill 69 53 -294 71 53 -294 minecraft:stone
fill 67 53 -293 71 53 -293 minecraft:stone
fill 67 53 -292 71 53 -292 minecraft:stone
fill 67 53 -291 71 53 -291 minecraft:stone
fill 67 53 -290 71 53 -290 minecraft:stone
fill 68 53 -289 71 53 -289 minecraft:stone
fill 70 53 -288 71 53 -288 minecraft:stone
fill 70 53 -287 71 53 -287 minecraft:stone
setblock 71 53 -286 minecraft:stone
setblock 71 53 -271 minecraft:stone
setblock 71 53 -270 minecraft:stone
fill 70 53 -269 71 53 -269 minecraft:stone
fill 70 53 -268 71 53 -268 minecraft:stone
fill 70 53 -267 71 53 -267 minecraft:stone
fill 69 53 -266 71 53 -266 minecraft:stone
fill 68 53 -265 71 53 -265 minecraft:stone
fill 68 53 -264 70 53 -264 minecraft:stone
fill 67 53 -263 70 53 -263 minecraft:stone
fill 66 53 -262 69 53 -262 minecraft:stone
fill 66 53 -261 68 53 -261 minecraft:stone
fill 65 53 -260 68 53 -260 minecraft:stone
fill 64 53 -259 67 53 -259 minecraft:stone
fill 64 53 -258 66 53 -258 minecraft:stone
fill 64 53 -257 65 53 -257 minecraft:stone
fill 63 53 -256 65 53 -256 minecraft:stone
fill 63 53 -255 64 53 -255 minecraft:stone
fill 17 54 -318 26 54 -318 minecraft:stone
fill 42 54 -318 43 54 -318 minecraft:stone
fill 22 54 -317 26 54 -317 minecraft:stone
fill 42 54 -317 43 54 -317 minecraft:stone
fill 23 54 -316 26 54 -316 minecraft:stone
fill 23 54 -315 26 54 -315 minecraft:stone
fill 23 54 -314 26 54 -314 minecraft:stone
fill 23 54 -313 26 54 -313 minecraft:stone
fill 22 54 -312 26 54 -312 minecraft:stone
fill 22 54 -311 25 54 -311 minecraft:stone
fill 22 54 -310 25 54 -310 minecraft:stone
fill 22 54 -309 23 54 -309 minecraft:stone
fill 24 54 -308 28 54 -308 minecraft:stone
fill 25 54 -307 28 54 -307 minecraft:stone
fill 49 54 -307 50 54 -307 minecraft:stone
fill 26 54 -306 29 54 -306 minecraft:stone
fill 49 54 -306 51 54 -306 minecraft:stone
fill 26 54 -305 29 54 -305 minecraft:stone
fill 49 54 -305 52 54 -305 minecraft:stone
fill 50 54 -304 53 54 -304 minecraft:stone
fill 51 54 -303 52 54 -303 minecraft:stone
fill 69 54 -297 70 54 -297 minecraft:stone
fill 67 54 -296 71 54 -296 minecraft:stone
fill 68 54 -295 71 54 -295 minecraft:stone
fill 69 54 -294 71 54 -294 minecraft:stone
fill 67 54 -293 71 54 -293 minecraft:stone
fill 67 54 -292 71 54 -292 minecraft:stone
fill 67 54 -291 71 54 -291 minecraft:stone
fill 67 54 -290 71 54 -290 minecraft:stone
fill 67 54 -289 71 54 -289 minecraft:stone
fill 69 54 -288 71 54 -288 minecraft:stone
fill 70 54 -287 71 54 -287 minecraft:stone
setblock 71 54 -286 minecraft:stone
setblock 71 54 -272 minecraft:stone
setblock 71 54 -271 minecraft:stone
setblock 71 54 -270 minecraft:stone
fill 70 54 -269 71 54 -269 minecraft:stone
fill 70 54 -268 71 54 -268 minecraft:stone
fill 69 54 -267 71 54 -267 minecraft:stone
fill 69 54 -266 71 54 -266 minecraft:stone
fill 68 54 -265 70 54 -265 minecraft:stone
fill 67 54 -264 70 54 -264 minecraft:stone
fill 67 54 -263 69 54 -263 minecraft:stone
fill 67 54 -262 69 54 -262 minecraft:stone
fill 66 54 -261 68 54 -261 minecraft:stone
fill 66 54 -260 67 54 -260 minecraft:stone
fill 66 54 -259 67 54 -259 minecraft:stone
setblock 66 54 -258 minecraft:stone
setblock 65 54 -257 minecraft:stone
fill 17 55 -318 26 55 -318 minecraft:stone
fill 41 55 -318 45 55 -318 minecraft:stone
fill 18 55 -317 26 55 -317 minecraft:stone
fill 41 55 -317 45 55 -317 minecraft:stone
fill 22 55 -316 26 55 -316 minecraft:stone
fill 42 55 -316 45 55 -316 minecraft:stone
fill 22 55 -315 26 55 -315 minecraft:stone
fill 42 55 -315 46 55 -315 minecraft:stone
fill 22 55 -314 26 55 -314 minecraft:stone
fill 42 55 -314 46 55 -314 minecraft:stone
fill 22 55 -313 26 55 -313 minecraft:stone
fill 43 55 -313 45 55 -313 minecraft:stone
fill 22 55 -312 26 55 -312 minecraft:stone
fill 22 55 -311 26 55 -311 minecraft:stone
fill 21 55 -310 25 55 -310 minecraft:stone
fill 46 55 -310 49 55 -310 minecraft:stone
fill 21 55 -309 24 55 -309 minecraft:stone
fill 46 55 -309 50 55 -309 minecraft:stone
fill 21 55 -308 23 55 -308 minecraft:stone
fill 25 55 -308 28 55 -308 minecraft:stone
fill 47 55 -308 51 55 -308 minecraft:stone
setblock 22 55 -307 minecraft:stone
fill 25 55 -307 28 55 -307 minecraft:stone
fill 47 55 -307 51 55 -307 minecraft:stone
fill 26 55 -306 29 55 -306 minecraft:stone
fill 48 55 -306 52 55 -306 minecraft:stone
fill 26 55 -305 29 55 -305 minecraft:stone
fill 48 55 -305 54 55 -305 minecraft:stone
setblock 27 55 -304 minecraft:stone
fill 49 55 -304 56 55 -304 minecraft:stone
fill 50 55 -303 56 55 -303 minecraft:stone
fill 51 55 -302 56 55 -302 minecraft:stone
setblock 70 55 -299 minecraft:stone
fill 69 55 -298 71 55 -298 minecraft:stone
fill 68 55 -297 71 55 -297 minecraft:stone
fill 67 55 -296 71 55 -296 minecraft:stone
fill 68 55 -295 71 55 -295 minecraft:stone
fill 69 55 -294 71 55 -294 minecraft:stone
fill 69 55 -293 71 55 -293 minecraft:stone
fill 67 55 -292 71 55 -292 minecraft:stone
fill 67 55 -291 71 55 -291 minecraft:stone
fill 67 55 -290 71 55 -290 minecraft:stone
fill 67 55 -289 71 55 -289 minecraft:stone
fill 68 55 -288 71 55 -288 minecraft:stone
fill 69 55 -287 71 55 -287 minecraft:stone
fill 70 55 -286 71 55 -286 minecraft:stone
setblock 71 55 -273 minecraft:stone
setblock 71 55 -272 minecraft:stone
setblock 71 55 -271 minecraft:stone
fill 70 55 -270 71 55 -270 minecraft:stone
fill 70 55 -269 71 55 -269 minecraft:stone
fill 69 55 -268 71 55 -268 minecraft:stone
fill 69 55 -267 71 55 -267 minecraft:stone
fill 69 55 -266 71 55 -266 minecraft:stone
fill 68 55 -265 70 55 -265 minecraft:stone
fill 68 55 -264 70 55 -264 minecraft:stone
fill 68 55 -263 69 55 -263 minecraft:stone
setblock 68 55 -262 minecraft:stone
setblock 68 55 -261 minecraft:stone
setblock 67 55 -260 minecraft:stone
fill 17 56 -318 26 56 -318 minecraft:stone
fill 41 56 -318 45 56 -318 minecraft:stone
fill 18 56 -317 26 56 -317 minecraft:stone
fill 41 56 -317 45 56 -317 minecraft:stone
fill 19 56 -316 26 56 -316 minecraft:stone
fill 41 56 -316 46 56 -316 minecraft:stone
fill 21 56 -315 26 56 -315 minecraft:stone
fill 41 56 -315 46 56 -315 minecraft:stone
fill 23 56 -314 26 56 -314 minecraft:stone
fill 42 56 -314 46 56 -314 minecraft:stone
fill 23 56 -313 26 56 -313 minecraft:stone
setblock 43 56 -313 minecraft:stone
setblock 48 56 -313 minecraft:stone
fill 22 56 -312 26 56 -312 minecraft:stone
setblock 48 56 -312 minecraft:stone
fill 21 56 -311 25 56 -311 minecraft:stone
fill 48 56 -311 49 56 -311 minecraft:stone
fill 21 56 -310 25 56 -310 minecraft:stone
fill 45 56 -310 50 56 -310 minecraft:stone
fill 20 56 -309 24 56 -309 minecraft:stone
fill 45 56 -309 50 56 -309 minecraft:stone
fill 20 56 -308 24 56 -308 minecraft:stone
setblock 28 56 -308 minecraft:stone
fill 46 56 -308 51 56 -308 minecraft:stone
fill 20 56 -307 23 56 -307 minecraft:stone
fill 25 56 -307 28 56 -307 minecraft:stone
fill 47 56 -307 51 56 -307 minecraft:stone
fill 21 56 -306 22 56 -306 minecraft:stone
fill 25 56 -306 29 56 -306 minecraft:stone
fill 47 56 -306 53 56 -306 minecraft:stone
fill 26 56 -305 28 56 -305 minecraft:stone
fill 48 56 -305 57 56 -305 minecraft:stone
fill 48 56 -304 58 56 -304 minecraft:stone
fill 49 56 -303 58 56 -303 minecraft:stone
fill 51 56 -302 57 56 -302 minecraft:stone
fill 54 56 -301 56 56 -301 minecraft:stone
setblock 71 56 -300 minecraft:stone
fill 70 56 -299 71 56 -299 minecraft:stone
fill 69 56 -298 71 56 -298 minecraft:stone
fill 68 56 -297 71 56 -297 minecraft:stone
fill 67 56 -296 71 56 -296 minecraft:stone
fill 68 56 -295 71 56 -295 minecraft:stone
fill 68 56 -294 71 56 -294 minecraft:stone
fill 69 56 -293 71 56 -293 minecraft:stone
setblock 8 56 -292 minecraft:stone
setblock 67 56 -292 minecraft:stone
fill 70 56 -292 71 56 -292 minecraft:stone
setblock 8 56 -291 minecraft:stone
fill 67 56 -291 71 56 -291 minecraft:stone
fill 67 56 -290 71 56 -290 minecraft:stone
fill 67 56 -289 71 56 -289 minecraft:stone
fill 67 56 -288 71 56 -288 minecraft:stone
fill 69 56 -287 71 56 -287 minecraft:stone
fill 70 56 -286 71 56 -286 minecraft:stone
setblock 71 56 -285 minecraft:stone
setblock 71 56 -284 minecraft:stone
setblock 71 56 -274 minecraft:stone
setblock 71 56 -273 minecraft:dirt
setblock 71 56 -272 minecraft:dirt
fill 70 56 -271 71 56 -271 minecraft:dirt
fill 70 56 -270 71 56 -270 minecraft:dirt
fill 70 56 -269 71 56 -269 minecraft:dirt
fill 70 56 -268 71 56 -268 minecraft:dirt
fill 70 56 -267 71 56 -267 minecraft:dirt
setblock 70 56 -266 minecraft:dirt
fill 69 56 -265 70 56 -265 minecraft:dirt
setblock 69 56 -264 minecraft:dirt
setblock 69 56 -263 minecraft:dirt
fill 17 57 -318 24 57 -318 minecraft:stone
fill 41 57 -318 45 57 -318 minecraft:stone
fill 18 57 -317 24 57 -317 minecraft:stone
fill 41 57 -317 45 57 -317 minecraft:stone
fill 19 57 -316 24 57 -316 minecraft:stone
fill 41 57 -316 46 57 -316 minecraft:stone
fill 20 57 -315 23 57 -315 minecraft:stone
fill 42 57 -315 46 57 -315 minecraft:stone
setblock 24 57 -314 minecraft:stone
fill 42 57 -314 45 57 -314 minecraft:stone
fill 24 57 -313 25 57 -313 minecraft:stone
setblock 48 57 -313 minecraft:stone
fill 23 57 -312 24 57 -312 minecraft:stone
fill 47 57 -312 48 57 -312 minecraft:stone
fill 22 57 -311 24 57 -311 minecraft:stone
fill 45 57 -311 49 57 -311 minecraft:stone
fill 21 57 -310 24 57 -310 minecraft:stone
fill 45 57 -310 50 57 -310 minecraft:stone
fill 20 57 -309 24 57 -309 minecraft:stone
fill 45 57 -309 50 57 -309 minecraft:stone
fill 20 57 -308 23 57 -308 minecraft:stone
setblock 28 57 -308 minecraft:stone
fill 46 57 -308 51 57 -308 minecraft:stone
fill 19 57 -307 23 57 -307 minecraft:stone
fill 25 57 -307 29 57 -307 minecraft:stone
fill 47 57 -307 51 57 -307 minecraft:stone
fill 58 57 -307 59 57 -307 minecraft:stone
fill 18 57 -306 22 57 -306 minecraft:stone
fill 26 57 -306 28 57 -306 minecraft:stone
fill 47 57 -306 52 57 -306 minecraft:stone
fill 57 57 -306 59 57 -306 minecraft:stone
fill 18 57 -305 21 57 -305 minecraft:stone
setblock 31 57 -305 minecraft:stone
fill 48 57 -305 59 57 -305 minecraft:stone
fill 49 57 -304 59 57 -304 minecraft:stone
fill 50 57 -303 59 57 -303 minecraft:stone
fill 51 57 -302 58 57 -302 minecraft:stone
fill 54 57 -301 57 57 -301 minecraft:stone
setblock 71 57 -300 minecraft:stone
fill 70 57 -299 71 57 -299 minecraft:stone
fill 69 57 -298 71 57 -298 minecraft:stone
fill 68 57 -297 71 57 -297 minecraft:stone
fill 67 57 -296 71 57 -296 minecraft:stone
fill 68 57 -295 71 57 -295 minecraft:stone
fill 8 57 -294 9 57 -294 minecraft:stone
fill 69 57 -294 71 57 -294 minecraft:stone
fill 8 57 -293 10 57 -293 minecraft:stone
fill 70 57 -293 71 57 -293 minecraft:stone
fill 8 57 -292 11 57 -292 minecraft:stone
setblock 71 57 -292 minecraft:stone
fill 8 57 -291 11 57 -291 minecraft:stone
fill 67 57 -291 69 57 -291 minecraft:stone
fill 8 57 -290 10 57 -290 minecraft:stone
fill 67 57 -290 71 57 -290 minecraft:stone
fill 8 57 -289 9 57 -289 minecraft:stone
fill 67 57 -289 71 57 -289 minecraft:stone
fill 67 57 -288 71 57 -288 minecraft:stone
fill 68 57 -287 71 57 -287 minecraft:stone
fill 69 57 -286 71 57 -286 minecraft:stone
fill 70 57 -285 71 57 -285 minecraft:stone
setblock 71 57 -284 minecraft:stone
setblock 71 57 -283 minecraft:stone
setblock 71 57 -275 minecraft:stone
setblock 71 57 -274 minecraft:stone
setblock 71 57 -273 minecraft:dirt
setblock 71 57 -272 minecraft:dirt
setblock 71 57 -271 minecraft:dirt
setblock 71 57 -270 minecraft:dirt
setblock 71 57 -269 minecraft:dirt
setblock 71 57 -268 minecraft:dirt
setblock 71 57 -267 minecraft:dirt
setblock 70 57 -266 minecraft:dirt
setblock 70 57 -265 minecraft:dirt
fill 18 58 -318 25 58 -318 minecraft:stone
fill 41 58 -318 45 58 -318 minecraft:stone
fill 56 58 -318 57 58 -318 minecraft:stone
fill 18 58 -317 25 58 -317 minecraft:stone
fill 42 58 -317 44 58 -317 minecraft:stone
fill 19 58 -316 25 58 -316 minecraft:stone
fill 42 58 -316 45 58 -316 minecraft:stone
fill 19 58 -315 25 58 -315 minecraft:stone
fill 42 58 -315 45 58 -315 minecraft:stone
fill 21 58 -314 25 58 -314 minecraft:stone
fill 43 58 -314 44 58 -314 minecraft:stone
setblock 47 58 -314 minecraft:stone
setblock 23 58 -313 minecraft:stone
setblock 47 58 -313 minecraft:stone
fill 47 58 -312 48 58 -312 minecraft:stone
fill 44 58 -311 45 58 -311 minecraft:stone
fill 47 58 -311 49 58 -311 minecraft:stone
fill 58 58 -311 59 58 -311 minecraft:stone
fill 45 58 -310 49 58 -310 minecraft:stone
fill 57 58 -310 60 58 -310 minecraft:stone
fill 20 58 -309 23 58 -309 minecraft:stone
fill 46 58 -309 50 58 -309 minecraft:stone
fill 57 58 -309 60 58 -309 minecraft:stone
fill 19 58 -308 23 58 -308 minecraft:stone
fill 47 58 -308 50 58 -308 minecraft:stone
fill 57 58 -308 60 58 -308 minecraft:stone
fill 18 58 -307 23 58 -307 minecraft:stone
fill 26 58 -307 27 58 -307 minecraft:stone
fill 48 58 -307 50 58 -307 minecraft:stone
fill 57 58 -307 60 58 -307 minecraft:stone
fill 16 58 -306 22 58 -306 minecraft:stone
setblock 31 58 -306 minecraft:stone
fill 48 58 -306 51 58 -306 minecraft:stone
fill 56 58 -306 60 58 -306 minecraft:stone
fill 8 58 -305 11 58 -305 minecraft:stone
fill 14 58 -305 21 58 -305 minecraft:stone
fill 30 58 -305 32 58 -305 minecraft:stone
fill 49 58 -305 52 58 -305 minecraft:stone
fill 55 58 -305 60 58 -305 minecraft:stone
fill 8 58 -304 11 58 -304 minecraft:stone
fill 14 58 -304 18 58 -304 minecraft:stone
fill 50 58 -304 60 58 -304 minecraft:stone
fill 8 58 -303 12 58 -303 minecraft:stone
fill 14 58 -303 15 58 -303 minecraft:stone
fill 51 58 -303 59 58 -303 minecraft:stone
fill 53 58 -302 58 58 -302 minecraft:stone
fill 55 58 -301 57 58 -301 minecraft:stone
setblock 71 58 -300 minecraft:stone
fill 70 58 -299 71 58 -299 minecraft:stone
fill 69 58 -298 71 58 -298 minecraft:stone
fill 68 58 -297 71 58 -297 minecraft:stone
fill 68 58 -296 71 58 -296 minecraft:stone
fill 8 58 -295 9 58 -295 minecraft:stone
fill 69 58 -295 71 58 -295 minecraft:stone
fill 8 58 -294 12 58 -294 minecraft:stone
fill 70 58 -294 71 58 -294 minecraft:stone
fill 8 58 -293 13 58 -293 minecraft:stone
setblock 71 58 -293 minecraft:stone
fill 8 58 -292 13 58 -292 minecraft:stone
fill 8 58 -291 13 58 -291 minecraft:stone
setblock 68 58 -291 minecraft:stone
fill 8 58 -290 13 58 -290 minecraft:stone
fill 68 58 -290 70 58 -290 minecraft:stone
fill 8 58 -289 11 58 -289 minecraft:stone
fill 68 58 -289 71 58 -289 minecraft:stone
fill 8 58 -288 9 58 -288 minecraft:stone
fill 68 58 -288 71 58 -288 minecraft:stone
fill 68 58 -287 71 58 -287 minecraft:stone
fill 68 58 -286 71 58 -286 minecraft:stone
fill 69 58 -285 71 58 -285 minecraft:stone
fill 70 58 -284 71 58 -284 minecraft:stone
setblock 71 58 -283 minecraft:stone
setblock 27 58 -282 minecraft:stone
setblock 71 58 -282 minecraft:stone
setblock 71 58 -281 minecraft:stone
setblock 71 58 -277 minecraft:stone
setblock 71 58 -276 minecraft:stone
setblock 71 58 -275 minecraft:stone
setblock 71 58 -274 minecraft:stone
setblock 71 58 -273 minecraft:dirt
setblock 71 58 -272 minecraft:dirt
setblock 71 58 -271 minecraft:dirt
setblock 71 58 -270 minecraft:dirt
setblock 71 58 -269 minecraft:dirt
setblock 71 58 -268 minecraft:dirt
fill 18 59 -318 25 59 -318 minecraft:stone
fill 40 59 -318 45 59 -318 minecraft:stone
fill 55 59 -318 58 59 -318 minecraft:stone
fill 18 59 -317 26 59 -317 minecraft:stone
fill 41 59 -317 44 59 -317 minecraft:stone
fill 55 59 -317 58 59 -317 minecraft:stone
fill 19 59 -316 26 59 -316 minecraft:stone
fill 56 59 -316 58 59 -316 minecraft:stone
fill 20 59 -315 26 59 -315 minecraft:stone
fill 56 59 -315 59 59 -315 minecraft:stone
fill 20 59 -314 26 59 -314 minecraft:stone
fill 56 59 -314 59 59 -314 minecraft:stone
fill 22 59 -313 25 59 -313 minecraft:stone
setblock 46 59 -313 minecraft:stone
fill 57 59 -313 59 59 -313 minecraft:stone
setblock 46 59 -312 minecraft:stone
fill 57 59 -312 60 59 -312 minecraft:stone
fill 46 59 -311 47 59 -311 minecraft:stone
fill 57 59 -311 60 59 -311 minecraft:stone
setblock 47 59 -310 minecraft:stone
fill 57 59 -310 60 59 -310 minecraft:stone
fill 57 59 -309 60 59 -309 minecraft:stone
fill 20 59 -308 21 59 -308 minecraft:stone
setblock 30 59 -308 minecraft:stone
fill 57 59 -308 60 59 -308 minecraft:stone
fill 17 59 -307 21 59 -307 minecraft:stone
fill 29 59 -307 31 59 -307 minecraft:stone
fill 57 59 -307 60 59 -307 minecraft:stone
fill 15 59 -306 21 59 -306 minecraft:stone
fill 30 59 -306 32 59 -306 minecraft:stone
fill 56 59 -306 60 59 -306 minecraft:stone
fill 8 59 -305 11 59 -305 minecraft:stone
fill 14 59 -305 18 59 -305 minecraft:stone
fill 30 59 -305 32 59 -305 minecraft:stone
fill 56 59 -305 60 59 -305 minecraft:stone
fill 8 59 -304 11 59 -304 minecraft:stone
fill 14 59 -304 15 59 -304 minecraft:stone
fill 29 59 -304 30 59 -304 minecraft:stone
fill 56 59 -304 60 59 -304 minecraft:stone
fill 8 59 -303 12 59 -303 minecraft:stone
fill 55 59 -303 59 59 -303 minecraft:stone
setblock 12 59 -302 minecraft:stone
fill 56 59 -302 58 59 -302 minecraft:stone
setblock 71 59 -300 minecraft:stone
fill 70 59 -299 71 59 -299 minecraft:stone
fill 69 59 -298 71 59 -298 minecraft:stone
fill 69 59 -297 71 59 -297 minecraft:stone
fill 68 59 -296 71 59 -296 minecraft:stone
fill 8 59 -295 15 59 -295 minecraft:stone
fill 70 59 -295 71 59 -295 minecraft:stone
fill 8 59 -294 16 59 -294 minecraft:stone
setblock 71 59 -294 minecraft:stone
fill 8 59 -293 16 59 -293 minecraft:stone
fill 8 59 -292 16 59 -292 minecraft:stone
fill 8 59 -291 15 59 -291 minecraft:stone
fill 8 59 -290 14 59 -290 minecraft:stone
fill 68 59 -290 69 59 -290 minecraft:stone
fill 8 59 -289 13 59 -289 minecraft:stone
fill 68 59 -289 71 59 -289 minecraft:stone
fill 8 59 -288 11 59 -288 minecraft:stone
fill 68 59 -288 71 59 -288 minecraft:stone
fill 68 59 -287 71 59 -287 minecraft:stone
fill 68 59 -286 71 59 -286 minecraft:stone
fill 69 59 -285 71 59 -285 minecraft:stone
fill 70 59 -284 71 59 -284 minecraft:stone
fill 70 59 -283 71 59 -283 minecraft:stone
fill 27 59 -282 71 59 -282 minecraft:stone
fill 27 59 -281 71 59 -281 minecraft:stone
fill 27 59 -280 71 59 -280 minecraft:stone
fill 27 59 -279 71 59 -279 minecraft:stone
fill 27 59 -278 71 59 -278 minecraft:stone
fill 27 59 -277 71 59 -277 minecraft:stone
fill 27 59 -276 71 59 -276 minecraft:stone
fill 27 59 -275 71 59 -275 minecraft:stone
fill 27 59 -274 71 59 -274 minecraft:stone
fill 27 59 -273 70 59 -273 minecraft:stone
fill 27 59 -272 67 59 -272 minecraft:stone
fill 27 59 -271 65 59 -271 minecraft:stone
fill 27 59 -270 63 59 -270 minecraft:stone
fill 27 59 -269 61 59 -269 minecraft:stone
fill 27 59 -268 59 59 -268 minecraft:stone
fill 27 59 -267 57 59 -267 minecraft:stone
fill 27 59 -266 56 59 -266 minecraft:stone
fill 27 59 -265 54 59 -265 minecraft:stone
fill 27 59 -264 53 59 -264 minecraft:stone
fill 27 59 -263 52 59 -263 minecraft:stone
fill 27 59 -262 28 59 -262 minecraft:stone
fill 30 59 -262 51 59 -262 minecraft:stone
fill 27 59 -261 50 59 -261 minecraft:stone
fill 27 59 -260 49 59 -260 minecraft:stone
fill 27 59 -259 48 59 -259 minecraft:stone
fill 27 59 -258 47 59 -258 minecraft:stone
fill 27 59 -257 46 59 -257 minecraft:stone
fill 27 59 -256 45 59 -256 minecraft:stone
fill 27 59 -255 44 59 -255 minecraft:stone
fill 19 60 -318 25 60 -318 minecraft:stone
fill 55 60 -318 58 60 -318 minecraft:stone
fill 19 60 -317 26 60 -317 minecraft:stone
fill 55 60 -317 58 60 -317 minecraft:stone
fill 19 60 -316 26 60 -316 minecraft:stone
fill 55 60 -316 59 60 -316 minecraft:stone
fill 20 60 -315 26 60 -315 minecraft:stone
fill 56 60 -315 59 60 -315 minecraft:stone
fill 20 60 -314 25 60 -314 minecraft:stone
fill 56 60 -314 59 60 -314 minecraft:stone
fill 21 60 -313 24 60 -313 minecraft:stone
fill 57 60 -313 60 60 -313 minecraft:stone
fill 57 60 -312 60 60 -312 minecraft:stone
fill 57 60 -311 60 60 -311 minecraft:stone
fill 57 60 -310 60 60 -310 minecraft:stone
fill 57 60 -309 60 60 -309 minecraft:stone
fill 57 60 -308 60 60 -308 minecraft:stone
setblock 19 60 -307 minecraft:stone
fill 29 60 -307 32 60 -307 minecraft:stone
fill 57 60 -307 59 60 -307 minecraft:stone
fill 16 60 -306 17 60 -306 minecraft:stone
fill 30 60 -306 32 60 -306 minecraft:stone
fill 57 60 -306 60 60 -306 minecraft:stone
fill 8 60 -305 10 60 -305 minecraft:stone
setblock 14 60 -305 minecraft:stone
fill 30 60 -305 33 60 -305 minecraft:stone
fill 57 60 -305 59 60 -305 minecraft:stone
fill 8 60 -304 11 60 -304 minecraft:stone
fill 29 60 -304 30 60 -304 minecraft:stone
fill 57 60 -304 59 60 -304 minecraft:stone
fill 8 60 -303 12 60 -303 minecraft:stone
fill 57 60 -303 58 60 -303 minecraft:stone
setblock 71 60 -300 minecraft:stone
fill 70 60 -299 71 60 -299 minecraft:stone
fill 70 60 -298 71 60 -298 minecraft:stone
fill 70 60 -297 71 60 -297 minecraft:stone
fill 12 60 -296 16 60 -296 minecraft:stone
fill 70 60 -296 71 60 -296 minecraft:stone
fill 8 60 -295 18 60 -295 minecraft:stone
fill 8 60 -294 18 60 -294 minecraft:stone
fill 8 60 -293 18 60 -293 minecraft:stone
fill 8 60 -292 18 60 -292 minecraft:stone
fill 8 60 -291 17 60 -291 minecraft:stone
fill 8 60 -290 16 60 -290 minecraft:stone
setblock 68 60 -290 minecraft:stone
fill 8 60 -289 13 60 -289 minecraft:stone
fill 68 60 -289 71 60 -289 minecraft:stone
fill 8 60 -288 12 60 -288 minecraft:stone
fill 68 60 -288 71 60 -288 minecraft:stone
fill 68 60 -287 71 60 -287 minecraft:stone
fill 69 60 -286 71 60 -286 minecraft:stone
fill 69 60 -285 71 60 -285 minecraft:stone
fill 69 60 -284 71 60 -284 minecraft:stone
fill 52 60 -283 71 60 -283 minecraft:stone
fill 27 60 -282 71 60 -282 minecraft:stone
fill 27 60 -281 71 60 -281 minecraft:stone
fill 27 60 -280 71 60 -280 minecraft:stone
fill 27 60 -279 71 60 -279 minecraft:stone
fill 27 60 -278 71 60 -278 minecraft:stone
fill 27 60 -277 71 60 -277 minecraft:stone
fill 27 60 -276 71 60 -276 minecraft:stone
fill 27 60 -275 71 60 -275 minecraft:stone
fill 27 60 -274 71 60 -274 minecraft:stone
fill 27 60 -273 70 60 -273 minecraft:stone
fill 27 60 -272 67 60 -272 minecraft:stone
fill 27 60 -271 65 60 -271 minecraft:stone
fill 27 60 -270 63 60 -270 minecraft:stone
fill 27 60 -269 61 60 -269 minecraft:stone
fill 27 60 -268 59 60 -268 minecraft:stone
fill 27 60 -267 57 60 -267 minecraft:stone
fill 27 60 -266 56 60 -266 minecraft:stone
fill 27 60 -265 54 60 -265 minecraft:stone
fill 27 60 -264 53 60 -264 minecraft:stone
fill 27 60 -263 52 60 -263 minecraft:stone
fill 27 60 -262 51 60 -262 minecraft:stone
fill 27 60 -261 50 60 -261 minecraft:stone
fill 27 60 -260 49 60 -260 minecraft:stone
fill 27 60 -259 48 60 -259 minecraft:stone
fill 27 60 -258 47 60 -258 minecraft:stone
fill 27 60 -257 46 60 -257 minecraft:stone
fill 27 60 -256 45 60 -256 minecraft:stone
fill 27 60 -255 44 60 -255 minecraft:stone
fill 20 61 -318 26 61 -318 minecraft:stone
fill 35 61 -318 42 61 -318 minecraft:stone
fill 55 61 -318 58 61 -318 minecraft:stone
fill 20 61 -317 26 61 -317 minecraft:stone
fill 34 61 -317 43 61 -317 minecraft:stone
fill 56 61 -317 58 61 -317 minecraft:stone
fill 20 61 -316 26 61 -316 minecraft:stone
fill 34 61 -316 41 61 -316 minecraft:stone
fill 56 61 -316 58 61 -316 minecraft:stone
fill 20 61 -315 26 61 -315 minecraft:stone
fill 34 61 -315 37 61 -315 minecraft:stone
setblock 39 61 -315 minecraft:stone
fill 56 61 -315 59 61 -315 minecraft:stone
fill 21 61 -314 25 61 -314 minecraft:stone
setblock 36 61 -314 minecraft:stone
fill 56 61 -314 59 61 -314 minecraft:stone
fill 21 61 -313 25 61 -313 minecraft:stone
fill 57 61 -313 59 61 -313 minecraft:stone
fill 23 61 -312 24 61 -312 minecraft:stone
fill 57 61 -312 60 61 -312 minecraft:stone
fill 57 61 -311 59 61 -311 minecraft:stone
fill 57 61 -310 60 61 -310 minecraft:stone
fill 58 61 -309 59 61 -309 minecraft:stone
fill 58 61 -308 59 61 -308 minecraft:stone
fill 28 61 -307 32 61 -307 minecraft:stone
fill 29 61 -306 33 61 -306 minecraft:stone
fill 29 61 -305 34 61 -305 minecraft:stone
fill 30 61 -304 31 61 -304 minecraft:stone
fill 68 61 -304 71 61 -304 minecraft:stone
fill 68 61 -303 69 61 -303 minecraft:stone
setblock 71 61 -303 minecraft:stone
fill 68 61 -302 71 61 -302 minecraft:stone
fill 68 61 -301 71 61 -301 minecraft:stone
fill 68 61 -300 71 61 -300 minecraft:stone
fill 14 61 -297 17 61 -297 minecraft:stone
fill 11 61 -296 19 61 -296 minecraft:stone
fill 10 61 -295 20 61 -295 minecraft:stone
fill 8 61 -294 20 61 -294 minecraft:stone
fill 8 61 -293 21 61 -293 minecraft:stone
fill 8 61 -292 21 61 -292 minecraft:stone
fill 8 61 -291 20 61 -291 minecraft:stone
fill 8 61 -290 19 61 -290 minecraft:stone
fill 8 61 -289 14 61 -289 minecraft:stone
fill 68 61 -289 70 61 -289 minecraft:stone
fill 68 61 -288 71 61 -288 minecraft:stone
fill 69 61 -287 71 61 -287 minecraft:stone
fill 69 61 -286 71 61 -286 minecraft:stone
fill 69 61 -285 71 61 -285 minecraft:stone
fill 70 61 -284 71 61 -284 minecraft:stone
fill 52 61 -283 71 61 -283 minecraft:stone
fill 27 61 -282 71 61 -282 minecraft:stone
fill 27 61 -281 71 61 -281 minecraft:stone
fill 27 61 -280 71 61 -280 minecraft:stone
fill 27 61 -279 71 61 -279 minecraft:stone
fill 27 61 -278 71 61 -278 minecraft:stone
fill 27 61 -277 71 61 -277 minecraft:stone
fill 27 61 -276 71 61 -276 minecraft:stone
fill 27 61 -275 71 61 -275 minecraft:stone
fill 27 61 -274 71 61 -274 minecraft:stone
fill 27 61 -273 70 61 -273 minecraft:stone
fill 27 61 -272 67 61 -272 minecraft:stone
fill 27 61 -271 65 61 -271 minecraft:stone
fill 27 61 -270 63 61 -270 minecraft:stone
fill 27 61 -269 61 61 -269 minecraft:stone
fill 27 61 -268 59 61 -268 minecraft:stone
fill 27 61 -267 57 61 -267 minecraft:stone
fill 27 61 -266 56 61 -266 minecraft:stone
fill 27 61 -265 54 61 -265 minecraft:stone
fill 27 61 -264 53 61 -264 minecraft:stone
fill 27 61 -263 52 61 -263 minecraft:stone
fill 27 61 -262 51 61 -262 minecraft:stone
fill 27 61 -261 50 61 -261 minecraft:stone
fill 27 61 -260 49 61 -260 minecraft:stone
fill 27 61 -259 48 61 -259 minecraft:stone
fill 27 61 -258 47 61 -258 minecraft:stone
fill 27 61 -257 46 61 -257 minecraft:stone
fill 27 61 -256 45 61 -256 minecraft:stone
fill 27 61 -255 44 61 -255 minecraft:stone
fill 22 62 -318 25 62 -318 minecraft:dirt
fill 33 62 -318 42 62 -318 minecraft:dirt
fill 21 62 -317 26 62 -317 minecraft:dirt
fill 32 62 -317 41 62 -317 minecraft:dirt
fill 21 62 -316 26 62 -316 minecraft:dirt
fill 32 62 -316 40 62 -316 minecraft:dirt
fill 21 62 -315 25 62 -315 minecraft:dirt
fill 32 62 -315 38 62 -315 minecraft:dirt
fill 21 62 -314 25 62 -314 minecraft:dirt
fill 33 62 -314 37 62 -314 minecraft:dirt
setblock 58 62 -314 minecraft:dirt
fill 22 62 -313 24 62 -313 minecraft:dirt
fill 23 62 -312 24 62 -312 minecraft:dirt
fill 27 62 -307 33 62 -307 minecraft:dirt
fill 24 62 -306 34 62 -306 minecraft:dirt
fill 23 62 -305 34 62 -305 minecraft:dirt
fill 67 62 -305 70 62 -305 minecraft:dirt
fill 23 62 -304 35 62 -304 minecraft:dirt
fill 66 62 -304 71 62 -304 minecraft:dirt
fill 23 62 -303 35 62 -303 minecraft:dirt
fill 67 62 -303 69 62 -303 minecraft:dirt
setblock 71 62 -303 minecraft:dirt
fill 31 62 -302 35 62 -302 minecraft:dirt
fill 67 62 -302 71 62 -302 minecraft:dirt
fill 32 62 -301 35 62 -301 minecraft:dirt
fill 67 62 -301 71 62 -301 minecraft:dirt
fill 68 62 -300 71 62 -300 minecraft:dirt
setblock 68 62 -299 minecraft:dirt
fill 14 62 -297 18 62 -297 minecraft:dirt
fill 12 62 -296 20 62 -296 minecraft:dirt
fill 11 62 -295 21 62 -295 minecraft:dirt
fill 10 62 -294 22 62 -294 minecraft:dirt
fill 9 62 -293 22 62 -293 minecraft:dirt
fill 9 62 -292 22 62 -292 minecraft:dirt
fill 9 62 -291 22 62 -291 minecraft:dirt
fill 9 62 -290 22 62 -290 minecraft:dirt
fill 18 62 -289 20 62 -289 minecraft:dirt
fill 69 62 -288 71 62 -288 minecraft:dirt
fill 69 62 -287 71 62 -287 minecraft:dirt
fill 69 62 -286 71 62 -286 minecraft:dirt
fill 70 62 -285 71 62 -285 minecraft:dirt
fill 70 62 -284 71 62 -284 minecraft:dirt
fill 52 62 -283 71 62 -283 minecraft:dirt
fill 27 62 -282 71 62 -282 minecraft:dirt
fill 27 62 -281 71 62 -281 minecraft:dirt
fill 27 62 -280 71 62 -280 minecraft:dirt
fill 27 62 -279 71 62 -279 minecraft:dirt
fill 27 62 -278 71 62 -278 minecraft:dirt
fill 27 62 -277 71 62 -277 minecraft:dirt
fill 27 62 -276 71 62 -276 minecraft:dirt
fill 27 62 -275 71 62 -275 minecraft:dirt
fill 27 62 -274 71 62 -274 minecraft:dirt
fill 27 62 -273 70 62 -273 minecraft:dirt
fill 27 62 -272 67 62 -272 minecraft:dirt
fill 27 62 -271 65 62 -271 minecraft:dirt
fill 27 62 -270 63 62 -270 minecraft:dirt
fill 27 62 -269 61 62 -269 minecraft:dirt
fill 27 62 -268 59 62 -268 minecraft:dirt
fill 27 62 -267 57 62 -267 minecraft:dirt
fill 27 62 -266 56 62 -266 minecraft:dirt
fill 27 62 -265 54 62 -265 minecraft:dirt
fill 27 62 -264 53 62 -264 minecraft:dirt
fill 27 62 -263 52 62 -263 minecraft:dirt
fill 27 62 -262 51 62 -262 minecraft:dirt
fill 27 62 -261 50 62 -261 minecraft:dirt
fill 27 62 -260 49 62 -260 minecraft:dirt
fill 27 62 -259 48 62 -259 minecraft:dirt
fill 27 62 -258 47 62 -258 minecraft:dirt
fill 27 62 -257 46 62 -257 minecraft:dirt
fill 27 62 -256 45 62 -256 minecraft:dirt
fill 27 62 -255 44 62 -255 minecraft:dirt
fill 22 63 -318 26 63 -318 minecraft:dirt
fill 31 63 -318 40 63 -318 minecraft:dirt
fill 21 63 -317 26 63 -317 minecraft:dirt
fill 30 63 -317 40 63 -317 minecraft:dirt
fill 21 63 -316 25 63 -316 minecraft:dirt
fill 30 63 -316 38 63 -316 minecraft:dirt
fill 21 63 -315 25 63 -315 minecraft:dirt
setblock 27 63 -315 minecraft:dirt
fill 31 63 -315 38 63 -315 minecraft:dirt
fill 21 63 -314 27 63 -314 minecraft:dirt
fill 32 63 -314 37 63 -314 minecraft:dirt
fill 22 63 -313 26 63 -313 minecraft:dirt
setblock 34 63 -313 minecraft:dirt
fill 23 63 -312 25 63 -312 minecraft:dirt
fill 20 63 -307 21 63 -307 minecraft:dirt
fill 24 63 -307 34 63 -307 minecraft:dirt
setblock 68 63 -307 minecraft:dirt
fill 19 63 -306 34 63 -306 minecraft:dirt
fill 67 63 -306 70 63 -306 minecraft:dirt
fill 19 63 -305 35 63 -305 minecraft:dirt
fill 66 63 -305 71 63 -305 minecraft:dirt
fill 19 63 -304 35 63 -304 minecraft:dirt
fill 65 63 -304 71 63 -304 minecraft:dirt
fill 20 63 -303 35 63 -303 minecraft:dirt
fill 65 63 -303 69 63 -303 minecraft:dirt
setblock 71 63 -303 minecraft:dirt
fill 22 63 -302 27 63 -302 minecraft:dirt
fill 30 63 -302 36 63 -302 minecraft:dirt
fill 66 63 -302 71 63 -302 minecraft:dirt
fill 32 63 -301 36 63 -301 minecraft:dirt
fill 67 63 -301 71 63 -301 minecraft:dirt
fill 33 63 -300 37 63 -300 minecraft:dirt
fill 67 63 -300 71 63 -300 minecraft:dirt
fill 35 63 -299 37 63 -299 minecraft:dirt
setblock 68 63 -299 minecraft:dirt
fill 35 63 -298 37 63 -298 minecraft:dirt
fill 15 63 -297 18 63 -297 minecraft:dirt
fill 13 63 -296 20 63 -296 minecraft:dirt
fill 12 63 -295 22 63 -295 minecraft:dirt
fill 11 63 -294 23 63 -294 minecraft:dirt
fill 11 63 -293 23 63 -293 minecraft:dirt
fill 11 63 -292 24 63 -292 minecraft:dirt
fill 12 63 -291 24 63 -291 minecraft:dirt
fill 13 63 -290 24 63 -290 minecraft:dirt
fill 17 63 -289 23 63 -289 minecraft:dirt
setblock 21 63 -288 minecraft:dirt
fill 69 63 -288 70 63 -288 minecraft:dirt
fill 69 63 -287 71 63 -287 minecraft:dirt
fill 70 63 -286 71 63 -286 minecraft:dirt
fill 70 63 -285 71 63 -285 minecraft:dirt
fill 70 63 -284 71 63 -284 minecraft:dirt
fill 52 63 -283 71 63 -283 minecraft:dirt
fill 27 63 -282 71 63 -282 minecraft:dirt
fill 27 63 -281 71 63 -281 minecraft:dirt
fill 27 63 -280 71 63 -280 minecraft:dirt
fill 27 63 -279 71 63 -279 minecraft:dirt
fill 27 63 -278 71 63 -278 minecraft:dirt
fill 27 63 -277 71 63 -277 minecraft:dirt
fill 27 63 -276 71 63 -276 minecraft:dirt
fill 27 63 -275 71 63 -275 minecraft:dirt
fill 27 63 -274 71 63 -274 minecraft:dirt
fill 27 63 -273 70 63 -273 minecraft:dirt
fill 27 63 -272 67 63 -272 minecraft:dirt
fill 27 63 -271 65 63 -271 minecraft:dirt
fill 27 63 -270 63 63 -270 minecraft:dirt
fill 27 63 -269 61 63 -269 minecraft:dirt
fill 27 63 -268 59 63 -268 minecraft:dirt
fill 27 63 -267 57 63 -267 minecraft:dirt
fill 27 63 -266 56 63 -266 minecraft:dirt
fill 27 63 -265 54 63 -265 minecraft:dirt
fill 27 63 -264 53 63 -264 minecraft:dirt
fill 27 63 -263 52 63 -263 minecraft:dirt
fill 27 63 -262 51 63 -262 minecraft:dirt
fill 27 63 -261 50 63 -261 minecraft:dirt
fill 27 63 -260 49 63 -260 minecraft:dirt
fill 27 63 -259 48 63 -259 minecraft:dirt
fill 27 63 -258 47 63 -258 minecraft:dirt
fill 27 63 -257 46 63 -257 minecraft:dirt
fill 27 63 -256 45 63 -256 minecraft:dirt
fill 27 63 -255 44 63 -255 minecraft:dirt
fill 21 64 -318 37 64 -318 minecraft:dirt
fill 20 64 -317 38 64 -317 minecraft:dirt
fill 19 64 -316 38 64 -316 minecraft:dirt
fill 18 64 -315 27 64 -315 minecraft:dirt
fill 29 64 -315 38 64 -315 minecraft:dirt
fill 17 64 -314 26 64 -314 minecraft:dirt
fill 31 64 -314 37 64 -314 minecraft:dirt
fill 16 64 -313 26 64 -313 minecraft:dirt
fill 33 64 -313 34 64 -313 minecraft:dirt
fill 15 64 -312 22 64 -312 minecraft:dirt
setblock 24 64 -312 minecraft:dirt
fill 15 64 -311 20 64 -311 minecraft:dirt
fill 14 64 -310 19 64 -310 minecraft:dirt
fill 14 64 -309 19 64 -309 minecraft:dirt
fill 15 64 -308 19 64 -308 minecraft:dirt
fill 67 64 -308 69 64 -308 minecraft:dirt
fill 15 64 -307 27 64 -307 minecraft:dirt
fill 30 64 -307 34 64 -307 minecraft:dirt
fill 66 64 -307 70 64 -307 minecraft:dirt
fill 15 64 -306 35 64 -306 minecraft:dirt
fill 65 64 -306 71 64 -306 minecraft:dirt
fill 15 64 -305 35 64 -305 minecraft:dirt
fill 64 64 -305 71 64 -305 minecraft:dirt
fill 16 64 -304 35 64 -304 minecraft:dirt
setblock 63 64 -304 minecraft:dirt
fill 65 64 -304 71 64 -304 minecraft:dirt
fill 18 64 -303 35 64 -303 minecraft:dirt
fill 64 64 -303 69 64 -303 minecraft:dirt
setblock 71 64 -303 minecraft:dirt
fill 20 64 -302 26 64 -302 minecraft:dirt
fill 31 64 -302 35 64 -302 minecraft:dirt
fill 65 64 -302 71 64 -302 minecraft:dirt
fill 32 64 -301 37 64 -301 minecraft:dirt
fill 66 64 -301 71 64 -301 minecraft:dirt
fill 34 64 -300 38 64 -300 minecraft:dirt
fill 66 64 -300 70 64 -300 minecraft:dirt
fill 34 64 -299 38 64 -299 minecraft:dirt
fill 68 64 -299 69 64 -299 minecraft:dirt
fill 35 64 -298 38 64 -298 minecraft:dirt
fill 36 64 -297 37 64 -297 minecraft:dirt
fill 15 64 -296 21 64 -296 minecraft:dirt
fill 14 64 -295 22 64 -295 minecraft:dirt
fill 13 64 -294 23 64 -294 minecraft:dirt
fill 13 64 -293 24 64 -293 minecraft:dirt
fill 13 64 -292 25 64 -292 minecraft:dirt
fill 14 64 -291 25 64 -291 minecraft:dirt
fill 16 64 -290 25 64 -290 minecraft:dirt
fill 17 64 -289 24 64 -289 minecraft:dirt
fill 19 64 -288 24 64 -288 minecraft:dirt
setblock 69 64 -288 minecraft:dirt
setblock 8 64 -287 minecraft:dirt
fill 70 64 -287 71 64 -287 minecraft:dirt
setblock 8 64 -286 minecraft:dirt
fill 70 64 -286 71 64 -286 minecraft:dirt
setblock 8 64 -285 minecraft:dirt
fill 70 64 -285 71 64 -285 minecraft:dirt
setblock 8 64 -284 minecraft:dirt
setblock 71 64 -284 minecraft:dirt
fill 52 64 -283 71 64 -283 minecraft:dirt
fill 27 64 -282 71 64 -282 minecraft:dirt
fill 27 64 -281 71 64 -281 minecraft:dirt
fill 27 64 -280 71 64 -280 minecraft:dirt
fill 27 64 -279 71 64 -279 minecraft:dirt
fill 27 64 -278 71 64 -278 minecraft:dirt
fill 27 64 -277 71 64 -277 minecraft:dirt
fill 27 64 -276 71 64 -276 minecraft:dirt
fill 27 64 -275 71 64 -275 minecraft:dirt
fill 27 64 -274 71 64 -274 minecraft:dirt
fill 27 64 -273 70 64 -273 minecraft:dirt
fill 27 64 -272 67 64 -272 minecraft:dirt
fill 27 64 -271 65 64 -271 minecraft:dirt
fill 69 64 -271 71 64 -271 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -270 63 64 -270 minecraft:dirt
fill 67 64 -270 71 64 -270 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -269 61 64 -269 minecraft:dirt
fill 64 64 -269 71 64 -269 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -268 59 64 -268 minecraft:dirt
fill 63 64 -268 71 64 -268 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -267 57 64 -267 minecraft:dirt
fill 61 64 -267 68 64 -267 minecraft:smooth_quartz_slab[type=top]
fill 70 64 -267 71 64 -267 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -266 56 64 -266 minecraft:dirt
fill 59 64 -266 62 64 -266 minecraft:smooth_quartz_slab[type=top]
fill 64 64 -266 67 64 -266 minecraft:smooth_quartz_slab[type=top]
fill 69 64 -266 71 64 -266 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -265 54 64 -265 minecraft:dirt
fill 58 64 -265 71 64 -265 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -264 53 64 -264 minecraft:dirt
fill 56 64 -264 71 64 -264 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -263 52 64 -263 minecraft:dirt
fill 55 64 -263 71 64 -263 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -262 51 64 -262 minecraft:dirt
fill 54 64 -262 71 64 -262 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -261 50 64 -261 minecraft:dirt
fill 54 64 -261 57 64 -261 minecraft:smooth_quartz_slab[type=top]
fill 59 64 -261 62 64 -261 minecraft:smooth_quartz_slab[type=top]
fill 64 64 -261 67 64 -261 minecraft:smooth_quartz_slab[type=top]
fill 69 64 -261 71 64 -261 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -260 49 64 -260 minecraft:dirt
fill 52 64 -260 56 64 -260 minecraft:smooth_quartz_slab[type=top]
fill 58 64 -260 71 64 -260 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -259 48 64 -259 minecraft:dirt
fill 51 64 -259 71 64 -259 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -258 47 64 -258 minecraft:dirt
fill 50 64 -258 71 64 -258 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -257 46 64 -257 minecraft:dirt
fill 49 64 -257 65 64 -257 minecraft:smooth_quartz_slab[type=top]
fill 67 64 -257 71 64 -257 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -256 45 64 -256 minecraft:dirt
fill 49 64 -256 52 64 -256 minecraft:smooth_quartz_slab[type=top]
fill 54 64 -256 57 64 -256 minecraft:smooth_quartz_slab[type=top]
fill 59 64 -256 62 64 -256 minecraft:smooth_quartz_slab[type=top]
fill 64 64 -256 67 64 -256 minecraft:smooth_quartz_slab[type=top]
fill 69 64 -256 71 64 -256 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -255 44 64 -255 minecraft:dirt
fill 47 64 -255 71 64 -255 minecraft:smooth_quartz_slab[type=top]
fill 8 65 -318 11 65 -318 minecraft:light_gray_concrete
setblock 12 65 -318 minecraft:sea_lantern
setblock 13 65 -318 minecraft:smooth_quartz
fill 14 65 -318 55 65 -318 minecraft:grass_block
fill 60 65 -318 71 65 -318 minecraft:grass_block
fill 8 65 -317 10 65 -317 minecraft:light_gray_concrete
setblock 11 65 -317 minecraft:sea_lantern
setblock 12 65 -317 minecraft:light_gray_concrete
setblock 13 65 -317 minecraft:smooth_quartz
fill 14 65 -317 55 65 -317 minecraft:grass_block
fill 61 65 -317 71 65 -317 minecraft:grass_block
fill 8 65 -316 9 65 -316 minecraft:light_gray_concrete
setblock 10 65 -316 minecraft:sea_lantern
fill 11 65 -316 12 65 -316 minecraft:light_gray_concrete
setblock 13 65 -316 minecraft:smooth_quartz
fill 14 65 -316 55 65 -316 minecraft:grass_block
fill 61 65 -316 71 65 -316 minecraft:grass_block
setblock 8 65 -315 minecraft:light_gray_concrete
setblock 9 65 -315 minecraft:sea_lantern
fill 10 65 -315 12 65 -315 minecraft:light_gray_concrete
setblock 13 65 -315 minecraft:smooth_quartz
fill 14 65 -315 56 65 -315 minecraft:grass_block
fill 61 65 -315 71 65 -315 minecraft:grass_block
fill 8 65 -314 12 65 -314 minecraft:light_gray_concrete
setblock 13 65 -314 minecraft:smooth_quartz
fill 14 65 -314 56 65 -314 minecraft:grass_block
fill 62 65 -314 71 65 -314 minecraft:grass_block
fill 8 65 -313 12 65 -313 minecraft:light_gray_concrete
setblock 13 65 -313 minecraft:smooth_quartz
fill 14 65 -313 57 65 -313 minecraft:grass_block
fill 62 65 -313 71 65 -313 minecraft:grass_block
fill 8 65 -312 12 65 -312 minecraft:light_gray_concrete
setblock 13 65 -312 minecraft:smooth_quartz
fill 14 65 -312 57 65 -312 minecraft:grass_block
fill 63 65 -312 71 65 -312 minecraft:grass_block
fill 8 65 -311 12 65 -311 minecraft:light_gray_concrete
setblock 13 65 -311 minecraft:smooth_quartz
fill 14 65 -311 58 65 -311 minecraft:grass_block
fill 63 65 -311 71 65 -311 minecraft:grass_block
fill 8 65 -310 12 65 -310 minecraft:light_gray_concrete
setblock 13 65 -310 minecraft:smooth_quartz
fill 14 65 -310 59 65 -310 minecraft:grass_block
fill 63 65 -310 71 65 -310 minecraft:grass_block
fill 8 65 -309 11 65 -309 minecraft:light_gray_concrete
setblock 12 65 -309 minecraft:sea_lantern
setblock 13 65 -309 minecraft:smooth_quartz
fill 14 65 -309 60 65 -309 minecraft:grass_block
setblock 62 65 -309 minecraft:grass_block
fill 64 65 -309 71 65 -309 minecraft:grass_block
fill 8 65 -308 10 65 -308 minecraft:light_gray_concrete
setblock 11 65 -308 minecraft:sea_lantern
setblock 12 65 -308 minecraft:light_gray_concrete
setblock 13 65 -308 minecraft:smooth_quartz
fill 14 65 -308 31 65 -308 minecraft:grass_block
setblock 34 65 -308 minecraft:grass_block
fill 36 65 -308 61 65 -308 minecraft:grass_block
fill 65 65 -308 71 65 -308 minecraft:grass_block
fill 8 65 -307 9 65 -307 minecraft:light_gray_concrete
setblock 10 65 -307 minecraft:sea_lantern
fill 11 65 -307 12 65 -307 minecraft:light_gray_concrete
setblock 13 65 -307 minecraft:smooth_quartz
fill 14 65 -307 60 65 -307 minecraft:grass_block
fill 64 65 -307 71 65 -307 minecraft:grass_block
setblock 8 65 -306 minecraft:light_gray_concrete
setblock 9 65 -306 minecraft:sea_lantern
fill 10 65 -306 12 65 -306 minecraft:light_gray_concrete
setblock 13 65 -306 minecraft:smooth_quartz
fill 14 65 -306 35 65 -306 minecraft:grass_block
fill 37 65 -306 60 65 -306 minecraft:grass_block
fill 63 65 -306 71 65 -306 minecraft:grass_block
fill 8 65 -305 12 65 -305 minecraft:light_gray_concrete
setblock 13 65 -305 minecraft:smooth_quartz
fill 14 65 -305 59 65 -305 minecraft:grass_block
fill 62 65 -305 71 65 -305 minecraft:grass_block
fill 8 65 -304 12 65 -304 minecraft:light_gray_concrete
setblock 13 65 -304 minecraft:smooth_quartz
fill 14 65 -304 59 65 -304 minecraft:grass_block
fill 62 65 -304 71 65 -304 minecraft:grass_block
fill 8 65 -303 12 65 -303 minecraft:light_gray_concrete
setblock 13 65 -303 minecraft:smooth_quartz
fill 14 65 -303 60 65 -303 minecraft:grass_block
fill 63 65 -303 71 65 -303 minecraft:grass_block
fill 8 65 -302 12 65 -302 minecraft:light_gray_concrete
setblock 13 65 -302 minecraft:smooth_quartz
fill 14 65 -302 61 65 -302 minecraft:grass_block
fill 63 65 -302 71 65 -302 minecraft:grass_block
fill 8 65 -301 12 65 -301 minecraft:light_gray_concrete
setblock 13 65 -301 minecraft:smooth_quartz
fill 14 65 -301 62 65 -301 minecraft:grass_block
fill 64 65 -301 71 65 -301 minecraft:grass_block
fill 8 65 -300 11 65 -300 minecraft:light_gray_concrete
setblock 12 65 -300 minecraft:sea_lantern
setblock 13 65 -300 minecraft:smooth_quartz
fill 14 65 -300 63 65 -300 minecraft:grass_block
fill 65 65 -300 71 65 -300 minecraft:grass_block
fill 8 65 -299 10 65 -299 minecraft:light_gray_concrete
setblock 11 65 -299 minecraft:sea_lantern
setblock 12 65 -299 minecraft:light_gray_concrete
setblock 13 65 -299 minecraft:smooth_quartz
fill 14 65 -299 64 65 -299 minecraft:grass_block
fill 67 65 -299 70 65 -299 minecraft:grass_block
fill 8 65 -298 9 65 -298 minecraft:light_gray_concrete
setblock 10 65 -298 minecraft:sea_lantern
fill 11 65 -298 12 65 -298 minecraft:light_gray_concrete
setblock 13 65 -298 minecraft:smooth_quartz
fill 14 65 -298 39 65 -298 minecraft:grass_block
fill 41 65 -298 66 65 -298 minecraft:grass_block
setblock 68 65 -298 minecraft:grass_block
setblock 71 65 -298 minecraft:grass_block
setblock 8 65 -297 minecraft:light_gray_concrete
setblock 9 65 -297 minecraft:sea_lantern
fill 10 65 -297 12 65 -297 minecraft:light_gray_concrete
setblock 13 65 -297 minecraft:smooth_quartz
fill 14 65 -297 39 65 -297 minecraft:grass_block
fill 41 65 -297 67 65 -297 minecraft:grass_block
fill 69 65 -297 71 65 -297 minecraft:grass_block
fill 8 65 -296 12 65 -296 minecraft:light_gray_concrete
setblock 13 65 -296 minecraft:smooth_quartz
fill 14 65 -296 39 65 -296 minecraft:grass_block
fill 41 65 -296 71 65 -296 minecraft:grass_block
fill 8 65 -295 12 65 -295 minecraft:light_gray_concrete
setblock 13 65 -295 minecraft:smooth_quartz
fill 14 65 -295 37 65 -295 minecraft:grass_block
fill 40 65 -295 71 65 -295 minecraft:grass_block
fill 8 65 -294 12 65 -294 minecraft:light_gray_concrete
setblock 13 65 -294 minecraft:smooth_quartz
fill 14 65 -294 71 65 -294 minecraft:grass_block
fill 8 65 -293 12 65 -293 minecraft:light_gray_concrete
setblock 13 65 -293 minecraft:smooth_quartz
fill 14 65 -293 70 65 -293 minecraft:grass_block
fill 8 65 -292 12 65 -292 minecraft:light_gray_concrete
setblock 13 65 -292 minecraft:smooth_quartz
fill 14 65 -292 70 65 -292 minecraft:grass_block
fill 8 65 -291 11 65 -291 minecraft:light_gray_concrete
setblock 12 65 -291 minecraft:sea_lantern
setblock 13 65 -291 minecraft:smooth_quartz
fill 14 65 -291 70 65 -291 minecraft:grass_block
fill 8 65 -290 10 65 -290 minecraft:light_gray_concrete
setblock 11 65 -290 minecraft:sea_lantern
setblock 12 65 -290 minecraft:light_gray_concrete
setblock 13 65 -290 minecraft:smooth_quartz
fill 14 65 -290 70 65 -290 minecraft:grass_block
fill 8 65 -289 9 65 -289 minecraft:light_gray_concrete
setblock 10 65 -289 minecraft:sea_lantern
fill 11 65 -289 12 65 -289 minecraft:light_gray_concrete
setblock 13 65 -289 minecraft:smooth_quartz
fill 14 65 -289 70 65 -289 minecraft:grass_block
setblock 8 65 -288 minecraft:light_gray_concrete
setblock 9 65 -288 minecraft:sea_lantern
fill 10 65 -288 12 65 -288 minecraft:light_gray_concrete
setblock 13 65 -288 minecraft:smooth_quartz
fill 14 65 -288 71 65 -288 minecraft:grass_block
fill 8 65 -287 12 65 -287 minecraft:light_gray_concrete
setblock 13 65 -287 minecraft:smooth_quartz
fill 14 65 -287 71 65 -287 minecraft:grass_block
fill 8 65 -286 12 65 -286 minecraft:light_gray_concrete
setblock 13 65 -286 minecraft:smooth_quartz
fill 14 65 -286 71 65 -286 minecraft:grass_block
fill 8 65 -285 12 65 -285 minecraft:light_gray_concrete
setblock 13 65 -285 minecraft:smooth_quartz
fill 14 65 -285 71 65 -285 minecraft:grass_block
fill 8 65 -284 12 65 -284 minecraft:light_gray_concrete
setblock 13 65 -284 minecraft:smooth_quartz
fill 14 65 -284 69 65 -284 minecraft:grass_block
setblock 71 65 -284 minecraft:grass_block
fill 8 65 -283 12 65 -283 minecraft:light_gray_concrete
setblock 13 65 -283 minecraft:smooth_quartz
fill 14 65 -283 71 65 -283 minecraft:grass_block
fill 8 65 -282 11 65 -282 minecraft:light_gray_concrete
setblock 12 65 -282 minecraft:sea_lantern
setblock 13 65 -282 minecraft:smooth_quartz
fill 14 65 -282 71 65 -282 minecraft:grass_block
fill 8 65 -281 10 65 -281 minecraft:light_gray_concrete
setblock 11 65 -281 minecraft:sea_lantern
setblock 12 65 -281 minecraft:light_gray_concrete
setblock 13 65 -281 minecraft:smooth_quartz
fill 14 65 -281 71 65 -281 minecraft:grass_block
fill 8 65 -280 9 65 -280 minecraft:light_gray_concrete
setblock 10 65 -280 minecraft:sea_lantern
fill 11 65 -280 12 65 -280 minecraft:light_gray_concrete
setblock 13 65 -280 minecraft:smooth_quartz
fill 14 65 -280 70 65 -280 minecraft:grass_block
setblock 8 65 -279 minecraft:light_gray_concrete
setblock 9 65 -279 minecraft:sea_lantern
fill 10 65 -279 12 65 -279 minecraft:light_gray_concrete
setblock 13 65 -279 minecraft:smooth_quartz
fill 14 65 -279 67 65 -279 minecraft:grass_block
fill 8 65 -278 12 65 -278 minecraft:light_gray_concrete
setblock 13 65 -278 minecraft:smooth_quartz
fill 14 65 -278 64 65 -278 minecraft:grass_block
fill 8 65 -277 12 65 -277 minecraft:light_gray_concrete
setblock 13 65 -277 minecraft:smooth_quartz
fill 14 65 -277 62 65 -277 minecraft:grass_block
fill 8 65 -276 12 65 -276 minecraft:light_gray_concrete
setblock 13 65 -276 minecraft:smooth_quartz
fill 14 65 -276 60 65 -276 minecraft:grass_block
fill 8 65 -275 12 65 -275 minecraft:light_gray_concrete
setblock 13 65 -275 minecraft:smooth_quartz
fill 14 65 -275 58 65 -275 minecraft:grass_block
fill 8 65 -274 12 65 -274 minecraft:light_gray_concrete
setblock 13 65 -274 minecraft:smooth_quartz
fill 14 65 -274 56 65 -274 minecraft:grass_block
fill 8 65 -273 11 65 -273 minecraft:light_gray_concrete
setblock 12 65 -273 minecraft:sea_lantern
setblock 13 65 -273 minecraft:smooth_quartz
fill 14 65 -273 55 65 -273 minecraft:grass_block
fill 8 65 -272 10 65 -272 minecraft:light_gray_concrete
setblock 11 65 -272 minecraft:sea_lantern
setblock 12 65 -272 minecraft:light_gray_concrete
setblock 13 65 -272 minecraft:smooth_quartz
fill 14 65 -272 53 65 -272 minecraft:grass_block
fill 8 65 -271 9 65 -271 minecraft:light_gray_concrete
setblock 10 65 -271 minecraft:sea_lantern
fill 11 65 -271 12 65 -271 minecraft:light_gray_concrete
setblock 13 65 -271 minecraft:smooth_quartz
fill 14 65 -271 52 65 -271 minecraft:grass_block
setblock 8 65 -270 minecraft:light_gray_concrete
setblock 9 65 -270 minecraft:sea_lantern
fill 10 65 -270 12 65 -270 minecraft:light_gray_concrete
setblock 13 65 -270 minecraft:smooth_quartz
fill 14 65 -270 50 65 -270 minecraft:grass_block
fill 8 65 -269 12 65 -269 minecraft:light_gray_concrete
setblock 13 65 -269 minecraft:smooth_quartz
fill 14 65 -269 49 65 -269 minecraft:grass_block
fill 8 65 -268 12 65 -268 minecraft:light_gray_concrete
setblock 13 65 -268 minecraft:smooth_quartz
fill 14 65 -268 48 65 -268 minecraft:grass_block
fill 8 65 -267 12 65 -267 minecraft:light_gray_concrete
setblock 13 65 -267 minecraft:smooth_quartz
fill 14 65 -267 47 65 -267 minecraft:grass_block
fill 8 65 -266 12 65 -266 minecraft:light_gray_concrete
setblock 13 65 -266 minecraft:smooth_quartz
fill 14 65 -266 46 65 -266 minecraft:grass_block
fill 8 65 -265 12 65 -265 minecraft:light_gray_concrete
setblock 13 65 -265 minecraft:smooth_quartz
fill 14 65 -265 45 65 -265 minecraft:grass_block
fill 8 65 -264 11 65 -264 minecraft:light_gray_concrete
setblock 12 65 -264 minecraft:sea_lantern
setblock 13 65 -264 minecraft:smooth_quartz
fill 14 65 -264 44 65 -264 minecraft:grass_block
fill 8 65 -263 10 65 -263 minecraft:light_gray_concrete
setblock 11 65 -263 minecraft:sea_lantern
setblock 12 65 -263 minecraft:light_gray_concrete
setblock 13 65 -263 minecraft:smooth_quartz
fill 14 65 -263 43 65 -263 minecraft:grass_block
fill 8 65 -262 9 65 -262 minecraft:light_gray_concrete
setblock 10 65 -262 minecraft:sea_lantern
fill 11 65 -262 12 65 -262 minecraft:light_gray_concrete
setblock 13 65 -262 minecraft:smooth_quartz
fill 14 65 -262 42 65 -262 minecraft:grass_block
setblock 8 65 -261 minecraft:light_gray_concrete
setblock 9 65 -261 minecraft:sea_lantern
fill 10 65 -261 12 65 -261 minecraft:light_gray_concrete
setblock 13 65 -261 minecraft:smooth_quartz
fill 14 65 -261 41 65 -261 minecraft:grass_block
fill 8 65 -260 12 65 -260 minecraft:light_gray_concrete
setblock 13 65 -260 minecraft:smooth_quartz
fill 14 65 -260 40 65 -260 minecraft:grass_block
fill 8 65 -259 12 65 -259 minecraft:light_gray_concrete
setblock 13 65 -259 minecraft:smooth_quartz
fill 14 65 -259 39 65 -259 minecraft:grass_block
fill 8 65 -258 12 65 -258 minecraft:light_gray_concrete
setblock 13 65 -258 minecraft:smooth_quartz
fill 14 65 -258 38 65 -258 minecraft:grass_block
fill 8 65 -257 12 65 -257 minecraft:light_gray_concrete
setblock 13 65 -257 minecraft:smooth_quartz
fill 14 65 -257 38 65 -257 minecraft:grass_block
fill 8 65 -256 12 65 -256 minecraft:light_gray_concrete
setblock 13 65 -256 minecraft:smooth_quartz
fill 14 65 -256 37 65 -256 minecraft:grass_block
fill 8 65 -255 11 65 -255 minecraft:light_gray_concrete
setblock 12 65 -255 minecraft:sea_lantern
setblock 13 65 -255 minecraft:smooth_quartz
fill 14 65 -255 36 65 -255 minecraft:grass_block
fill 8 66 -318 20 66 -318 minecraft:air
fill 35 66 -318 55 66 -318 minecraft:air
fill 57 66 -318 58 66 -318 minecraft:air
fill 60 66 -318 61 66 -318 minecraft:air
setblock 63 66 -318 minecraft:air
fill 8 66 -317 19 66 -317 minecraft:air
fill 36 66 -317 55 66 -317 minecraft:air
setblock 58 66 -317 minecraft:air
fill 63 66 -317 64 66 -317 minecraft:air
fill 8 66 -316 17 66 -316 minecraft:air
fill 36 66 -316 55 66 -316 minecraft:air
fill 61 66 -316 65 66 -316 minecraft:air
fill 8 66 -315 16 66 -315 minecraft:air
fill 36 66 -315 57 66 -315 minecraft:air
fill 60 66 -315 63 66 -315 minecraft:air
fill 65 66 -315 66 66 -315 minecraft:air
fill 8 66 -314 15 66 -314 minecraft:air
fill 27 66 -314 30 66 -314 minecraft:air
fill 34 66 -314 56 66 -314 minecraft:air
setblock 61 66 -314 minecraft:air
setblock 66 66 -314 minecraft:air
fill 8 66 -313 14 66 -313 minecraft:air
fill 25 66 -313 57 66 -313 minecraft:air
fill 66 66 -313 68 66 -313 minecraft:air
setblock 71 66 -313 minecraft:air
fill 8 66 -312 14 66 -312 minecraft:air
fill 24 66 -312 57 66 -312 minecraft:air
setblock 60 66 -312 minecraft:air
setblock 64 66 -312 minecraft:air
fill 8 66 -311 13 66 -311 minecraft:air
fill 22 66 -311 58 66 -311 minecraft:air
setblock 62 66 -311 minecraft:air
setblock 64 66 -311 minecraft:air
setblock 67 66 -311 minecraft:air
setblock 70 66 -311 minecraft:air
fill 8 66 -310 13 66 -310 minecraft:air
fill 21 66 -310 59 66 -310 minecraft:air
fill 61 66 -310 64 66 -310 minecraft:air
setblock 67 66 -310 minecraft:air
fill 69 66 -310 70 66 -310 minecraft:air
fill 8 66 -309 13 66 -309 minecraft:air
setblock 18 66 -309 minecraft:oak_log
fill 20 66 -309 62 66 -309 minecraft:air
fill 8 66 -308 13 66 -308 minecraft:air
fill 20 66 -308 31 66 -308 minecraft:air
fill 36 66 -308 61 66 -308 minecraft:air
fill 8 66 -307 14 66 -307 minecraft:air
fill 22 66 -307 31 66 -307 minecraft:air
fill 36 66 -307 60 66 -307 minecraft:air
setblock 64 66 -307 minecraft:air
fill 8 66 -306 14 66 -306 minecraft:air
fill 24 66 -306 31 66 -306 minecraft:air
fill 37 66 -306 60 66 -306 minecraft:air
fill 8 66 -305 14 66 -305 minecraft:air
fill 26 66 -305 32 66 -305 minecraft:air
fill 36 66 -305 59 66 -305 minecraft:air
fill 8 66 -304 15 66 -304 minecraft:air
fill 26 66 -304 59 66 -304 minecraft:air
setblock 64 66 -304 minecraft:air
fill 8 66 -303 18 66 -303 minecraft:air
fill 25 66 -303 60 66 -303 minecraft:air
setblock 70 66 -303 minecraft:air
fill 8 66 -302 61 66 -302 minecraft:air
fill 8 66 -301 62 66 -301 minecraft:air
fill 8 66 -300 34 66 -300 minecraft:air
fill 38 66 -300 63 66 -300 minecraft:air
fill 8 66 -299 17 66 -299 minecraft:air
setblock 18 66 -299 minecraft:oak_log
fill 19 66 -299 34 66 -299 minecraft:air
fill 40 66 -299 64 66 -299 minecraft:air
fill 8 66 -298 34 66 -298 minecraft:air
fill 41 66 -298 66 66 -298 minecraft:air
setblock 71 66 -298 minecraft:air
fill 8 66 -297 35 66 -297 minecraft:air
fill 41 66 -297 67 66 -297 minecraft:air
fill 69 66 -297 71 66 -297 minecraft:air
fill 8 66 -296 36 66 -296 minecraft:air
fill 41 66 -296 71 66 -296 minecraft:air
fill 8 66 -295 20 66 -295 minecraft:air
fill 22 66 -295 37 66 -295 minecraft:air
fill 40 66 -295 71 66 -295 minecraft:air
fill 8 66 -294 17 66 -294 minecraft:air
fill 25 66 -294 71 66 -294 minecraft:air
fill 8 66 -293 16 66 -293 minecraft:air
fill 26 66 -293 68 66 -293 minecraft:air
fill 8 66 -292 16 66 -292 minecraft:air
fill 27 66 -292 68 66 -292 minecraft:air
fill 8 66 -291 17 66 -291 minecraft:air
fill 27 66 -291 68 66 -291 minecraft:air
fill 8 66 -290 17 66 -290 minecraft:air
fill 27 66 -290 68 66 -290 minecraft:air
fill 8 66 -289 17 66 -289 minecraft:air
setblock 18 66 -289 minecraft:oak_log
fill 28 66 -289 68 66 -289 minecraft:air
fill 8 66 -288 18 66 -288 minecraft:air
fill 27 66 -288 68 66 -288 minecraft:air
fill 9 66 -287 19 66 -287 minecraft:air
fill 27 66 -287 68 66 -287 minecraft:air
fill 9 66 -286 21 66 -286 minecraft:air
fill 25 66 -286 68 66 -286 minecraft:air
fill 9 66 -285 68 66 -285 minecraft:air
fill 9 66 -284 68 66 -284 minecraft:air
fill 9 66 -283 51 66 -283 minecraft:air
fill 8 66 -282 26 66 -282 minecraft:air
fill 8 66 -281 26 66 -281 minecraft:air
fill 8 66 -280 26 66 -280 minecraft:air
fill 8 66 -279 17 66 -279 minecraft:air
setblock 18 66 -279 minecraft:oak_log
fill 19 66 -279 26 66 -279 minecraft:air
fill 8 66 -278 26 66 -278 minecraft:air
fill 8 66 -277 26 66 -277 minecraft:air
fill 8 66 -276 26 66 -276 minecraft:air
fill 8 66 -275 26 66 -275 minecraft:air
fill 8 66 -274 26 66 -274 minecraft:air
fill 8 66 -273 26 66 -273 minecraft:air
fill 8 66 -272 26 66 -272 minecraft:air
fill 8 66 -271 26 66 -271 minecraft:air
fill 8 66 -270 26 66 -270 minecraft:air
fill 8 66 -269 17 66 -269 minecraft:air
setblock 18 66 -269 minecraft:oak_log
fill 19 66 -269 26 66 -269 minecraft:air
fill 8 66 -268 26 66 -268 minecraft:air
fill 8 66 -267 26 66 -267 minecraft:air
fill 8 66 -266 26 66 -266 minecraft:air
fill 8 66 -265 26 66 -265 minecraft:air
fill 8 66 -264 26 66 -264 minecraft:air
fill 8 66 -263 26 66 -263 minecraft:air
fill 8 66 -262 26 66 -262 minecraft:air
fill 8 66 -261 26 66 -261 minecraft:air
fill 8 66 -260 26 66 -260 minecraft:air
fill 8 66 -259 17 66 -259 minecraft:air
setblock 18 66 -259 minecraft:oak_log
fill 19 66 -259 26 66 -259 minecraft:air
fill 8 66 -258 26 66 -258 minecraft:air
fill 8 66 -257 26 66 -257 minecraft:air
fill 8 66 -256 26 66 -256 minecraft:air
fill 8 66 -255 26 66 -255 minecraft:air
fill 8 67 -318 22 67 -318 minecraft:air
fill 33 67 -318 49 67 -318 minecraft:air
setblock 55 67 -318 minecraft:air
setblock 57 67 -318 minecraft:air
setblock 61 67 -318 minecraft:air
fill 8 67 -317 19 67 -317 minecraft:air
fill 34 67 -317 49 67 -317 minecraft:air
setblock 51 67 -317 minecraft:air
setblock 55 67 -317 minecraft:air
setblock 58 67 -317 minecraft:air
setblock 64 67 -317 minecraft:air
fill 8 67 -316 18 67 -316 minecraft:air
fill 34 67 -316 50 67 -316 minecraft:air
setblock 54 67 -316 minecraft:air
setblock 61 67 -316 minecraft:air
fill 8 67 -315 16 67 -315 minecraft:air
fill 27 67 -315 29 67 -315 minecraft:air
fill 33 67 -315 50 67 -315 minecraft:air
fill 55 67 -315 57 67 -315 minecraft:air
fill 8 67 -314 15 67 -314 minecraft:air
fill 25 67 -314 50 67 -314 minecraft:air
setblock 61 67 -314 minecraft:air
fill 8 67 -313 15 67 -313 minecraft:air
fill 24 67 -313 50 67 -313 minecraft:air
setblock 53 67 -313 minecraft:air
fill 8 67 -312 14 67 -312 minecraft:air
fill 23 67 -312 51 67 -312 minecraft:air
setblock 60 67 -312 minecraft:air
setblock 64 67 -312 minecraft:air
fill 8 67 -311 14 67 -311 minecraft:air
fill 21 67 -311 51 67 -311 minecraft:air
fill 8 67 -310 13 67 -310 minecraft:air
fill 21 67 -310 51 67 -310 minecraft:air
setblock 62 67 -310 minecraft:air
setblock 70 67 -310 minecraft:air
fill 8 67 -309 13 67 -309 minecraft:air
setblock 18 67 -309 minecraft:oak_log
fill 20 67 -309 51 67 -309 minecraft:air
setblock 55 67 -309 minecraft:air
setblock 62 67 -309 minecraft:air
fill 8 67 -308 14 67 -308 minecraft:air
fill 20 67 -308 32 67 -308 minecraft:air
fill 37 67 -308 52 67 -308 minecraft:air
setblock 55 67 -308 minecraft:air
fill 8 67 -307 14 67 -307 minecraft:air
fill 20 67 -307 32 67 -307 minecraft:air
fill 37 67 -307 53 67 -307 minecraft:air
setblock 64 67 -307 minecraft:air
fill 8 67 -306 14 67 -306 minecraft:air
fill 22 67 -306 32 67 -306 minecraft:air
fill 37 67 -306 55 67 -306 minecraft:air
fill 8 67 -305 15 67 -305 minecraft:air
fill 22 67 -305 56 67 -305 minecraft:air
fill 8 67 -304 17 67 -304 minecraft:air
fill 22 67 -304 56 67 -304 minecraft:air
setblock 64 67 -304 minecraft:air
fill 8 67 -303 57 67 -303 minecraft:air
setblock 70 67 -303 minecraft:air
fill 8 67 -302 58 67 -302 minecraft:air
fill 8 67 -301 60 67 -301 minecraft:air
fill 8 67 -300 61 67 -300 minecraft:air
fill 8 67 -299 17 67 -299 minecraft:air
setblock 18 67 -299 minecraft:oak_log
fill 19 67 -299 36 67 -299 minecraft:air
fill 40 67 -299 62 67 -299 minecraft:air
fill 8 67 -298 35 67 -298 minecraft:air
fill 41 67 -298 64 67 -298 minecraft:air
fill 8 67 -297 36 67 -297 minecraft:air
fill 41 67 -297 66 67 -297 minecraft:air
fill 8 67 -296 36 67 -296 minecraft:air
fill 41 67 -296 71 67 -296 minecraft:air
fill 8 67 -295 36 67 -295 minecraft:air
fill 41 67 -295 71 67 -295 minecraft:air
fill 8 67 -294 20 67 -294 minecraft:air
fill 24 67 -294 37 67 -294 minecraft:air
fill 40 67 -294 71 67 -294 minecraft:air
fill 8 67 -293 18 67 -293 minecraft:air
fill 26 67 -293 68 67 -293 minecraft:air
fill 8 67 -292 18 67 -292 minecraft:air
fill 27 67 -292 68 67 -292 minecraft:air
fill 8 67 -291 18 67 -291 minecraft:air
fill 28 67 -291 68 67 -291 minecraft:air
fill 8 67 -290 18 67 -290 minecraft:air
fill 29 67 -290 68 67 -290 minecraft:air
fill 8 67 -289 17 67 -289 minecraft:air
setblock 18 67 -289 minecraft:oak_log
fill 29 67 -289 68 67 -289 minecraft:air
fill 8 67 -288 18 67 -288 minecraft:air
fill 29 67 -288 68 67 -288 minecraft:air
fill 8 67 -287 19 67 -287 minecraft:air
fill 29 67 -287 68 67 -287 minecraft:air
fill 9 67 -286 20 67 -286 minecraft:air
fill 28 67 -286 68 67 -286 minecraft:air
fill 9 67 -285 23 67 -285 minecraft:air
fill 26 67 -285 68 67 -285 minecraft:air
fill 8 67 -284 68 67 -284 minecraft:air
fill 8 67 -283 51 67 -283 minecraft:air
fill 8 67 -282 26 67 -282 minecraft:air
fill 8 67 -281 26 67 -281 minecraft:air
fill 8 67 -280 26 67 -280 minecraft:air
fill 8 67 -279 17 67 -279 minecraft:air
setblock 18 67 -279 minecraft:oak_log
fill 19 67 -279 26 67 -279 minecraft:air
fill 8 67 -278 26 67 -278 minecraft:air
fill 8 67 -277 26 67 -277 minecraft:air
fill 8 67 -276 26 67 -276 minecraft:air
fill 8 67 -275 26 67 -275 minecraft:air
fill 8 67 -274 26 67 -274 minecraft:air
fill 8 67 -273 26 67 -273 minecraft:air
fill 8 67 -272 26 67 -272 minecraft:air
fill 8 67 -271 26 67 -271 minecraft:air
fill 8 67 -270 26 67 -270 minecraft:air
fill 8 67 -269 17 67 -269 minecraft:air
setblock 18 67 -269 minecraft:oak_log
fill 19 67 -269 26 67 -269 minecraft:air
fill 8 67 -268 26 67 -268 minecraft:air
fill 8 67 -267 26 67 -267 minecraft:air
fill 8 67 -266 26 67 -266 minecraft:air
fill 8 67 -265 26 67 -265 minecraft:air
fill 8 67 -264 26 67 -264 minecraft:air
fill 8 67 -263 26 67 -263 minecraft:air
fill 8 67 -262 26 67 -262 minecraft:air
fill 8 67 -261 26 67 -261 minecraft:air
fill 8 67 -260 26 67 -260 minecraft:air
fill 8 67 -259 17 67 -259 minecraft:air
setblock 18 67 -259 minecraft:oak_log
fill 19 67 -259 26 67 -259 minecraft:air
fill 8 67 -258 26 67 -258 minecraft:air
fill 8 67 -257 26 67 -257 minecraft:air
fill 8 67 -256 26 67 -256 minecraft:air
fill 8 67 -255 26 67 -255 minecraft:air
fill 8 68 -318 25 68 -318 minecraft:air
fill 31 68 -318 43 68 -318 minecraft:air
setblock 55 68 -318 minecraft:air
setblock 61 68 -318 minecraft:air
setblock 65 68 -318 minecraft:air
fill 8 68 -317 24 68 -317 minecraft:air
fill 31 68 -317 43 68 -317 minecraft:air
setblock 47 68 -317 minecraft:air
setblock 51 68 -317 minecraft:air
setblock 55 68 -317 minecraft:air
fill 64 68 -317 66 68 -317 minecraft:air
fill 8 68 -316 20 68 -316 minecraft:air
fill 23 68 -316 44 68 -316 minecraft:air
setblock 54 68 -316 minecraft:air
setblock 65 68 -316 minecraft:air
fill 8 68 -315 18 68 -315 minecraft:air
fill 24 68 -315 44 68 -315 minecraft:air
setblock 48 68 -315 minecraft:air
fill 55 68 -315 56 68 -315 minecraft:air
fill 8 68 -314 16 68 -314 minecraft:air
fill 23 68 -314 44 68 -314 minecraft:air
fill 8 68 -313 16 68 -313 minecraft:air
fill 23 68 -313 45 68 -313 minecraft:air
setblock 48 68 -313 minecraft:air
setblock 53 68 -313 minecraft:air
fill 8 68 -312 15 68 -312 minecraft:air
fill 22 68 -312 45 68 -312 minecraft:air
setblock 64 68 -312 minecraft:air
fill 8 68 -311 15 68 -311 minecraft:air
fill 20 68 -311 45 68 -311 minecraft:air
fill 47 68 -311 48 68 -311 minecraft:air
fill 8 68 -310 14 68 -310 minecraft:air
fill 19 68 -310 45 68 -310 minecraft:air
fill 50 68 -310 51 68 -310 minecraft:air
setblock 70 68 -310 minecraft:air
fill 8 68 -309 14 68 -309 minecraft:air
setblock 18 68 -309 minecraft:oak_log
fill 19 68 -309 35 68 -309 minecraft:air
fill 37 68 -309 46 68 -309 minecraft:air
setblock 49 68 -309 minecraft:air
setblock 62 68 -309 minecraft:air
fill 8 68 -308 15 68 -308 minecraft:air
fill 18 68 -308 32 68 -308 minecraft:air
fill 37 68 -308 47 68 -308 minecraft:air
setblock 51 68 -308 minecraft:air
setblock 55 68 -308 minecraft:air
fill 8 68 -307 16 68 -307 minecraft:air
fill 18 68 -307 32 68 -307 minecraft:air
fill 37 68 -307 47 68 -307 minecraft:air
setblock 50 68 -307 minecraft:air
setblock 64 68 -307 minecraft:air
fill 8 68 -306 33 68 -306 minecraft:air
fill 38 68 -306 49 68 -306 minecraft:air
setblock 54 68 -306 minecraft:air
fill 8 68 -305 49 68 -305 minecraft:air
fill 8 68 -304 50 68 -304 minecraft:air
setblock 64 68 -304 minecraft:air
fill 8 68 -303 51 68 -303 minecraft:air
setblock 70 68 -303 minecraft:air
fill 8 68 -302 52 68 -302 minecraft:air
fill 8 68 -301 54 68 -301 minecraft:air
setblock 56 68 -301 minecraft:air
setblock 59 68 -301 minecraft:air
fill 8 68 -300 56 68 -300 minecraft:air
fill 8 68 -299 17 68 -299 minecraft:air
setblock 18 68 -299 minecraft:oak_log
fill 19 68 -299 58 68 -299 minecraft:air
fill 8 68 -298 37 68 -298 minecraft:air
fill 40 68 -298 60 68 -298 minecraft:air
fill 8 68 -297 36 68 -297 minecraft:air
fill 41 68 -297 63 68 -297 minecraft:air
fill 8 68 -296 36 68 -296 minecraft:air
fill 41 68 -296 65 68 -296 minecraft:air
setblock 68 68 -296 minecraft:air
fill 8 68 -295 36 68 -295 minecraft:air
fill 42 68 -295 66 68 -295 minecraft:air
fill 8 68 -294 37 68 -294 minecraft:air
fill 41 68 -294 67 68 -294 minecraft:air
fill 8 68 -293 20 68 -293 minecraft:air
fill 26 68 -293 68 68 -293 minecraft:air
fill 8 68 -292 19 68 -292 minecraft:air
fill 28 68 -292 68 68 -292 minecraft:air
fill 8 68 -291 19 68 -291 minecraft:air
fill 29 68 -291 68 68 -291 minecraft:air
fill 8 68 -290 18 68 -290 minecraft:air
fill 30 68 -290 68 68 -290 minecraft:air
fill 8 68 -289 17 68 -289 minecraft:air
setblock 18 68 -289 minecraft:oak_log
fill 31 68 -289 68 68 -289 minecraft:air
fill 8 68 -288 19 68 -288 minecraft:air
fill 30 68 -288 68 68 -288 minecraft:air
fill 8 68 -287 20 68 -287 minecraft:air
fill 31 68 -287 68 68 -287 minecraft:air
fill 8 68 -286 20 68 -286 minecraft:air
fill 31 68 -286 68 68 -286 minecraft:air
fill 8 68 -285 22 68 -285 minecraft:air
fill 30 68 -285 68 68 -285 minecraft:air
fill 8 68 -284 68 68 -284 minecraft:air
fill 8 68 -283 51 68 -283 minecraft:air
fill 8 68 -282 26 68 -282 minecraft:air
fill 8 68 -281 26 68 -281 minecraft:air
fill 8 68 -280 26 68 -280 minecraft:air
fill 8 68 -279 17 68 -279 minecraft:air
setblock 18 68 -279 minecraft:oak_log
fill 19 68 -279 26 68 -279 minecraft:air
fill 8 68 -278 26 68 -278 minecraft:air
fill 8 68 -277 26 68 -277 minecraft:air
fill 8 68 -276 26 68 -276 minecraft:air
fill 8 68 -275 26 68 -275 minecraft:air
fill 8 68 -274 26 68 -274 minecraft:air
fill 8 68 -273 26 68 -273 minecraft:air
fill 8 68 -272 26 68 -272 minecraft:air
fill 8 68 -271 26 68 -271 minecraft:air
fill 8 68 -270 26 68 -270 minecraft:air
fill 8 68 -269 17 68 -269 minecraft:air
setblock 18 68 -269 minecraft:oak_log
fill 19 68 -269 26 68 -269 minecraft:air
fill 8 68 -268 26 68 -268 minecraft:air
fill 8 68 -267 26 68 -267 minecraft:air
fill 8 68 -266 26 68 -266 minecraft:air
fill 8 68 -265 26 68 -265 minecraft:air
fill 8 68 -264 26 68 -264 minecraft:air
fill 8 68 -263 26 68 -263 minecraft:air
fill 8 68 -262 26 68 -262 minecraft:air
fill 8 68 -261 26 68 -261 minecraft:air
fill 8 68 -260 26 68 -260 minecraft:air
fill 8 68 -259 17 68 -259 minecraft:air
setblock 18 68 -259 minecraft:oak_log
fill 19 68 -259 26 68 -259 minecraft:air
fill 8 68 -258 26 68 -258 minecraft:air
fill 8 68 -257 26 68 -257 minecraft:air
fill 8 68 -256 26 68 -256 minecraft:air
fill 8 68 -255 26 68 -255 minecraft:air
fill 8 69 -318 16 69 -318 minecraft:air
fill 17 69 -318 19 69 -318 minecraft:oak_leaves[persistent=true]
fill 20 69 -318 37 69 -318 minecraft:air
setblock 61 69 -318 minecraft:air
fill 8 69 -317 17 69 -317 minecraft:air
setblock 18 69 -317 minecraft:oak_leaves[persistent=true]
fill 19 69 -317 37 69 -317 minecraft:air
setblock 39 69 -317 minecraft:air
setblock 47 69 -317 minecraft:air
setblock 51 69 -317 minecraft:air
fill 64 69 -317 65 69 -317 minecraft:air
fill 8 69 -316 38 69 -316 minecraft:air
fill 8 69 -315 38 69 -315 minecraft:air
setblock 43 69 -315 minecraft:air
setblock 48 69 -315 minecraft:air
fill 8 69 -314 38 69 -314 minecraft:air
fill 8 69 -313 38 69 -313 minecraft:air
setblock 42 69 -313 minecraft:air
setblock 44 69 -313 minecraft:air
setblock 53 69 -313 minecraft:air
fill 8 69 -312 38 69 -312 minecraft:air
setblock 40 69 -312 minecraft:air
setblock 64 69 -312 minecraft:air
fill 8 69 -311 17 69 -311 minecraft:air
setblock 18 69 -311 minecraft:oak_leaves[persistent=true]
fill 19 69 -311 38 69 -311 minecraft:air
setblock 43 69 -311 minecraft:air
fill 8 69 -310 16 69 -310 minecraft:air
fill 17 69 -310 19 69 -310 minecraft:oak_leaves[persistent=true]
fill 20 69 -310 38 69 -310 minecraft:air
setblock 45 69 -310 minecraft:air
setblock 51 69 -310 minecraft:air
setblock 70 69 -310 minecraft:air
fill 8 69 -309 15 69 -309 minecraft:air
fill 16 69 -309 17 69 -309 minecraft:oak_leaves[persistent=true]
setblock 18 69 -309 minecraft:oak_log
fill 19 69 -309 20 69 -309 minecraft:oak_leaves[persistent=true]
fill 21 69 -309 33 69 -309 minecraft:air
fill 37 69 -309 39 69 -309 minecraft:air
setblock 42 69 -309 minecraft:air
setblock 62 69 -309 minecraft:air
setblock 70 69 -309 minecraft:air
fill 8 69 -308 16 69 -308 minecraft:air
fill 17 69 -308 19 69 -308 minecraft:oak_leaves[persistent=true]
fill 20 69 -308 33 69 -308 minecraft:air
fill 38 69 -308 39 69 -308 minecraft:air
fill 45 69 -308 46 69 -308 minecraft:air
setblock 55 69 -308 minecraft:air
fill 8 69 -307 17 69 -307 minecraft:air
setblock 18 69 -307 minecraft:oak_leaves[persistent=true]
fill 19 69 -307 33 69 -307 minecraft:air
fill 38 69 -307 39 69 -307 minecraft:air
setblock 44 69 -307 minecraft:air
setblock 46 69 -307 minecraft:air
setblock 64 69 -307 minecraft:air
fill 8 69 -306 33 69 -306 minecraft:air
fill 35 69 -306 40 69 -306 minecraft:air
setblock 49 69 -306 minecraft:air
fill 8 69 -305 41 69 -305 minecraft:air
setblock 71 69 -305 minecraft:air
fill 8 69 -304 43 69 -304 minecraft:air
fill 48 69 -304 49 69 -304 minecraft:air
fill 64 69 -304 65 69 -304 minecraft:air
fill 70 69 -304 71 69 -304 minecraft:air
fill 8 69 -303 43 69 -303 minecraft:air
fill 70 69 -303 71 69 -303 minecraft:air
fill 8 69 -302 43 69 -302 minecraft:air
setblock 49 69 -302 minecraft:air
setblock 51 69 -302 minecraft:air
fill 8 69 -301 17 69 -301 minecraft:air
setblock 18 69 -301 minecraft:oak_leaves[persistent=true]
fill 19 69 -301 44 69 -301 minecraft:air
setblock 54 69 -301 minecraft:air
setblock 56 69 -301 minecraft:air
setblock 59 69 -301 minecraft:air
fill 8 69 -300 16 69 -300 minecraft:air
fill 17 69 -300 19 69 -300 minecraft:oak_leaves[persistent=true]
fill 20 69 -300 45 69 -300 minecraft:air
setblock 50 69 -300 minecraft:air
setblock 55 69 -300 minecraft:air
fill 8 69 -299 15 69 -299 minecraft:air
fill 16 69 -299 17 69 -299 minecraft:oak_leaves[persistent=true]
setblock 18 69 -299 minecraft:oak_log
fill 19 69 -299 20 69 -299 minecraft:oak_leaves[persistent=true]
fill 21 69 -299 46 69 -299 minecraft:air
setblock 48 69 -299 minecraft:air
setblock 58 69 -299 minecraft:air
fill 8 69 -298 16 69 -298 minecraft:air
fill 17 69 -298 19 69 -298 minecraft:oak_leaves[persistent=true]
fill 20 69 -298 45 69 -298 minecraft:air
setblock 49 69 -298 minecraft:air
setblock 55 69 -298 minecraft:air
setblock 57 69 -298 minecraft:air
fill 8 69 -297 17 69 -297 minecraft:air
setblock 18 69 -297 minecraft:oak_leaves[persistent=true]
fill 19 69 -297 37 69 -297 minecraft:air
fill 40 69 -297 46 69 -297 minecraft:air
setblock 49 69 -297 minecraft:air
fill 54 69 -297 55 69 -297 minecraft:air
setblock 63 69 -297 minecraft:air
fill 8 69 -296 37 69 -296 minecraft:air
fill 41 69 -296 46 69 -296 minecraft:air
setblock 52 69 -296 minecraft:air
fill 55 69 -296 57 69 -296 minecraft:air
setblock 68 69 -296 minecraft:air
fill 8 69 -295 37 69 -295 minecraft:air
fill 42 69 -295 48 69 -295 minecraft:air
setblock 51 69 -295 minecraft:air
setblock 55 69 -295 minecraft:air
fill 61 69 -295 62 69 -295 minecraft:air
fill 8 69 -294 37 69 -294 minecraft:air
fill 41 69 -294 51 69 -294 minecraft:air
setblock 53 69 -294 minecraft:air
setblock 56 69 -294 minecraft:air
setblock 58 69 -294 minecraft:air
setblock 60 69 -294 minecraft:air
fill 8 69 -293 38 69 -293 minecraft:air
fill 40 69 -293 60 69 -293 minecraft:air
setblock 67 69 -293 minecraft:air
fill 8 69 -292 21 69 -292 minecraft:air
fill 28 69 -292 63 69 -292 minecraft:air
setblock 67 69 -292 minecraft:air
fill 8 69 -291 17 69 -291 minecraft:air
setblock 18 69 -291 minecraft:oak_leaves[persistent=true]
fill 19 69 -291 20 69 -291 minecraft:air
fill 31 69 -291 62 69 -291 minecraft:air
fill 8 69 -290 16 69 -290 minecraft:air
fill 17 69 -290 19 69 -290 minecraft:oak_leaves[persistent=true]
setblock 20 69 -290 minecraft:air
fill 32 69 -290 62 69 -290 minecraft:air
setblock 68 69 -290 minecraft:air
fill 8 69 -289 15 69 -289 minecraft:air
fill 16 69 -289 17 69 -289 minecraft:oak_leaves[persistent=true]
setblock 18 69 -289 minecraft:oak_log
fill 19 69 -289 20 69 -289 minecraft:oak_leaves[persistent=true]
fill 33 69 -289 63 69 -289 minecraft:air
fill 8 69 -288 16 69 -288 minecraft:air
fill 17 69 -288 19 69 -288 minecraft:oak_leaves[persistent=true]
setblock 20 69 -288 minecraft:air
setblock 30 69 -288 minecraft:air
fill 34 69 -288 63 69 -288 minecraft:air
fill 8 69 -287 17 69 -287 minecraft:air
setblock 18 69 -287 minecraft:oak_leaves[persistent=true]
fill 19 69 -287 20 69 -287 minecraft:air
fill 34 69 -287 62 69 -287 minecraft:air
fill 8 69 -286 21 69 -286 minecraft:air
fill 34 69 -286 62 69 -286 minecraft:air
fill 8 69 -285 22 69 -285 minecraft:air
fill 33 69 -285 59 69 -285 minecraft:air
setblock 64 69 -285 minecraft:air
fill 8 69 -284 25 69 -284 minecraft:air
fill 30 69 -284 54 69 -284 minecraft:air
fill 56 69 -284 58 69 -284 minecraft:air
fill 60 69 -284 61 69 -284 minecraft:air
setblock 65 69 -284 minecraft:air
fill 8 69 -283 51 69 -283 minecraft:air
fill 8 69 -282 26 69 -282 minecraft:air
fill 8 69 -281 17 69 -281 minecraft:air
setblock 18 69 -281 minecraft:oak_leaves[persistent=true]
fill 19 69 -281 26 69 -281 minecraft:air
fill 8 69 -280 16 69 -280 minecraft:air
fill 17 69 -280 19 69 -280 minecraft:oak_leaves[persistent=true]
fill 20 69 -280 26 69 -280 minecraft:air
fill 8 69 -279 15 69 -279 minecraft:air
fill 16 69 -279 17 69 -279 minecraft:oak_leaves[persistent=true]
setblock 18 69 -279 minecraft:oak_log
fill 19 69 -279 20 69 -279 minecraft:oak_leaves[persistent=true]
fill 21 69 -279 26 69 -279 minecraft:air
fill 8 69 -278 16 69 -278 minecraft:air
fill 17 69 -278 19 69 -278 minecraft:oak_leaves[persistent=true]
fill 20 69 -278 26 69 -278 minecraft:air
fill 8 69 -277 17 69 -277 minecraft:air
setblock 18 69 -277 minecraft:oak_leaves[persistent=true]
fill 19 69 -277 26 69 -277 minecraft:air
fill 8 69 -276 26 69 -276 minecraft:air
fill 8 69 -275 26 69 -275 minecraft:air
fill 8 69 -274 26 69 -274 minecraft:air
fill 8 69 -273 26 69 -273 minecraft:air
fill 8 69 -272 26 69 -272 minecraft:air
fill 8 69 -271 17 69 -271 minecraft:air
setblock 18 69 -271 minecraft:oak_leaves[persistent=true]
fill 19 69 -271 26 69 -271 minecraft:air
fill 8 69 -270 16 69 -270 minecraft:air
fill 17 69 -270 19 69 -270 minecraft:oak_leaves[persistent=true]
fill 20 69 -270 26 69 -270 minecraft:air
fill 8 69 -269 15 69 -269 minecraft:air
fill 16 69 -269 17 69 -269 minecraft:oak_leaves[persistent=true]
setblock 18 69 -269 minecraft:oak_log
fill 19 69 -269 20 69 -269 minecraft:oak_leaves[persistent=true]
fill 21 69 -269 26 69 -269 minecraft:air
fill 8 69 -268 16 69 -268 minecraft:air
fill 17 69 -268 19 69 -268 minecraft:oak_leaves[persistent=true]
fill 20 69 -268 26 69 -268 minecraft:air
fill 8 69 -267 17 69 -267 minecraft:air
setblock 18 69 -267 minecraft:oak_leaves[persistent=true]
fill 19 69 -267 26 69 -267 minecraft:air
fill 8 69 -266 26 69 -266 minecraft:air
fill 8 69 -265 26 69 -265 minecraft:air
fill 8 69 -264 26 69 -264 minecraft:air
fill 8 69 -263 26 69 -263 minecraft:air
fill 8 69 -262 26 69 -262 minecraft:air
fill 8 69 -261 17 69 -261 minecraft:air
setblock 18 69 -261 minecraft:oak_leaves[persistent=true]
fill 19 69 -261 26 69 -261 minecraft:air
fill 8 69 -260 16 69 -260 minecraft:air
fill 17 69 -260 19 69 -260 minecraft:oak_leaves[persistent=true]
fill 20 69 -260 26 69 -260 minecraft:air
fill 8 69 -259 15 69 -259 minecraft:air
fill 16 69 -259 17 69 -259 minecraft:oak_leaves[persistent=true]
setblock 18 69 -259 minecraft:oak_log
fill 19 69 -259 20 69 -259 minecraft:oak_leaves[persistent=true]
fill 21 69 -259 26 69 -259 minecraft:air
fill 8 69 -258 16 69 -258 minecraft:air
fill 17 69 -258 19 69 -258 minecraft:oak_leaves[persistent=true]
fill 20 69 -258 26 69 -258 minecraft:air
fill 8 69 -257 17 69 -257 minecraft:air
setblock 18 69 -257 minecraft:oak_leaves[persistent=true]
fill 19 69 -257 26 69 -257 minecraft:air
fill 8 69 -256 26 69 -256 minecraft:air
fill 8 69 -255 26 69 -255 minecraft:air
fill 8 70 -318 15 70 -318 minecraft:air
fill 16 70 -318 20 70 -318 minecraft:oak_leaves[persistent=true]
fill 21 70 -318 32 70 -318 minecraft:air
setblock 61 70 -318 minecraft:air
fill 63 70 -318 65 70 -318 minecraft:air
fill 8 70 -317 16 70 -317 minecraft:air
fill 17 70 -317 19 70 -317 minecraft:oak_leaves[persistent=true]
fill 20 70 -317 32 70 -317 minecraft:air
setblock 36 70 -317 minecraft:air
setblock 47 70 -317 minecraft:air
setblock 51 70 -317 minecraft:air
fill 62 70 -317 66 70 -317 minecraft:air
fill 8 70 -316 32 70 -316 minecraft:air
fill 63 70 -316 65 70 -316 minecraft:air
fill 8 70 -315 32 70 -315 minecraft:air
setblock 48 70 -315 minecraft:air
setblock 64 70 -315 minecraft:air
fill 8 70 -314 33 70 -314 minecraft:air
fill 8 70 -313 32 70 -313 minecraft:air
setblock 53 70 -313 minecraft:air
fill 8 70 -312 35 70 -312 minecraft:air
setblock 38 70 -312 minecraft:air
setblock 40 70 -312 minecraft:air
setblock 64 70 -312 minecraft:air
fill 8 70 -311 16 70 -311 minecraft:air
fill 17 70 -311 19 70 -311 minecraft:oak_leaves[persistent=true]
fill 20 70 -311 32 70 -311 minecraft:air
fill 8 70 -310 15 70 -310 minecraft:air
fill 16 70 -310 20 70 -310 minecraft:oak_leaves[persistent=true]
fill 21 70 -310 32 70 -310 minecraft:air
setblock 38 70 -310 minecraft:air
setblock 45 70 -310 minecraft:air
setblock 51 70 -310 minecraft:air
setblock 70 70 -310 minecraft:air
fill 8 70 -309 15 70 -309 minecraft:air
fill 16 70 -309 17 70 -309 minecraft:oak_leaves[persistent=true]
setblock 18 70 -309 minecraft:oak_log
fill 19 70 -309 20 70 -309 minecraft:oak_leaves[persistent=true]
fill 21 70 -309 32 70 -309 minecraft:air
setblock 62 70 -309 minecraft:air
fill 8 70 -308 15 70 -308 minecraft:air
fill 16 70 -308 20 70 -308 minecraft:oak_leaves[persistent=true]
fill 21 70 -308 33 70 -308 minecraft:air
setblock 39 70 -308 minecraft:air
setblock 46 70 -308 minecraft:air
setblock 55 70 -308 minecraft:air
fill 8 70 -307 16 70 -307 minecraft:air
fill 17 70 -307 19 70 -307 minecraft:oak_leaves[persistent=true]
fill 20 70 -307 33 70 -307 minecraft:air
setblock 64 70 -307 minecraft:air
fill 8 70 -306 33 70 -306 minecraft:air
setblock 38 70 -306 minecraft:air
setblock 40 70 -306 minecraft:air
setblock 49 70 -306 minecraft:air
fill 8 70 -305 35 70 -305 minecraft:air
fill 37 70 -305 38 70 -305 minecraft:air
setblock 40 70 -305 minecraft:air
setblock 71 70 -305 minecraft:air
fill 8 70 -304 33 70 -304 minecraft:air
setblock 35 70 -304 minecraft:air
setblock 39 70 -304 minecraft:air
setblock 42 70 -304 minecraft:air
setblock 64 70 -304 minecraft:air
setblock 71 70 -304 minecraft:air
fill 8 70 -303 34 70 -303 minecraft:air
fill 40 70 -303 41 70 -303 minecraft:air
setblock 43 70 -303 minecraft:air
fill 70 70 -303 71 70 -303 minecraft:air
fill 8 70 -302 36 70 -302 minecraft:air
fill 41 70 -302 43 70 -302 minecraft:air
fill 8 70 -301 16 70 -301 minecraft:air
fill 17 70 -301 19 70 -301 minecraft:oak_leaves[persistent=true]
fill 20 70 -301 36 70 -301 minecraft:air
setblock 56 70 -301 minecraft:air
setblock 59 70 -301 minecraft:air
fill 8 70 -300 15 70 -300 minecraft:air
fill 16 70 -300 20 70 -300 minecraft:oak_leaves[persistent=true]
fill 21 70 -300 35 70 -300 minecraft:air
fill 8 70 -299 15 70 -299 minecraft:air
fill 16 70 -299 17 70 -299 minecraft:oak_leaves[persistent=true]
setblock 18 70 -299 minecraft:oak_log
fill 19 70 -299 20 70 -299 minecraft:oak_leaves[persistent=true]
fill 21 70 -299 35 70 -299 minecraft:air
setblock 37 70 -299 minecraft:air
setblock 40 70 -299 minecraft:air
setblock 46 70 -299 minecraft:air
setblock 58 70 -299 minecraft:air
fill 8 70 -298 15 70 -298 minecraft:air
fill 16 70 -298 20 70 -298 minecraft:oak_leaves[persistent=true]
fill 21 70 -298 35 70 -298 minecraft:air
setblock 39 70 -298 minecraft:air
setblock 42 70 -298 minecraft:air
setblock 49 70 -298 minecraft:air
fill 8 70 -297 16 70 -297 minecraft:air
fill 17 70 -297 19 70 -297 minecraft:oak_leaves[persistent=true]
fill 20 70 -297 36 70 -297 minecraft:air
setblock 40 70 -297 minecraft:air
setblock 43 70 -297 minecraft:air
setblock 45 70 -297 minecraft:air
fill 8 70 -296 35 70 -296 minecraft:air
setblock 68 70 -296 minecraft:air
fill 8 70 -295 36 70 -295 minecraft:air
setblock 62 70 -295 minecraft:air
fill 8 70 -294 36 70 -294 minecraft:air
setblock 47 70 -294 minecraft:air
setblock 56 70 -294 minecraft:air
fill 8 70 -293 37 70 -293 minecraft:air
setblock 67 70 -293 minecraft:air
fill 8 70 -292 23 70 -292 minecraft:air
fill 28 70 -292 37 70 -292 minecraft:air
setblock 49 70 -292 minecraft:air
fill 52 70 -292 53 70 -292 minecraft:air
setblock 62 70 -292 minecraft:air
fill 8 70 -291 16 70 -291 minecraft:air
fill 17 70 -291 19 70 -291 minecraft:oak_leaves[persistent=true]
fill 20 70 -291 21 70 -291 minecraft:air
fill 32 70 -291 40 70 -291 minecraft:air
setblock 43 70 -291 minecraft:air
setblock 61 70 -291 minecraft:air
fill 8 70 -290 15 70 -290 minecraft:air
fill 16 70 -290 20 70 -290 minecraft:oak_leaves[persistent=true]
setblock 21 70 -290 minecraft:air
fill 34 70 -290 41 70 -290 minecraft:air
setblock 61 70 -290 minecraft:air
fill 8 70 -289 15 70 -289 minecraft:air
fill 16 70 -289 17 70 -289 minecraft:oak_leaves[persistent=true]
setblock 18 70 -289 minecraft:oak_log
fill 19 70 -289 20 70 -289 minecraft:oak_leaves[persistent=true]
fill 35 70 -289 43 70 -289 minecraft:air
setblock 60 70 -289 minecraft:air
fill 8 70 -288 15 70 -288 minecraft:air
fill 16 70 -288 20 70 -288 minecraft:oak_leaves[persistent=true]
setblock 30 70 -288 minecraft:air
fill 35 70 -288 47 70 -288 minecraft:air
setblock 56 70 -288 minecraft:air
fill 8 70 -287 16 70 -287 minecraft:air
fill 17 70 -287 19 70 -287 minecraft:oak_leaves[persistent=true]
fill 20 70 -287 21 70 -287 minecraft:air
fill 36 70 -287 50 70 -287 minecraft:air
fill 52 70 -287 53 70 -287 minecraft:air
setblock 60 70 -287 minecraft:air
setblock 62 70 -287 minecraft:air
fill 8 70 -286 22 70 -286 minecraft:air
fill 36 70 -286 52 70 -286 minecraft:air
setblock 57 70 -286 minecraft:air
fill 8 70 -285 23 70 -285 minecraft:air
fill 35 70 -285 53 70 -285 minecraft:air
setblock 55 70 -285 minecraft:air
fill 8 70 -284 25 70 -284 minecraft:air
fill 35 70 -284 53 70 -284 minecraft:air
fill 8 70 -283 51 70 -283 minecraft:air
fill 8 70 -282 26 70 -282 minecraft:air
fill 8 70 -281 16 70 -281 minecraft:air
fill 17 70 -281 19 70 -281 minecraft:oak_leaves[persistent=true]
fill 20 70 -281 26 70 -281 minecraft:air
fill 8 70 -280 15 70 -280 minecraft:air
fill 16 70 -280 20 70 -280 minecraft:oak_leaves[persistent=true]
fill 21 70 -280 26 70 -280 minecraft:air
fill 8 70 -279 15 70 -279 minecraft:air
fill 16 70 -279 17 70 -279 minecraft:oak_leaves[persistent=true]
setblock 18 70 -279 minecraft:oak_log
fill 19 70 -279 20 70 -279 minecraft:oak_leaves[persistent=true]
fill 21 70 -279 26 70 -279 minecraft:air
fill 8 70 -278 15 70 -278 minecraft:air
fill 16 70 -278 20 70 -278 minecraft:oak_leaves[persistent=true]
fill 21 70 -278 26 70 -278 minecraft:air
fill 8 70 -277 16 70 -277 minecraft:air
fill 17 70 -277 19 70 -277 minecraft:oak_leaves[persistent=true]
fill 20 70 -277 26 70 -277 minecraft:air
fill 8 70 -276 26 70 -276 minecraft:air
fill 8 70 -275 26 70 -275 minecraft:air
fill 8 70 -274 26 70 -274 minecraft:air
fill 8 70 -273 26 70 -273 minecraft:air
fill 8 70 -272 26 70 -272 minecraft:air
fill 8 70 -271 16 70 -271 minecraft:air
fill 17 70 -271 19 70 -271 minecraft:oak_leaves[persistent=true]
fill 20 70 -271 26 70 -271 minecraft:air
fill 8 70 -270 15 70 -270 minecraft:air
fill 16 70 -270 20 70 -270 minecraft:oak_leaves[persistent=true]
fill 21 70 -270 26 70 -270 minecraft:air
fill 8 70 -269 15 70 -269 minecraft:air
fill 16 70 -269 17 70 -269 minecraft:oak_leaves[persistent=true]
setblock 18 70 -269 minecraft:oak_log
fill 19 70 -269 20 70 -269 minecraft:oak_leaves[persistent=true]
fill 21 70 -269 26 70 -269 minecraft:air
fill 8 70 -268 15 70 -268 minecraft:air
fill 16 70 -268 20 70 -268 minecraft:oak_leaves[persistent=true]
fill 21 70 -268 26 70 -268 minecraft:air
fill 8 70 -267 16 70 -267 minecraft:air
fill 17 70 -267 19 70 -267 minecraft:oak_leaves[persistent=true]
fill 20 70 -267 26 70 -267 minecraft:air
fill 8 70 -266 26 70 -266 minecraft:air
fill 8 70 -265 26 70 -265 minecraft:air
fill 8 70 -264 26 70 -264 minecraft:air
fill 8 70 -263 26 70 -263 minecraft:air
fill 8 70 -262 26 70 -262 minecraft:air
fill 8 70 -261 16 70 -261 minecraft:air
fill 17 70 -261 19 70 -261 minecraft:oak_leaves[persistent=true]
fill 20 70 -261 26 70 -261 minecraft:air
fill 9 70 -260 15 70 -260 minecraft:air
fill 16 70 -260 20 70 -260 minecraft:oak_leaves[persistent=true]
fill 21 70 -260 26 70 -260 minecraft:air
fill 9 70 -259 15 70 -259 minecraft:air
fill 16 70 -259 17 70 -259 minecraft:oak_leaves[persistent=true]
setblock 18 70 -259 minecraft:oak_log
fill 19 70 -259 20 70 -259 minecraft:oak_leaves[persistent=true]
fill 21 70 -259 26 70 -259 minecraft:air
fill 9 70 -258 15 70 -258 minecraft:air
fill 16 70 -258 20 70 -258 minecraft:oak_leaves[persistent=true]
fill 21 70 -258 26 70 -258 minecraft:air
fill 8 70 -257 16 70 -257 minecraft:air
fill 17 70 -257 19 70 -257 minecraft:oak_leaves[persistent=true]
fill 20 70 -257 26 70 -257 minecraft:air
fill 8 70 -256 26 70 -256 minecraft:air
fill 8 70 -255 26 70 -255 minecraft:air
fill 8 71 -318 16 71 -318 minecraft:air
fill 17 71 -318 19 71 -318 minecraft:oak_leaves[persistent=true]
fill 20 71 -318 26 71 -318 minecraft:air
setblock 61 71 -318 minecraft:air
fill 63 71 -318 65 71 -318 minecraft:air
fill 8 71 -317 17 71 -317 minecraft:air
setblock 18 71 -317 minecraft:oak_leaves[persistent=true]
fill 19 71 -317 26 71 -317 minecraft:air
setblock 36 71 -317 minecraft:air
setblock 47 71 -317 minecraft:air
setblock 51 71 -317 minecraft:air
fill 63 71 -317 65 71 -317 minecraft:air
fill 8 71 -316 27 71 -316 minecraft:air
setblock 31 71 -316 minecraft:air
fill 63 71 -316 65 71 -316 minecraft:air
fill 8 71 -315 28 71 -315 minecraft:air
setblock 48 71 -315 minecraft:air
fill 8 71 -314 28 71 -314 minecraft:air
fill 8 71 -313 28 71 -313 minecraft:air
setblock 32 71 -313 minecraft:air
setblock 53 71 -313 minecraft:air
fill 8 71 -312 28 71 -312 minecraft:air
setblock 34 71 -312 minecraft:air
setblock 40 71 -312 minecraft:air
setblock 64 71 -312 minecraft:air
fill 8 71 -311 17 71 -311 minecraft:air
setblock 18 71 -311 minecraft:oak_leaves[persistent=true]
fill 19 71 -311 28 71 -311 minecraft:air
setblock 30 71 -311 minecraft:air
fill 8 71 -310 16 71 -310 minecraft:air
fill 17 71 -310 19 71 -310 minecraft:oak_leaves[persistent=true]
fill 20 71 -310 28 71 -310 minecraft:air
setblock 45 71 -310 minecraft:air
setblock 51 71 -310 minecraft:air
setblock 70 71 -310 minecraft:air
fill 8 71 -309 15 71 -309 minecraft:air
fill 16 71 -309 20 71 -309 minecraft:oak_leaves[persistent=true]
fill 21 71 -309 28 71 -309 minecraft:air
setblock 31 71 -309 minecraft:air
setblock 62 71 -309 minecraft:air
fill 8 71 -308 16 71 -308 minecraft:air
fill 17 71 -308 19 71 -308 minecraft:oak_leaves[persistent=true]
fill 20 71 -308 29 71 -308 minecraft:air
setblock 31 71 -308 minecraft:air
setblock 46 71 -308 minecraft:air
setblock 55 71 -308 minecraft:air
fill 8 71 -307 17 71 -307 minecraft:air
setblock 18 71 -307 minecraft:oak_leaves[persistent=true]
fill 19 71 -307 30 71 -307 minecraft:air
fill 64 71 -307 65 71 -307 minecraft:air
fill 8 71 -306 29 71 -306 minecraft:air
setblock 49 71 -306 minecraft:air
fill 8 71 -305 29 71 -305 minecraft:air
setblock 70 71 -305 minecraft:air
fill 8 71 -304 29 71 -304 minecraft:air
setblock 39 71 -304 minecraft:air
setblock 64 71 -304 minecraft:air
fill 69 71 -304 71 71 -304 minecraft:air
fill 8 71 -303 29 71 -303 minecraft:air
setblock 34 71 -303 minecraft:air
fill 68 71 -303 71 71 -303 minecraft:air
fill 8 71 -302 30 71 -302 minecraft:air
setblock 41 71 -302 minecraft:air
fill 69 71 -302 71 71 -302 minecraft:air
fill 8 71 -301 17 71 -301 minecraft:air
setblock 18 71 -301 minecraft:oak_leaves[persistent=true]
fill 19 71 -301 31 71 -301 minecraft:air
setblock 56 71 -301 minecraft:air
setblock 59 71 -301 minecraft:air
setblock 70 71 -301 minecraft:air
fill 8 71 -300 16 71 -300 minecraft:air
fill 17 71 -300 19 71 -300 minecraft:oak_leaves[persistent=true]
fill 20 71 -300 30 71 -300 minecraft:air
setblock 33 71 -300 minecraft:air
fill 8 71 -299 15 71 -299 minecraft:air
fill 16 71 -299 20 71 -299 minecraft:oak_leaves[persistent=true]
fill 21 71 -299 30 71 -299 minecraft:air
setblock 46 71 -299 minecraft:air
setblock 58 71 -299 minecraft:air
fill 8 71 -298 16 71 -298 minecraft:air
fill 17 71 -298 19 71 -298 minecraft:oak_leaves[persistent=true]
fill 20 71 -298 30 71 -298 minecraft:air
setblock 33 71 -298 minecraft:air
setblock 35 71 -298 minecraft:air
setblock 49 71 -298 minecraft:air
fill 8 71 -297 17 71 -297 minecraft:air
setblock 18 71 -297 minecraft:oak_leaves[persistent=true]
fill 19 71 -297 31 71 -297 minecraft:air
setblock 35 71 -297 minecraft:air
setblock 40 71 -297 minecraft:air
fill 8 71 -296 31 71 -296 minecraft:air
setblock 68 71 -296 minecraft:air
fill 8 71 -295 31 71 -295 minecraft:air
setblock 62 71 -295 minecraft:air
fill 8 71 -294 32 71 -294 minecraft:air
setblock 47 71 -294 minecraft:air
setblock 56 71 -294 minecraft:air
fill 8 71 -293 32 71 -293 minecraft:air
setblock 67 71 -293 minecraft:air
fill 8 71 -292 33 71 -292 minecraft:air
setblock 52 71 -292 minecraft:air
fill 8 71 -291 17 71 -291 minecraft:air
setblock 18 71 -291 minecraft:oak_leaves[persistent=true]
fill 19 71 -291 24 71 -291 minecraft:air
setblock 33 71 -291 minecraft:air
setblock 40 71 -291 minecraft:air
setblock 43 71 -291 minecraft:air
fill 8 71 -290 16 71 -290 minecraft:air
fill 17 71 -290 19 71 -290 minecraft:oak_leaves[persistent=true]
fill 20 71 -290 22 71 -290 minecraft:air
fill 8 71 -289 15 71 -289 minecraft:air
fill 16 71 -289 20 71 -289 minecraft:oak_leaves[persistent=true]
fill 21 71 -289 22 71 -289 minecraft:air
setblock 60 71 -289 minecraft:air
fill 8 71 -288 16 71 -288 minecraft:air
fill 17 71 -288 19 71 -288 minecraft:oak_leaves[persistent=true]
fill 20 71 -288 22 71 -288 minecraft:air
setblock 30 71 -288 minecraft:air
setblock 56 71 -288 minecraft:air
fill 8 71 -287 17 71 -287 minecraft:air
setblock 18 71 -287 minecraft:oak_leaves[persistent=true]
fill 19 71 -287 22 71 -287 minecraft:air
fill 52 71 -287 53 71 -287 minecraft:air
setblock 60 71 -287 minecraft:air
fill 8 71 -286 23 71 -286 minecraft:air
setblock 49 71 -286 minecraft:air
fill 8 71 -285 24 71 -285 minecraft:air
setblock 43 71 -285 minecraft:air
fill 8 71 -284 26 71 -284 minecraft:air
setblock 51 71 -284 minecraft:air
fill 8 71 -283 29 71 -283 minecraft:air
setblock 40 71 -283 minecraft:air
setblock 42 71 -283 minecraft:air
fill 8 71 -282 26 71 -282 minecraft:air
fill 8 71 -281 17 71 -281 minecraft:air
setblock 18 71 -281 minecraft:oak_leaves[persistent=true]
fill 19 71 -281 26 71 -281 minecraft:air
fill 8 71 -280 16 71 -280 minecraft:air
fill 17 71 -280 19 71 -280 minecraft:oak_leaves[persistent=true]
fill 20 71 -280 26 71 -280 minecraft:air
fill 8 71 -279 15 71 -279 minecraft:air
fill 16 71 -279 20 71 -279 minecraft:oak_leaves[persistent=true]
fill 21 71 -279 26 71 -279 minecraft:air
fill 8 71 -278 16 71 -278 minecraft:air
fill 17 71 -278 19 71 -278 minecraft:oak_leaves[persistent=true]
fill 20 71 -278 26 71 -278 minecraft:air
fill 8 71 -277 17 71 -277 minecraft:air
setblock 18 71 -277 minecraft:oak_leaves[persistent=true]
fill 19 71 -277 26 71 -277 minecraft:air
fill 8 71 -276 26 71 -276 minecraft:air
fill 8 71 -275 26 71 -275 minecraft:air
fill 8 71 -274 26 71 -274 minecraft:air
fill 8 71 -273 26 71 -273 minecraft:air
fill 8 71 -272 26 71 -272 minecraft:air
fill 8 71 -271 17 71 -271 minecraft:air
setblock 18 71 -271 minecraft:oak_leaves[persistent=true]
fill 19 71 -271 26 71 -271 minecraft:air
fill 8 71 -270 16 71 -270 minecraft:air
fill 17 71 -270 19 71 -270 minecraft:oak_leaves[persistent=true]
fill 20 71 -270 26 71 -270 minecraft:air
fill 8 71 -269 15 71 -269 minecraft:air
fill 16 71 -269 20 71 -269 minecraft:oak_leaves[persistent=true]
fill 21 71 -269 26 71 -269 minecraft:air
fill 8 71 -268 16 71 -268 minecraft:air
fill 17 71 -268 19 71 -268 minecraft:oak_leaves[persistent=true]
fill 20 71 -268 26 71 -268 minecraft:air
fill 8 71 -267 17 71 -267 minecraft:air
setblock 18 71 -267 minecraft:oak_leaves[persistent=true]
fill 19 71 -267 26 71 -267 minecraft:air
fill 8 71 -266 26 71 -266 minecraft:air
fill 8 71 -265 26 71 -265 minecraft:air
fill 8 71 -264 26 71 -264 minecraft:air
fill 8 71 -263 26 71 -263 minecraft:air
fill 8 71 -262 26 71 -262 minecraft:air
fill 9 71 -261 17 71 -261 minecraft:air
setblock 18 71 -261 minecraft:oak_leaves[persistent=true]
fill 19 71 -261 26 71 -261 minecraft:air
fill 10 71 -260 16 71 -260 minecraft:air
fill 17 71 -260 19 71 -260 minecraft:oak_leaves[persistent=true]
fill 20 71 -260 26 71 -260 minecraft:air
fill 11 71 -259 15 71 -259 minecraft:air
fill 16 71 -259 20 71 -259 minecraft:oak_leaves[persistent=true]
fill 21 71 -259 26 71 -259 minecraft:air
fill 11 71 -258 16 71 -258 minecraft:air
fill 17 71 -258 19 71 -258 minecraft:oak_leaves[persistent=true]
fill 20 71 -258 26 71 -258 minecraft:air
fill 11 71 -257 17 71 -257 minecraft:air
setblock 18 71 -257 minecraft:oak_leaves[persistent=true]
fill 19 71 -257 26 71 -257 minecraft:air
fill 9 71 -256 26 71 -256 minecraft:air
fill 8 71 -255 26 71 -255 minecraft:air
fill 8 72 -318 19 72 -318 minecraft:air
setblock 26 72 -318 minecraft:air
setblock 61 72 -318 minecraft:air
setblock 64 72 -318 minecraft:air
fill 8 72 -317 19 72 -317 minecraft:air
setblock 22 72 -317 minecraft:air
setblock 26 72 -317 minecraft:air
setblock 36 72 -317 minecraft:air
setblock 47 72 -317 minecraft:air
setblock 51 72 -317 minecraft:air
fill 63 72 -317 65 72 -317 minecraft:air
fill 8 72 -316 19 72 -316 minecraft:air
fill 22 72 -316 23 72 -316 minecraft:air
setblock 31 72 -316 minecraft:air
setblock 64 72 -316 minecraft:air
fill 8 72 -315 19 72 -315 minecraft:air
setblock 21 72 -315 minecraft:air
setblock 48 72 -315 minecraft:air
fill 8 72 -314 20 72 -314 minecraft:air
fill 8 72 -313 21 72 -313 minecraft:air
setblock 28 72 -313 minecraft:air
setblock 32 72 -313 minecraft:air
setblock 53 72 -313 minecraft:air
fill 8 72 -312 21 72 -312 minecraft:air
fill 25 72 -312 26 72 -312 minecraft:air
setblock 28 72 -312 minecraft:air
setblock 34 72 -312 minecraft:air
setblock 40 72 -312 minecraft:air
setblock 64 72 -312 minecraft:air
fill 8 72 -311 21 72 -311 minecraft:air
fill 8 72 -310 21 72 -310 minecraft:air
setblock 27 72 -310 minecraft:air
setblock 45 72 -310 minecraft:air
setblock 51 72 -310 minecraft:air
fill 8 72 -309 17 72 -309 minecraft:air
setblock 18 72 -309 minecraft:oak_leaves[persistent=true]
fill 19 72 -309 22 72 -309 minecraft:air
fill 26 72 -309 28 72 -309 minecraft:air
setblock 31 72 -309 minecraft:air
setblock 62 72 -309 minecraft:air
setblock 70 72 -309 minecraft:air
fill 8 72 -308 23 72 -308 minecraft:air
setblock 46 72 -308 minecraft:air
setblock 55 72 -308 minecraft:air
fill 8 72 -307 23 72 -307 minecraft:air
setblock 26 72 -307 minecraft:air
setblock 64 72 -307 minecraft:air
fill 8 72 -306 22 72 -306 minecraft:air
setblock 25 72 -306 minecraft:air
setblock 49 72 -306 minecraft:air
fill 8 72 -305 21 72 -305 minecraft:air
setblock 25 72 -305 minecraft:air
fill 8 72 -304 22 72 -304 minecraft:air
setblock 39 72 -304 minecraft:air
setblock 64 72 -304 minecraft:air
fill 69 72 -304 71 72 -304 minecraft:air
fill 8 72 -303 21 72 -303 minecraft:air
fill 69 72 -303 71 72 -303 minecraft:air
fill 8 72 -302 22 72 -302 minecraft:air
setblock 41 72 -302 minecraft:air
fill 69 72 -302 71 72 -302 minecraft:air
fill 8 72 -301 21 72 -301 minecraft:air
setblock 28 72 -301 minecraft:air
setblock 56 72 -301 minecraft:air
setblock 59 72 -301 minecraft:air
fill 8 72 -300 21 72 -300 minecraft:air
setblock 33 72 -300 minecraft:air
setblock 71 72 -300 minecraft:air
fill 8 72 -299 17 72 -299 minecraft:air
setblock 18 72 -299 minecraft:oak_leaves[persistent=true]
fill 19 72 -299 22 72 -299 minecraft:air
setblock 46 72 -299 minecraft:air
setblock 58 72 -299 minecraft:air
fill 8 72 -298 23 72 -298 minecraft:air
setblock 27 72 -298 minecraft:air
setblock 49 72 -298 minecraft:air
fill 8 72 -297 23 72 -297 minecraft:air
setblock 30 72 -297 minecraft:air
setblock 35 72 -297 minecraft:air
setblock 40 72 -297 minecraft:air
fill 8 72 -296 24 72 -296 minecraft:air
setblock 68 72 -296 minecraft:air
fill 8 72 -295 24 72 -295 minecraft:air
setblock 62 72 -295 minecraft:air
fill 8 72 -294 25 72 -294 minecraft:air
setblock 47 72 -294 minecraft:air
setblock 56 72 -294 minecraft:air
fill 8 72 -293 26 72 -293 minecraft:air
setblock 67 72 -293 minecraft:air
fill 8 72 -292 26 72 -292 minecraft:air
setblock 29 72 -292 minecraft:air
setblock 52 72 -292 minecraft:air
fill 8 72 -291 26 72 -291 minecraft:air
setblock 40 72 -291 minecraft:air
setblock 43 72 -291 minecraft:air
fill 8 72 -290 25 72 -290 minecraft:air
fill 8 72 -289 17 72 -289 minecraft:air
setblock 18 72 -289 minecraft:oak_leaves[persistent=true]
fill 19 72 -289 24 72 -289 minecraft:air
setblock 60 72 -289 minecraft:air
fill 8 72 -288 24 72 -288 minecraft:air
setblock 30 72 -288 minecraft:air
fill 8 72 -287 24 72 -287 minecraft:air
setblock 52 72 -287 minecraft:air
fill 8 72 -286 25 72 -286 minecraft:air
setblock 49 72 -286 minecraft:air
fill 8 72 -285 26 72 -285 minecraft:air
setblock 43 72 -285 minecraft:air
fill 8 72 -284 27 72 -284 minecraft:air
fill 8 72 -283 27 72 -283 minecraft:air
setblock 29 72 -283 minecraft:air
fill 8 72 -282 26 72 -282 minecraft:air
fill 8 72 -281 26 72 -281 minecraft:air
fill 9 72 -280 26 72 -280 minecraft:air
fill 9 72 -279 17 72 -279 minecraft:air
setblock 18 72 -279 minecraft:oak_leaves[persistent=true]
fill 19 72 -279 26 72 -279 minecraft:air
fill 9 72 -278 26 72 -278 minecraft:air
fill 9 72 -277 26 72 -277 minecraft:air
fill 8 72 -276 26 72 -276 minecraft:air
fill 8 72 -275 26 72 -275 minecraft:air
fill 8 72 -274 26 72 -274 minecraft:air
fill 8 72 -273 26 72 -273 minecraft:air
fill 8 72 -272 26 72 -272 minecraft:air
fill 8 72 -271 26 72 -271 minecraft:air
fill 8 72 -270 26 72 -270 minecraft:air
fill 8 72 -269 17 72 -269 minecraft:air
setblock 18 72 -269 minecraft:oak_leaves[persistent=true]
fill 19 72 -269 26 72 -269 minecraft:air
fill 8 72 -268 26 72 -268 minecraft:air
fill 8 72 -267 26 72 -267 minecraft:air
fill 8 72 -266 26 72 -266 minecraft:air
fill 8 72 -265 26 72 -265 minecraft:air
fill 8 72 -264 26 72 -264 minecraft:air
fill 8 72 -263 26 72 -263 minecraft:air
fill 8 72 -262 26 72 -262 minecraft:air
fill 10 72 -261 26 72 -261 minecraft:air
fill 11 72 -260 26 72 -260 minecraft:air
fill 12 72 -259 17 72 -259 minecraft:air
setblock 18 72 -259 minecraft:oak_leaves[persistent=true]
fill 19 72 -259 26 72 -259 minecraft:air
fill 12 72 -258 26 72 -258 minecraft:air
fill 12 72 -257 26 72 -257 minecraft:air
fill 12 72 -256 26 72 -256 minecraft:air
fill 11 72 -255 26 72 -255 minecraft:air
fill 8 73 -318 13 73 -318 minecraft:air
setblock 61 73 -318 minecraft:air
setblock 64 73 -318 minecraft:air
fill 8 73 -317 13 73 -317 minecraft:air
setblock 26 73 -317 minecraft:air
setblock 36 73 -317 minecraft:air
setblock 47 73 -317 minecraft:air
setblock 51 73 -317 minecraft:air
setblock 61 73 -317 minecraft:air
fill 63 73 -317 65 73 -317 minecraft:air
setblock 71 73 -317 minecraft:air
fill 8 73 -316 12 73 -316 minecraft:air
setblock 16 73 -316 minecraft:air
setblock 19 73 -316 minecraft:air
setblock 31 73 -316 minecraft:air
setblock 64 73 -316 minecraft:air
fill 8 73 -315 14 73 -315 minecraft:air
setblock 48 73 -315 minecraft:air
fill 8 73 -314 13 73 -314 minecraft:air
setblock 20 73 -314 minecraft:air
fill 8 73 -313 13 73 -313 minecraft:air
setblock 18 73 -313 minecraft:air
setblock 32 73 -313 minecraft:air
setblock 53 73 -313 minecraft:air
setblock 64 73 -313 minecraft:air
fill 8 73 -312 14 73 -312 minecraft:air
setblock 16 73 -312 minecraft:air
setblock 34 73 -312 minecraft:air
setblock 40 73 -312 minecraft:air
setblock 64 73 -312 minecraft:air
fill 8 73 -311 13 73 -311 minecraft:air
setblock 70 73 -311 minecraft:air
fill 8 73 -310 13 73 -310 minecraft:air
setblock 45 73 -310 minecraft:air
setblock 51 73 -310 minecraft:air
setblock 55 73 -310 minecraft:air
fill 69 73 -310 71 73 -310 minecraft:air
fill 8 73 -309 12 73 -309 minecraft:air
setblock 21 73 -309 minecraft:air
fill 54 73 -309 56 73 -309 minecraft:air
setblock 62 73 -309 minecraft:air
fill 68 73 -309 71 73 -309 minecraft:air
fill 8 73 -308 12 73 -308 minecraft:air
setblock 23 73 -308 minecraft:air
setblock 46 73 -308 minecraft:air
fill 53 73 -308 57 73 -308 minecraft:air
fill 69 73 -308 71 73 -308 minecraft:air
fill 8 73 -307 12 73 -307 minecraft:air
setblock 21 73 -307 minecraft:air
fill 54 73 -307 56 73 -307 minecraft:air
setblock 64 73 -307 minecraft:air
setblock 70 73 -307 minecraft:air
fill 8 73 -306 12 73 -306 minecraft:air
setblock 22 73 -306 minecraft:air
fill 49 73 -306 50 73 -306 minecraft:air
setblock 55 73 -306 minecraft:air
fill 8 73 -305 12 73 -305 minecraft:air
setblock 18 73 -305 minecraft:air
setblock 25 73 -305 minecraft:air
fill 8 73 -304 12 73 -304 minecraft:air
setblock 21 73 -304 minecraft:air
setblock 39 73 -304 minecraft:air
setblock 64 73 -304 minecraft:air
setblock 70 73 -304 minecraft:air
fill 8 73 -303 12 73 -303 minecraft:air
setblock 17 73 -303 minecraft:air
setblock 19 73 -303 minecraft:air
fill 69 73 -303 71 73 -303 minecraft:air
fill 8 73 -302 12 73 -302 minecraft:air
setblock 21 73 -302 minecraft:air
setblock 41 73 -302 minecraft:air
setblock 70 73 -302 minecraft:air
fill 8 73 -301 12 73 -301 minecraft:air
setblock 19 73 -301 minecraft:air
setblock 28 73 -301 minecraft:air
setblock 56 73 -301 minecraft:air
setblock 59 73 -301 minecraft:air
fill 8 73 -300 12 73 -300 minecraft:air
setblock 20 73 -300 minecraft:air
fill 8 73 -299 13 73 -299 minecraft:air
setblock 15 73 -299 minecraft:air
setblock 17 73 -299 minecraft:air
setblock 20 73 -299 minecraft:air
setblock 46 73 -299 minecraft:air
setblock 58 73 -299 minecraft:air
fill 8 73 -298 14 73 -298 minecraft:air
setblock 20 73 -298 minecraft:air
setblock 27 73 -298 minecraft:air
setblock 49 73 -298 minecraft:air
fill 8 73 -297 14 73 -297 minecraft:air
setblock 30 73 -297 minecraft:air
setblock 35 73 -297 minecraft:air
setblock 40 73 -297 minecraft:air
fill 8 73 -296 15 73 -296 minecraft:air
setblock 17 73 -296 minecraft:air
fill 67 73 -296 68 73 -296 minecraft:air
fill 8 73 -295 16 73 -295 minecraft:air
setblock 22 73 -295 minecraft:air
setblock 62 73 -295 minecraft:air
fill 8 73 -294 18 73 -294 minecraft:air
setblock 23 73 -294 minecraft:air
setblock 47 73 -294 minecraft:air
setblock 56 73 -294 minecraft:air
fill 8 73 -293 18 73 -293 minecraft:air
setblock 67 73 -293 minecraft:air
fill 8 73 -292 19 73 -292 minecraft:air
setblock 29 73 -292 minecraft:air
setblock 52 73 -292 minecraft:air
fill 8 73 -291 19 73 -291 minecraft:air
setblock 26 73 -291 minecraft:air
setblock 40 73 -291 minecraft:air
setblock 43 73 -291 minecraft:air
fill 8 73 -290 20 73 -290 minecraft:air
setblock 24 73 -290 minecraft:air
fill 8 73 -289 21 73 -289 minecraft:air
setblock 60 73 -289 minecraft:air
fill 8 73 -288 22 73 -288 minecraft:air
setblock 30 73 -288 minecraft:air
fill 8 73 -287 23 73 -287 minecraft:air
setblock 52 73 -287 minecraft:air
fill 8 73 -286 23 73 -286 minecraft:air
setblock 49 73 -286 minecraft:air
fill 8 73 -285 24 73 -285 minecraft:air
setblock 43 73 -285 minecraft:air
fill 8 73 -284 11 73 -284 minecraft:air
fill 13 73 -284 23 73 -284 minecraft:air
fill 8 73 -283 23 73 -283 minecraft:air
setblock 26 73 -283 minecraft:air
setblock 29 73 -283 minecraft:air
fill 8 73 -282 24 73 -282 minecraft:air
fill 10 73 -281 23 73 -281 minecraft:air
fill 10 73 -280 23 73 -280 minecraft:air
fill 10 73 -279 24 73 -279 minecraft:air
fill 10 73 -278 24 73 -278 minecraft:air
fill 10 73 -277 24 73 -277 minecraft:air
fill 9 73 -276 25 73 -276 minecraft:air
fill 9 73 -275 25 73 -275 minecraft:air
fill 9 73 -274 25 73 -274 minecraft:air
fill 8 73 -273 25 73 -273 minecraft:air
fill 8 73 -272 25 73 -272 minecraft:air
fill 8 73 -271 25 73 -271 minecraft:air
fill 8 73 -270 24 73 -270 minecraft:air
fill 8 73 -269 24 73 -269 minecraft:air
fill 8 73 -268 24 73 -268 minecraft:air
fill 8 73 -267 25 73 -267 minecraft:air
fill 8 73 -266 24 73 -266 minecraft:air
fill 8 73 -265 25 73 -265 minecraft:air
fill 8 73 -264 25 73 -264 minecraft:air
fill 8 73 -263 25 73 -263 minecraft:air
fill 8 73 -262 25 73 -262 minecraft:air
fill 8 73 -261 25 73 -261 minecraft:air
fill 11 73 -260 25 73 -260 minecraft:air
fill 12 73 -259 25 73 -259 minecraft:air
fill 12 73 -258 24 73 -258 minecraft:air
fill 12 73 -257 23 73 -257 minecraft:air
setblock 26 73 -257 minecraft:air
fill 12 73 -256 23 73 -256 minecraft:air
fill 12 73 -255 23 73 -255 minecraft:air
setblock 8 74 -318 minecraft:air
fill 50 74 -318 52 74 -318 minecraft:air
setblock 61 74 -318 minecraft:air
setblock 26 74 -317 minecraft:air
setblock 36 74 -317 minecraft:air
fill 47 74 -317 53 74 -317 minecraft:air
setblock 31 74 -316 minecraft:air
fill 47 74 -316 52 74 -316 minecraft:air
fill 9 74 -315 10 74 -315 minecraft:air
fill 46 74 -315 51 74 -315 minecraft:air
setblock 53 74 -315 minecraft:air
setblock 20 74 -314 minecraft:air
fill 47 74 -314 49 74 -314 minecraft:air
fill 52 74 -314 54 74 -314 minecraft:air
setblock 32 74 -313 minecraft:air
setblock 48 74 -313 minecraft:air
fill 51 74 -313 55 74 -313 minecraft:air
setblock 12 74 -312 minecraft:air
setblock 16 74 -312 minecraft:air
setblock 34 74 -312 minecraft:air
setblock 40 74 -312 minecraft:air
fill 51 74 -312 54 74 -312 minecraft:air
setblock 64 74 -312 minecraft:air
fill 50 74 -311 53 74 -311 minecraft:air
setblock 8 74 -310 minecraft:air
setblock 10 74 -310 minecraft:air
setblock 45 74 -310 minecraft:air
fill 49 74 -310 53 74 -310 minecraft:air
fill 69 74 -310 71 74 -310 minecraft:air
fill 8 74 -309 9 74 -309 minecraft:air
fill 50 74 -309 52 74 -309 minecraft:air
fill 54 74 -309 56 74 -309 minecraft:air
setblock 62 74 -309 minecraft:air
fill 69 74 -309 71 74 -309 minecraft:air
setblock 8 74 -308 minecraft:air
fill 45 74 -308 46 74 -308 minecraft:air
setblock 51 74 -308 minecraft:air
fill 54 74 -308 56 74 -308 minecraft:air
fill 69 74 -308 71 74 -308 minecraft:air
setblock 8 74 -307 minecraft:air
fill 54 74 -307 56 74 -307 minecraft:air
setblock 64 74 -307 minecraft:air
setblock 10 74 -306 minecraft:air
setblock 49 74 -306 minecraft:air
setblock 8 74 -305 minecraft:air
setblock 18 74 -305 minecraft:air
setblock 25 74 -305 minecraft:air
fill 8 74 -304 9 74 -304 minecraft:air
setblock 39 74 -304 minecraft:air
setblock 64 74 -304 minecraft:air
setblock 12 74 -303 minecraft:air
setblock 59 74 -303 minecraft:air
setblock 70 74 -303 minecraft:air
setblock 41 74 -302 minecraft:air
fill 58 74 -302 60 74 -302 minecraft:air
setblock 70 74 -302 minecraft:air
setblock 10 74 -301 minecraft:air
setblock 28 74 -301 minecraft:air
setblock 46 74 -301 minecraft:air
fill 56 74 -301 61 74 -301 minecraft:air
fill 9 74 -300 10 74 -300 minecraft:air
fill 45 74 -300 47 74 -300 minecraft:air
fill 57 74 -300 60 74 -300 minecraft:air
setblock 9 74 -299 minecraft:air
setblock 15 74 -299 minecraft:air
setblock 20 74 -299 minecraft:air
fill 44 74 -299 48 74 -299 minecraft:air
fill 56 74 -299 60 74 -299 minecraft:air
setblock 9 74 -298 minecraft:air
setblock 12 74 -298 minecraft:air
setblock 27 74 -298 minecraft:air
fill 45 74 -298 47 74 -298 minecraft:air
setblock 49 74 -298 minecraft:air
fill 57 74 -298 59 74 -298 minecraft:air
setblock 30 74 -297 minecraft:air
setblock 35 74 -297 minecraft:air
setblock 40 74 -297 minecraft:air
setblock 46 74 -297 minecraft:air
setblock 58 74 -297 minecraft:air
setblock 56 74 -296 minecraft:air
setblock 68 74 -296 minecraft:air
setblock 8 74 -295 minecraft:air
setblock 12 74 -295 minecraft:air
setblock 15 74 -295 minecraft:air
fill 55 74 -295 57 74 -295 minecraft:air
setblock 62 74 -295 minecraft:air
fill 8 74 -294 10 74 -294 minecraft:air
setblock 14 74 -294 minecraft:air
setblock 23 74 -294 minecraft:air
setblock 47 74 -294 minecraft:air
fill 54 74 -294 58 74 -294 minecraft:air
fill 8 74 -293 12 74 -293 minecraft:air
fill 55 74 -293 57 74 -293 minecraft:air
setblock 67 74 -293 minecraft:air
fill 8 74 -292 13 74 -292 minecraft:air
setblock 29 74 -292 minecraft:air
setblock 52 74 -292 minecraft:air
setblock 56 74 -292 minecraft:air
fill 8 74 -291 13 74 -291 minecraft:air
setblock 17 74 -291 minecraft:air
setblock 26 74 -291 minecraft:air
setblock 40 74 -291 minecraft:air
setblock 43 74 -291 minecraft:air
fill 8 74 -290 14 74 -290 minecraft:air
setblock 24 74 -290 minecraft:air
setblock 30 74 -290 minecraft:air
fill 8 74 -289 14 74 -289 minecraft:air
fill 29 74 -289 31 74 -289 minecraft:air
setblock 60 74 -289 minecraft:air
fill 8 74 -288 15 74 -288 minecraft:air
fill 28 74 -288 32 74 -288 minecraft:air
fill 8 74 -287 15 74 -287 minecraft:air
fill 29 74 -287 31 74 -287 minecraft:air
setblock 52 74 -287 minecraft:air
fill 8 74 -286 11 74 -286 minecraft:air
setblock 13 74 -286 minecraft:air
fill 15 74 -286 17 74 -286 minecraft:air
setblock 30 74 -286 minecraft:air
setblock 49 74 -286 minecraft:air
fill 8 74 -285 10 74 -285 minecraft:air
fill 15 74 -285 18 74 -285 minecraft:air
setblock 43 74 -285 minecraft:air
fill 8 74 -284 9 74 -284 minecraft:air
fill 15 74 -284 19 74 -284 minecraft:air
setblock 23 74 -284 minecraft:air
setblock 8 74 -283 minecraft:air
fill 14 74 -283 20 74 -283 minecraft:air
setblock 22 74 -283 minecraft:air
setblock 26 74 -283 minecraft:air
setblock 29 74 -283 minecraft:air
fill 12 74 -282 20 74 -282 minecraft:air
fill 12 74 -281 20 74 -281 minecraft:air
fill 11 74 -280 20 74 -280 minecraft:air
fill 11 74 -279 21 74 -279 minecraft:air
setblock 23 74 -279 minecraft:air
fill 11 74 -278 21 74 -278 minecraft:air
setblock 23 74 -278 minecraft:air
fill 11 74 -277 22 74 -277 minecraft:air
setblock 24 74 -277 minecraft:air
fill 11 74 -276 22 74 -276 minecraft:air
fill 11 74 -275 22 74 -275 minecraft:air
fill 10 74 -274 22 74 -274 minecraft:air
fill 10 74 -273 23 74 -273 minecraft:air
fill 10 74 -272 23 74 -272 minecraft:air
fill 9 74 -271 22 74 -271 minecraft:air
fill 8 74 -270 22 74 -270 minecraft:air
setblock 24 74 -270 minecraft:air
fill 8 74 -269 21 74 -269 minecraft:air
fill 8 74 -268 20 74 -268 minecraft:air
fill 8 74 -267 21 74 -267 minecraft:air
setblock 25 74 -267 minecraft:air
fill 8 74 -266 21 74 -266 minecraft:air
fill 8 74 -265 22 74 -265 minecraft:air
fill 8 74 -264 23 74 -264 minecraft:air
setblock 25 74 -264 minecraft:air
fill 8 74 -263 24 74 -263 minecraft:air
fill 8 74 -262 23 74 -262 minecraft:air
fill 8 74 -261 23 74 -261 minecraft:air
fill 8 74 -260 23 74 -260 minecraft:air
fill 10 74 -259 22 74 -259 minecraft:air
fill 24 74 -259 25 74 -259 minecraft:air
fill 11 74 -258 22 74 -258 minecraft:air
fill 12 74 -257 21 74 -257 minecraft:air
setblock 26 74 -257 minecraft:air
fill 11 74 -256 21 74 -256 minecraft:air
fill 11 74 -255 21 74 -255 minecraft:air
fill 35 75 -318 37 75 -318 minecraft:air
fill 50 75 -318 52 75 -318 minecraft:air
fill 59 75 -318 63 75 -318 minecraft:air
setblock 26 75 -317 minecraft:air
fill 34 75 -317 38 75 -317 minecraft:air
setblock 47 75 -317 minecraft:air
fill 50 75 -317 52 75 -317 minecraft:air
fill 60 75 -317 62 75 -317 minecraft:air
setblock 31 75 -316 minecraft:air
fill 35 75 -316 37 75 -316 minecraft:air
fill 47 75 -316 52 75 -316 minecraft:air
setblock 61 75 -316 minecraft:air
setblock 10 75 -315 minecraft:air
setblock 36 75 -315 minecraft:air
fill 47 75 -315 49 75 -315 minecraft:air
setblock 20 75 -314 minecraft:air
fill 47 75 -314 49 75 -314 minecraft:air
fill 52 75 -314 54 75 -314 minecraft:air
setblock 64 75 -314 minecraft:air
setblock 32 75 -313 minecraft:air
fill 52 75 -313 54 75 -313 minecraft:air
fill 63 75 -313 65 75 -313 minecraft:air
setblock 12 75 -312 minecraft:air
setblock 16 75 -312 minecraft:air
setblock 34 75 -312 minecraft:air
setblock 40 75 -312 minecraft:air
setblock 45 75 -312 minecraft:air
fill 52 75 -312 54 75 -312 minecraft:air
fill 62 75 -312 66 75 -312 minecraft:air
fill 44 75 -311 46 75 -311 minecraft:air
fill 50 75 -311 52 75 -311 minecraft:air
fill 63 75 -311 65 75 -311 minecraft:air
setblock 10 75 -310 minecraft:air
fill 43 75 -310 47 75 -310 minecraft:air
fill 50 75 -310 52 75 -310 minecraft:air
setblock 64 75 -310 minecraft:air
setblock 70 75 -310 minecraft:air
setblock 8 75 -309 minecraft:air
fill 44 75 -309 46 75 -309 minecraft:air
fill 50 75 -309 52 75 -309 minecraft:air
setblock 55 75 -309 minecraft:air
setblock 62 75 -309 minecraft:air
setblock 64 75 -309 minecraft:air
fill 69 75 -309 71 75 -309 minecraft:air
fill 45 75 -308 46 75 -308 minecraft:air
fill 54 75 -308 56 75 -308 minecraft:air
fill 63 75 -308 65 75 -308 minecraft:air
setblock 70 75 -308 minecraft:air
setblock 55 75 -307 minecraft:air
fill 62 75 -307 66 75 -307 minecraft:air
setblock 39 75 -306 minecraft:air
setblock 49 75 -306 minecraft:air
fill 63 75 -306 65 75 -306 minecraft:air
setblock 18 75 -305 minecraft:air
setblock 25 75 -305 minecraft:air
fill 38 75 -305 40 75 -305 minecraft:air
fill 63 75 -305 65 75 -305 minecraft:air
setblock 8 75 -304 minecraft:air
fill 37 75 -304 41 75 -304 minecraft:air
fill 62 75 -304 66 75 -304 minecraft:air
fill 38 75 -303 40 75 -303 minecraft:air
setblock 56 75 -303 minecraft:air
fill 63 75 -303 65 75 -303 minecraft:air
setblock 39 75 -302 minecraft:air
setblock 41 75 -302 minecraft:air
fill 55 75 -302 60 75 -302 minecraft:air
setblock 64 75 -302 minecraft:air
setblock 10 75 -301 minecraft:air
setblock 28 75 -301 minecraft:air
fill 54 75 -301 60 75 -301 minecraft:air
fill 45 75 -300 47 75 -300 minecraft:air
setblock 49 75 -300 minecraft:air
fill 55 75 -300 60 75 -300 minecraft:air
setblock 20 75 -299 minecraft:air
fill 45 75 -299 50 75 -299 minecraft:air
fill 56 75 -299 59 75 -299 minecraft:air
setblock 27 75 -298 minecraft:air
fill 45 75 -298 51 75 -298 minecraft:air
fill 57 75 -298 59 75 -298 minecraft:air
setblock 30 75 -297 minecraft:air
setblock 35 75 -297 minecraft:air
setblock 40 75 -297 minecraft:air
fill 48 75 -297 50 75 -297 minecraft:air
setblock 49 75 -296 minecraft:air
setblock 68 75 -296 minecraft:air
setblock 15 75 -295 minecraft:air
fill 55 75 -295 57 75 -295 minecraft:air
setblock 62 75 -295 minecraft:air
setblock 67 75 -295 minecraft:air
setblock 9 75 -294 minecraft:air
setblock 23 75 -294 minecraft:air
setblock 47 75 -294 minecraft:air
fill 55 75 -294 57 75 -294 minecraft:air
fill 66 75 -294 68 75 -294 minecraft:air
setblock 8 75 -293 minecraft:air
fill 55 75 -293 57 75 -293 minecraft:air
fill 65 75 -293 68 75 -293 minecraft:air
setblock 10 75 -292 minecraft:air
setblock 13 75 -292 minecraft:air
setblock 29 75 -292 minecraft:air
setblock 52 75 -292 minecraft:air
fill 66 75 -292 68 75 -292 minecraft:air
setblock 26 75 -291 minecraft:air
setblock 40 75 -291 minecraft:air
setblock 43 75 -291 minecraft:air
setblock 67 75 -291 minecraft:air
setblock 9 75 -290 minecraft:air
fill 13 75 -290 14 75 -290 minecraft:air
setblock 24 75 -290 minecraft:air
fill 29 75 -289 31 75 -289 minecraft:air
setblock 52 75 -289 minecraft:air
setblock 60 75 -289 minecraft:air
setblock 8 75 -288 minecraft:air
fill 10 75 -288 11 75 -288 minecraft:air
fill 29 75 -288 31 75 -288 minecraft:air
fill 51 75 -288 53 75 -288 minecraft:air
setblock 9 75 -287 minecraft:air
setblock 12 75 -287 minecraft:air
fill 29 75 -287 31 75 -287 minecraft:air
fill 50 75 -287 54 75 -287 minecraft:air
setblock 9 75 -286 minecraft:air
setblock 13 75 -286 minecraft:air
setblock 49 75 -286 minecraft:air
fill 51 75 -286 53 75 -286 minecraft:air
setblock 43 75 -285 minecraft:air
setblock 52 75 -285 minecraft:air
setblock 23 75 -284 minecraft:air
fill 29 75 -283 30 75 -283 minecraft:air
setblock 17 75 -282 minecraft:air
setblock 20 75 -282 minecraft:air
setblock 15 75 -281 minecraft:air
setblock 19 75 -281 minecraft:air
setblock 12 75 -280 minecraft:air
fill 15 75 -280 16 75 -280 minecraft:air
fill 12 75 -279 17 75 -279 minecraft:air
setblock 21 75 -279 minecraft:air
fill 11 75 -278 18 75 -278 minecraft:air
fill 20 75 -278 21 75 -278 minecraft:air
fill 12 75 -277 20 75 -277 minecraft:air
setblock 24 75 -277 minecraft:air
fill 12 75 -276 22 75 -276 minecraft:air
fill 12 75 -275 20 75 -275 minecraft:air
fill 12 75 -274 20 75 -274 minecraft:air
fill 12 75 -273 20 75 -273 minecraft:air
setblock 10 75 -272 minecraft:air
fill 13 75 -272 20 75 -272 minecraft:air
fill 13 75 -271 20 75 -271 minecraft:air
fill 12 75 -270 18 75 -270 minecraft:air
setblock 24 75 -270 minecraft:air
fill 12 75 -269 17 75 -269 minecraft:air
fill 8 75 -268 16 75 -268 minecraft:air
fill 18 75 -268 19 75 -268 minecraft:air
fill 8 75 -267 18 75 -267 minecraft:air
setblock 25 75 -267 minecraft:air
fill 8 75 -266 18 75 -266 minecraft:air
fill 8 75 -265 19 75 -265 minecraft:air
fill 8 75 -264 19 75 -264 minecraft:air
setblock 22 75 -264 minecraft:air
fill 8 75 -263 20 75 -263 minecraft:air
setblock 22 75 -263 minecraft:air
fill 8 75 -262 20 75 -262 minecraft:air
setblock 22 75 -262 minecraft:air
fill 8 75 -261 20 75 -261 minecraft:air
setblock 22 75 -261 minecraft:air
fill 8 75 -260 21 75 -260 minecraft:air
fill 8 75 -259 20 75 -259 minecraft:air
setblock 22 75 -259 minecraft:air
setblock 25 75 -259 minecraft:air
fill 8 75 -258 19 75 -258 minecraft:air
fill 8 75 -257 19 75 -257 minecraft:air
setblock 26 75 -257 minecraft:air
fill 8 75 -256 19 75 -256 minecraft:air
fill 8 75 -255 19 75 -255 minecraft:air
setblock 31 76 -318 minecraft:air
fill 35 76 -318 37 76 -318 minecraft:air
fill 46 76 -318 48 76 -318 minecraft:air
setblock 51 76 -318 minecraft:air
fill 60 76 -318 62 76 -318 minecraft:air
setblock 26 76 -317 minecraft:air
fill 30 76 -317 32 76 -317 minecraft:air
fill 35 76 -317 37 76 -317 minecraft:air
fill 45 76 -317 52 76 -317 minecraft:air
fill 60 76 -317 62 76 -317 minecraft:air
fill 29 76 -316 33 76 -316 minecraft:air
fill 35 76 -316 37 76 -316 minecraft:air
fill 46 76 -316 48 76 -316 minecraft:air
setblock 51 76 -316 minecraft:air
fill 30 76 -315 32 76 -315 minecraft:air
fill 47 76 -315 49 76 -315 minecraft:air
setblock 20 76 -314 minecraft:air
setblock 31 76 -314 minecraft:air
setblock 48 76 -314 minecraft:air
setblock 53 76 -314 minecraft:air
setblock 32 76 -313 minecraft:air
fill 52 76 -313 54 76 -313 minecraft:air
fill 63 76 -313 65 76 -313 minecraft:air
setblock 12 76 -312 minecraft:air
setblock 16 76 -312 minecraft:air
setblock 34 76 -312 minecraft:air
setblock 40 76 -312 minecraft:air
setblock 53 76 -312 minecraft:air
fill 63 76 -312 65 76 -312 minecraft:air
fill 44 76 -311 46 76 -311 minecraft:air
setblock 51 76 -311 minecraft:air
fill 62 76 -311 65 76 -311 minecraft:air
setblock 10 76 -310 minecraft:air
fill 44 76 -310 46 76 -310 minecraft:air
fill 50 76 -310 52 76 -310 minecraft:air
fill 61 76 -310 63 76 -310 minecraft:air
setblock 70 76 -310 minecraft:air
setblock 8 76 -309 minecraft:air
fill 44 76 -309 46 76 -309 minecraft:air
setblock 51 76 -309 minecraft:air
fill 60 76 -309 64 76 -309 minecraft:air
fill 69 76 -309 70 76 -309 minecraft:air
setblock 46 76 -308 minecraft:air
fill 55 76 -308 56 76 -308 minecraft:air
fill 61 76 -308 65 76 -308 minecraft:air
fill 62 76 -307 65 76 -307 minecraft:air
setblock 49 76 -306 minecraft:air
fill 63 76 -306 65 76 -306 minecraft:air
setblock 18 76 -305 minecraft:air
setblock 25 76 -305 minecraft:air
fill 38 76 -305 40 76 -305 minecraft:air
fill 63 76 -305 65 76 -305 minecraft:air
setblock 8 76 -304 minecraft:air
fill 38 76 -304 41 76 -304 minecraft:air
fill 63 76 -304 65 76 -304 minecraft:air
fill 38 76 -303 42 76 -303 minecraft:air
fill 63 76 -303 65 76 -303 minecraft:air
fill 39 76 -302 43 76 -302 minecraft:air
fill 55 76 -302 57 76 -302 minecraft:air
setblock 59 76 -302 minecraft:air
setblock 10 76 -301 minecraft:air
setblock 28 76 -301 minecraft:air
fill 40 76 -301 42 76 -301 minecraft:air
fill 55 76 -301 60 76 -301 minecraft:air
setblock 41 76 -300 minecraft:air
setblock 46 76 -300 minecraft:air
fill 55 76 -300 59 76 -300 minecraft:air
setblock 20 76 -299 minecraft:air
fill 45 76 -299 50 76 -299 minecraft:air
fill 57 76 -299 59 76 -299 minecraft:air
setblock 27 76 -298 minecraft:air
setblock 46 76 -298 minecraft:air
fill 48 76 -298 50 76 -298 minecraft:air
setblock 58 76 -298 minecraft:air
setblock 68 76 -298 minecraft:air
setblock 30 76 -297 minecraft:air
setblock 35 76 -297 minecraft:air
setblock 40 76 -297 minecraft:air
fill 48 76 -297 50 76 -297 minecraft:air
fill 67 76 -297 69 76 -297 minecraft:air
setblock 47 76 -296 minecraft:air
fill 66 76 -296 70 76 -296 minecraft:air
setblock 15 76 -295 minecraft:air
fill 46 76 -295 48 76 -295 minecraft:air
setblock 56 76 -295 minecraft:air
setblock 62 76 -295 minecraft:air
fill 67 76 -295 69 76 -295 minecraft:air
setblock 9 76 -294 minecraft:air
setblock 23 76 -294 minecraft:air
fill 45 76 -294 49 76 -294 minecraft:air
setblock 52 76 -294 minecraft:air
fill 55 76 -294 57 76 -294 minecraft:air
fill 66 76 -294 68 76 -294 minecraft:air
setblock 40 76 -293 minecraft:air
fill 46 76 -293 48 76 -293 minecraft:air
fill 51 76 -293 53 76 -293 minecraft:air
setblock 56 76 -293 minecraft:air
fill 66 76 -293 68 76 -293 minecraft:air
setblock 13 76 -292 minecraft:air
setblock 29 76 -292 minecraft:air
fill 39 76 -292 41 76 -292 minecraft:air
setblock 47 76 -292 minecraft:air
fill 50 76 -292 54 76 -292 minecraft:air
fill 66 76 -292 68 76 -292 minecraft:air
setblock 26 76 -291 minecraft:air
fill 38 76 -291 43 76 -291 minecraft:air
fill 51 76 -291 53 76 -291 minecraft:air
setblock 14 76 -290 minecraft:air
setblock 24 76 -290 minecraft:air
fill 39 76 -290 41 76 -290 minecraft:air
setblock 52 76 -290 minecraft:air
setblock 30 76 -289 minecraft:air
setblock 40 76 -289 minecraft:air
setblock 60 76 -289 minecraft:air
setblock 10 76 -288 minecraft:air
fill 29 76 -288 31 76 -288 minecraft:air
fill 51 76 -288 53 76 -288 minecraft:air
setblock 30 76 -287 minecraft:air
fill 51 76 -287 53 76 -287 minecraft:air
setblock 13 76 -286 minecraft:air
setblock 49 76 -286 minecraft:air
fill 51 76 -286 53 76 -286 minecraft:air
setblock 43 76 -285 minecraft:air
setblock 23 76 -284 minecraft:air
setblock 29 76 -283 minecraft:air
setblock 12 76 -280 minecraft:air
setblock 11 76 -278 minecraft:air
setblock 21 76 -278 minecraft:air
setblock 14 76 -277 minecraft:air
fill 16 76 -277 17 76 -277 minecraft:air
setblock 24 76 -277 minecraft:air
setblock 22 76 -276 minecraft:air
fill 14 76 -274 16 76 -274 minecraft:air
setblock 19 76 -274 minecraft:air
setblock 16 76 -273 minecraft:air
setblock 10 76 -272 minecraft:air
fill 15 76 -272 17 76 -272 minecraft:air
setblock 16 76 -271 minecraft:air
setblock 24 76 -270 minecraft:air
setblock 14 76 -268 minecraft:air
setblock 18 76 -267 minecraft:air
setblock 25 76 -267 minecraft:air
setblock 8 76 -266 minecraft:air
fill 11 76 -265 16 76 -265 minecraft:air
fill 9 76 -264 18 76 -264 minecraft:air
fill 9 76 -263 17 76 -263 minecraft:air
fill 19 76 -263 20 76 -263 minecraft:air
fill 8 76 -262 17 76 -262 minecraft:air
setblock 20 76 -262 minecraft:air
fill 8 76 -261 17 76 -261 minecraft:air
fill 8 76 -260 17 76 -260 minecraft:air
setblock 19 76 -260 minecraft:air
fill 8 76 -259 17 76 -259 minecraft:air
setblock 25 76 -259 minecraft:air
fill 8 76 -258 17 76 -258 minecraft:air
fill 8 76 -257 17 76 -257 minecraft:air
setblock 26 76 -257 minecraft:air
fill 8 76 -256 18 76 -256 minecraft:air
fill 8 76 -255 17 76 -255 minecraft:air
setblock 36 77 -318 minecraft:air
fill 46 77 -318 48 77 -318 minecraft:air
setblock 51 77 -318 minecraft:air
fill 60 77 -318 62 77 -318 minecraft:air
setblock 26 77 -317 minecraft:air
fill 30 77 -317 32 77 -317 minecraft:air
fill 35 77 -317 37 77 -317 minecraft:air
fill 46 77 -317 48 77 -317 minecraft:air
setblock 51 77 -317 minecraft:air
setblock 61 77 -317 minecraft:air
fill 30 77 -316 32 77 -316 minecraft:air
setblock 36 77 -316 minecraft:air
fill 46 77 -316 48 77 -316 minecraft:air
setblock 51 77 -316 minecraft:air
fill 30 77 -315 32 77 -315 minecraft:air
fill 47 77 -315 49 77 -315 minecraft:air
setblock 20 77 -314 minecraft:air
setblock 34 77 -314 minecraft:air
setblock 40 77 -314 minecraft:air
setblock 48 77 -314 minecraft:air
setblock 53 77 -314 minecraft:air
fill 32 77 -313 35 77 -313 minecraft:air
fill 39 77 -313 41 77 -313 minecraft:air
setblock 53 77 -313 minecraft:air
setblock 64 77 -313 minecraft:air
setblock 12 77 -312 minecraft:air
setblock 16 77 -312 minecraft:air
fill 32 77 -312 36 77 -312 minecraft:air
fill 38 77 -312 42 77 -312 minecraft:air
setblock 53 77 -312 minecraft:air
fill 63 77 -312 65 77 -312 minecraft:air
fill 33 77 -311 35 77 -311 minecraft:air
fill 39 77 -311 41 77 -311 minecraft:air
setblock 45 77 -311 minecraft:air
setblock 64 77 -311 minecraft:air
setblock 10 77 -310 minecraft:air
setblock 34 77 -310 minecraft:air
setblock 40 77 -310 minecraft:air
fill 44 77 -310 46 77 -310 minecraft:air
fill 50 77 -310 52 77 -310 minecraft:air
fill 61 77 -310 63 77 -310 minecraft:air
setblock 8 77 -309 minecraft:air
fill 45 77 -309 47 77 -309 minecraft:air
setblock 51 77 -309 minecraft:air
fill 61 77 -309 63 77 -309 minecraft:air
fill 44 77 -308 48 77 -308 minecraft:air
fill 61 77 -308 64 77 -308 minecraft:air
fill 45 77 -307 47 77 -307 minecraft:air
fill 63 77 -307 65 77 -307 minecraft:air
setblock 46 77 -306 minecraft:air
setblock 49 77 -306 minecraft:air
setblock 64 77 -306 minecraft:air
setblock 18 77 -305 minecraft:air
setblock 25 77 -305 minecraft:air
setblock 39 77 -305 minecraft:air
setblock 64 77 -305 minecraft:air
setblock 8 77 -304 minecraft:air
fill 38 77 -304 40 77 -304 minecraft:air
fill 63 77 -304 65 77 -304 minecraft:air
setblock 28 77 -303 minecraft:air
fill 39 77 -303 42 77 -303 minecraft:air
setblock 64 77 -303 minecraft:air
fill 27 77 -302 29 77 -302 minecraft:air
fill 40 77 -302 42 77 -302 minecraft:air
setblock 56 77 -302 minecraft:air
setblock 59 77 -302 minecraft:air
setblock 10 77 -301 minecraft:air
fill 26 77 -301 30 77 -301 minecraft:air
fill 40 77 -301 42 77 -301 minecraft:air
fill 55 77 -301 59 77 -301 minecraft:air
fill 27 77 -300 29 77 -300 minecraft:air
setblock 46 77 -300 minecraft:air
setblock 56 77 -300 minecraft:air
setblock 20 77 -299 minecraft:air
setblock 28 77 -299 minecraft:air
setblock 35 77 -299 minecraft:air
fill 46 77 -299 47 77 -299 minecraft:air
setblock 49 77 -299 minecraft:air
setblock 58 77 -299 minecraft:air
setblock 27 77 -298 minecraft:air
fill 34 77 -298 36 77 -298 minecraft:air
fill 48 77 -298 50 77 -298 minecraft:air
setblock 30 77 -297 minecraft:air
fill 33 77 -297 37 77 -297 minecraft:air
setblock 40 77 -297 minecraft:air
setblock 49 77 -297 minecraft:air
setblock 62 77 -297 minecraft:air
fill 67 77 -297 69 77 -297 minecraft:air
fill 34 77 -296 36 77 -296 minecraft:air
fill 61 77 -296 63 77 -296 minecraft:air
fill 67 77 -296 69 77 -296 minecraft:air
setblock 15 77 -295 minecraft:air
setblock 35 77 -295 minecraft:air
fill 46 77 -295 48 77 -295 minecraft:air
fill 60 77 -295 64 77 -295 minecraft:air
fill 67 77 -295 69 77 -295 minecraft:air
setblock 9 77 -294 minecraft:air
setblock 23 77 -294 minecraft:air
fill 46 77 -294 48 77 -294 minecraft:air
fill 55 77 -294 57 77 -294 minecraft:air
fill 61 77 -294 63 77 -294 minecraft:air
setblock 67 77 -294 minecraft:air
setblock 43 77 -293 minecraft:air
fill 46 77 -293 48 77 -293 minecraft:air
fill 51 77 -293 53 77 -293 minecraft:air
setblock 62 77 -293 minecraft:air
fill 66 77 -293 68 77 -293 minecraft:air
setblock 13 77 -292 minecraft:air
setblock 29 77 -292 minecraft:air
fill 39 77 -292 44 77 -292 minecraft:air
fill 51 77 -292 53 77 -292 minecraft:air
setblock 67 77 -292 minecraft:air
setblock 26 77 -291 minecraft:air
fill 39 77 -291 45 77 -291 minecraft:air
fill 51 77 -291 53 77 -291 minecraft:air
setblock 14 77 -290 minecraft:air
setblock 24 77 -290 minecraft:air
fill 39 77 -290 44 77 -290 minecraft:air
setblock 30 77 -289 minecraft:air
setblock 43 77 -289 minecraft:air
setblock 60 77 -289 minecraft:air
setblock 10 77 -288 minecraft:air
fill 29 77 -288 30 77 -288 minecraft:air
setblock 49 77 -288 minecraft:air
setblock 52 77 -288 minecraft:air
setblock 30 77 -287 minecraft:air
setblock 43 77 -287 minecraft:air
fill 48 77 -287 53 77 -287 minecraft:air
setblock 13 77 -286 minecraft:air
fill 42 77 -286 44 77 -286 minecraft:air
fill 47 77 -286 52 77 -286 minecraft:air
fill 41 77 -285 45 77 -285 minecraft:air
fill 48 77 -285 50 77 -285 minecraft:air
setblock 23 77 -284 minecraft:air
fill 42 77 -284 44 77 -284 minecraft:air
setblock 49 77 -284 minecraft:air
setblock 29 77 -283 minecraft:air
setblock 43 77 -283 minecraft:air
setblock 12 77 -280 minecraft:air
setblock 11 77 -278 minecraft:air
setblock 21 77 -278 minecraft:air
setblock 16 77 -277 minecraft:air
setblock 24 77 -277 minecraft:air
setblock 22 77 -276 minecraft:air
setblock 15 77 -274 minecraft:air
setblock 10 77 -272 minecraft:air
setblock 24 77 -270 minecraft:air
setblock 14 77 -268 minecraft:air
setblock 18 77 -267 minecraft:air
setblock 25 77 -267 minecraft:air
setblock 8 77 -266 minecraft:air
setblock 11 77 -265 minecraft:air
setblock 14 77 -265 minecraft:air
setblock 15 77 -264 minecraft:air
setblock 11 77 -262 minecraft:air
setblock 20 77 -262 minecraft:air
setblock 15 77 -261 minecraft:air
fill 12 77 -259 14 77 -259 minecraft:air
setblock 25 77 -259 minecraft:air
setblock 9 77 -258 minecraft:air
setblock 26 77 -257 minecraft:air
fill 11 77 -256 12 77 -256 minecraft:air
setblock 18 77 -256 minecraft:air
setblock 16 77 -255 minecraft:air
fill 25 78 -318 27 78 -318 minecraft:air
setblock 47 78 -318 minecraft:air
fill 61 78 -318 62 78 -318 minecraft:air
fill 24 78 -317 28 78 -317 minecraft:air
setblock 31 78 -317 minecraft:air
fill 35 78 -317 36 78 -317 minecraft:air
fill 46 78 -317 48 78 -317 minecraft:air
setblock 61 78 -317 minecraft:air
fill 25 78 -316 27 78 -316 minecraft:air
fill 30 78 -316 32 78 -316 minecraft:air
setblock 47 78 -316 minecraft:air
setblock 26 78 -315 minecraft:air
fill 31 78 -315 32 78 -315 minecraft:air
setblock 16 78 -314 minecraft:air
setblock 20 78 -314 minecraft:air
fill 31 78 -314 33 78 -314 minecraft:air
fill 15 78 -313 17 78 -313 minecraft:air
fill 30 78 -313 35 78 -313 minecraft:air
fill 39 78 -313 41 78 -313 minecraft:air
setblock 64 78 -313 minecraft:air
setblock 12 78 -312 minecraft:air
fill 14 78 -312 18 78 -312 minecraft:air
fill 31 78 -312 35 78 -312 minecraft:air
fill 39 78 -312 41 78 -312 minecraft:air
fill 63 78 -312 65 78 -312 minecraft:air
fill 15 78 -311 17 78 -311 minecraft:air
fill 32 78 -311 35 78 -311 minecraft:air
fill 39 78 -311 41 78 -311 minecraft:air
setblock 45 78 -311 minecraft:air
setblock 64 78 -311 minecraft:air
setblock 8 78 -310 minecraft:air
setblock 10 78 -310 minecraft:air
setblock 16 78 -310 minecraft:air
setblock 45 78 -310 minecraft:air
setblock 62 78 -310 minecraft:air
fill 8 78 -309 9 78 -309 minecraft:air
fill 45 78 -309 47 78 -309 minecraft:air
fill 61 78 -309 63 78 -309 minecraft:air
setblock 8 78 -308 minecraft:air
fill 45 78 -308 47 78 -308 minecraft:air
setblock 62 78 -308 minecraft:air
setblock 64 78 -308 minecraft:air
setblock 25 78 -307 minecraft:air
fill 45 78 -307 47 78 -307 minecraft:air
fill 63 78 -307 65 78 -307 minecraft:air
fill 24 78 -306 26 78 -306 minecraft:air
setblock 49 78 -306 minecraft:air
setblock 18 78 -305 minecraft:air
fill 23 78 -305 27 78 -305 minecraft:air
setblock 39 78 -305 minecraft:air
setblock 8 78 -304 minecraft:air
fill 24 78 -304 26 78 -304 minecraft:air
fill 38 78 -304 39 78 -304 minecraft:air
fill 64 78 -304 65 78 -304 minecraft:air
setblock 25 78 -303 minecraft:air
setblock 39 78 -303 minecraft:air
setblock 41 78 -303 minecraft:air
fill 27 78 -302 29 78 -302 minecraft:air
fill 40 78 -302 42 78 -302 minecraft:air
setblock 10 78 -301 minecraft:air
fill 27 78 -301 29 78 -301 minecraft:air
setblock 41 78 -301 minecraft:air
setblock 56 78 -301 minecraft:air
fill 27 78 -300 29 78 -300 minecraft:air
setblock 20 78 -299 minecraft:air
setblock 30 78 -299 minecraft:air
setblock 27 78 -298 minecraft:air
fill 29 78 -298 31 78 -298 minecraft:air
fill 34 78 -298 36 78 -298 minecraft:air
fill 49 78 -298 50 78 -298 minecraft:air
fill 28 78 -297 32 78 -297 minecraft:air
fill 34 78 -297 36 78 -297 minecraft:air
setblock 40 78 -297 minecraft:air
setblock 68 78 -297 minecraft:air
fill 29 78 -296 31 78 -296 minecraft:air
fill 34 78 -296 36 78 -296 minecraft:air
fill 61 78 -296 63 78 -296 minecraft:air
fill 67 78 -296 69 78 -296 minecraft:air
setblock 15 78 -295 minecraft:air
setblock 30 78 -295 minecraft:air
setblock 47 78 -295 minecraft:air
fill 61 78 -295 63 78 -295 minecraft:air
setblock 68 78 -295 minecraft:air
setblock 9 78 -294 minecraft:air
setblock 23 78 -294 minecraft:air
setblock 29 78 -294 minecraft:air
fill 46 78 -294 48 78 -294 minecraft:air
fill 61 78 -294 63 78 -294 minecraft:air
setblock 67 78 -294 minecraft:air
fill 28 78 -293 30 78 -293 minecraft:air
setblock 47 78 -293 minecraft:air
setblock 52 78 -293 minecraft:air
setblock 67 78 -293 minecraft:air
setblock 13 78 -292 minecraft:air
setblock 24 78 -292 minecraft:air
fill 26 78 -292 31 78 -292 minecraft:air
setblock 40 78 -292 minecraft:air
fill 42 78 -292 44 78 -292 minecraft:air
fill 51 78 -292 53 78 -292 minecraft:air
fill 23 78 -291 26 78 -291 minecraft:air
fill 28 78 -291 30 78 -291 minecraft:air
fill 39 78 -291 44 78 -291 minecraft:air
setblock 52 78 -291 minecraft:air
setblock 14 78 -290 minecraft:air
fill 22 78 -290 26 78 -290 minecraft:air
setblock 29 78 -290 minecraft:air
setblock 40 78 -290 minecraft:air
fill 42 78 -290 44 78 -290 minecraft:air
fill 23 78 -289 25 78 -289 minecraft:air
setblock 60 78 -289 minecraft:air
setblock 10 78 -288 minecraft:air
setblock 24 78 -288 minecraft:air
fill 48 78 -287 50 78 -287 minecraft:air
setblock 52 78 -287 minecraft:air
setblock 13 78 -286 minecraft:air
fill 42 78 -286 44 78 -286 minecraft:air
fill 48 78 -286 50 78 -286 minecraft:air
fill 42 78 -285 44 78 -285 minecraft:air
fill 48 78 -285 50 78 -285 minecraft:air
setblock 23 78 -284 minecraft:air
fill 42 78 -284 44 78 -284 minecraft:air
setblock 29 78 -283 minecraft:air
setblock 12 78 -280 minecraft:air
setblock 11 78 -278 minecraft:air
setblock 21 78 -278 minecraft:air
setblock 24 78 -277 minecraft:air
setblock 22 78 -276 minecraft:air
setblock 15 78 -274 minecraft:air
setblock 10 78 -272 minecraft:air
setblock 24 78 -270 minecraft:air
setblock 14 78 -268 minecraft:air
setblock 18 78 -267 minecraft:air
setblock 25 78 -267 minecraft:air
setblock 8 78 -266 minecraft:air
setblock 11 78 -265 minecraft:air
setblock 15 78 -264 minecraft:air
setblock 20 78 -262 minecraft:air
setblock 12 78 -259 minecraft:air
setblock 25 78 -259 minecraft:air
setblock 26 78 -257 minecraft:air
setblock 18 78 -256 minecraft:air
fill 25 79 -318 27 79 -318 minecraft:air
setblock 47 79 -318 minecraft:air
fill 25 79 -317 27 79 -317 minecraft:air
setblock 31 79 -317 minecraft:air
fill 47 79 -317 48 79 -317 minecraft:air
fill 25 79 -316 27 79 -316 minecraft:air
fill 31 79 -316 32 79 -316 minecraft:air
setblock 20 79 -314 minecraft:air
fill 31 79 -314 33 79 -314 minecraft:air
setblock 12 79 -313 minecraft:air
fill 15 79 -313 17 79 -313 minecraft:air
fill 31 79 -313 34 79 -313 minecraft:air
setblock 40 79 -313 minecraft:air
setblock 10 79 -312 minecraft:air
setblock 12 79 -312 minecraft:air
fill 15 79 -312 17 79 -312 minecraft:air
fill 31 79 -312 35 79 -312 minecraft:air
fill 39 79 -312 41 79 -312 minecraft:air
fill 8 79 -311 11 79 -311 minecraft:air
fill 15 79 -311 17 79 -311 minecraft:air
setblock 34 79 -311 minecraft:air
setblock 40 79 -311 minecraft:air
fill 8 79 -310 12 79 -310 minecraft:air
setblock 62 79 -310 minecraft:air
fill 8 79 -309 11 79 -309 minecraft:air
setblock 46 79 -309 minecraft:air
fill 61 79 -309 63 79 -309 minecraft:air
fill 8 79 -308 10 79 -308 minecraft:air
fill 45 79 -308 47 79 -308 minecraft:air
setblock 49 79 -308 minecraft:air
fill 8 79 -307 9 79 -307 minecraft:air
setblock 18 79 -307 minecraft:air
setblock 46 79 -307 minecraft:air
fill 48 79 -307 50 79 -307 minecraft:air
fill 17 79 -306 19 79 -306 minecraft:air
fill 24 79 -306 26 79 -306 minecraft:air
fill 47 79 -306 51 79 -306 minecraft:air
fill 16 79 -305 20 79 -305 minecraft:air
fill 24 79 -305 26 79 -305 minecraft:air
fill 48 79 -305 50 79 -305 minecraft:air
setblock 8 79 -304 minecraft:air
fill 17 79 -304 19 79 -304 minecraft:air
fill 24 79 -304 26 79 -304 minecraft:air
setblock 49 79 -304 minecraft:air
setblock 18 79 -303 minecraft:air
setblock 28 79 -302 minecraft:air
fill 40 79 -302 41 79 -302 minecraft:air
setblock 10 79 -301 minecraft:air
setblock 20 79 -301 minecraft:air
fill 27 79 -301 29 79 -301 minecraft:air
setblock 41 79 -301 minecraft:air
fill 19 79 -300 21 79 -300 minecraft:air
fill 27 79 -300 28 79 -300 minecraft:air
fill 18 79 -299 22 79 -299 minecraft:air
fill 26 79 -299 28 79 -299 minecraft:air
fill 19 79 -298 21 79 -298 minecraft:air
fill 25 79 -298 31 79 -298 minecraft:air
setblock 35 79 -298 minecraft:air
setblock 20 79 -297 minecraft:air
fill 26 79 -297 31 79 -297 minecraft:air
fill 34 79 -297 36 79 -297 minecraft:air
setblock 40 79 -297 minecraft:air
setblock 68 79 -297 minecraft:air
setblock 27 79 -296 minecraft:air
fill 29 79 -296 31 79 -296 minecraft:air
setblock 35 79 -296 minecraft:air
setblock 62 79 -296 minecraft:air
fill 67 79 -296 69 79 -296 minecraft:air
setblock 15 79 -295 minecraft:air
fill 61 79 -295 63 79 -295 minecraft:air
setblock 68 79 -295 minecraft:air
setblock 9 79 -294 minecraft:air
setblock 23 79 -294 minecraft:air
fill 46 79 -294 47 79 -294 minecraft:air
setblock 62 79 -294 minecraft:air
fill 28 79 -293 30 79 -293 minecraft:air
setblock 47 79 -293 minecraft:air
setblock 52 79 -293 minecraft:air
setblock 13 79 -292 minecraft:air
fill 28 79 -292 30 79 -292 minecraft:air
setblock 43 79 -292 minecraft:air
setblock 52 79 -292 minecraft:air
fill 23 79 -291 26 79 -291 minecraft:air
fill 28 79 -291 30 79 -291 minecraft:air
fill 40 79 -291 44 79 -291 minecraft:air
setblock 14 79 -290 minecraft:air
fill 23 79 -290 25 79 -290 minecraft:air
setblock 40 79 -290 minecraft:air
setblock 43 79 -290 minecraft:air
fill 23 79 -289 25 79 -289 minecraft:air
setblock 60 79 -289 minecraft:air
setblock 10 79 -288 minecraft:air
setblock 49 79 -287 minecraft:air
setblock 13 79 -286 minecraft:air
setblock 23 79 -286 minecraft:air
setblock 43 79 -286 minecraft:air
fill 48 79 -286 50 79 -286 minecraft:air
fill 22 79 -285 24 79 -285 minecraft:air
fill 42 79 -285 44 79 -285 minecraft:air
setblock 49 79 -285 minecraft:air
fill 21 79 -284 25 79 -284 minecraft:air
setblock 43 79 -284 minecraft:air
fill 22 79 -283 24 79 -283 minecraft:air
setblock 29 79 -283 minecraft:air
setblock 23 79 -282 minecraft:air
setblock 12 79 -280 minecraft:air
setblock 11 79 -278 minecraft:air
setblock 21 79 -278 minecraft:air
setblock 24 79 -277 minecraft:air
setblock 22 79 -276 minecraft:air
setblock 15 79 -274 minecraft:air
setblock 10 79 -272 minecraft:air
setblock 24 79 -270 minecraft:air
setblock 25 79 -269 minecraft:air
setblock 14 79 -268 minecraft:air
fill 24 79 -268 26 79 -268 minecraft:air
setblock 18 79 -267 minecraft:air
fill 23 79 -267 26 79 -267 minecraft:air
setblock 8 79 -266 minecraft:air
fill 24 79 -266 26 79 -266 minecraft:air
setblock 11 79 -265 minecraft:air
setblock 25 79 -265 minecraft:air
setblock 15 79 -264 minecraft:air
setblock 20 79 -262 minecraft:air
setblock 12 79 -259 minecraft:air
setblock 25 79 -259 minecraft:air
setblock 26 79 -257 minecraft:air
setblock 18 79 -256 minecraft:air
setblock 26 80 -318 minecraft:air
setblock 30 80 -318 minecraft:air
setblock 8 80 -317 minecraft:air
fill 25 80 -317 27 80 -317 minecraft:air
setblock 20 80 -316 minecraft:air
setblock 26 80 -316 minecraft:air
fill 19 80 -315 21 80 -315 minecraft:air
fill 18 80 -314 22 80 -314 minecraft:air
setblock 32 80 -314 minecraft:air
setblock 16 80 -313 minecraft:air
fill 19 80 -313 21 80 -313 minecraft:air
fill 31 80 -313 33 80 -313 minecraft:air
setblock 40 80 -313 minecraft:air
setblock 12 80 -312 minecraft:air
fill 15 80 -312 17 80 -312 minecraft:air
setblock 20 80 -312 minecraft:air
fill 32 80 -312 34 80 -312 minecraft:air
fill 39 80 -312 41 80 -312 minecraft:air
fill 8 80 -311 11 80 -311 minecraft:air
setblock 16 80 -311 minecraft:air
setblock 34 80 -311 minecraft:air
setblock 40 80 -311 minecraft:air
fill 8 80 -310 11 80 -310 minecraft:air
fill 8 80 -309 11 80 -309 minecraft:air
setblock 46 80 -309 minecraft:air
fill 8 80 -308 10 80 -308 minecraft:air
fill 45 80 -308 46 80 -308 minecraft:air
fill 8 80 -307 9 80 -307 minecraft:air
fill 48 80 -307 50 80 -307 minecraft:air
fill 17 80 -306 19 80 -306 minecraft:air
setblock 25 80 -306 minecraft:air
fill 48 80 -306 50 80 -306 minecraft:air
fill 17 80 -305 19 80 -305 minecraft:air
fill 24 80 -305 26 80 -305 minecraft:air
fill 48 80 -305 50 80 -305 minecraft:air
setblock 8 80 -304 minecraft:air
fill 17 80 -304 19 80 -304 minecraft:air
setblock 25 80 -304 minecraft:air
setblock 10 80 -301 minecraft:air
fill 27 80 -301 28 80 -301 minecraft:air
fill 19 80 -300 21 80 -300 minecraft:air
fill 19 80 -299 21 80 -299 minecraft:air
fill 26 80 -299 28 80 -299 minecraft:air
setblock 40 80 -299 minecraft:air
fill 19 80 -298 21 80 -298 minecraft:air
fill 26 80 -298 28 80 -298 minecraft:air
setblock 30 80 -298 minecraft:air
setblock 35 80 -298 minecraft:air
fill 39 80 -298 41 80 -298 minecraft:air
fill 26 80 -297 31 80 -297 minecraft:air
fill 34 80 -297 35 80 -297 minecraft:air
fill 38 80 -297 42 80 -297 minecraft:air
setblock 9 80 -296 minecraft:air
setblock 30 80 -296 minecraft:air
fill 39 80 -296 41 80 -296 minecraft:air
setblock 62 80 -296 minecraft:air
fill 8 80 -295 10 80 -295 minecraft:air
setblock 15 80 -295 minecraft:air
setblock 40 80 -295 minecraft:air
fill 62 80 -295 63 80 -295 minecraft:air
fill 8 80 -294 11 80 -294 minecraft:air
setblock 23 80 -294 minecraft:air
setblock 62 80 -294 minecraft:air
fill 8 80 -293 10 80 -293 minecraft:air
setblock 29 80 -293 minecraft:air
setblock 9 80 -292 minecraft:air
setblock 13 80 -292 minecraft:air
fill 28 80 -292 30 80 -292 minecraft:air
setblock 43 80 -292 minecraft:air
setblock 24 80 -291 minecraft:air
setblock 26 80 -291 minecraft:air
setblock 29 80 -291 minecraft:air
setblock 43 80 -291 minecraft:air
setblock 14 80 -290 minecraft:air
fill 23 80 -290 25 80 -290 minecraft:air
setblock 24 80 -289 minecraft:air
setblock 60 80 -289 minecraft:air
setblock 10 80 -288 minecraft:air
setblock 13 80 -288 minecraft:air
fill 12 80 -287 14 80 -287 minecraft:air
setblock 49 80 -287 minecraft:air
fill 11 80 -286 15 80 -286 minecraft:air
setblock 43 80 -286 minecraft:air
fill 48 80 -286 49 80 -286 minecraft:air
fill 12 80 -285 14 80 -285 minecraft:air
fill 22 80 -285 24 80 -285 minecraft:air
setblock 43 80 -285 minecraft:air
setblock 13 80 -284 minecraft:air
fill 22 80 -284 24 80 -284 minecraft:air
setblock 43 80 -284 minecraft:air
fill 22 80 -283 24 80 -283 minecraft:air
setblock 29 80 -283 minecraft:air
fill 11 80 -280 12 80 -280 minecraft:air
fill 10 80 -279 12 80 -279 minecraft:air
fill 9 80 -278 13 80 -278 minecraft:air
setblock 21 80 -278 minecraft:air
fill 10 80 -277 12 80 -277 minecraft:air
setblock 24 80 -277 minecraft:air
setblock 11 80 -276 minecraft:air
setblock 22 80 -276 minecraft:air
setblock 15 80 -274 minecraft:air
setblock 10 80 -272 minecraft:air
setblock 24 80 -270 minecraft:air
fill 13 80 -268 14 80 -268 minecraft:air
fill 24 80 -268 26 80 -268 minecraft:air
setblock 18 80 -267 minecraft:air
fill 24 80 -267 26 80 -267 minecraft:air
setblock 8 80 -266 minecraft:air
fill 24 80 -266 26 80 -266 minecraft:air
setblock 11 80 -265 minecraft:air
setblock 15 80 -264 minecraft:air
setblock 20 80 -262 minecraft:air
setblock 25 80 -261 minecraft:air
fill 24 80 -260 26 80 -260 minecraft:air
setblock 12 80 -259 minecraft:air
fill 23 80 -259 27 80 -259 minecraft:air
fill 24 80 -258 26 80 -258 minecraft:air
fill 25 80 -257 26 80 -257 minecraft:air
setblock 18 80 -256 minecraft:air
fill 26 81 -317 27 81 -317 minecraft:air
setblock 26 81 -316 minecraft:air
fill 19 81 -315 21 81 -315 minecraft:air
fill 19 81 -314 21 81 -314 minecraft:air
setblock 16 81 -313 minecraft:air
fill 19 81 -313 21 81 -313 minecraft:air
fill 31 81 -313 33 81 -313 minecraft:air
setblock 12 81 -312 minecraft:air
setblock 16 81 -312 minecraft:air
setblock 32 81 -312 minecraft:air
fill 8 81 -311 10 81 -311 minecraft:air
fill 8 81 -310 11 81 -310 minecraft:air
fill 8 81 -309 10 81 -309 minecraft:air
fill 8 81 -308 10 81 -308 minecraft:air
fill 8 81 -307 9 81 -307 minecraft:air
setblock 49 81 -307 minecraft:air
setblock 8 81 -306 minecraft:air
setblock 18 81 -306 minecraft:air
fill 48 81 -306 50 81 -306 minecraft:air
fill 8 81 -305 9 81 -305 minecraft:air
fill 17 81 -305 19 81 -305 minecraft:air
fill 24 81 -305 26 81 -305 minecraft:air
setblock 49 81 -305 minecraft:air
fill 8 81 -304 10 81 -304 minecraft:air
setblock 18 81 -304 minecraft:air
setblock 25 81 -304 minecraft:air
fill 8 81 -303 9 81 -303 minecraft:air
setblock 8 81 -302 minecraft:air
setblock 10 81 -301 minecraft:air
setblock 20 81 -300 minecraft:air
fill 19 81 -299 21 81 -299 minecraft:air
setblock 27 81 -299 minecraft:air
setblock 20 81 -298 minecraft:air
fill 26 81 -298 28 81 -298 minecraft:air
fill 39 81 -298 41 81 -298 minecraft:air
setblock 27 81 -297 minecraft:air
setblock 30 81 -297 minecraft:air
fill 39 81 -297 41 81 -297 minecraft:air
setblock 23 81 -296 minecraft:air
fill 39 81 -296 41 81 -296 minecraft:air
fill 8 81 -295 10 81 -295 minecraft:air
setblock 15 81 -295 minecraft:air
fill 22 81 -295 24 81 -295 minecraft:air
fill 8 81 -294 10 81 -294 minecraft:air
fill 21 81 -294 25 81 -294 minecraft:air
fill 8 81 -293 10 81 -293 minecraft:air
fill 22 81 -293 24 81 -293 minecraft:air
setblock 29 81 -293 minecraft:air
setblock 13 81 -292 minecraft:air
setblock 23 81 -292 minecraft:air
fill 28 81 -292 30 81 -292 minecraft:air
setblock 24 81 -291 minecraft:air
setblock 26 81 -291 minecraft:air
setblock 29 81 -291 minecraft:air
setblock 60 81 -291 minecraft:air
setblock 14 81 -290 minecraft:air
fill 24 81 -290 25 81 -290 minecraft:air
fill 59 81 -290 61 81 -290 minecraft:air
fill 58 81 -289 62 81 -289 minecraft:air
setblock 10 81 -288 minecraft:air
fill 59 81 -288 61 81 -288 minecraft:air
fill 12 81 -287 14 81 -287 minecraft:air
setblock 60 81 -287 minecraft:air
fill 12 81 -286 14 81 -286 minecraft:air
fill 12 81 -285 14 81 -285 minecraft:air
setblock 23 81 -285 minecraft:air
setblock 29 81 -285 minecraft:air
fill 22 81 -284 24 81 -284 minecraft:air
fill 28 81 -284 30 81 -284 minecraft:air
setblock 23 81 -283 minecraft:air
setblock 29 81 -283 minecraft:air
setblock 31 81 -283 minecraft:air
setblock 12 81 -282 minecraft:air
fill 11 81 -281 13 81 -281 minecraft:air
fill 10 81 -280 14 81 -280 minecraft:air
fill 10 81 -279 13 81 -279 minecraft:air
setblock 24 81 -279 minecraft:air
fill 10 81 -278 12 81 -278 minecraft:air
fill 21 81 -278 25 81 -278 minecraft:air
fill 10 81 -277 12 81 -277 minecraft:air
fill 21 81 -277 26 81 -277 minecraft:air
fill 20 81 -276 25 81 -276 minecraft:air
fill 21 81 -275 24 81 -275 minecraft:air
setblock 10 81 -274 minecraft:air
setblock 15 81 -274 minecraft:air
setblock 22 81 -274 minecraft:air
fill 9 81 -273 11 81 -273 minecraft:air
fill 8 81 -272 12 81 -272 minecraft:air
fill 9 81 -271 11 81 -271 minecraft:air
setblock 10 81 -270 minecraft:air
setblock 24 81 -270 minecraft:air
setblock 18 81 -269 minecraft:air
setblock 8 81 -268 minecraft:air
setblock 14 81 -268 minecraft:air
fill 17 81 -268 19 81 -268 minecraft:air
setblock 25 81 -268 minecraft:air
fill 16 81 -267 20 81 -267 minecraft:air
fill 24 81 -267 26 81 -267 minecraft:air
setblock 8 81 -266 minecraft:air
fill 17 81 -266 19 81 -266 minecraft:air
setblock 25 81 -266 minecraft:air
setblock 11 81 -265 minecraft:air
setblock 18 81 -265 minecraft:air
setblock 15 81 -264 minecraft:air
setblock 20 81 -262 minecraft:air
fill 24 81 -260 25 81 -260 minecraft:air
setblock 12 81 -259 minecraft:air
fill 24 81 -259 25 81 -259 minecraft:air
fill 24 81 -258 26 81 -258 minecraft:air
setblock 26 81 -257 minecraft:air
setblock 18 81 -256 minecraft:air
setblock 26 81 -255 minecraft:air
setblock 20 82 -315 minecraft:air
fill 19 82 -314 21 82 -314 minecraft:air
setblock 20 82 -313 minecraft:air
setblock 12 82 -312 minecraft:air
fill 8 82 -311 10 82 -311 minecraft:air
fill 8 82 -310 11 82 -310 minecraft:air
fill 8 82 -309 10 82 -309 minecraft:air
fill 8 82 -308 10 82 -308 minecraft:air
fill 8 82 -307 9 82 -307 minecraft:air
setblock 49 82 -307 minecraft:air
fill 49 82 -306 50 82 -306 minecraft:air
fill 8 82 -305 9 82 -305 minecraft:air
fill 17 82 -305 18 82 -305 minecraft:air
fill 8 82 -304 9 82 -304 minecraft:air
fill 8 82 -303 9 82 -303 minecraft:air
setblock 10 82 -301 minecraft:air
fill 19 82 -299 20 82 -299 minecraft:air
fill 26 82 -298 27 82 -298 minecraft:air
setblock 40 82 -298 minecraft:air
setblock 27 82 -297 minecraft:air
fill 39 82 -297 41 82 -297 minecraft:air
setblock 40 82 -296 minecraft:air
setblock 9 82 -295 minecraft:air
setblock 15 82 -295 minecraft:air
fill 22 82 -295 24 82 -295 minecraft:air
fill 8 82 -294 10 82 -294 minecraft:air
setblock 13 82 -294 minecraft:air
fill 22 82 -294 24 82 -294 minecraft:air
setblock 9 82 -293 minecraft:air
fill 12 82 -293 14 82 -293 minecraft:air
fill 22 82 -293 24 82 -293 minecraft:air
setblock 26 82 -293 minecraft:air
fill 11 82 -292 15 82 -292 minecraft:air
fill 25 82 -292 27 82 -292 minecraft:air
fill 12 82 -291 14 82 -291 minecraft:air
fill 24 82 -291 28 82 -291 minecraft:air
fill 13 82 -290 14 82 -290 minecraft:air
fill 25 82 -290 27 82 -290 minecraft:air
fill 59 82 -290 61 82 -290 minecraft:air
setblock 26 82 -289 minecraft:air
fill 59 82 -289 61 82 -289 minecraft:air
setblock 10 82 -288 minecraft:air
fill 59 82 -288 61 82 -288 minecraft:air
setblock 13 82 -287 minecraft:air
fill 12 82 -286 14 82 -286 minecraft:air
setblock 13 82 -285 minecraft:air
fill 22 82 -284 24 82 -284 minecraft:air
fill 28 82 -284 30 82 -284 minecraft:air
setblock 23 82 -283 minecraft:air
fill 30 82 -283 32 82 -283 minecraft:air
fill 11 82 -281 13 82 -281 minecraft:air
fill 11 82 -280 13 82 -280 minecraft:air
setblock 21 82 -280 minecraft:air
fill 11 82 -279 13 82 -279 minecraft:air
fill 20 82 -279 22 82 -279 minecraft:air
fill 10 82 -278 12 82 -278 minecraft:air
fill 19 82 -278 25 82 -278 minecraft:air
setblock 11 82 -277 minecraft:air
fill 20 82 -277 25 82 -277 minecraft:air
setblock 15 82 -276 minecraft:air
fill 21 82 -276 25 82 -276 minecraft:air
fill 14 82 -275 16 82 -275 minecraft:air
fill 21 82 -275 23 82 -275 minecraft:air
fill 13 82 -274 17 82 -274 minecraft:air
fill 9 82 -273 11 82 -273 minecraft:air
fill 14 82 -273 16 82 -273 minecraft:air
fill 9 82 -272 11 82 -272 minecraft:air
setblock 15 82 -272 minecraft:air
fill 9 82 -271 11 82 -271 minecraft:air
fill 23 82 -270 24 82 -270 minecraft:air
setblock 8 82 -268 minecraft:air
setblock 14 82 -268 minecraft:air
fill 17 82 -268 19 82 -268 minecraft:air
setblock 25 82 -268 minecraft:air
fill 8 82 -267 9 82 -267 minecraft:air
fill 17 82 -267 19 82 -267 minecraft:air
fill 25 82 -267 26 82 -267 minecraft:air
fill 8 82 -266 10 82 -266 minecraft:air
setblock 15 82 -266 minecraft:air
fill 17 82 -266 19 82 -266 minecraft:air
fill 8 82 -265 9 82 -265 minecraft:air
setblock 11 82 -265 minecraft:air
fill 14 82 -265 16 82 -265 minecraft:air
setblock 8 82 -264 minecraft:air
fill 13 82 -264 17 82 -264 minecraft:air
fill 14 82 -263 16 82 -263 minecraft:air
setblock 15 82 -262 minecraft:air
setblock 20 82 -262 minecraft:air
setblock 12 82 -261 minecraft:air
fill 11 82 -260 13 82 -260 minecraft:air
setblock 25 82 -260 minecraft:air
fill 10 82 -259 14 82 -259 minecraft:air
fill 24 82 -259 25 82 -259 minecraft:air
fill 11 82 -258 13 82 -258 minecraft:air
setblock 25 82 -258 minecraft:air
setblock 12 82 -257 minecraft:air
setblock 26 82 -257 minecraft:air
setblock 18 82 -256 minecraft:air
setblock 12 83 -314 minecraft:air
setblock 20 83 -314 minecraft:air
fill 11 83 -313 13 83 -313 minecraft:air
fill 10 83 -312 14 83 -312 minecraft:air
fill 11 83 -311 13 83 -311 minecraft:air
setblock 8 83 -310 minecraft:air
setblock 12 83 -310 minecraft:air
fill 8 83 -309 9 83 -309 minecraft:air
setblock 8 83 -308 minecraft:air
setblock 8 83 -305 minecraft:air
fill 8 83 -304 9 83 -304 minecraft:air
setblock 8 83 -303 minecraft:air
setblock 10 83 -301 minecraft:air
fill 39 83 -297 40 83 -297 minecraft:air
setblock 15 83 -295 minecraft:air
setblock 23 83 -295 minecraft:air
setblock 9 83 -294 minecraft:air
fill 22 83 -294 24 83 -294 minecraft:air
setblock 9 83 -293 minecraft:air
fill 12 83 -293 14 83 -293 minecraft:air
setblock 23 83 -293 minecraft:air
fill 12 83 -292 14 83 -292 minecraft:air
fill 25 83 -292 27 83 -292 minecraft:air
fill 12 83 -291 14 83 -291 minecraft:air
fill 25 83 -291 27 83 -291 minecraft:air
setblock 14 83 -290 minecraft:air
fill 25 83 -290 27 83 -290 minecraft:air
setblock 60 83 -290 minecraft:air
fill 59 83 -289 61 83 -289 minecraft:air
setblock 10 83 -288 minecraft:air
setblock 60 83 -288 minecraft:air
setblock 13 83 -287 minecraft:air
fill 13 83 -286 14 83 -286 minecraft:air
setblock 29 83 -284 minecraft:air
fill 30 83 -283 31 83 -283 minecraft:air
setblock 12 83 -281 minecraft:air
fill 11 83 -280 13 83 -280 minecraft:air
setblock 12 83 -279 minecraft:air
fill 20 83 -279 22 83 -279 minecraft:air
setblock 11 83 -278 minecraft:air
fill 20 83 -278 22 83 -278 minecraft:air
setblock 24 83 -278 minecraft:air
setblock 11 83 -277 minecraft:air
fill 20 83 -277 25 83 -277 minecraft:air
fill 21 83 -276 24 83 -276 minecraft:air
fill 14 83 -275 16 83 -275 minecraft:air
setblock 22 83 -275 minecraft:air
fill 14 83 -274 16 83 -274 minecraft:air
setblock 10 83 -273 minecraft:air
fill 14 83 -273 16 83 -273 minecraft:air
fill 9 83 -272 11 83 -272 minecraft:air
setblock 10 83 -271 minecraft:air
setblock 14 83 -270 minecraft:air
setblock 24 83 -270 minecraft:air
fill 13 83 -269 15 83 -269 minecraft:air
fill 12 83 -268 16 83 -268 minecraft:air
setblock 18 83 -268 minecraft:air
fill 8 83 -267 9 83 -267 minecraft:air
fill 13 83 -267 15 83 -267 minecraft:air
fill 17 83 -267 19 83 -267 minecraft:air
fill 8 83 -266 9 83 -266 minecraft:air
setblock 14 83 -266 minecraft:air
setblock 18 83 -266 minecraft:air
fill 8 83 -265 9 83 -265 minecraft:air
setblock 11 83 -265 minecraft:air
fill 14 83 -265 16 83 -265 minecraft:air
fill 14 83 -264 16 83 -264 minecraft:air
setblock 20 83 -264 minecraft:air
fill 14 83 -263 16 83 -263 minecraft:air
fill 19 83 -263 21 83 -263 minecraft:air
fill 18 83 -262 22 83 -262 minecraft:air
fill 19 83 -261 21 83 -261 minecraft:air
fill 11 83 -260 13 83 -260 minecraft:air
setblock 20 83 -260 minecraft:air
setblock 25 83 -260 minecraft:air
fill 11 83 -259 13 83 -259 minecraft:air
fill 24 83 -259 25 83 -259 minecraft:air
fill 11 83 -258 13 83 -258 minecraft:air
fill 25 83 -258 27 83 -258 minecraft:air
fill 24 83 -257 28 83 -257 minecraft:air
setblock 18 83 -256 minecraft:air
fill 25 83 -256 27 83 -256 minecraft:air
setblock 26 83 -255 minecraft:air
fill 11 84 -313 13 84 -313 minecraft:air
fill 11 84 -312 13 84 -312 minecraft:air
fill 11 84 -311 13 84 -311 minecraft:air
fill 8 84 -304 9 84 -304 minecraft:air
setblock 8 84 -303 minecraft:air
setblock 10 84 -303 minecraft:air
fill 9 84 -302 11 84 -302 minecraft:air
fill 8 84 -301 12 84 -301 minecraft:air
fill 9 84 -300 11 84 -300 minecraft:air
setblock 10 84 -299 minecraft:air
setblock 15 84 -295 minecraft:air
setblock 23 84 -295 minecraft:air
fill 23 84 -294 24 84 -294 minecraft:air
setblock 13 84 -293 minecraft:air
fill 12 84 -292 14 84 -292 minecraft:air
setblock 26 84 -292 minecraft:air
fill 13 84 -291 15 84 -291 minecraft:air
fill 25 84 -291 27 84 -291 minecraft:air
fill 12 84 -290 16 84 -290 minecraft:air
setblock 26 84 -290 minecraft:air
setblock 60 84 -290 minecraft:air
fill 13 84 -289 15 84 -289 minecraft:air
setblock 60 84 -289 minecraft:air
setblock 10 84 -288 minecraft:air
setblock 14 84 -288 minecraft:air
setblock 60 84 -288 minecraft:air
setblock 29 84 -284 minecraft:air
setblock 12 84 -281 minecraft:air
fill 11 84 -280 13 84 -280 minecraft:air
setblock 21 84 -279 minecraft:air
fill 20 84 -278 22 84 -278 minecraft:air
setblock 24 84 -278 minecraft:air
setblock 21 84 -277 minecraft:air
fill 23 84 -277 24 84 -277 minecraft:air
setblock 22 84 -276 minecraft:air
setblock 15 84 -275 minecraft:air
setblock 22 84 -275 minecraft:air
fill 14 84 -274 16 84 -274 minecraft:air
setblock 15 84 -273 minecraft:air
fill 10 84 -272 11 84 -272 minecraft:air
setblock 24 84 -270 minecraft:air
fill 13 84 -269 15 84 -269 minecraft:air
fill 13 84 -268 15 84 -268 minecraft:air
setblock 8 84 -267 minecraft:air
setblock 11 84 -267 minecraft:air
fill 13 84 -267 15 84 -267 minecraft:air
setblock 18 84 -267 minecraft:air
fill 8 84 -266 12 84 -266 minecraft:air
setblock 18 84 -266 minecraft:air
fill 8 84 -265 13 84 -265 minecraft:air
setblock 15 84 -265 minecraft:air
fill 10 84 -264 12 84 -264 minecraft:air
fill 14 84 -264 16 84 -264 minecraft:air
setblock 11 84 -263 minecraft:air
setblock 15 84 -263 minecraft:air
fill 19 84 -263 21 84 -263 minecraft:air
fill 19 84 -262 21 84 -262 minecraft:air
fill 19 84 -261 21 84 -261 minecraft:air
setblock 12 84 -260 minecraft:air
fill 11 84 -259 13 84 -259 minecraft:air
setblock 12 84 -258 minecraft:air
fill 25 84 -258 27 84 -258 minecraft:air
fill 25 84 -257 27 84 -257 minecraft:air
setblock 18 84 -256 minecraft:air
fill 25 84 -256 27 84 -256 minecraft:air
setblock 12 85 -313 minecraft:air
fill 11 85 -312 13 85 -312 minecraft:air
setblock 12 85 -311 minecraft:air
setblock 8 85 -310 minecraft:air
fill 9 85 -302 11 85 -302 minecraft:air
fill 9 85 -301 11 85 -301 minecraft:air
fill 9 85 -300 11 85 -300 minecraft:air
setblock 15 85 -297 minecraft:air
fill 14 85 -296 16 85 -296 minecraft:air
fill 13 85 -295 17 85 -295 minecraft:air
fill 14 85 -294 16 85 -294 minecraft:air
setblock 13 85 -293 minecraft:air
setblock 15 85 -293 minecraft:air
fill 12 85 -292 14 85 -292 minecraft:air
setblock 26 85 -292 minecraft:air
fill 13 85 -291 15 85 -291 minecraft:air
setblock 26 85 -291 minecraft:air
setblock 10 85 -290 minecraft:air
fill 13 85 -290 15 85 -290 minecraft:air
setblock 26 85 -290 minecraft:air
fill 9 85 -289 11 85 -289 minecraft:air
fill 13 85 -289 15 85 -289 minecraft:air
fill 8 85 -288 12 85 -288 minecraft:air
fill 9 85 -287 11 85 -287 minecraft:air
setblock 10 85 -286 minecraft:air
setblock 21 85 -279 minecraft:air
setblock 21 85 -278 minecraft:air
setblock 15 85 -275 minecraft:air
fill 14 85 -274 16 85 -274 minecraft:air
setblock 24 85 -272 minecraft:air
fill 23 85 -271 25 85 -271 minecraft:air
fill 22 85 -270 26 85 -270 minecraft:air
setblock 14 85 -269 minecraft:air
fill 23 85 -269 25 85 -269 minecraft:air
fill 13 85 -268 15 85 -268 minecraft:air
setblock 24 85 -268 minecraft:air
setblock 8 85 -267 minecraft:air
setblock 14 85 -267 minecraft:air
fill 8 85 -266 12 85 -266 minecraft:air
fill 10 85 -265 12 85 -265 minecraft:air
fill 10 85 -264 12 85 -264 minecraft:air
setblock 15 85 -264 minecraft:air
setblock 20 85 -263 minecraft:air
fill 19 85 -262 21 85 -262 minecraft:air
setblock 20 85 -261 minecraft:air
setblock 12 85 -260 minecraft:air
fill 11 85 -259 13 85 -259 minecraft:air
setblock 12 85 -258 minecraft:air
setblock 26 85 -258 minecraft:air
fill 25 85 -257 27 85 -257 minecraft:air
setblock 18 85 -256 minecraft:air
setblock 26 85 -256 minecraft:air
fill 11 86 -312 12 86 -312 minecraft:air
setblock 12 86 -311 minecraft:air
setblock 10 86 -302 minecraft:air
fill 9 86 -301 11 86 -301 minecraft:air
setblock 10 86 -300 minecraft:air
fill 14 86 -296 16 86 -296 minecraft:air
fill 14 86 -295 16 86 -295 minecraft:air
fill 14 86 -294 16 86 -294 minecraft:air
setblock 14 86 -291 minecraft:air
fill 13 86 -290 15 86 -290 minecraft:air
fill 9 86 -289 11 86 -289 minecraft:air
setblock 14 86 -289 minecraft:air
fill 9 86 -288 11 86 -288 minecraft:air
fill 9 86 -287 11 86 -287 minecraft:air
fill 23 86 -271 25 86 -271 minecraft:air
fill 23 86 -270 25 86 -270 minecraft:air
fill 23 86 -269 25 86 -269 minecraft:air
fill 14 86 -268 15 86 -268 minecraft:air
setblock 14 86 -267 minecraft:air
setblock 11 86 -266 minecraft:air
fill 10 86 -265 12 86 -265 minecraft:air
setblock 11 86 -264 minecraft:air
fill 19 86 -262 20 86 -262 minecraft:air
setblock 20 86 -261 minecraft:air
setblock 26 86 -258 minecraft:air
fill 25 86 -257 26 86 -257 minecraft:air
setblock 18 86 -256 minecraft:air
setblock 26 86 -256 minecraft:air
setblock 10 87 -302 minecraft:air
fill 9 87 -301 10 87 -301 minecraft:air
setblock 10 87 -300 minecraft:air
setblock 15 87 -296 minecraft:air
fill 14 87 -295 16 87 -295 minecraft:air
setblock 15 87 -294 minecraft:air
setblock 14 87 -291 minecraft:air
setblock 14 87 -290 minecraft:air
setblock 10 87 -289 minecraft:air
setblock 14 87 -289 minecraft:air
fill 9 87 -288 11 87 -288 minecraft:air
setblock 10 87 -287 minecraft:air
setblock 24 87 -271 minecraft:air
fill 23 87 -270 25 87 -270 minecraft:air
setblock 24 87 -269 minecraft:air
setblock 11 87 -266 minecraft:air
setblock 11 87 -265 minecraft:air
setblock 11 87 -264 minecraft:air
setblock 18 87 -258 minecraft:air
fill 17 87 -257 19 87 -257 minecraft:air
fill 16 87 -256 20 87 -256 minecraft:air
fill 17 87 -255 19 87 -255 minecraft:air
fill 15 88 -295 16 88 -295 minecraft:air
setblock 15 88 -294 minecraft:air
fill 10 88 -288 11 88 -288 minecraft:air
setblock 10 88 -287 minecraft:air
fill 23 88 -270 25 88 -270 minecraft:air
fill 17 88 -257 19 88 -257 minecraft:air
fill 17 88 -256 19 88 -256 minecraft:air
fill 17 88 -255 19 88 -255 minecraft:air
setblock 18 89 -257 minecraft:air
fill 17 89 -256 19 89 -256 minecraft:air
setblock 18 89 -255 minecraft:air
setblock 18 90 -256 minecraft:air
forceload remove 8 -318 71 -255
tellraw @a {"text":"Campus bau a15 fertig.","color":"green"}
