# Abschnitt a23: x 72..135, z -254..-191 (3815 Blöcke)
forceload add 72 -254 135 -191
tellraw @a {"text":"Campus bau a23: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a23_1 2s
