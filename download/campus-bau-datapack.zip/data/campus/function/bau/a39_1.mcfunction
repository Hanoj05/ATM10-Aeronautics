fill 200 45 -126 234 45 -126 minecraft:stone
fill 237 45 -126 263 45 -126 minecraft:stone
fill 200 45 -125 234 45 -125 minecraft:stone
fill 237 45 -125 250 45 -125 minecraft:stone
fill 258 45 -125 263 45 -125 minecraft:stone
fill 200 45 -124 214 45 -124 minecraft:stone
fill 219 45 -124 235 45 -124 minecraft:stone
fill 237 45 -124 249 45 -124 minecraft:stone
fill 258 45 -124 263 45 -124 minecraft:stone
fill 200 45 -123 202 45 -123 minecraft:stone
fill 204 45 -123 206 45 -123 minecraft:stone
fill 220 45 -123 235 45 -123 minecraft:stone
fill 238 45 -123 249 45 -123 minecraft:stone
fill 257 45 -123 263 45 -123 minecraft:stone
fill 200 45 -122 201 45 -122 minecraft:stone
fill 220 45 -122 235 45 -122 minecraft:stone
fill 238 45 -122 248 45 -122 minecraft:stone
fill 257 45 -122 263 45 -122 minecraft:stone
fill 200 45 -121 202 45 -121 minecraft:stone
fill 215 45 -121 218 45 -121 minecraft:stone
fill 221 45 -121 235 45 -121 minecraft:stone
fill 238 45 -121 247 45 -121 minecraft:stone
fill 256 45 -121 263 45 -121 minecraft:stone
fill 200 45 -120 201 45 -120 minecraft:stone
fill 207 45 -120 218 45 -120 minecraft:stone
fill 220 45 -120 235 45 -120 minecraft:stone
fill 238 45 -120 246 45 -120 minecraft:stone
fill 255 45 -120 263 45 -120 minecraft:stone
fill 200 45 -119 201 45 -119 minecraft:stone
fill 204 45 -119 218 45 -119 minecraft:stone
fill 221 45 -119 235 45 -119 minecraft:stone
fill 239 45 -119 245 45 -119 minecraft:stone
fill 255 45 -119 263 45 -119 minecraft:stone
fill 200 45 -118 201 45 -118 minecraft:stone
fill 204 45 -118 219 45 -118 minecraft:stone
fill 221 45 -118 235 45 -118 minecraft:stone
fill 237 45 -118 245 45 -118 minecraft:stone
fill 254 45 -118 260 45 -118 minecraft:stone
fill 262 45 -118 263 45 -118 minecraft:stone
fill 200 45 -117 201 45 -117 minecraft:stone
fill 204 45 -117 219 45 -117 minecraft:stone
fill 221 45 -117 223 45 -117 minecraft:stone
fill 227 45 -117 234 45 -117 minecraft:stone
fill 236 45 -117 245 45 -117 minecraft:stone
fill 253 45 -117 260 45 -117 minecraft:stone
fill 262 45 -117 263 45 -117 minecraft:stone
setblock 200 45 -116 minecraft:stone
fill 203 45 -116 220 45 -116 minecraft:stone
fill 235 45 -116 244 45 -116 minecraft:stone
fill 252 45 -116 259 45 -116 minecraft:stone
fill 262 45 -116 263 45 -116 minecraft:stone
fill 200 46 -126 235 46 -126 minecraft:stone
fill 238 46 -126 263 46 -126 minecraft:stone
fill 200 46 -125 236 46 -125 minecraft:stone
fill 239 46 -125 251 46 -125 minecraft:stone
fill 256 46 -125 263 46 -125 minecraft:stone
fill 201 46 -124 236 46 -124 minecraft:stone
fill 239 46 -124 249 46 -124 minecraft:stone
fill 257 46 -124 263 46 -124 minecraft:stone
fill 200 46 -123 216 46 -123 minecraft:stone
fill 219 46 -123 236 46 -123 minecraft:stone
fill 239 46 -123 248 46 -123 minecraft:stone
fill 257 46 -123 263 46 -123 minecraft:stone
fill 200 46 -122 208 46 -122 minecraft:stone
fill 219 46 -122 236 46 -122 minecraft:stone
fill 239 46 -122 247 46 -122 minecraft:stone
fill 256 46 -122 263 46 -122 minecraft:stone
fill 200 46 -121 201 46 -121 minecraft:stone
fill 220 46 -121 236 46 -121 minecraft:stone
fill 239 46 -121 246 46 -121 minecraft:stone
fill 256 46 -121 263 46 -121 minecraft:stone
fill 200 46 -120 201 46 -120 minecraft:stone
fill 217 46 -120 218 46 -120 minecraft:stone
fill 220 46 -120 236 46 -120 minecraft:stone
fill 239 46 -120 245 46 -120 minecraft:stone
fill 255 46 -120 263 46 -120 minecraft:stone
fill 200 46 -119 201 46 -119 minecraft:stone
fill 209 46 -119 218 46 -119 minecraft:stone
fill 221 46 -119 236 46 -119 minecraft:stone
fill 239 46 -119 245 46 -119 minecraft:stone
fill 255 46 -119 263 46 -119 minecraft:stone
fill 200 46 -118 201 46 -118 minecraft:stone
fill 204 46 -118 219 46 -118 minecraft:stone
fill 221 46 -118 235 46 -118 minecraft:stone
fill 238 46 -118 245 46 -118 minecraft:stone
fill 254 46 -118 260 46 -118 minecraft:stone
fill 262 46 -118 263 46 -118 minecraft:stone
fill 200 46 -117 201 46 -117 minecraft:stone
fill 204 46 -117 219 46 -117 minecraft:stone
fill 221 46 -117 233 46 -117 minecraft:stone
fill 236 46 -117 244 46 -117 minecraft:stone
fill 253 46 -117 260 46 -117 minecraft:stone
fill 262 46 -117 263 46 -117 minecraft:stone
setblock 200 46 -116 minecraft:stone
fill 203 46 -116 219 46 -116 minecraft:stone
setblock 232 46 -116 minecraft:stone
fill 235 46 -116 244 46 -116 minecraft:stone
fill 252 46 -116 259 46 -116 minecraft:stone
fill 262 46 -116 263 46 -116 minecraft:stone
fill 201 47 -126 236 47 -126 minecraft:stone
fill 239 47 -126 263 47 -126 minecraft:stone
fill 201 47 -125 236 47 -125 minecraft:stone
fill 239 47 -125 251 47 -125 minecraft:stone
fill 256 47 -125 263 47 -125 minecraft:stone
fill 202 47 -124 236 47 -124 minecraft:stone
fill 239 47 -124 249 47 -124 minecraft:stone
fill 257 47 -124 263 47 -124 minecraft:stone
fill 202 47 -123 236 47 -123 minecraft:stone
fill 239 47 -123 248 47 -123 minecraft:stone
fill 257 47 -123 263 47 -123 minecraft:stone
fill 202 47 -122 237 47 -122 minecraft:stone
fill 239 47 -122 247 47 -122 minecraft:stone
fill 257 47 -122 263 47 -122 minecraft:stone
fill 202 47 -121 210 47 -121 minecraft:stone
fill 220 47 -121 237 47 -121 minecraft:stone
fill 239 47 -121 246 47 -121 minecraft:stone
fill 256 47 -121 263 47 -121 minecraft:stone
fill 220 47 -120 237 47 -120 minecraft:stone
fill 239 47 -120 245 47 -120 minecraft:stone
fill 256 47 -120 263 47 -120 minecraft:stone
setblock 201 47 -119 minecraft:stone
fill 220 47 -119 236 47 -119 minecraft:stone
fill 239 47 -119 245 47 -119 minecraft:stone
fill 255 47 -119 263 47 -119 minecraft:stone
setblock 201 47 -118 minecraft:stone
fill 211 47 -118 218 47 -118 minecraft:stone
fill 220 47 -118 235 47 -118 minecraft:stone
fill 238 47 -118 245 47 -118 minecraft:stone
fill 255 47 -118 260 47 -118 minecraft:stone
fill 262 47 -118 263 47 -118 minecraft:stone
setblock 201 47 -117 minecraft:stone
fill 204 47 -117 218 47 -117 minecraft:stone
fill 221 47 -117 234 47 -117 minecraft:stone
fill 237 47 -117 244 47 -117 minecraft:stone
fill 254 47 -117 259 47 -117 minecraft:stone
fill 262 47 -117 263 47 -117 minecraft:stone
setblock 200 47 -116 minecraft:stone
fill 203 47 -116 219 47 -116 minecraft:stone
fill 222 47 -116 233 47 -116 minecraft:stone
fill 235 47 -116 244 47 -116 minecraft:stone
fill 253 47 -116 259 47 -116 minecraft:stone
fill 261 47 -116 263 47 -116 minecraft:stone
fill 201 48 -126 236 48 -126 minecraft:stone
fill 238 48 -126 263 48 -126 minecraft:stone
fill 201 48 -125 236 48 -125 minecraft:stone
fill 239 48 -125 251 48 -125 minecraft:stone
fill 255 48 -125 263 48 -125 minecraft:stone
fill 201 48 -124 236 48 -124 minecraft:stone
fill 239 48 -124 249 48 -124 minecraft:stone
fill 258 48 -124 263 48 -124 minecraft:stone
fill 202 48 -123 236 48 -123 minecraft:stone
fill 240 48 -123 248 48 -123 minecraft:stone
fill 258 48 -123 263 48 -123 minecraft:stone
fill 202 48 -122 237 48 -122 minecraft:stone
fill 240 48 -122 247 48 -122 minecraft:stone
fill 258 48 -122 263 48 -122 minecraft:stone
fill 202 48 -121 217 48 -121 minecraft:stone
fill 219 48 -121 237 48 -121 minecraft:stone
fill 240 48 -121 246 48 -121 minecraft:stone
fill 257 48 -121 263 48 -121 minecraft:stone
fill 203 48 -120 212 48 -120 minecraft:stone
fill 219 48 -120 237 48 -120 minecraft:stone
fill 239 48 -120 245 48 -120 minecraft:stone
fill 257 48 -120 263 48 -120 minecraft:stone
fill 203 48 -119 204 48 -119 minecraft:stone
fill 219 48 -119 236 48 -119 minecraft:stone
fill 239 48 -119 245 48 -119 minecraft:stone
fill 256 48 -119 263 48 -119 minecraft:stone
fill 220 48 -118 235 48 -118 minecraft:stone
fill 238 48 -118 245 48 -118 minecraft:stone
fill 256 48 -118 259 48 -118 minecraft:stone
fill 261 48 -118 263 48 -118 minecraft:stone
fill 213 48 -117 218 48 -117 minecraft:stone
fill 220 48 -117 234 48 -117 minecraft:stone
fill 237 48 -117 244 48 -117 minecraft:stone
fill 256 48 -117 258 48 -117 minecraft:stone
fill 261 48 -117 263 48 -117 minecraft:stone
fill 205 48 -116 210 48 -116 minecraft:stone
fill 213 48 -116 219 48 -116 minecraft:stone
fill 222 48 -116 233 48 -116 minecraft:stone
fill 236 48 -116 244 48 -116 minecraft:stone
fill 255 48 -116 257 48 -116 minecraft:stone
fill 261 48 -116 263 48 -116 minecraft:stone
fill 225 49 -119 227 49 -119 minecraft:stone
fill 224 49 -118 227 49 -118 minecraft:stone
fill 223 49 -117 227 49 -117 minecraft:stone
setblock 213 49 -116 minecraft:stone
fill 223 49 -116 226 49 -116 minecraft:stone
fill 225 50 -119 227 50 -119 minecraft:stone
fill 224 50 -118 227 50 -118 minecraft:stone
fill 223 50 -117 227 50 -117 minecraft:stone
fill 222 50 -116 227 50 -116 minecraft:stone
setblock 226 51 -118 minecraft:stone
fill 224 51 -117 225 51 -117 minecraft:stone
fill 223 51 -116 225 51 -116 minecraft:stone
fill 258 63 -126 263 63 -126 minecraft:dirt
fill 259 63 -125 263 63 -125 minecraft:dirt
fill 260 63 -124 263 63 -124 minecraft:dirt
fill 259 63 -123 263 63 -123 minecraft:dirt
fill 258 63 -122 263 63 -122 minecraft:dirt
fill 258 63 -121 263 63 -121 minecraft:dirt
fill 257 63 -120 263 63 -120 minecraft:dirt
fill 252 63 -119 263 63 -119 minecraft:dirt
setblock 252 63 -118 minecraft:dirt
fill 254 63 -118 263 63 -118 minecraft:dirt
fill 252 63 -117 263 63 -117 minecraft:dirt
fill 225 63 -116 229 63 -116 minecraft:dirt
fill 253 63 -116 263 63 -116 minecraft:dirt
fill 213 64 -126 263 64 -126 minecraft:water
fill 223 64 -125 263 64 -125 minecraft:dirt
fill 220 64 -124 224 64 -124 minecraft:dirt
fill 227 64 -124 236 64 -124 minecraft:dirt
fill 238 64 -124 239 64 -124 minecraft:dirt
fill 241 64 -124 263 64 -124 minecraft:dirt
fill 217 64 -123 263 64 -123 minecraft:dirt
fill 216 64 -122 263 64 -122 minecraft:dirt
fill 214 64 -121 263 64 -121 minecraft:dirt
fill 200 64 -120 202 64 -120 minecraft:dirt
fill 212 64 -120 230 64 -120 minecraft:dirt
fill 232 64 -120 242 64 -120 minecraft:dirt
fill 244 64 -120 263 64 -120 minecraft:dirt
fill 200 64 -119 203 64 -119 minecraft:dirt
fill 206 64 -119 208 64 -119 minecraft:dirt
fill 210 64 -119 235 64 -119 minecraft:dirt
fill 237 64 -119 263 64 -119 minecraft:dirt
fill 200 64 -118 224 64 -118 minecraft:dirt
fill 226 64 -118 246 64 -118 minecraft:dirt
fill 248 64 -118 263 64 -118 minecraft:dirt
fill 200 64 -117 204 64 -117 minecraft:dirt
setblock 206 64 -117 minecraft:dirt
fill 209 64 -117 245 64 -117 minecraft:dirt
fill 247 64 -117 248 64 -117 minecraft:dirt
setblock 250 64 -117 minecraft:dirt
fill 252 64 -117 263 64 -117 minecraft:dirt
fill 200 64 -116 202 64 -116 minecraft:dirt
setblock 205 64 -116 minecraft:dirt
setblock 207 64 -116 minecraft:dirt
fill 210 64 -116 247 64 -116 minecraft:dirt
setblock 249 64 -116 minecraft:dirt
fill 251 64 -116 263 64 -116 minecraft:dirt
fill 200 65 -126 211 65 -126 minecraft:grass_block
setblock 212 65 -126 minecraft:smooth_quartz
fill 213 65 -126 223 65 -126 minecraft:air
fill 200 65 -125 211 65 -125 minecraft:grass_block
fill 212 65 -125 214 65 -125 minecraft:smooth_quartz
setblock 215 65 -125 minecraft:sea_lantern
fill 216 65 -125 220 65 -125 minecraft:smooth_quartz
setblock 221 65 -125 minecraft:sea_lantern
fill 222 65 -125 226 65 -125 minecraft:smooth_quartz
setblock 227 65 -125 minecraft:sea_lantern
fill 228 65 -125 232 65 -125 minecraft:smooth_quartz
setblock 233 65 -125 minecraft:sea_lantern
fill 234 65 -125 238 65 -125 minecraft:smooth_quartz
setblock 239 65 -125 minecraft:sea_lantern
fill 240 65 -125 244 65 -125 minecraft:smooth_quartz
setblock 245 65 -125 minecraft:sea_lantern
fill 246 65 -125 250 65 -125 minecraft:smooth_quartz
setblock 251 65 -125 minecraft:sea_lantern
fill 252 65 -125 256 65 -125 minecraft:smooth_quartz
setblock 257 65 -125 minecraft:sea_lantern
fill 258 65 -125 262 65 -125 minecraft:smooth_quartz
setblock 263 65 -125 minecraft:sea_lantern
fill 200 65 -124 212 65 -124 minecraft:grass_block
fill 215 65 -124 263 65 -124 minecraft:grass_block
setblock 200 65 -123 minecraft:grass_block
fill 203 65 -123 211 65 -123 minecraft:grass_block
fill 214 65 -123 263 65 -123 minecraft:grass_block
fill 200 65 -122 202 65 -122 minecraft:grass_block
fill 207 65 -122 208 65 -122 minecraft:grass_block
fill 213 65 -122 263 65 -122 minecraft:grass_block
fill 200 65 -121 263 65 -121 minecraft:smooth_quartz
setblock 200 65 -120 minecraft:light_gray_concrete
setblock 201 65 -120 minecraft:sea_lantern
fill 202 65 -120 209 65 -120 minecraft:light_gray_concrete
setblock 210 65 -120 minecraft:sea_lantern
fill 211 65 -120 218 65 -120 minecraft:light_gray_concrete
setblock 219 65 -120 minecraft:sea_lantern
fill 220 65 -120 227 65 -120 minecraft:light_gray_concrete
setblock 228 65 -120 minecraft:sea_lantern
fill 229 65 -120 236 65 -120 minecraft:light_gray_concrete
setblock 237 65 -120 minecraft:sea_lantern
fill 238 65 -120 245 65 -120 minecraft:light_gray_concrete
setblock 246 65 -120 minecraft:sea_lantern
fill 247 65 -120 254 65 -120 minecraft:light_gray_concrete
setblock 255 65 -120 minecraft:sea_lantern
fill 256 65 -120 263 65 -120 minecraft:light_gray_concrete
setblock 200 65 -119 minecraft:sea_lantern
fill 201 65 -119 208 65 -119 minecraft:light_gray_concrete
setblock 209 65 -119 minecraft:sea_lantern
fill 210 65 -119 217 65 -119 minecraft:light_gray_concrete
setblock 218 65 -119 minecraft:sea_lantern
fill 219 65 -119 226 65 -119 minecraft:light_gray_concrete
setblock 227 65 -119 minecraft:sea_lantern
fill 228 65 -119 235 65 -119 minecraft:light_gray_concrete
setblock 236 65 -119 minecraft:sea_lantern
fill 237 65 -119 244 65 -119 minecraft:light_gray_concrete
setblock 245 65 -119 minecraft:sea_lantern
fill 246 65 -119 253 65 -119 minecraft:light_gray_concrete
setblock 254 65 -119 minecraft:sea_lantern
fill 255 65 -119 262 65 -119 minecraft:light_gray_concrete
setblock 263 65 -119 minecraft:sea_lantern
fill 200 65 -118 207 65 -118 minecraft:light_gray_concrete
setblock 208 65 -118 minecraft:sea_lantern
fill 209 65 -118 216 65 -118 minecraft:light_gray_concrete
setblock 217 65 -118 minecraft:sea_lantern
fill 218 65 -118 225 65 -118 minecraft:light_gray_concrete
setblock 226 65 -118 minecraft:sea_lantern
fill 227 65 -118 234 65 -118 minecraft:light_gray_concrete
setblock 235 65 -118 minecraft:sea_lantern
fill 236 65 -118 243 65 -118 minecraft:light_gray_concrete
setblock 244 65 -118 minecraft:sea_lantern
fill 245 65 -118 252 65 -118 minecraft:light_gray_concrete
setblock 253 65 -118 minecraft:sea_lantern
fill 254 65 -118 261 65 -118 minecraft:light_gray_concrete
setblock 262 65 -118 minecraft:sea_lantern
setblock 263 65 -118 minecraft:light_gray_concrete
fill 200 65 -117 206 65 -117 minecraft:light_gray_concrete
setblock 207 65 -117 minecraft:sea_lantern
fill 208 65 -117 215 65 -117 minecraft:light_gray_concrete
setblock 216 65 -117 minecraft:sea_lantern
fill 217 65 -117 224 65 -117 minecraft:light_gray_concrete
setblock 225 65 -117 minecraft:sea_lantern
fill 226 65 -117 233 65 -117 minecraft:light_gray_concrete
setblock 234 65 -117 minecraft:sea_lantern
fill 235 65 -117 242 65 -117 minecraft:light_gray_concrete
setblock 243 65 -117 minecraft:sea_lantern
fill 244 65 -117 251 65 -117 minecraft:light_gray_concrete
setblock 252 65 -117 minecraft:sea_lantern
fill 253 65 -117 260 65 -117 minecraft:light_gray_concrete
setblock 261 65 -117 minecraft:sea_lantern
fill 262 65 -117 263 65 -117 minecraft:light_gray_concrete
fill 200 65 -116 263 65 -116 minecraft:light_gray_concrete
fill 200 66 -126 201 66 -126 minecraft:air
setblock 202 66 -126 minecraft:oak_log
fill 203 66 -126 219 66 -126 minecraft:air
fill 200 66 -125 214 66 -125 minecraft:air
setblock 218 66 -125 minecraft:air
fill 200 66 -124 212 66 -124 minecraft:air
setblock 226 66 -124 minecraft:air
setblock 237 66 -124 minecraft:air
fill 203 66 -123 211 66 -123 minecraft:air
fill 207 66 -122 208 66 -122 minecraft:air
setblock 231 66 -120 minecraft:air
setblock 243 66 -120 minecraft:air
setblock 209 66 -119 minecraft:air
setblock 225 66 -119 minecraft:air
fill 224 66 -118 226 66 -118 minecraft:air
setblock 225 66 -117 minecraft:air
setblock 200 67 -126 minecraft:air
setblock 202 67 -126 minecraft:oak_log
fill 203 67 -126 212 67 -126 minecraft:air
setblock 215 67 -126 minecraft:air
setblock 217 67 -126 minecraft:air
setblock 231 67 -126 minecraft:air
fill 205 67 -125 210 67 -125 minecraft:air
setblock 214 67 -125 minecraft:air
setblock 204 67 -124 minecraft:air
fill 206 67 -124 209 67 -124 minecraft:air
setblock 226 67 -124 minecraft:air
setblock 237 67 -124 minecraft:air
setblock 207 67 -123 minecraft:air
setblock 208 67 -122 minecraft:air
setblock 243 67 -121 minecraft:air
fill 223 67 -120 226 67 -120 minecraft:air
setblock 231 67 -120 minecraft:air
fill 242 67 -120 244 67 -120 minecraft:air
setblock 209 67 -119 minecraft:air
fill 223 67 -119 227 67 -119 minecraft:air
setblock 243 67 -119 minecraft:air
fill 223 67 -118 227 67 -118 minecraft:air
fill 223 67 -117 227 67 -117 minecraft:air
fill 224 67 -116 227 67 -116 minecraft:air
setblock 202 68 -126 minecraft:oak_log
fill 207 68 -126 209 68 -126 minecraft:air
fill 229 68 -126 233 68 -126 minecraft:air
setblock 206 68 -125 minecraft:air
setblock 226 68 -125 minecraft:air
fill 229 68 -125 232 68 -125 minecraft:air
setblock 237 68 -125 minecraft:air
setblock 208 68 -124 minecraft:air
fill 225 68 -124 227 68 -124 minecraft:air
fill 236 68 -124 238 68 -124 minecraft:air
setblock 226 68 -123 minecraft:air
setblock 237 68 -123 minecraft:air
fill 242 68 -122 245 68 -122 minecraft:air
fill 241 68 -121 245 68 -121 minecraft:air
fill 224 68 -120 226 68 -120 minecraft:air
setblock 231 68 -120 minecraft:air
fill 241 68 -120 245 68 -120 minecraft:air
setblock 209 68 -119 minecraft:air
fill 223 68 -119 227 68 -119 minecraft:air
fill 241 68 -119 245 68 -119 minecraft:air
fill 223 68 -118 227 68 -118 minecraft:air
fill 241 68 -118 244 68 -118 minecraft:air
fill 223 68 -117 227 68 -117 minecraft:air
fill 224 68 -116 226 68 -116 minecraft:air
fill 200 69 -126 201 69 -126 minecraft:oak_leaves[persistent=true]
setblock 202 69 -126 minecraft:oak_log
fill 203 69 -126 204 69 -126 minecraft:oak_leaves[persistent=true]
fill 225 69 -126 233 69 -126 minecraft:air
fill 235 69 -126 239 69 -126 minecraft:air
setblock 250 69 -126 minecraft:air
fill 201 69 -125 203 69 -125 minecraft:oak_leaves[persistent=true]
fill 224 69 -125 228 69 -125 minecraft:air
fill 230 69 -125 232 69 -125 minecraft:air
fill 235 69 -125 239 69 -125 minecraft:air
setblock 202 69 -124 minecraft:oak_leaves[persistent=true]
setblock 208 69 -124 minecraft:air
fill 224 69 -124 228 69 -124 minecraft:air
fill 235 69 -124 239 69 -124 minecraft:air
fill 224 69 -123 228 69 -123 minecraft:air
fill 235 69 -123 239 69 -123 minecraft:air
fill 224 69 -122 227 69 -122 minecraft:air
fill 230 69 -122 232 69 -122 minecraft:air
fill 236 69 -122 238 69 -122 minecraft:air
fill 242 69 -122 245 69 -122 minecraft:air
fill 229 69 -121 233 69 -121 minecraft:air
fill 241 69 -121 245 69 -121 minecraft:air
fill 229 69 -120 233 69 -120 minecraft:air
fill 241 69 -120 245 69 -120 minecraft:air
setblock 209 69 -119 minecraft:air
fill 224 69 -119 226 69 -119 minecraft:air
fill 229 69 -119 233 69 -119 minecraft:air
fill 241 69 -119 245 69 -119 minecraft:air
fill 224 69 -118 226 69 -118 minecraft:air
fill 230 69 -118 232 69 -118 minecraft:air
fill 241 69 -118 244 69 -118 minecraft:air
fill 224 69 -117 226 69 -117 minecraft:air
setblock 225 69 -116 minecraft:air
fill 200 70 -126 201 70 -126 minecraft:oak_leaves[persistent=true]
setblock 202 70 -126 minecraft:oak_log
fill 203 70 -126 204 70 -126 minecraft:oak_leaves[persistent=true]
fill 225 70 -126 227 70 -126 minecraft:air
fill 230 70 -126 232 70 -126 minecraft:air
fill 236 70 -126 239 70 -126 minecraft:air
fill 247 70 -126 253 70 -126 minecraft:air
fill 200 70 -125 204 70 -125 minecraft:oak_leaves[persistent=true]
fill 224 70 -125 228 70 -125 minecraft:air
setblock 231 70 -125 minecraft:air
fill 235 70 -125 239 70 -125 minecraft:air
fill 247 70 -125 253 70 -125 minecraft:air
fill 201 70 -124 203 70 -124 minecraft:oak_leaves[persistent=true]
setblock 208 70 -124 minecraft:air
fill 224 70 -124 228 70 -124 minecraft:air
fill 235 70 -124 239 70 -124 minecraft:air
fill 248 70 -124 252 70 -124 minecraft:air
fill 224 70 -123 228 70 -123 minecraft:air
fill 235 70 -123 239 70 -123 minecraft:air
fill 225 70 -122 228 70 -122 minecraft:air
fill 236 70 -122 238 70 -122 minecraft:air
setblock 243 70 -122 minecraft:air
setblock 231 70 -121 minecraft:air
fill 242 70 -121 244 70 -121 minecraft:air
setblock 209 70 -120 minecraft:air
fill 230 70 -120 232 70 -120 minecraft:air
fill 241 70 -120 244 70 -120 minecraft:air
fill 208 70 -119 210 70 -119 minecraft:air
setblock 225 70 -119 minecraft:air
setblock 231 70 -119 minecraft:air
fill 242 70 -119 244 70 -119 minecraft:air
setblock 209 70 -118 minecraft:air
fill 224 70 -118 226 70 -118 minecraft:air
setblock 243 70 -118 minecraft:air
setblock 225 70 -117 minecraft:air
fill 200 71 -126 204 71 -126 minecraft:oak_leaves[persistent=true]
fill 219 71 -126 222 71 -126 minecraft:air
setblock 226 71 -126 minecraft:air
fill 231 71 -126 232 71 -126 minecraft:air
setblock 237 71 -126 minecraft:air
fill 248 71 -126 252 71 -126 minecraft:air
fill 201 71 -125 203 71 -125 minecraft:oak_leaves[persistent=true]
fill 225 71 -125 227 71 -125 minecraft:air
fill 236 71 -125 238 71 -125 minecraft:air
fill 249 71 -125 251 71 -125 minecraft:air
setblock 202 71 -124 minecraft:oak_leaves[persistent=true]
setblock 208 71 -124 minecraft:air
fill 224 71 -124 228 71 -124 minecraft:air
fill 235 71 -124 239 71 -124 minecraft:air
fill 225 71 -123 227 71 -123 minecraft:air
fill 229 71 -123 233 71 -123 minecraft:air
fill 236 71 -123 238 71 -123 minecraft:air
fill 228 71 -122 234 71 -122 minecraft:air
setblock 237 71 -122 minecraft:air
fill 208 71 -121 211 71 -121 minecraft:air
fill 228 71 -121 234 71 -121 minecraft:air
fill 243 71 -121 244 71 -121 minecraft:air
fill 207 71 -120 211 71 -120 minecraft:air
fill 228 71 -120 234 71 -120 minecraft:air
fill 242 71 -120 244 71 -120 minecraft:air
fill 207 71 -119 211 71 -119 minecraft:air
setblock 225 71 -119 minecraft:air
fill 228 71 -119 234 71 -119 minecraft:air
setblock 243 71 -119 minecraft:air
fill 207 71 -118 211 71 -118 minecraft:air
fill 224 71 -118 226 71 -118 minecraft:air
fill 228 71 -118 234 71 -118 minecraft:air
fill 208 71 -117 211 71 -117 minecraft:air
fill 224 71 -117 225 71 -117 minecraft:air
fill 229 71 -117 233 71 -117 minecraft:air
setblock 200 72 -126 minecraft:air
setblock 202 72 -126 minecraft:oak_leaves[persistent=true]
fill 219 72 -126 222 72 -126 minecraft:air
fill 230 72 -126 231 72 -126 minecraft:air
setblock 250 72 -126 minecraft:air
setblock 200 72 -125 minecraft:air
fill 226 72 -125 227 72 -125 minecraft:air
fill 236 72 -125 237 72 -125 minecraft:air
setblock 208 72 -124 minecraft:air
fill 225 72 -124 227 72 -124 minecraft:air
fill 236 72 -124 238 72 -124 minecraft:air
setblock 226 72 -123 minecraft:air
setblock 237 72 -123 minecraft:air
fill 230 72 -122 232 72 -122 minecraft:air
fill 208 72 -121 211 72 -121 minecraft:air
fill 229 72 -121 233 72 -121 minecraft:air
setblock 243 72 -121 minecraft:air
fill 207 72 -120 211 72 -120 minecraft:air
fill 229 72 -120 233 72 -120 minecraft:air
fill 242 72 -120 244 72 -120 minecraft:air
fill 207 72 -119 211 72 -119 minecraft:air
fill 229 72 -119 233 72 -119 minecraft:air
fill 243 72 -119 244 72 -119 minecraft:air
fill 207 72 -118 211 72 -118 minecraft:air
setblock 225 72 -118 minecraft:air
fill 230 72 -118 232 72 -118 minecraft:air
fill 207 72 -117 211 72 -117 minecraft:air
setblock 200 73 -126 minecraft:air
fill 247 73 -126 253 73 -126 minecraft:air
fill 225 73 -125 226 73 -125 minecraft:air
fill 237 73 -125 238 73 -125 minecraft:air
fill 247 73 -125 253 73 -125 minecraft:air
setblock 208 73 -124 minecraft:air
fill 225 73 -124 227 73 -124 minecraft:air
fill 236 73 -124 238 73 -124 minecraft:air
fill 248 73 -124 252 73 -124 minecraft:air
fill 207 73 -123 210 73 -123 minecraft:air
setblock 226 73 -123 minecraft:air
setblock 237 73 -123 minecraft:air
fill 206 73 -122 208 73 -122 minecraft:air
setblock 207 73 -121 minecraft:air
setblock 209 73 -121 minecraft:air
setblock 231 73 -121 minecraft:air
fill 208 73 -120 210 73 -120 minecraft:air
fill 230 73 -120 232 73 -120 minecraft:air
setblock 243 73 -120 minecraft:air
fill 208 73 -119 211 73 -119 minecraft:air
setblock 231 73 -119 minecraft:air
fill 208 73 -118 210 73 -118 minecraft:air
setblock 209 73 -117 minecraft:air
fill 248 74 -126 252 74 -126 minecraft:air
fill 249 74 -125 251 74 -125 minecraft:air
fill 206 74 -124 208 74 -124 minecraft:air
setblock 226 74 -124 minecraft:air
setblock 237 74 -124 minecraft:air
fill 205 74 -123 209 74 -123 minecraft:air
setblock 212 74 -123 minecraft:air
fill 229 74 -123 233 74 -123 minecraft:air
fill 205 74 -122 209 74 -122 minecraft:air
fill 211 74 -122 213 74 -122 minecraft:air
fill 228 74 -122 234 74 -122 minecraft:air
fill 205 74 -121 209 74 -121 minecraft:air
setblock 212 74 -121 minecraft:air
fill 228 74 -121 234 74 -121 minecraft:air
fill 206 74 -120 209 74 -120 minecraft:air
fill 228 74 -120 234 74 -120 minecraft:air
fill 208 74 -119 210 74 -119 minecraft:air
fill 228 74 -119 234 74 -119 minecraft:air
fill 209 74 -118 210 74 -118 minecraft:air
fill 228 74 -118 234 74 -118 minecraft:air
fill 229 74 -117 233 74 -117 minecraft:air
setblock 250 75 -126 minecraft:air
setblock 205 75 -125 minecraft:air
setblock 209 75 -125 minecraft:air
fill 204 75 -124 208 75 -124 minecraft:air
fill 211 75 -124 213 75 -124 minecraft:air
fill 205 75 -123 214 75 -123 minecraft:air
fill 205 75 -122 214 75 -122 minecraft:air
fill 230 75 -122 232 75 -122 minecraft:air
fill 205 75 -121 214 75 -121 minecraft:air
fill 229 75 -121 233 75 -121 minecraft:air
fill 206 75 -120 209 75 -120 minecraft:air
fill 211 75 -120 213 75 -120 minecraft:air
fill 229 75 -120 233 75 -120 minecraft:air
fill 208 75 -119 210 75 -119 minecraft:air
fill 229 75 -119 233 75 -119 minecraft:air
fill 209 75 -118 210 75 -118 minecraft:air
fill 230 75 -118 232 75 -118 minecraft:air
fill 204 76 -126 206 76 -126 minecraft:air
fill 209 76 -126 211 76 -126 minecraft:air
fill 214 76 -126 216 76 -126 minecraft:air
fill 247 76 -126 253 76 -126 minecraft:air
fill 203 76 -125 207 76 -125 minecraft:air
setblock 210 76 -125 minecraft:air
fill 247 76 -125 253 76 -125 minecraft:air
fill 203 76 -124 208 76 -124 minecraft:air
fill 211 76 -124 213 76 -124 minecraft:air
fill 248 76 -124 252 76 -124 minecraft:air
fill 203 76 -123 214 76 -123 minecraft:air
fill 204 76 -122 214 76 -122 minecraft:air
fill 205 76 -121 214 76 -121 minecraft:air
setblock 231 76 -121 minecraft:air
fill 206 76 -120 208 76 -120 minecraft:air
fill 211 76 -120 213 76 -120 minecraft:air
fill 230 76 -120 232 76 -120 minecraft:air
setblock 209 76 -119 minecraft:air
setblock 231 76 -119 minecraft:air
fill 204 77 -126 206 77 -126 minecraft:air
fill 208 77 -126 212 77 -126 minecraft:air
fill 214 77 -126 216 77 -126 minecraft:air
fill 248 77 -126 252 77 -126 minecraft:air
fill 203 77 -125 212 77 -125 minecraft:air
fill 249 77 -125 251 77 -125 minecraft:air
fill 203 77 -124 213 77 -124 minecraft:air
fill 203 77 -123 207 77 -123 minecraft:air
fill 210 77 -123 214 77 -123 minecraft:air
fill 229 77 -123 233 77 -123 minecraft:air
fill 204 77 -122 208 77 -122 minecraft:air
fill 210 77 -122 214 77 -122 minecraft:air
fill 228 77 -122 234 77 -122 minecraft:air
setblock 207 77 -121 minecraft:air
fill 210 77 -121 214 77 -121 minecraft:air
fill 228 77 -121 234 77 -121 minecraft:air
fill 211 77 -120 213 77 -120 minecraft:air
fill 228 77 -120 234 77 -120 minecraft:air
fill 228 77 -119 234 77 -119 minecraft:air
fill 228 77 -118 234 77 -118 minecraft:air
fill 229 77 -117 233 77 -117 minecraft:air
fill 202 78 -126 206 78 -126 minecraft:air
fill 208 78 -126 212 78 -126 minecraft:air
fill 214 78 -126 216 78 -126 minecraft:air
setblock 250 78 -126 minecraft:air
fill 203 78 -125 212 78 -125 minecraft:air
fill 203 78 -124 211 78 -124 minecraft:air
fill 203 78 -123 208 78 -123 minecraft:air
setblock 212 78 -123 minecraft:air
fill 204 78 -122 207 78 -122 minecraft:air
fill 211 78 -122 213 78 -122 minecraft:air
fill 230 78 -122 232 78 -122 minecraft:air
setblock 212 78 -121 minecraft:air
fill 229 78 -121 233 78 -121 minecraft:air
fill 229 78 -120 233 78 -120 minecraft:air
fill 229 78 -119 233 78 -119 minecraft:air
fill 230 78 -118 232 78 -118 minecraft:air
fill 202 79 -126 206 79 -126 minecraft:air
fill 208 79 -126 212 79 -126 minecraft:air
fill 248 79 -126 252 79 -126 minecraft:air
fill 203 79 -125 205 79 -125 minecraft:air
fill 208 79 -125 212 79 -125 minecraft:air
fill 249 79 -125 251 79 -125 minecraft:air
fill 204 79 -124 206 79 -124 minecraft:air
fill 208 79 -124 212 79 -124 minecraft:air
setblock 205 79 -123 minecraft:air
fill 209 79 -123 211 79 -123 minecraft:air
fill 206 79 -121 207 79 -121 minecraft:air
setblock 231 79 -121 minecraft:air
fill 205 79 -120 207 79 -120 minecraft:air
fill 230 79 -120 232 79 -120 minecraft:air
setblock 206 79 -119 minecraft:air
setblock 231 79 -119 minecraft:air
fill 202 80 -126 206 80 -126 minecraft:air
fill 208 80 -126 212 80 -126 minecraft:air
setblock 250 80 -126 minecraft:air
fill 203 80 -125 205 80 -125 minecraft:air
fill 208 80 -125 212 80 -125 minecraft:air
fill 208 80 -124 212 80 -124 minecraft:air
fill 209 80 -123 211 80 -123 minecraft:air
fill 205 80 -122 207 80 -122 minecraft:air
fill 230 80 -122 232 80 -122 minecraft:air
fill 204 80 -121 208 80 -121 minecraft:air
fill 229 80 -121 233 80 -121 minecraft:air
fill 204 80 -120 208 80 -120 minecraft:air
fill 229 80 -120 233 80 -120 minecraft:air
fill 204 80 -119 208 80 -119 minecraft:air
fill 229 80 -119 233 80 -119 minecraft:air
fill 205 80 -118 207 80 -118 minecraft:air
fill 230 80 -118 232 80 -118 minecraft:air
setblock 204 81 -126 minecraft:air
fill 208 81 -126 212 81 -126 minecraft:air
fill 208 81 -125 212 81 -125 minecraft:air
fill 207 81 -124 212 81 -124 minecraft:air
fill 208 81 -123 212 81 -123 minecraft:air
fill 205 81 -122 207 81 -122 minecraft:air
fill 209 81 -122 211 81 -122 minecraft:air
fill 204 81 -121 208 81 -121 minecraft:air
setblock 231 81 -121 minecraft:air
fill 204 81 -120 208 81 -120 minecraft:air
fill 230 81 -120 232 81 -120 minecraft:air
fill 204 81 -119 208 81 -119 minecraft:air
setblock 231 81 -119 minecraft:air
fill 205 81 -118 207 81 -118 minecraft:air
fill 207 82 -126 211 82 -126 minecraft:air
setblock 250 82 -126 minecraft:air
fill 206 82 -125 212 82 -125 minecraft:air
fill 206 82 -124 212 82 -124 minecraft:air
fill 206 82 -123 212 82 -123 minecraft:air
fill 205 82 -122 211 82 -122 minecraft:air
fill 204 82 -121 208 82 -121 minecraft:air
fill 204 82 -120 208 82 -120 minecraft:air
setblock 231 82 -120 minecraft:air
fill 204 82 -119 208 82 -119 minecraft:air
fill 205 82 -118 207 82 -118 minecraft:air
fill 207 83 -126 211 83 -126 minecraft:air
fill 206 83 -125 212 83 -125 minecraft:air
fill 206 83 -124 212 83 -124 minecraft:air
fill 206 83 -123 212 83 -123 minecraft:air
fill 207 83 -122 211 83 -122 minecraft:air
setblock 206 83 -121 minecraft:air
setblock 231 83 -121 minecraft:air
fill 205 83 -120 207 83 -120 minecraft:air
fill 230 83 -120 232 83 -120 minecraft:air
setblock 206 83 -119 minecraft:air
setblock 231 83 -119 minecraft:air
fill 207 84 -126 209 84 -126 minecraft:air
fill 206 84 -125 210 84 -125 minecraft:air
fill 206 84 -124 211 84 -124 minecraft:air
fill 206 84 -123 210 84 -123 minecraft:air
fill 207 84 -122 209 84 -122 minecraft:air
setblock 208 85 -125 minecraft:air
fill 207 85 -124 209 85 -124 minecraft:air
setblock 208 85 -123 minecraft:air
forceload remove 200 -126 263 -63
tellraw @a {"text":"Campus bau a39 fertig.","color":"green"}
