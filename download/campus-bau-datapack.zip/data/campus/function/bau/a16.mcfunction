# Abschnitt a16: x 72..135, z -318..-255 (19824 Blöcke)
forceload add 72 -318 135 -255
tellraw @a {"text":"Campus bau a16: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a16_1 2s
