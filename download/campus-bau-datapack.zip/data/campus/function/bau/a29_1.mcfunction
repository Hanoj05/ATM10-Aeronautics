fill 46 45 -190 68 45 -190 minecraft:stone
fill 47 45 -189 68 45 -189 minecraft:stone
fill 49 45 -188 68 45 -188 minecraft:stone
fill 51 45 -187 68 45 -187 minecraft:stone
fill 24 45 -186 25 45 -186 minecraft:stone
fill 53 45 -186 68 45 -186 minecraft:stone
fill 23 45 -185 26 45 -185 minecraft:stone
fill 53 45 -185 68 45 -185 minecraft:stone
fill 23 45 -184 26 45 -184 minecraft:stone
fill 53 45 -184 68 45 -184 minecraft:stone
fill 23 45 -183 26 45 -183 minecraft:stone
fill 54 45 -183 56 45 -183 minecraft:stone
fill 59 45 -183 67 45 -183 minecraft:stone
fill 23 45 -182 26 45 -182 minecraft:stone
fill 54 45 -182 56 45 -182 minecraft:stone
fill 60 45 -182 66 45 -182 minecraft:stone
fill 24 45 -181 25 45 -181 minecraft:stone
fill 63 45 -181 65 45 -181 minecraft:stone
setblock 64 45 -180 minecraft:stone
fill 41 45 -166 42 45 -166 minecraft:stone
fill 40 45 -165 43 45 -165 minecraft:stone
fill 42 45 -164 43 45 -164 minecraft:stone
setblock 28 45 -142 minecraft:stone
fill 29 45 -141 31 45 -141 minecraft:stone
fill 30 45 -140 33 45 -140 minecraft:stone
fill 31 45 -139 35 45 -139 minecraft:stone
fill 32 45 -138 36 45 -138 minecraft:stone
fill 33 45 -137 37 45 -137 minecraft:stone
fill 35 45 -136 38 45 -136 minecraft:stone
fill 36 45 -135 39 45 -135 minecraft:stone
fill 37 45 -134 40 45 -134 minecraft:stone
fill 38 45 -133 40 45 -133 minecraft:stone
fill 39 45 -132 41 45 -132 minecraft:stone
fill 39 45 -131 42 45 -131 minecraft:stone
fill 40 45 -130 42 45 -130 minecraft:stone
fill 41 45 -129 43 45 -129 minecraft:stone
fill 42 45 -128 43 45 -128 minecraft:stone
fill 42 45 -127 43 45 -127 minecraft:stone
fill 46 46 -190 68 46 -190 minecraft:stone
fill 48 46 -189 68 46 -189 minecraft:stone
fill 50 46 -188 68 46 -188 minecraft:stone
fill 23 46 -187 26 46 -187 minecraft:stone
fill 52 46 -187 68 46 -187 minecraft:stone
setblock 71 46 -187 minecraft:stone
fill 23 46 -186 26 46 -186 minecraft:stone
fill 53 46 -186 68 46 -186 minecraft:stone
setblock 71 46 -186 minecraft:stone
fill 23 46 -185 26 46 -185 minecraft:stone
fill 53 46 -185 68 46 -185 minecraft:stone
setblock 71 46 -185 minecraft:stone
fill 23 46 -184 26 46 -184 minecraft:stone
fill 53 46 -184 67 46 -184 minecraft:stone
setblock 71 46 -184 minecraft:stone
fill 23 46 -183 25 46 -183 minecraft:stone
fill 53 46 -183 57 46 -183 minecraft:stone
fill 60 46 -183 65 46 -183 minecraft:stone
fill 54 46 -182 57 46 -182 minecraft:stone
fill 63 46 -182 64 46 -182 minecraft:stone
fill 55 46 -181 58 46 -181 minecraft:stone
setblock 64 46 -181 minecraft:stone
fill 56 46 -180 58 46 -180 minecraft:stone
fill 40 46 -166 43 46 -166 minecraft:stone
fill 41 46 -165 43 46 -165 minecraft:stone
fill 42 46 -164 43 46 -164 minecraft:stone
setblock 10 46 -147 minecraft:stone
setblock 26 46 -142 minecraft:stone
fill 27 46 -141 29 46 -141 minecraft:stone
fill 28 46 -140 32 46 -140 minecraft:stone
fill 29 46 -139 33 46 -139 minecraft:stone
fill 30 46 -138 35 46 -138 minecraft:stone
fill 32 46 -137 36 46 -137 minecraft:stone
fill 33 46 -136 37 46 -136 minecraft:stone
fill 35 46 -135 38 46 -135 minecraft:stone
fill 36 46 -134 39 46 -134 minecraft:stone
fill 37 46 -133 40 46 -133 minecraft:stone
fill 38 46 -132 40 46 -132 minecraft:stone
fill 39 46 -131 41 46 -131 minecraft:stone
fill 40 46 -130 41 46 -130 minecraft:stone
fill 40 46 -129 42 46 -129 minecraft:stone
fill 41 46 -128 42 46 -128 minecraft:stone
setblock 42 46 -127 minecraft:stone
fill 42 47 -190 43 47 -190 minecraft:stone
fill 47 47 -190 68 47 -190 minecraft:stone
fill 24 47 -189 26 47 -189 minecraft:stone
fill 49 47 -189 68 47 -189 minecraft:stone
fill 23 47 -188 26 47 -188 minecraft:stone
fill 51 47 -188 70 47 -188 minecraft:stone
fill 23 47 -187 26 47 -187 minecraft:stone
fill 53 47 -187 71 47 -187 minecraft:stone
fill 23 47 -186 26 47 -186 minecraft:stone
fill 54 47 -186 67 47 -186 minecraft:stone
fill 69 47 -186 71 47 -186 minecraft:stone
fill 23 47 -185 26 47 -185 minecraft:stone
fill 53 47 -185 66 47 -185 minecraft:stone
fill 70 47 -185 71 47 -185 minecraft:stone
fill 23 47 -184 25 47 -184 minecraft:stone
fill 53 47 -184 56 47 -184 minecraft:stone
fill 58 47 -184 63 47 -184 minecraft:stone
setblock 71 47 -184 minecraft:stone
fill 46 47 -183 49 47 -183 minecraft:stone
fill 54 47 -183 57 47 -183 minecraft:stone
fill 46 47 -182 49 47 -182 minecraft:stone
fill 54 47 -182 58 47 -182 minecraft:stone
fill 46 47 -181 49 47 -181 minecraft:stone
fill 55 47 -181 59 47 -181 minecraft:stone
fill 46 47 -180 49 47 -180 minecraft:stone
fill 56 47 -180 60 47 -180 minecraft:stone
fill 46 47 -179 49 47 -179 minecraft:stone
fill 57 47 -179 61 47 -179 minecraft:stone
fill 46 47 -178 49 47 -178 minecraft:stone
fill 59 47 -178 60 47 -178 minecraft:stone
fill 46 47 -177 49 47 -177 minecraft:stone
fill 46 47 -176 49 47 -176 minecraft:stone
fill 46 47 -175 49 47 -175 minecraft:stone
setblock 48 47 -174 minecraft:stone
fill 40 47 -166 43 47 -166 minecraft:stone
fill 41 47 -165 44 47 -165 minecraft:stone
fill 42 47 -164 43 47 -164 minecraft:stone
fill 9 47 -147 10 47 -147 minecraft:stone
fill 9 47 -146 12 47 -146 minecraft:stone
fill 9 47 -145 11 47 -145 minecraft:stone
fill 25 47 -141 27 47 -141 minecraft:stone
fill 26 47 -140 30 47 -140 minecraft:stone
fill 27 47 -139 31 47 -139 minecraft:stone
fill 28 47 -138 33 47 -138 minecraft:stone
fill 30 47 -137 34 47 -137 minecraft:stone
fill 32 47 -136 35 47 -136 minecraft:stone
fill 34 47 -135 36 47 -135 minecraft:stone
fill 35 47 -134 37 47 -134 minecraft:stone
fill 36 47 -133 38 47 -133 minecraft:stone
fill 37 47 -132 39 47 -132 minecraft:stone
fill 38 47 -131 40 47 -131 minecraft:stone
fill 39 47 -130 40 47 -130 minecraft:stone
fill 40 47 -129 41 47 -129 minecraft:stone
fill 40 47 -128 41 47 -128 minecraft:stone
setblock 41 47 -127 minecraft:stone
fill 23 48 -190 26 48 -190 minecraft:stone
fill 41 48 -190 46 48 -190 minecraft:stone
fill 48 48 -190 68 48 -190 minecraft:stone
fill 23 48 -189 27 48 -189 minecraft:stone
fill 42 48 -189 47 48 -189 minecraft:stone
fill 50 48 -189 68 48 -189 minecraft:stone
fill 23 48 -188 27 48 -188 minecraft:stone
fill 43 48 -188 47 48 -188 minecraft:stone
fill 52 48 -188 69 48 -188 minecraft:stone
fill 23 48 -187 26 48 -187 minecraft:stone
fill 44 48 -187 47 48 -187 minecraft:stone
fill 53 48 -187 70 48 -187 minecraft:stone
fill 23 48 -186 26 48 -186 minecraft:stone
fill 45 48 -186 48 48 -186 minecraft:stone
fill 54 48 -186 71 48 -186 minecraft:stone
fill 24 48 -185 25 48 -185 minecraft:stone
fill 45 48 -185 49 48 -185 minecraft:stone
fill 54 48 -185 65 48 -185 minecraft:stone
fill 69 48 -185 71 48 -185 minecraft:stone
fill 45 48 -184 49 48 -184 minecraft:stone
fill 54 48 -184 55 48 -184 minecraft:stone
fill 60 48 -184 61 48 -184 minecraft:stone
fill 70 48 -184 71 48 -184 minecraft:stone
fill 46 48 -183 49 48 -183 minecraft:stone
fill 54 48 -183 56 48 -183 minecraft:stone
setblock 71 48 -183 minecraft:stone
fill 46 48 -182 49 48 -182 minecraft:stone
fill 55 48 -182 58 48 -182 minecraft:stone
fill 46 48 -181 49 48 -181 minecraft:stone
fill 55 48 -181 59 48 -181 minecraft:stone
fill 46 48 -180 49 48 -180 minecraft:stone
fill 56 48 -180 60 48 -180 minecraft:stone
fill 46 48 -179 49 48 -179 minecraft:stone
fill 57 48 -179 62 48 -179 minecraft:stone
fill 46 48 -178 49 48 -178 minecraft:stone
fill 59 48 -178 63 48 -178 minecraft:stone
fill 46 48 -177 49 48 -177 minecraft:stone
fill 60 48 -177 65 48 -177 minecraft:stone
fill 46 48 -176 49 48 -176 minecraft:stone
fill 63 48 -176 65 48 -176 minecraft:stone
fill 46 48 -175 49 48 -175 minecraft:stone
fill 46 48 -174 50 48 -174 minecraft:stone
fill 47 48 -173 50 48 -173 minecraft:stone
fill 47 48 -172 52 48 -172 minecraft:stone
setblock 60 48 -172 minecraft:stone
fill 48 48 -171 53 48 -171 minecraft:stone
fill 55 48 -171 61 48 -171 minecraft:stone
fill 49 48 -170 61 48 -170 minecraft:stone
fill 50 48 -169 52 48 -169 minecraft:stone
fill 54 48 -169 60 48 -169 minecraft:stone
fill 54 48 -168 57 48 -168 minecraft:stone
fill 40 48 -166 43 48 -166 minecraft:stone
fill 41 48 -165 44 48 -165 minecraft:stone
setblock 43 48 -164 minecraft:stone
setblock 71 48 -161 minecraft:stone
setblock 71 48 -160 minecraft:stone
fill 9 48 -147 10 48 -147 minecraft:stone
fill 9 48 -146 11 48 -146 minecraft:stone
fill 9 48 -145 14 48 -145 minecraft:stone
fill 10 48 -144 17 48 -144 minecraft:stone
fill 19 48 -143 20 48 -143 minecraft:stone
fill 21 48 -142 22 48 -142 minecraft:stone
setblock 22 48 -141 minecraft:stone
fill 26 48 -140 28 48 -140 minecraft:stone
fill 25 48 -139 29 48 -139 minecraft:stone
fill 27 48 -138 30 48 -138 minecraft:stone
fill 29 48 -137 32 48 -137 minecraft:stone
fill 31 48 -136 33 48 -136 minecraft:stone
fill 32 48 -135 34 48 -135 minecraft:stone
fill 34 48 -134 35 48 -134 minecraft:stone
fill 35 48 -133 36 48 -133 minecraft:stone
fill 36 48 -132 37 48 -132 minecraft:stone
fill 37 48 -131 38 48 -131 minecraft:stone
fill 38 48 -130 39 48 -130 minecraft:stone
setblock 39 48 -129 minecraft:stone
setblock 40 48 -128 minecraft:stone
setblock 40 48 -127 minecraft:stone
fill 23 49 -190 27 49 -190 minecraft:stone
fill 41 49 -190 46 49 -190 minecraft:stone
fill 23 49 -189 27 49 -189 minecraft:stone
fill 42 49 -189 46 49 -189 minecraft:stone
setblock 67 49 -189 minecraft:stone
fill 23 49 -188 26 49 -188 minecraft:stone
fill 43 49 -188 47 49 -188 minecraft:stone
fill 67 49 -188 68 49 -188 minecraft:stone
fill 24 49 -187 26 49 -187 minecraft:stone
fill 44 49 -187 46 49 -187 minecraft:stone
fill 67 49 -187 69 49 -187 minecraft:stone
fill 46 49 -186 48 49 -186 minecraft:stone
fill 68 49 -186 70 49 -186 minecraft:stone
fill 46 49 -185 48 49 -185 minecraft:stone
fill 68 49 -185 71 49 -185 minecraft:stone
fill 46 49 -184 48 49 -184 minecraft:stone
fill 69 49 -184 71 49 -184 minecraft:stone
fill 47 49 -183 48 49 -183 minecraft:stone
fill 70 49 -183 71 49 -183 minecraft:stone
fill 47 49 -182 48 49 -182 minecraft:stone
fill 56 49 -182 57 49 -182 minecraft:stone
fill 47 49 -181 49 49 -181 minecraft:stone
fill 56 49 -181 59 49 -181 minecraft:stone
fill 47 49 -180 48 49 -180 minecraft:stone
fill 57 49 -180 61 49 -180 minecraft:stone
setblock 48 49 -179 minecraft:stone
fill 58 49 -179 62 49 -179 minecraft:stone
fill 59 49 -178 64 49 -178 minecraft:stone
fill 47 49 -177 48 49 -177 minecraft:stone
fill 60 49 -177 66 49 -177 minecraft:stone
fill 47 49 -176 48 49 -176 minecraft:stone
fill 62 49 -176 67 49 -176 minecraft:stone
fill 47 49 -175 49 49 -175 minecraft:stone
fill 64 49 -175 69 49 -175 minecraft:stone
fill 47 49 -174 49 49 -174 minecraft:stone
fill 67 49 -174 71 49 -174 minecraft:stone
fill 47 49 -173 50 49 -173 minecraft:stone
fill 70 49 -173 71 49 -173 minecraft:stone
fill 48 49 -172 51 49 -172 minecraft:stone
setblock 61 49 -172 minecraft:stone
fill 48 49 -171 52 49 -171 minecraft:stone
fill 58 49 -171 63 49 -171 minecraft:stone
fill 50 49 -170 52 49 -170 minecraft:stone
fill 55 49 -170 63 49 -170 minecraft:stone
setblock 51 49 -169 minecraft:stone
fill 55 49 -169 56 49 -169 minecraft:stone
fill 59 49 -169 62 49 -169 minecraft:stone
fill 41 49 -166 44 49 -166 minecraft:stone
fill 42 49 -165 44 49 -165 minecraft:stone
setblock 71 49 -162 minecraft:stone
setblock 71 49 -161 minecraft:stone
setblock 71 49 -160 minecraft:stone
setblock 9 49 -147 minecraft:stone
fill 9 49 -146 11 49 -146 minecraft:stone
fill 9 49 -145 13 49 -145 minecraft:stone
fill 9 49 -144 16 49 -144 minecraft:stone
fill 12 49 -143 19 49 -143 minecraft:stone
fill 18 49 -142 22 49 -142 minecraft:stone
fill 20 49 -141 23 49 -141 minecraft:stone
setblock 22 49 -140 minecraft:stone
setblock 27 49 -140 minecraft:stone
fill 27 49 -139 28 49 -139 minecraft:stone
fill 27 49 -138 29 49 -138 minecraft:stone
fill 27 49 -137 30 49 -137 minecraft:stone
fill 29 49 -136 32 49 -136 minecraft:stone
fill 31 49 -135 33 49 -135 minecraft:stone
fill 33 49 -134 34 49 -134 minecraft:stone
fill 34 49 -133 35 49 -133 minecraft:stone
fill 35 49 -132 36 49 -132 minecraft:stone
fill 36 49 -131 37 49 -131 minecraft:stone
fill 37 49 -130 38 49 -130 minecraft:stone
setblock 38 49 -129 minecraft:stone
setblock 39 49 -128 minecraft:stone
fill 24 50 -190 27 50 -190 minecraft:stone
fill 24 50 -189 26 50 -189 minecraft:stone
setblock 67 50 -188 minecraft:stone
fill 67 50 -187 68 50 -187 minecraft:stone
fill 67 50 -186 69 50 -186 minecraft:stone
fill 67 50 -185 70 50 -185 minecraft:stone
fill 68 50 -184 70 50 -184 minecraft:stone
fill 69 50 -183 71 50 -183 minecraft:stone
setblock 71 50 -182 minecraft:stone
fill 58 50 -180 60 50 -180 minecraft:stone
fill 58 50 -179 62 50 -179 minecraft:stone
fill 59 50 -178 64 50 -178 minecraft:stone
fill 61 50 -177 66 50 -177 minecraft:stone
fill 62 50 -176 68 50 -176 minecraft:stone
fill 64 50 -175 71 50 -175 minecraft:stone
fill 66 50 -174 71 50 -174 minecraft:stone
fill 69 50 -173 71 50 -173 minecraft:stone
setblock 71 50 -172 minecraft:stone
fill 60 50 -171 62 50 -171 minecraft:stone
fill 60 50 -170 63 50 -170 minecraft:stone
fill 61 50 -169 62 50 -169 minecraft:stone
setblock 43 50 -167 minecraft:stone
fill 41 50 -166 44 50 -166 minecraft:stone
fill 42 50 -165 45 50 -165 minecraft:stone
setblock 71 50 -161 minecraft:stone
setblock 71 50 -160 minecraft:stone
fill 9 50 -146 10 50 -146 minecraft:stone
fill 9 50 -145 12 50 -145 minecraft:stone
fill 9 50 -144 15 50 -144 minecraft:stone
fill 10 50 -143 17 50 -143 minecraft:stone
fill 13 50 -142 20 50 -142 minecraft:stone
fill 17 50 -141 23 50 -141 minecraft:stone
fill 19 50 -140 24 50 -140 minecraft:stone
fill 22 50 -139 23 50 -139 minecraft:stone
setblock 27 50 -138 minecraft:stone
fill 27 50 -137 29 50 -137 minecraft:stone
fill 28 50 -136 30 50 -136 minecraft:stone
fill 30 50 -135 31 50 -135 minecraft:stone
fill 31 50 -134 33 50 -134 minecraft:stone
fill 33 50 -133 34 50 -133 minecraft:stone
fill 34 50 -132 35 50 -132 minecraft:stone
fill 35 50 -131 36 50 -131 minecraft:stone
fill 36 50 -130 37 50 -130 minecraft:stone
fill 37 50 -129 38 50 -129 minecraft:stone
setblock 38 50 -128 minecraft:stone
setblock 39 50 -127 minecraft:stone
setblock 66 51 -188 minecraft:stone
fill 66 51 -187 67 51 -187 minecraft:stone
fill 66 51 -186 68 51 -186 minecraft:stone
fill 66 51 -185 69 51 -185 minecraft:stone
fill 67 51 -184 69 51 -184 minecraft:stone
fill 68 51 -183 70 51 -183 minecraft:stone
setblock 70 51 -182 minecraft:stone
fill 61 51 -178 64 51 -178 minecraft:stone
fill 62 51 -177 65 51 -177 minecraft:stone
fill 63 51 -176 68 51 -176 minecraft:stone
fill 65 51 -175 69 51 -175 minecraft:stone
fill 67 51 -174 71 51 -174 minecraft:stone
fill 69 51 -173 71 51 -173 minecraft:stone
fill 64 51 -172 65 51 -172 minecraft:stone
fill 63 51 -171 66 51 -171 minecraft:stone
fill 63 51 -170 66 51 -170 minecraft:stone
setblock 64 51 -169 minecraft:stone
fill 43 51 -167 44 51 -167 minecraft:stone
fill 42 51 -166 45 51 -166 minecraft:stone
fill 43 51 -165 45 51 -165 minecraft:stone
fill 9 51 -145 11 51 -145 minecraft:stone
fill 9 51 -144 13 51 -144 minecraft:stone
fill 10 51 -143 16 51 -143 minecraft:stone
fill 11 51 -142 19 51 -142 minecraft:stone
fill 14 51 -141 21 51 -141 minecraft:stone
fill 17 51 -140 24 51 -140 minecraft:stone
fill 20 51 -139 24 51 -139 minecraft:stone
fill 27 51 -139 28 51 -139 minecraft:stone
fill 21 51 -138 24 51 -138 minecraft:stone
fill 27 51 -138 28 51 -138 minecraft:stone
fill 21 51 -137 23 51 -137 minecraft:stone
fill 27 51 -137 28 51 -137 minecraft:stone
setblock 22 51 -136 minecraft:stone
fill 27 51 -136 29 51 -136 minecraft:stone
fill 28 51 -135 30 51 -135 minecraft:stone
fill 30 51 -134 31 51 -134 minecraft:stone
fill 31 51 -133 33 51 -133 minecraft:stone
fill 33 51 -132 34 51 -132 minecraft:stone
fill 34 51 -131 35 51 -131 minecraft:stone
fill 35 51 -130 36 51 -130 minecraft:stone
fill 36 51 -129 37 51 -129 minecraft:stone
setblock 37 51 -128 minecraft:stone
setblock 38 51 -127 minecraft:stone
setblock 65 52 -188 minecraft:stone
fill 65 52 -187 66 52 -187 minecraft:stone
fill 65 52 -186 67 52 -186 minecraft:stone
fill 66 52 -185 68 52 -185 minecraft:stone
fill 66 52 -184 69 52 -184 minecraft:stone
fill 67 52 -183 69 52 -183 minecraft:stone
fill 68 52 -182 69 52 -182 minecraft:stone
setblock 65 52 -176 minecraft:stone
setblock 67 52 -175 minecraft:stone
setblock 69 52 -175 minecraft:stone
fill 68 52 -174 69 52 -174 minecraft:stone
setblock 71 52 -174 minecraft:stone
fill 64 52 -172 65 52 -172 minecraft:stone
fill 63 52 -171 66 52 -171 minecraft:stone
fill 64 52 -170 66 52 -170 minecraft:stone
fill 42 52 -167 44 52 -167 minecraft:stone
fill 42 52 -166 45 52 -166 minecraft:stone
fill 43 52 -165 46 52 -165 minecraft:stone
fill 10 52 -144 12 52 -144 minecraft:stone
fill 10 52 -143 15 52 -143 minecraft:stone
fill 10 52 -142 17 52 -142 minecraft:stone
fill 12 52 -141 20 52 -141 minecraft:stone
fill 15 52 -140 22 52 -140 minecraft:stone
setblock 25 52 -140 minecraft:stone
fill 27 52 -140 28 52 -140 minecraft:stone
fill 17 52 -139 24 52 -139 minecraft:stone
fill 27 52 -139 30 52 -139 minecraft:stone
fill 15 52 -138 24 52 -138 minecraft:stone
fill 27 52 -138 31 52 -138 minecraft:stone
fill 15 52 -137 24 52 -137 minecraft:stone
fill 26 52 -137 31 52 -137 minecraft:stone
fill 16 52 -136 23 52 -136 minecraft:stone
fill 26 52 -136 31 52 -136 minecraft:stone
fill 27 52 -135 28 52 -135 minecraft:stone
fill 28 52 -134 30 52 -134 minecraft:stone
fill 30 52 -133 31 52 -133 minecraft:stone
fill 31 52 -132 33 52 -132 minecraft:stone
fill 33 52 -131 34 52 -131 minecraft:stone
fill 34 52 -130 35 52 -130 minecraft:stone
fill 35 52 -129 36 52 -129 minecraft:stone
setblock 36 52 -128 minecraft:stone
setblock 37 52 -127 minecraft:stone
setblock 65 53 -187 minecraft:stone
fill 65 53 -186 66 53 -186 minecraft:stone
fill 65 53 -185 67 53 -185 minecraft:stone
fill 65 53 -184 68 53 -184 minecraft:stone
fill 66 53 -183 68 53 -183 minecraft:stone
fill 67 53 -182 68 53 -182 minecraft:stone
fill 41 53 -167 45 53 -167 minecraft:stone
fill 43 53 -166 46 53 -166 minecraft:stone
fill 44 53 -165 46 53 -165 minecraft:stone
fill 45 53 -159 50 53 -159 minecraft:stone
fill 45 53 -158 52 53 -158 minecraft:stone
fill 45 53 -157 52 53 -157 minecraft:stone
fill 49 53 -156 51 53 -156 minecraft:stone
fill 10 53 -143 13 53 -143 minecraft:stone
fill 10 53 -142 16 53 -142 minecraft:stone
fill 10 53 -141 18 53 -141 minecraft:stone
fill 13 53 -140 21 53 -140 minecraft:stone
fill 27 53 -140 30 53 -140 minecraft:stone
fill 16 53 -139 24 53 -139 minecraft:stone
fill 27 53 -139 31 53 -139 minecraft:stone
fill 15 53 -138 24 53 -138 minecraft:stone
fill 26 53 -138 32 53 -138 minecraft:stone
fill 15 53 -137 23 53 -137 minecraft:stone
fill 26 53 -137 33 53 -137 minecraft:stone
fill 16 53 -136 24 53 -136 minecraft:stone
fill 26 53 -136 33 53 -136 minecraft:stone
fill 26 53 -135 32 53 -135 minecraft:stone
fill 27 53 -134 28 53 -134 minecraft:stone
setblock 31 53 -134 minecraft:stone
fill 28 53 -133 30 53 -133 minecraft:stone
fill 30 53 -132 31 53 -132 minecraft:stone
fill 31 53 -131 32 53 -131 minecraft:stone
setblock 33 53 -130 minecraft:stone
setblock 34 53 -129 minecraft:stone
setblock 35 53 -128 minecraft:stone
setblock 36 53 -127 minecraft:stone
setblock 64 54 -187 minecraft:stone
fill 64 54 -186 65 54 -186 minecraft:stone
fill 64 54 -185 66 54 -185 minecraft:stone
fill 65 54 -184 67 54 -184 minecraft:stone
fill 65 54 -183 67 54 -183 minecraft:stone
fill 66 54 -182 68 54 -182 minecraft:stone
setblock 68 54 -181 minecraft:stone
fill 42 54 -167 45 54 -167 minecraft:stone
fill 43 54 -166 46 54 -166 minecraft:stone
fill 44 54 -165 47 54 -165 minecraft:stone
setblock 46 54 -160 minecraft:stone
fill 44 54 -159 52 54 -159 minecraft:stone
fill 44 54 -158 53 54 -158 minecraft:stone
fill 44 54 -157 53 54 -157 minecraft:stone
fill 48 54 -156 53 54 -156 minecraft:stone
fill 10 54 -142 14 54 -142 minecraft:stone
fill 10 54 -141 17 54 -141 minecraft:stone
fill 11 54 -140 19 54 -140 minecraft:stone
fill 27 54 -140 30 54 -140 minecraft:stone
fill 13 54 -139 20 54 -139 minecraft:stone
fill 22 54 -139 24 54 -139 minecraft:stone
fill 27 54 -139 32 54 -139 minecraft:stone
fill 16 54 -138 24 54 -138 minecraft:stone
fill 26 54 -138 33 54 -138 minecraft:stone
fill 16 54 -137 24 54 -137 minecraft:stone
fill 26 54 -137 34 54 -137 minecraft:stone
fill 19 54 -136 20 54 -136 minecraft:stone
fill 22 54 -136 24 54 -136 minecraft:stone
fill 26 54 -136 34 54 -136 minecraft:stone
fill 28 54 -135 34 54 -135 minecraft:stone
fill 26 54 -134 27 54 -134 minecraft:stone
fill 30 54 -134 34 54 -134 minecraft:stone
fill 27 54 -133 28 54 -133 minecraft:stone
fill 31 54 -133 33 54 -133 minecraft:stone
fill 28 54 -132 29 54 -132 minecraft:stone
fill 30 54 -131 31 54 -131 minecraft:stone
fill 31 54 -130 32 54 -130 minecraft:stone
setblock 33 54 -129 minecraft:stone
setblock 34 54 -128 minecraft:stone
setblock 63 55 -187 minecraft:stone
setblock 64 55 -186 minecraft:stone
fill 64 55 -185 65 55 -185 minecraft:stone
fill 64 55 -184 66 55 -184 minecraft:stone
fill 64 55 -183 67 55 -183 minecraft:stone
fill 65 55 -182 67 55 -182 minecraft:stone
setblock 67 55 -181 minecraft:stone
fill 42 55 -167 46 55 -167 minecraft:stone
fill 44 55 -166 47 55 -166 minecraft:stone
fill 45 55 -165 48 55 -165 minecraft:stone
setblock 49 55 -164 minecraft:stone
fill 45 55 -159 47 55 -159 minecraft:stone
fill 50 55 -159 53 55 -159 minecraft:stone
fill 44 55 -158 53 55 -158 minecraft:stone
fill 45 55 -157 53 55 -157 minecraft:stone
fill 50 55 -156 53 55 -156 minecraft:stone
fill 10 55 -141 13 55 -141 minecraft:stone
fill 11 55 -140 16 55 -140 minecraft:stone
fill 27 55 -140 30 55 -140 minecraft:stone
fill 11 55 -139 18 55 -139 minecraft:stone
fill 27 55 -139 32 55 -139 minecraft:stone
fill 13 55 -138 20 55 -138 minecraft:stone
fill 22 55 -138 24 55 -138 minecraft:stone
fill 27 55 -138 33 55 -138 minecraft:stone
fill 17 55 -137 24 55 -137 minecraft:stone
fill 27 55 -137 34 55 -137 minecraft:stone
fill 20 55 -136 23 55 -136 minecraft:stone
fill 27 55 -136 35 55 -136 minecraft:stone
fill 22 55 -135 23 55 -135 minecraft:stone
fill 28 55 -135 35 55 -135 minecraft:stone
fill 29 55 -134 37 55 -134 minecraft:stone
setblock 26 55 -133 minecraft:stone
fill 30 55 -133 38 55 -133 minecraft:stone
fill 27 55 -132 28 55 -132 minecraft:stone
fill 33 55 -132 38 55 -132 minecraft:stone
setblock 29 55 -131 minecraft:stone
fill 33 55 -131 38 55 -131 minecraft:stone
setblock 30 55 -130 minecraft:stone
fill 34 55 -130 37 55 -130 minecraft:stone
setblock 31 55 -129 minecraft:stone
setblock 63 56 -186 minecraft:dirt
fill 63 56 -185 64 56 -185 minecraft:dirt
fill 63 56 -184 65 56 -184 minecraft:dirt
fill 63 56 -183 66 56 -183 minecraft:dirt
fill 64 56 -182 66 56 -182 minecraft:dirt
fill 66 56 -181 67 56 -181 minecraft:dirt
setblock 67 56 -180 minecraft:dirt
fill 43 56 -167 47 56 -167 minecraft:stone
fill 44 56 -166 48 56 -166 minecraft:stone
fill 45 56 -165 48 56 -165 minecraft:stone
setblock 49 56 -164 minecraft:stone
fill 53 56 -159 55 56 -159 minecraft:stone
setblock 45 56 -158 minecraft:stone
fill 51 56 -158 55 56 -158 minecraft:stone
fill 51 56 -157 55 56 -157 minecraft:stone
setblock 52 56 -156 minecraft:stone
fill 11 56 -140 13 56 -140 minecraft:stone
fill 11 56 -139 16 56 -139 minecraft:stone
fill 28 56 -139 32 56 -139 minecraft:stone
fill 11 56 -138 18 56 -138 minecraft:stone
fill 27 56 -138 33 56 -138 minecraft:stone
fill 13 56 -137 20 56 -137 minecraft:stone
fill 27 56 -137 34 56 -137 minecraft:stone
fill 17 56 -136 21 56 -136 minecraft:stone
fill 28 56 -136 35 56 -136 minecraft:stone
fill 20 56 -135 22 56 -135 minecraft:stone
fill 29 56 -135 37 56 -135 minecraft:stone
fill 22 56 -134 23 56 -134 minecraft:stone
fill 29 56 -134 38 56 -134 minecraft:stone
fill 30 56 -133 38 56 -133 minecraft:stone
setblock 26 56 -132 minecraft:stone
fill 33 56 -132 39 56 -132 minecraft:stone
setblock 27 56 -131 minecraft:stone
fill 33 56 -131 39 56 -131 minecraft:stone
setblock 28 56 -130 minecraft:stone
fill 33 56 -130 41 56 -130 minecraft:stone
setblock 30 56 -129 minecraft:stone
fill 34 56 -129 41 56 -129 minecraft:stone
setblock 31 56 -128 minecraft:stone
fill 35 56 -128 42 56 -128 minecraft:stone
setblock 32 56 -127 minecraft:stone
fill 36 56 -127 42 56 -127 minecraft:stone
setblock 8 57 -189 minecraft:stone
setblock 63 57 -185 minecraft:dirt
fill 63 57 -184 64 57 -184 minecraft:dirt
fill 63 57 -183 65 57 -183 minecraft:dirt
fill 63 57 -182 66 57 -182 minecraft:dirt
fill 64 57 -181 66 57 -181 minecraft:dirt
fill 65 57 -180 66 57 -180 minecraft:dirt
setblock 67 57 -179 minecraft:dirt
fill 44 57 -167 47 57 -167 minecraft:stone
fill 45 57 -166 48 57 -166 minecraft:stone
fill 46 57 -165 49 57 -165 minecraft:stone
fill 49 57 -164 50 57 -164 minecraft:stone
setblock 51 57 -163 minecraft:stone
fill 53 57 -159 55 57 -159 minecraft:stone
fill 53 57 -158 56 57 -158 minecraft:stone
fill 53 57 -157 55 57 -157 minecraft:stone
fill 11 57 -140 13 57 -140 minecraft:stone
fill 11 57 -139 16 57 -139 minecraft:stone
fill 11 57 -138 18 57 -138 minecraft:stone
fill 29 57 -138 33 57 -138 minecraft:stone
fill 12 57 -137 20 57 -137 minecraft:stone
fill 28 57 -137 34 57 -137 minecraft:stone
fill 12 57 -136 21 57 -136 minecraft:stone
fill 29 57 -136 35 57 -136 minecraft:stone
fill 17 57 -135 22 57 -135 minecraft:stone
fill 29 57 -135 37 57 -135 minecraft:stone
fill 20 57 -134 23 57 -134 minecraft:stone
fill 30 57 -134 38 57 -134 minecraft:stone
fill 22 57 -133 24 57 -133 minecraft:stone
fill 31 57 -133 39 57 -133 minecraft:stone
setblock 24 57 -132 minecraft:stone
setblock 26 57 -132 minecraft:stone
fill 32 57 -132 39 57 -132 minecraft:stone
fill 26 57 -131 27 57 -131 minecraft:stone
fill 32 57 -131 40 57 -131 minecraft:stone
fill 27 57 -130 28 57 -130 minecraft:stone
fill 33 57 -130 42 57 -130 minecraft:stone
setblock 29 57 -129 minecraft:stone
fill 34 57 -129 43 57 -129 minecraft:stone
setblock 30 57 -128 minecraft:stone
fill 34 57 -128 44 57 -128 minecraft:stone
fill 35 57 -127 44 57 -127 minecraft:stone
setblock 8 58 -188 minecraft:stone
setblock 8 58 -187 minecraft:stone
setblock 8 58 -186 minecraft:stone
setblock 8 58 -185 minecraft:stone
setblock 8 58 -184 minecraft:stone
setblock 63 58 -184 minecraft:dirt
fill 8 58 -183 9 58 -183 minecraft:stone
fill 63 58 -183 64 58 -183 minecraft:dirt
setblock 9 58 -182 minecraft:stone
fill 63 58 -182 65 58 -182 minecraft:dirt
fill 63 58 -181 66 58 -181 minecraft:dirt
fill 64 58 -180 66 58 -180 minecraft:dirt
fill 65 58 -179 66 58 -179 minecraft:dirt
fill 66 58 -178 67 58 -178 minecraft:dirt
fill 45 58 -167 48 58 -167 minecraft:stone
fill 46 58 -166 49 58 -166 minecraft:stone
fill 47 58 -165 50 58 -165 minecraft:stone
fill 49 58 -164 51 58 -164 minecraft:stone
fill 51 58 -163 52 58 -163 minecraft:stone
setblock 56 58 -160 minecraft:stone
fill 53 58 -159 57 58 -159 minecraft:stone
fill 53 58 -158 57 58 -158 minecraft:stone
fill 53 58 -157 56 58 -157 minecraft:stone
fill 11 58 -139 13 58 -139 minecraft:stone
fill 11 58 -138 16 58 -138 minecraft:stone
setblock 31 58 -138 minecraft:stone
fill 12 58 -137 19 58 -137 minecraft:stone
fill 30 58 -137 34 58 -137 minecraft:stone
fill 12 58 -136 21 58 -136 minecraft:stone
fill 30 58 -136 34 58 -136 minecraft:stone
fill 13 58 -135 22 58 -135 minecraft:stone
fill 30 58 -135 37 58 -135 minecraft:stone
fill 17 58 -134 23 58 -134 minecraft:stone
fill 30 58 -134 38 58 -134 minecraft:stone
fill 21 58 -133 24 58 -133 minecraft:stone
fill 32 58 -133 39 58 -133 minecraft:stone
fill 23 58 -132 24 58 -132 minecraft:stone
fill 32 58 -132 40 58 -132 minecraft:stone
fill 26 58 -131 27 58 -131 minecraft:stone
fill 32 58 -131 41 58 -131 minecraft:stone
fill 26 58 -130 28 58 -130 minecraft:stone
fill 33 58 -130 43 58 -130 minecraft:stone
fill 28 58 -129 29 58 -129 minecraft:stone
fill 34 58 -129 44 58 -129 minecraft:stone
fill 29 58 -128 30 58 -128 minecraft:stone
fill 34 58 -128 44 58 -128 minecraft:stone
setblock 31 58 -127 minecraft:stone
fill 35 58 -127 44 58 -127 minecraft:stone
setblock 49 58 -127 minecraft:stone
setblock 8 59 -188 minecraft:stone
setblock 8 59 -187 minecraft:stone
fill 8 59 -186 9 59 -186 minecraft:stone
fill 8 59 -185 9 59 -185 minecraft:stone
fill 8 59 -184 9 59 -184 minecraft:stone
fill 8 59 -183 10 59 -183 minecraft:stone
fill 9 59 -182 10 59 -182 minecraft:stone
setblock 10 59 -181 minecraft:stone
setblock 11 59 -180 minecraft:stone
fill 45 59 -167 49 59 -167 minecraft:stone
fill 47 59 -166 50 59 -166 minecraft:stone
fill 48 59 -165 51 59 -165 minecraft:stone
fill 49 59 -164 52 59 -164 minecraft:stone
fill 51 59 -163 52 59 -163 minecraft:stone
setblock 53 59 -162 minecraft:stone
setblock 27 59 -160 minecraft:stone
fill 55 59 -160 56 59 -160 minecraft:stone
fill 54 59 -159 57 59 -159 minecraft:stone
fill 54 59 -158 57 59 -158 minecraft:stone
fill 55 59 -157 57 59 -157 minecraft:stone
fill 57 59 -144 59 59 -144 minecraft:stone
fill 56 59 -143 60 59 -143 minecraft:stone
fill 55 59 -142 61 59 -142 minecraft:stone
fill 54 59 -141 61 59 -141 minecraft:stone
fill 54 59 -140 61 59 -140 minecraft:stone
fill 54 59 -139 61 59 -139 minecraft:stone
fill 11 59 -138 12 59 -138 minecraft:stone
fill 55 59 -138 60 59 -138 minecraft:stone
fill 12 59 -137 16 59 -137 minecraft:stone
fill 56 59 -137 59 59 -137 minecraft:stone
fill 12 59 -136 19 59 -136 minecraft:stone
fill 31 59 -136 33 59 -136 minecraft:stone
fill 13 59 -135 21 59 -135 minecraft:stone
fill 31 59 -135 37 59 -135 minecraft:stone
fill 17 59 -134 23 59 -134 minecraft:stone
fill 32 59 -134 38 59 -134 minecraft:stone
fill 18 59 -133 24 59 -133 minecraft:stone
fill 33 59 -133 39 59 -133 minecraft:stone
fill 21 59 -132 25 59 -132 minecraft:stone
fill 33 59 -132 40 59 -132 minecraft:stone
fill 23 59 -131 24 59 -131 minecraft:stone
fill 33 59 -131 41 59 -131 minecraft:stone
setblock 25 59 -130 minecraft:stone
setblock 27 59 -130 minecraft:stone
fill 33 59 -130 43 59 -130 minecraft:stone
setblock 50 59 -130 minecraft:stone
fill 27 59 -129 28 59 -129 minecraft:stone
fill 34 59 -129 44 59 -129 minecraft:stone
fill 50 59 -129 51 59 -129 minecraft:stone
fill 28 59 -128 30 59 -128 minecraft:stone
fill 34 59 -128 45 59 -128 minecraft:stone
fill 50 59 -128 51 59 -128 minecraft:stone
setblock 30 59 -127 minecraft:stone
fill 35 59 -127 46 59 -127 minecraft:stone
fill 48 59 -127 51 59 -127 minecraft:stone
fill 27 60 -190 37 60 -190 minecraft:stone
fill 27 60 -189 38 60 -189 minecraft:stone
fill 27 60 -188 38 60 -188 minecraft:stone
setblock 8 60 -187 minecraft:stone
fill 27 60 -187 39 60 -187 minecraft:stone
fill 8 60 -186 9 60 -186 minecraft:stone
fill 27 60 -186 40 60 -186 minecraft:stone
fill 8 60 -185 9 60 -185 minecraft:stone
fill 27 60 -185 41 60 -185 minecraft:stone
fill 8 60 -184 10 60 -184 minecraft:stone
fill 27 60 -184 41 60 -184 minecraft:stone
fill 8 60 -183 11 60 -183 minecraft:stone
fill 27 60 -183 42 60 -183 minecraft:stone
fill 8 60 -182 11 60 -182 minecraft:stone
fill 27 60 -182 43 60 -182 minecraft:stone
fill 9 60 -181 11 60 -181 minecraft:stone
fill 27 60 -181 44 60 -181 minecraft:stone
fill 10 60 -180 12 60 -180 minecraft:stone
fill 27 60 -180 45 60 -180 minecraft:stone
fill 11 60 -179 12 60 -179 minecraft:stone
fill 27 60 -179 46 60 -179 minecraft:stone
setblock 13 60 -178 minecraft:stone
fill 27 60 -178 47 60 -178 minecraft:stone
fill 27 60 -177 48 60 -177 minecraft:stone
fill 27 60 -176 49 60 -176 minecraft:stone
fill 27 60 -175 50 60 -175 minecraft:stone
fill 27 60 -174 52 60 -174 minecraft:stone
fill 27 60 -173 53 60 -173 minecraft:stone
fill 27 60 -172 54 60 -172 minecraft:stone
fill 27 60 -171 56 60 -171 minecraft:stone
fill 27 60 -170 57 60 -170 minecraft:stone
fill 27 60 -169 59 60 -169 minecraft:stone
fill 27 60 -168 61 60 -168 minecraft:stone
fill 27 60 -167 63 60 -167 minecraft:stone
fill 27 60 -166 66 60 -166 minecraft:stone
fill 27 60 -165 68 60 -165 minecraft:stone
fill 27 60 -164 71 60 -164 minecraft:stone
fill 27 60 -163 71 60 -163 minecraft:stone
fill 27 60 -162 71 60 -162 minecraft:stone
fill 27 60 -161 71 60 -161 minecraft:stone
fill 27 60 -160 71 60 -160 minecraft:stone
fill 54 60 -159 58 60 -159 minecraft:stone
fill 54 60 -158 59 60 -158 minecraft:stone
fill 55 60 -157 59 60 -157 minecraft:stone
fill 57 60 -156 58 60 -156 minecraft:stone
fill 56 60 -148 58 60 -148 minecraft:stone
fill 56 60 -147 58 60 -147 minecraft:stone
fill 55 60 -146 58 60 -146 minecraft:stone
fill 55 60 -145 58 60 -145 minecraft:stone
fill 56 60 -144 60 60 -144 minecraft:stone
fill 55 60 -143 61 60 -143 minecraft:stone
fill 54 60 -142 61 60 -142 minecraft:stone
fill 54 60 -141 61 60 -141 minecraft:stone
fill 54 60 -140 61 60 -140 minecraft:stone
fill 53 60 -139 62 60 -139 minecraft:stone
fill 52 60 -138 62 60 -138 minecraft:stone
fill 51 60 -137 62 60 -137 minecraft:stone
fill 12 60 -136 16 60 -136 minecraft:stone
fill 50 60 -136 59 60 -136 minecraft:stone
setblock 61 60 -136 minecraft:stone
fill 13 60 -135 20 60 -135 minecraft:stone
fill 49 60 -135 58 60 -135 minecraft:stone
fill 16 60 -134 22 60 -134 minecraft:stone
fill 34 60 -134 37 60 -134 minecraft:stone
fill 48 60 -134 58 60 -134 minecraft:stone
fill 18 60 -133 24 60 -133 minecraft:stone
fill 33 60 -133 38 60 -133 minecraft:stone
fill 48 60 -133 57 60 -133 minecraft:stone
fill 20 60 -132 25 60 -132 minecraft:stone
fill 33 60 -132 39 60 -132 minecraft:stone
fill 47 60 -132 55 60 -132 minecraft:stone
fill 21 60 -131 25 60 -131 minecraft:stone
fill 33 60 -131 41 60 -131 minecraft:stone
fill 46 60 -131 54 60 -131 minecraft:stone
fill 23 60 -130 25 60 -130 minecraft:stone
setblock 27 60 -130 minecraft:stone
fill 34 60 -130 43 60 -130 minecraft:stone
fill 46 60 -130 53 60 -130 minecraft:stone
fill 27 60 -129 28 60 -129 minecraft:stone
fill 34 60 -129 46 60 -129 minecraft:stone
fill 48 60 -129 53 60 -129 minecraft:stone
fill 27 60 -128 29 60 -128 minecraft:stone
fill 34 60 -128 52 60 -128 minecraft:stone
fill 29 60 -127 30 60 -127 minecraft:stone
fill 35 60 -127 52 60 -127 minecraft:stone
fill 27 61 -190 37 61 -190 minecraft:stone
fill 27 61 -189 38 61 -189 minecraft:stone
fill 27 61 -188 38 61 -188 minecraft:stone
fill 27 61 -187 39 61 -187 minecraft:stone
fill 27 61 -186 40 61 -186 minecraft:stone
setblock 9 61 -185 minecraft:stone
fill 27 61 -185 41 61 -185 minecraft:stone
fill 9 61 -184 10 61 -184 minecraft:stone
fill 27 61 -184 41 61 -184 minecraft:stone
fill 9 61 -183 11 61 -183 minecraft:stone
fill 27 61 -183 42 61 -183 minecraft:stone
fill 9 61 -182 12 61 -182 minecraft:stone
fill 27 61 -182 43 61 -182 minecraft:stone
fill 9 61 -181 12 61 -181 minecraft:stone
fill 27 61 -181 44 61 -181 minecraft:stone
fill 10 61 -180 13 61 -180 minecraft:stone
fill 27 61 -180 45 61 -180 minecraft:stone
fill 11 61 -179 13 61 -179 minecraft:stone
fill 27 61 -179 46 61 -179 minecraft:stone
fill 12 61 -178 14 61 -178 minecraft:stone
fill 27 61 -178 47 61 -178 minecraft:stone
setblock 14 61 -177 minecraft:stone
fill 27 61 -177 48 61 -177 minecraft:stone
fill 27 61 -176 49 61 -176 minecraft:stone
fill 27 61 -175 50 61 -175 minecraft:stone
fill 27 61 -174 52 61 -174 minecraft:stone
fill 27 61 -173 53 61 -173 minecraft:stone
fill 27 61 -172 54 61 -172 minecraft:stone
fill 27 61 -171 56 61 -171 minecraft:stone
fill 27 61 -170 57 61 -170 minecraft:stone
fill 27 61 -169 59 61 -169 minecraft:stone
fill 27 61 -168 61 61 -168 minecraft:stone
fill 27 61 -167 63 61 -167 minecraft:stone
fill 27 61 -166 66 61 -166 minecraft:stone
fill 27 61 -165 68 61 -165 minecraft:stone
fill 27 61 -164 71 61 -164 minecraft:stone
fill 27 61 -163 71 61 -163 minecraft:stone
fill 27 61 -162 71 61 -162 minecraft:stone
fill 27 61 -161 71 61 -161 minecraft:stone
fill 27 61 -160 71 61 -160 minecraft:stone
fill 55 61 -159 58 61 -159 minecraft:stone
fill 55 61 -158 59 61 -158 minecraft:stone
fill 56 61 -157 60 61 -157 minecraft:stone
fill 57 61 -156 60 61 -156 minecraft:stone
fill 57 61 -155 60 61 -155 minecraft:stone
fill 57 61 -154 59 61 -154 minecraft:stone
fill 57 61 -153 59 61 -153 minecraft:stone
fill 56 61 -152 59 61 -152 minecraft:stone
fill 56 61 -151 59 61 -151 minecraft:stone
fill 56 61 -150 59 61 -150 minecraft:stone
fill 56 61 -149 59 61 -149 minecraft:stone
fill 55 61 -148 59 61 -148 minecraft:stone
fill 55 61 -147 59 61 -147 minecraft:stone
fill 55 61 -146 59 61 -146 minecraft:stone
fill 55 61 -145 59 61 -145 minecraft:stone
fill 55 61 -144 60 61 -144 minecraft:stone
fill 55 61 -143 61 61 -143 minecraft:stone
fill 54 61 -142 61 61 -142 minecraft:stone
fill 54 61 -141 62 61 -141 minecraft:stone
fill 53 61 -140 62 61 -140 minecraft:stone
fill 53 61 -139 62 61 -139 minecraft:stone
fill 51 61 -138 63 61 -138 minecraft:stone
fill 50 61 -137 63 61 -137 minecraft:stone
fill 49 61 -136 64 61 -136 minecraft:stone
fill 13 61 -135 16 61 -135 minecraft:stone
fill 48 61 -135 59 61 -135 minecraft:stone
fill 61 61 -135 65 61 -135 minecraft:stone
fill 16 61 -134 20 61 -134 minecraft:stone
fill 48 61 -134 58 61 -134 minecraft:stone
fill 62 61 -134 64 61 -134 minecraft:stone
fill 18 61 -133 22 61 -133 minecraft:stone
fill 34 61 -133 38 61 -133 minecraft:stone
fill 47 61 -133 57 61 -133 minecraft:stone
fill 20 61 -132 24 61 -132 minecraft:stone
fill 34 61 -132 39 61 -132 minecraft:stone
fill 47 61 -132 56 61 -132 minecraft:stone
fill 21 61 -131 25 61 -131 minecraft:stone
fill 34 61 -131 40 61 -131 minecraft:stone
fill 46 61 -131 55 61 -131 minecraft:stone
fill 22 61 -130 24 61 -130 minecraft:stone
setblock 27 61 -130 minecraft:stone
fill 34 61 -130 43 61 -130 minecraft:stone
fill 45 61 -130 54 61 -130 minecraft:stone
setblock 24 61 -129 minecraft:stone
fill 26 61 -129 27 61 -129 minecraft:stone
fill 34 61 -129 53 61 -129 minecraft:stone
fill 26 61 -128 29 61 -128 minecraft:stone
fill 35 61 -128 53 61 -128 minecraft:stone
fill 27 61 -127 29 61 -127 minecraft:stone
fill 36 61 -127 52 61 -127 minecraft:stone
fill 27 62 -190 37 62 -190 minecraft:dirt
fill 27 62 -189 38 62 -189 minecraft:dirt
fill 27 62 -188 38 62 -188 minecraft:dirt
fill 27 62 -187 39 62 -187 minecraft:dirt
fill 27 62 -186 40 62 -186 minecraft:dirt
fill 27 62 -185 41 62 -185 minecraft:dirt
setblock 10 62 -184 minecraft:dirt
fill 27 62 -184 41 62 -184 minecraft:dirt
setblock 10 62 -183 minecraft:dirt
fill 27 62 -183 42 62 -183 minecraft:dirt
fill 10 62 -182 12 62 -182 minecraft:dirt
fill 27 62 -182 43 62 -182 minecraft:dirt
fill 11 62 -181 13 62 -181 minecraft:dirt
fill 27 62 -181 44 62 -181 minecraft:dirt
fill 11 62 -180 14 62 -180 minecraft:dirt
fill 27 62 -180 45 62 -180 minecraft:dirt
fill 11 62 -179 14 62 -179 minecraft:dirt
fill 27 62 -179 46 62 -179 minecraft:dirt
fill 12 62 -178 15 62 -178 minecraft:dirt
fill 27 62 -178 47 62 -178 minecraft:dirt
fill 14 62 -177 15 62 -177 minecraft:dirt
fill 27 62 -177 48 62 -177 minecraft:dirt
setblock 16 62 -176 minecraft:dirt
fill 27 62 -176 49 62 -176 minecraft:dirt
fill 27 62 -175 50 62 -175 minecraft:dirt
fill 27 62 -174 52 62 -174 minecraft:dirt
fill 27 62 -173 53 62 -173 minecraft:dirt
fill 27 62 -172 54 62 -172 minecraft:dirt
fill 27 62 -171 56 62 -171 minecraft:dirt
fill 27 62 -170 57 62 -170 minecraft:dirt
fill 27 62 -169 59 62 -169 minecraft:dirt
fill 27 62 -168 61 62 -168 minecraft:dirt
fill 27 62 -167 63 62 -167 minecraft:dirt
fill 27 62 -166 66 62 -166 minecraft:dirt
fill 27 62 -165 68 62 -165 minecraft:dirt
fill 27 62 -164 71 62 -164 minecraft:dirt
fill 27 62 -163 71 62 -163 minecraft:dirt
fill 27 62 -162 71 62 -162 minecraft:dirt
fill 27 62 -161 71 62 -161 minecraft:dirt
fill 27 62 -160 71 62 -160 minecraft:dirt
fill 57 62 -159 58 62 -159 minecraft:dirt
fill 56 62 -158 59 62 -158 minecraft:dirt
fill 56 62 -157 60 62 -157 minecraft:dirt
fill 57 62 -156 60 62 -156 minecraft:dirt
fill 57 62 -155 60 62 -155 minecraft:dirt
fill 56 62 -154 60 62 -154 minecraft:dirt
fill 57 62 -153 60 62 -153 minecraft:dirt
fill 56 62 -152 59 62 -152 minecraft:dirt
fill 56 62 -151 59 62 -151 minecraft:dirt
fill 55 62 -150 59 62 -150 minecraft:dirt
fill 55 62 -149 59 62 -149 minecraft:dirt
fill 55 62 -148 59 62 -148 minecraft:dirt
fill 55 62 -147 59 62 -147 minecraft:dirt
fill 55 62 -146 59 62 -146 minecraft:dirt
fill 55 62 -145 59 62 -145 minecraft:dirt
fill 55 62 -144 60 62 -144 minecraft:dirt
fill 55 62 -143 61 62 -143 minecraft:dirt
fill 54 62 -142 61 62 -142 minecraft:dirt
fill 53 62 -141 62 62 -141 minecraft:dirt
fill 53 62 -140 62 62 -140 minecraft:dirt
fill 52 62 -139 62 62 -139 minecraft:dirt
fill 51 62 -138 63 62 -138 minecraft:dirt
fill 50 62 -137 64 62 -137 minecraft:dirt
fill 49 62 -136 68 62 -136 minecraft:dirt
fill 48 62 -135 59 62 -135 minecraft:dirt
fill 61 62 -135 68 62 -135 minecraft:dirt
setblock 16 62 -134 minecraft:dirt
fill 47 62 -134 58 62 -134 minecraft:dirt
fill 61 62 -134 68 62 -134 minecraft:dirt
fill 18 62 -133 20 62 -133 minecraft:dirt
fill 47 62 -133 58 62 -133 minecraft:dirt
fill 63 62 -133 68 62 -133 minecraft:dirt
fill 19 62 -132 23 62 -132 minecraft:dirt
fill 36 62 -132 37 62 -132 minecraft:dirt
fill 46 62 -132 57 62 -132 minecraft:dirt
fill 21 62 -131 25 62 -131 minecraft:dirt
fill 35 62 -131 38 62 -131 minecraft:dirt
fill 46 62 -131 55 62 -131 minecraft:dirt
fill 22 62 -130 24 62 -130 minecraft:dirt
fill 35 62 -130 41 62 -130 minecraft:dirt
fill 45 62 -130 54 62 -130 minecraft:dirt
fill 23 62 -129 24 62 -129 minecraft:dirt
fill 26 62 -129 27 62 -129 minecraft:dirt
fill 35 62 -129 54 62 -129 minecraft:dirt
setblock 24 62 -128 minecraft:dirt
fill 26 62 -128 28 62 -128 minecraft:dirt
fill 36 62 -128 53 62 -128 minecraft:dirt
fill 26 62 -127 29 62 -127 minecraft:dirt
fill 36 62 -127 53 62 -127 minecraft:dirt
fill 27 63 -190 37 63 -190 minecraft:dirt
fill 27 63 -189 38 63 -189 minecraft:dirt
fill 27 63 -188 38 63 -188 minecraft:dirt
fill 27 63 -187 39 63 -187 minecraft:dirt
fill 27 63 -186 40 63 -186 minecraft:dirt
fill 27 63 -185 41 63 -185 minecraft:dirt
fill 27 63 -184 41 63 -184 minecraft:dirt
fill 27 63 -183 42 63 -183 minecraft:dirt
setblock 11 63 -182 minecraft:dirt
fill 27 63 -182 43 63 -182 minecraft:dirt
setblock 12 63 -181 minecraft:dirt
fill 27 63 -181 44 63 -181 minecraft:dirt
fill 12 63 -180 14 63 -180 minecraft:dirt
fill 27 63 -180 45 63 -180 minecraft:dirt
fill 12 63 -179 15 63 -179 minecraft:dirt
fill 27 63 -179 46 63 -179 minecraft:dirt
fill 13 63 -178 16 63 -178 minecraft:dirt
fill 27 63 -178 47 63 -178 minecraft:dirt
fill 13 63 -177 16 63 -177 minecraft:dirt
fill 27 63 -177 48 63 -177 minecraft:dirt
fill 16 63 -176 17 63 -176 minecraft:dirt
fill 27 63 -176 49 63 -176 minecraft:dirt
fill 27 63 -175 50 63 -175 minecraft:dirt
fill 27 63 -174 52 63 -174 minecraft:dirt
fill 27 63 -173 53 63 -173 minecraft:dirt
fill 27 63 -172 54 63 -172 minecraft:dirt
fill 27 63 -171 56 63 -171 minecraft:dirt
fill 27 63 -170 57 63 -170 minecraft:dirt
fill 27 63 -169 59 63 -169 minecraft:dirt
fill 27 63 -168 61 63 -168 minecraft:dirt
fill 27 63 -167 63 63 -167 minecraft:dirt
fill 27 63 -166 66 63 -166 minecraft:dirt
fill 27 63 -165 68 63 -165 minecraft:dirt
fill 27 63 -164 71 63 -164 minecraft:dirt
fill 27 63 -163 71 63 -163 minecraft:dirt
fill 27 63 -162 71 63 -162 minecraft:dirt
fill 27 63 -161 71 63 -161 minecraft:dirt
fill 27 63 -160 71 63 -160 minecraft:dirt
setblock 57 63 -159 minecraft:dirt
fill 57 63 -158 59 63 -158 minecraft:dirt
fill 57 63 -157 59 63 -157 minecraft:dirt
fill 57 63 -156 60 63 -156 minecraft:dirt
fill 57 63 -155 60 63 -155 minecraft:dirt
fill 57 63 -154 60 63 -154 minecraft:dirt
fill 57 63 -153 60 63 -153 minecraft:dirt
fill 56 63 -152 59 63 -152 minecraft:dirt
fill 56 63 -151 59 63 -151 minecraft:dirt
fill 56 63 -150 59 63 -150 minecraft:dirt
fill 56 63 -149 59 63 -149 minecraft:dirt
fill 55 63 -148 58 63 -148 minecraft:dirt
fill 56 63 -147 58 63 -147 minecraft:dirt
fill 56 63 -146 58 63 -146 minecraft:dirt
fill 56 63 -145 58 63 -145 minecraft:dirt
fill 56 63 -144 60 63 -144 minecraft:dirt
fill 55 63 -143 61 63 -143 minecraft:dirt
fill 54 63 -142 61 63 -142 minecraft:dirt
fill 54 63 -141 61 63 -141 minecraft:dirt
fill 53 63 -140 61 63 -140 minecraft:dirt
fill 52 63 -139 62 63 -139 minecraft:dirt
fill 51 63 -138 62 63 -138 minecraft:dirt
fill 50 63 -137 65 63 -137 minecraft:dirt
fill 49 63 -136 70 63 -136 minecraft:dirt
fill 48 63 -135 59 63 -135 minecraft:dirt
fill 61 63 -135 71 63 -135 minecraft:dirt
fill 47 63 -134 59 63 -134 minecraft:dirt
fill 61 63 -134 71 63 -134 minecraft:dirt
fill 47 63 -133 58 63 -133 minecraft:dirt
fill 63 63 -133 71 63 -133 minecraft:dirt
fill 19 63 -132 21 63 -132 minecraft:dirt
fill 46 63 -132 57 63 -132 minecraft:dirt
fill 20 63 -131 23 63 -131 minecraft:dirt
fill 46 63 -131 55 63 -131 minecraft:dirt
fill 21 63 -130 24 63 -130 minecraft:dirt
fill 45 63 -130 54 63 -130 minecraft:dirt
fill 22 63 -129 24 63 -129 minecraft:dirt
fill 26 63 -129 27 63 -129 minecraft:dirt
fill 38 63 -129 40 63 -129 minecraft:dirt
fill 45 63 -129 54 63 -129 minecraft:dirt
fill 23 63 -128 24 63 -128 minecraft:dirt
fill 26 63 -128 28 63 -128 minecraft:dirt
fill 38 63 -128 53 63 -128 minecraft:dirt
fill 26 63 -127 28 63 -127 minecraft:dirt
fill 38 63 -127 53 63 -127 minecraft:dirt
fill 27 64 -190 37 64 -190 minecraft:dirt
fill 45 64 -190 53 64 -190 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -189 38 64 -189 minecraft:dirt
fill 45 64 -189 53 64 -189 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -188 38 64 -188 minecraft:dirt
fill 46 64 -188 53 64 -188 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -187 39 64 -187 minecraft:dirt
fill 47 64 -187 53 64 -187 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -186 40 64 -186 minecraft:dirt
fill 49 64 -186 52 64 -186 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -185 41 64 -185 minecraft:dirt
fill 49 64 -185 53 64 -185 minecraft:smooth_quartz_slab[type=top]
fill 70 64 -185 71 64 -185 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -184 41 64 -184 minecraft:dirt
fill 50 64 -184 52 64 -184 minecraft:smooth_quartz_slab[type=top]
fill 66 64 -184 71 64 -184 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -183 42 64 -183 minecraft:dirt
fill 51 64 -183 52 64 -183 minecraft:smooth_quartz_slab[type=top]
fill 63 64 -183 71 64 -183 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -182 43 64 -182 minecraft:dirt
setblock 52 64 -182 minecraft:smooth_quartz_slab[type=top]
fill 59 64 -182 71 64 -182 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -181 44 64 -181 minecraft:dirt
fill 55 64 -181 57 64 -181 minecraft:smooth_quartz_slab[type=top]
fill 59 64 -181 62 64 -181 minecraft:smooth_quartz_slab[type=top]
fill 64 64 -181 67 64 -181 minecraft:smooth_quartz_slab[type=top]
fill 69 64 -181 71 64 -181 minecraft:smooth_quartz_slab[type=top]
fill 13 64 -180 14 64 -180 minecraft:dirt
fill 27 64 -180 45 64 -180 minecraft:dirt
fill 54 64 -180 71 64 -180 minecraft:smooth_quartz_slab[type=top]
fill 14 64 -179 15 64 -179 minecraft:dirt
fill 27 64 -179 46 64 -179 minecraft:dirt
fill 55 64 -179 71 64 -179 minecraft:smooth_quartz_slab[type=top]
fill 14 64 -178 17 64 -178 minecraft:dirt
fill 27 64 -178 47 64 -178 minecraft:dirt
fill 56 64 -178 71 64 -178 minecraft:smooth_quartz_slab[type=top]
fill 15 64 -177 18 64 -177 minecraft:dirt
fill 27 64 -177 48 64 -177 minecraft:dirt
fill 58 64 -177 71 64 -177 minecraft:smooth_quartz_slab[type=top]
fill 15 64 -176 18 64 -176 minecraft:dirt
fill 27 64 -176 49 64 -176 minecraft:dirt
fill 59 64 -176 62 64 -176 minecraft:smooth_quartz_slab[type=top]
fill 64 64 -176 67 64 -176 minecraft:smooth_quartz_slab[type=top]
fill 69 64 -176 71 64 -176 minecraft:smooth_quartz_slab[type=top]
setblock 19 64 -175 minecraft:dirt
fill 27 64 -175 50 64 -175 minecraft:dirt
fill 61 64 -175 71 64 -175 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -174 52 64 -174 minecraft:dirt
fill 63 64 -174 71 64 -174 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -173 53 64 -173 minecraft:dirt
fill 64 64 -173 71 64 -173 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -172 54 64 -172 minecraft:dirt
fill 67 64 -172 71 64 -172 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -171 56 64 -171 minecraft:dirt
fill 69 64 -171 71 64 -171 minecraft:smooth_quartz_slab[type=top]
fill 27 64 -170 57 64 -170 minecraft:dirt
fill 27 64 -169 59 64 -169 minecraft:dirt
fill 27 64 -168 61 64 -168 minecraft:dirt
fill 27 64 -167 63 64 -167 minecraft:dirt
fill 27 64 -166 66 64 -166 minecraft:dirt
fill 27 64 -165 68 64 -165 minecraft:dirt
fill 27 64 -164 71 64 -164 minecraft:dirt
fill 27 64 -163 71 64 -163 minecraft:dirt
fill 27 64 -162 71 64 -162 minecraft:dirt
fill 27 64 -161 71 64 -161 minecraft:dirt
fill 27 64 -160 71 64 -160 minecraft:dirt
setblock 57 64 -159 minecraft:dirt
setblock 8 64 -158 minecraft:dirt
setblock 58 64 -158 minecraft:dirt
fill 8 64 -157 9 64 -157 minecraft:dirt
fill 8 64 -156 9 64 -156 minecraft:dirt
fill 58 64 -156 59 64 -156 minecraft:dirt
setblock 8 64 -155 minecraft:dirt
fill 58 64 -155 59 64 -155 minecraft:dirt
fill 8 64 -154 10 64 -154 minecraft:dirt
fill 57 64 -154 59 64 -154 minecraft:dirt
fill 8 64 -153 10 64 -153 minecraft:dirt
fill 57 64 -153 59 64 -153 minecraft:dirt
fill 8 64 -152 10 64 -152 minecraft:dirt
fill 57 64 -152 58 64 -152 minecraft:dirt
fill 9 64 -151 10 64 -151 minecraft:dirt
fill 56 64 -151 58 64 -151 minecraft:dirt
fill 9 64 -150 11 64 -150 minecraft:dirt
fill 56 64 -150 58 64 -150 minecraft:dirt
fill 9 64 -149 11 64 -149 minecraft:dirt
fill 56 64 -149 58 64 -149 minecraft:dirt
fill 9 64 -148 11 64 -148 minecraft:dirt
fill 56 64 -148 58 64 -148 minecraft:dirt
fill 9 64 -147 11 64 -147 minecraft:dirt
setblock 57 64 -147 minecraft:dirt
fill 9 64 -146 13 64 -146 minecraft:dirt
setblock 57 64 -146 minecraft:dirt
setblock 9 64 -145 minecraft:dirt
fill 11 64 -145 14 64 -145 minecraft:dirt
fill 9 64 -144 14 64 -144 minecraft:dirt
fill 57 64 -144 59 64 -144 minecraft:dirt
setblock 10 64 -143 minecraft:dirt
fill 12 64 -143 15 64 -143 minecraft:dirt
fill 55 64 -143 60 64 -143 minecraft:dirt
fill 10 64 -142 15 64 -142 minecraft:dirt
fill 27 64 -142 28 64 -142 minecraft:dirt
fill 30 64 -142 31 64 -142 minecraft:dirt
fill 33 64 -142 34 64 -142 minecraft:dirt
fill 54 64 -142 61 64 -142 minecraft:dirt
fill 10 64 -141 15 64 -141 minecraft:dirt
setblock 20 64 -141 minecraft:dirt
fill 25 64 -141 34 64 -141 minecraft:dirt
fill 54 64 -141 61 64 -141 minecraft:dirt
fill 11 64 -140 12 64 -140 minecraft:dirt
fill 14 64 -140 15 64 -140 minecraft:dirt
fill 17 64 -140 22 64 -140 minecraft:dirt
setblock 26 64 -140 minecraft:dirt
fill 28 64 -140 36 64 -140 minecraft:dirt
fill 53 64 -140 61 64 -140 minecraft:dirt
fill 11 64 -139 18 64 -139 minecraft:dirt
fill 25 64 -139 33 64 -139 minecraft:dirt
fill 35 64 -139 36 64 -139 minecraft:dirt
fill 53 64 -139 61 64 -139 minecraft:dirt
fill 11 64 -138 17 64 -138 minecraft:dirt
fill 25 64 -138 37 64 -138 minecraft:dirt
fill 51 64 -138 61 64 -138 minecraft:dirt
fill 12 64 -137 17 64 -137 minecraft:dirt
fill 25 64 -137 28 64 -137 minecraft:dirt
fill 30 64 -137 37 64 -137 minecraft:dirt
fill 50 64 -137 64 64 -137 minecraft:dirt
fill 12 64 -136 17 64 -136 minecraft:dirt
fill 25 64 -136 37 64 -136 minecraft:dirt
fill 49 64 -136 59 64 -136 minecraft:dirt
fill 61 64 -136 71 64 -136 minecraft:dirt
setblock 13 64 -135 minecraft:dirt
fill 15 64 -135 19 64 -135 minecraft:dirt
fill 22 64 -135 37 64 -135 minecraft:dirt
fill 48 64 -135 59 64 -135 minecraft:dirt
fill 61 64 -135 71 64 -135 minecraft:dirt
fill 13 64 -134 36 64 -134 minecraft:dirt
fill 47 64 -134 58 64 -134 minecraft:dirt
fill 62 64 -134 71 64 -134 minecraft:dirt
fill 14 64 -133 15 64 -133 minecraft:dirt
fill 17 64 -133 18 64 -133 minecraft:dirt
fill 20 64 -133 35 64 -133 minecraft:dirt
fill 47 64 -133 58 64 -133 minecraft:dirt
fill 64 64 -133 71 64 -133 minecraft:dirt
fill 15 64 -132 36 64 -132 minecraft:dirt
fill 46 64 -132 57 64 -132 minecraft:dirt
fill 15 64 -131 36 64 -131 minecraft:dirt
fill 46 64 -131 55 64 -131 minecraft:dirt
fill 16 64 -130 36 64 -130 minecraft:dirt
fill 45 64 -130 54 64 -130 minecraft:dirt
fill 17 64 -129 27 64 -129 minecraft:dirt
fill 29 64 -129 35 64 -129 minecraft:dirt
fill 45 64 -129 54 64 -129 minecraft:dirt
setblock 18 64 -128 minecraft:dirt
fill 20 64 -128 35 64 -128 minecraft:dirt
fill 44 64 -128 53 64 -128 minecraft:dirt
fill 19 64 -127 32 64 -127 minecraft:dirt
setblock 34 64 -127 minecraft:dirt
fill 42 64 -127 52 64 -127 minecraft:dirt
fill 8 65 -190 9 65 -190 minecraft:light_gray_concrete
setblock 10 65 -190 minecraft:sea_lantern
fill 11 65 -190 12 65 -190 minecraft:light_gray_concrete
setblock 13 65 -190 minecraft:smooth_quartz
fill 14 65 -190 34 65 -190 minecraft:grass_block
setblock 8 65 -189 minecraft:light_gray_concrete
setblock 9 65 -189 minecraft:sea_lantern
fill 10 65 -189 12 65 -189 minecraft:light_gray_concrete
setblock 13 65 -189 minecraft:smooth_quartz
fill 14 65 -189 35 65 -189 minecraft:grass_block
fill 8 65 -188 12 65 -188 minecraft:light_gray_concrete
setblock 13 65 -188 minecraft:smooth_quartz
fill 14 65 -188 36 65 -188 minecraft:grass_block
fill 8 65 -187 12 65 -187 minecraft:light_gray_concrete
setblock 13 65 -187 minecraft:smooth_quartz
fill 14 65 -187 36 65 -187 minecraft:grass_block
fill 8 65 -186 12 65 -186 minecraft:light_gray_concrete
setblock 13 65 -186 minecraft:smooth_quartz
fill 14 65 -186 37 65 -186 minecraft:grass_block
fill 8 65 -185 12 65 -185 minecraft:light_gray_concrete
setblock 13 65 -185 minecraft:smooth_quartz
fill 14 65 -185 38 65 -185 minecraft:grass_block
fill 8 65 -184 12 65 -184 minecraft:light_gray_concrete
setblock 13 65 -184 minecraft:smooth_quartz
fill 14 65 -184 38 65 -184 minecraft:grass_block
fill 8 65 -183 11 65 -183 minecraft:light_gray_concrete
setblock 12 65 -183 minecraft:sea_lantern
setblock 13 65 -183 minecraft:smooth_quartz
fill 14 65 -183 39 65 -183 minecraft:grass_block
fill 8 65 -182 10 65 -182 minecraft:light_gray_concrete
setblock 11 65 -182 minecraft:sea_lantern
setblock 12 65 -182 minecraft:light_gray_concrete
setblock 13 65 -182 minecraft:smooth_quartz
fill 14 65 -182 40 65 -182 minecraft:grass_block
fill 8 65 -181 9 65 -181 minecraft:light_gray_concrete
setblock 10 65 -181 minecraft:sea_lantern
fill 11 65 -181 12 65 -181 minecraft:light_gray_concrete
setblock 13 65 -181 minecraft:smooth_quartz
fill 14 65 -181 41 65 -181 minecraft:grass_block
setblock 8 65 -180 minecraft:light_gray_concrete
setblock 9 65 -180 minecraft:sea_lantern
fill 10 65 -180 12 65 -180 minecraft:light_gray_concrete
setblock 13 65 -180 minecraft:smooth_quartz
fill 14 65 -180 42 65 -180 minecraft:grass_block
fill 8 65 -179 12 65 -179 minecraft:light_gray_concrete
setblock 13 65 -179 minecraft:smooth_quartz
fill 14 65 -179 43 65 -179 minecraft:grass_block
fill 8 65 -178 12 65 -178 minecraft:light_gray_concrete
setblock 13 65 -178 minecraft:smooth_quartz
fill 14 65 -178 44 65 -178 minecraft:grass_block
fill 8 65 -177 12 65 -177 minecraft:light_gray_concrete
setblock 13 65 -177 minecraft:smooth_quartz
fill 14 65 -177 18 65 -177 minecraft:grass_block
fill 20 65 -177 45 65 -177 minecraft:grass_block
fill 8 65 -176 12 65 -176 minecraft:light_gray_concrete
setblock 13 65 -176 minecraft:smooth_quartz
fill 14 65 -176 46 65 -176 minecraft:grass_block
fill 8 65 -175 12 65 -175 minecraft:light_gray_concrete
setblock 13 65 -175 minecraft:smooth_quartz
fill 14 65 -175 19 65 -175 minecraft:grass_block
fill 21 65 -175 47 65 -175 minecraft:grass_block
fill 8 65 -174 11 65 -174 minecraft:light_gray_concrete
setblock 12 65 -174 minecraft:sea_lantern
setblock 13 65 -174 minecraft:smooth_quartz
fill 14 65 -174 48 65 -174 minecraft:grass_block
fill 8 65 -173 10 65 -173 minecraft:light_gray_concrete
setblock 11 65 -173 minecraft:sea_lantern
setblock 12 65 -173 minecraft:light_gray_concrete
setblock 13 65 -173 minecraft:smooth_quartz
fill 14 65 -173 49 65 -173 minecraft:grass_block
fill 8 65 -172 9 65 -172 minecraft:light_gray_concrete
setblock 10 65 -172 minecraft:sea_lantern
fill 11 65 -172 12 65 -172 minecraft:light_gray_concrete
setblock 13 65 -172 minecraft:smooth_quartz
fill 14 65 -172 50 65 -172 minecraft:grass_block
setblock 8 65 -171 minecraft:light_gray_concrete
setblock 9 65 -171 minecraft:sea_lantern
fill 10 65 -171 12 65 -171 minecraft:light_gray_concrete
setblock 13 65 -171 minecraft:smooth_quartz
fill 14 65 -171 52 65 -171 minecraft:grass_block
fill 8 65 -170 12 65 -170 minecraft:light_gray_concrete
setblock 13 65 -170 minecraft:smooth_quartz
fill 14 65 -170 53 65 -170 minecraft:grass_block
fill 8 65 -169 12 65 -169 minecraft:light_gray_concrete
setblock 13 65 -169 minecraft:smooth_quartz
fill 14 65 -169 55 65 -169 minecraft:grass_block
fill 8 65 -168 12 65 -168 minecraft:light_gray_concrete
setblock 13 65 -168 minecraft:smooth_quartz
fill 14 65 -168 56 65 -168 minecraft:grass_block
fill 8 65 -167 12 65 -167 minecraft:light_gray_concrete
setblock 13 65 -167 minecraft:smooth_quartz
fill 14 65 -167 58 65 -167 minecraft:grass_block
fill 8 65 -166 12 65 -166 minecraft:light_gray_concrete
setblock 13 65 -166 minecraft:smooth_quartz
fill 14 65 -166 60 65 -166 minecraft:grass_block
fill 8 65 -165 11 65 -165 minecraft:light_gray_concrete
setblock 12 65 -165 minecraft:sea_lantern
setblock 13 65 -165 minecraft:smooth_quartz
fill 14 65 -165 62 65 -165 minecraft:grass_block
fill 8 65 -164 10 65 -164 minecraft:light_gray_concrete
setblock 11 65 -164 minecraft:sea_lantern
setblock 12 65 -164 minecraft:light_gray_concrete
setblock 13 65 -164 minecraft:smooth_quartz
fill 17 65 -164 64 65 -164 minecraft:grass_block
fill 8 65 -163 9 65 -163 minecraft:light_gray_concrete
setblock 10 65 -163 minecraft:sea_lantern
fill 11 65 -163 12 65 -163 minecraft:light_gray_concrete
setblock 13 65 -163 minecraft:smooth_quartz
fill 19 65 -163 67 65 -163 minecraft:grass_block
setblock 8 65 -162 minecraft:light_gray_concrete
setblock 9 65 -162 minecraft:sea_lantern
fill 10 65 -162 12 65 -162 minecraft:light_gray_concrete
setblock 13 65 -162 minecraft:smooth_quartz
fill 23 65 -162 70 65 -162 minecraft:grass_block
fill 8 65 -161 12 65 -161 minecraft:light_gray_concrete
setblock 13 65 -161 minecraft:smooth_quartz
setblock 14 65 -161 minecraft:grass_block
fill 27 65 -161 71 65 -161 minecraft:grass_block
fill 8 65 -160 12 65 -160 minecraft:light_gray_concrete
setblock 13 65 -160 minecraft:smooth_quartz
fill 14 65 -160 17 65 -160 minecraft:grass_block
setblock 19 65 -160 minecraft:grass_block
fill 27 65 -160 71 65 -160 minecraft:grass_block
fill 8 65 -159 12 65 -159 minecraft:light_gray_concrete
setblock 13 65 -159 minecraft:smooth_quartz
fill 14 65 -159 17 65 -159 minecraft:grass_block
fill 41 65 -159 47 65 -159 minecraft:grass_block
setblock 50 65 -159 minecraft:grass_block
setblock 58 65 -159 minecraft:grass_block
fill 61 65 -159 71 65 -159 minecraft:grass_block
fill 8 65 -158 12 65 -158 minecraft:light_gray_concrete
setblock 13 65 -158 minecraft:smooth_quartz
fill 14 65 -158 17 65 -158 minecraft:grass_block
fill 40 65 -158 48 65 -158 minecraft:grass_block
setblock 53 65 -158 minecraft:grass_block
fill 61 65 -158 71 65 -158 minecraft:grass_block
fill 8 65 -157 12 65 -157 minecraft:light_gray_concrete
setblock 13 65 -157 minecraft:smooth_quartz
fill 14 65 -157 16 65 -157 minecraft:grass_block
fill 39 65 -157 49 65 -157 minecraft:grass_block
fill 61 65 -157 71 65 -157 minecraft:grass_block
fill 8 65 -156 11 65 -156 minecraft:light_gray_concrete
setblock 12 65 -156 minecraft:sea_lantern
setblock 13 65 -156 minecraft:smooth_quartz
fill 14 65 -156 16 65 -156 minecraft:grass_block
fill 39 65 -156 51 65 -156 minecraft:grass_block
fill 61 65 -156 71 65 -156 minecraft:grass_block
fill 8 65 -155 10 65 -155 minecraft:light_gray_concrete
setblock 11 65 -155 minecraft:sea_lantern
setblock 12 65 -155 minecraft:light_gray_concrete
setblock 13 65 -155 minecraft:smooth_quartz
fill 14 65 -155 17 65 -155 minecraft:grass_block
fill 38 65 -155 52 65 -155 minecraft:grass_block
fill 61 65 -155 71 65 -155 minecraft:grass_block
fill 8 65 -154 9 65 -154 minecraft:light_gray_concrete
setblock 10 65 -154 minecraft:sea_lantern
fill 11 65 -154 12 65 -154 minecraft:light_gray_concrete
setblock 13 65 -154 minecraft:smooth_quartz
fill 14 65 -154 21 65 -154 minecraft:grass_block
fill 38 65 -154 53 65 -154 minecraft:grass_block
fill 61 65 -154 71 65 -154 minecraft:grass_block
setblock 8 65 -153 minecraft:light_gray_concrete
setblock 9 65 -153 minecraft:sea_lantern
fill 10 65 -153 12 65 -153 minecraft:light_gray_concrete
setblock 13 65 -153 minecraft:smooth_quartz
fill 14 65 -153 21 65 -153 minecraft:grass_block
fill 38 65 -153 54 65 -153 minecraft:grass_block
fill 60 65 -153 71 65 -153 minecraft:grass_block
fill 8 65 -152 12 65 -152 minecraft:light_gray_concrete
setblock 13 65 -152 minecraft:smooth_quartz
fill 14 65 -152 22 65 -152 minecraft:grass_block
fill 37 65 -152 54 65 -152 minecraft:grass_block
fill 60 65 -152 71 65 -152 minecraft:grass_block
fill 9 65 -151 13 65 -151 minecraft:light_gray_concrete
setblock 14 65 -151 minecraft:smooth_quartz
fill 15 65 -151 24 65 -151 minecraft:grass_block
setblock 32 65 -151 minecraft:grass_block
fill 37 65 -151 53 65 -151 minecraft:grass_block
fill 60 65 -151 71 65 -151 minecraft:grass_block
fill 9 65 -150 13 65 -150 minecraft:light_gray_concrete
setblock 14 65 -150 minecraft:smooth_quartz
fill 15 65 -150 24 65 -150 minecraft:grass_block
fill 36 65 -150 51 65 -150 minecraft:grass_block
fill 59 65 -150 71 65 -150 minecraft:grass_block
fill 9 65 -149 13 65 -149 minecraft:light_gray_concrete
setblock 14 65 -149 minecraft:smooth_quartz
fill 15 65 -149 25 65 -149 minecraft:grass_block
fill 33 65 -149 50 65 -149 minecraft:grass_block
fill 59 65 -149 71 65 -149 minecraft:grass_block
fill 9 65 -148 12 65 -148 minecraft:light_gray_concrete
setblock 13 65 -148 minecraft:sea_lantern
setblock 14 65 -148 minecraft:smooth_quartz
fill 15 65 -148 27 65 -148 minecraft:grass_block
fill 29 65 -148 50 65 -148 minecraft:grass_block
fill 58 65 -148 71 65 -148 minecraft:grass_block
fill 9 65 -147 11 65 -147 minecraft:light_gray_concrete
setblock 12 65 -147 minecraft:sea_lantern
setblock 13 65 -147 minecraft:light_gray_concrete
setblock 14 65 -147 minecraft:smooth_quartz
fill 15 65 -147 48 65 -147 minecraft:grass_block
fill 52 65 -147 71 65 -147 minecraft:grass_block
fill 9 65 -146 10 65 -146 minecraft:light_gray_concrete
setblock 11 65 -146 minecraft:sea_lantern
fill 12 65 -146 13 65 -146 minecraft:light_gray_concrete
setblock 14 65 -146 minecraft:smooth_quartz
fill 15 65 -146 46 65 -146 minecraft:grass_block
fill 51 65 -146 71 65 -146 minecraft:grass_block
setblock 9 65 -145 minecraft:light_gray_concrete
setblock 10 65 -145 minecraft:sea_lantern
fill 11 65 -145 13 65 -145 minecraft:light_gray_concrete
setblock 14 65 -145 minecraft:smooth_quartz
fill 15 65 -145 46 65 -145 minecraft:grass_block
fill 50 65 -145 71 65 -145 minecraft:grass_block
fill 9 65 -144 14 65 -144 minecraft:light_gray_concrete
setblock 15 65 -144 minecraft:smooth_quartz
fill 16 65 -144 45 65 -144 minecraft:grass_block
fill 48 65 -144 71 65 -144 minecraft:grass_block
fill 10 65 -143 14 65 -143 minecraft:light_gray_concrete
setblock 15 65 -143 minecraft:smooth_quartz
fill 16 65 -143 46 65 -143 minecraft:grass_block
fill 49 65 -143 71 65 -143 minecraft:grass_block
fill 10 65 -142 14 65 -142 minecraft:light_gray_concrete
setblock 15 65 -142 minecraft:smooth_quartz
fill 16 65 -142 46 65 -142 minecraft:grass_block
fill 50 65 -142 71 65 -142 minecraft:grass_block
fill 10 65 -141 14 65 -141 minecraft:light_gray_concrete
setblock 15 65 -141 minecraft:sea_lantern
setblock 16 65 -141 minecraft:smooth_quartz
fill 17 65 -141 47 65 -141 minecraft:grass_block
fill 50 65 -141 71 65 -141 minecraft:grass_block
fill 11 65 -140 13 65 -140 minecraft:light_gray_concrete
setblock 14 65 -140 minecraft:sea_lantern
setblock 15 65 -140 minecraft:light_gray_concrete
setblock 16 65 -140 minecraft:smooth_quartz
fill 17 65 -140 48 65 -140 minecraft:grass_block
fill 51 65 -140 71 65 -140 minecraft:grass_block
fill 11 65 -139 12 65 -139 minecraft:light_gray_concrete
setblock 13 65 -139 minecraft:sea_lantern
fill 14 65 -139 15 65 -139 minecraft:light_gray_concrete
setblock 16 65 -139 minecraft:smooth_quartz
fill 17 65 -139 48 65 -139 minecraft:grass_block
fill 51 65 -139 71 65 -139 minecraft:grass_block
setblock 11 65 -138 minecraft:light_gray_concrete
setblock 12 65 -138 minecraft:sea_lantern
fill 13 65 -138 16 65 -138 minecraft:light_gray_concrete
setblock 17 65 -138 minecraft:smooth_quartz
fill 18 65 -138 48 65 -138 minecraft:grass_block
fill 51 65 -138 71 65 -138 minecraft:grass_block
fill 12 65 -137 16 65 -137 minecraft:light_gray_concrete
fill 17 65 -137 18 65 -137 minecraft:smooth_quartz
fill 19 65 -137 48 65 -137 minecraft:grass_block
fill 50 65 -137 71 65 -137 minecraft:grass_block
fill 12 65 -136 17 65 -136 minecraft:light_gray_concrete
setblock 18 65 -136 minecraft:smooth_quartz
fill 19 65 -136 71 65 -136 minecraft:grass_block
fill 13 65 -135 17 65 -135 minecraft:light_gray_concrete
setblock 18 65 -135 minecraft:sea_lantern
setblock 19 65 -135 minecraft:smooth_quartz
fill 20 65 -135 71 65 -135 minecraft:grass_block
fill 13 65 -134 16 65 -134 minecraft:light_gray_concrete
setblock 17 65 -134 minecraft:sea_lantern
setblock 18 65 -134 minecraft:light_gray_concrete
setblock 19 65 -134 minecraft:smooth_quartz
fill 20 65 -134 71 65 -134 minecraft:grass_block
fill 14 65 -133 15 65 -133 minecraft:light_gray_concrete
setblock 16 65 -133 minecraft:sea_lantern
fill 17 65 -133 19 65 -133 minecraft:light_gray_concrete
setblock 20 65 -133 minecraft:smooth_quartz
fill 21 65 -133 71 65 -133 minecraft:grass_block
fill 15 65 -132 20 65 -132 minecraft:light_gray_concrete
setblock 21 65 -132 minecraft:smooth_quartz
fill 22 65 -132 71 65 -132 minecraft:grass_block
fill 15 65 -131 21 65 -131 minecraft:light_gray_concrete
setblock 22 65 -131 minecraft:smooth_quartz
fill 23 65 -131 71 65 -131 minecraft:grass_block
fill 16 65 -130 21 65 -130 minecraft:light_gray_concrete
setblock 22 65 -130 minecraft:sea_lantern
setblock 23 65 -130 minecraft:smooth_quartz
fill 24 65 -130 71 65 -130 minecraft:grass_block
fill 17 65 -129 20 65 -129 minecraft:light_gray_concrete
setblock 21 65 -129 minecraft:sea_lantern
fill 22 65 -129 23 65 -129 minecraft:light_gray_concrete
setblock 24 65 -129 minecraft:smooth_quartz
fill 25 65 -129 71 65 -129 minecraft:grass_block
fill 18 65 -128 19 65 -128 minecraft:light_gray_concrete
setblock 20 65 -128 minecraft:sea_lantern
fill 21 65 -128 24 65 -128 minecraft:light_gray_concrete
setblock 25 65 -128 minecraft:smooth_quartz
fill 26 65 -128 39 65 -128 minecraft:grass_block
fill 43 65 -128 71 65 -128 minecraft:grass_block
fill 19 65 -127 25 65 -127 minecraft:light_gray_concrete
fill 26 65 -127 27 65 -127 minecraft:smooth_quartz
fill 28 65 -127 39 65 -127 minecraft:grass_block
fill 44 65 -127 70 65 -127 minecraft:grass_block
fill 8 66 -190 26 66 -190 minecraft:air
fill 8 66 -189 26 66 -189 minecraft:air
fill 8 66 -188 26 66 -188 minecraft:air
fill 8 66 -187 26 66 -187 minecraft:air
fill 8 66 -186 26 66 -186 minecraft:air
fill 8 66 -185 26 66 -185 minecraft:air
fill 8 66 -184 17 66 -184 minecraft:air
setblock 18 66 -184 minecraft:oak_log
fill 19 66 -184 26 66 -184 minecraft:air
fill 8 66 -183 26 66 -183 minecraft:air
fill 8 66 -182 26 66 -182 minecraft:air
fill 8 66 -181 26 66 -181 minecraft:air
fill 8 66 -180 26 66 -180 minecraft:air
fill 8 66 -179 14 66 -179 minecraft:air
fill 16 66 -179 26 66 -179 minecraft:air
fill 8 66 -178 14 66 -178 minecraft:air
fill 19 66 -178 26 66 -178 minecraft:air
fill 8 66 -177 15 66 -177 minecraft:air
fill 20 66 -177 26 66 -177 minecraft:air
fill 8 66 -176 15 66 -176 minecraft:air
fill 20 66 -176 26 66 -176 minecraft:air
fill 8 66 -175 17 66 -175 minecraft:air
fill 21 66 -175 26 66 -175 minecraft:air
fill 8 66 -174 17 66 -174 minecraft:air
setblock 18 66 -174 minecraft:oak_log
fill 19 66 -174 26 66 -174 minecraft:air
fill 8 66 -173 26 66 -173 minecraft:air
fill 8 66 -172 26 66 -172 minecraft:air
fill 8 66 -171 26 66 -171 minecraft:air
fill 8 66 -170 26 66 -170 minecraft:air
fill 8 66 -169 26 66 -169 minecraft:air
fill 8 66 -168 26 66 -168 minecraft:air
fill 8 66 -167 26 66 -167 minecraft:air
fill 8 66 -166 26 66 -166 minecraft:air
fill 9 66 -165 26 66 -165 minecraft:air
setblock 14 66 -164 minecraft:air
setblock 17 66 -164 minecraft:air
setblock 18 66 -164 minecraft:oak_log
fill 19 66 -164 26 66 -164 minecraft:air
setblock 10 66 -163 minecraft:air
fill 12 66 -163 13 66 -163 minecraft:air
fill 19 66 -163 26 66 -163 minecraft:air
setblock 9 66 -162 minecraft:air
fill 23 66 -162 26 66 -162 minecraft:air
setblock 19 66 -160 minecraft:air
fill 25 66 -160 26 66 -160 minecraft:air
setblock 29 66 -159 minecraft:air
setblock 33 66 -159 minecraft:air
setblock 37 66 -159 minecraft:air
fill 48 66 -159 50 66 -159 minecraft:air
setblock 52 66 -159 minecraft:air
fill 61 66 -159 71 66 -159 minecraft:air
setblock 14 66 -158 minecraft:air
setblock 27 66 -158 minecraft:air
setblock 35 66 -158 minecraft:air
setblock 53 66 -158 minecraft:air
fill 61 66 -158 71 66 -158 minecraft:air
setblock 12 66 -157 minecraft:air
setblock 29 66 -157 minecraft:air
fill 34 66 -157 35 66 -157 minecraft:air
setblock 38 66 -157 minecraft:air
setblock 46 66 -157 minecraft:air
fill 61 66 -157 71 66 -157 minecraft:air
setblock 30 66 -156 minecraft:air
setblock 36 66 -156 minecraft:air
setblock 59 66 -156 minecraft:air
fill 61 66 -156 71 66 -156 minecraft:air
setblock 9 66 -155 minecraft:air
setblock 17 66 -155 minecraft:air
setblock 39 66 -155 minecraft:air
setblock 53 66 -155 minecraft:air
setblock 55 66 -155 minecraft:air
setblock 59 66 -155 minecraft:air
fill 61 66 -155 71 66 -155 minecraft:air
setblock 18 66 -154 minecraft:oak_log
setblock 21 66 -154 minecraft:air
setblock 43 66 -154 minecraft:air
setblock 52 66 -154 minecraft:air
fill 61 66 -154 71 66 -154 minecraft:air
setblock 24 66 -153 minecraft:air
setblock 26 66 -153 minecraft:air
fill 60 66 -153 71 66 -153 minecraft:air
setblock 22 66 -152 minecraft:air
setblock 28 66 -152 minecraft:air
setblock 32 66 -152 minecraft:air
setblock 57 66 -152 minecraft:air
fill 60 66 -152 71 66 -152 minecraft:air
setblock 24 66 -151 minecraft:air
setblock 27 66 -151 minecraft:air
setblock 32 66 -151 minecraft:air
setblock 44 66 -151 minecraft:air
setblock 49 66 -151 minecraft:air
fill 59 66 -151 71 66 -151 minecraft:air
setblock 26 66 -150 minecraft:air
setblock 29 66 -150 minecraft:air
setblock 40 66 -150 minecraft:air
setblock 52 66 -150 minecraft:air
setblock 55 66 -150 minecraft:air
fill 59 66 -150 71 66 -150 minecraft:air
setblock 19 66 -149 minecraft:air
fill 59 66 -149 71 66 -149 minecraft:air
setblock 15 66 -148 minecraft:air
fill 58 66 -148 71 66 -148 minecraft:air
setblock 12 66 -147 minecraft:air
fill 52 66 -147 71 66 -147 minecraft:air
fill 51 66 -146 71 66 -146 minecraft:air
setblock 10 66 -145 minecraft:air
setblock 38 66 -145 minecraft:air
fill 50 66 -145 71 66 -145 minecraft:air
setblock 15 66 -144 minecraft:air
setblock 18 66 -144 minecraft:air
fill 48 66 -144 71 66 -144 minecraft:air
setblock 11 66 -143 minecraft:air
setblock 20 66 -143 minecraft:air
fill 49 66 -143 71 66 -143 minecraft:air
setblock 29 66 -142 minecraft:air
setblock 32 66 -142 minecraft:air
fill 50 66 -142 56 66 -142 minecraft:air
fill 60 66 -142 71 66 -142 minecraft:air
setblock 35 66 -141 minecraft:air
fill 50 66 -141 55 66 -141 minecraft:air
fill 60 66 -141 71 66 -141 minecraft:air
setblock 13 66 -140 minecraft:air
setblock 27 66 -140 minecraft:air
fill 51 66 -140 57 66 -140 minecraft:air
fill 60 66 -140 71 66 -140 minecraft:air
setblock 34 66 -139 minecraft:air
fill 51 66 -139 53 66 -139 minecraft:air
fill 55 66 -139 57 66 -139 minecraft:air
fill 60 66 -139 71 66 -139 minecraft:air
setblock 51 66 -138 minecraft:air
fill 55 66 -138 57 66 -138 minecraft:air
fill 60 66 -138 71 66 -138 minecraft:air
setblock 29 66 -137 minecraft:air
fill 60 66 -137 71 66 -137 minecraft:air
setblock 38 66 -136 minecraft:air
fill 59 66 -136 70 66 -136 minecraft:air
setblock 14 66 -135 minecraft:air
setblock 47 66 -135 minecraft:air
fill 59 66 -135 66 66 -135 minecraft:air
fill 58 66 -134 66 66 -134 minecraft:air
setblock 16 66 -133 minecraft:air
setblock 19 66 -133 minecraft:air
setblock 36 66 -133 minecraft:air
fill 58 66 -133 69 66 -133 minecraft:air
fill 56 66 -132 71 66 -132 minecraft:air
fill 55 66 -131 71 66 -131 minecraft:air
fill 55 66 -130 71 66 -130 minecraft:air
setblock 28 66 -129 minecraft:air
fill 54 66 -129 71 66 -129 minecraft:air
setblock 19 66 -128 minecraft:air
setblock 36 66 -128 minecraft:oak_log
fill 53 66 -128 71 66 -128 minecraft:air
setblock 33 66 -127 minecraft:air
setblock 38 66 -127 minecraft:air
fill 40 66 -127 41 66 -127 minecraft:air
fill 52 66 -127 70 66 -127 minecraft:air
fill 8 67 -190 26 67 -190 minecraft:air
fill 8 67 -189 26 67 -189 minecraft:air
fill 8 67 -188 26 67 -188 minecraft:air
fill 8 67 -187 26 67 -187 minecraft:air
fill 8 67 -186 26 67 -186 minecraft:air
fill 8 67 -185 26 67 -185 minecraft:air
fill 8 67 -184 17 67 -184 minecraft:air
setblock 18 67 -184 minecraft:oak_log
fill 19 67 -184 26 67 -184 minecraft:air
fill 8 67 -183 26 67 -183 minecraft:air
fill 8 67 -182 26 67 -182 minecraft:air
fill 8 67 -181 26 67 -181 minecraft:air
fill 8 67 -180 26 67 -180 minecraft:air
fill 8 67 -179 14 67 -179 minecraft:air
fill 16 67 -179 26 67 -179 minecraft:air
fill 8 67 -178 15 67 -178 minecraft:air
fill 18 67 -178 26 67 -178 minecraft:air
fill 8 67 -177 15 67 -177 minecraft:air
fill 20 67 -177 26 67 -177 minecraft:air
fill 8 67 -176 16 67 -176 minecraft:air
fill 21 67 -176 26 67 -176 minecraft:air
fill 8 67 -175 17 67 -175 minecraft:air
fill 22 67 -175 26 67 -175 minecraft:air
fill 8 67 -174 17 67 -174 minecraft:air
setblock 18 67 -174 minecraft:oak_log
fill 19 67 -174 26 67 -174 minecraft:air
fill 8 67 -173 26 67 -173 minecraft:air
fill 8 67 -172 26 67 -172 minecraft:air
fill 8 67 -171 26 67 -171 minecraft:air
fill 8 67 -170 26 67 -170 minecraft:air
fill 8 67 -169 26 67 -169 minecraft:air
fill 8 67 -168 26 67 -168 minecraft:air
fill 9 67 -167 26 67 -167 minecraft:air
fill 11 67 -166 26 67 -166 minecraft:air
fill 12 67 -165 13 67 -165 minecraft:air
fill 19 67 -165 26 67 -165 minecraft:air
setblock 18 67 -164 minecraft:oak_log
setblock 9 67 -162 minecraft:air
fill 24 67 -162 26 67 -162 minecraft:air
setblock 19 67 -160 minecraft:air
setblock 50 67 -159 minecraft:air
setblock 14 67 -158 minecraft:air
setblock 53 67 -158 minecraft:air
setblock 68 67 -158 minecraft:air
setblock 46 67 -157 minecraft:air
setblock 67 67 -157 minecraft:air
setblock 71 67 -157 minecraft:air
setblock 68 67 -156 minecraft:air
fill 70 67 -156 71 67 -156 minecraft:air
setblock 9 67 -155 minecraft:air
setblock 17 67 -155 minecraft:air
setblock 39 67 -155 minecraft:air
setblock 62 67 -155 minecraft:air
setblock 65 67 -155 minecraft:air
fill 70 67 -155 71 67 -155 minecraft:air
setblock 18 67 -154 minecraft:oak_log
setblock 21 67 -154 minecraft:air
setblock 43 67 -154 minecraft:air
setblock 52 67 -154 minecraft:air
setblock 65 67 -154 minecraft:air
setblock 67 67 -154 minecraft:air
setblock 69 67 -154 minecraft:air
setblock 71 67 -154 minecraft:air
setblock 64 67 -153 minecraft:air
setblock 22 67 -152 minecraft:air
fill 63 67 -152 65 67 -152 minecraft:air
setblock 24 67 -151 minecraft:air
setblock 32 67 -151 minecraft:air
setblock 44 67 -151 minecraft:air
setblock 49 67 -151 minecraft:air
fill 63 67 -151 67 67 -151 minecraft:air
fill 69 67 -151 71 67 -151 minecraft:air
setblock 40 67 -150 minecraft:air
fill 62 67 -150 71 67 -150 minecraft:air
fill 62 67 -149 71 67 -149 minecraft:air
setblock 15 67 -148 minecraft:air
fill 61 67 -148 71 67 -148 minecraft:air
setblock 12 67 -147 minecraft:air
fill 55 67 -147 56 67 -147 minecraft:air
fill 61 67 -147 71 67 -147 minecraft:air
setblock 53 67 -146 minecraft:air
setblock 56 67 -146 minecraft:air
setblock 58 67 -146 minecraft:air
fill 62 67 -146 71 67 -146 minecraft:air
setblock 10 67 -145 minecraft:air
setblock 38 67 -145 minecraft:air
setblock 51 67 -145 minecraft:air
setblock 57 67 -145 minecraft:air
fill 62 67 -145 71 67 -145 minecraft:air
setblock 15 67 -144 minecraft:air
setblock 18 67 -144 minecraft:air
setblock 48 67 -144 minecraft:air
setblock 57 67 -144 minecraft:air
fill 61 67 -144 71 67 -144 minecraft:air
setblock 11 67 -143 minecraft:air
setblock 20 67 -143 minecraft:air
setblock 50 67 -143 minecraft:air
fill 63 67 -143 71 67 -143 minecraft:air
setblock 29 67 -142 minecraft:air
setblock 32 67 -142 minecraft:air
setblock 61 67 -142 minecraft:air
fill 63 67 -142 71 67 -142 minecraft:air
setblock 35 67 -141 minecraft:air
fill 63 67 -141 71 67 -141 minecraft:air
setblock 13 67 -140 minecraft:air
setblock 27 67 -140 minecraft:air
fill 63 67 -140 71 67 -140 minecraft:air
setblock 34 67 -139 minecraft:air
setblock 53 67 -139 minecraft:air
fill 63 67 -139 71 67 -139 minecraft:air
fill 63 67 -138 71 67 -138 minecraft:air
setblock 29 67 -137 minecraft:air
setblock 61 67 -137 minecraft:air
fill 63 67 -137 71 67 -137 minecraft:air
setblock 38 67 -136 minecraft:air
fill 63 67 -136 71 67 -136 minecraft:air
setblock 14 67 -135 minecraft:air
setblock 47 67 -135 minecraft:air
fill 63 67 -135 71 67 -135 minecraft:air
fill 63 67 -134 69 67 -134 minecraft:air
setblock 16 67 -133 minecraft:air
setblock 19 67 -133 minecraft:air
setblock 36 67 -133 minecraft:air
setblock 59 67 -133 minecraft:air
fill 62 67 -133 67 67 -133 minecraft:air
fill 61 67 -132 65 67 -132 minecraft:air
setblock 56 67 -131 minecraft:air
fill 58 67 -131 59 67 -131 minecraft:air
fill 55 67 -130 56 67 -130 minecraft:air
setblock 58 67 -130 minecraft:air
setblock 60 67 -130 minecraft:air
setblock 63 67 -130 minecraft:air
setblock 28 67 -129 minecraft:air
setblock 55 67 -129 minecraft:air
setblock 64 67 -129 minecraft:air
setblock 19 67 -128 minecraft:air
setblock 36 67 -128 minecraft:oak_log
fill 56 67 -128 57 67 -128 minecraft:air
setblock 59 67 -128 minecraft:air
setblock 23 67 -127 minecraft:air
setblock 33 67 -127 minecraft:air
setblock 38 67 -127 minecraft:air
fill 56 67 -127 58 67 -127 minecraft:air
fill 8 68 -190 26 68 -190 minecraft:air
fill 8 68 -189 26 68 -189 minecraft:air
fill 8 68 -188 26 68 -188 minecraft:air
fill 9 68 -187 26 68 -187 minecraft:air
fill 9 68 -186 26 68 -186 minecraft:air
fill 9 68 -185 26 68 -185 minecraft:air
fill 9 68 -184 17 68 -184 minecraft:air
setblock 18 68 -184 minecraft:oak_log
fill 19 68 -184 26 68 -184 minecraft:air
fill 8 68 -183 26 68 -183 minecraft:air
fill 8 68 -182 26 68 -182 minecraft:air
fill 8 68 -181 26 68 -181 minecraft:air
fill 8 68 -180 26 68 -180 minecraft:air
fill 8 68 -179 26 68 -179 minecraft:air
fill 8 68 -178 15 68 -178 minecraft:air
fill 18 68 -178 26 68 -178 minecraft:air
fill 8 68 -177 16 68 -177 minecraft:air
fill 21 68 -177 26 68 -177 minecraft:air
fill 8 68 -176 16 68 -176 minecraft:air
fill 22 68 -176 26 68 -176 minecraft:air
fill 8 68 -175 17 68 -175 minecraft:air
fill 22 68 -175 26 68 -175 minecraft:air
fill 8 68 -174 17 68 -174 minecraft:air
setblock 18 68 -174 minecraft:oak_log
fill 19 68 -174 26 68 -174 minecraft:air
fill 8 68 -173 26 68 -173 minecraft:air
fill 8 68 -172 26 68 -172 minecraft:air
fill 8 68 -171 26 68 -171 minecraft:air
fill 8 68 -170 26 68 -170 minecraft:air
fill 10 68 -169 26 68 -169 minecraft:air
fill 12 68 -168 26 68 -168 minecraft:air
setblock 12 68 -167 minecraft:air
fill 15 68 -167 26 68 -167 minecraft:air
setblock 16 68 -166 minecraft:air
setblock 26 68 -166 minecraft:air
setblock 18 68 -164 minecraft:oak_log
setblock 9 68 -162 minecraft:air
setblock 19 68 -160 minecraft:air
setblock 50 68 -159 minecraft:air
setblock 14 68 -158 minecraft:air
setblock 53 68 -158 minecraft:air
setblock 68 68 -158 minecraft:air
setblock 46 68 -157 minecraft:air
setblock 9 68 -155 minecraft:air
setblock 17 68 -155 minecraft:air
setblock 39 68 -155 minecraft:air
setblock 71 68 -155 minecraft:air
setblock 18 68 -154 minecraft:oak_log
setblock 21 68 -154 minecraft:air
setblock 43 68 -154 minecraft:air
setblock 52 68 -154 minecraft:air
setblock 67 68 -154 minecraft:air
setblock 22 68 -152 minecraft:air
setblock 63 68 -152 minecraft:air
setblock 24 68 -151 minecraft:air
setblock 32 68 -151 minecraft:air
setblock 44 68 -151 minecraft:air
setblock 49 68 -151 minecraft:air
setblock 67 68 -151 minecraft:air
setblock 40 68 -150 minecraft:air
setblock 64 68 -150 minecraft:air
setblock 69 68 -150 minecraft:air
setblock 68 68 -149 minecraft:air
setblock 15 68 -148 minecraft:air
setblock 65 68 -148 minecraft:air
setblock 71 68 -148 minecraft:air
setblock 12 68 -147 minecraft:air
setblock 55 68 -147 minecraft:air
setblock 63 68 -147 minecraft:air
setblock 71 68 -147 minecraft:air
setblock 53 68 -146 minecraft:air
setblock 58 68 -146 minecraft:air
setblock 10 68 -145 minecraft:air
setblock 38 68 -145 minecraft:air
setblock 51 68 -145 minecraft:air
setblock 69 68 -145 minecraft:air
setblock 15 68 -144 minecraft:air
setblock 18 68 -144 minecraft:air
setblock 48 68 -144 minecraft:air
setblock 57 68 -144 minecraft:air
setblock 64 68 -144 minecraft:air
setblock 67 68 -144 minecraft:air
setblock 11 68 -143 minecraft:air
setblock 20 68 -143 minecraft:air
setblock 50 68 -143 minecraft:air
setblock 63 68 -143 minecraft:air
fill 66 68 -143 68 68 -143 minecraft:air
setblock 29 68 -142 minecraft:air
setblock 32 68 -142 minecraft:air
setblock 66 68 -142 minecraft:air
setblock 35 68 -141 minecraft:air
fill 66 68 -141 67 68 -141 minecraft:air
setblock 69 68 -141 minecraft:air
setblock 13 68 -140 minecraft:air
setblock 27 68 -140 minecraft:air
setblock 64 68 -140 minecraft:air
fill 68 68 -140 69 68 -140 minecraft:air
setblock 34 68 -139 minecraft:air
setblock 53 68 -139 minecraft:air
setblock 29 68 -137 minecraft:air
setblock 70 68 -137 minecraft:air
setblock 38 68 -136 minecraft:air
setblock 64 68 -136 minecraft:air
setblock 14 68 -135 minecraft:air
setblock 47 68 -135 minecraft:air
setblock 16 68 -133 minecraft:air
setblock 19 68 -133 minecraft:air
setblock 36 68 -133 minecraft:air
setblock 63 68 -133 minecraft:air
setblock 56 68 -130 minecraft:air
setblock 28 68 -129 minecraft:air
setblock 64 68 -129 minecraft:air
setblock 19 68 -128 minecraft:air
fill 22 68 -128 24 68 -128 minecraft:air
setblock 36 68 -128 minecraft:oak_log
fill 21 68 -127 25 68 -127 minecraft:air
setblock 33 68 -127 minecraft:air
setblock 38 68 -127 minecraft:air
setblock 56 68 -127 minecraft:air
fill 9 69 -190 26 69 -190 minecraft:air
fill 10 69 -189 26 69 -189 minecraft:air
fill 10 69 -188 26 69 -188 minecraft:air
fill 10 69 -187 26 69 -187 minecraft:air
fill 9 69 -186 17 69 -186 minecraft:air
setblock 18 69 -186 minecraft:oak_leaves[persistent=true]
fill 19 69 -186 26 69 -186 minecraft:air
fill 10 69 -185 16 69 -185 minecraft:air
fill 17 69 -185 19 69 -185 minecraft:oak_leaves[persistent=true]
fill 20 69 -185 26 69 -185 minecraft:air
fill 10 69 -184 15 69 -184 minecraft:air
fill 16 69 -184 17 69 -184 minecraft:oak_leaves[persistent=true]
setblock 18 69 -184 minecraft:oak_log
fill 19 69 -184 20 69 -184 minecraft:oak_leaves[persistent=true]
fill 21 69 -184 26 69 -184 minecraft:air
setblock 8 69 -183 minecraft:air
fill 10 69 -183 16 69 -183 minecraft:air
fill 17 69 -183 19 69 -183 minecraft:oak_leaves[persistent=true]
fill 20 69 -183 26 69 -183 minecraft:air
fill 10 69 -182 17 69 -182 minecraft:air
setblock 18 69 -182 minecraft:oak_leaves[persistent=true]
fill 19 69 -182 26 69 -182 minecraft:air
fill 10 69 -181 26 69 -181 minecraft:air
fill 10 69 -180 26 69 -180 minecraft:air
fill 9 69 -179 26 69 -179 minecraft:air
fill 9 69 -178 16 69 -178 minecraft:air
fill 18 69 -178 26 69 -178 minecraft:air
fill 10 69 -177 16 69 -177 minecraft:air
fill 22 69 -177 26 69 -177 minecraft:air
fill 10 69 -176 17 69 -176 minecraft:air
setblock 18 69 -176 minecraft:oak_leaves[persistent=true]
fill 22 69 -176 25 69 -176 minecraft:air
fill 10 69 -175 16 69 -175 minecraft:air
fill 17 69 -175 19 69 -175 minecraft:oak_leaves[persistent=true]
fill 23 69 -175 25 69 -175 minecraft:air
fill 9 69 -174 15 69 -174 minecraft:air
fill 16 69 -174 17 69 -174 minecraft:oak_leaves[persistent=true]
setblock 18 69 -174 minecraft:oak_log
fill 19 69 -174 20 69 -174 minecraft:oak_leaves[persistent=true]
fill 21 69 -174 25 69 -174 minecraft:air
fill 9 69 -173 16 69 -173 minecraft:air
fill 17 69 -173 19 69 -173 minecraft:oak_leaves[persistent=true]
fill 20 69 -173 25 69 -173 minecraft:air
fill 9 69 -172 17 69 -172 minecraft:air
setblock 18 69 -172 minecraft:oak_leaves[persistent=true]
fill 19 69 -172 26 69 -172 minecraft:air
fill 11 69 -171 25 69 -171 minecraft:air
fill 14 69 -170 25 69 -170 minecraft:air
fill 15 69 -169 25 69 -169 minecraft:air
setblock 12 69 -168 minecraft:air
fill 16 69 -168 25 69 -168 minecraft:air
setblock 19 69 -167 minecraft:air
setblock 24 69 -167 minecraft:air
setblock 18 69 -166 minecraft:oak_leaves[persistent=true]
setblock 26 69 -166 minecraft:air
fill 17 69 -165 19 69 -165 minecraft:oak_leaves[persistent=true]
fill 16 69 -164 17 69 -164 minecraft:oak_leaves[persistent=true]
setblock 18 69 -164 minecraft:oak_log
fill 19 69 -164 20 69 -164 minecraft:oak_leaves[persistent=true]
fill 17 69 -163 19 69 -163 minecraft:oak_leaves[persistent=true]
setblock 9 69 -162 minecraft:air
setblock 18 69 -162 minecraft:oak_leaves[persistent=true]
setblock 19 69 -160 minecraft:air
setblock 50 69 -159 minecraft:air
setblock 14 69 -158 minecraft:air
setblock 53 69 -158 minecraft:air
setblock 68 69 -158 minecraft:air
setblock 46 69 -157 minecraft:air
setblock 18 69 -156 minecraft:oak_leaves[persistent=true]
setblock 9 69 -155 minecraft:air
fill 17 69 -155 19 69 -155 minecraft:oak_leaves[persistent=true]
setblock 39 69 -155 minecraft:air
fill 16 69 -154 17 69 -154 minecraft:oak_leaves[persistent=true]
setblock 18 69 -154 minecraft:oak_log
fill 19 69 -154 20 69 -154 minecraft:oak_leaves[persistent=true]
setblock 21 69 -154 minecraft:air
setblock 43 69 -154 minecraft:air
setblock 52 69 -154 minecraft:air
setblock 67 69 -154 minecraft:air
fill 17 69 -153 19 69 -153 minecraft:oak_leaves[persistent=true]
setblock 18 69 -152 minecraft:oak_leaves[persistent=true]
setblock 22 69 -152 minecraft:air
setblock 24 69 -151 minecraft:air
setblock 32 69 -151 minecraft:air
setblock 44 69 -151 minecraft:air
setblock 49 69 -151 minecraft:air
setblock 40 69 -150 minecraft:air
setblock 15 69 -148 minecraft:air
setblock 65 69 -148 minecraft:air
fill 11 69 -147 12 69 -147 minecraft:air
setblock 55 69 -147 minecraft:air
setblock 63 69 -147 minecraft:air
setblock 53 69 -146 minecraft:air
setblock 58 69 -146 minecraft:air
fill 10 69 -145 11 69 -145 minecraft:air
fill 38 69 -145 39 69 -145 minecraft:air
setblock 51 69 -145 minecraft:air
fill 10 69 -144 12 69 -144 minecraft:air
setblock 15 69 -144 minecraft:air
setblock 18 69 -144 minecraft:air
setblock 48 69 -144 minecraft:air
setblock 57 69 -144 minecraft:air
setblock 67 69 -144 minecraft:air
fill 10 69 -143 13 69 -143 minecraft:air
setblock 20 69 -143 minecraft:air
setblock 50 69 -143 minecraft:air
fill 10 69 -142 12 69 -142 minecraft:air
setblock 27 69 -142 minecraft:air
setblock 29 69 -142 minecraft:air
setblock 32 69 -142 minecraft:air
setblock 11 69 -141 minecraft:air
fill 26 69 -141 28 69 -141 minecraft:air
fill 34 69 -141 35 69 -141 minecraft:air
fill 12 69 -140 13 69 -140 minecraft:air
fill 25 69 -140 29 69 -140 minecraft:air
fill 33 69 -140 35 69 -140 minecraft:air
setblock 64 69 -140 minecraft:air
setblock 68 69 -140 minecraft:air
fill 26 69 -139 28 69 -139 minecraft:air
fill 32 69 -139 36 69 -139 minecraft:air
setblock 53 69 -139 minecraft:air
setblock 27 69 -138 minecraft:air
fill 33 69 -138 35 69 -138 minecraft:air
setblock 29 69 -137 minecraft:air
setblock 34 69 -137 minecraft:air
setblock 70 69 -137 minecraft:air
setblock 38 69 -136 minecraft:air
setblock 64 69 -136 minecraft:air
setblock 14 69 -135 minecraft:air
setblock 47 69 -135 minecraft:air
setblock 14 69 -134 minecraft:air
setblock 16 69 -133 minecraft:air
setblock 19 69 -133 minecraft:air
setblock 36 69 -133 minecraft:air
setblock 36 69 -130 minecraft:oak_leaves[persistent=true]
setblock 56 69 -130 minecraft:air
setblock 28 69 -129 minecraft:air
fill 35 69 -129 37 69 -129 minecraft:oak_leaves[persistent=true]
setblock 64 69 -129 minecraft:air
setblock 19 69 -128 minecraft:air
fill 22 69 -128 24 69 -128 minecraft:air
fill 34 69 -128 35 69 -128 minecraft:oak_leaves[persistent=true]
setblock 36 69 -128 minecraft:oak_log
fill 37 69 -128 38 69 -128 minecraft:oak_leaves[persistent=true]
setblock 52 69 -128 minecraft:oak_leaves[persistent=true]
setblock 62 69 -128 minecraft:oak_leaves[persistent=true]
setblock 19 69 -127 minecraft:air
fill 21 69 -127 25 69 -127 minecraft:air
setblock 27 69 -127 minecraft:air
setblock 33 69 -127 minecraft:air
fill 35 69 -127 37 69 -127 minecraft:oak_leaves[persistent=true]
setblock 38 69 -127 minecraft:air
fill 51 69 -127 53 69 -127 minecraft:oak_leaves[persistent=true]
setblock 56 69 -127 minecraft:air
fill 61 69 -127 63 69 -127 minecraft:oak_leaves[persistent=true]
setblock 71 69 -127 minecraft:oak_leaves[persistent=true]
fill 10 70 -190 25 70 -190 minecraft:air
fill 11 70 -189 25 70 -189 minecraft:air
fill 12 70 -188 25 70 -188 minecraft:air
fill 12 70 -187 24 70 -187 minecraft:air
fill 9 70 -186 10 70 -186 minecraft:air
fill 12 70 -186 16 70 -186 minecraft:air
fill 17 70 -186 19 70 -186 minecraft:oak_leaves[persistent=true]
fill 20 70 -186 24 70 -186 minecraft:air
fill 12 70 -185 15 70 -185 minecraft:air
fill 16 70 -185 20 70 -185 minecraft:oak_leaves[persistent=true]
fill 21 70 -185 23 70 -185 minecraft:air
fill 12 70 -184 15 70 -184 minecraft:air
fill 16 70 -184 17 70 -184 minecraft:oak_leaves[persistent=true]
setblock 18 70 -184 minecraft:oak_log
fill 19 70 -184 20 70 -184 minecraft:oak_leaves[persistent=true]
setblock 21 70 -184 minecraft:air
setblock 8 70 -183 minecraft:air
setblock 10 70 -183 minecraft:air
fill 12 70 -183 15 70 -183 minecraft:air
fill 16 70 -183 20 70 -183 minecraft:oak_leaves[persistent=true]
fill 12 70 -182 16 70 -182 minecraft:air
fill 17 70 -182 19 70 -182 minecraft:oak_leaves[persistent=true]
setblock 26 70 -182 minecraft:air
fill 12 70 -181 16 70 -181 minecraft:air
fill 19 70 -181 21 70 -181 minecraft:air
fill 12 70 -180 14 70 -180 minecraft:air
setblock 22 70 -180 minecraft:air
fill 12 70 -179 14 70 -179 minecraft:air
setblock 19 70 -179 minecraft:air
fill 24 70 -179 25 70 -179 minecraft:air
setblock 9 70 -178 minecraft:air
fill 12 70 -178 14 70 -178 minecraft:air
fill 12 70 -177 13 70 -177 minecraft:air
setblock 16 70 -177 minecraft:air
fill 25 70 -177 26 70 -177 minecraft:air
fill 12 70 -176 13 70 -176 minecraft:air
fill 17 70 -176 19 70 -176 minecraft:oak_leaves[persistent=true]
fill 12 70 -175 13 70 -175 minecraft:air
fill 16 70 -175 20 70 -175 minecraft:oak_leaves[persistent=true]
setblock 23 70 -175 minecraft:air
fill 12 70 -174 13 70 -174 minecraft:air
fill 16 70 -174 17 70 -174 minecraft:oak_leaves[persistent=true]
setblock 18 70 -174 minecraft:oak_log
fill 19 70 -174 20 70 -174 minecraft:oak_leaves[persistent=true]
fill 21 70 -174 23 70 -174 minecraft:air
setblock 12 70 -173 minecraft:air
fill 16 70 -173 20 70 -173 minecraft:oak_leaves[persistent=true]
fill 21 70 -173 23 70 -173 minecraft:air
setblock 12 70 -172 minecraft:air
fill 17 70 -172 19 70 -172 minecraft:oak_leaves[persistent=true]
fill 24 70 -172 25 70 -172 minecraft:air
fill 24 70 -170 25 70 -170 minecraft:air
setblock 24 70 -169 minecraft:air
setblock 20 70 -168 minecraft:air
fill 23 70 -168 24 70 -168 minecraft:air
fill 17 70 -166 19 70 -166 minecraft:oak_leaves[persistent=true]
fill 16 70 -165 20 70 -165 minecraft:oak_leaves[persistent=true]
fill 16 70 -164 17 70 -164 minecraft:oak_leaves[persistent=true]
setblock 18 70 -164 minecraft:oak_log
fill 19 70 -164 20 70 -164 minecraft:oak_leaves[persistent=true]
fill 16 70 -163 20 70 -163 minecraft:oak_leaves[persistent=true]
setblock 9 70 -162 minecraft:air
fill 17 70 -162 19 70 -162 minecraft:oak_leaves[persistent=true]
setblock 19 70 -160 minecraft:air
setblock 46 70 -159 minecraft:air
setblock 50 70 -159 minecraft:air
setblock 14 70 -158 minecraft:air
fill 45 70 -158 47 70 -158 minecraft:air
setblock 53 70 -158 minecraft:air
setblock 68 70 -158 minecraft:air
fill 44 70 -157 48 70 -157 minecraft:air
fill 17 70 -156 19 70 -156 minecraft:oak_leaves[persistent=true]
fill 45 70 -156 47 70 -156 minecraft:air
setblock 9 70 -155 minecraft:air
fill 16 70 -155 20 70 -155 minecraft:oak_leaves[persistent=true]
setblock 39 70 -155 minecraft:air
setblock 46 70 -155 minecraft:air
fill 16 70 -154 17 70 -154 minecraft:oak_leaves[persistent=true]
setblock 18 70 -154 minecraft:oak_log
fill 19 70 -154 20 70 -154 minecraft:oak_leaves[persistent=true]
setblock 21 70 -154 minecraft:air
setblock 43 70 -154 minecraft:air
setblock 52 70 -154 minecraft:air
setblock 67 70 -154 minecraft:air
fill 16 70 -153 20 70 -153 minecraft:oak_leaves[persistent=true]
fill 17 70 -152 19 70 -152 minecraft:oak_leaves[persistent=true]
setblock 22 70 -152 minecraft:air
setblock 24 70 -151 minecraft:air
setblock 32 70 -151 minecraft:air
setblock 44 70 -151 minecraft:air
setblock 49 70 -151 minecraft:air
setblock 40 70 -150 minecraft:air
setblock 15 70 -148 minecraft:air
setblock 65 70 -148 minecraft:air
setblock 12 70 -147 minecraft:air
setblock 55 70 -147 minecraft:air
setblock 63 70 -147 minecraft:air
setblock 53 70 -146 minecraft:air
setblock 58 70 -146 minecraft:air
setblock 10 70 -145 minecraft:air
setblock 38 70 -145 minecraft:air
setblock 48 70 -145 minecraft:air
setblock 51 70 -145 minecraft:air
fill 10 70 -144 12 70 -144 minecraft:air
setblock 15 70 -144 minecraft:air
setblock 18 70 -144 minecraft:air
setblock 32 70 -144 minecraft:air
setblock 48 70 -144 minecraft:air
setblock 57 70 -144 minecraft:air
setblock 67 70 -144 minecraft:air
fill 10 70 -143 12 70 -143 minecraft:air
setblock 20 70 -143 minecraft:air
fill 31 70 -143 33 70 -143 minecraft:air
setblock 50 70 -143 minecraft:air
fill 10 70 -142 12 70 -142 minecraft:air
fill 29 70 -142 34 70 -142 minecraft:air
fill 10 70 -141 11 70 -141 minecraft:air
fill 26 70 -141 28 70 -141 minecraft:air
fill 31 70 -141 33 70 -141 minecraft:air
setblock 35 70 -141 minecraft:air
fill 11 70 -140 13 70 -140 minecraft:air
fill 26 70 -140 28 70 -140 minecraft:air
fill 32 70 -140 35 70 -140 minecraft:air
setblock 64 70 -140 minecraft:air
setblock 68 70 -140 minecraft:air
setblock 11 70 -139 minecraft:air
fill 26 70 -139 29 70 -139 minecraft:air
fill 33 70 -139 35 70 -139 minecraft:air
setblock 53 70 -139 minecraft:air
setblock 11 70 -138 minecraft:air
fill 28 70 -138 30 70 -138 minecraft:air
fill 33 70 -138 35 70 -138 minecraft:air
setblock 38 70 -138 minecraft:air
setblock 12 70 -137 minecraft:air
setblock 14 70 -137 minecraft:air
fill 27 70 -137 31 70 -137 minecraft:air
fill 37 70 -137 39 70 -137 minecraft:air
setblock 70 70 -137 minecraft:air
fill 13 70 -136 15 70 -136 minecraft:air
fill 28 70 -136 30 70 -136 minecraft:air
fill 36 70 -136 40 70 -136 minecraft:air
setblock 64 70 -136 minecraft:air
fill 13 70 -135 16 70 -135 minecraft:air
setblock 29 70 -135 minecraft:air
fill 37 70 -135 39 70 -135 minecraft:air
setblock 47 70 -135 minecraft:air
fill 13 70 -134 17 70 -134 minecraft:air
setblock 38 70 -134 minecraft:air
fill 14 70 -133 19 70 -133 minecraft:air
setblock 36 70 -133 minecraft:air
fill 15 70 -132 17 70 -132 minecraft:air
setblock 16 70 -131 minecraft:air
setblock 28 70 -131 minecraft:air
fill 27 70 -130 29 70 -130 minecraft:air
fill 35 70 -130 37 70 -130 minecraft:oak_leaves[persistent=true]
setblock 56 70 -130 minecraft:air
fill 26 70 -129 30 70 -129 minecraft:air
fill 34 70 -129 38 70 -129 minecraft:oak_leaves[persistent=true]
setblock 64 70 -129 minecraft:air
setblock 19 70 -128 minecraft:air
fill 22 70 -128 24 70 -128 minecraft:air
fill 27 70 -128 29 70 -128 minecraft:air
fill 34 70 -128 35 70 -128 minecraft:oak_leaves[persistent=true]
setblock 36 70 -128 minecraft:oak_log
fill 37 70 -128 38 70 -128 minecraft:oak_leaves[persistent=true]
fill 51 70 -128 53 70 -128 minecraft:oak_leaves[persistent=true]
fill 61 70 -128 63 70 -128 minecraft:oak_leaves[persistent=true]
setblock 71 70 -128 minecraft:oak_leaves[persistent=true]
fill 21 70 -127 25 70 -127 minecraft:air
setblock 28 70 -127 minecraft:air
setblock 33 70 -127 minecraft:air
fill 34 70 -127 38 70 -127 minecraft:oak_leaves[persistent=true]
fill 50 70 -127 54 70 -127 minecraft:oak_leaves[persistent=true]
setblock 56 70 -127 minecraft:air
fill 60 70 -127 64 70 -127 minecraft:oak_leaves[persistent=true]
fill 70 70 -127 71 70 -127 minecraft:oak_leaves[persistent=true]
setblock 12 71 -190 minecraft:air
setblock 14 71 -190 minecraft:air
setblock 25 71 -190 minecraft:air
setblock 15 71 -189 minecraft:air
setblock 13 71 -187 minecraft:air
setblock 9 71 -186 minecraft:air
setblock 16 71 -186 minecraft:air
setblock 18 71 -186 minecraft:oak_leaves[persistent=true]
fill 17 71 -185 19 71 -185 minecraft:oak_leaves[persistent=true]
setblock 14 71 -184 minecraft:air
fill 16 71 -184 20 71 -184 minecraft:oak_leaves[persistent=true]
setblock 21 71 -184 minecraft:air
setblock 8 71 -183 minecraft:air
setblock 16 71 -183 minecraft:air
fill 17 71 -183 19 71 -183 minecraft:oak_leaves[persistent=true]
setblock 18 71 -182 minecraft:oak_leaves[persistent=true]
setblock 12 71 -181 minecraft:air
setblock 20 71 -181 minecraft:air
setblock 14 71 -180 minecraft:air
setblock 14 71 -179 minecraft:air
setblock 19 71 -179 minecraft:air
setblock 9 71 -178 minecraft:air
setblock 16 71 -177 minecraft:air
setblock 18 71 -176 minecraft:oak_leaves[persistent=true]
fill 17 71 -175 19 71 -175 minecraft:oak_leaves[persistent=true]
fill 16 71 -174 20 71 -174 minecraft:oak_leaves[persistent=true]
setblock 23 71 -174 minecraft:air
fill 17 71 -173 19 71 -173 minecraft:oak_leaves[persistent=true]
setblock 23 71 -173 minecraft:air
setblock 18 71 -172 minecraft:oak_leaves[persistent=true]
setblock 20 71 -168 minecraft:air
setblock 18 71 -166 minecraft:oak_leaves[persistent=true]
fill 17 71 -165 19 71 -165 minecraft:oak_leaves[persistent=true]
fill 8 71 -164 9 71 -164 minecraft:air
fill 16 71 -164 20 71 -164 minecraft:oak_leaves[persistent=true]
fill 8 71 -163 10 71 -163 minecraft:air
fill 17 71 -163 19 71 -163 minecraft:oak_leaves[persistent=true]
fill 8 71 -162 11 71 -162 minecraft:air
setblock 18 71 -162 minecraft:oak_leaves[persistent=true]
fill 8 71 -161 10 71 -161 minecraft:air
setblock 9 71 -160 minecraft:air
setblock 19 71 -160 minecraft:air
setblock 50 71 -159 minecraft:air
setblock 14 71 -158 minecraft:air
fill 45 71 -158 47 71 -158 minecraft:air
setblock 53 71 -158 minecraft:air
setblock 68 71 -158 minecraft:air
setblock 9 71 -157 minecraft:air
fill 45 71 -157 47 71 -157 minecraft:air
fill 8 71 -156 10 71 -156 minecraft:air
setblock 18 71 -156 minecraft:oak_leaves[persistent=true]
setblock 43 71 -156 minecraft:air
fill 45 71 -156 47 71 -156 minecraft:air
fill 8 71 -155 11 71 -155 minecraft:air
fill 17 71 -155 19 71 -155 minecraft:oak_leaves[persistent=true]
setblock 39 71 -155 minecraft:air
fill 42 71 -155 44 71 -155 minecraft:air
setblock 52 71 -155 minecraft:air
fill 8 71 -154 10 71 -154 minecraft:air
fill 16 71 -154 20 71 -154 minecraft:oak_leaves[persistent=true]
fill 21 71 -154 22 71 -154 minecraft:air
fill 41 71 -154 45 71 -154 minecraft:air
setblock 52 71 -154 minecraft:air
setblock 67 71 -154 minecraft:air
setblock 9 71 -153 minecraft:air
fill 17 71 -153 19 71 -153 minecraft:oak_leaves[persistent=true]
fill 21 71 -153 23 71 -153 minecraft:air
fill 42 71 -153 44 71 -153 minecraft:air
setblock 49 71 -153 minecraft:air
setblock 18 71 -152 minecraft:oak_leaves[persistent=true]
fill 20 71 -152 24 71 -152 minecraft:air
setblock 43 71 -152 minecraft:air
fill 48 71 -152 50 71 -152 minecraft:air
fill 21 71 -151 24 71 -151 minecraft:air
setblock 32 71 -151 minecraft:air
setblock 44 71 -151 minecraft:air
fill 47 71 -151 51 71 -151 minecraft:air
setblock 15 71 -150 minecraft:air
setblock 22 71 -150 minecraft:air
setblock 40 71 -150 minecraft:air
fill 48 71 -150 50 71 -150 minecraft:air
fill 14 71 -149 16 71 -149 minecraft:air
setblock 49 71 -149 minecraft:air
fill 13 71 -148 17 71 -148 minecraft:air
setblock 65 71 -148 minecraft:air
setblock 12 71 -147 minecraft:air
fill 14 71 -147 16 71 -147 minecraft:air
setblock 55 71 -147 minecraft:air
setblock 58 71 -147 minecraft:air
setblock 63 71 -147 minecraft:air
setblock 15 71 -146 minecraft:air
setblock 18 71 -146 minecraft:air
setblock 53 71 -146 minecraft:air
setblock 58 71 -146 minecraft:air
setblock 10 71 -145 minecraft:air
fill 17 71 -145 19 71 -145 minecraft:air
setblock 38 71 -145 minecraft:air
setblock 51 71 -145 minecraft:air
setblock 9 71 -144 minecraft:air
setblock 11 71 -144 minecraft:air
fill 15 71 -144 20 71 -144 minecraft:air
setblock 48 71 -144 minecraft:air
setblock 57 71 -144 minecraft:air
setblock 67 71 -144 minecraft:air
fill 10 71 -143 12 71 -143 minecraft:air
fill 17 71 -143 20 71 -143 minecraft:air
fill 31 71 -143 33 71 -143 minecraft:air
setblock 50 71 -143 minecraft:air
setblock 11 71 -142 minecraft:air
setblock 18 71 -142 minecraft:air
setblock 29 71 -142 minecraft:air
fill 31 71 -142 33 71 -142 minecraft:air
setblock 35 71 -142 minecraft:air
fill 10 71 -141 11 71 -141 minecraft:air
setblock 27 71 -141 minecraft:air
fill 31 71 -141 33 71 -141 minecraft:air
setblock 35 71 -141 minecraft:air
setblock 11 71 -140 minecraft:air
setblock 13 71 -140 minecraft:air
fill 26 71 -140 28 71 -140 minecraft:air
setblock 34 71 -140 minecraft:air
setblock 64 71 -140 minecraft:air
setblock 68 71 -140 minecraft:air
setblock 11 71 -139 minecraft:air
setblock 27 71 -139 minecraft:air
fill 33 71 -139 35 71 -139 minecraft:air
setblock 53 71 -139 minecraft:air
setblock 11 71 -138 minecraft:air
fill 28 71 -138 30 71 -138 minecraft:air
setblock 34 71 -138 minecraft:air
fill 28 71 -137 30 71 -137 minecraft:air
fill 37 71 -137 39 71 -137 minecraft:air
setblock 70 71 -137 minecraft:air
fill 13 71 -136 15 71 -136 minecraft:air
fill 28 71 -136 30 71 -136 minecraft:air
fill 37 71 -136 39 71 -136 minecraft:air
setblock 64 71 -136 minecraft:air
fill 13 71 -135 15 71 -135 minecraft:air
setblock 19 71 -135 minecraft:air
fill 36 71 -135 39 71 -135 minecraft:air
setblock 47 71 -135 minecraft:air
fill 13 71 -134 20 71 -134 minecraft:air
fill 35 71 -134 37 71 -134 minecraft:air
fill 15 71 -133 21 71 -133 minecraft:air
fill 34 71 -133 38 71 -133 minecraft:air
fill 15 71 -132 20 71 -132 minecraft:air
fill 35 71 -132 37 71 -132 minecraft:air
setblock 19 71 -131 minecraft:air
setblock 36 71 -131 minecraft:air
setblock 19 71 -130 minecraft:air
fill 27 71 -130 29 71 -130 minecraft:air
setblock 36 71 -130 minecraft:oak_leaves[persistent=true]
setblock 56 71 -130 minecraft:air
fill 18 71 -129 20 71 -129 minecraft:air
fill 27 71 -129 29 71 -129 minecraft:air
fill 35 71 -129 37 71 -129 minecraft:oak_leaves[persistent=true]
setblock 64 71 -129 minecraft:air
fill 18 71 -128 21 71 -128 minecraft:air
fill 27 71 -128 29 71 -128 minecraft:air
fill 34 71 -128 38 71 -128 minecraft:oak_leaves[persistent=true]
setblock 52 71 -128 minecraft:oak_leaves[persistent=true]
setblock 62 71 -128 minecraft:oak_leaves[persistent=true]
fill 19 71 -127 20 71 -127 minecraft:air
setblock 23 71 -127 minecraft:air
setblock 33 71 -127 minecraft:air
fill 35 71 -127 37 71 -127 minecraft:oak_leaves[persistent=true]
setblock 38 71 -127 minecraft:air
fill 51 71 -127 53 71 -127 minecraft:oak_leaves[persistent=true]
setblock 56 71 -127 minecraft:air
fill 61 71 -127 63 71 -127 minecraft:oak_leaves[persistent=true]
setblock 71 71 -127 minecraft:oak_leaves[persistent=true]
setblock 9 72 -186 minecraft:air
setblock 18 72 -184 minecraft:oak_leaves[persistent=true]
setblock 21 72 -184 minecraft:air
setblock 8 72 -183 minecraft:air
setblock 12 72 -181 minecraft:air
setblock 19 72 -179 minecraft:air
setblock 9 72 -178 minecraft:air
setblock 16 72 -177 minecraft:air
setblock 18 72 -174 minecraft:oak_leaves[persistent=true]
setblock 23 72 -173 minecraft:air
setblock 18 72 -172 minecraft:air
setblock 20 72 -168 minecraft:air
setblock 18 72 -164 minecraft:oak_leaves[persistent=true]
fill 8 72 -163 10 72 -163 minecraft:air
fill 8 72 -162 10 72 -162 minecraft:air
fill 8 72 -161 10 72 -161 minecraft:air
setblock 14 72 -160 minecraft:air
setblock 19 72 -160 minecraft:air
fill 13 72 -159 15 72 -159 minecraft:air
fill 46 72 -159 48 72 -159 minecraft:air
setblock 50 72 -159 minecraft:air
fill 12 72 -158 16 72 -158 minecraft:air
fill 46 72 -158 47 72 -158 minecraft:air
setblock 53 72 -158 minecraft:air
setblock 68 72 -158 minecraft:air
fill 13 72 -157 15 72 -157 minecraft:air
setblock 17 72 -157 minecraft:air
fill 45 72 -157 47 72 -157 minecraft:air
fill 8 72 -156 10 72 -156 minecraft:air
setblock 14 72 -156 minecraft:air
fill 16 72 -156 18 72 -156 minecraft:air
setblock 21 72 -156 minecraft:air
setblock 46 72 -156 minecraft:air
fill 8 72 -155 10 72 -155 minecraft:air
fill 15 72 -155 22 72 -155 minecraft:air
setblock 39 72 -155 minecraft:air
fill 42 72 -155 44 72 -155 minecraft:air
fill 8 72 -154 10 72 -154 minecraft:air
fill 16 72 -154 17 72 -154 minecraft:air
setblock 18 72 -154 minecraft:oak_leaves[persistent=true]
fill 19 72 -154 23 72 -154 minecraft:air
fill 42 72 -154 44 72 -154 minecraft:air
setblock 52 72 -154 minecraft:air
setblock 67 72 -154 minecraft:air
setblock 17 72 -153 minecraft:air
fill 20 72 -153 23 72 -153 minecraft:air
fill 42 72 -153 44 72 -153 minecraft:air
fill 21 72 -152 23 72 -152 minecraft:air
setblock 40 72 -152 minecraft:air
fill 48 72 -152 50 72 -152 minecraft:air
fill 21 72 -151 24 72 -151 minecraft:air
setblock 32 72 -151 minecraft:air
fill 39 72 -151 41 72 -151 minecraft:air
setblock 44 72 -151 minecraft:air
fill 48 72 -151 50 72 -151 minecraft:air
fill 38 72 -150 42 72 -150 minecraft:air
fill 48 72 -150 50 72 -150 minecraft:air
fill 14 72 -149 16 72 -149 minecraft:air
fill 39 72 -149 41 72 -149 minecraft:air
fill 14 72 -148 16 72 -148 minecraft:air
setblock 40 72 -148 minecraft:air
setblock 65 72 -148 minecraft:air
setblock 12 72 -147 minecraft:air
fill 14 72 -147 16 72 -147 minecraft:air
setblock 53 72 -147 minecraft:air
setblock 55 72 -147 minecraft:air
setblock 63 72 -147 minecraft:air
setblock 15 72 -146 minecraft:air
setblock 53 72 -146 minecraft:air
setblock 58 72 -146 minecraft:air
setblock 10 72 -145 minecraft:air
fill 14 72 -145 19 72 -145 minecraft:air
setblock 38 72 -145 minecraft:air
fill 51 72 -145 52 72 -145 minecraft:air
setblock 11 72 -144 minecraft:air
fill 13 72 -144 19 72 -144 minecraft:air
setblock 29 72 -144 minecraft:air
setblock 48 72 -144 minecraft:air
setblock 57 72 -144 minecraft:air
setblock 67 72 -144 minecraft:air
setblock 11 72 -143 minecraft:air
fill 14 72 -143 20 72 -143 minecraft:air
fill 28 72 -143 30 72 -143 minecraft:air
setblock 32 72 -143 minecraft:air
setblock 50 72 -143 minecraft:air
setblock 11 72 -142 minecraft:air
setblock 15 72 -142 minecraft:air
fill 27 72 -142 33 72 -142 minecraft:air
setblock 10 72 -141 minecraft:air
fill 27 72 -141 30 72 -141 minecraft:air
setblock 32 72 -141 minecraft:air
setblock 35 72 -141 minecraft:air
setblock 11 72 -140 minecraft:air
fill 13 72 -140 14 72 -140 minecraft:air
fill 26 72 -140 27 72 -140 minecraft:air
setblock 29 72 -140 minecraft:air
setblock 64 72 -140 minecraft:air
setblock 68 72 -140 minecraft:air
setblock 27 72 -139 minecraft:air
setblock 34 72 -139 minecraft:air
setblock 53 72 -139 minecraft:air
setblock 29 72 -138 minecraft:air
fill 28 72 -137 30 72 -137 minecraft:air
setblock 38 72 -137 minecraft:air
setblock 70 72 -137 minecraft:air
setblock 14 72 -136 minecraft:air
setblock 29 72 -136 minecraft:air
fill 37 72 -136 39 72 -136 minecraft:air
setblock 64 72 -136 minecraft:air
fill 13 72 -135 15 72 -135 minecraft:air
setblock 38 72 -135 minecraft:air
setblock 47 72 -135 minecraft:air
setblock 14 72 -134 minecraft:air
setblock 16 72 -134 minecraft:air
fill 18 72 -134 20 72 -134 minecraft:air
fill 35 72 -134 37 72 -134 minecraft:air
fill 15 72 -133 20 72 -133 minecraft:air
fill 35 72 -133 37 72 -133 minecraft:air
setblock 16 72 -132 minecraft:air
fill 18 72 -132 20 72 -132 minecraft:air
fill 35 72 -132 37 72 -132 minecraft:air
setblock 64 72 -131 minecraft:air
setblock 28 72 -130 minecraft:air
setblock 56 72 -130 minecraft:air
fill 63 72 -130 65 72 -130 minecraft:air
fill 18 72 -129 20 72 -129 minecraft:air
fill 27 72 -129 29 72 -129 minecraft:air
fill 62 72 -129 66 72 -129 minecraft:air
fill 18 72 -128 20 72 -128 minecraft:air
setblock 28 72 -128 minecraft:air
setblock 35 72 -128 minecraft:air
setblock 36 72 -128 minecraft:oak_leaves[persistent=true]
fill 63 72 -128 65 72 -128 minecraft:air
fill 19 72 -127 20 72 -127 minecraft:air
fill 33 72 -127 36 72 -127 minecraft:air
setblock 38 72 -127 minecraft:air
setblock 56 72 -127 minecraft:air
setblock 64 72 -127 minecraft:air
setblock 9 73 -186 minecraft:air
setblock 8 73 -185 minecraft:air
fill 8 73 -184 9 73 -184 minecraft:air
setblock 21 73 -184 minecraft:air
fill 8 73 -183 10 73 -183 minecraft:air
fill 8 73 -182 9 73 -182 minecraft:air
setblock 8 73 -181 minecraft:air
setblock 12 73 -181 minecraft:air
setblock 19 73 -179 minecraft:air
setblock 9 73 -178 minecraft:air
setblock 16 73 -177 minecraft:air
setblock 23 73 -173 minecraft:air
setblock 18 73 -172 minecraft:air
setblock 20 73 -168 minecraft:air
setblock 9 73 -163 minecraft:air
fill 8 73 -162 10 73 -162 minecraft:air
setblock 9 73 -161 minecraft:air
setblock 19 73 -160 minecraft:air
fill 13 73 -159 15 73 -159 minecraft:air
fill 46 73 -159 52 73 -159 minecraft:air
fill 13 73 -158 15 73 -158 minecraft:air
fill 49 73 -158 51 73 -158 minecraft:air
setblock 53 73 -158 minecraft:air
setblock 68 73 -158 minecraft:air
fill 13 73 -157 15 73 -157 minecraft:air
fill 45 73 -157 47 73 -157 minecraft:air
setblock 50 73 -157 minecraft:air
setblock 9 73 -156 minecraft:air
fill 16 73 -156 18 73 -156 minecraft:air
fill 8 73 -155 10 73 -155 minecraft:air
fill 16 73 -155 18 73 -155 minecraft:air
fill 20 73 -155 22 73 -155 minecraft:air
setblock 39 73 -155 minecraft:air
setblock 43 73 -155 minecraft:air
setblock 9 73 -154 minecraft:air
fill 16 73 -154 18 73 -154 minecraft:air
fill 20 73 -154 22 73 -154 minecraft:air
fill 42 73 -154 44 73 -154 minecraft:air
setblock 52 73 -154 minecraft:air
setblock 67 73 -154 minecraft:air
fill 20 73 -153 22 73 -153 minecraft:air
fill 43 73 -153 44 73 -153 minecraft:air
fill 21 73 -152 23 73 -152 minecraft:air
fill 43 73 -152 45 73 -152 minecraft:air
setblock 49 73 -152 minecraft:air
setblock 22 73 -151 minecraft:air
setblock 24 73 -151 minecraft:air
setblock 32 73 -151 minecraft:air
fill 39 73 -151 46 73 -151 minecraft:air
fill 48 73 -151 50 73 -151 minecraft:air
fill 39 73 -150 41 73 -150 minecraft:air
fill 43 73 -150 45 73 -150 minecraft:air
setblock 49 73 -150 minecraft:air
setblock 15 73 -149 minecraft:air
fill 39 73 -149 41 73 -149 minecraft:air
setblock 44 73 -149 minecraft:air
setblock 63 73 -149 minecraft:air
fill 14 73 -148 16 73 -148 minecraft:air
fill 62 73 -148 65 73 -148 minecraft:air
setblock 12 73 -147 minecraft:air
setblock 15 73 -147 minecraft:air
setblock 38 73 -147 minecraft:air
setblock 55 73 -147 minecraft:air
fill 61 73 -147 65 73 -147 minecraft:air
fill 37 73 -146 39 73 -146 minecraft:air
setblock 48 73 -146 minecraft:air
fill 52 73 -146 53 73 -146 minecraft:air
setblock 58 73 -146 minecraft:air
fill 62 73 -146 64 73 -146 minecraft:air
setblock 10 73 -145 minecraft:air
fill 14 73 -145 16 73 -145 minecraft:air
setblock 18 73 -145 minecraft:air
setblock 20 73 -145 minecraft:air
fill 36 73 -145 40 73 -145 minecraft:air
fill 47 73 -145 51 73 -145 minecraft:air
setblock 63 73 -145 minecraft:air
fill 14 73 -144 21 73 -144 minecraft:air
fill 37 73 -144 39 73 -144 minecraft:air
fill 46 73 -144 51 73 -144 minecraft:air
setblock 57 73 -144 minecraft:air
setblock 67 73 -144 minecraft:air
fill 14 73 -143 16 73 -143 minecraft:air
fill 18 73 -143 22 73 -143 minecraft:air
fill 28 73 -143 30 73 -143 minecraft:air
setblock 38 73 -143 minecraft:air
fill 47 73 -143 52 73 -143 minecraft:air
fill 19 73 -142 21 73 -142 minecraft:air
fill 28 73 -142 30 73 -142 minecraft:air
fill 32 73 -142 33 73 -142 minecraft:air
fill 48 73 -142 51 73 -142 minecraft:air
setblock 20 73 -141 minecraft:air
fill 28 73 -141 30 73 -141 minecraft:air
setblock 32 73 -141 minecraft:air
setblock 35 73 -141 minecraft:air
setblock 50 73 -141 minecraft:air
setblock 13 73 -140 minecraft:air
setblock 64 73 -140 minecraft:air
setblock 68 73 -140 minecraft:air
setblock 53 73 -139 minecraft:air
fill 28 73 -137 29 73 -137 minecraft:air
setblock 70 73 -137 minecraft:air
setblock 29 73 -136 minecraft:air
setblock 38 73 -136 minecraft:air
setblock 64 73 -136 minecraft:air
fill 13 73 -135 15 73 -135 minecraft:air
setblock 38 73 -135 minecraft:air
setblock 47 73 -135 minecraft:air
setblock 14 73 -134 minecraft:air
setblock 19 73 -134 minecraft:air
setblock 36 73 -134 minecraft:air
fill 15 73 -133 16 73 -133 minecraft:air
fill 18 73 -133 20 73 -133 minecraft:air
fill 35 73 -133 37 73 -133 minecraft:air
setblock 16 73 -132 minecraft:air
setblock 19 73 -132 minecraft:air
setblock 36 73 -132 minecraft:air
setblock 56 73 -132 minecraft:air
fill 55 73 -131 57 73 -131 minecraft:air
setblock 28 73 -130 minecraft:air
fill 54 73 -130 58 73 -130 minecraft:air
fill 63 73 -130 65 73 -130 minecraft:air
setblock 19 73 -129 minecraft:air
setblock 28 73 -129 minecraft:air
fill 55 73 -129 57 73 -129 minecraft:air
fill 63 73 -129 65 73 -129 minecraft:air
fill 18 73 -128 20 73 -128 minecraft:air
setblock 56 73 -128 minecraft:air
fill 63 73 -128 65 73 -128 minecraft:air
setblock 19 73 -127 minecraft:air
fill 33 73 -127 36 73 -127 minecraft:air
setblock 38 73 -127 minecraft:air
setblock 56 73 -127 minecraft:air
setblock 9 74 -186 minecraft:air
fill 8 74 -184 9 74 -184 minecraft:air
setblock 21 74 -184 minecraft:air
fill 8 74 -183 9 74 -183 minecraft:air
fill 8 74 -182 9 74 -182 minecraft:air
setblock 12 74 -181 minecraft:air
setblock 9 74 -180 minecraft:air
fill 8 74 -179 10 74 -179 minecraft:air
setblock 19 74 -179 minecraft:air
fill 8 74 -178 11 74 -178 minecraft:air
fill 8 74 -177 10 74 -177 minecraft:air
setblock 16 74 -177 minecraft:air
setblock 9 74 -176 minecraft:air
setblock 23 74 -173 minecraft:air
setblock 18 74 -172 minecraft:air
setblock 20 74 -168 minecraft:air
setblock 9 74 -163 minecraft:air
fill 8 74 -162 9 74 -162 minecraft:air
setblock 19 74 -160 minecraft:air
setblock 14 74 -159 minecraft:air
setblock 47 74 -159 minecraft:air
fill 49 74 -159 51 74 -159 minecraft:air
fill 13 74 -158 15 74 -158 minecraft:air
fill 49 74 -158 51 74 -158 minecraft:air
setblock 53 74 -158 minecraft:air
setblock 68 74 -158 minecraft:air
setblock 14 74 -157 minecraft:air
setblock 17 74 -156 minecraft:air
setblock 9 74 -155 minecraft:air
fill 16 74 -155 18 74 -155 minecraft:air
setblock 21 74 -155 minecraft:air
setblock 39 74 -155 minecraft:air
setblock 9 74 -154 minecraft:air
setblock 17 74 -154 minecraft:air
fill 20 74 -154 22 74 -154 minecraft:air
fill 43 74 -154 44 74 -154 minecraft:air
setblock 52 74 -154 minecraft:air
setblock 67 74 -154 minecraft:air
fill 21 74 -153 22 74 -153 minecraft:air
setblock 24 74 -153 minecraft:air
setblock 32 74 -153 minecraft:air
setblock 43 74 -153 minecraft:air
fill 21 74 -152 25 74 -152 minecraft:air
fill 31 74 -152 33 74 -152 minecraft:air
fill 43 74 -152 45 74 -152 minecraft:air
fill 22 74 -151 26 74 -151 minecraft:air
fill 30 74 -151 34 74 -151 minecraft:air
setblock 40 74 -151 minecraft:air
fill 43 74 -151 45 74 -151 minecraft:air
fill 48 74 -151 50 74 -151 minecraft:air
fill 23 74 -150 25 74 -150 minecraft:air
fill 31 74 -150 33 74 -150 minecraft:air
fill 39 74 -150 41 74 -150 minecraft:air
fill 43 74 -150 45 74 -150 minecraft:air
setblock 49 74 -150 minecraft:air
setblock 12 74 -149 minecraft:air
setblock 15 74 -149 minecraft:air
setblock 24 74 -149 minecraft:air
setblock 32 74 -149 minecraft:air
setblock 40 74 -149 minecraft:air
fill 11 74 -148 16 74 -148 minecraft:air
fill 62 74 -148 65 74 -148 minecraft:air
fill 10 74 -147 15 74 -147 minecraft:air
setblock 55 74 -147 minecraft:air
fill 62 74 -147 64 74 -147 minecraft:air
fill 11 74 -146 13 74 -146 minecraft:air
fill 37 74 -146 39 74 -146 minecraft:air
setblock 53 74 -146 minecraft:air
fill 57 74 -146 58 74 -146 minecraft:air
fill 62 74 -146 64 74 -146 minecraft:air
setblock 10 74 -145 minecraft:air
setblock 12 74 -145 minecraft:air
setblock 15 74 -145 minecraft:air
setblock 18 74 -145 minecraft:air
fill 37 74 -145 39 74 -145 minecraft:air
fill 47 74 -145 49 74 -145 minecraft:air
setblock 51 74 -145 minecraft:air
fill 56 74 -145 58 74 -145 minecraft:air
fill 14 74 -144 21 74 -144 minecraft:air
fill 37 74 -144 39 74 -144 minecraft:air
fill 47 74 -144 51 74 -144 minecraft:air
fill 55 74 -144 59 74 -144 minecraft:air
setblock 67 74 -144 minecraft:air
setblock 15 74 -143 minecraft:air
fill 18 74 -143 21 74 -143 minecraft:air
setblock 29 74 -143 minecraft:air
setblock 35 74 -143 minecraft:air
fill 47 74 -143 51 74 -143 minecraft:air
fill 56 74 -143 58 74 -143 minecraft:air
fill 19 74 -142 21 74 -142 minecraft:air
fill 28 74 -142 30 74 -142 minecraft:air
fill 34 74 -142 36 74 -142 minecraft:air
fill 49 74 -142 51 74 -142 minecraft:air
setblock 57 74 -142 minecraft:air
setblock 29 74 -141 minecraft:air
fill 33 74 -141 37 74 -141 minecraft:air
setblock 13 74 -140 minecraft:air
fill 34 74 -140 36 74 -140 minecraft:air
setblock 64 74 -140 minecraft:air
setblock 68 74 -140 minecraft:air
setblock 35 74 -139 minecraft:air
setblock 53 74 -139 minecraft:air
setblock 64 74 -138 minecraft:air
fill 63 74 -137 65 74 -137 minecraft:air
setblock 70 74 -137 minecraft:air
fill 62 74 -136 66 74 -136 minecraft:air
setblock 47 74 -135 minecraft:air
fill 63 74 -135 65 74 -135 minecraft:air
setblock 19 74 -134 minecraft:air
setblock 64 74 -134 minecraft:air
fill 18 74 -133 19 74 -133 minecraft:air
fill 36 74 -133 37 74 -133 minecraft:air
setblock 19 74 -132 minecraft:air
fill 55 74 -131 57 74 -131 minecraft:air
fill 55 74 -130 57 74 -130 minecraft:air
setblock 64 74 -130 minecraft:air
setblock 33 74 -129 minecraft:air
fill 55 74 -129 57 74 -129 minecraft:air
fill 63 74 -129 65 74 -129 minecraft:air
fill 19 74 -128 20 74 -128 minecraft:air
fill 32 74 -128 34 74 -128 minecraft:air
fill 55 74 -128 57 74 -128 minecraft:air
setblock 64 74 -128 minecraft:air
fill 31 74 -127 35 74 -127 minecraft:air
setblock 38 74 -127 minecraft:air
fill 54 74 -127 58 74 -127 minecraft:air
setblock 17 75 -190 minecraft:air
setblock 9 75 -186 minecraft:air
setblock 8 75 -184 minecraft:air
setblock 21 75 -184 minecraft:air
fill 8 75 -183 9 75 -183 minecraft:air
setblock 8 75 -182 minecraft:air
setblock 12 75 -181 minecraft:air
fill 8 75 -179 10 75 -179 minecraft:air
setblock 19 75 -179 minecraft:air
fill 8 75 -178 10 75 -178 minecraft:air
fill 8 75 -177 10 75 -177 minecraft:air
setblock 16 75 -177 minecraft:air
setblock 23 75 -173 minecraft:air
setblock 18 75 -172 minecraft:air
setblock 20 75 -168 minecraft:air
setblock 19 75 -160 minecraft:air
fill 49 75 -159 51 75 -159 minecraft:air
fill 14 75 -158 15 75 -158 minecraft:air
setblock 50 75 -158 minecraft:air
setblock 53 75 -158 minecraft:air
setblock 68 75 -158 minecraft:air
setblock 14 75 -157 minecraft:air
setblock 39 75 -157 minecraft:air
fill 38 75 -156 40 75 -156 minecraft:air
setblock 52 75 -156 minecraft:air
setblock 17 75 -155 minecraft:air
setblock 21 75 -155 minecraft:air
fill 37 75 -155 41 75 -155 minecraft:air
fill 51 75 -155 53 75 -155 minecraft:air
fill 21 75 -154 22 75 -154 minecraft:air
fill 38 75 -154 40 75 -154 minecraft:air
fill 50 75 -154 54 75 -154 minecraft:air
setblock 67 75 -154 minecraft:air
setblock 21 75 -153 minecraft:air
setblock 39 75 -153 minecraft:air
fill 51 75 -153 53 75 -153 minecraft:air
fill 23 75 -152 25 75 -152 minecraft:air
fill 31 75 -152 33 75 -152 minecraft:air
setblock 44 75 -152 minecraft:air
setblock 52 75 -152 minecraft:air
fill 23 75 -151 25 75 -151 minecraft:air
fill 31 75 -151 33 75 -151 minecraft:air
fill 43 75 -151 45 75 -151 minecraft:air
fill 23 75 -150 25 75 -150 minecraft:air
fill 31 75 -150 33 75 -150 minecraft:air
fill 39 75 -150 40 75 -150 minecraft:air
setblock 44 75 -150 minecraft:air
setblock 40 75 -149 minecraft:air
fill 11 75 -148 13 75 -148 minecraft:air
setblock 63 75 -148 minecraft:air
setblock 65 75 -148 minecraft:air
fill 10 75 -147 13 75 -147 minecraft:air
setblock 51 75 -147 minecraft:air
fill 54 75 -147 55 75 -147 minecraft:air
fill 62 75 -147 64 75 -147 minecraft:air
fill 9 75 -146 13 75 -146 minecraft:air
setblock 38 75 -146 minecraft:air
fill 50 75 -146 53 75 -146 minecraft:air
setblock 58 75 -146 minecraft:air
setblock 63 75 -146 minecraft:air
fill 9 75 -145 12 75 -145 minecraft:air
fill 37 75 -145 39 75 -145 minecraft:air
fill 48 75 -145 53 75 -145 minecraft:air
fill 56 75 -145 58 75 -145 minecraft:air
fill 9 75 -144 11 75 -144 minecraft:air
fill 14 75 -144 16 75 -144 minecraft:air
setblock 20 75 -144 minecraft:air
setblock 38 75 -144 minecraft:air
fill 47 75 -144 52 75 -144 minecraft:air
fill 56 75 -144 58 75 -144 minecraft:air
setblock 67 75 -144 minecraft:air
setblock 10 75 -143 minecraft:air
fill 19 75 -143 21 75 -143 minecraft:air
setblock 29 75 -143 minecraft:air
fill 48 75 -143 51 75 -143 minecraft:air
fill 56 75 -143 58 75 -143 minecraft:air
setblock 13 75 -142 minecraft:air
setblock 20 75 -142 minecraft:air
fill 28 75 -142 30 75 -142 minecraft:air
fill 34 75 -142 36 75 -142 minecraft:air
setblock 50 75 -142 minecraft:air
setblock 68 75 -142 minecraft:air
fill 12 75 -141 14 75 -141 minecraft:air
setblock 29 75 -141 minecraft:air
fill 34 75 -141 36 75 -141 minecraft:air
setblock 53 75 -141 minecraft:air
fill 67 75 -141 69 75 -141 minecraft:air
fill 11 75 -140 15 75 -140 minecraft:air
fill 34 75 -140 36 75 -140 minecraft:air
fill 52 75 -140 54 75 -140 minecraft:air
setblock 64 75 -140 minecraft:air
fill 66 75 -140 70 75 -140 minecraft:air
fill 12 75 -139 14 75 -139 minecraft:air
fill 51 75 -139 55 75 -139 minecraft:air
fill 67 75 -139 69 75 -139 minecraft:air
setblock 13 75 -138 minecraft:air
fill 52 75 -138 54 75 -138 minecraft:air
setblock 68 75 -138 minecraft:air
setblock 47 75 -137 minecraft:air
setblock 53 75 -137 minecraft:air
fill 63 75 -137 65 75 -137 minecraft:air
setblock 70 75 -137 minecraft:air
fill 46 75 -136 48 75 -136 minecraft:air
fill 63 75 -136 65 75 -136 minecraft:air
fill 45 75 -135 49 75 -135 minecraft:air
fill 63 75 -135 65 75 -135 minecraft:air
fill 46 75 -134 48 75 -134 minecraft:air
setblock 47 75 -133 minecraft:air
setblock 56 75 -131 minecraft:air
fill 55 75 -130 57 75 -130 minecraft:air
setblock 64 75 -130 minecraft:air
setblock 56 75 -129 minecraft:air
setblock 64 75 -129 minecraft:air
fill 32 75 -128 34 75 -128 minecraft:air
fill 55 75 -128 57 75 -128 minecraft:air
setblock 64 75 -128 minecraft:air
fill 32 75 -127 35 75 -127 minecraft:air
setblock 38 75 -127 minecraft:air
fill 55 75 -127 57 75 -127 minecraft:air
setblock 9 76 -188 minecraft:air
fill 8 76 -187 10 76 -187 minecraft:air
fill 8 76 -186 11 76 -186 minecraft:air
fill 8 76 -185 10 76 -185 minecraft:air
setblock 9 76 -184 minecraft:air
setblock 21 76 -184 minecraft:air
fill 8 76 -183 9 76 -183 minecraft:air
setblock 12 76 -183 minecraft:air
setblock 8 76 -182 minecraft:air
fill 11 76 -182 13 76 -182 minecraft:air
fill 10 76 -181 14 76 -181 minecraft:air
fill 11 76 -180 13 76 -180 minecraft:air
setblock 9 76 -179 minecraft:air
setblock 12 76 -179 minecraft:air
setblock 19 76 -179 minecraft:air
fill 8 76 -178 10 76 -178 minecraft:air
setblock 9 76 -177 minecraft:air
setblock 16 76 -177 minecraft:air
setblock 23 76 -175 minecraft:air
setblock 18 76 -174 minecraft:air
fill 22 76 -174 24 76 -174 minecraft:air
fill 17 76 -173 19 76 -173 minecraft:air
fill 21 76 -173 25 76 -173 minecraft:air
fill 16 76 -172 20 76 -172 minecraft:air
fill 22 76 -172 24 76 -172 minecraft:air
fill 17 76 -171 19 76 -171 minecraft:air
setblock 23 76 -171 minecraft:air
setblock 18 76 -170 minecraft:air
setblock 20 76 -168 minecraft:air
setblock 19 76 -162 minecraft:air
fill 18 76 -161 20 76 -161 minecraft:air
fill 17 76 -160 21 76 -160 minecraft:air
fill 18 76 -159 20 76 -159 minecraft:air
fill 50 76 -159 54 76 -159 minecraft:air
fill 67 76 -159 69 76 -159 minecraft:air
setblock 19 76 -158 minecraft:air
fill 51 76 -158 55 76 -158 minecraft:air
fill 66 76 -158 70 76 -158 minecraft:air
fill 52 76 -157 54 76 -157 minecraft:air
fill 67 76 -157 69 76 -157 minecraft:air
fill 38 76 -156 40 76 -156 minecraft:air
setblock 53 76 -156 minecraft:air
fill 67 76 -156 68 76 -156 minecraft:air
fill 38 76 -155 40 76 -155 minecraft:air
fill 51 76 -155 53 76 -155 minecraft:air
fill 66 76 -155 68 76 -155 minecraft:air
fill 38 76 -154 40 76 -154 minecraft:air
fill 51 76 -154 53 76 -154 minecraft:air
fill 65 76 -154 69 76 -154 minecraft:air
fill 51 76 -153 53 76 -153 minecraft:air
fill 66 76 -153 68 76 -153 minecraft:air
setblock 24 76 -152 minecraft:air
setblock 32 76 -152 minecraft:air
setblock 44 76 -152 minecraft:air
setblock 67 76 -152 minecraft:air
fill 23 76 -151 25 76 -151 minecraft:air
fill 31 76 -151 33 76 -151 minecraft:air
fill 43 76 -151 45 76 -151 minecraft:air
setblock 24 76 -150 minecraft:air
setblock 32 76 -150 minecraft:air
setblock 44 76 -150 minecraft:air
setblock 65 76 -150 minecraft:air
fill 64 76 -149 66 76 -149 minecraft:air
setblock 12 76 -148 minecraft:air
setblock 53 76 -148 minecraft:air
fill 63 76 -148 67 76 -148 minecraft:air
fill 11 76 -147 13 76 -147 minecraft:air
fill 52 76 -147 55 76 -147 minecraft:air
fill 62 76 -147 66 76 -147 minecraft:air
fill 9 76 -146 12 76 -146 minecraft:air
fill 50 76 -146 55 76 -146 minecraft:air
setblock 58 76 -146 minecraft:air
setblock 65 76 -146 minecraft:air
fill 9 76 -145 11 76 -145 minecraft:air
setblock 38 76 -145 minecraft:air
setblock 48 76 -145 minecraft:air
fill 50 76 -145 54 76 -145 minecraft:air
setblock 57 76 -145 minecraft:air
fill 9 76 -144 11 76 -144 minecraft:air
setblock 38 76 -144 minecraft:air
setblock 48 76 -144 minecraft:air
fill 50 76 -144 53 76 -144 minecraft:air
fill 56 76 -144 58 76 -144 minecraft:air
setblock 67 76 -144 minecraft:air
fill 19 76 -143 20 76 -143 minecraft:air
fill 50 76 -143 51 76 -143 minecraft:air
setblock 57 76 -143 minecraft:air
setblock 35 76 -142 minecraft:air
setblock 64 76 -142 minecraft:air
fill 12 76 -141 14 76 -141 minecraft:air
fill 34 76 -141 36 76 -141 minecraft:air
fill 63 76 -141 65 76 -141 minecraft:air
fill 67 76 -141 69 76 -141 minecraft:air
fill 12 76 -140 14 76 -140 minecraft:air
setblock 35 76 -140 minecraft:air
fill 52 76 -140 54 76 -140 minecraft:air
fill 62 76 -140 69 76 -140 minecraft:air
fill 12 76 -139 14 76 -139 minecraft:air
fill 52 76 -139 54 76 -139 minecraft:air
fill 63 76 -139 65 76 -139 minecraft:air
fill 67 76 -139 69 76 -139 minecraft:air
fill 52 76 -138 54 76 -138 minecraft:air
setblock 64 76 -138 minecraft:air
setblock 64 76 -137 minecraft:air
setblock 70 76 -137 minecraft:air
fill 46 76 -136 48 76 -136 minecraft:air
fill 63 76 -136 65 76 -136 minecraft:air
fill 46 76 -135 48 76 -135 minecraft:air
setblock 64 76 -135 minecraft:air
fill 46 76 -134 48 76 -134 minecraft:air
fill 55 76 -130 56 76 -130 minecraft:air
setblock 38 76 -129 minecraft:air
setblock 33 76 -128 minecraft:air
fill 37 76 -128 39 76 -128 minecraft:air
setblock 56 76 -128 minecraft:air
fill 32 76 -127 34 76 -127 minecraft:air
fill 36 76 -127 40 76 -127 minecraft:air
fill 55 76 -127 57 76 -127 minecraft:air
fill 8 77 -187 10 77 -187 minecraft:air
fill 8 77 -186 10 77 -186 minecraft:air
fill 8 77 -185 10 77 -185 minecraft:air
setblock 21 77 -184 minecraft:air
fill 11 77 -182 13 77 -182 minecraft:air
fill 11 77 -181 13 77 -181 minecraft:air
fill 11 77 -180 13 77 -180 minecraft:air
setblock 9 77 -179 minecraft:air
setblock 19 77 -179 minecraft:air
setblock 9 77 -178 minecraft:air
setblock 9 77 -177 minecraft:air
setblock 16 77 -177 minecraft:air
fill 22 77 -174 24 77 -174 minecraft:air
fill 17 77 -173 19 77 -173 minecraft:air
fill 22 77 -173 24 77 -173 minecraft:air
fill 17 77 -172 19 77 -172 minecraft:air
fill 22 77 -172 24 77 -172 minecraft:air
fill 17 77 -171 19 77 -171 minecraft:air
setblock 20 77 -170 minecraft:air
fill 19 77 -169 21 77 -169 minecraft:air
fill 18 77 -168 22 77 -168 minecraft:air
fill 19 77 -167 21 77 -167 minecraft:air
setblock 20 77 -166 minecraft:air
fill 59 77 -163 60 77 -163 minecraft:air
fill 58 77 -162 60 77 -162 minecraft:air
setblock 62 77 -162 minecraft:air
setblock 66 77 -162 minecraft:air
fill 18 77 -161 20 77 -161 minecraft:air
fill 58 77 -161 63 77 -161 minecraft:air
fill 65 77 -161 67 77 -161 minecraft:air
fill 18 77 -160 20 77 -160 minecraft:air
fill 60 77 -160 68 77 -160 minecraft:air
fill 18 77 -159 20 77 -159 minecraft:air
fill 52 77 -159 54 77 -159 minecraft:air
fill 61 77 -159 63 77 -159 minecraft:air
fill 65 77 -159 69 77 -159 minecraft:air
fill 52 77 -158 54 77 -158 minecraft:air
setblock 62 77 -158 minecraft:air
fill 66 77 -158 69 77 -158 minecraft:air
fill 52 77 -157 54 77 -157 minecraft:air
fill 67 77 -157 69 77 -157 minecraft:air
setblock 39 77 -156 minecraft:air
fill 38 77 -155 40 77 -155 minecraft:air
setblock 52 77 -155 minecraft:air
fill 66 77 -155 68 77 -155 minecraft:air
setblock 39 77 -154 minecraft:air
fill 51 77 -154 53 77 -154 minecraft:air
fill 66 77 -154 68 77 -154 minecraft:air
setblock 52 77 -153 minecraft:air
fill 66 77 -153 68 77 -153 minecraft:air
setblock 24 77 -152 minecraft:air
fill 23 77 -151 24 77 -151 minecraft:air
setblock 32 77 -151 minecraft:air
fill 64 77 -149 66 77 -149 minecraft:air
setblock 58 77 -148 minecraft:air
fill 64 77 -148 66 77 -148 minecraft:air
fill 11 77 -147 12 77 -147 minecraft:air
fill 52 77 -147 55 77 -147 minecraft:air
fill 57 77 -147 59 77 -147 minecraft:air
fill 64 77 -147 66 77 -147 minecraft:air
setblock 10 77 -146 minecraft:air
setblock 12 77 -146 minecraft:air
fill 51 77 -146 54 77 -146 minecraft:air
fill 56 77 -146 60 77 -146 minecraft:air
fill 9 77 -145 11 77 -145 minecraft:air
fill 50 77 -145 54 77 -145 minecraft:air
fill 57 77 -145 59 77 -145 minecraft:air
setblock 10 77 -144 minecraft:air
setblock 51 77 -144 minecraft:air
fill 57 77 -144 58 77 -144 minecraft:air
setblock 67 77 -144 minecraft:air
setblock 13 77 -141 minecraft:air
fill 35 77 -141 36 77 -141 minecraft:air
fill 63 77 -141 65 77 -141 minecraft:air
setblock 68 77 -141 minecraft:air
fill 12 77 -140 14 77 -140 minecraft:air
setblock 35 77 -140 minecraft:air
setblock 53 77 -140 minecraft:air
fill 63 77 -140 65 77 -140 minecraft:air
fill 67 77 -140 69 77 -140 minecraft:air
setblock 13 77 -139 minecraft:air
fill 52 77 -139 54 77 -139 minecraft:air
fill 63 77 -139 65 77 -139 minecraft:air
setblock 68 77 -139 minecraft:air
setblock 53 77 -138 minecraft:air
setblock 64 77 -137 minecraft:air
setblock 70 77 -137 minecraft:air
setblock 47 77 -136 minecraft:air
setblock 64 77 -136 minecraft:air
fill 46 77 -135 48 77 -135 minecraft:air
setblock 47 77 -134 minecraft:air
fill 37 77 -128 39 77 -128 minecraft:air
setblock 54 77 -128 minecraft:air
setblock 33 77 -127 minecraft:air
fill 37 77 -127 39 77 -127 minecraft:air
fill 53 77 -127 57 77 -127 minecraft:air
setblock 9 78 -187 minecraft:air
fill 8 78 -186 10 78 -186 minecraft:air
setblock 9 78 -185 minecraft:air
setblock 21 78 -184 minecraft:air
setblock 12 78 -182 minecraft:air
fill 11 78 -181 13 78 -181 minecraft:air
setblock 12 78 -180 minecraft:air
setblock 19 78 -179 minecraft:air
setblock 16 78 -177 minecraft:air
setblock 23 78 -174 minecraft:air
setblock 18 78 -173 minecraft:air
fill 22 78 -173 24 78 -173 minecraft:air
fill 17 78 -172 19 78 -172 minecraft:air
setblock 23 78 -172 minecraft:air
setblock 18 78 -171 minecraft:air
fill 19 78 -169 21 78 -169 minecraft:air
fill 19 78 -168 21 78 -168 minecraft:air
fill 19 78 -167 21 78 -167 minecraft:air
fill 59 78 -162 60 78 -162 minecraft:air
setblock 19 78 -161 minecraft:air
setblock 59 78 -161 minecraft:air
fill 61 78 -161 63 78 -161 minecraft:air
fill 65 78 -161 67 78 -161 minecraft:air
fill 18 78 -160 20 78 -160 minecraft:air
fill 61 78 -160 63 78 -160 minecraft:air
fill 65 78 -160 67 78 -160 minecraft:air
setblock 19 78 -159 minecraft:air
setblock 53 78 -159 minecraft:air
fill 61 78 -159 63 78 -159 minecraft:air
fill 65 78 -159 68 78 -159 minecraft:air
fill 52 78 -158 54 78 -158 minecraft:air
fill 67 78 -158 69 78 -158 minecraft:air
setblock 53 78 -157 minecraft:air
setblock 68 78 -157 minecraft:air
fill 39 78 -155 40 78 -155 minecraft:air
setblock 52 78 -155 minecraft:air
setblock 67 78 -155 minecraft:air
setblock 39 78 -154 minecraft:air
fill 52 78 -154 53 78 -154 minecraft:air
fill 66 78 -154 68 78 -154 minecraft:air
setblock 52 78 -153 minecraft:air
setblock 67 78 -153 minecraft:air
setblock 55 78 -149 minecraft:air
setblock 65 78 -149 minecraft:air
fill 54 78 -148 56 78 -148 minecraft:air
fill 64 78 -148 66 78 -148 minecraft:air
fill 53 78 -147 59 78 -147 minecraft:air
setblock 65 78 -147 minecraft:air
setblock 71 78 -147 minecraft:air
setblock 10 78 -146 minecraft:air
fill 51 78 -146 59 78 -146 minecraft:air
fill 70 78 -146 71 78 -146 minecraft:air
setblock 10 78 -145 minecraft:air
setblock 51 78 -145 minecraft:air
setblock 53 78 -145 minecraft:air
setblock 55 78 -145 minecraft:air
fill 57 78 -145 59 78 -145 minecraft:air
setblock 71 78 -145 minecraft:air
setblock 10 78 -144 minecraft:air
setblock 67 78 -144 minecraft:air
setblock 64 78 -141 minecraft:air
setblock 68 78 -141 minecraft:air
fill 12 78 -140 13 78 -140 minecraft:air
fill 63 78 -140 65 78 -140 minecraft:air
fill 67 78 -140 69 78 -140 minecraft:air
setblock 13 78 -139 minecraft:air
setblock 53 78 -139 minecraft:air
setblock 64 78 -139 minecraft:air
setblock 70 78 -139 minecraft:air
setblock 53 78 -138 minecraft:air
fill 69 78 -138 71 78 -138 minecraft:air
fill 68 78 -137 71 78 -137 minecraft:air
fill 69 78 -136 71 78 -136 minecraft:air
fill 46 78 -135 48 78 -135 minecraft:air
setblock 70 78 -135 minecraft:air
setblock 38 78 -128 minecraft:air
fill 37 78 -127 39 78 -127 minecraft:air
fill 53 78 -127 55 78 -127 minecraft:air
setblock 9 79 -187 minecraft:air
setblock 9 79 -186 minecraft:air
setblock 21 79 -184 minecraft:air
fill 11 79 -181 13 79 -181 minecraft:air
setblock 19 79 -181 minecraft:air
fill 18 79 -180 20 79 -180 minecraft:air
fill 17 79 -179 21 79 -179 minecraft:air
fill 18 79 -178 20 79 -178 minecraft:air
setblock 16 79 -177 minecraft:air
setblock 19 79 -177 minecraft:air
setblock 23 79 -174 minecraft:air
setblock 18 79 -173 minecraft:air
fill 22 79 -173 23 79 -173 minecraft:air
fill 18 79 -172 19 79 -172 minecraft:air
setblock 20 79 -169 minecraft:air
fill 19 79 -168 21 79 -168 minecraft:air
setblock 20 79 -167 minecraft:air
setblock 62 79 -161 minecraft:air
setblock 66 79 -161 minecraft:air
fill 19 79 -160 20 79 -160 minecraft:air
fill 61 79 -160 63 79 -160 minecraft:air
fill 65 79 -160 67 79 -160 minecraft:air
setblock 19 79 -159 minecraft:air
setblock 53 79 -159 minecraft:air
setblock 62 79 -159 minecraft:air
setblock 66 79 -159 minecraft:air
setblock 53 79 -158 minecraft:air
fill 67 79 -158 69 79 -158 minecraft:air
setblock 67 79 -155 minecraft:air
fill 66 79 -154 67 79 -154 minecraft:air
setblock 67 79 -153 minecraft:air
fill 54 79 -148 56 79 -148 minecraft:air
fill 64 79 -148 65 79 -148 minecraft:air
fill 53 79 -147 56 79 -147 minecraft:air
setblock 58 79 -147 minecraft:air
setblock 71 79 -147 minecraft:air
fill 53 79 -146 59 79 -146 minecraft:air
setblock 67 79 -146 minecraft:air
setblock 71 79 -146 minecraft:air
setblock 53 79 -145 minecraft:air
setblock 58 79 -145 minecraft:air
fill 66 79 -145 68 79 -145 minecraft:air
setblock 71 79 -145 minecraft:air
fill 65 79 -144 69 79 -144 minecraft:air
fill 66 79 -143 68 79 -143 minecraft:air
setblock 67 79 -142 minecraft:air
setblock 64 79 -140 minecraft:air
fill 69 79 -138 71 79 -138 minecraft:air
fill 69 79 -137 71 79 -137 minecraft:air
fill 69 79 -136 71 79 -136 minecraft:air
fill 38 79 -127 39 79 -127 minecraft:air
setblock 54 79 -127 minecraft:air
setblock 53 80 -190 minecraft:sea_lantern
setblock 53 80 -189 minecraft:sea_lantern
setblock 53 80 -188 minecraft:sea_lantern
setblock 53 80 -187 minecraft:sea_lantern
setblock 53 80 -186 minecraft:sea_lantern
setblock 53 80 -185 minecraft:sea_lantern
fill 70 80 -185 71 80 -185 minecraft:sea_lantern
setblock 21 80 -184 minecraft:air
setblock 52 80 -184 minecraft:sea_lantern
fill 67 80 -184 69 80 -184 minecraft:sea_lantern
setblock 52 80 -183 minecraft:sea_lantern
fill 63 80 -183 66 80 -183 minecraft:sea_lantern
setblock 52 80 -182 minecraft:sea_lantern
fill 59 80 -182 62 80 -182 minecraft:sea_lantern
setblock 52 80 -181 minecraft:sea_lantern
fill 55 80 -181 58 80 -181 minecraft:sea_lantern
fill 18 80 -180 20 80 -180 minecraft:air
fill 52 80 -180 54 80 -180 minecraft:sea_lantern
fill 18 80 -179 20 80 -179 minecraft:air
fill 18 80 -178 20 80 -178 minecraft:air
setblock 16 80 -177 minecraft:air
setblock 8 80 -174 minecraft:air
fill 19 80 -168 21 80 -168 minecraft:air
setblock 62 80 -161 minecraft:air
setblock 66 80 -161 minecraft:air
setblock 62 80 -160 minecraft:air
fill 66 80 -160 67 80 -160 minecraft:air
setblock 66 80 -159 minecraft:air
setblock 55 80 -148 minecraft:air
fill 54 80 -147 56 80 -147 minecraft:air
setblock 55 80 -146 minecraft:air
fill 57 80 -146 59 80 -146 minecraft:air
setblock 71 80 -146 minecraft:air
fill 66 80 -145 68 80 -145 minecraft:air
fill 66 80 -144 68 80 -144 minecraft:air
fill 66 80 -143 68 80 -143 minecraft:air
setblock 70 80 -138 minecraft:air
fill 69 80 -137 71 80 -137 minecraft:air
setblock 70 80 -136 minecraft:air
setblock 53 81 -190 minecraft:purple_stained_glass
setblock 53 81 -189 minecraft:purple_stained_glass
setblock 53 81 -188 minecraft:purple_stained_glass
setblock 53 81 -187 minecraft:purple_stained_glass
setblock 53 81 -186 minecraft:purple_stained_glass
setblock 53 81 -185 minecraft:purple_stained_glass
fill 70 81 -185 71 81 -185 minecraft:purple_stained_glass
setblock 21 81 -184 minecraft:air
setblock 52 81 -184 minecraft:purple_stained_glass
fill 67 81 -184 69 81 -184 minecraft:purple_stained_glass
setblock 52 81 -183 minecraft:purple_stained_glass
fill 63 81 -183 66 81 -183 minecraft:purple_stained_glass
setblock 52 81 -182 minecraft:purple_stained_glass
fill 59 81 -182 62 81 -182 minecraft:purple_stained_glass
setblock 52 81 -181 minecraft:purple_stained_glass
fill 55 81 -181 58 81 -181 minecraft:purple_stained_glass
setblock 19 81 -180 minecraft:air
fill 52 81 -180 54 81 -180 minecraft:purple_stained_glass
setblock 16 81 -179 minecraft:air
fill 18 81 -179 20 81 -179 minecraft:air
fill 15 81 -178 17 81 -178 minecraft:air
setblock 19 81 -178 minecraft:air
fill 14 81 -177 18 81 -177 minecraft:air
fill 15 81 -176 17 81 -176 minecraft:air
setblock 16 81 -175 minecraft:air
setblock 55 81 -148 minecraft:air
fill 55 81 -147 56 81 -147 minecraft:air
setblock 71 81 -146 minecraft:air
setblock 67 81 -145 minecraft:air
fill 66 81 -144 68 81 -144 minecraft:air
setblock 67 81 -143 minecraft:air
fill 70 81 -137 71 81 -137 minecraft:air
setblock 70 81 -136 minecraft:air
fill 16 82 -190 18 82 -190 minecraft:air
setblock 17 82 -189 minecraft:air
setblock 21 82 -186 minecraft:air
fill 20 82 -185 22 82 -185 minecraft:air
fill 19 82 -184 23 82 -184 minecraft:air
fill 20 82 -183 22 82 -183 minecraft:air
setblock 21 82 -182 minecraft:air
fill 18 82 -179 19 82 -179 minecraft:air
fill 15 82 -178 17 82 -178 minecraft:air
fill 15 82 -177 17 82 -177 minecraft:air
fill 15 82 -176 17 82 -176 minecraft:air
fill 66 82 -144 68 82 -144 minecraft:air
setblock 67 82 -143 minecraft:air
fill 16 83 -190 18 83 -190 minecraft:air
fill 20 83 -185 22 83 -185 minecraft:air
fill 20 83 -184 22 83 -184 minecraft:air
fill 20 83 -183 22 83 -183 minecraft:air
setblock 16 83 -178 minecraft:air
fill 15 83 -177 17 83 -177 minecraft:air
setblock 16 83 -176 minecraft:air
setblock 17 84 -190 minecraft:air
setblock 21 84 -185 minecraft:air
fill 20 84 -184 22 84 -184 minecraft:air
setblock 21 84 -183 minecraft:air
setblock 16 84 -178 minecraft:air
fill 16 84 -177 17 84 -177 minecraft:air
setblock 17 85 -190 minecraft:air
fill 20 85 -184 22 85 -184 minecraft:air
setblock 21 85 -183 minecraft:air
forceload remove 8 -190 71 -127
tellraw @a {"text":"Campus bau a29 fertig.","color":"green"}
