# Abschnitt a39: x 200..263, z -126..-63 (4836 Blöcke)
forceload add 200 -126 263 -63
tellraw @a {"text":"Campus bau a39: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a39_1 2s
