fill 143 45 -126 150 45 -126 minecraft:stone
fill 194 45 -126 199 45 -126 minecraft:stone
fill 147 45 -125 150 45 -125 minecraft:stone
fill 193 45 -125 199 45 -125 minecraft:stone
fill 189 45 -124 190 45 -124 minecraft:stone
fill 193 45 -124 199 45 -124 minecraft:stone
fill 189 45 -123 190 45 -123 minecraft:stone
fill 193 45 -123 199 45 -123 minecraft:stone
fill 188 45 -122 190 45 -122 minecraft:stone
fill 193 45 -122 199 45 -122 minecraft:stone
fill 187 45 -121 190 45 -121 minecraft:stone
fill 193 45 -121 199 45 -121 minecraft:stone
fill 185 45 -120 190 45 -120 minecraft:stone
fill 193 45 -120 199 45 -120 minecraft:stone
fill 186 45 -119 191 45 -119 minecraft:stone
fill 193 45 -119 199 45 -119 minecraft:stone
fill 186 45 -118 191 45 -118 minecraft:stone
fill 193 45 -118 199 45 -118 minecraft:stone
fill 188 45 -117 191 45 -117 minecraft:stone
fill 193 45 -117 199 45 -117 minecraft:stone
fill 189 45 -116 191 45 -116 minecraft:stone
fill 193 45 -116 199 45 -116 minecraft:stone
fill 144 46 -126 145 46 -126 minecraft:stone
fill 147 46 -126 161 46 -126 minecraft:stone
fill 147 46 -125 162 46 -125 minecraft:stone
fill 188 46 -125 189 46 -125 minecraft:stone
fill 198 46 -125 199 46 -125 minecraft:stone
setblock 149 46 -124 minecraft:stone
fill 158 46 -124 163 46 -124 minecraft:stone
fill 185 46 -124 189 46 -124 minecraft:stone
fill 198 46 -124 199 46 -124 minecraft:stone
fill 159 46 -123 163 46 -123 minecraft:stone
fill 184 46 -123 189 46 -123 minecraft:stone
fill 198 46 -123 199 46 -123 minecraft:stone
fill 160 46 -122 163 46 -122 minecraft:stone
fill 183 46 -122 189 46 -122 minecraft:stone
fill 197 46 -122 199 46 -122 minecraft:stone
fill 160 46 -121 163 46 -121 minecraft:stone
fill 181 46 -121 189 46 -121 minecraft:stone
fill 197 46 -121 199 46 -121 minecraft:stone
setblock 159 46 -120 minecraft:stone
fill 161 46 -120 162 46 -120 minecraft:stone
fill 180 46 -120 189 46 -120 minecraft:stone
fill 197 46 -120 199 46 -120 minecraft:stone
fill 158 46 -119 160 46 -119 minecraft:stone
fill 180 46 -119 190 46 -119 minecraft:stone
fill 196 46 -119 199 46 -119 minecraft:stone
fill 157 46 -118 160 46 -118 minecraft:stone
fill 179 46 -118 190 46 -118 minecraft:stone
fill 196 46 -118 199 46 -118 minecraft:stone
fill 157 46 -117 160 46 -117 minecraft:stone
fill 179 46 -117 190 46 -117 minecraft:stone
fill 196 46 -117 199 46 -117 minecraft:stone
setblock 158 46 -116 minecraft:stone
fill 179 46 -116 190 46 -116 minecraft:stone
fill 195 46 -116 199 46 -116 minecraft:stone
fill 147 47 -126 161 47 -126 minecraft:stone
fill 186 47 -126 188 47 -126 minecraft:stone
fill 191 47 -126 195 47 -126 minecraft:stone
fill 148 47 -125 162 47 -125 minecraft:stone
fill 184 47 -125 188 47 -125 minecraft:stone
fill 191 47 -125 194 47 -125 minecraft:stone
fill 158 47 -124 162 47 -124 minecraft:stone
fill 182 47 -124 188 47 -124 minecraft:stone
fill 191 47 -124 194 47 -124 minecraft:stone
fill 159 47 -123 163 47 -123 minecraft:stone
fill 181 47 -123 188 47 -123 minecraft:stone
fill 191 47 -123 194 47 -123 minecraft:stone
fill 160 47 -122 163 47 -122 minecraft:stone
fill 180 47 -122 188 47 -122 minecraft:stone
fill 191 47 -122 193 47 -122 minecraft:stone
fill 160 47 -121 163 47 -121 minecraft:stone
fill 178 47 -121 188 47 -121 minecraft:stone
fill 192 47 -121 193 47 -121 minecraft:stone
fill 159 47 -120 162 47 -120 minecraft:stone
fill 177 47 -120 188 47 -120 minecraft:stone
fill 192 47 -120 193 47 -120 minecraft:stone
fill 158 47 -119 160 47 -119 minecraft:stone
fill 177 47 -119 188 47 -119 minecraft:stone
setblock 192 47 -119 minecraft:stone
fill 157 47 -118 160 47 -118 minecraft:stone
fill 176 47 -118 188 47 -118 minecraft:stone
setblock 192 47 -118 minecraft:stone
fill 156 47 -117 158 47 -117 minecraft:stone
fill 176 47 -117 188 47 -117 minecraft:stone
setblock 192 47 -117 minecraft:stone
fill 156 47 -116 157 47 -116 minecraft:stone
fill 176 47 -116 189 47 -116 minecraft:stone
fill 150 48 -126 160 48 -126 minecraft:stone
fill 183 48 -126 186 48 -126 minecraft:stone
fill 190 48 -126 198 48 -126 minecraft:stone
fill 151 48 -125 155 48 -125 minecraft:stone
fill 158 48 -125 161 48 -125 minecraft:stone
fill 182 48 -125 185 48 -125 minecraft:stone
fill 190 48 -125 198 48 -125 minecraft:stone
fill 160 48 -124 161 48 -124 minecraft:stone
fill 180 48 -124 186 48 -124 minecraft:stone
fill 190 48 -124 199 48 -124 minecraft:stone
fill 161 48 -123 162 48 -123 minecraft:stone
fill 179 48 -123 187 48 -123 minecraft:stone
fill 190 48 -123 199 48 -123 minecraft:stone
fill 161 48 -122 162 48 -122 minecraft:stone
fill 178 48 -122 187 48 -122 minecraft:stone
fill 190 48 -122 198 48 -122 minecraft:stone
fill 161 48 -121 162 48 -121 minecraft:stone
fill 176 48 -121 187 48 -121 minecraft:stone
fill 190 48 -121 198 48 -121 minecraft:stone
fill 175 48 -120 187 48 -120 minecraft:stone
fill 190 48 -120 198 48 -120 minecraft:stone
fill 159 48 -119 160 48 -119 minecraft:stone
fill 175 48 -119 187 48 -119 minecraft:stone
fill 190 48 -119 197 48 -119 minecraft:stone
fill 157 48 -118 158 48 -118 minecraft:stone
setblock 160 48 -118 minecraft:stone
fill 175 48 -118 187 48 -118 minecraft:stone
fill 191 48 -118 197 48 -118 minecraft:stone
fill 157 48 -117 158 48 -117 minecraft:stone
fill 175 48 -117 187 48 -117 minecraft:stone
fill 191 48 -117 197 48 -117 minecraft:stone
fill 174 48 -116 187 48 -116 minecraft:stone
fill 191 48 -116 196 48 -116 minecraft:stone
fill 192 49 -117 193 49 -117 minecraft:stone
fill 192 49 -116 193 49 -116 minecraft:stone
fill 172 51 -120 175 51 -120 minecraft:stone
fill 172 51 -119 176 51 -119 minecraft:stone
fill 171 51 -118 177 51 -118 minecraft:stone
fill 172 51 -117 178 51 -117 minecraft:stone
fill 173 51 -116 179 51 -116 minecraft:stone
fill 173 52 -124 174 52 -124 minecraft:stone
fill 172 52 -123 175 52 -123 minecraft:stone
fill 171 52 -122 175 52 -122 minecraft:stone
fill 171 52 -121 175 52 -121 minecraft:stone
fill 171 52 -120 175 52 -120 minecraft:stone
fill 171 52 -119 176 52 -119 minecraft:stone
fill 171 52 -118 177 52 -118 minecraft:stone
fill 172 52 -117 178 52 -117 minecraft:stone
fill 172 52 -116 179 52 -116 minecraft:stone
fill 173 53 -126 177 53 -126 minecraft:stone
fill 172 53 -125 177 53 -125 minecraft:stone
fill 172 53 -124 176 53 -124 minecraft:stone
fill 171 53 -123 176 53 -123 minecraft:stone
fill 171 53 -122 176 53 -122 minecraft:stone
fill 171 53 -121 175 53 -121 minecraft:stone
fill 171 53 -120 175 53 -120 minecraft:stone
fill 171 53 -119 176 53 -119 minecraft:stone
fill 171 53 -118 177 53 -118 minecraft:stone
fill 172 53 -117 178 53 -117 minecraft:stone
fill 173 53 -116 179 53 -116 minecraft:stone
fill 172 54 -126 177 54 -126 minecraft:stone
fill 172 54 -125 177 54 -125 minecraft:stone
fill 172 54 -124 177 54 -124 minecraft:stone
fill 171 54 -123 176 54 -123 minecraft:stone
fill 171 54 -122 176 54 -122 minecraft:stone
fill 171 54 -121 175 54 -121 minecraft:stone
fill 171 54 -120 175 54 -120 minecraft:stone
fill 171 54 -119 175 54 -119 minecraft:stone
fill 172 54 -118 176 54 -118 minecraft:stone
fill 173 54 -117 177 54 -117 minecraft:stone
fill 174 54 -116 178 54 -116 minecraft:stone
fill 173 55 -126 177 55 -126 minecraft:stone
fill 172 55 -125 177 55 -125 minecraft:stone
fill 172 55 -124 177 55 -124 minecraft:stone
fill 171 55 -123 176 55 -123 minecraft:stone
fill 171 55 -122 176 55 -122 minecraft:stone
fill 171 55 -121 175 55 -121 minecraft:stone
fill 171 55 -120 175 55 -120 minecraft:stone
fill 171 55 -119 174 55 -119 minecraft:stone
fill 173 55 -118 174 55 -118 minecraft:stone
setblock 174 55 -117 minecraft:stone
fill 173 56 -126 177 56 -126 minecraft:stone
fill 173 56 -125 177 56 -125 minecraft:stone
fill 172 56 -124 176 56 -124 minecraft:stone
fill 172 56 -123 176 56 -123 minecraft:stone
fill 172 56 -122 175 56 -122 minecraft:stone
fill 172 56 -121 174 56 -121 minecraft:stone
fill 172 56 -120 174 56 -120 minecraft:stone
setblock 173 56 -119 minecraft:stone
fill 174 57 -126 176 57 -126 minecraft:stone
fill 173 57 -125 176 57 -125 minecraft:stone
fill 174 57 -124 175 57 -124 minecraft:stone
fill 173 57 -123 174 57 -123 minecraft:stone
fill 153 60 -116 155 60 -116 minecraft:stone
fill 154 61 -117 155 61 -117 minecraft:stone
fill 151 61 -116 155 61 -116 minecraft:stone
fill 151 62 -116 155 62 -116 minecraft:dirt
fill 152 63 -116 153 63 -116 minecraft:dirt
fill 155 64 -126 167 64 -126 minecraft:dirt
fill 155 64 -125 166 64 -125 minecraft:dirt
fill 156 64 -124 166 64 -124 minecraft:dirt
fill 156 64 -123 165 64 -123 minecraft:dirt
fill 158 64 -122 164 64 -122 minecraft:dirt
fill 159 64 -121 164 64 -121 minecraft:dirt
fill 191 64 -121 193 64 -121 minecraft:dirt
fill 159 64 -120 164 64 -120 minecraft:dirt
fill 186 64 -120 188 64 -120 minecraft:dirt
setblock 190 64 -120 minecraft:dirt
fill 192 64 -120 196 64 -120 minecraft:dirt
fill 198 64 -120 199 64 -120 minecraft:dirt
fill 159 64 -119 163 64 -119 minecraft:dirt
fill 185 64 -119 195 64 -119 minecraft:dirt
fill 158 64 -118 162 64 -118 minecraft:dirt
fill 184 64 -118 199 64 -118 minecraft:dirt
fill 156 64 -117 157 64 -117 minecraft:dirt
fill 159 64 -117 162 64 -117 minecraft:dirt
fill 183 64 -117 194 64 -117 minecraft:dirt
setblock 196 64 -117 minecraft:dirt
fill 198 64 -117 199 64 -117 minecraft:dirt
fill 155 64 -116 161 64 -116 minecraft:dirt
fill 183 64 -116 199 64 -116 minecraft:dirt
fill 136 65 -126 181 65 -126 minecraft:grass_block
fill 195 65 -126 199 65 -126 minecraft:grass_block
fill 136 65 -125 153 65 -125 minecraft:grass_block
fill 155 65 -125 180 65 -125 minecraft:grass_block
fill 190 65 -125 192 65 -125 minecraft:grass_block
fill 196 65 -125 199 65 -125 minecraft:grass_block
fill 136 65 -124 153 65 -124 minecraft:grass_block
fill 155 65 -124 179 65 -124 minecraft:grass_block
setblock 182 65 -124 minecraft:grass_block
fill 189 65 -124 199 65 -124 minecraft:grass_block
fill 136 65 -123 153 65 -123 minecraft:grass_block
fill 155 65 -123 178 65 -123 minecraft:grass_block
fill 187 65 -123 199 65 -123 minecraft:grass_block
fill 136 65 -122 154 65 -122 minecraft:grass_block
fill 156 65 -122 174 65 -122 minecraft:grass_block
fill 176 65 -122 177 65 -122 minecraft:grass_block
fill 184 65 -122 199 65 -122 minecraft:grass_block
fill 136 65 -121 199 65 -121 minecraft:smooth_quartz
fill 136 65 -120 137 65 -120 minecraft:light_gray_concrete
setblock 138 65 -120 minecraft:sea_lantern
fill 139 65 -120 146 65 -120 minecraft:light_gray_concrete
setblock 147 65 -120 minecraft:sea_lantern
fill 148 65 -120 155 65 -120 minecraft:light_gray_concrete
setblock 156 65 -120 minecraft:sea_lantern
fill 157 65 -120 164 65 -120 minecraft:light_gray_concrete
setblock 165 65 -120 minecraft:sea_lantern
fill 166 65 -120 173 65 -120 minecraft:light_gray_concrete
setblock 174 65 -120 minecraft:sea_lantern
fill 175 65 -120 182 65 -120 minecraft:light_gray_concrete
setblock 183 65 -120 minecraft:sea_lantern
fill 184 65 -120 191 65 -120 minecraft:light_gray_concrete
setblock 192 65 -120 minecraft:sea_lantern
fill 193 65 -120 199 65 -120 minecraft:light_gray_concrete
setblock 136 65 -119 minecraft:light_gray_concrete
setblock 137 65 -119 minecraft:sea_lantern
fill 138 65 -119 145 65 -119 minecraft:light_gray_concrete
setblock 146 65 -119 minecraft:sea_lantern
fill 147 65 -119 154 65 -119 minecraft:light_gray_concrete
setblock 155 65 -119 minecraft:sea_lantern
fill 156 65 -119 163 65 -119 minecraft:light_gray_concrete
setblock 164 65 -119 minecraft:sea_lantern
fill 165 65 -119 172 65 -119 minecraft:light_gray_concrete
setblock 173 65 -119 minecraft:sea_lantern
fill 174 65 -119 181 65 -119 minecraft:light_gray_concrete
setblock 182 65 -119 minecraft:sea_lantern
fill 183 65 -119 190 65 -119 minecraft:light_gray_concrete
setblock 191 65 -119 minecraft:sea_lantern
fill 192 65 -119 199 65 -119 minecraft:light_gray_concrete
setblock 136 65 -118 minecraft:sea_lantern
fill 137 65 -118 144 65 -118 minecraft:light_gray_concrete
setblock 145 65 -118 minecraft:sea_lantern
fill 146 65 -118 153 65 -118 minecraft:light_gray_concrete
setblock 154 65 -118 minecraft:sea_lantern
fill 155 65 -118 162 65 -118 minecraft:light_gray_concrete
setblock 163 65 -118 minecraft:sea_lantern
fill 164 65 -118 171 65 -118 minecraft:light_gray_concrete
setblock 172 65 -118 minecraft:sea_lantern
fill 173 65 -118 180 65 -118 minecraft:light_gray_concrete
setblock 181 65 -118 minecraft:sea_lantern
fill 182 65 -118 189 65 -118 minecraft:light_gray_concrete
setblock 190 65 -118 minecraft:sea_lantern
fill 191 65 -118 198 65 -118 minecraft:light_gray_concrete
setblock 199 65 -118 minecraft:sea_lantern
fill 136 65 -117 143 65 -117 minecraft:light_gray_concrete
setblock 144 65 -117 minecraft:sea_lantern
fill 145 65 -117 152 65 -117 minecraft:light_gray_concrete
setblock 153 65 -117 minecraft:sea_lantern
fill 154 65 -117 161 65 -117 minecraft:light_gray_concrete
setblock 162 65 -117 minecraft:sea_lantern
fill 163 65 -117 170 65 -117 minecraft:light_gray_concrete
setblock 171 65 -117 minecraft:sea_lantern
fill 172 65 -117 179 65 -117 minecraft:light_gray_concrete
setblock 180 65 -117 minecraft:sea_lantern
fill 181 65 -117 188 65 -117 minecraft:light_gray_concrete
setblock 189 65 -117 minecraft:sea_lantern
fill 190 65 -117 197 65 -117 minecraft:light_gray_concrete
setblock 198 65 -117 minecraft:sea_lantern
setblock 199 65 -117 minecraft:light_gray_concrete
fill 136 65 -116 199 65 -116 minecraft:light_gray_concrete
fill 136 66 -126 141 66 -126 minecraft:air
setblock 142 66 -126 minecraft:oak_log
fill 143 66 -126 151 66 -126 minecraft:air
setblock 152 66 -126 minecraft:oak_log
setblock 153 66 -126 minecraft:air
setblock 162 66 -126 minecraft:oak_log
setblock 172 66 -126 minecraft:oak_log
setblock 182 66 -126 minecraft:oak_log
setblock 192 66 -126 minecraft:oak_log
fill 195 66 -126 199 66 -126 minecraft:air
fill 136 66 -125 153 66 -125 minecraft:air
fill 196 66 -125 199 66 -125 minecraft:air
fill 136 66 -124 153 66 -124 minecraft:air
setblock 155 66 -124 minecraft:air
setblock 182 66 -124 minecraft:air
fill 197 66 -124 199 66 -124 minecraft:air
fill 136 66 -123 153 66 -123 minecraft:air
fill 136 66 -122 155 66 -122 minecraft:air
setblock 165 66 -122 minecraft:air
setblock 179 66 -122 minecraft:air
fill 136 66 -121 154 66 -121 minecraft:air
fill 136 66 -120 155 66 -120 minecraft:air
setblock 179 66 -120 minecraft:air
fill 136 66 -119 154 66 -119 minecraft:air
setblock 173 66 -119 minecraft:air
setblock 184 66 -119 minecraft:air
setblock 137 66 -118 minecraft:air
fill 139 66 -118 155 66 -118 minecraft:air
setblock 181 66 -118 minecraft:air
fill 139 66 -117 152 66 -117 minecraft:air
setblock 171 66 -117 minecraft:air
setblock 173 66 -117 minecraft:air
setblock 176 66 -117 minecraft:air
setblock 181 66 -117 minecraft:air
setblock 136 66 -116 minecraft:air
fill 139 66 -116 152 66 -116 minecraft:air
setblock 170 66 -116 minecraft:air
fill 179 66 -116 180 66 -116 minecraft:air
setblock 137 67 -126 minecraft:air
fill 139 67 -126 141 67 -126 minecraft:air
setblock 142 67 -126 minecraft:oak_log
fill 143 67 -126 151 67 -126 minecraft:air
setblock 152 67 -126 minecraft:oak_log
setblock 162 67 -126 minecraft:oak_log
setblock 172 67 -126 minecraft:oak_log
setblock 182 67 -126 minecraft:oak_log
setblock 192 67 -126 minecraft:oak_log
setblock 197 67 -126 minecraft:air
setblock 138 67 -125 minecraft:air
fill 140 67 -125 152 67 -125 minecraft:air
fill 140 67 -124 152 67 -124 minecraft:air
setblock 155 67 -124 minecraft:air
setblock 182 67 -124 minecraft:air
setblock 136 67 -123 minecraft:air
fill 139 67 -123 152 67 -123 minecraft:air
setblock 139 67 -122 minecraft:air
fill 142 67 -122 152 67 -122 minecraft:air
setblock 165 67 -122 minecraft:air
fill 140 67 -121 141 67 -121 minecraft:air
fill 143 67 -121 152 67 -121 minecraft:air
fill 143 67 -120 152 67 -120 minecraft:air
setblock 138 67 -119 minecraft:air
fill 144 67 -119 152 67 -119 minecraft:air
setblock 154 67 -119 minecraft:air
setblock 184 67 -119 minecraft:air
setblock 140 67 -118 minecraft:air
setblock 142 67 -118 minecraft:air
fill 146 67 -118 149 67 -118 minecraft:air
setblock 155 67 -118 minecraft:air
fill 139 67 -117 142 67 -117 minecraft:air
setblock 146 67 -117 minecraft:air
setblock 148 67 -117 minecraft:air
fill 141 67 -116 143 67 -116 minecraft:air
setblock 141 68 -126 minecraft:air
setblock 142 68 -126 minecraft:oak_log
setblock 143 68 -126 minecraft:air
fill 147 68 -126 148 68 -126 minecraft:air
fill 150 68 -126 151 68 -126 minecraft:air
setblock 152 68 -126 minecraft:oak_log
setblock 162 68 -126 minecraft:oak_log
setblock 172 68 -126 minecraft:oak_log
setblock 182 68 -126 minecraft:oak_log
setblock 192 68 -126 minecraft:oak_log
setblock 145 68 -125 minecraft:air
setblock 151 68 -125 minecraft:air
setblock 150 68 -124 minecraft:air
setblock 155 68 -124 minecraft:air
setblock 182 68 -124 minecraft:air
fill 144 68 -123 145 68 -123 minecraft:air
setblock 151 68 -122 minecraft:air
setblock 165 68 -122 minecraft:air
setblock 144 68 -121 minecraft:air
setblock 150 68 -121 minecraft:air
setblock 143 68 -120 minecraft:air
setblock 146 68 -120 minecraft:air
setblock 146 68 -119 minecraft:air
fill 149 68 -119 150 68 -119 minecraft:air
setblock 184 68 -119 minecraft:air
setblock 142 68 -118 minecraft:air
setblock 155 68 -118 minecraft:air
setblock 139 68 -117 minecraft:air
fill 140 69 -126 141 69 -126 minecraft:oak_leaves[persistent=true]
setblock 142 69 -126 minecraft:oak_log
fill 143 69 -126 144 69 -126 minecraft:oak_leaves[persistent=true]
fill 150 69 -126 151 69 -126 minecraft:oak_leaves[persistent=true]
setblock 152 69 -126 minecraft:oak_log
fill 153 69 -126 154 69 -126 minecraft:oak_leaves[persistent=true]
fill 160 69 -126 161 69 -126 minecraft:oak_leaves[persistent=true]
setblock 162 69 -126 minecraft:oak_log
fill 163 69 -126 164 69 -126 minecraft:oak_leaves[persistent=true]
fill 170 69 -126 171 69 -126 minecraft:oak_leaves[persistent=true]
setblock 172 69 -126 minecraft:oak_log
fill 173 69 -126 174 69 -126 minecraft:oak_leaves[persistent=true]
fill 180 69 -126 181 69 -126 minecraft:oak_leaves[persistent=true]
setblock 182 69 -126 minecraft:oak_log
fill 183 69 -126 184 69 -126 minecraft:oak_leaves[persistent=true]
fill 190 69 -126 191 69 -126 minecraft:oak_leaves[persistent=true]
setblock 192 69 -126 minecraft:oak_log
fill 193 69 -126 194 69 -126 minecraft:oak_leaves[persistent=true]
fill 141 69 -125 143 69 -125 minecraft:oak_leaves[persistent=true]
setblock 145 69 -125 minecraft:air
fill 151 69 -125 153 69 -125 minecraft:oak_leaves[persistent=true]
fill 161 69 -125 163 69 -125 minecraft:oak_leaves[persistent=true]
fill 171 69 -125 173 69 -125 minecraft:oak_leaves[persistent=true]
fill 181 69 -125 183 69 -125 minecraft:oak_leaves[persistent=true]
fill 191 69 -125 193 69 -125 minecraft:oak_leaves[persistent=true]
setblock 142 69 -124 minecraft:oak_leaves[persistent=true]
setblock 150 69 -124 minecraft:air
setblock 152 69 -124 minecraft:oak_leaves[persistent=true]
setblock 155 69 -124 minecraft:air
setblock 162 69 -124 minecraft:oak_leaves[persistent=true]
setblock 172 69 -124 minecraft:oak_leaves[persistent=true]
setblock 182 69 -124 minecraft:oak_leaves[persistent=true]
setblock 192 69 -124 minecraft:oak_leaves[persistent=true]
setblock 165 69 -123 minecraft:air
fill 164 69 -122 166 69 -122 minecraft:air
fill 182 69 -122 186 69 -122 minecraft:air
setblock 165 69 -121 minecraft:air
fill 181 69 -121 187 69 -121 minecraft:air
fill 181 69 -120 187 69 -120 minecraft:air
fill 181 69 -119 187 69 -119 minecraft:air
setblock 142 69 -118 minecraft:air
setblock 155 69 -118 minecraft:air
fill 181 69 -118 187 69 -118 minecraft:air
setblock 139 69 -117 minecraft:air
fill 181 69 -117 187 69 -117 minecraft:air
fill 182 69 -116 186 69 -116 minecraft:air
fill 140 70 -126 141 70 -126 minecraft:oak_leaves[persistent=true]
setblock 142 70 -126 minecraft:oak_log
fill 143 70 -126 144 70 -126 minecraft:oak_leaves[persistent=true]
fill 150 70 -126 151 70 -126 minecraft:oak_leaves[persistent=true]
setblock 152 70 -126 minecraft:oak_log
fill 153 70 -126 154 70 -126 minecraft:oak_leaves[persistent=true]
fill 160 70 -126 161 70 -126 minecraft:oak_leaves[persistent=true]
setblock 162 70 -126 minecraft:oak_log
fill 163 70 -126 164 70 -126 minecraft:oak_leaves[persistent=true]
fill 170 70 -126 171 70 -126 minecraft:oak_leaves[persistent=true]
setblock 172 70 -126 minecraft:oak_log
fill 173 70 -126 174 70 -126 minecraft:oak_leaves[persistent=true]
fill 180 70 -126 181 70 -126 minecraft:oak_leaves[persistent=true]
setblock 182 70 -126 minecraft:oak_log
fill 183 70 -126 184 70 -126 minecraft:oak_leaves[persistent=true]
fill 190 70 -126 191 70 -126 minecraft:oak_leaves[persistent=true]
setblock 192 70 -126 minecraft:oak_log
fill 193 70 -126 194 70 -126 minecraft:oak_leaves[persistent=true]
fill 140 70 -125 144 70 -125 minecraft:oak_leaves[persistent=true]
setblock 145 70 -125 minecraft:air
fill 150 70 -125 154 70 -125 minecraft:oak_leaves[persistent=true]
setblock 155 70 -125 minecraft:air
fill 160 70 -125 164 70 -125 minecraft:oak_leaves[persistent=true]
fill 165 70 -125 167 70 -125 minecraft:air
fill 170 70 -125 174 70 -125 minecraft:oak_leaves[persistent=true]
fill 180 70 -125 184 70 -125 minecraft:oak_leaves[persistent=true]
fill 190 70 -125 194 70 -125 minecraft:oak_leaves[persistent=true]
fill 141 70 -124 143 70 -124 minecraft:oak_leaves[persistent=true]
setblock 150 70 -124 minecraft:air
fill 151 70 -124 153 70 -124 minecraft:oak_leaves[persistent=true]
fill 154 70 -124 156 70 -124 minecraft:air
fill 161 70 -124 163 70 -124 minecraft:oak_leaves[persistent=true]
fill 164 70 -124 168 70 -124 minecraft:air
fill 171 70 -124 173 70 -124 minecraft:oak_leaves[persistent=true]
fill 181 70 -124 183 70 -124 minecraft:oak_leaves[persistent=true]
fill 191 70 -124 193 70 -124 minecraft:oak_leaves[persistent=true]
setblock 155 70 -123 minecraft:air
fill 162 70 -123 168 70 -123 minecraft:air
fill 162 70 -122 168 70 -122 minecraft:air
fill 162 70 -121 168 70 -121 minecraft:air
fill 183 70 -121 185 70 -121 minecraft:air
fill 154 70 -120 156 70 -120 minecraft:air
fill 162 70 -120 168 70 -120 minecraft:air
fill 182 70 -120 186 70 -120 minecraft:air
fill 153 70 -119 157 70 -119 minecraft:air
fill 163 70 -119 167 70 -119 minecraft:air
fill 182 70 -119 186 70 -119 minecraft:air
setblock 142 70 -118 minecraft:air
fill 153 70 -118 157 70 -118 minecraft:air
fill 182 70 -118 186 70 -118 minecraft:air
setblock 139 70 -117 minecraft:air
fill 153 70 -117 157 70 -117 minecraft:air
fill 183 70 -117 185 70 -117 minecraft:air
fill 154 70 -116 156 70 -116 minecraft:air
fill 140 71 -126 144 71 -126 minecraft:oak_leaves[persistent=true]
fill 150 71 -126 154 71 -126 minecraft:oak_leaves[persistent=true]
fill 155 71 -126 156 71 -126 minecraft:air
setblock 159 71 -126 minecraft:air
fill 160 71 -126 164 71 -126 minecraft:oak_leaves[persistent=true]
fill 170 71 -126 174 71 -126 minecraft:oak_leaves[persistent=true]
fill 180 71 -126 184 71 -126 minecraft:oak_leaves[persistent=true]
setblock 185 71 -126 minecraft:air
fill 190 71 -126 194 71 -126 minecraft:oak_leaves[persistent=true]
setblock 198 71 -126 minecraft:air
fill 141 71 -125 143 71 -125 minecraft:oak_leaves[persistent=true]
setblock 145 71 -125 minecraft:air
fill 151 71 -125 153 71 -125 minecraft:oak_leaves[persistent=true]
fill 154 71 -125 157 71 -125 minecraft:air
fill 161 71 -125 163 71 -125 minecraft:oak_leaves[persistent=true]
fill 171 71 -125 173 71 -125 minecraft:oak_leaves[persistent=true]
fill 181 71 -125 183 71 -125 minecraft:oak_leaves[persistent=true]
fill 191 71 -125 193 71 -125 minecraft:oak_leaves[persistent=true]
setblock 142 71 -124 minecraft:oak_leaves[persistent=true]
setblock 150 71 -124 minecraft:air
setblock 152 71 -124 minecraft:oak_leaves[persistent=true]
fill 153 71 -124 157 71 -124 minecraft:air
setblock 162 71 -124 minecraft:oak_leaves[persistent=true]
fill 164 71 -124 166 71 -124 minecraft:air
setblock 172 71 -124 minecraft:oak_leaves[persistent=true]
setblock 181 71 -124 minecraft:air
setblock 182 71 -124 minecraft:oak_leaves[persistent=true]
setblock 183 71 -124 minecraft:air
setblock 192 71 -124 minecraft:oak_leaves[persistent=true]
fill 153 71 -123 157 71 -123 minecraft:air
fill 163 71 -123 167 71 -123 minecraft:air
setblock 182 71 -123 minecraft:air
fill 154 71 -122 156 71 -122 minecraft:air
fill 163 71 -122 167 71 -122 minecraft:air
fill 163 71 -121 167 71 -121 minecraft:air
fill 164 71 -120 166 71 -120 minecraft:air
setblock 184 71 -120 minecraft:air
setblock 155 71 -119 minecraft:air
fill 183 71 -119 185 71 -119 minecraft:air
setblock 142 71 -118 minecraft:air
fill 154 71 -118 156 71 -118 minecraft:air
setblock 184 71 -118 minecraft:air
setblock 139 71 -117 minecraft:air
setblock 155 71 -117 minecraft:air
setblock 141 72 -126 minecraft:air
setblock 142 72 -126 minecraft:oak_leaves[persistent=true]
setblock 152 72 -126 minecraft:oak_leaves[persistent=true]
fill 159 72 -126 161 72 -126 minecraft:air
setblock 162 72 -126 minecraft:oak_leaves[persistent=true]
setblock 172 72 -126 minecraft:oak_leaves[persistent=true]
fill 179 72 -126 181 72 -126 minecraft:air
setblock 182 72 -126 minecraft:oak_leaves[persistent=true]
fill 183 72 -126 185 72 -126 minecraft:air
setblock 192 72 -126 minecraft:oak_leaves[persistent=true]
fill 196 72 -126 199 72 -126 minecraft:air
setblock 145 72 -125 minecraft:air
setblock 155 72 -125 minecraft:air
fill 179 72 -125 185 72 -125 minecraft:air
fill 196 72 -125 199 72 -125 minecraft:air
setblock 150 72 -124 minecraft:air
fill 154 72 -124 156 72 -124 minecraft:air
fill 179 72 -124 185 72 -124 minecraft:air
setblock 155 72 -123 minecraft:air
setblock 165 72 -123 minecraft:air
fill 179 72 -123 185 72 -123 minecraft:air
fill 164 72 -122 166 72 -122 minecraft:air
fill 179 72 -122 186 72 -122 minecraft:air
setblock 165 72 -121 minecraft:air
fill 180 72 -121 187 72 -121 minecraft:air
fill 141 72 -120 143 72 -120 minecraft:air
fill 154 72 -120 156 72 -120 minecraft:air
fill 181 72 -120 187 72 -120 minecraft:air
fill 139 72 -119 144 72 -119 minecraft:air
fill 153 72 -119 157 72 -119 minecraft:air
fill 181 72 -119 187 72 -119 minecraft:air
fill 138 72 -118 144 72 -118 minecraft:air
fill 153 72 -118 157 72 -118 minecraft:air
fill 181 72 -118 187 72 -118 minecraft:air
fill 137 72 -117 144 72 -117 minecraft:air
fill 153 72 -117 157 72 -117 minecraft:air
fill 181 72 -117 187 72 -117 minecraft:air
fill 138 72 -116 143 72 -116 minecraft:air
fill 154 72 -116 156 72 -116 minecraft:air
fill 182 72 -116 186 72 -116 minecraft:air
setblock 141 73 -126 minecraft:air
fill 144 73 -126 156 73 -126 minecraft:air
fill 159 73 -126 161 73 -126 minecraft:air
fill 181 73 -126 187 73 -126 minecraft:air
fill 196 73 -126 199 73 -126 minecraft:air
fill 143 73 -125 157 73 -125 minecraft:air
fill 163 73 -125 167 73 -125 minecraft:air
fill 180 73 -125 186 73 -125 minecraft:air
fill 196 73 -125 199 73 -125 minecraft:air
fill 144 73 -124 157 73 -124 minecraft:air
fill 162 73 -124 168 73 -124 minecraft:air
fill 180 73 -124 184 73 -124 minecraft:air
setblock 145 73 -123 minecraft:air
fill 147 73 -123 157 73 -123 minecraft:air
fill 162 73 -123 168 73 -123 minecraft:air
fill 180 73 -123 184 73 -123 minecraft:air
fill 147 73 -122 156 73 -122 minecraft:air
fill 162 73 -122 168 73 -122 minecraft:air
fill 181 73 -122 183 73 -122 minecraft:air
fill 148 73 -121 152 73 -121 minecraft:air
fill 162 73 -121 168 73 -121 minecraft:air
fill 183 73 -121 185 73 -121 minecraft:air
fill 162 73 -120 168 73 -120 minecraft:air
fill 182 73 -120 186 73 -120 minecraft:air
setblock 142 73 -119 minecraft:air
setblock 155 73 -119 minecraft:air
fill 163 73 -119 167 73 -119 minecraft:air
fill 182 73 -119 186 73 -119 minecraft:air
fill 138 73 -118 143 73 -118 minecraft:air
fill 154 73 -118 156 73 -118 minecraft:air
fill 182 73 -118 186 73 -118 minecraft:air
fill 138 73 -117 140 73 -117 minecraft:air
setblock 142 73 -117 minecraft:air
setblock 155 73 -117 minecraft:air
fill 183 73 -117 185 73 -117 minecraft:air
fill 138 73 -116 140 73 -116 minecraft:air
fill 139 74 -126 146 74 -126 minecraft:air
fill 149 74 -126 151 74 -126 minecraft:air
fill 183 74 -126 185 74 -126 minecraft:air
fill 197 74 -126 199 74 -126 minecraft:air
fill 140 74 -125 142 74 -125 minecraft:air
fill 144 74 -125 146 74 -125 minecraft:air
fill 148 74 -125 152 74 -125 minecraft:air
setblock 155 74 -125 minecraft:air
setblock 182 74 -125 minecraft:air
setblock 198 74 -125 minecraft:air
setblock 141 74 -124 minecraft:air
fill 144 74 -124 146 74 -124 minecraft:air
fill 148 74 -124 152 74 -124 minecraft:air
fill 154 74 -124 156 74 -124 minecraft:air
fill 164 74 -124 166 74 -124 minecraft:air
fill 181 74 -124 183 74 -124 minecraft:air
fill 148 74 -123 152 74 -123 minecraft:air
setblock 155 74 -123 minecraft:air
fill 163 74 -123 167 74 -123 minecraft:air
setblock 182 74 -123 minecraft:air
fill 149 74 -122 151 74 -122 minecraft:air
fill 163 74 -122 167 74 -122 minecraft:air
fill 163 74 -121 167 74 -121 minecraft:air
fill 141 74 -120 143 74 -120 minecraft:air
fill 154 74 -120 156 74 -120 minecraft:air
fill 164 74 -120 166 74 -120 minecraft:air
setblock 184 74 -120 minecraft:air
fill 140 74 -119 144 74 -119 minecraft:air
fill 153 74 -119 157 74 -119 minecraft:air
fill 183 74 -119 185 74 -119 minecraft:air
fill 139 74 -118 144 74 -118 minecraft:air
fill 153 74 -118 157 74 -118 minecraft:air
setblock 184 74 -118 minecraft:air
fill 138 74 -117 144 74 -117 minecraft:air
fill 153 74 -117 157 74 -117 minecraft:air
setblock 139 74 -116 minecraft:air
fill 141 74 -116 143 74 -116 minecraft:air
fill 154 74 -116 156 74 -116 minecraft:air
fill 140 75 -126 142 75 -126 minecraft:air
setblock 145 75 -126 minecraft:air
fill 154 75 -126 156 75 -126 minecraft:air
fill 179 75 -126 185 75 -126 minecraft:air
setblock 198 75 -126 minecraft:air
fill 140 75 -125 142 75 -125 minecraft:air
fill 144 75 -125 146 75 -125 minecraft:air
setblock 150 75 -125 minecraft:air
fill 153 75 -125 157 75 -125 minecraft:air
fill 179 75 -125 185 75 -125 minecraft:air
setblock 145 75 -124 minecraft:air
fill 149 75 -124 151 75 -124 minecraft:air
fill 153 75 -124 157 75 -124 minecraft:air
fill 179 75 -124 185 75 -124 minecraft:air
setblock 150 75 -123 minecraft:air
fill 153 75 -123 157 75 -123 minecraft:air
setblock 165 75 -123 minecraft:air
fill 179 75 -123 185 75 -123 minecraft:air
fill 154 75 -122 156 75 -122 minecraft:air
fill 164 75 -122 166 75 -122 minecraft:air
fill 179 75 -122 185 75 -122 minecraft:air
setblock 165 75 -121 minecraft:air
fill 180 75 -121 185 75 -121 minecraft:air
fill 182 75 -120 186 75 -120 minecraft:air
setblock 142 75 -119 minecraft:air
setblock 155 75 -119 minecraft:air
fill 182 75 -119 186 75 -119 minecraft:air
setblock 139 75 -118 minecraft:air
fill 141 75 -118 143 75 -118 minecraft:air
fill 154 75 -118 156 75 -118 minecraft:air
fill 182 75 -118 186 75 -118 minecraft:air
fill 138 75 -117 139 75 -117 minecraft:air
setblock 142 75 -117 minecraft:air
setblock 155 75 -117 minecraft:air
fill 183 75 -117 185 75 -117 minecraft:air
fill 140 76 -126 142 76 -126 minecraft:air
fill 147 76 -126 153 76 -126 minecraft:air
fill 181 76 -126 187 76 -126 minecraft:air
fill 197 76 -126 198 76 -126 minecraft:air
setblock 141 76 -125 minecraft:air
fill 145 76 -125 153 76 -125 minecraft:air
setblock 155 76 -125 minecraft:air
fill 180 76 -125 186 76 -125 minecraft:air
fill 147 76 -124 156 76 -124 minecraft:air
fill 164 76 -124 166 76 -124 minecraft:air
fill 180 76 -124 184 76 -124 minecraft:air
fill 147 76 -123 153 76 -123 minecraft:air
setblock 155 76 -123 minecraft:air
fill 163 76 -123 167 76 -123 minecraft:air
fill 180 76 -123 184 76 -123 minecraft:air
fill 147 76 -122 153 76 -122 minecraft:air
fill 163 76 -122 167 76 -122 minecraft:air
fill 181 76 -122 183 76 -122 minecraft:air
fill 148 76 -121 152 76 -121 minecraft:air
fill 163 76 -121 167 76 -121 minecraft:air
fill 141 76 -120 143 76 -120 minecraft:air
fill 154 76 -120 156 76 -120 minecraft:air
fill 164 76 -120 166 76 -120 minecraft:air
setblock 184 76 -120 minecraft:air
fill 140 76 -119 144 76 -119 minecraft:air
fill 153 76 -119 157 76 -119 minecraft:air
fill 183 76 -119 185 76 -119 minecraft:air
fill 140 76 -118 144 76 -118 minecraft:air
fill 153 76 -118 157 76 -118 minecraft:air
setblock 184 76 -118 minecraft:air
fill 140 76 -117 144 76 -117 minecraft:air
fill 153 76 -117 157 76 -117 minecraft:air
fill 141 76 -116 143 76 -116 minecraft:air
fill 154 76 -116 156 76 -116 minecraft:air
fill 140 77 -126 141 77 -126 minecraft:air
fill 149 77 -126 151 77 -126 minecraft:air
fill 154 77 -126 156 77 -126 minecraft:air
fill 183 77 -126 185 77 -126 minecraft:air
fill 148 77 -125 157 77 -125 minecraft:air
setblock 182 77 -125 minecraft:air
fill 148 77 -124 157 77 -124 minecraft:air
fill 181 77 -124 183 77 -124 minecraft:air
fill 148 77 -123 157 77 -123 minecraft:air
setblock 165 77 -123 minecraft:air
setblock 182 77 -123 minecraft:air
fill 149 77 -122 151 77 -122 minecraft:air
fill 154 77 -122 156 77 -122 minecraft:air
fill 164 77 -122 166 77 -122 minecraft:air
setblock 165 77 -121 minecraft:air
setblock 142 77 -119 minecraft:air
setblock 155 77 -119 minecraft:air
setblock 184 77 -119 minecraft:air
fill 141 77 -118 143 77 -118 minecraft:air
fill 154 77 -118 156 77 -118 minecraft:air
setblock 142 77 -117 minecraft:air
setblock 155 77 -117 minecraft:air
setblock 149 78 -126 minecraft:air
fill 151 78 -126 153 78 -126 minecraft:air
fill 181 78 -126 183 78 -126 minecraft:air
setblock 150 78 -125 minecraft:air
setblock 152 78 -125 minecraft:air
setblock 155 78 -125 minecraft:air
fill 180 78 -125 184 78 -125 minecraft:air
fill 149 78 -124 151 78 -124 minecraft:air
fill 154 78 -124 156 78 -124 minecraft:air
fill 180 78 -124 184 78 -124 minecraft:air
setblock 150 78 -123 minecraft:air
setblock 155 78 -123 minecraft:air
fill 180 78 -123 184 78 -123 minecraft:air
setblock 165 78 -122 minecraft:air
fill 181 78 -122 183 78 -122 minecraft:air
fill 141 78 -120 143 78 -120 minecraft:air
fill 154 78 -120 156 78 -120 minecraft:air
setblock 184 78 -120 minecraft:air
fill 140 78 -119 144 78 -119 minecraft:air
fill 153 78 -119 157 78 -119 minecraft:air
fill 183 78 -119 185 78 -119 minecraft:air
fill 140 78 -118 144 78 -118 minecraft:air
fill 153 78 -118 157 78 -118 minecraft:air
setblock 184 78 -118 minecraft:air
fill 140 78 -117 144 78 -117 minecraft:air
fill 153 78 -117 157 78 -117 minecraft:air
fill 141 78 -116 143 78 -116 minecraft:air
fill 154 78 -116 156 78 -116 minecraft:air
fill 149 79 -126 156 79 -126 minecraft:air
fill 181 79 -126 187 79 -126 minecraft:air
fill 148 79 -125 157 79 -125 minecraft:air
fill 182 79 -125 186 79 -125 minecraft:air
fill 148 79 -124 157 79 -124 minecraft:air
fill 181 79 -124 183 79 -124 minecraft:air
fill 148 79 -123 157 79 -123 minecraft:air
setblock 165 79 -123 minecraft:air
setblock 182 79 -123 minecraft:air
fill 149 79 -122 151 79 -122 minecraft:air
fill 154 79 -122 156 79 -122 minecraft:air
fill 164 79 -122 166 79 -122 minecraft:air
setblock 165 79 -121 minecraft:air
setblock 142 79 -119 minecraft:air
setblock 155 79 -119 minecraft:air
setblock 184 79 -119 minecraft:air
fill 141 79 -118 143 79 -118 minecraft:air
fill 154 79 -118 156 79 -118 minecraft:air
setblock 142 79 -117 minecraft:air
setblock 155 79 -117 minecraft:air
setblock 152 80 -126 minecraft:air
fill 183 80 -126 185 80 -126 minecraft:air
setblock 150 80 -125 minecraft:air
setblock 155 80 -125 minecraft:air
fill 149 80 -124 151 80 -124 minecraft:air
fill 154 80 -124 156 80 -124 minecraft:air
setblock 182 80 -124 minecraft:air
setblock 150 80 -123 minecraft:air
setblock 155 80 -123 minecraft:air
setblock 165 80 -122 minecraft:air
fill 141 80 -120 143 80 -120 minecraft:air
fill 140 80 -119 144 80 -119 minecraft:air
fill 140 80 -118 144 80 -118 minecraft:air
setblock 155 80 -118 minecraft:air
fill 140 80 -117 144 80 -117 minecraft:air
fill 141 80 -116 143 80 -116 minecraft:air
setblock 152 81 -126 minecraft:air
setblock 182 81 -125 minecraft:air
setblock 150 81 -124 minecraft:air
setblock 155 81 -124 minecraft:air
fill 181 81 -124 183 81 -124 minecraft:air
setblock 182 81 -123 minecraft:air
setblock 142 81 -119 minecraft:air
setblock 155 81 -119 minecraft:air
fill 141 81 -118 143 81 -118 minecraft:air
fill 154 81 -118 156 81 -118 minecraft:air
setblock 142 81 -117 minecraft:air
setblock 155 81 -117 minecraft:air
fill 183 82 -126 185 82 -126 minecraft:air
setblock 150 82 -125 minecraft:air
setblock 155 82 -125 minecraft:air
fill 149 82 -124 151 82 -124 minecraft:air
fill 154 82 -124 156 82 -124 minecraft:air
setblock 150 82 -123 minecraft:air
setblock 155 82 -123 minecraft:air
fill 141 82 -120 143 82 -120 minecraft:air
fill 140 82 -119 144 82 -119 minecraft:air
fill 140 82 -118 144 82 -118 minecraft:air
fill 140 82 -117 144 82 -117 minecraft:air
fill 141 82 -116 143 82 -116 minecraft:air
setblock 150 83 -124 minecraft:air
setblock 142 83 -119 minecraft:air
fill 141 83 -118 143 83 -118 minecraft:air
setblock 142 83 -117 minecraft:air
setblock 142 84 -118 minecraft:air
setblock 142 85 -119 minecraft:air
fill 141 85 -118 143 85 -118 minecraft:air
setblock 142 85 -117 minecraft:air
forceload remove 136 -126 199 -63
tellraw @a {"text":"Campus bau a38 fertig.","color":"green"}
