fill 38 45 -441 39 45 -441 minecraft:stone
fill 38 45 -440 39 45 -440 minecraft:stone
fill 38 45 -439 39 45 -439 minecraft:stone
fill 37 45 -438 39 45 -438 minecraft:stone
fill 37 45 -437 39 45 -437 minecraft:stone
fill 36 45 -436 38 45 -436 minecraft:stone
fill 35 45 -435 37 45 -435 minecraft:stone
fill 19 45 -434 20 45 -434 minecraft:stone
fill 35 45 -434 37 45 -434 minecraft:stone
fill 19 45 -433 20 45 -433 minecraft:stone
fill 34 45 -433 36 45 -433 minecraft:stone
fill 34 45 -432 35 45 -432 minecraft:stone
fill 19 45 -392 23 45 -392 minecraft:stone
fill 19 45 -391 22 45 -391 minecraft:stone
fill 19 45 -390 22 45 -390 minecraft:stone
fill 38 46 -443 39 46 -443 minecraft:stone
fill 38 46 -442 40 46 -442 minecraft:stone
fill 38 46 -441 39 46 -441 minecraft:stone
fill 38 46 -440 39 46 -440 minecraft:stone
fill 38 46 -439 39 46 -439 minecraft:stone
fill 37 46 -438 39 46 -438 minecraft:stone
fill 37 46 -437 39 46 -437 minecraft:stone
fill 37 46 -436 38 46 -436 minecraft:stone
fill 35 46 -435 37 46 -435 minecraft:stone
fill 19 46 -434 20 46 -434 minecraft:stone
fill 35 46 -434 37 46 -434 minecraft:stone
fill 19 46 -433 20 46 -433 minecraft:stone
fill 35 46 -433 36 46 -433 minecraft:stone
fill 19 46 -391 23 46 -391 minecraft:stone
fill 19 46 -390 23 46 -390 minecraft:stone
fill 19 46 -389 22 46 -389 minecraft:stone
fill 39 47 -445 40 47 -445 minecraft:stone
setblock 39 47 -444 minecraft:stone
fill 38 47 -443 40 47 -443 minecraft:stone
fill 38 47 -442 40 47 -442 minecraft:stone
fill 38 47 -441 40 47 -441 minecraft:stone
fill 38 47 -440 39 47 -440 minecraft:stone
fill 38 47 -439 39 47 -439 minecraft:stone
fill 37 47 -438 39 47 -438 minecraft:stone
fill 37 47 -437 39 47 -437 minecraft:stone
setblock 38 47 -436 minecraft:stone
fill 22 47 -391 23 47 -391 minecraft:stone
fill 20 47 -390 23 47 -390 minecraft:stone
fill 20 47 -389 23 47 -389 minecraft:stone
fill 20 47 -388 22 47 -388 minecraft:stone
setblock 8 47 -383 minecraft:stone
fill 44 48 -446 47 48 -446 minecraft:stone
fill 36 48 -445 46 48 -445 minecraft:stone
fill 34 48 -444 46 48 -444 minecraft:stone
fill 35 48 -443 45 48 -443 minecraft:stone
fill 36 48 -442 44 48 -442 minecraft:stone
fill 38 48 -441 39 48 -441 minecraft:stone
fill 38 48 -440 39 48 -440 minecraft:stone
fill 38 48 -439 39 48 -439 minecraft:stone
setblock 38 48 -438 minecraft:stone
setblock 12 48 -405 minecraft:stone
fill 20 48 -390 24 48 -390 minecraft:stone
fill 20 48 -389 24 48 -389 minecraft:stone
fill 70 48 -389 71 48 -389 minecraft:stone
fill 20 48 -388 23 48 -388 minecraft:stone
fill 60 48 -388 71 48 -388 minecraft:stone
fill 60 48 -387 71 48 -387 minecraft:stone
fill 59 48 -386 71 48 -386 minecraft:stone
fill 58 48 -385 71 48 -385 minecraft:stone
setblock 8 48 -384 minecraft:stone
fill 56 48 -384 71 48 -384 minecraft:stone
fill 8 48 -383 9 48 -383 minecraft:stone
fill 56 48 -383 71 48 -383 minecraft:stone
fill 44 49 -446 50 49 -446 minecraft:stone
fill 36 49 -445 50 49 -445 minecraft:stone
fill 33 49 -444 50 49 -444 minecraft:stone
fill 31 49 -443 50 49 -443 minecraft:stone
fill 32 49 -442 49 49 -442 minecraft:stone
fill 32 49 -441 48 49 -441 minecraft:stone
fill 33 49 -440 48 49 -440 minecraft:stone
fill 34 49 -439 46 49 -439 minecraft:stone
fill 35 49 -438 44 49 -438 minecraft:stone
fill 53 49 -433 54 49 -433 minecraft:stone
fill 54 49 -432 56 49 -432 minecraft:stone
fill 55 49 -431 58 49 -431 minecraft:stone
fill 56 49 -430 58 49 -430 minecraft:stone
setblock 13 49 -428 minecraft:stone
setblock 13 49 -427 minecraft:stone
setblock 59 49 -427 minecraft:stone
fill 12 49 -426 13 49 -426 minecraft:stone
fill 12 49 -425 13 49 -425 minecraft:stone
fill 11 49 -424 12 49 -424 minecraft:stone
fill 11 49 -423 12 49 -423 minecraft:stone
fill 11 49 -422 12 49 -422 minecraft:stone
fill 10 49 -421 12 49 -421 minecraft:stone
fill 10 49 -420 12 49 -420 minecraft:stone
fill 10 49 -419 12 49 -419 minecraft:stone
fill 68 49 -398 71 49 -398 minecraft:stone
fill 68 49 -397 71 49 -397 minecraft:stone
fill 68 49 -396 71 49 -396 minecraft:stone
fill 67 49 -395 71 49 -395 minecraft:stone
fill 66 49 -394 71 49 -394 minecraft:stone
fill 65 49 -393 71 49 -393 minecraft:stone
fill 65 49 -392 71 49 -392 minecraft:stone
fill 65 49 -391 71 49 -391 minecraft:stone
setblock 24 49 -390 minecraft:stone
fill 65 49 -390 71 49 -390 minecraft:stone
fill 21 49 -389 24 49 -389 minecraft:stone
fill 62 49 -389 71 49 -389 minecraft:stone
fill 21 49 -388 24 49 -388 minecraft:stone
fill 60 49 -388 71 49 -388 minecraft:stone
fill 20 49 -387 23 49 -387 minecraft:stone
fill 59 49 -387 71 49 -387 minecraft:stone
fill 59 49 -386 71 49 -386 minecraft:stone
fill 58 49 -385 71 49 -385 minecraft:stone
fill 8 49 -384 9 49 -384 minecraft:stone
fill 56 49 -384 71 49 -384 minecraft:stone
fill 8 49 -383 9 49 -383 minecraft:stone
fill 56 49 -383 71 49 -383 minecraft:stone
fill 44 50 -446 52 50 -446 minecraft:stone
fill 36 50 -445 53 50 -445 minecraft:stone
fill 33 50 -444 56 50 -444 minecraft:stone
fill 30 50 -443 56 50 -443 minecraft:stone
fill 28 50 -442 56 50 -442 minecraft:stone
fill 27 50 -441 54 50 -441 minecraft:stone
fill 27 50 -440 53 50 -440 minecraft:stone
fill 27 50 -439 52 50 -439 minecraft:stone
fill 27 50 -438 52 50 -438 minecraft:stone
fill 27 50 -437 52 50 -437 minecraft:stone
fill 27 50 -436 49 50 -436 minecraft:stone
fill 51 50 -436 52 50 -436 minecraft:stone
fill 28 50 -435 39 50 -435 minecraft:stone
fill 42 50 -435 47 50 -435 minecraft:stone
fill 51 50 -435 53 50 -435 minecraft:stone
fill 51 50 -434 54 50 -434 minecraft:stone
fill 52 50 -433 56 50 -433 minecraft:stone
setblock 16 50 -432 minecraft:stone
fill 54 50 -432 57 50 -432 minecraft:stone
fill 15 50 -431 16 50 -431 minecraft:stone
fill 55 50 -431 58 50 -431 minecraft:stone
fill 15 50 -430 16 50 -430 minecraft:stone
fill 56 50 -430 58 50 -430 minecraft:stone
fill 14 50 -429 16 50 -429 minecraft:stone
setblock 57 50 -429 minecraft:stone
setblock 59 50 -429 minecraft:stone
fill 13 50 -428 17 50 -428 minecraft:stone
fill 58 50 -428 60 50 -428 minecraft:stone
fill 13 50 -427 16 50 -427 minecraft:stone
fill 58 50 -427 60 50 -427 minecraft:stone
fill 12 50 -426 16 50 -426 minecraft:stone
fill 58 50 -426 60 50 -426 minecraft:stone
fill 12 50 -425 16 50 -425 minecraft:stone
fill 58 50 -425 60 50 -425 minecraft:stone
fill 11 50 -424 16 50 -424 minecraft:stone
fill 59 50 -424 60 50 -424 minecraft:stone
fill 11 50 -423 16 50 -423 minecraft:stone
setblock 59 50 -423 minecraft:stone
fill 11 50 -422 15 50 -422 minecraft:stone
fill 10 50 -421 15 50 -421 minecraft:stone
fill 10 50 -420 15 50 -420 minecraft:stone
fill 10 50 -419 15 50 -419 minecraft:stone
fill 9 50 -418 14 50 -418 minecraft:stone
fill 9 50 -417 14 50 -417 minecraft:stone
fill 9 50 -416 13 50 -416 minecraft:stone
fill 9 50 -415 12 50 -415 minecraft:stone
fill 9 50 -414 10 50 -414 minecraft:stone
setblock 71 50 -404 minecraft:stone
fill 69 50 -403 71 50 -403 minecraft:stone
fill 68 50 -402 71 50 -402 minecraft:stone
fill 68 50 -401 71 50 -401 minecraft:stone
fill 68 50 -400 71 50 -400 minecraft:stone
fill 68 50 -399 71 50 -399 minecraft:stone
fill 68 50 -398 71 50 -398 minecraft:stone
fill 68 50 -397 71 50 -397 minecraft:stone
fill 68 50 -396 71 50 -396 minecraft:stone
fill 66 50 -395 71 50 -395 minecraft:stone
fill 65 50 -394 71 50 -394 minecraft:stone
fill 64 50 -393 71 50 -393 minecraft:stone
fill 64 50 -392 71 50 -392 minecraft:stone
fill 64 50 -391 71 50 -391 minecraft:stone
fill 63 50 -390 71 50 -390 minecraft:stone
fill 22 50 -389 24 50 -389 minecraft:stone
fill 61 50 -389 71 50 -389 minecraft:stone
fill 21 50 -388 24 50 -388 minecraft:stone
fill 60 50 -388 71 50 -388 minecraft:stone
fill 21 50 -387 24 50 -387 minecraft:stone
fill 59 50 -387 71 50 -387 minecraft:stone
fill 20 50 -386 23 50 -386 minecraft:stone
fill 59 50 -386 71 50 -386 minecraft:stone
fill 8 50 -385 9 50 -385 minecraft:stone
fill 57 50 -385 71 50 -385 minecraft:stone
fill 8 50 -384 9 50 -384 minecraft:stone
fill 56 50 -384 71 50 -384 minecraft:stone
fill 8 50 -383 10 50 -383 minecraft:stone
fill 56 50 -383 71 50 -383 minecraft:stone
fill 44 51 -446 53 51 -446 minecraft:stone
fill 36 51 -445 55 51 -445 minecraft:stone
fill 33 51 -444 56 51 -444 minecraft:stone
fill 30 51 -443 56 51 -443 minecraft:stone
fill 28 51 -442 56 51 -442 minecraft:stone
fill 26 51 -441 56 51 -441 minecraft:stone
fill 25 51 -440 56 51 -440 minecraft:stone
fill 58 51 -440 59 51 -440 minecraft:stone
fill 23 51 -439 56 51 -439 minecraft:stone
setblock 58 51 -439 minecraft:stone
fill 22 51 -438 57 51 -438 minecraft:stone
fill 21 51 -437 57 51 -437 minecraft:stone
fill 20 51 -436 56 51 -436 minecraft:stone
fill 19 51 -435 56 51 -435 minecraft:stone
fill 18 51 -434 56 51 -434 minecraft:stone
fill 17 51 -433 56 51 -433 minecraft:stone
fill 16 51 -432 37 51 -432 minecraft:stone
fill 48 51 -432 57 51 -432 minecraft:stone
fill 15 51 -431 34 51 -431 minecraft:stone
fill 50 51 -431 58 51 -431 minecraft:stone
fill 15 51 -430 28 51 -430 minecraft:stone
fill 51 51 -430 58 51 -430 minecraft:stone
fill 14 51 -429 26 51 -429 minecraft:stone
setblock 54 51 -429 minecraft:stone
setblock 57 51 -429 minecraft:stone
fill 59 51 -429 60 51 -429 minecraft:stone
fill 13 51 -428 25 51 -428 minecraft:stone
fill 57 51 -428 61 51 -428 minecraft:stone
fill 13 51 -427 24 51 -427 minecraft:stone
fill 56 51 -427 61 51 -427 minecraft:stone
fill 12 51 -426 23 51 -426 minecraft:stone
fill 55 51 -426 56 51 -426 minecraft:stone
fill 58 51 -426 61 51 -426 minecraft:stone
fill 12 51 -425 21 51 -425 minecraft:stone
fill 55 51 -425 56 51 -425 minecraft:stone
fill 58 51 -425 61 51 -425 minecraft:stone
fill 11 51 -424 20 51 -424 minecraft:stone
fill 56 51 -424 60 51 -424 minecraft:stone
fill 11 51 -423 19 51 -423 minecraft:stone
fill 58 51 -423 60 51 -423 minecraft:stone
fill 11 51 -422 19 51 -422 minecraft:stone
fill 58 51 -422 60 51 -422 minecraft:stone
fill 10 51 -421 18 51 -421 minecraft:stone
fill 58 51 -421 59 51 -421 minecraft:stone
fill 10 51 -420 18 51 -420 minecraft:stone
fill 58 51 -420 59 51 -420 minecraft:stone
fill 10 51 -419 18 51 -419 minecraft:stone
fill 9 51 -418 17 51 -418 minecraft:stone
fill 9 51 -417 17 51 -417 minecraft:stone
fill 9 51 -416 17 51 -416 minecraft:stone
fill 9 51 -415 16 51 -415 minecraft:stone
fill 9 51 -414 16 51 -414 minecraft:stone
fill 9 51 -413 15 51 -413 minecraft:stone
fill 9 51 -412 14 51 -412 minecraft:stone
fill 9 51 -411 13 51 -411 minecraft:stone
fill 8 51 -410 12 51 -410 minecraft:stone
setblock 71 51 -408 minecraft:stone
setblock 71 51 -407 minecraft:stone
fill 70 51 -406 71 51 -406 minecraft:stone
fill 70 51 -405 71 51 -405 minecraft:stone
fill 68 51 -404 71 51 -404 minecraft:stone
fill 68 51 -403 71 51 -403 minecraft:stone
fill 68 51 -402 71 51 -402 minecraft:stone
fill 67 51 -401 71 51 -401 minecraft:stone
fill 67 51 -400 71 51 -400 minecraft:stone
fill 67 51 -399 71 51 -399 minecraft:stone
fill 67 51 -398 71 51 -398 minecraft:stone
fill 67 51 -397 71 51 -397 minecraft:stone
fill 66 51 -396 71 51 -396 minecraft:stone
fill 65 51 -395 71 51 -395 minecraft:stone
fill 64 51 -394 71 51 -394 minecraft:stone
fill 64 51 -393 71 51 -393 minecraft:stone
fill 64 51 -392 71 51 -392 minecraft:stone
fill 63 51 -391 71 51 -391 minecraft:stone
fill 62 51 -390 71 51 -390 minecraft:stone
fill 60 51 -389 71 51 -389 minecraft:stone
fill 21 51 -388 24 51 -388 minecraft:stone
fill 59 51 -388 71 51 -388 minecraft:stone
fill 21 51 -387 24 51 -387 minecraft:stone
fill 59 51 -387 71 51 -387 minecraft:stone
fill 8 51 -386 9 51 -386 minecraft:stone
fill 21 51 -386 24 51 -386 minecraft:stone
fill 58 51 -386 71 51 -386 minecraft:stone
fill 8 51 -385 10 51 -385 minecraft:stone
fill 21 51 -385 23 51 -385 minecraft:stone
fill 56 51 -385 71 51 -385 minecraft:stone
fill 8 51 -384 10 51 -384 minecraft:stone
fill 56 51 -384 71 51 -384 minecraft:stone
fill 8 51 -383 11 51 -383 minecraft:stone
fill 56 51 -383 71 51 -383 minecraft:stone
fill 44 52 -446 54 52 -446 minecraft:stone
fill 36 52 -445 56 52 -445 minecraft:stone
fill 33 52 -444 56 52 -444 minecraft:stone
fill 30 52 -443 55 52 -443 minecraft:stone
fill 28 52 -442 56 52 -442 minecraft:stone
fill 26 52 -441 57 52 -441 minecraft:stone
fill 25 52 -440 60 52 -440 minecraft:stone
fill 23 52 -439 60 52 -439 minecraft:stone
fill 22 52 -438 60 52 -438 minecraft:stone
fill 21 52 -437 60 52 -437 minecraft:stone
fill 20 52 -436 59 52 -436 minecraft:stone
fill 19 52 -435 59 52 -435 minecraft:stone
fill 18 52 -434 59 52 -434 minecraft:stone
fill 17 52 -433 59 52 -433 minecraft:stone
fill 16 52 -432 59 52 -432 minecraft:stone
fill 15 52 -431 59 52 -431 minecraft:stone
fill 15 52 -430 60 52 -430 minecraft:stone
fill 14 52 -429 47 52 -429 minecraft:stone
setblock 49 52 -429 minecraft:stone
fill 52 52 -429 62 52 -429 minecraft:stone
fill 13 52 -428 47 52 -428 minecraft:stone
fill 49 52 -428 50 52 -428 minecraft:stone
fill 54 52 -428 64 52 -428 minecraft:stone
fill 13 52 -427 30 52 -427 minecraft:stone
fill 46 52 -427 51 52 -427 minecraft:stone
fill 55 52 -427 64 52 -427 minecraft:stone
fill 12 52 -426 28 52 -426 minecraft:stone
fill 48 52 -426 52 52 -426 minecraft:stone
fill 55 52 -426 64 52 -426 minecraft:stone
fill 12 52 -425 27 52 -425 minecraft:stone
fill 50 52 -425 53 52 -425 minecraft:stone
fill 55 52 -425 64 52 -425 minecraft:stone
fill 11 52 -424 26 52 -424 minecraft:stone
fill 51 52 -424 53 52 -424 minecraft:stone
fill 56 52 -424 64 52 -424 minecraft:stone
fill 11 52 -423 25 52 -423 minecraft:stone
fill 51 52 -423 62 52 -423 minecraft:stone
fill 11 52 -422 24 52 -422 minecraft:stone
fill 52 52 -422 61 52 -422 minecraft:stone
fill 10 52 -421 23 52 -421 minecraft:stone
fill 52 52 -421 60 52 -421 minecraft:stone
fill 10 52 -420 22 52 -420 minecraft:stone
fill 54 52 -420 59 52 -420 minecraft:stone
fill 10 52 -419 21 52 -419 minecraft:stone
fill 57 52 -419 59 52 -419 minecraft:stone
fill 9 52 -418 21 52 -418 minecraft:stone
fill 57 52 -418 59 52 -418 minecraft:stone
fill 9 52 -417 20 52 -417 minecraft:stone
setblock 58 52 -417 minecraft:stone
fill 9 52 -416 20 52 -416 minecraft:stone
fill 9 52 -415 19 52 -415 minecraft:stone
fill 9 52 -414 19 52 -414 minecraft:stone
fill 9 52 -413 18 52 -413 minecraft:stone
fill 9 52 -412 17 52 -412 minecraft:stone
fill 9 52 -411 17 52 -411 minecraft:stone
fill 8 52 -410 16 52 -410 minecraft:stone
setblock 71 52 -410 minecraft:stone
fill 8 52 -409 15 52 -409 minecraft:stone
setblock 71 52 -409 minecraft:stone
fill 8 52 -408 14 52 -408 minecraft:stone
fill 70 52 -408 71 52 -408 minecraft:stone
fill 8 52 -407 14 52 -407 minecraft:stone
fill 70 52 -407 71 52 -407 minecraft:stone
fill 8 52 -406 14 52 -406 minecraft:stone
fill 69 52 -406 71 52 -406 minecraft:stone
fill 8 52 -405 14 52 -405 minecraft:stone
fill 68 52 -405 71 52 -405 minecraft:stone
fill 8 52 -404 14 52 -404 minecraft:stone
fill 68 52 -404 71 52 -404 minecraft:stone
fill 8 52 -403 14 52 -403 minecraft:stone
fill 67 52 -403 71 52 -403 minecraft:stone
fill 8 52 -402 14 52 -402 minecraft:stone
fill 66 52 -402 71 52 -402 minecraft:stone
fill 8 52 -401 14 52 -401 minecraft:stone
fill 66 52 -401 71 52 -401 minecraft:stone
fill 8 52 -400 15 52 -400 minecraft:stone
fill 60 52 -400 61 52 -400 minecraft:stone
fill 66 52 -400 71 52 -400 minecraft:stone
fill 60 52 -399 61 52 -399 minecraft:stone
fill 66 52 -399 71 52 -399 minecraft:stone
fill 60 52 -398 62 52 -398 minecraft:stone
fill 66 52 -398 71 52 -398 minecraft:stone
fill 61 52 -397 62 52 -397 minecraft:stone
fill 66 52 -397 71 52 -397 minecraft:stone
fill 61 52 -396 63 52 -396 minecraft:stone
fill 65 52 -396 71 52 -396 minecraft:stone
fill 62 52 -395 71 52 -395 minecraft:stone
fill 63 52 -394 71 52 -394 minecraft:stone
fill 63 52 -393 71 52 -393 minecraft:stone
fill 63 52 -392 71 52 -392 minecraft:stone
fill 62 52 -391 71 52 -391 minecraft:stone
fill 61 52 -390 71 52 -390 minecraft:stone
fill 8 52 -389 12 52 -389 minecraft:stone
fill 60 52 -389 71 52 -389 minecraft:stone
fill 8 52 -388 12 52 -388 minecraft:stone
setblock 25 52 -388 minecraft:stone
fill 59 52 -388 71 52 -388 minecraft:stone
fill 8 52 -387 12 52 -387 minecraft:stone
fill 21 52 -387 24 52 -387 minecraft:stone
fill 58 52 -387 71 52 -387 minecraft:stone
fill 8 52 -386 13 52 -386 minecraft:stone
fill 21 52 -386 24 52 -386 minecraft:stone
fill 57 52 -386 71 52 -386 minecraft:stone
fill 8 52 -385 13 52 -385 minecraft:stone
fill 21 52 -385 24 52 -385 minecraft:stone
fill 56 52 -385 71 52 -385 minecraft:stone
fill 8 52 -384 13 52 -384 minecraft:stone
fill 21 52 -384 24 52 -384 minecraft:stone
fill 56 52 -384 71 52 -384 minecraft:stone
fill 8 52 -383 13 52 -383 minecraft:stone
setblock 25 52 -383 minecraft:stone
fill 56 52 -383 71 52 -383 minecraft:stone
fill 44 53 -446 54 53 -446 minecraft:stone
fill 36 53 -445 56 53 -445 minecraft:stone
fill 33 53 -444 57 53 -444 minecraft:stone
fill 30 53 -443 56 53 -443 minecraft:stone
fill 28 53 -442 57 53 -442 minecraft:stone
fill 26 53 -441 57 53 -441 minecraft:stone
setblock 59 53 -441 minecraft:stone
fill 25 53 -440 63 53 -440 minecraft:stone
fill 23 53 -439 60 53 -439 minecraft:stone
setblock 62 53 -439 minecraft:stone
fill 22 53 -438 60 53 -438 minecraft:stone
fill 21 53 -437 61 53 -437 minecraft:stone
fill 20 53 -436 61 53 -436 minecraft:stone
fill 19 53 -435 61 53 -435 minecraft:stone
fill 18 53 -434 61 53 -434 minecraft:stone
fill 17 53 -433 61 53 -433 minecraft:stone
fill 16 53 -432 61 53 -432 minecraft:stone
fill 15 53 -431 63 53 -431 minecraft:stone
fill 15 53 -430 64 53 -430 minecraft:stone
fill 14 53 -429 66 53 -429 minecraft:stone
fill 13 53 -428 66 53 -428 minecraft:stone
fill 13 53 -427 66 53 -427 minecraft:stone
fill 12 53 -426 66 53 -426 minecraft:stone
fill 12 53 -425 31 53 -425 minecraft:stone
fill 35 53 -425 66 53 -425 minecraft:stone
fill 11 53 -424 30 53 -424 minecraft:stone
fill 38 53 -424 66 53 -424 minecraft:stone
fill 11 53 -423 29 53 -423 minecraft:stone
fill 38 53 -423 66 53 -423 minecraft:stone
fill 11 53 -422 27 53 -422 minecraft:stone
fill 39 53 -422 66 53 -422 minecraft:stone
fill 10 53 -421 26 53 -421 minecraft:stone
fill 40 53 -421 66 53 -421 minecraft:stone
fill 10 53 -420 25 53 -420 minecraft:stone
fill 40 53 -420 65 53 -420 minecraft:stone
fill 10 53 -419 25 53 -419 minecraft:stone
fill 42 53 -419 64 53 -419 minecraft:stone
fill 9 53 -418 24 53 -418 minecraft:stone
fill 44 53 -418 63 53 -418 minecraft:stone
fill 9 53 -417 24 53 -417 minecraft:stone
fill 45 53 -417 62 53 -417 minecraft:stone
fill 9 53 -416 23 53 -416 minecraft:stone
fill 46 53 -416 60 53 -416 minecraft:stone
fill 9 53 -415 23 53 -415 minecraft:stone
fill 47 53 -415 57 53 -415 minecraft:stone
fill 59 53 -415 60 53 -415 minecraft:stone
fill 9 53 -414 22 53 -414 minecraft:stone
fill 47 53 -414 54 53 -414 minecraft:stone
fill 9 53 -413 22 53 -413 minecraft:stone
fill 48 53 -413 53 53 -413 minecraft:stone
setblock 71 53 -413 minecraft:stone
fill 9 53 -412 21 53 -412 minecraft:stone
fill 70 53 -412 71 53 -412 minecraft:stone
fill 9 53 -411 20 53 -411 minecraft:stone
fill 70 53 -411 71 53 -411 minecraft:stone
fill 8 53 -410 20 53 -410 minecraft:stone
fill 70 53 -410 71 53 -410 minecraft:stone
fill 8 53 -409 20 53 -409 minecraft:stone
fill 70 53 -409 71 53 -409 minecraft:stone
fill 8 53 -408 19 53 -408 minecraft:stone
fill 70 53 -408 71 53 -408 minecraft:stone
fill 8 53 -407 19 53 -407 minecraft:stone
fill 69 53 -407 71 53 -407 minecraft:stone
fill 8 53 -406 18 53 -406 minecraft:stone
fill 68 53 -406 71 53 -406 minecraft:stone
fill 8 53 -405 18 53 -405 minecraft:stone
setblock 61 53 -405 minecraft:stone
fill 67 53 -405 71 53 -405 minecraft:stone
fill 8 53 -404 18 53 -404 minecraft:stone
fill 60 53 -404 62 53 -404 minecraft:stone
fill 67 53 -404 71 53 -404 minecraft:stone
fill 8 53 -403 18 53 -403 minecraft:stone
fill 60 53 -403 62 53 -403 minecraft:stone
fill 65 53 -403 71 53 -403 minecraft:stone
fill 8 53 -402 18 53 -402 minecraft:stone
fill 46 53 -402 49 53 -402 minecraft:stone
fill 59 53 -402 62 53 -402 minecraft:stone
fill 64 53 -402 71 53 -402 minecraft:stone
fill 8 53 -401 18 53 -401 minecraft:stone
fill 60 53 -401 62 53 -401 minecraft:stone
fill 64 53 -401 71 53 -401 minecraft:stone
fill 8 53 -400 18 53 -400 minecraft:stone
fill 59 53 -400 62 53 -400 minecraft:stone
fill 65 53 -400 71 53 -400 minecraft:stone
fill 8 53 -399 18 53 -399 minecraft:stone
fill 59 53 -399 62 53 -399 minecraft:stone
fill 65 53 -399 71 53 -399 minecraft:stone
fill 8 53 -398 18 53 -398 minecraft:stone
fill 60 53 -398 63 53 -398 minecraft:stone
fill 65 53 -398 71 53 -398 minecraft:stone
fill 8 53 -397 20 53 -397 minecraft:stone
setblock 23 53 -397 minecraft:stone
setblock 25 53 -397 minecraft:stone
fill 60 53 -397 71 53 -397 minecraft:stone
fill 8 53 -396 21 53 -396 minecraft:stone
fill 23 53 -396 25 53 -396 minecraft:stone
fill 60 53 -396 71 53 -396 minecraft:stone
fill 8 53 -395 26 53 -395 minecraft:stone
fill 61 53 -395 71 53 -395 minecraft:stone
fill 8 53 -394 25 53 -394 minecraft:stone
fill 62 53 -394 71 53 -394 minecraft:stone
fill 8 53 -393 25 53 -393 minecraft:stone
fill 62 53 -393 71 53 -393 minecraft:stone
fill 8 53 -392 24 53 -392 minecraft:stone
fill 62 53 -392 71 53 -392 minecraft:stone
fill 8 53 -391 24 53 -391 minecraft:stone
fill 61 53 -391 71 53 -391 minecraft:stone
fill 8 53 -390 25 53 -390 minecraft:stone
fill 60 53 -390 71 53 -390 minecraft:stone
fill 8 53 -389 25 53 -389 minecraft:stone
fill 59 53 -389 71 53 -389 minecraft:stone
fill 8 53 -388 25 53 -388 minecraft:stone
fill 58 53 -388 71 53 -388 minecraft:stone
fill 8 53 -387 25 53 -387 minecraft:stone
fill 58 53 -387 71 53 -387 minecraft:stone
fill 8 53 -386 25 53 -386 minecraft:stone
fill 57 53 -386 71 53 -386 minecraft:stone
fill 8 53 -385 24 53 -385 minecraft:stone
fill 56 53 -385 71 53 -385 minecraft:stone
fill 8 53 -384 24 53 -384 minecraft:stone
fill 55 53 -384 71 53 -384 minecraft:stone
fill 8 53 -383 25 53 -383 minecraft:stone
fill 55 53 -383 71 53 -383 minecraft:stone
fill 44 54 -446 55 54 -446 minecraft:stone
fill 36 54 -445 56 54 -445 minecraft:stone
fill 33 54 -444 58 54 -444 minecraft:stone
fill 30 54 -443 58 54 -443 minecraft:stone
fill 28 54 -442 59 54 -442 minecraft:stone
fill 26 54 -441 62 54 -441 minecraft:stone
fill 25 54 -440 64 54 -440 minecraft:stone
fill 23 54 -439 64 54 -439 minecraft:stone
fill 22 54 -438 64 54 -438 minecraft:stone
fill 21 54 -437 63 54 -437 minecraft:stone
fill 20 54 -436 62 54 -436 minecraft:stone
fill 19 54 -435 63 54 -435 minecraft:stone
fill 18 54 -434 63 54 -434 minecraft:stone
fill 17 54 -433 64 54 -433 minecraft:stone
fill 16 54 -432 65 54 -432 minecraft:stone
fill 15 54 -431 67 54 -431 minecraft:stone
fill 15 54 -430 67 54 -430 minecraft:stone
fill 14 54 -429 71 54 -429 minecraft:stone
fill 13 54 -428 71 54 -428 minecraft:stone
fill 13 54 -427 71 54 -427 minecraft:stone
fill 12 54 -426 71 54 -426 minecraft:stone
fill 12 54 -425 71 54 -425 minecraft:stone
fill 11 54 -424 71 54 -424 minecraft:stone
fill 11 54 -423 71 54 -423 minecraft:stone
fill 11 54 -422 71 54 -422 minecraft:stone
fill 10 54 -421 31 54 -421 minecraft:stone
fill 33 54 -421 70 54 -421 minecraft:stone
fill 10 54 -420 29 54 -420 minecraft:stone
fill 34 54 -420 70 54 -420 minecraft:stone
fill 10 54 -419 29 54 -419 minecraft:stone
fill 34 54 -419 70 54 -419 minecraft:stone
fill 9 54 -418 29 54 -418 minecraft:stone
fill 34 54 -418 71 54 -418 minecraft:stone
fill 9 54 -417 29 54 -417 minecraft:stone
fill 35 54 -417 71 54 -417 minecraft:stone
fill 9 54 -416 29 54 -416 minecraft:stone
fill 37 54 -416 71 54 -416 minecraft:stone
fill 9 54 -415 29 54 -415 minecraft:stone
fill 37 54 -415 71 54 -415 minecraft:stone
fill 9 54 -414 28 54 -414 minecraft:stone
fill 38 54 -414 71 54 -414 minecraft:stone
fill 9 54 -413 28 54 -413 minecraft:stone
fill 39 54 -413 71 54 -413 minecraft:stone
fill 9 54 -412 27 54 -412 minecraft:stone
fill 41 54 -412 71 54 -412 minecraft:stone
fill 9 54 -411 27 54 -411 minecraft:stone
fill 41 54 -411 71 54 -411 minecraft:stone
fill 8 54 -410 26 54 -410 minecraft:stone
fill 42 54 -410 62 54 -410 minecraft:stone
fill 67 54 -410 71 54 -410 minecraft:stone
fill 8 54 -409 26 54 -409 minecraft:stone
fill 42 54 -409 60 54 -409 minecraft:stone
setblock 62 54 -409 minecraft:stone
fill 69 54 -409 71 54 -409 minecraft:stone
fill 8 54 -408 25 54 -408 minecraft:stone
fill 43 54 -408 46 54 -408 minecraft:stone
fill 54 54 -408 58 54 -408 minecraft:stone
fill 61 54 -408 62 54 -408 minecraft:stone
fill 69 54 -408 71 54 -408 minecraft:stone
fill 8 54 -407 25 54 -407 minecraft:stone
setblock 44 54 -407 minecraft:stone
fill 61 54 -407 62 54 -407 minecraft:stone
fill 67 54 -407 71 54 -407 minecraft:stone
fill 8 54 -406 25 54 -406 minecraft:stone
fill 66 54 -406 71 54 -406 minecraft:stone
fill 8 54 -405 24 54 -405 minecraft:stone
fill 60 54 -405 62 54 -405 minecraft:stone
fill 66 54 -405 71 54 -405 minecraft:stone
fill 8 54 -404 24 54 -404 minecraft:stone
fill 59 54 -404 62 54 -404 minecraft:stone
fill 66 54 -404 71 54 -404 minecraft:stone
fill 8 54 -403 24 54 -403 minecraft:stone
fill 48 54 -403 49 54 -403 minecraft:stone
fill 59 54 -403 62 54 -403 minecraft:stone
fill 65 54 -403 71 54 -403 minecraft:stone
fill 8 54 -402 24 54 -402 minecraft:stone
fill 43 54 -402 54 54 -402 minecraft:stone
fill 59 54 -402 62 54 -402 minecraft:stone
fill 64 54 -402 71 54 -402 minecraft:stone
fill 8 54 -401 24 54 -401 minecraft:stone
fill 42 54 -401 56 54 -401 minecraft:stone
fill 59 54 -401 62 54 -401 minecraft:stone
fill 64 54 -401 71 54 -401 minecraft:stone
fill 8 54 -400 23 54 -400 minecraft:stone
fill 59 54 -400 62 54 -400 minecraft:stone
fill 64 54 -400 71 54 -400 minecraft:stone
fill 8 54 -399 25 54 -399 minecraft:stone
fill 59 54 -399 71 54 -399 minecraft:stone
fill 8 54 -398 26 54 -398 minecraft:stone
fill 60 54 -398 71 54 -398 minecraft:stone
fill 8 54 -397 27 54 -397 minecraft:stone
fill 60 54 -397 71 54 -397 minecraft:stone
fill 8 54 -396 28 54 -396 minecraft:stone
fill 60 54 -396 71 54 -396 minecraft:stone
fill 8 54 -395 28 54 -395 minecraft:stone
fill 61 54 -395 71 54 -395 minecraft:stone
fill 8 54 -394 29 54 -394 minecraft:stone
fill 61 54 -394 71 54 -394 minecraft:stone
fill 8 54 -393 29 54 -393 minecraft:stone
fill 61 54 -393 71 54 -393 minecraft:stone
fill 8 54 -392 30 54 -392 minecraft:stone
fill 61 54 -392 71 54 -392 minecraft:stone
fill 8 54 -391 30 54 -391 minecraft:stone
fill 61 54 -391 71 54 -391 minecraft:stone
fill 8 54 -390 30 54 -390 minecraft:stone
fill 59 54 -390 71 54 -390 minecraft:stone
fill 8 54 -389 30 54 -389 minecraft:stone
fill 58 54 -389 71 54 -389 minecraft:stone
fill 8 54 -388 30 54 -388 minecraft:stone
fill 57 54 -388 71 54 -388 minecraft:stone
fill 8 54 -387 30 54 -387 minecraft:stone
fill 57 54 -387 71 54 -387 minecraft:stone
fill 8 54 -386 30 54 -386 minecraft:stone
fill 56 54 -386 71 54 -386 minecraft:stone
fill 8 54 -385 31 54 -385 minecraft:stone
fill 55 54 -385 71 54 -385 minecraft:stone
fill 8 54 -384 31 54 -384 minecraft:stone
fill 55 54 -384 71 54 -384 minecraft:stone
fill 8 54 -383 32 54 -383 minecraft:stone
fill 54 54 -383 71 54 -383 minecraft:stone
fill 44 55 -446 55 55 -446 minecraft:stone
fill 36 55 -445 57 55 -445 minecraft:stone
fill 33 55 -444 60 55 -444 minecraft:stone
fill 30 55 -443 60 55 -443 minecraft:stone
fill 28 55 -442 62 55 -442 minecraft:stone
fill 26 55 -441 64 55 -441 minecraft:stone
fill 25 55 -440 65 55 -440 minecraft:stone
fill 23 55 -439 66 55 -439 minecraft:stone
fill 22 55 -438 66 55 -438 minecraft:stone
fill 21 55 -437 66 55 -437 minecraft:stone
fill 20 55 -436 71 55 -436 minecraft:stone
fill 19 55 -435 71 55 -435 minecraft:stone
fill 18 55 -434 71 55 -434 minecraft:stone
fill 17 55 -433 71 55 -433 minecraft:stone
fill 16 55 -432 71 55 -432 minecraft:stone
fill 15 55 -431 71 55 -431 minecraft:stone
fill 15 55 -430 71 55 -430 minecraft:stone
fill 14 55 -429 71 55 -429 minecraft:stone
fill 13 55 -428 71 55 -428 minecraft:stone
fill 13 55 -427 71 55 -427 minecraft:stone
fill 12 55 -426 71 55 -426 minecraft:stone
fill 12 55 -425 71 55 -425 minecraft:stone
fill 11 55 -424 71 55 -424 minecraft:stone
fill 11 55 -423 71 55 -423 minecraft:stone
fill 11 55 -422 71 55 -422 minecraft:stone
fill 10 55 -421 71 55 -421 minecraft:stone
fill 10 55 -420 71 55 -420 minecraft:stone
fill 10 55 -419 71 55 -419 minecraft:stone
fill 9 55 -418 71 55 -418 minecraft:stone
fill 9 55 -417 71 55 -417 minecraft:stone
fill 9 55 -416 71 55 -416 minecraft:stone
fill 9 55 -415 71 55 -415 minecraft:stone
fill 9 55 -414 71 55 -414 minecraft:stone
fill 9 55 -413 71 55 -413 minecraft:stone
fill 9 55 -412 71 55 -412 minecraft:stone
fill 9 55 -411 71 55 -411 minecraft:stone
fill 8 55 -410 71 55 -410 minecraft:stone
fill 8 55 -409 71 55 -409 minecraft:stone
fill 8 55 -408 71 55 -408 minecraft:stone
fill 8 55 -407 71 55 -407 minecraft:stone
fill 8 55 -406 71 55 -406 minecraft:stone
fill 8 55 -405 71 55 -405 minecraft:stone
fill 8 55 -404 35 55 -404 minecraft:stone
fill 37 55 -404 71 55 -404 minecraft:stone
fill 8 55 -403 34 55 -403 minecraft:stone
fill 39 55 -403 71 55 -403 minecraft:stone
fill 8 55 -402 33 55 -402 minecraft:stone
fill 41 55 -402 71 55 -402 minecraft:stone
fill 8 55 -401 32 55 -401 minecraft:stone
fill 40 55 -401 71 55 -401 minecraft:stone
fill 8 55 -400 31 55 -400 minecraft:stone
fill 40 55 -400 44 55 -400 minecraft:stone
fill 50 55 -400 71 55 -400 minecraft:stone
fill 8 55 -399 32 55 -399 minecraft:stone
fill 60 55 -399 71 55 -399 minecraft:stone
fill 8 55 -398 33 55 -398 minecraft:stone
fill 60 55 -398 71 55 -398 minecraft:stone
fill 8 55 -397 33 55 -397 minecraft:stone
fill 60 55 -397 71 55 -397 minecraft:stone
fill 8 55 -396 33 55 -396 minecraft:stone
fill 61 55 -396 71 55 -396 minecraft:stone
fill 8 55 -395 33 55 -395 minecraft:stone
fill 61 55 -395 71 55 -395 minecraft:stone
fill 8 55 -394 34 55 -394 minecraft:stone
fill 61 55 -394 71 55 -394 minecraft:stone
fill 8 55 -393 34 55 -393 minecraft:stone
fill 61 55 -393 71 55 -393 minecraft:stone
fill 8 55 -392 34 55 -392 minecraft:stone
fill 61 55 -392 71 55 -392 minecraft:stone
fill 8 55 -391 34 55 -391 minecraft:stone
fill 58 55 -391 71 55 -391 minecraft:stone
fill 8 55 -390 34 55 -390 minecraft:stone
fill 57 55 -390 71 55 -390 minecraft:stone
fill 8 55 -389 35 55 -389 minecraft:stone
fill 56 55 -389 71 55 -389 minecraft:stone
fill 8 55 -388 35 55 -388 minecraft:stone
fill 55 55 -388 71 55 -388 minecraft:stone
fill 8 55 -387 36 55 -387 minecraft:stone
fill 55 55 -387 71 55 -387 minecraft:stone
fill 8 55 -386 37 55 -386 minecraft:stone
fill 54 55 -386 71 55 -386 minecraft:stone
fill 8 55 -385 38 55 -385 minecraft:stone
fill 54 55 -385 71 55 -385 minecraft:stone
fill 8 55 -384 40 55 -384 minecraft:stone
fill 54 55 -384 71 55 -384 minecraft:stone
fill 8 55 -383 41 55 -383 minecraft:stone
fill 51 55 -383 71 55 -383 minecraft:stone
fill 44 56 -446 55 56 -446 minecraft:stone
fill 36 56 -445 58 56 -445 minecraft:stone
fill 33 56 -444 60 56 -444 minecraft:stone
fill 30 56 -443 61 56 -443 minecraft:stone
fill 28 56 -442 63 56 -442 minecraft:stone
fill 26 56 -441 65 56 -441 minecraft:stone
fill 25 56 -440 67 56 -440 minecraft:stone
setblock 71 56 -440 minecraft:stone
fill 23 56 -439 67 56 -439 minecraft:stone
fill 69 56 -439 71 56 -439 minecraft:stone
fill 22 56 -438 71 56 -438 minecraft:stone
fill 21 56 -437 71 56 -437 minecraft:stone
fill 20 56 -436 71 56 -436 minecraft:stone
fill 19 56 -435 71 56 -435 minecraft:stone
fill 18 56 -434 71 56 -434 minecraft:stone
fill 17 56 -433 71 56 -433 minecraft:stone
fill 16 56 -432 71 56 -432 minecraft:stone
fill 15 56 -431 71 56 -431 minecraft:stone
fill 15 56 -430 71 56 -430 minecraft:stone
fill 14 56 -429 71 56 -429 minecraft:stone
fill 13 56 -428 71 56 -428 minecraft:stone
fill 13 56 -427 71 56 -427 minecraft:stone
fill 12 56 -426 71 56 -426 minecraft:stone
fill 12 56 -425 71 56 -425 minecraft:stone
fill 11 56 -424 71 56 -424 minecraft:stone
fill 11 56 -423 71 56 -423 minecraft:stone
fill 11 56 -422 71 56 -422 minecraft:stone
fill 10 56 -421 71 56 -421 minecraft:stone
fill 10 56 -420 71 56 -420 minecraft:stone
fill 10 56 -419 71 56 -419 minecraft:stone
fill 9 56 -418 71 56 -418 minecraft:stone
fill 9 56 -417 71 56 -417 minecraft:stone
fill 9 56 -416 71 56 -416 minecraft:stone
fill 9 56 -415 71 56 -415 minecraft:stone
fill 9 56 -414 71 56 -414 minecraft:stone
fill 9 56 -413 71 56 -413 minecraft:stone
fill 9 56 -412 71 56 -412 minecraft:stone
fill 9 56 -411 71 56 -411 minecraft:stone
fill 8 56 -410 71 56 -410 minecraft:stone
fill 8 56 -409 71 56 -409 minecraft:stone
fill 8 56 -408 71 56 -408 minecraft:stone
fill 8 56 -407 71 56 -407 minecraft:stone
fill 8 56 -406 71 56 -406 minecraft:stone
fill 8 56 -405 71 56 -405 minecraft:stone
fill 8 56 -404 71 56 -404 minecraft:stone
fill 8 56 -403 71 56 -403 minecraft:stone
fill 8 56 -402 71 56 -402 minecraft:stone
fill 8 56 -401 71 56 -401 minecraft:stone
fill 8 56 -400 71 56 -400 minecraft:stone
fill 8 56 -399 71 56 -399 minecraft:stone
fill 8 56 -398 71 56 -398 minecraft:stone
fill 8 56 -397 71 56 -397 minecraft:stone
fill 8 56 -396 71 56 -396 minecraft:stone
fill 8 56 -395 71 56 -395 minecraft:stone
fill 8 56 -394 42 56 -394 minecraft:stone
fill 50 56 -394 71 56 -394 minecraft:stone
fill 8 56 -393 40 56 -393 minecraft:stone
fill 52 56 -393 71 56 -393 minecraft:stone
fill 8 56 -392 40 56 -392 minecraft:stone
fill 53 56 -392 71 56 -392 minecraft:stone
fill 8 56 -391 41 56 -391 minecraft:stone
fill 53 56 -391 71 56 -391 minecraft:stone
fill 8 56 -390 41 56 -390 minecraft:stone
fill 52 56 -390 71 56 -390 minecraft:stone
fill 8 56 -389 41 56 -389 minecraft:stone
fill 52 56 -389 71 56 -389 minecraft:stone
fill 8 56 -388 42 56 -388 minecraft:stone
fill 52 56 -388 71 56 -388 minecraft:stone
fill 8 56 -387 43 56 -387 minecraft:stone
fill 51 56 -387 71 56 -387 minecraft:stone
fill 8 56 -386 44 56 -386 minecraft:stone
fill 51 56 -386 71 56 -386 minecraft:stone
fill 8 56 -385 46 56 -385 minecraft:stone
fill 50 56 -385 71 56 -385 minecraft:stone
fill 8 56 -384 47 56 -384 minecraft:stone
fill 49 56 -384 71 56 -384 minecraft:stone
fill 8 56 -383 71 56 -383 minecraft:stone
fill 44 57 -446 56 57 -446 minecraft:stone
fill 36 57 -445 58 57 -445 minecraft:stone
fill 33 57 -444 60 57 -444 minecraft:stone
fill 30 57 -443 62 57 -443 minecraft:stone
fill 28 57 -442 63 57 -442 minecraft:stone
setblock 71 57 -442 minecraft:stone
fill 26 57 -441 67 57 -441 minecraft:stone
fill 70 57 -441 71 57 -441 minecraft:stone
fill 25 57 -440 71 57 -440 minecraft:stone
fill 23 57 -439 71 57 -439 minecraft:stone
fill 22 57 -438 71 57 -438 minecraft:stone
fill 21 57 -437 71 57 -437 minecraft:stone
fill 20 57 -436 71 57 -436 minecraft:stone
fill 19 57 -435 71 57 -435 minecraft:stone
fill 18 57 -434 71 57 -434 minecraft:stone
fill 17 57 -433 71 57 -433 minecraft:stone
fill 16 57 -432 71 57 -432 minecraft:stone
fill 15 57 -431 71 57 -431 minecraft:stone
fill 15 57 -430 71 57 -430 minecraft:stone
fill 14 57 -429 71 57 -429 minecraft:stone
fill 13 57 -428 71 57 -428 minecraft:stone
fill 13 57 -427 71 57 -427 minecraft:stone
fill 12 57 -426 71 57 -426 minecraft:stone
fill 12 57 -425 71 57 -425 minecraft:stone
fill 11 57 -424 71 57 -424 minecraft:stone
fill 11 57 -423 71 57 -423 minecraft:stone
fill 11 57 -422 71 57 -422 minecraft:stone
fill 10 57 -421 71 57 -421 minecraft:stone
fill 10 57 -420 71 57 -420 minecraft:stone
fill 10 57 -419 71 57 -419 minecraft:stone
fill 9 57 -418 71 57 -418 minecraft:stone
fill 9 57 -417 71 57 -417 minecraft:stone
fill 9 57 -416 71 57 -416 minecraft:stone
fill 9 57 -415 71 57 -415 minecraft:stone
fill 9 57 -414 71 57 -414 minecraft:stone
fill 9 57 -413 71 57 -413 minecraft:stone
fill 9 57 -412 71 57 -412 minecraft:stone
fill 9 57 -411 71 57 -411 minecraft:stone
fill 8 57 -410 71 57 -410 minecraft:stone
fill 8 57 -409 71 57 -409 minecraft:stone
fill 8 57 -408 71 57 -408 minecraft:stone
fill 8 57 -407 71 57 -407 minecraft:stone
fill 8 57 -406 71 57 -406 minecraft:stone
fill 8 57 -405 71 57 -405 minecraft:stone
fill 8 57 -404 71 57 -404 minecraft:stone
fill 8 57 -403 71 57 -403 minecraft:stone
fill 8 57 -402 71 57 -402 minecraft:stone
fill 8 57 -401 71 57 -401 minecraft:stone
fill 8 57 -400 71 57 -400 minecraft:stone
fill 8 57 -399 71 57 -399 minecraft:stone
fill 8 57 -398 71 57 -398 minecraft:stone
fill 8 57 -397 71 57 -397 minecraft:stone
fill 8 57 -396 71 57 -396 minecraft:stone
fill 8 57 -395 71 57 -395 minecraft:stone
fill 8 57 -394 71 57 -394 minecraft:stone
fill 8 57 -393 71 57 -393 minecraft:stone
fill 8 57 -392 71 57 -392 minecraft:stone
fill 8 57 -391 71 57 -391 minecraft:stone
fill 8 57 -390 71 57 -390 minecraft:stone
fill 8 57 -389 71 57 -389 minecraft:stone
fill 8 57 -388 71 57 -388 minecraft:stone
fill 8 57 -387 71 57 -387 minecraft:stone
fill 8 57 -386 71 57 -386 minecraft:stone
fill 8 57 -385 71 57 -385 minecraft:stone
fill 8 57 -384 71 57 -384 minecraft:stone
fill 8 57 -383 71 57 -383 minecraft:stone
fill 44 58 -446 57 58 -446 minecraft:stone
fill 36 58 -445 59 58 -445 minecraft:stone
fill 33 58 -444 62 58 -444 minecraft:stone
setblock 71 58 -444 minecraft:stone
fill 30 58 -443 63 58 -443 minecraft:stone
setblock 71 58 -443 minecraft:stone
fill 28 58 -442 65 58 -442 minecraft:stone
fill 70 58 -442 71 58 -442 minecraft:stone
fill 26 58 -441 71 58 -441 minecraft:stone
fill 25 58 -440 71 58 -440 minecraft:stone
fill 23 58 -439 71 58 -439 minecraft:stone
fill 22 58 -438 71 58 -438 minecraft:stone
fill 21 58 -437 71 58 -437 minecraft:stone
fill 20 58 -436 71 58 -436 minecraft:stone
fill 19 58 -435 71 58 -435 minecraft:stone
fill 18 58 -434 71 58 -434 minecraft:stone
fill 17 58 -433 71 58 -433 minecraft:stone
fill 16 58 -432 71 58 -432 minecraft:stone
fill 15 58 -431 71 58 -431 minecraft:stone
fill 15 58 -430 71 58 -430 minecraft:stone
fill 14 58 -429 71 58 -429 minecraft:stone
fill 13 58 -428 71 58 -428 minecraft:stone
fill 13 58 -427 71 58 -427 minecraft:stone
fill 12 58 -426 71 58 -426 minecraft:stone
fill 12 58 -425 71 58 -425 minecraft:stone
fill 11 58 -424 71 58 -424 minecraft:stone
fill 11 58 -423 71 58 -423 minecraft:stone
fill 11 58 -422 71 58 -422 minecraft:stone
fill 10 58 -421 71 58 -421 minecraft:stone
fill 10 58 -420 71 58 -420 minecraft:stone
fill 10 58 -419 71 58 -419 minecraft:stone
fill 9 58 -418 71 58 -418 minecraft:stone
fill 9 58 -417 71 58 -417 minecraft:stone
fill 9 58 -416 71 58 -416 minecraft:stone
fill 9 58 -415 71 58 -415 minecraft:stone
fill 9 58 -414 71 58 -414 minecraft:stone
fill 9 58 -413 71 58 -413 minecraft:stone
fill 9 58 -412 71 58 -412 minecraft:stone
fill 9 58 -411 71 58 -411 minecraft:stone
fill 8 58 -410 71 58 -410 minecraft:stone
fill 8 58 -409 71 58 -409 minecraft:stone
fill 8 58 -408 71 58 -408 minecraft:stone
fill 8 58 -407 71 58 -407 minecraft:stone
fill 8 58 -406 71 58 -406 minecraft:stone
fill 8 58 -405 71 58 -405 minecraft:stone
fill 8 58 -404 71 58 -404 minecraft:stone
fill 8 58 -403 71 58 -403 minecraft:stone
fill 8 58 -402 71 58 -402 minecraft:stone
fill 8 58 -401 71 58 -401 minecraft:stone
fill 8 58 -400 71 58 -400 minecraft:stone
fill 8 58 -399 71 58 -399 minecraft:stone
fill 8 58 -398 71 58 -398 minecraft:stone
fill 8 58 -397 71 58 -397 minecraft:stone
fill 8 58 -396 71 58 -396 minecraft:stone
fill 8 58 -395 71 58 -395 minecraft:stone
fill 8 58 -394 71 58 -394 minecraft:stone
fill 8 58 -393 71 58 -393 minecraft:stone
fill 8 58 -392 71 58 -392 minecraft:stone
fill 8 58 -391 71 58 -391 minecraft:stone
fill 8 58 -390 71 58 -390 minecraft:stone
fill 8 58 -389 71 58 -389 minecraft:stone
fill 8 58 -388 71 58 -388 minecraft:stone
fill 8 58 -387 71 58 -387 minecraft:stone
fill 8 58 -386 71 58 -386 minecraft:stone
fill 8 58 -385 71 58 -385 minecraft:stone
fill 8 58 -384 71 58 -384 minecraft:stone
fill 8 58 -383 71 58 -383 minecraft:stone
fill 44 59 -446 57 59 -446 minecraft:stone
fill 36 59 -445 60 59 -445 minecraft:stone
fill 33 59 -444 62 59 -444 minecraft:stone
setblock 71 59 -444 minecraft:stone
fill 30 59 -443 63 59 -443 minecraft:stone
fill 70 59 -443 71 59 -443 minecraft:stone
fill 28 59 -442 67 59 -442 minecraft:stone
fill 69 59 -442 71 59 -442 minecraft:stone
fill 26 59 -441 71 59 -441 minecraft:stone
fill 25 59 -440 71 59 -440 minecraft:stone
fill 23 59 -439 71 59 -439 minecraft:stone
fill 22 59 -438 71 59 -438 minecraft:stone
fill 21 59 -437 71 59 -437 minecraft:stone
fill 20 59 -436 71 59 -436 minecraft:stone
fill 19 59 -435 71 59 -435 minecraft:stone
fill 18 59 -434 71 59 -434 minecraft:stone
fill 17 59 -433 71 59 -433 minecraft:stone
fill 16 59 -432 71 59 -432 minecraft:stone
fill 15 59 -431 71 59 -431 minecraft:stone
fill 15 59 -430 71 59 -430 minecraft:stone
fill 14 59 -429 71 59 -429 minecraft:stone
fill 13 59 -428 71 59 -428 minecraft:stone
fill 13 59 -427 71 59 -427 minecraft:stone
fill 12 59 -426 71 59 -426 minecraft:stone
fill 12 59 -425 71 59 -425 minecraft:stone
fill 11 59 -424 71 59 -424 minecraft:stone
fill 11 59 -423 71 59 -423 minecraft:stone
fill 11 59 -422 71 59 -422 minecraft:stone
fill 10 59 -421 71 59 -421 minecraft:stone
fill 10 59 -420 71 59 -420 minecraft:stone
fill 10 59 -419 71 59 -419 minecraft:stone
fill 9 59 -418 71 59 -418 minecraft:stone
fill 9 59 -417 71 59 -417 minecraft:stone
fill 9 59 -416 71 59 -416 minecraft:stone
fill 9 59 -415 71 59 -415 minecraft:stone
fill 9 59 -414 71 59 -414 minecraft:stone
fill 9 59 -413 71 59 -413 minecraft:stone
fill 9 59 -412 71 59 -412 minecraft:stone
fill 9 59 -411 71 59 -411 minecraft:stone
fill 8 59 -410 71 59 -410 minecraft:stone
fill 8 59 -409 71 59 -409 minecraft:stone
fill 8 59 -408 71 59 -408 minecraft:stone
fill 8 59 -407 71 59 -407 minecraft:stone
fill 8 59 -406 71 59 -406 minecraft:stone
fill 8 59 -405 71 59 -405 minecraft:stone
fill 8 59 -404 71 59 -404 minecraft:stone
fill 8 59 -403 71 59 -403 minecraft:stone
fill 8 59 -402 71 59 -402 minecraft:stone
fill 8 59 -401 71 59 -401 minecraft:stone
fill 8 59 -400 71 59 -400 minecraft:stone
fill 8 59 -399 71 59 -399 minecraft:stone
fill 8 59 -398 71 59 -398 minecraft:stone
fill 8 59 -397 71 59 -397 minecraft:stone
fill 8 59 -396 71 59 -396 minecraft:stone
fill 8 59 -395 71 59 -395 minecraft:stone
fill 8 59 -394 71 59 -394 minecraft:stone
fill 8 59 -393 71 59 -393 minecraft:stone
fill 8 59 -392 71 59 -392 minecraft:stone
fill 8 59 -391 71 59 -391 minecraft:stone
fill 8 59 -390 71 59 -390 minecraft:stone
fill 8 59 -389 71 59 -389 minecraft:stone
fill 8 59 -388 71 59 -388 minecraft:stone
fill 8 59 -387 71 59 -387 minecraft:stone
fill 8 59 -386 71 59 -386 minecraft:stone
fill 8 59 -385 71 59 -385 minecraft:stone
fill 8 59 -384 71 59 -384 minecraft:stone
fill 8 59 -383 71 59 -383 minecraft:stone
fill 44 60 -446 58 60 -446 minecraft:stone
fill 36 60 -445 61 60 -445 minecraft:stone
setblock 71 60 -445 minecraft:stone
fill 33 60 -444 63 60 -444 minecraft:stone
fill 70 60 -444 71 60 -444 minecraft:stone
fill 30 60 -443 67 60 -443 minecraft:stone
fill 69 60 -443 71 60 -443 minecraft:stone
fill 28 60 -442 71 60 -442 minecraft:stone
fill 26 60 -441 71 60 -441 minecraft:stone
fill 25 60 -440 71 60 -440 minecraft:stone
fill 23 60 -439 71 60 -439 minecraft:stone
fill 22 60 -438 71 60 -438 minecraft:stone
fill 21 60 -437 71 60 -437 minecraft:stone
fill 20 60 -436 71 60 -436 minecraft:stone
fill 19 60 -435 71 60 -435 minecraft:stone
fill 18 60 -434 71 60 -434 minecraft:stone
fill 17 60 -433 71 60 -433 minecraft:stone
fill 16 60 -432 71 60 -432 minecraft:stone
fill 15 60 -431 71 60 -431 minecraft:stone
fill 15 60 -430 71 60 -430 minecraft:stone
fill 14 60 -429 71 60 -429 minecraft:stone
fill 13 60 -428 71 60 -428 minecraft:stone
fill 13 60 -427 71 60 -427 minecraft:stone
fill 12 60 -426 71 60 -426 minecraft:stone
fill 12 60 -425 71 60 -425 minecraft:stone
fill 11 60 -424 71 60 -424 minecraft:stone
fill 11 60 -423 71 60 -423 minecraft:stone
fill 11 60 -422 71 60 -422 minecraft:stone
fill 10 60 -421 71 60 -421 minecraft:stone
fill 10 60 -420 71 60 -420 minecraft:stone
fill 10 60 -419 71 60 -419 minecraft:stone
fill 9 60 -418 71 60 -418 minecraft:stone
fill 9 60 -417 71 60 -417 minecraft:stone
fill 9 60 -416 71 60 -416 minecraft:stone
fill 9 60 -415 71 60 -415 minecraft:stone
fill 9 60 -414 71 60 -414 minecraft:stone
fill 9 60 -413 71 60 -413 minecraft:stone
fill 9 60 -412 71 60 -412 minecraft:stone
fill 9 60 -411 71 60 -411 minecraft:stone
fill 8 60 -410 71 60 -410 minecraft:stone
fill 8 60 -409 71 60 -409 minecraft:stone
fill 8 60 -408 71 60 -408 minecraft:stone
fill 8 60 -407 71 60 -407 minecraft:stone
fill 8 60 -406 71 60 -406 minecraft:stone
fill 8 60 -405 71 60 -405 minecraft:stone
fill 8 60 -404 71 60 -404 minecraft:stone
fill 8 60 -403 71 60 -403 minecraft:stone
fill 8 60 -402 71 60 -402 minecraft:stone
fill 8 60 -401 71 60 -401 minecraft:stone
fill 8 60 -400 71 60 -400 minecraft:stone
fill 8 60 -399 71 60 -399 minecraft:stone
fill 8 60 -398 71 60 -398 minecraft:stone
fill 8 60 -397 71 60 -397 minecraft:stone
fill 8 60 -396 71 60 -396 minecraft:stone
fill 8 60 -395 71 60 -395 minecraft:stone
fill 8 60 -394 71 60 -394 minecraft:stone
fill 8 60 -393 71 60 -393 minecraft:stone
fill 8 60 -392 71 60 -392 minecraft:stone
fill 8 60 -391 71 60 -391 minecraft:stone
fill 8 60 -390 71 60 -390 minecraft:stone
fill 8 60 -389 71 60 -389 minecraft:stone
fill 8 60 -388 71 60 -388 minecraft:stone
fill 8 60 -387 71 60 -387 minecraft:stone
fill 8 60 -386 71 60 -386 minecraft:stone
fill 8 60 -385 71 60 -385 minecraft:stone
fill 8 60 -384 71 60 -384 minecraft:stone
fill 8 60 -383 71 60 -383 minecraft:stone
fill 44 61 -446 59 61 -446 minecraft:stone
setblock 71 61 -446 minecraft:stone
fill 36 61 -445 62 61 -445 minecraft:stone
fill 70 61 -445 71 61 -445 minecraft:stone
fill 33 61 -444 63 61 -444 minecraft:stone
fill 69 61 -444 71 61 -444 minecraft:stone
fill 30 61 -443 71 61 -443 minecraft:stone
fill 28 61 -442 71 61 -442 minecraft:stone
fill 26 61 -441 71 61 -441 minecraft:stone
fill 25 61 -440 71 61 -440 minecraft:stone
fill 23 61 -439 71 61 -439 minecraft:stone
fill 22 61 -438 71 61 -438 minecraft:stone
fill 21 61 -437 71 61 -437 minecraft:stone
fill 20 61 -436 71 61 -436 minecraft:stone
fill 19 61 -435 71 61 -435 minecraft:stone
fill 18 61 -434 71 61 -434 minecraft:stone
fill 17 61 -433 71 61 -433 minecraft:stone
fill 16 61 -432 71 61 -432 minecraft:stone
fill 15 61 -431 71 61 -431 minecraft:stone
fill 15 61 -430 71 61 -430 minecraft:stone
fill 14 61 -429 71 61 -429 minecraft:stone
fill 13 61 -428 71 61 -428 minecraft:stone
fill 13 61 -427 71 61 -427 minecraft:stone
fill 12 61 -426 71 61 -426 minecraft:stone
fill 12 61 -425 71 61 -425 minecraft:stone
fill 11 61 -424 71 61 -424 minecraft:stone
fill 11 61 -423 71 61 -423 minecraft:stone
fill 11 61 -422 71 61 -422 minecraft:stone
fill 10 61 -421 71 61 -421 minecraft:stone
fill 10 61 -420 71 61 -420 minecraft:stone
fill 10 61 -419 71 61 -419 minecraft:stone
fill 9 61 -418 71 61 -418 minecraft:stone
fill 9 61 -417 71 61 -417 minecraft:stone
fill 9 61 -416 71 61 -416 minecraft:stone
fill 9 61 -415 71 61 -415 minecraft:stone
fill 9 61 -414 71 61 -414 minecraft:stone
fill 9 61 -413 71 61 -413 minecraft:stone
fill 9 61 -412 71 61 -412 minecraft:stone
fill 9 61 -411 71 61 -411 minecraft:stone
fill 8 61 -410 71 61 -410 minecraft:stone
fill 8 61 -409 71 61 -409 minecraft:stone
fill 8 61 -408 71 61 -408 minecraft:stone
fill 8 61 -407 71 61 -407 minecraft:stone
fill 8 61 -406 71 61 -406 minecraft:stone
fill 8 61 -405 71 61 -405 minecraft:stone
fill 8 61 -404 71 61 -404 minecraft:stone
fill 8 61 -403 71 61 -403 minecraft:stone
fill 8 61 -402 71 61 -402 minecraft:stone
fill 8 61 -401 71 61 -401 minecraft:stone
fill 8 61 -400 71 61 -400 minecraft:stone
fill 8 61 -399 71 61 -399 minecraft:stone
fill 8 61 -398 71 61 -398 minecraft:stone
fill 8 61 -397 71 61 -397 minecraft:stone
fill 8 61 -396 71 61 -396 minecraft:stone
fill 8 61 -395 71 61 -395 minecraft:stone
fill 8 61 -394 71 61 -394 minecraft:stone
fill 8 61 -393 71 61 -393 minecraft:stone
fill 8 61 -392 71 61 -392 minecraft:stone
fill 8 61 -391 71 61 -391 minecraft:stone
fill 8 61 -390 71 61 -390 minecraft:stone
fill 8 61 -389 71 61 -389 minecraft:stone
fill 8 61 -388 71 61 -388 minecraft:stone
fill 8 61 -387 71 61 -387 minecraft:stone
fill 8 61 -386 71 61 -386 minecraft:stone
fill 8 61 -385 71 61 -385 minecraft:stone
fill 8 61 -384 71 61 -384 minecraft:stone
fill 8 61 -383 71 61 -383 minecraft:stone
fill 44 62 -446 60 62 -446 minecraft:dirt
fill 70 62 -446 71 62 -446 minecraft:dirt
fill 36 62 -445 63 62 -445 minecraft:dirt
fill 69 62 -445 71 62 -445 minecraft:dirt
fill 33 62 -444 71 62 -444 minecraft:dirt
fill 30 62 -443 71 62 -443 minecraft:dirt
fill 28 62 -442 71 62 -442 minecraft:dirt
fill 26 62 -441 71 62 -441 minecraft:dirt
fill 25 62 -440 71 62 -440 minecraft:dirt
fill 23 62 -439 71 62 -439 minecraft:dirt
fill 22 62 -438 71 62 -438 minecraft:dirt
fill 21 62 -437 71 62 -437 minecraft:dirt
fill 20 62 -436 71 62 -436 minecraft:dirt
fill 19 62 -435 71 62 -435 minecraft:dirt
fill 18 62 -434 71 62 -434 minecraft:dirt
fill 17 62 -433 71 62 -433 minecraft:dirt
fill 16 62 -432 71 62 -432 minecraft:dirt
fill 15 62 -431 71 62 -431 minecraft:dirt
fill 15 62 -430 71 62 -430 minecraft:dirt
fill 14 62 -429 71 62 -429 minecraft:dirt
fill 13 62 -428 71 62 -428 minecraft:dirt
fill 13 62 -427 71 62 -427 minecraft:dirt
fill 12 62 -426 71 62 -426 minecraft:dirt
fill 12 62 -425 71 62 -425 minecraft:dirt
fill 11 62 -424 71 62 -424 minecraft:dirt
fill 11 62 -423 71 62 -423 minecraft:dirt
fill 11 62 -422 71 62 -422 minecraft:dirt
fill 10 62 -421 71 62 -421 minecraft:dirt
fill 10 62 -420 71 62 -420 minecraft:dirt
fill 10 62 -419 71 62 -419 minecraft:dirt
fill 9 62 -418 71 62 -418 minecraft:dirt
fill 9 62 -417 71 62 -417 minecraft:dirt
fill 9 62 -416 71 62 -416 minecraft:dirt
fill 9 62 -415 71 62 -415 minecraft:dirt
fill 9 62 -414 71 62 -414 minecraft:dirt
fill 9 62 -413 71 62 -413 minecraft:dirt
fill 9 62 -412 71 62 -412 minecraft:dirt
fill 9 62 -411 71 62 -411 minecraft:dirt
fill 8 62 -410 71 62 -410 minecraft:dirt
fill 8 62 -409 71 62 -409 minecraft:dirt
fill 8 62 -408 71 62 -408 minecraft:dirt
fill 8 62 -407 71 62 -407 minecraft:dirt
fill 8 62 -406 71 62 -406 minecraft:dirt
fill 8 62 -405 71 62 -405 minecraft:dirt
fill 8 62 -404 71 62 -404 minecraft:dirt
fill 8 62 -403 71 62 -403 minecraft:dirt
fill 8 62 -402 71 62 -402 minecraft:dirt
fill 8 62 -401 71 62 -401 minecraft:dirt
fill 8 62 -400 71 62 -400 minecraft:dirt
fill 8 62 -399 71 62 -399 minecraft:dirt
fill 8 62 -398 71 62 -398 minecraft:dirt
fill 8 62 -397 71 62 -397 minecraft:dirt
fill 8 62 -396 71 62 -396 minecraft:dirt
fill 8 62 -395 71 62 -395 minecraft:dirt
fill 8 62 -394 71 62 -394 minecraft:dirt
fill 8 62 -393 71 62 -393 minecraft:dirt
fill 8 62 -392 71 62 -392 minecraft:dirt
fill 8 62 -391 71 62 -391 minecraft:dirt
fill 8 62 -390 71 62 -390 minecraft:dirt
fill 8 62 -389 71 62 -389 minecraft:dirt
fill 8 62 -388 71 62 -388 minecraft:dirt
fill 8 62 -387 71 62 -387 minecraft:dirt
fill 8 62 -386 71 62 -386 minecraft:dirt
fill 8 62 -385 71 62 -385 minecraft:dirt
fill 8 62 -384 71 62 -384 minecraft:dirt
fill 8 62 -383 71 62 -383 minecraft:dirt
fill 44 63 -446 62 63 -446 minecraft:dirt
fill 69 63 -446 71 63 -446 minecraft:dirt
fill 36 63 -445 71 63 -445 minecraft:dirt
fill 33 63 -444 71 63 -444 minecraft:dirt
fill 30 63 -443 71 63 -443 minecraft:dirt
fill 28 63 -442 71 63 -442 minecraft:dirt
fill 26 63 -441 71 63 -441 minecraft:dirt
fill 25 63 -440 71 63 -440 minecraft:dirt
fill 23 63 -439 71 63 -439 minecraft:dirt
fill 22 63 -438 71 63 -438 minecraft:dirt
fill 21 63 -437 71 63 -437 minecraft:dirt
fill 20 63 -436 71 63 -436 minecraft:dirt
fill 19 63 -435 71 63 -435 minecraft:dirt
fill 18 63 -434 71 63 -434 minecraft:dirt
fill 17 63 -433 71 63 -433 minecraft:dirt
fill 16 63 -432 71 63 -432 minecraft:dirt
fill 15 63 -431 71 63 -431 minecraft:dirt
fill 15 63 -430 71 63 -430 minecraft:dirt
fill 14 63 -429 71 63 -429 minecraft:dirt
fill 13 63 -428 71 63 -428 minecraft:dirt
fill 13 63 -427 71 63 -427 minecraft:dirt
fill 12 63 -426 71 63 -426 minecraft:dirt
fill 12 63 -425 71 63 -425 minecraft:dirt
fill 11 63 -424 71 63 -424 minecraft:dirt
fill 11 63 -423 71 63 -423 minecraft:dirt
fill 11 63 -422 71 63 -422 minecraft:dirt
fill 10 63 -421 71 63 -421 minecraft:dirt
fill 10 63 -420 71 63 -420 minecraft:dirt
fill 10 63 -419 71 63 -419 minecraft:dirt
fill 9 63 -418 71 63 -418 minecraft:dirt
fill 9 63 -417 71 63 -417 minecraft:dirt
fill 9 63 -416 71 63 -416 minecraft:dirt
fill 9 63 -415 71 63 -415 minecraft:dirt
fill 9 63 -414 71 63 -414 minecraft:dirt
fill 9 63 -413 71 63 -413 minecraft:dirt
fill 9 63 -412 71 63 -412 minecraft:dirt
fill 9 63 -411 71 63 -411 minecraft:dirt
fill 8 63 -410 71 63 -410 minecraft:dirt
fill 8 63 -409 71 63 -409 minecraft:dirt
fill 8 63 -408 71 63 -408 minecraft:dirt
fill 8 63 -407 71 63 -407 minecraft:dirt
fill 8 63 -406 71 63 -406 minecraft:dirt
fill 8 63 -405 71 63 -405 minecraft:dirt
fill 8 63 -404 71 63 -404 minecraft:dirt
fill 8 63 -403 71 63 -403 minecraft:dirt
fill 8 63 -402 71 63 -402 minecraft:dirt
fill 8 63 -401 71 63 -401 minecraft:dirt
fill 8 63 -400 71 63 -400 minecraft:dirt
fill 8 63 -399 71 63 -399 minecraft:dirt
fill 8 63 -398 71 63 -398 minecraft:dirt
fill 8 63 -397 71 63 -397 minecraft:dirt
fill 8 63 -396 71 63 -396 minecraft:dirt
fill 8 63 -395 71 63 -395 minecraft:dirt
fill 8 63 -394 71 63 -394 minecraft:dirt
fill 8 63 -393 71 63 -393 minecraft:dirt
fill 8 63 -392 71 63 -392 minecraft:dirt
fill 8 63 -391 71 63 -391 minecraft:dirt
fill 8 63 -390 71 63 -390 minecraft:dirt
fill 8 63 -389 71 63 -389 minecraft:dirt
fill 8 63 -388 71 63 -388 minecraft:dirt
fill 8 63 -387 71 63 -387 minecraft:dirt
fill 8 63 -386 71 63 -386 minecraft:dirt
fill 8 63 -385 71 63 -385 minecraft:dirt
fill 8 63 -384 71 63 -384 minecraft:dirt
fill 8 63 -383 71 63 -383 minecraft:dirt
fill 44 64 -446 63 64 -446 minecraft:dirt
fill 66 64 -446 71 64 -446 minecraft:dirt
fill 36 64 -445 71 64 -445 minecraft:dirt
fill 33 64 -444 71 64 -444 minecraft:dirt
fill 30 64 -443 71 64 -443 minecraft:dirt
fill 28 64 -442 71 64 -442 minecraft:dirt
fill 26 64 -441 71 64 -441 minecraft:dirt
fill 25 64 -440 71 64 -440 minecraft:dirt
fill 23 64 -439 71 64 -439 minecraft:dirt
fill 22 64 -438 71 64 -438 minecraft:dirt
fill 21 64 -437 71 64 -437 minecraft:dirt
fill 20 64 -436 71 64 -436 minecraft:dirt
fill 19 64 -435 71 64 -435 minecraft:dirt
fill 18 64 -434 71 64 -434 minecraft:dirt
fill 17 64 -433 71 64 -433 minecraft:dirt
fill 16 64 -432 71 64 -432 minecraft:dirt
fill 15 64 -431 71 64 -431 minecraft:dirt
fill 15 64 -430 71 64 -430 minecraft:dirt
fill 14 64 -429 71 64 -429 minecraft:dirt
fill 13 64 -428 71 64 -428 minecraft:dirt
fill 13 64 -427 71 64 -427 minecraft:dirt
fill 12 64 -426 71 64 -426 minecraft:dirt
fill 12 64 -425 71 64 -425 minecraft:dirt
fill 11 64 -424 71 64 -424 minecraft:dirt
fill 11 64 -423 71 64 -423 minecraft:dirt
fill 11 64 -422 71 64 -422 minecraft:dirt
fill 10 64 -421 71 64 -421 minecraft:dirt
fill 10 64 -420 71 64 -420 minecraft:dirt
fill 10 64 -419 71 64 -419 minecraft:dirt
fill 9 64 -418 71 64 -418 minecraft:dirt
fill 9 64 -417 71 64 -417 minecraft:dirt
fill 9 64 -416 71 64 -416 minecraft:dirt
fill 9 64 -415 71 64 -415 minecraft:dirt
fill 9 64 -414 71 64 -414 minecraft:dirt
fill 9 64 -413 71 64 -413 minecraft:dirt
fill 9 64 -412 71 64 -412 minecraft:dirt
fill 9 64 -411 71 64 -411 minecraft:dirt
fill 8 64 -410 71 64 -410 minecraft:dirt
fill 8 64 -409 71 64 -409 minecraft:dirt
fill 8 64 -408 71 64 -408 minecraft:dirt
fill 8 64 -407 71 64 -407 minecraft:dirt
fill 8 64 -406 71 64 -406 minecraft:dirt
fill 8 64 -405 71 64 -405 minecraft:dirt
fill 8 64 -404 71 64 -404 minecraft:dirt
fill 8 64 -403 71 64 -403 minecraft:dirt
fill 8 64 -402 71 64 -402 minecraft:dirt
fill 8 64 -401 71 64 -401 minecraft:dirt
fill 8 64 -400 71 64 -400 minecraft:dirt
fill 8 64 -399 71 64 -399 minecraft:dirt
fill 8 64 -398 71 64 -398 minecraft:dirt
fill 8 64 -397 71 64 -397 minecraft:dirt
fill 8 64 -396 71 64 -396 minecraft:dirt
fill 8 64 -395 71 64 -395 minecraft:dirt
fill 8 64 -394 71 64 -394 minecraft:dirt
fill 8 64 -393 71 64 -393 minecraft:dirt
fill 8 64 -392 71 64 -392 minecraft:dirt
fill 8 64 -391 71 64 -391 minecraft:dirt
fill 8 64 -390 71 64 -390 minecraft:dirt
fill 8 64 -389 71 64 -389 minecraft:dirt
fill 8 64 -388 71 64 -388 minecraft:dirt
fill 8 64 -387 71 64 -387 minecraft:dirt
fill 8 64 -386 71 64 -386 minecraft:dirt
fill 8 64 -385 71 64 -385 minecraft:dirt
fill 8 64 -384 71 64 -384 minecraft:dirt
fill 8 64 -383 71 64 -383 minecraft:dirt
fill 44 65 -446 71 65 -446 minecraft:light_gray_concrete
fill 36 65 -445 48 65 -445 minecraft:light_gray_concrete
setblock 49 65 -445 minecraft:sea_lantern
fill 50 65 -445 57 65 -445 minecraft:light_gray_concrete
setblock 58 65 -445 minecraft:sea_lantern
fill 59 65 -445 66 65 -445 minecraft:light_gray_concrete
setblock 67 65 -445 minecraft:sea_lantern
fill 68 65 -445 71 65 -445 minecraft:light_gray_concrete
fill 33 65 -444 38 65 -444 minecraft:light_gray_concrete
setblock 39 65 -444 minecraft:sea_lantern
fill 40 65 -444 47 65 -444 minecraft:light_gray_concrete
setblock 48 65 -444 minecraft:sea_lantern
fill 49 65 -444 56 65 -444 minecraft:light_gray_concrete
setblock 57 65 -444 minecraft:sea_lantern
fill 58 65 -444 65 65 -444 minecraft:light_gray_concrete
setblock 66 65 -444 minecraft:sea_lantern
fill 67 65 -444 71 65 -444 minecraft:light_gray_concrete
fill 30 65 -443 37 65 -443 minecraft:light_gray_concrete
setblock 38 65 -443 minecraft:sea_lantern
fill 39 65 -443 46 65 -443 minecraft:light_gray_concrete
setblock 47 65 -443 minecraft:sea_lantern
fill 48 65 -443 55 65 -443 minecraft:light_gray_concrete
setblock 56 65 -443 minecraft:sea_lantern
fill 57 65 -443 64 65 -443 minecraft:light_gray_concrete
setblock 65 65 -443 minecraft:sea_lantern
fill 66 65 -443 71 65 -443 minecraft:light_gray_concrete
fill 28 65 -442 36 65 -442 minecraft:light_gray_concrete
setblock 37 65 -442 minecraft:sea_lantern
fill 38 65 -442 45 65 -442 minecraft:light_gray_concrete
setblock 46 65 -442 minecraft:sea_lantern
fill 47 65 -442 54 65 -442 minecraft:light_gray_concrete
setblock 55 65 -442 minecraft:sea_lantern
fill 56 65 -442 63 65 -442 minecraft:light_gray_concrete
setblock 64 65 -442 minecraft:sea_lantern
fill 65 65 -442 71 65 -442 minecraft:light_gray_concrete
fill 26 65 -441 35 65 -441 minecraft:light_gray_concrete
setblock 36 65 -441 minecraft:sea_lantern
fill 37 65 -441 43 65 -441 minecraft:light_gray_concrete
fill 44 65 -441 71 65 -441 minecraft:smooth_quartz
setblock 25 65 -440 minecraft:light_gray_concrete
setblock 26 65 -440 minecraft:sea_lantern
fill 27 65 -440 34 65 -440 minecraft:light_gray_concrete
setblock 35 65 -440 minecraft:sea_lantern
setblock 36 65 -440 minecraft:light_gray_concrete
fill 37 65 -440 43 65 -440 minecraft:smooth_quartz
fill 44 65 -440 71 65 -440 minecraft:grass_block
fill 23 65 -439 24 65 -439 minecraft:light_gray_concrete
setblock 25 65 -439 minecraft:sea_lantern
fill 26 65 -439 33 65 -439 minecraft:light_gray_concrete
fill 34 65 -439 36 65 -439 minecraft:smooth_quartz
fill 37 65 -439 71 65 -439 minecraft:grass_block
fill 22 65 -438 23 65 -438 minecraft:light_gray_concrete
setblock 24 65 -438 minecraft:sea_lantern
fill 25 65 -438 30 65 -438 minecraft:light_gray_concrete
fill 31 65 -438 33 65 -438 minecraft:smooth_quartz
fill 34 65 -438 71 65 -438 minecraft:grass_block
fill 21 65 -437 22 65 -437 minecraft:light_gray_concrete
setblock 23 65 -437 minecraft:sea_lantern
fill 24 65 -437 28 65 -437 minecraft:light_gray_concrete
fill 29 65 -437 30 65 -437 minecraft:smooth_quartz
fill 31 65 -437 71 65 -437 minecraft:grass_block
fill 20 65 -436 21 65 -436 minecraft:light_gray_concrete
setblock 22 65 -436 minecraft:sea_lantern
fill 23 65 -436 27 65 -436 minecraft:light_gray_concrete
fill 28 65 -436 29 65 -436 minecraft:smooth_quartz
fill 30 65 -436 71 65 -436 minecraft:grass_block
fill 19 65 -435 20 65 -435 minecraft:light_gray_concrete
setblock 21 65 -435 minecraft:sea_lantern
fill 22 65 -435 25 65 -435 minecraft:light_gray_concrete
fill 26 65 -435 27 65 -435 minecraft:smooth_quartz
fill 28 65 -435 71 65 -435 minecraft:grass_block
fill 18 65 -434 19 65 -434 minecraft:light_gray_concrete
setblock 20 65 -434 minecraft:sea_lantern
fill 21 65 -434 24 65 -434 minecraft:light_gray_concrete
setblock 25 65 -434 minecraft:smooth_quartz
fill 26 65 -434 71 65 -434 minecraft:grass_block
fill 17 65 -433 18 65 -433 minecraft:light_gray_concrete
setblock 19 65 -433 minecraft:sea_lantern
fill 20 65 -433 23 65 -433 minecraft:light_gray_concrete
setblock 24 65 -433 minecraft:smooth_quartz
fill 25 65 -433 71 65 -433 minecraft:grass_block
fill 16 65 -432 17 65 -432 minecraft:light_gray_concrete
setblock 18 65 -432 minecraft:sea_lantern
fill 19 65 -432 22 65 -432 minecraft:light_gray_concrete
setblock 23 65 -432 minecraft:smooth_quartz
fill 24 65 -432 71 65 -432 minecraft:grass_block
fill 15 65 -431 16 65 -431 minecraft:light_gray_concrete
setblock 17 65 -431 minecraft:sea_lantern
fill 18 65 -431 21 65 -431 minecraft:light_gray_concrete
setblock 22 65 -431 minecraft:smooth_quartz
fill 23 65 -431 71 65 -431 minecraft:grass_block
setblock 15 65 -430 minecraft:light_gray_concrete
setblock 16 65 -430 minecraft:sea_lantern
fill 17 65 -430 20 65 -430 minecraft:light_gray_concrete
setblock 21 65 -430 minecraft:smooth_quartz
fill 22 65 -430 71 65 -430 minecraft:grass_block
setblock 14 65 -429 minecraft:light_gray_concrete
setblock 15 65 -429 minecraft:sea_lantern
fill 16 65 -429 19 65 -429 minecraft:light_gray_concrete
setblock 20 65 -429 minecraft:smooth_quartz
fill 21 65 -429 71 65 -429 minecraft:grass_block
setblock 13 65 -428 minecraft:light_gray_concrete
setblock 14 65 -428 minecraft:sea_lantern
fill 15 65 -428 18 65 -428 minecraft:light_gray_concrete
setblock 19 65 -428 minecraft:smooth_quartz
fill 20 65 -428 71 65 -428 minecraft:grass_block
fill 13 65 -427 18 65 -427 minecraft:light_gray_concrete
setblock 19 65 -427 minecraft:smooth_quartz
fill 20 65 -427 71 65 -427 minecraft:grass_block
fill 12 65 -426 17 65 -426 minecraft:light_gray_concrete
setblock 18 65 -426 minecraft:smooth_quartz
fill 19 65 -426 71 65 -426 minecraft:grass_block
fill 12 65 -425 16 65 -425 minecraft:light_gray_concrete
fill 17 65 -425 18 65 -425 minecraft:smooth_quartz
fill 19 65 -425 71 65 -425 minecraft:grass_block
fill 11 65 -424 16 65 -424 minecraft:light_gray_concrete
setblock 17 65 -424 minecraft:smooth_quartz
fill 18 65 -424 71 65 -424 minecraft:grass_block
fill 11 65 -423 15 65 -423 minecraft:light_gray_concrete
setblock 16 65 -423 minecraft:smooth_quartz
fill 17 65 -423 71 65 -423 minecraft:grass_block
fill 11 65 -422 15 65 -422 minecraft:light_gray_concrete
setblock 16 65 -422 minecraft:smooth_quartz
fill 17 65 -422 71 65 -422 minecraft:grass_block
fill 10 65 -421 15 65 -421 minecraft:light_gray_concrete
setblock 16 65 -421 minecraft:smooth_quartz
fill 17 65 -421 71 65 -421 minecraft:grass_block
fill 10 65 -420 14 65 -420 minecraft:light_gray_concrete
setblock 15 65 -420 minecraft:smooth_quartz
fill 16 65 -420 71 65 -420 minecraft:grass_block
fill 10 65 -419 13 65 -419 minecraft:light_gray_concrete
setblock 14 65 -419 minecraft:sea_lantern
setblock 15 65 -419 minecraft:smooth_quartz
fill 16 65 -419 71 65 -419 minecraft:grass_block
fill 9 65 -418 12 65 -418 minecraft:light_gray_concrete
setblock 13 65 -418 minecraft:sea_lantern
setblock 14 65 -418 minecraft:light_gray_concrete
setblock 15 65 -418 minecraft:smooth_quartz
fill 16 65 -418 71 65 -418 minecraft:grass_block
fill 9 65 -417 11 65 -417 minecraft:light_gray_concrete
setblock 12 65 -417 minecraft:sea_lantern
setblock 13 65 -417 minecraft:light_gray_concrete
setblock 14 65 -417 minecraft:smooth_quartz
fill 15 65 -417 71 65 -417 minecraft:grass_block
fill 9 65 -416 10 65 -416 minecraft:light_gray_concrete
setblock 11 65 -416 minecraft:sea_lantern
fill 12 65 -416 13 65 -416 minecraft:light_gray_concrete
setblock 14 65 -416 minecraft:smooth_quartz
fill 15 65 -416 71 65 -416 minecraft:grass_block
setblock 9 65 -415 minecraft:light_gray_concrete
setblock 10 65 -415 minecraft:sea_lantern
fill 11 65 -415 13 65 -415 minecraft:light_gray_concrete
setblock 14 65 -415 minecraft:smooth_quartz
fill 15 65 -415 71 65 -415 minecraft:grass_block
fill 9 65 -414 13 65 -414 minecraft:light_gray_concrete
setblock 14 65 -414 minecraft:smooth_quartz
fill 15 65 -414 71 65 -414 minecraft:grass_block
fill 9 65 -413 13 65 -413 minecraft:light_gray_concrete
setblock 14 65 -413 minecraft:smooth_quartz
fill 15 65 -413 71 65 -413 minecraft:grass_block
fill 9 65 -412 13 65 -412 minecraft:light_gray_concrete
setblock 14 65 -412 minecraft:smooth_quartz
fill 15 65 -412 71 65 -412 minecraft:grass_block
fill 9 65 -411 13 65 -411 minecraft:light_gray_concrete
setblock 14 65 -411 minecraft:smooth_quartz
fill 15 65 -411 71 65 -411 minecraft:grass_block
fill 8 65 -410 12 65 -410 minecraft:light_gray_concrete
setblock 13 65 -410 minecraft:smooth_quartz
fill 14 65 -410 71 65 -410 minecraft:grass_block
fill 8 65 -409 12 65 -409 minecraft:light_gray_concrete
setblock 13 65 -409 minecraft:smooth_quartz
fill 14 65 -409 71 65 -409 minecraft:grass_block
fill 8 65 -408 11 65 -408 minecraft:light_gray_concrete
setblock 12 65 -408 minecraft:sea_lantern
setblock 13 65 -408 minecraft:smooth_quartz
fill 14 65 -408 71 65 -408 minecraft:grass_block
fill 8 65 -407 10 65 -407 minecraft:light_gray_concrete
setblock 11 65 -407 minecraft:sea_lantern
setblock 12 65 -407 minecraft:light_gray_concrete
setblock 13 65 -407 minecraft:smooth_quartz
fill 14 65 -407 71 65 -407 minecraft:grass_block
fill 8 65 -406 9 65 -406 minecraft:light_gray_concrete
setblock 10 65 -406 minecraft:sea_lantern
fill 11 65 -406 12 65 -406 minecraft:light_gray_concrete
setblock 13 65 -406 minecraft:smooth_quartz
fill 14 65 -406 71 65 -406 minecraft:grass_block
setblock 8 65 -405 minecraft:light_gray_concrete
setblock 9 65 -405 minecraft:sea_lantern
fill 10 65 -405 12 65 -405 minecraft:light_gray_concrete
setblock 13 65 -405 minecraft:smooth_quartz
fill 14 65 -405 71 65 -405 minecraft:grass_block
fill 8 65 -404 12 65 -404 minecraft:light_gray_concrete
setblock 13 65 -404 minecraft:smooth_quartz
fill 14 65 -404 71 65 -404 minecraft:grass_block
fill 8 65 -403 12 65 -403 minecraft:light_gray_concrete
setblock 13 65 -403 minecraft:smooth_quartz
fill 14 65 -403 71 65 -403 minecraft:grass_block
fill 8 65 -402 12 65 -402 minecraft:light_gray_concrete
setblock 13 65 -402 minecraft:smooth_quartz
fill 14 65 -402 71 65 -402 minecraft:grass_block
fill 8 65 -401 12 65 -401 minecraft:light_gray_concrete
setblock 13 65 -401 minecraft:smooth_quartz
fill 14 65 -401 71 65 -401 minecraft:grass_block
fill 8 65 -400 12 65 -400 minecraft:light_gray_concrete
setblock 13 65 -400 minecraft:smooth_quartz
fill 14 65 -400 71 65 -400 minecraft:grass_block
fill 8 65 -399 11 65 -399 minecraft:light_gray_concrete
setblock 12 65 -399 minecraft:sea_lantern
setblock 13 65 -399 minecraft:smooth_quartz
fill 14 65 -399 71 65 -399 minecraft:grass_block
fill 8 65 -398 10 65 -398 minecraft:light_gray_concrete
setblock 11 65 -398 minecraft:sea_lantern
setblock 12 65 -398 minecraft:light_gray_concrete
setblock 13 65 -398 minecraft:smooth_quartz
fill 14 65 -398 71 65 -398 minecraft:grass_block
fill 8 65 -397 9 65 -397 minecraft:light_gray_concrete
setblock 10 65 -397 minecraft:sea_lantern
fill 11 65 -397 12 65 -397 minecraft:light_gray_concrete
setblock 13 65 -397 minecraft:smooth_quartz
fill 14 65 -397 71 65 -397 minecraft:grass_block
setblock 8 65 -396 minecraft:light_gray_concrete
setblock 9 65 -396 minecraft:sea_lantern
fill 10 65 -396 12 65 -396 minecraft:light_gray_concrete
setblock 13 65 -396 minecraft:smooth_quartz
fill 14 65 -396 71 65 -396 minecraft:grass_block
fill 8 65 -395 12 65 -395 minecraft:light_gray_concrete
setblock 13 65 -395 minecraft:smooth_quartz
fill 14 65 -395 71 65 -395 minecraft:grass_block
fill 8 65 -394 12 65 -394 minecraft:light_gray_concrete
setblock 13 65 -394 minecraft:smooth_quartz
fill 14 65 -394 71 65 -394 minecraft:grass_block
fill 8 65 -393 12 65 -393 minecraft:light_gray_concrete
setblock 13 65 -393 minecraft:smooth_quartz
fill 14 65 -393 71 65 -393 minecraft:grass_block
fill 8 65 -392 12 65 -392 minecraft:light_gray_concrete
setblock 13 65 -392 minecraft:smooth_quartz
fill 14 65 -392 71 65 -392 minecraft:grass_block
fill 8 65 -391 12 65 -391 minecraft:light_gray_concrete
setblock 13 65 -391 minecraft:smooth_quartz
fill 14 65 -391 71 65 -391 minecraft:grass_block
fill 8 65 -390 11 65 -390 minecraft:light_gray_concrete
setblock 12 65 -390 minecraft:sea_lantern
setblock 13 65 -390 minecraft:smooth_quartz
fill 14 65 -390 71 65 -390 minecraft:grass_block
fill 8 65 -389 10 65 -389 minecraft:light_gray_concrete
setblock 11 65 -389 minecraft:sea_lantern
setblock 12 65 -389 minecraft:light_gray_concrete
setblock 13 65 -389 minecraft:smooth_quartz
fill 14 65 -389 71 65 -389 minecraft:grass_block
fill 8 65 -388 9 65 -388 minecraft:light_gray_concrete
setblock 10 65 -388 minecraft:sea_lantern
fill 11 65 -388 12 65 -388 minecraft:light_gray_concrete
setblock 13 65 -388 minecraft:smooth_quartz
fill 14 65 -388 71 65 -388 minecraft:grass_block
setblock 8 65 -387 minecraft:light_gray_concrete
setblock 9 65 -387 minecraft:sea_lantern
fill 10 65 -387 12 65 -387 minecraft:light_gray_concrete
setblock 13 65 -387 minecraft:smooth_quartz
fill 14 65 -387 71 65 -387 minecraft:grass_block
fill 8 65 -386 12 65 -386 minecraft:light_gray_concrete
setblock 13 65 -386 minecraft:smooth_quartz
fill 14 65 -386 71 65 -386 minecraft:grass_block
fill 8 65 -385 12 65 -385 minecraft:light_gray_concrete
setblock 13 65 -385 minecraft:smooth_quartz
fill 14 65 -385 71 65 -385 minecraft:grass_block
fill 8 65 -384 12 65 -384 minecraft:light_gray_concrete
setblock 13 65 -384 minecraft:smooth_quartz
fill 14 65 -384 71 65 -384 minecraft:grass_block
fill 8 65 -383 12 65 -383 minecraft:light_gray_concrete
setblock 13 65 -383 minecraft:smooth_quartz
fill 14 65 -383 71 65 -383 minecraft:grass_block
setblock 52 66 -436 minecraft:oak_log
setblock 62 66 -436 minecraft:oak_log
setblock 40 66 -435 minecraft:oak_log
setblock 26 66 -428 minecraft:oak_log
setblock 20 66 -420 minecraft:oak_log
setblock 18 66 -409 minecraft:oak_log
setblock 18 66 -399 minecraft:oak_log
setblock 18 66 -389 minecraft:oak_log
setblock 52 67 -436 minecraft:oak_log
setblock 62 67 -436 minecraft:oak_log
setblock 40 67 -435 minecraft:oak_log
setblock 26 67 -428 minecraft:oak_log
setblock 20 67 -420 minecraft:oak_log
setblock 18 67 -409 minecraft:oak_log
setblock 18 67 -399 minecraft:oak_log
setblock 18 67 -389 minecraft:oak_log
setblock 52 68 -436 minecraft:oak_log
setblock 62 68 -436 minecraft:oak_log
setblock 40 68 -435 minecraft:oak_log
setblock 26 68 -428 minecraft:oak_log
setblock 20 68 -420 minecraft:oak_log
setblock 18 68 -409 minecraft:oak_log
setblock 18 68 -399 minecraft:oak_log
setblock 18 68 -389 minecraft:oak_log
setblock 52 69 -438 minecraft:oak_leaves[persistent=true]
setblock 62 69 -438 minecraft:oak_leaves[persistent=true]
setblock 40 69 -437 minecraft:oak_leaves[persistent=true]
fill 51 69 -437 53 69 -437 minecraft:oak_leaves[persistent=true]
fill 61 69 -437 63 69 -437 minecraft:oak_leaves[persistent=true]
setblock 71 69 -437 minecraft:oak_leaves[persistent=true]
fill 39 69 -436 41 69 -436 minecraft:oak_leaves[persistent=true]
fill 50 69 -436 51 69 -436 minecraft:oak_leaves[persistent=true]
setblock 52 69 -436 minecraft:oak_log
fill 53 69 -436 54 69 -436 minecraft:oak_leaves[persistent=true]
fill 60 69 -436 61 69 -436 minecraft:oak_leaves[persistent=true]
setblock 62 69 -436 minecraft:oak_log
fill 63 69 -436 64 69 -436 minecraft:oak_leaves[persistent=true]
fill 70 69 -436 71 69 -436 minecraft:oak_leaves[persistent=true]
fill 38 69 -435 39 69 -435 minecraft:oak_leaves[persistent=true]
setblock 40 69 -435 minecraft:oak_log
fill 41 69 -435 42 69 -435 minecraft:oak_leaves[persistent=true]
fill 51 69 -435 53 69 -435 minecraft:oak_leaves[persistent=true]
fill 61 69 -435 63 69 -435 minecraft:oak_leaves[persistent=true]
setblock 71 69 -435 minecraft:oak_leaves[persistent=true]
fill 39 69 -434 41 69 -434 minecraft:oak_leaves[persistent=true]
setblock 52 69 -434 minecraft:oak_leaves[persistent=true]
setblock 62 69 -434 minecraft:oak_leaves[persistent=true]
setblock 40 69 -433 minecraft:oak_leaves[persistent=true]
setblock 26 69 -430 minecraft:oak_leaves[persistent=true]
fill 25 69 -429 27 69 -429 minecraft:oak_leaves[persistent=true]
fill 24 69 -428 25 69 -428 minecraft:oak_leaves[persistent=true]
setblock 26 69 -428 minecraft:oak_log
fill 27 69 -428 28 69 -428 minecraft:oak_leaves[persistent=true]
fill 25 69 -427 27 69 -427 minecraft:oak_leaves[persistent=true]
setblock 26 69 -426 minecraft:oak_leaves[persistent=true]
setblock 20 69 -422 minecraft:oak_leaves[persistent=true]
fill 19 69 -421 21 69 -421 minecraft:oak_leaves[persistent=true]
fill 18 69 -420 19 69 -420 minecraft:oak_leaves[persistent=true]
setblock 20 69 -420 minecraft:oak_log
fill 21 69 -420 22 69 -420 minecraft:oak_leaves[persistent=true]
fill 19 69 -419 21 69 -419 minecraft:oak_leaves[persistent=true]
setblock 20 69 -418 minecraft:oak_leaves[persistent=true]
setblock 18 69 -411 minecraft:oak_leaves[persistent=true]
fill 17 69 -410 19 69 -410 minecraft:oak_leaves[persistent=true]
fill 16 69 -409 17 69 -409 minecraft:oak_leaves[persistent=true]
setblock 18 69 -409 minecraft:oak_log
fill 19 69 -409 20 69 -409 minecraft:oak_leaves[persistent=true]
fill 17 69 -408 19 69 -408 minecraft:oak_leaves[persistent=true]
setblock 18 69 -407 minecraft:oak_leaves[persistent=true]
setblock 18 69 -401 minecraft:oak_leaves[persistent=true]
fill 17 69 -400 19 69 -400 minecraft:oak_leaves[persistent=true]
fill 16 69 -399 17 69 -399 minecraft:oak_leaves[persistent=true]
setblock 18 69 -399 minecraft:oak_log
fill 19 69 -399 20 69 -399 minecraft:oak_leaves[persistent=true]
fill 17 69 -398 19 69 -398 minecraft:oak_leaves[persistent=true]
setblock 18 69 -397 minecraft:oak_leaves[persistent=true]
setblock 18 69 -391 minecraft:oak_leaves[persistent=true]
fill 17 69 -390 19 69 -390 minecraft:oak_leaves[persistent=true]
fill 16 69 -389 17 69 -389 minecraft:oak_leaves[persistent=true]
setblock 18 69 -389 minecraft:oak_log
fill 19 69 -389 20 69 -389 minecraft:oak_leaves[persistent=true]
fill 17 69 -388 19 69 -388 minecraft:oak_leaves[persistent=true]
setblock 18 69 -387 minecraft:oak_leaves[persistent=true]
fill 51 70 -438 53 70 -438 minecraft:oak_leaves[persistent=true]
fill 61 70 -438 63 70 -438 minecraft:oak_leaves[persistent=true]
setblock 71 70 -438 minecraft:oak_leaves[persistent=true]
fill 39 70 -437 41 70 -437 minecraft:oak_leaves[persistent=true]
fill 50 70 -437 54 70 -437 minecraft:oak_leaves[persistent=true]
fill 60 70 -437 64 70 -437 minecraft:oak_leaves[persistent=true]
fill 70 70 -437 71 70 -437 minecraft:oak_leaves[persistent=true]
fill 38 70 -436 42 70 -436 minecraft:oak_leaves[persistent=true]
fill 50 70 -436 51 70 -436 minecraft:oak_leaves[persistent=true]
setblock 52 70 -436 minecraft:oak_log
fill 53 70 -436 54 70 -436 minecraft:oak_leaves[persistent=true]
fill 60 70 -436 61 70 -436 minecraft:oak_leaves[persistent=true]
setblock 62 70 -436 minecraft:oak_log
fill 63 70 -436 64 70 -436 minecraft:oak_leaves[persistent=true]
fill 70 70 -436 71 70 -436 minecraft:oak_leaves[persistent=true]
fill 38 70 -435 39 70 -435 minecraft:oak_leaves[persistent=true]
setblock 40 70 -435 minecraft:oak_log
fill 41 70 -435 42 70 -435 minecraft:oak_leaves[persistent=true]
fill 50 70 -435 54 70 -435 minecraft:oak_leaves[persistent=true]
fill 60 70 -435 64 70 -435 minecraft:oak_leaves[persistent=true]
fill 70 70 -435 71 70 -435 minecraft:oak_leaves[persistent=true]
fill 38 70 -434 42 70 -434 minecraft:oak_leaves[persistent=true]
fill 51 70 -434 53 70 -434 minecraft:oak_leaves[persistent=true]
fill 61 70 -434 63 70 -434 minecraft:oak_leaves[persistent=true]
setblock 71 70 -434 minecraft:oak_leaves[persistent=true]
fill 39 70 -433 41 70 -433 minecraft:oak_leaves[persistent=true]
fill 25 70 -430 27 70 -430 minecraft:oak_leaves[persistent=true]
fill 24 70 -429 28 70 -429 minecraft:oak_leaves[persistent=true]
fill 24 70 -428 25 70 -428 minecraft:oak_leaves[persistent=true]
setblock 26 70 -428 minecraft:oak_log
fill 27 70 -428 28 70 -428 minecraft:oak_leaves[persistent=true]
fill 24 70 -427 28 70 -427 minecraft:oak_leaves[persistent=true]
fill 25 70 -426 27 70 -426 minecraft:oak_leaves[persistent=true]
fill 19 70 -422 21 70 -422 minecraft:oak_leaves[persistent=true]
fill 18 70 -421 22 70 -421 minecraft:oak_leaves[persistent=true]
fill 18 70 -420 19 70 -420 minecraft:oak_leaves[persistent=true]
setblock 20 70 -420 minecraft:oak_log
fill 21 70 -420 22 70 -420 minecraft:oak_leaves[persistent=true]
fill 18 70 -419 22 70 -419 minecraft:oak_leaves[persistent=true]
fill 19 70 -418 21 70 -418 minecraft:oak_leaves[persistent=true]
fill 17 70 -411 19 70 -411 minecraft:oak_leaves[persistent=true]
fill 16 70 -410 20 70 -410 minecraft:oak_leaves[persistent=true]
fill 16 70 -409 17 70 -409 minecraft:oak_leaves[persistent=true]
setblock 18 70 -409 minecraft:oak_log
fill 19 70 -409 20 70 -409 minecraft:oak_leaves[persistent=true]
fill 16 70 -408 20 70 -408 minecraft:oak_leaves[persistent=true]
fill 17 70 -407 19 70 -407 minecraft:oak_leaves[persistent=true]
fill 17 70 -401 19 70 -401 minecraft:oak_leaves[persistent=true]
fill 16 70 -400 20 70 -400 minecraft:oak_leaves[persistent=true]
fill 16 70 -399 17 70 -399 minecraft:oak_leaves[persistent=true]
setblock 18 70 -399 minecraft:oak_log
fill 19 70 -399 20 70 -399 minecraft:oak_leaves[persistent=true]
fill 16 70 -398 20 70 -398 minecraft:oak_leaves[persistent=true]
fill 17 70 -397 19 70 -397 minecraft:oak_leaves[persistent=true]
fill 17 70 -391 19 70 -391 minecraft:oak_leaves[persistent=true]
fill 16 70 -390 20 70 -390 minecraft:oak_leaves[persistent=true]
fill 16 70 -389 17 70 -389 minecraft:oak_leaves[persistent=true]
setblock 18 70 -389 minecraft:oak_log
fill 19 70 -389 20 70 -389 minecraft:oak_leaves[persistent=true]
fill 16 70 -388 20 70 -388 minecraft:oak_leaves[persistent=true]
fill 17 70 -387 19 70 -387 minecraft:oak_leaves[persistent=true]
setblock 52 71 -438 minecraft:oak_leaves[persistent=true]
setblock 62 71 -438 minecraft:oak_leaves[persistent=true]
setblock 40 71 -437 minecraft:oak_leaves[persistent=true]
fill 51 71 -437 53 71 -437 minecraft:oak_leaves[persistent=true]
fill 61 71 -437 63 71 -437 minecraft:oak_leaves[persistent=true]
setblock 71 71 -437 minecraft:oak_leaves[persistent=true]
fill 39 71 -436 41 71 -436 minecraft:oak_leaves[persistent=true]
fill 50 71 -436 54 71 -436 minecraft:oak_leaves[persistent=true]
fill 60 71 -436 64 71 -436 minecraft:oak_leaves[persistent=true]
fill 70 71 -436 71 71 -436 minecraft:oak_leaves[persistent=true]
fill 38 71 -435 42 71 -435 minecraft:oak_leaves[persistent=true]
fill 51 71 -435 53 71 -435 minecraft:oak_leaves[persistent=true]
fill 61 71 -435 63 71 -435 minecraft:oak_leaves[persistent=true]
setblock 71 71 -435 minecraft:oak_leaves[persistent=true]
fill 39 71 -434 41 71 -434 minecraft:oak_leaves[persistent=true]
setblock 52 71 -434 minecraft:oak_leaves[persistent=true]
setblock 62 71 -434 minecraft:oak_leaves[persistent=true]
setblock 40 71 -433 minecraft:oak_leaves[persistent=true]
setblock 26 71 -430 minecraft:oak_leaves[persistent=true]
fill 25 71 -429 27 71 -429 minecraft:oak_leaves[persistent=true]
fill 24 71 -428 28 71 -428 minecraft:oak_leaves[persistent=true]
fill 25 71 -427 27 71 -427 minecraft:oak_leaves[persistent=true]
setblock 26 71 -426 minecraft:oak_leaves[persistent=true]
setblock 20 71 -422 minecraft:oak_leaves[persistent=true]
fill 19 71 -421 21 71 -421 minecraft:oak_leaves[persistent=true]
fill 18 71 -420 22 71 -420 minecraft:oak_leaves[persistent=true]
fill 19 71 -419 21 71 -419 minecraft:oak_leaves[persistent=true]
setblock 20 71 -418 minecraft:oak_leaves[persistent=true]
setblock 18 71 -411 minecraft:oak_leaves[persistent=true]
fill 17 71 -410 19 71 -410 minecraft:oak_leaves[persistent=true]
fill 16 71 -409 20 71 -409 minecraft:oak_leaves[persistent=true]
fill 17 71 -408 19 71 -408 minecraft:oak_leaves[persistent=true]
setblock 18 71 -407 minecraft:oak_leaves[persistent=true]
setblock 18 71 -401 minecraft:oak_leaves[persistent=true]
fill 17 71 -400 19 71 -400 minecraft:oak_leaves[persistent=true]
fill 16 71 -399 20 71 -399 minecraft:oak_leaves[persistent=true]
fill 17 71 -398 19 71 -398 minecraft:oak_leaves[persistent=true]
setblock 18 71 -397 minecraft:oak_leaves[persistent=true]
setblock 18 71 -391 minecraft:oak_leaves[persistent=true]
fill 17 71 -390 19 71 -390 minecraft:oak_leaves[persistent=true]
fill 16 71 -389 20 71 -389 minecraft:oak_leaves[persistent=true]
fill 17 71 -388 19 71 -388 minecraft:oak_leaves[persistent=true]
setblock 18 71 -387 minecraft:oak_leaves[persistent=true]
setblock 52 72 -436 minecraft:oak_leaves[persistent=true]
setblock 62 72 -436 minecraft:oak_leaves[persistent=true]
setblock 40 72 -435 minecraft:oak_leaves[persistent=true]
setblock 26 72 -428 minecraft:oak_leaves[persistent=true]
setblock 20 72 -420 minecraft:oak_leaves[persistent=true]
setblock 18 72 -409 minecraft:oak_leaves[persistent=true]
setblock 18 72 -399 minecraft:oak_leaves[persistent=true]
setblock 18 72 -389 minecraft:oak_leaves[persistent=true]
forceload remove 8 -446 71 -383
tellraw @a {"text":"Campus bau a01 fertig.","color":"green"}
