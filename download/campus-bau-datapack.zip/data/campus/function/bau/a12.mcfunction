# Abschnitt a12: x 264..327, z -382..-319 (6134 Blöcke)
forceload add 264 -382 327 -319
tellraw @a {"text":"Campus bau a12: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a12_1 2s
