fill 200 45 -190 226 45 -190 minecraft:stone
setblock 228 45 -190 minecraft:stone
fill 200 45 -189 231 45 -189 minecraft:stone
fill 200 45 -188 234 45 -188 minecraft:stone
fill 200 45 -187 238 45 -187 minecraft:stone
fill 200 45 -186 241 45 -186 minecraft:stone
fill 201 45 -185 242 45 -185 minecraft:stone
fill 201 45 -184 244 45 -184 minecraft:stone
fill 201 45 -183 245 45 -183 minecraft:stone
fill 200 45 -182 245 45 -182 minecraft:stone
fill 200 45 -181 246 45 -181 minecraft:stone
fill 200 45 -180 246 45 -180 minecraft:stone
fill 200 45 -179 246 45 -179 minecraft:stone
fill 200 45 -178 246 45 -178 minecraft:stone
fill 200 45 -177 247 45 -177 minecraft:stone
fill 200 45 -176 247 45 -176 minecraft:stone
fill 200 45 -175 247 45 -175 minecraft:stone
fill 200 45 -174 248 45 -174 minecraft:stone
fill 201 45 -173 249 45 -173 minecraft:stone
fill 201 45 -172 249 45 -172 minecraft:stone
fill 202 45 -171 250 45 -171 minecraft:stone
fill 203 45 -170 251 45 -170 minecraft:stone
fill 204 45 -169 251 45 -169 minecraft:stone
fill 205 45 -168 252 45 -168 minecraft:stone
fill 205 45 -167 253 45 -167 minecraft:stone
fill 206 45 -166 253 45 -166 minecraft:stone
fill 206 45 -165 252 45 -165 minecraft:stone
fill 207 45 -164 243 45 -164 minecraft:stone
fill 260 45 -164 261 45 -164 minecraft:stone
fill 208 45 -163 239 45 -163 minecraft:stone
fill 254 45 -163 256 45 -163 minecraft:stone
fill 259 45 -163 261 45 -163 minecraft:stone
fill 208 45 -162 236 45 -162 minecraft:stone
fill 245 45 -162 251 45 -162 minecraft:stone
fill 253 45 -162 261 45 -162 minecraft:stone
fill 209 45 -161 235 45 -161 minecraft:stone
fill 241 45 -161 261 45 -161 minecraft:stone
fill 210 45 -160 235 45 -160 minecraft:stone
fill 238 45 -160 263 45 -160 minecraft:stone
fill 211 45 -159 234 45 -159 minecraft:stone
fill 237 45 -159 263 45 -159 minecraft:stone
fill 212 45 -158 234 45 -158 minecraft:stone
fill 236 45 -158 263 45 -158 minecraft:stone
fill 213 45 -157 234 45 -157 minecraft:stone
fill 236 45 -157 262 45 -157 minecraft:stone
fill 215 45 -156 234 45 -156 minecraft:stone
fill 237 45 -156 262 45 -156 minecraft:stone
fill 216 45 -155 234 45 -155 minecraft:stone
fill 237 45 -155 261 45 -155 minecraft:stone
fill 217 45 -154 235 45 -154 minecraft:stone
fill 237 45 -154 260 45 -154 minecraft:stone
fill 218 45 -153 235 45 -153 minecraft:stone
fill 237 45 -153 259 45 -153 minecraft:stone
fill 218 45 -152 236 45 -152 minecraft:stone
fill 240 45 -152 258 45 -152 minecraft:stone
fill 219 45 -151 237 45 -151 minecraft:stone
setblock 242 45 -151 minecraft:stone
fill 244 45 -151 258 45 -151 minecraft:stone
setblock 263 45 -151 minecraft:stone
fill 219 45 -150 239 45 -150 minecraft:stone
fill 244 45 -150 257 45 -150 minecraft:stone
setblock 263 45 -150 minecraft:stone
fill 219 45 -149 241 45 -149 minecraft:stone
fill 246 45 -149 255 45 -149 minecraft:stone
fill 262 45 -149 263 45 -149 minecraft:stone
fill 219 45 -148 231 45 -148 minecraft:stone
setblock 233 45 -148 minecraft:stone
fill 235 45 -148 242 45 -148 minecraft:stone
fill 246 45 -148 256 45 -148 minecraft:stone
setblock 263 45 -148 minecraft:stone
fill 219 45 -147 231 45 -147 minecraft:stone
fill 236 45 -147 243 45 -147 minecraft:stone
fill 247 45 -147 258 45 -147 minecraft:stone
fill 218 45 -146 229 45 -146 minecraft:stone
fill 236 45 -146 244 45 -146 minecraft:stone
fill 248 45 -146 262 45 -146 minecraft:stone
fill 218 45 -145 227 45 -145 minecraft:stone
fill 232 45 -145 233 45 -145 minecraft:stone
fill 237 45 -145 245 45 -145 minecraft:stone
fill 248 45 -145 263 45 -145 minecraft:stone
fill 211 45 -144 212 45 -144 minecraft:stone
fill 217 45 -144 228 45 -144 minecraft:stone
fill 232 45 -144 233 45 -144 minecraft:stone
fill 238 45 -144 245 45 -144 minecraft:stone
fill 249 45 -144 263 45 -144 minecraft:stone
fill 210 45 -143 214 45 -143 minecraft:stone
fill 217 45 -143 228 45 -143 minecraft:stone
fill 232 45 -143 234 45 -143 minecraft:stone
fill 239 45 -143 246 45 -143 minecraft:stone
fill 250 45 -143 263 45 -143 minecraft:stone
fill 210 45 -142 228 45 -142 minecraft:stone
fill 232 45 -142 235 45 -142 minecraft:stone
fill 239 45 -142 247 45 -142 minecraft:stone
fill 250 45 -142 263 45 -142 minecraft:stone
fill 211 45 -141 228 45 -141 minecraft:stone
fill 232 45 -141 236 45 -141 minecraft:stone
fill 240 45 -141 248 45 -141 minecraft:stone
fill 250 45 -141 263 45 -141 minecraft:stone
fill 212 45 -140 213 45 -140 minecraft:stone
fill 215 45 -140 228 45 -140 minecraft:stone
fill 232 45 -140 236 45 -140 minecraft:stone
fill 241 45 -140 247 45 -140 minecraft:stone
fill 250 45 -140 263 45 -140 minecraft:stone
fill 214 45 -139 228 45 -139 minecraft:stone
fill 232 45 -139 237 45 -139 minecraft:stone
fill 241 45 -139 247 45 -139 minecraft:stone
fill 249 45 -139 263 45 -139 minecraft:stone
fill 213 45 -138 228 45 -138 minecraft:stone
fill 232 45 -138 238 45 -138 minecraft:stone
fill 242 45 -138 245 45 -138 minecraft:stone
fill 249 45 -138 263 45 -138 minecraft:stone
fill 212 45 -137 228 45 -137 minecraft:stone
fill 232 45 -137 238 45 -137 minecraft:stone
fill 248 45 -137 263 45 -137 minecraft:stone
fill 211 45 -136 229 45 -136 minecraft:stone
fill 233 45 -136 239 45 -136 minecraft:stone
fill 245 45 -136 263 45 -136 minecraft:stone
fill 210 45 -135 229 45 -135 minecraft:stone
fill 233 45 -135 263 45 -135 minecraft:stone
fill 209 45 -134 229 45 -134 minecraft:stone
fill 233 45 -134 263 45 -134 minecraft:stone
fill 207 45 -133 229 45 -133 minecraft:stone
fill 233 45 -133 263 45 -133 minecraft:stone
fill 206 45 -132 229 45 -132 minecraft:stone
fill 233 45 -132 253 45 -132 minecraft:stone
fill 258 45 -132 263 45 -132 minecraft:stone
fill 204 45 -131 230 45 -131 minecraft:stone
fill 237 45 -131 254 45 -131 minecraft:stone
fill 257 45 -131 263 45 -131 minecraft:stone
fill 203 45 -130 231 45 -130 minecraft:stone
fill 237 45 -130 263 45 -130 minecraft:stone
fill 201 45 -129 234 45 -129 minecraft:stone
fill 237 45 -129 263 45 -129 minecraft:stone
fill 200 45 -128 234 45 -128 minecraft:stone
fill 237 45 -128 263 45 -128 minecraft:stone
fill 200 45 -127 234 45 -127 minecraft:stone
fill 237 45 -127 263 45 -127 minecraft:stone
fill 200 46 -190 225 46 -190 minecraft:stone
fill 200 46 -189 233 46 -189 minecraft:stone
fill 200 46 -188 236 46 -188 minecraft:stone
fill 200 46 -187 240 46 -187 minecraft:stone
fill 200 46 -186 242 46 -186 minecraft:stone
fill 201 46 -185 243 46 -185 minecraft:stone
fill 201 46 -184 245 46 -184 minecraft:stone
fill 201 46 -183 246 46 -183 minecraft:stone
fill 200 46 -182 246 46 -182 minecraft:stone
fill 200 46 -181 246 46 -181 minecraft:stone
fill 200 46 -180 246 46 -180 minecraft:stone
fill 200 46 -179 247 46 -179 minecraft:stone
fill 200 46 -178 247 46 -178 minecraft:stone
fill 200 46 -177 247 46 -177 minecraft:stone
fill 200 46 -176 247 46 -176 minecraft:stone
fill 200 46 -175 248 46 -175 minecraft:stone
fill 200 46 -174 249 46 -174 minecraft:stone
fill 201 46 -173 249 46 -173 minecraft:stone
fill 201 46 -172 250 46 -172 minecraft:stone
fill 203 46 -171 251 46 -171 minecraft:stone
fill 204 46 -170 251 46 -170 minecraft:stone
fill 205 46 -169 252 46 -169 minecraft:stone
fill 205 46 -168 252 46 -168 minecraft:stone
fill 206 46 -167 252 46 -167 minecraft:stone
fill 206 46 -166 252 46 -166 minecraft:stone
setblock 257 46 -166 minecraft:stone
fill 207 46 -165 252 46 -165 minecraft:stone
setblock 258 46 -165 minecraft:stone
fill 207 46 -164 244 46 -164 minecraft:stone
setblock 247 46 -164 minecraft:stone
setblock 254 46 -164 minecraft:stone
fill 256 46 -164 260 46 -164 minecraft:stone
fill 208 46 -163 240 46 -163 minecraft:stone
fill 254 46 -163 260 46 -163 minecraft:stone
fill 208 46 -162 239 46 -162 minecraft:stone
fill 247 46 -162 261 46 -162 minecraft:stone
fill 209 46 -161 235 46 -161 minecraft:stone
fill 242 46 -161 263 46 -161 minecraft:stone
fill 210 46 -160 235 46 -160 minecraft:stone
fill 239 46 -160 263 46 -160 minecraft:stone
fill 211 46 -159 234 46 -159 minecraft:stone
fill 237 46 -159 263 46 -159 minecraft:stone
fill 212 46 -158 234 46 -158 minecraft:stone
fill 237 46 -158 263 46 -158 minecraft:stone
fill 213 46 -157 235 46 -157 minecraft:stone
fill 237 46 -157 263 46 -157 minecraft:stone
fill 215 46 -156 234 46 -156 minecraft:stone
fill 237 46 -156 263 46 -156 minecraft:stone
fill 216 46 -155 234 46 -155 minecraft:stone
fill 237 46 -155 263 46 -155 minecraft:stone
fill 217 46 -154 235 46 -154 minecraft:stone
fill 238 46 -154 262 46 -154 minecraft:stone
fill 218 46 -153 235 46 -153 minecraft:stone
fill 238 46 -153 262 46 -153 minecraft:stone
fill 218 46 -152 236 46 -152 minecraft:stone
fill 239 46 -152 261 46 -152 minecraft:stone
fill 218 46 -151 236 46 -151 minecraft:stone
fill 242 46 -151 260 46 -151 minecraft:stone
fill 219 46 -150 238 46 -150 minecraft:stone
fill 243 46 -150 259 46 -150 minecraft:stone
fill 219 46 -149 240 46 -149 minecraft:stone
fill 244 46 -149 258 46 -149 minecraft:stone
fill 220 46 -148 231 46 -148 minecraft:stone
fill 237 46 -148 241 46 -148 minecraft:stone
fill 244 46 -148 257 46 -148 minecraft:stone
fill 219 46 -147 229 46 -147 minecraft:stone
fill 238 46 -147 241 46 -147 minecraft:stone
fill 245 46 -147 257 46 -147 minecraft:stone
setblock 260 46 -147 minecraft:stone
fill 219 46 -146 228 46 -146 minecraft:stone
fill 232 46 -146 234 46 -146 minecraft:stone
fill 238 46 -146 242 46 -146 minecraft:stone
fill 246 46 -146 263 46 -146 minecraft:stone
fill 218 46 -145 226 46 -145 minecraft:stone
fill 230 46 -145 235 46 -145 minecraft:stone
fill 239 46 -145 243 46 -145 minecraft:stone
fill 247 46 -145 263 46 -145 minecraft:stone
fill 210 46 -144 212 46 -144 minecraft:stone
fill 217 46 -144 226 46 -144 minecraft:stone
fill 230 46 -144 235 46 -144 minecraft:stone
fill 240 46 -144 243 46 -144 minecraft:stone
fill 248 46 -144 263 46 -144 minecraft:stone
fill 209 46 -143 213 46 -143 minecraft:stone
fill 217 46 -143 226 46 -143 minecraft:stone
fill 230 46 -143 236 46 -143 minecraft:stone
fill 240 46 -143 243 46 -143 minecraft:stone
fill 248 46 -143 263 46 -143 minecraft:stone
fill 210 46 -142 214 46 -142 minecraft:stone
fill 216 46 -142 227 46 -142 minecraft:stone
fill 231 46 -142 237 46 -142 minecraft:stone
fill 241 46 -142 243 46 -142 minecraft:stone
fill 249 46 -142 263 46 -142 minecraft:stone
fill 210 46 -141 213 46 -141 minecraft:stone
fill 215 46 -141 227 46 -141 minecraft:stone
fill 231 46 -141 237 46 -141 minecraft:stone
fill 242 46 -141 243 46 -141 minecraft:stone
fill 249 46 -141 263 46 -141 minecraft:stone
fill 214 46 -140 227 46 -140 minecraft:stone
fill 231 46 -140 238 46 -140 minecraft:stone
setblock 243 46 -140 minecraft:stone
fill 249 46 -140 263 46 -140 minecraft:stone
fill 213 46 -139 227 46 -139 minecraft:stone
fill 231 46 -139 239 46 -139 minecraft:stone
setblock 243 46 -139 minecraft:stone
fill 249 46 -139 263 46 -139 minecraft:stone
fill 212 46 -138 227 46 -138 minecraft:stone
fill 231 46 -138 240 46 -138 minecraft:stone
fill 248 46 -138 263 46 -138 minecraft:stone
fill 211 46 -137 227 46 -137 minecraft:stone
fill 231 46 -137 240 46 -137 minecraft:stone
fill 247 46 -137 263 46 -137 minecraft:stone
fill 211 46 -136 227 46 -136 minecraft:stone
fill 231 46 -136 263 46 -136 minecraft:stone
fill 210 46 -135 227 46 -135 minecraft:stone
fill 231 46 -135 263 46 -135 minecraft:stone
fill 208 46 -134 228 46 -134 minecraft:stone
fill 232 46 -134 263 46 -134 minecraft:stone
fill 207 46 -133 228 46 -133 minecraft:stone
fill 232 46 -133 263 46 -133 minecraft:stone
fill 206 46 -132 226 46 -132 minecraft:stone
fill 233 46 -132 253 46 -132 minecraft:stone
fill 258 46 -132 263 46 -132 minecraft:stone
fill 204 46 -131 228 46 -131 minecraft:stone
setblock 230 46 -131 minecraft:stone
fill 237 46 -131 253 46 -131 minecraft:stone
fill 258 46 -131 263 46 -131 minecraft:stone
fill 202 46 -130 233 46 -130 minecraft:stone
fill 237 46 -130 263 46 -130 minecraft:stone
fill 200 46 -129 235 46 -129 minecraft:stone
fill 238 46 -129 263 46 -129 minecraft:stone
fill 200 46 -128 235 46 -128 minecraft:stone
fill 238 46 -128 263 46 -128 minecraft:stone
fill 200 46 -127 235 46 -127 minecraft:stone
fill 238 46 -127 263 46 -127 minecraft:stone
fill 200 47 -190 202 47 -190 minecraft:stone
fill 205 47 -190 228 47 -190 minecraft:stone
fill 200 47 -189 203 47 -189 minecraft:stone
fill 205 47 -189 230 47 -189 minecraft:stone
fill 232 47 -189 234 47 -189 minecraft:stone
setblock 237 47 -189 minecraft:stone
fill 200 47 -188 239 47 -188 minecraft:stone
fill 200 47 -187 242 47 -187 minecraft:stone
fill 200 47 -186 243 47 -186 minecraft:stone
fill 201 47 -185 245 47 -185 minecraft:stone
fill 201 47 -184 247 47 -184 minecraft:stone
fill 201 47 -183 247 47 -183 minecraft:stone
fill 200 47 -182 247 47 -182 minecraft:stone
fill 200 47 -181 247 47 -181 minecraft:stone
fill 200 47 -180 247 47 -180 minecraft:stone
fill 200 47 -179 247 47 -179 minecraft:stone
fill 200 47 -178 247 47 -178 minecraft:stone
fill 200 47 -177 248 47 -177 minecraft:stone
fill 200 47 -176 248 47 -176 minecraft:stone
fill 200 47 -175 249 47 -175 minecraft:stone
fill 200 47 -174 249 47 -174 minecraft:stone
fill 201 47 -173 250 47 -173 minecraft:stone
fill 201 47 -172 251 47 -172 minecraft:stone
fill 203 47 -171 251 47 -171 minecraft:stone
fill 204 47 -170 252 47 -170 minecraft:stone
fill 205 47 -169 252 47 -169 minecraft:stone
fill 255 47 -169 256 47 -169 minecraft:stone
fill 205 47 -168 252 47 -168 minecraft:stone
fill 255 47 -168 258 47 -168 minecraft:stone
fill 206 47 -167 252 47 -167 minecraft:stone
fill 255 47 -167 259 47 -167 minecraft:stone
fill 207 47 -166 252 47 -166 minecraft:stone
fill 255 47 -166 260 47 -166 minecraft:stone
fill 207 47 -165 252 47 -165 minecraft:stone
fill 255 47 -165 260 47 -165 minecraft:stone
fill 208 47 -164 245 47 -164 minecraft:stone
fill 248 47 -164 249 47 -164 minecraft:stone
fill 255 47 -164 261 47 -164 minecraft:stone
fill 208 47 -163 241 47 -163 minecraft:stone
fill 253 47 -163 261 47 -163 minecraft:stone
fill 209 47 -162 240 47 -162 minecraft:stone
fill 249 47 -162 250 47 -162 minecraft:stone
fill 252 47 -162 263 47 -162 minecraft:stone
fill 210 47 -161 238 47 -161 minecraft:stone
fill 243 47 -161 263 47 -161 minecraft:stone
fill 210 47 -160 235 47 -160 minecraft:stone
fill 241 47 -160 263 47 -160 minecraft:stone
fill 211 47 -159 235 47 -159 minecraft:stone
fill 238 47 -159 263 47 -159 minecraft:stone
fill 212 47 -158 235 47 -158 minecraft:stone
fill 237 47 -158 263 47 -158 minecraft:stone
fill 213 47 -157 235 47 -157 minecraft:stone
fill 238 47 -157 263 47 -157 minecraft:stone
fill 215 47 -156 235 47 -156 minecraft:stone
fill 238 47 -156 263 47 -156 minecraft:stone
fill 216 47 -155 236 47 -155 minecraft:stone
fill 238 47 -155 263 47 -155 minecraft:stone
fill 217 47 -154 236 47 -154 minecraft:stone
fill 238 47 -154 263 47 -154 minecraft:stone
fill 217 47 -153 236 47 -153 minecraft:stone
fill 238 47 -153 263 47 -153 minecraft:stone
fill 218 47 -152 236 47 -152 minecraft:stone
fill 240 47 -152 263 47 -152 minecraft:stone
fill 218 47 -151 236 47 -151 minecraft:stone
fill 241 47 -151 262 47 -151 minecraft:stone
fill 219 47 -150 235 47 -150 minecraft:stone
fill 241 47 -150 262 47 -150 minecraft:stone
fill 219 47 -149 234 47 -149 minecraft:stone
fill 242 47 -149 261 47 -149 minecraft:stone
fill 220 47 -148 230 47 -148 minecraft:stone
fill 243 47 -148 258 47 -148 minecraft:stone
fill 219 47 -147 228 47 -147 minecraft:stone
fill 234 47 -147 235 47 -147 minecraft:stone
fill 244 47 -147 259 47 -147 minecraft:stone
fill 219 47 -146 226 47 -146 minecraft:stone
fill 232 47 -146 236 47 -146 minecraft:stone
fill 245 47 -146 263 47 -146 minecraft:stone
fill 218 47 -145 226 47 -145 minecraft:stone
fill 229 47 -145 236 47 -145 minecraft:stone
fill 246 47 -145 263 47 -145 minecraft:stone
fill 209 47 -144 212 47 -144 minecraft:stone
fill 217 47 -144 225 47 -144 minecraft:stone
fill 229 47 -144 237 47 -144 minecraft:stone
fill 247 47 -144 263 47 -144 minecraft:stone
fill 209 47 -143 213 47 -143 minecraft:stone
fill 217 47 -143 225 47 -143 minecraft:stone
fill 229 47 -143 238 47 -143 minecraft:stone
fill 248 47 -143 263 47 -143 minecraft:stone
fill 209 47 -142 213 47 -142 minecraft:stone
fill 215 47 -142 225 47 -142 minecraft:stone
fill 229 47 -142 239 47 -142 minecraft:stone
fill 248 47 -142 263 47 -142 minecraft:stone
fill 210 47 -141 212 47 -141 minecraft:stone
fill 214 47 -141 225 47 -141 minecraft:stone
fill 229 47 -141 239 47 -141 minecraft:stone
fill 248 47 -141 263 47 -141 minecraft:stone
fill 213 47 -140 226 47 -140 minecraft:stone
fill 230 47 -140 240 47 -140 minecraft:stone
fill 248 47 -140 263 47 -140 minecraft:stone
fill 212 47 -139 226 47 -139 minecraft:stone
fill 230 47 -139 241 47 -139 minecraft:stone
fill 247 47 -139 263 47 -139 minecraft:stone
fill 211 47 -138 226 47 -138 minecraft:stone
fill 230 47 -138 241 47 -138 minecraft:stone
fill 247 47 -138 263 47 -138 minecraft:stone
fill 211 47 -137 226 47 -137 minecraft:stone
fill 230 47 -137 263 47 -137 minecraft:stone
fill 210 47 -136 226 47 -136 minecraft:stone
fill 230 47 -136 263 47 -136 minecraft:stone
fill 209 47 -135 226 47 -135 minecraft:stone
fill 230 47 -135 263 47 -135 minecraft:stone
fill 208 47 -134 226 47 -134 minecraft:stone
fill 230 47 -134 263 47 -134 minecraft:stone
fill 207 47 -133 226 47 -133 minecraft:stone
fill 230 47 -133 263 47 -133 minecraft:stone
fill 205 47 -132 226 47 -132 minecraft:stone
fill 233 47 -132 253 47 -132 minecraft:stone
fill 258 47 -132 263 47 -132 minecraft:stone
fill 203 47 -131 230 47 -131 minecraft:stone
fill 237 47 -131 253 47 -131 minecraft:stone
fill 258 47 -131 263 47 -131 minecraft:stone
fill 200 47 -130 233 47 -130 minecraft:stone
fill 237 47 -130 253 47 -130 minecraft:stone
fill 255 47 -130 263 47 -130 minecraft:stone
fill 200 47 -129 235 47 -129 minecraft:stone
fill 238 47 -129 263 47 -129 minecraft:stone
fill 200 47 -128 235 47 -128 minecraft:stone
fill 238 47 -128 263 47 -128 minecraft:stone
fill 200 47 -127 236 47 -127 minecraft:stone
fill 238 47 -127 263 47 -127 minecraft:stone
fill 200 48 -190 201 48 -190 minecraft:stone
fill 206 48 -190 229 48 -190 minecraft:stone
fill 200 48 -189 202 48 -189 minecraft:stone
fill 205 48 -189 231 48 -189 minecraft:stone
fill 234 48 -189 236 48 -189 minecraft:stone
fill 200 48 -188 202 48 -188 minecraft:stone
fill 205 48 -188 241 48 -188 minecraft:stone
fill 200 48 -187 243 48 -187 minecraft:stone
fill 200 48 -186 246 48 -186 minecraft:stone
fill 201 48 -185 250 48 -185 minecraft:stone
fill 201 48 -184 251 48 -184 minecraft:stone
fill 201 48 -183 251 48 -183 minecraft:stone
fill 200 48 -182 250 48 -182 minecraft:stone
fill 200 48 -181 250 48 -181 minecraft:stone
fill 200 48 -180 249 48 -180 minecraft:stone
fill 200 48 -179 249 48 -179 minecraft:stone
setblock 260 48 -179 minecraft:stone
fill 200 48 -178 249 48 -178 minecraft:stone
setblock 260 48 -178 minecraft:stone
fill 200 48 -177 249 48 -177 minecraft:stone
setblock 260 48 -177 minecraft:stone
fill 200 48 -176 249 48 -176 minecraft:stone
fill 260 48 -176 261 48 -176 minecraft:stone
fill 200 48 -175 250 48 -175 minecraft:stone
fill 200 48 -174 250 48 -174 minecraft:stone
fill 201 48 -173 251 48 -173 minecraft:stone
fill 202 48 -172 251 48 -172 minecraft:stone
fill 203 48 -171 251 48 -171 minecraft:stone
fill 254 48 -171 255 48 -171 minecraft:stone
fill 205 48 -170 251 48 -170 minecraft:stone
fill 254 48 -170 258 48 -170 minecraft:stone
setblock 263 48 -170 minecraft:stone
fill 205 48 -169 251 48 -169 minecraft:stone
fill 254 48 -169 263 48 -169 minecraft:stone
fill 206 48 -168 251 48 -168 minecraft:stone
fill 254 48 -168 263 48 -168 minecraft:stone
fill 206 48 -167 251 48 -167 minecraft:stone
fill 254 48 -167 263 48 -167 minecraft:stone
fill 207 48 -166 251 48 -166 minecraft:stone
fill 254 48 -166 262 48 -166 minecraft:stone
fill 207 48 -165 251 48 -165 minecraft:stone
fill 254 48 -165 261 48 -165 minecraft:stone
fill 208 48 -164 247 48 -164 minecraft:stone
setblock 250 48 -164 minecraft:stone
fill 254 48 -164 261 48 -164 minecraft:stone
fill 208 48 -163 243 48 -163 minecraft:stone
fill 252 48 -163 262 48 -163 minecraft:stone
fill 209 48 -162 242 48 -162 minecraft:stone
fill 251 48 -162 263 48 -162 minecraft:stone
fill 210 48 -161 239 48 -161 minecraft:stone
fill 245 48 -161 263 48 -161 minecraft:stone
fill 210 48 -160 236 48 -160 minecraft:stone
fill 242 48 -160 263 48 -160 minecraft:stone
fill 211 48 -159 235 48 -159 minecraft:stone
fill 240 48 -159 263 48 -159 minecraft:stone
fill 212 48 -158 236 48 -158 minecraft:stone
fill 238 48 -158 263 48 -158 minecraft:stone
fill 213 48 -157 236 48 -157 minecraft:stone
fill 238 48 -157 263 48 -157 minecraft:stone
fill 214 48 -156 236 48 -156 minecraft:stone
fill 238 48 -156 263 48 -156 minecraft:stone
fill 215 48 -155 236 48 -155 minecraft:stone
fill 239 48 -155 263 48 -155 minecraft:stone
fill 216 48 -154 236 48 -154 minecraft:stone
fill 239 48 -154 263 48 -154 minecraft:stone
fill 217 48 -153 237 48 -153 minecraft:stone
fill 239 48 -153 263 48 -153 minecraft:stone
fill 217 48 -152 237 48 -152 minecraft:stone
fill 239 48 -152 263 48 -152 minecraft:stone
fill 218 48 -151 236 48 -151 minecraft:stone
fill 239 48 -151 263 48 -151 minecraft:stone
fill 219 48 -150 236 48 -150 minecraft:stone
fill 240 48 -150 263 48 -150 minecraft:stone
fill 219 48 -149 234 48 -149 minecraft:stone
fill 241 48 -149 263 48 -149 minecraft:stone
fill 220 48 -148 232 48 -148 minecraft:stone
setblock 239 48 -148 minecraft:stone
fill 241 48 -148 262 48 -148 minecraft:stone
fill 219 48 -147 229 48 -147 minecraft:stone
fill 234 48 -147 236 48 -147 minecraft:stone
fill 239 48 -147 240 48 -147 minecraft:stone
fill 242 48 -147 262 48 -147 minecraft:stone
fill 219 48 -146 227 48 -146 minecraft:stone
fill 232 48 -146 236 48 -146 minecraft:stone
fill 240 48 -146 241 48 -146 minecraft:stone
fill 243 48 -146 263 48 -146 minecraft:stone
fill 209 48 -145 210 48 -145 minecraft:stone
fill 218 48 -145 224 48 -145 minecraft:stone
fill 230 48 -145 237 48 -145 minecraft:stone
fill 240 48 -145 242 48 -145 minecraft:stone
fill 244 48 -145 263 48 -145 minecraft:stone
fill 208 48 -144 211 48 -144 minecraft:stone
fill 217 48 -144 223 48 -144 minecraft:stone
fill 228 48 -144 237 48 -144 minecraft:stone
setblock 239 48 -144 minecraft:stone
fill 241 48 -144 263 48 -144 minecraft:stone
fill 208 48 -143 212 48 -143 minecraft:stone
fill 216 48 -143 222 48 -143 minecraft:stone
setblock 224 48 -143 minecraft:stone
fill 228 48 -143 240 48 -143 minecraft:stone
fill 242 48 -143 263 48 -143 minecraft:stone
fill 209 48 -142 212 48 -142 minecraft:stone
fill 215 48 -142 224 48 -142 minecraft:stone
fill 228 48 -142 240 48 -142 minecraft:stone
fill 242 48 -142 263 48 -142 minecraft:stone
setblock 210 48 -141 minecraft:stone
fill 213 48 -141 224 48 -141 minecraft:stone
fill 228 48 -141 241 48 -141 minecraft:stone
fill 243 48 -141 263 48 -141 minecraft:stone
fill 212 48 -140 224 48 -140 minecraft:stone
fill 228 48 -140 263 48 -140 minecraft:stone
fill 211 48 -139 224 48 -139 minecraft:stone
fill 228 48 -139 263 48 -139 minecraft:stone
fill 210 48 -138 225 48 -138 minecraft:stone
fill 229 48 -138 263 48 -138 minecraft:stone
fill 210 48 -137 225 48 -137 minecraft:stone
fill 229 48 -137 263 48 -137 minecraft:stone
fill 209 48 -136 225 48 -136 minecraft:stone
fill 229 48 -136 263 48 -136 minecraft:stone
fill 209 48 -135 225 48 -135 minecraft:stone
fill 229 48 -135 263 48 -135 minecraft:stone
fill 207 48 -134 225 48 -134 minecraft:stone
fill 229 48 -134 263 48 -134 minecraft:stone
fill 206 48 -133 224 48 -133 minecraft:stone
fill 230 48 -133 263 48 -133 minecraft:stone
fill 205 48 -132 225 48 -132 minecraft:stone
fill 234 48 -132 263 48 -132 minecraft:stone
fill 202 48 -131 230 48 -131 minecraft:stone
fill 237 48 -131 253 48 -131 minecraft:stone
fill 259 48 -131 263 48 -131 minecraft:stone
fill 200 48 -130 234 48 -130 minecraft:stone
fill 238 48 -130 254 48 -130 minecraft:stone
fill 257 48 -130 263 48 -130 minecraft:stone
fill 200 48 -129 235 48 -129 minecraft:stone
fill 238 48 -129 263 48 -129 minecraft:stone
fill 201 48 -128 235 48 -128 minecraft:stone
fill 238 48 -128 263 48 -128 minecraft:stone
fill 201 48 -127 236 48 -127 minecraft:stone
fill 238 48 -127 263 48 -127 minecraft:stone
fill 216 49 -188 217 49 -188 minecraft:stone
fill 216 49 -187 217 49 -187 minecraft:stone
fill 215 49 -186 218 49 -186 minecraft:stone
fill 215 49 -185 218 49 -185 minecraft:stone
fill 215 49 -184 219 49 -184 minecraft:stone
fill 215 49 -183 218 49 -183 minecraft:stone
fill 215 49 -182 217 49 -182 minecraft:stone
setblock 216 49 -181 minecraft:stone
setblock 216 49 -180 minecraft:stone
fill 257 49 -158 258 49 -158 minecraft:stone
setblock 258 49 -157 minecraft:stone
setblock 259 49 -156 minecraft:stone
setblock 260 49 -155 minecraft:stone
setblock 248 49 -152 minecraft:stone
setblock 248 49 -151 minecraft:stone
setblock 248 49 -150 minecraft:stone
fill 208 49 -145 210 49 -145 minecraft:stone
fill 208 49 -144 211 49 -144 minecraft:stone
fill 208 49 -143 211 49 -143 minecraft:stone
fill 208 49 -142 211 49 -142 minecraft:stone
setblock 223 49 -140 minecraft:stone
setblock 223 49 -139 minecraft:stone
fill 222 49 -138 223 49 -138 minecraft:stone
fill 222 49 -137 223 49 -137 minecraft:stone
fill 222 49 -136 224 49 -136 minecraft:stone
fill 223 49 -135 224 49 -135 minecraft:stone
setblock 220 49 -134 minecraft:stone
fill 219 49 -133 220 49 -133 minecraft:stone
fill 218 49 -132 220 49 -132 minecraft:stone
fill 260 49 -128 261 49 -128 minecraft:stone
setblock 257 50 -158 minecraft:stone
fill 207 50 -145 210 50 -145 minecraft:stone
fill 207 50 -144 211 50 -144 minecraft:stone
fill 207 50 -143 211 50 -143 minecraft:stone
fill 209 50 -142 210 50 -142 minecraft:stone
fill 200 51 -190 201 51 -190 minecraft:stone
fill 200 51 -189 202 51 -189 minecraft:stone
fill 200 51 -188 202 51 -188 minecraft:stone
fill 200 51 -187 202 51 -187 minecraft:stone
fill 201 51 -186 203 51 -186 minecraft:stone
fill 201 51 -185 203 51 -185 minecraft:stone
fill 201 51 -184 202 51 -184 minecraft:stone
fill 201 51 -183 202 51 -183 minecraft:stone
fill 207 51 -146 209 51 -146 minecraft:stone
fill 207 51 -145 210 51 -145 minecraft:stone
fill 207 51 -144 210 51 -144 minecraft:stone
fill 207 51 -143 209 51 -143 minecraft:stone
fill 200 52 -190 201 52 -190 minecraft:stone
fill 200 52 -189 202 52 -189 minecraft:stone
fill 200 52 -188 202 52 -188 minecraft:stone
fill 200 52 -187 202 52 -187 minecraft:stone
fill 201 52 -186 202 52 -186 minecraft:stone
fill 201 52 -185 203 52 -185 minecraft:stone
fill 201 52 -184 203 52 -184 minecraft:stone
fill 201 52 -183 202 52 -183 minecraft:stone
fill 200 52 -182 202 52 -182 minecraft:stone
fill 200 52 -181 202 52 -181 minecraft:stone
fill 207 52 -146 209 52 -146 minecraft:stone
fill 206 52 -145 209 52 -145 minecraft:stone
fill 206 52 -144 209 52 -144 minecraft:stone
fill 207 52 -143 209 52 -143 minecraft:stone
fill 200 53 -190 201 53 -190 minecraft:stone
fill 200 53 -189 201 53 -189 minecraft:stone
fill 200 53 -188 202 53 -188 minecraft:stone
fill 201 53 -187 202 53 -187 minecraft:stone
fill 201 53 -186 202 53 -186 minecraft:stone
fill 201 53 -185 202 53 -185 minecraft:stone
fill 201 53 -184 202 53 -184 minecraft:stone
fill 201 53 -183 202 53 -183 minecraft:stone
fill 200 53 -182 202 53 -182 minecraft:stone
fill 200 53 -181 202 53 -181 minecraft:stone
setblock 207 53 -147 minecraft:stone
fill 206 53 -146 209 53 -146 minecraft:stone
fill 206 53 -145 209 53 -145 minecraft:stone
fill 206 53 -144 209 53 -144 minecraft:stone
fill 207 53 -143 208 53 -143 minecraft:stone
fill 200 54 -190 201 54 -190 minecraft:stone
setblock 200 54 -189 minecraft:stone
fill 201 54 -183 202 54 -183 minecraft:stone
fill 200 54 -182 202 54 -182 minecraft:stone
fill 200 54 -181 202 54 -181 minecraft:stone
setblock 200 54 -180 minecraft:stone
setblock 200 54 -179 minecraft:stone
setblock 200 54 -178 minecraft:stone
fill 206 54 -147 207 54 -147 minecraft:stone
fill 205 54 -146 208 54 -146 minecraft:stone
fill 206 54 -145 209 54 -145 minecraft:stone
fill 206 54 -144 208 54 -144 minecraft:stone
setblock 201 55 -181 minecraft:stone
setblock 200 55 -180 minecraft:stone
setblock 200 55 -179 minecraft:stone
setblock 200 55 -178 minecraft:stone
fill 205 55 -148 206 55 -148 minecraft:stone
fill 205 55 -147 208 55 -147 minecraft:stone
fill 205 55 -146 208 55 -146 minecraft:stone
fill 205 55 -145 208 55 -145 minecraft:stone
setblock 207 55 -144 minecraft:stone
setblock 200 56 -179 minecraft:stone
setblock 200 56 -178 minecraft:stone
fill 204 56 -148 207 56 -148 minecraft:stone
fill 204 56 -147 207 56 -147 minecraft:stone
fill 204 56 -146 208 56 -146 minecraft:stone
fill 205 56 -145 207 56 -145 minecraft:stone
setblock 204 57 -149 minecraft:stone
fill 203 57 -148 206 57 -148 minecraft:stone
fill 203 57 -147 207 57 -147 minecraft:stone
fill 204 57 -146 207 57 -146 minecraft:stone
fill 203 58 -149 205 58 -149 minecraft:stone
fill 203 58 -148 206 58 -148 minecraft:stone
fill 203 58 -147 206 58 -147 minecraft:stone
fill 204 58 -146 206 58 -146 minecraft:stone
fill 203 59 -149 204 59 -149 minecraft:stone
fill 202 59 -148 205 59 -148 minecraft:stone
fill 202 59 -147 205 59 -147 minecraft:stone
fill 203 59 -146 204 59 -146 minecraft:stone
fill 207 60 -184 208 60 -184 minecraft:stone
fill 207 60 -183 208 60 -183 minecraft:stone
fill 204 60 -182 208 60 -182 minecraft:stone
fill 204 60 -181 208 60 -181 minecraft:stone
fill 204 60 -180 208 60 -180 minecraft:stone
fill 205 60 -179 207 60 -179 minecraft:stone
fill 205 60 -178 207 60 -178 minecraft:stone
fill 202 60 -149 204 60 -149 minecraft:stone
fill 202 60 -148 205 60 -148 minecraft:stone
fill 202 60 -147 204 60 -147 minecraft:stone
setblock 203 60 -146 minecraft:stone
setblock 208 61 -183 minecraft:stone
fill 204 61 -182 208 61 -182 minecraft:stone
fill 204 61 -181 208 61 -181 minecraft:stone
setblock 204 61 -180 minecraft:stone
fill 206 61 -180 208 61 -180 minecraft:stone
fill 202 61 -179 206 61 -179 minecraft:stone
fill 203 61 -178 206 61 -178 minecraft:stone
fill 202 61 -177 206 61 -177 minecraft:stone
fill 203 61 -176 205 61 -176 minecraft:stone
setblock 260 61 -152 minecraft:stone
setblock 261 61 -151 minecraft:stone
fill 203 61 -148 204 61 -148 minecraft:stone
fill 201 61 -147 204 61 -147 minecraft:stone
fill 201 61 -146 203 61 -146 minecraft:stone
setblock 202 61 -145 minecraft:stone
fill 260 62 -190 263 62 -190 minecraft:dirt
fill 259 62 -189 260 62 -189 minecraft:dirt
setblock 262 62 -189 minecraft:dirt
fill 259 62 -188 260 62 -188 minecraft:dirt
fill 204 62 -182 207 62 -182 minecraft:dirt
setblock 204 62 -181 minecraft:dirt
fill 206 62 -181 207 62 -181 minecraft:dirt
fill 203 62 -180 206 62 -180 minecraft:dirt
fill 202 62 -179 206 62 -179 minecraft:dirt
fill 201 62 -178 206 62 -178 minecraft:dirt
fill 202 62 -177 206 62 -177 minecraft:dirt
fill 203 62 -176 206 62 -176 minecraft:dirt
setblock 204 62 -175 minecraft:dirt
setblock 260 62 -152 minecraft:dirt
setblock 261 62 -151 minecraft:dirt
setblock 202 62 -148 minecraft:dirt
fill 201 62 -147 203 62 -147 minecraft:dirt
fill 201 62 -146 203 62 -146 minecraft:dirt
fill 201 62 -145 203 62 -145 minecraft:dirt
fill 201 62 -144 202 62 -144 minecraft:dirt
fill 260 62 -141 261 62 -141 minecraft:dirt
fill 259 62 -140 261 62 -140 minecraft:dirt
fill 260 62 -138 261 62 -138 minecraft:dirt
fill 260 62 -137 261 62 -137 minecraft:dirt
fill 260 62 -136 263 62 -136 minecraft:dirt
fill 260 62 -135 263 62 -135 minecraft:dirt
fill 260 63 -190 263 63 -190 minecraft:dirt
fill 258 63 -189 260 63 -189 minecraft:dirt
setblock 262 63 -189 minecraft:dirt
fill 247 63 -188 249 63 -188 minecraft:dirt
fill 257 63 -188 260 63 -188 minecraft:dirt
fill 247 63 -187 249 63 -187 minecraft:dirt
fill 257 63 -187 258 63 -187 minecraft:dirt
fill 247 63 -186 249 63 -186 minecraft:dirt
setblock 257 63 -186 minecraft:dirt
fill 206 63 -182 207 63 -182 minecraft:dirt
setblock 204 63 -181 minecraft:dirt
fill 203 63 -180 205 63 -180 minecraft:dirt
fill 202 63 -179 206 63 -179 minecraft:dirt
fill 202 63 -178 207 63 -178 minecraft:dirt
fill 202 63 -177 206 63 -177 minecraft:dirt
fill 202 63 -176 205 63 -176 minecraft:dirt
setblock 203 63 -175 minecraft:dirt
fill 259 63 -152 260 63 -152 minecraft:dirt
setblock 261 63 -151 minecraft:dirt
fill 201 63 -147 203 63 -147 minecraft:dirt
fill 200 63 -146 203 63 -146 minecraft:dirt
fill 200 63 -145 203 63 -145 minecraft:dirt
fill 201 63 -144 203 63 -144 minecraft:dirt
fill 202 63 -143 203 63 -143 minecraft:dirt
fill 260 63 -143 263 63 -143 minecraft:dirt
fill 258 63 -142 263 63 -142 minecraft:dirt
fill 258 63 -141 263 63 -141 minecraft:dirt
fill 258 63 -140 263 63 -140 minecraft:dirt
fill 258 63 -139 263 63 -139 minecraft:dirt
fill 258 63 -138 263 63 -138 minecraft:dirt
fill 258 63 -137 263 63 -137 minecraft:dirt
fill 259 63 -136 263 63 -136 minecraft:dirt
fill 259 63 -135 263 63 -135 minecraft:dirt
fill 260 63 -134 263 63 -134 minecraft:dirt
fill 261 63 -129 263 63 -129 minecraft:dirt
fill 257 63 -128 263 63 -128 minecraft:dirt
fill 257 63 -127 263 63 -127 minecraft:dirt
fill 243 64 -190 263 64 -190 minecraft:dirt
fill 242 64 -189 260 64 -189 minecraft:dirt
fill 262 64 -189 263 64 -189 minecraft:dirt
fill 242 64 -188 263 64 -188 minecraft:dirt
fill 242 64 -187 263 64 -187 minecraft:dirt
fill 242 64 -186 263 64 -186 minecraft:dirt
fill 242 64 -185 263 64 -185 minecraft:dirt
fill 242 64 -184 263 64 -184 minecraft:dirt
fill 242 64 -183 263 64 -183 minecraft:dirt
setblock 200 64 -182 minecraft:dirt
fill 243 64 -182 263 64 -182 minecraft:dirt
fill 200 64 -181 203 64 -181 minecraft:dirt
fill 243 64 -181 258 64 -181 minecraft:dirt
fill 200 64 -180 205 64 -180 minecraft:dirt
fill 243 64 -180 257 64 -180 minecraft:dirt
fill 200 64 -179 206 64 -179 minecraft:dirt
fill 243 64 -179 257 64 -179 minecraft:dirt
fill 200 64 -178 206 64 -178 minecraft:dirt
fill 243 64 -178 257 64 -178 minecraft:dirt
fill 200 64 -177 206 64 -177 minecraft:dirt
fill 242 64 -177 257 64 -177 minecraft:dirt
fill 200 64 -176 208 64 -176 minecraft:dirt
fill 242 64 -176 257 64 -176 minecraft:dirt
fill 200 64 -175 208 64 -175 minecraft:dirt
fill 242 64 -175 257 64 -175 minecraft:dirt
fill 200 64 -174 208 64 -174 minecraft:dirt
fill 242 64 -174 257 64 -174 minecraft:dirt
fill 200 64 -173 208 64 -173 minecraft:dirt
fill 241 64 -173 256 64 -173 minecraft:dirt
fill 200 64 -172 207 64 -172 minecraft:dirt
fill 241 64 -172 256 64 -172 minecraft:dirt
fill 200 64 -171 206 64 -171 minecraft:dirt
fill 243 64 -171 255 64 -171 minecraft:dirt
setblock 200 64 -170 minecraft:dirt
fill 202 64 -170 203 64 -170 minecraft:dirt
fill 245 64 -170 255 64 -170 minecraft:dirt
fill 200 64 -169 202 64 -169 minecraft:dirt
fill 246 64 -169 254 64 -169 minecraft:dirt
setblock 200 64 -168 minecraft:dirt
fill 247 64 -168 253 64 -168 minecraft:dirt
setblock 200 64 -167 minecraft:dirt
fill 248 64 -167 252 64 -167 minecraft:dirt
setblock 200 64 -166 minecraft:dirt
setblock 200 64 -164 minecraft:dirt
setblock 263 64 -160 minecraft:dirt
fill 254 64 -157 263 64 -157 minecraft:dirt
fill 252 64 -156 263 64 -156 minecraft:dirt
fill 251 64 -155 253 64 -155 minecraft:dirt
fill 255 64 -155 263 64 -155 minecraft:dirt
fill 250 64 -154 263 64 -154 minecraft:dirt
fill 250 64 -153 263 64 -153 minecraft:dirt
fill 249 64 -152 263 64 -152 minecraft:dirt
fill 248 64 -151 263 64 -151 minecraft:dirt
fill 248 64 -150 263 64 -150 minecraft:dirt
fill 247 64 -149 263 64 -149 minecraft:dirt
fill 247 64 -148 263 64 -148 minecraft:dirt
fill 247 64 -147 263 64 -147 minecraft:dirt
fill 201 64 -146 202 64 -146 minecraft:dirt
fill 247 64 -146 263 64 -146 minecraft:dirt
fill 200 64 -145 203 64 -145 minecraft:dirt
fill 247 64 -145 263 64 -145 minecraft:dirt
fill 200 64 -144 203 64 -144 minecraft:dirt
fill 247 64 -144 263 64 -144 minecraft:dirt
fill 201 64 -143 203 64 -143 minecraft:dirt
fill 247 64 -143 263 64 -143 minecraft:dirt
fill 201 64 -142 203 64 -142 minecraft:dirt
fill 247 64 -142 253 64 -142 minecraft:dirt
fill 255 64 -142 263 64 -142 minecraft:dirt
fill 202 64 -141 203 64 -141 minecraft:dirt
fill 247 64 -141 263 64 -141 minecraft:dirt
fill 247 64 -140 263 64 -140 minecraft:dirt
fill 246 64 -139 263 64 -139 minecraft:dirt
fill 243 64 -138 263 64 -138 minecraft:dirt
setblock 232 64 -137 minecraft:dirt
fill 242 64 -137 255 64 -137 minecraft:dirt
fill 257 64 -137 263 64 -137 minecraft:dirt
fill 229 64 -136 234 64 -136 minecraft:dirt
fill 241 64 -136 263 64 -136 minecraft:dirt
fill 229 64 -135 238 64 -135 minecraft:dirt
fill 241 64 -135 263 64 -135 minecraft:dirt
fill 228 64 -134 240 64 -134 minecraft:dirt
fill 242 64 -134 256 64 -134 minecraft:dirt
fill 258 64 -134 263 64 -134 minecraft:dirt
fill 229 64 -133 263 64 -133 minecraft:dirt
fill 228 64 -132 241 64 -132 minecraft:dirt
fill 243 64 -132 262 64 -132 minecraft:dirt
fill 213 64 -131 263 64 -131 minecraft:water
fill 213 64 -130 263 64 -130 minecraft:water
fill 213 64 -129 263 64 -129 minecraft:water
fill 213 64 -128 263 64 -128 minecraft:water
fill 213 64 -127 263 64 -127 minecraft:water
fill 200 65 -164 201 65 -164 minecraft:grass_block
fill 200 65 -163 202 65 -163 minecraft:grass_block
fill 200 65 -162 203 65 -162 minecraft:grass_block
setblock 200 65 -160 minecraft:grass_block
setblock 200 65 -159 minecraft:grass_block
fill 218 65 -149 219 65 -149 minecraft:grass_block
fill 217 65 -148 221 65 -148 minecraft:grass_block
setblock 200 65 -147 minecraft:grass_block
fill 217 65 -147 223 65 -147 minecraft:grass_block
fill 200 65 -146 201 65 -146 minecraft:grass_block
fill 216 65 -146 225 65 -146 minecraft:grass_block
fill 200 65 -145 201 65 -145 minecraft:grass_block
fill 215 65 -145 227 65 -145 minecraft:grass_block
fill 200 65 -144 203 65 -144 minecraft:grass_block
fill 215 65 -144 229 65 -144 minecraft:grass_block
fill 200 65 -143 204 65 -143 minecraft:grass_block
fill 215 65 -143 231 65 -143 minecraft:grass_block
fill 200 65 -142 204 65 -142 minecraft:grass_block
fill 215 65 -142 234 65 -142 minecraft:grass_block
fill 200 65 -141 203 65 -141 minecraft:grass_block
fill 216 65 -141 237 65 -141 minecraft:grass_block
fill 200 65 -140 201 65 -140 minecraft:grass_block
setblock 207 65 -140 minecraft:grass_block
fill 210 65 -140 211 65 -140 minecraft:grass_block
fill 216 65 -140 240 65 -140 minecraft:grass_block
fill 200 65 -139 208 65 -139 minecraft:grass_block
fill 210 65 -139 211 65 -139 minecraft:grass_block
fill 217 65 -139 244 65 -139 minecraft:grass_block
fill 200 65 -138 212 65 -138 minecraft:grass_block
fill 216 65 -138 250 65 -138 minecraft:grass_block
fill 200 65 -137 214 65 -137 minecraft:grass_block
setblock 216 65 -137 minecraft:grass_block
fill 219 65 -137 262 65 -137 minecraft:grass_block
fill 200 65 -136 238 65 -136 minecraft:grass_block
fill 243 65 -136 263 65 -136 minecraft:grass_block
fill 200 65 -135 263 65 -135 minecraft:grass_block
fill 200 65 -134 224 65 -134 minecraft:grass_block
fill 227 65 -134 263 65 -134 minecraft:grass_block
fill 200 65 -133 224 65 -133 minecraft:grass_block
fill 226 65 -133 263 65 -133 minecraft:grass_block
fill 200 65 -132 211 65 -132 minecraft:grass_block
fill 212 65 -132 215 65 -132 minecraft:smooth_quartz
setblock 216 65 -132 minecraft:sea_lantern
fill 217 65 -132 221 65 -132 minecraft:smooth_quartz
setblock 222 65 -132 minecraft:sea_lantern
fill 223 65 -132 227 65 -132 minecraft:smooth_quartz
setblock 228 65 -132 minecraft:sea_lantern
fill 229 65 -132 233 65 -132 minecraft:smooth_quartz
setblock 234 65 -132 minecraft:sea_lantern
fill 235 65 -132 239 65 -132 minecraft:smooth_quartz
setblock 240 65 -132 minecraft:sea_lantern
fill 241 65 -132 245 65 -132 minecraft:smooth_quartz
setblock 246 65 -132 minecraft:sea_lantern
fill 247 65 -132 251 65 -132 minecraft:smooth_quartz
setblock 252 65 -132 minecraft:sea_lantern
fill 253 65 -132 257 65 -132 minecraft:smooth_quartz
setblock 258 65 -132 minecraft:sea_lantern
fill 259 65 -132 263 65 -132 minecraft:smooth_quartz
fill 200 65 -131 211 65 -131 minecraft:grass_block
setblock 212 65 -131 minecraft:smooth_quartz
fill 213 65 -131 223 65 -131 minecraft:air
fill 200 65 -130 211 65 -130 minecraft:grass_block
setblock 212 65 -130 minecraft:smooth_quartz
fill 213 65 -130 223 65 -130 minecraft:air
setblock 225 65 -130 minecraft:air
fill 200 65 -129 211 65 -129 minecraft:grass_block
setblock 212 65 -129 minecraft:smooth_quartz
fill 213 65 -129 222 65 -129 minecraft:air
setblock 242 65 -129 minecraft:air
fill 200 65 -128 211 65 -128 minecraft:grass_block
setblock 212 65 -128 minecraft:sea_lantern
fill 213 65 -128 223 65 -128 minecraft:air
fill 200 65 -127 211 65 -127 minecraft:grass_block
setblock 212 65 -127 minecraft:smooth_quartz
fill 213 65 -127 221 65 -127 minecraft:air
setblock 231 65 -127 minecraft:air
setblock 250 65 -127 minecraft:air
setblock 225 66 -190 minecraft:lantern[hanging=false]
setblock 200 66 -147 minecraft:air
fill 200 66 -146 201 66 -146 minecraft:air
fill 200 66 -145 201 66 -145 minecraft:air
fill 200 66 -144 201 66 -144 minecraft:air
fill 200 66 -143 201 66 -143 minecraft:air
fill 200 66 -142 201 66 -142 minecraft:air
fill 200 66 -141 201 66 -141 minecraft:air
fill 200 66 -140 201 66 -140 minecraft:air
fill 200 66 -139 207 66 -139 minecraft:air
fill 200 66 -138 207 66 -138 minecraft:air
fill 200 66 -137 214 66 -137 minecraft:air
setblock 216 66 -137 minecraft:air
fill 219 66 -137 226 66 -137 minecraft:air
fill 200 66 -136 226 66 -136 minecraft:air
fill 200 66 -135 226 66 -135 minecraft:air
fill 200 66 -134 224 66 -134 minecraft:air
setblock 241 66 -134 minecraft:air
fill 200 66 -133 223 66 -133 minecraft:air
setblock 228 66 -133 minecraft:air
fill 200 66 -132 222 66 -132 minecraft:air
fill 200 66 -131 222 66 -131 minecraft:air
fill 200 66 -130 221 66 -130 minecraft:air
fill 200 66 -129 222 66 -129 minecraft:air
setblock 242 66 -129 minecraft:air
fill 200 66 -128 220 66 -128 minecraft:air
fill 200 66 -127 220 66 -127 minecraft:air
setblock 231 66 -127 minecraft:air
setblock 250 66 -127 minecraft:air
setblock 236 67 -180 minecraft:lantern[hanging=false]
setblock 201 67 -146 minecraft:air
setblock 201 67 -144 minecraft:air
setblock 201 67 -143 minecraft:air
setblock 201 67 -142 minecraft:air
setblock 201 67 -141 minecraft:air
fill 200 67 -140 201 67 -140 minecraft:air
fill 201 67 -139 207 67 -139 minecraft:air
fill 201 67 -138 207 67 -138 minecraft:air
fill 201 67 -137 214 67 -137 minecraft:air
setblock 216 67 -137 minecraft:air
fill 219 67 -137 225 67 -137 minecraft:air
fill 201 67 -136 225 67 -136 minecraft:air
fill 201 67 -135 224 67 -135 minecraft:air
setblock 241 67 -135 minecraft:air
fill 201 67 -134 222 67 -134 minecraft:air
fill 240 67 -134 242 67 -134 minecraft:air
fill 201 67 -133 221 67 -133 minecraft:air
setblock 228 67 -133 minecraft:air
setblock 241 67 -133 minecraft:air
fill 201 67 -132 221 67 -132 minecraft:air
fill 201 67 -131 220 67 -131 minecraft:air
fill 201 67 -130 219 67 -130 minecraft:air
fill 200 67 -129 218 67 -129 minecraft:air
setblock 242 67 -129 minecraft:air
fill 200 67 -128 216 67 -128 minecraft:air
setblock 220 67 -128 minecraft:air
setblock 231 67 -128 minecraft:air
fill 202 67 -127 216 67 -127 minecraft:air
fill 230 67 -127 232 67 -127 minecraft:air
setblock 250 67 -127 minecraft:air
setblock 201 68 -146 minecraft:air
setblock 201 68 -143 minecraft:air
setblock 200 68 -140 minecraft:air
setblock 207 68 -139 minecraft:air
fill 204 68 -138 207 68 -138 minecraft:air
fill 206 68 -137 214 68 -137 minecraft:air
setblock 216 68 -137 minecraft:air
fill 219 68 -137 224 68 -137 minecraft:air
setblock 202 68 -136 minecraft:air
fill 205 68 -136 223 68 -136 minecraft:air
setblock 201 68 -135 minecraft:air
fill 204 68 -135 221 68 -135 minecraft:air
fill 239 68 -135 243 68 -135 minecraft:air
fill 206 68 -134 220 68 -134 minecraft:air
setblock 228 68 -134 minecraft:air
fill 239 68 -134 243 68 -134 minecraft:air
fill 206 68 -133 220 68 -133 minecraft:air
fill 227 68 -133 229 68 -133 minecraft:air
fill 239 68 -133 243 68 -133 minecraft:air
fill 205 68 -132 219 68 -132 minecraft:air
setblock 228 68 -132 minecraft:air
fill 239 68 -132 242 68 -132 minecraft:air
fill 207 68 -131 218 68 -131 minecraft:air
setblock 201 68 -130 minecraft:air
fill 207 68 -130 217 68 -130 minecraft:air
setblock 219 68 -130 minecraft:air
setblock 201 68 -129 minecraft:air
fill 207 68 -129 208 68 -129 minecraft:air
fill 210 68 -129 211 68 -129 minecraft:air
fill 214 68 -129 216 68 -129 minecraft:air
setblock 218 68 -129 minecraft:air
fill 230 68 -129 232 68 -129 minecraft:air
setblock 242 68 -129 minecraft:air
fill 201 68 -128 202 68 -128 minecraft:air
setblock 208 68 -128 minecraft:air
setblock 216 68 -128 minecraft:air
setblock 220 68 -128 minecraft:air
fill 229 68 -128 233 68 -128 minecraft:air
setblock 202 68 -127 minecraft:air
setblock 205 68 -127 minecraft:air
setblock 216 68 -127 minecraft:air
fill 229 68 -127 233 68 -127 minecraft:air
setblock 250 68 -127 minecraft:air
setblock 201 69 -146 minecraft:air
setblock 208 69 -137 minecraft:air
setblock 212 69 -137 minecraft:air
setblock 214 69 -137 minecraft:air
setblock 216 69 -137 minecraft:air
fill 219 69 -137 220 69 -137 minecraft:air
setblock 210 69 -136 minecraft:air
fill 212 69 -136 220 69 -136 minecraft:air
fill 205 69 -135 206 69 -135 minecraft:air
fill 209 69 -135 210 69 -135 minecraft:air
fill 212 69 -135 218 69 -135 minecraft:air
fill 226 69 -135 230 69 -135 minecraft:air
fill 239 69 -135 243 69 -135 minecraft:air
setblock 206 69 -134 minecraft:air
setblock 208 69 -134 minecraft:air
fill 211 69 -134 217 69 -134 minecraft:air
fill 226 69 -134 230 69 -134 minecraft:air
fill 239 69 -134 243 69 -134 minecraft:air
setblock 206 69 -133 minecraft:air
setblock 208 69 -133 minecraft:air
fill 210 69 -133 216 69 -133 minecraft:air
fill 226 69 -133 230 69 -133 minecraft:air
fill 239 69 -133 243 69 -133 minecraft:air
setblock 205 69 -132 minecraft:air
setblock 208 69 -132 minecraft:air
fill 210 69 -132 216 69 -132 minecraft:air
fill 218 69 -132 219 69 -132 minecraft:air
fill 226 69 -132 230 69 -132 minecraft:air
fill 240 69 -132 242 69 -132 minecraft:air
fill 207 69 -131 208 69 -131 minecraft:air
setblock 210 69 -131 minecraft:air
fill 212 69 -131 214 69 -131 minecraft:air
fill 216 69 -131 217 69 -131 minecraft:air
fill 226 69 -131 230 69 -131 minecraft:air
fill 241 69 -131 243 69 -131 minecraft:air
fill 208 69 -130 211 69 -130 minecraft:air
setblock 214 69 -130 minecraft:air
setblock 216 69 -130 minecraft:air
fill 240 69 -130 244 69 -130 minecraft:air
fill 215 69 -129 216 69 -129 minecraft:air
fill 230 69 -129 233 69 -129 minecraft:air
fill 240 69 -129 244 69 -129 minecraft:air
setblock 202 69 -128 minecraft:oak_leaves[persistent=true]
setblock 220 69 -128 minecraft:air
fill 229 69 -128 233 69 -128 minecraft:air
fill 240 69 -128 244 69 -128 minecraft:air
setblock 250 69 -128 minecraft:air
fill 201 69 -127 203 69 -127 minecraft:oak_leaves[persistent=true]
fill 229 69 -127 233 69 -127 minecraft:air
fill 241 69 -127 243 69 -127 minecraft:air
fill 249 69 -127 251 69 -127 minecraft:air
setblock 201 70 -146 minecraft:air
setblock 215 70 -137 minecraft:air
setblock 212 70 -136 minecraft:air
setblock 215 70 -136 minecraft:air
setblock 212 70 -135 minecraft:air
fill 214 70 -135 215 70 -135 minecraft:air
fill 227 70 -135 229 70 -135 minecraft:air
fill 240 70 -135 242 70 -135 minecraft:air
setblock 217 70 -134 minecraft:air
fill 226 70 -134 230 70 -134 minecraft:air
fill 240 70 -134 243 70 -134 minecraft:air
setblock 215 70 -133 minecraft:air
fill 226 70 -133 230 70 -133 minecraft:air
fill 240 70 -133 242 70 -133 minecraft:air
setblock 205 70 -132 minecraft:air
fill 211 70 -132 212 70 -132 minecraft:air
fill 214 70 -132 215 70 -132 minecraft:air
fill 226 70 -132 230 70 -132 minecraft:air
setblock 241 70 -132 minecraft:air
fill 227 70 -131 230 70 -131 minecraft:air
setblock 242 70 -130 minecraft:air
fill 248 70 -130 252 70 -130 minecraft:air
setblock 216 70 -129 minecraft:air
setblock 220 70 -129 minecraft:air
setblock 231 70 -129 minecraft:air
fill 241 70 -129 243 70 -129 minecraft:air
fill 247 70 -129 253 70 -129 minecraft:air
fill 201 70 -128 203 70 -128 minecraft:oak_leaves[persistent=true]
fill 219 70 -128 221 70 -128 minecraft:air
fill 230 70 -128 232 70 -128 minecraft:air
setblock 242 70 -128 minecraft:air
fill 247 70 -128 253 70 -128 minecraft:air
fill 200 70 -127 204 70 -127 minecraft:oak_leaves[persistent=true]
setblock 220 70 -127 minecraft:air
fill 229 70 -127 232 70 -127 minecraft:air
fill 247 70 -127 253 70 -127 minecraft:air
setblock 201 71 -146 minecraft:air
setblock 241 71 -135 minecraft:air
fill 227 71 -134 229 71 -134 minecraft:air
fill 240 71 -134 242 71 -134 minecraft:air
setblock 215 71 -133 minecraft:air
fill 227 71 -133 230 71 -133 minecraft:air
fill 241 71 -133 242 71 -133 minecraft:air
setblock 205 71 -132 minecraft:air
setblock 211 71 -132 minecraft:air
fill 227 71 -132 229 71 -132 minecraft:air
setblock 228 71 -131 minecraft:air
fill 241 71 -131 243 71 -131 minecraft:air
fill 219 71 -130 222 71 -130 minecraft:air
fill 240 71 -130 244 71 -130 minecraft:air
setblock 216 71 -129 minecraft:air
fill 218 71 -129 222 71 -129 minecraft:air
fill 240 71 -129 244 71 -129 minecraft:air
fill 249 71 -129 251 71 -129 minecraft:air
setblock 202 71 -128 minecraft:oak_leaves[persistent=true]
fill 218 71 -128 222 71 -128 minecraft:air
fill 230 71 -128 231 71 -128 minecraft:air
fill 240 71 -128 244 71 -128 minecraft:air
fill 248 71 -128 252 71 -128 minecraft:air
fill 201 71 -127 203 71 -127 minecraft:oak_leaves[persistent=true]
fill 218 71 -127 222 71 -127 minecraft:air
fill 230 71 -127 232 71 -127 minecraft:air
fill 241 71 -127 243 71 -127 minecraft:air
fill 248 71 -127 252 71 -127 minecraft:air
fill 200 72 -148 201 72 -148 minecraft:air
fill 200 72 -147 201 72 -147 minecraft:air
fill 200 72 -146 201 72 -146 minecraft:air
fill 200 72 -145 201 72 -145 minecraft:air
fill 200 72 -144 201 72 -144 minecraft:air
fill 240 72 -135 242 72 -135 minecraft:air
fill 228 72 -134 229 72 -134 minecraft:air
fill 240 72 -134 242 72 -134 minecraft:air
setblock 215 72 -133 minecraft:air
fill 227 72 -133 229 72 -133 minecraft:air
fill 240 72 -133 241 72 -133 minecraft:air
setblock 205 72 -132 minecraft:air
setblock 211 72 -132 minecraft:air
fill 228 72 -132 229 72 -132 minecraft:air
fill 219 72 -130 222 72 -130 minecraft:air
setblock 242 72 -130 minecraft:air
setblock 216 72 -129 minecraft:air
fill 218 72 -129 222 72 -129 minecraft:air
fill 241 72 -129 243 72 -129 minecraft:air
setblock 200 72 -128 minecraft:air
fill 218 72 -128 222 72 -128 minecraft:air
setblock 231 72 -128 minecraft:air
setblock 242 72 -128 minecraft:air
setblock 250 72 -128 minecraft:air
setblock 200 72 -127 minecraft:air
fill 218 72 -127 222 72 -127 minecraft:air
fill 230 72 -127 232 72 -127 minecraft:air
fill 249 72 -127 251 72 -127 minecraft:air
setblock 201 73 -147 minecraft:air
fill 200 73 -146 201 73 -146 minecraft:air
setblock 201 73 -145 minecraft:air
fill 203 73 -135 207 73 -135 minecraft:air
fill 202 73 -134 208 73 -134 minecraft:air
fill 227 73 -134 228 73 -134 minecraft:air
setblock 241 73 -134 minecraft:air
fill 202 73 -133 208 73 -133 minecraft:air
setblock 210 73 -133 minecraft:air
setblock 215 73 -133 minecraft:air
fill 227 73 -133 229 73 -133 minecraft:air
fill 202 73 -132 208 73 -132 minecraft:air
setblock 211 73 -132 minecraft:air
fill 228 73 -132 229 73 -132 minecraft:air
fill 202 73 -131 208 73 -131 minecraft:air
fill 241 73 -131 243 73 -131 minecraft:air
fill 202 73 -130 208 73 -130 minecraft:air
setblock 220 73 -130 minecraft:air
fill 240 73 -130 244 73 -130 minecraft:air
fill 248 73 -130 252 73 -130 minecraft:air
setblock 200 73 -129 minecraft:air
fill 203 73 -129 207 73 -129 minecraft:air
setblock 216 73 -129 minecraft:air
fill 219 73 -129 221 73 -129 minecraft:air
fill 240 73 -129 244 73 -129 minecraft:air
fill 247 73 -129 253 73 -129 minecraft:air
setblock 200 73 -128 minecraft:air
fill 219 73 -128 221 73 -128 minecraft:air
fill 240 73 -128 244 73 -128 minecraft:air
fill 247 73 -128 253 73 -128 minecraft:air
setblock 200 73 -127 minecraft:air
fill 219 73 -127 221 73 -127 minecraft:air
setblock 231 73 -127 minecraft:air
fill 241 73 -127 243 73 -127 minecraft:air
fill 247 73 -127 253 73 -127 minecraft:air
fill 200 74 -149 201 74 -149 minecraft:air
fill 200 74 -148 201 74 -148 minecraft:air
fill 200 74 -147 201 74 -147 minecraft:air
fill 200 74 -146 201 74 -146 minecraft:air
fill 200 74 -145 201 74 -145 minecraft:air
fill 200 74 -144 201 74 -144 minecraft:air
fill 200 74 -143 201 74 -143 minecraft:air
setblock 209 74 -135 minecraft:air
fill 204 74 -134 206 74 -134 minecraft:air
fill 208 74 -134 210 74 -134 minecraft:air
fill 203 74 -133 207 74 -133 minecraft:air
setblock 209 74 -133 minecraft:air
setblock 215 74 -133 minecraft:air
setblock 228 74 -133 minecraft:air
fill 203 74 -132 207 74 -132 minecraft:air
setblock 211 74 -132 minecraft:air
fill 203 74 -131 207 74 -131 minecraft:air
fill 204 74 -130 206 74 -130 minecraft:air
setblock 217 74 -130 minecraft:air
setblock 242 74 -130 minecraft:air
fill 216 74 -129 220 74 -129 minecraft:air
fill 241 74 -129 243 74 -129 minecraft:air
fill 249 74 -129 251 74 -129 minecraft:air
setblock 217 74 -128 minecraft:air
fill 219 74 -128 221 74 -128 minecraft:air
setblock 242 74 -128 minecraft:air
fill 248 74 -128 252 74 -128 minecraft:air
setblock 200 74 -127 minecraft:air
fill 220 74 -127 221 74 -127 minecraft:air
fill 248 74 -127 252 74 -127 minecraft:air
fill 200 75 -148 201 75 -148 minecraft:air
fill 200 75 -147 201 75 -147 minecraft:air
fill 200 75 -146 201 75 -146 minecraft:air
fill 200 75 -145 201 75 -145 minecraft:air
fill 200 75 -144 201 75 -144 minecraft:air
fill 208 75 -136 210 75 -136 minecraft:air
fill 213 75 -136 217 75 -136 minecraft:air
fill 207 75 -135 218 75 -135 minecraft:air
fill 207 75 -134 218 75 -134 minecraft:air
setblock 205 75 -133 minecraft:air
fill 207 75 -133 218 75 -133 minecraft:air
fill 204 75 -132 206 75 -132 minecraft:air
fill 208 75 -132 218 75 -132 minecraft:air
setblock 205 75 -131 minecraft:air
fill 211 75 -131 218 75 -131 minecraft:air
fill 241 75 -131 243 75 -131 minecraft:air
fill 213 75 -130 219 75 -130 minecraft:air
fill 240 75 -130 244 75 -130 minecraft:air
fill 215 75 -129 221 75 -129 minecraft:air
fill 240 75 -129 244 75 -129 minecraft:air
fill 214 75 -128 221 75 -128 minecraft:air
fill 240 75 -128 244 75 -128 minecraft:air
setblock 250 75 -128 minecraft:air
fill 215 75 -127 218 75 -127 minecraft:air
setblock 220 75 -127 minecraft:air
fill 241 75 -127 243 75 -127 minecraft:air
fill 249 75 -127 251 75 -127 minecraft:air
setblock 201 76 -147 minecraft:air
fill 200 76 -146 201 76 -146 minecraft:air
setblock 201 76 -145 minecraft:air
fill 208 76 -136 210 76 -136 minecraft:air
fill 203 76 -135 211 76 -135 minecraft:air
fill 214 76 -135 216 76 -135 minecraft:air
fill 202 76 -134 217 76 -134 minecraft:air
fill 202 76 -133 217 76 -133 minecraft:air
fill 202 76 -132 217 76 -132 minecraft:air
fill 202 76 -131 218 76 -131 minecraft:air
fill 202 76 -130 208 76 -130 minecraft:air
fill 210 76 -130 212 76 -130 minecraft:air
fill 214 76 -130 219 76 -130 minecraft:air
setblock 242 76 -130 minecraft:air
fill 248 76 -130 252 76 -130 minecraft:air
fill 203 76 -129 207 76 -129 minecraft:air
fill 213 76 -129 219 76 -129 minecraft:air
fill 241 76 -129 243 76 -129 minecraft:air
fill 247 76 -129 253 76 -129 minecraft:air
fill 213 76 -128 220 76 -128 minecraft:air
setblock 242 76 -128 minecraft:air
fill 247 76 -128 253 76 -128 minecraft:air
setblock 210 76 -127 minecraft:air
fill 213 76 -127 218 76 -127 minecraft:air
fill 247 76 -127 253 76 -127 minecraft:air
fill 200 77 -149 201 77 -149 minecraft:air
fill 200 77 -148 201 77 -148 minecraft:air
fill 200 77 -147 201 77 -147 minecraft:air
fill 200 77 -146 201 77 -146 minecraft:air
fill 200 77 -145 201 77 -145 minecraft:air
fill 200 77 -144 201 77 -144 minecraft:air
fill 200 77 -143 201 77 -143 minecraft:air
fill 208 77 -136 210 77 -136 minecraft:air
fill 207 77 -135 211 77 -135 minecraft:air
fill 204 77 -134 212 77 -134 minecraft:air
setblock 215 77 -134 minecraft:air
fill 203 77 -133 216 77 -133 minecraft:air
fill 203 77 -132 213 77 -132 minecraft:air
setblock 215 77 -132 minecraft:air
fill 203 77 -131 207 77 -131 minecraft:air
fill 209 77 -131 213 77 -131 minecraft:air
fill 215 77 -131 218 77 -131 minecraft:air
fill 204 77 -130 206 77 -130 minecraft:air
fill 210 77 -130 212 77 -130 minecraft:air
fill 214 77 -130 219 77 -130 minecraft:air
fill 213 77 -129 219 77 -129 minecraft:air
setblock 242 77 -129 minecraft:air
fill 249 77 -129 251 77 -129 minecraft:air
setblock 204 77 -128 minecraft:air
fill 209 77 -128 211 77 -128 minecraft:air
fill 213 77 -128 219 77 -128 minecraft:air
fill 248 77 -128 252 77 -128 minecraft:air
fill 203 77 -127 205 77 -127 minecraft:air
fill 208 77 -127 218 77 -127 minecraft:air
fill 248 77 -127 252 77 -127 minecraft:air
fill 200 78 -148 201 78 -148 minecraft:air
fill 200 78 -147 201 78 -147 minecraft:air
fill 200 78 -146 201 78 -146 minecraft:air
fill 200 78 -145 201 78 -145 minecraft:air
fill 200 78 -144 201 78 -144 minecraft:air
fill 213 78 -136 217 78 -136 minecraft:air
setblock 209 78 -135 minecraft:air
fill 212 78 -135 218 78 -135 minecraft:air
fill 208 78 -134 218 78 -134 minecraft:air
setblock 205 78 -133 minecraft:air
fill 209 78 -133 218 78 -133 minecraft:air
fill 204 78 -132 206 78 -132 minecraft:air
fill 209 78 -132 218 78 -132 minecraft:air
setblock 205 78 -131 minecraft:air
fill 209 78 -131 218 78 -131 minecraft:air
fill 210 78 -130 218 78 -130 minecraft:air
setblock 242 78 -130 minecraft:air
fill 203 78 -129 205 78 -129 minecraft:air
fill 213 78 -129 218 78 -129 minecraft:air
fill 241 78 -129 243 78 -129 minecraft:air
fill 202 78 -128 206 78 -128 minecraft:air
fill 209 78 -128 211 78 -128 minecraft:air
fill 213 78 -128 218 78 -128 minecraft:air
setblock 242 78 -128 minecraft:air
setblock 250 78 -128 minecraft:air
fill 202 78 -127 206 78 -127 minecraft:air
fill 208 78 -127 217 78 -127 minecraft:air
fill 249 78 -127 251 78 -127 minecraft:air
setblock 201 79 -147 minecraft:air
fill 200 79 -146 201 79 -146 minecraft:air
setblock 201 79 -145 minecraft:air
fill 203 79 -135 207 79 -135 minecraft:air
fill 214 79 -135 216 79 -135 minecraft:air
fill 202 79 -134 208 79 -134 minecraft:air
fill 213 79 -134 217 79 -134 minecraft:air
fill 202 79 -133 208 79 -133 minecraft:air
setblock 211 79 -133 minecraft:air
fill 213 79 -133 217 79 -133 minecraft:air
fill 202 79 -132 208 79 -132 minecraft:air
fill 210 79 -132 217 79 -132 minecraft:air
fill 202 79 -131 208 79 -131 minecraft:air
setblock 211 79 -131 minecraft:air
fill 214 79 -131 217 79 -131 minecraft:air
fill 202 79 -130 208 79 -130 minecraft:air
fill 214 79 -130 218 79 -130 minecraft:air
fill 203 79 -129 207 79 -129 minecraft:air
fill 214 79 -129 218 79 -129 minecraft:air
setblock 242 79 -129 minecraft:air
fill 249 79 -129 251 79 -129 minecraft:air
fill 202 79 -128 206 79 -128 minecraft:air
fill 209 79 -128 211 79 -128 minecraft:air
fill 214 79 -128 218 79 -128 minecraft:air
fill 248 79 -128 252 79 -128 minecraft:air
fill 202 79 -127 206 79 -127 minecraft:air
fill 208 79 -127 212 79 -127 minecraft:air
fill 215 79 -127 217 79 -127 minecraft:air
fill 248 79 -127 252 79 -127 minecraft:air
fill 200 80 -148 201 80 -148 minecraft:air
fill 200 80 -147 201 80 -147 minecraft:air
fill 200 80 -146 201 80 -146 minecraft:air
fill 200 80 -145 201 80 -145 minecraft:air
fill 200 80 -144 201 80 -144 minecraft:air
fill 204 80 -134 206 80 -134 minecraft:air
setblock 215 80 -134 minecraft:air
fill 203 80 -133 207 80 -133 minecraft:air
fill 214 80 -133 216 80 -133 minecraft:air
fill 203 80 -132 207 80 -132 minecraft:air
setblock 215 80 -132 minecraft:air
fill 203 80 -131 207 80 -131 minecraft:air
fill 204 80 -130 206 80 -130 minecraft:air
setblock 216 80 -130 minecraft:air
fill 203 80 -129 205 80 -129 minecraft:air
fill 215 80 -129 217 80 -129 minecraft:air
fill 202 80 -128 206 80 -128 minecraft:air
setblock 216 80 -128 minecraft:air
setblock 250 80 -128 minecraft:air
fill 202 80 -127 206 80 -127 minecraft:air
fill 209 80 -127 211 80 -127 minecraft:air
fill 249 80 -127 251 80 -127 minecraft:air
fill 212 81 -134 218 81 -134 minecraft:air
setblock 205 81 -133 minecraft:air
fill 212 81 -133 218 81 -133 minecraft:air
fill 204 81 -132 206 81 -132 minecraft:air
fill 212 81 -132 218 81 -132 minecraft:air
setblock 205 81 -131 minecraft:air
fill 212 81 -131 218 81 -131 minecraft:air
fill 213 81 -130 217 81 -130 minecraft:air
setblock 204 81 -128 minecraft:air
fill 203 81 -127 205 81 -127 minecraft:air
fill 209 81 -127 211 81 -127 minecraft:air
setblock 250 81 -127 minecraft:air
fill 204 82 -134 206 82 -134 minecraft:air
fill 213 82 -134 217 82 -134 minecraft:air
fill 203 82 -133 207 82 -133 minecraft:air
fill 213 82 -133 217 82 -133 minecraft:air
fill 203 82 -132 207 82 -132 minecraft:air
fill 213 82 -132 217 82 -132 minecraft:air
fill 203 82 -131 207 82 -131 minecraft:air
fill 214 82 -131 216 82 -131 minecraft:air
fill 204 82 -130 206 82 -130 minecraft:air
setblock 250 82 -128 minecraft:air
fill 249 82 -127 251 82 -127 minecraft:air
setblock 215 83 -134 minecraft:air
setblock 205 83 -133 minecraft:air
fill 214 83 -133 216 83 -133 minecraft:air
fill 204 83 -132 206 83 -132 minecraft:air
setblock 215 83 -132 minecraft:air
setblock 205 83 -131 minecraft:air
fill 213 84 -134 217 84 -134 minecraft:air
fill 213 84 -133 217 84 -133 minecraft:air
setblock 205 84 -132 minecraft:air
fill 213 84 -132 217 84 -132 minecraft:air
fill 214 84 -131 216 84 -131 minecraft:air
setblock 218 85 -189 minecraft:sea_lantern
setblock 220 85 -186 minecraft:sea_lantern
setblock 222 85 -184 minecraft:sea_lantern
setblock 224 85 -182 minecraft:sea_lantern
setblock 226 85 -180 minecraft:sea_lantern
setblock 200 85 -179 minecraft:sea_lantern
setblock 200 85 -178 minecraft:sea_lantern
setblock 229 85 -177 minecraft:sea_lantern
setblock 202 85 -176 minecraft:sea_lantern
setblock 231 85 -176 minecraft:sea_lantern
setblock 202 85 -175 minecraft:sea_lantern
setblock 233 85 -175 minecraft:sea_lantern
setblock 204 85 -173 minecraft:sea_lantern
setblock 236 85 -173 minecraft:sea_lantern
setblock 239 85 -171 minecraft:sea_lantern
setblock 206 85 -170 minecraft:sea_lantern
setblock 242 85 -170 minecraft:sea_lantern
setblock 208 85 -168 minecraft:sea_lantern
setblock 251 85 -167 minecraft:sea_lantern
setblock 253 85 -167 minecraft:sea_lantern
setblock 255 85 -167 minecraft:sea_lantern
setblock 210 85 -166 minecraft:sea_lantern
setblock 257 85 -166 minecraft:sea_lantern
setblock 259 85 -166 minecraft:sea_lantern
setblock 262 85 -166 minecraft:sea_lantern
setblock 212 85 -165 minecraft:sea_lantern
setblock 214 85 -163 minecraft:sea_lantern
setblock 216 85 -162 minecraft:sea_lantern
setblock 219 85 -159 minecraft:sea_lantern
setblock 220 85 -158 minecraft:sea_lantern
setblock 222 85 -157 minecraft:sea_lantern
setblock 224 85 -156 minecraft:sea_lantern
setblock 225 85 -155 minecraft:sea_lantern
setblock 227 85 -154 minecraft:sea_lantern
setblock 232 85 -152 minecraft:sea_lantern
setblock 233 85 -151 minecraft:sea_lantern
setblock 235 85 -151 minecraft:sea_lantern
setblock 247 85 -147 minecraft:sea_lantern
setblock 249 85 -147 minecraft:sea_lantern
setblock 253 85 -146 minecraft:sea_lantern
setblock 255 85 -146 minecraft:sea_lantern
setblock 258 85 -146 minecraft:sea_lantern
setblock 261 85 -146 minecraft:sea_lantern
setblock 206 85 -142 minecraft:air
fill 205 85 -141 207 85 -141 minecraft:air
setblock 206 85 -140 minecraft:air
setblock 215 85 -134 minecraft:air
setblock 205 85 -133 minecraft:air
fill 214 85 -133 216 85 -133 minecraft:air
fill 204 85 -132 206 85 -132 minecraft:air
setblock 215 85 -132 minecraft:air
setblock 205 85 -131 minecraft:air
setblock 213 86 -190 minecraft:sea_lantern
setblock 202 86 -183 minecraft:sea_lantern
setblock 201 86 -182 minecraft:sea_lantern
setblock 223 86 -178 minecraft:sea_lantern
setblock 207 86 -175 minecraft:sea_lantern
setblock 229 86 -173 minecraft:sea_lantern
setblock 235 86 -169 minecraft:sea_lantern
fill 213 86 -168 214 86 -168 minecraft:sea_lantern
setblock 242 86 -166 minecraft:sea_lantern
setblock 221 86 -163 minecraft:sea_lantern
setblock 221 86 -162 minecraft:sea_lantern
setblock 229 86 -158 minecraft:sea_lantern
setblock 229 86 -157 minecraft:sea_lantern
setblock 238 86 -154 minecraft:sea_lantern
fill 237 86 -153 238 86 -153 minecraft:sea_lantern
setblock 247 86 -151 minecraft:sea_lantern
setblock 247 86 -150 minecraft:sea_lantern
setblock 256 86 -150 minecraft:sea_lantern
setblock 256 86 -149 minecraft:sea_lantern
setblock 256 86 -148 minecraft:sea_lantern
setblock 206 86 -141 minecraft:air
setblock 215 86 -133 minecraft:air
setblock 215 87 -134 minecraft:air
fill 214 87 -133 216 87 -133 minecraft:air
setblock 215 87 -132 minecraft:air
forceload remove 200 -190 263 -127
tellraw @a {"text":"Campus bau a32 fertig.","color":"green"}
