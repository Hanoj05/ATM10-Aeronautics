# Abschnitt a06: x 328..391, z -446..-383 (7453 Blöcke)
forceload add 328 -446 391 -383
tellraw @a {"text":"Campus bau a06: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a06_1 2s
