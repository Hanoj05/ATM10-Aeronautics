# Abschnitt a14: x 392..455, z -382..-319 (21105 Blöcke)
forceload add 392 -382 455 -319
tellraw @a {"text":"Campus bau a14: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a14_1 2s
