# Abschnitt a05: x 264..327, z -446..-383 (19206 Blöcke)
forceload add 264 -446 327 -383
tellraw @a {"text":"Campus bau a05: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a05_1 2s
