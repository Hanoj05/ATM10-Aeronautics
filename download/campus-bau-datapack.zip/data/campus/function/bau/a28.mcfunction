# Abschnitt a28: x 392..455, z -254..-191 (13729 Blöcke)
forceload add 392 -254 455 -191
tellraw @a {"text":"Campus bau a28: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a28_1 2s
