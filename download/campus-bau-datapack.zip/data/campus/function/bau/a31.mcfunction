# Abschnitt a31: x 136..199, z -190..-127 (19737 Blöcke)
forceload add 136 -190 199 -127
tellraw @a {"text":"Campus bau a31: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a31_1 2s
