# Abschnitt a32: x 200..263, z -190..-127 (16807 Blöcke)
forceload add 200 -190 263 -127
tellraw @a {"text":"Campus bau a32: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a32_1 2s
