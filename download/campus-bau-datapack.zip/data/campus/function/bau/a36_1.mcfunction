fill 43 45 -126 44 45 -126 minecraft:stone
fill 43 45 -125 44 45 -125 minecraft:stone
setblock 44 45 -124 minecraft:stone
fill 42 46 -126 43 46 -126 minecraft:stone
setblock 43 46 -125 minecraft:stone
setblock 42 47 -125 minecraft:stone
setblock 40 49 -126 minecraft:stone
fill 37 56 -126 41 56 -126 minecraft:stone
fill 38 56 -125 40 56 -125 minecraft:stone
fill 36 57 -126 46 57 -126 minecraft:stone
fill 37 57 -125 46 57 -125 minecraft:stone
fill 39 57 -124 45 57 -124 minecraft:stone
fill 41 57 -123 44 57 -123 minecraft:stone
fill 36 58 -126 49 58 -126 minecraft:stone
fill 37 58 -125 49 58 -125 minecraft:stone
fill 38 58 -124 49 58 -124 minecraft:stone
fill 40 58 -123 48 58 -123 minecraft:stone
fill 43 58 -122 46 58 -122 minecraft:stone
setblock 31 59 -126 minecraft:stone
fill 36 59 -126 51 59 -126 minecraft:stone
fill 37 59 -125 51 59 -125 minecraft:stone
fill 38 59 -124 50 59 -124 minecraft:stone
fill 40 59 -123 49 59 -123 minecraft:stone
fill 42 59 -122 48 59 -122 minecraft:stone
setblock 30 60 -126 minecraft:stone
fill 36 60 -126 52 60 -126 minecraft:stone
setblock 31 60 -125 minecraft:stone
fill 37 60 -125 51 60 -125 minecraft:stone
fill 38 60 -124 51 60 -124 minecraft:stone
fill 40 60 -123 50 60 -123 minecraft:stone
fill 42 60 -122 48 60 -122 minecraft:stone
fill 29 61 -126 30 61 -126 minecraft:stone
fill 36 61 -126 52 61 -126 minecraft:stone
setblock 30 61 -125 minecraft:stone
fill 37 61 -125 51 61 -125 minecraft:stone
fill 39 61 -124 51 61 -124 minecraft:stone
fill 40 61 -123 50 61 -123 minecraft:stone
fill 42 61 -122 49 61 -122 minecraft:stone
fill 28 62 -126 29 62 -126 minecraft:dirt
fill 37 62 -126 52 62 -126 minecraft:dirt
fill 29 62 -125 30 62 -125 minecraft:dirt
fill 38 62 -125 52 62 -125 minecraft:dirt
setblock 30 62 -124 minecraft:dirt
fill 40 62 -124 51 62 -124 minecraft:dirt
fill 41 62 -123 50 62 -123 minecraft:dirt
fill 43 62 -122 48 62 -122 minecraft:dirt
fill 26 63 -126 29 63 -126 minecraft:dirt
fill 39 63 -126 52 63 -126 minecraft:dirt
fill 28 63 -125 29 63 -125 minecraft:dirt
fill 40 63 -125 51 63 -125 minecraft:dirt
fill 29 63 -124 30 63 -124 minecraft:dirt
fill 41 63 -124 51 63 -124 minecraft:dirt
setblock 30 63 -123 minecraft:dirt
fill 42 63 -123 50 63 -123 minecraft:dirt
fill 44 63 -122 48 63 -122 minecraft:dirt
fill 20 64 -126 22 64 -126 minecraft:dirt
fill 24 64 -126 33 64 -126 minecraft:dirt
fill 42 64 -126 52 64 -126 minecraft:dirt
fill 21 64 -125 26 64 -125 minecraft:dirt
fill 28 64 -125 32 64 -125 minecraft:dirt
fill 42 64 -125 51 64 -125 minecraft:dirt
fill 22 64 -124 32 64 -124 minecraft:dirt
fill 43 64 -124 50 64 -124 minecraft:dirt
fill 23 64 -123 31 64 -123 minecraft:dirt
fill 44 64 -123 49 64 -123 minecraft:dirt
fill 25 64 -122 29 64 -122 minecraft:dirt
setblock 26 64 -121 minecraft:dirt
fill 20 65 -126 26 65 -126 minecraft:light_gray_concrete
setblock 27 65 -126 minecraft:sea_lantern
fill 28 65 -126 29 65 -126 minecraft:smooth_quartz
fill 30 65 -126 38 65 -126 minecraft:grass_block
fill 44 65 -126 69 65 -126 minecraft:grass_block
fill 21 65 -125 25 65 -125 minecraft:light_gray_concrete
setblock 26 65 -125 minecraft:sea_lantern
fill 27 65 -125 28 65 -125 minecraft:light_gray_concrete
fill 29 65 -125 30 65 -125 minecraft:smooth_quartz
fill 31 65 -125 37 65 -125 minecraft:grass_block
fill 44 65 -125 51 65 -125 minecraft:grass_block
fill 55 65 -125 58 65 -125 minecraft:grass_block
fill 63 65 -125 68 65 -125 minecraft:grass_block
fill 22 65 -124 24 65 -124 minecraft:light_gray_concrete
setblock 25 65 -124 minecraft:sea_lantern
fill 26 65 -124 30 65 -124 minecraft:light_gray_concrete
fill 31 65 -124 33 65 -124 minecraft:smooth_quartz
fill 34 65 -124 36 65 -124 minecraft:grass_block
fill 45 65 -124 49 65 -124 minecraft:grass_block
setblock 63 65 -124 minecraft:grass_block
fill 23 65 -123 32 65 -123 minecraft:light_gray_concrete
setblock 33 65 -123 minecraft:sea_lantern
fill 34 65 -123 36 65 -123 minecraft:smooth_quartz
fill 25 65 -122 31 65 -122 minecraft:light_gray_concrete
setblock 32 65 -122 minecraft:sea_lantern
fill 33 65 -122 36 65 -122 minecraft:light_gray_concrete
fill 37 65 -122 43 65 -122 minecraft:smooth_quartz
setblock 66 65 -122 minecraft:grass_block
fill 26 65 -121 30 65 -121 minecraft:light_gray_concrete
setblock 31 65 -121 minecraft:sea_lantern
fill 32 65 -121 39 65 -121 minecraft:light_gray_concrete
setblock 40 65 -121 minecraft:sea_lantern
fill 41 65 -121 43 65 -121 minecraft:light_gray_concrete
fill 44 65 -121 71 65 -121 minecraft:smooth_quartz
fill 28 65 -120 29 65 -120 minecraft:light_gray_concrete
setblock 30 65 -120 minecraft:sea_lantern
fill 31 65 -120 38 65 -120 minecraft:light_gray_concrete
setblock 39 65 -120 minecraft:sea_lantern
fill 40 65 -120 47 65 -120 minecraft:light_gray_concrete
setblock 48 65 -120 minecraft:sea_lantern
fill 49 65 -120 56 65 -120 minecraft:light_gray_concrete
setblock 57 65 -120 minecraft:sea_lantern
fill 58 65 -120 65 65 -120 minecraft:light_gray_concrete
setblock 66 65 -120 minecraft:sea_lantern
fill 67 65 -120 71 65 -120 minecraft:light_gray_concrete
fill 30 65 -119 37 65 -119 minecraft:light_gray_concrete
setblock 38 65 -119 minecraft:sea_lantern
fill 39 65 -119 46 65 -119 minecraft:light_gray_concrete
setblock 47 65 -119 minecraft:sea_lantern
fill 48 65 -119 55 65 -119 minecraft:light_gray_concrete
setblock 56 65 -119 minecraft:sea_lantern
fill 57 65 -119 64 65 -119 minecraft:light_gray_concrete
setblock 65 65 -119 minecraft:sea_lantern
fill 66 65 -119 71 65 -119 minecraft:light_gray_concrete
fill 33 65 -118 36 65 -118 minecraft:light_gray_concrete
setblock 37 65 -118 minecraft:sea_lantern
fill 38 65 -118 45 65 -118 minecraft:light_gray_concrete
setblock 46 65 -118 minecraft:sea_lantern
fill 47 65 -118 54 65 -118 minecraft:light_gray_concrete
setblock 55 65 -118 minecraft:sea_lantern
fill 56 65 -118 63 65 -118 minecraft:light_gray_concrete
setblock 64 65 -118 minecraft:sea_lantern
fill 65 65 -118 71 65 -118 minecraft:light_gray_concrete
fill 36 65 -117 44 65 -117 minecraft:light_gray_concrete
setblock 45 65 -117 minecraft:sea_lantern
fill 46 65 -117 53 65 -117 minecraft:light_gray_concrete
setblock 54 65 -117 minecraft:sea_lantern
fill 55 65 -117 62 65 -117 minecraft:light_gray_concrete
setblock 63 65 -117 minecraft:sea_lantern
fill 64 65 -117 71 65 -117 minecraft:light_gray_concrete
fill 44 65 -116 71 65 -116 minecraft:light_gray_concrete
setblock 23 66 -126 minecraft:air
setblock 35 66 -126 minecraft:air
setblock 40 66 -126 minecraft:air
setblock 42 66 -126 minecraft:air
setblock 51 66 -126 minecraft:air
setblock 52 66 -126 minecraft:oak_log
fill 53 66 -126 61 66 -126 minecraft:air
setblock 62 66 -126 minecraft:oak_log
fill 63 66 -126 69 66 -126 minecraft:air
setblock 27 66 -125 minecraft:air
fill 55 66 -125 58 66 -125 minecraft:air
setblock 60 66 -125 minecraft:air
fill 63 66 -125 68 66 -125 minecraft:air
setblock 41 66 -124 minecraft:air
setblock 63 66 -124 minecraft:air
setblock 37 66 -123 minecraft:air
setblock 40 66 -123 minecraft:air
setblock 43 66 -123 minecraft:air
setblock 52 66 -123 minecraft:air
setblock 55 66 -123 minecraft:air
fill 37 66 -122 38 66 -122 minecraft:air
setblock 42 66 -122 minecraft:air
fill 44 66 -122 45 66 -122 minecraft:air
setblock 50 66 -122 minecraft:air
setblock 54 66 -122 minecraft:air
setblock 66 66 -122 minecraft:air
setblock 40 66 -121 minecraft:air
fill 47 66 -121 48 66 -121 minecraft:air
setblock 50 66 -121 minecraft:air
setblock 59 66 -121 minecraft:air
setblock 36 66 -120 minecraft:air
setblock 44 66 -120 minecraft:air
setblock 54 66 -120 minecraft:air
setblock 35 66 -119 minecraft:air
fill 41 66 -119 45 66 -119 minecraft:air
setblock 49 66 -119 minecraft:air
setblock 71 66 -119 minecraft:air
fill 48 66 -118 49 66 -118 minecraft:air
setblock 52 66 -118 minecraft:air
setblock 54 66 -118 minecraft:air
setblock 69 66 -118 minecraft:air
setblock 36 66 -117 minecraft:air
setblock 45 66 -117 minecraft:air
fill 50 66 -117 55 66 -117 minecraft:air
fill 45 66 -116 56 66 -116 minecraft:air
setblock 63 66 -116 minecraft:air
fill 22 67 -126 24 67 -126 minecraft:air
setblock 35 67 -126 minecraft:air
setblock 52 67 -126 minecraft:oak_log
setblock 54 67 -126 minecraft:air
setblock 62 67 -126 minecraft:oak_log
setblock 23 67 -125 minecraft:air
setblock 27 67 -125 minecraft:air
setblock 56 67 -125 minecraft:air
setblock 63 67 -124 minecraft:air
setblock 37 67 -122 minecraft:air
setblock 66 67 -122 minecraft:air
setblock 50 67 -121 minecraft:air
setblock 35 67 -119 minecraft:air
setblock 71 67 -119 minecraft:air
setblock 69 67 -118 minecraft:air
setblock 45 67 -117 minecraft:air
setblock 50 67 -117 minecraft:air
setblock 56 67 -116 minecraft:air
fill 21 68 -126 25 68 -126 minecraft:air
setblock 35 68 -126 minecraft:air
setblock 52 68 -126 minecraft:oak_log
setblock 54 68 -126 minecraft:air
setblock 62 68 -126 minecraft:oak_log
fill 21 68 -125 25 68 -125 minecraft:air
setblock 27 68 -125 minecraft:air
fill 22 68 -124 24 68 -124 minecraft:air
setblock 63 68 -124 minecraft:air
setblock 37 68 -122 minecraft:air
setblock 66 68 -122 minecraft:air
setblock 50 68 -121 minecraft:air
setblock 35 68 -119 minecraft:air
setblock 71 68 -119 minecraft:air
setblock 69 68 -118 minecraft:air
setblock 45 68 -117 minecraft:air
setblock 56 68 -116 minecraft:air
fill 20 69 -126 28 69 -126 minecraft:air
setblock 35 69 -126 minecraft:air
setblock 36 69 -126 minecraft:oak_leaves[persistent=true]
fill 50 69 -126 51 69 -126 minecraft:oak_leaves[persistent=true]
setblock 52 69 -126 minecraft:oak_log
fill 53 69 -126 54 69 -126 minecraft:oak_leaves[persistent=true]
fill 60 69 -126 61 69 -126 minecraft:oak_leaves[persistent=true]
setblock 62 69 -126 minecraft:oak_log
fill 63 69 -126 64 69 -126 minecraft:oak_leaves[persistent=true]
fill 70 69 -126 71 69 -126 minecraft:oak_leaves[persistent=true]
fill 21 69 -125 29 69 -125 minecraft:air
fill 51 69 -125 53 69 -125 minecraft:oak_leaves[persistent=true]
fill 61 69 -125 63 69 -125 minecraft:oak_leaves[persistent=true]
setblock 71 69 -125 minecraft:oak_leaves[persistent=true]
fill 22 69 -124 24 69 -124 minecraft:air
fill 26 69 -124 28 69 -124 minecraft:air
setblock 52 69 -124 minecraft:oak_leaves[persistent=true]
setblock 62 69 -124 minecraft:oak_leaves[persistent=true]
setblock 63 69 -124 minecraft:air
setblock 27 69 -123 minecraft:air
setblock 37 69 -122 minecraft:air
setblock 66 69 -122 minecraft:air
setblock 50 69 -121 minecraft:air
setblock 35 69 -119 minecraft:air
setblock 71 69 -119 minecraft:air
setblock 69 69 -118 minecraft:air
setblock 45 69 -117 minecraft:air
setblock 56 69 -116 minecraft:air
fill 20 70 -126 28 70 -126 minecraft:air
fill 35 70 -126 37 70 -126 minecraft:oak_leaves[persistent=true]
fill 50 70 -126 51 70 -126 minecraft:oak_leaves[persistent=true]
setblock 52 70 -126 minecraft:oak_log
fill 53 70 -126 54 70 -126 minecraft:oak_leaves[persistent=true]
fill 60 70 -126 61 70 -126 minecraft:oak_leaves[persistent=true]
setblock 62 70 -126 minecraft:oak_log
fill 63 70 -126 64 70 -126 minecraft:oak_leaves[persistent=true]
fill 70 70 -126 71 70 -126 minecraft:oak_leaves[persistent=true]
fill 21 70 -125 28 70 -125 minecraft:air
fill 50 70 -125 54 70 -125 minecraft:oak_leaves[persistent=true]
fill 60 70 -125 64 70 -125 minecraft:oak_leaves[persistent=true]
fill 70 70 -125 71 70 -125 minecraft:oak_leaves[persistent=true]
fill 22 70 -124 24 70 -124 minecraft:air
fill 26 70 -124 28 70 -124 minecraft:air
fill 51 70 -124 53 70 -124 minecraft:oak_leaves[persistent=true]
fill 61 70 -124 63 70 -124 minecraft:oak_leaves[persistent=true]
setblock 71 70 -124 minecraft:oak_leaves[persistent=true]
setblock 37 70 -122 minecraft:air
setblock 66 70 -122 minecraft:air
setblock 50 70 -121 minecraft:air
setblock 35 70 -119 minecraft:air
setblock 71 70 -119 minecraft:air
setblock 69 70 -118 minecraft:air
setblock 45 70 -117 minecraft:air
fill 52 70 -116 54 70 -116 minecraft:air
setblock 56 70 -116 minecraft:air
fill 22 71 -126 24 71 -126 minecraft:air
setblock 27 71 -126 minecraft:air
setblock 35 71 -126 minecraft:air
setblock 36 71 -126 minecraft:oak_leaves[persistent=true]
fill 50 71 -126 54 71 -126 minecraft:oak_leaves[persistent=true]
fill 60 71 -126 64 71 -126 minecraft:oak_leaves[persistent=true]
fill 70 71 -126 71 71 -126 minecraft:oak_leaves[persistent=true]
setblock 23 71 -125 minecraft:air
fill 26 71 -125 28 71 -125 minecraft:air
fill 51 71 -125 53 71 -125 minecraft:oak_leaves[persistent=true]
fill 61 71 -125 63 71 -125 minecraft:oak_leaves[persistent=true]
setblock 71 71 -125 minecraft:oak_leaves[persistent=true]
setblock 27 71 -124 minecraft:air
setblock 52 71 -124 minecraft:oak_leaves[persistent=true]
setblock 62 71 -124 minecraft:oak_leaves[persistent=true]
setblock 63 71 -124 minecraft:air
setblock 37 71 -122 minecraft:air
setblock 66 71 -122 minecraft:air
setblock 50 71 -121 minecraft:air
setblock 30 71 -120 minecraft:air
fill 30 71 -119 31 71 -119 minecraft:air
setblock 35 71 -119 minecraft:air
setblock 71 71 -119 minecraft:air
setblock 69 71 -118 minecraft:air
setblock 45 71 -117 minecraft:air
fill 52 71 -116 54 71 -116 minecraft:air
setblock 56 71 -116 minecraft:air
fill 33 72 -126 37 72 -126 minecraft:air
setblock 52 72 -126 minecraft:oak_leaves[persistent=true]
setblock 54 72 -126 minecraft:air
setblock 62 72 -126 minecraft:oak_leaves[persistent=true]
setblock 63 72 -126 minecraft:air
fill 26 72 -125 27 72 -125 minecraft:air
fill 34 72 -125 36 72 -125 minecraft:air
fill 62 72 -125 64 72 -125 minecraft:air
setblock 35 72 -124 minecraft:air
fill 61 72 -124 65 72 -124 minecraft:air
setblock 50 72 -123 minecraft:air
fill 62 72 -123 64 72 -123 minecraft:air
setblock 37 72 -122 minecraft:air
fill 49 72 -122 51 72 -122 minecraft:air
setblock 63 72 -122 minecraft:air
setblock 66 72 -122 minecraft:air
setblock 35 72 -121 minecraft:air
fill 48 72 -121 52 72 -121 minecraft:air
fill 34 72 -120 36 72 -120 minecraft:air
fill 49 72 -120 51 72 -120 minecraft:air
fill 30 72 -119 31 72 -119 minecraft:air
fill 33 72 -119 37 72 -119 minecraft:air
setblock 50 72 -119 minecraft:air
setblock 71 72 -119 minecraft:air
fill 34 72 -118 36 72 -118 minecraft:air
setblock 56 72 -118 minecraft:air
setblock 69 72 -118 minecraft:air
setblock 45 72 -117 minecraft:air
setblock 51 72 -117 minecraft:air
fill 55 72 -117 57 72 -117 minecraft:air
fill 50 72 -116 58 72 -116 minecraft:air
fill 34 73 -126 36 73 -126 minecraft:air
setblock 54 73 -126 minecraft:air
fill 34 73 -125 36 73 -125 minecraft:air
fill 62 73 -125 64 73 -125 minecraft:air
setblock 71 73 -125 minecraft:air
fill 62 73 -124 64 73 -124 minecraft:air
fill 62 73 -123 64 73 -123 minecraft:air
fill 36 73 -122 37 73 -122 minecraft:air
fill 49 73 -122 51 73 -122 minecraft:air
setblock 66 73 -122 minecraft:air
fill 49 73 -121 51 73 -121 minecraft:air
fill 34 73 -120 36 73 -120 minecraft:air
fill 49 73 -120 51 73 -120 minecraft:air
setblock 30 73 -119 minecraft:air
fill 34 73 -119 36 73 -119 minecraft:air
setblock 71 73 -119 minecraft:air
fill 34 73 -118 36 73 -118 minecraft:air
setblock 69 73 -118 minecraft:air
setblock 45 73 -117 minecraft:air
fill 55 73 -117 57 73 -117 minecraft:air
fill 50 73 -116 52 73 -116 minecraft:air
fill 55 73 -116 57 73 -116 minecraft:air
fill 32 74 -126 36 74 -126 minecraft:air
fill 54 74 -126 57 74 -126 minecraft:air
setblock 33 74 -125 minecraft:air
setblock 35 74 -125 minecraft:air
setblock 56 74 -125 minecraft:air
setblock 63 74 -125 minecraft:air
fill 62 74 -124 64 74 -124 minecraft:air
setblock 66 74 -124 minecraft:air
setblock 63 74 -123 minecraft:air
fill 65 74 -123 67 74 -123 minecraft:air
setblock 37 74 -122 minecraft:air
setblock 50 74 -122 minecraft:air
fill 64 74 -122 68 74 -122 minecraft:air
fill 49 74 -121 51 74 -121 minecraft:air
fill 65 74 -121 67 74 -121 minecraft:air
setblock 35 74 -120 minecraft:air
setblock 50 74 -120 minecraft:air
setblock 66 74 -120 minecraft:air
setblock 30 74 -119 minecraft:air
fill 34 74 -119 36 74 -119 minecraft:air
setblock 71 74 -119 minecraft:air
setblock 35 74 -118 minecraft:air
setblock 69 74 -118 minecraft:air
setblock 45 74 -117 minecraft:air
setblock 56 74 -117 minecraft:air
setblock 51 74 -116 minecraft:air
fill 55 74 -116 57 74 -116 minecraft:air
fill 32 75 -126 35 75 -126 minecraft:air
fill 54 75 -126 57 75 -126 minecraft:air
setblock 35 75 -125 minecraft:air
setblock 63 75 -125 minecraft:air
fill 62 75 -124 63 75 -124 minecraft:air
fill 65 75 -123 67 75 -123 minecraft:air
setblock 37 75 -122 minecraft:air
setblock 50 75 -122 minecraft:air
fill 65 75 -122 67 75 -122 minecraft:air
setblock 50 75 -121 minecraft:air
fill 65 75 -121 67 75 -121 minecraft:air
setblock 35 75 -120 minecraft:air
setblock 35 75 -119 minecraft:air
setblock 71 75 -119 minecraft:air
setblock 69 75 -118 minecraft:air
setblock 45 75 -117 minecraft:air
setblock 56 75 -117 minecraft:air
setblock 51 75 -116 minecraft:air
fill 55 75 -116 57 75 -116 minecraft:air
setblock 33 76 -126 minecraft:air
fill 37 76 -126 39 76 -126 minecraft:air
setblock 54 76 -126 minecraft:air
setblock 56 76 -126 minecraft:air
setblock 38 76 -125 minecraft:air
setblock 37 76 -124 minecraft:air
fill 36 76 -123 38 76 -123 minecraft:air
setblock 66 76 -123 minecraft:air
fill 35 76 -122 39 76 -122 minecraft:air
fill 65 76 -122 67 76 -122 minecraft:air
fill 36 76 -121 38 76 -121 minecraft:air
setblock 66 76 -121 minecraft:air
setblock 71 76 -121 minecraft:air
setblock 37 76 -120 minecraft:air
fill 69 76 -120 71 76 -120 minecraft:air
fill 68 76 -119 71 76 -119 minecraft:air
fill 67 76 -118 71 76 -118 minecraft:air
setblock 45 76 -117 minecraft:air
fill 68 76 -117 71 76 -117 minecraft:air
setblock 69 76 -116 minecraft:air
setblock 33 77 -126 minecraft:air
fill 37 77 -126 39 77 -126 minecraft:air
fill 52 77 -126 56 77 -126 minecraft:air
fill 53 77 -125 55 77 -125 minecraft:air
setblock 54 77 -124 minecraft:air
fill 36 77 -123 38 77 -123 minecraft:air
fill 36 77 -122 38 77 -122 minecraft:air
fill 65 77 -122 66 77 -122 minecraft:air
fill 36 77 -121 38 77 -121 minecraft:air
setblock 66 77 -121 minecraft:air
fill 70 77 -120 71 77 -120 minecraft:air
setblock 45 77 -119 minecraft:air
fill 68 77 -119 71 77 -119 minecraft:air
setblock 41 77 -118 minecraft:air
fill 44 77 -118 46 77 -118 minecraft:air
fill 68 77 -118 71 77 -118 minecraft:air
fill 40 77 -117 47 77 -117 minecraft:air
fill 68 77 -117 70 77 -117 minecraft:air
fill 44 77 -116 46 77 -116 minecraft:air
setblock 38 78 -126 minecraft:air
fill 53 78 -126 55 78 -126 minecraft:air
fill 53 78 -125 55 78 -125 minecraft:air
setblock 37 78 -123 minecraft:air
fill 36 78 -122 38 78 -122 minecraft:air
setblock 37 78 -121 minecraft:air
setblock 71 78 -120 minecraft:air
fill 69 78 -119 71 78 -119 minecraft:air
fill 44 78 -118 46 78 -118 minecraft:air
fill 68 78 -118 71 78 -118 minecraft:air
fill 40 78 -117 42 78 -117 minecraft:air
fill 44 78 -117 46 78 -117 minecraft:air
setblock 69 78 -117 minecraft:air
fill 44 78 -116 46 78 -116 minecraft:air
setblock 38 79 -126 minecraft:air
fill 53 79 -126 55 79 -126 minecraft:air
setblock 54 79 -125 minecraft:air
setblock 37 79 -123 minecraft:air
fill 36 79 -122 37 79 -122 minecraft:air
setblock 37 79 -121 minecraft:air
setblock 71 79 -119 minecraft:air
setblock 45 79 -118 minecraft:air
fill 68 79 -118 69 79 -118 minecraft:air
setblock 71 79 -118 minecraft:air
setblock 41 79 -117 minecraft:air
fill 44 79 -117 46 79 -117 minecraft:air
setblock 69 79 -117 minecraft:air
setblock 45 79 -116 minecraft:air
fill 53 80 -126 55 80 -126 minecraft:air
setblock 41 80 -117 minecraft:air
setblock 45 80 -117 minecraft:air
forceload remove 8 -126 71 -63
tellraw @a {"text":"Campus bau a36 fertig.","color":"green"}
