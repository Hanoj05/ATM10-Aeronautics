fill 264 45 -126 284 45 -126 minecraft:stone
fill 264 45 -125 284 45 -125 minecraft:stone
fill 264 45 -124 271 45 -124 minecraft:stone
fill 273 45 -124 284 45 -124 minecraft:stone
fill 264 45 -123 271 45 -123 minecraft:stone
fill 274 45 -123 280 45 -123 minecraft:stone
fill 305 45 -123 307 45 -123 minecraft:stone
fill 264 45 -122 270 45 -122 minecraft:stone
fill 305 45 -122 308 45 -122 minecraft:stone
fill 264 45 -121 270 45 -121 minecraft:stone
fill 292 45 -121 297 45 -121 minecraft:stone
fill 305 45 -121 308 45 -121 minecraft:stone
fill 264 45 -120 270 45 -120 minecraft:stone
fill 292 45 -120 297 45 -120 minecraft:stone
fill 305 45 -120 308 45 -120 minecraft:stone
fill 264 45 -119 269 45 -119 minecraft:stone
fill 306 45 -119 307 45 -119 minecraft:stone
fill 264 45 -118 269 45 -118 minecraft:stone
fill 264 45 -117 269 45 -117 minecraft:stone
fill 264 45 -116 269 45 -116 minecraft:stone
fill 264 46 -126 285 46 -126 minecraft:stone
fill 264 46 -125 284 46 -125 minecraft:stone
fill 264 46 -124 271 46 -124 minecraft:stone
fill 273 46 -124 284 46 -124 minecraft:stone
fill 305 46 -124 306 46 -124 minecraft:stone
fill 264 46 -123 270 46 -123 minecraft:stone
fill 274 46 -123 281 46 -123 minecraft:stone
fill 304 46 -123 307 46 -123 minecraft:stone
fill 264 46 -122 270 46 -122 minecraft:stone
fill 293 46 -122 297 46 -122 minecraft:stone
fill 304 46 -122 307 46 -122 minecraft:stone
fill 264 46 -121 270 46 -121 minecraft:stone
fill 293 46 -121 297 46 -121 minecraft:stone
fill 304 46 -121 307 46 -121 minecraft:stone
fill 264 46 -120 270 46 -120 minecraft:stone
setblock 306 46 -120 minecraft:stone
fill 264 46 -119 270 46 -119 minecraft:stone
fill 264 46 -118 269 46 -118 minecraft:stone
fill 264 46 -117 269 46 -117 minecraft:stone
fill 264 46 -116 269 46 -116 minecraft:stone
fill 264 47 -126 287 47 -126 minecraft:stone
fill 264 47 -125 286 47 -125 minecraft:stone
fill 305 47 -125 306 47 -125 minecraft:stone
fill 264 47 -124 271 47 -124 minecraft:stone
fill 273 47 -124 286 47 -124 minecraft:stone
fill 304 47 -124 307 47 -124 minecraft:stone
fill 264 47 -123 270 47 -123 minecraft:stone
fill 274 47 -123 284 47 -123 minecraft:stone
fill 294 47 -123 298 47 -123 minecraft:stone
fill 304 47 -123 307 47 -123 minecraft:stone
fill 264 47 -122 270 47 -122 minecraft:stone
fill 294 47 -122 298 47 -122 minecraft:stone
fill 304 47 -122 307 47 -122 minecraft:stone
fill 264 47 -121 270 47 -121 minecraft:stone
fill 305 47 -121 306 47 -121 minecraft:stone
fill 264 47 -120 270 47 -120 minecraft:stone
fill 264 47 -119 270 47 -119 minecraft:stone
fill 264 47 -118 270 47 -118 minecraft:stone
fill 264 47 -117 271 47 -117 minecraft:stone
fill 274 47 -117 277 47 -117 minecraft:stone
fill 264 47 -116 271 47 -116 minecraft:stone
fill 273 47 -116 278 47 -116 minecraft:stone
fill 264 48 -126 289 48 -126 minecraft:stone
fill 296 48 -126 303 48 -126 minecraft:stone
fill 264 48 -125 291 48 -125 minecraft:stone
fill 293 48 -125 302 48 -125 minecraft:stone
fill 304 48 -125 306 48 -125 minecraft:stone
fill 264 48 -124 271 48 -124 minecraft:stone
fill 273 48 -124 301 48 -124 minecraft:stone
fill 303 48 -124 307 48 -124 minecraft:stone
fill 264 48 -123 270 48 -123 minecraft:stone
fill 274 48 -123 301 48 -123 minecraft:stone
fill 303 48 -123 306 48 -123 minecraft:stone
fill 264 48 -122 270 48 -122 minecraft:stone
fill 282 48 -122 301 48 -122 minecraft:stone
fill 304 48 -122 306 48 -122 minecraft:stone
fill 264 48 -121 270 48 -121 minecraft:stone
fill 284 48 -121 302 48 -121 minecraft:stone
fill 264 48 -120 269 48 -120 minecraft:stone
fill 284 48 -120 288 48 -120 minecraft:stone
fill 294 48 -120 302 48 -120 minecraft:stone
fill 308 48 -120 315 48 -120 minecraft:stone
fill 264 48 -119 270 48 -119 minecraft:stone
fill 284 48 -119 303 48 -119 minecraft:stone
fill 305 48 -119 315 48 -119 minecraft:stone
fill 264 48 -118 277 48 -118 minecraft:stone
fill 284 48 -118 315 48 -118 minecraft:stone
fill 264 48 -117 279 48 -117 minecraft:stone
fill 282 48 -117 316 48 -117 minecraft:stone
fill 264 48 -116 316 48 -116 minecraft:stone
fill 271 49 -126 274 49 -126 minecraft:stone
setblock 288 49 -126 minecraft:stone
fill 295 49 -126 306 49 -126 minecraft:stone
fill 271 49 -125 274 49 -125 minecraft:stone
fill 287 49 -125 306 49 -125 minecraft:stone
fill 271 49 -124 274 49 -124 minecraft:stone
fill 286 49 -124 306 49 -124 minecraft:stone
fill 271 49 -123 274 49 -123 minecraft:stone
fill 285 49 -123 306 49 -123 minecraft:stone
fill 271 49 -122 274 49 -122 minecraft:stone
fill 285 49 -122 303 49 -122 minecraft:stone
setblock 305 49 -122 minecraft:stone
fill 271 49 -121 274 49 -121 minecraft:stone
fill 284 49 -121 315 49 -121 minecraft:stone
fill 272 49 -120 275 49 -120 minecraft:stone
fill 283 49 -120 315 49 -120 minecraft:stone
fill 273 49 -119 275 49 -119 minecraft:stone
fill 283 49 -119 317 49 -119 minecraft:stone
fill 272 49 -118 277 49 -118 minecraft:stone
fill 282 49 -118 316 49 -118 minecraft:stone
fill 270 49 -117 316 49 -117 minecraft:stone
fill 318 49 -117 319 49 -117 minecraft:stone
fill 269 49 -116 316 49 -116 minecraft:stone
fill 318 49 -116 321 49 -116 minecraft:stone
fill 270 50 -126 274 50 -126 minecraft:stone
fill 294 50 -126 306 50 -126 minecraft:stone
fill 270 50 -125 275 50 -125 minecraft:stone
fill 288 50 -125 306 50 -125 minecraft:stone
fill 270 50 -124 275 50 -124 minecraft:stone
fill 287 50 -124 306 50 -124 minecraft:stone
fill 270 50 -123 275 50 -123 minecraft:stone
fill 286 50 -123 312 50 -123 minecraft:stone
fill 270 50 -122 275 50 -122 minecraft:stone
fill 286 50 -122 315 50 -122 minecraft:stone
fill 271 50 -121 275 50 -121 minecraft:stone
fill 284 50 -121 316 50 -121 minecraft:stone
setblock 318 50 -121 minecraft:stone
fill 271 50 -120 276 50 -120 minecraft:stone
fill 283 50 -120 317 50 -120 minecraft:stone
fill 272 50 -119 277 50 -119 minecraft:stone
fill 283 50 -119 318 50 -119 minecraft:stone
setblock 320 50 -119 minecraft:stone
fill 272 50 -118 277 50 -118 minecraft:stone
fill 282 50 -118 320 50 -118 minecraft:stone
fill 271 50 -117 320 50 -117 minecraft:stone
fill 322 50 -117 323 50 -117 minecraft:stone
fill 270 50 -116 327 50 -116 minecraft:stone
fill 270 51 -126 274 51 -126 minecraft:stone
fill 294 51 -126 319 51 -126 minecraft:stone
fill 270 51 -125 275 51 -125 minecraft:stone
fill 288 51 -125 315 51 -125 minecraft:stone
fill 317 51 -125 318 51 -125 minecraft:stone
fill 270 51 -124 274 51 -124 minecraft:stone
fill 287 51 -124 315 51 -124 minecraft:stone
fill 270 51 -123 275 51 -123 minecraft:stone
fill 287 51 -123 317 51 -123 minecraft:stone
fill 270 51 -122 275 51 -122 minecraft:stone
fill 286 51 -122 316 51 -122 minecraft:stone
fill 318 51 -122 320 51 -122 minecraft:stone
fill 271 51 -121 275 51 -121 minecraft:stone
fill 284 51 -121 321 51 -121 minecraft:stone
fill 271 51 -120 276 51 -120 minecraft:stone
fill 283 51 -120 320 51 -120 minecraft:stone
fill 272 51 -119 277 51 -119 minecraft:stone
fill 282 51 -119 323 51 -119 minecraft:stone
fill 325 51 -119 327 51 -119 minecraft:stone
fill 272 51 -118 278 51 -118 minecraft:stone
fill 281 51 -118 327 51 -118 minecraft:stone
fill 272 51 -117 327 51 -117 minecraft:stone
fill 271 51 -116 327 51 -116 minecraft:stone
fill 271 52 -126 274 52 -126 minecraft:stone
fill 293 52 -126 322 52 -126 minecraft:stone
fill 271 52 -125 274 52 -125 minecraft:stone
fill 288 52 -125 321 52 -125 minecraft:stone
fill 271 52 -124 274 52 -124 minecraft:stone
fill 287 52 -124 319 52 -124 minecraft:stone
fill 271 52 -123 274 52 -123 minecraft:stone
fill 287 52 -123 319 52 -123 minecraft:stone
fill 321 52 -123 322 52 -123 minecraft:stone
fill 271 52 -122 274 52 -122 minecraft:stone
fill 286 52 -122 323 52 -122 minecraft:stone
fill 272 52 -121 275 52 -121 minecraft:stone
fill 284 52 -121 327 52 -121 minecraft:stone
fill 272 52 -120 276 52 -120 minecraft:stone
fill 283 52 -120 327 52 -120 minecraft:stone
fill 272 52 -119 277 52 -119 minecraft:stone
fill 282 52 -119 327 52 -119 minecraft:stone
fill 273 52 -118 277 52 -118 minecraft:stone
fill 281 52 -118 327 52 -118 minecraft:stone
fill 272 52 -117 327 52 -117 minecraft:stone
fill 271 52 -116 327 52 -116 minecraft:stone
fill 293 53 -126 323 53 -126 minecraft:stone
fill 288 53 -125 323 53 -125 minecraft:stone
fill 287 53 -124 323 53 -124 minecraft:stone
fill 287 53 -123 326 53 -123 minecraft:stone
fill 286 53 -122 327 53 -122 minecraft:stone
fill 284 53 -121 327 53 -121 minecraft:stone
fill 283 53 -120 327 53 -120 minecraft:stone
fill 282 53 -119 327 53 -119 minecraft:stone
fill 281 53 -118 327 53 -118 minecraft:stone
fill 272 53 -117 327 53 -117 minecraft:stone
fill 271 53 -116 327 53 -116 minecraft:stone
fill 293 54 -126 326 54 -126 minecraft:stone
fill 288 54 -125 326 54 -125 minecraft:stone
fill 287 54 -124 326 54 -124 minecraft:stone
fill 287 54 -123 327 54 -123 minecraft:stone
fill 286 54 -122 327 54 -122 minecraft:stone
fill 284 54 -121 327 54 -121 minecraft:stone
fill 283 54 -120 327 54 -120 minecraft:stone
fill 282 54 -119 327 54 -119 minecraft:stone
fill 281 54 -118 327 54 -118 minecraft:stone
fill 272 54 -117 327 54 -117 minecraft:stone
fill 271 54 -116 327 54 -116 minecraft:stone
fill 292 55 -126 327 55 -126 minecraft:stone
fill 288 55 -125 327 55 -125 minecraft:stone
fill 287 55 -124 327 55 -124 minecraft:stone
fill 287 55 -123 327 55 -123 minecraft:stone
fill 286 55 -122 327 55 -122 minecraft:stone
fill 284 55 -121 327 55 -121 minecraft:stone
fill 283 55 -120 327 55 -120 minecraft:stone
fill 282 55 -119 327 55 -119 minecraft:stone
fill 281 55 -118 327 55 -118 minecraft:stone
fill 272 55 -117 327 55 -117 minecraft:stone
fill 271 55 -116 327 55 -116 minecraft:stone
fill 292 56 -126 327 56 -126 minecraft:stone
fill 289 56 -125 327 56 -125 minecraft:stone
fill 287 56 -124 327 56 -124 minecraft:stone
fill 287 56 -123 327 56 -123 minecraft:stone
fill 286 56 -122 327 56 -122 minecraft:stone
fill 284 56 -121 327 56 -121 minecraft:stone
fill 283 56 -120 327 56 -120 minecraft:stone
fill 282 56 -119 327 56 -119 minecraft:stone
fill 281 56 -118 327 56 -118 minecraft:stone
fill 272 56 -117 327 56 -117 minecraft:stone
fill 271 56 -116 327 56 -116 minecraft:stone
fill 292 57 -126 327 57 -126 minecraft:stone
fill 288 57 -125 327 57 -125 minecraft:stone
fill 287 57 -124 327 57 -124 minecraft:stone
fill 287 57 -123 327 57 -123 minecraft:stone
fill 286 57 -122 327 57 -122 minecraft:stone
fill 284 57 -121 327 57 -121 minecraft:stone
fill 282 57 -120 327 57 -120 minecraft:stone
fill 281 57 -119 327 57 -119 minecraft:stone
fill 273 57 -118 327 57 -118 minecraft:stone
fill 272 57 -117 327 57 -117 minecraft:stone
fill 271 57 -116 327 57 -116 minecraft:stone
fill 291 58 -126 327 58 -126 minecraft:stone
fill 288 58 -125 327 58 -125 minecraft:stone
fill 287 58 -124 327 58 -124 minecraft:stone
fill 286 58 -123 327 58 -123 minecraft:stone
fill 285 58 -122 327 58 -122 minecraft:stone
fill 283 58 -121 327 58 -121 minecraft:stone
fill 283 58 -120 327 58 -120 minecraft:stone
fill 281 58 -119 327 58 -119 minecraft:stone
fill 272 58 -118 327 58 -118 minecraft:stone
fill 271 58 -117 327 58 -117 minecraft:stone
fill 271 58 -116 327 58 -116 minecraft:stone
fill 290 59 -126 327 59 -126 minecraft:stone
fill 288 59 -125 327 59 -125 minecraft:stone
fill 287 59 -124 327 59 -124 minecraft:stone
fill 286 59 -123 327 59 -123 minecraft:stone
fill 285 59 -122 327 59 -122 minecraft:stone
fill 284 59 -121 327 59 -121 minecraft:stone
fill 283 59 -120 327 59 -120 minecraft:stone
setblock 279 59 -119 minecraft:stone
fill 281 59 -119 327 59 -119 minecraft:stone
fill 272 59 -118 277 59 -118 minecraft:stone
fill 279 59 -118 327 59 -118 minecraft:stone
fill 271 59 -117 327 59 -117 minecraft:stone
fill 271 59 -116 327 59 -116 minecraft:stone
fill 288 60 -126 327 60 -126 minecraft:stone
fill 287 60 -125 327 60 -125 minecraft:stone
fill 286 60 -124 327 60 -124 minecraft:stone
fill 286 60 -123 327 60 -123 minecraft:stone
fill 285 60 -122 327 60 -122 minecraft:stone
fill 283 60 -121 327 60 -121 minecraft:stone
fill 281 60 -120 327 60 -120 minecraft:stone
fill 272 60 -119 277 60 -119 minecraft:stone
fill 279 60 -119 327 60 -119 minecraft:stone
fill 271 60 -118 327 60 -118 minecraft:stone
fill 272 60 -117 327 60 -117 minecraft:stone
fill 271 60 -116 327 60 -116 minecraft:stone
fill 287 61 -126 313 61 -126 minecraft:dirt
fill 314 61 -126 327 61 -126 minecraft:stone
fill 286 61 -125 327 61 -125 minecraft:stone
setblock 272 61 -124 minecraft:stone
fill 286 61 -124 327 61 -124 minecraft:stone
setblock 272 61 -123 minecraft:stone
fill 285 61 -123 327 61 -123 minecraft:stone
fill 284 61 -122 327 61 -122 minecraft:stone
fill 281 61 -121 327 61 -121 minecraft:stone
fill 274 61 -120 277 61 -120 minecraft:stone
fill 280 61 -120 327 61 -120 minecraft:stone
fill 271 61 -119 327 61 -119 minecraft:stone
fill 271 61 -118 327 61 -118 minecraft:stone
fill 270 61 -117 327 61 -117 minecraft:stone
fill 270 61 -116 327 61 -116 minecraft:stone
fill 286 62 -126 327 62 -126 minecraft:dirt
setblock 272 62 -125 minecraft:dirt
fill 286 62 -125 327 62 -125 minecraft:dirt
fill 270 62 -124 274 62 -124 minecraft:dirt
fill 285 62 -124 327 62 -124 minecraft:dirt
setblock 270 62 -123 minecraft:dirt
fill 272 62 -123 274 62 -123 minecraft:dirt
fill 285 62 -123 327 62 -123 minecraft:dirt
setblock 270 62 -122 minecraft:dirt
fill 272 62 -122 276 62 -122 minecraft:dirt
fill 281 62 -122 327 62 -122 minecraft:dirt
fill 273 62 -121 327 62 -121 minecraft:dirt
setblock 271 62 -120 minecraft:dirt
fill 273 62 -120 327 62 -120 minecraft:dirt
fill 271 62 -119 327 62 -119 minecraft:dirt
fill 269 62 -118 327 62 -118 minecraft:dirt
fill 269 62 -117 327 62 -117 minecraft:dirt
fill 269 62 -116 327 62 -116 minecraft:dirt
fill 264 63 -126 281 63 -126 minecraft:dirt
fill 285 63 -126 327 63 -126 minecraft:dirt
fill 264 63 -125 327 63 -125 minecraft:dirt
fill 264 63 -124 327 63 -124 minecraft:dirt
fill 264 63 -123 327 63 -123 minecraft:dirt
fill 264 63 -122 327 63 -122 minecraft:dirt
fill 264 63 -121 267 63 -121 minecraft:dirt
fill 269 63 -121 327 63 -121 minecraft:dirt
fill 264 63 -120 266 63 -120 minecraft:dirt
fill 270 63 -120 327 63 -120 minecraft:dirt
fill 264 63 -119 267 63 -119 minecraft:dirt
fill 269 63 -119 327 63 -119 minecraft:dirt
fill 264 63 -118 266 63 -118 minecraft:dirt
fill 268 63 -118 327 63 -118 minecraft:dirt
fill 264 63 -117 327 63 -117 minecraft:dirt
fill 264 63 -116 327 63 -116 minecraft:dirt
fill 264 64 -126 313 64 -126 minecraft:water
fill 314 64 -126 327 64 -126 minecraft:dirt
fill 264 64 -125 327 64 -125 minecraft:dirt
fill 264 64 -124 327 64 -124 minecraft:dirt
fill 264 64 -123 327 64 -123 minecraft:dirt
fill 264 64 -122 327 64 -122 minecraft:dirt
fill 264 64 -121 327 64 -121 minecraft:dirt
fill 264 64 -120 327 64 -120 minecraft:dirt
fill 264 64 -119 327 64 -119 minecraft:dirt
fill 264 64 -118 327 64 -118 minecraft:dirt
fill 264 64 -117 327 64 -117 minecraft:dirt
fill 264 64 -116 327 64 -116 minecraft:dirt
setblock 314 65 -126 minecraft:smooth_quartz
fill 315 65 -126 319 65 -126 minecraft:grass_block
setblock 320 65 -126 minecraft:light_gray_concrete
fill 321 65 -126 323 65 -126 minecraft:smooth_quartz
setblock 324 65 -126 minecraft:sea_lantern
fill 325 65 -126 327 65 -126 minecraft:grass_block
fill 264 65 -125 268 65 -125 minecraft:smooth_quartz
setblock 269 65 -125 minecraft:sea_lantern
fill 270 65 -125 274 65 -125 minecraft:smooth_quartz
setblock 275 65 -125 minecraft:sea_lantern
fill 276 65 -125 280 65 -125 minecraft:smooth_quartz
setblock 281 65 -125 minecraft:sea_lantern
fill 282 65 -125 286 65 -125 minecraft:smooth_quartz
setblock 287 65 -125 minecraft:sea_lantern
fill 288 65 -125 292 65 -125 minecraft:smooth_quartz
setblock 293 65 -125 minecraft:sea_lantern
fill 294 65 -125 298 65 -125 minecraft:smooth_quartz
setblock 299 65 -125 minecraft:sea_lantern
fill 300 65 -125 304 65 -125 minecraft:smooth_quartz
setblock 305 65 -125 minecraft:sea_lantern
fill 306 65 -125 310 65 -125 minecraft:smooth_quartz
setblock 311 65 -125 minecraft:sea_lantern
fill 312 65 -125 314 65 -125 minecraft:smooth_quartz
fill 315 65 -125 319 65 -125 minecraft:grass_block
setblock 320 65 -125 minecraft:sea_lantern
fill 321 65 -125 323 65 -125 minecraft:smooth_quartz
setblock 324 65 -125 minecraft:sea_lantern
fill 325 65 -125 327 65 -125 minecraft:grass_block
fill 264 65 -124 320 65 -124 minecraft:grass_block
fill 321 65 -124 323 65 -124 minecraft:sea_lantern
fill 324 65 -124 327 65 -124 minecraft:grass_block
fill 264 65 -123 327 65 -123 minecraft:grass_block
fill 264 65 -122 327 65 -122 minecraft:grass_block
fill 264 65 -121 327 65 -121 minecraft:smooth_quartz
setblock 264 65 -120 minecraft:sea_lantern
fill 265 65 -120 272 65 -120 minecraft:light_gray_concrete
setblock 273 65 -120 minecraft:sea_lantern
fill 274 65 -120 281 65 -120 minecraft:light_gray_concrete
setblock 282 65 -120 minecraft:sea_lantern
fill 283 65 -120 290 65 -120 minecraft:light_gray_concrete
setblock 291 65 -120 minecraft:sea_lantern
fill 292 65 -120 299 65 -120 minecraft:light_gray_concrete
setblock 300 65 -120 minecraft:sea_lantern
fill 301 65 -120 308 65 -120 minecraft:light_gray_concrete
setblock 309 65 -120 minecraft:sea_lantern
fill 310 65 -120 317 65 -120 minecraft:light_gray_concrete
setblock 318 65 -120 minecraft:sea_lantern
fill 319 65 -120 326 65 -120 minecraft:light_gray_concrete
setblock 327 65 -120 minecraft:sea_lantern
fill 264 65 -119 271 65 -119 minecraft:light_gray_concrete
setblock 272 65 -119 minecraft:sea_lantern
fill 273 65 -119 280 65 -119 minecraft:light_gray_concrete
setblock 281 65 -119 minecraft:sea_lantern
fill 282 65 -119 289 65 -119 minecraft:light_gray_concrete
setblock 290 65 -119 minecraft:sea_lantern
fill 291 65 -119 298 65 -119 minecraft:light_gray_concrete
setblock 299 65 -119 minecraft:sea_lantern
fill 300 65 -119 307 65 -119 minecraft:light_gray_concrete
setblock 308 65 -119 minecraft:sea_lantern
fill 309 65 -119 316 65 -119 minecraft:light_gray_concrete
setblock 317 65 -119 minecraft:sea_lantern
fill 318 65 -119 325 65 -119 minecraft:light_gray_concrete
setblock 326 65 -119 minecraft:sea_lantern
setblock 327 65 -119 minecraft:light_gray_concrete
fill 264 65 -118 270 65 -118 minecraft:light_gray_concrete
setblock 271 65 -118 minecraft:sea_lantern
fill 272 65 -118 279 65 -118 minecraft:light_gray_concrete
setblock 280 65 -118 minecraft:sea_lantern
fill 281 65 -118 288 65 -118 minecraft:light_gray_concrete
setblock 289 65 -118 minecraft:sea_lantern
fill 290 65 -118 297 65 -118 minecraft:light_gray_concrete
setblock 298 65 -118 minecraft:sea_lantern
fill 299 65 -118 306 65 -118 minecraft:light_gray_concrete
setblock 307 65 -118 minecraft:sea_lantern
fill 308 65 -118 315 65 -118 minecraft:light_gray_concrete
setblock 316 65 -118 minecraft:sea_lantern
fill 317 65 -118 324 65 -118 minecraft:light_gray_concrete
setblock 325 65 -118 minecraft:sea_lantern
fill 326 65 -118 327 65 -118 minecraft:light_gray_concrete
fill 264 65 -117 269 65 -117 minecraft:light_gray_concrete
setblock 270 65 -117 minecraft:sea_lantern
fill 271 65 -117 278 65 -117 minecraft:light_gray_concrete
setblock 279 65 -117 minecraft:sea_lantern
fill 280 65 -117 287 65 -117 minecraft:light_gray_concrete
setblock 288 65 -117 minecraft:sea_lantern
fill 289 65 -117 296 65 -117 minecraft:light_gray_concrete
setblock 297 65 -117 minecraft:sea_lantern
fill 298 65 -117 305 65 -117 minecraft:light_gray_concrete
setblock 306 65 -117 minecraft:sea_lantern
fill 307 65 -117 314 65 -117 minecraft:light_gray_concrete
setblock 315 65 -117 minecraft:sea_lantern
fill 316 65 -117 323 65 -117 minecraft:light_gray_concrete
setblock 324 65 -117 minecraft:sea_lantern
fill 325 65 -117 327 65 -117 minecraft:light_gray_concrete
fill 264 65 -116 327 65 -116 minecraft:light_gray_concrete
forceload remove 264 -126 327 -63
tellraw @a {"text":"Campus bau a40 fertig.","color":"green"}
