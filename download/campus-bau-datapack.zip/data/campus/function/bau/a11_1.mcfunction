fill 221 45 -382 223 45 -382 minecraft:stone
fill 234 45 -382 236 45 -382 minecraft:stone
fill 239 45 -382 243 45 -382 minecraft:stone
fill 220 45 -381 223 45 -381 minecraft:stone
setblock 235 45 -381 minecraft:stone
fill 238 45 -381 241 45 -381 minecraft:stone
fill 220 45 -380 221 45 -380 minecraft:stone
setblock 235 45 -380 minecraft:stone
fill 238 45 -380 240 45 -380 minecraft:stone
fill 211 45 -379 217 45 -379 minecraft:stone
fill 237 45 -379 240 45 -379 minecraft:stone
fill 237 45 -378 240 45 -378 minecraft:stone
fill 238 45 -377 239 45 -377 minecraft:stone
setblock 229 45 -321 minecraft:stone
setblock 230 45 -320 minecraft:stone
setblock 236 46 -382 minecraft:stone
fill 239 46 -382 241 46 -382 minecraft:stone
fill 221 46 -381 222 46 -381 minecraft:stone
setblock 236 46 -381 minecraft:stone
fill 239 46 -381 241 46 -381 minecraft:stone
fill 238 46 -380 240 46 -380 minecraft:stone
fill 238 46 -379 240 46 -379 minecraft:stone
fill 237 46 -378 240 46 -378 minecraft:stone
fill 237 46 -377 239 46 -377 minecraft:stone
fill 237 46 -376 239 46 -376 minecraft:stone
setblock 239 46 -375 minecraft:stone
fill 227 46 -321 228 46 -321 minecraft:stone
fill 228 46 -320 229 46 -320 minecraft:stone
fill 228 46 -319 229 46 -319 minecraft:stone
setblock 237 47 -382 minecraft:stone
fill 239 47 -381 240 47 -381 minecraft:stone
fill 239 47 -380 241 47 -380 minecraft:stone
fill 210 47 -379 215 47 -379 minecraft:stone
fill 238 47 -379 240 47 -379 minecraft:stone
fill 238 47 -378 240 47 -378 minecraft:stone
fill 237 47 -377 239 47 -377 minecraft:stone
fill 237 47 -376 239 47 -376 minecraft:stone
fill 237 47 -375 239 47 -375 minecraft:stone
setblock 239 47 -374 minecraft:stone
setblock 232 47 -368 minecraft:stone
fill 233 47 -366 235 47 -366 minecraft:stone
fill 233 47 -365 234 47 -365 minecraft:stone
fill 226 47 -320 228 47 -320 minecraft:stone
fill 226 47 -319 227 47 -319 minecraft:stone
setblock 237 48 -382 minecraft:stone
setblock 237 48 -381 minecraft:stone
fill 239 48 -380 240 48 -380 minecraft:stone
fill 210 48 -379 214 48 -379 minecraft:stone
fill 239 48 -379 240 48 -379 minecraft:stone
fill 208 48 -378 212 48 -378 minecraft:stone
fill 238 48 -378 240 48 -378 minecraft:stone
setblock 207 48 -377 minecraft:stone
fill 209 48 -377 211 48 -377 minecraft:stone
fill 238 48 -377 239 48 -377 minecraft:stone
fill 238 48 -376 239 48 -376 minecraft:stone
fill 237 48 -375 239 48 -375 minecraft:stone
fill 237 48 -374 239 48 -374 minecraft:stone
setblock 239 48 -373 minecraft:stone
setblock 232 48 -370 minecraft:stone
fill 231 48 -369 233 48 -369 minecraft:stone
setblock 229 48 -368 minecraft:stone
fill 231 48 -368 233 48 -368 minecraft:stone
fill 231 48 -367 235 48 -367 minecraft:stone
fill 231 48 -366 236 48 -366 minecraft:stone
fill 232 48 -365 236 48 -365 minecraft:stone
fill 224 48 -320 226 48 -320 minecraft:stone
fill 224 48 -319 226 48 -319 minecraft:stone
setblock 243 49 -382 minecraft:stone
setblock 237 49 -381 minecraft:stone
setblock 237 49 -380 minecraft:stone
fill 210 49 -379 212 49 -379 minecraft:stone
setblock 239 49 -379 minecraft:stone
fill 208 49 -378 212 49 -378 minecraft:stone
fill 239 49 -378 240 49 -378 minecraft:stone
fill 207 49 -377 210 49 -377 minecraft:stone
fill 238 49 -377 239 49 -377 minecraft:stone
fill 238 49 -376 239 49 -376 minecraft:stone
fill 238 49 -375 239 49 -375 minecraft:stone
fill 237 49 -374 239 49 -374 minecraft:stone
fill 238 49 -373 239 49 -373 minecraft:stone
fill 228 49 -370 233 49 -370 minecraft:stone
fill 228 49 -369 234 49 -369 minecraft:stone
fill 227 49 -368 235 49 -368 minecraft:stone
fill 228 49 -367 236 49 -367 minecraft:stone
fill 228 49 -366 236 49 -366 minecraft:stone
fill 229 49 -365 236 49 -365 minecraft:stone
fill 233 49 -364 235 49 -364 minecraft:stone
setblock 234 49 -363 minecraft:stone
fill 223 49 -320 225 49 -320 minecraft:stone
fill 222 49 -319 225 49 -319 minecraft:stone
setblock 237 50 -380 minecraft:stone
setblock 210 50 -379 minecraft:stone
setblock 237 50 -379 minecraft:stone
fill 208 50 -378 212 50 -378 minecraft:stone
fill 207 50 -377 210 50 -377 minecraft:stone
setblock 239 50 -377 minecraft:stone
setblock 239 50 -376 minecraft:stone
fill 238 50 -375 239 50 -375 minecraft:stone
setblock 238 50 -374 minecraft:stone
fill 228 50 -371 230 50 -371 minecraft:stone
fill 227 50 -370 233 50 -370 minecraft:stone
fill 227 50 -369 235 50 -369 minecraft:stone
fill 227 50 -368 235 50 -368 minecraft:stone
fill 227 50 -367 236 50 -367 minecraft:stone
fill 227 50 -366 236 50 -366 minecraft:stone
fill 228 50 -365 236 50 -365 minecraft:stone
fill 229 50 -364 230 50 -364 minecraft:stone
fill 232 50 -364 236 50 -364 minecraft:stone
fill 233 50 -363 235 50 -363 minecraft:stone
fill 222 50 -320 223 50 -320 minecraft:stone
fill 220 50 -319 223 50 -319 minecraft:stone
fill 208 51 -378 212 51 -378 minecraft:stone
setblock 237 51 -378 minecraft:stone
fill 207 51 -377 210 51 -377 minecraft:stone
setblock 238 51 -374 minecraft:stone
setblock 237 51 -372 minecraft:stone
fill 228 51 -371 230 51 -371 minecraft:stone
fill 237 51 -371 238 51 -371 minecraft:stone
fill 227 51 -370 232 51 -370 minecraft:stone
fill 227 51 -369 234 51 -369 minecraft:stone
fill 227 51 -368 235 51 -368 minecraft:stone
fill 227 51 -367 235 51 -367 minecraft:stone
fill 227 51 -366 236 51 -366 minecraft:stone
fill 228 51 -365 236 51 -365 minecraft:stone
fill 229 51 -364 230 51 -364 minecraft:stone
fill 233 51 -364 235 51 -364 minecraft:stone
fill 233 51 -363 234 51 -363 minecraft:stone
setblock 220 51 -319 minecraft:stone
fill 208 52 -378 212 52 -378 minecraft:stone
fill 207 52 -377 210 52 -377 minecraft:stone
fill 236 52 -377 237 52 -377 minecraft:stone
setblock 209 52 -376 minecraft:stone
fill 236 52 -376 237 52 -376 minecraft:stone
setblock 236 52 -375 minecraft:stone
setblock 236 52 -374 minecraft:stone
fill 236 52 -373 237 52 -373 minecraft:stone
fill 236 52 -372 238 52 -372 minecraft:stone
fill 229 52 -371 230 52 -371 minecraft:stone
fill 236 52 -371 238 52 -371 minecraft:stone
fill 228 52 -370 231 52 -370 minecraft:stone
fill 237 52 -370 238 52 -370 minecraft:stone
fill 227 52 -369 231 52 -369 minecraft:stone
fill 227 52 -368 232 52 -368 minecraft:stone
fill 227 52 -367 231 52 -367 minecraft:stone
fill 228 52 -366 231 52 -366 minecraft:stone
fill 228 52 -365 230 52 -365 minecraft:stone
setblock 263 52 -332 minecraft:stone
fill 262 52 -331 263 52 -331 minecraft:stone
fill 262 52 -330 263 52 -330 minecraft:stone
fill 262 52 -329 263 52 -329 minecraft:stone
fill 261 52 -328 263 52 -328 minecraft:stone
fill 261 52 -327 263 52 -327 minecraft:stone
fill 261 52 -326 263 52 -326 minecraft:stone
fill 261 52 -325 263 52 -325 minecraft:stone
fill 261 52 -324 263 52 -324 minecraft:stone
fill 261 52 -323 263 52 -323 minecraft:stone
fill 262 52 -322 263 52 -322 minecraft:stone
fill 262 52 -321 263 52 -321 minecraft:stone
fill 262 52 -320 263 52 -320 minecraft:stone
setblock 263 52 -319 minecraft:stone
fill 208 53 -378 212 53 -378 minecraft:stone
fill 207 53 -377 210 53 -377 minecraft:stone
fill 208 53 -376 209 53 -376 minecraft:stone
fill 236 53 -376 237 53 -376 minecraft:stone
setblock 236 53 -375 minecraft:stone
setblock 236 53 -374 minecraft:stone
fill 236 53 -373 238 53 -373 minecraft:stone
fill 236 53 -372 238 53 -372 minecraft:stone
fill 236 53 -371 237 53 -371 minecraft:stone
fill 236 53 -370 237 53 -370 minecraft:stone
setblock 237 53 -369 minecraft:stone
setblock 263 53 -333 minecraft:stone
setblock 263 53 -332 minecraft:stone
fill 262 53 -331 263 53 -331 minecraft:stone
fill 262 53 -330 263 53 -330 minecraft:stone
fill 261 53 -329 263 53 -329 minecraft:stone
fill 261 53 -328 263 53 -328 minecraft:stone
fill 261 53 -327 263 53 -327 minecraft:stone
fill 261 53 -326 263 53 -326 minecraft:stone
fill 261 53 -325 263 53 -325 minecraft:stone
fill 261 53 -324 263 53 -324 minecraft:stone
fill 261 53 -323 263 53 -323 minecraft:stone
fill 261 53 -322 263 53 -322 minecraft:stone
fill 261 53 -321 263 53 -321 minecraft:stone
fill 262 53 -320 263 53 -320 minecraft:stone
fill 262 53 -319 263 53 -319 minecraft:stone
fill 208 54 -378 211 54 -378 minecraft:stone
fill 207 54 -377 210 54 -377 minecraft:stone
fill 207 54 -376 209 54 -376 minecraft:stone
setblock 236 54 -375 minecraft:stone
setblock 238 54 -375 minecraft:stone
fill 236 54 -374 237 54 -374 minecraft:stone
fill 236 54 -373 238 54 -373 minecraft:stone
fill 236 54 -372 237 54 -372 minecraft:stone
fill 236 54 -371 237 54 -371 minecraft:stone
fill 236 54 -370 237 54 -370 minecraft:stone
fill 235 54 -369 237 54 -369 minecraft:stone
setblock 237 54 -368 minecraft:stone
setblock 263 54 -337 minecraft:stone
fill 262 54 -336 263 54 -336 minecraft:stone
fill 262 54 -335 263 54 -335 minecraft:stone
setblock 263 54 -334 minecraft:stone
setblock 263 54 -333 minecraft:stone
setblock 263 54 -332 minecraft:stone
fill 262 54 -331 263 54 -331 minecraft:stone
fill 261 54 -330 263 54 -330 minecraft:stone
fill 261 54 -329 263 54 -329 minecraft:stone
fill 261 54 -328 263 54 -328 minecraft:stone
fill 261 54 -327 263 54 -327 minecraft:stone
fill 261 54 -326 263 54 -326 minecraft:stone
fill 261 54 -325 263 54 -325 minecraft:stone
fill 261 54 -324 263 54 -324 minecraft:stone
fill 261 54 -323 263 54 -323 minecraft:stone
fill 261 54 -322 263 54 -322 minecraft:stone
fill 261 54 -321 263 54 -321 minecraft:stone
fill 262 54 -320 263 54 -320 minecraft:stone
fill 262 54 -319 263 54 -319 minecraft:stone
fill 208 55 -378 210 55 -378 minecraft:stone
fill 207 55 -377 210 55 -377 minecraft:stone
fill 207 55 -376 209 55 -376 minecraft:stone
fill 236 55 -374 238 55 -374 minecraft:stone
fill 236 55 -373 237 55 -373 minecraft:stone
fill 236 55 -372 237 55 -372 minecraft:stone
fill 235 55 -371 237 55 -371 minecraft:stone
fill 235 55 -370 237 55 -370 minecraft:stone
fill 235 55 -369 237 55 -369 minecraft:stone
fill 235 55 -368 236 55 -368 minecraft:stone
fill 259 55 -344 261 55 -344 minecraft:stone
fill 246 55 -343 247 55 -343 minecraft:stone
fill 259 55 -343 262 55 -343 minecraft:stone
fill 245 55 -342 248 55 -342 minecraft:stone
fill 259 55 -342 262 55 -342 minecraft:stone
fill 244 55 -341 248 55 -341 minecraft:stone
fill 259 55 -341 262 55 -341 minecraft:stone
fill 244 55 -340 247 55 -340 minecraft:stone
fill 259 55 -340 263 55 -340 minecraft:stone
fill 243 55 -339 247 55 -339 minecraft:stone
fill 259 55 -339 263 55 -339 minecraft:stone
fill 242 55 -338 247 55 -338 minecraft:stone
fill 260 55 -338 263 55 -338 minecraft:stone
fill 242 55 -337 246 55 -337 minecraft:stone
fill 260 55 -337 263 55 -337 minecraft:stone
fill 242 55 -336 246 55 -336 minecraft:stone
fill 261 55 -336 263 55 -336 minecraft:stone
fill 242 55 -335 245 55 -335 minecraft:stone
fill 262 55 -335 263 55 -335 minecraft:stone
fill 241 55 -334 245 55 -334 minecraft:stone
fill 262 55 -334 263 55 -334 minecraft:stone
fill 241 55 -333 245 55 -333 minecraft:stone
setblock 263 55 -333 minecraft:stone
fill 241 55 -332 244 55 -332 minecraft:stone
setblock 263 55 -332 minecraft:stone
fill 241 55 -331 244 55 -331 minecraft:stone
fill 262 55 -331 263 55 -331 minecraft:stone
fill 241 55 -330 244 55 -330 minecraft:stone
fill 262 55 -330 263 55 -330 minecraft:stone
fill 241 55 -329 243 55 -329 minecraft:stone
fill 261 55 -329 263 55 -329 minecraft:stone
fill 261 55 -328 263 55 -328 minecraft:stone
fill 261 55 -327 263 55 -327 minecraft:stone
fill 261 55 -326 263 55 -326 minecraft:stone
fill 261 55 -325 263 55 -325 minecraft:stone
fill 261 55 -324 263 55 -324 minecraft:stone
fill 261 55 -323 263 55 -323 minecraft:stone
fill 261 55 -322 263 55 -322 minecraft:stone
fill 261 55 -321 263 55 -321 minecraft:stone
fill 262 55 -320 263 55 -320 minecraft:stone
fill 262 55 -319 263 55 -319 minecraft:stone
fill 208 56 -378 210 56 -378 minecraft:stone
fill 207 56 -377 210 56 -377 minecraft:stone
fill 207 56 -376 209 56 -376 minecraft:stone
fill 235 56 -372 237 56 -372 minecraft:stone
fill 235 56 -371 237 56 -371 minecraft:stone
fill 235 56 -370 236 56 -370 minecraft:stone
fill 235 56 -369 236 56 -369 minecraft:stone
fill 235 56 -368 236 56 -368 minecraft:stone
fill 234 56 -367 236 56 -367 minecraft:stone
fill 257 56 -349 259 56 -349 minecraft:stone
fill 256 56 -348 260 56 -348 minecraft:stone
fill 256 56 -347 261 56 -347 minecraft:stone
fill 247 56 -346 248 56 -346 minecraft:stone
fill 257 56 -346 261 56 -346 minecraft:stone
fill 246 56 -345 249 56 -345 minecraft:stone
fill 257 56 -345 261 56 -345 minecraft:stone
fill 246 56 -344 250 56 -344 minecraft:stone
fill 258 56 -344 262 56 -344 minecraft:stone
fill 245 56 -343 249 56 -343 minecraft:stone
fill 258 56 -343 262 56 -343 minecraft:stone
fill 244 56 -342 249 56 -342 minecraft:stone
fill 258 56 -342 262 56 -342 minecraft:stone
fill 244 56 -341 249 56 -341 minecraft:stone
fill 258 56 -341 263 56 -341 minecraft:stone
fill 243 56 -340 248 56 -340 minecraft:stone
fill 259 56 -340 263 56 -340 minecraft:stone
fill 243 56 -339 247 56 -339 minecraft:stone
fill 259 56 -339 263 56 -339 minecraft:stone
fill 242 56 -338 247 56 -338 minecraft:stone
fill 259 56 -338 263 56 -338 minecraft:stone
fill 242 56 -337 246 56 -337 minecraft:stone
fill 260 56 -337 263 56 -337 minecraft:stone
fill 242 56 -336 246 56 -336 minecraft:stone
fill 261 56 -336 263 56 -336 minecraft:stone
fill 241 56 -335 245 56 -335 minecraft:stone
fill 262 56 -335 263 56 -335 minecraft:stone
fill 241 56 -334 245 56 -334 minecraft:stone
setblock 263 56 -334 minecraft:stone
fill 241 56 -333 245 56 -333 minecraft:stone
setblock 263 56 -333 minecraft:stone
fill 241 56 -332 245 56 -332 minecraft:stone
setblock 263 56 -332 minecraft:stone
fill 241 56 -331 244 56 -331 minecraft:stone
setblock 263 56 -331 minecraft:stone
fill 240 56 -330 244 56 -330 minecraft:stone
fill 262 56 -330 263 56 -330 minecraft:stone
fill 240 56 -329 244 56 -329 minecraft:stone
fill 262 56 -329 263 56 -329 minecraft:stone
fill 241 56 -328 244 56 -328 minecraft:stone
fill 262 56 -328 263 56 -328 minecraft:stone
fill 241 56 -327 243 56 -327 minecraft:stone
fill 262 56 -327 263 56 -327 minecraft:stone
fill 262 56 -326 263 56 -326 minecraft:stone
fill 262 56 -325 263 56 -325 minecraft:stone
fill 262 56 -324 263 56 -324 minecraft:stone
fill 262 56 -323 263 56 -323 minecraft:stone
fill 262 56 -322 263 56 -322 minecraft:stone
fill 262 56 -321 263 56 -321 minecraft:stone
fill 262 56 -320 263 56 -320 minecraft:stone
fill 262 56 -319 263 56 -319 minecraft:stone
fill 208 57 -378 210 57 -378 minecraft:stone
fill 207 57 -377 211 57 -377 minecraft:stone
fill 207 57 -376 209 57 -376 minecraft:stone
fill 234 57 -371 236 57 -371 minecraft:stone
fill 234 57 -370 236 57 -370 minecraft:stone
fill 234 57 -369 236 57 -369 minecraft:stone
fill 234 57 -368 236 57 -368 minecraft:stone
fill 233 57 -367 235 57 -367 minecraft:stone
fill 233 57 -366 235 57 -366 minecraft:stone
fill 253 57 -351 257 57 -351 minecraft:stone
fill 251 57 -350 259 57 -350 minecraft:stone
fill 250 57 -349 260 57 -349 minecraft:stone
fill 249 57 -348 260 57 -348 minecraft:stone
fill 249 57 -347 261 57 -347 minecraft:stone
fill 247 57 -346 252 57 -346 minecraft:stone
fill 257 57 -346 261 57 -346 minecraft:stone
fill 246 57 -345 250 57 -345 minecraft:stone
fill 257 57 -345 261 57 -345 minecraft:stone
fill 246 57 -344 250 57 -344 minecraft:stone
fill 258 57 -344 262 57 -344 minecraft:stone
fill 245 57 -343 250 57 -343 minecraft:stone
fill 258 57 -343 262 57 -343 minecraft:stone
fill 244 57 -342 249 57 -342 minecraft:stone
fill 258 57 -342 262 57 -342 minecraft:stone
fill 244 57 -341 249 57 -341 minecraft:stone
fill 258 57 -341 263 57 -341 minecraft:stone
fill 243 57 -340 248 57 -340 minecraft:stone
fill 259 57 -340 263 57 -340 minecraft:stone
fill 243 57 -339 247 57 -339 minecraft:stone
fill 259 57 -339 263 57 -339 minecraft:stone
fill 243 57 -338 247 57 -338 minecraft:stone
fill 260 57 -338 263 57 -338 minecraft:stone
fill 242 57 -337 246 57 -337 minecraft:stone
fill 260 57 -337 263 57 -337 minecraft:stone
fill 242 57 -336 245 57 -336 minecraft:stone
fill 261 57 -336 263 57 -336 minecraft:stone
fill 242 57 -335 245 57 -335 minecraft:stone
fill 262 57 -335 263 57 -335 minecraft:stone
fill 241 57 -334 245 57 -334 minecraft:stone
setblock 263 57 -334 minecraft:stone
fill 241 57 -333 245 57 -333 minecraft:stone
fill 241 57 -332 244 57 -332 minecraft:stone
fill 241 57 -331 244 57 -331 minecraft:stone
setblock 263 57 -331 minecraft:stone
fill 240 57 -330 244 57 -330 minecraft:stone
setblock 263 57 -330 minecraft:stone
fill 240 57 -329 244 57 -329 minecraft:stone
setblock 263 57 -329 minecraft:stone
fill 240 57 -328 244 57 -328 minecraft:stone
setblock 263 57 -328 minecraft:stone
fill 241 57 -327 244 57 -327 minecraft:stone
fill 241 57 -326 244 57 -326 minecraft:stone
fill 241 57 -325 244 57 -325 minecraft:stone
fill 208 58 -378 210 58 -378 minecraft:stone
fill 208 58 -377 211 58 -377 minecraft:stone
fill 207 58 -376 210 58 -376 minecraft:stone
fill 233 58 -370 235 58 -370 minecraft:stone
fill 233 58 -369 235 58 -369 minecraft:stone
fill 233 58 -368 235 58 -368 minecraft:stone
fill 233 58 -367 234 58 -367 minecraft:stone
fill 232 58 -366 234 58 -366 minecraft:stone
fill 231 58 -365 233 58 -365 minecraft:stone
fill 252 58 -351 257 58 -351 minecraft:stone
fill 251 58 -350 259 58 -350 minecraft:stone
fill 249 58 -349 260 58 -349 minecraft:stone
fill 249 58 -348 260 58 -348 minecraft:stone
fill 249 58 -347 261 58 -347 minecraft:stone
fill 247 58 -346 253 58 -346 minecraft:stone
fill 257 58 -346 261 58 -346 minecraft:stone
fill 246 58 -345 249 58 -345 minecraft:stone
setblock 251 58 -345 minecraft:stone
fill 257 58 -345 261 58 -345 minecraft:stone
fill 246 58 -344 250 58 -344 minecraft:stone
fill 258 58 -344 262 58 -344 minecraft:stone
fill 245 58 -343 249 58 -343 minecraft:stone
fill 258 58 -343 262 58 -343 minecraft:stone
fill 245 58 -342 249 58 -342 minecraft:stone
fill 258 58 -342 262 58 -342 minecraft:stone
fill 245 58 -341 248 58 -341 minecraft:stone
fill 259 58 -341 262 58 -341 minecraft:stone
fill 244 58 -340 247 58 -340 minecraft:stone
fill 259 58 -340 263 58 -340 minecraft:stone
fill 244 58 -339 246 58 -339 minecraft:stone
fill 260 58 -339 263 58 -339 minecraft:stone
fill 244 58 -338 246 58 -338 minecraft:stone
fill 260 58 -338 263 58 -338 minecraft:stone
fill 243 58 -337 245 58 -337 minecraft:stone
fill 261 58 -337 263 58 -337 minecraft:stone
setblock 244 58 -336 minecraft:stone
setblock 263 58 -336 minecraft:stone
fill 243 58 -335 244 58 -335 minecraft:stone
fill 243 58 -334 244 58 -334 minecraft:stone
fill 242 58 -333 244 58 -333 minecraft:stone
fill 242 58 -332 243 58 -332 minecraft:stone
fill 241 58 -331 243 58 -331 minecraft:stone
fill 241 58 -330 243 58 -330 minecraft:stone
fill 241 58 -329 244 58 -329 minecraft:stone
fill 241 58 -328 244 58 -328 minecraft:stone
fill 241 58 -327 244 58 -327 minecraft:stone
fill 241 58 -326 244 58 -326 minecraft:stone
fill 241 58 -325 244 58 -325 minecraft:stone
fill 241 58 -324 244 58 -324 minecraft:stone
fill 241 58 -323 245 58 -323 minecraft:stone
fill 242 58 -322 244 58 -322 minecraft:stone
fill 209 59 -378 211 59 -378 minecraft:stone
fill 208 59 -377 212 59 -377 minecraft:stone
fill 208 59 -376 210 59 -376 minecraft:stone
setblock 232 59 -369 minecraft:stone
fill 232 59 -368 234 59 -368 minecraft:stone
fill 231 59 -367 234 59 -367 minecraft:stone
fill 231 59 -366 233 59 -366 minecraft:stone
fill 230 59 -365 233 59 -365 minecraft:stone
fill 229 59 -364 232 59 -364 minecraft:stone
fill 252 59 -351 257 59 -351 minecraft:stone
fill 251 59 -350 258 59 -350 minecraft:stone
fill 249 59 -349 259 59 -349 minecraft:stone
fill 249 59 -348 260 59 -348 minecraft:stone
fill 249 59 -347 260 59 -347 minecraft:stone
fill 249 59 -346 252 59 -346 minecraft:stone
fill 257 59 -346 260 59 -346 minecraft:stone
fill 247 59 -345 248 59 -345 minecraft:stone
setblock 251 59 -345 minecraft:stone
fill 258 59 -345 260 59 -345 minecraft:stone
fill 247 59 -344 249 59 -344 minecraft:stone
fill 259 59 -344 260 59 -344 minecraft:stone
fill 247 59 -343 249 59 -343 minecraft:stone
fill 259 59 -343 261 59 -343 minecraft:stone
setblock 247 59 -342 minecraft:stone
setblock 260 59 -342 minecraft:stone
fill 242 59 -328 243 59 -328 minecraft:stone
fill 241 59 -327 243 59 -327 minecraft:stone
fill 241 59 -326 243 59 -326 minecraft:stone
fill 241 59 -325 244 59 -325 minecraft:stone
fill 241 59 -324 245 59 -324 minecraft:stone
fill 241 59 -323 245 59 -323 minecraft:stone
fill 242 59 -322 246 59 -322 minecraft:stone
fill 243 59 -321 246 59 -321 minecraft:stone
fill 243 59 -320 247 59 -320 minecraft:stone
fill 244 59 -319 247 59 -319 minecraft:stone
fill 209 60 -378 211 60 -378 minecraft:stone
fill 208 60 -377 213 60 -377 minecraft:stone
fill 208 60 -376 211 60 -376 minecraft:stone
setblock 210 60 -375 minecraft:stone
setblock 230 60 -368 minecraft:stone
fill 230 60 -367 233 60 -367 minecraft:stone
fill 229 60 -366 232 60 -366 minecraft:stone
fill 228 60 -365 232 60 -365 minecraft:stone
fill 227 60 -364 231 60 -364 minecraft:stone
fill 228 60 -363 230 60 -363 minecraft:stone
fill 253 60 -351 255 60 -351 minecraft:stone
fill 251 60 -350 257 60 -350 minecraft:stone
fill 250 60 -349 257 60 -349 minecraft:stone
fill 250 60 -348 258 60 -348 minecraft:stone
fill 250 60 -347 253 60 -347 minecraft:stone
fill 250 60 -346 252 60 -346 minecraft:stone
fill 242 60 -325 244 60 -325 minecraft:stone
fill 241 60 -324 244 60 -324 minecraft:stone
fill 242 60 -323 245 60 -323 minecraft:stone
fill 242 60 -322 246 60 -322 minecraft:stone
fill 243 60 -321 247 60 -321 minecraft:stone
fill 243 60 -320 248 60 -320 minecraft:stone
fill 244 60 -319 248 60 -319 minecraft:stone
fill 209 61 -378 212 61 -378 minecraft:stone
fill 208 61 -377 213 61 -377 minecraft:stone
fill 209 61 -376 212 61 -376 minecraft:stone
fill 210 61 -375 211 61 -375 minecraft:stone
setblock 228 61 -367 minecraft:stone
fill 227 61 -366 231 61 -366 minecraft:stone
fill 226 61 -365 230 61 -365 minecraft:stone
fill 225 61 -364 229 61 -364 minecraft:stone
fill 224 61 -363 228 61 -363 minecraft:stone
fill 226 61 -362 227 61 -362 minecraft:stone
fill 243 61 -323 244 61 -323 minecraft:stone
fill 243 61 -322 245 61 -322 minecraft:stone
fill 243 61 -321 246 61 -321 minecraft:stone
fill 244 61 -320 248 61 -320 minecraft:stone
fill 244 61 -319 249 61 -319 minecraft:stone
fill 210 62 -378 212 62 -378 minecraft:dirt
fill 208 62 -377 213 62 -377 minecraft:dirt
fill 209 62 -376 214 62 -376 minecraft:dirt
fill 210 62 -375 212 62 -375 minecraft:dirt
fill 225 62 -367 226 62 -367 minecraft:dirt
fill 224 62 -366 227 62 -366 minecraft:dirt
fill 223 62 -365 229 62 -365 minecraft:dirt
fill 222 62 -364 228 62 -364 minecraft:dirt
fill 223 62 -363 226 62 -363 minecraft:dirt
setblock 224 62 -362 minecraft:dirt
fill 256 62 -351 258 62 -351 minecraft:dirt
fill 256 62 -350 258 62 -350 minecraft:dirt
fill 256 62 -349 258 62 -349 minecraft:dirt
fill 256 62 -348 257 62 -348 minecraft:dirt
fill 256 62 -347 257 62 -347 minecraft:dirt
fill 245 62 -320 246 62 -320 minecraft:dirt
fill 245 62 -319 247 62 -319 minecraft:dirt
fill 210 63 -378 212 63 -378 minecraft:dirt
fill 209 63 -377 214 63 -377 minecraft:dirt
fill 209 63 -376 215 63 -376 minecraft:dirt
fill 211 63 -375 215 63 -375 minecraft:dirt
setblock 212 63 -374 minecraft:dirt
fill 222 63 -367 223 63 -367 minecraft:dirt
fill 221 63 -366 225 63 -366 minecraft:dirt
fill 219 63 -365 226 63 -365 minecraft:dirt
fill 220 63 -364 225 63 -364 minecraft:dirt
fill 221 63 -363 224 63 -363 minecraft:dirt
fill 256 63 -351 258 63 -351 minecraft:dirt
fill 256 63 -350 258 63 -350 minecraft:dirt
fill 256 63 -349 258 63 -349 minecraft:dirt
fill 256 63 -348 257 63 -348 minecraft:dirt
fill 256 63 -347 257 63 -347 minecraft:dirt
fill 256 63 -346 257 63 -346 minecraft:dirt
setblock 246 63 -321 minecraft:dirt
fill 245 63 -320 247 63 -320 minecraft:dirt
fill 246 63 -319 247 63 -319 minecraft:dirt
fill 200 64 -382 201 64 -382 minecraft:dirt
fill 200 64 -381 201 64 -381 minecraft:dirt
fill 200 64 -380 201 64 -380 minecraft:dirt
fill 211 64 -378 213 64 -378 minecraft:dirt
fill 209 64 -377 214 64 -377 minecraft:dirt
fill 210 64 -376 215 64 -376 minecraft:dirt
fill 211 64 -375 216 64 -375 minecraft:dirt
fill 212 64 -374 217 64 -374 minecraft:dirt
setblock 213 64 -373 minecraft:dirt
setblock 218 64 -373 minecraft:dirt
setblock 220 64 -370 minecraft:dirt
setblock 220 64 -369 minecraft:dirt
fill 220 64 -368 221 64 -368 minecraft:dirt
fill 218 64 -367 222 64 -367 minecraft:dirt
fill 218 64 -366 223 64 -366 minecraft:dirt
fill 219 64 -365 224 64 -365 minecraft:dirt
fill 219 64 -364 223 64 -364 minecraft:dirt
setblock 220 64 -363 minecraft:dirt
fill 256 64 -351 258 64 -351 minecraft:dirt
fill 256 64 -350 258 64 -350 minecraft:dirt
fill 256 64 -349 258 64 -349 minecraft:dirt
fill 256 64 -348 257 64 -348 minecraft:dirt
fill 256 64 -347 257 64 -347 minecraft:dirt
setblock 256 64 -345 minecraft:dirt
setblock 246 64 -322 minecraft:dirt
fill 245 64 -321 247 64 -321 minecraft:dirt
setblock 246 64 -320 minecraft:dirt
setblock 246 64 -319 minecraft:dirt
fill 200 65 -382 204 65 -382 minecraft:grass_block
setblock 205 65 -382 minecraft:light_gray_concrete
fill 206 65 -382 216 65 -382 minecraft:smooth_quartz
setblock 217 65 -382 minecraft:light_gray_concrete
fill 218 65 -382 228 65 -382 minecraft:smooth_quartz
setblock 229 65 -382 minecraft:light_gray_concrete
fill 230 65 -382 240 65 -382 minecraft:smooth_quartz
setblock 241 65 -382 minecraft:light_gray_concrete
fill 242 65 -382 246 65 -382 minecraft:smooth_quartz
fill 200 65 -381 204 65 -381 minecraft:grass_block
setblock 205 65 -381 minecraft:light_gray_concrete
fill 206 65 -381 216 65 -381 minecraft:smooth_quartz
setblock 217 65 -381 minecraft:light_gray_concrete
fill 218 65 -381 228 65 -381 minecraft:smooth_quartz
setblock 229 65 -381 minecraft:light_gray_concrete
fill 230 65 -381 240 65 -381 minecraft:smooth_quartz
setblock 241 65 -381 minecraft:light_gray_concrete
fill 242 65 -381 247 65 -381 minecraft:smooth_quartz
fill 200 65 -380 204 65 -380 minecraft:grass_block
fill 205 65 -380 246 65 -380 minecraft:light_gray_concrete
fill 200 65 -379 203 65 -379 minecraft:grass_block
setblock 205 65 -379 minecraft:light_gray_concrete
fill 206 65 -379 216 65 -379 minecraft:smooth_quartz
setblock 217 65 -379 minecraft:light_gray_concrete
fill 218 65 -379 228 65 -379 minecraft:smooth_quartz
setblock 229 65 -379 minecraft:light_gray_concrete
fill 230 65 -379 240 65 -379 minecraft:smooth_quartz
setblock 241 65 -379 minecraft:light_gray_concrete
fill 242 65 -379 245 65 -379 minecraft:smooth_quartz
fill 200 65 -378 202 65 -378 minecraft:grass_block
setblock 204 65 -378 minecraft:grass_block
setblock 205 65 -378 minecraft:light_gray_concrete
fill 206 65 -378 216 65 -378 minecraft:smooth_quartz
setblock 217 65 -378 minecraft:light_gray_concrete
fill 218 65 -378 228 65 -378 minecraft:smooth_quartz
setblock 229 65 -378 minecraft:light_gray_concrete
fill 230 65 -378 240 65 -378 minecraft:smooth_quartz
setblock 241 65 -378 minecraft:light_gray_concrete
fill 242 65 -378 246 65 -378 minecraft:smooth_quartz
fill 200 65 -377 201 65 -377 minecraft:grass_block
setblock 205 65 -377 minecraft:light_gray_concrete
fill 206 65 -377 216 65 -377 minecraft:smooth_quartz
setblock 217 65 -377 minecraft:light_gray_concrete
fill 218 65 -377 228 65 -377 minecraft:smooth_quartz
setblock 229 65 -377 minecraft:light_gray_concrete
fill 230 65 -377 240 65 -377 minecraft:smooth_quartz
setblock 241 65 -377 minecraft:light_gray_concrete
fill 242 65 -377 245 65 -377 minecraft:smooth_quartz
setblock 205 65 -376 minecraft:light_gray_concrete
fill 206 65 -376 216 65 -376 minecraft:smooth_quartz
setblock 217 65 -376 minecraft:light_gray_concrete
fill 218 65 -376 228 65 -376 minecraft:smooth_quartz
setblock 229 65 -376 minecraft:light_gray_concrete
fill 230 65 -376 240 65 -376 minecraft:smooth_quartz
setblock 241 65 -376 minecraft:light_gray_concrete
fill 242 65 -376 244 65 -376 minecraft:smooth_quartz
fill 203 65 -375 204 65 -375 minecraft:grass_block
setblock 205 65 -375 minecraft:light_gray_concrete
fill 206 65 -375 216 65 -375 minecraft:smooth_quartz
setblock 217 65 -375 minecraft:light_gray_concrete
fill 218 65 -375 228 65 -375 minecraft:smooth_quartz
setblock 229 65 -375 minecraft:light_gray_concrete
fill 230 65 -375 240 65 -375 minecraft:smooth_quartz
setblock 241 65 -375 minecraft:light_gray_concrete
fill 242 65 -375 245 65 -375 minecraft:smooth_quartz
fill 202 65 -374 204 65 -374 minecraft:grass_block
setblock 205 65 -374 minecraft:light_gray_concrete
fill 206 65 -374 214 65 -374 minecraft:smooth_quartz
setblock 215 65 -374 minecraft:sea_lantern
setblock 216 65 -374 minecraft:smooth_quartz
setblock 217 65 -374 minecraft:light_gray_concrete
fill 218 65 -374 228 65 -374 minecraft:smooth_quartz
setblock 229 65 -374 minecraft:light_gray_concrete
fill 230 65 -374 238 65 -374 minecraft:smooth_quartz
setblock 239 65 -374 minecraft:sea_lantern
setblock 240 65 -374 minecraft:smooth_quartz
setblock 241 65 -374 minecraft:light_gray_concrete
fill 242 65 -374 244 65 -374 minecraft:smooth_quartz
fill 200 65 -373 204 65 -373 minecraft:grass_block
setblock 205 65 -373 minecraft:light_gray_concrete
fill 206 65 -373 213 65 -373 minecraft:smooth_quartz
fill 214 65 -373 216 65 -373 minecraft:grass_block
setblock 217 65 -373 minecraft:light_gray_concrete
fill 218 65 -373 228 65 -373 minecraft:smooth_quartz
setblock 229 65 -373 minecraft:light_gray_concrete
fill 230 65 -373 237 65 -373 minecraft:smooth_quartz
fill 238 65 -373 240 65 -373 minecraft:grass_block
setblock 241 65 -373 minecraft:light_gray_concrete
fill 242 65 -373 245 65 -373 minecraft:smooth_quartz
fill 200 65 -372 204 65 -372 minecraft:grass_block
setblock 205 65 -372 minecraft:light_gray_concrete
fill 206 65 -372 212 65 -372 minecraft:smooth_quartz
fill 213 65 -372 217 65 -372 minecraft:grass_block
fill 218 65 -372 228 65 -372 minecraft:smooth_quartz
setblock 229 65 -372 minecraft:light_gray_concrete
fill 230 65 -372 236 65 -372 minecraft:smooth_quartz
fill 237 65 -372 241 65 -372 minecraft:grass_block
fill 242 65 -372 246 65 -372 minecraft:smooth_quartz
fill 200 65 -371 204 65 -371 minecraft:grass_block
setblock 205 65 -371 minecraft:light_gray_concrete
fill 206 65 -371 211 65 -371 minecraft:smooth_quartz
fill 212 65 -371 218 65 -371 minecraft:grass_block
fill 219 65 -371 228 65 -371 minecraft:smooth_quartz
setblock 229 65 -371 minecraft:light_gray_concrete
fill 230 65 -371 235 65 -371 minecraft:smooth_quartz
fill 236 65 -371 242 65 -371 minecraft:grass_block
fill 243 65 -371 245 65 -371 minecraft:smooth_quartz
fill 200 65 -370 204 65 -370 minecraft:grass_block
setblock 205 65 -370 minecraft:light_gray_concrete
fill 206 65 -370 210 65 -370 minecraft:smooth_quartz
setblock 211 65 -370 minecraft:sea_lantern
fill 212 65 -370 218 65 -370 minecraft:grass_block
setblock 219 65 -370 minecraft:sea_lantern
fill 220 65 -370 228 65 -370 minecraft:smooth_quartz
setblock 229 65 -370 minecraft:light_gray_concrete
fill 230 65 -370 234 65 -370 minecraft:smooth_quartz
setblock 235 65 -370 minecraft:sea_lantern
fill 236 65 -370 242 65 -370 minecraft:grass_block
setblock 243 65 -370 minecraft:sea_lantern
fill 244 65 -370 246 65 -370 minecraft:smooth_quartz
fill 200 65 -369 204 65 -369 minecraft:grass_block
setblock 205 65 -369 minecraft:light_gray_concrete
fill 206 65 -369 211 65 -369 minecraft:smooth_quartz
fill 212 65 -369 218 65 -369 minecraft:grass_block
fill 219 65 -369 228 65 -369 minecraft:smooth_quartz
setblock 229 65 -369 minecraft:light_gray_concrete
fill 230 65 -369 235 65 -369 minecraft:smooth_quartz
fill 236 65 -369 242 65 -369 minecraft:grass_block
fill 243 65 -369 247 65 -369 minecraft:smooth_quartz
fill 200 65 -368 204 65 -368 minecraft:grass_block
fill 205 65 -368 212 65 -368 minecraft:light_gray_concrete
fill 213 65 -368 217 65 -368 minecraft:grass_block
fill 218 65 -368 236 65 -368 minecraft:light_gray_concrete
fill 237 65 -368 241 65 -368 minecraft:grass_block
fill 242 65 -368 246 65 -368 minecraft:light_gray_concrete
fill 200 65 -367 204 65 -367 minecraft:grass_block
setblock 205 65 -367 minecraft:light_gray_concrete
fill 206 65 -367 213 65 -367 minecraft:smooth_quartz
fill 214 65 -367 216 65 -367 minecraft:grass_block
setblock 217 65 -367 minecraft:light_gray_concrete
fill 218 65 -367 228 65 -367 minecraft:smooth_quartz
setblock 229 65 -367 minecraft:light_gray_concrete
fill 230 65 -367 237 65 -367 minecraft:smooth_quartz
fill 238 65 -367 240 65 -367 minecraft:grass_block
setblock 241 65 -367 minecraft:light_gray_concrete
fill 242 65 -367 247 65 -367 minecraft:smooth_quartz
fill 200 65 -366 204 65 -366 minecraft:grass_block
setblock 205 65 -366 minecraft:light_gray_concrete
fill 206 65 -366 214 65 -366 minecraft:smooth_quartz
setblock 215 65 -366 minecraft:sea_lantern
setblock 216 65 -366 minecraft:smooth_quartz
setblock 217 65 -366 minecraft:light_gray_concrete
fill 218 65 -366 228 65 -366 minecraft:smooth_quartz
setblock 229 65 -366 minecraft:light_gray_concrete
fill 230 65 -366 238 65 -366 minecraft:smooth_quartz
setblock 239 65 -366 minecraft:sea_lantern
setblock 240 65 -366 minecraft:smooth_quartz
setblock 241 65 -366 minecraft:light_gray_concrete
fill 242 65 -366 248 65 -366 minecraft:smooth_quartz
fill 200 65 -365 204 65 -365 minecraft:grass_block
setblock 205 65 -365 minecraft:light_gray_concrete
fill 206 65 -365 216 65 -365 minecraft:smooth_quartz
setblock 217 65 -365 minecraft:light_gray_concrete
fill 218 65 -365 228 65 -365 minecraft:smooth_quartz
setblock 229 65 -365 minecraft:light_gray_concrete
fill 230 65 -365 240 65 -365 minecraft:smooth_quartz
setblock 241 65 -365 minecraft:light_gray_concrete
fill 242 65 -365 249 65 -365 minecraft:smooth_quartz
setblock 251 65 -365 minecraft:smooth_quartz
fill 200 65 -364 204 65 -364 minecraft:grass_block
setblock 205 65 -364 minecraft:light_gray_concrete
fill 206 65 -364 216 65 -364 minecraft:smooth_quartz
setblock 217 65 -364 minecraft:light_gray_concrete
fill 218 65 -364 228 65 -364 minecraft:smooth_quartz
setblock 229 65 -364 minecraft:light_gray_concrete
fill 230 65 -364 240 65 -364 minecraft:smooth_quartz
setblock 241 65 -364 minecraft:light_gray_concrete
fill 242 65 -364 252 65 -364 minecraft:smooth_quartz
setblock 254 65 -364 minecraft:smooth_quartz
fill 200 65 -363 204 65 -363 minecraft:grass_block
setblock 205 65 -363 minecraft:light_gray_concrete
fill 206 65 -363 216 65 -363 minecraft:smooth_quartz
setblock 217 65 -363 minecraft:light_gray_concrete
fill 218 65 -363 228 65 -363 minecraft:smooth_quartz
setblock 229 65 -363 minecraft:light_gray_concrete
fill 230 65 -363 240 65 -363 minecraft:smooth_quartz
setblock 241 65 -363 minecraft:light_gray_concrete
fill 242 65 -363 252 65 -363 minecraft:smooth_quartz
setblock 253 65 -363 minecraft:light_gray_concrete
fill 254 65 -363 256 65 -363 minecraft:smooth_quartz
fill 200 65 -362 204 65 -362 minecraft:grass_block
setblock 205 65 -362 minecraft:light_gray_concrete
fill 206 65 -362 216 65 -362 minecraft:smooth_quartz
setblock 217 65 -362 minecraft:light_gray_concrete
fill 218 65 -362 228 65 -362 minecraft:smooth_quartz
setblock 229 65 -362 minecraft:light_gray_concrete
fill 230 65 -362 240 65 -362 minecraft:smooth_quartz
setblock 241 65 -362 minecraft:light_gray_concrete
fill 242 65 -362 252 65 -362 minecraft:smooth_quartz
setblock 253 65 -362 minecraft:light_gray_concrete
fill 254 65 -362 256 65 -362 minecraft:smooth_quartz
fill 200 65 -361 204 65 -361 minecraft:grass_block
setblock 205 65 -361 minecraft:light_gray_concrete
fill 206 65 -361 216 65 -361 minecraft:smooth_quartz
setblock 217 65 -361 minecraft:light_gray_concrete
fill 218 65 -361 228 65 -361 minecraft:smooth_quartz
setblock 229 65 -361 minecraft:light_gray_concrete
fill 230 65 -361 240 65 -361 minecraft:smooth_quartz
setblock 241 65 -361 minecraft:light_gray_concrete
fill 242 65 -361 252 65 -361 minecraft:smooth_quartz
setblock 253 65 -361 minecraft:light_gray_concrete
fill 254 65 -361 256 65 -361 minecraft:smooth_quartz
fill 200 65 -360 204 65 -360 minecraft:grass_block
setblock 205 65 -360 minecraft:light_gray_concrete
fill 206 65 -360 216 65 -360 minecraft:smooth_quartz
setblock 217 65 -360 minecraft:light_gray_concrete
fill 218 65 -360 228 65 -360 minecraft:smooth_quartz
setblock 229 65 -360 minecraft:light_gray_concrete
fill 230 65 -360 240 65 -360 minecraft:smooth_quartz
setblock 241 65 -360 minecraft:light_gray_concrete
fill 242 65 -360 252 65 -360 minecraft:smooth_quartz
setblock 253 65 -360 minecraft:light_gray_concrete
fill 254 65 -360 256 65 -360 minecraft:smooth_quartz
fill 200 65 -359 204 65 -359 minecraft:grass_block
setblock 205 65 -359 minecraft:light_gray_concrete
fill 206 65 -359 216 65 -359 minecraft:smooth_quartz
setblock 217 65 -359 minecraft:light_gray_concrete
fill 218 65 -359 228 65 -359 minecraft:smooth_quartz
setblock 229 65 -359 minecraft:light_gray_concrete
fill 230 65 -359 240 65 -359 minecraft:smooth_quartz
setblock 241 65 -359 minecraft:light_gray_concrete
fill 242 65 -359 252 65 -359 minecraft:smooth_quartz
setblock 253 65 -359 minecraft:light_gray_concrete
fill 254 65 -359 256 65 -359 minecraft:smooth_quartz
fill 200 65 -358 204 65 -358 minecraft:grass_block
setblock 205 65 -358 minecraft:light_gray_concrete
fill 206 65 -358 216 65 -358 minecraft:smooth_quartz
setblock 217 65 -358 minecraft:light_gray_concrete
fill 218 65 -358 228 65 -358 minecraft:smooth_quartz
setblock 229 65 -358 minecraft:light_gray_concrete
fill 230 65 -358 240 65 -358 minecraft:smooth_quartz
setblock 241 65 -358 minecraft:light_gray_concrete
fill 242 65 -358 252 65 -358 minecraft:smooth_quartz
setblock 253 65 -358 minecraft:light_gray_concrete
fill 254 65 -358 256 65 -358 minecraft:smooth_quartz
fill 200 65 -357 204 65 -357 minecraft:grass_block
setblock 205 65 -357 minecraft:light_gray_concrete
fill 206 65 -357 216 65 -357 minecraft:smooth_quartz
setblock 217 65 -357 minecraft:light_gray_concrete
fill 218 65 -357 228 65 -357 minecraft:smooth_quartz
setblock 229 65 -357 minecraft:light_gray_concrete
fill 230 65 -357 240 65 -357 minecraft:smooth_quartz
setblock 241 65 -357 minecraft:light_gray_concrete
fill 242 65 -357 252 65 -357 minecraft:smooth_quartz
setblock 253 65 -357 minecraft:light_gray_concrete
fill 254 65 -357 256 65 -357 minecraft:smooth_quartz
fill 200 65 -356 204 65 -356 minecraft:grass_block
fill 205 65 -356 252 65 -356 minecraft:light_gray_concrete
setblock 254 65 -356 minecraft:light_gray_concrete
fill 200 65 -355 204 65 -355 minecraft:grass_block
setblock 205 65 -355 minecraft:light_gray_concrete
fill 206 65 -355 216 65 -355 minecraft:smooth_quartz
setblock 217 65 -355 minecraft:light_gray_concrete
fill 218 65 -355 228 65 -355 minecraft:smooth_quartz
setblock 229 65 -355 minecraft:light_gray_concrete
fill 230 65 -355 240 65 -355 minecraft:smooth_quartz
setblock 241 65 -355 minecraft:light_gray_concrete
fill 242 65 -355 249 65 -355 minecraft:smooth_quartz
setblock 251 65 -355 minecraft:smooth_quartz
fill 200 65 -354 204 65 -354 minecraft:grass_block
setblock 205 65 -354 minecraft:light_gray_concrete
fill 206 65 -354 216 65 -354 minecraft:smooth_quartz
setblock 217 65 -354 minecraft:light_gray_concrete
fill 218 65 -354 228 65 -354 minecraft:smooth_quartz
setblock 229 65 -354 minecraft:light_gray_concrete
fill 230 65 -354 240 65 -354 minecraft:smooth_quartz
setblock 241 65 -354 minecraft:light_gray_concrete
fill 242 65 -354 248 65 -354 minecraft:smooth_quartz
fill 200 65 -353 204 65 -353 minecraft:grass_block
setblock 205 65 -353 minecraft:light_gray_concrete
fill 206 65 -353 216 65 -353 minecraft:smooth_quartz
setblock 217 65 -353 minecraft:light_gray_concrete
fill 218 65 -353 228 65 -353 minecraft:smooth_quartz
setblock 229 65 -353 minecraft:light_gray_concrete
fill 230 65 -353 240 65 -353 minecraft:smooth_quartz
setblock 241 65 -353 minecraft:light_gray_concrete
fill 242 65 -353 247 65 -353 minecraft:smooth_quartz
fill 200 65 -352 204 65 -352 minecraft:grass_block
setblock 205 65 -352 minecraft:light_gray_concrete
fill 206 65 -352 216 65 -352 minecraft:smooth_quartz
setblock 217 65 -352 minecraft:light_gray_concrete
fill 218 65 -352 228 65 -352 minecraft:smooth_quartz
setblock 229 65 -352 minecraft:light_gray_concrete
fill 230 65 -352 240 65 -352 minecraft:smooth_quartz
setblock 241 65 -352 minecraft:light_gray_concrete
fill 242 65 -352 246 65 -352 minecraft:smooth_quartz
fill 200 65 -351 204 65 -351 minecraft:grass_block
setblock 205 65 -351 minecraft:light_gray_concrete
fill 206 65 -351 216 65 -351 minecraft:smooth_quartz
setblock 217 65 -351 minecraft:light_gray_concrete
fill 218 65 -351 228 65 -351 minecraft:smooth_quartz
setblock 229 65 -351 minecraft:light_gray_concrete
fill 230 65 -351 240 65 -351 minecraft:smooth_quartz
setblock 241 65 -351 minecraft:light_gray_concrete
fill 242 65 -351 247 65 -351 minecraft:smooth_quartz
fill 200 65 -350 204 65 -350 minecraft:grass_block
setblock 205 65 -350 minecraft:light_gray_concrete
fill 206 65 -350 214 65 -350 minecraft:smooth_quartz
setblock 215 65 -350 minecraft:sea_lantern
setblock 216 65 -350 minecraft:smooth_quartz
setblock 217 65 -350 minecraft:light_gray_concrete
fill 218 65 -350 228 65 -350 minecraft:smooth_quartz
setblock 229 65 -350 minecraft:light_gray_concrete
fill 230 65 -350 238 65 -350 minecraft:smooth_quartz
setblock 239 65 -350 minecraft:sea_lantern
setblock 240 65 -350 minecraft:smooth_quartz
setblock 241 65 -350 minecraft:light_gray_concrete
fill 242 65 -350 246 65 -350 minecraft:smooth_quartz
fill 200 65 -349 204 65 -349 minecraft:grass_block
setblock 205 65 -349 minecraft:light_gray_concrete
fill 206 65 -349 213 65 -349 minecraft:smooth_quartz
fill 214 65 -349 216 65 -349 minecraft:grass_block
setblock 217 65 -349 minecraft:light_gray_concrete
fill 218 65 -349 228 65 -349 minecraft:smooth_quartz
setblock 229 65 -349 minecraft:light_gray_concrete
fill 230 65 -349 237 65 -349 minecraft:smooth_quartz
fill 238 65 -349 240 65 -349 minecraft:grass_block
setblock 241 65 -349 minecraft:light_gray_concrete
fill 242 65 -349 245 65 -349 minecraft:smooth_quartz
fill 200 65 -348 204 65 -348 minecraft:grass_block
setblock 205 65 -348 minecraft:light_gray_concrete
fill 206 65 -348 212 65 -348 minecraft:smooth_quartz
fill 215 65 -348 217 65 -348 minecraft:grass_block
fill 218 65 -348 228 65 -348 minecraft:smooth_quartz
setblock 229 65 -348 minecraft:light_gray_concrete
fill 230 65 -348 236 65 -348 minecraft:smooth_quartz
fill 237 65 -348 241 65 -348 minecraft:grass_block
fill 242 65 -348 246 65 -348 minecraft:smooth_quartz
fill 200 65 -347 204 65 -347 minecraft:grass_block
setblock 205 65 -347 minecraft:light_gray_concrete
fill 206 65 -347 211 65 -347 minecraft:smooth_quartz
fill 213 65 -347 218 65 -347 minecraft:grass_block
fill 219 65 -347 228 65 -347 minecraft:smooth_quartz
setblock 229 65 -347 minecraft:light_gray_concrete
fill 230 65 -347 235 65 -347 minecraft:smooth_quartz
fill 236 65 -347 242 65 -347 minecraft:grass_block
fill 243 65 -347 245 65 -347 minecraft:smooth_quartz
fill 200 65 -346 204 65 -346 minecraft:grass_block
setblock 205 65 -346 minecraft:light_gray_concrete
fill 206 65 -346 210 65 -346 minecraft:smooth_quartz
setblock 211 65 -346 minecraft:sea_lantern
fill 212 65 -346 218 65 -346 minecraft:grass_block
setblock 219 65 -346 minecraft:sea_lantern
fill 220 65 -346 228 65 -346 minecraft:smooth_quartz
setblock 229 65 -346 minecraft:light_gray_concrete
fill 230 65 -346 234 65 -346 minecraft:smooth_quartz
setblock 235 65 -346 minecraft:sea_lantern
fill 236 65 -346 242 65 -346 minecraft:grass_block
setblock 243 65 -346 minecraft:sea_lantern
setblock 244 65 -346 minecraft:smooth_quartz
fill 200 65 -345 204 65 -345 minecraft:grass_block
setblock 205 65 -345 minecraft:light_gray_concrete
fill 206 65 -345 211 65 -345 minecraft:smooth_quartz
fill 212 65 -345 218 65 -345 minecraft:grass_block
fill 219 65 -345 228 65 -345 minecraft:smooth_quartz
setblock 229 65 -345 minecraft:light_gray_concrete
fill 230 65 -345 235 65 -345 minecraft:smooth_quartz
fill 236 65 -345 242 65 -345 minecraft:grass_block
fill 243 65 -345 245 65 -345 minecraft:smooth_quartz
fill 200 65 -344 204 65 -344 minecraft:grass_block
fill 205 65 -344 212 65 -344 minecraft:light_gray_concrete
fill 213 65 -344 217 65 -344 minecraft:grass_block
fill 218 65 -344 236 65 -344 minecraft:light_gray_concrete
fill 237 65 -344 241 65 -344 minecraft:grass_block
fill 242 65 -344 244 65 -344 minecraft:light_gray_concrete
fill 200 65 -343 204 65 -343 minecraft:grass_block
setblock 205 65 -343 minecraft:light_gray_concrete
fill 206 65 -343 213 65 -343 minecraft:smooth_quartz
fill 214 65 -343 216 65 -343 minecraft:grass_block
setblock 217 65 -343 minecraft:light_gray_concrete
fill 218 65 -343 228 65 -343 minecraft:smooth_quartz
setblock 229 65 -343 minecraft:light_gray_concrete
fill 230 65 -343 237 65 -343 minecraft:smooth_quartz
fill 238 65 -343 240 65 -343 minecraft:grass_block
setblock 241 65 -343 minecraft:light_gray_concrete
fill 242 65 -343 245 65 -343 minecraft:smooth_quartz
fill 200 65 -342 204 65 -342 minecraft:grass_block
setblock 205 65 -342 minecraft:light_gray_concrete
fill 206 65 -342 214 65 -342 minecraft:smooth_quartz
setblock 215 65 -342 minecraft:sea_lantern
setblock 216 65 -342 minecraft:smooth_quartz
setblock 217 65 -342 minecraft:light_gray_concrete
fill 218 65 -342 228 65 -342 minecraft:smooth_quartz
setblock 229 65 -342 minecraft:light_gray_concrete
fill 230 65 -342 238 65 -342 minecraft:smooth_quartz
setblock 239 65 -342 minecraft:sea_lantern
setblock 240 65 -342 minecraft:smooth_quartz
setblock 241 65 -342 minecraft:light_gray_concrete
fill 242 65 -342 246 65 -342 minecraft:smooth_quartz
fill 200 65 -341 204 65 -341 minecraft:grass_block
setblock 205 65 -341 minecraft:light_gray_concrete
fill 206 65 -341 216 65 -341 minecraft:smooth_quartz
setblock 217 65 -341 minecraft:light_gray_concrete
fill 218 65 -341 228 65 -341 minecraft:smooth_quartz
setblock 229 65 -341 minecraft:light_gray_concrete
fill 230 65 -341 240 65 -341 minecraft:smooth_quartz
setblock 241 65 -341 minecraft:light_gray_concrete
fill 242 65 -341 245 65 -341 minecraft:smooth_quartz
fill 200 65 -340 204 65 -340 minecraft:grass_block
setblock 205 65 -340 minecraft:light_gray_concrete
fill 206 65 -340 216 65 -340 minecraft:smooth_quartz
setblock 217 65 -340 minecraft:light_gray_concrete
fill 218 65 -340 228 65 -340 minecraft:smooth_quartz
setblock 229 65 -340 minecraft:light_gray_concrete
fill 230 65 -340 240 65 -340 minecraft:smooth_quartz
setblock 241 65 -340 minecraft:light_gray_concrete
fill 242 65 -340 246 65 -340 minecraft:smooth_quartz
setblock 205 65 -339 minecraft:light_gray_concrete
fill 206 65 -339 216 65 -339 minecraft:smooth_quartz
setblock 217 65 -339 minecraft:light_gray_concrete
fill 218 65 -339 228 65 -339 minecraft:smooth_quartz
setblock 229 65 -339 minecraft:light_gray_concrete
fill 230 65 -339 240 65 -339 minecraft:smooth_quartz
setblock 241 65 -339 minecraft:light_gray_concrete
fill 242 65 -339 247 65 -339 minecraft:smooth_quartz
setblock 205 65 -338 minecraft:light_gray_concrete
fill 206 65 -338 216 65 -338 minecraft:smooth_quartz
setblock 217 65 -338 minecraft:light_gray_concrete
fill 218 65 -338 228 65 -338 minecraft:smooth_quartz
setblock 229 65 -338 minecraft:light_gray_concrete
fill 230 65 -338 240 65 -338 minecraft:smooth_quartz
setblock 241 65 -338 minecraft:light_gray_concrete
fill 242 65 -338 246 65 -338 minecraft:smooth_quartz
setblock 205 65 -337 minecraft:light_gray_concrete
fill 206 65 -337 216 65 -337 minecraft:smooth_quartz
setblock 217 65 -337 minecraft:light_gray_concrete
fill 218 65 -337 228 65 -337 minecraft:smooth_quartz
setblock 229 65 -337 minecraft:light_gray_concrete
fill 230 65 -337 240 65 -337 minecraft:smooth_quartz
setblock 241 65 -337 minecraft:light_gray_concrete
fill 242 65 -337 247 65 -337 minecraft:smooth_quartz
setblock 205 65 -336 minecraft:light_gray_concrete
fill 206 65 -336 216 65 -336 minecraft:smooth_quartz
setblock 217 65 -336 minecraft:light_gray_concrete
fill 218 65 -336 228 65 -336 minecraft:smooth_quartz
setblock 229 65 -336 minecraft:light_gray_concrete
fill 230 65 -336 240 65 -336 minecraft:smooth_quartz
setblock 241 65 -336 minecraft:light_gray_concrete
fill 242 65 -336 248 65 -336 minecraft:smooth_quartz
setblock 205 65 -335 minecraft:light_gray_concrete
fill 206 65 -335 216 65 -335 minecraft:smooth_quartz
setblock 217 65 -335 minecraft:light_gray_concrete
fill 218 65 -335 228 65 -335 minecraft:smooth_quartz
setblock 229 65 -335 minecraft:light_gray_concrete
fill 230 65 -335 240 65 -335 minecraft:smooth_quartz
setblock 241 65 -335 minecraft:light_gray_concrete
fill 242 65 -335 249 65 -335 minecraft:smooth_quartz
setblock 251 65 -335 minecraft:smooth_quartz
setblock 263 65 -335 minecraft:smooth_quartz
setblock 205 65 -334 minecraft:light_gray_concrete
fill 206 65 -334 216 65 -334 minecraft:smooth_quartz
setblock 217 65 -334 minecraft:light_gray_concrete
fill 218 65 -334 228 65 -334 minecraft:smooth_quartz
setblock 229 65 -334 minecraft:light_gray_concrete
fill 230 65 -334 240 65 -334 minecraft:smooth_quartz
setblock 241 65 -334 minecraft:light_gray_concrete
fill 242 65 -334 252 65 -334 minecraft:smooth_quartz
setblock 254 65 -334 minecraft:smooth_quartz
setblock 260 65 -334 minecraft:smooth_quartz
fill 262 65 -334 263 65 -334 minecraft:smooth_quartz
setblock 205 65 -333 minecraft:light_gray_concrete
fill 206 65 -333 216 65 -333 minecraft:smooth_quartz
setblock 217 65 -333 minecraft:light_gray_concrete
fill 218 65 -333 228 65 -333 minecraft:smooth_quartz
setblock 229 65 -333 minecraft:light_gray_concrete
fill 230 65 -333 240 65 -333 minecraft:smooth_quartz
setblock 241 65 -333 minecraft:light_gray_concrete
fill 242 65 -333 252 65 -333 minecraft:smooth_quartz
setblock 253 65 -333 minecraft:light_gray_concrete
fill 254 65 -333 255 65 -333 minecraft:smooth_quartz
setblock 257 65 -333 minecraft:smooth_quartz
fill 259 65 -333 263 65 -333 minecraft:smooth_quartz
fill 205 65 -332 263 65 -332 minecraft:light_gray_concrete
setblock 205 65 -331 minecraft:light_gray_concrete
fill 206 65 -331 216 65 -331 minecraft:smooth_quartz
setblock 217 65 -331 minecraft:light_gray_concrete
fill 218 65 -331 228 65 -331 minecraft:smooth_quartz
setblock 229 65 -331 minecraft:light_gray_concrete
fill 230 65 -331 240 65 -331 minecraft:smooth_quartz
setblock 241 65 -331 minecraft:light_gray_concrete
fill 242 65 -331 252 65 -331 minecraft:smooth_quartz
setblock 253 65 -331 minecraft:light_gray_concrete
fill 254 65 -331 263 65 -331 minecraft:smooth_quartz
setblock 200 65 -330 minecraft:grass_block
setblock 205 65 -330 minecraft:light_gray_concrete
fill 206 65 -330 216 65 -330 minecraft:smooth_quartz
setblock 217 65 -330 minecraft:light_gray_concrete
fill 218 65 -330 228 65 -330 minecraft:smooth_quartz
setblock 229 65 -330 minecraft:light_gray_concrete
fill 230 65 -330 240 65 -330 minecraft:smooth_quartz
setblock 241 65 -330 minecraft:light_gray_concrete
fill 242 65 -330 252 65 -330 minecraft:smooth_quartz
setblock 253 65 -330 minecraft:light_gray_concrete
fill 254 65 -330 262 65 -330 minecraft:smooth_quartz
setblock 200 65 -329 minecraft:grass_block
setblock 205 65 -329 minecraft:light_gray_concrete
fill 206 65 -329 216 65 -329 minecraft:smooth_quartz
setblock 217 65 -329 minecraft:light_gray_concrete
fill 218 65 -329 228 65 -329 minecraft:smooth_quartz
setblock 229 65 -329 minecraft:light_gray_concrete
fill 230 65 -329 240 65 -329 minecraft:smooth_quartz
setblock 241 65 -329 minecraft:light_gray_concrete
fill 242 65 -329 252 65 -329 minecraft:smooth_quartz
setblock 253 65 -329 minecraft:light_gray_concrete
fill 254 65 -329 262 65 -329 minecraft:smooth_quartz
setblock 200 65 -328 minecraft:grass_block
setblock 205 65 -328 minecraft:light_gray_concrete
fill 206 65 -328 216 65 -328 minecraft:smooth_quartz
setblock 217 65 -328 minecraft:light_gray_concrete
fill 218 65 -328 228 65 -328 minecraft:smooth_quartz
setblock 229 65 -328 minecraft:light_gray_concrete
fill 230 65 -328 240 65 -328 minecraft:smooth_quartz
setblock 241 65 -328 minecraft:light_gray_concrete
fill 242 65 -328 252 65 -328 minecraft:smooth_quartz
setblock 253 65 -328 minecraft:light_gray_concrete
fill 254 65 -328 262 65 -328 minecraft:smooth_quartz
setblock 205 65 -327 minecraft:light_gray_concrete
fill 206 65 -327 216 65 -327 minecraft:smooth_quartz
setblock 217 65 -327 minecraft:light_gray_concrete
fill 218 65 -327 228 65 -327 minecraft:smooth_quartz
setblock 229 65 -327 minecraft:light_gray_concrete
fill 230 65 -327 240 65 -327 minecraft:smooth_quartz
setblock 241 65 -327 minecraft:light_gray_concrete
fill 242 65 -327 252 65 -327 minecraft:smooth_quartz
setblock 253 65 -327 minecraft:light_gray_concrete
fill 254 65 -327 263 65 -327 minecraft:smooth_quartz
setblock 205 65 -326 minecraft:light_gray_concrete
fill 206 65 -326 214 65 -326 minecraft:smooth_quartz
setblock 215 65 -326 minecraft:sea_lantern
setblock 216 65 -326 minecraft:smooth_quartz
setblock 217 65 -326 minecraft:light_gray_concrete
fill 218 65 -326 228 65 -326 minecraft:smooth_quartz
setblock 229 65 -326 minecraft:light_gray_concrete
fill 230 65 -326 238 65 -326 minecraft:smooth_quartz
setblock 239 65 -326 minecraft:sea_lantern
setblock 240 65 -326 minecraft:smooth_quartz
setblock 241 65 -326 minecraft:light_gray_concrete
fill 242 65 -326 252 65 -326 minecraft:smooth_quartz
setblock 253 65 -326 minecraft:light_gray_concrete
fill 254 65 -326 263 65 -326 minecraft:smooth_quartz
setblock 205 65 -325 minecraft:light_gray_concrete
fill 206 65 -325 213 65 -325 minecraft:smooth_quartz
fill 214 65 -325 216 65 -325 minecraft:grass_block
setblock 217 65 -325 minecraft:light_gray_concrete
fill 218 65 -325 222 65 -325 minecraft:smooth_quartz
fill 224 65 -325 228 65 -325 minecraft:smooth_quartz
setblock 229 65 -325 minecraft:light_gray_concrete
fill 230 65 -325 237 65 -325 minecraft:smooth_quartz
fill 238 65 -325 240 65 -325 minecraft:grass_block
setblock 241 65 -325 minecraft:light_gray_concrete
fill 242 65 -325 252 65 -325 minecraft:smooth_quartz
setblock 253 65 -325 minecraft:light_gray_concrete
fill 254 65 -325 262 65 -325 minecraft:smooth_quartz
setblock 205 65 -324 minecraft:light_gray_concrete
fill 206 65 -324 212 65 -324 minecraft:smooth_quartz
fill 213 65 -324 217 65 -324 minecraft:grass_block
fill 218 65 -324 228 65 -324 minecraft:smooth_quartz
setblock 229 65 -324 minecraft:light_gray_concrete
fill 230 65 -324 236 65 -324 minecraft:smooth_quartz
fill 237 65 -324 241 65 -324 minecraft:grass_block
fill 242 65 -324 252 65 -324 minecraft:smooth_quartz
setblock 253 65 -324 minecraft:light_gray_concrete
fill 254 65 -324 261 65 -324 minecraft:smooth_quartz
setblock 205 65 -323 minecraft:light_gray_concrete
fill 206 65 -323 211 65 -323 minecraft:smooth_quartz
fill 213 65 -323 218 65 -323 minecraft:grass_block
fill 219 65 -323 228 65 -323 minecraft:smooth_quartz
setblock 229 65 -323 minecraft:light_gray_concrete
fill 230 65 -323 235 65 -323 minecraft:smooth_quartz
fill 236 65 -323 242 65 -323 minecraft:grass_block
fill 243 65 -323 252 65 -323 minecraft:smooth_quartz
setblock 253 65 -323 minecraft:light_gray_concrete
fill 254 65 -323 261 65 -323 minecraft:smooth_quartz
setblock 205 65 -322 minecraft:light_gray_concrete
fill 206 65 -322 210 65 -322 minecraft:smooth_quartz
setblock 211 65 -322 minecraft:sea_lantern
fill 212 65 -322 218 65 -322 minecraft:grass_block
setblock 219 65 -322 minecraft:sea_lantern
fill 220 65 -322 224 65 -322 minecraft:smooth_quartz
fill 227 65 -322 228 65 -322 minecraft:smooth_quartz
setblock 229 65 -322 minecraft:light_gray_concrete
fill 230 65 -322 234 65 -322 minecraft:smooth_quartz
setblock 235 65 -322 minecraft:sea_lantern
fill 236 65 -322 242 65 -322 minecraft:grass_block
setblock 243 65 -322 minecraft:sea_lantern
fill 244 65 -322 252 65 -322 minecraft:smooth_quartz
setblock 253 65 -322 minecraft:light_gray_concrete
fill 254 65 -322 261 65 -322 minecraft:smooth_quartz
setblock 205 65 -321 minecraft:light_gray_concrete
fill 206 65 -321 211 65 -321 minecraft:smooth_quartz
fill 212 65 -321 218 65 -321 minecraft:grass_block
fill 219 65 -321 222 65 -321 minecraft:smooth_quartz
fill 225 65 -321 228 65 -321 minecraft:smooth_quartz
setblock 229 65 -321 minecraft:light_gray_concrete
fill 230 65 -321 235 65 -321 minecraft:smooth_quartz
fill 236 65 -321 242 65 -321 minecraft:grass_block
fill 243 65 -321 252 65 -321 minecraft:smooth_quartz
setblock 253 65 -321 minecraft:light_gray_concrete
fill 254 65 -321 262 65 -321 minecraft:smooth_quartz
fill 205 65 -320 212 65 -320 minecraft:light_gray_concrete
fill 213 65 -320 217 65 -320 minecraft:grass_block
fill 218 65 -320 236 65 -320 minecraft:light_gray_concrete
fill 237 65 -320 241 65 -320 minecraft:grass_block
fill 242 65 -320 263 65 -320 minecraft:light_gray_concrete
setblock 205 65 -319 minecraft:light_gray_concrete
fill 206 65 -319 213 65 -319 minecraft:smooth_quartz
fill 214 65 -319 216 65 -319 minecraft:grass_block
setblock 217 65 -319 minecraft:light_gray_concrete
fill 218 65 -319 228 65 -319 minecraft:smooth_quartz
setblock 229 65 -319 minecraft:light_gray_concrete
fill 230 65 -319 237 65 -319 minecraft:smooth_quartz
fill 238 65 -319 240 65 -319 minecraft:grass_block
setblock 241 65 -319 minecraft:light_gray_concrete
fill 242 65 -319 252 65 -319 minecraft:smooth_quartz
setblock 253 65 -319 minecraft:light_gray_concrete
fill 254 65 -319 263 65 -319 minecraft:smooth_quartz
setblock 205 66 -380 minecraft:air
setblock 200 66 -379 minecraft:air
setblock 205 66 -379 minecraft:air
setblock 204 66 -378 minecraft:air
setblock 236 66 -378 minecraft:air
setblock 206 66 -377 minecraft:air
fill 205 66 -376 206 66 -376 minecraft:air
fill 203 66 -375 206 66 -375 minecraft:air
fill 202 66 -374 206 66 -374 minecraft:air
setblock 220 66 -374 minecraft:air
fill 200 66 -373 206 66 -373 minecraft:air
fill 200 66 -372 206 66 -372 minecraft:air
fill 200 66 -371 206 66 -371 minecraft:air
setblock 208 66 -371 minecraft:air
fill 200 66 -370 206 66 -370 minecraft:air
setblock 215 66 -370 minecraft:oak_log
setblock 239 66 -370 minecraft:oak_log
fill 200 66 -369 206 66 -369 minecraft:air
fill 200 66 -368 206 66 -368 minecraft:air
fill 200 66 -367 206 66 -367 minecraft:air
fill 200 66 -366 206 66 -366 minecraft:air
fill 200 66 -365 206 66 -365 minecraft:air
setblock 236 66 -365 minecraft:air
fill 200 66 -364 206 66 -364 minecraft:air
fill 200 66 -363 206 66 -363 minecraft:air
fill 200 66 -362 206 66 -362 minecraft:air
setblock 216 66 -362 minecraft:air
setblock 249 66 -362 minecraft:air
fill 200 66 -361 206 66 -361 minecraft:air
fill 200 66 -360 206 66 -360 minecraft:air
fill 200 66 -359 206 66 -359 minecraft:air
fill 200 66 -358 206 66 -358 minecraft:air
fill 200 66 -357 206 66 -357 minecraft:air
fill 200 66 -356 206 66 -356 minecraft:air
fill 200 66 -355 206 66 -355 minecraft:air
fill 200 66 -354 206 66 -354 minecraft:air
setblock 225 66 -354 minecraft:air
fill 200 66 -353 206 66 -353 minecraft:air
fill 200 66 -352 206 66 -352 minecraft:air
fill 200 66 -351 206 66 -351 minecraft:air
fill 200 66 -350 206 66 -350 minecraft:air
setblock 241 66 -350 minecraft:air
fill 200 66 -349 206 66 -349 minecraft:air
fill 200 66 -348 206 66 -348 minecraft:air
setblock 209 66 -348 minecraft:air
fill 200 66 -347 206 66 -347 minecraft:air
fill 200 66 -346 206 66 -346 minecraft:air
setblock 215 66 -346 minecraft:oak_log
setblock 239 66 -346 minecraft:oak_log
fill 200 66 -345 206 66 -345 minecraft:air
fill 200 66 -344 206 66 -344 minecraft:air
fill 200 66 -343 206 66 -343 minecraft:air
setblock 228 66 -343 minecraft:air
fill 200 66 -342 206 66 -342 minecraft:air
fill 200 66 -341 206 66 -341 minecraft:air
fill 200 66 -340 206 66 -340 minecraft:air
setblock 234 66 -336 minecraft:air
setblock 220 66 -334 minecraft:air
setblock 241 66 -329 minecraft:air
setblock 208 66 -328 minecraft:air
setblock 231 66 -325 minecraft:air
setblock 259 66 -324 minecraft:air
setblock 215 66 -322 minecraft:oak_log
setblock 239 66 -322 minecraft:oak_log
setblock 247 66 -321 minecraft:air
setblock 205 67 -380 minecraft:air
setblock 200 67 -379 minecraft:air
setblock 204 67 -378 minecraft:air
setblock 203 67 -375 minecraft:air
setblock 206 67 -375 minecraft:air
setblock 206 67 -373 minecraft:air
fill 205 67 -372 206 67 -372 minecraft:air
fill 205 67 -371 206 67 -371 minecraft:air
fill 204 67 -370 206 67 -370 minecraft:air
setblock 215 67 -370 minecraft:oak_log
setblock 239 67 -370 minecraft:oak_log
setblock 201 67 -369 minecraft:air
fill 203 67 -369 206 67 -369 minecraft:air
fill 202 67 -368 206 67 -368 minecraft:air
fill 202 67 -367 206 67 -367 minecraft:air
fill 200 67 -366 206 67 -366 minecraft:air
fill 200 67 -365 206 67 -365 minecraft:air
fill 200 67 -364 206 67 -364 minecraft:air
fill 200 67 -363 206 67 -363 minecraft:air
fill 200 67 -362 206 67 -362 minecraft:air
fill 200 67 -361 206 67 -361 minecraft:air
fill 200 67 -360 206 67 -360 minecraft:air
fill 200 67 -359 206 67 -359 minecraft:air
fill 200 67 -358 206 67 -358 minecraft:air
fill 200 67 -357 206 67 -357 minecraft:air
fill 200 67 -356 206 67 -356 minecraft:air
fill 200 67 -355 206 67 -355 minecraft:air
fill 200 67 -354 206 67 -354 minecraft:air
fill 200 67 -353 206 67 -353 minecraft:air
fill 200 67 -352 206 67 -352 minecraft:air
fill 200 67 -351 206 67 -351 minecraft:air
fill 200 67 -350 206 67 -350 minecraft:air
fill 200 67 -349 206 67 -349 minecraft:air
fill 200 67 -348 206 67 -348 minecraft:air
fill 200 67 -347 206 67 -347 minecraft:air
fill 200 67 -346 206 67 -346 minecraft:air
setblock 215 67 -346 minecraft:oak_log
setblock 239 67 -346 minecraft:oak_log
fill 200 67 -345 206 67 -345 minecraft:air
fill 200 67 -344 206 67 -344 minecraft:air
fill 200 67 -343 206 67 -343 minecraft:air
fill 200 67 -342 206 67 -342 minecraft:air
fill 200 67 -341 206 67 -341 minecraft:air
fill 200 67 -340 206 67 -340 minecraft:air
setblock 215 67 -322 minecraft:oak_log
setblock 239 67 -322 minecraft:oak_log
setblock 205 68 -380 minecraft:air
setblock 200 68 -379 minecraft:air
setblock 204 68 -378 minecraft:air
setblock 203 68 -375 minecraft:air
setblock 215 68 -370 minecraft:oak_log
setblock 239 68 -370 minecraft:oak_log
setblock 203 68 -369 minecraft:air
setblock 206 68 -369 minecraft:air
setblock 203 68 -368 minecraft:air
setblock 206 68 -368 minecraft:air
fill 203 68 -367 204 68 -367 minecraft:air
setblock 202 68 -366 minecraft:air
setblock 206 68 -361 minecraft:air
setblock 202 68 -360 minecraft:air
fill 204 68 -360 206 68 -360 minecraft:air
fill 203 68 -359 206 68 -359 minecraft:air
setblock 201 68 -358 minecraft:air
fill 203 68 -358 206 68 -358 minecraft:air
fill 200 68 -357 206 68 -357 minecraft:air
setblock 200 68 -356 minecraft:air
fill 202 68 -356 206 68 -356 minecraft:air
fill 202 68 -355 206 68 -355 minecraft:air
fill 202 68 -354 206 68 -354 minecraft:air
fill 202 68 -353 206 68 -353 minecraft:air
fill 202 68 -352 206 68 -352 minecraft:air
fill 202 68 -351 206 68 -351 minecraft:air
fill 202 68 -350 206 68 -350 minecraft:air
setblock 200 68 -349 minecraft:air
fill 202 68 -349 206 68 -349 minecraft:air
fill 203 68 -348 206 68 -348 minecraft:air
fill 202 68 -347 206 68 -347 minecraft:air
fill 203 68 -346 206 68 -346 minecraft:air
setblock 215 68 -346 minecraft:oak_log
setblock 239 68 -346 minecraft:oak_log
fill 203 68 -345 206 68 -345 minecraft:air
fill 204 68 -344 206 68 -344 minecraft:air
fill 204 68 -343 206 68 -343 minecraft:air
fill 204 68 -342 206 68 -342 minecraft:air
setblock 200 68 -341 minecraft:air
fill 205 68 -341 206 68 -341 minecraft:air
setblock 200 68 -340 minecraft:air
setblock 206 68 -340 minecraft:air
setblock 215 68 -322 minecraft:oak_log
setblock 239 68 -322 minecraft:oak_log
setblock 205 69 -380 minecraft:air
setblock 200 69 -379 minecraft:air
setblock 204 69 -378 minecraft:air
setblock 203 69 -375 minecraft:air
setblock 215 69 -372 minecraft:oak_leaves[persistent=true]
setblock 239 69 -372 minecraft:oak_leaves[persistent=true]
fill 214 69 -371 216 69 -371 minecraft:oak_leaves[persistent=true]
fill 238 69 -371 240 69 -371 minecraft:oak_leaves[persistent=true]
fill 213 69 -370 214 69 -370 minecraft:oak_leaves[persistent=true]
setblock 215 69 -370 minecraft:oak_log
fill 216 69 -370 217 69 -370 minecraft:oak_leaves[persistent=true]
fill 237 69 -370 238 69 -370 minecraft:oak_leaves[persistent=true]
setblock 239 69 -370 minecraft:oak_log
fill 240 69 -370 241 69 -370 minecraft:oak_leaves[persistent=true]
fill 214 69 -369 216 69 -369 minecraft:oak_leaves[persistent=true]
fill 238 69 -369 240 69 -369 minecraft:oak_leaves[persistent=true]
setblock 215 69 -368 minecraft:oak_leaves[persistent=true]
setblock 239 69 -368 minecraft:oak_leaves[persistent=true]
setblock 204 69 -360 minecraft:air
setblock 203 69 -358 minecraft:air
setblock 204 69 -356 minecraft:air
setblock 205 69 -354 minecraft:air
setblock 202 69 -352 minecraft:air
setblock 203 69 -351 minecraft:air
setblock 215 69 -348 minecraft:oak_leaves[persistent=true]
setblock 239 69 -348 minecraft:oak_leaves[persistent=true]
fill 214 69 -347 216 69 -347 minecraft:oak_leaves[persistent=true]
fill 238 69 -347 240 69 -347 minecraft:oak_leaves[persistent=true]
fill 213 69 -346 214 69 -346 minecraft:oak_leaves[persistent=true]
setblock 215 69 -346 minecraft:oak_log
fill 216 69 -346 217 69 -346 minecraft:oak_leaves[persistent=true]
fill 237 69 -346 238 69 -346 minecraft:oak_leaves[persistent=true]
setblock 239 69 -346 minecraft:oak_log
fill 240 69 -346 241 69 -346 minecraft:oak_leaves[persistent=true]
fill 214 69 -345 216 69 -345 minecraft:oak_leaves[persistent=true]
fill 238 69 -345 240 69 -345 minecraft:oak_leaves[persistent=true]
fill 204 69 -344 205 69 -344 minecraft:air
setblock 215 69 -344 minecraft:oak_leaves[persistent=true]
setblock 239 69 -344 minecraft:oak_leaves[persistent=true]
setblock 206 69 -343 minecraft:air
fill 204 69 -342 205 69 -342 minecraft:air
setblock 215 69 -324 minecraft:oak_leaves[persistent=true]
setblock 239 69 -324 minecraft:oak_leaves[persistent=true]
fill 214 69 -323 216 69 -323 minecraft:oak_leaves[persistent=true]
fill 238 69 -323 240 69 -323 minecraft:oak_leaves[persistent=true]
fill 213 69 -322 214 69 -322 minecraft:oak_leaves[persistent=true]
setblock 215 69 -322 minecraft:oak_log
fill 216 69 -322 217 69 -322 minecraft:oak_leaves[persistent=true]
fill 237 69 -322 238 69 -322 minecraft:oak_leaves[persistent=true]
setblock 239 69 -322 minecraft:oak_log
fill 240 69 -322 241 69 -322 minecraft:oak_leaves[persistent=true]
fill 214 69 -321 216 69 -321 minecraft:oak_leaves[persistent=true]
fill 238 69 -321 240 69 -321 minecraft:oak_leaves[persistent=true]
setblock 215 69 -320 minecraft:oak_leaves[persistent=true]
setblock 239 69 -320 minecraft:oak_leaves[persistent=true]
setblock 205 70 -380 minecraft:air
setblock 200 70 -379 minecraft:air
setblock 204 70 -378 minecraft:air
setblock 200 70 -376 minecraft:air
setblock 203 70 -375 minecraft:air
fill 214 70 -372 216 70 -372 minecraft:oak_leaves[persistent=true]
fill 238 70 -372 240 70 -372 minecraft:oak_leaves[persistent=true]
fill 213 70 -371 217 70 -371 minecraft:oak_leaves[persistent=true]
fill 237 70 -371 241 70 -371 minecraft:oak_leaves[persistent=true]
fill 213 70 -370 214 70 -370 minecraft:oak_leaves[persistent=true]
setblock 215 70 -370 minecraft:oak_log
fill 216 70 -370 217 70 -370 minecraft:oak_leaves[persistent=true]
fill 237 70 -370 238 70 -370 minecraft:oak_leaves[persistent=true]
setblock 239 70 -370 minecraft:oak_log
fill 240 70 -370 241 70 -370 minecraft:oak_leaves[persistent=true]
fill 213 70 -369 217 70 -369 minecraft:oak_leaves[persistent=true]
fill 237 70 -369 241 70 -369 minecraft:oak_leaves[persistent=true]
fill 214 70 -368 216 70 -368 minecraft:oak_leaves[persistent=true]
fill 238 70 -368 240 70 -368 minecraft:oak_leaves[persistent=true]
setblock 204 70 -360 minecraft:air
setblock 203 70 -358 minecraft:air
setblock 205 70 -354 minecraft:air
setblock 202 70 -352 minecraft:air
fill 214 70 -348 216 70 -348 minecraft:oak_leaves[persistent=true]
fill 238 70 -348 240 70 -348 minecraft:oak_leaves[persistent=true]
fill 213 70 -347 217 70 -347 minecraft:oak_leaves[persistent=true]
fill 237 70 -347 241 70 -347 minecraft:oak_leaves[persistent=true]
fill 213 70 -346 214 70 -346 minecraft:oak_leaves[persistent=true]
setblock 215 70 -346 minecraft:oak_log
fill 216 70 -346 217 70 -346 minecraft:oak_leaves[persistent=true]
fill 237 70 -346 238 70 -346 minecraft:oak_leaves[persistent=true]
setblock 239 70 -346 minecraft:oak_log
fill 240 70 -346 241 70 -346 minecraft:oak_leaves[persistent=true]
fill 213 70 -345 217 70 -345 minecraft:oak_leaves[persistent=true]
fill 237 70 -345 241 70 -345 minecraft:oak_leaves[persistent=true]
fill 214 70 -344 216 70 -344 minecraft:oak_leaves[persistent=true]
fill 238 70 -344 240 70 -344 minecraft:oak_leaves[persistent=true]
setblock 204 70 -342 minecraft:air
fill 214 70 -324 216 70 -324 minecraft:oak_leaves[persistent=true]
fill 238 70 -324 240 70 -324 minecraft:oak_leaves[persistent=true]
fill 213 70 -323 217 70 -323 minecraft:oak_leaves[persistent=true]
fill 237 70 -323 241 70 -323 minecraft:oak_leaves[persistent=true]
fill 213 70 -322 214 70 -322 minecraft:oak_leaves[persistent=true]
setblock 215 70 -322 minecraft:oak_log
fill 216 70 -322 217 70 -322 minecraft:oak_leaves[persistent=true]
fill 237 70 -322 238 70 -322 minecraft:oak_leaves[persistent=true]
setblock 239 70 -322 minecraft:oak_log
fill 240 70 -322 241 70 -322 minecraft:oak_leaves[persistent=true]
fill 213 70 -321 217 70 -321 minecraft:oak_leaves[persistent=true]
fill 237 70 -321 241 70 -321 minecraft:oak_leaves[persistent=true]
fill 214 70 -320 216 70 -320 minecraft:oak_leaves[persistent=true]
fill 238 70 -320 240 70 -320 minecraft:oak_leaves[persistent=true]
setblock 263 70 -319 minecraft:air
setblock 205 71 -382 minecraft:air
setblock 200 71 -381 minecraft:air
fill 204 71 -381 206 71 -381 minecraft:air
fill 200 71 -380 201 71 -380 minecraft:air
fill 203 71 -380 206 71 -380 minecraft:air
fill 200 71 -379 202 71 -379 minecraft:air
fill 204 71 -379 206 71 -379 minecraft:air
fill 200 71 -378 201 71 -378 minecraft:air
fill 204 71 -378 205 71 -378 minecraft:air
setblock 200 71 -377 minecraft:air
setblock 203 71 -375 minecraft:air
setblock 215 71 -372 minecraft:oak_leaves[persistent=true]
setblock 239 71 -372 minecraft:oak_leaves[persistent=true]
fill 214 71 -371 216 71 -371 minecraft:oak_leaves[persistent=true]
fill 238 71 -371 240 71 -371 minecraft:oak_leaves[persistent=true]
fill 213 71 -370 217 71 -370 minecraft:oak_leaves[persistent=true]
fill 237 71 -370 241 71 -370 minecraft:oak_leaves[persistent=true]
fill 214 71 -369 216 71 -369 minecraft:oak_leaves[persistent=true]
fill 238 71 -369 240 71 -369 minecraft:oak_leaves[persistent=true]
setblock 215 71 -368 minecraft:oak_leaves[persistent=true]
setblock 239 71 -368 minecraft:oak_leaves[persistent=true]
setblock 204 71 -360 minecraft:air
setblock 203 71 -358 minecraft:air
setblock 205 71 -354 minecraft:air
setblock 202 71 -352 minecraft:air
setblock 215 71 -348 minecraft:oak_leaves[persistent=true]
setblock 239 71 -348 minecraft:oak_leaves[persistent=true]
fill 214 71 -347 216 71 -347 minecraft:oak_leaves[persistent=true]
fill 238 71 -347 240 71 -347 minecraft:oak_leaves[persistent=true]
fill 213 71 -346 217 71 -346 minecraft:oak_leaves[persistent=true]
fill 237 71 -346 241 71 -346 minecraft:oak_leaves[persistent=true]
fill 214 71 -345 216 71 -345 minecraft:oak_leaves[persistent=true]
fill 238 71 -345 240 71 -345 minecraft:oak_leaves[persistent=true]
setblock 215 71 -344 minecraft:oak_leaves[persistent=true]
setblock 239 71 -344 minecraft:oak_leaves[persistent=true]
setblock 204 71 -342 minecraft:air
setblock 215 71 -324 minecraft:oak_leaves[persistent=true]
setblock 239 71 -324 minecraft:oak_leaves[persistent=true]
fill 214 71 -323 216 71 -323 minecraft:oak_leaves[persistent=true]
fill 238 71 -323 240 71 -323 minecraft:oak_leaves[persistent=true]
fill 213 71 -322 217 71 -322 minecraft:oak_leaves[persistent=true]
fill 237 71 -322 241 71 -322 minecraft:oak_leaves[persistent=true]
fill 214 71 -321 216 71 -321 minecraft:oak_leaves[persistent=true]
fill 238 71 -321 240 71 -321 minecraft:oak_leaves[persistent=true]
setblock 215 71 -320 minecraft:oak_leaves[persistent=true]
setblock 239 71 -320 minecraft:oak_leaves[persistent=true]
setblock 263 71 -319 minecraft:air
fill 204 72 -381 206 72 -381 minecraft:air
fill 200 72 -380 201 72 -380 minecraft:air
fill 204 72 -380 206 72 -380 minecraft:air
fill 200 72 -379 201 72 -379 minecraft:air
fill 203 72 -379 206 72 -379 minecraft:air
fill 200 72 -378 206 72 -378 minecraft:air
fill 203 72 -377 205 72 -377 minecraft:air
setblock 204 72 -376 minecraft:air
setblock 203 72 -375 minecraft:air
setblock 215 72 -370 minecraft:oak_leaves[persistent=true]
setblock 239 72 -370 minecraft:oak_leaves[persistent=true]
setblock 204 72 -360 minecraft:air
setblock 203 72 -358 minecraft:air
setblock 205 72 -354 minecraft:air
setblock 202 72 -352 minecraft:air
setblock 215 72 -346 minecraft:oak_leaves[persistent=true]
setblock 239 72 -346 minecraft:oak_leaves[persistent=true]
setblock 204 72 -342 minecraft:air
setblock 215 72 -322 minecraft:oak_leaves[persistent=true]
setblock 239 72 -322 minecraft:oak_leaves[persistent=true]
setblock 205 73 -381 minecraft:air
setblock 200 73 -380 minecraft:air
fill 204 73 -380 206 73 -380 minecraft:air
fill 200 73 -379 201 73 -379 minecraft:air
fill 203 73 -379 205 73 -379 minecraft:air
setblock 200 73 -378 minecraft:air
fill 203 73 -378 205 73 -378 minecraft:air
fill 203 73 -377 205 73 -377 minecraft:air
fill 202 73 -376 204 73 -376 minecraft:air
fill 201 73 -375 205 73 -375 minecraft:air
fill 202 73 -374 204 73 -374 minecraft:air
setblock 203 73 -373 minecraft:air
setblock 200 73 -370 minecraft:air
fill 200 73 -369 201 73 -369 minecraft:air
setblock 200 73 -368 minecraft:air
setblock 204 73 -360 minecraft:air
setblock 203 73 -358 minecraft:air
setblock 205 73 -354 minecraft:air
setblock 202 73 -352 minecraft:air
setblock 204 73 -342 minecraft:air
setblock 205 74 -381 minecraft:air
fill 205 74 -380 206 74 -380 minecraft:air
fill 200 74 -379 201 74 -379 minecraft:air
fill 204 74 -379 205 74 -379 minecraft:air
setblock 200 74 -378 minecraft:air
fill 203 74 -378 205 74 -378 minecraft:air
setblock 204 74 -377 minecraft:air
fill 202 74 -376 204 74 -376 minecraft:air
fill 202 74 -375 204 74 -375 minecraft:air
fill 202 74 -374 204 74 -374 minecraft:air
setblock 200 74 -370 minecraft:air
setblock 200 74 -369 minecraft:air
setblock 200 74 -368 minecraft:air
setblock 204 74 -360 minecraft:air
setblock 203 74 -358 minecraft:air
setblock 205 74 -354 minecraft:air
setblock 200 74 -352 minecraft:air
setblock 202 74 -352 minecraft:air
setblock 206 74 -352 minecraft:air
fill 200 74 -351 201 74 -351 minecraft:air
fill 205 74 -351 206 74 -351 minecraft:air
setblock 200 74 -350 minecraft:air
setblock 206 74 -350 minecraft:air
setblock 204 74 -344 minecraft:air
fill 203 74 -343 205 74 -343 minecraft:air
fill 202 74 -342 206 74 -342 minecraft:air
fill 203 74 -341 205 74 -341 minecraft:air
fill 204 74 -340 206 74 -340 minecraft:air
setblock 204 75 -379 minecraft:air
fill 204 75 -378 205 75 -378 minecraft:air
setblock 204 75 -377 minecraft:air
setblock 203 75 -376 minecraft:air
fill 202 75 -375 204 75 -375 minecraft:air
setblock 203 75 -374 minecraft:air
setblock 200 75 -369 minecraft:air
setblock 204 75 -362 minecraft:air
fill 203 75 -361 205 75 -361 minecraft:air
fill 202 75 -360 206 75 -360 minecraft:air
fill 203 75 -359 205 75 -359 minecraft:air
fill 203 75 -358 204 75 -358 minecraft:air
setblock 205 75 -356 minecraft:air
setblock 200 75 -355 minecraft:air
fill 204 75 -355 206 75 -355 minecraft:air
fill 200 75 -354 201 75 -354 minecraft:air
fill 203 75 -354 206 75 -354 minecraft:air
setblock 200 75 -353 minecraft:air
fill 204 75 -353 206 75 -353 minecraft:air
setblock 200 75 -352 minecraft:air
setblock 202 75 -352 minecraft:air
fill 205 75 -352 206 75 -352 minecraft:air
setblock 200 75 -351 minecraft:air
setblock 206 75 -351 minecraft:air
setblock 200 75 -350 minecraft:air
setblock 206 75 -350 minecraft:air
fill 203 75 -343 205 75 -343 minecraft:air
fill 203 75 -342 205 75 -342 minecraft:air
fill 203 75 -341 205 75 -341 minecraft:air
fill 204 75 -340 206 75 -340 minecraft:air
fill 203 76 -375 204 76 -375 minecraft:air
setblock 203 76 -374 minecraft:air
setblock 200 76 -369 minecraft:air
setblock 206 76 -363 minecraft:air
fill 205 76 -362 206 76 -362 minecraft:air
fill 203 76 -361 206 76 -361 minecraft:air
fill 203 76 -360 205 76 -360 minecraft:air
fill 202 76 -359 205 76 -359 minecraft:air
fill 201 76 -358 205 76 -358 minecraft:air
fill 202 76 -357 204 76 -357 minecraft:air
setblock 203 76 -356 minecraft:air
setblock 200 76 -355 minecraft:air
fill 204 76 -355 206 76 -355 minecraft:air
setblock 200 76 -354 minecraft:air
setblock 202 76 -354 minecraft:air
fill 204 76 -354 206 76 -354 minecraft:air
fill 200 76 -353 206 76 -353 minecraft:air
fill 200 76 -352 204 76 -352 minecraft:air
fill 200 76 -351 203 76 -351 minecraft:air
setblock 206 76 -351 minecraft:air
setblock 202 76 -350 minecraft:air
setblock 204 76 -343 minecraft:air
fill 203 76 -342 205 76 -342 minecraft:air
setblock 204 76 -341 minecraft:air
setblock 205 76 -340 minecraft:air
setblock 206 77 -362 minecraft:air
setblock 204 77 -361 minecraft:air
setblock 206 77 -361 minecraft:air
fill 203 77 -360 205 77 -360 minecraft:air
fill 202 77 -359 204 77 -359 minecraft:air
fill 202 77 -358 204 77 -358 minecraft:air
fill 202 77 -357 204 77 -357 minecraft:air
setblock 205 77 -355 minecraft:air
setblock 200 77 -354 minecraft:air
fill 204 77 -354 206 77 -354 minecraft:air
fill 201 77 -353 203 77 -353 minecraft:air
setblock 205 77 -353 minecraft:air
fill 201 77 -352 203 77 -352 minecraft:air
fill 201 77 -351 203 77 -351 minecraft:air
setblock 204 77 -343 minecraft:air
fill 203 77 -342 205 77 -342 minecraft:air
setblock 204 78 -360 minecraft:air
setblock 203 78 -359 minecraft:air
fill 202 78 -358 204 78 -358 minecraft:air
setblock 203 78 -357 minecraft:air
setblock 205 78 -355 minecraft:air
setblock 200 78 -354 minecraft:air
fill 204 78 -354 206 78 -354 minecraft:air
setblock 202 78 -353 minecraft:air
setblock 205 78 -353 minecraft:air
fill 201 78 -352 203 78 -352 minecraft:air
setblock 202 78 -351 minecraft:air
fill 202 79 -358 203 79 -358 minecraft:air
fill 201 79 -352 203 79 -352 minecraft:air
forceload remove 200 -382 263 -319
tellraw @a {"text":"Campus bau a11 fertig.","color":"green"}
