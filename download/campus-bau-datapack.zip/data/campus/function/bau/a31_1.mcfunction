fill 136 45 -190 146 45 -190 minecraft:stone
fill 194 45 -190 199 45 -190 minecraft:stone
fill 136 45 -189 146 45 -189 minecraft:stone
fill 193 45 -189 199 45 -189 minecraft:stone
fill 136 45 -188 146 45 -188 minecraft:stone
fill 193 45 -188 199 45 -188 minecraft:stone
fill 136 45 -187 144 45 -187 minecraft:stone
fill 193 45 -187 199 45 -187 minecraft:stone
fill 136 45 -186 144 45 -186 minecraft:stone
fill 193 45 -186 199 45 -186 minecraft:stone
fill 136 45 -185 142 45 -185 minecraft:stone
fill 192 45 -185 199 45 -185 minecraft:stone
fill 137 45 -184 141 45 -184 minecraft:stone
fill 192 45 -184 197 45 -184 minecraft:stone
fill 186 45 -183 187 45 -183 minecraft:stone
fill 192 45 -183 199 45 -183 minecraft:stone
fill 186 45 -182 188 45 -182 minecraft:stone
fill 192 45 -182 199 45 -182 minecraft:stone
fill 186 45 -181 188 45 -181 minecraft:stone
fill 192 45 -181 199 45 -181 minecraft:stone
fill 168 45 -180 170 45 -180 minecraft:stone
fill 187 45 -180 189 45 -180 minecraft:stone
fill 192 45 -180 199 45 -180 minecraft:stone
fill 167 45 -179 172 45 -179 minecraft:stone
fill 187 45 -179 189 45 -179 minecraft:stone
fill 192 45 -179 199 45 -179 minecraft:stone
fill 167 45 -178 173 45 -178 minecraft:stone
fill 187 45 -178 188 45 -178 minecraft:stone
fill 192 45 -178 199 45 -178 minecraft:stone
fill 168 45 -177 171 45 -177 minecraft:stone
fill 192 45 -177 199 45 -177 minecraft:stone
setblock 171 45 -176 minecraft:stone
fill 192 45 -176 199 45 -176 minecraft:stone
fill 171 45 -175 177 45 -175 minecraft:stone
fill 191 45 -175 199 45 -175 minecraft:stone
fill 172 45 -174 177 45 -174 minecraft:stone
fill 189 45 -174 199 45 -174 minecraft:stone
fill 173 45 -173 178 45 -173 minecraft:stone
fill 188 45 -173 199 45 -173 minecraft:stone
fill 174 45 -172 177 45 -172 minecraft:stone
fill 187 45 -172 199 45 -172 minecraft:stone
fill 187 45 -171 197 45 -171 minecraft:stone
fill 187 45 -170 196 45 -170 minecraft:stone
fill 186 45 -169 195 45 -169 minecraft:stone
fill 185 45 -168 193 45 -168 minecraft:stone
setblock 164 45 -167 minecraft:stone
fill 185 45 -167 193 45 -167 minecraft:stone
setblock 164 45 -166 minecraft:stone
fill 185 45 -166 192 45 -166 minecraft:stone
setblock 164 45 -165 minecraft:stone
fill 186 45 -165 192 45 -165 minecraft:stone
fill 164 45 -164 168 45 -164 minecraft:stone
fill 163 45 -163 170 45 -163 minecraft:stone
fill 163 45 -162 171 45 -162 minecraft:stone
fill 163 45 -161 172 45 -161 minecraft:stone
fill 163 45 -160 172 45 -160 minecraft:stone
fill 162 45 -159 164 45 -159 minecraft:stone
fill 166 45 -159 172 45 -159 minecraft:stone
fill 161 45 -158 164 45 -158 minecraft:stone
fill 168 45 -158 173 45 -158 minecraft:stone
fill 160 45 -157 164 45 -157 minecraft:stone
fill 168 45 -157 173 45 -157 minecraft:stone
fill 159 45 -156 163 45 -156 minecraft:stone
fill 169 45 -156 173 45 -156 minecraft:stone
fill 159 45 -155 163 45 -155 minecraft:stone
fill 169 45 -155 173 45 -155 minecraft:stone
fill 158 45 -154 163 45 -154 minecraft:stone
fill 169 45 -154 173 45 -154 minecraft:stone
fill 158 45 -153 162 45 -153 minecraft:stone
fill 170 45 -153 173 45 -153 minecraft:stone
fill 157 45 -152 162 45 -152 minecraft:stone
fill 171 45 -152 173 45 -152 minecraft:stone
fill 157 45 -151 161 45 -151 minecraft:stone
fill 172 45 -151 173 45 -151 minecraft:stone
fill 157 45 -150 160 45 -150 minecraft:stone
setblock 172 45 -150 minecraft:stone
setblock 136 45 -138 minecraft:stone
fill 136 45 -137 138 45 -137 minecraft:stone
fill 136 45 -136 139 45 -136 minecraft:stone
fill 136 45 -135 140 45 -135 minecraft:stone
fill 136 45 -134 141 45 -134 minecraft:stone
fill 137 45 -133 143 45 -133 minecraft:stone
fill 138 45 -132 144 45 -132 minecraft:stone
fill 137 45 -131 144 45 -131 minecraft:stone
fill 137 45 -130 144 45 -130 minecraft:stone
fill 137 45 -129 145 45 -129 minecraft:stone
fill 137 45 -128 146 45 -128 minecraft:stone
fill 148 45 -128 149 45 -128 minecraft:stone
fill 198 45 -128 199 45 -128 minecraft:stone
fill 138 45 -127 150 45 -127 minecraft:stone
fill 196 45 -127 199 45 -127 minecraft:stone
fill 136 46 -190 146 46 -190 minecraft:stone
fill 181 46 -190 186 46 -190 minecraft:stone
fill 194 46 -190 199 46 -190 minecraft:stone
fill 136 46 -189 145 46 -189 minecraft:stone
fill 194 46 -189 199 46 -189 minecraft:stone
fill 136 46 -188 144 46 -188 minecraft:stone
fill 193 46 -188 199 46 -188 minecraft:stone
fill 136 46 -187 143 46 -187 minecraft:stone
fill 193 46 -187 199 46 -187 minecraft:stone
fill 136 46 -186 141 46 -186 minecraft:stone
fill 193 46 -186 199 46 -186 minecraft:stone
fill 136 46 -185 142 46 -185 minecraft:stone
fill 192 46 -185 199 46 -185 minecraft:stone
fill 192 46 -184 197 46 -184 minecraft:stone
fill 192 46 -183 199 46 -183 minecraft:stone
fill 193 46 -182 199 46 -182 minecraft:stone
fill 193 46 -181 199 46 -181 minecraft:stone
fill 193 46 -180 199 46 -180 minecraft:stone
fill 167 46 -179 170 46 -179 minecraft:stone
fill 193 46 -179 199 46 -179 minecraft:stone
fill 167 46 -178 171 46 -178 minecraft:stone
fill 193 46 -178 199 46 -178 minecraft:stone
fill 170 46 -177 176 46 -177 minecraft:stone
fill 193 46 -177 199 46 -177 minecraft:stone
fill 171 46 -176 176 46 -176 minecraft:stone
fill 193 46 -176 199 46 -176 minecraft:stone
fill 172 46 -175 177 46 -175 minecraft:stone
fill 192 46 -175 199 46 -175 minecraft:stone
fill 173 46 -174 177 46 -174 minecraft:stone
fill 190 46 -174 199 46 -174 minecraft:stone
fill 189 46 -173 199 46 -173 minecraft:stone
fill 188 46 -172 199 46 -172 minecraft:stone
fill 188 46 -171 197 46 -171 minecraft:stone
fill 187 46 -170 196 46 -170 minecraft:stone
fill 186 46 -169 195 46 -169 minecraft:stone
fill 186 46 -168 193 46 -168 minecraft:stone
fill 186 46 -167 192 46 -167 minecraft:stone
fill 186 46 -166 192 46 -166 minecraft:stone
fill 188 46 -165 189 46 -165 minecraft:stone
fill 165 46 -163 168 46 -163 minecraft:stone
fill 165 46 -162 169 46 -162 minecraft:stone
fill 165 46 -161 170 46 -161 minecraft:stone
fill 166 46 -160 171 46 -160 minecraft:stone
fill 168 46 -159 171 46 -159 minecraft:stone
fill 169 46 -158 171 46 -158 minecraft:stone
fill 169 46 -157 171 46 -157 minecraft:stone
fill 160 46 -156 162 46 -156 minecraft:stone
fill 170 46 -156 171 46 -156 minecraft:stone
fill 160 46 -155 162 46 -155 minecraft:stone
fill 170 46 -155 171 46 -155 minecraft:stone
fill 158 46 -154 162 46 -154 minecraft:stone
fill 157 46 -153 162 46 -153 minecraft:stone
fill 157 46 -152 162 46 -152 minecraft:stone
fill 156 46 -151 161 46 -151 minecraft:stone
fill 156 46 -150 160 46 -150 minecraft:stone
fill 156 46 -149 160 46 -149 minecraft:stone
fill 150 46 -148 151 46 -148 minecraft:stone
fill 156 46 -148 159 46 -148 minecraft:stone
fill 150 46 -147 151 46 -147 minecraft:stone
fill 156 46 -147 160 46 -147 minecraft:stone
fill 156 46 -146 160 46 -146 minecraft:stone
fill 156 46 -145 160 46 -145 minecraft:stone
fill 157 46 -144 159 46 -144 minecraft:stone
fill 136 46 -137 137 46 -137 minecraft:stone
fill 136 46 -136 138 46 -136 minecraft:stone
fill 136 46 -135 139 46 -135 minecraft:stone
fill 136 46 -134 140 46 -134 minecraft:stone
fill 137 46 -133 142 46 -133 minecraft:stone
fill 138 46 -132 143 46 -132 minecraft:stone
fill 138 46 -131 143 46 -131 minecraft:stone
fill 138 46 -130 143 46 -130 minecraft:stone
fill 138 46 -129 145 46 -129 minecraft:stone
setblock 199 46 -129 minecraft:stone
fill 139 46 -128 146 46 -128 minecraft:stone
fill 148 46 -128 156 46 -128 minecraft:stone
setblock 158 46 -128 minecraft:stone
setblock 199 46 -128 minecraft:stone
fill 143 46 -127 160 46 -127 minecraft:stone
fill 136 47 -190 144 47 -190 minecraft:stone
fill 179 47 -190 181 47 -190 minecraft:stone
fill 194 47 -190 199 47 -190 minecraft:stone
fill 136 47 -189 144 47 -189 minecraft:stone
fill 194 47 -189 199 47 -189 minecraft:stone
fill 136 47 -188 142 47 -188 minecraft:stone
setblock 144 47 -188 minecraft:stone
fill 193 47 -188 199 47 -188 minecraft:stone
fill 136 47 -187 140 47 -187 minecraft:stone
setblock 142 47 -187 minecraft:stone
fill 193 47 -187 199 47 -187 minecraft:stone
fill 136 47 -186 141 47 -186 minecraft:stone
fill 193 47 -186 199 47 -186 minecraft:stone
setblock 136 47 -185 minecraft:stone
fill 192 47 -185 199 47 -185 minecraft:stone
setblock 167 47 -184 minecraft:stone
fill 192 47 -184 198 47 -184 minecraft:stone
setblock 168 47 -183 minecraft:stone
fill 192 47 -183 199 47 -183 minecraft:stone
fill 168 47 -182 169 47 -182 minecraft:stone
fill 193 47 -182 199 47 -182 minecraft:stone
fill 168 47 -181 170 47 -181 minecraft:stone
fill 193 47 -181 199 47 -181 minecraft:stone
fill 169 47 -180 171 47 -180 minecraft:stone
fill 193 47 -180 199 47 -180 minecraft:stone
fill 169 47 -179 175 47 -179 minecraft:stone
fill 193 47 -179 199 47 -179 minecraft:stone
fill 170 47 -178 175 47 -178 minecraft:stone
fill 193 47 -178 199 47 -178 minecraft:stone
fill 171 47 -177 176 47 -177 minecraft:stone
fill 194 47 -177 199 47 -177 minecraft:stone
fill 171 47 -176 176 47 -176 minecraft:stone
fill 194 47 -176 199 47 -176 minecraft:stone
fill 172 47 -175 177 47 -175 minecraft:stone
fill 192 47 -175 199 47 -175 minecraft:stone
fill 191 47 -174 199 47 -174 minecraft:stone
fill 190 47 -173 199 47 -173 minecraft:stone
fill 188 47 -172 199 47 -172 minecraft:stone
fill 188 47 -171 197 47 -171 minecraft:stone
fill 188 47 -170 196 47 -170 minecraft:stone
fill 187 47 -169 195 47 -169 minecraft:stone
fill 186 47 -168 193 47 -168 minecraft:stone
fill 186 47 -167 192 47 -167 minecraft:stone
fill 187 47 -166 191 47 -166 minecraft:stone
setblock 160 47 -154 minecraft:stone
fill 158 47 -153 161 47 -153 minecraft:stone
fill 157 47 -152 161 47 -152 minecraft:stone
fill 156 47 -151 160 47 -151 minecraft:stone
fill 156 47 -150 160 47 -150 minecraft:stone
fill 156 47 -149 160 47 -149 minecraft:stone
fill 150 47 -148 151 47 -148 minecraft:stone
fill 156 47 -148 160 47 -148 minecraft:stone
fill 150 47 -147 151 47 -147 minecraft:stone
fill 156 47 -147 160 47 -147 minecraft:stone
fill 156 47 -146 160 47 -146 minecraft:stone
fill 156 47 -145 160 47 -145 minecraft:stone
fill 156 47 -144 160 47 -144 minecraft:stone
fill 157 47 -143 160 47 -143 minecraft:stone
fill 157 47 -142 160 47 -142 minecraft:stone
fill 157 47 -141 160 47 -141 minecraft:stone
fill 157 47 -140 160 47 -140 minecraft:stone
fill 158 47 -139 159 47 -139 minecraft:stone
setblock 136 47 -136 minecraft:stone
setblock 136 47 -135 minecraft:stone
fill 140 47 -132 141 47 -132 minecraft:stone
fill 139 47 -131 142 47 -131 minecraft:stone
fill 139 47 -130 142 47 -130 minecraft:stone
fill 140 47 -129 141 47 -129 minecraft:stone
setblock 198 47 -129 minecraft:stone
fill 150 47 -128 156 47 -128 minecraft:stone
setblock 158 47 -128 minecraft:stone
fill 193 47 -128 195 47 -128 minecraft:stone
fill 147 47 -127 160 47 -127 minecraft:stone
fill 191 47 -127 195 47 -127 minecraft:stone
fill 136 48 -190 143 48 -190 minecraft:stone
setblock 168 48 -190 minecraft:stone
fill 176 48 -190 178 48 -190 minecraft:stone
fill 195 48 -190 199 48 -190 minecraft:stone
fill 136 48 -189 142 48 -189 minecraft:stone
fill 167 48 -189 168 48 -189 minecraft:stone
setblock 176 48 -189 minecraft:stone
fill 194 48 -189 199 48 -189 minecraft:stone
fill 136 48 -188 140 48 -188 minecraft:stone
setblock 142 48 -188 minecraft:stone
fill 167 48 -188 168 48 -188 minecraft:stone
fill 194 48 -188 199 48 -188 minecraft:stone
fill 139 48 -187 140 48 -187 minecraft:stone
fill 167 48 -187 168 48 -187 minecraft:stone
fill 193 48 -187 199 48 -187 minecraft:stone
setblock 139 48 -186 minecraft:stone
fill 167 48 -186 169 48 -186 minecraft:stone
fill 193 48 -186 199 48 -186 minecraft:stone
fill 167 48 -185 169 48 -185 minecraft:stone
fill 192 48 -185 199 48 -185 minecraft:stone
fill 167 48 -184 170 48 -184 minecraft:stone
fill 192 48 -184 198 48 -184 minecraft:stone
fill 167 48 -183 170 48 -183 minecraft:stone
fill 192 48 -183 199 48 -183 minecraft:stone
fill 168 48 -182 171 48 -182 minecraft:stone
fill 193 48 -182 199 48 -182 minecraft:stone
fill 168 48 -181 174 48 -181 minecraft:stone
fill 194 48 -181 199 48 -181 minecraft:stone
fill 169 48 -180 174 48 -180 minecraft:stone
fill 194 48 -180 199 48 -180 minecraft:stone
fill 170 48 -179 174 48 -179 minecraft:stone
fill 194 48 -179 199 48 -179 minecraft:stone
fill 170 48 -178 175 48 -178 minecraft:stone
fill 194 48 -178 199 48 -178 minecraft:stone
fill 171 48 -177 176 48 -177 minecraft:stone
fill 194 48 -177 199 48 -177 minecraft:stone
fill 172 48 -176 176 48 -176 minecraft:stone
fill 194 48 -176 199 48 -176 minecraft:stone
fill 193 48 -175 199 48 -175 minecraft:stone
fill 192 48 -174 199 48 -174 minecraft:stone
fill 190 48 -173 199 48 -173 minecraft:stone
fill 189 48 -172 198 48 -172 minecraft:stone
fill 188 48 -171 197 48 -171 minecraft:stone
fill 188 48 -170 196 48 -170 minecraft:stone
fill 187 48 -169 195 48 -169 minecraft:stone
fill 186 48 -168 193 48 -168 minecraft:stone
fill 187 48 -167 191 48 -167 minecraft:stone
fill 188 48 -166 189 48 -166 minecraft:stone
fill 157 48 -151 159 48 -151 minecraft:stone
fill 157 48 -150 159 48 -150 minecraft:stone
fill 156 48 -149 159 48 -149 minecraft:stone
fill 156 48 -148 159 48 -148 minecraft:stone
fill 156 48 -147 159 48 -147 minecraft:stone
fill 156 48 -146 160 48 -146 minecraft:stone
fill 156 48 -145 160 48 -145 minecraft:stone
fill 157 48 -144 160 48 -144 minecraft:stone
fill 157 48 -143 160 48 -143 minecraft:stone
fill 156 48 -142 160 48 -142 minecraft:stone
fill 156 48 -141 160 48 -141 minecraft:stone
fill 156 48 -140 160 48 -140 minecraft:stone
fill 156 48 -139 160 48 -139 minecraft:stone
fill 155 48 -138 159 48 -138 minecraft:stone
fill 155 48 -137 159 48 -137 minecraft:stone
fill 156 48 -136 158 48 -136 minecraft:stone
fill 197 48 -130 199 48 -130 minecraft:stone
fill 192 48 -129 194 48 -129 minecraft:stone
fill 153 48 -128 156 48 -128 minecraft:stone
fill 190 48 -128 196 48 -128 minecraft:stone
fill 151 48 -127 156 48 -127 minecraft:stone
setblock 158 48 -127 minecraft:stone
setblock 186 48 -127 minecraft:stone
fill 190 48 -127 198 48 -127 minecraft:stone
fill 136 49 -190 141 49 -190 minecraft:stone
fill 166 49 -190 168 49 -190 minecraft:stone
fill 171 49 -190 177 49 -190 minecraft:stone
fill 136 49 -189 137 49 -189 minecraft:stone
fill 140 49 -189 141 49 -189 minecraft:stone
fill 165 49 -189 169 49 -189 minecraft:stone
fill 171 49 -189 175 49 -189 minecraft:stone
setblock 138 49 -188 minecraft:stone
fill 165 49 -188 169 49 -188 minecraft:stone
fill 171 49 -188 174 49 -188 minecraft:stone
setblock 137 49 -187 minecraft:stone
fill 165 49 -187 169 49 -187 minecraft:stone
fill 172 49 -187 174 49 -187 minecraft:stone
fill 166 49 -186 169 49 -186 minecraft:stone
fill 172 49 -186 173 49 -186 minecraft:stone
fill 167 49 -185 170 49 -185 minecraft:stone
fill 172 49 -185 173 49 -185 minecraft:stone
fill 167 49 -184 170 49 -184 minecraft:stone
fill 172 49 -184 173 49 -184 minecraft:stone
fill 168 49 -183 170 49 -183 minecraft:stone
fill 168 49 -182 170 49 -182 minecraft:stone
setblock 173 49 -182 minecraft:stone
fill 170 49 -181 173 49 -181 minecraft:stone
fill 171 49 -180 174 49 -180 minecraft:stone
fill 172 49 -179 174 49 -179 minecraft:stone
setblock 158 49 -147 minecraft:stone
setblock 158 49 -146 minecraft:stone
fill 151 49 -145 153 49 -145 minecraft:stone
fill 158 49 -145 159 49 -145 minecraft:stone
fill 151 49 -144 153 49 -144 minecraft:stone
fill 157 49 -144 160 49 -144 minecraft:stone
fill 150 49 -143 154 49 -143 minecraft:stone
fill 157 49 -143 160 49 -143 minecraft:stone
fill 150 49 -142 153 49 -142 minecraft:stone
fill 157 49 -142 160 49 -142 minecraft:stone
fill 151 49 -141 152 49 -141 minecraft:stone
fill 157 49 -141 160 49 -141 minecraft:stone
fill 156 49 -140 160 49 -140 minecraft:stone
fill 152 49 -139 153 49 -139 minecraft:stone
fill 156 49 -139 160 49 -139 minecraft:stone
fill 151 49 -138 159 49 -138 minecraft:stone
fill 151 49 -137 159 49 -137 minecraft:stone
fill 151 49 -136 158 49 -136 minecraft:stone
fill 152 49 -135 157 49 -135 minecraft:stone
setblock 137 50 -190 minecraft:stone
fill 171 50 -190 174 50 -190 minecraft:stone
setblock 169 50 -189 minecraft:stone
fill 171 50 -189 174 50 -189 minecraft:stone
setblock 169 50 -188 minecraft:stone
fill 171 50 -188 173 50 -188 minecraft:stone
fill 172 50 -187 173 50 -187 minecraft:stone
setblock 172 50 -186 minecraft:stone
setblock 172 50 -185 minecraft:stone
setblock 172 50 -184 minecraft:stone
fill 153 50 -147 162 50 -147 minecraft:stone
fill 152 50 -146 164 50 -146 minecraft:stone
fill 151 50 -145 165 50 -145 minecraft:stone
fill 150 50 -144 164 50 -144 minecraft:stone
fill 150 50 -143 154 50 -143 minecraft:stone
fill 150 50 -142 153 50 -142 minecraft:stone
fill 149 50 -141 153 50 -141 minecraft:stone
fill 158 50 -141 159 50 -141 minecraft:stone
fill 149 50 -140 153 50 -140 minecraft:stone
fill 157 50 -140 159 50 -140 minecraft:stone
fill 150 50 -139 153 50 -139 minecraft:stone
fill 156 50 -139 159 50 -139 minecraft:stone
fill 150 50 -138 159 50 -138 minecraft:stone
fill 150 50 -137 158 50 -137 minecraft:stone
fill 151 50 -136 158 50 -136 minecraft:stone
fill 152 50 -135 157 50 -135 minecraft:stone
setblock 154 50 -134 minecraft:stone
setblock 199 51 -190 minecraft:stone
fill 155 51 -147 163 51 -147 minecraft:stone
fill 152 51 -146 167 51 -146 minecraft:stone
fill 151 51 -145 167 51 -145 minecraft:stone
fill 151 51 -144 167 51 -144 minecraft:stone
fill 150 51 -143 153 51 -143 minecraft:stone
setblock 164 51 -143 minecraft:stone
fill 166 51 -143 167 51 -143 minecraft:stone
fill 150 51 -142 153 51 -142 minecraft:stone
fill 149 51 -141 153 51 -141 minecraft:stone
fill 150 51 -140 153 51 -140 minecraft:stone
fill 150 51 -139 153 51 -139 minecraft:stone
fill 150 51 -138 157 51 -138 minecraft:stone
fill 150 51 -137 157 51 -137 minecraft:stone
fill 151 51 -136 157 51 -136 minecraft:stone
fill 152 51 -135 156 51 -135 minecraft:stone
setblock 199 52 -190 minecraft:stone
setblock 199 52 -189 minecraft:stone
fill 155 52 -146 156 52 -146 minecraft:stone
fill 163 52 -146 167 52 -146 minecraft:stone
fill 155 52 -145 156 52 -145 minecraft:stone
fill 161 52 -145 167 52 -145 minecraft:stone
fill 169 52 -145 171 52 -145 minecraft:stone
fill 163 52 -144 167 52 -144 minecraft:stone
fill 169 52 -144 172 52 -144 minecraft:stone
fill 166 52 -143 167 52 -143 minecraft:stone
fill 169 52 -143 173 52 -143 minecraft:stone
fill 170 52 -142 173 52 -142 minecraft:stone
setblock 151 52 -141 minecraft:stone
fill 171 52 -141 173 52 -141 minecraft:stone
setblock 151 52 -140 minecraft:stone
fill 151 52 -139 152 52 -139 minecraft:stone
fill 151 52 -138 152 52 -138 minecraft:stone
fill 152 52 -137 153 52 -137 minecraft:stone
fill 173 52 -137 174 52 -137 minecraft:stone
fill 173 52 -136 174 52 -136 minecraft:stone
fill 173 52 -135 174 52 -135 minecraft:stone
setblock 199 53 -190 minecraft:stone
setblock 166 53 -145 minecraft:stone
fill 169 53 -145 171 53 -145 minecraft:stone
setblock 166 53 -144 minecraft:stone
fill 169 53 -144 172 53 -144 minecraft:stone
fill 169 53 -143 173 53 -143 minecraft:stone
fill 170 53 -142 174 53 -142 minecraft:stone
fill 171 53 -141 174 53 -141 minecraft:stone
fill 172 53 -140 174 53 -140 minecraft:stone
fill 172 53 -139 175 53 -139 minecraft:stone
fill 172 53 -138 175 53 -138 minecraft:stone
fill 172 53 -137 175 53 -137 minecraft:stone
fill 172 53 -136 175 53 -136 minecraft:stone
fill 173 53 -135 174 53 -135 minecraft:stone
fill 174 53 -129 177 53 -129 minecraft:stone
fill 174 53 -128 177 53 -128 minecraft:stone
fill 173 53 -127 177 53 -127 minecraft:stone
setblock 199 54 -190 minecraft:stone
setblock 199 54 -180 minecraft:stone
setblock 199 54 -179 minecraft:stone
setblock 199 54 -178 minecraft:stone
fill 170 54 -144 171 54 -144 minecraft:stone
fill 170 54 -143 172 54 -143 minecraft:stone
fill 171 54 -142 173 54 -142 minecraft:stone
fill 172 54 -141 174 54 -141 minecraft:stone
fill 172 54 -140 174 54 -140 minecraft:stone
fill 173 54 -139 174 54 -139 minecraft:stone
fill 173 54 -138 174 54 -138 minecraft:stone
fill 173 54 -137 174 54 -137 minecraft:stone
fill 173 54 -136 174 54 -136 minecraft:stone
fill 177 54 -133 180 54 -133 minecraft:stone
fill 176 54 -132 180 54 -132 minecraft:stone
fill 175 54 -131 180 54 -131 minecraft:stone
fill 174 54 -130 180 54 -130 minecraft:stone
fill 174 54 -129 179 54 -129 minecraft:stone
fill 173 54 -128 178 54 -128 minecraft:stone
fill 173 54 -127 178 54 -127 minecraft:stone
setblock 199 55 -180 minecraft:stone
setblock 199 55 -179 minecraft:stone
fill 198 55 -178 199 55 -178 minecraft:stone
fill 198 55 -177 199 55 -177 minecraft:stone
fill 198 55 -176 199 55 -176 minecraft:stone
fill 178 55 -134 181 55 -134 minecraft:stone
fill 177 55 -133 182 55 -133 minecraft:stone
fill 176 55 -132 182 55 -132 minecraft:stone
fill 175 55 -131 182 55 -131 minecraft:stone
fill 174 55 -130 181 55 -130 minecraft:stone
fill 174 55 -129 179 55 -129 minecraft:stone
fill 173 55 -128 178 55 -128 minecraft:stone
fill 173 55 -127 178 55 -127 minecraft:stone
fill 191 56 -190 194 56 -190 minecraft:stone
setblock 185 56 -189 minecraft:stone
fill 191 56 -189 194 56 -189 minecraft:stone
fill 183 56 -188 186 56 -188 minecraft:stone
fill 191 56 -188 193 56 -188 minecraft:stone
fill 184 56 -187 186 56 -187 minecraft:stone
fill 190 56 -187 193 56 -187 minecraft:stone
fill 184 56 -186 187 56 -186 minecraft:stone
fill 189 56 -186 193 56 -186 minecraft:stone
fill 184 56 -185 192 56 -185 minecraft:stone
fill 185 56 -184 191 56 -184 minecraft:stone
fill 187 56 -183 190 56 -183 minecraft:stone
setblock 199 56 -179 minecraft:stone
setblock 199 56 -178 minecraft:stone
fill 198 56 -177 199 56 -177 minecraft:stone
fill 198 56 -176 199 56 -176 minecraft:stone
fill 178 56 -134 181 56 -134 minecraft:stone
fill 177 56 -133 183 56 -133 minecraft:stone
fill 176 56 -132 183 56 -132 minecraft:stone
fill 175 56 -131 183 56 -131 minecraft:stone
fill 174 56 -130 183 56 -130 minecraft:stone
fill 174 56 -129 179 56 -129 minecraft:stone
fill 174 56 -128 178 56 -128 minecraft:stone
fill 173 56 -127 178 56 -127 minecraft:stone
fill 183 57 -190 189 57 -190 minecraft:stone
fill 191 57 -190 194 57 -190 minecraft:stone
fill 183 57 -189 187 57 -189 minecraft:stone
fill 191 57 -189 194 57 -189 minecraft:stone
fill 183 57 -188 186 57 -188 minecraft:stone
fill 191 57 -188 193 57 -188 minecraft:stone
fill 183 57 -187 186 57 -187 minecraft:stone
fill 190 57 -187 193 57 -187 minecraft:stone
fill 184 57 -186 193 57 -186 minecraft:stone
fill 184 57 -185 192 57 -185 minecraft:stone
fill 185 57 -184 191 57 -184 minecraft:stone
fill 186 57 -183 190 57 -183 minecraft:stone
fill 198 57 -177 199 57 -177 minecraft:stone
fill 198 57 -176 199 57 -176 minecraft:stone
fill 178 57 -134 182 57 -134 minecraft:stone
fill 177 57 -133 183 57 -133 minecraft:stone
fill 176 57 -132 185 57 -132 minecraft:stone
fill 176 57 -131 185 57 -131 minecraft:stone
fill 175 57 -130 185 57 -130 minecraft:stone
fill 175 57 -129 179 57 -129 minecraft:stone
fill 182 57 -129 184 57 -129 minecraft:stone
fill 174 57 -128 178 57 -128 minecraft:stone
fill 174 57 -127 177 57 -127 minecraft:stone
fill 183 58 -190 190 58 -190 minecraft:stone
fill 192 58 -190 194 58 -190 minecraft:stone
fill 183 58 -189 188 58 -189 minecraft:stone
fill 191 58 -189 193 58 -189 minecraft:stone
fill 183 58 -188 186 58 -188 minecraft:stone
fill 191 58 -188 193 58 -188 minecraft:stone
fill 184 58 -187 186 58 -187 minecraft:stone
fill 190 58 -187 193 58 -187 minecraft:stone
fill 184 58 -186 187 58 -186 minecraft:stone
fill 189 58 -186 192 58 -186 minecraft:stone
fill 184 58 -185 192 58 -185 minecraft:stone
fill 185 58 -184 190 58 -184 minecraft:stone
fill 187 58 -183 190 58 -183 minecraft:stone
setblock 197 58 -175 minecraft:stone
fill 197 58 -174 198 58 -174 minecraft:stone
setblock 197 58 -173 minecraft:stone
fill 179 58 -134 182 58 -134 minecraft:stone
fill 178 58 -133 184 58 -133 minecraft:stone
fill 177 58 -132 186 58 -132 minecraft:stone
fill 177 58 -131 186 58 -131 minecraft:stone
fill 176 58 -130 185 58 -130 minecraft:stone
fill 176 58 -129 177 58 -129 minecraft:stone
fill 182 58 -129 185 58 -129 minecraft:stone
setblock 187 58 -129 minecraft:stone
fill 184 58 -128 185 58 -128 minecraft:stone
setblock 187 58 -128 minecraft:stone
fill 136 59 -190 149 59 -190 minecraft:stone
fill 183 59 -190 190 59 -190 minecraft:stone
fill 136 59 -189 149 59 -189 minecraft:stone
fill 183 59 -189 188 59 -189 minecraft:stone
setblock 192 59 -189 minecraft:stone
fill 136 59 -188 149 59 -188 minecraft:stone
fill 184 59 -188 185 59 -188 minecraft:stone
setblock 192 59 -188 minecraft:stone
fill 136 59 -187 149 59 -187 minecraft:stone
fill 184 59 -187 186 59 -187 minecraft:stone
fill 191 59 -187 192 59 -187 minecraft:stone
fill 136 59 -186 149 59 -186 minecraft:stone
fill 184 59 -186 186 59 -186 minecraft:stone
setblock 191 59 -186 minecraft:stone
fill 136 59 -185 149 59 -185 minecraft:stone
fill 185 59 -185 190 59 -185 minecraft:stone
fill 136 59 -184 149 59 -184 minecraft:stone
fill 186 59 -184 190 59 -184 minecraft:stone
fill 136 59 -183 149 59 -183 minecraft:stone
fill 136 59 -182 149 59 -182 minecraft:stone
fill 136 59 -181 149 59 -181 minecraft:stone
fill 136 59 -180 149 59 -180 minecraft:stone
fill 136 59 -179 149 59 -179 minecraft:stone
fill 136 59 -178 149 59 -178 minecraft:stone
fill 136 59 -177 149 59 -177 minecraft:stone
fill 136 59 -176 149 59 -176 minecraft:stone
fill 136 59 -175 149 59 -175 minecraft:stone
setblock 197 59 -175 minecraft:stone
fill 136 59 -174 149 59 -174 minecraft:stone
fill 197 59 -174 198 59 -174 minecraft:stone
fill 136 59 -173 149 59 -173 minecraft:stone
setblock 197 59 -173 minecraft:stone
fill 136 59 -172 149 59 -172 minecraft:stone
fill 136 59 -171 149 59 -171 minecraft:stone
fill 136 59 -170 149 59 -170 minecraft:stone
fill 136 59 -169 149 59 -169 minecraft:stone
fill 136 59 -168 149 59 -168 minecraft:stone
fill 136 59 -167 149 59 -167 minecraft:stone
fill 136 59 -166 149 59 -166 minecraft:stone
fill 136 59 -165 149 59 -165 minecraft:stone
fill 136 59 -164 149 59 -164 minecraft:stone
fill 136 59 -163 149 59 -163 minecraft:stone
fill 136 59 -162 149 59 -162 minecraft:stone
fill 136 59 -161 149 59 -161 minecraft:stone
fill 136 59 -160 149 59 -160 minecraft:stone
setblock 136 59 -138 minecraft:stone
setblock 136 59 -137 minecraft:stone
setblock 136 59 -136 minecraft:stone
setblock 136 59 -135 minecraft:stone
setblock 136 59 -134 minecraft:stone
fill 179 59 -133 184 59 -133 minecraft:stone
fill 179 59 -132 186 59 -132 minecraft:stone
setblock 191 59 -132 minecraft:stone
fill 179 59 -131 186 59 -131 minecraft:stone
fill 189 59 -131 192 59 -131 minecraft:stone
fill 181 59 -130 186 59 -130 minecraft:stone
fill 188 59 -130 192 59 -130 minecraft:stone
fill 182 59 -129 186 59 -129 minecraft:stone
fill 188 59 -129 192 59 -129 minecraft:stone
fill 184 59 -128 185 59 -128 minecraft:stone
fill 188 59 -128 190 59 -128 minecraft:stone
setblock 187 59 -127 minecraft:stone
fill 136 60 -190 149 60 -190 minecraft:stone
fill 184 60 -190 190 60 -190 minecraft:stone
fill 136 60 -189 149 60 -189 minecraft:stone
fill 185 60 -189 187 60 -189 minecraft:stone
fill 136 60 -188 149 60 -188 minecraft:stone
fill 136 60 -187 149 60 -187 minecraft:stone
fill 136 60 -186 149 60 -186 minecraft:stone
fill 136 60 -185 149 60 -185 minecraft:stone
fill 136 60 -184 149 60 -184 minecraft:stone
fill 136 60 -183 149 60 -183 minecraft:stone
fill 136 60 -182 149 60 -182 minecraft:stone
fill 136 60 -181 149 60 -181 minecraft:stone
fill 136 60 -180 149 60 -180 minecraft:stone
fill 136 60 -179 149 60 -179 minecraft:stone
fill 136 60 -178 149 60 -178 minecraft:stone
fill 136 60 -177 149 60 -177 minecraft:stone
fill 136 60 -176 149 60 -176 minecraft:stone
fill 136 60 -175 149 60 -175 minecraft:stone
fill 136 60 -174 149 60 -174 minecraft:stone
setblock 197 60 -174 minecraft:stone
fill 136 60 -173 149 60 -173 minecraft:stone
fill 136 60 -172 149 60 -172 minecraft:stone
fill 136 60 -171 149 60 -171 minecraft:stone
fill 136 60 -170 149 60 -170 minecraft:stone
fill 136 60 -169 149 60 -169 minecraft:stone
fill 136 60 -168 149 60 -168 minecraft:stone
fill 136 60 -167 149 60 -167 minecraft:stone
fill 136 60 -166 149 60 -166 minecraft:stone
fill 136 60 -165 149 60 -165 minecraft:stone
fill 136 60 -164 149 60 -164 minecraft:stone
fill 136 60 -163 149 60 -163 minecraft:stone
fill 136 60 -162 149 60 -162 minecraft:stone
fill 136 60 -161 149 60 -161 minecraft:stone
fill 136 60 -160 149 60 -160 minecraft:stone
setblock 155 60 -154 minecraft:stone
fill 154 60 -153 155 60 -153 minecraft:stone
setblock 155 60 -152 minecraft:stone
fill 136 60 -139 140 60 -139 minecraft:stone
fill 136 60 -138 140 60 -138 minecraft:stone
fill 136 60 -137 140 60 -137 minecraft:stone
fill 192 60 -137 193 60 -137 minecraft:stone
fill 136 60 -136 139 60 -136 minecraft:stone
fill 191 60 -136 194 60 -136 minecraft:stone
fill 136 60 -135 138 60 -135 minecraft:stone
fill 191 60 -135 194 60 -135 minecraft:stone
setblock 136 60 -134 minecraft:stone
setblock 194 60 -134 minecraft:stone
setblock 182 60 -133 minecraft:stone
fill 181 60 -132 186 60 -132 minecraft:stone
setblock 190 60 -132 minecraft:stone
fill 181 60 -131 187 60 -131 minecraft:stone
fill 189 60 -131 190 60 -131 minecraft:stone
fill 182 60 -130 186 60 -130 minecraft:stone
fill 189 60 -130 191 60 -130 minecraft:stone
fill 182 60 -129 186 60 -129 minecraft:stone
fill 189 60 -129 192 60 -129 minecraft:stone
fill 184 60 -128 186 60 -128 minecraft:stone
fill 188 60 -128 191 60 -128 minecraft:stone
setblock 189 60 -127 minecraft:stone
fill 136 61 -190 149 61 -190 minecraft:stone
fill 165 61 -190 172 61 -190 minecraft:stone
fill 185 61 -190 189 61 -190 minecraft:stone
fill 136 61 -189 149 61 -189 minecraft:stone
fill 166 61 -189 172 61 -189 minecraft:stone
fill 136 61 -188 149 61 -188 minecraft:stone
fill 168 61 -188 172 61 -188 minecraft:stone
fill 136 61 -187 149 61 -187 minecraft:stone
fill 168 61 -187 169 61 -187 minecraft:stone
fill 136 61 -186 149 61 -186 minecraft:stone
fill 136 61 -185 149 61 -185 minecraft:stone
fill 136 61 -184 149 61 -184 minecraft:stone
fill 136 61 -183 149 61 -183 minecraft:stone
fill 136 61 -182 149 61 -182 minecraft:stone
fill 136 61 -181 149 61 -181 minecraft:stone
fill 136 61 -180 149 61 -180 minecraft:stone
fill 136 61 -179 149 61 -179 minecraft:stone
fill 136 61 -178 149 61 -178 minecraft:stone
fill 136 61 -177 149 61 -177 minecraft:stone
fill 136 61 -176 149 61 -176 minecraft:stone
fill 136 61 -175 149 61 -175 minecraft:stone
fill 136 61 -174 149 61 -174 minecraft:stone
fill 136 61 -173 149 61 -173 minecraft:stone
fill 136 61 -172 149 61 -172 minecraft:stone
fill 136 61 -171 149 61 -171 minecraft:stone
fill 136 61 -170 149 61 -170 minecraft:stone
fill 136 61 -169 149 61 -169 minecraft:stone
fill 136 61 -168 149 61 -168 minecraft:stone
fill 136 61 -167 149 61 -167 minecraft:stone
fill 136 61 -166 149 61 -166 minecraft:stone
fill 136 61 -165 149 61 -165 minecraft:stone
fill 136 61 -164 149 61 -164 minecraft:stone
fill 136 61 -163 149 61 -163 minecraft:stone
fill 136 61 -162 149 61 -162 minecraft:stone
fill 136 61 -161 149 61 -161 minecraft:stone
fill 136 61 -160 149 61 -160 minecraft:stone
fill 154 61 -155 155 61 -155 minecraft:stone
fill 154 61 -154 156 61 -154 minecraft:stone
fill 154 61 -153 156 61 -153 minecraft:stone
fill 150 61 -152 156 61 -152 minecraft:stone
fill 150 61 -151 155 61 -151 minecraft:stone
fill 150 61 -150 155 61 -150 minecraft:stone
fill 152 61 -149 155 61 -149 minecraft:stone
fill 151 61 -148 155 61 -148 minecraft:stone
fill 151 61 -147 155 61 -147 minecraft:stone
setblock 193 61 -141 minecraft:stone
fill 192 61 -140 194 61 -140 minecraft:stone
fill 136 61 -139 138 61 -139 minecraft:stone
setblock 140 61 -139 minecraft:stone
fill 192 61 -139 194 61 -139 minecraft:stone
fill 136 61 -138 140 61 -138 minecraft:stone
fill 191 61 -138 194 61 -138 minecraft:stone
fill 136 61 -137 140 61 -137 minecraft:stone
fill 191 61 -137 194 61 -137 minecraft:stone
fill 136 61 -136 140 61 -136 minecraft:stone
fill 191 61 -136 194 61 -136 minecraft:stone
fill 136 61 -135 139 61 -135 minecraft:stone
fill 191 61 -135 194 61 -135 minecraft:stone
setblock 136 61 -134 minecraft:stone
fill 191 61 -134 194 61 -134 minecraft:stone
fill 193 61 -133 194 61 -133 minecraft:stone
fill 184 61 -132 185 61 -132 minecraft:stone
fill 193 61 -132 194 61 -132 minecraft:stone
fill 183 61 -131 187 61 -131 minecraft:stone
fill 183 61 -130 187 61 -130 minecraft:stone
setblock 189 61 -130 minecraft:stone
fill 184 61 -129 187 61 -129 minecraft:stone
fill 189 61 -129 190 61 -129 minecraft:stone
fill 185 61 -128 186 61 -128 minecraft:stone
fill 189 61 -128 190 61 -128 minecraft:stone
fill 136 62 -190 187 62 -190 minecraft:dirt
fill 136 62 -189 174 62 -189 minecraft:dirt
fill 176 62 -189 183 62 -189 minecraft:dirt
fill 185 62 -189 187 62 -189 minecraft:dirt
fill 136 62 -188 150 62 -188 minecraft:dirt
fill 152 62 -188 166 62 -188 minecraft:dirt
fill 168 62 -188 186 62 -188 minecraft:dirt
fill 136 62 -187 153 62 -187 minecraft:dirt
fill 155 62 -187 186 62 -187 minecraft:dirt
fill 136 62 -186 163 62 -186 minecraft:dirt
fill 165 62 -186 186 62 -186 minecraft:dirt
fill 136 62 -185 160 62 -185 minecraft:dirt
fill 162 62 -185 181 62 -185 minecraft:dirt
fill 183 62 -185 185 62 -185 minecraft:dirt
fill 136 62 -184 185 62 -184 minecraft:dirt
fill 136 62 -183 162 62 -183 minecraft:dirt
fill 164 62 -183 180 62 -183 minecraft:dirt
fill 182 62 -183 184 62 -183 minecraft:dirt
fill 136 62 -182 154 62 -182 minecraft:dirt
fill 156 62 -182 169 62 -182 minecraft:dirt
fill 171 62 -182 183 62 -182 minecraft:dirt
fill 136 62 -181 160 62 -181 minecraft:dirt
fill 162 62 -181 183 62 -181 minecraft:dirt
fill 136 62 -180 174 62 -180 minecraft:dirt
fill 176 62 -180 182 62 -180 minecraft:dirt
fill 136 62 -179 182 62 -179 minecraft:dirt
fill 136 62 -178 182 62 -178 minecraft:dirt
fill 136 62 -177 158 62 -177 minecraft:dirt
fill 160 62 -177 182 62 -177 minecraft:dirt
fill 136 62 -176 155 62 -176 minecraft:dirt
fill 157 62 -176 170 62 -176 minecraft:dirt
fill 172 62 -176 181 62 -176 minecraft:dirt
fill 136 62 -175 182 62 -175 minecraft:dirt
fill 136 62 -174 183 62 -174 minecraft:dirt
fill 136 62 -173 160 62 -173 minecraft:dirt
fill 162 62 -173 181 62 -173 minecraft:dirt
fill 183 62 -173 184 62 -173 minecraft:dirt
fill 136 62 -172 162 62 -172 minecraft:dirt
fill 164 62 -172 184 62 -172 minecraft:dirt
fill 136 62 -171 167 62 -171 minecraft:dirt
fill 169 62 -171 171 62 -171 minecraft:dirt
fill 173 62 -171 185 62 -171 minecraft:dirt
fill 136 62 -170 185 62 -170 minecraft:dirt
fill 136 62 -169 185 62 -169 minecraft:dirt
fill 136 62 -168 150 62 -168 minecraft:dirt
fill 152 62 -168 177 62 -168 minecraft:dirt
fill 179 62 -168 184 62 -168 minecraft:dirt
fill 136 62 -167 160 62 -167 minecraft:dirt
fill 162 62 -167 186 62 -167 minecraft:dirt
fill 136 62 -166 176 62 -166 minecraft:dirt
fill 178 62 -166 186 62 -166 minecraft:dirt
fill 136 62 -165 185 62 -165 minecraft:dirt
fill 136 62 -164 163 62 -164 minecraft:dirt
fill 165 62 -164 172 62 -164 minecraft:dirt
fill 175 62 -164 186 62 -164 minecraft:dirt
fill 136 62 -163 156 62 -163 minecraft:dirt
fill 158 62 -163 170 62 -163 minecraft:dirt
setblock 172 62 -163 minecraft:dirt
setblock 174 62 -163 minecraft:dirt
fill 176 62 -163 185 62 -163 minecraft:dirt
fill 136 62 -162 159 62 -162 minecraft:dirt
fill 161 62 -162 172 62 -162 minecraft:dirt
fill 174 62 -162 177 62 -162 minecraft:dirt
fill 179 62 -162 185 62 -162 minecraft:dirt
fill 136 62 -161 149 62 -161 minecraft:dirt
fill 151 62 -161 173 62 -161 minecraft:dirt
fill 175 62 -161 179 62 -161 minecraft:dirt
fill 181 62 -161 185 62 -161 minecraft:dirt
fill 136 62 -160 152 62 -160 minecraft:dirt
fill 154 62 -160 161 62 -160 minecraft:dirt
fill 163 62 -160 174 62 -160 minecraft:dirt
fill 176 62 -160 184 62 -160 minecraft:dirt
fill 153 62 -159 158 62 -159 minecraft:dirt
fill 160 62 -159 171 62 -159 minecraft:dirt
fill 173 62 -159 177 62 -159 minecraft:dirt
fill 179 62 -159 184 62 -159 minecraft:dirt
fill 165 62 -158 175 62 -158 minecraft:dirt
fill 177 62 -158 183 62 -158 minecraft:dirt
fill 165 62 -157 172 62 -157 minecraft:dirt
fill 174 62 -157 176 62 -157 minecraft:dirt
fill 178 62 -157 182 62 -157 minecraft:dirt
fill 154 62 -156 155 62 -156 minecraft:dirt
fill 165 62 -156 182 62 -156 minecraft:dirt
fill 154 62 -155 156 62 -155 minecraft:dirt
fill 166 62 -155 171 62 -155 minecraft:dirt
setblock 173 62 -155 minecraft:dirt
fill 175 62 -155 179 62 -155 minecraft:dirt
fill 181 62 -155 182 62 -155 minecraft:dirt
fill 149 62 -154 156 62 -154 minecraft:dirt
fill 167 62 -154 181 62 -154 minecraft:dirt
fill 147 62 -153 156 62 -153 minecraft:dirt
fill 168 62 -153 180 62 -153 minecraft:dirt
fill 147 62 -152 156 62 -152 minecraft:dirt
fill 168 62 -152 178 62 -152 minecraft:dirt
setblock 180 62 -152 minecraft:dirt
fill 148 62 -151 156 62 -151 minecraft:dirt
fill 171 62 -151 178 62 -151 minecraft:dirt
fill 148 62 -150 156 62 -150 minecraft:dirt
fill 175 62 -150 176 62 -150 minecraft:dirt
fill 148 62 -149 156 62 -149 minecraft:dirt
fill 149 62 -148 156 62 -148 minecraft:dirt
fill 150 62 -147 155 62 -147 minecraft:dirt
fill 151 62 -146 155 62 -146 minecraft:dirt
fill 136 62 -142 140 62 -142 minecraft:dirt
fill 193 62 -142 195 62 -142 minecraft:dirt
fill 136 62 -141 141 62 -141 minecraft:dirt
fill 192 62 -141 196 62 -141 minecraft:dirt
fill 136 62 -140 139 62 -140 minecraft:dirt
setblock 141 62 -140 minecraft:dirt
fill 192 62 -140 195 62 -140 minecraft:dirt
fill 136 62 -139 140 62 -139 minecraft:dirt
fill 191 62 -139 195 62 -139 minecraft:dirt
fill 136 62 -138 140 62 -138 minecraft:dirt
fill 191 62 -138 194 62 -138 minecraft:dirt
fill 136 62 -137 140 62 -137 minecraft:dirt
fill 191 62 -137 194 62 -137 minecraft:dirt
fill 136 62 -136 140 62 -136 minecraft:dirt
fill 191 62 -136 194 62 -136 minecraft:dirt
fill 136 62 -135 140 62 -135 minecraft:dirt
fill 191 62 -135 194 62 -135 minecraft:dirt
setblock 136 62 -134 minecraft:dirt
fill 191 62 -134 194 62 -134 minecraft:dirt
fill 191 62 -133 194 62 -133 minecraft:dirt
fill 191 62 -132 194 62 -132 minecraft:dirt
fill 192 62 -131 193 62 -131 minecraft:dirt
fill 185 62 -130 187 62 -130 minecraft:dirt
setblock 192 62 -130 minecraft:dirt
fill 185 62 -129 187 62 -129 minecraft:dirt
setblock 187 62 -128 minecraft:dirt
fill 136 63 -190 190 63 -190 minecraft:dirt
fill 192 63 -190 193 63 -190 minecraft:dirt
fill 136 63 -189 174 63 -189 minecraft:dirt
fill 176 63 -189 183 63 -189 minecraft:dirt
fill 185 63 -189 193 63 -189 minecraft:dirt
fill 136 63 -188 150 63 -188 minecraft:dirt
fill 152 63 -188 166 63 -188 minecraft:dirt
fill 168 63 -188 193 63 -188 minecraft:dirt
fill 136 63 -187 153 63 -187 minecraft:dirt
fill 155 63 -187 193 63 -187 minecraft:dirt
fill 136 63 -186 163 63 -186 minecraft:dirt
fill 165 63 -186 194 63 -186 minecraft:dirt
fill 136 63 -185 160 63 -185 minecraft:dirt
fill 162 63 -185 181 63 -185 minecraft:dirt
fill 183 63 -185 190 63 -185 minecraft:dirt
fill 192 63 -185 194 63 -185 minecraft:dirt
fill 136 63 -184 196 63 -184 minecraft:dirt
fill 136 63 -183 162 63 -183 minecraft:dirt
fill 164 63 -183 180 63 -183 minecraft:dirt
fill 182 63 -183 195 63 -183 minecraft:dirt
fill 136 63 -182 154 63 -182 minecraft:dirt
fill 156 63 -182 169 63 -182 minecraft:dirt
fill 171 63 -182 185 63 -182 minecraft:dirt
fill 187 63 -182 196 63 -182 minecraft:dirt
fill 136 63 -181 160 63 -181 minecraft:dirt
fill 162 63 -181 190 63 -181 minecraft:dirt
fill 192 63 -181 196 63 -181 minecraft:dirt
fill 136 63 -180 174 63 -180 minecraft:dirt
fill 176 63 -180 196 63 -180 minecraft:dirt
fill 136 63 -179 196 63 -179 minecraft:dirt
fill 136 63 -178 195 63 -178 minecraft:dirt
fill 136 63 -177 158 63 -177 minecraft:dirt
fill 160 63 -177 195 63 -177 minecraft:dirt
fill 136 63 -176 155 63 -176 minecraft:dirt
fill 157 63 -176 170 63 -176 minecraft:dirt
fill 172 63 -176 185 63 -176 minecraft:dirt
fill 187 63 -176 195 63 -176 minecraft:dirt
fill 136 63 -175 194 63 -175 minecraft:dirt
fill 136 63 -174 188 63 -174 minecraft:dirt
fill 190 63 -174 194 63 -174 minecraft:dirt
fill 136 63 -173 160 63 -173 minecraft:dirt
fill 162 63 -173 181 63 -173 minecraft:dirt
fill 183 63 -173 194 63 -173 minecraft:dirt
fill 136 63 -172 162 63 -172 minecraft:dirt
fill 164 63 -172 191 63 -172 minecraft:dirt
setblock 193 63 -172 minecraft:dirt
fill 136 63 -171 167 63 -171 minecraft:dirt
fill 169 63 -171 171 63 -171 minecraft:dirt
fill 173 63 -171 193 63 -171 minecraft:dirt
fill 136 63 -170 193 63 -170 minecraft:dirt
fill 136 63 -169 145 63 -169 minecraft:dirt
fill 147 63 -169 192 63 -169 minecraft:dirt
fill 136 63 -168 150 63 -168 minecraft:dirt
fill 152 63 -168 177 63 -168 minecraft:dirt
fill 179 63 -168 184 63 -168 minecraft:dirt
fill 186 63 -168 192 63 -168 minecraft:dirt
fill 136 63 -167 160 63 -167 minecraft:dirt
fill 162 63 -167 187 63 -167 minecraft:dirt
fill 189 63 -167 192 63 -167 minecraft:dirt
fill 136 63 -166 176 63 -166 minecraft:dirt
fill 178 63 -166 191 63 -166 minecraft:dirt
fill 136 63 -165 185 63 -165 minecraft:dirt
fill 187 63 -165 191 63 -165 minecraft:dirt
fill 136 63 -164 163 63 -164 minecraft:dirt
fill 165 63 -164 191 63 -164 minecraft:dirt
fill 136 63 -163 156 63 -163 minecraft:dirt
fill 158 63 -163 170 63 -163 minecraft:dirt
setblock 172 63 -163 minecraft:dirt
fill 174 63 -163 190 63 -163 minecraft:dirt
fill 136 63 -162 159 63 -162 minecraft:dirt
fill 161 63 -162 190 63 -162 minecraft:dirt
fill 136 63 -161 149 63 -161 minecraft:dirt
fill 151 63 -161 179 63 -161 minecraft:dirt
fill 181 63 -161 185 63 -161 minecraft:dirt
fill 187 63 -161 190 63 -161 minecraft:dirt
fill 136 63 -160 152 63 -160 minecraft:dirt
fill 154 63 -160 161 63 -160 minecraft:dirt
fill 163 63 -160 189 63 -160 minecraft:dirt
fill 136 63 -159 158 63 -159 minecraft:dirt
fill 160 63 -159 171 63 -159 minecraft:dirt
fill 173 63 -159 177 63 -159 minecraft:dirt
fill 179 63 -159 189 63 -159 minecraft:dirt
fill 136 63 -158 138 63 -158 minecraft:dirt
fill 140 63 -158 147 63 -158 minecraft:dirt
fill 149 63 -158 175 63 -158 minecraft:dirt
fill 177 63 -158 188 63 -158 minecraft:dirt
fill 136 63 -157 172 63 -157 minecraft:dirt
fill 174 63 -157 182 63 -157 minecraft:dirt
fill 184 63 -157 188 63 -157 minecraft:dirt
fill 136 63 -156 187 63 -156 minecraft:dirt
fill 136 63 -155 141 63 -155 minecraft:dirt
fill 143 63 -155 171 63 -155 minecraft:dirt
fill 173 63 -155 179 63 -155 minecraft:dirt
fill 181 63 -155 186 63 -155 minecraft:dirt
fill 136 63 -154 186 63 -154 minecraft:dirt
fill 136 63 -153 145 63 -153 minecraft:dirt
fill 147 63 -153 185 63 -153 minecraft:dirt
fill 136 63 -152 178 63 -152 minecraft:dirt
fill 180 63 -152 184 63 -152 minecraft:dirt
fill 136 63 -151 184 63 -151 minecraft:dirt
fill 136 63 -150 183 63 -150 minecraft:dirt
fill 136 63 -149 182 63 -149 minecraft:dirt
fill 136 63 -148 147 63 -148 minecraft:dirt
fill 149 63 -148 182 63 -148 minecraft:dirt
fill 136 63 -147 181 63 -147 minecraft:dirt
fill 136 63 -146 177 63 -146 minecraft:dirt
fill 179 63 -146 180 63 -146 minecraft:dirt
fill 136 63 -145 178 63 -145 minecraft:dirt
setblock 197 63 -145 minecraft:dirt
fill 136 63 -144 158 63 -144 minecraft:dirt
fill 161 63 -144 176 63 -144 minecraft:dirt
fill 195 63 -144 198 63 -144 minecraft:dirt
fill 136 63 -143 137 63 -143 minecraft:dirt
fill 139 63 -143 149 63 -143 minecraft:dirt
fill 151 63 -143 153 63 -143 minecraft:dirt
fill 155 63 -143 157 63 -143 minecraft:dirt
fill 162 63 -143 171 63 -143 minecraft:dirt
fill 194 63 -143 196 63 -143 minecraft:dirt
setblock 198 63 -143 minecraft:dirt
fill 136 63 -142 156 63 -142 minecraft:dirt
fill 162 63 -142 169 63 -142 minecraft:dirt
fill 193 63 -142 197 63 -142 minecraft:dirt
fill 136 63 -141 153 63 -141 minecraft:dirt
fill 163 63 -141 168 63 -141 minecraft:dirt
fill 192 63 -141 196 63 -141 minecraft:dirt
fill 136 63 -140 149 63 -140 minecraft:dirt
fill 151 63 -140 152 63 -140 minecraft:dirt
fill 163 63 -140 166 63 -140 minecraft:dirt
fill 192 63 -140 196 63 -140 minecraft:dirt
fill 136 63 -139 141 63 -139 minecraft:dirt
fill 144 63 -139 152 63 -139 minecraft:dirt
fill 163 63 -139 165 63 -139 minecraft:dirt
fill 192 63 -139 195 63 -139 minecraft:dirt
fill 136 63 -138 141 63 -138 minecraft:dirt
fill 147 63 -138 152 63 -138 minecraft:dirt
fill 163 63 -138 165 63 -138 minecraft:dirt
fill 192 63 -138 194 63 -138 minecraft:dirt
fill 136 63 -137 141 63 -137 minecraft:dirt
fill 148 63 -137 152 63 -137 minecraft:dirt
fill 163 63 -137 164 63 -137 minecraft:dirt
fill 192 63 -137 194 63 -137 minecraft:dirt
fill 136 63 -136 140 63 -136 minecraft:dirt
fill 147 63 -136 153 63 -136 minecraft:dirt
fill 163 63 -136 164 63 -136 minecraft:dirt
fill 192 63 -136 194 63 -136 minecraft:dirt
fill 136 63 -135 139 63 -135 minecraft:dirt
fill 152 63 -135 153 63 -135 minecraft:dirt
fill 163 63 -135 164 63 -135 minecraft:dirt
fill 192 63 -135 194 63 -135 minecraft:dirt
setblock 136 63 -134 minecraft:dirt
fill 152 63 -134 154 63 -134 minecraft:dirt
fill 163 63 -134 164 63 -134 minecraft:dirt
fill 192 63 -134 194 63 -134 minecraft:dirt
fill 152 63 -133 154 63 -133 minecraft:dirt
setblock 164 63 -133 minecraft:dirt
fill 191 63 -133 193 63 -133 minecraft:dirt
fill 152 63 -132 155 63 -132 minecraft:dirt
setblock 164 63 -132 minecraft:dirt
fill 191 63 -132 193 63 -132 minecraft:dirt
setblock 156 63 -130 minecraft:dirt
setblock 191 63 -130 minecraft:dirt
setblock 156 63 -129 minecraft:dirt
setblock 156 63 -128 minecraft:dirt
setblock 156 63 -127 minecraft:dirt
fill 136 64 -190 190 64 -190 minecraft:dirt
fill 192 64 -190 195 64 -190 minecraft:dirt
fill 136 64 -189 174 64 -189 minecraft:dirt
fill 176 64 -189 183 64 -189 minecraft:dirt
fill 185 64 -189 196 64 -189 minecraft:dirt
fill 136 64 -188 150 64 -188 minecraft:dirt
fill 152 64 -188 166 64 -188 minecraft:dirt
fill 168 64 -188 196 64 -188 minecraft:dirt
fill 136 64 -187 153 64 -187 minecraft:dirt
fill 155 64 -187 197 64 -187 minecraft:dirt
fill 136 64 -186 163 64 -186 minecraft:dirt
fill 165 64 -186 197 64 -186 minecraft:dirt
fill 136 64 -185 160 64 -185 minecraft:dirt
fill 162 64 -185 181 64 -185 minecraft:dirt
fill 183 64 -185 190 64 -185 minecraft:dirt
fill 192 64 -185 196 64 -185 minecraft:dirt
setblock 198 64 -185 minecraft:dirt
fill 136 64 -184 198 64 -184 minecraft:dirt
fill 136 64 -183 180 64 -183 minecraft:dirt
fill 182 64 -183 195 64 -183 minecraft:dirt
fill 197 64 -183 199 64 -183 minecraft:dirt
fill 136 64 -182 154 64 -182 minecraft:dirt
fill 156 64 -182 169 64 -182 minecraft:dirt
fill 171 64 -182 185 64 -182 minecraft:dirt
fill 187 64 -182 199 64 -182 minecraft:dirt
fill 136 64 -181 160 64 -181 minecraft:dirt
fill 162 64 -181 190 64 -181 minecraft:dirt
fill 192 64 -181 199 64 -181 minecraft:dirt
fill 136 64 -180 174 64 -180 minecraft:dirt
fill 176 64 -180 199 64 -180 minecraft:dirt
fill 136 64 -179 199 64 -179 minecraft:dirt
fill 136 64 -178 195 64 -178 minecraft:dirt
fill 197 64 -178 199 64 -178 minecraft:dirt
fill 136 64 -177 158 64 -177 minecraft:dirt
fill 160 64 -177 199 64 -177 minecraft:dirt
fill 136 64 -176 155 64 -176 minecraft:dirt
fill 157 64 -176 170 64 -176 minecraft:dirt
fill 172 64 -176 185 64 -176 minecraft:dirt
fill 187 64 -176 195 64 -176 minecraft:dirt
fill 197 64 -176 199 64 -176 minecraft:dirt
fill 136 64 -175 199 64 -175 minecraft:dirt
fill 136 64 -174 188 64 -174 minecraft:dirt
fill 190 64 -174 199 64 -174 minecraft:dirt
fill 136 64 -173 160 64 -173 minecraft:dirt
fill 162 64 -173 181 64 -173 minecraft:dirt
fill 183 64 -173 199 64 -173 minecraft:dirt
fill 136 64 -172 162 64 -172 minecraft:dirt
fill 164 64 -172 191 64 -172 minecraft:dirt
fill 193 64 -172 199 64 -172 minecraft:dirt
fill 136 64 -171 167 64 -171 minecraft:dirt
fill 169 64 -171 171 64 -171 minecraft:dirt
fill 173 64 -171 199 64 -171 minecraft:dirt
fill 136 64 -170 199 64 -170 minecraft:dirt
fill 136 64 -169 199 64 -169 minecraft:dirt
fill 136 64 -168 150 64 -168 minecraft:dirt
fill 152 64 -168 184 64 -168 minecraft:dirt
fill 186 64 -168 199 64 -168 minecraft:dirt
fill 136 64 -167 160 64 -167 minecraft:dirt
fill 162 64 -167 187 64 -167 minecraft:dirt
fill 189 64 -167 199 64 -167 minecraft:dirt
fill 136 64 -166 176 64 -166 minecraft:dirt
fill 178 64 -166 199 64 -166 minecraft:dirt
fill 136 64 -165 185 64 -165 minecraft:dirt
fill 187 64 -165 199 64 -165 minecraft:dirt
fill 136 64 -164 163 64 -164 minecraft:dirt
fill 165 64 -164 199 64 -164 minecraft:dirt
fill 136 64 -163 156 64 -163 minecraft:dirt
fill 158 64 -163 170 64 -163 minecraft:dirt
fill 172 64 -163 195 64 -163 minecraft:dirt
fill 197 64 -163 199 64 -163 minecraft:dirt
fill 136 64 -162 159 64 -162 minecraft:dirt
fill 161 64 -162 198 64 -162 minecraft:dirt
fill 136 64 -161 149 64 -161 minecraft:dirt
fill 151 64 -161 179 64 -161 minecraft:dirt
fill 181 64 -161 185 64 -161 minecraft:dirt
fill 187 64 -161 196 64 -161 minecraft:dirt
fill 136 64 -160 152 64 -160 minecraft:dirt
fill 154 64 -160 161 64 -160 minecraft:dirt
fill 163 64 -160 191 64 -160 minecraft:dirt
fill 193 64 -160 195 64 -160 minecraft:dirt
fill 136 64 -159 158 64 -159 minecraft:dirt
fill 160 64 -159 171 64 -159 minecraft:dirt
fill 173 64 -159 177 64 -159 minecraft:dirt
fill 179 64 -159 194 64 -159 minecraft:dirt
fill 136 64 -158 138 64 -158 minecraft:dirt
fill 140 64 -158 147 64 -158 minecraft:dirt
fill 149 64 -158 175 64 -158 minecraft:dirt
fill 177 64 -158 194 64 -158 minecraft:dirt
fill 136 64 -157 172 64 -157 minecraft:dirt
fill 174 64 -157 182 64 -157 minecraft:dirt
fill 184 64 -157 193 64 -157 minecraft:dirt
fill 136 64 -156 188 64 -156 minecraft:dirt
fill 190 64 -156 193 64 -156 minecraft:dirt
fill 136 64 -155 141 64 -155 minecraft:dirt
fill 143 64 -155 171 64 -155 minecraft:dirt
fill 173 64 -155 179 64 -155 minecraft:dirt
fill 181 64 -155 192 64 -155 minecraft:dirt
fill 136 64 -154 191 64 -154 minecraft:dirt
fill 136 64 -153 145 64 -153 minecraft:dirt
fill 147 64 -153 190 64 -153 minecraft:dirt
fill 136 64 -152 178 64 -152 minecraft:dirt
fill 180 64 -152 189 64 -152 minecraft:dirt
fill 136 64 -151 188 64 -151 minecraft:dirt
fill 136 64 -150 189 64 -150 minecraft:dirt
fill 136 64 -149 188 64 -149 minecraft:dirt
fill 136 64 -148 147 64 -148 minecraft:dirt
fill 149 64 -148 188 64 -148 minecraft:dirt
fill 136 64 -147 182 64 -147 minecraft:dirt
fill 184 64 -147 185 64 -147 minecraft:dirt
fill 187 64 -147 188 64 -147 minecraft:dirt
fill 136 64 -146 177 64 -146 minecraft:dirt
fill 179 64 -146 188 64 -146 minecraft:dirt
fill 136 64 -145 188 64 -145 minecraft:dirt
fill 196 64 -145 199 64 -145 minecraft:dirt
fill 136 64 -144 188 64 -144 minecraft:dirt
fill 195 64 -144 199 64 -144 minecraft:dirt
fill 136 64 -143 137 64 -143 minecraft:dirt
fill 139 64 -143 149 64 -143 minecraft:dirt
fill 151 64 -143 153 64 -143 minecraft:dirt
fill 155 64 -143 188 64 -143 minecraft:dirt
fill 194 64 -143 199 64 -143 minecraft:dirt
fill 136 64 -142 187 64 -142 minecraft:dirt
fill 194 64 -142 197 64 -142 minecraft:dirt
fill 136 64 -141 187 64 -141 minecraft:dirt
fill 193 64 -141 196 64 -141 minecraft:dirt
fill 136 64 -140 149 64 -140 minecraft:dirt
fill 151 64 -140 186 64 -140 minecraft:dirt
fill 193 64 -140 195 64 -140 minecraft:dirt
fill 136 64 -139 185 64 -139 minecraft:dirt
fill 193 64 -139 194 64 -139 minecraft:dirt
fill 136 64 -138 138 64 -138 minecraft:dirt
fill 140 64 -138 141 64 -138 minecraft:dirt
fill 143 64 -138 184 64 -138 minecraft:dirt
setblock 193 64 -138 minecraft:dirt
fill 136 64 -137 146 64 -137 minecraft:dirt
fill 148 64 -137 174 64 -137 minecraft:dirt
fill 136 64 -136 156 64 -136 minecraft:dirt
fill 158 64 -136 172 64 -136 minecraft:dirt
fill 136 64 -135 139 64 -135 minecraft:dirt
fill 144 64 -135 171 64 -135 minecraft:dirt
fill 136 64 -134 138 64 -134 minecraft:dirt
fill 150 64 -134 170 64 -134 minecraft:dirt
fill 136 64 -133 137 64 -133 minecraft:dirt
fill 151 64 -133 170 64 -133 minecraft:dirt
fill 136 64 -132 137 64 -132 minecraft:dirt
fill 151 64 -132 170 64 -132 minecraft:dirt
setblock 136 64 -131 minecraft:dirt
fill 152 64 -131 169 64 -131 minecraft:dirt
fill 153 64 -130 169 64 -130 minecraft:dirt
fill 154 64 -129 168 64 -129 minecraft:dirt
fill 155 64 -128 159 64 -128 minecraft:dirt
fill 161 64 -128 168 64 -128 minecraft:dirt
fill 155 64 -127 168 64 -127 minecraft:dirt
fill 142 65 -190 154 65 -190 minecraft:grass_block
fill 155 65 -190 156 65 -190 minecraft:light_gray_concrete
fill 157 65 -190 166 65 -190 minecraft:smooth_quartz
fill 167 65 -190 168 65 -190 minecraft:light_gray_concrete
fill 169 65 -190 180 65 -190 minecraft:grass_block
fill 141 65 -189 156 65 -189 minecraft:grass_block
fill 157 65 -189 158 65 -189 minecraft:light_gray_concrete
fill 159 65 -189 168 65 -189 minecraft:smooth_quartz
setblock 169 65 -189 minecraft:sea_lantern
setblock 170 65 -189 minecraft:light_gray_concrete
fill 171 65 -189 181 65 -189 minecraft:grass_block
fill 184 65 -189 185 65 -189 minecraft:grass_block
fill 140 65 -188 157 65 -188 minecraft:grass_block
setblock 158 65 -188 minecraft:light_gray_concrete
setblock 159 65 -188 minecraft:sea_lantern
setblock 160 65 -188 minecraft:light_gray_concrete
fill 161 65 -188 170 65 -188 minecraft:smooth_quartz
fill 171 65 -188 172 65 -188 minecraft:light_gray_concrete
fill 173 65 -188 185 65 -188 minecraft:grass_block
fill 140 65 -187 159 65 -187 minecraft:grass_block
fill 160 65 -187 161 65 -187 minecraft:light_gray_concrete
fill 162 65 -187 172 65 -187 minecraft:smooth_quartz
fill 173 65 -187 174 65 -187 minecraft:light_gray_concrete
fill 175 65 -187 186 65 -187 minecraft:grass_block
fill 139 65 -186 161 65 -186 minecraft:grass_block
fill 162 65 -186 163 65 -186 minecraft:light_gray_concrete
fill 164 65 -186 174 65 -186 minecraft:smooth_quartz
setblock 175 65 -186 minecraft:light_gray_concrete
setblock 176 65 -186 minecraft:sea_lantern
fill 177 65 -186 186 65 -186 minecraft:grass_block
fill 138 65 -185 163 65 -185 minecraft:grass_block
fill 164 65 -185 165 65 -185 minecraft:light_gray_concrete
fill 166 65 -185 175 65 -185 minecraft:smooth_quartz
setblock 176 65 -185 minecraft:sea_lantern
fill 177 65 -185 178 65 -185 minecraft:light_gray_concrete
fill 179 65 -185 187 65 -185 minecraft:grass_block
fill 138 65 -184 165 65 -184 minecraft:grass_block
setblock 166 65 -184 minecraft:sea_lantern
setblock 167 65 -184 minecraft:light_gray_concrete
fill 168 65 -184 177 65 -184 minecraft:smooth_quartz
fill 178 65 -184 179 65 -184 minecraft:light_gray_concrete
fill 180 65 -184 187 65 -184 minecraft:grass_block
fill 137 65 -183 167 65 -183 minecraft:grass_block
fill 168 65 -183 169 65 -183 minecraft:light_gray_concrete
fill 170 65 -183 179 65 -183 minecraft:smooth_quartz
fill 180 65 -183 181 65 -183 minecraft:light_gray_concrete
fill 182 65 -183 188 65 -183 minecraft:grass_block
fill 136 65 -182 168 65 -182 minecraft:grass_block
fill 169 65 -182 171 65 -182 minecraft:light_gray_concrete
fill 172 65 -182 181 65 -182 minecraft:smooth_quartz
setblock 182 65 -182 minecraft:light_gray_concrete
setblock 183 65 -182 minecraft:sea_lantern
fill 184 65 -182 188 65 -182 minecraft:grass_block
fill 136 65 -181 170 65 -181 minecraft:grass_block
fill 171 65 -181 172 65 -181 minecraft:light_gray_concrete
fill 173 65 -181 183 65 -181 minecraft:smooth_quartz
fill 184 65 -181 185 65 -181 minecraft:light_gray_concrete
fill 186 65 -181 189 65 -181 minecraft:grass_block
fill 136 65 -180 172 65 -180 minecraft:grass_block
setblock 173 65 -180 minecraft:sea_lantern
setblock 174 65 -180 minecraft:light_gray_concrete
fill 175 65 -180 185 65 -180 minecraft:smooth_quartz
fill 186 65 -180 187 65 -180 minecraft:light_gray_concrete
fill 188 65 -180 189 65 -180 minecraft:grass_block
fill 136 65 -179 174 65 -179 minecraft:grass_block
fill 175 65 -179 176 65 -179 minecraft:light_gray_concrete
fill 177 65 -179 186 65 -179 minecraft:smooth_quartz
fill 187 65 -179 188 65 -179 minecraft:light_gray_concrete
fill 189 65 -179 190 65 -179 minecraft:grass_block
fill 136 65 -178 176 65 -178 minecraft:grass_block
fill 177 65 -178 178 65 -178 minecraft:light_gray_concrete
fill 179 65 -178 188 65 -178 minecraft:smooth_quartz
setblock 189 65 -178 minecraft:light_gray_concrete
setblock 190 65 -178 minecraft:sea_lantern
fill 136 65 -177 178 65 -177 minecraft:grass_block
setblock 179 65 -177 minecraft:light_gray_concrete
setblock 180 65 -177 minecraft:sea_lantern
fill 181 65 -177 190 65 -177 minecraft:smooth_quartz
setblock 191 65 -177 minecraft:sea_lantern
fill 136 65 -176 179 65 -176 minecraft:grass_block
setblock 180 65 -176 minecraft:sea_lantern
setblock 181 65 -176 minecraft:light_gray_concrete
fill 182 65 -176 191 65 -176 minecraft:smooth_quartz
setblock 192 65 -176 minecraft:sea_lantern
fill 136 65 -175 181 65 -175 minecraft:grass_block
setblock 183 65 -175 minecraft:light_gray_concrete
fill 184 65 -175 191 65 -175 minecraft:smooth_quartz
setblock 192 65 -175 minecraft:sea_lantern
fill 136 65 -174 180 65 -174 minecraft:grass_block
fill 184 65 -174 185 65 -174 minecraft:light_gray_concrete
fill 186 65 -174 191 65 -174 minecraft:smooth_quartz
setblock 192 65 -174 minecraft:sea_lantern
setblock 193 65 -174 minecraft:grass_block
fill 136 65 -173 179 65 -173 minecraft:grass_block
setblock 185 65 -173 minecraft:grass_block
setblock 186 65 -173 minecraft:light_gray_concrete
setblock 187 65 -173 minecraft:sea_lantern
fill 188 65 -173 190 65 -173 minecraft:smooth_quartz
setblock 191 65 -173 minecraft:sea_lantern
fill 192 65 -173 194 65 -173 minecraft:grass_block
fill 136 65 -172 180 65 -172 minecraft:grass_block
fill 184 65 -172 187 65 -172 minecraft:grass_block
fill 188 65 -172 190 65 -172 minecraft:sea_lantern
fill 191 65 -172 194 65 -172 minecraft:grass_block
fill 136 65 -171 181 65 -171 minecraft:grass_block
fill 183 65 -171 195 65 -171 minecraft:grass_block
fill 136 65 -170 184 65 -170 minecraft:grass_block
fill 186 65 -170 196 65 -170 minecraft:grass_block
fill 136 65 -169 183 65 -169 minecraft:grass_block
fill 186 65 -169 197 65 -169 minecraft:grass_block
fill 136 65 -168 182 65 -168 minecraft:grass_block
fill 186 65 -168 197 65 -168 minecraft:grass_block
fill 136 65 -167 183 65 -167 minecraft:grass_block
fill 186 65 -167 198 65 -167 minecraft:grass_block
fill 136 65 -166 184 65 -166 minecraft:grass_block
fill 186 65 -166 199 65 -166 minecraft:grass_block
fill 136 65 -165 183 65 -165 minecraft:grass_block
fill 186 65 -165 199 65 -165 minecraft:grass_block
fill 136 65 -164 184 65 -164 minecraft:grass_block
fill 186 65 -164 199 65 -164 minecraft:grass_block
fill 136 65 -163 199 65 -163 minecraft:grass_block
fill 136 65 -162 199 65 -162 minecraft:grass_block
fill 136 65 -161 199 65 -161 minecraft:grass_block
fill 136 65 -160 199 65 -160 minecraft:grass_block
fill 136 65 -159 199 65 -159 minecraft:grass_block
fill 136 65 -158 182 65 -158 minecraft:grass_block
fill 184 65 -158 199 65 -158 minecraft:grass_block
fill 136 65 -157 181 65 -157 minecraft:grass_block
setblock 183 65 -157 minecraft:grass_block
fill 185 65 -157 198 65 -157 minecraft:grass_block
fill 136 65 -156 182 65 -156 minecraft:grass_block
fill 184 65 -156 195 65 -156 minecraft:grass_block
setblock 197 65 -156 minecraft:grass_block
fill 136 65 -155 196 65 -155 minecraft:grass_block
fill 136 65 -154 195 65 -154 minecraft:grass_block
fill 136 65 -153 190 65 -153 minecraft:grass_block
fill 192 65 -153 194 65 -153 minecraft:grass_block
fill 136 65 -152 188 65 -152 minecraft:grass_block
fill 192 65 -152 194 65 -152 minecraft:grass_block
fill 136 65 -151 187 65 -151 minecraft:grass_block
setblock 189 65 -151 minecraft:grass_block
setblock 191 65 -151 minecraft:grass_block
setblock 193 65 -151 minecraft:grass_block
setblock 195 65 -151 minecraft:grass_block
fill 136 65 -150 188 65 -150 minecraft:grass_block
fill 190 65 -150 193 65 -150 minecraft:grass_block
fill 136 65 -149 192 65 -149 minecraft:grass_block
fill 136 65 -148 182 65 -148 minecraft:grass_block
fill 184 65 -148 185 65 -148 minecraft:grass_block
fill 187 65 -148 192 65 -148 minecraft:grass_block
setblock 199 65 -148 minecraft:grass_block
fill 136 65 -147 181 65 -147 minecraft:grass_block
setblock 183 65 -147 minecraft:grass_block
setblock 186 65 -147 minecraft:grass_block
fill 188 65 -147 190 65 -147 minecraft:grass_block
setblock 192 65 -147 minecraft:grass_block
fill 198 65 -147 199 65 -147 minecraft:grass_block
fill 136 65 -146 182 65 -146 minecraft:grass_block
fill 184 65 -146 185 65 -146 minecraft:grass_block
fill 187 65 -146 188 65 -146 minecraft:grass_block
setblock 190 65 -146 minecraft:grass_block
fill 198 65 -146 199 65 -146 minecraft:grass_block
fill 136 65 -145 189 65 -145 minecraft:grass_block
setblock 191 65 -145 minecraft:grass_block
fill 197 65 -145 199 65 -145 minecraft:grass_block
fill 136 65 -144 190 65 -144 minecraft:grass_block
setblock 192 65 -144 minecraft:grass_block
fill 196 65 -144 199 65 -144 minecraft:grass_block
fill 136 65 -143 188 65 -143 minecraft:grass_block
fill 190 65 -143 191 65 -143 minecraft:grass_block
fill 195 65 -143 199 65 -143 minecraft:grass_block
fill 136 65 -142 191 65 -142 minecraft:grass_block
fill 195 65 -142 199 65 -142 minecraft:grass_block
fill 136 65 -141 190 65 -141 minecraft:grass_block
fill 196 65 -141 199 65 -141 minecraft:grass_block
fill 136 65 -140 190 65 -140 minecraft:grass_block
setblock 192 65 -140 minecraft:grass_block
fill 196 65 -140 199 65 -140 minecraft:grass_block
fill 136 65 -139 190 65 -139 minecraft:grass_block
setblock 192 65 -139 minecraft:grass_block
fill 195 65 -139 199 65 -139 minecraft:grass_block
fill 136 65 -138 189 65 -138 minecraft:grass_block
setblock 192 65 -138 minecraft:grass_block
fill 195 65 -138 199 65 -138 minecraft:grass_block
fill 136 65 -137 183 65 -137 minecraft:grass_block
fill 186 65 -137 188 65 -137 minecraft:grass_block
setblock 192 65 -137 minecraft:grass_block
fill 195 65 -137 199 65 -137 minecraft:grass_block
fill 136 65 -136 185 65 -136 minecraft:grass_block
setblock 187 65 -136 minecraft:grass_block
setblock 192 65 -136 minecraft:grass_block
fill 195 65 -136 199 65 -136 minecraft:grass_block
fill 136 65 -135 186 65 -135 minecraft:grass_block
fill 195 65 -135 199 65 -135 minecraft:grass_block
fill 136 65 -134 141 65 -134 minecraft:grass_block
fill 148 65 -134 184 65 -134 minecraft:grass_block
fill 195 65 -134 199 65 -134 minecraft:grass_block
fill 136 65 -133 138 65 -133 minecraft:grass_block
fill 140 65 -133 148 65 -133 minecraft:grass_block
fill 150 65 -133 182 65 -133 minecraft:grass_block
setblock 192 65 -133 minecraft:grass_block
fill 194 65 -133 199 65 -133 minecraft:grass_block
fill 136 65 -132 137 65 -132 minecraft:grass_block
fill 139 65 -132 149 65 -132 minecraft:grass_block
fill 151 65 -132 181 65 -132 minecraft:grass_block
fill 192 65 -132 199 65 -132 minecraft:grass_block
fill 136 65 -131 137 65 -131 minecraft:grass_block
fill 139 65 -131 149 65 -131 minecraft:grass_block
fill 151 65 -131 180 65 -131 minecraft:grass_block
fill 191 65 -131 199 65 -131 minecraft:grass_block
setblock 136 65 -130 minecraft:grass_block
fill 138 65 -130 150 65 -130 minecraft:grass_block
fill 152 65 -130 179 65 -130 minecraft:grass_block
fill 191 65 -130 199 65 -130 minecraft:grass_block
fill 136 65 -129 151 65 -129 minecraft:grass_block
fill 153 65 -129 181 65 -129 minecraft:grass_block
fill 190 65 -129 199 65 -129 minecraft:grass_block
fill 136 65 -128 152 65 -128 minecraft:grass_block
fill 154 65 -128 181 65 -128 minecraft:grass_block
setblock 184 65 -128 minecraft:grass_block
fill 190 65 -128 199 65 -128 minecraft:grass_block
fill 136 65 -127 152 65 -127 minecraft:grass_block
fill 154 65 -127 181 65 -127 minecraft:grass_block
fill 194 65 -127 199 65 -127 minecraft:grass_block
setblock 151 66 -188 minecraft:air
setblock 167 66 -188 minecraft:air
setblock 154 66 -187 minecraft:air
setblock 164 66 -186 minecraft:air
setblock 161 66 -185 minecraft:air
setblock 155 66 -182 minecraft:air
setblock 161 66 -181 minecraft:air
setblock 163 66 -180 minecraft:birch_log
fill 159 66 -177 160 66 -177 minecraft:air
fill 160 66 -175 162 66 -175 minecraft:air
fill 159 66 -174 163 66 -174 minecraft:air
fill 159 66 -173 163 66 -173 minecraft:air
fill 159 66 -172 163 66 -172 minecraft:air
fill 160 66 -171 162 66 -171 minecraft:air
setblock 168 66 -171 minecraft:air
setblock 172 66 -171 minecraft:air
setblock 161 66 -167 minecraft:air
setblock 177 66 -166 minecraft:air
setblock 164 66 -164 minecraft:air
setblock 157 66 -163 minecraft:air
setblock 171 66 -163 minecraft:air
setblock 160 66 -162 minecraft:air
setblock 150 66 -161 minecraft:air
setblock 180 66 -161 minecraft:air
setblock 153 66 -160 minecraft:air
setblock 162 66 -160 minecraft:air
setblock 159 66 -159 minecraft:air
setblock 172 66 -159 minecraft:air
setblock 178 66 -159 minecraft:air
setblock 148 66 -158 minecraft:air
setblock 176 66 -158 minecraft:air
setblock 173 66 -157 minecraft:air
setblock 183 66 -157 minecraft:air
setblock 172 66 -155 minecraft:air
setblock 180 66 -155 minecraft:air
setblock 146 66 -153 minecraft:air
setblock 179 66 -152 minecraft:air
setblock 189 66 -151 minecraft:air
setblock 195 66 -151 minecraft:air
setblock 197 66 -151 minecraft:air
setblock 148 66 -148 minecraft:air
setblock 197 66 -148 minecraft:air
setblock 199 66 -148 minecraft:air
setblock 183 66 -147 minecraft:air
setblock 186 66 -147 minecraft:air
fill 198 66 -147 199 66 -147 minecraft:air
setblock 178 66 -146 minecraft:air
fill 198 66 -146 199 66 -146 minecraft:air
setblock 197 66 -145 minecraft:air
setblock 192 66 -144 minecraft:air
setblock 150 66 -143 minecraft:air
setblock 154 66 -143 minecraft:air
setblock 194 66 -143 minecraft:air
fill 197 66 -143 199 66 -143 minecraft:air
setblock 194 66 -142 minecraft:air
fill 196 66 -142 199 66 -142 minecraft:air
fill 196 66 -141 199 66 -141 minecraft:air
setblock 150 66 -140 minecraft:air
setblock 192 66 -140 minecraft:air
fill 196 66 -140 199 66 -140 minecraft:air
setblock 192 66 -139 minecraft:air
fill 195 66 -139 199 66 -139 minecraft:air
setblock 139 66 -138 minecraft:air
setblock 142 66 -138 minecraft:air
fill 192 66 -138 193 66 -138 minecraft:air
fill 195 66 -138 199 66 -138 minecraft:air
setblock 147 66 -137 minecraft:air
setblock 189 66 -137 minecraft:air
setblock 192 66 -137 minecraft:air
fill 195 66 -137 199 66 -137 minecraft:air
setblock 157 66 -136 minecraft:air
fill 191 66 -136 192 66 -136 minecraft:air
fill 195 66 -136 199 66 -136 minecraft:air
fill 186 66 -135 189 66 -135 minecraft:air
fill 195 66 -135 199 66 -135 minecraft:air
fill 140 66 -134 141 66 -134 minecraft:air
setblock 143 66 -134 minecraft:air
fill 188 66 -134 190 66 -134 minecraft:air
fill 195 66 -134 199 66 -134 minecraft:air
fill 140 66 -133 148 66 -133 minecraft:air
setblock 183 66 -133 minecraft:air
fill 188 66 -133 189 66 -133 minecraft:air
setblock 192 66 -133 minecraft:air
fill 194 66 -133 199 66 -133 minecraft:air
fill 139 66 -132 150 66 -132 minecraft:air
setblock 186 66 -132 minecraft:air
setblock 188 66 -132 minecraft:air
fill 191 66 -132 199 66 -132 minecraft:air
fill 139 66 -131 149 66 -131 minecraft:air
setblock 189 66 -131 minecraft:air
fill 191 66 -131 199 66 -131 minecraft:air
fill 138 66 -130 150 66 -130 minecraft:air
setblock 188 66 -130 minecraft:air
fill 191 66 -130 199 66 -130 minecraft:air
fill 136 66 -129 151 66 -129 minecraft:air
fill 185 66 -129 187 66 -129 minecraft:air
fill 189 66 -129 199 66 -129 minecraft:air
fill 136 66 -128 152 66 -128 minecraft:air
setblock 160 66 -128 minecraft:air
setblock 184 66 -128 minecraft:air
fill 189 66 -128 199 66 -128 minecraft:air
fill 136 66 -127 152 66 -127 minecraft:air
setblock 187 66 -127 minecraft:air
fill 189 66 -127 190 66 -127 minecraft:air
fill 193 66 -127 199 66 -127 minecraft:air
setblock 151 67 -188 minecraft:air
setblock 154 67 -187 minecraft:air
setblock 155 67 -184 minecraft:air
fill 154 67 -183 156 67 -183 minecraft:air
fill 153 67 -182 157 67 -182 minecraft:air
fill 154 67 -181 156 67 -181 minecraft:air
setblock 155 67 -180 minecraft:air
setblock 163 67 -180 minecraft:birch_log
setblock 162 67 -175 minecraft:air
fill 161 67 -174 163 67 -174 minecraft:air
fill 160 67 -173 163 67 -173 minecraft:air
fill 160 67 -172 163 67 -172 minecraft:air
fill 160 67 -171 162 67 -171 minecraft:air
setblock 168 67 -171 minecraft:air
setblock 172 67 -171 minecraft:air
setblock 161 67 -167 minecraft:air
setblock 164 67 -166 minecraft:air
setblock 177 67 -166 minecraft:air
fill 163 67 -165 165 67 -165 minecraft:air
setblock 171 67 -165 minecraft:air
fill 162 67 -164 166 67 -164 minecraft:air
fill 170 67 -164 172 67 -164 minecraft:air
setblock 157 67 -163 minecraft:air
fill 163 67 -163 165 67 -163 minecraft:air
fill 169 67 -163 173 67 -163 minecraft:air
setblock 180 67 -163 minecraft:air
setblock 160 67 -162 minecraft:air
setblock 164 67 -162 minecraft:air
fill 170 67 -162 172 67 -162 minecraft:air
fill 179 67 -162 181 67 -162 minecraft:air
setblock 150 67 -161 minecraft:air
setblock 171 67 -161 minecraft:air
fill 178 67 -161 182 67 -161 minecraft:air
setblock 153 67 -160 minecraft:air
setblock 162 67 -160 minecraft:air
fill 179 67 -160 181 67 -160 minecraft:air
setblock 159 67 -159 minecraft:air
setblock 172 67 -159 minecraft:air
setblock 178 67 -159 minecraft:air
setblock 180 67 -159 minecraft:air
fill 182 67 -159 185 67 -159 minecraft:air
setblock 148 67 -158 minecraft:air
setblock 176 67 -158 minecraft:air
fill 181 67 -158 182 67 -158 minecraft:air
fill 184 67 -158 185 67 -158 minecraft:air
setblock 173 67 -157 minecraft:air
setblock 181 67 -157 minecraft:air
setblock 183 67 -157 minecraft:air
setblock 185 67 -157 minecraft:air
fill 181 67 -156 182 67 -156 minecraft:air
fill 184 67 -156 185 67 -156 minecraft:air
setblock 172 67 -155 minecraft:air
fill 180 67 -155 185 67 -155 minecraft:air
setblock 146 67 -153 minecraft:air
setblock 179 67 -152 minecraft:air
setblock 189 67 -151 minecraft:air
setblock 195 67 -151 minecraft:air
setblock 148 67 -148 minecraft:air
setblock 183 67 -147 minecraft:air
setblock 186 67 -147 minecraft:air
setblock 178 67 -146 minecraft:air
setblock 197 67 -145 minecraft:air
setblock 192 67 -144 minecraft:air
setblock 150 67 -143 minecraft:air
setblock 154 67 -143 minecraft:air
setblock 196 67 -142 minecraft:air
setblock 198 67 -142 minecraft:air
setblock 150 67 -140 minecraft:air
setblock 139 67 -138 minecraft:air
setblock 142 67 -138 minecraft:air
setblock 192 67 -138 minecraft:air
setblock 147 67 -137 minecraft:air
setblock 157 67 -136 minecraft:air
setblock 192 67 -136 minecraft:air
setblock 186 67 -135 minecraft:air
setblock 141 67 -134 minecraft:air
setblock 143 67 -133 minecraft:air
setblock 146 67 -133 minecraft:air
setblock 148 67 -133 minecraft:air
fill 140 67 -132 149 67 -132 minecraft:air
fill 140 67 -131 149 67 -131 minecraft:air
setblock 192 67 -131 minecraft:air
setblock 196 67 -131 minecraft:air
fill 139 67 -130 149 67 -130 minecraft:air
fill 196 67 -130 198 67 -130 minecraft:air
fill 139 67 -129 149 67 -129 minecraft:air
setblock 190 67 -129 minecraft:air
setblock 192 67 -129 minecraft:air
fill 194 67 -129 198 67 -129 minecraft:air
fill 137 67 -128 150 67 -128 minecraft:air
setblock 160 67 -128 minecraft:air
setblock 184 67 -128 minecraft:air
setblock 190 67 -128 minecraft:air
setblock 195 67 -128 minecraft:air
fill 198 67 -128 199 67 -128 minecraft:air
setblock 136 67 -127 minecraft:air
fill 138 67 -127 152 67 -127 minecraft:air
fill 196 67 -127 198 67 -127 minecraft:air
fill 152 68 -190 154 68 -190 minecraft:air
setblock 153 68 -189 minecraft:air
setblock 151 68 -188 minecraft:air
setblock 154 68 -187 minecraft:air
fill 154 68 -183 156 68 -183 minecraft:air
fill 154 68 -182 156 68 -182 minecraft:air
fill 154 68 -181 156 68 -181 minecraft:air
setblock 163 68 -180 minecraft:birch_log
setblock 162 68 -175 minecraft:air
fill 161 68 -174 163 68 -174 minecraft:air
fill 160 68 -173 163 68 -173 minecraft:air
setblock 172 68 -173 minecraft:air
fill 160 68 -172 163 68 -172 minecraft:air
fill 171 68 -172 173 68 -172 minecraft:air
fill 160 68 -171 162 68 -171 minecraft:air
setblock 168 68 -171 minecraft:air
fill 170 68 -171 174 68 -171 minecraft:air
fill 171 68 -170 173 68 -170 minecraft:air
setblock 172 68 -169 minecraft:air
setblock 177 68 -168 minecraft:air
setblock 161 68 -167 minecraft:air
fill 176 68 -167 178 68 -167 minecraft:air
fill 175 68 -166 179 68 -166 minecraft:air
setblock 157 68 -165 minecraft:air
fill 163 68 -165 165 68 -165 minecraft:air
fill 176 68 -165 178 68 -165 minecraft:air
fill 156 68 -164 158 68 -164 minecraft:air
fill 163 68 -164 165 68 -164 minecraft:air
fill 170 68 -164 172 68 -164 minecraft:air
setblock 177 68 -164 minecraft:air
fill 155 68 -163 159 68 -163 minecraft:air
fill 163 68 -163 165 68 -163 minecraft:air
fill 170 68 -163 172 68 -163 minecraft:air
fill 156 68 -162 158 68 -162 minecraft:air
setblock 160 68 -162 minecraft:air
fill 170 68 -162 172 68 -162 minecraft:air
fill 179 68 -162 181 68 -162 minecraft:air
setblock 150 68 -161 minecraft:air
setblock 157 68 -161 minecraft:air
setblock 172 68 -161 minecraft:air
fill 178 68 -161 181 68 -161 minecraft:air
setblock 153 68 -160 minecraft:air
setblock 162 68 -160 minecraft:air
fill 171 68 -160 173 68 -160 minecraft:air
fill 176 68 -160 181 68 -160 minecraft:air
setblock 159 68 -159 minecraft:air
fill 170 68 -159 180 68 -159 minecraft:air
fill 182 68 -159 185 68 -159 minecraft:air
setblock 148 68 -158 minecraft:air
fill 171 68 -158 179 68 -158 minecraft:air
fill 181 68 -158 182 68 -158 minecraft:air
fill 184 68 -158 185 68 -158 minecraft:air
fill 171 68 -157 178 68 -157 minecraft:air
setblock 181 68 -157 minecraft:air
setblock 183 68 -157 minecraft:air
setblock 185 68 -157 minecraft:air
fill 171 68 -156 174 68 -156 minecraft:air
setblock 176 68 -156 minecraft:air
fill 181 68 -156 182 68 -156 minecraft:air
fill 184 68 -156 185 68 -156 minecraft:air
setblock 146 68 -155 minecraft:air
fill 170 68 -155 174 68 -155 minecraft:air
fill 180 68 -155 184 68 -155 minecraft:air
fill 145 68 -154 147 68 -154 minecraft:air
fill 171 68 -154 173 68 -154 minecraft:air
fill 144 68 -153 148 68 -153 minecraft:air
setblock 172 68 -153 minecraft:air
fill 145 68 -152 147 68 -152 minecraft:air
setblock 179 68 -152 minecraft:air
setblock 146 68 -151 minecraft:air
setblock 189 68 -151 minecraft:air
setblock 195 68 -151 minecraft:air
setblock 148 68 -150 minecraft:air
fill 147 68 -149 149 68 -149 minecraft:air
fill 181 68 -149 188 68 -149 minecraft:air
fill 146 68 -148 150 68 -148 minecraft:air
fill 181 68 -148 182 68 -148 minecraft:air
fill 184 68 -148 185 68 -148 minecraft:air
fill 187 68 -148 188 68 -148 minecraft:air
fill 147 68 -147 149 68 -147 minecraft:air
setblock 178 68 -147 minecraft:air
setblock 181 68 -147 minecraft:air
setblock 183 68 -147 minecraft:air
setblock 186 68 -147 minecraft:air
setblock 188 68 -147 minecraft:air
setblock 148 68 -146 minecraft:air
fill 177 68 -146 179 68 -146 minecraft:air
fill 181 68 -146 182 68 -146 minecraft:air
fill 184 68 -146 185 68 -146 minecraft:air
fill 187 68 -146 188 68 -146 minecraft:air
setblock 178 68 -145 minecraft:air
fill 182 68 -145 187 68 -145 minecraft:air
setblock 192 68 -144 minecraft:air
setblock 150 68 -143 minecraft:air
setblock 154 68 -143 minecraft:air
setblock 196 68 -142 minecraft:air
setblock 150 68 -140 minecraft:air
setblock 139 68 -138 minecraft:air
setblock 142 68 -138 minecraft:air
setblock 147 68 -137 minecraft:air
setblock 157 68 -137 minecraft:air
fill 156 68 -136 158 68 -136 minecraft:air
setblock 136 68 -135 minecraft:air
setblock 157 68 -135 minecraft:air
setblock 186 68 -135 minecraft:air
setblock 141 68 -134 minecraft:air
fill 142 68 -132 148 68 -132 minecraft:air
fill 141 68 -131 148 68 -131 minecraft:air
setblock 196 68 -131 minecraft:air
setblock 139 68 -130 minecraft:air
fill 143 68 -130 148 68 -130 minecraft:air
setblock 162 68 -130 minecraft:air
fill 144 68 -129 148 68 -129 minecraft:air
setblock 158 68 -129 minecraft:air
fill 161 68 -129 163 68 -129 minecraft:air
setblock 190 68 -129 minecraft:air
setblock 140 68 -128 minecraft:air
fill 144 68 -128 149 68 -128 minecraft:air
fill 159 68 -128 162 68 -128 minecraft:air
setblock 184 68 -128 minecraft:air
setblock 138 68 -127 minecraft:air
fill 146 68 -127 148 68 -127 minecraft:air
setblock 152 68 -127 minecraft:air
setblock 198 68 -127 minecraft:air
fill 151 69 -190 154 69 -190 minecraft:air
fill 150 69 -189 152 69 -189 minecraft:air
fill 149 69 -188 153 69 -188 minecraft:air
fill 150 69 -187 152 69 -187 minecraft:air
setblock 154 69 -187 minecraft:air
setblock 151 69 -186 minecraft:air
setblock 155 69 -183 minecraft:air
fill 154 69 -182 156 69 -182 minecraft:air
setblock 163 69 -182 minecraft:birch_leaves[persistent=true]
setblock 155 69 -181 minecraft:air
fill 162 69 -181 164 69 -181 minecraft:birch_leaves[persistent=true]
fill 161 69 -180 162 69 -180 minecraft:birch_leaves[persistent=true]
setblock 163 69 -180 minecraft:birch_log
fill 164 69 -180 165 69 -180 minecraft:birch_leaves[persistent=true]
fill 162 69 -179 164 69 -179 minecraft:birch_leaves[persistent=true]
setblock 163 69 -178 minecraft:birch_leaves[persistent=true]
setblock 161 69 -174 minecraft:air
fill 160 69 -173 162 69 -173 minecraft:air
setblock 168 69 -173 minecraft:air
setblock 161 69 -172 minecraft:air
setblock 163 69 -172 minecraft:air
fill 167 69 -172 169 69 -172 minecraft:air
fill 171 69 -172 173 69 -172 minecraft:air
fill 166 69 -171 173 69 -171 minecraft:air
fill 167 69 -170 169 69 -170 minecraft:air
fill 171 69 -170 173 69 -170 minecraft:air
setblock 168 69 -169 minecraft:air
setblock 161 69 -167 minecraft:air
fill 176 69 -167 178 69 -167 minecraft:air
fill 176 69 -166 178 69 -166 minecraft:air
setblock 164 69 -165 minecraft:air
fill 176 69 -165 178 69 -165 minecraft:air
fill 156 69 -164 158 69 -164 minecraft:air
fill 163 69 -164 165 69 -164 minecraft:air
setblock 171 69 -164 minecraft:air
fill 156 69 -163 158 69 -163 minecraft:air
setblock 164 69 -163 minecraft:air
fill 170 69 -163 172 69 -163 minecraft:air
fill 150 69 -162 151 69 -162 minecraft:air
setblock 153 69 -162 minecraft:air
fill 156 69 -162 158 69 -162 minecraft:air
setblock 160 69 -162 minecraft:air
setblock 171 69 -162 minecraft:air
setblock 180 69 -162 minecraft:air
fill 149 69 -161 154 69 -161 minecraft:air
fill 179 69 -161 181 69 -161 minecraft:air
fill 150 69 -160 155 69 -160 minecraft:air
setblock 162 69 -160 minecraft:air
fill 171 69 -160 173 69 -160 minecraft:air
fill 177 69 -160 180 69 -160 minecraft:air
fill 148 69 -159 150 69 -159 minecraft:air
fill 152 69 -159 154 69 -159 minecraft:air
setblock 159 69 -159 minecraft:air
fill 171 69 -159 173 69 -159 minecraft:air
fill 175 69 -159 179 69 -159 minecraft:air
setblock 183 69 -159 minecraft:air
fill 147 69 -158 150 69 -158 minecraft:air
setblock 153 69 -158 minecraft:air
fill 171 69 -158 179 69 -158 minecraft:air
setblock 182 69 -158 minecraft:air
setblock 184 69 -158 minecraft:air
fill 147 69 -157 149 69 -157 minecraft:air
fill 172 69 -157 177 69 -157 minecraft:air
setblock 183 69 -157 minecraft:air
setblock 148 69 -156 minecraft:air
fill 171 69 -156 174 69 -156 minecraft:air
setblock 182 69 -156 minecraft:air
setblock 184 69 -156 minecraft:air
fill 171 69 -155 173 69 -155 minecraft:air
setblock 180 69 -155 minecraft:air
setblock 183 69 -155 minecraft:air
fill 145 69 -154 147 69 -154 minecraft:air
fill 171 69 -154 173 69 -154 minecraft:air
fill 145 69 -153 147 69 -153 minecraft:air
fill 145 69 -152 147 69 -152 minecraft:air
setblock 179 69 -152 minecraft:air
setblock 189 69 -151 minecraft:air
setblock 195 69 -151 minecraft:air
fill 147 69 -149 149 69 -149 minecraft:air
fill 176 69 -149 180 69 -149 minecraft:air
fill 182 69 -149 188 69 -149 minecraft:air
fill 147 69 -148 149 69 -148 minecraft:air
fill 175 69 -148 182 69 -148 minecraft:air
fill 184 69 -148 185 69 -148 minecraft:air
fill 187 69 -148 188 69 -148 minecraft:air
fill 147 69 -147 149 69 -147 minecraft:air
fill 175 69 -147 181 69 -147 minecraft:air
setblock 183 69 -147 minecraft:air
setblock 186 69 -147 minecraft:air
setblock 188 69 -147 minecraft:air
fill 175 69 -146 182 69 -146 minecraft:air
fill 184 69 -146 185 69 -146 minecraft:air
fill 187 69 -146 188 69 -146 minecraft:air
fill 175 69 -145 187 69 -145 minecraft:air
fill 175 69 -144 181 69 -144 minecraft:air
setblock 192 69 -144 minecraft:air
setblock 150 69 -143 minecraft:air
setblock 154 69 -143 minecraft:air
fill 176 69 -143 180 69 -143 minecraft:air
setblock 196 69 -142 minecraft:air
setblock 150 69 -140 minecraft:air
setblock 139 69 -138 minecraft:air
setblock 142 69 -138 minecraft:air
fill 156 69 -138 158 69 -138 minecraft:air
fill 147 69 -137 148 69 -137 minecraft:air
fill 155 69 -137 159 69 -137 minecraft:air
fill 155 69 -136 159 69 -136 minecraft:air
fill 155 69 -135 159 69 -135 minecraft:air
fill 185 69 -135 187 69 -135 minecraft:air
setblock 141 69 -134 minecraft:air
fill 156 69 -134 159 69 -134 minecraft:air
setblock 186 69 -134 minecraft:air
fill 142 69 -132 143 69 -132 minecraft:air
setblock 147 69 -131 minecraft:air
fill 161 69 -131 163 69 -131 minecraft:air
setblock 196 69 -131 minecraft:air
setblock 144 69 -130 minecraft:air
fill 147 69 -130 148 69 -130 minecraft:air
setblock 157 69 -130 minecraft:air
fill 160 69 -130 164 69 -130 minecraft:air
setblock 148 69 -129 minecraft:air
fill 156 69 -129 158 69 -129 minecraft:air
fill 160 69 -129 164 69 -129 minecraft:air
setblock 190 69 -129 minecraft:air
setblock 142 69 -128 minecraft:oak_leaves[persistent=true]
setblock 149 69 -128 minecraft:air
setblock 152 69 -128 minecraft:oak_leaves[persistent=true]
setblock 157 69 -128 minecraft:air
fill 160 69 -128 161 69 -128 minecraft:air
setblock 162 69 -128 minecraft:oak_leaves[persistent=true]
fill 163 69 -128 164 69 -128 minecraft:air
setblock 172 69 -128 minecraft:oak_leaves[persistent=true]
setblock 182 69 -128 minecraft:oak_leaves[persistent=true]
setblock 184 69 -128 minecraft:air
setblock 192 69 -128 minecraft:oak_leaves[persistent=true]
fill 141 69 -127 143 69 -127 minecraft:oak_leaves[persistent=true]
fill 151 69 -127 153 69 -127 minecraft:oak_leaves[persistent=true]
fill 161 69 -127 163 69 -127 minecraft:oak_leaves[persistent=true]
fill 171 69 -127 173 69 -127 minecraft:oak_leaves[persistent=true]
fill 181 69 -127 183 69 -127 minecraft:oak_leaves[persistent=true]
fill 191 69 -127 193 69 -127 minecraft:oak_leaves[persistent=true]
setblock 198 69 -127 minecraft:air
setblock 153 70 -190 minecraft:air
fill 150 70 -189 152 70 -189 minecraft:air
fill 150 70 -188 152 70 -188 minecraft:air
fill 150 70 -187 152 70 -187 minecraft:air
setblock 154 70 -187 minecraft:air
fill 154 70 -182 156 70 -182 minecraft:air
fill 162 70 -182 164 70 -182 minecraft:birch_leaves[persistent=true]
setblock 155 70 -181 minecraft:air
fill 161 70 -181 165 70 -181 minecraft:birch_leaves[persistent=true]
fill 161 70 -180 162 70 -180 minecraft:birch_leaves[persistent=true]
setblock 163 70 -180 minecraft:birch_log
fill 164 70 -180 165 70 -180 minecraft:birch_leaves[persistent=true]
fill 161 70 -179 165 70 -179 minecraft:birch_leaves[persistent=true]
fill 162 70 -178 164 70 -178 minecraft:birch_leaves[persistent=true]
setblock 163 70 -172 minecraft:air
fill 167 70 -172 169 70 -172 minecraft:air
setblock 172 70 -172 minecraft:air
fill 167 70 -171 169 70 -171 minecraft:air
fill 171 70 -171 173 70 -171 minecraft:air
fill 167 70 -170 169 70 -170 minecraft:air
setblock 172 70 -170 minecraft:air
setblock 161 70 -167 minecraft:air
setblock 177 70 -167 minecraft:air
fill 176 70 -166 178 70 -166 minecraft:air
setblock 164 70 -165 minecraft:air
setblock 177 70 -165 minecraft:air
setblock 157 70 -164 minecraft:air
setblock 160 70 -164 minecraft:air
fill 164 70 -164 165 70 -164 minecraft:air
setblock 171 70 -164 minecraft:air
setblock 149 70 -163 minecraft:air
fill 156 70 -163 161 70 -163 minecraft:air
setblock 171 70 -163 minecraft:air
fill 149 70 -162 151 70 -162 minecraft:air
fill 157 70 -162 162 70 -162 minecraft:air
setblock 171 70 -162 minecraft:air
fill 149 70 -161 154 70 -161 minecraft:air
fill 159 70 -161 161 70 -161 minecraft:air
fill 179 70 -161 181 70 -161 minecraft:air
fill 150 70 -160 154 70 -160 minecraft:air
setblock 160 70 -160 minecraft:air
setblock 162 70 -160 minecraft:air
setblock 172 70 -160 minecraft:air
setblock 178 70 -160 minecraft:air
fill 144 70 -159 149 70 -159 minecraft:air
fill 152 70 -159 154 70 -159 minecraft:air
setblock 159 70 -159 minecraft:air
fill 171 70 -159 173 70 -159 minecraft:air
fill 176 70 -159 179 70 -159 minecraft:air
setblock 145 70 -158 minecraft:air
fill 147 70 -158 149 70 -158 minecraft:air
fill 172 70 -158 173 70 -158 minecraft:air
fill 175 70 -158 178 70 -158 minecraft:air
fill 147 70 -157 149 70 -157 minecraft:air
fill 172 70 -157 174 70 -157 minecraft:air
setblock 176 70 -157 minecraft:air
setblock 183 70 -157 minecraft:air
fill 172 70 -156 173 70 -156 minecraft:air
setblock 184 70 -156 minecraft:air
fill 171 70 -155 173 70 -155 minecraft:air
setblock 180 70 -155 minecraft:air
setblock 146 70 -154 minecraft:air
setblock 172 70 -154 minecraft:air
fill 145 70 -153 147 70 -153 minecraft:air
fill 188 70 -153 190 70 -153 minecraft:air
setblock 146 70 -152 minecraft:air
setblock 179 70 -152 minecraft:air
fill 187 70 -152 188 70 -152 minecraft:air
setblock 187 70 -151 minecraft:air
setblock 189 70 -151 minecraft:air
setblock 191 70 -151 minecraft:air
setblock 195 70 -151 minecraft:air
setblock 136 70 -150 minecraft:air
fill 187 70 -150 188 70 -150 minecraft:air
fill 190 70 -150 191 70 -150 minecraft:air
fill 136 70 -149 137 70 -149 minecraft:air
setblock 148 70 -149 minecraft:air
fill 186 70 -149 190 70 -149 minecraft:air
setblock 136 70 -148 minecraft:air
fill 147 70 -148 149 70 -148 minecraft:air
fill 177 70 -148 179 70 -148 minecraft:air
setblock 182 70 -148 minecraft:air
fill 184 70 -148 185 70 -148 minecraft:air
setblock 187 70 -148 minecraft:air
setblock 148 70 -147 minecraft:air
fill 176 70 -147 181 70 -147 minecraft:air
setblock 183 70 -147 minecraft:air
setblock 186 70 -147 minecraft:air
fill 176 70 -146 180 70 -146 minecraft:air
setblock 182 70 -146 minecraft:air
fill 184 70 -146 185 70 -146 minecraft:air
setblock 187 70 -146 minecraft:air
setblock 193 70 -146 minecraft:air
fill 176 70 -145 180 70 -145 minecraft:air
setblock 183 70 -145 minecraft:air
setblock 186 70 -145 minecraft:air
setblock 191 70 -145 minecraft:air
setblock 194 70 -145 minecraft:air
fill 177 70 -144 179 70 -144 minecraft:air
setblock 190 70 -144 minecraft:air
setblock 192 70 -144 minecraft:air
setblock 150 70 -143 minecraft:air
setblock 154 70 -143 minecraft:air
fill 190 70 -143 191 70 -143 minecraft:air
setblock 194 70 -143 minecraft:air
fill 191 70 -142 194 70 -142 minecraft:air
setblock 196 70 -142 minecraft:air
setblock 142 70 -140 minecraft:air
setblock 150 70 -140 minecraft:air
fill 141 70 -139 143 70 -139 minecraft:air
fill 139 70 -138 144 70 -138 minecraft:air
fill 155 70 -138 158 70 -138 minecraft:air
fill 141 70 -137 143 70 -137 minecraft:air
setblock 147 70 -137 minecraft:air
fill 155 70 -137 159 70 -137 minecraft:air
fill 186 70 -137 187 70 -137 minecraft:air
setblock 142 70 -136 minecraft:air
fill 155 70 -136 159 70 -136 minecraft:air
fill 184 70 -136 185 70 -136 minecraft:air
fill 187 70 -136 188 70 -136 minecraft:air
fill 155 70 -135 159 70 -135 minecraft:air
fill 184 70 -135 188 70 -135 minecraft:air
setblock 141 70 -134 minecraft:air
fill 156 70 -134 159 70 -134 minecraft:air
fill 184 70 -134 188 70 -134 minecraft:air
fill 185 70 -133 188 70 -133 minecraft:air
setblock 143 70 -132 minecraft:air
fill 156 70 -131 158 70 -131 minecraft:air
fill 161 70 -131 163 70 -131 minecraft:air
setblock 196 70 -131 minecraft:air
setblock 144 70 -130 minecraft:air
fill 155 70 -130 164 70 -130 minecraft:air
fill 155 70 -129 164 70 -129 minecraft:air
setblock 190 70 -129 minecraft:air
fill 141 70 -128 143 70 -128 minecraft:oak_leaves[persistent=true]
setblock 149 70 -128 minecraft:air
fill 151 70 -128 153 70 -128 minecraft:oak_leaves[persistent=true]
fill 155 70 -128 160 70 -128 minecraft:air
fill 161 70 -128 163 70 -128 minecraft:oak_leaves[persistent=true]
setblock 164 70 -128 minecraft:air
fill 171 70 -128 173 70 -128 minecraft:oak_leaves[persistent=true]
fill 181 70 -128 183 70 -128 minecraft:oak_leaves[persistent=true]
setblock 184 70 -128 minecraft:air
fill 191 70 -128 193 70 -128 minecraft:oak_leaves[persistent=true]
fill 140 70 -127 144 70 -127 minecraft:oak_leaves[persistent=true]
fill 150 70 -127 154 70 -127 minecraft:oak_leaves[persistent=true]
fill 156 70 -127 158 70 -127 minecraft:air
fill 160 70 -127 164 70 -127 minecraft:oak_leaves[persistent=true]
fill 170 70 -127 174 70 -127 minecraft:oak_leaves[persistent=true]
fill 180 70 -127 184 70 -127 minecraft:oak_leaves[persistent=true]
fill 190 70 -127 194 70 -127 minecraft:oak_leaves[persistent=true]
setblock 198 70 -127 minecraft:air
setblock 151 71 -189 minecraft:air
fill 150 71 -188 152 71 -188 minecraft:air
setblock 151 71 -187 minecraft:air
setblock 154 71 -187 minecraft:air
setblock 164 71 -186 minecraft:air
setblock 163 71 -182 minecraft:birch_leaves[persistent=true]
setblock 161 71 -181 minecraft:air
fill 162 71 -181 164 71 -181 minecraft:birch_leaves[persistent=true]
fill 161 71 -180 165 71 -180 minecraft:birch_leaves[persistent=true]
fill 162 71 -179 164 71 -179 minecraft:birch_leaves[persistent=true]
setblock 163 71 -178 minecraft:birch_leaves[persistent=true]
setblock 159 71 -177 minecraft:air
setblock 156 71 -176 minecraft:air
setblock 163 71 -172 minecraft:air
setblock 168 71 -172 minecraft:air
setblock 172 71 -172 minecraft:air
fill 167 71 -171 169 71 -171 minecraft:air
fill 171 71 -171 173 71 -171 minecraft:air
setblock 168 71 -170 minecraft:air
setblock 161 71 -169 minecraft:air
fill 160 71 -168 162 71 -168 minecraft:air
fill 159 71 -167 163 71 -167 minecraft:air
setblock 177 71 -167 minecraft:air
fill 160 71 -166 162 71 -166 minecraft:air
setblock 177 71 -166 minecraft:air
setblock 161 71 -165 minecraft:air
setblock 177 71 -165 minecraft:air
setblock 157 71 -163 minecraft:air
fill 159 71 -163 161 71 -163 minecraft:air
setblock 150 71 -162 minecraft:air
fill 159 71 -162 161 71 -162 minecraft:air
fill 149 71 -161 151 71 -161 minecraft:air
setblock 153 71 -161 minecraft:air
fill 159 71 -161 161 71 -161 minecraft:air
setblock 150 71 -160 minecraft:air
fill 152 71 -160 154 71 -160 minecraft:air
setblock 162 71 -160 minecraft:air
fill 145 71 -159 146 71 -159 minecraft:air
setblock 148 71 -159 minecraft:air
setblock 153 71 -159 minecraft:air
setblock 159 71 -159 minecraft:air
fill 171 71 -159 173 71 -159 minecraft:air
setblock 176 71 -159 minecraft:air
setblock 178 71 -159 minecraft:air
fill 147 71 -158 149 71 -158 minecraft:air
setblock 172 71 -158 minecraft:air
setblock 176 71 -158 minecraft:air
setblock 182 71 -158 minecraft:air
setblock 148 71 -157 minecraft:air
fill 172 71 -157 174 71 -157 minecraft:air
setblock 176 71 -157 minecraft:air
setblock 183 71 -157 minecraft:air
setblock 172 71 -156 minecraft:air
setblock 184 71 -156 minecraft:air
fill 171 71 -155 172 71 -155 minecraft:air
setblock 180 71 -155 minecraft:air
setblock 172 71 -154 minecraft:air
fill 146 71 -153 147 71 -153 minecraft:air
fill 188 71 -153 190 71 -153 minecraft:air
fill 192 71 -153 198 71 -153 minecraft:air
setblock 179 71 -152 minecraft:air
fill 187 71 -152 188 71 -152 minecraft:air
fill 192 71 -152 198 71 -152 minecraft:air
setblock 187 71 -151 minecraft:air
setblock 189 71 -151 minecraft:air
fill 191 71 -151 198 71 -151 minecraft:air
setblock 136 71 -150 minecraft:air
fill 187 71 -150 188 71 -150 minecraft:air
fill 190 71 -150 198 71 -150 minecraft:air
setblock 136 71 -149 minecraft:air
fill 188 71 -149 198 71 -149 minecraft:air
setblock 136 71 -148 minecraft:air
fill 148 71 -148 149 71 -148 minecraft:air
setblock 182 71 -148 minecraft:air
fill 193 71 -148 197 71 -148 minecraft:air
setblock 148 71 -147 minecraft:air
setblock 178 71 -147 minecraft:air
setblock 183 71 -147 minecraft:air
setblock 186 71 -147 minecraft:air
fill 177 71 -146 179 71 -146 minecraft:air
fill 184 71 -146 185 71 -146 minecraft:air
setblock 187 71 -146 minecraft:air
setblock 190 71 -146 minecraft:air
setblock 193 71 -146 minecraft:air
setblock 154 71 -145 minecraft:air
setblock 178 71 -145 minecraft:air
setblock 191 71 -145 minecraft:air
setblock 194 71 -145 minecraft:air
fill 153 71 -144 155 71 -144 minecraft:air
setblock 190 71 -144 minecraft:air
setblock 192 71 -144 minecraft:air
setblock 150 71 -143 minecraft:air
fill 152 71 -143 156 71 -143 minecraft:air
fill 190 71 -143 191 71 -143 minecraft:air
setblock 194 71 -143 minecraft:air
fill 153 71 -142 155 71 -142 minecraft:air
fill 190 71 -142 194 71 -142 minecraft:air
setblock 196 71 -142 minecraft:air
setblock 154 71 -141 minecraft:air
setblock 150 71 -140 minecraft:air
fill 141 71 -139 143 71 -139 minecraft:air
setblock 139 71 -138 minecraft:air
fill 141 71 -138 143 71 -138 minecraft:air
fill 141 71 -137 143 71 -137 minecraft:air
setblock 147 71 -137 minecraft:air
fill 156 71 -137 158 71 -137 minecraft:air
fill 186 71 -137 187 71 -137 minecraft:air
fill 155 71 -136 159 71 -136 minecraft:air
fill 184 71 -136 185 71 -136 minecraft:air
fill 187 71 -136 188 71 -136 minecraft:air
fill 156 71 -135 158 71 -135 minecraft:air
fill 184 71 -135 188 71 -135 minecraft:air
setblock 141 71 -134 minecraft:air
fill 184 71 -134 188 71 -134 minecraft:air
fill 184 71 -133 188 71 -133 minecraft:air
setblock 143 71 -132 minecraft:air
fill 156 71 -131 158 71 -131 minecraft:air
fill 161 71 -131 163 71 -131 minecraft:air
setblock 196 71 -131 minecraft:air
setblock 144 71 -130 minecraft:air
fill 155 71 -130 164 71 -130 minecraft:air
fill 183 71 -130 185 71 -130 minecraft:air
setblock 190 71 -130 minecraft:air
fill 155 71 -129 164 71 -129 minecraft:air
fill 182 71 -129 186 71 -129 minecraft:air
fill 189 71 -129 191 71 -129 minecraft:air
setblock 142 71 -128 minecraft:oak_leaves[persistent=true]
setblock 149 71 -128 minecraft:air
setblock 152 71 -128 minecraft:oak_leaves[persistent=true]
fill 155 71 -128 161 71 -128 minecraft:air
setblock 162 71 -128 minecraft:oak_leaves[persistent=true]
fill 163 71 -128 164 71 -128 minecraft:air
setblock 172 71 -128 minecraft:oak_leaves[persistent=true]
setblock 182 71 -128 minecraft:oak_leaves[persistent=true]
fill 183 71 -128 186 71 -128 minecraft:air
setblock 190 71 -128 minecraft:air
setblock 192 71 -128 minecraft:oak_leaves[persistent=true]
setblock 198 71 -128 minecraft:air
fill 141 71 -127 143 71 -127 minecraft:oak_leaves[persistent=true]
fill 151 71 -127 153 71 -127 minecraft:oak_leaves[persistent=true]
fill 156 71 -127 160 71 -127 minecraft:air
fill 161 71 -127 163 71 -127 minecraft:oak_leaves[persistent=true]
fill 171 71 -127 173 71 -127 minecraft:oak_leaves[persistent=true]
fill 181 71 -127 183 71 -127 minecraft:oak_leaves[persistent=true]
fill 184 71 -127 186 71 -127 minecraft:air
fill 191 71 -127 193 71 -127 minecraft:oak_leaves[persistent=true]
fill 197 71 -127 199 71 -127 minecraft:air
setblock 165 72 -190 minecraft:air
setblock 154 72 -189 minecraft:air
fill 166 72 -189 167 72 -189 minecraft:air
fill 151 72 -188 155 72 -188 minecraft:air
setblock 164 72 -188 minecraft:air
fill 166 72 -188 168 72 -188 minecraft:air
fill 152 72 -187 156 72 -187 minecraft:air
fill 163 72 -187 168 72 -187 minecraft:air
fill 153 72 -186 155 72 -186 minecraft:air
fill 162 72 -186 166 72 -186 minecraft:air
setblock 154 72 -185 minecraft:air
fill 163 72 -185 165 72 -185 minecraft:air
setblock 164 72 -184 minecraft:air
setblock 161 72 -181 minecraft:air
setblock 163 72 -180 minecraft:birch_leaves[persistent=true]
setblock 159 72 -179 minecraft:air
setblock 156 72 -178 minecraft:air
fill 158 72 -178 160 72 -178 minecraft:air
fill 155 72 -177 161 72 -177 minecraft:air
fill 154 72 -176 160 72 -176 minecraft:air
fill 155 72 -175 157 72 -175 minecraft:air
setblock 159 72 -175 minecraft:air
setblock 156 72 -174 minecraft:air
setblock 163 72 -172 minecraft:air
setblock 168 72 -172 minecraft:air
fill 168 72 -171 169 72 -171 minecraft:air
setblock 168 72 -170 minecraft:air
fill 160 72 -168 162 72 -168 minecraft:air
fill 160 72 -167 162 72 -167 minecraft:air
fill 160 72 -166 162 72 -166 minecraft:air
setblock 160 72 -163 minecraft:air
setblock 150 72 -162 minecraft:air
fill 159 72 -162 161 72 -162 minecraft:air
fill 149 72 -161 151 72 -161 minecraft:air
setblock 153 72 -161 minecraft:air
setblock 160 72 -161 minecraft:air
fill 153 72 -160 154 72 -160 minecraft:air
setblock 162 72 -160 minecraft:air
setblock 148 72 -159 minecraft:air
setblock 153 72 -159 minecraft:air
setblock 159 72 -159 minecraft:air
fill 148 72 -158 149 72 -158 minecraft:air
setblock 180 72 -157 minecraft:air
setblock 183 72 -157 minecraft:air
fill 179 72 -156 181 72 -156 minecraft:air
fill 178 72 -155 182 72 -155 minecraft:air
fill 179 72 -154 181 72 -154 minecraft:air
setblock 180 72 -153 minecraft:air
fill 194 72 -153 196 72 -153 minecraft:air
setblock 179 72 -152 minecraft:air
setblock 188 72 -152 minecraft:air
fill 193 72 -152 197 72 -152 minecraft:air
setblock 189 72 -151 minecraft:air
fill 193 72 -151 197 72 -151 minecraft:air
setblock 188 72 -150 minecraft:air
setblock 190 72 -150 minecraft:air
fill 193 72 -150 197 72 -150 minecraft:air
setblock 136 72 -149 minecraft:air
fill 176 72 -149 180 72 -149 minecraft:air
setblock 189 72 -149 minecraft:air
fill 194 72 -149 196 72 -149 minecraft:air
fill 175 72 -148 181 72 -148 minecraft:air
setblock 185 72 -148 minecraft:air
fill 175 72 -147 181 72 -147 minecraft:air
setblock 183 72 -147 minecraft:air
setblock 186 72 -147 minecraft:air
setblock 199 72 -147 minecraft:air
fill 175 72 -146 182 72 -146 minecraft:air
setblock 184 72 -146 minecraft:air
setblock 199 72 -146 minecraft:air
setblock 150 72 -145 minecraft:air
fill 175 72 -145 181 72 -145 minecraft:air
setblock 191 72 -145 minecraft:air
fill 194 72 -145 199 72 -145 minecraft:air
fill 149 72 -144 151 72 -144 minecraft:air
fill 153 72 -144 155 72 -144 minecraft:air
fill 175 72 -144 181 72 -144 minecraft:air
fill 192 72 -144 199 72 -144 minecraft:air
fill 148 72 -143 155 72 -143 minecraft:air
fill 176 72 -143 180 72 -143 minecraft:air
setblock 191 72 -143 minecraft:air
fill 193 72 -143 199 72 -143 minecraft:air
fill 149 72 -142 151 72 -142 minecraft:air
fill 153 72 -142 155 72 -142 minecraft:air
fill 193 72 -142 199 72 -142 minecraft:air
setblock 150 72 -141 minecraft:air
fill 193 72 -141 199 72 -141 minecraft:air
setblock 150 72 -140 minecraft:air
fill 193 72 -140 199 72 -140 minecraft:air
setblock 142 72 -139 minecraft:air
setblock 147 72 -139 minecraft:air
fill 194 72 -139 198 72 -139 minecraft:air
setblock 139 72 -138 minecraft:air
fill 141 72 -138 143 72 -138 minecraft:air
fill 146 72 -138 148 72 -138 minecraft:air
setblock 142 72 -137 minecraft:air
fill 145 72 -137 149 72 -137 minecraft:air
setblock 157 72 -137 minecraft:air
fill 146 72 -136 148 72 -136 minecraft:air
fill 156 72 -136 158 72 -136 minecraft:air
setblock 185 72 -136 minecraft:air
setblock 187 72 -136 minecraft:air
setblock 147 72 -135 minecraft:air
fill 156 72 -135 157 72 -135 minecraft:air
fill 185 72 -135 187 72 -135 minecraft:air
setblock 141 72 -134 minecraft:air
fill 185 72 -134 187 72 -134 minecraft:air
setblock 186 72 -133 minecraft:air
setblock 143 72 -132 minecraft:air
setblock 196 72 -132 minecraft:air
fill 156 72 -131 158 72 -131 minecraft:air
fill 189 72 -131 191 72 -131 minecraft:air
fill 195 72 -131 197 72 -131 minecraft:air
setblock 144 72 -130 minecraft:air
fill 155 72 -130 162 72 -130 minecraft:air
fill 188 72 -130 192 72 -130 minecraft:air
setblock 196 72 -130 minecraft:air
fill 155 72 -129 163 72 -129 minecraft:air
setblock 184 72 -129 minecraft:air
fill 188 72 -129 192 72 -129 minecraft:air
fill 196 72 -129 199 72 -129 minecraft:air
setblock 149 72 -128 minecraft:air
fill 155 72 -128 162 72 -128 minecraft:air
fill 183 72 -128 185 72 -128 minecraft:air
fill 188 72 -128 192 72 -128 minecraft:air
fill 196 72 -128 199 72 -128 minecraft:air
setblock 152 72 -127 minecraft:air
fill 156 72 -127 162 72 -127 minecraft:air
fill 180 72 -127 184 72 -127 minecraft:air
fill 188 72 -127 192 72 -127 minecraft:air
fill 196 72 -127 199 72 -127 minecraft:air
fill 153 73 -188 155 73 -188 minecraft:air
fill 166 73 -188 167 73 -188 minecraft:air
fill 153 73 -187 155 73 -187 minecraft:air
fill 163 73 -187 165 73 -187 minecraft:air
setblock 167 73 -187 minecraft:air
fill 153 73 -186 155 73 -186 minecraft:air
fill 163 73 -186 165 73 -186 minecraft:air
fill 163 73 -185 165 73 -185 minecraft:air
setblock 161 73 -183 minecraft:air
fill 160 73 -182 162 73 -182 minecraft:air
fill 159 73 -181 163 73 -181 minecraft:air
fill 160 73 -180 162 73 -180 minecraft:air
setblock 161 73 -179 minecraft:air
fill 158 73 -178 160 73 -178 minecraft:air
fill 155 73 -177 160 73 -177 minecraft:air
fill 155 73 -176 160 73 -176 minecraft:air
fill 155 73 -175 157 73 -175 minecraft:air
setblock 163 73 -174 minecraft:air
fill 162 73 -173 164 73 -173 minecraft:air
fill 161 73 -172 165 73 -172 minecraft:air
fill 162 73 -171 164 73 -171 minecraft:air
setblock 163 73 -170 minecraft:air
setblock 161 73 -168 minecraft:air
fill 160 73 -167 162 73 -167 minecraft:air
setblock 161 73 -166 minecraft:air
setblock 160 73 -163 minecraft:air
fill 159 73 -162 160 73 -162 minecraft:air
setblock 162 73 -162 minecraft:air
setblock 159 73 -161 minecraft:air
fill 161 73 -161 163 73 -161 minecraft:air
fill 158 73 -160 164 73 -160 minecraft:air
fill 157 73 -159 163 73 -159 minecraft:air
fill 158 73 -158 160 73 -158 minecraft:air
setblock 162 73 -158 minecraft:air
setblock 159 73 -157 minecraft:air
fill 179 73 -156 181 73 -156 minecraft:air
fill 179 73 -155 181 73 -155 minecraft:air
fill 179 73 -154 181 73 -154 minecraft:air
fill 178 73 -153 180 73 -153 minecraft:air
fill 177 73 -152 181 73 -152 minecraft:air
setblock 195 73 -152 minecraft:air
fill 178 73 -151 180 73 -151 minecraft:air
setblock 189 73 -151 minecraft:air
fill 194 73 -151 196 73 -151 minecraft:air
setblock 179 73 -150 minecraft:air
setblock 190 73 -150 minecraft:air
setblock 195 73 -150 minecraft:air
fill 177 73 -148 179 73 -148 minecraft:air
fill 176 73 -147 180 73 -147 minecraft:air
setblock 183 73 -147 minecraft:air
setblock 186 73 -147 minecraft:air
fill 176 73 -146 180 73 -146 minecraft:air
fill 176 73 -145 180 73 -145 minecraft:air
setblock 191 73 -145 minecraft:air
fill 149 73 -144 151 73 -144 minecraft:air
setblock 154 73 -144 minecraft:air
fill 177 73 -144 179 73 -144 minecraft:air
setblock 192 73 -144 minecraft:air
fill 195 73 -144 197 73 -144 minecraft:air
fill 149 73 -143 151 73 -143 minecraft:air
fill 153 73 -143 155 73 -143 minecraft:air
setblock 191 73 -143 minecraft:air
fill 194 73 -143 198 73 -143 minecraft:air
fill 149 73 -142 151 73 -142 minecraft:air
setblock 154 73 -142 minecraft:air
fill 194 73 -142 198 73 -142 minecraft:air
fill 194 73 -141 198 73 -141 minecraft:air
setblock 150 73 -140 minecraft:air
fill 195 73 -140 197 73 -140 minecraft:air
setblock 139 73 -138 minecraft:air
setblock 142 73 -138 minecraft:air
fill 146 73 -138 148 73 -138 minecraft:air
setblock 142 73 -137 minecraft:air
fill 146 73 -137 148 73 -137 minecraft:air
setblock 157 73 -137 minecraft:air
setblock 141 73 -136 minecraft:air
fill 146 73 -136 148 73 -136 minecraft:air
fill 156 73 -136 158 73 -136 minecraft:air
setblock 185 73 -136 minecraft:air
setblock 187 73 -136 minecraft:air
fill 140 73 -135 142 73 -135 minecraft:air
fill 156 73 -135 157 73 -135 minecraft:air
fill 185 73 -135 187 73 -135 minecraft:air
fill 139 73 -134 143 73 -134 minecraft:air
fill 185 73 -134 186 73 -134 minecraft:air
fill 194 73 -134 198 73 -134 minecraft:air
fill 140 73 -133 142 73 -133 minecraft:air
fill 193 73 -133 199 73 -133 minecraft:air
setblock 141 73 -132 minecraft:air
setblock 143 73 -132 minecraft:air
fill 193 73 -132 199 73 -132 minecraft:air
fill 182 73 -131 186 73 -131 minecraft:air
fill 188 73 -131 199 73 -131 minecraft:air
setblock 144 73 -130 minecraft:air
setblock 157 73 -130 minecraft:air
fill 159 73 -130 161 73 -130 minecraft:air
fill 181 73 -130 199 73 -130 minecraft:air
fill 156 73 -129 162 73 -129 minecraft:air
fill 181 73 -129 199 73 -129 minecraft:air
setblock 149 73 -128 minecraft:air
fill 157 73 -128 162 73 -128 minecraft:air
fill 181 73 -128 192 73 -128 minecraft:air
fill 194 73 -128 199 73 -128 minecraft:air
setblock 145 73 -127 minecraft:air
fill 148 73 -127 152 73 -127 minecraft:air
fill 158 73 -127 162 73 -127 minecraft:air
fill 181 73 -127 187 73 -127 minecraft:air
fill 189 73 -127 192 73 -127 minecraft:air
fill 196 73 -127 199 73 -127 minecraft:air
setblock 154 74 -188 minecraft:air
setblock 166 74 -188 minecraft:air
fill 153 74 -187 155 74 -187 minecraft:air
setblock 164 74 -187 minecraft:air
setblock 154 74 -186 minecraft:air
fill 163 74 -186 165 74 -186 minecraft:air
setblock 164 74 -185 minecraft:air
fill 160 74 -182 162 74 -182 minecraft:air
fill 160 74 -181 162 74 -181 minecraft:air
fill 160 74 -180 162 74 -180 minecraft:air
setblock 159 74 -178 minecraft:air
setblock 156 74 -177 minecraft:air
fill 158 74 -177 160 74 -177 minecraft:air
fill 155 74 -176 157 74 -176 minecraft:air
setblock 159 74 -176 minecraft:air
setblock 156 74 -175 minecraft:air
fill 162 74 -173 164 74 -173 minecraft:air
fill 162 74 -172 164 74 -172 minecraft:air
fill 162 74 -171 164 74 -171 minecraft:air
fill 160 74 -167 162 74 -167 minecraft:air
fill 161 74 -161 163 74 -161 minecraft:air
fill 158 74 -160 163 74 -160 minecraft:air
fill 158 74 -159 163 74 -159 minecraft:air
fill 158 74 -158 160 74 -158 minecraft:air
setblock 180 74 -156 minecraft:air
fill 179 74 -155 181 74 -155 minecraft:air
setblock 180 74 -154 minecraft:air
fill 178 74 -153 180 74 -153 minecraft:air
fill 192 74 -153 198 74 -153 minecraft:air
fill 178 74 -152 180 74 -152 minecraft:air
fill 192 74 -152 198 74 -152 minecraft:air
fill 178 74 -151 180 74 -151 minecraft:air
setblock 189 74 -151 minecraft:air
fill 192 74 -151 198 74 -151 minecraft:air
setblock 188 74 -150 minecraft:air
setblock 190 74 -150 minecraft:air
fill 192 74 -150 198 74 -150 minecraft:air
fill 192 74 -149 199 74 -149 minecraft:air
fill 193 74 -148 199 74 -148 minecraft:air
setblock 178 74 -147 minecraft:air
fill 198 74 -147 199 74 -147 minecraft:air
fill 177 74 -146 179 74 -146 minecraft:air
fill 198 74 -146 199 74 -146 minecraft:air
setblock 178 74 -145 minecraft:air
fill 198 74 -145 199 74 -145 minecraft:air
setblock 150 74 -144 minecraft:air
setblock 192 74 -144 minecraft:air
fill 198 74 -144 199 74 -144 minecraft:air
fill 149 74 -143 151 74 -143 minecraft:air
fill 153 74 -143 155 74 -143 minecraft:air
setblock 191 74 -143 minecraft:air
setblock 196 74 -143 minecraft:air
setblock 199 74 -143 minecraft:air
setblock 150 74 -142 minecraft:air
fill 195 74 -142 197 74 -142 minecraft:air
fill 149 74 -141 151 74 -141 minecraft:air
setblock 196 74 -141 minecraft:air
fill 148 74 -140 152 74 -140 minecraft:air
fill 149 74 -139 151 74 -139 minecraft:air
setblock 139 74 -138 minecraft:air
setblock 147 74 -138 minecraft:air
setblock 150 74 -138 minecraft:air
fill 146 74 -137 148 74 -137 minecraft:air
setblock 147 74 -136 minecraft:air
setblock 157 74 -136 minecraft:air
setblock 185 74 -136 minecraft:air
setblock 187 74 -136 minecraft:air
fill 140 74 -135 142 74 -135 minecraft:air
fill 185 74 -135 187 74 -135 minecraft:air
fill 140 74 -134 142 74 -134 minecraft:air
fill 185 74 -134 186 74 -134 minecraft:air
fill 140 74 -133 142 74 -133 minecraft:air
fill 195 74 -133 197 74 -133 minecraft:air
fill 143 74 -132 144 74 -132 minecraft:air
fill 194 74 -132 198 74 -132 minecraft:air
fill 143 74 -131 145 74 -131 minecraft:air
fill 194 74 -131 198 74 -131 minecraft:air
fill 142 74 -130 146 74 -130 minecraft:air
fill 183 74 -130 185 74 -130 minecraft:air
fill 189 74 -130 191 74 -130 minecraft:air
fill 194 74 -130 198 74 -130 minecraft:air
fill 143 74 -129 145 74 -129 minecraft:air
setblock 160 74 -129 minecraft:air
fill 182 74 -129 186 74 -129 minecraft:air
fill 188 74 -129 191 74 -129 minecraft:air
fill 195 74 -129 198 74 -129 minecraft:air
setblock 141 74 -128 minecraft:air
setblock 144 74 -128 minecraft:air
setblock 149 74 -128 minecraft:air
fill 159 74 -128 161 74 -128 minecraft:air
fill 182 74 -128 186 74 -128 minecraft:air
fill 189 74 -128 191 74 -128 minecraft:air
fill 197 74 -128 199 74 -128 minecraft:air
fill 140 74 -127 142 74 -127 minecraft:air
setblock 152 74 -127 minecraft:air
setblock 160 74 -127 minecraft:air
fill 182 74 -127 186 74 -127 minecraft:air
setblock 190 74 -127 minecraft:air
fill 196 74 -127 199 74 -127 minecraft:air
fill 153 75 -187 155 75 -187 minecraft:air
setblock 164 75 -187 minecraft:air
fill 163 75 -186 164 75 -186 minecraft:air
setblock 161 75 -182 minecraft:air
fill 160 75 -181 162 75 -181 minecraft:air
setblock 161 75 -180 minecraft:air
fill 159 75 -177 160 75 -177 minecraft:air
setblock 156 75 -176 minecraft:air
setblock 159 75 -176 minecraft:air
setblock 156 75 -175 minecraft:air
setblock 163 75 -173 minecraft:air
fill 162 75 -172 164 75 -172 minecraft:air
setblock 163 75 -171 minecraft:air
setblock 162 75 -161 minecraft:air
setblock 159 75 -160 minecraft:air
fill 161 75 -160 163 75 -160 minecraft:air
fill 158 75 -159 160 75 -159 minecraft:air
setblock 162 75 -159 minecraft:air
setblock 159 75 -158 minecraft:air
setblock 180 75 -156 minecraft:air
fill 179 75 -155 181 75 -155 minecraft:air
setblock 180 75 -154 minecraft:air
setblock 179 75 -153 minecraft:air
fill 194 75 -153 196 75 -153 minecraft:air
fill 178 75 -152 180 75 -152 minecraft:air
fill 193 75 -152 197 75 -152 minecraft:air
setblock 179 75 -151 minecraft:air
setblock 189 75 -151 minecraft:air
fill 193 75 -151 197 75 -151 minecraft:air
fill 193 75 -150 197 75 -150 minecraft:air
fill 194 75 -149 196 75 -149 minecraft:air
fill 177 75 -148 179 75 -148 minecraft:air
fill 176 75 -147 180 75 -147 minecraft:air
setblock 199 75 -147 minecraft:air
fill 176 75 -146 180 75 -146 minecraft:air
setblock 199 75 -146 minecraft:air
fill 176 75 -145 180 75 -145 minecraft:air
fill 194 75 -145 199 75 -145 minecraft:air
setblock 150 75 -144 minecraft:air
fill 177 75 -144 179 75 -144 minecraft:air
fill 192 75 -144 199 75 -144 minecraft:air
fill 149 75 -143 151 75 -143 minecraft:air
fill 193 75 -143 199 75 -143 minecraft:air
fill 193 75 -142 199 75 -142 minecraft:air
fill 149 75 -141 151 75 -141 minecraft:air
fill 193 75 -141 199 75 -141 minecraft:air
setblock 139 75 -140 minecraft:air
fill 149 75 -140 151 75 -140 minecraft:air
fill 193 75 -140 199 75 -140 minecraft:air
fill 138 75 -139 140 75 -139 minecraft:air
fill 149 75 -139 151 75 -139 minecraft:air
fill 194 75 -139 198 75 -139 minecraft:air
fill 137 75 -138 141 75 -138 minecraft:air
setblock 147 75 -138 minecraft:air
fill 138 75 -137 140 75 -137 minecraft:air
fill 146 75 -137 148 75 -137 minecraft:air
setblock 139 75 -136 minecraft:air
setblock 141 75 -135 minecraft:air
setblock 186 75 -135 minecraft:air
fill 140 75 -134 143 75 -134 minecraft:air
fill 141 75 -133 144 75 -133 minecraft:air
fill 141 75 -132 145 75 -132 minecraft:air
setblock 196 75 -132 minecraft:air
fill 142 75 -131 145 75 -131 minecraft:air
fill 195 75 -131 197 75 -131 minecraft:air
fill 143 75 -130 145 75 -130 minecraft:air
fill 190 75 -130 191 75 -130 minecraft:air
setblock 196 75 -130 minecraft:air
fill 143 75 -129 145 75 -129 minecraft:air
setblock 184 75 -129 minecraft:air
fill 189 75 -129 191 75 -129 minecraft:air
setblock 149 75 -128 minecraft:air
fill 183 75 -128 185 75 -128 minecraft:air
fill 189 75 -128 191 75 -128 minecraft:air
fill 197 75 -128 198 75 -128 minecraft:air
fill 140 75 -127 142 75 -127 minecraft:air
setblock 152 75 -127 minecraft:air
fill 180 75 -127 184 75 -127 minecraft:air
fill 197 75 -127 199 75 -127 minecraft:air
fill 161 76 -181 162 76 -181 minecraft:air
setblock 163 76 -173 minecraft:air
setblock 163 76 -172 minecraft:air
setblock 159 76 -160 minecraft:air
fill 161 76 -160 163 76 -160 minecraft:air
fill 158 76 -159 159 76 -159 minecraft:air
setblock 159 76 -158 minecraft:air
fill 178 76 -152 180 76 -152 minecraft:air
setblock 195 76 -152 minecraft:air
fill 194 76 -151 196 76 -151 minecraft:air
setblock 195 76 -150 minecraft:air
setblock 178 76 -147 minecraft:air
fill 177 76 -146 179 76 -146 minecraft:air
setblock 178 76 -145 minecraft:air
fill 195 76 -144 197 76 -144 minecraft:air
fill 194 76 -143 198 76 -143 minecraft:air
fill 194 76 -142 198 76 -142 minecraft:air
setblock 150 76 -141 minecraft:air
fill 194 76 -141 198 76 -141 minecraft:air
fill 149 76 -140 151 76 -140 minecraft:air
fill 195 76 -140 197 76 -140 minecraft:air
fill 138 76 -139 140 76 -139 minecraft:air
setblock 150 76 -139 minecraft:air
fill 138 76 -138 140 76 -138 minecraft:air
fill 138 76 -137 140 76 -137 minecraft:air
setblock 141 76 -135 minecraft:air
setblock 141 76 -134 minecraft:air
fill 194 76 -134 198 76 -134 minecraft:air
fill 142 76 -133 144 76 -133 minecraft:air
fill 193 76 -133 199 76 -133 minecraft:air
fill 142 76 -132 144 76 -132 minecraft:air
fill 193 76 -132 199 76 -132 minecraft:air
fill 142 76 -131 144 76 -131 minecraft:air
fill 182 76 -131 186 76 -131 minecraft:air
fill 193 76 -131 199 76 -131 minecraft:air
fill 143 76 -130 145 76 -130 minecraft:air
fill 181 76 -130 187 76 -130 minecraft:air
fill 189 76 -130 190 76 -130 minecraft:air
fill 193 76 -130 199 76 -130 minecraft:air
setblock 144 76 -129 minecraft:air
fill 181 76 -129 187 76 -129 minecraft:air
fill 189 76 -129 191 76 -129 minecraft:air
fill 193 76 -129 199 76 -129 minecraft:air
setblock 149 76 -128 minecraft:air
fill 181 76 -128 187 76 -128 minecraft:air
fill 189 76 -128 190 76 -128 minecraft:air
fill 194 76 -128 199 76 -128 minecraft:air
setblock 141 76 -127 minecraft:air
fill 148 76 -127 152 76 -127 minecraft:air
fill 181 76 -127 187 76 -127 minecraft:air
fill 197 76 -127 199 76 -127 minecraft:air
fill 192 77 -153 196 77 -153 minecraft:air
fill 192 77 -152 196 77 -152 minecraft:air
fill 192 77 -151 196 77 -151 minecraft:air
fill 192 77 -150 197 77 -150 minecraft:air
fill 192 77 -149 199 77 -149 minecraft:air
fill 193 77 -148 199 77 -148 minecraft:air
fill 198 77 -147 199 77 -147 minecraft:air
setblock 178 77 -146 minecraft:air
fill 198 77 -146 199 77 -146 minecraft:air
fill 198 77 -145 199 77 -145 minecraft:air
fill 198 77 -144 199 77 -144 minecraft:air
setblock 196 77 -143 minecraft:air
setblock 199 77 -143 minecraft:air
fill 195 77 -142 197 77 -142 minecraft:air
setblock 196 77 -141 minecraft:air
fill 149 77 -140 150 77 -140 minecraft:air
setblock 139 77 -139 minecraft:air
setblock 150 77 -139 minecraft:air
fill 138 77 -138 140 77 -138 minecraft:air
setblock 139 77 -137 minecraft:air
setblock 143 77 -133 minecraft:air
fill 195 77 -133 197 77 -133 minecraft:air
fill 142 77 -132 144 77 -132 minecraft:air
fill 194 77 -132 198 77 -132 minecraft:air
setblock 143 77 -131 minecraft:air
fill 194 77 -131 198 77 -131 minecraft:air
fill 143 77 -130 144 77 -130 minecraft:air
fill 183 77 -130 185 77 -130 minecraft:air
fill 194 77 -130 198 77 -130 minecraft:air
fill 182 77 -129 186 77 -129 minecraft:air
setblock 190 77 -129 minecraft:air
fill 195 77 -129 197 77 -129 minecraft:air
setblock 149 77 -128 minecraft:air
fill 182 77 -128 186 77 -128 minecraft:air
setblock 141 77 -127 minecraft:air
setblock 152 77 -127 minecraft:air
fill 182 77 -127 186 77 -127 minecraft:air
setblock 198 77 -127 minecraft:air
fill 194 78 -153 196 78 -153 minecraft:air
fill 193 78 -152 196 78 -152 minecraft:air
fill 193 78 -151 196 78 -151 minecraft:air
fill 193 78 -150 196 78 -150 minecraft:air
fill 194 78 -149 196 78 -149 minecraft:air
setblock 198 78 -149 minecraft:air
setblock 178 78 -147 minecraft:air
setblock 199 78 -147 minecraft:air
fill 177 78 -146 179 78 -146 minecraft:air
setblock 199 78 -146 minecraft:air
setblock 178 78 -145 minecraft:air
fill 194 78 -145 199 78 -145 minecraft:air
fill 193 78 -144 199 78 -144 minecraft:air
fill 193 78 -143 199 78 -143 minecraft:air
fill 193 78 -142 199 78 -142 minecraft:air
fill 193 78 -141 199 78 -141 minecraft:air
fill 193 78 -140 199 78 -140 minecraft:air
setblock 139 78 -139 minecraft:air
fill 194 78 -139 198 78 -139 minecraft:air
setblock 139 78 -138 minecraft:air
setblock 139 78 -137 minecraft:air
setblock 143 78 -133 minecraft:air
fill 143 78 -132 144 78 -132 minecraft:air
setblock 196 78 -132 minecraft:air
fill 195 78 -131 197 78 -131 minecraft:air
setblock 149 78 -130 minecraft:air
setblock 196 78 -130 minecraft:air
fill 148 78 -129 150 78 -129 minecraft:air
setblock 152 78 -129 minecraft:air
setblock 184 78 -129 minecraft:air
fill 147 78 -128 153 78 -128 minecraft:air
fill 183 78 -128 185 78 -128 minecraft:air
fill 148 78 -127 154 78 -127 minecraft:air
setblock 184 78 -127 minecraft:air
setblock 195 79 -152 minecraft:air
fill 194 79 -151 196 79 -151 minecraft:air
setblock 195 79 -150 minecraft:air
setblock 198 79 -149 minecraft:air
fill 195 79 -144 197 79 -144 minecraft:air
fill 194 79 -143 198 79 -143 minecraft:air
fill 194 79 -142 198 79 -142 minecraft:air
fill 194 79 -141 198 79 -141 minecraft:air
fill 195 79 -140 197 79 -140 minecraft:air
fill 195 79 -133 197 79 -133 minecraft:air
fill 194 79 -132 198 79 -132 minecraft:air
fill 182 79 -131 186 79 -131 minecraft:air
fill 194 79 -131 198 79 -131 minecraft:air
fill 181 79 -130 187 79 -130 minecraft:air
fill 194 79 -130 198 79 -130 minecraft:air
fill 148 79 -129 150 79 -129 minecraft:air
fill 181 79 -129 187 79 -129 minecraft:air
fill 195 79 -129 197 79 -129 minecraft:air
fill 148 79 -128 153 79 -128 minecraft:air
fill 181 79 -128 187 79 -128 minecraft:air
fill 148 79 -127 153 79 -127 minecraft:air
fill 181 79 -127 187 79 -127 minecraft:air
fill 194 80 -153 196 80 -153 minecraft:air
fill 193 80 -152 196 80 -152 minecraft:air
fill 193 80 -151 196 80 -151 minecraft:air
fill 193 80 -150 196 80 -150 minecraft:air
fill 194 80 -149 196 80 -149 minecraft:air
setblock 198 80 -149 minecraft:air
setblock 199 80 -147 minecraft:air
setblock 199 80 -146 minecraft:air
setblock 199 80 -145 minecraft:air
setblock 196 80 -143 minecraft:air
fill 195 80 -142 197 80 -142 minecraft:air
setblock 196 80 -141 minecraft:air
setblock 196 80 -132 minecraft:air
fill 195 80 -131 197 80 -131 minecraft:air
fill 183 80 -130 185 80 -130 minecraft:air
setblock 196 80 -130 minecraft:air
setblock 149 80 -129 minecraft:air
fill 182 80 -129 186 80 -129 minecraft:air
fill 148 80 -128 150 80 -128 minecraft:air
setblock 152 80 -128 minecraft:air
fill 182 80 -128 186 80 -128 minecraft:air
setblock 149 80 -127 minecraft:air
fill 151 80 -127 153 80 -127 minecraft:air
fill 182 80 -127 186 80 -127 minecraft:air
setblock 196 81 -131 minecraft:air
setblock 184 81 -129 minecraft:air
fill 149 81 -128 150 81 -128 minecraft:air
fill 183 81 -128 185 81 -128 minecraft:air
fill 151 81 -127 152 81 -127 minecraft:air
setblock 184 81 -127 minecraft:air
setblock 196 82 -132 minecraft:air
fill 195 82 -131 197 82 -131 minecraft:air
fill 183 82 -130 185 82 -130 minecraft:air
setblock 196 82 -130 minecraft:air
fill 182 82 -129 186 82 -129 minecraft:air
fill 182 82 -128 186 82 -128 minecraft:air
fill 182 82 -127 186 82 -127 minecraft:air
setblock 184 83 -129 minecraft:air
fill 183 83 -128 185 83 -128 minecraft:air
setblock 184 83 -127 minecraft:air
setblock 184 84 -128 minecraft:air
setblock 193 85 -190 minecraft:sea_lantern
setblock 194 85 -189 minecraft:sea_lantern
setblock 194 85 -188 minecraft:sea_lantern
setblock 197 85 -183 minecraft:sea_lantern
setblock 197 85 -182 minecraft:sea_lantern
setblock 196 85 -142 minecraft:air
setblock 184 85 -129 minecraft:air
fill 183 85 -128 185 85 -128 minecraft:air
setblock 184 85 -127 minecraft:air
forceload remove 136 -190 199 -127
tellraw @a {"text":"Campus bau a31 fertig.","color":"green"}
