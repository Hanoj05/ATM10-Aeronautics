# Abschnitt a24: x 136..199, z -254..-191 (22434 Blöcke)
forceload add 136 -254 199 -191
tellraw @a {"text":"Campus bau a24: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a24_1 2s
