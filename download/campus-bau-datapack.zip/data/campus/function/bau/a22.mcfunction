# Abschnitt a22: x 8..71, z -254..-191 (19623 Blöcke)
forceload add 8 -254 71 -191
tellraw @a {"text":"Campus bau a22: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a22_1 2s
