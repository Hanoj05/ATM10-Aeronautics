# Abschnitt a33: x 264..327, z -190..-127 (12362 Blöcke)
forceload add 264 -190 327 -127
tellraw @a {"text":"Campus bau a33: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a33_1 2s
