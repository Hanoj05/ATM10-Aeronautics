fill 408 45 -437 409 45 -437 minecraft:stone
fill 409 45 -436 410 45 -436 minecraft:stone
fill 410 45 -435 411 45 -435 minecraft:stone
fill 411 45 -434 412 45 -434 minecraft:stone
fill 412 45 -433 413 45 -433 minecraft:stone
fill 412 45 -432 414 45 -432 minecraft:stone
fill 413 45 -431 415 45 -431 minecraft:stone
fill 413 45 -430 415 45 -430 minecraft:stone
fill 414 45 -429 416 45 -429 minecraft:stone
fill 415 45 -428 417 45 -428 minecraft:stone
fill 415 45 -427 417 45 -427 minecraft:stone
fill 416 45 -426 418 45 -426 minecraft:stone
fill 417 45 -425 418 45 -425 minecraft:stone
fill 417 45 -424 419 45 -424 minecraft:stone
fill 417 45 -423 419 45 -423 minecraft:stone
fill 417 45 -422 419 45 -422 minecraft:stone
fill 418 45 -421 420 45 -421 minecraft:stone
fill 418 45 -420 420 45 -420 minecraft:stone
setblock 410 45 -419 minecraft:stone
fill 418 45 -419 420 45 -419 minecraft:stone
setblock 410 45 -418 minecraft:stone
fill 418 45 -418 421 45 -418 minecraft:stone
fill 409 45 -417 410 45 -417 minecraft:stone
fill 418 45 -417 421 45 -417 minecraft:stone
setblock 409 45 -416 minecraft:stone
fill 419 45 -416 421 45 -416 minecraft:stone
fill 419 45 -415 421 45 -415 minecraft:stone
fill 419 45 -414 421 45 -414 minecraft:stone
fill 419 45 -413 421 45 -413 minecraft:stone
fill 419 45 -412 421 45 -412 minecraft:stone
fill 419 45 -411 421 45 -411 minecraft:stone
fill 419 45 -410 422 45 -410 minecraft:stone
fill 419 45 -409 422 45 -409 minecraft:stone
setblock 419 45 -408 minecraft:stone
fill 421 45 -408 422 45 -408 minecraft:stone
setblock 419 45 -407 minecraft:stone
fill 421 45 -407 422 45 -407 minecraft:stone
setblock 419 45 -406 minecraft:stone
setblock 422 45 -406 minecraft:stone
setblock 419 45 -405 minecraft:stone
fill 421 45 -405 422 45 -405 minecraft:stone
setblock 419 45 -404 minecraft:stone
setblock 422 45 -404 minecraft:stone
setblock 419 45 -403 minecraft:stone
setblock 422 45 -403 minecraft:stone
setblock 419 45 -402 minecraft:stone
setblock 422 45 -402 minecraft:stone
setblock 419 45 -401 minecraft:stone
setblock 419 45 -400 minecraft:stone
setblock 422 45 -400 minecraft:stone
setblock 419 45 -399 minecraft:stone
setblock 422 45 -399 minecraft:stone
setblock 419 45 -398 minecraft:stone
setblock 419 45 -397 minecraft:stone
setblock 419 45 -396 minecraft:stone
setblock 419 45 -395 minecraft:stone
setblock 419 45 -394 minecraft:stone
setblock 419 45 -393 minecraft:stone
setblock 419 45 -392 minecraft:stone
setblock 419 45 -391 minecraft:stone
setblock 419 45 -390 minecraft:stone
setblock 419 45 -389 minecraft:stone
setblock 419 45 -388 minecraft:stone
setblock 419 45 -387 minecraft:stone
setblock 419 45 -386 minecraft:stone
setblock 419 45 -385 minecraft:stone
setblock 419 45 -384 minecraft:stone
setblock 419 45 -383 minecraft:stone
fill 408 46 -437 409 46 -437 minecraft:stone
fill 409 46 -436 410 46 -436 minecraft:stone
fill 410 46 -435 411 46 -435 minecraft:stone
fill 411 46 -434 412 46 -434 minecraft:stone
fill 412 46 -433 413 46 -433 minecraft:stone
fill 412 46 -432 414 46 -432 minecraft:stone
fill 412 46 -431 415 46 -431 minecraft:stone
fill 413 46 -430 415 46 -430 minecraft:stone
fill 414 46 -429 416 46 -429 minecraft:stone
fill 415 46 -428 417 46 -428 minecraft:stone
fill 415 46 -427 417 46 -427 minecraft:stone
fill 416 46 -426 418 46 -426 minecraft:stone
fill 417 46 -425 418 46 -425 minecraft:stone
fill 417 46 -424 419 46 -424 minecraft:stone
fill 417 46 -423 419 46 -423 minecraft:stone
fill 417 46 -422 419 46 -422 minecraft:stone
fill 418 46 -421 420 46 -421 minecraft:stone
fill 418 46 -420 420 46 -420 minecraft:stone
fill 418 46 -419 420 46 -419 minecraft:stone
fill 408 46 -418 409 46 -418 minecraft:stone
fill 418 46 -418 421 46 -418 minecraft:stone
fill 409 46 -417 410 46 -417 minecraft:stone
fill 418 46 -417 421 46 -417 minecraft:stone
setblock 409 46 -416 minecraft:stone
fill 419 46 -416 421 46 -416 minecraft:stone
fill 419 46 -415 421 46 -415 minecraft:stone
fill 419 46 -414 421 46 -414 minecraft:stone
fill 419 46 -413 421 46 -413 minecraft:stone
fill 419 46 -412 421 46 -412 minecraft:stone
fill 419 46 -411 421 46 -411 minecraft:stone
fill 419 46 -410 422 46 -410 minecraft:stone
fill 419 46 -409 422 46 -409 minecraft:stone
setblock 419 46 -408 minecraft:stone
fill 421 46 -408 422 46 -408 minecraft:stone
setblock 419 46 -407 minecraft:stone
fill 421 46 -407 422 46 -407 minecraft:stone
setblock 419 46 -406 minecraft:stone
fill 421 46 -406 422 46 -406 minecraft:stone
setblock 419 46 -405 minecraft:stone
fill 421 46 -405 422 46 -405 minecraft:stone
setblock 419 46 -404 minecraft:stone
setblock 422 46 -404 minecraft:stone
setblock 419 46 -403 minecraft:stone
setblock 422 46 -403 minecraft:stone
setblock 419 46 -402 minecraft:stone
setblock 422 46 -402 minecraft:stone
setblock 419 46 -401 minecraft:stone
setblock 419 46 -400 minecraft:stone
setblock 422 46 -400 minecraft:stone
setblock 419 46 -399 minecraft:stone
setblock 422 46 -399 minecraft:stone
setblock 419 46 -398 minecraft:stone
setblock 419 46 -397 minecraft:stone
setblock 419 46 -396 minecraft:stone
setblock 419 46 -395 minecraft:stone
setblock 419 46 -394 minecraft:stone
setblock 419 46 -393 minecraft:stone
setblock 419 46 -392 minecraft:stone
setblock 419 46 -391 minecraft:stone
setblock 419 46 -390 minecraft:stone
setblock 419 46 -389 minecraft:stone
setblock 419 46 -388 minecraft:stone
setblock 419 46 -387 minecraft:stone
setblock 419 46 -386 minecraft:stone
setblock 419 46 -385 minecraft:stone
setblock 419 46 -384 minecraft:stone
setblock 419 46 -383 minecraft:stone
fill 408 47 -437 409 47 -437 minecraft:stone
fill 409 47 -436 410 47 -436 minecraft:stone
fill 410 47 -435 411 47 -435 minecraft:stone
fill 411 47 -434 412 47 -434 minecraft:stone
fill 412 47 -433 413 47 -433 minecraft:stone
fill 412 47 -432 414 47 -432 minecraft:stone
fill 412 47 -431 415 47 -431 minecraft:stone
fill 413 47 -430 415 47 -430 minecraft:stone
fill 414 47 -429 416 47 -429 minecraft:stone
fill 415 47 -428 417 47 -428 minecraft:stone
fill 415 47 -427 417 47 -427 minecraft:stone
fill 416 47 -426 418 47 -426 minecraft:stone
fill 417 47 -425 418 47 -425 minecraft:stone
fill 417 47 -424 419 47 -424 minecraft:stone
fill 417 47 -423 419 47 -423 minecraft:stone
fill 417 47 -422 419 47 -422 minecraft:stone
fill 418 47 -421 420 47 -421 minecraft:stone
fill 418 47 -420 420 47 -420 minecraft:stone
fill 418 47 -419 420 47 -419 minecraft:stone
setblock 409 47 -418 minecraft:stone
fill 418 47 -418 421 47 -418 minecraft:stone
fill 408 47 -417 409 47 -417 minecraft:stone
fill 418 47 -417 421 47 -417 minecraft:stone
fill 408 47 -416 409 47 -416 minecraft:stone
fill 419 47 -416 421 47 -416 minecraft:stone
fill 408 47 -415 409 47 -415 minecraft:stone
fill 419 47 -415 421 47 -415 minecraft:stone
fill 419 47 -414 421 47 -414 minecraft:stone
fill 419 47 -413 421 47 -413 minecraft:stone
fill 420 47 -412 421 47 -412 minecraft:stone
fill 420 47 -411 421 47 -411 minecraft:stone
fill 420 47 -410 422 47 -410 minecraft:stone
fill 420 47 -409 422 47 -409 minecraft:stone
fill 421 47 -408 422 47 -408 minecraft:stone
fill 421 47 -407 422 47 -407 minecraft:stone
fill 421 47 -406 422 47 -406 minecraft:stone
fill 421 47 -405 422 47 -405 minecraft:stone
setblock 422 47 -404 minecraft:stone
setblock 422 47 -403 minecraft:stone
setblock 422 47 -402 minecraft:stone
setblock 422 47 -400 minecraft:stone
setblock 422 47 -399 minecraft:stone
fill 408 48 -437 409 48 -437 minecraft:stone
fill 409 48 -436 410 48 -436 minecraft:stone
fill 410 48 -435 411 48 -435 minecraft:stone
fill 411 48 -434 412 48 -434 minecraft:stone
fill 412 48 -433 413 48 -433 minecraft:stone
fill 412 48 -432 414 48 -432 minecraft:stone
fill 412 48 -431 415 48 -431 minecraft:stone
fill 413 48 -430 415 48 -430 minecraft:stone
fill 414 48 -429 416 48 -429 minecraft:stone
fill 415 48 -428 417 48 -428 minecraft:stone
fill 415 48 -427 417 48 -427 minecraft:stone
fill 416 48 -426 418 48 -426 minecraft:stone
fill 417 48 -425 418 48 -425 minecraft:stone
fill 417 48 -424 419 48 -424 minecraft:stone
fill 417 48 -423 419 48 -423 minecraft:stone
fill 417 48 -422 419 48 -422 minecraft:stone
fill 418 48 -421 420 48 -421 minecraft:stone
fill 418 48 -420 420 48 -420 minecraft:stone
fill 418 48 -419 420 48 -419 minecraft:stone
fill 418 48 -418 421 48 -418 minecraft:stone
fill 408 48 -417 409 48 -417 minecraft:stone
fill 418 48 -417 421 48 -417 minecraft:stone
fill 407 48 -416 409 48 -416 minecraft:stone
fill 419 48 -416 421 48 -416 minecraft:stone
fill 408 48 -415 409 48 -415 minecraft:stone
fill 419 48 -415 421 48 -415 minecraft:stone
setblock 408 48 -414 minecraft:stone
fill 419 48 -414 421 48 -414 minecraft:stone
fill 419 48 -413 421 48 -413 minecraft:stone
fill 419 48 -412 421 48 -412 minecraft:stone
fill 419 48 -411 421 48 -411 minecraft:stone
fill 419 48 -410 422 48 -410 minecraft:stone
fill 419 48 -409 422 48 -409 minecraft:stone
setblock 419 48 -408 minecraft:stone
fill 421 48 -408 422 48 -408 minecraft:stone
setblock 419 48 -407 minecraft:stone
fill 421 48 -407 422 48 -407 minecraft:stone
setblock 419 48 -406 minecraft:stone
fill 421 48 -406 422 48 -406 minecraft:stone
setblock 419 48 -405 minecraft:stone
fill 421 48 -405 422 48 -405 minecraft:stone
setblock 419 48 -404 minecraft:stone
setblock 422 48 -404 minecraft:stone
setblock 419 48 -403 minecraft:stone
setblock 422 48 -403 minecraft:stone
setblock 419 48 -402 minecraft:stone
setblock 422 48 -402 minecraft:stone
setblock 419 48 -401 minecraft:stone
setblock 419 48 -400 minecraft:stone
setblock 422 48 -400 minecraft:stone
setblock 419 48 -399 minecraft:stone
setblock 422 48 -399 minecraft:stone
setblock 419 48 -398 minecraft:stone
setblock 419 48 -397 minecraft:stone
setblock 419 48 -396 minecraft:stone
setblock 419 48 -395 minecraft:stone
setblock 419 48 -394 minecraft:stone
setblock 419 48 -393 minecraft:stone
setblock 419 48 -392 minecraft:stone
setblock 419 48 -391 minecraft:stone
setblock 419 48 -390 minecraft:stone
setblock 419 48 -389 minecraft:stone
setblock 419 48 -388 minecraft:stone
setblock 419 48 -387 minecraft:stone
setblock 419 48 -386 minecraft:stone
setblock 419 48 -385 minecraft:stone
setblock 419 48 -384 minecraft:stone
setblock 419 48 -383 minecraft:stone
setblock 392 49 -445 minecraft:stone
fill 392 49 -444 393 49 -444 minecraft:stone
fill 392 49 -443 393 49 -443 minecraft:stone
fill 392 49 -442 393 49 -442 minecraft:stone
fill 392 49 -441 394 49 -441 minecraft:stone
fill 392 49 -440 394 49 -440 minecraft:stone
fill 392 49 -439 393 49 -439 minecraft:stone
fill 408 49 -437 409 49 -437 minecraft:stone
fill 409 49 -436 410 49 -436 minecraft:stone
fill 410 49 -435 411 49 -435 minecraft:stone
fill 411 49 -434 412 49 -434 minecraft:stone
fill 412 49 -433 413 49 -433 minecraft:stone
fill 412 49 -432 414 49 -432 minecraft:stone
fill 412 49 -431 415 49 -431 minecraft:stone
fill 413 49 -430 415 49 -430 minecraft:stone
fill 414 49 -429 416 49 -429 minecraft:stone
fill 415 49 -428 417 49 -428 minecraft:stone
fill 415 49 -427 417 49 -427 minecraft:stone
fill 416 49 -426 418 49 -426 minecraft:stone
fill 417 49 -425 418 49 -425 minecraft:stone
fill 417 49 -424 419 49 -424 minecraft:stone
fill 417 49 -423 419 49 -423 minecraft:stone
fill 417 49 -422 419 49 -422 minecraft:stone
fill 418 49 -421 420 49 -421 minecraft:stone
fill 418 49 -420 420 49 -420 minecraft:stone
fill 418 49 -419 420 49 -419 minecraft:stone
fill 418 49 -418 421 49 -418 minecraft:stone
fill 418 49 -417 421 49 -417 minecraft:stone
setblock 408 49 -416 minecraft:stone
fill 419 49 -416 421 49 -416 minecraft:stone
fill 407 49 -415 409 49 -415 minecraft:stone
fill 419 49 -415 421 49 -415 minecraft:stone
setblock 408 49 -414 minecraft:stone
fill 419 49 -414 421 49 -414 minecraft:stone
fill 419 49 -413 421 49 -413 minecraft:stone
fill 420 49 -412 421 49 -412 minecraft:stone
fill 420 49 -411 421 49 -411 minecraft:stone
fill 420 49 -410 422 49 -410 minecraft:stone
fill 420 49 -409 422 49 -409 minecraft:stone
fill 421 49 -408 422 49 -408 minecraft:stone
fill 421 49 -407 422 49 -407 minecraft:stone
fill 421 49 -406 422 49 -406 minecraft:stone
fill 421 49 -405 422 49 -405 minecraft:stone
setblock 422 49 -404 minecraft:stone
setblock 422 49 -403 minecraft:stone
setblock 422 49 -402 minecraft:stone
setblock 422 49 -400 minecraft:stone
setblock 422 49 -399 minecraft:stone
setblock 392 50 -445 minecraft:stone
fill 392 50 -444 393 50 -444 minecraft:stone
fill 392 50 -443 393 50 -443 minecraft:stone
fill 392 50 -442 394 50 -442 minecraft:stone
fill 392 50 -441 394 50 -441 minecraft:stone
fill 392 50 -440 394 50 -440 minecraft:stone
fill 392 50 -439 394 50 -439 minecraft:stone
fill 392 50 -438 394 50 -438 minecraft:stone
fill 392 50 -437 393 50 -437 minecraft:stone
fill 408 50 -437 409 50 -437 minecraft:stone
setblock 392 50 -436 minecraft:stone
fill 409 50 -436 410 50 -436 minecraft:stone
fill 410 50 -435 411 50 -435 minecraft:stone
fill 411 50 -434 412 50 -434 minecraft:stone
fill 412 50 -433 413 50 -433 minecraft:stone
fill 412 50 -432 414 50 -432 minecraft:stone
fill 412 50 -431 415 50 -431 minecraft:stone
fill 413 50 -430 415 50 -430 minecraft:stone
fill 414 50 -429 416 50 -429 minecraft:stone
fill 415 50 -428 417 50 -428 minecraft:stone
fill 415 50 -427 417 50 -427 minecraft:stone
fill 416 50 -426 418 50 -426 minecraft:stone
fill 417 50 -425 418 50 -425 minecraft:stone
fill 417 50 -424 419 50 -424 minecraft:stone
fill 417 50 -423 419 50 -423 minecraft:stone
fill 417 50 -422 419 50 -422 minecraft:stone
fill 418 50 -421 420 50 -421 minecraft:stone
fill 418 50 -420 420 50 -420 minecraft:stone
fill 418 50 -419 420 50 -419 minecraft:stone
fill 418 50 -418 421 50 -418 minecraft:stone
fill 418 50 -417 421 50 -417 minecraft:stone
setblock 408 50 -416 minecraft:stone
fill 419 50 -416 421 50 -416 minecraft:stone
fill 407 50 -415 408 50 -415 minecraft:stone
fill 419 50 -415 421 50 -415 minecraft:stone
fill 407 50 -414 409 50 -414 minecraft:stone
fill 419 50 -414 421 50 -414 minecraft:stone
setblock 407 50 -413 minecraft:stone
fill 419 50 -413 421 50 -413 minecraft:stone
fill 420 50 -412 421 50 -412 minecraft:stone
fill 420 50 -411 421 50 -411 minecraft:stone
fill 420 50 -410 422 50 -410 minecraft:stone
fill 420 50 -409 422 50 -409 minecraft:stone
fill 421 50 -408 422 50 -408 minecraft:stone
fill 421 50 -407 422 50 -407 minecraft:stone
fill 421 50 -406 422 50 -406 minecraft:stone
fill 421 50 -405 422 50 -405 minecraft:stone
setblock 422 50 -404 minecraft:stone
setblock 422 50 -403 minecraft:stone
setblock 422 50 -402 minecraft:stone
setblock 422 50 -400 minecraft:stone
setblock 422 50 -399 minecraft:stone
setblock 392 51 -444 minecraft:stone
setblock 392 51 -443 minecraft:stone
fill 392 51 -442 393 51 -442 minecraft:stone
fill 392 51 -441 394 51 -441 minecraft:stone
fill 392 51 -440 394 51 -440 minecraft:stone
fill 392 51 -439 394 51 -439 minecraft:stone
fill 392 51 -438 394 51 -438 minecraft:stone
fill 392 51 -437 393 51 -437 minecraft:stone
fill 408 51 -437 409 51 -437 minecraft:stone
setblock 392 51 -436 minecraft:stone
fill 409 51 -436 410 51 -436 minecraft:stone
fill 410 51 -435 411 51 -435 minecraft:stone
fill 411 51 -434 412 51 -434 minecraft:stone
fill 412 51 -433 413 51 -433 minecraft:stone
fill 412 51 -432 414 51 -432 minecraft:stone
fill 412 51 -431 415 51 -431 minecraft:stone
fill 413 51 -430 415 51 -430 minecraft:stone
fill 414 51 -429 416 51 -429 minecraft:stone
fill 415 51 -428 417 51 -428 minecraft:stone
fill 415 51 -427 417 51 -427 minecraft:stone
fill 416 51 -426 418 51 -426 minecraft:stone
fill 417 51 -425 418 51 -425 minecraft:stone
fill 417 51 -424 419 51 -424 minecraft:stone
fill 417 51 -423 419 51 -423 minecraft:stone
fill 417 51 -422 419 51 -422 minecraft:stone
fill 418 51 -421 420 51 -421 minecraft:stone
fill 418 51 -420 420 51 -420 minecraft:stone
fill 418 51 -419 420 51 -419 minecraft:stone
fill 418 51 -418 421 51 -418 minecraft:stone
fill 418 51 -417 421 51 -417 minecraft:stone
fill 419 51 -416 421 51 -416 minecraft:stone
fill 407 51 -415 408 51 -415 minecraft:stone
fill 419 51 -415 421 51 -415 minecraft:stone
fill 406 51 -414 408 51 -414 minecraft:stone
fill 419 51 -414 421 51 -414 minecraft:stone
fill 407 51 -413 408 51 -413 minecraft:stone
fill 419 51 -413 421 51 -413 minecraft:stone
setblock 407 51 -412 minecraft:stone
fill 420 51 -412 421 51 -412 minecraft:stone
fill 420 51 -411 421 51 -411 minecraft:stone
fill 420 51 -410 422 51 -410 minecraft:stone
fill 420 51 -409 422 51 -409 minecraft:stone
fill 421 51 -408 422 51 -408 minecraft:stone
fill 421 51 -407 422 51 -407 minecraft:stone
setblock 422 51 -406 minecraft:stone
fill 421 51 -405 422 51 -405 minecraft:stone
setblock 422 51 -404 minecraft:stone
setblock 422 51 -403 minecraft:stone
setblock 422 51 -402 minecraft:stone
setblock 422 51 -400 minecraft:stone
setblock 422 51 -399 minecraft:stone
setblock 392 52 -440 minecraft:stone
fill 392 52 -439 393 52 -439 minecraft:stone
fill 392 52 -438 393 52 -438 minecraft:stone
setblock 392 52 -437 minecraft:stone
fill 408 52 -437 409 52 -437 minecraft:stone
setblock 392 52 -436 minecraft:stone
fill 409 52 -436 410 52 -436 minecraft:stone
fill 410 52 -435 411 52 -435 minecraft:stone
fill 411 52 -434 412 52 -434 minecraft:stone
fill 412 52 -433 413 52 -433 minecraft:stone
fill 412 52 -432 414 52 -432 minecraft:stone
fill 413 52 -431 415 52 -431 minecraft:stone
fill 413 52 -430 415 52 -430 minecraft:stone
fill 414 52 -429 416 52 -429 minecraft:stone
fill 415 52 -428 417 52 -428 minecraft:stone
fill 415 52 -427 417 52 -427 minecraft:stone
fill 416 52 -426 418 52 -426 minecraft:stone
fill 417 52 -425 418 52 -425 minecraft:stone
fill 417 52 -424 419 52 -424 minecraft:stone
fill 417 52 -423 419 52 -423 minecraft:stone
fill 417 52 -422 419 52 -422 minecraft:stone
fill 418 52 -421 420 52 -421 minecraft:stone
fill 418 52 -420 420 52 -420 minecraft:stone
fill 418 52 -419 420 52 -419 minecraft:stone
fill 418 52 -418 421 52 -418 minecraft:stone
fill 418 52 -417 421 52 -417 minecraft:stone
fill 419 52 -416 421 52 -416 minecraft:stone
fill 419 52 -415 421 52 -415 minecraft:stone
setblock 407 52 -414 minecraft:stone
fill 419 52 -414 421 52 -414 minecraft:stone
fill 406 52 -413 408 52 -413 minecraft:stone
fill 419 52 -413 421 52 -413 minecraft:stone
fill 406 52 -412 407 52 -412 minecraft:stone
fill 420 52 -412 421 52 -412 minecraft:stone
fill 420 52 -411 421 52 -411 minecraft:stone
fill 420 52 -410 422 52 -410 minecraft:stone
fill 420 52 -409 422 52 -409 minecraft:stone
fill 421 52 -408 422 52 -408 minecraft:stone
fill 421 52 -407 422 52 -407 minecraft:stone
setblock 422 52 -406 minecraft:stone
fill 421 52 -405 422 52 -405 minecraft:stone
setblock 422 52 -404 minecraft:stone
setblock 422 52 -403 minecraft:stone
setblock 422 52 -402 minecraft:stone
setblock 422 52 -400 minecraft:stone
setblock 422 52 -399 minecraft:stone
fill 408 53 -437 409 53 -437 minecraft:stone
fill 409 53 -436 410 53 -436 minecraft:stone
fill 410 53 -435 411 53 -435 minecraft:stone
fill 411 53 -434 412 53 -434 minecraft:stone
fill 412 53 -433 413 53 -433 minecraft:stone
fill 412 53 -432 414 53 -432 minecraft:stone
fill 413 53 -431 415 53 -431 minecraft:stone
fill 413 53 -430 415 53 -430 minecraft:stone
fill 414 53 -429 416 53 -429 minecraft:stone
fill 415 53 -428 417 53 -428 minecraft:stone
fill 415 53 -427 417 53 -427 minecraft:stone
fill 416 53 -426 418 53 -426 minecraft:stone
fill 417 53 -425 418 53 -425 minecraft:stone
fill 417 53 -424 419 53 -424 minecraft:stone
fill 418 53 -423 419 53 -423 minecraft:stone
fill 418 53 -422 419 53 -422 minecraft:stone
fill 418 53 -421 420 53 -421 minecraft:stone
fill 418 53 -420 420 53 -420 minecraft:stone
fill 418 53 -419 420 53 -419 minecraft:stone
fill 418 53 -418 421 53 -418 minecraft:stone
fill 418 53 -417 421 53 -417 minecraft:stone
fill 419 53 -416 421 53 -416 minecraft:stone
fill 419 53 -415 421 53 -415 minecraft:stone
setblock 407 53 -414 minecraft:stone
fill 419 53 -414 421 53 -414 minecraft:stone
fill 406 53 -413 407 53 -413 minecraft:stone
fill 419 53 -413 421 53 -413 minecraft:stone
fill 405 53 -412 407 53 -412 minecraft:stone
fill 420 53 -412 421 53 -412 minecraft:stone
fill 406 53 -411 407 53 -411 minecraft:stone
fill 420 53 -411 421 53 -411 minecraft:stone
setblock 406 53 -410 minecraft:stone
fill 420 53 -410 422 53 -410 minecraft:stone
fill 421 53 -409 422 53 -409 minecraft:stone
fill 421 53 -408 422 53 -408 minecraft:stone
fill 421 53 -407 422 53 -407 minecraft:stone
setblock 422 53 -406 minecraft:stone
setblock 422 53 -405 minecraft:stone
setblock 422 53 -404 minecraft:stone
setblock 422 53 -403 minecraft:stone
setblock 422 53 -402 minecraft:stone
setblock 422 53 -400 minecraft:stone
setblock 422 53 -399 minecraft:stone
setblock 411 54 -435 minecraft:stone
fill 411 54 -434 412 54 -434 minecraft:stone
fill 412 54 -433 413 54 -433 minecraft:stone
fill 412 54 -432 414 54 -432 minecraft:stone
fill 413 54 -431 415 54 -431 minecraft:stone
fill 414 54 -430 415 54 -430 minecraft:stone
fill 414 54 -429 416 54 -429 minecraft:stone
fill 415 54 -428 417 54 -428 minecraft:stone
fill 415 54 -427 417 54 -427 minecraft:stone
fill 416 54 -426 418 54 -426 minecraft:stone
fill 417 54 -425 418 54 -425 minecraft:stone
fill 417 54 -424 419 54 -424 minecraft:stone
fill 418 54 -423 419 54 -423 minecraft:stone
fill 418 54 -422 419 54 -422 minecraft:stone
fill 418 54 -421 420 54 -421 minecraft:stone
fill 418 54 -420 420 54 -420 minecraft:stone
fill 418 54 -419 420 54 -419 minecraft:stone
fill 418 54 -418 421 54 -418 minecraft:stone
fill 418 54 -417 421 54 -417 minecraft:stone
fill 419 54 -416 421 54 -416 minecraft:stone
fill 419 54 -415 421 54 -415 minecraft:stone
fill 419 54 -414 421 54 -414 minecraft:stone
fill 419 54 -413 421 54 -413 minecraft:stone
fill 406 54 -412 407 54 -412 minecraft:stone
fill 420 54 -412 421 54 -412 minecraft:stone
fill 405 54 -411 407 54 -411 minecraft:stone
fill 420 54 -411 421 54 -411 minecraft:stone
fill 405 54 -410 407 54 -410 minecraft:stone
fill 420 54 -410 422 54 -410 minecraft:stone
setblock 406 54 -409 minecraft:stone
fill 421 54 -409 422 54 -409 minecraft:stone
fill 421 54 -408 422 54 -408 minecraft:stone
setblock 422 54 -407 minecraft:stone
setblock 422 54 -406 minecraft:stone
setblock 422 54 -405 minecraft:stone
setblock 422 54 -404 minecraft:stone
setblock 422 54 -403 minecraft:stone
setblock 422 54 -402 minecraft:stone
setblock 422 54 -400 minecraft:stone
setblock 422 54 -399 minecraft:stone
setblock 412 55 -432 minecraft:stone
fill 414 55 -431 415 55 -431 minecraft:stone
fill 414 55 -430 415 55 -430 minecraft:stone
fill 414 55 -429 416 55 -429 minecraft:stone
fill 415 55 -428 417 55 -428 minecraft:stone
fill 416 55 -427 417 55 -427 minecraft:stone
fill 416 55 -426 418 55 -426 minecraft:stone
fill 417 55 -425 418 55 -425 minecraft:stone
fill 418 55 -424 419 55 -424 minecraft:stone
fill 418 55 -423 419 55 -423 minecraft:stone
fill 418 55 -422 419 55 -422 minecraft:stone
fill 418 55 -421 420 55 -421 minecraft:stone
fill 419 55 -420 420 55 -420 minecraft:stone
fill 419 55 -419 420 55 -419 minecraft:stone
fill 419 55 -418 421 55 -418 minecraft:stone
fill 419 55 -417 421 55 -417 minecraft:stone
fill 419 55 -416 421 55 -416 minecraft:stone
fill 419 55 -415 421 55 -415 minecraft:stone
fill 420 55 -414 421 55 -414 minecraft:stone
fill 420 55 -413 421 55 -413 minecraft:stone
setblock 406 55 -412 minecraft:stone
fill 420 55 -412 421 55 -412 minecraft:stone
setblock 406 55 -411 minecraft:stone
setblock 421 55 -411 minecraft:stone
fill 405 55 -410 407 55 -410 minecraft:stone
fill 421 55 -410 422 55 -410 minecraft:stone
fill 404 55 -409 406 55 -409 minecraft:stone
fill 421 55 -409 422 55 -409 minecraft:stone
setblock 405 55 -408 minecraft:stone
fill 421 55 -408 422 55 -408 minecraft:stone
setblock 422 55 -407 minecraft:stone
setblock 422 55 -406 minecraft:stone
setblock 422 55 -405 minecraft:stone
setblock 422 55 -404 minecraft:stone
setblock 422 55 -403 minecraft:stone
setblock 404 56 -441 minecraft:stone
setblock 405 56 -440 minecraft:stone
fill 405 56 -439 407 56 -439 minecraft:stone
fill 406 56 -438 408 56 -438 minecraft:stone
fill 406 56 -437 409 56 -437 minecraft:stone
fill 406 56 -436 410 56 -436 minecraft:stone
fill 406 56 -435 411 56 -435 minecraft:stone
fill 406 56 -434 412 56 -434 minecraft:stone
fill 406 56 -433 413 56 -433 minecraft:stone
fill 406 56 -432 414 56 -432 minecraft:stone
fill 407 56 -431 415 56 -431 minecraft:stone
fill 408 56 -430 415 56 -430 minecraft:stone
fill 410 56 -429 416 56 -429 minecraft:stone
setblock 412 56 -428 minecraft:stone
fill 419 56 -421 420 56 -421 minecraft:stone
fill 419 56 -420 420 56 -420 minecraft:stone
fill 419 56 -419 420 56 -419 minecraft:stone
fill 419 56 -418 421 56 -418 minecraft:stone
fill 419 56 -417 421 56 -417 minecraft:stone
fill 419 56 -416 421 56 -416 minecraft:stone
fill 419 56 -415 421 56 -415 minecraft:stone
fill 420 56 -414 421 56 -414 minecraft:stone
fill 420 56 -413 421 56 -413 minecraft:stone
fill 420 56 -412 421 56 -412 minecraft:stone
setblock 421 56 -411 minecraft:stone
fill 405 56 -410 406 56 -410 minecraft:stone
fill 421 56 -410 422 56 -410 minecraft:stone
fill 404 56 -409 407 56 -409 minecraft:stone
fill 421 56 -409 422 56 -409 minecraft:stone
fill 403 56 -408 406 56 -408 minecraft:stone
fill 421 56 -408 422 56 -408 minecraft:stone
fill 404 56 -407 405 56 -407 minecraft:stone
setblock 416 56 -404 minecraft:stone
fill 415 56 -403 418 56 -403 minecraft:stone
fill 413 56 -402 422 56 -402 minecraft:stone
fill 409 56 -401 422 56 -401 minecraft:stone
fill 408 56 -400 422 56 -400 minecraft:stone
fill 408 56 -399 422 56 -399 minecraft:stone
fill 408 56 -398 422 56 -398 minecraft:stone
fill 408 56 -397 422 56 -397 minecraft:stone
fill 408 56 -396 422 56 -396 minecraft:stone
fill 408 56 -395 422 56 -395 minecraft:stone
fill 409 56 -394 422 56 -394 minecraft:stone
fill 409 56 -393 422 56 -393 minecraft:stone
fill 409 56 -392 422 56 -392 minecraft:stone
fill 409 56 -391 422 56 -391 minecraft:stone
fill 408 56 -390 422 56 -390 minecraft:stone
fill 408 56 -389 422 56 -389 minecraft:stone
fill 408 56 -388 422 56 -388 minecraft:stone
fill 406 56 -387 422 56 -387 minecraft:stone
fill 405 56 -386 422 56 -386 minecraft:stone
fill 392 56 -385 393 56 -385 minecraft:stone
fill 403 56 -385 422 56 -385 minecraft:stone
fill 392 56 -384 395 56 -384 minecraft:stone
fill 401 56 -384 422 56 -384 minecraft:stone
fill 392 56 -383 422 56 -383 minecraft:stone
setblock 402 57 -442 minecraft:stone
fill 403 57 -441 404 57 -441 minecraft:stone
fill 403 57 -440 405 57 -440 minecraft:stone
fill 403 57 -439 407 57 -439 minecraft:stone
fill 404 57 -438 408 57 -438 minecraft:stone
fill 404 57 -437 409 57 -437 minecraft:stone
fill 404 57 -436 410 57 -436 minecraft:stone
fill 404 57 -435 411 57 -435 minecraft:stone
fill 404 57 -434 412 57 -434 minecraft:stone
fill 405 57 -433 413 57 -433 minecraft:stone
fill 405 57 -432 414 57 -432 minecraft:stone
fill 405 57 -431 415 57 -431 minecraft:stone
fill 406 57 -430 415 57 -430 minecraft:stone
fill 407 57 -429 416 57 -429 minecraft:stone
fill 408 57 -428 417 57 -428 minecraft:stone
fill 410 57 -427 417 57 -427 minecraft:stone
fill 412 57 -426 418 57 -426 minecraft:stone
setblock 418 57 -425 minecraft:stone
fill 418 57 -424 419 57 -424 minecraft:stone
setblock 419 57 -423 minecraft:stone
setblock 419 57 -422 minecraft:stone
setblock 420 57 -421 minecraft:stone
setblock 420 57 -420 minecraft:stone
setblock 421 57 -418 minecraft:stone
fill 420 57 -416 421 57 -416 minecraft:stone
fill 420 57 -415 421 57 -415 minecraft:stone
fill 420 57 -414 421 57 -414 minecraft:stone
fill 420 57 -413 421 57 -413 minecraft:stone
fill 420 57 -412 421 57 -412 minecraft:stone
fill 405 57 -409 406 57 -409 minecraft:stone
fill 404 57 -408 406 57 -408 minecraft:stone
fill 403 57 -407 406 57 -407 minecraft:stone
fill 415 57 -407 422 57 -407 minecraft:stone
fill 404 57 -406 405 57 -406 minecraft:stone
fill 412 57 -406 422 57 -406 minecraft:stone
fill 408 57 -405 422 57 -405 minecraft:stone
fill 406 57 -404 422 57 -404 minecraft:stone
fill 405 57 -403 422 57 -403 minecraft:stone
fill 405 57 -402 422 57 -402 minecraft:stone
fill 405 57 -401 422 57 -401 minecraft:stone
fill 405 57 -400 422 57 -400 minecraft:stone
fill 405 57 -399 422 57 -399 minecraft:stone
fill 405 57 -398 422 57 -398 minecraft:stone
fill 406 57 -397 422 57 -397 minecraft:stone
fill 406 57 -396 422 57 -396 minecraft:stone
fill 406 57 -395 422 57 -395 minecraft:stone
fill 406 57 -394 422 57 -394 minecraft:stone
fill 405 57 -393 422 57 -393 minecraft:stone
fill 405 57 -392 422 57 -392 minecraft:stone
fill 405 57 -391 422 57 -391 minecraft:stone
fill 404 57 -390 422 57 -390 minecraft:stone
setblock 392 57 -389 minecraft:stone
fill 404 57 -389 422 57 -389 minecraft:stone
setblock 392 57 -388 minecraft:stone
fill 399 57 -388 422 57 -388 minecraft:stone
fill 392 57 -387 395 57 -387 minecraft:stone
fill 397 57 -387 422 57 -387 minecraft:stone
fill 392 57 -386 422 57 -386 minecraft:stone
fill 392 57 -385 422 57 -385 minecraft:stone
fill 392 57 -384 422 57 -384 minecraft:stone
fill 392 57 -383 422 57 -383 minecraft:stone
fill 401 58 -442 402 58 -442 minecraft:stone
fill 401 58 -441 404 58 -441 minecraft:stone
fill 402 58 -440 405 58 -440 minecraft:stone
fill 402 58 -439 407 58 -439 minecraft:stone
fill 403 58 -438 408 58 -438 minecraft:stone
fill 403 58 -437 409 58 -437 minecraft:stone
fill 403 58 -436 410 58 -436 minecraft:stone
fill 404 58 -435 411 58 -435 minecraft:stone
fill 404 58 -434 412 58 -434 minecraft:stone
fill 404 58 -433 413 58 -433 minecraft:stone
fill 404 58 -432 414 58 -432 minecraft:stone
fill 404 58 -431 415 58 -431 minecraft:stone
fill 404 58 -430 415 58 -430 minecraft:stone
fill 405 58 -429 416 58 -429 minecraft:stone
fill 406 58 -428 417 58 -428 minecraft:stone
fill 407 58 -427 417 58 -427 minecraft:stone
fill 408 58 -426 418 58 -426 minecraft:stone
fill 408 58 -425 418 58 -425 minecraft:stone
fill 410 58 -424 419 58 -424 minecraft:stone
fill 413 58 -423 419 58 -423 minecraft:stone
fill 415 58 -422 419 58 -422 minecraft:stone
fill 416 58 -421 420 58 -421 minecraft:stone
fill 417 58 -420 420 58 -420 minecraft:stone
fill 418 58 -419 420 58 -419 minecraft:stone
fill 418 58 -418 421 58 -418 minecraft:stone
fill 419 58 -417 421 58 -417 minecraft:stone
fill 419 58 -416 421 58 -416 minecraft:stone
fill 420 58 -415 421 58 -415 minecraft:stone
fill 420 58 -414 421 58 -414 minecraft:stone
setblock 421 58 -411 minecraft:stone
fill 416 58 -410 422 58 -410 minecraft:stone
fill 413 58 -409 422 58 -409 minecraft:stone
setblock 405 58 -408 minecraft:stone
fill 409 58 -408 422 58 -408 minecraft:stone
fill 405 58 -407 406 58 -407 minecraft:stone
fill 408 58 -407 422 58 -407 minecraft:stone
fill 403 58 -406 422 58 -406 minecraft:stone
fill 403 58 -405 422 58 -405 minecraft:stone
fill 404 58 -404 422 58 -404 minecraft:stone
fill 404 58 -403 422 58 -403 minecraft:stone
fill 404 58 -402 422 58 -402 minecraft:stone
fill 404 58 -401 422 58 -401 minecraft:stone
fill 404 58 -400 422 58 -400 minecraft:stone
fill 404 58 -399 422 58 -399 minecraft:stone
fill 404 58 -398 422 58 -398 minecraft:stone
fill 404 58 -397 422 58 -397 minecraft:stone
fill 404 58 -396 422 58 -396 minecraft:stone
fill 404 58 -395 422 58 -395 minecraft:stone
fill 404 58 -394 422 58 -394 minecraft:stone
fill 404 58 -393 422 58 -393 minecraft:stone
fill 403 58 -392 422 58 -392 minecraft:stone
fill 402 58 -391 422 58 -391 minecraft:stone
fill 392 58 -390 399 58 -390 minecraft:stone
fill 401 58 -390 422 58 -390 minecraft:stone
fill 392 58 -389 422 58 -389 minecraft:stone
fill 392 58 -388 422 58 -388 minecraft:stone
fill 392 58 -387 422 58 -387 minecraft:stone
fill 392 58 -386 422 58 -386 minecraft:stone
fill 392 58 -385 422 58 -385 minecraft:stone
fill 392 58 -384 422 58 -384 minecraft:stone
fill 392 58 -383 422 58 -383 minecraft:stone
setblock 397 59 -444 minecraft:stone
fill 398 59 -443 400 59 -443 minecraft:stone
fill 399 59 -442 402 59 -442 minecraft:stone
fill 400 59 -441 404 59 -441 minecraft:stone
fill 400 59 -440 405 59 -440 minecraft:stone
fill 401 59 -439 407 59 -439 minecraft:stone
fill 402 59 -438 408 59 -438 minecraft:stone
fill 402 59 -437 409 59 -437 minecraft:stone
fill 402 59 -436 410 59 -436 minecraft:stone
fill 403 59 -435 411 59 -435 minecraft:stone
fill 403 59 -434 412 59 -434 minecraft:stone
fill 403 59 -433 413 59 -433 minecraft:stone
fill 403 59 -432 414 59 -432 minecraft:stone
fill 403 59 -431 415 59 -431 minecraft:stone
fill 404 59 -430 415 59 -430 minecraft:stone
fill 404 59 -429 416 59 -429 minecraft:stone
fill 404 59 -428 417 59 -428 minecraft:stone
fill 405 59 -427 417 59 -427 minecraft:stone
fill 406 59 -426 418 59 -426 minecraft:stone
fill 407 59 -425 418 59 -425 minecraft:stone
fill 407 59 -424 419 59 -424 minecraft:stone
fill 408 59 -423 419 59 -423 minecraft:stone
fill 408 59 -422 419 59 -422 minecraft:stone
fill 411 59 -421 420 59 -421 minecraft:stone
fill 413 59 -420 420 59 -420 minecraft:stone
fill 413 59 -419 420 59 -419 minecraft:stone
fill 414 59 -418 421 59 -418 minecraft:stone
fill 415 59 -417 421 59 -417 minecraft:stone
fill 417 59 -416 421 59 -416 minecraft:stone
fill 416 59 -415 421 59 -415 minecraft:stone
fill 416 59 -414 421 59 -414 minecraft:stone
fill 415 59 -413 421 59 -413 minecraft:stone
fill 415 59 -412 421 59 -412 minecraft:stone
fill 413 59 -411 421 59 -411 minecraft:stone
fill 411 59 -410 422 59 -410 minecraft:stone
fill 408 59 -409 422 59 -409 minecraft:stone
fill 406 59 -408 422 59 -408 minecraft:stone
fill 405 59 -407 422 59 -407 minecraft:stone
fill 404 59 -406 422 59 -406 minecraft:stone
fill 403 59 -405 422 59 -405 minecraft:stone
fill 403 59 -404 422 59 -404 minecraft:stone
fill 403 59 -403 422 59 -403 minecraft:stone
fill 403 59 -402 422 59 -402 minecraft:stone
fill 403 59 -401 422 59 -401 minecraft:stone
fill 404 59 -400 422 59 -400 minecraft:stone
fill 404 59 -399 422 59 -399 minecraft:stone
fill 404 59 -398 422 59 -398 minecraft:stone
fill 404 59 -397 422 59 -397 minecraft:stone
fill 404 59 -396 422 59 -396 minecraft:stone
fill 403 59 -395 422 59 -395 minecraft:stone
fill 403 59 -394 422 59 -394 minecraft:stone
fill 402 59 -393 422 59 -393 minecraft:stone
fill 392 59 -392 399 59 -392 minecraft:stone
fill 401 59 -392 422 59 -392 minecraft:stone
fill 392 59 -391 422 59 -391 minecraft:stone
fill 392 59 -390 422 59 -390 minecraft:stone
fill 392 59 -389 422 59 -389 minecraft:stone
fill 392 59 -388 422 59 -388 minecraft:stone
fill 392 59 -387 422 59 -387 minecraft:stone
fill 392 59 -386 422 59 -386 minecraft:stone
fill 392 59 -385 422 59 -385 minecraft:stone
fill 392 59 -384 422 59 -384 minecraft:stone
fill 392 59 -383 422 59 -383 minecraft:stone
fill 395 60 -444 397 60 -444 minecraft:stone
fill 396 60 -443 400 60 -443 minecraft:stone
fill 397 60 -442 402 60 -442 minecraft:stone
fill 398 60 -441 404 60 -441 minecraft:stone
fill 399 60 -440 405 60 -440 minecraft:stone
fill 400 60 -439 407 60 -439 minecraft:stone
fill 400 60 -438 408 60 -438 minecraft:stone
fill 401 60 -437 409 60 -437 minecraft:stone
fill 401 60 -436 410 60 -436 minecraft:stone
fill 402 60 -435 411 60 -435 minecraft:stone
fill 402 60 -434 412 60 -434 minecraft:stone
fill 402 60 -433 413 60 -433 minecraft:stone
fill 402 60 -432 414 60 -432 minecraft:stone
fill 402 60 -431 415 60 -431 minecraft:stone
fill 403 60 -430 415 60 -430 minecraft:stone
fill 403 60 -429 416 60 -429 minecraft:stone
fill 403 60 -428 417 60 -428 minecraft:stone
fill 404 60 -427 417 60 -427 minecraft:stone
fill 404 60 -426 418 60 -426 minecraft:stone
fill 405 60 -425 418 60 -425 minecraft:stone
fill 405 60 -424 419 60 -424 minecraft:stone
fill 406 60 -423 419 60 -423 minecraft:stone
fill 406 60 -422 419 60 -422 minecraft:stone
fill 406 60 -421 420 60 -421 minecraft:stone
fill 407 60 -420 420 60 -420 minecraft:stone
fill 408 60 -419 420 60 -419 minecraft:stone
fill 408 60 -418 421 60 -418 minecraft:stone
fill 409 60 -417 421 60 -417 minecraft:stone
fill 409 60 -416 421 60 -416 minecraft:stone
fill 410 60 -415 421 60 -415 minecraft:stone
fill 411 60 -414 421 60 -414 minecraft:stone
fill 411 60 -413 421 60 -413 minecraft:stone
fill 412 60 -412 421 60 -412 minecraft:stone
fill 410 60 -411 421 60 -411 minecraft:stone
fill 408 60 -410 422 60 -410 minecraft:stone
fill 405 60 -409 422 60 -409 minecraft:stone
fill 404 60 -408 422 60 -408 minecraft:stone
fill 403 60 -407 422 60 -407 minecraft:stone
fill 403 60 -406 422 60 -406 minecraft:stone
fill 402 60 -405 422 60 -405 minecraft:stone
fill 401 60 -404 422 60 -404 minecraft:stone
fill 402 60 -403 422 60 -403 minecraft:stone
fill 402 60 -402 422 60 -402 minecraft:stone
fill 403 60 -401 422 60 -401 minecraft:stone
fill 403 60 -400 422 60 -400 minecraft:stone
fill 403 60 -399 422 60 -399 minecraft:stone
fill 403 60 -398 422 60 -398 minecraft:stone
fill 403 60 -397 422 60 -397 minecraft:stone
fill 403 60 -396 422 60 -396 minecraft:stone
fill 402 60 -395 422 60 -395 minecraft:stone
fill 402 60 -394 422 60 -394 minecraft:stone
fill 401 60 -393 422 60 -393 minecraft:stone
fill 392 60 -392 422 60 -392 minecraft:stone
fill 392 60 -391 422 60 -391 minecraft:stone
fill 392 60 -390 422 60 -390 minecraft:stone
fill 392 60 -389 422 60 -389 minecraft:stone
fill 392 60 -388 422 60 -388 minecraft:stone
fill 392 60 -387 422 60 -387 minecraft:stone
fill 392 60 -386 422 60 -386 minecraft:stone
fill 392 60 -385 422 60 -385 minecraft:stone
fill 392 60 -384 422 60 -384 minecraft:stone
fill 392 60 -383 422 60 -383 minecraft:stone
setblock 394 61 -445 minecraft:stone
fill 394 61 -444 397 61 -444 minecraft:stone
fill 395 61 -443 400 61 -443 minecraft:stone
fill 395 61 -442 402 61 -442 minecraft:stone
fill 396 61 -441 404 61 -441 minecraft:stone
fill 397 61 -440 405 61 -440 minecraft:stone
fill 398 61 -439 407 61 -439 minecraft:stone
fill 399 61 -438 408 61 -438 minecraft:stone
fill 399 61 -437 409 61 -437 minecraft:stone
fill 400 61 -436 410 61 -436 minecraft:stone
fill 400 61 -435 411 61 -435 minecraft:stone
fill 401 61 -434 412 61 -434 minecraft:stone
fill 401 61 -433 413 61 -433 minecraft:stone
fill 401 61 -432 414 61 -432 minecraft:stone
fill 401 61 -431 415 61 -431 minecraft:stone
fill 401 61 -430 415 61 -430 minecraft:stone
fill 401 61 -429 416 61 -429 minecraft:stone
fill 401 61 -428 417 61 -428 minecraft:stone
fill 402 61 -427 417 61 -427 minecraft:stone
fill 403 61 -426 418 61 -426 minecraft:stone
fill 403 61 -425 418 61 -425 minecraft:stone
fill 404 61 -424 419 61 -424 minecraft:stone
fill 404 61 -423 419 61 -423 minecraft:stone
fill 403 61 -422 419 61 -422 minecraft:stone
fill 403 61 -421 420 61 -421 minecraft:stone
fill 403 61 -420 420 61 -420 minecraft:stone
fill 403 61 -419 420 61 -419 minecraft:stone
fill 404 61 -418 421 61 -418 minecraft:stone
fill 404 61 -417 421 61 -417 minecraft:stone
fill 404 61 -416 421 61 -416 minecraft:stone
fill 406 61 -415 421 61 -415 minecraft:stone
fill 407 61 -414 421 61 -414 minecraft:stone
fill 408 61 -413 421 61 -413 minecraft:stone
fill 409 61 -412 421 61 -412 minecraft:stone
fill 406 61 -411 421 61 -411 minecraft:stone
fill 404 61 -410 422 61 -410 minecraft:stone
fill 403 61 -409 422 61 -409 minecraft:stone
fill 403 61 -408 422 61 -408 minecraft:stone
fill 402 61 -407 422 61 -407 minecraft:stone
fill 401 61 -406 422 61 -406 minecraft:stone
fill 401 61 -405 422 61 -405 minecraft:stone
fill 400 61 -404 422 61 -404 minecraft:stone
fill 401 61 -403 422 61 -403 minecraft:stone
fill 401 61 -402 422 61 -402 minecraft:stone
fill 402 61 -401 422 61 -401 minecraft:stone
fill 402 61 -400 422 61 -400 minecraft:stone
fill 402 61 -399 422 61 -399 minecraft:stone
fill 402 61 -398 422 61 -398 minecraft:stone
fill 402 61 -397 422 61 -397 minecraft:stone
fill 402 61 -396 422 61 -396 minecraft:stone
fill 401 61 -395 422 61 -395 minecraft:stone
fill 398 61 -394 422 61 -394 minecraft:stone
fill 392 61 -393 422 61 -393 minecraft:stone
fill 392 61 -392 422 61 -392 minecraft:stone
fill 392 61 -391 422 61 -391 minecraft:stone
fill 392 61 -390 422 61 -390 minecraft:stone
fill 392 61 -389 422 61 -389 minecraft:stone
fill 392 61 -388 422 61 -388 minecraft:stone
fill 392 61 -387 422 61 -387 minecraft:stone
fill 392 61 -386 422 61 -386 minecraft:stone
fill 392 61 -385 422 61 -385 minecraft:stone
fill 392 61 -384 422 61 -384 minecraft:stone
fill 392 61 -383 422 61 -383 minecraft:stone
fill 392 62 -445 394 62 -445 minecraft:dirt
fill 392 62 -444 397 62 -444 minecraft:dirt
fill 393 62 -443 400 62 -443 minecraft:dirt
fill 393 62 -442 402 62 -442 minecraft:dirt
fill 394 62 -441 404 62 -441 minecraft:dirt
fill 395 62 -440 405 62 -440 minecraft:dirt
fill 396 62 -439 407 62 -439 minecraft:dirt
fill 397 62 -438 408 62 -438 minecraft:dirt
fill 397 62 -437 409 62 -437 minecraft:dirt
fill 398 62 -436 410 62 -436 minecraft:dirt
fill 398 62 -435 411 62 -435 minecraft:dirt
fill 399 62 -434 412 62 -434 minecraft:dirt
fill 399 62 -433 413 62 -433 minecraft:dirt
fill 399 62 -432 414 62 -432 minecraft:dirt
fill 399 62 -431 415 62 -431 minecraft:dirt
fill 399 62 -430 415 62 -430 minecraft:dirt
fill 400 62 -429 416 62 -429 minecraft:dirt
fill 400 62 -428 417 62 -428 minecraft:dirt
fill 400 62 -427 417 62 -427 minecraft:dirt
fill 401 62 -426 418 62 -426 minecraft:dirt
fill 401 62 -425 418 62 -425 minecraft:dirt
fill 402 62 -424 419 62 -424 minecraft:dirt
fill 402 62 -423 419 62 -423 minecraft:dirt
fill 401 62 -422 419 62 -422 minecraft:dirt
fill 401 62 -421 420 62 -421 minecraft:dirt
fill 400 62 -420 420 62 -420 minecraft:dirt
fill 400 62 -419 420 62 -419 minecraft:dirt
fill 401 62 -418 402 62 -418 minecraft:dirt
fill 404 62 -418 421 62 -418 minecraft:dirt
fill 400 62 -417 421 62 -417 minecraft:dirt
fill 400 62 -416 402 62 -416 minecraft:dirt
fill 404 62 -416 421 62 -416 minecraft:dirt
fill 401 62 -415 421 62 -415 minecraft:dirt
fill 401 62 -414 421 62 -414 minecraft:dirt
fill 402 62 -413 421 62 -413 minecraft:dirt
fill 403 62 -412 421 62 -412 minecraft:dirt
fill 402 62 -411 421 62 -411 minecraft:dirt
fill 401 62 -410 422 62 -410 minecraft:dirt
fill 401 62 -409 422 62 -409 minecraft:dirt
fill 401 62 -408 422 62 -408 minecraft:dirt
fill 400 62 -407 422 62 -407 minecraft:dirt
fill 399 62 -406 422 62 -406 minecraft:dirt
fill 398 62 -405 422 62 -405 minecraft:dirt
fill 397 62 -404 422 62 -404 minecraft:dirt
fill 398 62 -403 422 62 -403 minecraft:dirt
fill 399 62 -402 422 62 -402 minecraft:dirt
fill 400 62 -401 422 62 -401 minecraft:dirt
fill 401 62 -400 422 62 -400 minecraft:dirt
fill 401 62 -399 422 62 -399 minecraft:dirt
fill 401 62 -398 422 62 -398 minecraft:dirt
fill 401 62 -397 422 62 -397 minecraft:dirt
fill 401 62 -396 422 62 -396 minecraft:dirt
fill 396 62 -395 422 62 -395 minecraft:dirt
fill 392 62 -394 422 62 -394 minecraft:dirt
fill 392 62 -393 422 62 -393 minecraft:dirt
fill 392 62 -392 422 62 -392 minecraft:dirt
fill 392 62 -391 422 62 -391 minecraft:dirt
fill 392 62 -390 422 62 -390 minecraft:dirt
fill 392 62 -389 422 62 -389 minecraft:dirt
fill 392 62 -388 422 62 -388 minecraft:dirt
fill 392 62 -387 422 62 -387 minecraft:dirt
fill 392 62 -386 422 62 -386 minecraft:dirt
fill 392 62 -385 422 62 -385 minecraft:dirt
fill 392 62 -384 422 62 -384 minecraft:dirt
fill 392 62 -383 422 62 -383 minecraft:dirt
fill 392 63 -445 394 63 -445 minecraft:dirt
fill 392 63 -444 397 63 -444 minecraft:dirt
fill 392 63 -443 400 63 -443 minecraft:dirt
fill 392 63 -442 402 63 -442 minecraft:dirt
fill 392 63 -441 404 63 -441 minecraft:dirt
fill 392 63 -440 405 63 -440 minecraft:dirt
fill 393 63 -439 407 63 -439 minecraft:dirt
fill 394 63 -438 408 63 -438 minecraft:dirt
fill 394 63 -437 409 63 -437 minecraft:dirt
fill 395 63 -436 410 63 -436 minecraft:dirt
fill 395 63 -435 411 63 -435 minecraft:dirt
fill 396 63 -434 412 63 -434 minecraft:dirt
fill 396 63 -433 413 63 -433 minecraft:dirt
fill 396 63 -432 414 63 -432 minecraft:dirt
fill 396 63 -431 415 63 -431 minecraft:dirt
fill 397 63 -430 415 63 -430 minecraft:dirt
fill 397 63 -429 416 63 -429 minecraft:dirt
fill 397 63 -428 417 63 -428 minecraft:dirt
fill 398 63 -427 417 63 -427 minecraft:dirt
fill 398 63 -426 418 63 -426 minecraft:dirt
fill 399 63 -425 418 63 -425 minecraft:dirt
fill 399 63 -424 419 63 -424 minecraft:dirt
fill 399 63 -423 419 63 -423 minecraft:dirt
fill 398 63 -422 419 63 -422 minecraft:dirt
fill 398 63 -421 420 63 -421 minecraft:dirt
fill 398 63 -420 420 63 -420 minecraft:dirt
fill 398 63 -419 420 63 -419 minecraft:dirt
fill 398 63 -418 399 63 -418 minecraft:dirt
fill 401 63 -418 402 63 -418 minecraft:dirt
fill 404 63 -418 421 63 -418 minecraft:dirt
fill 398 63 -417 421 63 -417 minecraft:dirt
fill 398 63 -416 402 63 -416 minecraft:dirt
fill 404 63 -416 421 63 -416 minecraft:dirt
fill 398 63 -415 421 63 -415 minecraft:dirt
fill 398 63 -414 421 63 -414 minecraft:dirt
fill 398 63 -413 421 63 -413 minecraft:dirt
fill 397 63 -412 421 63 -412 minecraft:dirt
fill 396 63 -411 421 63 -411 minecraft:dirt
fill 397 63 -410 422 63 -410 minecraft:dirt
fill 396 63 -409 422 63 -409 minecraft:dirt
fill 393 63 -408 422 63 -408 minecraft:dirt
fill 392 63 -407 422 63 -407 minecraft:dirt
fill 392 63 -406 422 63 -406 minecraft:dirt
fill 392 63 -405 422 63 -405 minecraft:dirt
fill 392 63 -404 422 63 -404 minecraft:dirt
fill 392 63 -403 422 63 -403 minecraft:dirt
fill 393 63 -402 422 63 -402 minecraft:dirt
fill 394 63 -401 422 63 -401 minecraft:dirt
fill 394 63 -400 422 63 -400 minecraft:dirt
fill 393 63 -399 422 63 -399 minecraft:dirt
fill 393 63 -398 422 63 -398 minecraft:dirt
fill 393 63 -397 422 63 -397 minecraft:dirt
fill 392 63 -396 422 63 -396 minecraft:dirt
fill 392 63 -395 422 63 -395 minecraft:dirt
fill 392 63 -394 422 63 -394 minecraft:dirt
fill 392 63 -393 422 63 -393 minecraft:dirt
fill 392 63 -392 422 63 -392 minecraft:dirt
fill 392 63 -391 422 63 -391 minecraft:dirt
fill 392 63 -390 422 63 -390 minecraft:dirt
fill 392 63 -389 422 63 -389 minecraft:dirt
fill 392 63 -388 422 63 -388 minecraft:dirt
fill 392 63 -387 422 63 -387 minecraft:dirt
fill 392 63 -386 422 63 -386 minecraft:dirt
fill 392 63 -385 422 63 -385 minecraft:dirt
fill 392 63 -384 422 63 -384 minecraft:dirt
fill 392 63 -383 422 63 -383 minecraft:dirt
fill 392 64 -445 394 64 -445 minecraft:dirt
fill 392 64 -444 397 64 -444 minecraft:dirt
fill 392 64 -443 400 64 -443 minecraft:dirt
fill 392 64 -442 402 64 -442 minecraft:dirt
fill 392 64 -441 404 64 -441 minecraft:dirt
fill 392 64 -440 405 64 -440 minecraft:dirt
fill 392 64 -439 407 64 -439 minecraft:dirt
fill 392 64 -438 408 64 -438 minecraft:dirt
fill 392 64 -437 409 64 -437 minecraft:dirt
fill 392 64 -436 410 64 -436 minecraft:dirt
fill 392 64 -435 411 64 -435 minecraft:dirt
fill 392 64 -434 412 64 -434 minecraft:dirt
fill 392 64 -433 413 64 -433 minecraft:dirt
fill 392 64 -432 414 64 -432 minecraft:dirt
fill 392 64 -431 415 64 -431 minecraft:dirt
fill 392 64 -430 415 64 -430 minecraft:dirt
fill 392 64 -429 416 64 -429 minecraft:dirt
fill 392 64 -428 417 64 -428 minecraft:dirt
fill 392 64 -427 417 64 -427 minecraft:dirt
fill 392 64 -426 418 64 -426 minecraft:dirt
fill 392 64 -425 418 64 -425 minecraft:dirt
fill 393 64 -424 419 64 -424 minecraft:dirt
fill 393 64 -423 419 64 -423 minecraft:dirt
fill 393 64 -422 419 64 -422 minecraft:dirt
fill 393 64 -421 420 64 -421 minecraft:dirt
fill 393 64 -420 420 64 -420 minecraft:dirt
fill 393 64 -419 420 64 -419 minecraft:dirt
fill 393 64 -418 421 64 -418 minecraft:dirt
fill 393 64 -417 421 64 -417 minecraft:dirt
fill 393 64 -416 421 64 -416 minecraft:dirt
fill 393 64 -415 421 64 -415 minecraft:dirt
fill 392 64 -414 421 64 -414 minecraft:dirt
fill 392 64 -413 421 64 -413 minecraft:dirt
fill 392 64 -412 421 64 -412 minecraft:dirt
fill 392 64 -411 421 64 -411 minecraft:dirt
fill 392 64 -410 422 64 -410 minecraft:dirt
fill 392 64 -409 422 64 -409 minecraft:dirt
fill 392 64 -408 422 64 -408 minecraft:dirt
fill 392 64 -407 422 64 -407 minecraft:dirt
fill 392 64 -406 422 64 -406 minecraft:dirt
fill 392 64 -405 422 64 -405 minecraft:dirt
fill 392 64 -404 422 64 -404 minecraft:dirt
fill 392 64 -403 422 64 -403 minecraft:dirt
fill 392 64 -402 422 64 -402 minecraft:dirt
fill 392 64 -401 422 64 -401 minecraft:dirt
fill 392 64 -400 422 64 -400 minecraft:dirt
fill 392 64 -399 422 64 -399 minecraft:dirt
fill 392 64 -398 422 64 -398 minecraft:dirt
fill 392 64 -397 422 64 -397 minecraft:dirt
fill 392 64 -396 422 64 -396 minecraft:dirt
fill 392 64 -395 422 64 -395 minecraft:dirt
fill 392 64 -394 422 64 -394 minecraft:dirt
fill 392 64 -393 422 64 -393 minecraft:dirt
fill 392 64 -392 422 64 -392 minecraft:dirt
fill 392 64 -391 422 64 -391 minecraft:dirt
fill 392 64 -390 422 64 -390 minecraft:dirt
fill 392 64 -389 422 64 -389 minecraft:dirt
fill 392 64 -388 422 64 -388 minecraft:dirt
fill 392 64 -387 422 64 -387 minecraft:dirt
fill 392 64 -386 422 64 -386 minecraft:dirt
fill 392 64 -385 422 64 -385 minecraft:dirt
fill 392 64 -384 422 64 -384 minecraft:dirt
fill 392 64 -383 422 64 -383 minecraft:dirt
fill 392 65 -445 394 65 -445 minecraft:light_gray_concrete
fill 392 65 -444 397 65 -444 minecraft:light_gray_concrete
fill 392 65 -443 400 65 -443 minecraft:light_gray_concrete
fill 392 65 -442 396 65 -442 minecraft:light_gray_concrete
setblock 397 65 -442 minecraft:sea_lantern
fill 398 65 -442 402 65 -442 minecraft:light_gray_concrete
fill 392 65 -441 395 65 -441 minecraft:light_gray_concrete
setblock 396 65 -441 minecraft:sea_lantern
fill 397 65 -441 404 65 -441 minecraft:light_gray_concrete
fill 392 65 -440 393 65 -440 minecraft:smooth_quartz
setblock 394 65 -440 minecraft:light_gray_concrete
setblock 395 65 -440 minecraft:sea_lantern
fill 396 65 -440 403 65 -440 minecraft:light_gray_concrete
setblock 404 65 -440 minecraft:sea_lantern
setblock 405 65 -440 minecraft:light_gray_concrete
fill 392 65 -439 393 65 -439 minecraft:grass_block
fill 394 65 -439 396 65 -439 minecraft:smooth_quartz
fill 397 65 -439 402 65 -439 minecraft:light_gray_concrete
setblock 403 65 -439 minecraft:sea_lantern
fill 404 65 -439 407 65 -439 minecraft:light_gray_concrete
fill 392 65 -438 396 65 -438 minecraft:grass_block
fill 397 65 -438 399 65 -438 minecraft:smooth_quartz
fill 400 65 -438 401 65 -438 minecraft:light_gray_concrete
setblock 402 65 -438 minecraft:sea_lantern
fill 403 65 -438 408 65 -438 minecraft:light_gray_concrete
fill 392 65 -437 399 65 -437 minecraft:grass_block
fill 400 65 -437 401 65 -437 minecraft:smooth_quartz
fill 402 65 -437 409 65 -437 minecraft:light_gray_concrete
fill 392 65 -436 400 65 -436 minecraft:grass_block
fill 401 65 -436 402 65 -436 minecraft:smooth_quartz
fill 403 65 -436 408 65 -436 minecraft:light_gray_concrete
setblock 409 65 -436 minecraft:sea_lantern
setblock 410 65 -436 minecraft:light_gray_concrete
fill 392 65 -435 402 65 -435 minecraft:grass_block
fill 403 65 -435 404 65 -435 minecraft:smooth_quartz
fill 405 65 -435 407 65 -435 minecraft:light_gray_concrete
setblock 408 65 -435 minecraft:sea_lantern
fill 409 65 -435 411 65 -435 minecraft:light_gray_concrete
fill 392 65 -434 404 65 -434 minecraft:grass_block
setblock 405 65 -434 minecraft:smooth_quartz
setblock 406 65 -434 minecraft:light_gray_concrete
setblock 407 65 -434 minecraft:sea_lantern
fill 408 65 -434 412 65 -434 minecraft:light_gray_concrete
fill 392 65 -433 405 65 -433 minecraft:grass_block
setblock 406 65 -433 minecraft:smooth_quartz
fill 407 65 -433 413 65 -433 minecraft:light_gray_concrete
fill 392 65 -432 406 65 -432 minecraft:grass_block
setblock 407 65 -432 minecraft:smooth_quartz
fill 408 65 -432 414 65 -432 minecraft:light_gray_concrete
fill 392 65 -431 407 65 -431 minecraft:grass_block
setblock 408 65 -431 minecraft:smooth_quartz
fill 409 65 -431 412 65 -431 minecraft:light_gray_concrete
setblock 413 65 -431 minecraft:sea_lantern
fill 414 65 -431 415 65 -431 minecraft:light_gray_concrete
fill 392 65 -430 408 65 -430 minecraft:grass_block
setblock 409 65 -430 minecraft:smooth_quartz
fill 410 65 -430 411 65 -430 minecraft:light_gray_concrete
setblock 412 65 -430 minecraft:sea_lantern
fill 413 65 -430 415 65 -430 minecraft:light_gray_concrete
fill 392 65 -429 409 65 -429 minecraft:grass_block
setblock 410 65 -429 minecraft:smooth_quartz
setblock 411 65 -429 minecraft:sea_lantern
fill 412 65 -429 416 65 -429 minecraft:light_gray_concrete
fill 392 65 -428 410 65 -428 minecraft:grass_block
setblock 411 65 -428 minecraft:smooth_quartz
fill 412 65 -428 417 65 -428 minecraft:light_gray_concrete
fill 392 65 -427 410 65 -427 minecraft:grass_block
setblock 411 65 -427 minecraft:smooth_quartz
fill 412 65 -427 417 65 -427 minecraft:light_gray_concrete
fill 392 65 -426 411 65 -426 minecraft:grass_block
setblock 412 65 -426 minecraft:smooth_quartz
fill 413 65 -426 416 65 -426 minecraft:light_gray_concrete
setblock 417 65 -426 minecraft:sea_lantern
setblock 418 65 -426 minecraft:light_gray_concrete
fill 392 65 -425 411 65 -425 minecraft:grass_block
fill 412 65 -425 413 65 -425 minecraft:smooth_quartz
fill 414 65 -425 415 65 -425 minecraft:light_gray_concrete
setblock 416 65 -425 minecraft:sea_lantern
fill 417 65 -425 418 65 -425 minecraft:light_gray_concrete
fill 392 65 -424 412 65 -424 minecraft:grass_block
setblock 413 65 -424 minecraft:smooth_quartz
setblock 414 65 -424 minecraft:light_gray_concrete
setblock 415 65 -424 minecraft:sea_lantern
fill 416 65 -424 419 65 -424 minecraft:light_gray_concrete
fill 392 65 -423 413 65 -423 minecraft:grass_block
setblock 414 65 -423 minecraft:smooth_quartz
fill 415 65 -423 419 65 -423 minecraft:light_gray_concrete
fill 392 65 -422 413 65 -422 minecraft:grass_block
setblock 414 65 -422 minecraft:smooth_quartz
fill 415 65 -422 419 65 -422 minecraft:light_gray_concrete
fill 392 65 -421 413 65 -421 minecraft:grass_block
setblock 414 65 -421 minecraft:smooth_quartz
fill 415 65 -421 420 65 -421 minecraft:light_gray_concrete
fill 392 65 -420 414 65 -420 minecraft:grass_block
setblock 415 65 -420 minecraft:smooth_quartz
fill 416 65 -420 420 65 -420 minecraft:light_gray_concrete
fill 392 65 -419 414 65 -419 minecraft:grass_block
setblock 415 65 -419 minecraft:smooth_quartz
fill 416 65 -419 418 65 -419 minecraft:light_gray_concrete
setblock 419 65 -419 minecraft:sea_lantern
setblock 420 65 -419 minecraft:light_gray_concrete
fill 392 65 -418 414 65 -418 minecraft:grass_block
setblock 415 65 -418 minecraft:smooth_quartz
fill 416 65 -418 417 65 -418 minecraft:light_gray_concrete
setblock 418 65 -418 minecraft:sea_lantern
fill 419 65 -418 421 65 -418 minecraft:light_gray_concrete
fill 392 65 -417 415 65 -417 minecraft:grass_block
setblock 416 65 -417 minecraft:smooth_quartz
setblock 417 65 -417 minecraft:sea_lantern
fill 418 65 -417 421 65 -417 minecraft:light_gray_concrete
fill 392 65 -416 415 65 -416 minecraft:grass_block
setblock 416 65 -416 minecraft:smooth_quartz
fill 417 65 -416 421 65 -416 minecraft:light_gray_concrete
fill 392 65 -415 415 65 -415 minecraft:grass_block
setblock 416 65 -415 minecraft:smooth_quartz
fill 417 65 -415 421 65 -415 minecraft:light_gray_concrete
fill 392 65 -414 415 65 -414 minecraft:grass_block
setblock 416 65 -414 minecraft:smooth_quartz
fill 417 65 -414 421 65 -414 minecraft:light_gray_concrete
fill 392 65 -413 415 65 -413 minecraft:grass_block
setblock 416 65 -413 minecraft:smooth_quartz
fill 417 65 -413 421 65 -413 minecraft:light_gray_concrete
fill 392 65 -412 415 65 -412 minecraft:grass_block
setblock 416 65 -412 minecraft:smooth_quartz
fill 417 65 -412 421 65 -412 minecraft:light_gray_concrete
fill 392 65 -411 415 65 -411 minecraft:grass_block
setblock 416 65 -411 minecraft:smooth_quartz
fill 417 65 -411 419 65 -411 minecraft:light_gray_concrete
setblock 420 65 -411 minecraft:sea_lantern
setblock 421 65 -411 minecraft:light_gray_concrete
fill 392 65 -410 416 65 -410 minecraft:grass_block
setblock 417 65 -410 minecraft:smooth_quartz
setblock 418 65 -410 minecraft:light_gray_concrete
setblock 419 65 -410 minecraft:sea_lantern
fill 420 65 -410 422 65 -410 minecraft:light_gray_concrete
fill 392 65 -409 416 65 -409 minecraft:grass_block
setblock 417 65 -409 minecraft:smooth_quartz
setblock 418 65 -409 minecraft:sea_lantern
fill 419 65 -409 422 65 -409 minecraft:light_gray_concrete
fill 392 65 -408 416 65 -408 minecraft:grass_block
setblock 417 65 -408 minecraft:smooth_quartz
fill 418 65 -408 422 65 -408 minecraft:light_gray_concrete
fill 392 65 -407 416 65 -407 minecraft:grass_block
setblock 417 65 -407 minecraft:smooth_quartz
fill 418 65 -407 422 65 -407 minecraft:light_gray_concrete
fill 392 65 -406 416 65 -406 minecraft:grass_block
setblock 417 65 -406 minecraft:smooth_quartz
fill 418 65 -406 422 65 -406 minecraft:light_gray_concrete
fill 392 65 -405 416 65 -405 minecraft:grass_block
setblock 417 65 -405 minecraft:smooth_quartz
fill 418 65 -405 422 65 -405 minecraft:light_gray_concrete
fill 392 65 -404 416 65 -404 minecraft:grass_block
setblock 417 65 -404 minecraft:smooth_quartz
fill 418 65 -404 422 65 -404 minecraft:light_gray_concrete
fill 392 65 -403 416 65 -403 minecraft:grass_block
setblock 417 65 -403 minecraft:smooth_quartz
fill 418 65 -403 420 65 -403 minecraft:light_gray_concrete
setblock 421 65 -403 minecraft:sea_lantern
setblock 422 65 -403 minecraft:light_gray_concrete
fill 392 65 -402 416 65 -402 minecraft:grass_block
setblock 417 65 -402 minecraft:smooth_quartz
fill 418 65 -402 419 65 -402 minecraft:light_gray_concrete
setblock 420 65 -402 minecraft:sea_lantern
fill 421 65 -402 422 65 -402 minecraft:light_gray_concrete
fill 392 65 -401 416 65 -401 minecraft:grass_block
setblock 417 65 -401 minecraft:smooth_quartz
setblock 418 65 -401 minecraft:light_gray_concrete
setblock 419 65 -401 minecraft:sea_lantern
fill 420 65 -401 422 65 -401 minecraft:light_gray_concrete
fill 392 65 -400 416 65 -400 minecraft:grass_block
setblock 417 65 -400 minecraft:smooth_quartz
setblock 418 65 -400 minecraft:sea_lantern
fill 419 65 -400 422 65 -400 minecraft:light_gray_concrete
fill 392 65 -399 416 65 -399 minecraft:grass_block
setblock 417 65 -399 minecraft:smooth_quartz
fill 418 65 -399 422 65 -399 minecraft:light_gray_concrete
fill 392 65 -398 416 65 -398 minecraft:grass_block
setblock 417 65 -398 minecraft:smooth_quartz
fill 418 65 -398 422 65 -398 minecraft:light_gray_concrete
fill 392 65 -397 416 65 -397 minecraft:grass_block
setblock 417 65 -397 minecraft:smooth_quartz
fill 418 65 -397 422 65 -397 minecraft:light_gray_concrete
fill 392 65 -396 416 65 -396 minecraft:grass_block
setblock 417 65 -396 minecraft:smooth_quartz
fill 418 65 -396 422 65 -396 minecraft:light_gray_concrete
fill 392 65 -395 416 65 -395 minecraft:grass_block
setblock 417 65 -395 minecraft:smooth_quartz
fill 418 65 -395 422 65 -395 minecraft:light_gray_concrete
fill 392 65 -394 416 65 -394 minecraft:grass_block
setblock 417 65 -394 minecraft:smooth_quartz
fill 418 65 -394 420 65 -394 minecraft:light_gray_concrete
setblock 421 65 -394 minecraft:sea_lantern
setblock 422 65 -394 minecraft:light_gray_concrete
fill 392 65 -393 416 65 -393 minecraft:grass_block
setblock 417 65 -393 minecraft:smooth_quartz
fill 418 65 -393 419 65 -393 minecraft:light_gray_concrete
setblock 420 65 -393 minecraft:sea_lantern
fill 421 65 -393 422 65 -393 minecraft:light_gray_concrete
fill 392 65 -392 416 65 -392 minecraft:grass_block
setblock 417 65 -392 minecraft:smooth_quartz
setblock 418 65 -392 minecraft:light_gray_concrete
setblock 419 65 -392 minecraft:sea_lantern
fill 420 65 -392 422 65 -392 minecraft:light_gray_concrete
fill 392 65 -391 416 65 -391 minecraft:grass_block
setblock 417 65 -391 minecraft:smooth_quartz
setblock 418 65 -391 minecraft:sea_lantern
fill 419 65 -391 422 65 -391 minecraft:light_gray_concrete
fill 392 65 -390 416 65 -390 minecraft:grass_block
setblock 417 65 -390 minecraft:smooth_quartz
fill 418 65 -390 422 65 -390 minecraft:light_gray_concrete
fill 392 65 -389 416 65 -389 minecraft:grass_block
setblock 417 65 -389 minecraft:smooth_quartz
fill 418 65 -389 422 65 -389 minecraft:light_gray_concrete
fill 392 65 -388 416 65 -388 minecraft:grass_block
setblock 417 65 -388 minecraft:smooth_quartz
fill 418 65 -388 422 65 -388 minecraft:light_gray_concrete
fill 392 65 -387 416 65 -387 minecraft:grass_block
setblock 417 65 -387 minecraft:smooth_quartz
fill 418 65 -387 422 65 -387 minecraft:light_gray_concrete
fill 392 65 -386 416 65 -386 minecraft:grass_block
setblock 417 65 -386 minecraft:smooth_quartz
fill 418 65 -386 422 65 -386 minecraft:light_gray_concrete
fill 392 65 -385 416 65 -385 minecraft:grass_block
setblock 417 65 -385 minecraft:smooth_quartz
fill 418 65 -385 420 65 -385 minecraft:light_gray_concrete
setblock 421 65 -385 minecraft:sea_lantern
setblock 422 65 -385 minecraft:light_gray_concrete
fill 392 65 -384 416 65 -384 minecraft:grass_block
setblock 417 65 -384 minecraft:smooth_quartz
fill 418 65 -384 419 65 -384 minecraft:light_gray_concrete
setblock 420 65 -384 minecraft:sea_lantern
fill 421 65 -384 422 65 -384 minecraft:light_gray_concrete
fill 392 65 -383 416 65 -383 minecraft:grass_block
setblock 417 65 -383 minecraft:smooth_quartz
setblock 418 65 -383 minecraft:light_gray_concrete
setblock 419 65 -383 minecraft:sea_lantern
fill 420 65 -383 422 65 -383 minecraft:light_gray_concrete
setblock 396 66 -433 minecraft:oak_log
setblock 410 66 -420 minecraft:oak_log
setblock 412 66 -406 minecraft:oak_log
setblock 412 66 -396 minecraft:oak_log
setblock 412 66 -386 minecraft:oak_log
setblock 399 67 -443 minecraft:air
setblock 397 67 -438 minecraft:air
setblock 402 67 -437 minecraft:air
setblock 396 67 -433 minecraft:oak_log
setblock 400 67 -430 minecraft:air
setblock 394 67 -428 minecraft:air
setblock 410 67 -420 minecraft:oak_log
setblock 412 67 -406 minecraft:oak_log
setblock 412 67 -396 minecraft:oak_log
setblock 412 67 -386 minecraft:oak_log
setblock 392 68 -445 minecraft:air
setblock 395 68 -442 minecraft:air
setblock 392 68 -438 minecraft:air
setblock 396 68 -433 minecraft:oak_log
setblock 410 68 -420 minecraft:oak_log
setblock 412 68 -406 minecraft:oak_log
setblock 412 68 -396 minecraft:oak_log
setblock 412 68 -386 minecraft:oak_log
setblock 396 69 -435 minecraft:oak_leaves[persistent=true]
fill 395 69 -434 397 69 -434 minecraft:oak_leaves[persistent=true]
setblock 403 69 -434 minecraft:air
fill 394 69 -433 395 69 -433 minecraft:oak_leaves[persistent=true]
setblock 396 69 -433 minecraft:oak_log
fill 397 69 -433 398 69 -433 minecraft:oak_leaves[persistent=true]
fill 395 69 -432 397 69 -432 minecraft:oak_leaves[persistent=true]
setblock 396 69 -431 minecraft:oak_leaves[persistent=true]
setblock 396 69 -430 minecraft:air
setblock 410 69 -422 minecraft:oak_leaves[persistent=true]
fill 409 69 -421 411 69 -421 minecraft:oak_leaves[persistent=true]
fill 408 69 -420 409 69 -420 minecraft:oak_leaves[persistent=true]
setblock 410 69 -420 minecraft:oak_log
fill 411 69 -420 412 69 -420 minecraft:oak_leaves[persistent=true]
fill 409 69 -419 411 69 -419 minecraft:oak_leaves[persistent=true]
setblock 410 69 -418 minecraft:oak_leaves[persistent=true]
setblock 412 69 -408 minecraft:oak_leaves[persistent=true]
fill 411 69 -407 413 69 -407 minecraft:oak_leaves[persistent=true]
fill 410 69 -406 411 69 -406 minecraft:oak_leaves[persistent=true]
setblock 412 69 -406 minecraft:oak_log
fill 413 69 -406 414 69 -406 minecraft:oak_leaves[persistent=true]
fill 411 69 -405 413 69 -405 minecraft:oak_leaves[persistent=true]
setblock 412 69 -404 minecraft:oak_leaves[persistent=true]
setblock 412 69 -398 minecraft:oak_leaves[persistent=true]
fill 411 69 -397 413 69 -397 minecraft:oak_leaves[persistent=true]
fill 410 69 -396 411 69 -396 minecraft:oak_leaves[persistent=true]
setblock 412 69 -396 minecraft:oak_log
fill 413 69 -396 414 69 -396 minecraft:oak_leaves[persistent=true]
fill 411 69 -395 413 69 -395 minecraft:oak_leaves[persistent=true]
setblock 412 69 -394 minecraft:oak_leaves[persistent=true]
setblock 412 69 -388 minecraft:oak_leaves[persistent=true]
fill 411 69 -387 413 69 -387 minecraft:oak_leaves[persistent=true]
fill 410 69 -386 411 69 -386 minecraft:oak_leaves[persistent=true]
setblock 412 69 -386 minecraft:oak_log
fill 413 69 -386 414 69 -386 minecraft:oak_leaves[persistent=true]
fill 411 69 -385 413 69 -385 minecraft:oak_leaves[persistent=true]
setblock 412 69 -384 minecraft:oak_leaves[persistent=true]
setblock 403 70 -441 minecraft:air
fill 395 70 -435 397 70 -435 minecraft:oak_leaves[persistent=true]
fill 394 70 -434 398 70 -434 minecraft:oak_leaves[persistent=true]
fill 394 70 -433 395 70 -433 minecraft:oak_leaves[persistent=true]
setblock 396 70 -433 minecraft:oak_log
fill 397 70 -433 398 70 -433 minecraft:oak_leaves[persistent=true]
fill 394 70 -432 398 70 -432 minecraft:oak_leaves[persistent=true]
fill 395 70 -431 397 70 -431 minecraft:oak_leaves[persistent=true]
setblock 403 70 -428 minecraft:air
fill 409 70 -422 411 70 -422 minecraft:oak_leaves[persistent=true]
fill 408 70 -421 412 70 -421 minecraft:oak_leaves[persistent=true]
fill 408 70 -420 409 70 -420 minecraft:oak_leaves[persistent=true]
setblock 410 70 -420 minecraft:oak_log
fill 411 70 -420 412 70 -420 minecraft:oak_leaves[persistent=true]
fill 408 70 -419 412 70 -419 minecraft:oak_leaves[persistent=true]
fill 409 70 -418 411 70 -418 minecraft:oak_leaves[persistent=true]
fill 411 70 -408 413 70 -408 minecraft:oak_leaves[persistent=true]
fill 410 70 -407 414 70 -407 minecraft:oak_leaves[persistent=true]
fill 410 70 -406 411 70 -406 minecraft:oak_leaves[persistent=true]
setblock 412 70 -406 minecraft:oak_log
fill 413 70 -406 414 70 -406 minecraft:oak_leaves[persistent=true]
fill 410 70 -405 414 70 -405 minecraft:oak_leaves[persistent=true]
fill 411 70 -404 413 70 -404 minecraft:oak_leaves[persistent=true]
fill 411 70 -398 413 70 -398 minecraft:oak_leaves[persistent=true]
fill 410 70 -397 414 70 -397 minecraft:oak_leaves[persistent=true]
fill 410 70 -396 411 70 -396 minecraft:oak_leaves[persistent=true]
setblock 412 70 -396 minecraft:oak_log
fill 413 70 -396 414 70 -396 minecraft:oak_leaves[persistent=true]
fill 410 70 -395 414 70 -395 minecraft:oak_leaves[persistent=true]
fill 411 70 -394 413 70 -394 minecraft:oak_leaves[persistent=true]
fill 411 70 -388 413 70 -388 minecraft:oak_leaves[persistent=true]
fill 410 70 -387 414 70 -387 minecraft:oak_leaves[persistent=true]
fill 410 70 -386 411 70 -386 minecraft:oak_leaves[persistent=true]
setblock 412 70 -386 minecraft:oak_log
fill 413 70 -386 414 70 -386 minecraft:oak_leaves[persistent=true]
fill 410 70 -385 414 70 -385 minecraft:oak_leaves[persistent=true]
fill 411 70 -384 413 70 -384 minecraft:oak_leaves[persistent=true]
setblock 393 71 -436 minecraft:air
setblock 396 71 -435 minecraft:oak_leaves[persistent=true]
fill 395 71 -434 397 71 -434 minecraft:oak_leaves[persistent=true]
fill 394 71 -433 398 71 -433 minecraft:oak_leaves[persistent=true]
fill 395 71 -432 397 71 -432 minecraft:oak_leaves[persistent=true]
setblock 399 71 -432 minecraft:air
setblock 396 71 -431 minecraft:oak_leaves[persistent=true]
setblock 410 71 -422 minecraft:oak_leaves[persistent=true]
fill 409 71 -421 411 71 -421 minecraft:oak_leaves[persistent=true]
fill 408 71 -420 412 71 -420 minecraft:oak_leaves[persistent=true]
fill 409 71 -419 411 71 -419 minecraft:oak_leaves[persistent=true]
setblock 410 71 -418 minecraft:oak_leaves[persistent=true]
setblock 412 71 -408 minecraft:oak_leaves[persistent=true]
fill 411 71 -407 413 71 -407 minecraft:oak_leaves[persistent=true]
fill 410 71 -406 414 71 -406 minecraft:oak_leaves[persistent=true]
fill 411 71 -405 413 71 -405 minecraft:oak_leaves[persistent=true]
setblock 412 71 -404 minecraft:oak_leaves[persistent=true]
setblock 412 71 -398 minecraft:oak_leaves[persistent=true]
fill 411 71 -397 413 71 -397 minecraft:oak_leaves[persistent=true]
fill 410 71 -396 414 71 -396 minecraft:oak_leaves[persistent=true]
fill 411 71 -395 413 71 -395 minecraft:oak_leaves[persistent=true]
setblock 412 71 -394 minecraft:oak_leaves[persistent=true]
setblock 412 71 -388 minecraft:oak_leaves[persistent=true]
fill 411 71 -387 413 71 -387 minecraft:oak_leaves[persistent=true]
fill 410 71 -386 414 71 -386 minecraft:oak_leaves[persistent=true]
fill 411 71 -385 413 71 -385 minecraft:oak_leaves[persistent=true]
setblock 412 71 -384 minecraft:oak_leaves[persistent=true]
setblock 396 72 -433 minecraft:oak_leaves[persistent=true]
setblock 410 72 -420 minecraft:oak_leaves[persistent=true]
setblock 412 72 -406 minecraft:oak_leaves[persistent=true]
setblock 412 72 -396 minecraft:oak_leaves[persistent=true]
setblock 412 72 -386 minecraft:oak_leaves[persistent=true]
setblock 398 74 -439 minecraft:air
setblock 396 74 -434 minecraft:air
setblock 393 74 -426 minecraft:air
setblock 402 77 -441 minecraft:air
setblock 392 78 -442 minecraft:air
setblock 392 79 -434 minecraft:air
forceload remove 392 -446 455 -383
tellraw @a {"text":"Campus bau a07 fertig.","color":"green"}
