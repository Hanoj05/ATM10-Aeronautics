# Abschnitt a34: x 328..391, z -190..-127 (53061 Blöcke)
forceload add 328 -190 391 -127
tellraw @a {"text":"Campus bau a34: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a34_1 2s
