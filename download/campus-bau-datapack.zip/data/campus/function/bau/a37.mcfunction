# Abschnitt a37: x 72..135, z -126..-63 (2735 Blöcke)
forceload add 72 -126 135 -63
tellraw @a {"text":"Campus bau a37: Chunks werden geladen …","color":"gray"}
schedule function campus:bau/a37_1 2s
